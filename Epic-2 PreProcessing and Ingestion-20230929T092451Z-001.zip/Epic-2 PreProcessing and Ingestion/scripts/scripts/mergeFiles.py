import re, os
import time
import json
import logging
import collections
import sys, traceback
from csv import reader
from csv import DictReader
from scripts import processEachMsg as msgProcessor

def merge(destPath, logDict, logfile):
    logger = logging.getLogger(__name__)
    #destPath = 'D:\\prep\\odhprep_20221202180820_merge'
    #logFilePath = 'D:\\prep\\odhpreplogs_20221202180820'
    try:
        #for f in os.listdir(logFilePath):
        #    logfile = os.path.join(logFilePath, f)
    
        fileToMergeList = []
        filenameList = []
        filename = ''
        sizeToRollOut = 1024000000 #1 GB
        
        # Read log file
        with open(logfile, 'r',encoding='utf-8') as read_obj:
            csv_dict_reader = DictReader(read_obj, delimiter ="|")
            for row in csv_dict_reader:
                if (row['log-info-type'] == 'Mapping-Info'):
                    fileToMergeList.append(row['outputcsv'])
                    
        s=set(fileToMergeList)
        s = sorted(s)
        
        for s1 in s:
            n1 = s1.split('.')[0]
            n2 = s1.rfind('_')
            filename = s1[:n2]
            filenameList.append(filename)
            filename = ''
        filenameSet=set(filenameList)
        filenameSet=sorted(filenameSet)
         
        for filename in filenameSet:
            fileCount = len([x for x in os.listdir(destPath) if filename in x]) 
            mergedFilePath = destPath+'\\'+filename+'-merged.csv'
            #mergedFile = open(destPath+'\\'+filename+'-merged.csv','w')
            counter =0
            headerWritten=False
            for file in os.listdir(destPath):
                n1 = file.split('.')[0]
                n2 = file.rfind('_')
                if filename == file[:n2] :
        
                    counter +=1
                    fn= os.path.join(destPath, file)
                    fileToMerge = open(fn, 'r',encoding='utf-8')
                    dataToMerge = fileToMerge.readlines()
                    fileToMerge.close
                    header= dataToMerge[0]
                    for i in range(len(dataToMerge)):
                        fileexistsflag = msgProcessor.checkfileexists(mergedFilePath, sizeToRollOut, logDict, logfile)
                        if(fileexistsflag):
                            if(i==0 and headerWritten==True):
                                continue
                            with open(mergedFilePath, 'a',encoding='utf-8') as mergedFile:
                                mergedFile.write(dataToMerge[i])
                            headerWritten=True
                        else:
                            with open(mergedFilePath, 'a',encoding='utf-8') as mergedFile:
                            #mergedFile= open(mergedFilePath,'w')
                                if(i!=0):
                                    mergedFile.write(header)
                                    headerWritten=True
                                mergedFile.write(dataToMerge[i])
                                headerWritten=True
                    if counter < fileCount:
                        with open(mergedFilePath, 'a',encoding='utf-8') as mergedFile:
                            mergedFile.write("\n")       
        
            #mergedFile.close 
    except:
        raise
        
def deleteCsv(destPath):
    logger = logging.getLogger(__name__)
    #destPath = 'D:\\prep\\odhprep_20221202180820_merge'
    try:
        for f in os.listdir(destPath):
            file = os.path.join(destPath, f)
            if re.search("-merged",file) or re.search("REJECT",file):
                continue
            else:
                os.remove(file)
    except OSError as e:
        logger.error(e)
        logging.error(traceback.print_exc(file=sys.stdout))
        line= "Error-Info|NA| "+  os.path.basename(destPath) + "| NA| Exception| " + traceback.format_exc()
        msgProcessor.appendFile(logFilePath, line)
        #print("Error: %s : %s" % (file, e.strerror))
    except:
        raise
        
def renameMergedFile(destPath, logDict, logFilePath):
    logger = logging.getLogger(__name__)
    try:         
        #destPath = "D:\\prep\\odhprep_20221205234500"
        folderCreationTimestamp = destPath.split('_')[1][:14]
        
        for file in os.listdir(destPath): 
            if ".csv" in file:
                filename=file.replace("-merged","")
                #f1 = file.split('.')[0]
                #f2 = file.rfind('-')
                #filename = file[:f2]
                os.rename(destPath+'\\'+file, destPath+'\\'+filename)
        for newFileName in os.listdir(destPath):
            f1 = newFileName.split('.')[0]
            if (f1[-14:] == folderCreationTimestamp):
                updatedFileName = msgProcessor.appendTimestamp(os.path.join(destPath, newFileName)) 
                #write the mapping between the csv and avro for the ones where timestamp is appended 
                logDict = msgProcessor.flushToFile(logDict, newFileName, updatedFileName, logFilePath)
    except:
        raise
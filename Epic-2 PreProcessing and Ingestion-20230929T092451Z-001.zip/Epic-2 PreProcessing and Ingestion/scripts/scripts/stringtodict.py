import os
import json
import logging
import sys, traceback
from fastavro import reader
from scripts import processmsg as msgProcessor

def convert(srcPath, destPath, fileNamesList, sizeToRollOut, rejectFilePath, logDict, logFilePath):
    
    logger = logging.getLogger(__name__)     
    readRecordCount = 0
    processedRecordCount = 0
    folderCreationTimestamp = destPath.split('_')[1][:14]
    n1 = rejectFilePath.rfind('\\')
    rejectFilePath = rejectFilePath[:n1]+'\\Rejected_ODH_REJECTMESSAGE_'+folderCreationTimestamp
    
    try:
        #  Read the Reject message file'
        fo = open(srcPath, 'r',encoding='utf-8')
        rejectFileData = fo.readlines()
        fo.close
        for record in rejectFileData:
            if "message" in record:
                
                readRecordCount += 1
                
                try:
                
                    msgRecordString = record
                    msgRecordDict = json.loads(msgRecordString)
               
                    ##call process each msg function
                    msgProcessor.processMsgMain(srcPath, msgRecordDict['message'], destPath, fileNamesList, sizeToRollOut, logDict, logFilePath) 
                    processedRecordCount +=1
                    
                except Exception as e:
                    
                    logger.error(e)
                    logging.error(traceback.print_exc(file=sys.stdout))
                    line = "Input file: " + os.path.basename(srcPath) + " \n" + msgRecordString + "\n"
                    msgProcessor.appendFile(rejectFilePath, line)  
                    line= "Error-Info|NA| "+  os.path.basename(srcPath) + "| NA| Exception| " + traceback.format_exc()
                    msgProcessor.appendFile(logFilePath, line)
                    line= "Reject-Info|NA| "+  os.path.basename(srcPath) + "| NA| Reject| " + msgRecordString
                    msgProcessor.appendFile(logFilePath, line)
                pass    
        #print("Read record count: ",readRecordCount)
        #print("Processed record count: ",processedRecordCount)            
    except:
        raise




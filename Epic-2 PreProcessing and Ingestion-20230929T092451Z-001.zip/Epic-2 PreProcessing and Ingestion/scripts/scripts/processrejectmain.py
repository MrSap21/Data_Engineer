import re, os
import time
import json
import logging
import collections
import sys, traceback
from logging.config import fileConfig
from scripts import stringtodict as dictConverter
from scripts import processmsg as msgProcessor

global fileNamesList

'''python odhPreprocessorMain.py C:\Projects\PythonLanding\Python\src\odhsrc C:\Projects\PythonLanding\Python\output\odhprep C:\Projects\PythonLanding\Python\output\odhprep\rejectjson C:\Projects\PythonLanding\Python\output\odhpreplogs\logjson 1024'''
def processRejects(srcPath, destPath, fileNamesList, sizeToRollOut, rejectFilePath, logDict, logFilePath):
    
    logger = logging.getLogger(__name__)    
    logger.info("Started the Reject message processing----------------------")    
        
    try:          
        for file in os.listdir(srcPath):                                 
            if (file.startswith('ODH_REJECT')):
                filepath = os.path.join(srcPath, file)
                logger.info("file input to preprocess {}".format(filepath))  
                # Read reject message and convert it to dict
                dictConverter.convert(filepath, destPath, fileNamesList, sizeToRollOut, rejectFilePath, logDict, logFilePath)
                os.remove(filepath)
                count = collections.Counter(fileNamesList) 
                logger.info("Counters \n :  "+ str(count))
                
                line = "Counter-Info|NA| " +file + '| ' + str(count)  +'| NA| NA'                    
                msgProcessor.appendFile(logFilePath, line )    
                fileNamesList.clear() 
            
    except KeyError as k:
        logger.error("Key error occurred for {}".format(k)) 
        line= "Error-Info|NA| "+  os.path.basename(srcPath) + "| NA| Exception| " + traceback.format_exc()
        msgProcessor.appendFile(logFilePath, line)
        sys.exit(1)
        
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        logging.error(traceback.print_exc(file=sys.stdout))
        #print(traceback.print_tb(exc_traceback,limit=2, file=sys.stdout))
        #print(repr(traceback.format_exception(exc_type, exc_value, exc_traceback)))
        line= "Error-Info|NA| "+  os.path.basename(srcPath) + "| NA| Exception| " + traceback.format_exc()
        msgProcessor.appendFile(logFilePath, line)
        sys.exit(1)
        
    finally:
        time.sleep(1) 
        folderCreationTimestamp = destPath.split('_')[1][:14]
        #check for csv in the output folder and append timestamp for the files which dont have timestamp
        for file in os.listdir(destPath):
            if ".csv" in file:
                fname = file.split('.')[0]
                if (fname[-14:] == folderCreationTimestamp):
                    newFileName = msgProcessor.appendTimestamp(os.path.join(destPath, file)) 
                    #write the mapping between the csv and avro for the ones where timestamp is appended 
                    logDict = msgProcessor.flushToFile(logDict, file, newFileName, logFilePath) 
                                            
        logger.info("Completed processing reject message(s) ----------------------")
 

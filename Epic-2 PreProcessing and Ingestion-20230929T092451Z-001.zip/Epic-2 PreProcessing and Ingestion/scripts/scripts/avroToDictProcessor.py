import os
import json
import logging
import sys, traceback
from fastavro import reader
from scripts import processEachMsg as msgProcessor



def convert(srcPath, destPath, fileNamesList, sizeToRollOut, rejectFilePath, logDict, logFilePath):
    logger = logging.getLogger(__name__)     
    
    try:
        #  Read the Avro file 'C:\\Users\\acherian\\Documents\\odhpoc\\20_2.avro'
        with open(srcPath, 'rb') as fo:            
        
            avro_reader = reader(fo)
            for record in avro_reader:
                try:
                    msgBody = (bytearray(record['Body']))
                    #msgBody is of type bytes, hence convert to string first and then to dict
                    msgRecordString = ''.join(chr(x) for x in msgBody)
                    msgRecordDict = json.loads(msgRecordString)
                    
                    #call process each msg function
                    msgProcessor.processMsgMain(srcPath, msgRecordDict['message'], destPath, fileNamesList, sizeToRollOut, logDict, logFilePath) 
                except Exception as e:
                    logger.error(e)
                    logging.error(traceback.print_exc(file=sys.stdout))
                    line = "Avro: " + os.path.basename(srcPath) + " \n" + msgRecordString + "\n"
                    msgProcessor.appendFile(rejectFilePath, line)  
                    line= "Error-Info|NA| "+  os.path.basename(srcPath) + "| NA| Exception| " + traceback.format_exc()
                    msgProcessor.appendFile(logFilePath, line)
                    line= "Reject-Info|NA| "+  os.path.basename(srcPath) + "| NA| Reject| " + msgRecordString
                    msgProcessor.appendFile(logFilePath, line)
                    pass    
                        
    except:
        raise
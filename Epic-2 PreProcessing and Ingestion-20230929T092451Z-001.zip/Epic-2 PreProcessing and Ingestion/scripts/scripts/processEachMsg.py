import os, json, time
from datetime import datetime
import logging
import codecs
import re
#import locale


def unmangle_utf8(match):
    escaped = match.group(0)                   # '\\u00e2\\u0082\\u00ac'
    hexstr = escaped.replace(r'\u00', '')      # 'e282ac'
    buffer = codecs.decode(hexstr, "hex")      # b'\xe2\x82\xac'
    return buffer.decode('utf8')

def processMsg(avroPath, msg, destPath, fileNamesList, sizeToRollOut, logDict, logFilePath): 
    
    logger = logging.getLogger(__name__)     
             
    line = '\n'  
    try:
        #Getting the column names corresponding to tablename from json
        keylist = msg.keys()  
        fileName = keylist-['beforeData', 'headers']
        fileName = fileName.pop()
        
        attributenames = msg[fileName].keys()

        for attr in attributenames:
            attrvalue= json.dumps(msg[fileName][attr]) if msg[fileName][attr] is None else quoteAll(json.dumps(msg[fileName][attr]).rstrip('\"').lstrip('\"'))	
            #attrvalue= r"{}".format("\"\"") if json.dumps(msg[fileName][attr]) is None else json.dumps(msg[fileName][attr]) 
            attrvalue=re.sub(r"(?i)(?:\\u00[0-9a-f]{2})+", unmangle_utf8, attrvalue)
            line = line + attrvalue + '|'
        
        # Add timestamp and operation to list of attributenames
        csvheader = list(attributenames)
        csvheader.extend(['OPERATION', 'TIMESTAMP', 'TRANSACTIONID'])
        
        headOperation=json.dumps(msg['headers']['operation']) if msg['headers']['operation'] is None else quoteAll((msg['headers']['operation']))
        headTimestamp=json.dumps(msg['headers']['timestamp']) if msg['headers']['timestamp'] is None else quoteAll((msg['headers']['timestamp']))
        headTrsctnId=json.dumps(msg['headers']['transactionId'])    \
        if msg['headers']['transactionId'] is None else \
        quoteAll((msg['headers']['transactionId']))

        
      
        
        msg_extension=[headOperation,headTimestamp,headTrsctnId]
        #adding filenames to list for counters
        fileNamesList.append(fileName)
        csvheader = quoteAllList(csvheader)  #assuming csvheader will not have null values

        line = line + "|". join(msg_extension)
        avroFileName = os.path.basename(avroPath)
        folderCreationTimestamp = destPath.split('_')[1][:14]
        fileName = "ODH_" + fileName + "_" + folderCreationTimestamp
        fileexistsflag = checkfileexists(os.path.join(destPath, fileName+".csv"), sizeToRollOut, logDict, logFilePath) #'C:\\Users\\acherian\\Documents\\
        
        
        writecsvfile(os.path.join(destPath, fileName+".csv"), fileexistsflag, "|". join(csvheader), line, logDict, avroFileName)
        
    except:
        raise
  
        
    
    
def checkfileexists(filepath, sizeToRollOut, logDict,logFilePath): 
    logger = logging.getLogger(__name__) 
     
    try:
         
        maxSize = sizeToRollOut #1024000000 # 1GB
        if os.path.isfile(filepath):            
            size = os.path.getsize(filepath)
            
            if size> int(maxSize) :                
                fileName = appendTimestamp(filepath) 
                logger.info("size of filename is {}, hence renaming to {}".format(size, fileName))
                flushToFile(logDict, filepath, fileName, logFilePath)
                return False
            else:
                return True    
                     
        else:
            return False    
    except:
        raise
        
def flushToFile(logDict, filepath, newFileName, logFilePath):
    logger = logging.getLogger(__name__)
    try:
        fileName = os.path.basename(filepath)
        
        if fileName in logDict:
        
            v=logDict[fileName]
            
            if v and v.strip():
                for ls in v.split(','):
                    line= 'Mapping-Info|' + newFileName + '|' + ls + '|NA|NA|NA'         #maoping between csv and avro files in log excel
                    appendFile(logFilePath, line)                
                del logDict[fileName]               
        
        return logDict 
    except KeyError as k:        
        logger.error(k)
        raise
    except:
        raise

        
def appendFile(filePath, line):
    logger = logging.getLogger(__name__) 
    try:        
        with open(filePath, 'a',encoding='utf-8') as fl:       
            fl.write(line)
            fl.write('\n')
    except:
        raise    

def quoteAllList(itemList):
    try:
        quotedList=[]
        for item in itemList:
            quotedList.append(quoteAll(item))
        return quotedList
    except:
        raise        
               
       
def quoteAll(item):  
    #None case should be handled before calling this function   
    try: 
        if ("\"") in item:            
            item=item.replace("\"","\"\"")            
            
        if item is not None and len(str(item).strip())==0:
            return (r"{}".format("\"\""))        
        else:
            return(r"{}{}{}".format("\"", item, "\""))
                
         
    except:
        raise      
       
            
def appendTimestamp(filepath)  :
    try:
        time.sleep(1)
        fileName = os.path.basename(filepath)
        d = datetime.strptime(str(datetime.now()), "%Y-%m-%d %H:%M:%S.%f")
        s = d.strftime('%Y%m%d%H%M%S')
        fileName = fileName.split(".")[0] + '_' + s +'.csv'        
        os.rename(filepath, os.path.join(os.path.dirname(filepath),fileName )) 
        return fileName
    except:
        raise


def writecsvfile(filepath, fileexistsflag, header, line, logDict, avroFileName):
    logger = logging.getLogger(__name__) 
    try:
           
        with open(filepath, 'a',encoding='utf-8') as fo:
            if fileexistsflag == False:
                fo.write(header)                      
            
            fo.write(line) 
        fileName = os.path.basename(filepath)
        if fileName in logDict:
        
            if logDict.get(fileName) != avroFileName:
                logDict[fileName] = logDict[fileName] + ',' + avroFileName
        
        else:
            
            logDict[fileName] = avroFileName
            
        
    except:        
        raise
        
def processMsgMain(avroPath, msg, destPath, fileNamesList, sizeToRollOut, logDict, logFilePath):
    try:    
        processMsg(avroPath, msg, destPath, fileNamesList, sizeToRollOut, logDict, logFilePath)
    except :
        raise
    
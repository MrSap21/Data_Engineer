################################################################################################
## Name: GBSOP Kohls File
## Author: 
## Company: Walgreens Boots Alliance
## Purpose:
## Create csv files from web files (xlsx)
## Convert xlsx to csv
##
## Usage:
## It is called from a main .py (GBSOPKohls.py)
################################################################################################
## Ver By               Date         Change
## 0.1 Nishant Nigam	28/01/2021   Initial version
################################################################################################
import pandas as pd
import os as os
import fnmatch
from os import listdir
from os.path import isfile, join
import logging
import datetime as dt
import shutil
# local variables
l_name_file = 'GBSOPKohlsMain'
error_msg = ''
def KohlsXlsxToCSV(p_src_dir, p_dest_dir):
    ## Description: This 'def' read .xlsx, change format to .csv and save it
    ## par_src_dir: Source Directory path where the original file is
    ## par_dest_dir: Destination Directory path where the converted file is placed
    l_month = str(dt.date.today().year) + '-' + str(dt.date.today().month)  # + str(dt.date.today().day)
    l_day = str(dt.date.today().year) + '-' + str(dt.date.today().month)  + '-' + str(dt.date.today().day)

    ## DEBUG file
    l_logger = logging.getLogger(__name__)

    ## DEBUG level start
    l_logger.debug('START: ' + l_name_file)
    l_initfilename = 'Vendor SKU Data  Export*.xlsx'

    ## Process each file one by one
    ##for src_file_name in src_file_names:
    print('Checking for '+ p_src_dir)
    for file in os.listdir(p_src_dir):
        if fnmatch.fnmatch(file, l_initfilename):
            try:
                print('Found '+file)
                ## Path of the file to read
                src_file_path = (os.path.join(p_src_dir, file))
                l_logger.debug('Workings on: ' + src_file_path)

                ## Read the file in a python's pandas data frame.
                ## Load only the sheet specified in the sheet_name
                df = pd.read_excel(src_file_path,header=None)

                ## the destination file name is the same as the source file name by remove the .xlsx from the name as we want it to be a csv file
                ## pick name without extension from .xslx source file

                l_logger.debug('starting date extract on: ' + src_file_path)
                ##extract file date
                date = df.iloc[1,0]
                print(date)
                loaddate = date[-10:]
                print(loaddate)

                df.drop(df.index[[0, 1, 2, 3, 4, 5, 6, 7]], inplace=True)
                print('deleted the rows')
                df.drop(df.columns[[0, 1, 2, 3]], axis = 1, inplace=True)
                with pd.option_context('display.max_rows', None, 'display.max_columns', None):
                     print(df)
                ## Rename the columns
                df.columns = [
                "Brand"
                ,"BuyerCode"
                ,"BuyerDescription"
                ,"DeptCode"
                ,"DeptDescription"
                ,"ClassCode"
                ,"ClassDescription"
                ,"SubclassCode"
                ,"SubclassDescription"
                ,"GroupCode"
                ,"StyleCode"
                ,"StyleDescription"
                ,"VendorColor"
                ,"Size"
                ,"SKU"
                ,"UPC"
                ,"CorpUnitCost"
                ,"CorpUnitRetail"
                ,"WebEx"
                ,"LWStoresDemandAmt"
                ,"ShiftedLWStoresDemandSalesAmt"
                ,"LWStoresDemandUnits"
                ,"ShiftedLWStoresDemandSalesUnits"
                ,"LWStoresReceiptsAmt"
                ,"LWStoresReceiptsUnits"
                ,"MTDStoresDemandSalesAmt"
                ,"ShiftedMTDStoresDemandSalesAmt"
                ,"MTDStoresDemandSalesUnits"
                ,"ShiftedMTDStoresDemandSalesUnits"
                ,"STDStoresDemandSalesAmt"
                ,"ShiftedSTDStoresDemandSalesAmt"
                ,"STDStoresDemandSalesUnits"
                ,"ShiftedSTDStoresDemandSalesUnits"
                ,"StoresEOHAmt"
                ,"ShiftedStoresEOHAmt"
                ,"StoresEOHUnits"
                ,"ShiftedStoresEOHUnits"
                ,"StoresTotalOnOrderAmt"
                ,"StoresTotalOnOrderUnits"
                ,"LWDigitalDemandAmt"
                ,"ShiftedLWDigitalDemandSalesAmt"
                ,"LWDigitalDemandUnits"
                ,"ShiftedLWDigitalDemandSalesUnits"
                ,"LWDigitalReceiptsAmt"
                ,"LWDigitalReceiptsUnits"
                ,"MTDDigitalDemandSalesAmt"
                ,"ShiftedMTDDigitalDemandSalesAmt"
                ,"MTDDigitalDemandSalesUnits"
                ,"ShiftedMTDDigitalDemandSalesUnits"
                ,"STDDigital0DemandSalesAmt"
                ,"ShiftedSTDDigitalDemandSalesAmt"
                ,"STDDigitalDemandSalesUnits"
                ,"ShiftedSTDDigitalDemandSalesUnits"
                ,"EFCEOHAmt"
                ,"ShiftedEFCEOHAmt"
                ,"EFCEOHUnits"
                ,"ShiftedEFCEOHUnits"
                ,"DigitalTotalOnOrderAmt"
                ,"DigitalTotalOnOrderUnits"]

                print('After Rename')
                
                ## add .csv to the file name
                dst_file_name = file[:-5]
                df['FileDate'] = loaddate
                dst_file_path = (os.path.join(p_dest_dir, dst_file_name)) + r'.csv'

                l_logger.debug('Writing . . . ' + dst_file_path)

                ## Write the dataframe as a csv file
                df.to_csv(dst_file_path, index = None, header=True)
                shutil.move(src_file_path,(os.path.join(p_src_dir + '\processed', file)))
            except:
                l_logger.error(' - Error loading file: ' + src_file_path)
                l_logger.error(' - ' + error_msg)
    ## DEBUG level end
    l_logger.debug('END: ' + l_name_file)

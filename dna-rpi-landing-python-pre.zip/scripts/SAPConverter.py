################################################################################################
## Name: SAPConverter
## Author: 
## Company: Walgreens Boots Alliance
## Purpose:
## Create csv files from web files (xlsx)
## Convert xlsx to csv
##
## Usage:
## It is called from a main .py (SAPMmain.py)
################################################################################################
## Ver By               Date         Change
## 0.1 S Blakemore	    29/07/2020   Initial version
################################################################################################
import pandas as pd
import os as os
import fnmatch
from os import listdir
from os.path import isfile, join
import logging
import datetime as dt
import shutil
import traceback
import sys
# local variables
l_name_file = 'SAPConverter'
error_msg = ''
def SAPConverter(p_src_dir, p_dest_dir,p_filename):
    ## Description: This 'def' read .xlsx, change format to .csv and save it
    ## par_src_dir: Source Directory path where the original file is
    ## par_dest_dir: Destination Directory path where the converted file is placed
    l_month = str(dt.date.today().year) + '-' + str(dt.date.today().month)  # + str(dt.date.today().day)
    l_day = str(dt.date.today().year) + '-' + str(dt.date.today().month)  + '-' + str(dt.date.today().day)

    ## DEBUG file
    l_logger = logging.getLogger(__name__)

    ## DEBUG level start
    l_logger.debug('START: ' + l_name_file)
    l_initfilename = p_filename

    ## Process each file one by one
    ##for src_file_name in src_file_names:
    print('Checking for '+ p_src_dir)
    for file in os.listdir(p_src_dir):
        if fnmatch.fnmatch(file, l_initfilename):
            try:
                print('Found '+file)
                ## Path of the file to read
                src_file_path = (os.path.join(p_src_dir, file))
                l_logger.debug('Working on: ' + src_file_path)

                ## Read the file in a python's pandas data frame.
                df = pd.read_csv(src_file_path,header=None)
    
                ## Rename the columns
                df.columns = [
                "out_table",
                "csv_fields",
                "date_clause"
                ]

                df.drop('out_table',axis=1, inplace=True)
                df.drop('date_clause',axis=1, inplace=True)             

                sap_file_name = file[:-4]
                sap_file_name = sap_file_name[-4:]
                print(sap_file_name)

                ## Enter your SAP Header Here with the FOUR Letter lookup value
                if sap_file_name == 'VBRK':
                    df2 = pd.DataFrame([['MANDT|VBELN|FKART|FKTYP|VBTYP|WAERK|VKORG|VTWEG|KALSM|KNUMV|VSBED|FKDAT|BELNR|GJAHR|POPER|KONDA|KDGRP|BZIRK|PLTYP|INCO1|INCO2|EXPKZ|RFBSK|MRNKZ|KURRF|CPKUR|VALTG|VALDT|ZTERM|ZLSCH|KTGRD|LAND1|REGIO|COUNC|CITYC|BUKRS|TAXK1|TAXK2|TAXK3|TAXK4|TAXK5|TAXK6|TAXK7|TAXK8|TAXK9|NETWR|ZUKRI|ERNAM|ERZET|ERDAT|STAFO|KUNRG|KUNAG|MABER|STWAE|EXNUM|STCEG|AEDAT|SFAKN|KNUMA|FKART_RL|FKDAT_RL|KURST|MSCHL|MANSP|SPART|KKBER|KNKLI|CMWAE|CMKUF|HITYP_PR|BSTNK_VF|VBUND|FKART_AB|KAPPL|LANDTX|STCEG_H|STCEG_L|XBLNR|ZUONR|MWSBK|LOGSYS|FKSTO|XEGDR|RPLNR|LCNUM|J_1AFITP|KURRF_DAT|AKWAE|AKKUR|KIDNO|BVTYP|NUMPG|BUPLA|VKONT|FKK_DOCSTAT|NRZAS|SPE_BILLING_IND|VTREF|MNDID|PAY_TYPE|SEPON|MNDVG|XXXXX']],columns=['csv_fields'])
                elif sap_file_name == 'VBRP':
                    df2 = pd.DataFrame([['MANDT|VBELN|POSNR|UEPOS|FKIMG|VRKME|UMVKZ|UMVKN|MEINS|SMENG|FKLMG|LMENG|NTGEW|BRGEW|GEWEI|VOLUM|VOLEH|GSBER|PRSDT|FBUDA|KURSK|NETWR|VBELV|POSNV|VGBEL|VGPOS|VGTYP|AUBEL|AUPOS|AUREF|MATNR|ARKTX|PMATN|CHARG|MATKL|PSTYV|POSAR|PRODH|VSTEL|ATPKZ|SPART|POSPA|WERKS|ALAND|WKREG|WKCOU|WKCTY|TAXM1|TAXM2|TAXM3|TAXM4|TAXM5|TAXM6|TAXM7|TAXM8|TAXM9|KOWRR|PRSFD|SKTOF|SKFBP|KONDM|KTGRM|KOSTL|BONUS|PROVG|EANNR|VKGRP|VKBUR|SPARA|SHKZG|ERNAM|ERDAT|ERZET|BWTAR|LGORT|STAFO|WAVWR|KZWI1|KZWI2|KZWI3|KZWI4|KZWI5|KZWI6|STCUR|UVPRS|UVALL|EAN11|PRCTR|KVGR1|KVGR2|KVGR3|KVGR4|KVGR5|MVGR1|MVGR2|MVGR3|MVGR4|MVGR5|MATWA|BONBA|KOKRS|PAOBJNR|PS_PSP_PNR|AUFNR|TXJCD|CMPRE|CMPNT|CUOBJ|CUOBJ_CH|KOUPD|UECHA|XCHAR|ABRVW|SERNR|BZIRK_AUFT|KDGRP_AUFT|KONDA_AUFT|LLAND_AUFT|MPROK|PLTYP_AUFT|REGIO_AUFT|VKORG_AUFT|VTWEG_AUFT|ABRBG|PROSA|UEPVW|AUTYP|STADAT|FPLNR|FPLTR|AKTNR|KNUMA_PI|KNUMA_AG|PREFE|MWSBP|AUGRU_AUFT|FAREG|UPMAT|UKONM|CMPRE_FLT|ABFOR|ABGES|J_1ARFZ|J_1AREGIO|J_1AGICD|J_1ADTYP|J_1ATXREL|J_1BCFOP|J_1BTAXLW1|J_1BTAXLW2|J_1BTXSDC|BRTWR|WKTNR|WKTPS|RPLNR|KURSK_DAT|WGRU1|WGRU2|KDKG1|KDKG2|KDKG3|KDKG4|KDKG5|VKAUS|J_1AINDXP|J_1AIDATEP|KZFME|MWSKZ|VERTT|VERTN|SGTXT|DELCO|BEMOT|RRREL|AKKUR|WMINR|VGBEL_EX|VGPOS_EX|LOGSYS|VGTYP_EX|J_1BTAXLW3|J_1BTAXLW4|J_1BTAXLW5|MSR_ID|MSR_REFUND_CODE|MSR_RET_REASON|AUFPL|APLZL|PEROP_BEG|PEROP_END|FONDS|FISTL|FKBER|GRANT_NBR|PPRCTR|PARGB|CAMPAIGN|COMPREAS|XXXXX']],columns=['csv_fields'])
                else:
                    df2 = pd.DataFrame([['']],columns=['csv_fields'])
                    print('Problem')

                df3 = pd.concat([df2, df], ignore_index=True)

                l_logger.debug('After Rename: ')

                ## add .csv to the file name
                dst_file_name = file[:-4]
                dst_file_path = (os.path.join(p_dest_dir, dst_file_name)) + r'.csv'

                l_logger.debug('Writing . . . ' + dst_file_path)

                ## Write the dataframe as a csv file
                df3.to_csv(dst_file_path, index = None, header=False)

            except:
                l_logger.error(' - Error loading file: ' + src_file_path)
                l_logger.error(' - ' + error_msg)
                exc_type, exc_value, exc_traceback = sys.exc_info()
                traceback.print_exception(exc_type, exc_value, exc_traceback)
                ## DEBUG level end
                l_logger.debug('END: ' + l_name_file)

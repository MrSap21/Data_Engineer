################################################################################################
## Name: WAGProductsConverter
## Author: WBADZ - BI
## Company: < b > Walgreens Boots Alliance < / b >
## Purpose:
## Create csv files from 'wagus_iri_products*subset.dat'
##
## Usage:
## It is called from a main .py (WAGmain.py)
################################################################################################
## Ver By               Date         Change
## 0.1 Enrique Barberan 13/12/2019   Initial version
################################################################################################
import pandas as pd
import os as os
from os import listdir
from os.path import isfile, join
import logging
import datetime as dt
import shutil
## variables
l_name_file = 'WAGProductsConverter'
e_msg = ''
def WAGProductsToCSV(p_src_dir, p_dest_dir):
    ## Description:
    ## par_src_dir: Source Directory path where the original file is
    ## par_dest_dir: Destination Directory path where the converted file sholud be placed
    l_month = str(dt.date.today().year) + '-' + str(dt.date.today().month) #+ str(dt.date.today().day)
    l_day = str(dt.date.today().year) + '-' + str(dt.date.today().month)  + '-' + str(dt.date.today().day)
    ## DEBUG file
    l_logger = logging.getLogger(__name__)
    ## DEBUG level start
    l_logger.debug('START: ' + l_name_file)

    ## Get the names of all the files in the directory and save the names as a list
    ## filter by: extension and initial string
    l_extension = ['dat']
    l_initfilename = ['wagus_iri_products']
    src_file_names = [fn for fn in os.listdir(p_src_dir)
                  if any(fn.endswith(ext) for ext in l_extension)
                      and
                      any(fn.startswith(ext) for ext in l_initfilename)]
    ## Test print filter files <---- delete comment and command
    ## print(src_file_names)

    for src_file_name in src_file_names:
            try:
                ## Path of the file to read
                src_file_path = (os.path.join(p_src_dir, src_file_name))
                l_logger.debug('Working on: ' + src_file_path)

                ## Get the date from the file path. String between index 15 and 5 of the file name starting from the end
                date = src_file_path[25:33]

                ## Read the file in a pandas library data frame.
                df = pd.read_csv(src_file_path, sep = '|',encoding='latin1')
                l_logger.debug('End reading on: ' + src_file_path)
                ## Rename the columns
                df.columns = [
                    "upc_code", #1
                    "upc_desc", #2
                    "src_sys_cd", #3
                    "retail_prdct_id", #4
                    "item_desc", #5
                    "dept_nbr", #6
                    "dept_name", #7
                    "cat_nbr", #8
                    "cat_name", #9
                    "mfr_nbr", #10
                    "mfr_name", #11
                    "brd_nbr", #12
                    "brd_name", #13
                    "discontinued_ind", #14
                    "add_dt", #15
                    "del_dt", #16
                    "unit_of_measure_desc", #17
                    "retail_pack_size", #18
                    "pvt_label_ind", #19
                    "sales_catg_prod_id", #20
                    "sales_catg_name", #21
                    "mdse_div_nbr", #22
                    "mdse_div_name", #23
                    "mdse_cat_nbr", #24
                    "mdse_cat_name", #25
                    "pln_nbr", #26
                    "pln_name", #27
                    "gmm_nbr", #28
                    "gmm_name", #29
                    "store_count", #30
                    "basic_prod_ind", #31
                    "whse_prod_vendor_name", #32
                    "wic", #33
                    "same_retail_link_nbr"]  #34
                df.loc[:, 'filename'] = src_file_name
                df.loc[:, 'filedate'] = date
                df.loc[:, 'createdate'] = l_day

                ## Print the dataframe just for debugging purpose
                ## with pd.option_context('display.max_rows', None, 'display.max_columns', None):
                ## print(df)

                ## the destination file name is the same as the source file name
                ## Build destination filename
                dst_file_name = src_file_name[:-4]
                ##add .csv to the file name
                dst_file_path = (os.path.join(p_dest_dir, dst_file_name)) + r'.csv'
                l_logger.debug('Writting . . . ' + dst_file_path)

                ## Write the dataframe as a csv file
                df.to_csv(dst_file_path, index = None, header=True)

                ## move source file
                shutil.move(src_file_path,(os.path.join(p_src_dir + '\processed', src_file_name)))
            except Exception as err:
                l_logger.error(' - Error loading file: ' + src_file_path)
                l_logger.error(' - ' + err.__str__())
    ## DEBUG level end
    l_logger.debug('END: ' + l_name_file)
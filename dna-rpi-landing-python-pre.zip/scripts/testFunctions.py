import logging as logg
def same_initial(wd1, wd2):
    logg.basicConfig(filename='example.log', level=logg.DEBUG)
    if wd1[0].lower() == wd2[0].lower():
        logg.debug('.debug. it is the same, true - wd1:' + wd1 )
        logg.info('.info. it is the same, true - wd1:' + wd1 )
        logg.warning('.warning.  it is the same, true - wd1:' + wd1 )
        return True
    else:
        logg.debug('.debug. it is not the same, false - wd2:' + wd2 )
        logg.info('.info. it is not the same, false - wd2:' + wd2 )
        logg.warning('.warning.  it is not the same, false - wd2:' + wd2 )
        return False
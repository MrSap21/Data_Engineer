################################################################################################
## Name: SDMStoreSales
## Author: 
## Company: Walgreens Boots Alliance
## Purpose:
## Create csv files from web files (xlsx)
## Convert xlsx to csv
##
## Usage:
## It is called from a main .py (SDMmain.py)
################################################################################################
## Ver By               Date         Change
## 0.1 S Blakemore	    23/03/2020   Initial version
################################################################################################
import pandas as pd
import os as os
import fnmatch
from os import listdir
from os.path import isfile, join
import logging
import datetime as dt
import shutil
# local variables
l_name_file = 'SkinSGStoreSales'
error_msg = ''
def SkinXlsxToCSV(p_src_dir, p_dest_dir):
    ## Description: This 'def' read .xlsx, change format to .csv and save it
    ## par_src_dir: Source Directory path where the original file is
    ## par_dest_dir: Destination Directory path where the converted file is placed
    l_month = str(dt.date.today().year) + '-' + str(dt.date.today().month)  # + str(dt.date.today().day)
    l_day = str(dt.date.today().year) + '-' + str(dt.date.today().month)  + '-' + str(dt.date.today().day)

    ## DEBUG file
    l_logger = logging.getLogger(__name__)

    ## DEBUG level start
    l_logger.debug('START: ' + l_name_file)
    l_initfilename = 'SG sales wk*.xlsx'

    ## Process each file one by one
    ##for src_file_name in src_file_names:
    print('Checking for '+ p_src_dir)
    for file in os.listdir(p_src_dir):
        if fnmatch.fnmatch(file, l_initfilename):
            try:
                print('Found '+file)
                ## Path of the file to read
                src_file_path = (os.path.join(p_src_dir, file))
                l_logger.debug('Working on: ' + src_file_path)

                ## Read the file in a python's pandas data frame.
                ## Load only the sheet specified in the sheet_name
                df = pd.read_excel(src_file_path,header=None)

                ## the destination file name is the same as the source file name by remove the .xlsx from the name as we want it to be a csv file
                ## pick name without extension from .xslx source file

                ## Extract Week Number and Year from the First Row Header
                ##year = df.iloc[0,0]
                ##loadyear = year[-4:]
                ##loadweek = year[-7:-5]
					
                df.drop(df.index[[0,1,2]], inplace=True)
    
                ## Rename the columns
                df.columns = [
	            "DateSplit",
	            "ProductID",
	            "UPC",
	            "Title",
                "ListPriceorRevenueLocalSkinstore",
	            "UnitsSkinstore",
	            "ListPriceorRevenueLocalTotal",
				"UnitsTotal"]

                ##df.drop('Dummy1',axis=1, inplace=True)
                ##df.drop('Dummy2',axis=1, inplace=True)
                ##df.drop('Dummy3',axis=1, inplace=True)
                ##df.drop('Dummy4',axis=1, inplace=True)                

                l_logger.debug('After Rename: ')
                ## Dataframes seems to be creating the following columns as Float, just changes these back.
                ##print(df.dtypes)
                ##df['Store_Num'] = df['Store_Num'].astype(str)
                df['UPC'] = df['UPC'].astype(str)	
                ##df['Size'] = df['Size'].astype(str)		
                #print(df.dtypes)
	
	            ## As we've changed the datatypes it leaves behind a decimal point
                df['UPC'] = df['UPC'].str.replace('\.0','')
                ##df['Size'] = df['Size'].str.replace('\.0','')
                ##df=df.fillna(value=0)

                df['ListPriceorRevenueLocalSkinstore'] = df['ListPriceorRevenueLocalSkinstore'].astype(str)
                df['ListPriceorRevenueLocalSkinstore'] = df['ListPriceorRevenueLocalSkinstore'].str[:5]
                df['UnitsSkinstore'] = df['UnitsSkinstore'].astype(str)
                df['UnitsSkinstore'] = df['UnitsSkinstore'].str[:6]
                df['ListPriceorRevenueLocalTotal'] = df['ListPriceorRevenueLocalTotal'].astype(str)
                df['ListPriceorRevenueLocalTotal'] = df['ListPriceorRevenueLocalTotal'].str[:5]
                df['UnitsTotal'] = df['UnitsTotal'].astype(str)
                df['UnitsTotal'] = df['UnitsTotal'].str[:6]
                ##df['Units_Pct_Var'] = df['Units_Pct_Var'].astype(str)
                ##df['Units_Pct_Var'] = df['Units_Pct_Var'].str[:10]
                ##df['Units_YTD'] = df['Units_YTD'].astype(str)
                ##df['Units_YTD'] = df['Units_YTD'].str[:10]
                ##df['Units_LYTD'] = df['Units_LYTD'].astype(str)
                ##df['Units_LYTD'] = df['Units_LYTD'].str[:10]
                ##df['Units_YTD_Pct_Var'] = df['Units_YTD_Pct_Var'].astype(str)
                ##df['Units_YTD_Pct_Var'] = df['Units_YTD_Pct_Var' ].str[:10]       
                l_logger.debug('After Conversion: ')				
                
                ##df['FinYear'] = loadyear
                ##df['WeekNumber'] = loadweek
                df['FileDate'] = 'Dummy'

                df.drop(df[df.ProductID=='Total'].index , inplace=True)
                ##df = df[df['Title'].str.contains("Soap and Glory")]
                ##df = df[~df['Title'].str.contains("Soap and Glory")]

                ## add .csv to the file name
                dst_file_name = file[:-5]
                dst_file_path = (os.path.join(p_dest_dir, dst_file_name)) + r'.csv'

                l_logger.debug('Writing . . . ' + dst_file_path)

                ## Write the dataframe as a csv file
                df.to_csv(dst_file_path, index = None, header=True)
                shutil.move(src_file_path,(os.path.join(p_src_dir + '\processed', file)))
            except:
                l_logger.error(' - Error loading file: ' + src_file_path)
                l_logger.error(' - ' + error_msg)
    ## DEBUG level end
    l_logger.debug('END: ' + l_name_file)

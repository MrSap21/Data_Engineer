################################################################################################
## Name: ULTAconverter
## Author: WBADZ - BI
## Company: Walgreens Boots Alliance
## Purpose:
## Create csv files from web files (xlsx)
## Convert xlsx to csv
##
## Usage:
## It is called from a main .py (ULTAmain.py)
################################################################################################
## Ver By               Date         Change
## 0.1 Enrique Barberan 04/12/2019   Initial version
## 0.2 Enrique Barberan 08/01/2020   Eliminate checking dates
################################################################################################
import pandas as pd
import os as os
from os import listdir
from os.path import isfile, join
import logging
import datetime as dt
import shutil
# local variables
l_name_file = 'ULTAconverter'
error_msg = ''
def UltaXlsxToCSV(p_src_dir, p_dest_dir):
    ## Description: This 'def' read .xlsx, change format to .csv and save it
    ## par_src_dir: Source Directory path where the original file is
    ## par_dest_dir: Destination Directory path where the converted file is placed
    l_month = str(dt.date.today().year) + '-' + str(dt.date.today().month)  # + str(dt.date.today().day)
    l_day = str(dt.date.today().year) + '-' + str(dt.date.today().month)  + '-' + str(dt.date.today().day)

    ## DEBUG file
    l_logger = logging.getLogger(__name__)

    ## DEBUG level start
    l_logger.debug('START: ' + l_name_file)
    l_initfilename = 'Sales-Inv-Perf'
    ## Get the names of all the files in the directory and save the names as a list
    src_file_names = [fn for fn in listdir(p_src_dir) if isfile(join(p_src_dir, fn))
                      if any(fn.startswith(ext) for ext in l_initfilename)
                      ]

    ## Process each file one by one
    for src_file_name in src_file_names:
            try:
                ## Path of the file to read
                src_file_path = (os.path.join(p_src_dir, src_file_name))
                l_logger.debug('Working on: ' + src_file_path)

                ## Get the date from the file path. String between index 15 and 5 of the file name starting from the end
                date = src_file_path[-15:-5]
                # print(date[0:7]) test variable
                #if date[0:7] != l_month:
                #    error_msg = 'The month is not correct. Month of today is: ' + l_month + '| month of file is: ' + date[0:7]
                #    raise Exception(error_msg)


                ## Read the file in a python's pandas data frame.
                ## Load only the sheet specified in the sheet_name
                ## Skip the first 6 rows of the excel sheet
                df = pd.read_excel(src_file_path, sheet_name='Last Closed Week', skiprows = 6)

                ## Drop the first column as it is empty in the 'Last Closed Week' excel file
                df = df.drop(df.columns[0], axis=1)

                ## Drop the row that contains "Overall Result" text in the entire row
                df = df.iloc[1:]

                ## Rename the columns
                df.columns = [
                    "UPC",
                    "ULTAItem",
                    "ULTAItemDescription",
                    "BrandPartnerSKU",
                    "Brand",
                    "RetailItemRank",
                    "FeatureCode",
                    "SeasonCode",
                    "PurchaseCostAverage",
                    "RetailPriceCurrent",
                    "TOTALSalesTYUnits",
                    "TOTALSalesLYUnits",
                    "TOTALSalesUnitChgPercent",
                    "TOTALSalesTYAmount",
                    "TOTALSalesLYAmount",
                    "TOTALSalesAmountChgPercent",
                    "COMPSalesTYUnits",
                    "COMPSalesLYUnits",
                    "COMPSalesUnitChgPercent",
                    "COMPSalesTYAmount",
                    "COMPSalesLYAmount",
                    "COMPSalesAmountChgPercent",
                    "NONCOMPSalesTYUnits",
                    "NONCOMPSalesLYUnits",
                    "NONCOMPSalesUnitChgPercent",
                    "NONCOMPSalesTYAmount",
                    "NONCOMPSalesLYAmount",
                    "NONCOMPSalesAmountChgPercent",
                    "DOTCOMSalesTYUnits",
                    "DOTCOMSalesLYUnits",
                    "DOTCOMSalesUnitChgPercent",
                    "DOTCOMSalesTYAmount",
                    "DOTCOMSalesLYAmount",
                    "DOTCOMSalesAmountChgPercent",
                    "TOTALEOHSalesTYUnits",
                    "TOTALEOHSalesLYUnits",
                    "TOTALEOHSalesUnitChgPercent",
                    "TOTALEOHSalesTYAmount",
                    "TOTALEOHSalesLYAmount",
                    "TOTALEOHSalesAmountChgPercent",
                    "TOTALEOHUnitsL5W",
                    "TOTALEOHWOS",
                    "DCEOHSalesTYUnits",
                    "DCEOHSalesLYUnits",
                    "DCEOHSalesUnitChgPercent",
                    "DCEOHSalesTYAmount",
                    "DCEOHSalesLYAmount",
                    "DCEOHSalesAmountChgPercent",
                    "DCEOHOnOrderUnits",
                    "DCEOHATPUnits",
                    "DCEOHWebReserve",
                    "DCEOHDotcomWOS",
                    "DCEOHTotalWOS",
                    "DC822EOH",
                    "DC822ATP",
                    "DC822WebReserve",
                    "DC822OnOrderUnits",
                    "DC822WOS",
                    "DC822StoreCount",
                    "DC833EOH",
                    "DC833ATP",
                    "DC833WebReserve",
                    "DC833OnOrderUnits",
                    "DC833WOS",
                    "DC833StoreCount",
                    "DC844EOH",
                    "DC844ATP",
                    "DC844WebReserve",
                    "DC844OnOrderUnits",
                    "DC844WOS",
                    "DC844StoreCount",
                    "DC855EOH",
                    "DC855ATP",
                    "DC855WebReserve",
                    "DC855OnOrderUnits",
                    "DC855WOS",
                    "DC855StoreCount",
                    "DC888EOH",
                    "DC888ATP",
                    "DC888OnOrderUnits",
                    "DC888WOS",
                    "DC808EOH",
                    "DC808ATP",
                    "DC808OnOrderUnits",
                    "DC808WOS",
                    "STOREEOHTYUnits",
                    "STOREEOHLYUnits",
                    "STOREEOHUnitChgPercent",
                    "STOREEOHTYAmount",
                    "STOREEOHLYAmount",
                    "STOREEOHAmountChgPercent",
                    "STOREOnOrderUnits",
                    "STOREInTransitUnits",
                    "STOREAvgSalesL5WUnits",
                    "STORETotalWOS",
                    "StoreCount",
                    "StoreOuts",
                    "StoreInStockPercent"]
                df.loc[:, 'filename'] = src_file_name
                df.loc[:, 'filedate'] = date
                df.loc[:, 'createdate'] = l_day

                df.drop('DC808EOH',axis=1, inplace=True)  
                df.drop('DC808ATP',axis=1, inplace=True)  
                df.drop('DC808OnOrderUnits',axis=1, inplace=True)  
                df.rename({'DC808WOS': 'DC888StoreCount'}, axis=1, inplace=True)

                df['ULTAItem'] = df['ULTAItem'].astype(str)
                df['ULTAItem'] = df['ULTAItem'].str.replace('\.0','')

                ## Print the dataframe just for debugging purpose
                ## with pd.option_context('display.max_rows', None, 'display.max_columns', None):
                ## print(df)

                ## òJÓ (èyÉ in Spanish) - test save take less columns by name
                ## df2 = df[[
                    ##     "UPC",
                    ##     "ULTAItem",
                    ##     "ULTAItemDescription",
                    ##     "BrandPartnerSKU",
                    ##     "Brand",
                    ##     "RetailItemRank",
                    ##     "FeatureCode",
                    ##     "TOTALSalesTYUnits",
                    ##     "TOTALSalesLYUnits",
                    ##     "STOREEOHLYUnits",
                    ##     "StoreInStockPercent"]]
                ## Add constant column for trace
                ## df2.loc[:, 'filename'] = src_file_name
                ## df2.loc[:, 'filedate'] = date
                ## df2.loc[:, 'createdate'] = l_day


                ## the destination file name is the same as the source file name by remove the .xlsx from the name as we want it to be a csv file
                ## pick name without extension from .xslx source file
                dst_file_name = src_file_name[:-5]
                ## add .csv to the file name
                dst_file_path = (os.path.join(p_dest_dir, dst_file_name)) + r'.csv'
                l_logger.debug('Writting . . . ' + dst_file_path)

                ## Write the dataframe as a csv file
                df.to_csv(dst_file_path, index = None, header=True)

                ## òJÓ (eye in Spanish) - test save less columns selected before
                ## df2.to_csv((os.path.join(p_dest_dir, dst_file_name)) + r'_xxxx2.csv', index = None, header=True)

                ## delete source file
                ## os.remove(src_file_path)

                ## move source file
                shutil.move(src_file_path,(os.path.join(p_src_dir + '\processed', src_file_name)))
            except:
                l_logger.error(' - Error loading file: ' + src_file_path)
                l_logger.error(' - ' + error_msg)
    ## DEBUG level end
    l_logger.debug('END: ' + l_name_file)
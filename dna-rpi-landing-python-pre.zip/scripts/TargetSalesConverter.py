################################################################################################
## Name: SDMStoreSales
## Author: 
## Company: Walgreens Boots Alliance
## Purpose:
## Create csv files from web files (xlsx)
## Convert xlsx to csv
##
## Usage:
## It is called from a main .py (SDMmain.py)
################################################################################################
## Ver By               Date         Change
## 0.1 S Blakemore	    16/03/2020   Initial version
################################################################################################
import pandas as pd
import os as os
import fnmatch
from os import listdir
from os.path import isfile, join
import logging
import datetime as dt
import shutil
# local variables
l_name_file = 'DermStore'
error_msg = ''
def TargetCSV(p_src_dir, p_dest_dir):
    ## Description: This 'def' read .xlsx, change format to .csv and save it
    ## par_src_dir: Source Directory path where the original file is
    ## par_dest_dir: Destination Directory path where the converted file is placed
    l_month = str(dt.date.today().year) + '-' + str(dt.date.today().month)  # + str(dt.date.today().day)
    l_day = str(dt.date.today().year) + '-' + str(dt.date.today().month)  + '-' + str(dt.date.today().day)

    ## DEBUG file
    l_logger = logging.getLogger(__name__)

    ## DEBUG level start
    l_logger.debug('START: ' + l_name_file)
    l_initfilename = 'GDH Daily Sales - Previous Day*.csv'

    ## Process each file one by one
    ##for src_file_name in src_file_names:
    print('Checking for '+ p_src_dir)
    for file in os.listdir(p_src_dir):
        if fnmatch.fnmatch(file, l_initfilename):
            try:
                print('Found '+file)
                ## Path of the file to read
                src_file_path = (os.path.join(p_src_dir, file))
                l_logger.debug('Working on: ' + src_file_path)

                ## Read the file in a python's pandas data frame.
                ## Load only the sheet specified in the sheet_name
                df = pd.read_csv(src_file_path,header=None)

                #df.drop(df.tail(7).index,inplace=True) 
                #df = df[df['your column'].isin(['CHANNEL','ONLINE','STORE'])]
                df = df[df.loc[:,0].isin(['CHANNEL - ORIGINATED','ONLINE','STORE','Channel - Originated'])]
				
                ## add .csv to the file name
                dst_file_name = file[:-4]
                dst_file_path = (os.path.join(p_dest_dir, dst_file_name)) + r'.csv'

                l_logger.debug('Writing . . . ' + dst_file_path)

                ## Write the dataframe as a csv file
                df.to_csv(dst_file_path, index = None, header=None)
                shutil.move(src_file_path,(os.path.join(p_src_dir + '\processed', file)))
            except:
                l_logger.error(' - Error loading file: ' + src_file_path)
                l_logger.error(' - ' + error_msg)
    ## DEBUG level end
    l_logger.debug('END: ' + l_name_file)

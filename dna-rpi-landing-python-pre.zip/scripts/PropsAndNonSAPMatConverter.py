################################################################################################
## Name: PropsAndNonSAPMatconverter
## Author: WBADZ - BI
## Company: Walgreens Boots Alliance
## Purpose:
## Create csv files from web files (xlsx)
## Convert xlsx to csv
##
## Usage:
## It is called from a main.py (SAPMasterFilesmain.py)
################################################################################################
## Ver By               Date         Change
## 0.1 Enrique Barberan 18/12/2019   Initial version
################################################################################################
import sys
import pandas as pd
import os as os
import logging
import datetime as dt
import shutil
# local variables
l_name_file = 'Props and Non SAP Material Sales Reporting Master Data.xlsx'
error_msg = ''
def PropsAndNonSAPMatXlsxToCSV(p_src_dir, p_dest_dir):
    ## Description: This 'def' read .xlsx, change format to .csv and save it
    ## par_src_dir: Source Directory path where the original file is
    ## par_dest_dir: Destination Directory path where the converted file is placed
    l_month = str(dt.date.today().year) + '-' + str(dt.date.today().month)  # + str(dt.date.today().day)
    l_day = str(dt.date.today().year) + '-' + str(dt.date.today().month)  + '-' + str(dt.date.today().day)

    ## DEBUG file
    l_logger = logging.getLogger(__name__)

    ## DEBUG level start
    l_logger.debug('START: ' + l_name_file)

    ## There is only 1 file always with the same name
    l_initfilename = 'Props and Non SAP Material Sales Reporting Master Data.xlsx'

    try:
        ## Path of the file to read
        src_file_path = (os.path.join(p_src_dir, l_initfilename))
        l_logger.debug('Working on: ' + src_file_path)

        ## Read the file in a python's pandas data frame.
        ## Load only the sheet specified in the sheet_name
        ## Skip the first 1 row of the excel sheet
        df = pd.read_excel(src_file_path, sheet_name='Sheet1', skiprows = 1)
        df = df.replace({r'\n': ''}, regex=True)

        # Get ndArray of all column names
        columnsNamesArr = df.columns.values
        # convert ndarray to list
        listOfColumnNames = list(columnsNamesArr)
        l_logger.debug('columnsNamesArr: ' + columnsNamesArr)
        # Change or delete characters from column names
        listOfColumnNames = [col.replace(':', '') for col in listOfColumnNames]
        listOfColumnNames = [col.replace('-', '') for col in listOfColumnNames]
        listOfColumnNames = [col.replace(' ', '') for col in listOfColumnNames]
        listOfColumnNames = [col.replace('/', '') for col in listOfColumnNames]
        listOfColumnNames = [col.replace('(', '') for col in listOfColumnNames]
        listOfColumnNames = [col.replace(')', '') for col in listOfColumnNames]

        # Rename Columns
        df.columns = listOfColumnNames

        ## Add constant column for tracing
        df.loc[:, 'filename'] = l_name_file
        df.loc[:, 'filedate'] = l_day
        df.loc[:, 'createdate'] = l_day

        ## Print the dataframe just for debugging purpose
        ## with pd.option_context('display.max_rows', None, 'display.max_columns', None):
        ## print(df)

        ## the destination file name is the same as the source file name by remove the .xlsx from the name as we want it to be a csv file
        ## pick name without extension from .xslx source file
        dst_file_name = l_name_file[:-5]
        ## add .csv to the file name
        dst_file_path = (os.path.join(p_dest_dir, dst_file_name)) + r'.csv'
        l_logger.debug('Writting . . . ' + dst_file_path)

        ## Write the dataframe as a csv file
        df.to_csv(dst_file_path, index = None, header=True)

        ## move source file
        shutil.move(src_file_path,(os.path.join(p_src_dir + '\processed', l_name_file)))
    except:
        l_logger.error(' - Error loading file: ' + src_file_path)
        l_logger.error(' - ' + error_msg)
    ## DEBUG level end
    l_logger.debug('END: ' + l_name_file)
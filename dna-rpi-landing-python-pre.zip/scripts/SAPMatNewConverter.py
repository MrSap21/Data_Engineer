
################################################################################################
## Name: SAPMatConverter
## Author: WBADZ - BI
## Company: Walgreens Boots Alliance
## Purpose:
## Create csv files from web files (xlsx)
## Convert xlsx to csv
##
## Usage:
## It is called from a main.py (SAPMasterFilesmain.py)
################################################################################################
## Ver By               Date         Change
## 0.1 Enrique Barberan 18/12/2019   Initial version
################################################################################################
import sys
import pandas as pd
import os as os
import fnmatch
from os import listdir
from os.path import isfile, join
import logging
import datetime as dt
import shutil
# local variables
l_name_file = 'Sap Material Sales Reporting Master Data.xlsx'
error_msg = ''
def SAPMasterXlsxToCSV(p_src_dir, p_dest_dir):
    ## Description: This 'def' read .xlsx, change format to .csv and save it
    ## par_src_dir: Source Directory path where the original file is
    ## par_dest_dir: Destination Directory path where the converted file is placed
    l_month = str(dt.date.today().year) + '-' + str(dt.date.today().month)  # + str(dt.date.today().day)
    l_day = str(dt.date.today().year) + '-' + str(dt.date.today().month)  + '-' + str(dt.date.today().day)

    ## DEBUG file
    l_logger = logging.getLogger(__name__)

    ## DEBUG level start
    l_logger.debug('START: ' + l_name_file)

    ## There is only 1 file always with the same name
    l_initfilename = 'Sap Material Sales Reporting Master Data**'
    l_logger.debug('INITFILE: ' + l_initfilename)
    
    

    ## Process each file one by one
    for src_file_name in os.listdir(p_src_dir):
        if fnmatch.fnmatch(src_file_name, l_initfilename):
            try:
                l_logger.debug('MATCH FOUND: ' + src_file_name)
                ## Path of the file to read
                src_file_path = (os.path.join(p_src_dir, src_file_name))
                l_logger.debug('Working on: ' + src_file_path)
        
                ## Read the file in a python's pandas data frame.
                ## Load only the sheet specified in the sheet_name
                ## Skip the first row of the excel sheet
        
                df = pd.read_excel(src_file_path, sheet_name='SAP Master Data', skiprows = 1)
        
                df = df.replace({r'\n': ''}, regex=True)
        
                # Get ndArray of all column names
                columnsNamesArr = df.columns.values
                # convert ndarray to list
                listOfColumnNames = list(columnsNamesArr)
                l_logger.debug('columnsNamesArr: ' + columnsNamesArr)
                # Change or delete characters from column names
                listOfColumnNames = [col.replace(':', '') for col in listOfColumnNames]
                listOfColumnNames = [col.replace('-', '') for col in listOfColumnNames]
                listOfColumnNames = [col.replace('(', '') for col in listOfColumnNames]
                listOfColumnNames = [col.replace(')', '') for col in listOfColumnNames]
                listOfColumnNames = [col.replace(' ', '') for col in listOfColumnNames]
                listOfColumnNames = [col.replace('/', '') for col in listOfColumnNames]
                listOfColumnNames = [col.replace('.', '') for col in listOfColumnNames]
                listOfColumnNames = [col.replace('&', 'and') for col in listOfColumnNames]
        
                # Rename Columns
                df.columns = listOfColumnNames
        
                ## Add constant column for trace
                df.loc[:, 'filename'] = src_file_name
                df.loc[:, 'filedate'] = l_day
                df.loc[:, 'createdate'] = l_day
        
        
                for column in [col for col in df.columns if 'Unnamed' in col]:
                    l_logger.debug('++column in for:' + (column))
                    df.drop(column, axis=1, inplace=True)

                ##df.drop(['ParentCode', 'ParentCodeDescription','RangeName'], axis=1, inplace=True).columns

                ##df.drop('X', axis=1, inplace=True)
                ##df.drop(df.columns[52], axis=1)
                ##df.drop('ParentCode', axis=1, inplace=True)
                ##df.drop('ParentCodeDescription', axis=1, inplace=True)
                ##df.drop('RangeName', axis=1, inplace=True)
  
                ##df.rename(columns={'ParentCode':'GS1ProductTypeCode'}, inplace=True)
  
                ## Print the dataframe just for debugging purpose
                ## with pd.option_context('display.max_rows', None, 'display.max_columns', None):
                ## print(df)
        
                ## Removing Duplicates
                l_logger.debug('Starting Sort')
                df = df.sort_values(by='SAPMaterial',ascending=True)
                l_logger.debug('middle Sort')
                df = df.drop_duplicates(subset='SAPMaterial', keep="last")
                l_logger.debug('Ending Sort')
        
                ## the destination file name is the same as the source file name by remove the .xlsx from the name as we want it to be a csv file
                ## pick name without extension from .xslx source file
                dst_file_name = src_file_name[:-5]
                ## add .csv to the file name
                dst_file_path = (os.path.join(p_dest_dir, dst_file_name)) + r'.csv'
                l_logger.debug('Writting . . . ' + dst_file_path)
        
                ## Write the dataframe as a csv file
                df.to_csv(dst_file_path, index = None, header=True)
        
                ## move source file
                shutil.move(src_file_path,(os.path.join(p_src_dir + '\processed', src_file_name)))
            except:
                l_logger.error(' - Error loading file: ' + src_file_path)
                l_logger.error(' - ' + error_msg)
    ## DEBUG level end
    l_logger.debug('END: ' + l_name_file)
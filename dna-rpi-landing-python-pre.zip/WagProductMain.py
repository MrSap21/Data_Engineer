################################################################################################
## Name: ConvertWagProductHist
## Author: 
## Company: Walgreens Boots Alliance
## Purpose:
## File to Unzip, Remove non-UTF characters, fix any rows with column pipe character issues then Compress again.
##
## Usage:
## Run this script with python
################################################################################################
## Ver By               Date         Change
## 0.1 S Blakemore		20/07/2020   Initial version
################################################################################################
import os as os
import io
import time
import traceback
import sys
import fnmatch
#from scripts 
from utils import Convert as cv
from utils import ReadChunks as rc
from utils import GzipDecom as gd
from utils import GzipCom as gc

## Logging . . .
l_initfilename = 'WAGUS_*'

## Process each file one by one
##for src_file_name in src_file_names:

#p_src_dir = 'C:\\Projects\\PythonForGBA\\Python' + sys.argv[1]
p_src_dir = '.\\' + sys.argv[1]
p_dst_dir = '.\\' + sys.argv[2]

print('Checking for '+ p_src_dir)
for file in os.listdir(p_src_dir):
	if fnmatch.fnmatch(file, l_initfilename):
		try:
			#  Set Filenames Up

			src_file_path = (os.path.join(p_src_dir, file))
			dst_file_path = (os.path.join(p_dst_dir, file))
			#l_logger.debug('Working on: ' + src_file_path)			
	
			l_orig_filename = src_file_path

			l_filename = file[:-3]
			l_filename_path = (os.path.join(p_src_dir, l_filename))
			print(l_filename_path)
			l_filename_2 = file[:-7]+'_Clean.dat'
			l_filename_2_path = (os.path.join(p_src_dir, l_filename_2))
			print(l_filename_2_path)
			l_filename_3 = file[:-7]+'_New.dat'
			l_filename_3_path = (os.path.join(p_src_dir, l_filename_3))
			print(l_filename_3)


			start = time.time()
			print('Start Decompress')
			gd.Decompress(l_orig_filename,l_filename_path)
			end = time.time()
			print(end - start)
			print('Start Conversion')
			start = time.time()
			cv.ConverttoUTF(l_filename_path,l_filename_2_path)
			#cv.ConverttoUTF('.\\' + sys.argv[1], '.\\' + sys.argv[2])
			end = time.time()
			print(end - start)
			print('Start Column Checks')
			start = time.time()
			rc.CheckColumns(l_filename_2_path,l_filename_3_path)
			end = time.time()
			print(end - start)

			# Remove original file.
			os.remove(l_orig_filename)

			print('Start Compress')
			start = time.time()
			gc.Compress(l_filename_3_path,dst_file_path)
			end = time.time()
			print(end - start)
	
			#Remove temp files
			os.remove(l_filename_path)	
			os.remove(l_filename_2_path)
			os.remove(l_filename_3_path)
	
			print('End')	
		except:
			exc_type, exc_value, exc_traceback = sys.exc_info()
			traceback.print_exception(exc_type, exc_value, exc_traceback)
			#print('Finished')
		finally:
			print('Finished')



################################################################################################
## Name: ConvertTarget
## Author: 
## Company: Walgreens Boots Alliance
## Purpose:
## File to Remove Erroneous rows
##
## Usage:
## Run this script with python
################################################################################################
## Ver By               Date         Change
## 0.1 S Blakemore		03/08/2020   Initial version
################################################################################################
import datetime as dt
import sys
import logging
import traceback
from scripts import TargetSalesConverter as cd

## Prepare Log
## today as YYYYMMDD
## Logging . . .
try:
    l_log = 'TargetSales'
    l_date = str(dt.date.today().year) + str(dt.date.today().month) + str(dt.date.today().day)
    root_logger = logging.getLogger()
    file_handler = logging.FileHandler('.\\' + sys.argv[3] + '\\' + l_log + l_date + '.log')
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(file_handler)
    ## INFO level start
    logging.info('START TargetMain')
    cd.TargetCSV('.\\' + sys.argv[1], '.\\' + sys.argv[2])
except:
    exc_type, exc_value, exc_traceback = sys.exc_info()
    traceback.print_exception(exc_type, exc_value, exc_traceback)
        #print('Finished')
finally:
    print('Finished')




################################################################################################
## Name: ULTAmain
## Author: WBADZ - BI
## Company: Walgreens Boots Alliance
## Purpose:
## This is the main script which calls the rest of scripts for ULTA
## In this case there is only one transformation: from xlsx to csv
##
## Usage:
## Run this script with python
################################################################################################
## Ver By               Date         Change
## 0.1 Enrique Barberan 04/12/2019   Initial version
################################################################################################
import datetime as dt
import logging
from scripts import WAGBasketsConverter as wbc
from scripts import WAGeBasketsConverter as webc
from scripts import WAGeTransactionsConverter as wetc
from scripts import WAGProductsConverter as wpc
from scripts import WAGStoreConverter as wsc
from scripts import WAGTransactionsConverter as wtc
## Prepare Log
## today as YYYYMMDD
## Logging . . .
l_log = 'WAG'
l_date = str(dt.date.today().year) + str(dt.date.today().month) + str(dt.date.today().day)
root_logger = logging.getLogger()
file_handler = logging.FileHandler('.\\log\\' + l_log + l_date + '.log')
root_logger.setLevel(logging.DEBUG)
root_logger.addHandler(file_handler)
l_process = ''
## INFO level start
logging.info('----SeparationLog----')
logging.info('START WAGMain')
try:
    ## WAG baskets .dat To CSV
    l_process = 'wbc.WAGBasketsToCSV'
    wbc.WAGBasketsToCSV('.\src', '.\dst')
    ## WAG ebaskets .dat To CSV
    l_process = 'webc.WAGeBasketsToCSV'
    webc.WAGeBasketsToCSV('.\src', '.\dst')
    ## WAG etransactions .dat To CSV
    l_process = 'wetc.WAGeTransactionsToCSV'
    wetc.WAGeTransactionsToCSV('.\src', '.\dst')
    ## WAG products .dat To CSV
    l_process = 'wpc.WAGProductsToCSV'
    wpc.WAGProductsToCSV('.\src', '.\dst')
    ## WAG store .dat To CSV
    l_process = 'wsc.WAGStoreToCSV'
    wsc.WAGStoreToCSV('.\src', '.\dst')
    ## WAG eTransactions .dat To CSV
    l_process = 'wtc.WAGTransactionsToCSV'
    wtc.WAGTransactionsToCSV('.\src', '.\dst')
except Exception as err:
    root_logger.error(' - Error loading process: ' + l_process)
    root_logger.error(' - ' + err.__str__())
## INFO level end
logging.info('END WAGMain')
logging.info('----SeparationLog----')
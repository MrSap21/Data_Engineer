################################################################################################
## Name: ULTAmain
## Author: WBADZ - BI
## Company: Walgreens Boots Alliance
## Purpose:
## This is the main script which calls the rest of scripts for ULTA
## In this case there is only one transformation: from xlsx to csv
##
## Usage:
## Run this script with python
################################################################################################
## Ver By               Date         Change
## 0.1 Enrique Barberan 04/12/2019   Initial version
## 0.2 Enrique Barberan 13/01/2020   Change log folder
## 0.3 Diego Mediano    17/02/2020   Change comment END section and Change root folders for dynamic folders
################################################################################################
import datetime as dt
import sys
import logging
from scripts import SAPMatConverter as sm
from scripts import PropsAndNonSAPMatConverter as pansm
## Prepare Log
## today as YYYYMMDD
## Logging . . .
try:
    l_log = 'SAPMat'
    l_date = str(dt.date.today().year) + str(dt.date.today().month) + str(dt.date.today().day)
    root_logger = logging.getLogger()
    file_handler = logging.FileHandler('.\\' + sys.argv[3] + '\\' + l_log + l_date + '.log')
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(file_handler)
    ## INFO level start
    logging.info('START ' + l_log + 'Main')
    ## SAPMat Xlsx To CSV
    sm.SAPMasterXlsxToCSV('.\\' + sys.argv[1], '.\\' + sys.argv[2])
    ## PropsAndNonSapMat Xlsx To CSV
    pansm.PropsAndNonSAPMatXlsxToCSV('.\\' + sys.argv[1], '.\\' + sys.argv[2])
except:
    logging.error('ERROR - ' + l_log + ' - START ')
finally:
    ## INFO level end
    logging.info('END ' + l_log + 'Main')

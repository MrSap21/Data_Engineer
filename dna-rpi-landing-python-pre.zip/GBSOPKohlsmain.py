################################################################################################
## Name: Kohls File for GBSOP 
## Author: 
## Company: Walgreens Boots Alliance
## Purpose:
## This is the main script which calls the rest of scripts for Kohls File
## In this case there are 4 transformations: from xlsx to csv, removal of metadata, removal of extra rows/columns and change of headers
## Usage:
## Run this script with python
################################################################################################
## Ver By               Date         Change
## 0.1 Nishant Nigam   10/02/2021   Initial version
################################################################################################
import datetime as dt
import sys
import logging
from scripts import GBSOPKohlsConverter as cd

## Prepare Log
## today as YYYYMMDD
## Logging . . .
try:
    l_log = 'GBSOPKohls'
    l_date = str(dt.date.today().year) + str(dt.date.today().month) + str(dt.date.today().day)
    root_logger = logging.getLogger()
    file_handler = logging.FileHandler('.\\' + sys.argv[3] + '\\' + l_log + l_date + '.log')
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(file_handler)
    ## INFO level start
    logging.info('START GBSOP Kohls')
    cd.KohlsXlsxToCSV('.\\' + sys.argv[1], '.\\' + sys.argv[2])
except:
    logging.error('ERROR - ' + l_log + ' - START ')
finally:
    ## INFO level end
    logging.info('END ' + l_log + 'Main')
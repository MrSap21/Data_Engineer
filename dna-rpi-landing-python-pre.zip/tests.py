import pandas as pd
#import numpy as np

df = pd.Series(["1", "22", "03", "44 ", "05"])
print(df[4])

#type
#df[0] = df[0].astype({"a": int, "b": complex})
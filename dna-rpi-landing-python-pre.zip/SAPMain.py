################################################################################################
## Name: ULTAmain
## Author: WBADZ - BI
## Company: Walgreens Boots Alliance
## Purpose:
## Main SAP Reporting Script for Dealing with any file created by the BAPI
##
## Usage:
## Run this script with python
################################################################################################
## Ver By               Date         Change
## 0.1 Steve Blakemore29/07/2020 Initial Version
################################################################################################
import datetime as dt
import sys
import logging
import traceback
from scripts import SAPConverter as Conv
## Prepare Log
## today as YYYYMMDD
## Logging . . .
try:
    l_log = 'SAP'
    l_date = str(dt.date.today().year) + str(dt.date.today().month) + str(dt.date.today().day)
    root_logger = logging.getLogger()
    file_handler = logging.FileHandler('.\\' + sys.argv[3] + '\\' + l_log + l_date + '.log')
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(file_handler)
    ## INFO level start
    logging.info('START SAPMain')
    ## SAP Converter
    Conv.SAPConverter('.\\' + sys.argv[1], '.\\' + sys.argv[2],sys.argv[4])
except:
    logging.error('ERROR - ' + l_log + ' - START ')
    exc_type, exc_value, exc_traceback = sys.exc_info()
    traceback.print_exception(exc_type, exc_value, exc_traceback)
finally:
    ## INFO level end
    logging.info('END ' + l_log + 'Main')


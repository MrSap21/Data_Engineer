--meta entry inserts for wrapper stored proc in transaction
insert into [psa].[TransactionExecuteMeta] values ('rawuk_btc_transaction_card_p','psa.sp_rawuk_btc_transaction_card_p',1,200000000,251331370);
insert into [psa].[TransactionExecuteMeta] values ('rawuk_btc_transaction_line_anon_p','psa.sp_rawuk_btc_transaction_line_anon_p',1,200000000,2503088037);
insert into [psa].[TransactionExecuteMeta] values ('rawuk_btc_transaction_line_card_p','psa.sp_rawuk_btc_transaction_line_card_p',1,200000000,3493700530);
insert into [psa].[TransactionExecuteMeta] values ('rawcl_crp_item_transaction','psa.sp_rawcl_crp_item_transaction',1,200000000,332396231);
insert into [psa].[TransactionExecuteMeta] values ('rawmx_crp_item_transaction','psa.sp_rawmx_crp_item_transaction',1,200000000,893598797);
insert into [psa].[TransactionExecuteMeta] values ('rawno_crp_item_transaction','psa.sp_rawno_crp_item_transaction',1,200000000,108454576);
insert into [psa].[TransactionExecuteMeta] values ('rawth_crp_item_transaction','psa.sp_rawth_crp_item_transaction',1,200000000,195450033);

--single insert for site table related to transaction
INSERT INTO [ser].[Site] ([SiteId],[SourceKey],[SiteName],[LOVSiteTypeId],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[PSARowKey])
SELECT top 1 
(SELECT max(SiteId) FROM [ser].[Site])+1 as SiteId,
'0',
'UNKNOWN',
(SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = '0' and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Site Type'))as LOVSiteTypeId,
12012,
'1900-01-01',
'9999-12-31',
'Y',
1,
151,
null,
null
from ser.reflov;
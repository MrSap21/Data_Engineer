/*-- the first update statement is for Partial Run for MEXICO ---*/
update psa.transactionexecutemeta set startval = 40000001, incval = 30000000 where tablename = 'rawmx_crp_item_transaction';
update psa.transactionexecutemeta set incval = 30000000 where tablename = 'rawuk_btc_transaction_line_anon_p';
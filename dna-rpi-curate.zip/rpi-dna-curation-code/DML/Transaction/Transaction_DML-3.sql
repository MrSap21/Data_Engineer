/*--- Update statements for Transaction meta table: Mexico will have partial run ---*/	
UPDATE psa.transactionexecutemeta SET startval = 40000001 where tablename = 'rawmx_crp_item_transaction';
UPDATE psa.transactionexecutemeta SET startval = 1, incval = 30000000 where tablename = 'rawcl_crp_item_transaction';
DECLARE 
			@SCDStartDate datetime=(SELECT CONVERT(datetime2,'1900-01-01 00:00:00')),
			@SCDEndDate datetime= (SELECT CONVERT(datetime2,'9999-12-31 00:00:00')),
			@SCDActiveFlag char='Y',
			@SCDVersion smallint=1,
			@LOVRecordSourceId int =12006,
			@PlnLOVRecordSourceId int =12002,
			@StoreLOVRecordSourceId int =12008,
			@SCDLOVRecordSourceId int =151,
			@ETLRunLogId int=null;
BEGIN
/* FactDimension Table*/	
						
						WITH FactDimesionCTE AS
								(SELECT  f.FactId FactId FROM  ser.Fact f
								WHERE f.FactName = 'BASE PLAN PRODUCT' AND f.LOVFactTypeId = (Select  r.LovID from ser.RefLOV r where r.LOVKey = 'TBC' AND 
										r.LovSetID in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type') )
										AND f.LOVRecordSourceId = @LOVRecordSourceId)

						INSERT INTO ser.FactDimension(
										FactId				 ,
										DimensionId          ,
										[Sequence]           ,
										Mandatory            ,
										LOVRecordSourceId    ,
										SCDStartDate         ,
										SCDEndDate           ,
										SCDActiveFlag        ,
										SCDVersion           ,
										SCDLOVRecordSourceId ,
                                        ETLRunLogId )	
						SELECT		Factid,
									(SELECT d.DimensionId from ser.Dimension d where Name = 'Planogram' and LOVRecordSourceId = @PlnLOVRecordSourceId)	[DimensionId]          ,
									null [Sequence]                            ,
									null [Mandatory ]                          ,
									@LOVRecordSourceId LOVRecordSourceID                 ,
								    @SCDStartDate SCDStartDate                 ,
								    @SCDEndDate SCDEndDate                     ,
								    @SCDActiveFlag SCDActiveFlag               ,
								    @SCDVersion SCDVersion                     ,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
								    @ETLRunLogId ETLRunLogId			   
												FROM FactDimesionCTE 
							   Group by FactId ;
			   
						PRINT ' Info : FactDimension  Table Loaded Successfully';
					
/* FactDimension Table -Product*/	
						WITH FactDimesionCTE AS
								(SELECT  f.FactId FactId FROM  ser.Fact f
								WHERE f.FactName = 'BASE PLAN PRODUCT' AND f.LOVFactTypeId = (Select  r.LovID from ser.RefLOV r where r.LOVKey = 'TBC' AND 
										r.LovSetID in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type') )
										AND f.LOVRecordSourceId = @LOVRecordSourceId)
						INSERT INTO ser.FactDimension(
										FactId				 ,
										DimensionId          ,
										[Sequence]           ,
										Mandatory            ,
										LOVRecordSourceId    ,
										SCDStartDate         ,
										SCDEndDate           ,
										SCDActiveFlag        ,
										SCDVersion           ,
										SCDLOVRecordSourceId ,
                                        ETLRunLogId )	
						SELECT		Factid,
									(SELECT d.DimensionId from ser.Dimension d where Name = 'Product' and LOVRecordSourceId = @PlnLOVRecordSourceId)	[DimensionId]          ,
									null [Sequence]                            ,
									null [Mandatory ]                          ,
									@LOVRecordSourceId  LOVRecordSourceID                 ,
								    @SCDStartDate SCDStartDate                 ,
								    @SCDEndDate SCDEndDate                     ,
								    @SCDActiveFlag SCDActiveFlag               ,
								    @SCDVersion SCDVersion                     ,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
								    @ETLRunLogId ETLRunLogId			   
												FROM FactDimesionCTE 
							   Group by FactId ;
			   
						PRINT ' Info : FactDimension  Table Loaded Successfully';
						

/* FactDimension Table -Calendar_Week*/	
						WITH FactDimesionCTE AS
								(SELECT  f.FactId FactId FROM  ser.Fact f
								WHERE f.FactName = 'BASE PLAN PRODUCT' AND f.LOVFactTypeId = (Select  r.LovID from ser.RefLOV r where r.LOVKey = 'TBC' AND 
										r.LovSetID in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type') )
										AND f.LOVRecordSourceId = @LOVRecordSourceId)
						
						INSERT INTO ser.FactDimension(
										FactId				 ,
										DimensionId          ,
										[Sequence]           ,
										Mandatory            ,
										LOVRecordSourceId    ,
										SCDStartDate         ,
										SCDEndDate           ,
										SCDActiveFlag        ,
										SCDVersion           ,
										SCDLOVRecordSourceId ,
                                        ETLRunLogId )	
						SELECT		Factid,
									(SELECT d.DimensionId from ser.Dimension d where Name = 'Calendar_Week' and LOVRecordSourceId = @LOVRecordSourceId)	[DimensionId]          ,
									null [Sequence]                            ,
									null [Mandatory ]                          ,
									@LOVRecordSourceId LOVRecordSourceID                 ,
								    @SCDStartDate SCDStartDate                 ,
								    @SCDEndDate SCDEndDate                     ,
								    @SCDActiveFlag SCDActiveFlag               ,
								    @SCDVersion SCDVersion                     ,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
								    @ETLRunLogId ETLRunLogId			   
												FROM FactDimesionCTE 
							   Group by FactId ;
			   
						PRINT ' Info : FactDimension  Table Loaded Successfully';

						

					
/* FactDimension Table --fiscal_week*/	
						WITH FactDimesionCTE AS
								(SELECT  f.FactId FactId FROM  ser.Fact f
								WHERE f.FactName = 'BASE PLAN PRODUCT' AND f.LOVFactTypeId = (Select  r.LovID from ser.RefLOV r where r.LOVKey = 'TBC' AND 
										r.LovSetID in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type') )
										AND f.LOVRecordSourceId = @LOVRecordSourceId)
												INSERT INTO ser.FactDimension(
										FactId				 ,
										DimensionId          ,
										[Sequence]           ,
										Mandatory            ,
										LOVRecordSourceId    ,
										SCDStartDate         ,
										SCDEndDate           ,
										SCDActiveFlag        ,
										SCDVersion           ,
										SCDLOVRecordSourceId ,
                                        ETLRunLogId )	
						SELECT		Factid,
									(SELECT d.DimensionId from ser.Dimension d where Name = 'Fiscal_Week' and LOVRecordSourceId = @LOVRecordSourceId)	[DimensionId]          ,
									null [Sequence]                            ,
									null [Mandatory ]                          ,
									@LOVRecordSourceId  LOVRecordSourceID                 ,
								    @SCDStartDate SCDStartDate                 ,
								    @SCDEndDate SCDEndDate                     ,
								    @SCDActiveFlag SCDActiveFlag               ,
								    @SCDVersion SCDVersion                     ,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
								    @ETLRunLogId ETLRunLogId			   
												FROM FactDimesionCTE 
							   Group by FactId ;
			   
						PRINT ' Info : FactDimension  Table Loaded Successfully';
						

				   WITH FactDimesionbspCTE AS
                                (SELECT  f.FactId FactId FROM  ser.Fact f
                                WHERE f.FactName = 'BASE STORE PLAN' AND f.LOVFactTypeId = (Select  r.LovID from ser.RefLOV r where r.LOVKey = 'TBC' AND 
                                        r.LovSetID in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type') )
                                        AND f.LOVRecordSourceId = @LOVRecordSourceId)

          
                        INSERT INTO ser.FactDimension(
                                        FactId                 ,
                                        DimensionId          ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId ) 



            
										  SELECT        Factid,
                                    (SELECT d.DimensionId from ser.Dimension d where Name = 'Store' and d.LOVRecordSourceId = @StoreLOVRecordSourceId)    [DimensionId]          ,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    @LOVRecordSourceId LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactDimesionbspCTE 
                               Group by FactId ;
               
                        PRINT ' Info : FactDimension  Table Loaded Successfully';
						
/*floor_plan*/
				WITH FactDimesionbspCTE AS
                                (SELECT  f.FactId FactId FROM  ser.Fact f
                                WHERE f.FactName = 'BASE STORE PLAN' AND f.LOVFactTypeId = (Select  r.LovID from ser.RefLOV r where r.LOVKey = 'TBC' AND 
                                        r.LovSetID in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type') )
                                        AND f.LOVRecordSourceId = @LOVRecordSourceId)

				 									INSERT INTO ser.FactDimension(
                                        FactId                 ,
                                        DimensionId          ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId )   


									SELECT        Factid,
                                    (SELECT d.DimensionId FROM ser.Dimension d WHERE d.Name = 'Floor_Plan' AND d.LOVRecordSourceId = @LOVRecordSourceId)    [DimensionId]          ,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    @LOVRecordSourceId LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactDimesionbspCTE 
                               Group by FactId ;
               
                        PRINT ' Info : FactDimension  Table Loaded Successfully';


/*calendar_week*/

				  WITH FactDimesionbspCTE AS
                                (SELECT  f.FactId FactId FROM  ser.Fact f
                                WHERE f.FactName = 'BASE STORE PLAN' AND f.LOVFactTypeId = (Select  r.LovID from ser.RefLOV r where r.LOVKey = 'TBC' AND 
                                        r.LovSetID in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type') )
                                        AND f.LOVRecordSourceId = @LOVRecordSourceId)

									INSERT INTO ser.FactDimension(
                                        FactId                 ,
                                        DimensionId          ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId ) 



									SELECT        Factid,
                                    (SELECT d.DimensionId FROM ser.Dimension d WHERE d.Name = 'Calendar_Week' AND d.LOVRecordSourceId = @LOVRecordSourceId)    [DimensionId]          ,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    @LOVRecordSourceId LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactDimesionbspCTE 
                               Group by FactId ;
               
                        PRINT ' Info : FactDimension  Table Loaded Successfully';

					
/*fiscal_week*/

				WITH FactDimesionbspCTE AS
                                (SELECT  f.FactId FactId FROM  ser.Fact f
                                WHERE f.FactName = 'BASE STORE PLAN' AND f.LOVFactTypeId = (Select  r.LovID from ser.RefLOV r where r.LOVKey = 'TBC' AND 
                                        r.LovSetID in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type') )
                                        AND f.LOVRecordSourceId = @LOVRecordSourceId) 

 INSERT INTO ser.FactDimension(
                                        FactId                 ,
                                        DimensionId          ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId )  



									SELECT        Factid,
                                    (SELECT d.DimensionId FROM ser.Dimension d WHERE d.Name = 'Fiscal_Week' AND d.LOVRecordSourceId = @LOVRecordSourceId)    [DimensionId]          ,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    @LOVRecordSourceId LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactDimesionbspCTE 
                               Group by FactId ;
               
                        PRINT ' Info : FactDimension  Table Loaded Successfully';

/*Planogram*/

				 WITH FactDimesionbspCTE AS
                                (SELECT  f.FactId FactId FROM  ser.Fact f
                                WHERE f.FactName = 'BASE STORE PLAN' AND f.LOVFactTypeId = (Select  r.LovID from ser.RefLOV r where r.LOVKey = 'TBC' AND 
                                        r.LovSetID in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type') )
                                        AND f.LOVRecordSourceId = @LOVRecordSourceId)

									INSERT INTO ser.FactDimension(
                                        FactId                 ,
                                        DimensionId          ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId )  



									SELECT        Factid,
                                    (SELECT d.DimensionId FROM ser.Dimension d WHERE d.Name = 'Planogram' AND d.LOVRecordSourceId = @PlnLOVRecordSourceId)    [DimensionId]          ,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    @LOVRecordSourceId LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactDimesionbspCTE 
                               Group by FactId ;
               
                        PRINT 'Info : FactDimension  Table Loaded Successfully';
END
DECLARE 
            
            @SCDStartDate datetime = (SELECT CONVERT(datetime2,'1900-01-01 00:00:00')),
            @SCDEndDate datetime = (SELECT CONVERT(datetime2,'9999-12-31 00:00:00')),
            @SCDActiveFlag char ='Y',
            @SCDVersion smallint ='1',
            @LOVRecordSourceId int =12006,
            @SCDLOVRecordSourceId int =151,
            @ETLRunLogId int = null;

BEGIN 

WITH FactDimesionCTE AS
(SELECT f.FactId FROM ser.Fact f WHERE f.FactName = 'Base Store Plan'
AND f.LOVFactTypeId IN ( SELECT r.LOVId FROM ser.Reflov r WHERE r.LOVKey = 'TBC'
AND r.LOVSetId IN ( SELECT rs.LOVSetId FROM ser.Reflovset rs WHERE rs.LOVSetName = 'Fact Type'))
AND f.LOVRecordSourceId = 12006)

 INSERT INTO ser.FactMeasure(
                                        FactId               ,
                                        MeasureId            ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId )   




SELECT                              Factid,
                                    (SELECT MeasureId from ser.Measure m WHERE m.MeasureName = 'sales_qty' AND m.LOVRecordSourceId = 12006) MeasureId,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    12006 as LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactDimesionCTE ;
												
												
/*sales_tesp*/

WITH FactMeasureCTE AS
(SELECT f.FactId FROM ser.Fact f WHERE f.FactName = 'Base Store Plan'
AND f.LOVFactTypeId IN ( SELECT r.LOVId FROM ser.Reflov r WHERE r.LOVKey = 'TBC'
AND r.LOVSetId IN ( SELECT rs.LOVSetId FROM ser.Reflovset rs WHERE rs.LOVSetName = 'Fact Type'))
AND f.LOVRecordSourceId = 12006)

 INSERT INTO ser.FactMeasure(
                                        FactId               ,
                                        MeasureId            ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId )   




SELECT                              Factid,
                                    (SELECT MeasureId from ser.Measure m WHERE m.MeasureName = 'sales_tesp' AND m.LOVRecordSourceId = 12006) MeasureId,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    12006 as LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactMeasureCTE ;


/*sales_tisp*/

WITH FactMeasureCTE AS
(SELECT f.FactId FROM ser.Fact f WHERE f.FactName = 'Base Store Plan'
AND f.LOVFactTypeId IN ( SELECT r.LOVId FROM ser.Reflov r WHERE r.LOVKey = 'TBC'
AND r.LOVSetId IN ( SELECT rs.LOVSetId FROM ser.Reflovset rs WHERE rs.LOVSetName = 'Fact Type'))
AND f.LOVRecordSourceId = 12006)

 INSERT INTO ser.FactMeasure(
                                        FactId               ,
                                        MeasureId            ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId ) 




SELECT                              Factid,
                                    (SELECT MeasureId from ser.Measure m WHERE m.MeasureName = 'sales_tisp' AND m.LOVRecordSourceId = 12006) MeasureId,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    12006 as LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactMeasureCTE ;


/*sales_epgp*/

WITH FactMeasureCTE AS
(SELECT f.FactId FROM ser.Fact f WHERE f.FactName = 'Base Store Plan'
AND f.LOVFactTypeId IN ( SELECT r.LOVId FROM ser.Reflov r WHERE r.LOVKey = 'TBC'
AND r.LOVSetId IN ( SELECT rs.LOVSetId FROM ser.Reflovset rs WHERE rs.LOVSetName = 'Fact Type'))
AND f.LOVRecordSourceId = 12006)

 INSERT INTO ser.FactMeasure(
                                        FactId               ,
                                        MeasureId            ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId )  




SELECT                              Factid,
                                    (SELECT MeasureId from ser.Measure m WHERE m.MeasureName = 'sales_epgp' AND m.LOVRecordSourceId = 12006) MeasureId,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    12006 as LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactMeasureCTE ;


/*modular_build*/

WITH FactMeasureCTE AS
(SELECT f.FactId FROM ser.Fact f WHERE f.FactName = 'Base Store Plan'
AND f.LOVFactTypeId IN ( SELECT r.LOVId FROM ser.Reflov r WHERE r.LOVKey = 'TBC'
AND r.LOVSetId IN ( SELECT rs.LOVSetId FROM ser.Reflovset rs WHERE rs.LOVSetName = 'Fact Type'))
AND f.LOVRecordSourceId = 12006)

 INSERT INTO ser.FactMeasure(
                                        FactId               ,
                                        MeasureId            ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId )  




SELECT                              Factid,
                                    (SELECT MeasureId from ser.Measure m WHERE m.MeasureName = 'modular_build' AND m.LOVRecordSourceId = 12006) MeasureId,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    12006 as LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactMeasureCTE ;


/*build_size*/

WITH FactMeasureCTE AS
(SELECT f.FactId FROM ser.Fact f WHERE f.FactName = 'Base Store Plan'
AND f.LOVFactTypeId IN ( SELECT r.LOVId FROM ser.Reflov r WHERE r.LOVKey = 'TBC'
AND r.LOVSetId IN ( SELECT rs.LOVSetId FROM ser.Reflovset rs WHERE rs.LOVSetName = 'Fact Type'))
AND f.LOVRecordSourceId = 12006)

 INSERT INTO ser.FactMeasure(
                                        FactId               ,
                                        MeasureId            ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId )  




SELECT                              Factid,
                                    (SELECT MeasureId from ser.Measure m WHERE m.MeasureName = 'build_size' AND m.LOVRecordSourceId = 12006) MeasureId,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    12006 as LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactMeasureCTE ;


/*instances*/

WITH FactMeasureCTE AS
(SELECT f.FactId FROM ser.Fact f WHERE f.FactName = 'Base Store Plan'
AND f.LOVFactTypeId IN ( SELECT r.LOVId FROM ser.Reflov r WHERE r.LOVKey = 'TBC'
AND r.LOVSetId IN ( SELECT rs.LOVSetId FROM ser.Reflovset rs WHERE rs.LOVSetName = 'Fact Type'))
AND f.LOVRecordSourceId = 12006)

 INSERT INTO ser.FactMeasure(
                                        FactId               ,
                                        MeasureId            ,
                                        [Sequence]           ,
                                        Mandatory            ,
                                        LOVRecordSourceId    ,
                                        SCDStartDate         ,
                                        SCDEndDate           ,
                                        SCDActiveFlag        ,
                                        SCDVersion           ,
                                        SCDLOVRecordSourceId ,
                                        ETLRunLogId ) 




SELECT                              Factid,
                                    (SELECT MeasureId from ser.Measure m WHERE m.MeasureName = 'instances' AND m.LOVRecordSourceId = 12006) MeasureId,
                                    null [Sequence]                            ,
                                    null [Mandatory ]                          ,
                                    12006 as LOVRecordSourceID                 ,
                                    @SCDStartDate SCDStartDate                 ,
                                    @SCDEndDate SCDEndDate                     ,
                                    @SCDActiveFlag SCDActiveFlag               ,
                                    @SCDVersion SCDVersion                     ,
                                    @SCDLOVRecordSourceId SCDLOVRecordSourceId ,
                                    @ETLRunLogId ETLRunLogId               
                                                FROM FactMeasureCTE ;
                               
               
                       END
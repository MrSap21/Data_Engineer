DECLARE 
			@max_FactID int,
			@SCDStartDate datetime= (SELECT CONVERT(datetime2,'1900-01-01 00:00:00')),
			@SCDEndDate datetime= (SELECT CONVERT(datetime2,'9999-12-31 00:00:00')),
			@SCDActiveFlag char='Y',
			@SCDVersion smallint=1,
			@LOVRecordSourceId int =12006,
			@PlnLOVRecordSourceId int =12002,
			@SCDLOVRecordSourceId int =151,
			@ETLRunLogId int=null;
	BEGIN		
/*Fact Table - BASE PLAN PRODUCT */
	SET @max_FactID=(SELECT COALESCE(MAX(FactID),0) from ser.FACT)
				INSERT INTO ser.Fact(
										FactId              ,
										FactName            ,
										LOVFactTypeId       ,
										LOVRecordSourceId   ,
										SCDStartDate        ,
										SCDEndDate          ,
										SCDActiveFlag       ,
										SCDVersion          ,
										SCDLOVRecordSourceId,
										ETLRunLogId)
	
					SELECT      ROW_NUMBER() OVER( ORDER BY FactName,LOVFactTypeId,LOVRecordSourceId  ASC)+@max_FactID FactId,
								FactName,
								LOVFactTypeId,
								LOVRecordSourceId,
								@SCDStartDate SCDStartDate,
								@SCDEndDate SCDEndDate,
								@SCDActiveFlag SCDActiveFlag,
								@SCDVersion SCDVersion,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								@ETLRunLogId ETLRunLogId
				
				From (	
					 SELECT 'BASE PLAN PRODUCT' FactName,
					(SELECT r.LOVID FROm ser.Reflov r Where r.LovKey ='TBC' and r.LOVSETID  in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type'  ) ) LOVFactTypeId,
					@LOVRecordSourceId LOVRecordSourceId 
					) t GROUP by FactName,LOVFactTypeId,LOVRecordSourceId ;
	
					PRINT ' Info : Fact  Table Loaded Successfully';
					SET @max_FactID=(SELECT COALESCE(MAX(FactID),0) from ser.FACT)
                 INSERT INTO ser.Fact(
                                        FactId              ,
                                        FactName            ,
                                        LOVFactTypeId       ,
                                        LOVRecordSourceId   ,
                                        SCDStartDate        ,
                                        SCDEndDate          ,
                                        SCDActiveFlag       ,
                                        SCDVersion          ,
                                        SCDLOVRecordSourceId,
                                        ETLRunLogId)
   
                    SELECT      ROW_NUMBER() OVER( ORDER BY FactName,LOVFactTypeId,LOVRecordSourceId  ASC)+@max_FactID FactId,
                                FactName,
                                LOVFactTypeId,
                                LOVRecordSourceId,
                                @SCDStartDate SCDStartDate,
                                @SCDEndDate SCDEndDate,
                                @SCDActiveFlag SCDActiveFlag,
                                @SCDVersion SCDVersion,
                                @SCDLOVRecordSourceId SCDLOVRecordSourceId,
                                @ETLRunLogId ETLRunLogId
               
                From (   
                     SELECT 'BASE STORE PLAN' FactName,
                    (SELECT r.LOVID FROm ser.Reflov r Where r.LovKey ='TBC' and r.LOVSETID  in (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Fact Type'  ) ) LOVFactTypeId,
                    @LOVRecordSourceId  LOVRecordSourceId
                    ) t GROUP by FactName,LOVFactTypeId,LOVRecordSourceId ;
   
                    PRINT ' Info : Fact  Table Loaded Successfully';
END
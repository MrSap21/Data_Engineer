DECLARE 
			@max_FactInstanceID bigint,
			@max_DimensionId int,
			@SCDStartDate datetime=(SELECT CONVERT(datetime2,'1900-01-01 00:00:00')),
			@SCDEndDate datetime= (SELECT CONVERT(datetime2,'9999-12-31 00:00:00')),
			@SCDActiveFlag char='Y',
			@SCDVersion smallint=1,
			@LOVRecordSourceId int =12006,
			@PlnLOVRecordSourceId int =12002,
			@StoreLOVRecordSourceId int =12008,
			@SCDLOVRecordSourceId int =151,
			@ETLRunLogId int=null;
BEGIN	
/* Dimension Table -Planogram*/	
						SET @max_DimensionId=(SELECT COALESCE(MAX(DimensionId),0) from ser.Dimension);
						INSERT INTO ser.Dimension(
										DimensionId            ,
                                        [Name]                   ,
                                        [Description]            ,
                                        [Schema]                 ,
                                        Tablename              ,
                                        SurrogateKeyColumn     ,
                                        SourceKeyColumn        ,
                                        LOVRecordSourceId      ,
                                        SCDStartDate           ,
                                        SCDEndDate             ,
                                        SCDActiveFlag          ,
                                        SCDVersion             ,
                                        SCDLOVRecordSourceId   ,
                                        ETLRunLogId )
	
					SELECT      ROW_NUMBER() OVER( ORDER BY [Name],LOVRecordSourceId  ASC)+@max_DimensionId DimensionId,
								[Name]										,
								null [Description]							,
								null [Schema]								,
								Tablename									,
								SurrogateKeyColumn							,
                                SourceKeyColumn								,
                                LOVRecordSourceId							,
								@SCDStartDate SCDStartDate					,
								@SCDEndDate SCDEndDate						,
								@SCDActiveFlag SCDActiveFlag				,
								@SCDVersion SCDVersion						,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId	,
								@ETLRunLogId ETLRunLogId
				
				From (	
					 SELECT 'PLANOGRAM' [Name],
					 (SELECT 'Planogram') Tablename,
					 (SELECT 'Planogram Id') SurrogateKeyColumn,
					 (SELECT 'Source Key') SourceKeyColumn,
					 @PlnLOVRecordSourceId LOVRecordSourceId		 
					) t GROUP by [Name],Tablename,SurrogateKeyColumn,SourceKeyColumn,LOVRecordSourceId ;
	
/* Dimension Table -Product*/	
						SET @max_DimensionId=(SELECT COALESCE(MAX(DimensionId),0) from ser.Dimension);
						INSERT INTO ser.Dimension(
										DimensionId            ,
                                        [Name]                   ,
                                        [Description]            ,
                                        [Schema]                 ,
                                        Tablename              ,
                                        SurrogateKeyColumn     ,
                                        SourceKeyColumn        ,
                                        LOVRecordSourceId      ,
                                        SCDStartDate           ,
                                        SCDEndDate             ,
                                        SCDActiveFlag          ,
                                        SCDVersion             ,
                                        SCDLOVRecordSourceId   ,
                                        ETLRunLogId )
	
					SELECT      ROW_NUMBER() OVER( ORDER BY [Name],LOVRecordSourceId  ASC)+@max_DimensionId DimensionId,
								[Name]										,
								null [Description]							,
								null [Schema]								,
								Tablename									,
								SurrogateKeyColumn							,
                                SourceKeyColumn								,
                                LOVRecordSourceId							,
								@SCDStartDate SCDStartDate					,
								@SCDEndDate SCDEndDate						,
								@SCDActiveFlag SCDActiveFlag				,
								@SCDVersion SCDVersion						,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId	,
								@ETLRunLogId ETLRunLogId
				
				From (	
					 SELECT 'Product' [Name],
					 (SELECT 'Product') Tablename,
					 (SELECT 'Product Id') SurrogateKeyColumn,
					 (SELECT 'Source Key') SourceKeyColumn,
					 @PlnLOVRecordSourceId LOVRecordSourceId		 
					) t GROUP by [Name],Tablename,SurrogateKeyColumn,SourceKeyColumn,LOVRecordSourceId ;
	
					PRINT ' Info : Dimension Table Loaded Successfully';

/* Dimension Table -Calendar_Week*/	
						SET @max_DimensionId=(SELECT COALESCE(MAX(DimensionId),0) from ser.Dimension);
						INSERT INTO ser.Dimension(
										DimensionId            ,
                                        [Name]                   ,
                                        [Description]            ,
                                        [Schema]                 ,
                                        Tablename              ,
                                        SurrogateKeyColumn     ,
                                        SourceKeyColumn        ,
                                        LOVRecordSourceId      ,
                                        SCDStartDate           ,
                                        SCDEndDate             ,
                                        SCDActiveFlag          ,
                                        SCDVersion             ,
                                        SCDLOVRecordSourceId   ,
                                        ETLRunLogId )
	
					SELECT      ROW_NUMBER() OVER( ORDER BY [Name],LOVRecordSourceId  ASC)+@max_DimensionId DimensionId,
								[Name]										,
								null [Description]							,
								null [Schema]								,
								Tablename									,
								SurrogateKeyColumn							,
                                SourceKeyColumn								,
                                LOVRecordSourceId							,
								@SCDStartDate SCDStartDate					,
								@SCDEndDate SCDEndDate						,
								@SCDActiveFlag SCDActiveFlag				,
								@SCDVersion SCDVersion						,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId	,
								@ETLRunLogId ETLRunLogId
				
				From (	
					 SELECT 'Calendar_Week' [Name],
					 (SELECT 'RefLOV') Tablename,
					 (SELECT 'LOVId') SurrogateKeyColumn,
					 (SELECT 'LOVKey') SourceKeyColumn,
					 @LOVRecordSourceId LOVRecordSourceId		 
					) t GROUP by [Name],Tablename,SurrogateKeyColumn,SourceKeyColumn,LOVRecordSourceId ;
	
					PRINT ' Info : Dimension Table Loaded Successfully';
					
/* Dimension Table -fiscal_week*/	
						SET @max_DimensionId=(SELECT COALESCE(MAX(DimensionId),0) from ser.Dimension);
						INSERT INTO ser.Dimension(
										DimensionId            ,
                                        [Name]                   ,
                                        [Description]            ,
                                        [Schema]                 ,
                                        Tablename              ,
                                        SurrogateKeyColumn     ,
                                        SourceKeyColumn        ,
                                        LOVRecordSourceId      ,
                                        SCDStartDate           ,
                                        SCDEndDate             ,
                                        SCDActiveFlag          ,
                                        SCDVersion             ,
                                        SCDLOVRecordSourceId   ,
                                        ETLRunLogId )
	
					SELECT      ROW_NUMBER() OVER( ORDER BY [Name],LOVRecordSourceId  ASC)+@max_DimensionId DimensionId,
								[Name]										,
								null [Description]							,
								null [Schema]								,
								Tablename									,
								SurrogateKeyColumn							,
                                SourceKeyColumn								,
                                LOVRecordSourceId							,
								@SCDStartDate SCDStartDate					,
								@SCDEndDate SCDEndDate						,
								@SCDActiveFlag SCDActiveFlag				,
								@SCDVersion SCDVersion						,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId	,
								@ETLRunLogId ETLRunLogId
				
				From (	
					 SELECT 'Fiscal_Week' [Name],
					 (SELECT 'RefLOV') Tablename,
					 (SELECT 'LOVId') SurrogateKeyColumn,
					 (SELECT 'LOVKey') SourceKeyColumn,
					 @LOVRecordSourceId LOVRecordSourceId		 
					) t GROUP by [Name],Tablename,SurrogateKeyColumn,SourceKeyColumn,LOVRecordSourceId ;
	
					PRINT ' Info : Dimension Table Loaded Successfully';
/*Dimension Table - store*/					
				SET @max_DimensionId=(SELECT COALESCE(MAX(DimensionId),0) from ser.Dimension);
  
		INSERT INTO ser.Dimension(
												DimensionId          ,
												Name                 ,
												Description          ,
												[Schema]               ,
												Tablename            ,
												SurrogateKeyColumn   ,
												SourceKeyColumn      ,
												LOVRecordSourceId    ,
												SCDStartDate         ,
												SCDEndDate           ,
												SCDActiveFlag        ,
												SCDVersion           ,
												SCDLOVRecordSourceId ,
												ETLRunLogId          )
   SELECT ROW_NUMBER() OVER( ORDER BY Name,LOVRecordSourceId  ASC)+@max_DimensionId DimensionId,
                                [Name],
                                [Description],
                                [Schema],
                                Tablename,
                                SurrogateKeyColumn,
                                SourceKeyColumn,
                                LOVRecordSourceId,
                                @SCDStartDate SCDStartDate,
                                @SCDEndDate SCDEndDate,
                                @SCDActiveFlag SCDActiveFlag,
                                @SCDVersion SCDVersion,
                                @SCDLOVRecordSourceId SCDLOVRecordSourceId,
                                @ETLRunLogId ETLRunLogId
                
                From     
                                (SELECT 'Store' [Name],
                                 NULL [Description],
                                 NULL [Schema],
                                'Site Role' Tablename,
                                'Site Role Id'  SurrogateKeyColumn,
                                'Source Key' SourceKeyColumn,
                                 @StoreLOVRecordSourceId LOVRecordSourceId) dim
                GROUP by [Name],[Description],[Schema],Tablename,SurrogateKeyColumn,SourceKeyColumn,LOVRecordSourceId
    
    
                        PRINT ' Info : Dimension  Table Loaded Successfully'

 

/*Dimension Table - floor_plan*/

        SET @max_DimensionId=(SELECT COALESCE(MAX(DimensionId),0) from ser.Dimension);
  
		INSERT INTO ser.Dimension(
												DimensionId          ,
												Name                 ,
												Description          ,
												[Schema]               ,
												Tablename            ,
												SurrogateKeyColumn   ,
												SourceKeyColumn      ,
												LOVRecordSourceId    ,
												SCDStartDate         ,
												SCDEndDate           ,
												SCDActiveFlag        ,
												SCDVersion           ,
												SCDLOVRecordSourceId ,
												ETLRunLogId          )
    SELECT ROW_NUMBER() OVER( ORDER BY Name,LOVRecordSourceId  ASC)+@max_DimensionId DimensionId,
                                [Name],
                                [Description],
                                [Schema],
                                Tablename,
                                SurrogateKeyColumn,
                                SourceKeyColumn,
                                LOVRecordSourceId,
                                @SCDStartDate SCDStartDate,
                                @SCDEndDate SCDEndDate,
                                @SCDActiveFlag SCDActiveFlag,
                                @SCDVersion SCDVersion,
                                @SCDLOVRecordSourceId SCDLOVRecordSourceId,
                                @ETLRunLogId ETLRunLogId
                
                From     
                                (SELECT 'Floor_Plan' [Name],
                                 NULL [Description],
                                 NULL [Schema],
                                'RefLov' Tablename,
                                'LOVId'  SurrogateKeyColumn,
                                'LOVKey' SourceKeyColumn,
                                 @LOVRecordSourceId LOVRecordSourceId) dim
                GROUP by [Name],[Description],[Schema],Tablename,SurrogateKeyColumn,SourceKeyColumn,LOVRecordSourceId
    
    
                        PRINT ' Info : Dimension  Table Loaded Successfully'
END
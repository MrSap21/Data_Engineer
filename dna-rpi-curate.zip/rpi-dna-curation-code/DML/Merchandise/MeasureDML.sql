--Planogram
DECLARE @max_measureID int
SET @max_measureID=(SELECT COALESCE(MAX(MeasureId),0) FROM  ser.Measure)
 INSERT INTO [SER].[MEASURE]
(MeasureId,LOVMeasureTypeId,LOVDataTypeId,MeasureName,MeasureDescription,Length,Precision,Scale,StandardMeasureId,LOVRecordSourceId,
SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId)
 SELECT   
@max_measureID+1 MeasureId,
(select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rls.LOVSetName = 'Measure Type'),
(select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'STRING' AND rls.LOVSetName = 'Data Type'),
'shelf_depth' , 'The standard shelf depth for the planogram' ,null ,null ,null ,null ,12002,'1900-01-01 00:00:00','9999-12-31 00:00:00' ,'Y',1,151,null
 UNION 
SELECT   
@max_measureID+2 ,
(select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rls.LOVSetName = 'Measure Type'),
(select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'STRING' AND rls.LOVSetName = 'Data Type'),
'shelf_height' ,'The standard shelf height for the planogram' ,null ,null ,null ,null ,12002,'1900-01-01 00:00:00','9999-12-31 00:00:00' ,'Y',1,151,null
UNION    
SELECT 
 @max_measureID+3 ,
(select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rls.LOVSetName = 'Measure Type'),
(select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'FLOAT' AND rls.LOVSetName = 'Data Type'),
'shelf_width' ,'The standard shelf width for the planogram' ,null ,null ,null ,null ,12002,'1900-01-01 00:00:00','9999-12-31 00:00:00' ,'Y',1,151,null
UNION    
SELECT  
@max_measureID+4 ,
(select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rls.LOVSetName = 'Measure Type'),
(select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'STRING' AND rls.LOVSetName = 'Data Type'),
'build_size' ,'The shelving units in store are modular, so when they design a planogram, it will be made up of a number of shelving units. They refer to this as the build size.E.g. A 3 mod planogram will be 3 shelves wide.',
null ,null ,null ,null ,12002,'1900-01-01 00:00:00','9999-12-31 00:00:00' ,'Y',1,151,null;
--Fixture

SET @max_measureID=(SELECT COALESCE(MAX(MeasureId),0) FROM  ser.Measure)
 INSERT INTO [ser].[MEASURE]
(MeasureId,LOVMeasureTypeId,LOVDataTypeId,MeasureName,MeasureDescription,Length,Precision,Scale,StandardMeasureId,LOVRecordSourceId,
SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId)
 SELECT
@max_measureID+1 MeasureId,
(select rl.LOVId FROM ser.RefLOV rl JOIN ser.RefLOVSet rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rls.LOVSetName = 'Measure Type'),
(select rl.LOVId FROM ser.RefLOV rl JOIN ser.RefLOVSet rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'STRING' AND rls.LOVSetName = 'Data Type'),
'shelf_number' ,'Planogram Shelf Number' ,null ,null ,null ,null ,12002,'1900-01-01 00:00:00','9999-12-31 00:00:00' ,'Y',1,151,null
--Fact
DECLARE 
            
            @SCDStartDate datetime = '1900-01-01 00:00:00',
            @SCDEndDate datetime = '9999-12-31 00:00:00',
            @SCDActiveFlag char ='Y',
            @SCDVersion smallint ='1',
            @LOVRecordSourceId int =12006,
            @SCDLOVRecordSourceId int =151,
            @ETLRunLogId int = null

BEGIN 

SET @max_MeasureId=(SELECT COALESCE(MAX(MeasureId),0) from ser.Measure)

INSERT INTO ser.Measure
(
MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
SCDStartDate,       
SCDEndDate,
SCDActiveFlag,
SCDVersion,     
SCDLOVRecordSourceId,
ETLRunLogId
)
 

SELECT
(ROW_NUMBER() OVER( ORDER BY MeasureName,LOVMeasureTypeId,LOVRecordSourceId  ASC)+@max_MeasureId) MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
@SCDStartDate SCDStartDate,
@SCDEndDate SCDEndDate,
@SCDActiveFlag SCDActiveFlag,
@SCDVersion SCDVersion,
@SCDLOVRecordSourceId SCDLOVRecordSourceId,
@ETLRunLogId ETLRunLogId
FROM
(select 
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'PLANOGRAM_AGGREGATION' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs WHERE rs.LOVSetName = 'Measure Type')) LOVMeasureTypeId,
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'INT' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Data Type')) LOVDataTypeId,
'sales_qty' MeasureName,
'The number of units sold of  an item as part of  a transaction totalled for the planogram for that week' MeasureDescription,
NULL Length,
NULL Precision,
NULL Scale,
NULL StandardMeasureId,
12006 LOVRecordSourceID
) ss





/*sales_tesp*/


SET @max_MeasureId=(SELECT COALESCE(MAX(MeasureId),0) from ser.Measure)

INSERT INTO ser.Measure
(
MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
SCDStartDate,       
SCDEndDate,
SCDActiveFlag,
SCDVersion,     
SCDLOVRecordSourceId,
ETLRunLogId
)
 

SELECT
(ROW_NUMBER() OVER( ORDER BY MeasureName,LOVMeasureTypeId,LOVRecordSourceId  ASC)+@max_MeasureId + 1) MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
@SCDStartDate SCDStartDate,
@SCDEndDate SCDEndDate,
@SCDActiveFlag SCDActiveFlag,
@SCDVersion SCDVersion,
@SCDLOVRecordSourceId SCDLOVRecordSourceId,
@ETLRunLogId ETLRunLogId
FROM
(select 
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'PLANOGRAM_AGGREGATION' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs WHERE rs.LOVSetName = 'Measure Type')) LOVMeasureTypeId,
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'DECIMAL' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Data Type')) LOVDataTypeId,
'sales_tesp' MeasureName,
'Tax exclusive selling price total for all the items on the planogram for that week' MeasureDescription,
NULL Length,
16 Precision,
4 Scale,
NULL StandardMeasureId,
12006 LOVRecordSourceID
) ss





/*sales_tisp*/


SET @max_MeasureId=(SELECT COALESCE(MAX(MeasureId),0) from ser.Measure)

INSERT INTO ser.Measure
(
MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
SCDStartDate,       
SCDEndDate,
SCDActiveFlag,
SCDVersion,     
SCDLOVRecordSourceId,
ETLRunLogId
)
 

SELECT
(ROW_NUMBER() OVER( ORDER BY MeasureName,LOVMeasureTypeId,LOVRecordSourceId  ASC)+@max_MeasureId + 2) MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
@SCDStartDate SCDStartDate,
@SCDEndDate SCDEndDate,
@SCDActiveFlag SCDActiveFlag,
@SCDVersion SCDVersion,
@SCDLOVRecordSourceId SCDLOVRecordSourceId,
@ETLRunLogId ETLRunLogId
FROM
(select 
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'PLANOGRAM_AGGREGATION' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs WHERE rs.LOVSetName = 'Measure Type')) LOVMeasureTypeId,
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'DECIMAL' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Data Type')) LOVDataTypeId,
'sales_tisp' MeasureName,
'Tax inclusive selling price total for all the items on the planogram for that week' MeasureDescription,
NULL Length,
16 Precision,
4 Scale,
NULL StandardMeasureId,
12006 LOVRecordSourceID
) ss


/*sales_epgp*/

SET @max_MeasureId=(SELECT COALESCE(MAX(MeasureId),0) from ser.Measure)

INSERT INTO ser.Measure
(
MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
SCDStartDate,       
SCDEndDate,
SCDActiveFlag,
SCDVersion,     
SCDLOVRecordSourceId,
ETLRunLogId
)
 

SELECT
(ROW_NUMBER() OVER( ORDER BY MeasureName,LOVMeasureTypeId,LOVRecordSourceId  ASC)+@max_MeasureId + 3) MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
@SCDStartDate SCDStartDate,
@SCDEndDate SCDEndDate,
@SCDActiveFlag SCDActiveFlag,
@SCDVersion SCDVersion,
@SCDLOVRecordSourceId SCDLOVRecordSourceId,
@ETLRunLogId ETLRunLogId
FROM
(select 
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'PLANOGRAM_AGGREGATION' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs WHERE rs.LOVSetName = 'Measure Type')) LOVMeasureTypeId,
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'DECIMAL' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Data Type')) LOVDataTypeId,
'sales_epgp' MeasureName,
'EPOS profit For the planogram for that week in that store – cash not a %' MeasureDescription,
NULL Length,
16 Precision,
4 Scale,
NULL StandardMeasureId,
12006 LOVRecordSourceID
) ss



/*modular_buid*/

SET @max_MeasureId=(SELECT COALESCE(MAX(MeasureId),0) from ser.Measure)
INSERT INTO ser.Measure
(
MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
SCDStartDate,       
SCDEndDate,
SCDActiveFlag,
SCDVersion,     
SCDLOVRecordSourceId,
ETLRunLogId
)
 

SELECT
(ROW_NUMBER() OVER( ORDER BY MeasureName,LOVMeasureTypeId,LOVRecordSourceId  ASC)+@max_MeasureId + 4) MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
@SCDStartDate SCDStartDate,
@SCDEndDate SCDEndDate,
@SCDActiveFlag SCDActiveFlag,
@SCDVersion SCDVersion,
@SCDLOVRecordSourceId SCDLOVRecordSourceId,
@ETLRunLogId ETLRunLogId
FROM
(select 
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'PLANOGRAM_AGGREGATION' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs WHERE rs.LOVSetName = 'Measure Type')) LOVMeasureTypeId,
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'DECIMAL' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Data Type')) LOVDataTypeId,
'modular_build' MeasureName,
'Size of the planogram in store.(Instances * POG Build Size)' MeasureDescription,
NULL Length,
16 Precision,
12 Scale,
NULL StandardMeasureId,
12006 LOVRecordSourceID
) ss



/*build_size*/


SET @max_MeasureId=(SELECT COALESCE(MAX(MeasureId),0) from ser.Measure)

INSERT INTO ser.Measure
(
MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
SCDStartDate,       
SCDEndDate,
SCDActiveFlag,
SCDVersion,     
SCDLOVRecordSourceId,
ETLRunLogId
)
 

SELECT
(ROW_NUMBER() OVER( ORDER BY MeasureName,LOVMeasureTypeId,LOVRecordSourceId  ASC)+@max_MeasureId + 5) MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
@SCDStartDate SCDStartDate,
@SCDEndDate SCDEndDate,
@SCDActiveFlag SCDActiveFlag,
@SCDVersion SCDVersion,
@SCDLOVRecordSourceId SCDLOVRecordSourceId,
@ETLRunLogId ETLRunLogId
FROM
(select 
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'PLANOGRAM_AGGREGATION' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs WHERE rs.LOVSetName = 'Measure Type')) LOVMeasureTypeId,
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'INT' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Data Type')) LOVDataTypeId,
'build_size' MeasureName,
'Build Size of the planogram' MeasureDescription,
NULL Length,
NULL Precision,
NULL Scale,
NULL StandardMeasureId,
12006 LOVRecordSourceID
) ss



/*instances*/

SET @max_MeasureId=(SELECT COALESCE(MAX(MeasureId),0) from ser.Measure)

INSERT INTO ser.Measure
(
MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
SCDStartDate,       
SCDEndDate,
SCDActiveFlag,
SCDVersion,     
SCDLOVRecordSourceId,
ETLRunLogId
)
 

SELECT
(ROW_NUMBER() OVER( ORDER BY MeasureName,LOVMeasureTypeId,LOVRecordSourceId  ASC)+@max_MeasureId + 6) MeasureId,
LOVMeasureTypeId,
LOVDataTypeId,                       
MeasureName,                                           
MeasureDescription,
Length,
Precision,
Scale,
StandardMeasureId,
LOVRecordSourceID,
@SCDStartDate SCDStartDate,
@SCDEndDate SCDEndDate,
@SCDActiveFlag SCDActiveFlag,
@SCDVersion SCDVersion,
@SCDLOVRecordSourceId SCDLOVRecordSourceId,
@ETLRunLogId ETLRunLogId
FROM
(select 
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'PLANOGRAM_AGGREGATION' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs WHERE rs.LOVSetName = 'Measure Type')) LOVMeasureTypeId,
(SELECT r.LovID from ser.RefLOV r WHERE r.LOVKey = 'INT' AND r.LovSetID IN (SELECT rs.LovSetID from ser.RefLOVSet rs where rs.LOVSetName = 'Data Type')) LOVDataTypeId,
'instances' MeasureName,
'Instances are usually how many times a planogram occurs in a store' MeasureDescription,
NULL Length,
NULL Precision,
NULL Scale,
NULL StandardMeasureId,
12006 LOVRecordSourceID
) ss

END
--Position
SET @max_measureID=(SELECT COALESCE(MAX(MeasureId),0) FROM  ser.Measure)
 INSERT INTO [SER].[MEASURE]
(MeasureId,LOVMeasureTypeId,LOVDataTypeId,MeasureName,MeasureDescription,Length,Precision,Scale,StandardMeasureId,LOVRecordSourceId,
SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId)
       SELECT  
            @max_measureID+1 MeasureId,
            (select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rls.LOVSetName = 'Measure Type'),
            (select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'INT' AND rls.LOVSetName = 'Data Type'),
            'product_location' ,
            'Planogram item Location ID on the planogram' ,
            null ,
            null ,
            null ,
            null ,
            12002,
            '1900-01-01 00:00:00',
            '9999-12-31 00:00:00',
            'Y',
            1,
            151,
            null
        UNION
        SELECT  
            @max_measureID+2 ,
            (select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rls.LOVSetName = 'Measure Type'),
            (select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'STRING' AND rls.LOVSetName = 'Data Type'),
            'product_facing' ,
            'Item facings for the planogram item' ,
            null ,
            null ,
            null ,
            null ,
            12002,
            '1900-01-01 00:00:00',
            '9999-12-31 00:00:00' ,
            'Y',
            1,
            151,
            null
        UNION   
        SELECT
             @max_measureID+3 ,
            (select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rls.LOVSetName = 'Measure Type'),
            (select rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'STRING' AND rls.LOVSetName = 'Data Type'),
            'item_segment' ,
            'Planogram Item Segment on the planogram' ,
            null ,
            null ,
            null ,
            null ,
            12002,
            '1900-01-01 00:00:00',
            '9999-12-31 00:00:00' ,
            'Y',
            1,
            151,
            null
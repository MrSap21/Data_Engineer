--PARTY DML
Insert into ser.party(partyID,LOVPartyTypeId,SourceKey,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRUNLOGID)
SELECT 1,(SELECT LOVId FROM ser.RefLOV r,ser.RefLOVSet rs WHERE r.LOVKey = 'ORG'  AND r.LOVSetId =  rs.LOVSetId and rs.LOVSetName = 'Party Type'),'WBA-NO-BN',12005,'1900-01-01 00:00:00.000','9999-12-31 00:00:00.000','Y',1,151,NULL
Insert into ser.party(partyID,LOVPartyTypeId,SourceKey,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRUNLOGID)
SELECT 2,(SELECT LOVId FROM ser.RefLOV r,ser.RefLOVSet rs WHERE r.LOVKey = 'ORG'  AND r.LOVSetId =  rs.LOVSetId and rs.LOVSetName = 'Party Type'),'WBA-MX-FB',12004,'1900-01-01 00:00:00.000','9999-12-31 00:00:00.000','Y',1,151,NULL
Insert into ser.party(partyID,LOVPartyTypeId,SourceKey,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRUNLOGID)
SELECT 3,(SELECT LOVId FROM ser.RefLOV r,ser.RefLOVSet rs WHERE r.LOVKey = 'ORG'  AND r.LOVSetId =  rs.LOVSetId and rs.LOVSetName = 'Party Type'),'WBA-TH-BT',12010,'1900-01-01 00:00:00.000','9999-12-31 00:00:00.000','Y',1,151,NULL
Insert into ser.party(partyID,LOVPartyTypeId,SourceKey,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRUNLOGID)
SELECT 4,(SELECT LOVId FROM ser.RefLOV r,ser.RefLOVSet rs WHERE r.LOVKey = 'ORG'  AND r.LOVSetId =  rs.LOVSetId and rs.LOVSetName = 'Party Type'),'WBA-CL-FA',12001,'1900-01-01 00:00:00.000','9999-12-31 00:00:00.000','Y',1,151,NULL
Insert into ser.party(partyID,LOVPartyTypeId,SourceKey,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRUNLOGID)
SELECT 5,(SELECT LOVId FROM ser.RefLOV r,ser.RefLOVSet rs WHERE r.LOVKey = 'ORG'  AND r.LOVSetId =  rs.LOVSetId and rs.LOVSetName = 'Party Type'),'WBA-UK-BTC',12008,'1900-01-01 00:00:00.000','9999-12-31 00:00:00.000','Y',1,151,NULL
Insert into ser.party(partyID,LOVPartyTypeId,SourceKey,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRUNLOGID)
SELECT 6,(SELECT rl.LOVId FROM ser.RefLov rl,ser.RefLovset rls WHERE rl.LOVSetId=rls.LOVSetID AND rl.LOVKey = 'ORG' AND rls.LOVSetName = 'Party Type'),'WBA-UK-BTC',12012,'1900-01-01 00:00:00.000','9999-12-31 00:00:00.000','Y',1,151,NULL
DECLARE @cur_date datetime = getutcdate(),
        @cur_user varchar(50)= system_user
TRUNCATE TABLE [psa].[cf_feed_load_status]
--Feed Load Status
insert into [psa].[cf_feed_load_status] values (1,'STARTED',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_load_status] values (2,'FAILED',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_load_status] values (3,'ONHOLD',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_load_status] values (4,'COMPLETED',1,@cur_date,@cur_user)

TRUNCATE TABLE [psa].[cf_feed_filter]
insert into [psa].[cf_feed_filter] values (1,'01',1,2,1,1,@cur_date,@cur_user)

TRUNCATE TABLE [psa].[cf_stored_proc]

--Stored Procedure Details 
insert into [psa].[cf_stored_proc] values (0, 'dummy.sql', 1, @cur_date, @cur_user)
insert into [psa].[cf_stored_proc] values (1,'psa.sp_IncrementalDataCapture', 1, @cur_date, @cur_user)
insert into [psa].[cf_stored_proc] values (3,'psa.sp_inc_uk_btc_mdm_article', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (4,'psa.sp_inc_uk_mf_dwtoffer', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (5,'psa.sp_inc_uk_base_store_plan', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (6,'psa.sp_inc_uk_base_plan_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (7,'psa.sp_inc_btc_mdm_store', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (8,'psa.sp_inc_uk_btc_ix_spc_fixture', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (9,'psa.sp_inc_uk_btc_ix_spc_planogram', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (10,'psa.sp_inc_uk_btc_ix_spc_position', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (11,'psa.sp_inc_uk_btc_ix_spc_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (12,'psa.sp_inc_int_crp_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (13,'psa.sp_inc_cl_crp_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (14,'psa.sp_inc_int_crp_store', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (15,'psa.sp_inc_th_crp_merchandise', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (16,'psa.sp_inc_th_crp_layout_performance', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (17,'psa.sp_inc_th_crp_planogram', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (18,'psa.sp_inc_cl_crp_merchandise',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (19,'psa.sp_inc_cl_crp_planogram',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (20,'psa.sp_inc_cl_crp_layout_performance',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (21,'psa.sp_inc_mx_crp_merchandise',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (22,'psa.sp_inc_mx_crp_planogram',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (23,'psa.sp_inc_mx_crp_layout_performance',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (24,'psa.sp_inc_no_crp_merchandise',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (25,'psa.sp_inc_no_crp_planogram',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (26,'psa.sp_inc_no_crp_layout_performance',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (27,'psa.sp_cl_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (28,'psa.sp_mx_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (29,'psa.sp_no_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (30,'psa.sp_th_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (31,'psa.sp_aw_membership_card', 1, @cur_date, @cur_user)
insert into [psa].[cf_stored_proc] values (32,'psa.sp_uk_abacus_header',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (33,'psa.sp_uk_abacus_item',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (34,'psa.sp_IncrementalDataCapture_Intactix',1,@cur_date,@cur_user);

TRUNCATE TABLE [psa].[cf_feed_configuration]
--All stored Procedure missing Ids are updated as 0
--Table Name missing (*switching_group* and *vendor_funding* kept as blank)
---Chile Feed Mapping
insert into [psa].[cf_feed_configuration] values (154,'cl_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (155,'cl_crp_item_transaction',1,27,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (156,'cl_crp_layout_performance',1,20,'','160,157',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (157,'cl_crp_merchandise',1,18,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (158,'cl_crp_planogram',1,19,'','159,157',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (159,'cl_crp_product',1,13,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (161,'cl_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (160,'cl_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
--Table name  needs to be updated for switching_group and vendor_funding  
insert into [psa].[cf_feed_configuration] values (162,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (163,'',1,0,'','',null,1,@cur_date,@cur_user)
--Mexico Feed Mapping
insert into [psa].[cf_feed_configuration] values (165,'mx_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (166,'mx_crp_item_transaction',1,28,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (167,'mx_crp_layout_performance',1,23,'','171,168',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (168,'mx_crp_merchandise',1,21,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (169,'mx_crp_planogram',1,22,'','170,168',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (170,'mx_crp_product',1,12,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (171,'mx_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (172,'mx_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
--Table name  needs to be updated for switching_group and vendor_funding  
insert into [psa].[cf_feed_configuration] values (173,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (174,'',1,0,'','',null,1,@cur_date,@cur_user)
--Norway Feed Mapping
insert into [psa].[cf_feed_configuration] values (176,'no_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (177,'no_crp_item_transaction',1,29,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (178,'no_crp_layout_performance',1,26,'','182,179',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (179,'no_crp_merchandise',1,24,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (180,'no_crp_planogram',1,25,'','181,179',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (181,'no_crp_product',1,12,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (182,'no_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (183,'no_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
--Table name  needs to be updated for switching_group and vendor_funding  
insert into [psa].[cf_feed_configuration] values (184,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (185,'',1,0,'','',null,1,@cur_date,@cur_user)
--Thailand Feed Mapping
insert into [psa].[cf_feed_configuration] values (187,'th_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (188,'th_crp_item_transaction',1,30,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (189,'th_crp_layout_performance',1,16,'','193,190',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (190,'th_crp_merchandise',1,15,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (191,'th_crp_planogram',1,17,'','192,190',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (192,'th_crp_product',1,12,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (193,'th_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (194,'th_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
--Table name  needs to be updated for switching_group and vendor_funding  
insert into [psa].[cf_feed_configuration] values (195,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (196,'',1,0,'','',null,1,@cur_date,@cur_user)
--Intactix Feed Mapping
insert into [psa].[cf_feed_configuration] values (198,'uk_btc_ix_spc_fixture',34,8,'','199','\\N',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (199,'uk_btc_ix_spc_planogram',34,9,'','','\\N',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (200,'uk_btc_ix_spc_position',34,10,'','201,199,198','\\N',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (201,'uk_btc_ix_spc_product',34,11,'','','\\N',1,@cur_date,@cur_user)
--MDM Feed Mapping
insert into [psa].[cf_feed_configuration] values (148,'uk_btc_mdm_store',1,7,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (150,'uk_btc_mdm_article',1,3,1,'',null,1,@cur_date,@cur_user)
--MainFrame Mapping
insert into [psa].[cf_feed_configuration] values (152,'uk_mf_dwoffer',1,4,'','150',null,1,@cur_date,@cur_user)
--SAP BW Mapping
insert into [psa].[cf_feed_configuration] values (122,'uk_abacus_item',1,33,'','120',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (124,'uk_abacus_payment',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (126,'uk_abacus_coupon',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (128,'uk_abacus_deals',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (130,'uk_abacus_promotions',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (142,'uk_sap_storearticlesales',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (140,'uk_sap_crp_productivity',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (138,'uk_sap_crp_distribution',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (136,'uk_sap_articlesales',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (134,'uk_base_store_plan',1,5,'','148,199',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (132,'uk_base_plan_product',1,6,'','201,199',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (120,'uk_abacus_header',1,32,'','250','MIGyBgkqhkiG9w0BBwaggaQwgaECAQAwgZsGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoATYEnRgbyYBgyFJ+RHa4RV5ZagzA==',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (250,'uk_aw_membership_card',1,31,'','',null,1,@cur_date,@cur_user)

--SAP R3 Mapping
insert into [psa].[cf_feed_configuration] values (144,'uk_btc_promotion_deal',1,0,'','',null,1,@cur_date,@cur_user)


TRUNCATE TABLE [psa].[cf_batch]
--Batch Id details
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',159,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',160,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',157,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',158,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',155,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',156,6,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',170,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',171,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',168,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',169,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',166,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',167,6,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',181,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',182,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',179,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',180,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',177,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',178,6,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',192,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',193,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',190,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',191,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',188,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',189,6,1,@cur_date,@cur_user)

-- BUKROI Batch for QA run
/*
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',201,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',199,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',198,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',200,4,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (6,'MDM',148,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'MDM',150,2,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',132,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',134,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',250,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',120,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',122,5,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (8,'Mainframe',152,1,1,@cur_date,@cur_user)
*/


-- BUKROI Batch for production run
INSERT INTO [psa].[cf_batch] VALUES (10,'Intactix',201,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'Intactix',199,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'Intactix',198,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'Intactix',200,4,1,@cur_date,@cur_user)
--*****************************************************************************
INSERT INTO [psa].[cf_batch] VALUES (10,'MDM',148,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'MDM',150,6,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'Mainframe',152,7,1,@cur_date,@cur_user)
--*****************************************************************************
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',132,8,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',134,9,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',250,10,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',120,11,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',122,12,1,@cur_date,@cur_user)
GO
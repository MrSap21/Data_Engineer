DECLARE @cur_date datetime = getutcdate(),
        @cur_user varchar(50)= system_user
TRUNCATE TABLE [psa].[cf_feed_load_status]
--Feed Load Status
insert into [psa].[cf_feed_load_status] values (1,'STARTED',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_load_status] values (2,'FAILED',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_load_status] values (3,'ONHOLD',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_load_status] values (4,'COMPLETED',1,@cur_date,@cur_user)

TRUNCATE TABLE [psa].[cf_feed_configuration]
--All stored Procedure missing Ids are updated as 0
--Table Name missing (*switching_group* and *vendor_funding* kept as blank)
---Chile Feed Mapping
insert into [psa].[cf_feed_configuration] values (164,'cl_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (135,'cl_crp_item_transaction',1,27,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (165,'cl_crp_layout_performance',1,20,'','169,166',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (166,'cl_crp_merchandise',1,18,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (167,'cl_crp_planogram',1,19,'','168,166',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (168,'cl_crp_product',1,13,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (134,'cl_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (169,'cl_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (170,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (171,'',1,0,'','',null,1,@cur_date,@cur_user)
--Mexico Feed Mapping
insert into [psa].[cf_feed_configuration] values (172,'mx_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (143,'mx_crp_item_transaction',1,28,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (142,'mx_crp_layout_performance',1,23,'','138,141',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (141,'mx_crp_merchandise',1,21,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (140,'mx_crp_planogram',1,22,'','139,141',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (139,'mx_crp_product',1,12,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (138,'mx_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (137,'mx_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (173,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (174,'',1,0,'','',null,1,@cur_date,@cur_user)
--Norway Feed Mapping
insert into [psa].[cf_feed_configuration] values (175,'no_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (161,'no_crp_item_transaction',1,29,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (160,'no_crp_layout_performance',1,26,'','156,159',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (159,'no_crp_merchandise',1,24,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (158,'no_crp_planogram',1,25,'','157,159',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (157,'no_crp_product',1,12,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (156,'no_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (155,'no_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (177,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (176,'',1,0,'','',null,1,@cur_date,@cur_user)
--Thailand Feed Mapping
insert into [psa].[cf_feed_configuration] values (178,'th_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (151,'th_crp_item_transaction',1,30,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (150,'th_crp_layout_performance',1,16,'','146,149',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (149,'th_crp_merchandise',1,15,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (148,'th_crp_planogram',1,17,'','147,149',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (147,'th_crp_product',1,12,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (146,'th_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (145,'th_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (180,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (179,'',1,0,'','',null,1,@cur_date,@cur_user)
--Intactix Feed Mapping
insert into [psa].[cf_feed_configuration] values (125,'uk_btc_ix_spc_fixture',34,8,'','126','\\N',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (126,'uk_btc_ix_spc_planogram',34,9,'','','\\N',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (127,'uk_btc_ix_spc_position',34,10,'','128,126,125','\\N',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (128,'uk_btc_ix_spc_product',34,11,'','','\\N',1,@cur_date,@cur_user)
--MDM Feed Mapping
insert into [psa].[cf_feed_configuration] values (106,'uk_btc_mdm_store',1,7,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (108,'uk_btc_mdm_article',1,3,1,'',null,1,@cur_date,@cur_user)
--SAP BW Mapping
insert into [psa].[cf_feed_configuration] values (96,'uk_abacus_item',1,33,'','132',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (98,'uk_abacus_payment',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (100,'uk_abacus_coupon',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (102,'uk_abacus_deals',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (104,'uk_abacus_promotions',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (120,'uk_sap_storearticlesales',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (118,'uk_sap_crp_productivity',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (116,'uk_sap_crp_distribution',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (114,'uk_sap_articlesales',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (112,'uk_base_store_plan',1,5,'','106,126',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (110,'uk_base_plan_product',1,6,'','128,126',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (132,'uk_abacus_header',1,32,'','184','MIGyBgkqhkiG9w0BBwaggaQwgaECAQAwgZsGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoATYEnRgbyYBgyFJ+RHa4RV5ZagzA==',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (184,'UK_AW_MEMBERSHIP_CARD',1,31,'','',null,1,@cur_date,@cur_user)
--MainFrame Mapping
insert into [psa].[cf_feed_configuration] values (94,'uk_mf_dwoffer',1,4,'','108',null,1,@cur_date,@cur_user)
--SAP R3 Mapping
insert into [psa].[cf_feed_configuration] values (123,'uk_btc_promotion_deal',1,0,'','',null,1,@cur_date,@cur_user)

TRUNCATE TABLE [psa].[cf_feed_filter]
insert into [psa].[cf_feed_filter] values (1,'01',1,2,1,1,@cur_date,@cur_user)


TRUNCATE TABLE [psa].[cf_stored_proc]

--Stored Procedure Details 
insert into [psa].[cf_stored_proc] values (0, 'dummy.sql', 1, @cur_date, @cur_user)
insert into [psa].[cf_stored_proc] values (1,'psa.sp_IncrementalDataCapture', 1, @cur_date, @cur_user)
insert into [psa].[cf_stored_proc] values (3,'psa.sp_inc_uk_btc_mdm_article', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (4,'psa.sp_inc_uk_mf_dwtoffer', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (5,'psa.sp_inc_uk_base_store_plan', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (6,'psa.sp_inc_uk_base_plan_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (7,'psa.sp_inc_btc_mdm_store', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (8,'psa.sp_inc_uk_btc_ix_spc_fixture', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (9,'psa.sp_inc_uk_btc_ix_spc_planogram', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (10,'psa.sp_inc_uk_btc_ix_spc_position', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (11,'psa.sp_inc_uk_btc_ix_spc_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (12,'psa.sp_inc_int_crp_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (13,'psa.sp_inc_cl_crp_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (14,'psa.sp_inc_int_crp_store', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (15,'psa.sp_inc_th_crp_merchandise', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (16,'psa.sp_inc_th_crp_layout_performance', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (17,'psa.sp_inc_th_crp_planogram', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (18,'psa.sp_inc_cl_crp_merchandise',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (19,'psa.sp_inc_cl_crp_planogram',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (20,'psa.sp_inc_cl_crp_layout_performance',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (21,'psa.sp_inc_mx_crp_merchandise',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (22,'psa.sp_inc_mx_crp_planogram',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (23,'psa.sp_inc_mx_crp_layout_performance',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (24,'psa.sp_inc_no_crp_merchandise',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (25,'psa.sp_inc_no_crp_planogram',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (26,'psa.sp_inc_no_crp_layout_performance',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (27,'psa.sp_cl_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (28,'psa.sp_mx_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (29,'psa.sp_no_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (30,'psa.sp_th_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (31,'psa.sp_aw_membership_card', 1, @cur_date, @cur_user)
insert into [psa].[cf_stored_proc] values (32,'psa.sp_uk_abacus_header',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (33,'psa.sp_uk_abacus_item',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (34,'psa.sp_IncrementalDataCapture_Intactix',1,@cur_date,@cur_user);

TRUNCATE TABLE [psa].[cf_batch]
--Batch Id details
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',168,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',169,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',166,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',167,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',135,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',165,6,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',139,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',138,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',141,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',140,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',143,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',142,6,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',157,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',156,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',159,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',158,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',161,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',160,6,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',147,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',146,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',149,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',148,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',151,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',150,6,1,@cur_date,@cur_user)

-- BUKROI Batch for QA run
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',128,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',126,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',125,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',127,4,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (6,'MDM',106,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'MDM',108,2,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',110,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',112,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',184,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',132,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (7,'SAPBW',96,5,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (8,'Mainframe',94,1,1,@cur_date,@cur_user)


-- BUKROI Batch for production run
INSERT INTO [psa].[cf_batch] VALUES (10,'Intactix',128,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'Intactix',126,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'Intactix',125,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'Intactix',127,4,1,@cur_date,@cur_user)
--*****************************************************************************
INSERT INTO [psa].[cf_batch] VALUES (10,'MDM',106,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'MDM',108,6,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'Mainframe',94,7,1,@cur_date,@cur_user)
--*****************************************************************************
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',110,8,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',112,9,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',184,10,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',132,11,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (10,'SAPBW',96,12,1,@cur_date,@cur_user)
DECLARE @cur_date datetime = getutcdate(),
        @cur_user varchar(50)= system_user

--Feed Load Status
insert into [psa].[cf_feed_load_status] values (1,'STARTED',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_load_status] values (2,'FAILED',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_load_status] values (3,'ONHOLD',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_load_status] values (4,'COMPLETED',1,@cur_date,@cur_user)

--All stored Procedure missing Ids are updated as 0
--Table Name missing (*switching_group* and *vendor_funding* kept as blank)
---Chile Feed Mapping
insert into [psa].[cf_feed_configuration] values (225,'cl_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (226,'cl_crp_item_transaction',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (227,'cl_crp_layout_performance',1,20,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (228,'cl_crp_merchandise',1,18,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (229,'cl_crp_planogram',1,19,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (230,'cl_crp_product',1,13,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (231,'cl_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (268,'cl_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (232,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (233,'',1,0,'','',null,1,@cur_date,@cur_user)
--Mexico Feed Mapping
insert into [psa].[cf_feed_configuration] values (234,'mx_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (235,'mx_crp_item_transaction',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (236,'mx_crp_layout_performance',1,23,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (237,'mx_crp_merchandise',1,21,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (238,'mx_crp_planogram',1,22,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (239,'mx_crp_product',1,12,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (240,'mx_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (241,'mx_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (242,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (243,'',1,0,'','',null,1,@cur_date,@cur_user)
--Norway Feed Mapping
insert into [psa].[cf_feed_configuration] values (244,'no_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (245,'no_crp_item_transaction',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (246,'no_crp_layout_performance',1,26,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (247,'no_crp_merchandise',1,24,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (248,'no_crp_planogram',1,25,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (249,'no_crp_product',1,12,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (250,'no_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (251,'no_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (252,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (253,'',1,0,'','',null,1,@cur_date,@cur_user)
--Thailand Feed Mapping
insert into [psa].[cf_feed_configuration] values (254,'th_crp_customer',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (255,'th_crp_item_transaction',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (256,'th_crp_layout_performance',1,16,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (257,'th_crp_merchandise',1,15,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (258,'th_crp_planogram',1,17,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (259,'th_crp_product',1,12,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (260,'th_crp_store',1,14,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (261,'th_crp_store_trial_analysis',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (262,'',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (263,'',1,0,'','',null,1,@cur_date,@cur_user)
--Intactix Feed Mapping
insert into [psa].[cf_feed_configuration] values (264,'uk_btc_ix_spc_fixture',1,8,'','','\N',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (265,'uk_btc_ix_spc_planogram',1,9,'','','\N',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (266,'uk_btc_ix_spc_position',1,10,'','','\N',1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (267,'uk_btc_ix_spc_product',1,11,'','','\N',1,@cur_date,@cur_user)
--MDM Feed Mapping
insert into [psa].[cf_feed_configuration] values (163,'uk_btc_mdm_store',1,7,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (165,'uk_btc_mdm_article',1,3,1,'',null,1,@cur_date,@cur_user)
--SAP BW Mapping
insert into [psa].[cf_feed_configuration] values (152,'uk_abacus_item',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (155,'uk_abacus_payment',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (157,'uk_abacus_coupon',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (159,'uk_abacus_deals',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (161,'uk_abacus_promotions',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (167,'uk_sap_storearticlesales',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (169,'uk_sap_crp_productivity',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (171,'uk_sap_crp_distribution',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (173,'uk_sap_articlesales',1,0,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (175,'uk_base_store_plan',1,5,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (177,'uk_base_plan_product',1,6,'','',null,1,@cur_date,@cur_user)
insert into [psa].[cf_feed_configuration] values (186,'uk_abacus_header',1,0,'','',null,1,@cur_date,@cur_user)
--MainFrame Mapping
insert into [psa].[cf_feed_configuration] values (182,'uk_mf_dwoffer',1,4,'','',null,1,@cur_date,@cur_user)

insert into [psa].[cf_feed_filter] values (1,'01',1,2,1,1,@cur_date,@cur_user)

--Stored Procedure Details 
insert into [psa].[cf_stored_proc] values (0, 'cxxx.sql', 1, @cur_date, @cur_user)
insert into [psa].[cf_stored_proc] values (1,'psa.sp_IncrementalDataCapture', 1, @cur_date, @cur_user)
insert into [psa].[cf_stored_proc] values (3,'psa.sp_inc_uk_btc_mdm_article', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (4,'psa.sp_inc_uk_mf_dwtoffer', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (5,'psa.sp_inc_uk_base_store_plan', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (6,'psa.sp_inc_uk_base_plan_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (7,'psa.sp_inc_btc_mdm_store', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (8,'psa.sp_inc_uk_btc_ix_spc_fixture', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (9,'psa.sp_inc_uk_btc_ix_spc_planogram', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (10,'psa.sp_inc_uk_btc_ix_spc_position', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (11,'psa.sp_inc_uk_btc_ix_spc_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (12,'psa.sp_inc_int_crp_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (13,'psa.sp_inc_cl_crp_product', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (14,'psa.sp_inc_int_crp_store', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (15,'psa.sp_inc_th_crp_merchandise', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (16,'psa.sp_inc_th_crp_layout_performance', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (17,'psa.sp_inc_th_crp_planogram', 1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (18,'psa.sp_inc_cl_crp_merchandise',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (19,'psa.sp_inc_cl_crp_planogram',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (20,'psa.sp_inc_cl_crp_layout_performance',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (21,'psa.sp_inc_mx_crp_merchandise',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (22,'psa.sp_inc_mx_crp_planogram',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (23,'psa.sp_inc_mx_crp_layout_performance',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (24,'psa.sp_inc_no_crp_merchandise',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (25,'psa.sp_inc_no_crp_planogram',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (26,'psa.sp_inc_no_crp_layout_performance',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (27,'psa.sp_cl_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (28,'psa.sp_mx_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (29,'psa.sp_no_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (30,'psa.sp_th_crp_item_transaction',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (31,'psa.sp_uk_abacus_header',1,@cur_date,@cur_user);
insert into [psa].[cf_stored_proc] values (32,'psa.sp_uk_abacus_item',1,@cur_date,@cur_user);

--Batch Id details
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',230,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',268,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',228,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',229,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',226,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',225,6,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',227,7,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',231,8,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',232,9,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (1,'Chile',233,10,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',239,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',240,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',237,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',238,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',235,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',234,6,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',236,7,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',241,8,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',242,9,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (2,'Mexico',243,10,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',249,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',250,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',247,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',248,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',245,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',244,6,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',246,7,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',251,8,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',252,9,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (3,'Norway',252,10,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',259,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',260,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',257,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',258,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',254,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',255,6,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',256,7,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',261,8,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',262,9,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (4,'Thailand',263,10,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',264,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',265,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',266,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'Intactix',267,4,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (5,'MDM',163,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (5,'MDM',165,2,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',152,1,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',155,2,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',157,3,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',159,4,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',161,5,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',167,6,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',169,7,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',171,8,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',173,9,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',175,10,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',177,11,1,@cur_date,@cur_user)
INSERT INTO [psa].[cf_batch] VALUES (6,'SAPBW',186,12,1,@cur_date,@cur_user)

INSERT INTO [psa].[cf_batch] VALUES (7,'Mainframe',182,1,1,@cur_date,@cur_user)
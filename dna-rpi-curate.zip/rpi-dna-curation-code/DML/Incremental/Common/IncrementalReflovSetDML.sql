INSERT [ser].[RefLOVSet] (LOVSetId,LOVSetName,LOVSetDescription,LOVSetSequence,RecordSourceId,DTCreated,UserCreated,ActiveFlag,ETLRunLogId) 
VALUES (199000, N'advantage_promotions', N'advantage_promotions', 1, 12008, N'2020-08-13T00:00:00', NULL, N'1', NULL)
GO

INSERT [ser].[RefLOVSet] (LOVSetId,LOVSetName,LOVSetDescription,LOVSetSequence,RecordSourceId,DTCreated,UserCreated,ActiveFlag,ETLRunLogId) 
VALUES (200000, N'Indicator - CHILE Transaction', N'Indicator - CHILE Transaction', 1, 12001, N'2020-08-13T00:00:00', NULL, N'1', NULL)
GO
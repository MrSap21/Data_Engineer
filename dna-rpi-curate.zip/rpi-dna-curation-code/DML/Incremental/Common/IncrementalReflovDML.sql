INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (120005453, 12000, N'1L6', N'1L6', N'1L6', 5453, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (120005454, 12000, N'3FN', N'3FN', N'3FN', 5454, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (120005455, 12000, N'6AA', N'6AA', N'6AA', 5455, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (85000279, 85000, N'44299', N'44299', N'44299', 279, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (85000280, 85000, N'44300', N'44300', N'44300', 280, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (86000405, 86000, N'33334', N'33334', N'33334', 405, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (92000905, 92000, N'ZXT', N'ZXT', N'ZXT', 905, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (1790008811, 179000, N'3JN', N'3JN', N'3JN', 8811, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (1790008812, 179000, N'BED', N'BED', N'BED', 8812, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (1790008813, 179000, N'BFR', N'BFR', N'BFR', 8813, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (1790008814, 179000, N'TFY', N'TFY', N'TFY', 8814, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (1800001287, 180000, N'9PX', N'9PX', N'9PX', 1287, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (1800001288, 180000, N'9Q7', N'9Q7', N'9Q7', 1288, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (1800001289, 180000, N'9Q8', N'9Q8', N'9Q8', 1289, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

INSERT [ser].[reflov] ([LOVID], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [RecordSourceId], [DTCreated], [UserCreated], [ActiveFlag], [ETLRunLogId])  VALUES (1800001290, 180000, N'9QF', N'9QF', N'9QF', 1290, 12008, N'2020-09-07 00:00:00.000', N'JOntiveros', N'1', NULL);
GO

DELETE ser.RefLOV WHERE lovsetid = 185000;
GO

INSERT [ser].[RefLOV] (LOVId,LOVSetId,LOVKey,LOVName,LOVDescription,LOVSequence,RecordSourceId,DTCreated,UserCreated,ETLRunLogId,ActiveFlag) 
VALUES (199000001, 199000, N'E', N'NO EARN / NO REDEEM', N'NO EARN / NO REDEEM', 1, 12008, N'2020-08-13T00:00:00', N'gssadmin', NULL, N'1')
GO

INSERT [ser].[RefLOV] (LOVId,LOVSetId,LOVKey,LOVName,LOVDescription,LOVSequence,RecordSourceId,DTCreated,UserCreated,ETLRunLogId,ActiveFlag) 
VALUES (199000002, 199000, N'N', N'EARN / NO REDEEM', N'EARN / NO REDEEM', 2, 12008, N'2020-08-13T00:00:00', N'gssadmin', NULL, N'1')
GO

INSERT [ser].[RefLOV] (LOVId,LOVSetId,LOVKey,LOVName,LOVDescription,LOVSequence,RecordSourceId,DTCreated,UserCreated,ETLRunLogId,ActiveFlag) 
VALUES (199000003, 199000, N'R', N'EARN / REDEEM', N'EARN / REDEEM', 3, 12008, N'2020-08-13T00:00:00', N'gssadmin', NULL, N'1')
GO

INSERT [ser].[RefLOV] (LOVId,LOVSetId,LOVKey,LOVName,LOVDescription,LOVSequence,RecordSourceId,DTCreated,UserCreated,ETLRunLogId,ActiveFlag) 
VALUES (200000001, 200000, N'prescription', N'prescription', N'prescription', 1, 12001, N'2020-08-13T00:00:00', N'gssadmin', NULL,  N'1')
GO

INSERT [ser].[RefLOV] (LOVId,LOVSetId,LOVKey,LOVName,LOVDescription,LOVSequence,RecordSourceId,DTCreated,UserCreated,ETLRunLogId,ActiveFlag) 
VALUES (185000003, 185000, N'R', N'Points Redemption', N'Points Redemption', 3, 12006, N'2020-07-01T08:17:00', N'gssadmin', NULL,  N'1')
GO

INSERT [ser].[RefLOV] (LOVId,LOVSetId,LOVKey,LOVName,LOVDescription,LOVSequence,RecordSourceId,DTCreated,UserCreated,ETLRunLogId,ActiveFlag) 
VALUES (185000002, 185000, N'M', N'Manual Points Adjustment', N'Manual Points Adjustment', 2, 12006, N'2020-07-01T08:17:00', N'gssadmin', NULL,  N'1')
GO

INSERT [ser].[RefLOV] (LOVId,LOVSetId,LOVKey,LOVName,LOVDescription,LOVSequence,RecordSourceId,DTCreated,UserCreated,ETLRunLogId,ActiveFlag) 
VALUES (185000004, 185000, N'S', N'Non-Credit / Debit Card Sale', N'Non-Credit / Debit Card Sale', 4, 12006, N'2020-07-01T08:17:00', N'gssadmin', NULL,  N'1')
GO

INSERT [ser].[RefLOV] (LOVId,LOVSetId,LOVKey,LOVName,LOVDescription,LOVSequence,RecordSourceId,DTCreated,UserCreated,ETLRunLogId,ActiveFlag) 
VALUES (185000001, 185000, N'C', N'Credit Debit Card Sale', N'Credit Debit Card Sale', 1, 12006, N'2020-07-01T08:17:00', N'gssadmin', NULL,  N'1')
GO

UPDATE ser.reflov  SET lovid= 197000004 where lovid =198000004 and lovsetid=197000;
GO
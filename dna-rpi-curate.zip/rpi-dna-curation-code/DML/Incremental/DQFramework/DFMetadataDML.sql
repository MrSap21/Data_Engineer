DECLARE @cur_date datetime = getutcdate(),
        @cur_user varchar(50)= system_user
TRUNCATE TABLE [psa].[Attribute]
--Populating the Attribute table
INSERT INTO [psa].[Attribute]
           ([AttributeId]
           ,[EntityId]
           ,[AttributeName]
           ,[AttributeDescription]
           ,[Position]
           ,[DataTypeId]
           ,[DataLength]
           ,[DataScale]
           ,[DataPrecision]
           ,[IsNullable]
           ,[AttributeType]
           ,[ActiveFlag]
           ,[DTCreated]
           ,[UserCreated])
    
SELECT [AttributeId], [EntityId], [AttributeName], [AttributeDescription], [Position], [DataTypeId], [DataLength], [DataScale],
    [DataPrecision],1,40003,[ActiveFlag], [DTCreated], [UserCreated] FROM [psa].[AttributeBkp]

--Update Business Keys
UPDATE [psa].[Attribute] SET [AttributeType] =40001 WHERE [EntityId]=1 AND [AttributeId]=1
TRUNCATE TABLE [psa].[Rule]
---Rule Table
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (1,'BK','Business Key','Business Key compliance','EXIST... listagg...$$ATTRIBUTE$$',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (2,'BK','Business Key Validation - Abacus Product','Business Key Validation - Abacus Product','CASE WHEN $$ATTRIBUTE1$$ IS NULL THEN ''FALSE'' ELSE ''TRUE'' END AS BK_SAP_PRODUCT',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (7,'NR','Number Range Check','Is Attribute a Number in Range','SELECT CASE WHEN $$ATTRIBUTE1$$ BETWEEN $$STARTRANGE$$ AND $$ENDRANGE$$ THEN ''TRUE'' ELSE ''FALSE'' END AS NR_check',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (17,'DDC','Duplicate Data Check','Duplicate Data Warning','Check in code',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (9,'AV','Allowable Value Check','Allowable Value Check','SELECT CASE WHEN $$ATTRIBUTE1$$ IN ($$VALUES)  THEN ''TRUE'' ELSE ''FALSE'' END AS AV_check',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (10,'DL','Data Length Check','Data Length Check','SELECT CASE WHEN LEN($$ATTRIBUTE1$$) <= $$LENGTH$$ THEN ''TRUE'' ELSE ''FALSE'' END AS DL_check',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (8,'DR','Date Range Check','Is Attribute a Date in Range','SELECT CASE WHEN $$ATTRIBUTE1$$ BETWEEN $$STARTRANGE$$ AND $$ENDRANGE$$ THEN ''TRUE'' ELSE ''FALSE'' END AS DR_check',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (3,'NN','Not Null Check','Is Attribute null','SELECT CASE WHEN ISNULL($$ATTRIBUTE1$$,NULL) IS NOT NULL THEN ''TRUE'' ELSE ''FALSE'' END AS NN_check',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (16,'DCW','Duplicate Check Warning','Duplicate Check Warning','Check in code',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (14,'DTW','Data Type Check Warning','Data Type Check Warning','Check in code',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (15,'NCW','NULL Check Warning','NULL Check Warning','Check in code',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (11,'RVC','Reference Value Check','Reference Value Check','Check in code',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (12,'FKL','Forigen Key Lookup','Forigen Key Lookup','Check in code',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (13,'BDC','Business Key Duplicate Check','Business Key Duplicate Check','Check in code',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (6,'NC','Number Check','Is Attribute Numeric','SELECT CASE WHEN TRY_$$ATTRIBUTE1$$ AS DECIMAL(20,10)) IS NOT NULL THEN ''TRUE'' ELSE ''FALSE'' END AS NC_check',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (4,'UK','Unique Key Check','Unique Key Check','SELECT CASE WHEN (SELECT COUNT(DISTINCt $$ATTRIBUTE1$$) FROM $$SCHEMANAME.$$TABLENAME HAVING COUNT(DISTINCT $$ATTRIBUTE1$$) > 1 ) = 0 THEN ''TRUE'' ELSE ''FALSE'' END ASUK_check',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (5,'DC','Date Check','Is Attribute a date','SELECT CASE WHEN TRY_$$ATTRIBUTE1$$ AS DATE) IS NOT NULL THEN ''TRUE'' ELSE ''FALSE'' END AS DC_check',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (18,'SRC','Skeleton Record Creation','Skeleton Record Creation','Check in code',21002,22005,1,@cur_date,@cur_user)
INSERT INTO [psa].[Rule] ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES (19,'TC','Time Check','Time Check','Check in code',21002,22005,1,@cur_date,@cur_user)
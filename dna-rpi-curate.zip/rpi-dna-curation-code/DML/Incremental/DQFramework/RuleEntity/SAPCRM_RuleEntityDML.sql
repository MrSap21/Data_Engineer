DECLARE @cur_date DATETIME = CURRENT_TIMESTAMP;
DECLARE @cur_user VARCHAR(50)= CURRENT_USER;
DECLARE @ruleidNN BIGINT;

DECLARE @entityidCRM BIGINT;
DECLARE @entityidpsaCRM BIGINT;
DECLARE @attributeid_accountnumber_CRM BIGINT;
DECLARE @attributeid_cardnumber_CRM BIGINT;
DECLARE @attributeid_cardtypecode_CRM BIGINT;
DECLARE @attributeid_statuscode_CRM BIGINT;

BEGIN
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');
SET @entityidCRM = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname = 'AW_MEMBERSHIP_CARD txt');
SET @entityidpsaCRM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'uk_aw_membership_card');

DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityidpsaCRM);

SET @attributeid_accountnumber_CRM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ACCOUNT_NUMBER' AND entityid = @entityidCRM);
SET @attributeid_cardnumber_CRM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'CARD_NUMBER' AND entityid = @entityidCRM);
SET @attributeid_cardtypecode_CRM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'CARD_TYPE_CODE' AND entityid = @entityidCRM);
SET @attributeid_statuscode_CRM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STATUS_CODE' AND entityid = @entityidCRM);

INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCRM,@attributeid_accountnumber_CRM,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCRM,@attributeid_cardnumber_CRM,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCRM,@attributeid_cardtypecode_CRM,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCRM,@attributeid_statuscode_CRM,28004,'28001',NULL,1,@cur_date,@cur_user);

UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityidCRM AND attributeName IN ('ACCOUNT_NUMBER','CARD_NUMBER','CARD_TYPE_CODE','STATUS_CODE') AND activeflag=1;
UPDATE psa.attribute SET attributeType=40003 WHERE entityID=@entityidCRM AND attributeName NOT IN ('ACCOUNT_NUMBER','CARD_NUMBER','CARD_TYPE_CODE','STATUS_CODE') AND activeflag=1;

PRINT 'Rule Entity for SAP CRM metadata Loaded Sucessfully'

END
/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : BUKROI/International
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @cur_date DATETIME = CURRENT_TIMESTAMP;
DECLARE @cur_user VARCHAR(50)= CURRENT_USER;
DECLARE @ruleidDC BIGINT;
DECLARE @ruleidNN BIGINT;
DECLARE @entityidNO BIGINT;
DECLARE @entityidMX BIGINT;
DECLARE @entityidTH BIGINT;
DECLARE @entityidCL BIGINT;
DECLARE @entityidUA BIGINT;
DECLARE @entityidUI BIGINT;
DECLARE @entityidpsaNO BIGINT;
DECLARE @entityidpsaMX BIGINT;
DECLARE @entityidpsaTH BIGINT;
DECLARE @entityidpsaCL BIGINT;
DECLARE @entityidpsaUA BIGINT;
DECLARE @entityidpsaUI BIGINT;
DECLARE @attributeidTransactionDateNO BIGINT;
DECLARE @attributeidTransactionDateCL BIGINT;
DECLARE @attributeidTransactionDateMX BIGINT;
DECLARE @attributeidTransactionDateTH BIGINT;
DECLARE @attributeidTransactionDateUA BIGINT;
DECLARE @attributeidTransactionDateUI BIGINT;
DECLARE @attributeidItemCodeNO BIGINT;
DECLARE @attributeidItemCodeCL BIGINT;
DECLARE @attributeidItemCodeMX BIGINT;
DECLARE @attributeidItemCodeTH BIGINT;
DECLARE @attributeidItemCodeUI BIGINT;
DECLARE @attributeidUpcCL BIGINT;
DECLARE @attributeidTillNumberUA BIGINT;
DECLARE @attributeidTillNumberUI BIGINT;
DECLARE @attributeidTillTxnNumberUA BIGINT;
DECLARE @attributeidTillTxnNumberUI BIGINT;
DECLARE @attributeidStoreNumberNO BIGINT;
DECLARE @attributeidStoreNumberCL BIGINT;
DECLARE @attributeidStoreNumberMX BIGINT;
DECLARE @attributeidStoreNumberTH BIGINT;
DECLARE @attributeidStoreNumberUA BIGINT;
DECLARE @attributeidStoreNumberUI BIGINT;
DECLARE @attributeidUnitsNO BIGINT;
DECLARE @attributeidUnitsCL BIGINT;
DECLARE @attributeidUnitsMX BIGINT;
DECLARE @attributeidUnitsTH BIGINT;
DECLARE @attributeidTispNO BIGINT;
DECLARE @attributeidTispCL BIGINT;
DECLARE @attributeidTispMX BIGINT;
DECLARE @attributeidTispTH BIGINT;
DECLARE @attributeidTespNO BIGINT;
DECLARE @attributeidTespCL BIGINT;
DECLARE @attributeidTespMX BIGINT;
DECLARE @attributeidTespTH BIGINT;

BEGIN
SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

SET @entityidNO = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname = 'Norway_crp_item_transaction_Incremental_Load_txt');
SET @entityidCL = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname = 'Chile_crp_item_transaction_Incremental_Load_txt');
SET @entityidMX = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname = 'Mexico_crp_item_transaction_Incremental_Load_txt');
SET @entityidTH = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname = 'Thailand_crp_item_transaction_Incremental_Load_txt');
SET @entityidUA = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname = 'IF_01111_HEADER_Incremental_Load_txt');
SET @entityidUI = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname = 'IF_01473_ITEM_Incremental_Load_txt');

SET @entityidpsaNO = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'no_crp_item_transaction');
SET @entityidpsaCL = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'cl_crp_item_transaction');
SET @entityidpsaMX = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'mx_crp_item_transaction');
SET @entityidpsaTH = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'th_crp_item_transaction');
SET @entityidpsaUA = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'uk_abacus_header');
SET @entityidpsaUI = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'uk_abacus_item');

DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityidpsaNO,@entityidpsaCL,@entityidpsaMX,@entityidpsaTH,@entityidpsaUA,@entityidpsaUI);

SET @attributeidTransactionDateNO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'transaction_date' AND entityid = @entityidNO);
SET @attributeidTransactionDateCL = (SELECT attributeid FROM psa.attribute WHERE attributename = 'transaction_date' AND entityid = @entityidCL);
SET @attributeidTransactionDateMX = (SELECT attributeid FROM psa.attribute WHERE attributename = 'transaction_date' AND entityid = @entityidMX);
SET @attributeidTransactionDateTH = (SELECT attributeid FROM psa.attribute WHERE attributename = 'transaction_date' AND entityid = @entityidTH);
SET @attributeidTransactionDateUA = (SELECT attributeid FROM psa.attribute WHERE attributename = 'till_txn_date' AND entityid = @entityidUA);
SET @attributeidTransactionDateUI = (SELECT attributeid FROM psa.attribute WHERE attributename = 'till_txn_date' AND entityid = @entityidUI);

SET @attributeidItemCodeNO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'item_code' AND entityid = @entityidNO);
SET @attributeidItemCodeCL = (SELECT attributeid FROM psa.attribute WHERE attributename = 'item_code' AND entityid = @entityidCL);
SET @attributeidItemCodeMX = (SELECT attributeid FROM psa.attribute WHERE attributename = 'item_code' AND entityid = @entityidMX);
SET @attributeidItemCodeTH = (SELECT attributeid FROM psa.attribute WHERE attributename = 'item_code' AND entityid = @entityidTH);
SET @attributeidItemCodeUI = (SELECT attributeid FROM psa.attribute WHERE attributename = 'item_code' AND entityid = @entityidUI);

SET @attributeidUpcCL = (SELECT attributeid FROM psa.attribute WHERE attributename = 'upc' AND entityid = @entityidCL);

SET @attributeidTillNumberUA = (SELECT attributeid FROM psa.attribute WHERE attributename = 'till_number' AND entityid = @entityidUA);
SET @attributeidTillNumberUI = (SELECT attributeid FROM psa.attribute WHERE attributename = 'till_number' AND entityid = @entityidUI);
SET @attributeidTillTxnNumberUA = (SELECT attributeid FROM psa.attribute WHERE attributename = 'till_txn_number' AND entityid = @entityidUA);
SET @attributeidTillTxnNumberUI = (SELECT attributeid FROM psa.attribute WHERE attributename = 'till_txn_number' AND entityid = @entityidUI);

SET @attributeidStoreNumberNO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'store_number' AND entityid = @entityidNO);
SET @attributeidStoreNumberCL = (SELECT attributeid FROM psa.attribute WHERE attributename = 'store_number' AND entityid = @entityidCL);
SET @attributeidStoreNumberMX = (SELECT attributeid FROM psa.attribute WHERE attributename = 'store_number' AND entityid = @entityidMX);
SET @attributeidStoreNumberTH = (SELECT attributeid FROM psa.attribute WHERE attributename = 'store_number' AND entityid = @entityidTH);
SET @attributeidStoreNumberUA = (SELECT attributeid FROM psa.attribute WHERE attributename = 'store_number' AND entityid = @entityidUA);
SET @attributeidStoreNumberUI = (SELECT attributeid FROM psa.attribute WHERE attributename = 'store_number' AND entityid = @entityidUI);

SET @attributeidUnitsNO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'units' AND entityid = @entityidNO);
SET @attributeidUnitsCL = (SELECT attributeid FROM psa.attribute WHERE attributename = 'units' AND entityid = @entityidCL);
SET @attributeidUnitsMX = (SELECT attributeid FROM psa.attribute WHERE attributename = 'units' AND entityid = @entityidMX);
SET @attributeidUnitsTH = (SELECT attributeid FROM psa.attribute WHERE attributename = 'units' AND entityid = @entityidTH);

SET @attributeidTispNO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'tisp' AND entityid = @entityidNO);
SET @attributeidTispCL = (SELECT attributeid FROM psa.attribute WHERE attributename = 'tisp' AND entityid = @entityidCL);
SET @attributeidTispMX = (SELECT attributeid FROM psa.attribute WHERE attributename = 'tisp' AND entityid = @entityidMX);
SET @attributeidTispTH = (SELECT attributeid FROM psa.attribute WHERE attributename = 'tisp' AND entityid = @entityidTH);

SET @attributeidTespNO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'tesp' AND entityid = @entityidNO);
SET @attributeidTespCL = (SELECT attributeid FROM psa.attribute WHERE attributename = 'tesp' AND entityid = @entityidCL);
SET @attributeidTespMX = (SELECT attributeid FROM psa.attribute WHERE attributename = 'tesp' AND entityid = @entityidMX);
SET @attributeidTespTH = (SELECT attributeid FROM psa.attribute WHERE attributename = 'tesp' AND entityid = @entityidTH);

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityidpsaNO,@attributeidTransactionDateNO,28004,'28001','{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityidpsaCL,@attributeidTransactionDateCL,28004,'28001','{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityidpsaMX,@attributeidTransactionDateMX,28004,'28001','{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityidpsaTH,@attributeidTransactionDateTH,28004,'28001','{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityidpsaUA,@attributeidTransactionDateUA,28004,'28001','{"DateFormatSQLServer":"103"}',1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityidpsaUI,@attributeidTransactionDateUI,28004,'28001','{"DateFormatSQLServer":"103"}',1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaNO,@attributeidItemCodeNO,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCL,@attributeidItemCodeCL,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaMX,@attributeidItemCodeMX,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaTH,@attributeidItemCodeTH,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaUI,@attributeidItemCodeUI,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCL,@attributeidUpcCL,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaNO,@attributeidTransactionDateNO,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCL,@attributeidTransactionDateCL,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaMX,@attributeidTransactionDateMX,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaTH,@attributeidTransactionDateTH,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaUA,@attributeidTransactionDateUA,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaUI,@attributeidTransactionDateUI,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaUA,@attributeidTillNumberUA,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaUI,@attributeidTillNumberUI,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaUA,@attributeidTillTxnNumberUA,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaUI,@attributeidTillTxnNumberUI,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaNO,@attributeidStoreNumberNO,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCL,@attributeidStoreNumberCL,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaMX,@attributeidStoreNumberMX,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaTH,@attributeidStoreNumberTH,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaUA,@attributeidStoreNumberUA,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaUI,@attributeidStoreNumberUI,28004,'28001',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaNO,@attributeidUnitsNO,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCL,@attributeidUnitsCL,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaMX,@attributeidUnitsMX,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaTH,@attributeidUnitsTH,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaNO,@attributeidTispNO,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCL,@attributeidTispCL,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaMX,@attributeidTispMX,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaTH,@attributeidTispTH,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaNO,@attributeidTespNO,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaCL,@attributeidTespCL,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaMX,@attributeidTespMX,28004,'28002',NULL,1,@cur_date,@cur_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityidpsaTH,@attributeidTespTH,28004,'28002',NULL,1,@cur_date,@cur_user);

UPDATE psa.attribute SET attributeType=40003 WHERE entityID in (@entityidNO,@entityidCL,@entityidMX,@entityidTH,@entityidUA,@entityidUI);

UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityidUA AND attributeName IN ('STORE_NUMBER','TILL_NUMBER','TILL_TXN_NUMBER','TILL_TXN_DATE','TILL_TXN_TIME') AND activeflag=1;
UPDATE psa.attribute SET attributeType=40003 WHERE entityID=@entityidUA AND attributeName NOT IN ('STORE_NUMBER','TILL_NUMBER','TILL_TXN_NUMBER','TILL_TXN_DATE','TILL_TXN_TIME') AND activeflag=1;


--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityidNO AND attributeName IN ('item_code','transaction_date','store_number','units','tisp','tesp') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40003 WHERE entityID=@entityidNO AND attributeName NOT IN ('item_code','transaction_date','store_number','units','tisp','tesp') AND activeflag=1;

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityidCL AND attributeName IN ('item_code','transaction_date','store_number','units','tisp','tesp','upc') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40003 WHERE entityID=@entityidCL AND attributeName NOT IN ('item_code','transaction_date','store_number','units','tisp','tesp','upc') AND activeflag=1;

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityidMX AND attributeName IN ('item_code','transaction_date','store_number','units','tisp','tesp') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40003 WHERE entityID=@entityidMX AND attributeName NOT IN ('item_code','transaction_date','store_number','units','tisp','tesp') AND activeflag=1;

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityidTH AND attributeName IN ('item_code','transaction_date','store_number','units','tisp','tesp') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40003 WHERE entityID=@entityidTH AND attributeName NOT IN ('item_code','transaction_date','store_number','units','tisp','tesp') AND activeflag=1;

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityidUA AND attributeName IN ('till_number','till_txn_date','store_number','till_txn_number') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40003 WHERE entityID=@entityidUA AND attributeName NOT IN ('till_number','till_txn_date','store_number','till_txn_number') AND activeflag=1;

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityidUI AND attributeName IN ('item_code','till_number','till_txn_date','store_number','till_txn_number') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40003 WHERE entityID=@entityidUI AND attributeName NOT IN ('item_code','till_number','till_txn_date','store_number','till_txn_number') AND activeflag=1;

PRINT 'Rule Entity for Transaction metadata Loaded Sucessfully'
END
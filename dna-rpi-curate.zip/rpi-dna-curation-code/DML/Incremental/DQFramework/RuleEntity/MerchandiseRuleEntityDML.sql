/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : BUKROI and International (CL,MX,NO and TH)
Domain  : Planogram 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
26-08-2020        Initial Configuration v1.0
02-09-2020        v1.1
15-09-2020        v1.2
22-09-2020        v1.3
23-09-2020		  v1.4
**************************************************************/

DECLARE 
		@EntityID BIGINT,
		@EntityIDPSA BIGINT,
		@RuleID BIGINT,		
		@BDC_RuleID BIGINT, --  Business Key Duplicate Check
		@NN_RuleID BIGINT,  --	Not Null Check
		@DC_RuleID BIGINT,  --	Date Check	
		@uk_planogram_dbkey_AttributeID BIGINT,
		@uk_planogram_value50_AttributeID BIGINT,  
		@date_AttributeID BIGINT,
		@cur_date datetime = CURRENT_TIMESTAMP,
		@cur_user varchar(50)= CURRENT_USER	,
		@uk_position_dbkey_AttributeID BIGINT,
		@uk_position_parentplanogramid_AttributeID BIGINT,  
		@uk_position_parentproductid_AttributeID BIGINT,
		@uk_position_parentfixtureid_AttributeID BIGINT,
		@FixtureEntityID BIGINT,
		@FixtureBDC_RuleID BIGINT, --  Business Key Duplicate Check
		@FixtureNN_RuleID BIGINT,  --	Not Null Check
		@Fixturedbkey_AttributeID BIGINT,
		@Fixturedbparentplanogramkey_AttributeID BIGINT,
		@cl_crp_merchandise_pogId_AttributeID BIGINT,
		@cl_crp_merchandise_dbKey_AttributeID BIGINT,  
        @cl_crp_merchandise_dateadded_AttributeID BIGINT,
		@cl_crp_planogram_dateadded_AttributeID BIGINT,
		@cl_crp_layout_performance_dateadded_AttributeID BIGINT,
		@mx_crp_merchandise_pogId_AttributeID BIGINT,
        @mx_crp_merchandise_dateadded_AttributeID BIGINT,
		@mx_crp_planogram_dateadded_AttributeID BIGINT,
		@mx_crp_layout_performance_dateadded_AttributeID BIGINT,
		@no_crp_merchandise_pogId_AttributeID BIGINT,
		@no_crp_merchandise_dbKey_AttributeID BIGINT,  
        @no_crp_merchandise_dateadded_AttributeID BIGINT,
		@no_crp_planogram_dateadded_AttributeID BIGINT,
		@no_crp_layout_performance_dateadded_AttributeID BIGINT,
		@th_crp_merchandise_pogId_AttributeID BIGINT,
		@th_crp_merchandise_dbKey_AttributeID BIGINT,  
        @th_crp_merchandise_dateadded_AttributeID BIGINT,
		@th_crp_planogram_dateadded_AttributeID BIGINT,
		@th_crp_layout_performance_dateadded_AttributeID BIGINT;
		
BEGIN
		SET @BDC_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='BDC' AND activeFlag='1')
		SET @NN_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='NN' AND activeFlag='1')
		SET @DC_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='DC' AND activeFlag='1')
		--Intactix  Planogram metadata configuration
		BEGIN
				SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'btc_ix_spc_planogram_Incremental_Load_txt')
				SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'uk_btc_ix_spc_planogram' and SchemaName='psa')
				SET @uk_planogram_dbkey_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='dbkey')
				SET @uk_planogram_value50_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='value50')
				--Delete from RuleEntity for intactix 
				   DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
				-- Configuration : Not null Check for dbkey
				INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
				VALUES(@NN_RuleID,@EntityIDPSA,@uk_planogram_dbkey_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
				INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
				VALUES(@NN_RuleID,@EntityIDPSA,@uk_planogram_value50_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user); 
				--UPDATE attribute table 
				UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='dbkey' AND activeflag=1;
				UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='value50' AND activeflag=1;
				UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName not in ('dbkey','value50') AND activeflag=1;
			 --	Configuration :  Date Check-DBDateEffectiveFrom
				SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='DBDateEffectiveFrom') ; 
				-- date format is  yyyy-mm-dd hh:mi:ss.mmm 
				INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
				 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"21"}',1,@cur_date,@cur_user); 
			 --	Configuration :  Date Check-DBDateEffectiveTo
				SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='DBDateEffectiveto') ; 
				INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
				 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"21"}',1,@cur_date,@cur_user); 	
			--	Configuration :  Date Check-Livedate
				SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='livedate') ; 
				INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
				 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"21"}',1,@cur_date,@cur_user); 
			 -- Configuration :  Business Key Duplicate Check
					INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
					VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);
					PRINT 'Rule Entity for Planogram metadata Loaded Sucessfully'
		END
		--Intactix  position metadata configuration
		BEGIN
			SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'btc_ix_spc_position_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'uk_btc_ix_spc_position' and SchemaName='psa')
			SET @uk_position_dbkey_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='dbkey')
			SET @uk_position_parentplanogramid_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='dbparentplanogramkey')
			SET @uk_position_parentproductid_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='dbparentproductkey')
			SET @uk_position_parentfixtureid_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='dbparentfixturekey')

			DELETE FROM  [psa].[RuleEntity] WHERE EntityID = @EntityIDPSA
			-- Configuration : Not null Check for dbkey,dbparentplanogramkey,dbparentproductkey,dbparentfixturekey
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@uk_position_dbkey_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@uk_position_parentplanogramid_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@uk_position_parentproductid_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			 INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@uk_position_parentfixtureid_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
 
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='dbkey' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName!='dbkey' AND activeflag=1;

			 -- Configuration :  Business Key Duplicate Check
 
			 INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);
			 PRINT 'Rule Entity for Position metadata Loaded Sucessfully'
	 END
	 
		 BEGIN
		 --Intactix  Fixture metadata configuration
			SET @FixtureEntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'btc_ix_spc_fixture_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'uk_btc_ix_spc_fixture' and SchemaName='psa')
			SET @FixtureBDC_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='BDC' AND activeFlag='1')
			SET @FixtureNN_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='NN' AND activeFlag='1')

			SET @Fixturedbkey_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE EntityID=@FixtureEntityID AND AttributeName='dbkey')
			SET @Fixturedbparentplanogramkey_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE EntityID=@FixtureEntityID AND AttributeName='dbparentplanogramkey')

			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;

			-- Configuration : Not null Check for dbkey and dbparentplanogramkey
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@FixtureNN_RuleID,@EntityIDPSA,@Fixturedbkey_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@FixtureNN_RuleID,@EntityIDPSA,@Fixturedbparentplanogramkey_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
 
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE EntityID=@FixtureEntityID AND attributeName ='dbkey' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE EntityID=@FixtureEntityID AND attributeName!='dbkey' AND activeflag=1;

			 -- Configuration :  Business Key Duplicate Check
 
			 INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@FixtureBDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);
			 PRINT 'Rule Entity for Fixture metadata Loaded Sucessfully'
		END



    -- International
	
	-- Chile Merchandise metadata configuration
	
        BEGIN
		
        SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Chile_crp_merchandise_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='cl_crp_merchandise'  AND SchemaName='psa') 
        
        SET @cl_crp_merchandise_pogId_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='pog_id')
        SET @cl_crp_merchandise_dbKey_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='db_key')
		SET @cl_crp_merchandise_dateadded_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
        --Delete from RuleEntity for cl_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
				   
				   
				   
        -- Configuration : Not null Check for pog_id,db_key and date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@cl_crp_merchandise_pogId_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@cl_crp_merchandise_dbKey_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
        
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@cl_crp_merchandise_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
         
         --UPDATE attribute table 
        UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='pog_id' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='db_key' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='planogram_start_date' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='planogram_end_date' AND activeflag=1;
        UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName not in ('pog_id','db_key','date_added','planogram_start_date','planogram_end_date') AND activeflag=1;
        
                
         --	Configuration :  Date Check for date_added,planogram_start_date and planogram_end_date
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
        
        -- planogram_start_date
		 SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='planogram_start_date') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		-- planogram_end_date 
		 SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='planogram_end_date') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		 
		PRINT 'Rule Entity for Chile Merchandise metadata Loaded Successfully'
        
        END		

		
		
		BEGIN 
		
		-- Chile Planogram metadata configuration
		
		SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Chile_crp_planogram_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='cl_crp_planogram'  AND SchemaName='psa') 
        
		SET @cl_crp_planogram_dateadded_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
		 --Delete from RuleEntity for cl_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
		
		-- Configuration : Not null Check for date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@cl_crp_planogram_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		 
		--	Configuration :  Date Check 
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		  PRINT 'Rule Entity for Chile Planogram metadata Loaded Successfully'
		
		END
 
		
		BEGIN 
		
		-- Chile Layout Performance metadata configuration
		
		SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Chile_crp_layout_performance_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='cl_crp_layout_performance'  AND SchemaName='psa') 
        
		SET @cl_crp_layout_performance_dateadded_AttributeID =(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
		 --Delete from RuleEntity for cl_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
		
		-- Configuration : Not null Check for date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@cl_crp_layout_performance_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		 
		--	Configuration :  Date Check 
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		  PRINT 'Rule Entity for Chile Layout Performance metadata Loaded Successfully'
		
		END
		
		-- Mexico Merchandise metadata configuration
	
        BEGIN
		
        SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Mexico_crp_merchandise_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='mx_crp_merchandise'  AND SchemaName='psa') 
        
        SET @mx_crp_merchandise_pogId_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='pog_id')
		SET @mx_crp_merchandise_dateadded_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
      		
        --Delete from RuleEntity for mx_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
				   
				   
				   
        -- Configuration : Not null Check for pog_id and date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@mx_crp_merchandise_pogId_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
	     
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@mx_crp_merchandise_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
         
		 
         --UPDATE attribute table 
        UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='pog_id' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
        UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName not in ('pog_id','date_added') AND activeflag=1;
        
                
         --	Configuration :  Date Check for date_added,planogram_start_date and planogram_end_date
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
        
        -- planogram_start_date
		 SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='planogram_start_date') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		-- planogram_end_date 
		 SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='planogram_end_date') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		 
		 PRINT 'Rule Entity for Mexico Merchandise metadata Loaded Successfully'
        
        END		

		
		
		BEGIN 
		
		-- Mexico Planogram metadata configuration
		
		SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Mexico_crp_planogram_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='mx_crp_planogram'  AND SchemaName='psa') 
        
		SET @mx_crp_planogram_dateadded_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
		 --Delete from RuleEntity for mx_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
		
		-- Configuration : Not null Check for date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@mx_crp_planogram_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		 
		--	Configuration :  Date Check 
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		  PRINT 'Rule Entity for Mexico Planogram metadata Loaded Successfully'
		
		END
 
		
		BEGIN 
		
		-- Mexico Layout Performance metadata configuration
		
		SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Mexico_crp_layout_performance_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='mx_crp_layout_performance'  AND SchemaName='psa') 
        
		SET @mx_crp_layout_performance_dateadded_AttributeID =(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
		 --Delete from RuleEntity for mx_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
		
		-- Configuration : Not null Check for date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@mx_crp_layout_performance_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		 
		--	Configuration :  Date Check 
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		  PRINT 'Rule Entity for Mexico Layout Performance metadata Loaded Successfully'
		
		END
		
		
		
		-- Norway Merchandise metadata configuration
	
        BEGIN
		
        SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Norway_crp_merchandise_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='no_crp_merchandise'  AND SchemaName='psa') 
        
        SET @no_crp_merchandise_pogId_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='pog_id')
        SET @no_crp_merchandise_dbKey_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='db_key')
		SET @no_crp_merchandise_dateadded_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
        --Delete from RuleEntity for no_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
				   
				   
				   
        -- Configuration : Not null Check for pog_id,db_key and date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@no_crp_merchandise_pogId_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@no_crp_merchandise_dbKey_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
        
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@no_crp_merchandise_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
         
         --UPDATE attribute table 
        UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='pog_id' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='db_key' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
        UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName not in ('pog_id','db_key','date_added') AND activeflag=1;
        
                
         --	Configuration :  Date Check for date_added,planogram_start_date and planogram_end_date
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
        
        -- planogram_start_date
		 SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='planogram_start_date') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		-- planogram_end_date 
		 SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='planogram_end_date') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		 
		 PRINT 'Rule Entity for Norway Merchandise metadata Loaded Successfully'
        
        END		

		
		
		BEGIN 
		
		-- Norway Planogram metadata configuration
		
		SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Norway_crp_planogram_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='no_crp_planogram'  AND SchemaName='psa') 
        
		SET @no_crp_planogram_dateadded_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
		 --Delete from RuleEntity for no_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
		
		-- Configuration : Not null Check for date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@no_crp_planogram_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		 
		--	Configuration :  Date Check 
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		  PRINT 'Rule Entity for Norway Planogram metadata Loaded Successfully'
		
		END
 
		
		BEGIN 
		
		-- Norway Layout Performance metadata configuration
		
		SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Norway_crp_layout_performance_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='no_crp_layout_performance'  AND SchemaName='psa') 
        
		SET @no_crp_layout_performance_dateadded_AttributeID =(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
		 --Delete from RuleEntity for no_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
		
		-- Configuration : Not null Check for date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@no_crp_layout_performance_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		 
		--	Configuration :  Date Check 
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		  PRINT 'Rule Entity for Norway Layout Performance metadata Loaded Successfully'
		
		END
		
		
		-- Thailand Merchandise metadata configuration
	
        BEGIN
		
        SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Thailand_crp_merchandise_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='th_crp_merchandise'  AND SchemaName='psa') 
        
        SET @th_crp_merchandise_pogId_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='pog_id')
        SET @th_crp_merchandise_dbKey_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='db_key')
		SET @th_crp_merchandise_dateadded_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
        --Delete from RuleEntity for th_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
				   
				   
				   
        -- Configuration : Not null Check for pog_id,db_key and date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@th_crp_merchandise_pogId_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@th_crp_merchandise_dbKey_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
        
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@th_crp_merchandise_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
         
         --UPDATE attribute table 
        UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='pog_id' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='db_key' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='planogram_start_date' AND activeflag=1;
		UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='planogram_end_date' AND activeflag=1;
        UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName not in ('pog_id','db_key','date_added','planogram_start_date','planogram_end_date') AND activeflag=1;
        
                
         --	Configuration :  Date Check for date_added,planogram_start_date and planogram_end_date
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
        
        -- planogram_start_date
		 SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='planogram_start_date') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"23"}',1,@cur_date,@cur_user);
		  
		-- planogram_end_date 
		 SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='planogram_end_date') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"23"}',1,@cur_date,@cur_user);
		  
		 
		 PRINT 'Rule Entity for Thailand Merchandise metadata Loaded Successfully'
        
        END		

		
		
		BEGIN 
		
		-- Thailand Planogram metadata configuration
		
		SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Thailand_crp_planogram_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='th_crp_planogram'  AND SchemaName='psa') 
        
		SET @th_crp_planogram_dateadded_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
		 --Delete from RuleEntity for th_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
		
		-- Configuration : Not null Check for date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@th_crp_planogram_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		 
		--	Configuration :  Date Check 
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		  PRINT 'Rule Entity for Thailand Planogram metadata Loaded Successfully'
		
		END
 
		
		BEGIN 
		
		-- Thailand Layout Performance metadata configuration
		
		SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'Thailand_crp_layout_performance_Incremental_Load_txt') 
		
		SET @EntityIDPSA =(SELECT EntityID FROM psa.Entity WHERE  EntityCode  ='th_crp_layout_performance'  AND SchemaName='psa') 
        
		SET @th_crp_layout_performance_dateadded_AttributeID =(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
		
		 --Delete from RuleEntity for th_crp_merchandise
        DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA
		
		-- Configuration : Not null Check for date_added
        INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
         VALUES(@NN_RuleID,@EntityIDPSA,@th_crp_layout_performance_dateadded_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
		 
		 
		--	Configuration :  Date Check 
		 
		 -- date_added
          SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added') ; 
		  
		  INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
          VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
		  
		PRINT 'Rule Entity for Thailand Layout Performance metadata Loaded Successfully'
		
		END
		
END
GO
/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : SAP MDM Store ,International Store
Domain  : Store 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
28-08-2020        Initial Configuration
04-09-2020		  Changed delete based on EntityIDPSA

**************************************************************/

DECLARE 
		@EntityID BIGINT,
		@EntityIDPSA BIGINT,
		@RuleID BIGINT,		
		@BDC_RuleID BIGINT, --  Business Key Duplicate Check
		@NN_RuleID BIGINT,  --	Not Null Check
		@DC_RuleID BIGINT,  --	Date Check	
		@storeNumber_AttributeID BIGINT,
		@date_AttributeID BIGINT,
		@cur_date datetime = CURRENT_TIMESTAMP,
		@cur_user varchar(50)= CURRENT_USER	;	

BEGIN 
		
		SET @BDC_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='BDC' AND activeFlag='1')
		SET @NN_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='NN' AND activeFlag='1')
		SET @DC_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='DC' AND activeFlag='1')
		--MDM StoreDQ metadata configuration
		BEGIN 
			SET @EntityID =(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'IF_00122_SITE_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'uk_btc_mdm_store' and SchemaName='psa')
			SET @storeNumber_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='store_number')
			--Delete from RuleEntity for MDM Store
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			-- Configuration : Not null Check for store_number
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@storeNumber_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			 
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='store_number' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName!='store_number' AND activeflag=1;


		-- Configuration :  Business Key Duplicate Check
		INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
		VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);
		END	
        ----International CHILE ------	
		BEGIN					
			SET @EntityID=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'Chile_crp_store_Incremental_Load_txt' )
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'cl_crp_store' and SchemaName='psa')
			SET @storeNumber_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='store_number')
			SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
			--Delete from RuleEntity for CHILE 
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='store_number' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName NOT IN ('store_number','date_added') AND activeflag=1;

			-- Configuration : Not null Check for store_number
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@storeNumber_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Not null Check for date_added
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
					  
			 --	Configuration :  Date Check			
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
			
			
			 -- Configuration :  Business Key Duplicate Check
			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);
		END
			----International MEXICO ------	
		BEGIN	
			SET @EntityID=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'Mexico_crp_store_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'mx_crp_store' and SchemaName='psa')
			SET @storeNumber_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='store_number')
			SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
			--Delete from RuleEntity for MEXICO 
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='store_number' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName NOT IN ('store_number','date_added') AND activeflag=1;					
			
			-- Configuration : Not null Check for store_number
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@storeNumber_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Not null Check for date_added
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			--	Configuration :  Date Check		
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
			
			
			 -- Configuration :  Business Key Duplicate Check
			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);
		END
		----International THAILAND ------		
		BEGIN
		    SET @EntityID=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'Thailand_crp_store_Incremental_Load_txt')
		    SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'th_crp_store' and SchemaName='psa')
			SET @storeNumber_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='store_number')
			SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
			
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='store_number' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName NOT IN ('store_number','date_added') AND activeflag=1;					
			
			--Delete from RuleEntity for THAILAND 
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			
			-- Configuration : Not null Check for store_number
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@storeNumber_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Not null Check for date_added
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			--	Configuration :  Date Check			 
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);		
			
			 -- Configuration :  Business Key Duplicate Check
			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);
		END
		---International NORWAY ------	
		BEGIN					
			SET @EntityID=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'Norway_crp_store_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'no_crp_store' and SchemaName='psa')
			SET @storeNumber_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='store_number')
			SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
			
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='store_number' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName NOT IN ('store_number','date_added') AND activeflag=1;					
			
			--Delete from RuleEntity for NORWAY 
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			-- Configuration : Not null Check for store_number
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@storeNumber_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Not null Check for date_added
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			--	Configuration :  Date Check	
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);			
			
			 -- Configuration :  Business Key Duplicate Check			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);
		END 

END
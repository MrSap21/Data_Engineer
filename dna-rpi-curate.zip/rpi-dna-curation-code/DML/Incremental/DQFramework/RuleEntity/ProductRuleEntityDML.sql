/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : SAP MDM Product ,International Product,Intactix Product
Domain  : Product 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
28-08-2020        Initial Configuration
04-09-2020		  Added custom Date and Time format in configuration for MDM Article
				  Changed delete based on EntityIDPSA
**************************************************************/

DECLARE 
		@EntityID BIGINT,
		@EntityIDPSA BIGINT,
		@BDC_RuleID BIGINT, --  Business Key Duplicate Check
		@NN_RuleID BIGINT,  --	Not Null Check
		@DC_RuleID BIGINT,  --	Date Check	
		@itemCode_AttributeID BIGINT,
		@brandCode_AttributeID BIGINT,  
		@itemDescription_AttributeID BIGINT,	
		@date_AttributeID BIGINT,
		@id_AttributeID BIGINT,
		@upc_AttributeID BIGINT,
		@cur_date datetime = CURRENT_TIMESTAMP,
		@cur_user varchar(50)= CURRENT_USER	;	

BEGIN 
		
		SET @BDC_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='BDC' AND activeFlag='1')
		SET @NN_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='NN' AND activeFlag='1')
		SET @DC_RuleID =(SELECT RuleID FROM [psa].[Rule] WHERE  RuleCode='DC' AND activeFlag='1')
		--Intactix  ProductDQ metadata configuration
		BEGIN
			SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'btc_ix_spc_product_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'uk_btc_ix_spc_product' and SchemaName='psa')
			SET @id_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='id')
			SET @itemDescription_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='name')
			SET @brandCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='brand')
			--Delete from RuleEntity for intactix 
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			-- Configuration : Not null Check for id			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@id_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
 
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='id' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName!='id' AND activeflag=1;

			 --	Configuration :  NULL Check Warning item_description AND brand
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemDescription_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@brandCode_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
 
 
			 -- Configuration :  Business Key Duplicate Check
 
			 INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user); 
			 
			 PRINT 'Rule Entity for Intactix Product Loaded Sucessfully'
		END
		--MDM ProductDQ IF_ARTICLE01 metadata configuration
		BEGIN 
			SET @EntityID =(SELECT EntityID FROM psa.Entity Where EntityName = 'IF_00123_ARTICLE_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'uk_btc_mdm_article' and SchemaName='psa')
			SET @itemCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_code')
			SET @itemDescription_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_description')
			SET @brandCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='brand_code')
			--Delete from RuleEntity for MDM Product
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			-- Configuration : Not null Check for item_code
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemCode_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			 
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='item_code' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName!='item_code' AND activeflag=1;

			 --	Configuration :  NULL Check Warning item_description AND brand_code
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemDescription_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@brandCode_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);		 
			 
			 --	Configuration :  Date Check			
			 SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='valid_from_date') ; 		
			  
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatCustom":"ddmmyyyy"}',1,@cur_date,@cur_user);
			 
			  SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='valid_from_time');
			  
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"TimeFormatCustom":"hhmiss"}',1,@cur_date,@cur_user);
			 
			  SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_deletion_date');
			  
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatCustom":"ddmmyyyy"}',1,@cur_date,@cur_user);
			 
			   SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_introduction_date');
			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatCustom":"ddmmyyyy"}',1,@cur_date,@cur_user);	 

			 -- Configuration :  Business Key Duplicate Check		 
			 INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);
			 
			 PRINT 'Rule Entity for MDM Article Loaded Sucessfully'

		END
		--MDM ProductDQ IF_DWTOFFER metadata configuration	
		BEGIN 
			SET @EntityID =(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'DWTOFFER_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'uk_mf_dwoffer' and SchemaName='psa')
			SET @itemCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_code')
			--Delete from RuleEntity for  IF_DWTOFFER
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			-- Configuration : Not null Check for item_code
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemCode_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			 
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='item_code' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName!='item_code' AND activeflag=1;
		
			 -- Configuration :  Business Key Duplicate Check		 
			 INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user); 
			 
			 PRINT 'Rule Entity for Mainframe DWTOFFER Loaded Sucessfully'
		END	
        ----International CHILE ------	
		BEGIN					
			SET @EntityID=(SELECT EntityID FROM psa.Entity Where EntityName = 'Chile_crp_product_Incremental_Load_txt' )
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'cl_crp_product' and SchemaName='psa')
			SET @itemCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_code')
			SET @upc_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='upc')
			SET @itemDescription_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_description')
			SET @brandCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='brand')
			SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
			--Delete from RuleEntity for CHILE 
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='item_code' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='upc' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName NOT IN ('item_code','upc','date_added') AND activeflag=1;

			-- Configuration : Not null Check for item_code
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemCode_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Not null Check for date_added
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			  -- Configuration : Null Check Waring for upc
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@upc_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Null Check Waring  for item_description
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemDescription_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Null Check Waring for brand
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@brandCode_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			  
			 --	Configuration :  Date Check			
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
			
			
			 -- Configuration :  Business Key Duplicate Check
			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);

			PRINT 'Rule Entity for Chile Product Loaded Sucessfully';
		END
			----International MEXICO ------	
		BEGIN	
			SET @EntityID=(SELECT EntityID FROM psa.Entity Where EntityName = 'Mexico_crp_product_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'mx_crp_product' and SchemaName='psa')
			SET @itemCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_code')
			SET @itemDescription_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_description')
			SET @brandCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='brand')
			SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
			--Delete from RuleEntity for MEXICO 
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='item_code' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName NOT IN ('item_code','date_added') AND activeflag=1;					
			
			-- Configuration : Not null Check for item_code
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemCode_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Not null Check for date_added
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Null Check Waring  for item_description
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemDescription_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Null Check Waring for brand
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@brandCode_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			  
			 --	Configuration :  Date Check		
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);
			
			
			 -- Configuration :  Business Key Duplicate Check
			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);

			 PRINT 'Rule Entity for MEXICO Product Loaded Sucessfully';
		END
		----International THAILAND ------		
		BEGIN
		    SET @EntityID=(SELECT EntityID FROM psa.Entity Where EntityName = 'Thailand_crp_product_Incremental_Load_txt')
		    SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'th_crp_product' and SchemaName='psa')
			SET @itemCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_code')
			SET @itemDescription_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_description')
			SET @brandCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='brand')
			SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
			
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='item_code' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName NOT IN ('item_code','date_added') AND activeflag=1;					
			
			--Delete from RuleEntity for THAILAND 
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			
			-- Configuration : Not null Check for item_code
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemCode_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Not null Check for date_added
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Null Check Waring  for item_description
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemDescription_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Null Check Waring for brand
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@brandCode_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			  
			 --	Configuration :  Date Check			 
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);		
			
			 -- Configuration :  Business Key Duplicate Check
			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);

			PRINT 'Rule Entity for THAILAND Product Loaded Sucessfully';
		END
		---International NORWAY ------	
		BEGIN					
			SET @EntityID=(SELECT EntityID FROM psa.Entity Where EntityName = 'Norway_crp_product_Incremental_Load_txt')
			SET @EntityIDPSA=(SELECT EntityID FROM psa.Entity WHERE  EntityName = 'no_crp_product' and SchemaName='psa')
			SET @itemCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_code')
			SET @itemDescription_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='item_description')
			SET @brandCode_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='brand')
			SET @date_AttributeID=(SELECT AttributeId FROM [psa].[Attribute] WHERE entityid=@EntityID AND AttributeName='date_added')
			
			 --UPDATE attribute table 
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='item_code' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40001 WHERE entityID=@EntityID AND attributeName ='date_added' AND activeflag=1;
			UPDATE [psa].[attribute]  SET attributeType=40003 WHERE entityID=@EntityID AND attributeName NOT IN ('item_code','date_added') AND activeflag=1;					
			
			--Delete from RuleEntity for NORWAY 
			DELETE [psa].[RuleEntity] WHERE EntityID=@EntityIDPSA;
			-- Configuration : Not null Check for item_code
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemCode_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Not null Check for date_added
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Null Check Waring  for item_description
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@itemDescription_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			
			 -- Configuration : Null Check Waring for brand
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@NN_RuleID,@EntityIDPSA,@brandCode_AttributeID,28004,28002,NULL,1,@cur_date,@cur_user);
			  
			 --	Configuration :  Date Check	
			
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@DC_RuleID,@EntityIDPSA,@date_AttributeID,28004,28001,'{"DateFormatSQLServer":"112"}',1,@cur_date,@cur_user);			
			
			 -- Configuration :  Business Key Duplicate Check			 
			INSERT INTO [psa].[RuleEntity]([RuleID],[EntityID],[AttributeID],[SuccessActionId],[FailureActionId],[ConvertStyle],[ActiveFlag],[DTCreated],[UserCreated])
			 VALUES(@BDC_RuleID,@EntityIDPSA,99999,28004,28001,NULL,1,@cur_date,@cur_user);

			PRINT 'Rule Entity for NORWAY Product Loaded Sucessfully';
		END 

END
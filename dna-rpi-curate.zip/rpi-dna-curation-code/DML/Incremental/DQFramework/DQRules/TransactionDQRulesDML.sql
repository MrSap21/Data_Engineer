/* ***********************************************************
Purpose	: RuleRefLookup Meta data Configuration for MissingLookupkeys
Source  : BUKROI/International
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration ***********************
09-09-2020        Configuration Changes on the metadata table  */

--Delete the existing data from psa.rulereflookup for transaction tables
DELETE FROM [psa].[RuleRefLookup] WHERE TableName IN ('th_crp_item_transaction','mx_crp_item_transaction','no_crp_item_transaction','cl_crp_item_transaction','uk_abacus_header','uk_abacus_item');
GO
--Transaction Incremental MissingLookup check metadata configuration
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','th_crp_item_transaction','customer_identifier_type','customer_identifier_type',NULL,'12010','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','mx_crp_item_transaction','customer_identifier_type','customer_identifier_type',NULL,'12004','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','cl_crp_item_transaction','customer_identifier_type','customer_identifier_type',NULL,'12001','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','no_crp_item_transaction','customer_identifier_type','customer_identifier_type',NULL,'12005','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','th_crp_item_transaction','customer_number_type','customer_number_type',NULL,'12010','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','mx_crp_item_transaction','customer_number_type','customer_number_type',NULL,'12004','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','cl_crp_item_transaction','customer_number_type','customer_number_type',NULL,'12001','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','no_crp_item_transaction','customer_number_type','customer_number_type',NULL,'12005','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','th_crp_item_transaction','other_customer_id_type','other_customer_id_type',NULL,'12010','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','mx_crp_item_transaction','other_customer_id_type','other_customer_id_type',NULL,'12004','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','cl_crp_item_transaction','other_customer_id_type','other_customer_id_type',NULL,'12001','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','no_crp_item_transaction','other_customer_id_type','other_customer_id_type',NULL,'12005','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','th_crp_item_transaction','sales_type','sales_type',NULL,'12010','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','mx_crp_item_transaction','sales_type','sales_type',NULL,'12004','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','cl_crp_item_transaction','sales_type','sales_type',NULL,'12001','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','no_crp_item_transaction','sales_type','sales_type',NULL,'12005','Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','uk_abacus_header','epos_txn_type_flag','till_transaction_type_code',NULL,'12006','Y',null);
GO
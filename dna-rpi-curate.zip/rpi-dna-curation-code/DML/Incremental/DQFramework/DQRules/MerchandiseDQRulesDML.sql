/* ***********************************************************
Purpose	: RuleRefLookup Meta data Configuration for MissingLookupkeys
Source  : BUKROI and International (CL,MX,NO and TH)
Domain  : Merchandise 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
28-08-2020        Initial Configuration ***********************
03-09-2020        Configuration Changes on the metadata table 
15-09-2020        Inclusion of International Tables */

--Delete the existing data for uk_btc_ix_spc_planogram table
DELETE FROM PSA.RuleRefLookup WHERE TableName='uk_btc_ix_spc_planogram';
GO
--Intactix planogram Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES (  'MissingLookupKeys','uk_btc_ix_spc_planogram','Desc1' ,NULL ,'footprint',NULL, 12002,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES (  'MissingLookupKeys','uk_btc_ix_spc_planogram','Desc5' ,NULL ,'fitting_type',NULL, 12002,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES (  'MissingLookupKeys','uk_btc_ix_spc_planogram','Desc2' ,NULL ,'planner_family',NULL, 12002,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES (  'MissingLookupKeys','uk_btc_ix_spc_planogram','Desc3' ,NULL ,'format',NULL, 12002,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES (  'MissingLookupKeys','uk_btc_ix_spc_planogram','Category' ,NULL ,'category',NULL, 12002,'Y');
GO


-- International

--Delete the existing data for cl_crp_merchandise table
DELETE FROM PSA.RuleRefLookup WHERE TableName='cl_crp_merchandise';
GO

--International Chile  planogram Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','cl_crp_merchandise','footprint' ,NULL ,'footprint',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','cl_crp_merchandise','fitting_type' ,NULL ,'fitting_type',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','cl_crp_merchandise','planner_family' ,NULL ,'planner_family',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','cl_crp_merchandise','format' ,NULL ,'format',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','cl_crp_merchandise','category' ,NULL ,'category',NULL, 12001,'Y');
GO



--Delete the existing data for mx_crp_merchandise table
DELETE FROM PSA.RuleRefLookup WHERE TableName='mx_crp_merchandise';
GO

--International Chile  planogram Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','mx_crp_merchandise','footprint' ,NULL ,'footprint',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','mx_crp_merchandise','fitting_type' ,NULL ,'fitting_type',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','mx_crp_merchandise','planner_family' ,NULL ,'planner_family',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','mx_crp_merchandise','format' ,NULL ,'format',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','mx_crp_merchandise','category' ,NULL ,'category',NULL, 12004,'Y');
GO



--Delete the existing data for no_crp_merchandise table
DELETE FROM PSA.RuleRefLookup WHERE TableName='no_crp_merchandise';
GO

--International Norway  planogram Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag)
VALUES 
( 
	'MissingLookupKeys','no_crp_merchandise','footprint' ,NULL ,'footprint',NULL, 12005,'Y'
);

INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) 
VALUES 
( 
	'MissingLookupKeys','no_crp_merchandise','fitting_type' ,NULL ,'fitting_type',NULL, 12005,'Y'
);

INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag)
VALUES 
(
	'MissingLookupKeys','no_crp_merchandise','planner_family' ,NULL ,'planner_family',NULL, 12005,'Y'
);

INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag)
VALUES 
(
	'MissingLookupKeys','no_crp_merchandise','format' ,NULL ,'format',NULL, 12005,'Y'
);

INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) 
VALUES 
( 
	'MissingLookupKeys','no_crp_merchandise','category' ,NULL ,'category',NULL, 12005,'Y'
);
GO



--Delete the existing data for th_crp_merchandise table
DELETE FROM PSA.RuleRefLookup WHERE TableName='th_crp_merchandise';
GO

--International Thailand  planogram Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','th_crp_merchandise','footprint' ,NULL ,'footprint',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','th_crp_merchandise','fitting_type' ,NULL ,'fitting_type',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','th_crp_merchandise','planner_family' ,NULL ,'planner_family',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','th_crp_merchandise','format' ,NULL ,'format',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','th_crp_merchandise','category' ,NULL ,'category',NULL, 12010,'Y');
GO
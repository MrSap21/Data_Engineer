/* ***********************************************************
Purpose	: RuleRefLookup Meta data Configuration for MissingLookupkeys
Source  : SAP MDM.International 
Domain  : Store 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
28-08-2020        Initial Configuration 
03-09-2020        Configuration Changes on the metadata table  
***********************/

--Delete the existing data for uk_btc_mdm_store table
DELETE FROM PSA.RuleRefLookup WHERE TableName='uk_btc_mdm_store';
GO
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','distribution_channel' ,NULL ,'distribution_channel',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','trading_format' ,NULL ,'trading_format',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','type_of_store_description' ,NULL ,'type_of_store_description',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','sag' ,NULL ,'sag',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','mini_sag' ,NULL ,'mini_sag',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','price_band_code' ,NULL ,'price_band_code',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','non_lfl_reason_code' ,NULL ,'non_lfl_reason_code',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','store_open_status' ,NULL ,'store_open_status',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','pharmacy_registration_status' ,NULL ,'pharmacy_registration_status',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','nhs_market' ,NULL ,'nhs_market',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','benchmark_group' ,NULL ,'benchmark_group',NULL, 12008,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES	( 'MissingLookupKeys','uk_btc_mdm_store','area_number' ,NULL ,'area_number',NULL, 12008,'Y');
GO
--Delete the existing data for cl_crp_store table
DELETE FROM PSA.RuleRefLookup WHERE TableName='cl_crp_store';
GO

--International chile  Store Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_store','area_code' ,NULL ,'area_code',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_store','district_code' ,NULL ,'district_code',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_store','region_code' ,NULL ,'region_code',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_store','store_format' ,NULL ,'store_format',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_store','store_loc' ,NULL ,'store_loc',NULL, 12001,'Y');
--Delete the existing data for th_crp_store table
DELETE FROM PSA.RuleRefLookup WHERE TableName='th_crp_store';
GO

--International Thailand  Store Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_store','area_code' ,NULL ,'area_code',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_store','district_code' ,NULL ,'district_code',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_store','region_code' ,NULL ,'region_code',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_store','store_format' ,NULL ,'store_format',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_store','store_loc' ,NULL ,'store_loc',NULL, 12010,'Y');
--Delete the existing data for no_crp_store table
DELETE FROM PSA.RuleRefLookup WHERE TableName='no_crp_store';
GO

--International Norway  Store Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_store','area_code' ,NULL ,'area_code',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_store','district_code' ,NULL ,'district_code',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_store','store_format' ,NULL ,'store_format',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_store','store_loc' ,NULL ,'store_loc',NULL, 12005,'Y');

--Delete the existing data for mx_crp_store table
DELETE FROM PSA.RuleRefLookup WHERE TableName='mx_crp_store';
GO

--International Mexico  Store Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_store','area_code' ,NULL ,'area_code',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_store','district_code' ,NULL ,'district_code',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_store','region_code' ,NULL ,'region_code',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_store','store_format' ,NULL ,'store_format',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName    ,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_store','store_loc' ,NULL ,'store_loc',NULL, 12004,'Y');
GO	
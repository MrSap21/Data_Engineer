DELETE FROM [psa].[RuleRefLookup] WHERE TableName IN ('UK_AW_MEMBERSHIP_CARD');

INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','UK_AW_MEMBERSHIP_CARD','card_type_code','card_type',NULL,12011,'Y',null);
INSERT INTO [psa].[RuleRefLookup] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[FnToApply]) VALUES ('MissingLookupKeys','UK_AW_MEMBERSHIP_CARD','status_code','card_status',NULL,12011,'Y',null);
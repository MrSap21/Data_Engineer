/* ***********************************************************
Purpose	: RuleRefLookup Meta data Configuration for MissingLookupkeys
Source  : SAP MDM.International Product,Intactix
Domain  : Product 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
28-08-2020        Initial Configuration
03-09-2020        Configuration Changes on the metadata table  
 ***********************/

--Delete the existing data for uk_btc_mdm_article table
DELETE FROM PSA.RuleRefLookup WHERE TableName='uk_btc_mdm_article';
GO
--MDM Product Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','brand_code' ,NULL ,'brand_code',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','sub_brand_code' ,NULL ,'sub_brand_code',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','item_hierarchy1_number' ,'Substring($Column, Patindex(''%[^0 ]%'', $Column + '' ''), Len($Column) )' ,'item_hierarchy1',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','item_hierarchy2_number' ,NULL ,'item_hierarchy2',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','item_hierarchy3_number' ,NULL ,'item_hierarchy3',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','item_hierarchy4_number' ,NULL ,'item_hierarchy4',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','item_hierarchy5_number' ,NULL ,'item_hierarchy5',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','item_hierarchy6_number' ,NULL ,'item_hierarchy6',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','merchandise_category_code' ,NULL ,'merchandise_category_code',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','occasion_code' ,NULL ,'occasion_code',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','item_type' ,NULL ,'item_type',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','ladder_id' ,NULL ,'ladder_id',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','sub_ladder_id' ,NULL ,'sub_ladder_id',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','bbe_attribute_code' ,NULL ,'bbe_attribute_code',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','advantage_promotions' ,NULL ,'advantage_promotions',NULL, 12008,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_btc_mdm_article','retail_status' ,NULL ,'retail_status_code',NULL, 12008,'Y');		
GO

DELETE FROM PSA.RuleRefLookup WHERE TableName='uk_mf_dwoffer';
GO
--International Mainframe Product Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_mf_dwoffer','merch_group_no' ,NULL ,'merchandise_group_number',NULL, 12003,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_mf_dwoffer','business_centre_no' ,NULL ,'business_centre_number',NULL, 12003,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_mf_dwoffer','concept_group_no' ,NULL ,'concept_group_number',NULL, 12003,'Y');		
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ( 'MissingLookupKeys','uk_mf_dwoffer','concept_seq_no' ,NULL ,'concept_seq_number',NULL, 12003,'Y');		
Go
--Delete the existing data for cl_crp_product table
DELETE FROM PSA.RuleRefLookup WHERE TableName='cl_crp_product';
GO

--International chile  Product Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','brand' ,NULL ,'brand',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy1' ,NULL ,'product_hierarchy1_name',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy2' ,NULL ,'product_hierarchy2_name',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy3' ,NULL ,'product_hierarchy3_name',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy4' ,NULL ,'product_hierarchy4_name',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy5' ,NULL ,'product_hierarchy5_name',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','item_status' ,NULL ,'item_status',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy1_code' ,NULL ,'product_hierarchy1_code',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy2_code' ,NULL ,'product_hierarchy2_code',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy3_code' ,NULL ,'product_hierarchy3_code',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy4_code' ,NULL ,'product_hierarchy4_code',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','product_hierarchy5_code' ,NULL ,'product_hierarchy5_code',NULL, 12001,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','cl_crp_product','subbrand' ,NULL ,'subbrand',NULL, 12001,'Y');

--Delete the existing data for no_crp_product table
DELETE FROM PSA.RuleRefLookup WHERE TableName='no_crp_product';
GO

--International Norway  Product Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','brand' ,NULL ,'brand',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy1' ,NULL ,'product_hierarchy1_name',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy2' ,NULL ,'product_hierarchy2_name',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy3' ,NULL ,'product_hierarchy3_name',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy4' ,NULL ,'product_hierarchy4_name',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy5' ,NULL ,'product_hierarchy5_name',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','item_status' ,NULL ,'item_status',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy1_code' ,NULL ,'product_hierarchy1_code',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy2_code' ,NULL ,'product_hierarchy2_code',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy3_code' ,NULL ,'product_hierarchy3_code',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy4_code' ,NULL ,'product_hierarchy4_code',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','product_hierarchy5_code' ,NULL ,'product_hierarchy5_code',NULL, 12005,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','no_crp_product','subbrand' ,NULL ,'subbrand',NULL, 12005,'Y');
GO
--Delete the existing data for mx_crp_product table
DELETE FROM PSA.RuleRefLookup WHERE TableName='mx_crp_product';
GO

--International Mexico Product Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','brand' ,NULL ,'brand',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy1' ,NULL ,'product_hierarchy1_name',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy2' ,NULL ,'product_hierarchy2_name',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy3' ,NULL ,'product_hierarchy3_name',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy4' ,NULL ,'product_hierarchy4_name',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy5' ,NULL ,'product_hierarchy5_name',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','item_status' ,NULL ,'item_status',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy1_code' ,NULL ,'product_hierarchy1_code',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy2_code' ,NULL ,'product_hierarchy2_code',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy3_code' ,NULL ,'product_hierarchy3_code',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy4_code' ,NULL ,'product_hierarchy4_code',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','product_hierarchy5_code' ,NULL ,'product_hierarchy5_code',NULL, 12004,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','mx_crp_product','subbrand' ,NULL ,'subbrand',NULL, 12004,'Y');
GO
--Delete the existing data for th_crp_product table
DELETE FROM PSA.RuleRefLookup WHERE TableName='th_crp_product';
GO

--International Thailand Product Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','brand' ,NULL ,'brand',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','product_hierarchy1' ,NULL ,'product_hierarchy1_name',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','product_hierarchy2' ,NULL ,'product_hierarchy2_name',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','product_hierarchy3' ,NULL ,'product_hierarchy3_name',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','product_hierarchy4' ,NULL ,'product_hierarchy4_name',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','item_status' ,NULL ,'item_status',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','product_hierarchy1_code' ,NULL ,'product_hierarchy1_code',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','product_hierarchy2_code' ,NULL ,'product_hierarchy2_code',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','product_hierarchy3_code' ,NULL ,'product_hierarchy3_code',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','product_hierarchy4_code' ,NULL ,'product_hierarchy4_code',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','th_crp_product','subbrand' ,NULL ,'subbrand',NULL, 12010,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','uk_btc_ix_spc_product','brand' ,NULL ,'brand',NULL, 12002,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','uk_btc_ix_spc_product','status' ,NULL ,'status',NULL, 12002,'Y');
GO
--Delete the existing data for uk_btc_ix_spc_product table
DELETE FROM PSA.RuleRefLookup WHERE TableName='uk_btc_ix_spc_product';
GO

--International Intactix Product Incremental MissingLookup check metadata configuration
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','uk_btc_ix_spc_product','brand' ,NULL ,'brand',NULL, 12002,'Y');
INSERT INTO PSA.RuleRefLookup( RuleType,TableName	,ColumnName,FnToApply,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES( 'MissingLookupKeys','uk_btc_ix_spc_product','status' ,NULL ,'status',NULL, 12002,'Y');
GO
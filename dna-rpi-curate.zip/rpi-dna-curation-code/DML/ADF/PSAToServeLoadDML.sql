INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Product','rawuk_btc_ix_spc_product','sp_rawuk_btc_ix_spc_product',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Product','rawcl_crp_product','sp_rawcl_crp_product',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Product','rawuk_btc_mdm_item','sp_rawuk_btc_mdm_item',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Product','rawno_crp_product','sp_rawint_crp_product',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Product','rawmx_crp_product','sp_rawint_crp_product',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Product','rawth_crp_product','sp_rawint_crp_product',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Store','rawuk_btc_mdm_store','sp_btc_mdm_store',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Store','rawcl_crp_store','sp_rawint_crp_store',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Store','rawth_crp_store','sp_rawint_crp_store',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Store','rawmx_crp_store','sp_rawint_crp_store',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Store','rawno_crp_store','sp_rawint_crp_store',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES('Merchandise','rawuk_base_plan_product','sp_rawuk_base_plan_product',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES('Merchandise','rawuk_base_store_plan','sp_rawuk_base_store_plan',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES('Merchandise','rawuk_btc_ix_spc_planogram','sp_rawuk_btc_ix_spc_planogram',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES('Merchandise','rawuk_btc_ix_spc_fixture','sp_rawuk_btc_ix_spc_fixture',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] VALUES ('Merchandise','rawuk_btc_ix_spc_position','sp_rawuk_btc_ix_spc_position',1,'N');

--Inserts for mappings for international merchandise stored procedures
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawmx_crp_layout_performance','sp_merchandising_crp_layout_performance_mexico_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawcl_crp_layout_performance','sp_merchandising_crp_layout_performance_chile_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawno_crp_layout_performance','sp_merchandising_crp_layout_performance_norway_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawth_crp_layout_performance','sp_merchandising_crp_layout_performance_thailand_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawmx_crp_merchandise','sp_merchandising_curation_crp_merchandising_mexico_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawcl_crp_merchandise','sp_merchandising_curation_crp_merchandising_chile_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawno_crp_merchandise','sp_merchandising_curation_crp_merchandising_norway_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawth_crp_merchandise','sp_merchandising_curation_crp_merchandising_thailand_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawmx_crp_planogram','sp_merchandising_curation_crp_planogram_mexico_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawcl_crp_planogram','sp_merchandising_curation_crp_planogram_chile_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawno_crp_planogram','sp_merchandising_curation_crp_planogram_norway_history',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Merchandise','rawth_crp_planogram','sp_merchandising_curation_crp_planogram_thailand_history',1,'N');

---Inserts for serve sp mapping for transaction module
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Transaction','rawcl_crp_item_transaction','execute_transaction_proc',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Transaction','rawno_crp_item_transaction','execute_transaction_proc',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Transaction','rawmx_crp_item_transaction','execute_transaction_proc',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Transaction','rawth_crp_item_transaction','execute_transaction_proc',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Transaction','rawuk_btc_transaction_line_card_p','execute_transaction_proc',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Transaction','rawuk_btc_transaction_line_anon_p','execute_transaction_proc',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Transaction','rawuk_btc_transaction_card_p','execute_transaction_proc',1,'N');
INSERT INTO [dbo].[serve_sp_mapping] ([Domain],[TableName],[SPName],[SPOrder],[SPStatus]) VALUES ('Transaction','sap_crm_ad_card','sp_SAPCRMAdcardSerLoad',1,'N');
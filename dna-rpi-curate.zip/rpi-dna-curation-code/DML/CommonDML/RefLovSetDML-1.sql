--reflovset
--International Store entry
INSERT [ser].[reflovset] ([LOVSetID], [LOVSetKey], [LOVSetName], [LOVSetDescription], [LOVSetSequence], [LOVSetRecordSourceID], [SCDActiveFlag], [DTCreated]) VALUES (197000, N'Unit of Measure Type', N'Unit of Measure Type
', N'Unit of Measure Type', 197, 12012, 1, N'2020-07-01 08:16:00' )
GO

--Mdm-store entry for benchmark_group column
-- 1 create benchmark set

INSERT [ser].[reflovset] ([LOVSetID], [LOVSetKey], [LOVSetName], [LOVSetDescription],[LOVSetSequence], [LOVSetRecordSourceID], [SCDActiveFlag], [DTCreated]) VALUES (198000,N'benchmark_group', N'benchmark_group', N'benchmark_group', 198, 12008, 1, N'2020-07-01 08:16:00');
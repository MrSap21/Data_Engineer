/* Modification History
-------------------------------------------
  Date :21-07-2020 Missing RefLOV Entries for BUKROI
  
 */
BEGIN TRANSACTION
Declare @DTCreated Datetime=getdate();
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (11005101,11000,'24:07:00          ','24:07:00          ','24:07:00          ',5101,1,12002,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (12005450,12000,'AU2 ','AU2 ','AU2 ',5450,1,12008,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (12005451,12000,'BI6 ','BI6 ','BI6 ',5451,1,12008,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (12005452,12000,'YKQ ','YKQ ','YKQ ',5452,1,12008,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (179008804,179000,'1ZS','1ZS','1ZS',8804,1,12008,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (179008805,179000,'20E','20E','20E',8805,1,12008,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (179008806,179000,'20F','20F','20F',8806,1,12008,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (179008807,179000,'20L','20L','20L',8807,1,12008,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (179008808,179000,'BEQ','BEQ','BEQ',8808,1,12008,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (179008809,179000,'BFK','BFK','BFK',8809,1,12008,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) VALUES (179008810,179000,'EFK','EFK','EFK',8810,1,12008,@DTCreated,'awilliams');

-- should insert 11 rows

COMMIT;
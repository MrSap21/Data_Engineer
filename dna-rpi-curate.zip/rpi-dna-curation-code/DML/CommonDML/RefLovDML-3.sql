/*Modification History
----------------------
28-07-2020 : Missing RefLOV values in Production
*/
BEGIN transaction
DECLARE @DTCreated Datetime=current_timestamp;
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) 
VALUES  (2000539,2000,'"SANTA ANA, PCO. "','"SANTA ANA, PCO. "','"SANTA ANA, PCO. "',539,1,12004,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) 
VALUES (2000540,2000,'"ABASOLO, GTO."','"ABASOLO, GTO."','"ABASOLO, GTO."',540,1,12004,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) 
VALUES (10002188,10000,'24/7','24/7','24/7',2188,1,12010,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) 
VALUES (11005102,11000,' Hollywood Lips',' Hollywood Lips',' Hollywood Lips',5102,1,12002,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) 
VALUES (124000261,124000,'074','074','074',261,1,12010,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) 
VALUES (155000207,155000,'43,700000000000003','43,700000000000003','43,700000000000003',207,1,12005,@DTCreated,'awilliams');
INSERT INTO [SER].[REFLOV] (LOVID,LOVSetID,LOVKey,LOVNAME,LOVDescription,LOVSequence,SCDActiveFlag,LOVRecordSourceId,DTCreated,UserCreated) 
VALUES (155000208,155000,'88,200000000000003','88,200000000000003','88,200000000000003',208,1,12005,@DTCreated,'awilliams') ;


-- only commit if 7 rows are inserted

commit;
/* Modification History
-----------------------------------------
 Date :21-07-2020  Fix for UAT work item: 23338
 */
Declare @DTCreated Datetime=CAST(N'2020-07-16T15:31:00' AS SmallDateTime)

INSERT [ser].[reflovset] ([LOVSetId], [LOVSetKey], [LOVSetName], [LOVSetDescription], [LOVSetSequence], [LOVSetRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12, N'System of Record', N'System of Record', N'System of Record', 1, N'12012', @DTCreated, NULL, NULL, NULL, N'1', NULL, NULL, NULL)
GO
/* Modification History
-----------------------------------------
 Date :21-07-2020  Fix for UAT work item: 23338
 */
Declare @DTCreated SmallDateTime=CAST(N'2020-07-16T15:31:00' AS SmallDateTime)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (107, 12, N'ADR7', N'ADR7', N'ADR7', 1, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (108, 12, N'Bamboo Rose', N'Bamboo Rose', N'Bamboo Rose', 2, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (109, 12, N'Bazaarvoice', N'Bazaarvoice', N'Bazaarvoice', 3, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (110, 12, N'BAZAARVOICEPORTAL', N'BAZAARVOICEPORTAL', N'BAZAARVOICEPORTAL', 4, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (111, 12, N'Boots Opticians SAP', N'Boots Opticians SAP', N'Boots Opticians SAP', 5, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (112, 12, N'BRUSAP01', N'BRUSAP01', N'BRUSAP01', 6, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (113, 12, N'Bubble', N'Bubble', N'Bubble', 7, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (114, 12, N'BUK Abacus', N'BUK Abacus', N'BUK Abacus', 8, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (117, 12, N'Check with Al', N'Check with Al', N'Check with Al', 9, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (118, 12, N'Columbus', N'Columbus', N'Columbus', 11, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (119, 12, N'Columbus PMS', N'Columbus PMS', N'Columbus PMS', 12, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (120, 12, N'Email', N'Email', N'Email', 14, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (121, 12, N'Excel', N'Excel', N'Excel', 15, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (122, 12, N'FAPOS', N'FAPOS', N'FAPOS', 16, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (123, 12, N'GB SAP', N'GB SAP', N'GB SAP', 17, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (124, 12, N'Mainframe', N'Mainframe', N'Mainframe', 17, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (125, 12, N'NHS Digital', N'NHS Digital', N'NHS Digital', 24, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (126, 12, N'Product Catalogue', N'Product Catalogue', N'Product Catalogue', 26, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (127, 12, N'Qlik', N'Qlik', N'Qlik', 27, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (128, 12, N'QNOMY', N'QNOMY', N'QNOMY', 28, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (129, 12, N'Sage', N'Sage', N'Sage', 29, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (130, 12, N'SalesForce', N'SalesForce', N'SalesForce', 30, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (131, 12, N'SALESFORCEPORTAL', N'SALESFORCEPORTAL', N'SALESFORCEPORTAL', 31, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (132, 12, N'SAP MDG', N'SAP MDG', N'SAP MDG', 35, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (133, 12, N'SharePoint', N'SharePoint', N'SharePoint', 38, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (134, 12, N'Target Web Portal', N'Target Web Portal', N'Target Web Portal', 39, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (135, 12, N'TBC', N'TBC', N'TBC', 40, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (136, 12, N'Teamcenter', N'Teamcenter', N'Teamcenter', 41, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (137, 12, N'Ulta Web Portal', N'Ulta Web Portal', N'Ulta Web Portal', 43, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (138, 12, N'Unknown', N'Unknown', N'Unknown', 44, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (139, 12, N'WAG EPOS', N'WAG EPOS', N'WAG EPOS', 45, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (140, 12, N'WAG SAP', N'WAG SAP', N'WAG SAP', 46, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (151, 12, N'HADOOP', N'HADOOP', N'HADOOP', 19, N'12012', @DTCreated, N'deploy<1.3.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12001, 12, N'CHILE_UNKNOWN', N'CHILE_UNKNOWN', N'CHILE_UNKNOWN', 10, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12002, 12, N'INTACTIX', N'INTACTIX', N'INTACTIX', 20, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12003, 12, N'MAINFRAME', N'MAINFRAME', N'MAINFRAME', 21, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12004, 12, N'MEXICO_UNKNOWN', N'MEXICO_UNKNOWN', N'MEXICO_UNKNOWN', 22, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12005, 12, N'NORWAY_UNKNOWN', N'NORWAY_UNKNOWN', N'NORWAY_UNKNOWN', 25, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12006, 12, N'SAPBW', N'SAPBW', N'SAPBW', 32, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12007, 12, N'SAPCAR', N'SAPCAR', N'SAPCAR', 33, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12008, 12, N'SAPMDM', N'SAPMDM', N'SAPMDM', 36, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12009, 12, N'SAPR3', N'SAPR3', N'SAPR3', 37, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12010, 12, N'THAILAND_UNKNOWN', N'THAILAND_UNKNOWN', N'THAILAND_UNKNOWN', 42, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12011, 12, N'SAPCRM', N'SAPCRM', N'SAPCRM', 34, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12012, 12, N'DNARDM', N'DNARDM', N'DNARDM', 13, N'12012', @DTCreated, N'deploy_1.4.0', NULL, NULL, 1, NULL, NULL, NULL)

INSERT [ser].[reflov] ([LOVId], [LOVSetId], [LOVKey], [LOVName], [LOVDescription], [LOVSequence], [LOVRecordSourceId], [DTCreated], [UserCreated], [SCDStartDate], [SCDEndDate], [SCDActiveFlag], [SCDVersion], [SCDLOVRecordSourceId], [ETLRunLogId]) VALUES (12013, 12, N'MS_AZURE', N'MS_AZURE', N'MS_AZURE', 23, N'12012', @DTCreated, N'deploy_1.6.0', NULL, NULL, 1, NULL, NULL, NULL)

GO
BEGIN TRANSACTION

UPDATE [ser].[reflovset]
   SET [LOVSetName] = 'floor'
      ,[LOVSetDescription] = 'floor'
 WHERE [LOVSetKey] = 'floor' 
   AND [LOVSetRecordSourceId]  in (12004,12001,12010,12005)
   AND [LOVSetName] = 'floor_plan'
   AND [LOVSetDescription] = 'floor_plan' 


COMMIT;
DECLARE @max_measure_id int,
        @data_type_id int,
		@data_type_double_id int,
		@data_type_int_id int,
		@record_source_id int=12008,
        @SCDLOVRecordSourceId Varchar(100)= '151',
		@measure_type_id int,
		@measure_type_geocode_id int,
		@MAXID int,
        @LOVGeoCodeMeasureTypeId int,
        @LOVFloorAreaMeasureTypeId int,
        @LOVDataTypeId int         



SELECT @measure_type_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='FLOOR_AREA' and rls.LOVSetName='Measure Type' 

SELECT @data_type_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='STRING' and rls.LOVSetName='Data Type' 
SELECT @measure_type_geocode_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='GEOCODE' and rls.LOVSetName='Measure Type' 

SELECT @data_type_double_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='DOUBLE' and rls.LOVSetName='Data Type'

SELECT @data_type_int_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='INT' and rls.LOVSetName='Data Type' 

---1---

select @max_measure_id=COALESCE((SELECT MAX(MeasureId) FROM  [ser].[Measure]),0)
INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
SELECT  (1+ @max_measure_id)MeasureId ,
        @measure_type_id,
		@data_type_id,
		'store_total_sales_area' as measureName,
		'Grand Total Total Sales Territory in m2',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
	 from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms

--2---

INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
SELECT  (2 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'number_of_floors' as measureName,
		'Number of Trading Floors',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms
		
		-----3------

		INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
SELECT  (3 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'non_dispensing_sales_area' as measureName,
		'Grand Total Non Dispensing Sales area(NDSA) in m2',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms
		
		--4-
				INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
SELECT  (4 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'baby_changing_room_area' as measureName,
		'Grand Total Baby Changing room area in m2',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms
		
		--5---
			INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (5 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'customer_toilets_area' as measureName,
		'Grand Total Customer Toilets area in m2',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms
		
		--6---
			INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (6 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'health_clinic_area' as measureName,
		'Grand Total Health Clinic area',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms
		
		
			--7---
			INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (7 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'opticans_off_sales_area' as measureName,
		'Grand Total Opticians Off-Sales area',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms	
		
			--8---
			INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (8 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'opticans_on_sales_area' as measureName,
		'Grand Total Opticians On-Sales area',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms	
					--9---
			INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (9 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'pharmacy_consultation_area' as measureName,
		'Grand Total Consulation area',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms	
					--10---
			INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (10 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'photolab_off_sales_area' as measureName,
		'Grand Total Photolab Off-Sales area',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms	
		
		
		------------11------
		
		INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (11 + @max_measure_id) MeasureId ,
        @measure_type_id,
		@data_type_id,
		'photolab_on_sales_area' as measureName,
		'Grand Total Photolab On-Sales area',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms	
		

	
		------------12------
		
		INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (12 + @max_measure_id) MeasureId ,
        @measure_type_geocode_id,
		@data_type_double_id,
		'z_grid_reference_longitude' as measureName,
		'Grid Reference Longitude',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms	
		
				------------13------
		
	   INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (13 + @max_measure_id) MeasureId ,
        @measure_type_geocode_id,
		@data_type_double_id,
		'z_grid_reference_latitude' as measureName,
		'Grid Reference Latitude',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms	
				------------14------
		INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (14 + @max_measure_id) MeasureId ,
        @measure_type_geocode_id,
		@data_type_int_id,
		'z_grid_reference_easting' as measureName,
		'Grid Reference Easting',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms	
				
	-----------15------
		
		INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
		   -- surogatekey not confirmed and dattype of measurename is varchar , so couldnt concat measurename.added sequence numbers 1 to 15 fro concat .
        SELECT  (15 + @max_measure_id) MeasureId ,
        @measure_type_geocode_id,
		@data_type_int_id,
		'z_grid_reference_northing' as measureName,
		'Grid Reference Northing',
		--length in not null , so inserted a dummy value
		NULL as Length,
		NULL as precision,
		NULL as scale,
		NULL as standard_measure_id,
		@record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    mdms.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawuk_btc_mdm_store) mdms	

RAISERROR ('Completed insertion source data to Measure  table', 0, 1) WITH NOWAIT

--INTERNATIONAL STORE---

--For Measure Table
SELECT @LOVGeoCodeMeasureTypeId =  ref.Lovid from ser.reflov ref JOIN ser.reflovset refset
        on ref.LovSetID = refset.LovSetID WHERE ref.LOVKey = 'GEOCODE' and refset.LOVSETName = 'Measure Type' 
 
SELECT @LOVFloorAreaMeasureTypeId =  ref.Lovid from ser.reflov ref JOIN ser.reflovset refset
        on ref.LovSetID = refset.LovSetID WHERE ref.LOVKey = 'FLOOR_AREA' and refset.LOVSETName = 'Measure Type' 
        
SELECT @LOVDataTypeId = ref.Lovid from ser.reflov ref JOIN ser.reflovset refset
        on ref.LovSetID = refset.LovSetID WHERE ref.LOVKey = 'STRING' and refset.LOVSETName = 'Data Type'
		
SELECT @MAXID = MAX(MeasureId) FROM [ser].[Measure]            
INSERT INTO [ser].[Measure]
           ([MeasureId]
           ,[LOVMeasureTypeId]
           ,[LOVDataTypeId]
           ,[MeasureName]
           ,[MeasureDescription]
           ,[Length]
           ,[Precision]
           ,[Scale]
           ,[StandardMeasureId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId])
    SELECT distinct  
    COALESCE(@MAXID, 0) + 1 ,@LOVGeoCodeMeasureTypeId,@LOVDataTypeId,'longitude','Longitude of Store address',
    NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawmx_crp_store) int_store	
     
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 2 ,@LOVGeoCodeMeasureTypeId,@LOVDataTypeId, 'latitude',
    'Latitude of Store address',NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawmx_crp_store) int_store	
     
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 3 ,@LOVFloorAreaMeasureTypeId,@LOVDataTypeId, 'store_ndsa', 
    'Non Dispensing Store Area',NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawmx_crp_store) int_store	
    
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 4 ,@LOVFloorAreaMeasureTypeId,@LOVDataTypeId, 'store_size',
    'Size of the store measured in m2', NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawmx_crp_store) int_store	
    UNION
    SELECT distinct  
    COALESCE(@MAXID, 0) + 5 ,@LOVGeoCodeMeasureTypeId,@LOVDataTypeId,'longitude','Longitude of Store address',
    NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawcl_crp_store) int_store	 
     
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 6 ,@LOVGeoCodeMeasureTypeId,@LOVDataTypeId, 'latitude',
    'Latitude of Store address',NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawcl_crp_store) int_store
     
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 7 ,@LOVFloorAreaMeasureTypeId,@LOVDataTypeId, 'store_ndsa', 
    'Non Dispensing Store Area',NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawcl_crp_store) int_store	
    
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 8 ,@LOVFloorAreaMeasureTypeId,@LOVDataTypeId, 'store_size',
    'Size of the store measured in m2',NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawcl_crp_store) int_store	
    
    UNION
    SELECT distinct  
    COALESCE(@MAXID, 0) + 9 ,@LOVGeoCodeMeasureTypeId,@LOVDataTypeId,'longitude','Longitude of Store address',
    NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawno_crp_store) int_store	
     
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 10 ,@LOVGeoCodeMeasureTypeId,@LOVDataTypeId, 'latitude',
    'Latitude of Store address', NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawno_crp_store) int_store	
     
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 11,@LOVFloorAreaMeasureTypeId,@LOVDataTypeId, 'store_ndsa', 
    'Non Dispensing Store Area', NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawno_crp_store) int_store	
    
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 12,@LOVFloorAreaMeasureTypeId,@LOVDataTypeId, 'store_size',
    'Size of the store measured in m2',  NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawno_crp_store) int_store	
    
    UNION
    SELECT distinct  
    COALESCE(@MAXID, 0) + 13 ,@LOVGeoCodeMeasureTypeId,@LOVDataTypeId,'longitude','Longitude of Store address',
     NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawth_crp_store) int_store	
     
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 14 ,@LOVGeoCodeMeasureTypeId,@LOVDataTypeId, 'latitude',
    'Latitude of Store address', NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawth_crp_store) int_store	
     
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 15,@LOVFloorAreaMeasureTypeId,@LOVDataTypeId, 'store_ndsa', 
    'Non Dispensing Store Area', NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawth_crp_store) int_store	
    
    UNION SELECT distinct  COALESCE(@MAXID, 0) + 16,@LOVFloorAreaMeasureTypeId,@LOVDataTypeId, 'store_size',
    'Size of the store measured in m2',  NULL,NULL,NULL,NULL,int_store.record_source_id,
		'1900-01-01 00:00:00' SCDStartDate ,
	   '9999-12-31 00:00:00'  SCDEndDate,'Y' as SCDActiveFlag,
	    1 as SCDVersion,
	    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	    int_store.etl_runlog_id as ETLRunLogId
		from (select distinct etl_runlog_id,record_source_id from psa.rawth_crp_store) int_store
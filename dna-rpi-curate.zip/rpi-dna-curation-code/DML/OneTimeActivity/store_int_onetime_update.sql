
DECLARE @SCDDefaultStartDate datetime,@SCDDefaultEndDate  datetime;
SET	@SCDDefaultStartDate      =	CONVERT(DateTime,'1900-01-01',126)			
SET	@SCDDefaultEndDate        = CONVERT(DateTime,'9999-12-31',126)
DECLARE @SCDDate datetime= (SELECT [modify_date] FROM sys.tables where name='siterolestatus')

-- update siterolestatus , updating scdactiveflag and scdversion in case both open_date and close_date are present
UPDATE ser.SiteroleStatus SET 
SCDVersion=tmp.SCDVersionupdated, SCDActiveFlag=tmp.SCDActiveflagupdated
from ser.siterolestatus srs
join
(SELECT SiteRoleId,LOVSiteRoleStatusSetId,LOVStatusId,EffectiveFrom,EffectiveTo,SCDVersion,lovrecordsourceid,
ROW_NUMBER() OVER(PARTITION BY siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId ORDER BY  SCDEndDate,EffectiveFrom) SCDVersionupdated,
LEAD('N',1,'Y') OVER(PARTITION BY siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId ORDER BY  SCDEndDate,EffectiveFrom) SCDActiveflagupdated
from ser.SiteroleStatus where lovrecordsourceid in (12001,12004,12005,12010) ) tmp on srs.siteroleid=tmp.siteroleid and srs.lovrecordsourceid=tmp.lovrecordsourceid 
and tmp.[LOVSiteRoleStatusSetId] =srs.[LOVSiteRoleStatusSetId] and tmp.SCDVersion=srs.SCDVersion and tmp.[LOVStatusId]=srs.[LOVStatusId]
where srs.lovrecordsourceid in (12001,12004,12005,12010) 

-- update siterolestatus , updating EffectiveTo

update ser.siterolestatus  set EffectiveTo=tmp.EffectiveTo from ser.siterolestatus srs join 
(select SiteRoleId,LOVSiteRoleStatusSetId,LOVStatusId,EffectiveFrom,
CASE when EffectiveTo is null Then LEAD(EffectiveFrom,1,NULL)
OVER(PARTITION BY siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId ORDER BY SCDVersion) ELSE EffectiveTo END EffectiveTo,LOVRecordSourceId,SCDVersion
FROM 
ser.siterolestatus  where lovrecordsourceid in (12001,12004,12005,12010) ) tmp on srs.siteroleid=tmp.siteroleid and srs.lovrecordsourceid=tmp.lovrecordsourceid 
and srs.scdversion=tmp.scdversion and tmp.[LOVSiteRoleStatusSetId] =srs.[LOVSiteRoleStatusSetId] 
where srs.lovrecordsourceid in (12001,12004,12005,12010)




update ser.SiteroleStatus  
set SCDStartDate= Case When SCDVersion=2 Then  @SCDDate Else SCDStartDate End,
SCDEndDate= Case When SCDVersion=1 Then @SCDDate Else SCDEndDate End
 
 from ser.SiteroleStatus srs join 
(select count(*) cnt, siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId from ser.SiteroleStatus
where SCDEndDate = @SCDDefaultEndDate and SCDStartDate=@SCDDefaultStartDate 
group by siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId having count(*)=2)tmp on 
srs.siteroleid=tmp.siteroleid and srs.lovrecordsourceid=tmp.lovrecordsourceid 
and tmp.[LOVSiteRoleStatusSetId] =srs.[LOVSiteRoleStatusSetId] 
where srs.lovrecordsourceid in (12001,12004,12005,12010)

update ser.SiteroleStatus  set SCDStartDate=tmp.SCDStartDateUpdated, SCDEndDate=tmp.SCDEndDateUpdated
 from ser.SiteroleStatus srs join 
(select SiteRoleId,LOVSiteRoleStatusSetId,LOVStatusId,EffectiveFrom,
CASE when SCDEndDate <> @SCDDefaultEndDate Then LAG(SCDENDDate,1,@SCDDefaultStartDate)
OVER(PARTITION BY siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId ORDER BY SCDVersion) Else SCDStartDate End SCDStartDateUpdated,
Case when SCDEndDate = @SCDDefaultEndDate and EffectiveTo is not NULL   Then SCDStartDate Else SCDEndDate END
SCDEndDateUpdated ,LOVRecordSourceId,SCDVersion
FROM 
ser.SiteroleStatus  where lovrecordsourceid in (12001,12004,12005,12010) ) tmp on 
srs.siteroleid=tmp.siteroleid and srs.lovrecordsourceid=tmp.lovrecordsourceid 
and srs.scdversion=tmp.scdversion and tmp.[LOVSiteRoleStatusSetId] =srs.[LOVSiteRoleStatusSetId] 
where srs.lovrecordsourceid in (12001,12004,12005,12010)

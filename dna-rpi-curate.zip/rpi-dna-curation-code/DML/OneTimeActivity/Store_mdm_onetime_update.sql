--One time update for mdm_store
DECLARE @SCDDate datetime= (SELECT [modify_date] FROM sys.tables where name='siterolestatus') -- '2020-08-14 10:18:52.470' 
DECLARE @SCDEndDate datetime=DATEADD(second,-1,@SCDDate)
--updating the version,flag and dates for the siteroleId which has multiple status records
UPDATE ser.SiteRoleStatus SET SCDVersion=1 ,SCDActiveFlag='N',SCDEndDate=@SCDEndDate where 
lovrecordsourceId=12008 and lovstatusId=178000002 and SiteRoleId in (select SiteRoleId from ser.SiteRoleStatus where lovrecordsourceId=12008 and lovstatusId=178000001)
UPDATE ser.SiteRoleStatus SET SCDVersion=2 ,SCDActiveFlag='Y',SCDStartDate=@SCDDate where lovrecordsourceId=12008 and lovstatusId=178000001 --closed

--EffectiveTo updation for the open status records
UPDATE ser.SiteRoleStatus SET effectiveTo=closed.effectivefrom 
from ser.SiteRoleStatus opens 
join (select siteroleId,effectivefrom,lovrecordsourceId from ser.SiteRoleStatus where lovrecordsourceId=12008 and lovstatusId=178000001) closed  
on opens.SiteRoleId=closed.SiteRoleID and opens.lovrecordsourceId=closed.lovrecordsourceId
where opens.lovstatusId=178000002

---update the site id for the skeleton record to negative record 
update ser.site set siteid=-1 where siteid=8294

update ser.siterole set siteid=-1 where siteid=8294
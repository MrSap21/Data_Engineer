--international merchandise- thailand
-- Update Measure details for tesp as incremental data has decimal scale greater than historical data
Update ser.Measure set Scale = 14 where MeasureName = 'tesp' AND Scale = '2' AND LOVRecordSourceID = 12010 AND SCDActiveFlag = 'Y';

-- Update Measure details for tisp as incremental data has decimal scale greater than historical data
Update ser.Measure set Scale = 14 where MeasureName = 'tisp' AND Scale = '2' AND LOVRecordSourceID = 12010 AND SCDActiveFlag = 'Y';

-- Update Measure details for epos profit as incremental data has decimal scale greater than historical data
Update ser.Measure set Scale = 14 where MeasureName = 'epos_profit' AND Scale = '2' AND LOVRecordSourceID = 12010 AND SCDActiveFlag = 'Y';

--Intactix Merchandise Onetiem Update
-- planogramposition
update ser.planogramposition
set scdstartdate=(SELECT CONVERT(datetime,'1900-01-01 00:00:00'))
from ser.planogramposition where scdstartdate is null and scdlovrecordsourceid=151;

--planogrampositionproperty
update ser.planogrampositionproperty
set scdstartdate=(SELECT CONVERT(datetime,'1900-01-01 00:00:00'))
from ser.planogrampositionproperty where scdstartdate is null and scdlovrecordsourceid=151;
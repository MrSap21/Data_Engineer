/* Purpose : Onetime activity for HIstory if the retail status code changes for a business key in history catch up ,
			then Correcting the Scdversion,SCdActiveFlag,ScdStartDate and EndDate of those records */

DECLARE @HistpsaRunlogId BIGINT,
		@rowtoupdate BIGINT,
		@LOVProductStatusSetid BIGINT,
		@SCDSTARTDATE DATETIME,
		@SCDENDDATE DATETIME;
		BEGIN	   
			SELECT @HistpsaRunlogId  = min(etl_runlog_id) FROM psa.rawuk_btc_mdm_item;
			
			Print 'History runlogid:'+cast(@HistpsaRunlogId as varchar(max));

			SELECT @rowtoupdate=count(*) FROM psa.rawuk_btc_mdm_item mdmi1
			WHERE etl_runlog_id <>@HistpsaRunlogId
			AND EXISTS  (SELECT item_code FROM psa.rawuk_btc_mdm_item 
			WHERE etl_runlog_id =@HistpsaRunlogId)
			AND NOT EXISTS  (SELECT 1 FROM psa.rawuk_btc_mdm_item mdmi2
			WHERE mdmi1.item_code=mdmi2.item_code
			and mdmi1.retail_status_code=mdmi2.retail_status_code
			 and mdmi2.etl_runlog_id = @HistpsaRunlogId);

			Print 'No.Of Product requires update:'+cast(@rowtoupdate as varchar(max))

			IF @rowtoupdate > 0 
				BEGIN
					
					 SELECT  @LOVProductStatusSetid=LovSetID from [ser].[Reflovset]
						where LOVSetName = 'retail_status_code'
						and LOVSetRecordSourceId = 12008;
						
						SELECT @SCDSTARTDATE =max(SCDStartDate) FROM ser.Product WHERE lovrecordsourceid=12008;
						
						SET @SCDEndDate =DATEADD(second,-1,@SCDStartDate);
						
						With RetailStatusTemp as (
							SELECT ps.productid
							,ps.LOVStatusId
							,ps.LOVProductStatusSetid
							,ROW_NUMBER() OVER(PARTITION BY ps.productid, ps.LOVProductStatusSetid, ps.LOVRecordSourceId ORDER BY  ps.etlrunlogid) SCDVersionupdated
							,LEAD('N',1,'Y') OVER(PARTITION BY  ps.productid, ps.LOVProductStatusSetid, ps.LOVRecordSourceId ORDER BY  ps.etlrunlogid) SCDActiveflagupdated
							,(CASE WHEN ROW_NUMBER() OVER(PARTITION BY ps.productid,ps.LOVProductStatusSetid,ps.LOVRecordSourceId ORDER BY ps.etlrunlogid ASC) =1 THEN '1900-01-01'
									ELSE @SCDStartDate END) AS SCDStartDateupdated,	
							,LEAD(@SCDEndDate,1,'9999-12-31') OVER (PARTITION BY  ps.productid,ps.LOVProductStatusSetid,ps.LOVRecordSourceId  order BY  ps.etlrunlogid) SCDEndDateupdated
							,ps.LOVRecordSourceID
							FROM ser.ProductStatus ps, psa.rawuk_btc_mdm_item mdmi,ser.Product p
							WHERE mdmi.item_code=p.sourcekey
								   and mdmi.record_source_id=p.lovrecordsourceid
								   and  p.SCDActiveFlag='Y'
								   and p.productid=ps.productid
								  and  ps.LOVProductStatusSetid=@LOVProductStatusSetid	
								  and  p.lovrecordsourceid=p.lovrecordsourceid
								AND mdmi.etl_runlog_id <> @HistpsaRunlogId
								AND EXISTS  (SELECT item_code FROM psa.rawuk_btc_mdm_item b
												WHERE b.etl_runlog_id =@HistpsaRunlogId)
								AND NOT EXISTS  (SELECT 1 FROM psa.rawuk_btc_mdm_item mdmi2
														  WHERE mdmi.item_code=mdmi2.item_code
															and mdmi.retail_status_code=mdmi2.retail_status_code
															and mdmi2.etl_runlog_id = @HistpsaRunlogId)
								 )
					  UPDATE ser.ProductStatus SET SCDVersion= SCDVersionupdated,SCDActiveFlag=SCDActiveflagupdated,SCDStartDate=SCDStartDateupdated,SCDEndDate=SCDEndDateupdated
						FROM ser.ProductStatus p
						  JOIN RetailStatusTemp a
						ON  p.productid=a.productid
						AND p.LOVProductStatusSetid=a.LOVProductStatusSetid
						AND p.LOVStatusID=a.LOVStatusID
						AND p.LOVRecordSourceID=a.LOVRecordSourceID;
				END
		END
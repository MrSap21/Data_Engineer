/* --- DQ Rule entry for ruletype = NullForMandatoryField for sapcrm_ad_card --- */
INSERT INTO psa.DQRules (RuleType ,TableName,ColumnName,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ('NullForMandatoryField','sap_crm_ad_card','account_number' ,'NA' ,'NA',12011, 'Y') ;
INSERT INTO psa.DQRules (RuleType ,TableName,ColumnName,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ('NullForMandatoryField','sap_crm_ad_card','full_card_number' ,'NA' ,'NA',12011, 'Y') ;
INSERT INTO psa.DQRules (RuleType ,TableName,ColumnName,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ('NullForMandatoryField','sap_crm_ad_card','card_status_code' ,'NA' ,'NA',12011, 'Y') ;
INSERT INTO psa.DQRules (RuleType ,TableName,ColumnName,RuleSetName,RuleKey,RecordSourceID,ActiveFlag) VALUES ('NullForMandatoryField','sap_crm_ad_card','card_type_code' ,'NA' ,'NA',12011, 'Y') ;

/* --- DQ Rule entry for ruletype = MissingLookupKeys for sapcrm_ad_card --- */
INSERT INTO [psa].[dqrules] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[Datatype]) VALUES ('MissingLookupKeys','sap_crm_ad_card','card_type_code','card_type',NULL,12011,'Y',NULL);
INSERT INTO [psa].[dqrules] ([RuleType],[TableName],[ColumnName],[RuleSetName],[RuleKey],[RecordSourceID],[ActiveFlag],[Datatype]) VALUES ('MissingLookupKeys','sap_crm_ad_card','card_status_code','card_status',NULL,12011,'Y',NULL);
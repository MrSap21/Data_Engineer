from azure.storage.filedatalake import DataLakeServiceClient
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient
from io import StringIO, BytesIO
import pandas as pd
import sys, json, os
import shutil, batch_logger

"""
Configuration Properties
"""
DOWNLOAD_FOLDER = '/input-files'

"""
Keys in ADLS Extended Propertes 
"""
INPUT_CONTAINER_KEY = 'inputContainer'
OUTPUT_CONTAINER_KEY = 'outputContainer'
INPUT_FILE_PATH = 'inputFilePath'
OUTPUT_FILE_PATH_KEY = 'outputFilePath'
DELIMITER_KEY = 'delimiter'
METADATA_JSON_KEY = 'metadataJson'
CHUNKSIZE_KEY = 'chunkSize'
SKIPHEADER_KEY = 'skipHeader'
SKIPFOOTER_KEY = 'skipFooter'
ADLS_SECRET_KEY = 'adlsSecretKey'
AZURE_CLIENT_ID = 'azureClientId'
AZURE_TENANT_ID = 'azureTenantId'
AZURE_CLIENT_SECRET = 'azureClientSecret'
NULLABLE_FIELDS = ['chunkSize', 'skipHeader', 'skipFooter']

"""
Batch Process Constants
"""
ACTIVITY_FILE = "activity.json"
LINKED_SERVICE_FILE = "linkedServices.json"

ADLS_LINKED_SERVICE_KEY = 'AzureBlobFS'
KEYVAULT_LINKED_SERVICE_KEY = 'AzureKeyVault'

FIXWIDTH_START_COL = "FixWidthStart"
FIXWIDTH_END_COL = "FixWidthEnd"

TYPE_PROPS_KEY = "typeProperties"
EXTD_PROPS_KEY = "extendedProperties"
ATTRIBUTE_KEY = "Attribute"
URL_KEY = 'url'
BASEURL_KEY = 'baseUrl'
ACCOUNTKEY_KEY = 'accountKey'
CONNECTIONSTRING_KEY = 'connectionString'
PROPS_KEY = 'properties'
TYPE_KEY = 'type'
ADLS_KEY = 'ADLS'
KEYVAULT_KEY = 'KeyVault'

"""
BatchProcessCSV Logger
"""
script_name = os.path.basename(__file__)
logger = batch_logger.get_logger(script_name)

class KeyVaultClient:
    """
    KeyVaultClient class accomodates setting the environment variables required for DefaultAzureCredential()
    and also, gets secret from Azure Key Vault with help of the key.
    
    :param client_id: Azure Client Id
    :param tenant_id: Azure Tenant Id
    :param client_secret: Azure Client Secret
    :param base_url: Base Url to access Azure Key Vault
    """
    def __init__(self, client_id, tenant_id, client_secret, base_url):
        try:
            logger.info('Initializing KeyVaultClient instance.')
            self.set_env_variables(client_id, tenant_id, client_secret)
            credential = DefaultAzureCredential()
            self._secret_client = SecretClient(vault_url=base_url, credential=credential)#, logging_enable=True)
            logger.info('Successfully initialized KeyVaultClient instance.')
        except Exception as ex:
            error_msg = "Error encountered while initializing KeyVaultClient."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)

    """
    Set the enviroment variables required for DefaultAzureCredential()
    """
    def set_env_variables(self, client_id, tenant_id, client_secret):
        logger.debug('Client ID : {}'.format(client_id))
        logger.debug('Tenant ID : {}'.format(tenant_id))
        if None not in (client_id, tenant_id, client_secret):
            logger.info('Configuring environmental variables.')
            os.environ["AZURE_CLIENT_ID"] = client_id
            os.environ["AZURE_TENANT_ID"] = tenant_id
            os.environ["AZURE_CLIENT_SECRET"] = client_secret
            logger.info('Successfully configured environmental variables.')

    """
    Gets the secret from the Azure Key Vault with the help of the secret key.
    """
    def get_secret(self, secret_key):
        logger.info('Fetching secret from the Key Vault.')
        if secret_key is not None:
            secret = self._secret_client.get_secret(secret_key)#, logging_enable=True)
            return secret.value if secret is not None else None
        else:
            error_msg = "Secret Key is empty."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)

class DataLakeClient:
    """
    DataLakeClient class accomodates reading and writing data files from/to ADLS Gen 2 storage.
    
    :param connection_string: Connection String to connect to the ADLS storage
    :param account_url: URL to access to the ADLS storage
    :param account_key: Account Key to authenticate the access to the ADLS storage
    """
    def __init__(self, connection_string, account_url, account_key):
        self._stream = BytesIO()
        self._target_file_exists = False
        self._start_offset = 0
        self._file_length = 0
        self.target_file_client = None
        try:
            logger.info('Initializing DataLakeClient instance.')
            if connection_string is not None:
                logger.info('Instantiating connection client using Connection String.')
                self.datalake_service_client = DataLakeServiceClient.from_connection_string(connection_string)
            else:
                logger.info('Instantiating connection client using Url and Credentials.')
                self.datalake_service_client = DataLakeServiceClient(account_url=account_url, credential=account_key)#, logging_enable=True)
            logger.info('Successfully initialized DataLakeClient instance.')
        except Exception as ex:
            error_msg = "Error encountered while initializing DataLakeClient."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)

    """
    Returns the File Client for a file in ADLS
    """
    def get_file_client(self, container, file_path):
        logger.info('Fetching file client.')
        logger.debug('Container : {}'.format(container))
        logger.debug('File Path : {}'.format(file_path))
        return self.datalake_service_client.get_file_client(container,file_path)

    """
    Reads a File from ADLS and returns the data as stream
    """
    def read_file_stream(self, container, file_path):
        file_stream = None
        try:
            logger.info('Fetching input data into file stream.')
            logger.debug('Container : {}'.format(container))
            logger.debug('File Path : {}'.format(file_path))
            file_client = self.get_file_client(container, file_path)
            file_stream = file_client.download_file().readinto(self._stream)
            logger.info('Successfully fetched input data into file stream.')
        except Exception as ex:
            error_msg = "Error encountered while reading file into stream."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)
        return self._stream
    
    """
    Reads a File from ADLS as chunks
    """
    def read_file_chunks(self, container, file_path):
        file_chunks = None
        try:
            logger.info('Fetching input data file as chunks.')
            logger.debug('Container : {}'.format(container))
            logger.debug('File Path : {}'.format(file_path))
            file_client = self.get_file_client(container, file_path)
            file_chunks = file_client.download_file().chunks()
            logger.info('Successfully fetched input data file as chunks.')
        except Exception as ex:
            error_msg = "Error encountered while reading file chunks."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)
        return file_chunks

    """
    Downloads a file from Datalake into the Azure Batch Node
    """
    def download_file(self, container, adls_file_path, local_file_path):
        try:
            logger.info('Downloading the input file from Datalake to Batch Node.')
            adls_file = adls_file_path.split('/')[-1]
            logger.debug('Container       : {}'.format(container))
            logger.debug('ADLS File Path  : {}'.format(adls_file_path))
            logger.debug('Local File Path : {}'.format(local_file_path))
            with open(local_file_path + '/' + adls_file, 'wb') as file:
                file_client = self.get_file_client(container, adls_file_path)
                file_stream = file_client.download_file().readinto(file)
            logger.info('Successfully downloaded the input file from Datalake to Batch Node.')
        except Exception as ex:
            error_msg = "Error encountered while downloading the input file."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)

    """
    Sets the target file client in  ADLS
    """
    def set_target_file_client(self, container, file_path):
        logger.info('Creating target file on Datalake.')
        logger.debug('Container       : {}'.format(container))
        logger.debug('File Path       : {}'.format(file_path))
        self.target_file_client = self.get_file_client(container, file_path)
        self.target_file_client.create_file()
        logger.info('Successfully created target file on Datalake.')

    """
    Uploads a file to the target location
    """
    def upload_file(self, container, file_path, data):
        file_client = self.get_file_client(container, file_path)
        file_client.create_file()
        file_client.upload_data(data, length=len(data), overwrite=True)

    """
    Appends data to the target file client
    """
    def append_data(self, data):
        try:            
            logger.info('Appending processed data to Datalake file.')
            logger.debug('Start Offset : {}'.format(self._start_offset))
            logger.debug('Data Length  : {}'.format(len(data)))
            self.target_file_client.append_data(data, self._start_offset, len(data))
        except Exception as ex:
            error_msg = "Error encountered while appending data into the Datalake file."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)
        else:
            self._start_offset += len(data)

    """
    Flushes the already appened data in the target file client to the target location
    """            
    def flush_data(self):
        try:
            logger.info('Flushing data to Datalake file.')
            logger.debug('Data Length  : {}'.format(self._start_offset))
            self.target_file_client.flush_data(self._start_offset)
            logger.info('Successfully flushed data to Datalake file.')
        except Exception as ex:
            error_msg = "Error encountered while flushing data into the Datalake file."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)


class FixedWidthFileProcessor:
    """
    FixedWidthFileProcessor class handles the various operations in processing the Fixed Width Files,
    and deducing the field widths from the Azure Data Factory parameters.

    """
    def __init__(self, filepath, chunksize, skiprows, metadata_json):
        logger.info('Initializing FixedWidthFileProcessor instance.')
        self._stream = StringIO()
        self._colspec_list = None
        logger.debug('Local File Path  : {}'.format(filepath))
        logger.debug('Chunk size       : {}'.format(chunksize))
        logger.debug('Skiprows         : {}'.format(skiprows))
        logger.debug('Metadata Json    : {}'.format(metadata_json))
        self._filepath = filepath
        self._chunksize = chunksize
        self._skiprows = skiprows
        self.process_metadata(metadata_json)
        logger.info('Successfully initialized FixedWidthFileProcessor instance.')
    
    """
    Processes the metadata json passed from the Azure Data Factory, denormalizes it
    and extracts the Column Specs (field width) from it, as a list.
    """
    def process_metadata(self, metadata_json):
        try:
            logger.info('Processing metadata json.')
            logger.debug('Metadata Json    : {}'.format(metadata_json))
            metadata_df = pd.json_normalize(metadata_json, ATTRIBUTE_KEY)
            colspec_df = '(' + metadata_df[FIXWIDTH_START_COL].map(str) + ',' + metadata_df[FIXWIDTH_END_COL].map(str) + ')'
            #self._colspec_list = colspec_df.values.tolist()
            self._colspec_list = [eval(colspec) for colspec in colspec_df.values.tolist()]
            logger.info('Successfully processed the metadata json.')
        except Exception as ex:
            error_msg = "Error encountered while processing metadata json."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)

    """
    Returns an iterator with all the chunks of data (as dataframes), read from the 
    fixed-width file.
    """
    def get_chunks(self):
        logger.info('Fetching input file chunks.')
        return pd.read_fwf(self._filepath, 
                    colspecs = self._colspec_list, 
                    header = None,
                    dtype=object,
                    chunksize = self._chunksize,
                    skiprows = self._skiprows,
                    #skipfooter=1,
                    #encoding='utf-16')
                    )
    """
    Returns the count of chunks generated from the fixed-width file.
    """
    def get_chunk_count(self):
        logger.info('Fetching input file chunk count.')
        chunks = pd.read_fwf(self._filepath, 
                colspecs = self._colspec_list, 
                header=None,
                dtype=object,
                chunksize = self._chunksize,
                skiprows = self._skiprows,
                #skipfooter=1,
                #encoding='utf-16')
                )
        chunk_count = sum(1 for _ in chunks)
        logger.debug('Input file chunk count    : {}'.format(chunk_count))
        return chunk_count

    """
    Converts a fixed-width file delimiter to a 'demiliter seperated value' stream,
    and returns it.
    """
    def convert_to_dsv(self, df, delimiter):
        try:
            logger.info('Converting fixed width data to delimiter seperated data.')
            self._stream.seek(0)
            self._stream.truncate(0)
            df.to_csv(self._stream, sep=delimiter, index=False, header=False)
        except Exception as ex:
            error_msg = "Error encountered while converting data into delimiter seperated values."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)
        return self._stream

    """
    Removes 'num_records' number of records from the end of the dataframe, and 
    returns the resultant dataframe.
    """
    def skip_footer(self, df, num_records):
        logger.info('Removing footer record.')
        if num_records is not None and df.empty == False:
            try:
                df.drop(df.tail(num_records).index, inplace=True)
                logger.info('Successfully removed the footer record.')
            except Exception as ex:
                error_msg = "Error encountered while removing the footer record."
                logger.error(error_msg, exc_info=True)
                raise Exception(error_msg, ex)
            return df
        else:
            return None
         
class BatchProcessor:
    """
    BatchProcessor is the helper class that - reads the Azure Data Factory parameters,
    parses the Linked Services for the connection paraments and instantiates the ADLS
    connection clients

    """
    def __init__(self):
        try:
            self._container_in = None
            self._container_out = None
            self._filepath_input = None
            self._filepath_output = None
            self._delimiter = None
            self._metadata_json = None
            self._chunksize = None
            self._skipheader = None
            self._skipfooter = None
            self._adls_secret = None
            self._azure_client_id = None
            self._azure_tenant_id = None
            self._azure_client_secret = None
            self._linked_service_dict = dict() 
            self._adf_props = self.read_adf_properties()
            self.configure_properties()
        except Exception as ex:
            error_msg = "Error encountered while initializing BatchProcessor instance."
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)

    """
    Configures the ADF Pipeline parameters
    """
    def configure_properties(self):
        if self._adf_props is not None:
            self._container_in = self.get_value(self._adf_props, INPUT_CONTAINER_KEY)
            self._container_out = self.get_value(self._adf_props, OUTPUT_CONTAINER_KEY)
            self._filepath_input = self.get_value(self._adf_props, INPUT_FILE_PATH)
            self._filepath_output = self.get_value(self._adf_props, OUTPUT_FILE_PATH_KEY)
            self._delimiter= self.get_value(self._adf_props, DELIMITER_KEY)
            self._metadata_json = self.get_value(self._adf_props, METADATA_JSON_KEY)
            self._chunksize = self.get_value(self._adf_props, CHUNKSIZE_KEY)
            self._skipheader = self.get_value(self._adf_props, SKIPHEADER_KEY)
            self._skipfooter = self.get_value(self._adf_props, SKIPFOOTER_KEY)
            self._adls_secret = self.get_value(self._adf_props, ADLS_SECRET_KEY)
            self._azure_client_id = self.get_value(self._adf_props, AZURE_CLIENT_ID)
            self._azure_tenant_id = self.get_value(self._adf_props, AZURE_TENANT_ID)
            self._azure_client_secret = self.get_value(self._adf_props, AZURE_CLIENT_SECRET)
            self.read_linked_services()
        else:
            error_msg = "Azure Data Factory Extended Properties is empty"
            logger.error(error_msg)
            raise Exception(error_msg)

    """
    Reads the properties set from the ADF
    """
    def read_adf_properties(self):
        logger.info('Reading Azure Data Factory Extended Properties.')
        with open(ACTIVITY_FILE) as file:
            activity_json = json.loads(file.read())
        if activity_json is not None and TYPE_PROPS_KEY in activity_json:
            return activity_json[TYPE_PROPS_KEY][EXTD_PROPS_KEY] if EXTD_PROPS_KEY in activity_json[TYPE_PROPS_KEY] else None
        return None

    """
    Parses linkedServices.json file and extracts the connection parameters
    """
    def read_linked_services(self):
        logger.info('Reading Azure Data Factory Reference Objects.')
        with open(LINKED_SERVICE_FILE) as file:
            linked_service_json = json.loads(file.read())
        for linked_service in linked_service_json:
            svc_type = linked_service[PROPS_KEY][TYPE_KEY]
            key = KEYVAULT_KEY if svc_type == KEYVAULT_LINKED_SERVICE_KEY else ADLS_KEY if svc_type == ADLS_LINKED_SERVICE_KEY else None
            if key is not None:
                type_props = linked_service[PROPS_KEY][TYPE_PROPS_KEY]
                if CONNECTIONSTRING_KEY in type_props:
                    self._linked_service_dict[key] = type_props[CONNECTIONSTRING_KEY]
                    logger.info('Fetched Connection String from Azure Data Factory Reference Objects.')
                elif URL_KEY in type_props:
                    self._linked_service_dict[key] = dict(url=type_props[URL_KEY])
                    logger.info('Fetched URL from Azure Data Factory Reference Objects.')
                    if ACCOUNTKEY_KEY in type_props:
                        self._linked_service_dict[key] = dict(url=type_props[URL_KEY], accountKey=type_props[ACCOUNTKEY_KEY])
                        logger.info('Fetched URL and AccountKey from Azure Data Factory Reference Objects.')
                elif BASEURL_KEY in type_props:
                    self._linked_service_dict[key] = type_props[BASEURL_KEY]
                    logger.info('Fetched Base URL from Azure Data Factory Reference Objects.')

    """
    Fetches value from a Dictionary based on the Key
    """
    def get_value(self, dictionary, key):
        if key in dictionary and len(dictionary[key]) > 0:
            return dictionary[key]
        elif key in NULLABLE_FIELDS and len(dictionary[key]) == 0:
            return ""
        else:
            raise ValueError('Property {} is missing in ADF Extended Properties.'.format(key))
            return None

    """
    Prints the values of the various configuration parameters
    """
    def log_extended_properties(self):
        logger.info('Container Input   : {}'.format(self._container_in))
        logger.info('Container Output  : {}'.format(self._container_out))
        logger.info('Filepath Input    : {}'.format(self._filepath_input))
        logger.info('Filepath Output   : {}'.format(self._filepath_output))
        logger.info('Delimiter         : {}'.format(self._delimiter))
        logger.info('Metadata Json     : {}'.format(self._metadata_json))
        logger.info('Chunk Size        : {}'.format(self._chunksize))
        logger.info('Skip Header       : {}'.format(self._skipheader))
        logger.info('Skip Footer       : {}'.format(self._skipfooter))

    @property
    def container_in(self): return self._container_in
    @property
    def container_out(self): return self._container_out
    @property
    def filepath_input(self): return self._filepath_input
    @property
    def filepath_output(self): return self._filepath_output
    @property
    def delimiter(self): return self._delimiter
    @property
    def metadata_json(self): return self._metadata_json
    @property
    def chunksize(self): return self._chunksize
    @property
    def skip_header(self): return self._skipheader
    @property
    def skip_footer(self): return self._skipfooter
    @property
    def adls_secret(self): return self._adls_secret
    @property
    def azure_client_id(self): return self._azure_client_id
    @property
    def azure_tenant_id(self): return self._azure_tenant_id
    @property
    def azure_client_secret(self): return self._azure_client_secret
    @property
    def addl_col(self): return self._addl_col
    @property
    def linked_service_dict(self): return self._linked_service_dict

"""
Gets the connection client object from the connection_prop Dictionary 
"""
def get_connection_client(connection_prop, storage_type, keyvault_secret):
    logger.info('Fetching {} connection client'.format(storage_type))
    if None not in (connection_prop, storage_type):
        if isinstance(connection_prop, dict):
            if URL_KEY in connection_prop:
                conn_url = connection_prop.get(URL_KEY)
                conn_accountKey = connection_prop.get(ACCOUNTKEY_KEY, keyvault_secret)
                if storage_type == ADLS_KEY:
                    return DataLakeClient(None, conn_url, conn_accountKey)
                else:
                    return None
        elif isinstance(connection_prop, str):
            if storage_type == ADLS_KEY:
                return DataLakeClient(connection_prop, None, None)
            else:
                return None
    error_msg = 'Error initializing {} connection client'.format(storage_type)
    logger.error(error_msg, exc_info=True)
    raise Exception(error_msg, ex)

'''
Converts a string literal to integer, and raises an error in case
of invalid inputs.
'''
def string_to_int(string, default, name):
        if not string:
            return default
        elif string.isdigit() == True:
            return int(string)
        else:
            error_msg = 'Error converting {} to int'.format(name)
            logger.error(error_msg, exc_info=True)
            raise Exception(error_msg, ex)

"""
Creates a new directory in the batch node working directory
"""
def create_resouce_directory(folder_name):
    try:
        logger.info('Creating resource directory.')
        wd_path = os.path.dirname(os.path.realpath(__file__))
        full_path = wd_path + folder_name
        logger.info('Resource Directory Path : {}'.format(full_path))
        os.mkdir(full_path)
        logger.info('Successfully created resource directory.')
    except Exception as ex:
        error_msg = 'Error encountered while creating directory at path {}.'.format(full_path)
        logger.error(error_msg, exc_info=True)
        raise Exception(error_msg, ex)
    return full_path

"""
Main Function
"""
if __name__=="__main__":
    logger.info('Starting Batch Process execution.')
    try:
        batch_processor = BatchProcessor()
        logger.info('Creating Source and Target connection clients.')
        linked_service_dict = batch_processor.linked_service_dict
        keyvault_client = KeyVaultClient(
                batch_processor.azure_client_id, 
                batch_processor.azure_tenant_id, 
                batch_processor.azure_client_secret,
                linked_service_dict[KEYVAULT_KEY])
        adls_secret = keyvault_client.get_secret(batch_processor.adls_secret)
        conn_prop_adls = linked_service_dict[ADLS_KEY]
        data_lake_client = get_connection_client(conn_prop_adls, ADLS_KEY, adls_secret)
        logger.info('Successfully created Source and Target connection clients.')
        
        logger.info('Configuring the Batch Process parameters.')
        container_in = batch_processor.container_in
        container_out = batch_processor.container_out
        filepath_input = batch_processor.filepath_input
        filepath_output = batch_processor.filepath_output
        delimiter = batch_processor.delimiter
        metadata_json = batch_processor.metadata_json
        chunksize = batch_processor.chunksize
        skip_header = batch_processor.skip_header
        skip_footer = batch_processor.skip_footer
        logger.info('Successfully configured the Batch Process parameters.')
        batch_processor.log_extended_properties()
        
        chunksize = string_to_int(chunksize, 100000, 'chunksize')
        skipheader_count = string_to_int(skip_header, None, 'skip_header')
        skipfooter_count = string_to_int(skip_footer, None, 'skip_footer')       
        file_name = filepath_input.split('/')[-1]

        logger.debug('Chunk Size        : {}'.format(str(chunksize)))
        logger.debug('Skip Header Count : {}'.format(str(skipheader_count)))
        logger.debug('Skip Footer Count : {}'.format(str(skipfooter_count)))
        logger.debug('File Name         : {}'.format(file_name))
    except Exception as ex:
        logger.error(ex, exc_info=True)
        sys.exit(1)

    error_code = 0
    chunk_counter = 0
    try:
        download_path = create_resouce_directory(DOWNLOAD_FOLDER)
        data_lake_client.download_file(container_in, filepath_input, download_path)
        data_lake_client.set_target_file_client(container_out, filepath_output)
        fwf_processor = FixedWidthFileProcessor(download_path + '/' + file_name, chunksize, skipheader_count, metadata_json)#json.loads(metadata_json))
        ###########################
        ##  Append & Flush Data  ##
        ###########################
        chunk_count = fwf_processor.get_chunk_count()
        for df in fwf_processor.get_chunks():
            if chunk_counter == chunk_count-1 and skipfooter_count is not None:
                df = fwf_processor.skip_footer(df, skipfooter_count)
            if df is not None:
                output_stream = fwf_processor.convert_to_dsv(df, delimiter)
                data_lake_client.append_data(output_stream.getvalue())
            chunk_counter += 1
    except Exception as ex:
        logger.error(ex, exc_info=True)
        error_code = 1
    else:    
        data_lake_client.flush_data()
        logger.info('Completed Batch Process execution.')
    finally:
        shutil.rmtree(download_path)
        if error_code == 1:
            sys.exit(1)

    ###############
    ##Upload File##
    ###############
    #processed_path = wd_path + '/processed'
    #os.mkdir(processed_path)
    #
    #for df in pd.read_fwf(download_path + '/' + file_name, colspecs=fwf_processor.colspec_list, header=None, chunksize=40000, encoding='utf8'):
    #    df.to_csv(processed_path + '/' + file_name, mode='a', sep=delimiter, index=False, header=False)
    #print(os.listdir(processed_path))
    #
    #
    #try:
    #    #with open(processed_path + '/' + file_name, 'rb') as processed_file:
    #    local_file = open(processed_path + '/' + file_name,'r', encoding = 'utf8')
    #    file_contents = local_file.read()
    #    data_lake_client.upload_file(container_out, filepath_output, file_contents)
    #except Exception as ex:
    #    print('ERROR :', ex)
    #finally:
    #    shutil.rmtree(download_path)
    #    shutil.rmtree(processed_path)
    #    print('total row count', col_count)
    #    print('total line count', file_line_count)
    #    print('total total_file_length', total_file_length)
    #    #print(os.listdir(download_path))
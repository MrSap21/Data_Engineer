#!/bin/bash

numHeader=$1
numFooter=$2
filePath=$3

echo "NumHeader :: $numHeader"
echo "NumFooter :: $numFooter"
echo "FileFullPath :: $filePath"

dirPath=$(dirname $filePath)
chmod 755 $dirPath

if [ $numFooter -gt 0 ]
then
	while [ -z "$(tail -c 1 "$filePath")" ]
	do
   		truncate -s -1 $filePath
   		echo 'New Line Removed'
	done
	lastLine=$(tail -n $numFooter $filePath)
	let truncateSize="${#lastLine} + 1"
	truncate -s -"$truncateSize" $filePath
fi

if [ $numHeader -gt 0 ]
then
	awk "NR>${numHeader}"  $filePath > "${filePath}.modified"
fi

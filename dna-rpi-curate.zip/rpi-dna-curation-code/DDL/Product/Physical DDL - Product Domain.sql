/* 
 * TABLE: [Product] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[Product](
    [ProductId]             bigint           NOT NULL,
    [SourceKey]             nvarchar(80)     NOT NULL,
    [LOVSourceKeyTypeId]    int              NOT NULL,
    [ProductName]           nvarchar(100)    NULL,
    [ProductDescription]    nvarchar(255)    NULL,
    [LOVBrandId]            int              NULL,
    [LOVSubBrandId]         int              NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [ParentProductId]       bigint           NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  int              NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVSourceKeyTypeId],[LOVRecordSourceId])
)
go

/* 
 * TABLE: [ProductStatus] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[ProductStatus](
    [ProductId]              bigint      NOT NULL,
    [LOVProductStatusSetId]  int         NOT NULL,
    [LOVStatusId]            int         NULL,
    [EffectiveFrom]          datetime    NULL,
    [EffectiveTo]            datetime    NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          nchar(1)    NULL,
    [SCDVersion]             smallint    NULL,
    [SCDLOVRecordSourceId]   int         NULL,
    [ETLRunLogId]            int         NULL,
    [PSARowKey]              bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([ProductId],[LOVProductStatusSetId],[LOVRecordSourceId])
)


go

/* 
 * TABLE: [ProductIdentifier] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[ProductIdentifier](
    [ProductId]             bigint          NOT NULL,
    [LOVIdentifierId]       int             NOT NULL,
    [Value]                 nvarchar(80)    NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVIdentifierId],[LOVRecordSourceId])
)

go


/* 
 * TABLE: [ProductIndicator] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[ProductIndicator](
    [ProductId]             bigint       NOT NULL,
    [LOVIndicatorId]        int          NOT NULL,
    [Value]                 nvarchar(10) NULL,
    [LOVRecordSourceId]     int          NOT NULL,
    [SCDStartDate]          datetime     NULL,
    [SCDEndDate]            datetime     NULL,
    [SCDActiveFlag]         nchar(1)     NULL,
    [SCDVersion]            smallint     NULL,
    [SCDLOVRecordSourceId]  int          NULL,
    [ETLRunLogId]           int          NULL,
    [PSARowKey]             bigint       NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([ProductId],[LOVIndicatorId],[LOVRecordSourceId])
)
go

/* 
 * TABLE: [ProductGroup] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[ProductGroup](
    [ProductGroupId]        bigint      NOT NULL,
    [ProductId]             bigint      NOT NULL,
    [LOVProductGroupSetId]  int         NOT NULL,
    [LOVGroupId]            int         NOT NULL,
    [ParentProductGroupId]  bigint      NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [PSARowKey]             bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([ProductId],[LOVProductGroupSetId],[LOVRecordSourceId])
)
go

/* 
 * TABLE: [ProductProperty] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[ProductProperty](
    [ProductId]             bigint           NOT NULL,
    [MeasureId]             int              NOT NULL,
    [LOVUOMId]              int              NOT NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  int              NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([ProductId],[MeasureId],[LOVUOMId],[LOVRecordSourceId])
)
go

/* 
 * TABLE: [ProductPartyRole] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[ProductPartyRole](
    [ProductId]             bigint      NOT NULL,
    [PartyRoleId]           bigint      NOT NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [PSARowKey]             bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([ProductId],[PartyRoleId],[LOVRecordSourceId])
)
go
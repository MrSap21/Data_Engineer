/* 
 * TABLE: [SiteRoleContactMethod] 
 */
CREATE TABLE ser.[SiteRoleContactMethod](
    [SiteRoleId]              bigint           NOT NULL,
    [LOVContactMethodTypeId]  int              NOT NULL,
    [LOVUsageTypeId]          int              NOT NULL,
    [ContactDetail]           nvarchar(255)    NULL,
    [LOVRecordSourceId]       int              NOT NULL,
    [SCDStartDate]            datetime         NULL,
    [SCDEndDate]              datetime         NULL,
    [SCDActiveFlag]           nchar(1)         NULL,
    [SCDVersion]              smallint         NULL,
    [SCDLOVRecordSourceId]    int              NULL,
    [ETLRunLogId]             int              NULL,
    [PSARowKey]               bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVContactMethodTypeId],[LOVUsageTypeId],[LOVRecordSourceId])
)
/* 
 * TABLE: [SiteRoleTerritory] 
 */
CREATE TABLE ser.[SiteRoleTerritory](
    [SiteRoleId]                 bigint      NOT NULL,
    [LOVSiteRoleTerritorySetId]  int         NOT NULL,
    [LOVTerritoryId]             int         NOT NULL,
    [LOVRecordSourceId]          int         NOT NULL,
    [SCDStartDate]               datetime    NULL,
    [SCDEndDate]                 datetime    NULL,
    [SCDActiveFlag]              nchar(1)    NULL,
    [SCDVersion]                 smallint    NULL,
    [SCDLOVRecordSourceId]       int         NULL,
    [ETLRunLogId]                int         NULL,
    [PSARowKey]                  bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVTerritoryId],[LOVRecordSourceId])
)
/* 
 * TABLE: [SiteRoleProperty] 
 */
CREATE TABLE [ser].[SiteRoleProperty](
    [SiteRoleId]            bigint           NOT NULL,
    [MeasureId]             int              NOT NULL,
    [LOVUOMId]              int              NOT NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  bigint           NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVUOMId],[LOVRecordSourceId])
)
/* 
 * TABLE: [SiteProperty] 
 */
CREATE TABLE [ser].[SiteProperty](
    [SiteId]                bigint           NOT NULL,
    [MeasureId]             int              NOT NULL,
    [LOVUOMId]              int              NOT NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  bigint           NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteId],[LOVUOMId],[LOVRecordSourceId])
)
/* 
 * TABLE: [SiteRoleStatus] 
 */
CREATE TABLE [ser].[SiteRoleStatus](
    [SiteRoleId]              bigint      NOT NULL,
    [LOVSiteRoleStatusSetId]  int         NOT NULL,
    [LOVStatusId]             int         NOT NULL,
    [EffectiveFrom]           datetime    NULL,
    [EffectiveTo]             datetime    NULL,
    [LOVRecordSourceId]       int         NOT NULL,
    [SCDStartDate]            datetime    NULL,
    [SCDEndDate]              datetime    NULL,
    [SCDActiveFlag]           nchar(1)    NULL,
    [SCDVersion]              smallint    NULL,
    [SCDLOVRecordSourceId]    int         NULL,
    [ETLRunLogId]             int         NULL,
    [PSARowKey]               bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVStatusId],[LOVRecordSourceId])
)
/* 
 * TABLE: [SiteRoleIndicator] 
 */
CREATE TABLE [ser].[SiteRoleIndicator](
    [SiteRoleId]            bigint      NOT NULL,
    [LOVIndicatorId]        int         NOT NULL,
    [Value]                 nchar(1)    NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [PSARowKey]             bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVRecordSourceId])
)

/* 
 * TABLE: [SiteRole] 
 */
CREATE TABLE [ser].[SiteRole](
    [SiteRoleId]            bigint          NOT NULL,
    [SiteId]                bigint          NOT NULL,
    [LOVRoleId]             int             NOT NULL,
    [SourceKey]             nvarchar(80)    NULL,
    [SiteRoleName]          nvarchar(80)    NULL,
    [SiteRoleShortName]     nvarchar(20)    NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteId],[SiteRoleId],[LOVRoleId],[LOVRecordSourceId])
)

/* 
 * TABLE: [PostalAddress] 
 */
CREATE TABLE [ser].[PostalAddress](
    [SiteId]                bigint          NOT NULL,
    [LocationName]          nvarchar(80)    NULL,
    [AddressLine1]          nvarchar(80)    NULL,
    [AddressLine2]          nvarchar(80)    NULL,
    [Town]                  nvarchar(80)    NULL,
    [County]                nvarchar(80)    NULL,
    [PostalCode]            nvarchar(10)    NULL,
    [LOVCountryId]          int             NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([SiteId],[LOVCountryId],[LOVRecordSourceId])
)
/* 
 * TABLE: [Site] 
 */
CREATE TABLE [ser].[Site](
    [SiteId]                bigint          NOT NULL,
    [SourceKey]             nvarchar(80)    NULL,
    [SiteName]              nvarchar(80)    NULL,
    [LOVSiteTypeId]         int             NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVSiteTypeId],[LOVRecordSourceId])
)
/* 
 * TABLE: [SiteRoleGroup] 
 */
CREATE TABLE [ser].[SiteRoleGroup](
    [SiteRoleGroupId]        bigint      NOT NULL,
    [SiteRoleId]             bigint      NOT NULL,
    [LOVSiteRoleGroupSetId]  int         NOT NULL,
    [LOVGroupId]             int         NOT NULL,
    [ParentSiteRoleGroupId]  bigint      NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          nchar(1)    NULL,
    [SCDVersion]             smallint    NULL,
    [SCDLOVRecordSourceId]   int         NULL,
    [ETLRunLogId]            int         NULL,
    [PSARowKey]              bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVSiteRoleGroupSetId],[LOVGroupId],[LOVRecordSourceId])
)
/* 
 * TABLE: [PartyRoleSiteRoleRelationship] 
 */
CREATE TABLE ser.[PartyRoleSiteRoleRelationship](
    [PartyRoleId]            bigint      NOT NULL,
    [SiteRoleId]             bigint      NOT NULL,
    [LOVRelationshipTypeId]  int         NOT NULL,
    [EffectiveFrom]          datetime    NULL,
    [EffectiveTo]            datetime    NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          nchar(1)    NULL,
    [SCDVersion]             smallint    NULL,
    [SCDLOVRecordSourceId]   int         NULL,
    [ETLRunLogId]            int         NULL,
    [PSARowKey]              bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([PartyRoleId],[SiteRoleId],[LOVRelationshipTypeId],[LOVRecordSourceId])
)



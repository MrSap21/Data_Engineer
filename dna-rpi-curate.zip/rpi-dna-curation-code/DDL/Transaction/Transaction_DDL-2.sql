/* --- DDL for [lod].[sap_crm_ad_card] --- */

CREATE TABLE [lod].[sap_crm_ad_card]
(
	[account_number] [nvarchar](300) NULL,
	[full_card_number] [nvarchar](300) NULL,
	[card_status_code] [nvarchar](100) NULL,
	[card_type_code] [nvarchar](300) NULL,
	[account_status_code] [nvarchar](300) NULL,
	[account_status_reason_code] [nvarchar](300) NULL,
	[etl_runlog_id] [int] NULL,
	[asset_id] [int] NULL,
	[record_source_id] [int] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [account_number] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

/* --- DDL for [psa].[sap_crm_ad_card] --- */

CREATE TABLE [psa].[sap_crm_ad_card]
(
	[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[account_number] [nvarchar](300) NULL,
	[full_card_number] [nvarchar](300) NULL,
	[card_status_code] [nvarchar](100) NULL,
	[card_type_code] [nvarchar](300) NULL,
	[account_status_code] [nvarchar](300) NULL,
	[account_status_reason_code] [nvarchar](300) NULL,
	[etl_runlog_id] [int] NULL,
	[asset_id] [int] NULL,
	[record_source_id] [int] NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [account_number] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

/* --- SERVE schema for LoyaltyAccountCardStatus --- */

CREATE TABLE [ser].[LoyaltyAccountCardStatus]
(
	[LoyaltyAccountCardId] [bigint] NOT NULL,
	[LOVLoyaltyAccountCardStatusSetId] [int] NOT NULL,
	[LOVStatusId] [int] NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[EffectiveFrom] [datetime] NULL,
	[EffectiveTo] [datetime] NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [char](1) NULL,
	[SCDVersion] [smallint] NULL,
	[ETLRunLogId] [bigint] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [LoyaltyAccountCardId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/************* View : RefLOVSetInfo *************/

CREATE VIEW ser.RefLOVSetInfo
AS SELECT 
r.[LOVId],
r.[LOVSetId],
r.[LOVKey],
r.[LOVName],
r.[LOVDescription],
r.[LOVSequence],
r.[LOVRecordSourceId],
rs.[LOVSetKey],
rs.[LOVSetName],
rs.[LOVSetDescription],
rs.[LOVSetSequence]
FROM ser.RefLOV r
INNER JOIN ser.RefLOVSet rs
ON r.LOVSetId=rs.LOVSetId
AND r.[LOVRecordSourceId]=rs.[LOVSetRecordSourceId]
AND r.SCDActiveFlag='1'
AND rs.SCDActiveFlag='1'
GO

/************* Table : TransactionExecuteMeta *************/

CREATE TABLE [psa].[TransactionExecuteMeta]
(
	[TableName] [varchar](200) NULL,
	[procName] [varchar](200) NULL,
	[StartVal] [bigint] NULL,
	[IncVal] [bigint] NULL,
	[StopVal] [bigint] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


/************* Table : Till *************/

CREATE TABLE [ser].[Till]
(
	[TillId] [bigint] NOT NULL,
	[SourceKey] [nvarchar](80) NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO

/************* Table : Transaction *************/

CREATE TABLE [ser].[Transaction]
(
	[TransactionId] [bigint] NOT NULL,
	[SourceKey] [nvarchar](80) NULL,
	[LOVTransactionTypeId] [int] NOT NULL,
	[SiteRoleId] [bigint] NOT NULL,
	[TransactionDatetime] [datetime] NOT NULL,
	[TillId] [bigint] NULL,
	[TillTransactionNumber] [nvarchar](80) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO


/************* Table : TransactionLineItem *************/


CREATE TABLE [ser].[TransactionLineItem]
(
	[TransactionLineItemId] [bigint] NOT NULL,
	[TransactionId] [bigint] NOT NULL,
	[ProductId] [bigint] NOT NULL,
	[LOVLineItemTypeId] [int] NULL,
	[DealId] [int] NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

/************* Table : TransactionIndicator *************/

CREATE TABLE [ser].[TransactionIndicator]
(
	[TransactionId] [bigint] NOT NULL,
	[LOVIndicatorId] [int] NOT NULL,
	[Value] [nchar](1) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

/************* Table : TransactionLineItemIndicator *************/

CREATE TABLE [ser].[TransactionLineItemIndicator]
(
	[TransactionLineItemId] [bigint] NOT NULL,
	[LOVIndicatorId] [int] NOT NULL,
	[Value] [nchar](1) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionLineItemId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

/************* Table : TransactionLineItemMeasure *************/

CREATE TABLE [ser].[TransactionLineItemMeasure]
(
	[TransactionLineItemMeasureId] [bigint] NOT NULL,
	[TransactionLineItemId] [bigint] NOT NULL,
	[MeasureId] [int] NOT NULL,
	[Value] [nvarchar](255) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionLineItemId] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

/************* Table : Deal *************/

CREATE TABLE [ser].[Deal]
(
	[DealId] [int] NOT NULL,
	[SourceKey] [nvarchar](80) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO

/************* Table : LoyaltyAccount *************/

CREATE TABLE [ser].[LoyaltyAccount]
(
	[LoyaltyAccountId] [bigint] NOT NULL,
	[LOVLoyaltyProgramId] [int] NOT NULL,
	[SourceKey] [nvarchar](300) NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO

/************* Table : LoyaltyAccountCard *************/

CREATE TABLE [ser].[LoyaltyAccountCard]
(
	[LoyaltyAccountCardId] [bigint] NOT NULL,
    [LoyaltyAccountId] [bigint] NOT NULL,
    [LOVCardTypeId] [bigint] NOT NULL,
    [SourceKey] [nvarchar](300) NOT NULL,
    [LOVRecordSourceId] [bigint] NOT NULL,
    [SCDStartDate] [datetime] NULL,
    [SCDEndDate] [datetime] NULL,
    [SCDActiveFlag] [nchar](1) NULL,
    [SCDVersion] [smallint] NULL,
    [SCDLOVRecordSourceId] [int] NULL,
    [ETLRunLogId] [int] NULL,
    [PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO

/************* Table : TransactionLoyaltyAccount *************/

CREATE TABLE [ser].[TransactionLoyaltyAccount]
(
	[TransactionId] [bigint] NOT NULL,
	[LoyaltyAccountId] [bigint] NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO

/************* Table : TransactionLoyaltyAccountCard *************/

CREATE TABLE [ser].[TransactionLoyaltyAccountCard](
    [TransactionId]         bigint      NOT NULL,
    [LoyaltyAccountCardId]  bigint      NOT NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [PSARowKey]             bigint      NULL
)

WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO
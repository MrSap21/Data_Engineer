CREATE TABLE [lod].[cl_crp_customer]
(
	[row_id] [bigint] IDENTITY(1,1) NOT NULL,
    [customer_identifier] [nvarchar](500) NULL,
	[customer_identifier_type] [nvarchar](100) NULL,
	[customer_number] [nvarchar](500) NULL,
	[scheme_id] [nvarchar](100) NULL,
	[gender] [nvarchar](500) NULL,
	[age_band] [nvarchar](100) NULL,
	[join_date] [nvarchar](100) NULL,
	[address_line1] [nvarchar](500) NULL,
	[address_line2] [nvarchar](500) NULL,
	[address_line3] [nvarchar](500) NULL,
	[address_line4] [nvarchar](500) NULL,
	[postal_code] [nvarchar](500) NULL,
	[longitude] [nvarchar](500) NULL,
	[latitude] [nvarchar](500) NULL,
	[date_added] [nvarchar](500) NULL,
    [etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [lod].[cl_crp_item_transaction]
(
	[row_id] [bigint] IDENTITY(1,1) NOT NULL,
    [transaction_key] [nvarchar](80) NULL,
	[till_id] [nvarchar](80) NULL,
	[transaction_date] [nvarchar](25) NULL,
	[transaction_time] [nvarchar](25) NULL,
	[item_code] [nvarchar](80) NULL,
	[units] [nvarchar](255) NULL,
	[tisp] [nvarchar](255) NULL,
	[tesp] [nvarchar](255) NULL,
	[store_number] [nvarchar](80) NULL,
	[customer_identifier] [nvarchar](500) NULL,		
	[customer_identifier_type] [nvarchar](255) NULL,
	[customer_number] [nvarchar](500) NULL,			
	[customer_number_type] [nvarchar](255) NULL,
	[other_customer_id] [nvarchar](500) NULL,		
	[other_customer_id_type] [nvarchar](255) NULL,
	[epos_profit] [nvarchar](255) NULL,
	[discount_applied] [nvarchar](255) NULL,
	[deal_id] [nvarchar](80) NULL,
	[upc] [nvarchar](80) NULL,
	[sales_type] [nvarchar](255) NULL,
	[prescription] [nvarchar](100) NULL,	
	[date_added] [nvarchar](500) NULL,
    [etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
)
GO
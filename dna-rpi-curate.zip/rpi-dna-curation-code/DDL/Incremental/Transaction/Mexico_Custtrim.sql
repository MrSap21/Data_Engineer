CREATE TABLE [psa].[rawmx_transaction_custtrim]
(
	[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[transaction_key] [nvarchar](500) NULL,
	[till_id] [nvarchar](500) NULL,
	[transaction_date] [nvarchar](500) NULL,
	[transaction_time] [nvarchar](500) NULL,
	[store_number] [nvarchar](500) NULL,
	[customer_identifier] [nvarchar](500) NULL,
	[customer_identifier_trimmed] [nvarchar](500) NULL,
	[customer_identifier_type] [nvarchar](500) NULL,
	[customer_number] [nvarchar](500) NULL,
	[customer_number_trimmed] [nvarchar](500) NULL,
	[customer_number_type] [nvarchar](500) NULL,
	[other_customer_id] [nvarchar](500) NULL,
	[other_customer_id_trimmed] [nvarchar](500) NULL,
	[other_customer_id_type] [nvarchar](500) NULL,
	[date_added] [nvarchar](500) NULL,
	[etl_runlog_id] [int] NULL,
	[asset_id] [int] NULL,
	[record_source_id] [int] NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [transaction_key] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

CREATE TABLE [lod].[rawmx_transaction_custtrim]
(
	[transaction_key] [nvarchar](500) NULL,
	[till_id] [nvarchar](500) NULL,
	[transaction_date] [nvarchar](500) NULL,
	[transaction_time] [nvarchar](500) NULL,
	[store_number] [nvarchar](500) NULL,
	[customer_identifier] [nvarchar](500) NULL,
	[customer_identifier_trimmed] [nvarchar](500) NULL,
	[customer_identifier_type] [nvarchar](500) NULL,
	[customer_number] [nvarchar](500) NULL,
	[customer_number_trimmed] [nvarchar](500) NULL,
	[customer_number_type] [nvarchar](500) NULL,
	[other_customer_id] [nvarchar](500) NULL,
	[other_customer_id_trimmed] [nvarchar](500) NULL,
	[other_customer_id_type] [nvarchar](500) NULL,
	[date_added] [nvarchar](500) NULL,
	[etl_runlog_id] [int] NULL,
	[asset_id] [int] NULL,
	[record_source_id] [int] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[TranMexicoTrimMeta]
(
	[row_id] [int] NULL,
	[assetId] [varchar](20) NULL,
	[dateadded] [varchar](20) NULL,
	[feedtype] [varchar](1) NULL,
	[assetstatus] [varchar](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
)
GO
/* 1. Create the table [ser].[TRANSACTIONGROUP] */
CREATE TABLE [ser].[TransactionGroup](
    [TransactionGroupId]        bigint      NOT NULL,
    [TransactionId]             bigint      NOT NULL,
    [LOVTransactionGroupSetId]  int         NOT NULL,
    [LOVGroupId]                int         NOT NULL,
    [ParentTransactionGroupId]  bigint      NULL,
    [LOVRecordSourceId]         int         NOT NULL,
    [SCDStartDate]              datetime    NULL,
    [SCDEndDate]                datetime    NULL,
    [SCDActiveFlag]             nchar(1)    NULL,
    [SCDVersion]                smallint    NULL,
    [SCDLOVRecordSourceId]      int         NULL,
    [ETLRunLogId]               int         NULL,
    [PSARowKey]                 bigint      NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO

/* 2. Add the column LOVUOMId to the table [ser].[TRANSACTIONLINEITEMMEASURE] */
ALTER TABLE [ser].[TRANSACTIONLINEITEMMEASURE]
ADD LOVUOMId int;
GO
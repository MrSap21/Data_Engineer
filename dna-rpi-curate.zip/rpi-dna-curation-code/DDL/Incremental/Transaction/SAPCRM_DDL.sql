/* --- LOD schema for SAP_CRM_MEMBERSHIP_CARD --- */

CREATE TABLE [lod].[UK_AW_MEMBERSHIP_CARD]
(
	[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[record_type] [nvarchar](80) NULL,
	[CARD_NUMBER] [nvarchar](500) NULL,
	[CHECK_DIGIT] [nvarchar](80) NULL,
	[STATUS_CODE] [nvarchar](80) NULL,
	[CUSTOMER_NUMBER] [nvarchar](500) NULL,
	[DESP_TO_CUST_DATE] [nvarchar](80) NULL,
	[CFA_ID] [nvarchar](80) NULL,
	[ACCOUNT_NUMBER] [nvarchar](500) NULL,
	[PROD_BATCH_NUMBER] [nvarchar](80) NULL,
	[GEOGRAPHY_CODE] [nvarchar](80) NULL,
	[ADVCD_TMNTD_TMSTMP] [nvarchar](80) NULL,
	[CARD_TYPE_CODE] [nvarchar](80) NULL,
	[CARD_ACTIVATION_DATE] [nvarchar](80) NULL,
	[CARD_EXPIRY_DATE] [nvarchar](80) NULL,
	[CHANGE_USER] [nvarchar](80) NULL,
	[CREATED_BY_CHANNEL] [nvarchar](80) NULL,
	[UPDATED_BY_CHANNEL] [nvarchar](80) NULL,
	[etl_runlog_id] [int] NULL,
	[asset_id] [int] NULL,
	[record_source_id] [int] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [CARD_NUMBER] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO

/* --- PSA schema for SAP_CRM_MEMBERSHIP_CARD --- */

CREATE TABLE [psa].[UK_AW_MEMBERSHIP_CARD]
(
	[row_id] [bigint] NOT NULL,
	[record_type] [nvarchar](80) NULL,
	[CARD_NUMBER] [nvarchar](500) NULL,
	[CHECK_DIGIT] [nvarchar](80) NULL,
	[STATUS_CODE] [nvarchar](80) NULL,
	[CUSTOMER_NUMBER] [nvarchar](500) NULL,
	[DESP_TO_CUST_DATE] [nvarchar](80) NULL,
	[CFA_ID] [nvarchar](80) NULL,
	[ACCOUNT_NUMBER] [nvarchar](500) NULL,
	[PROD_BATCH_NUMBER] [nvarchar](80) NULL,
	[GEOGRAPHY_CODE] [nvarchar](80) NULL,
	[ADVCD_TMNTD_TMSTMP] [nvarchar](80) NULL,
	[CARD_TYPE_CODE] [nvarchar](80) NULL,
	[CARD_ACTIVATION_DATE] [nvarchar](80) NULL,
	[CARD_EXPIRY_DATE] [nvarchar](80) NULL,
	[CHANGE_USER] [nvarchar](80) NULL,
	[CREATED_BY_CHANNEL] [nvarchar](80) NULL,
	[UPDATED_BY_CHANNEL] [nvarchar](80) NULL,
	[etl_runlog_id] [int] NULL,
	[asset_id] [int] NULL,
	[record_source_id] [int] NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = HASH ( [CARD_NUMBER] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO
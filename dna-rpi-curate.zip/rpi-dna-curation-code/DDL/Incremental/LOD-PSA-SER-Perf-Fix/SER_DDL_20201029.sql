CREATE TABLE [ser].[TransactionGroup_20201029]
WITH
(
DISTRIBUTION = HASH ( [TransactionGroupId] ),
CLUSTERED COLUMNSTORE INDEX ORDER ([TransactionId],[LOVTransactionGroupSetId],[LOVRecordSourceId])
)
AS SELECT * from [ser].TransactionGroup;

DROP TABLE [ser].TransactionGroup;

Rename object [ser].[TransactionGroup_20201029] to TransactionGroup;
--**************************************************************************************
CREATE TABLE [ser].[LoyaltyAccountCard_20201030]
WITH
(
DISTRIBUTION = HASH ( [LoyaltyAccountCardId] ),
CLUSTERED COLUMNSTORE INDEX 
)
AS SELECT * from [ser].LoyaltyAccountCard;

DROP TABLE [ser].LoyaltyAccountCard;

RENAME  OBJECT  ser.LoyaltyAccountCard_20201030 to LoyaltyAccountCard;

--**************************************************************************************

CREATE TABLE [ser].[LoyaltyAccountCardStatus_20201030]
WITH
(
DISTRIBUTION = HASH ( [LoyaltyAccountCardId] ),
CLUSTERED COLUMNSTORE INDEX
)
AS SELECT * from [ser].LoyaltyAccountCardStatus;

DROP TABLE [ser].LoyaltyAccountCardStatus;

RENAME  OBJECT  ser.LoyaltyAccountCardStatus_20201030 to LoyaltyAccountCardStatus
Rename object lod.rawuk_btc_transaction_anon_p to rawuk_btc_transaction_anon_p_20201022;
CREATE TABLE [lod].[rawuk_btc_transaction_anon_p]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].rawuk_btc_transaction_anon_p_20201022 where 1=2;
DROP TABLE [lod].rawuk_btc_transaction_anon_p_20201022;

--***********************************************************************

Rename object lod.rawuk_btc_transaction_card_p to rawuk_btc_transaction_card_p_20201022;
CREATE TABLE [lod].[rawuk_btc_transaction_card_p]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].rawuk_btc_transaction_card_p_20201022 where 1=2;
DROP TABLE [lod].rawuk_btc_transaction_card_p_20201022;

--***********************************************************************

Rename object lod.rawuk_btc_transaction_line_anon_p to rawuk_btc_transaction_line_anon_p_20201022;
CREATE TABLE [lod].[rawuk_btc_transaction_line_anon_p]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].rawuk_btc_transaction_line_anon_p_20201022 where 1=2;
DROP TABLE [lod].rawuk_btc_transaction_line_anon_p_20201022;

--***********************************************************************

Rename object lod.rawuk_btc_transaction_line_card_p to rawuk_btc_transaction_line_card_p_20201022;
CREATE TABLE [lod].[rawuk_btc_transaction_line_card_p]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].rawuk_btc_transaction_line_card_p_20201022 where 1=2;
DROP TABLE [lod].rawuk_btc_transaction_line_card_p_20201022;

--***********************************************************************

Rename object lod.rawuk_sap_articlesales to rawuk_sap_articlesales_20201022;
CREATE TABLE [lod].[rawuk_sap_articlesales]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].rawuk_sap_articlesales_20201022 where 1=2;
DROP TABLE [lod].rawuk_sap_articlesales_20201022;

--***********************************************************************

Rename object lod.rawuk_sap_crp_distribution to rawuk_sap_crp_distribution_20201022;
CREATE TABLE [lod].[rawuk_sap_crp_distribution]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].rawuk_sap_crp_distribution_20201022 where 1=2;
DROP TABLE [lod].rawuk_sap_crp_distribution_20201022;

--***********************************************************************

Rename object lod.rawuk_sap_crp_productivity to rawuk_sap_crp_productivity_20201022;
CREATE TABLE [lod].[rawuk_sap_crp_productivity]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].rawuk_sap_crp_productivity_20201022 where 1=2;
DROP TABLE [lod].rawuk_sap_crp_productivity_20201022;

--***********************************************************************

Rename object lod.rawuk_sap_storearticlesales to rawuk_sap_storearticlesales_20201022;
CREATE TABLE [lod].[rawuk_sap_storearticlesales]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].rawuk_sap_storearticlesales_20201022 where 1=2;
DROP TABLE [lod].rawuk_sap_storearticlesales_20201022;

--***********************************************************************

Rename object lod.sap_crm_ad_card to sap_crm_ad_card_20201022;
CREATE TABLE [lod].[sap_crm_ad_card]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].sap_crm_ad_card_20201022 where 1=2;
DROP TABLE [lod].sap_crm_ad_card_20201022;

--***********************************************************************

Rename object lod.th_crp_customer to th_crp_customer_20201022;
CREATE TABLE [lod].[th_crp_customer]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].th_crp_customer_20201022 where 1=2;
DROP TABLE [lod].th_crp_customer_20201022;

--***********************************************************************


Rename object lod.th_crp_item_transaction to th_crp_item_transaction_20201022;
CREATE TABLE [lod].[th_crp_item_transaction]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].th_crp_item_transaction_20201022 where 1=2;
DROP TABLE [lod].th_crp_item_transaction_20201022;

--***********************************************************************

Rename object lod.th_crp_layout_performance to th_crp_layout_performance_20201022;
CREATE TABLE [lod].[th_crp_layout_performance]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].th_crp_layout_performance_20201022 where 1=2;
DROP TABLE [lod].th_crp_layout_performance_20201022;

--***********************************************************************

Rename object lod.th_crp_merchandise to th_crp_merchandise_20201022;
CREATE TABLE [lod].[th_crp_merchandise]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].th_crp_merchandise_20201022 where 1=2;
DROP TABLE [lod].th_crp_merchandise_20201022;

--***********************************************************************

Rename object lod.th_crp_planogram to th_crp_planogram_20201022;
CREATE TABLE [lod].[th_crp_planogram]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].th_crp_planogram_20201022 where 1=2;
DROP TABLE [lod].th_crp_planogram_20201022;

--***********************************************************************

Rename object lod.th_crp_product to th_crp_product_20201022;
CREATE TABLE [lod].[th_crp_product]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].th_crp_product_20201022 where 1=2;
DROP TABLE [lod].th_crp_product_20201022;

--***********************************************************************

Rename object lod.th_crp_store to th_crp_store_20201022;
CREATE TABLE [lod].[th_crp_store]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].th_crp_store_20201022 where 1=2;
DROP TABLE [lod].th_crp_store_20201022;

--***********************************************************************


Rename object lod.th_crp_store_trial_analysis to th_crp_store_trial_analysis_20201022;
CREATE TABLE [lod].[th_crp_store_trial_analysis]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].th_crp_store_trial_analysis_20201022 where 1=2;
DROP TABLE [lod].th_crp_store_trial_analysis_20201022;

--***********************************************************************

Rename object lod.uk_abacus_header to uk_abacus_header_20201022;
CREATE TABLE [lod].[uk_abacus_header]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].uk_abacus_header_20201022 where 1=2;
DROP TABLE [lod].uk_abacus_header_20201022;

--***********************************************************************

Rename object lod.uk_abacus_item to uk_abacus_item_20201022;
CREATE TABLE [lod].[uk_abacus_item]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].uk_abacus_item_20201022 where 1=2;
DROP TABLE [lod].uk_abacus_item_20201022;

--***********************************************************************

Rename object lod.UK_AW_MEMBERSHIP_CARD to UK_AW_MEMBERSHIP_CARD_20201022;
CREATE TABLE [lod].[UK_AW_MEMBERSHIP_CARD]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].UK_AW_MEMBERSHIP_CARD_20201022 where 1=2;
DROP TABLE [lod].UK_AW_MEMBERSHIP_CARD_20201022;

--***********************************************************************
Rename object lod.uk_btc_promotion_deal to uk_btc_promotion_deal_20201022;
CREATE TABLE [lod].[uk_btc_promotion_deal]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, HEAP
 )
 AS SELECT * from [lod].uk_btc_promotion_deal_20201022 where 1=2;
DROP TABLE [lod].uk_btc_promotion_deal_20201022;

--***********************************************************************

Rename object lod.rawuk_btc_deal_qualified_anon to rawuk_btc_deal_qualified_anon_20201022;

CREATE TABLE [lod].[rawuk_btc_deal_qualified_anon]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_deal_qualified_anon_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_deal_qualified_anon_20201022;
--*****************************************
Rename object lod.rawuk_btc_deal_qualified_card to rawuk_btc_deal_qualified_card_20201022;

CREATE TABLE [lod].[rawuk_btc_deal_qualified_card]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_deal_qualified_card_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_deal_qualified_card_20201022;
--*****************************************
Rename object lod.rawuk_btc_ix_spc_fixture to rawuk_btc_ix_spc_fixture_20201022;

CREATE TABLE [lod].[rawuk_btc_ix_spc_fixture]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_ix_spc_fixture_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_ix_spc_fixture_20201022;
--*****************************************
Rename object lod.rawuk_btc_ix_spc_planogram to rawuk_btc_ix_spc_planogram_20201022;

CREATE TABLE [lod].[rawuk_btc_ix_spc_planogram]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_ix_spc_planogram_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_ix_spc_planogram_20201022;
--*****************************************
Rename object lod.rawuk_btc_ix_spc_position to rawuk_btc_ix_spc_position_20201022;

CREATE TABLE [lod].[rawuk_btc_ix_spc_position]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_ix_spc_position_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_ix_spc_position_20201022;
--*****************************************
Rename object lod.rawuk_btc_ix_spc_product to rawuk_btc_ix_spc_product_20201022;

CREATE TABLE [lod].[rawuk_btc_ix_spc_product]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_ix_spc_product_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_ix_spc_product_20201022;
--*****************************************
Rename object lod.rawuk_btc_mdm_item to rawuk_btc_mdm_item_20201022;

CREATE TABLE [lod].[rawuk_btc_mdm_item]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_mdm_item_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_mdm_item_20201022;
--*****************************************
Rename object lod.rawuk_btc_mdm_item_hierarchy1 to rawuk_btc_mdm_item_hierarchy1_20201022;

CREATE TABLE [lod].[rawuk_btc_mdm_item_hierarchy1]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_mdm_item_hierarchy1_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_mdm_item_hierarchy1_20201022;
--*****************************************
Rename object lod.rawuk_btc_mdm_item_hierarchy2 to rawuk_btc_mdm_item_hierarchy2_20201022;

CREATE TABLE [lod].[rawuk_btc_mdm_item_hierarchy2]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_mdm_item_hierarchy2_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_mdm_item_hierarchy2_20201022;
--*****************************************
Rename object lod.rawuk_btc_mdm_item_hierarchy3 to rawuk_btc_mdm_item_hierarchy3_20201022;

CREATE TABLE [lod].[rawuk_btc_mdm_item_hierarchy3]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_mdm_item_hierarchy3_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_mdm_item_hierarchy3_20201022;
--*****************************************
Rename object lod.rawuk_btc_mdm_item_hierarchy4 to rawuk_btc_mdm_item_hierarchy4_20201022;

CREATE TABLE [lod].[rawuk_btc_mdm_item_hierarchy4]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_mdm_item_hierarchy4_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_mdm_item_hierarchy4_20201022;
--*****************************************
Rename object lod.rawuk_btc_mdm_item_hierarchy5 to rawuk_btc_mdm_item_hierarchy5_20201022;

CREATE TABLE [lod].[rawuk_btc_mdm_item_hierarchy5]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_mdm_item_hierarchy5_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_mdm_item_hierarchy5_20201022;
--*****************************************
Rename object lod.rawuk_btc_mdm_item_hierarchy6 to rawuk_btc_mdm_item_hierarchy6_20201022;

CREATE TABLE [lod].[rawuk_btc_mdm_item_hierarchy6]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_mdm_item_hierarchy6_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_mdm_item_hierarchy6_20201022;
--*****************************************
Rename object lod.rawuk_btc_mdm_store to rawuk_btc_mdm_store_20201022;

CREATE TABLE [lod].[rawuk_btc_mdm_store]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_mdm_store_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_mdm_store_20201022;
--*****************************************
Rename object lod.rawuk_btc_promotion_deal to rawuk_btc_promotion_deal_20201022;

CREATE TABLE [lod].[rawuk_btc_promotion_deal]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawuk_btc_promotion_deal_20201022 where 1=2;

DROP TABLE [lod].rawuk_btc_promotion_deal_20201022;

--*****************************************
Rename object lod.cl_crp_customer to cl_crp_customer_20201022;

CREATE TABLE [lod].[cl_crp_customer]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].cl_crp_customer_20201022 where 1=2;
DROP TABLE [lod].cl_crp_customer_20201022;

--*****************************************
Rename object lod.cl_crp_item_transaction to cl_crp_item_transaction_20201022;

CREATE TABLE [lod].[cl_crp_item_transaction]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].cl_crp_item_transaction_20201022 where 1=2;
DROP TABLE [lod].cl_crp_item_transaction_20201022;

--*****************************************
Rename object lod.cl_crp_layout_performance to cl_crp_layout_performance_20201022;

CREATE TABLE [lod].[cl_crp_layout_performance]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].cl_crp_layout_performance_20201022 where 1=2;
DROP TABLE [lod].cl_crp_layout_performance_20201022;

--*****************************************
Rename object lod.cl_crp_merchandise to cl_crp_merchandise_20201022;

CREATE TABLE [lod].[cl_crp_merchandise]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].cl_crp_merchandise_20201022 where 1=2;
DROP TABLE [lod].cl_crp_merchandise_20201022;
--*****************************************

Rename object lod.cl_crp_planogram to cl_crp_planogram_20201022;

CREATE TABLE [lod].[cl_crp_planogram]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].cl_crp_planogram_20201022 where 1=2;
DROP TABLE [lod].cl_crp_planogram_20201022;
--*****************************************

Rename object lod.cl_crp_product to cl_crp_product_20201022;

CREATE TABLE [lod].[cl_crp_product]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].cl_crp_product_20201022 where 1=2;
DROP TABLE [lod].cl_crp_product_20201022;

--*****************************************
Rename object lod.cl_crp_store to cl_crp_store_20201022;

CREATE TABLE [lod].[cl_crp_store]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].cl_crp_store_20201022 where 1=2;
DROP TABLE [lod].cl_crp_store_20201022;
--*****************************************

Rename object lod.cl_crp_store_trial_analysis to cl_crp_store_trial_analysis_20201022;

CREATE TABLE [lod].[cl_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].cl_crp_store_trial_analysis_20201022 where 1=2;
DROP TABLE [lod].cl_crp_store_trial_analysis_20201022;
--*****************************************

Rename object lod.mx_crp_customer to mx_crp_customer_20201022;

CREATE TABLE [lod].[mx_crp_customer]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].mx_crp_customer_20201022 where 1=2;
DROP TABLE [lod].mx_crp_customer_20201022;

--*****************************************

Rename object lod.mx_crp_item_transaction to mx_crp_item_transaction_20201022;

CREATE TABLE [lod].[mx_crp_item_transaction]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].mx_crp_item_transaction_20201022 where 1=2;
DROP TABLE [lod].mx_crp_item_transaction_20201022;

--*****************************************

Rename object lod.mx_crp_layout_performance to mx_crp_layout_performance_20201022;

CREATE TABLE [lod].[mx_crp_layout_performance]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].mx_crp_layout_performance_20201022 where 1=2;
DROP TABLE [lod].mx_crp_layout_performance_20201022;

--*****************************************

Rename object lod.mx_crp_merchandise to mx_crp_merchandise_20201022;

CREATE TABLE [lod].[mx_crp_merchandise]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].mx_crp_merchandise_20201022 where 1=2;
DROP TABLE [lod].mx_crp_merchandise_20201022;

--*****************************************

Rename object lod.mx_crp_planogram to mx_crp_planogram_20201022;

CREATE TABLE [lod].[mx_crp_planogram]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].mx_crp_planogram_20201022 where 1=2;
DROP TABLE [lod].mx_crp_planogram_20201022;
--*****************************************

Rename object lod.mx_crp_product to mx_crp_product_20201022;

CREATE TABLE [lod].[mx_crp_product]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].mx_crp_product_20201022 where 1=2;
DROP TABLE [lod].mx_crp_product_20201022;
--*****************************************

Rename object lod.mx_crp_store to mx_crp_store_20201022;

CREATE TABLE [lod].[mx_crp_store]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].mx_crp_store_20201022 where 1=2;
DROP TABLE [lod].mx_crp_store_20201022;
--*****************************************

Rename object lod.mx_crp_store_trial_analysis to mx_crp_store_trial_analysis_20201022;

CREATE TABLE [lod].[mx_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].mx_crp_store_trial_analysis_20201022 where 1=2;
DROP TABLE [lod].mx_crp_store_trial_analysis_20201022;

--*****************************************

Rename object lod.no_crp_customer to no_crp_customer_20201022;

CREATE TABLE [lod].[no_crp_customer]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].no_crp_customer_20201022 where 1=2;
DROP TABLE [lod].no_crp_customer_20201022;

--*****************************************

Rename object lod.no_crp_item_transaction to no_crp_item_transaction_20201022;

CREATE TABLE [lod].[no_crp_item_transaction]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].no_crp_item_transaction_20201022 where 1=2;
DROP TABLE [lod].no_crp_item_transaction_20201022;

--*****************************************

Rename object lod.no_crp_layout_performance to no_crp_layout_performance_20201022;

CREATE TABLE [lod].[no_crp_layout_performance]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].no_crp_layout_performance_20201022 where 1=2;
DROP TABLE [lod].no_crp_layout_performance_20201022;
--*****************************************

Rename object lod.no_crp_merchandise to no_crp_merchandise_20201022;

CREATE TABLE [lod].[no_crp_merchandise]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].no_crp_merchandise_20201022 where 1=2;
DROP TABLE [lod].no_crp_merchandise_20201022;
--*****************************************

Rename object lod.no_crp_planogram to no_crp_planogram_20201022;

CREATE TABLE [lod].[no_crp_planogram]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].no_crp_planogram_20201022 where 1=2;
DROP TABLE [lod].no_crp_planogram_20201022;
--*****************************************

Rename object lod.no_crp_product to no_crp_product_20201022;

CREATE TABLE [lod].[no_crp_product]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].no_crp_product_20201022 where 1=2;
DROP TABLE [lod].no_crp_product_20201022;
--*****************************************

Rename object lod.no_crp_store to no_crp_store_20201022;

CREATE TABLE [lod].[no_crp_store]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].no_crp_store_20201022 where 1=2;
DROP TABLE [lod].no_crp_store_20201022;
--*****************************************

Rename object lod.no_crp_store_trial_analysis to no_crp_store_trial_analysis_20201022;

CREATE TABLE [lod].[no_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].no_crp_store_trial_analysis_20201022 where 1=2;
DROP TABLE [lod].no_crp_store_trial_analysis_20201022;

--*****************************************

Rename object lod.rawcl_crp_customer  to rawcl_crp_customer_20201022;
CREATE TABLE [lod].[rawcl_crp_customer]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawcl_crp_customer_20201022 where 1=2;

DROP TABLE [lod].rawcl_crp_customer_20201022;

--*****************************************
Rename object lod.rawcl_crp_merchandise  to rawcl_crp_merchandise_20201022;
CREATE TABLE [lod].[rawcl_crp_merchandise]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawcl_crp_merchandise_20201022 where 1=2;

DROP TABLE [lod].rawcl_crp_merchandise_20201022;

--*****************************************

Rename object lod.rawcl_crp_planogram  to rawcl_crp_planogram_20201022;

CREATE TABLE [lod].[rawcl_crp_planogram]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawcl_crp_planogram_20201022 where 1=2;

DROP TABLE [lod].rawcl_crp_planogram_20201022;


--*****************************************

Rename object lod.rawcl_crp_product  to rawcl_crp_product_20201022;
CREATE TABLE [lod].[rawcl_crp_product]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawcl_crp_product_20201022 where 1=2;

DROP TABLE [lod].rawcl_crp_product_20201022;

--*****************************************

Rename object lod.rawcl_crp_store  to rawcl_crp_store_20201022;
CREATE TABLE [lod].[rawcl_crp_store]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawcl_crp_store_20201022 where 1=2;

DROP TABLE [lod].rawcl_crp_store_20201022;

--*****************************************

Rename object lod.rawmx_crp_merchandise  to rawmx_crp_merchandise_20201022;
CREATE TABLE [lod].[rawmx_crp_merchandise]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawmx_crp_merchandise_20201022 where 1=2;

DROP TABLE [lod].rawmx_crp_merchandise_20201022;

--*****************************************

Rename object lod.rawmx_crp_product  to rawmx_crp_product_20201022;
CREATE TABLE [lod].[rawmx_crp_product]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawmx_crp_product_20201022 where 1=2;

DROP TABLE [lod].rawmx_crp_product_20201022;
--*****************************************

Rename object lod.rawmx_crp_store  to rawmx_crp_store_20201022;
CREATE TABLE [lod].[rawmx_crp_store]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawmx_crp_store_20201022 where 1=2;

DROP TABLE [lod].rawmx_crp_store_20201022;
--*****************************************

Rename object lod.rawno_crp_customer  to rawno_crp_customer_20201022;
CREATE TABLE [lod].[rawno_crp_customer]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawno_crp_customer_20201022 where 1=2;

DROP TABLE [lod].rawno_crp_customer_20201022;

--*****************************************

Rename object lod.rawno_crp_merchandise  to rawno_crp_merchandise_20201022;
CREATE TABLE [lod].[rawno_crp_merchandise]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawno_crp_merchandise_20201022 where 1=2;

DROP TABLE [lod].rawno_crp_merchandise_20201022;

--*****************************************

Rename object lod.rawno_crp_product  to rawno_crp_product_20201022;
CREATE TABLE [lod].[rawno_crp_product]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawno_crp_product_20201022 where 1=2;

DROP TABLE [lod].rawno_crp_product_20201022;

--*****************************************


Rename object lod.rawno_crp_store  to rawno_crp_store_20201022;
CREATE TABLE [lod].[rawno_crp_store]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawno_crp_store_20201022 where 1=2;

DROP TABLE [lod].rawno_crp_store_20201022;
--*****************************************
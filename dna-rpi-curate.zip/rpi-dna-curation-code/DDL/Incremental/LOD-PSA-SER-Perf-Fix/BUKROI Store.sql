RENAME OBJECT [ser].[SiteRoleGroup] to SiteRoleGroup_20201008;

CREATE TABLE [ser].[SiteRoleGroup]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
      [SiteRoleGroupId]
      ,[SiteRoleId]
      ,[LOVSiteRoleGroupSetId]
      ,[LOVGroupId]
      ,[ParentSiteRoleGroupId]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[serRowKey]
FROM [ser].[SiteRoleGroup_20201008];

update statistics ser.SiteRoleGroup;
--------------------------------------------------------------
RENAME OBJECT [ser].[SiteRoleProperty] to SiteRoleProperty_20201008;

CREATE TABLE [ser].[SiteRoleProperty]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
      [SiteRoleId]
      ,[MeasureId]
      ,[LOVUOMId]
      ,[Value]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[serRowKey]
FROM [ser].[SiteRoleProperty_20201008];

update statistics ser.SiteRoleProperty;
-----------------------------------------------------------------
RENAME OBJECT [ser].[SiteRoleTerritory] to SiteRoleTerritory_20201008;

CREATE TABLE [ser].[SiteRoleTerritory]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
      [SiteRoleId]
      ,[LOVSiteRoleTerritorySetId]
      ,[LOVTerritoryId]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[serRowKey]
FROM [ser].[SiteRoleTerritory_20201008];

update statistics ser.SiteRoleTerritory;
------------------------------------------------------------------
RENAME OBJECT [ser].[SiteRoleContactMethod] to SiteRoleContactMethod_20201008;

CREATE TABLE [ser].[SiteRoleContactMethod]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
      [SiteRoleId]
      ,[LOVSiteRoleTerritorySetId]
      ,[LOVTerritoryId]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[serRowKey]
FROM [ser].[SiteRoleContactMethod_20201008];

update statistics ser.SiteRoleContactMethod;
-----------------------------------------------------------------------
RENAME OBJECT [ser].[SiteProperty] to SiteProperty_20201008;

CREATE TABLE [ser].[SiteProperty]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
      [SiteId]
      ,[MeasureId]
      ,[LOVUOMId]
      ,[Value]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[serRowKey]
FROM [ser].[SiteProperty_20201008];

update statistics ser.SiteProperty;
-----------------------------------------------------------------------
RENAME OBJECT [ser].[PartyRoleSiteRoleRelationship] to PartyRoleSiteRoleRelationship_20201008;

CREATE TABLE [ser].[PartyRoleSiteRoleRelationship]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
      [PartyRoleId]
      ,[SiteRoleId]
      ,[LOVRelationshipTypeId]
      ,[EffectiveFrom]
      ,[EffectiveTo]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[serRowKey]
FROM [ser].[PartyRoleSiteRoleRelationship_20201008];

update statistics ser.SiteRoleContactMethod;
-----------------------------------------------------------------------
RENAME OBJECT [ser].[Reflov] to Reflov_20201008;

CREATE TABLE [ser].[Reflov]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
      [LOVId]
      ,[LOVSetId]
      ,[LOVKey]
      ,[LOVName]
      ,[LOVDescription]
      ,[LOVSequence]
      ,[LOVRecordSourceId]
      ,[DTCreated]
      ,[UserCreated]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
FROM [ser].[Reflov_20201008];

update statistics ser.Reflov;
-----------------------------------------------------------------------
RENAME OBJECT [ser].[Reflovset] to Reflovset_20201008;

CREATE TABLE [ser].[Reflovset]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
      [LOVSetId]
      ,[LOVSetKey]
      ,[LOVSetName]
      ,[LOVSetDescription]
      ,[LOVSetSequence]
      ,[LOVSetRecordSourceId]
      ,[DTCreated]
      ,[UserCreated]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
FROM [ser].[Reflovset_20201008];

update statistics ser.Reflovset;
-----------------------------------------------------------------------
Rename OBJECT [ser].[Party] to Party_20201008;

CREATE TABLE [ser].[Party]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM [ser].[Party_20201008];

update statistics ser.Party;
----------------------------------------------
Rename OBJECT [ser].[PartyRole] to PartyRole_20201008;

CREATE TABLE [ser].[PartyRole]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM [ser].[PartyRole_20201008];

update statistics ser.PartyRole;
----------------------------------------------
DROP TABLE [lod].[uk_btc_mdm_store];
CREATE TABLE [lod].[uk_btc_mdm_store]
(
  [row_id] [bigint] IDENTITY(1,1) NOT NULL,
  [STORE_NUMBER] [nvarchar](80) NULL,
  [STORE_NAME] [nvarchar](80) NULL,
  [LOCATION_NAME] [nvarchar](100) NULL,
  [LOCATION_TYPE] [nvarchar](100) NULL,
  [SALES_ORGANISATION] [nvarchar](80) NULL,
  [DISTRIBUTION_CHANNEL] [nvarchar](255) NULL,
  [COMPANY_NAME] [nvarchar](80) NULL,
  [STORE_ADDRESS_LINE_1] [nvarchar](80) NULL,
  [STORE_ADDRESS_LINE_2] [nvarchar](80) NULL,
  [STORE_TOWN] [nvarchar](80) NULL,
  [STORE_COUNTY] [nvarchar](80) NULL,
  [POSTCODE] [nvarchar](10) NULL,
  [DIVISION_NUMBER] [nvarchar](10) NULL,
  [DIVISION_NAME] [nvarchar](100) NULL,
  [REGION_NUMBER] [nvarchar](10) NULL,
  [REGION_NAME] [nvarchar](100) NULL,
  [AREA_NUMBER] [nvarchar](255) NULL,
  [AREA_NAME] [nvarchar](100) NULL,
  [COUNTRY_CODE] [nvarchar](255) NULL,
  [COUNTRY_DESCRIPTION] [nvarchar](100) NULL,
  [CURRENCY_CODE] [nvarchar](5) NULL,
  [STORE_OPENING_DATE] [nvarchar](25) NULL,
  [STORE_CLOSURE_DATE] [nvarchar](25) NULL,
  [STORE_OPEN_STATUS] [nvarchar](255) NULL,
  [TRADING_FORMAT] [nvarchar](255) NULL,
  [TYPE_OF_STORE_DESCRIPTION] [nvarchar](255) NULL,
  [SAG] [nvarchar](255) NULL,
  [MINI_SAG] [nvarchar](255) NULL,
  [PRICE_BAND_CODE] [nvarchar](255) NULL,
  [PRICE_BAND_DESCRIPTION] [nvarchar](100) NULL,
  [VAT_FREE_FLAG] [nvarchar](1) NULL,
  [STORE_TOTAL_SALES_AREA] [nvarchar](255) NULL,
  [NUMBER_OF_FLOORS] [nvarchar](255) NULL,
  [NON_DISPENSING_SALES_AREA] [nvarchar](255) NULL,
  [BABY_CHANGING_ROOM_AREA] [nvarchar](255) NULL,
  [CUSTOMER_TOILETS_AREA] [nvarchar](255) NULL,
  [INTERVENTION_END_DATE] [nvarchar](25) NULL,
  [INTERVENTION_START_DATE] [nvarchar](25) NULL,
  [NON_LFL_REASON_CODE] [nvarchar](255) NULL,
  [NON_LFL_REASON_DESCRIPTION] [nvarchar](100) NULL,
  [PHARMACY_REGISTRATION_STATUS] [nvarchar](255) NULL,
  [PRIMARY_CARE_ORGANISATION_DESCRIPTION] [nvarchar](80) NULL,
  [NAME_OF_HEALTH_AUTHORITY] [nvarchar](80) NULL,
  [Z_GRID_REFERENCE_EASTING] [nvarchar](255) NULL,
  [Z_GRID_REFERENCE_NORTHING] [nvarchar](255) NULL,
  [Z_GRID_REFERENCE_LATITUDE] [nvarchar](255) NULL,
  [Z_GRID_REFERENCE_LONGITUDE] [nvarchar](255) NULL,
  [STORE_SHORT_NAME] [nvarchar](20) NULL,
  [TELEPHONE_NUMBER] [nvarchar](255) NULL,
  [BENCHMARK_GROUP] [nvarchar](255) NULL,
  [HEALTH_CLINIC_AREA] [nvarchar](255) NULL,
  [OPTICANS_OFF_SALES_AREA] [nvarchar](255) NULL,
  [OPTICANS_ON_SALES_AREA] [nvarchar](255) NULL,
  [PHARMACY_CONSULTATION_AREA] [nvarchar](255) NULL,
  [PHOTOLAB_OFF_SALES_AREA] [nvarchar](255) NULL,
  [PHOTOLAB_ON_SALES_AREA] [nvarchar](255) NULL,
  [WAITROSE_FOOD_OFFER_TYPE_CODE] [nvarchar](4) NULL,
  [WAITROSE_FOOD_OFFER_TYPE_DESCRIPTION] [nvarchar](100) NULL,
  [MIDNIGHT_PHARMACY] [nvarchar](1) NULL,
  [NHS_CONTRACT_FLAG] [nvarchar](1) NULL,
  [NHS_MARKET] [nvarchar](255) NULL,
  [MDS_ROOM_FLAG] [nvarchar](1) NULL,
  [etl_runlog_id] [int] NULL,
  [asset_id] [int] NULL,
  [record_source_id] [int] NULL
)
WITH
(
  DISTRIBUTION = ROUND_ROBIN,
  HEAP
)



--****************************************************************************


RENAME OBJECT [psa].[uk_btc_mdm_store] to uk_btc_mdm_store_20201008;

CREATE TABLE [psa].[uk_btc_mdm_store]
WITH
(
	DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
		[row_id]
      ,[STORE_NUMBER]
      ,[STORE_NAME]
      ,[LOCATION_NAME]
      ,[LOCATION_TYPE]
      ,[SALES_ORGANISATION]
      ,[DISTRIBUTION_CHANNEL]
      ,[COMPANY_NAME]
      ,[STORE_ADDRESS_LINE_1]
      ,[STORE_ADDRESS_LINE_2]
      ,[STORE_TOWN]
      ,[STORE_COUNTY]
      ,[POSTCODE]
      ,[DIVISION_NUMBER]
      ,[DIVISION_NAME]
      ,[REGION_NUMBER]
      ,[REGION_NAME]
      ,[AREA_NUMBER]
      ,[AREA_NAME]
      ,[COUNTRY_CODE]
      ,[COUNTRY_DESCRIPTION]
      ,[CURRENCY_CODE]
      ,[STORE_OPENING_DATE]
      ,[STORE_CLOSURE_DATE]
      ,[STORE_OPEN_STATUS]
      ,[TRADING_FORMAT]
      ,[TYPE_OF_STORE_DESCRIPTION]
      ,[SAG]
      ,[MINI_SAG]
      ,[PRICE_BAND_CODE]
      ,[PRICE_BAND_DESCRIPTION]
      ,[VAT_FREE_FLAG]
      ,[STORE_TOTAL_SALES_AREA]
      ,[NUMBER_OF_FLOORS]
      ,[NON_DISPENSING_SALES_AREA]
      ,[BABY_CHANGING_ROOM_AREA]
      ,[CUSTOMER_TOILETS_AREA]
      ,[INTERVENTION_END_DATE]
      ,[INTERVENTION_START_DATE]
      ,[NON_LFL_REASON_CODE]
      ,[NON_LFL_REASON_DESCRIPTION]
      ,[PHARMACY_REGISTRATION_STATUS]
      ,[PRIMARY_CARE_ORGANISATION_DESCRIPTION]
      ,[NAME_OF_HEALTH_AUTHORITY]
      ,[Z_GRID_REFERENCE_EASTING]
      ,[Z_GRID_REFERENCE_NORTHING]
      ,[Z_GRID_REFERENCE_LATITUDE]
      ,[Z_GRID_REFERENCE_LONGITUDE]
      ,[STORE_SHORT_NAME]
      ,[TELEPHONE_NUMBER]
      ,[BENCHMARK_GROUP]
      ,[HEALTH_CLINIC_AREA]
      ,[OPTICANS_OFF_SALES_AREA]
      ,[OPTICANS_ON_SALES_AREA]
      ,[PHARMACY_CONSULTATION_AREA]
      ,[PHOTOLAB_OFF_SALES_AREA]
      ,[PHOTOLAB_ON_SALES_AREA]
      ,[WAITROSE_FOOD_OFFER_TYPE_CODE]
      ,[WAITROSE_FOOD_OFFER_TYPE_DESCRIPTION]
      ,[MIDNIGHT_PHARMACY]
      ,[NHS_CONTRACT_FLAG]
      ,[NHS_MARKET]
      ,[MDS_ROOM_FLAG]
      ,[etl_runlog_id]
      ,[asset_id]
      ,[record_source_id]
      ,[row_status]
      ,[created_timestamp]
      ,[active_flag]
  FROM [psa].[uk_btc_mdm_store_20201008];

  update statistics psa.uk_btc_mdm_store;

--***********************************************************************
RENAME OBJECT [ser].[Site] to Site_20201008;

CREATE TABLE [ser].[Site]
WITH
(
	DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT [SiteId]
      ,[SourceKey]
      ,[SiteName]
      ,[LOVSiteTypeId]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[PSARowKey]
  FROM [ser].[Site_20201008];

    update statistics ser.Site;

--***********************************************************************
RENAME OBJECT [ser].[PostalAddress] to PostalAddress_20201008;

CREATE TABLE [ser].[PostalAddress]
WITH
(
	DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
		[SiteId]
      ,[LocationName]
      ,[AddressLine1]
      ,[AddressLine2]
      ,[Town]
      ,[County]
      ,[PostalCode]
      ,[LOVCountryId]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[PSARowKey]
  FROM [ser].[PostalAddress_20201008];

   update statistics ser.PostalAddress;

--***********************************************************************

RENAME OBJECT [ser].[SiteRole] to SiteRole_20201008;

CREATE TABLE [ser].[SiteRole]
WITH
(
	DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
 [SiteRoleId]
      ,[SiteId]
      ,[LOVRoleId]
      ,[SourceKey]
      ,[SiteRoleName]
      ,[SiteRoleShortName]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[PSARowKey]
  FROM [ser].[SiteRole_20201008];

  update statistics ser.SiteRole;

--***********************************************************************
RENAME OBJECT [ser].[SiteRoleStatus] to SiteRoleStatus_20201008;

CREATE TABLE [ser].[SiteRoleStatus]
WITH
(
	DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
		[SiteRoleId]
      ,[LOVSiteRoleStatusSetId]
      ,[LOVStatusId]
      ,[EffectiveFrom]
      ,[EffectiveTo]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[PSARowKey]
  FROM [ser].[SiteRoleStatus_20201008];

    update statistics ser.SiteRoleStatus;


--***********************************************************************
RENAME OBJECT [ser].[SiteRoleIndicator] to SiteRoleIndicator_20201008;

CREATE TABLE [ser].[SiteRoleIndicator]
WITH
(
	DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
	   [SiteRoleId]
      ,[LOVIndicatorId]
      ,[Value]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[PSARowKey]
  FROM [ser].[SiteRoleIndicator];

  update statistics ser.SiteRoleIndicator;

--***********************************************************************
RENAME OBJECT [ser].[Organisation] to Organisation_20201008;

CREATE TABLE [ser].[Organisation]
WITH
(
	DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
       [PartyId]
      ,[SourceOrganisationKey]
      ,[OrganisationName]
      ,[ParentPartyId]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
      ,[PSARowKey]
  FROM [ser].[Organisation_20201008];

  update statistics ser.Organisation;

  --***********************************************************************
RENAME OBJECT [ser].[Measure] to Measure_20201008;

CREATE TABLE [ser].[Measure]
WITH
(
	DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT
	   [MeasureId]
      ,[LOVMeasureTypeId]
      ,[LOVDataTypeId]
      ,[MeasureName]
      ,[MeasureDescription]
      ,[Length]
      ,[Precision]
      ,[Scale]
      ,[StandardMeasureId]
      ,[LOVRecordSourceId]
      ,[SCDStartDate]
      ,[SCDEndDate]
      ,[SCDActiveFlag]
      ,[SCDVersion]
      ,[SCDLOVRecordSourceId]
      ,[ETLRunLogId]
  FROM [ser].[Measure_20201008];

  update statistics ser.Measure;

--***********************************************************************modified
Rename object psa.DQAnomalies  to DQAnomalies_20201013;

CREATE TABLE [psa].[DQAnomalies]
WITH
(
   DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [psa].DQAnomalies_20201013;
   
--***********************************************************************
Rename object psa.DQRules  to DQRules_20201009;

CREATE TABLE [psa].[DQRules]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].DQRules_20201009;
   

update statistics psa.DQRules ;

--***********************************************************************
Rename object psa.MappingEntity  to MappingEntity_20201009;

CREATE TABLE [psa].[MappingEntity]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].MappingEntity_20201009;

update statistics psa.MappingEntity ;

--***********************************************************************
Rename object psa.Entity  to Entity_20201009;

CREATE TABLE [psa].[Entity]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].Entity_20201009;
   

update statistics psa.Entity ;  

--***********************************************************************
Rename object psa.[Rule] to Rule_20201009;

CREATE TABLE [psa].[Rule]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].Rule_20201009;

 update statistics psa.[Rule] ;

 --***********************************************************************
Rename object psa.RuleEntity to RuleEntity_20201009;

CREATE TABLE [psa].[RuleEntity]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].RuleEntity_20201009;

update statistics psa.RuleEntity ;

 --***********************************************************************modified
Rename object psa.RuleEntityInstance to RuleEntityInstance_20201013;

CREATE TABLE [psa].[RuleEntityInstance]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [psa].RuleEntityInstance_20201013;

--***********************************************************************modified
 Rename object psa.RuleEntityOperation to RuleEntityOperation_20201013;

CREATE TABLE [psa].[RuleEntityOperation]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [psa].RuleEntityOperation_20201013; 

 --***********************************************************************

Rename object psa.RuleRefLookup to RuleRefLookup_20201009;

CREATE TABLE [psa].[RuleRefLookup]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].RuleRefLookup_20201009;

update statistics psa.RuleRefLookup ;
 --***********************************************************************

 Rename OBJECT [psa].[Attribute] to Attribute_20201009;

 CREATE TABLE [psa].[Attribute]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM [psa].[Attribute_20201009];

update statistics psa.Attribute;
 --***********************************************************************
 

Rename OBJECT [psa].[AttributeBkp] to AttributeBkp_20201009;

CREATE TABLE [psa].[AttributeBkp]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM [psa].[AttributeBkp_20201009];

update statistics psa.AttributeBkp;

  --***********************************************************************

Rename OBJECT psa.cf_batch to cf_batch_20201009;

CREATE TABLE [psa].[cf_batch]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM [psa].[cf_batch_20201009];

update statistics psa.cf_batch;
 --***********************************************************************
 
Rename OBJECT psa.cf_etl_audit to cf_etl_audit_20201009;

CREATE TABLE [psa].[cf_etl_audit]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM [psa].[cf_etl_audit_20201009];

 update statistics psa.cf_etl_audit;
 --***********************************************************************
 
Rename OBJECT psa.cf_feed_configuration to cf_feed_configuration_20201009;


CREATE TABLE [psa].[cf_feed_configuration]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM [psa].[cf_feed_configuration_20201009];

update statistics psa.cf_feed_configuration;
 --***********************************************************************
 
Rename OBJECT psa.cf_feed_filter to cf_feed_filter_20201009;

CREATE TABLE [psa].[cf_feed_filter]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM [psa].[cf_feed_filter_20201009];

update statistics psa.cf_feed_filter;

  --***********************************************************************

Rename OBJECT psa.cf_feed_load_status   to cf_feed_load_status_20201009;

CREATE TABLE [psa].[cf_feed_load_status]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM [psa].[cf_feed_load_status_20201009];

update statistics psa.cf_feed_load_status;
    --***********************************************************************
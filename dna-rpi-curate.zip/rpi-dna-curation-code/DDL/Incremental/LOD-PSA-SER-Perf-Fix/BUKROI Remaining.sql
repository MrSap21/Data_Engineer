--***********************************************************************
Rename object psa.uk_abacus_coupon  to uk_abacus_coupon_20201013;

CREATE TABLE [psa].[uk_abacus_coupon]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].uk_abacus_coupon_20201013;

--***********************************************************************
Rename object psa.uk_abacus_deals  to uk_abacus_deals_20201013;

CREATE TABLE [psa].[uk_abacus_deals]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].uk_abacus_deals_20201013;

--***********************************************************************
Rename object psa.uk_abacus_payment  to uk_abacus_payment_20201013;

CREATE TABLE [psa].[uk_abacus_payment]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].uk_abacus_payment_20201013;

--***********************************************************************
Rename object psa.uk_abacus_promotions  to uk_abacus_promotions_20201013;

CREATE TABLE [psa].[uk_abacus_promotions]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].uk_abacus_promotions_20201013;

--***********************************************************************
Rename object lod.uk_abacus_coupon  to uk_abacus_coupon_20201013;

CREATE TABLE [lod].[uk_abacus_coupon]
WITH
(
   DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].uk_abacus_coupon_20201013;

DROP table [lod].uk_abacus_coupon_20201013;

--***********************************************************************
Rename object lod.uk_abacus_deals  to uk_abacus_deals_20201013;

CREATE TABLE [lod].[uk_abacus_deals]
WITH
(
   DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].uk_abacus_deals_20201013;

DROP table [lod].uk_abacus_deals_20201013;

--***********************************************************************
Rename object lod.uk_abacus_payment  to uk_abacus_payment_20201013;

CREATE TABLE [lod].[uk_abacus_payment]
WITH
(
   DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].uk_abacus_payment_20201013;

DROP table [lod].uk_abacus_payment_20201013;

--***********************************************************************
Rename object lod.uk_abacus_promotions  to uk_abacus_promotions_20201013;

CREATE TABLE [lod].[uk_abacus_promotions]
WITH
(
   DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].uk_abacus_promotions_20201013;

DROP table [lod].uk_abacus_promotions_20201013;
--***********************************************************************






Rename object psa.uk_sap_articlesales  to uk_sap_articlesales_20201013;

CREATE TABLE [psa].[uk_sap_articlesales]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].uk_sap_articlesales_20201013;

--***********************************************************************
Rename object lod.uk_sap_articlesales  to uk_sap_articlesales_20201013;

CREATE TABLE [lod].[uk_sap_articlesales]
WITH
(
   DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].uk_sap_articlesales_20201013;

DROP table [lod].uk_sap_articlesales_20201013;
--***********************************************************************

Rename object psa.uk_sap_crp_distribution  to uk_sap_crp_distribution_20201013;

CREATE TABLE [psa].[uk_sap_crp_distribution]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].uk_sap_crp_distribution_20201013;

--***********************************************************************
Rename object lod.uk_sap_crp_distribution  to uk_sap_crp_distribution_20201013;

CREATE TABLE [lod].[uk_sap_crp_distribution]
WITH
(
   DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].uk_sap_crp_distribution_20201013;

DROP table [lod].uk_sap_crp_distribution_20201013;

--***********************************************************************

Rename object psa.uk_sap_crp_productivity  to uk_sap_crp_productivity_20201013;

CREATE TABLE [psa].[uk_sap_crp_productivity]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].uk_sap_crp_productivity_20201013;

--***********************************************************************
Rename object lod.uk_sap_crp_productivity  to uk_sap_crp_productivity_20201013;

CREATE TABLE [lod].[uk_sap_crp_productivity]
WITH
(
   DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].uk_sap_crp_productivity_20201013;

DROP table [lod].uk_sap_crp_productivity_20201013;

--***********************************************************************

Rename object psa.uk_sap_storearticlesales  to uk_sap_storearticlesales_20201013;

CREATE TABLE [psa].[uk_sap_storearticlesales]
WITH
(
   DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].uk_sap_storearticlesales_20201013;

--***********************************************************************
Rename object lod.uk_sap_storearticlesales  to uk_sap_storearticlesales_20201013;

CREATE TABLE [lod].[uk_sap_storearticlesales]
WITH
(
   DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].uk_sap_storearticlesales_20201013;

DROP table [lod].uk_sap_storearticlesales_20201013;




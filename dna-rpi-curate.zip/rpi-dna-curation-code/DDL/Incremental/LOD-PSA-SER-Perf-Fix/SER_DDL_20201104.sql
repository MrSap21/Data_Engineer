CREATE TABLE [ser].[TransactionLineItemMeasure_20201104]
WITH
(
DISTRIBUTION = HASH ( TransactionLineItemMeasureId ),
CLUSTERED COLUMNSTORE INDEX
)AS
SELECT * FROM [ser].[TransactionLineItemMeasure];

DROP TABLE [ser].[TransactionLineItemMeasure];

RENAME OBJECT [ser].[TransactionLineItemMeasure_20201104] TO TransactionLineItemMeasure;
*****************************************************************************************************

CREATE TABLE [psa].[uk_abacus_item_20201202]
WITH
(
DISTRIBUTION = HASH ( [row_id] ),
CLUSTERED COLUMNSTORE INDEX
)AS
SELECT * FROM psa.uk_abacus_item;

DROP TABLE [psa].[uk_abacus_item];
RENAME OBJECT [psa].[uk_abacus_item_20201202] TO uk_abacus_item;
--*****************************************************************************************************

CREATE TABLE [ser].[ProductProperty_20201214]
WITH
(
	DISTRIBUTION = HASH ( [ProductId] ),
	CLUSTERED COLUMNSTORE INDEX	
)As select * from  [ser].[ProductProperty]


DROP TABLE [ser].[ProductProperty];

Rename OBJECT ser.[ProductProperty_20201214] to ProductProperty;

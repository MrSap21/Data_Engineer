--***************************************************************************** modified

Rename Object ser.Product to Product_20201012;

Create table  ser.Product WITH
(
DISTRIBUTION = REPLICATE, 
				CLUSTERED INDEX (SourceKey, LOVRecordSourceId)
)
AS SELECT *
FROM ser.Product_20201012;

--***************************************************************************** modified

Rename Object ser.ProductGroup to ProductGroup_20201015;

Create table  ser.ProductGroup WITH
(
DISTRIBUTION = HASH(ProductGroupId), 
CLUSTERED COLUMNSTORE INDEX ORDER ([ProductId],[LOVProductGroupSetId],[LOVRecordSourceId])
)
AS SELECT *
FROM ser.ProductGroup_20201015;


--*****************************************************************************

Rename Object ser.ProductIdentifier to ProductIdentifier_20201009;

Create table  ser.ProductIdentifier WITH
(
DISTRIBUTION = REPLICATE, 
				CLUSTERED INDEX (ProductId, LOVRecordSourceId)
)
AS SELECT *
FROM ser.ProductIdentifier_20201009;

UPDATE STATISTICS ser.ProductIdentifier;

--*****************************************************************************

Rename Object ser.ProductIndicator to ProductIndicator_20201009;

Create table  ser.ProductIndicator WITH
(
DISTRIBUTION = REPLICATE, 
				CLUSTERED INDEX (ProductId, LOVRecordSourceId)
)
AS SELECT *
FROM ser.ProductIndicator_20201009;

UPDATE STATISTICS ser.ProductIndicator;

--*****************************************************************************

Rename Object ser.ProductPartyRole to ProductPartyRole_20201009;

Create table  ser.ProductPartyRole WITH
(
DISTRIBUTION = REPLICATE, 
				CLUSTERED INDEX (ProductId, LOVRecordSourceId)
)
AS SELECT *
FROM ser.ProductPartyRole_20201009;

UPDATE STATISTICS ser.ProductPartyRole;

--*****************************************************************************

Rename Object ser.ProductProperty to ProductProperty_20201009;

Create table  ser.ProductProperty WITH
(
DISTRIBUTION = REPLICATE, 
				CLUSTERED INDEX (ProductId, LOVRecordSourceId)
)
AS SELECT *
FROM ser.ProductProperty_20201009;

UPDATE STATISTICS ser.ProductProperty;

--*****************************************************************************

Rename Object ser.ProductStatus to ProductStatus_20201009;

Create table  ser.ProductStatus WITH
(
DISTRIBUTION = REPLICATE, 
				CLUSTERED INDEX (ProductId, LOVProductStatusSetId, LOVRecordSourceId)
)
AS SELECT *
FROM ser.ProductStatus_20201009;

UPDATE STATISTICS ser.ProductStatus;

--*****************************************************************************modifed

Rename Object lod.uk_btc_mdm_article to uk_btc_mdm_article_20201009;

Create table  lod.uk_btc_mdm_article WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT *
FROM lod.uk_btc_mdm_article_20201009;

DROP table lod.uk_btc_mdm_article_20201009;

--*****************************************************************************modifed

Rename Object lod.uk_mf_dwoffer to uk_mf_dwoffer_20201009;

Create table  lod.uk_mf_dwoffer WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT *
FROM lod.uk_mf_dwoffer_20201009;

DROP table lod.uk_mf_dwoffer_20201009;


--*****************************************************************************

Rename Object psa.uk_btc_mdm_article to uk_btc_mdm_article_20201009;

Create table  psa.uk_btc_mdm_article WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM psa.uk_btc_mdm_article_20201009;

UPDATE STATISTICS psa.uk_btc_mdm_article;

--*****************************************************************************
Rename Object psa.uk_mf_dwoffer to uk_mf_dwoffer_20201009;

Create table  psa.uk_mf_dwoffer WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM psa.uk_mf_dwoffer_20201009;

UPDATE STATISTICS psa.uk_mf_dwoffer;

--*****************************************************************************
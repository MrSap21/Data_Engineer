Rename Object lod.uk_btc_ix_spc_fixture to uk_btc_ix_spc_fixture_20201012; -- modifed

Create table  lod.uk_btc_ix_spc_fixture WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT *
FROM lod.uk_btc_ix_spc_fixture_20201012;

DROP table lod.uk_btc_ix_spc_fixture_20201012;
------------------------------------------------------------------ modifed

Rename Object lod.uk_btc_ix_spc_planogram to uk_btc_ix_spc_planogram_20201012;

Create table  lod.uk_btc_ix_spc_planogram WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT *
FROM lod.uk_btc_ix_spc_planogram_20201012;

DROP TABLE lod.uk_btc_ix_spc_planogram_20201012;
------------------------------------------------------------------- modifed

Rename Object lod.uk_btc_ix_spc_position to uk_btc_ix_spc_position_20201012;

Create table  lod.uk_btc_ix_spc_position WITH
(
DISTRIBUTION = ROUND_ROBIN, 
CLUSTERED INDEX (dbkey)
)
AS SELECT *
FROM lod.uk_btc_ix_spc_position_20201012;

DROP table lod.uk_btc_ix_spc_position_20201012;

--------------------------------------------------------------------
Rename Object ser.Planogram to Planogram_20201009;

Create table  ser.Planogram WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM ser.Planogram_20201009;

UPDATE STATISTICS ser.Planogram;
----------------------------------------------------------
Rename Object ser.PlanogramFixture to PlanogramFixture_20201009;

Create table  ser.PlanogramFixture WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM ser.PlanogramFixture_20201009;

UPDATE STATISTICS ser.PlanogramFixture;
------------------------------------------------------------------
Rename Object ser.PlanogramFixtureProperty to PlanogramFixtureProperty_20201009;

Create table  ser.PlanogramFixtureProperty WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM ser.PlanogramFixtureProperty_20201009;

UPDATE STATISTICS ser.PlanogramFixtureProperty;
------------------------------------------------------------------------------------
Rename Object ser.PlanogramGroup to PlanogramGroup_20201009;

Create table  ser.PlanogramGroup WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM ser.PlanogramGroup_20201009;

UPDATE STATISTICS ser.PlanogramGroup;
---------------------------------------------------------------------
Rename Object ser.PlanogramPosition to PlanogramPosition_20201009;

Create table  ser.PlanogramPosition WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM ser.PlanogramPosition_20201009;

UPDATE STATISTICS ser.PlanogramPosition;
------------------------------------------------------------------------------
Rename Object ser.PlanogramPositionProperty to PlanogramPositionProperty_20201009;

Create table  ser.PlanogramPositionProperty WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM ser.PlanogramPositionProperty_20201009;

UPDATE STATISTICS ser.PlanogramPositionProperty;
-------------------------------------------------------------------------------
Rename Object ser.PlanogramProperty to PlanogramProperty_20201009;

Create table  ser.PlanogramProperty WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM ser.PlanogramProperty_20201009;

UPDATE STATISTICS ser.PlanogramProperty;
--------------------------------------------------------------------------
Rename Object ser.PlanogramStatus to PlanogramStatus_20201009;

Create table  ser.PlanogramStatus WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM ser.PlanogramStatus_20201009;

UPDATE STATISTICS ser.PlanogramStatus;
-----------------------------------------------------------------

Rename Object psa.uk_btc_ix_spc_fixture to uk_btc_ix_spc_fixture_20201009;

Create table  psa.uk_btc_ix_spc_fixture WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM psa.uk_btc_ix_spc_fixture_20201009;

UPDATE STATISTICS psa.uk_btc_ix_spc_fixture;

----------------------------------------------------------------

Rename Object psa.uk_btc_ix_spc_planogram to uk_btc_ix_spc_planogram_20201009;

Create table  psa.uk_btc_ix_spc_planogram WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM psa.uk_btc_ix_spc_planogram_20201009;

UPDATE STATISTICS psa.uk_btc_ix_spc_planogram;


-----------------------------------------------------------------

Rename Object psa.uk_btc_ix_spc_position to uk_btc_ix_spc_position_20201009;

Create table  psa.uk_btc_ix_spc_position WITH
(
DISTRIBUTION = HASH(row_id), 
CLUSTERED INDEX (dbkey)
)
AS SELECT *
FROM psa.uk_btc_ix_spc_position_20201009;

UPDATE STATISTICS psa.uk_btc_ix_spc_position;

-----------------------------------------------------------------

Rename Object ser.PlanogramIndicator to PlanogramIndicator_20201009;

Create table  ser.PlanogramIndicator WITH
(
DISTRIBUTION = REPLICATE, 
HEAP
)
AS SELECT *
FROM ser.PlanogramIndicator_20201009;

UPDATE STATISTICS ser.PlanogramIndicator;
-----------------------------------------------------------------
Rename Object psa.uk_btc_ix_spc_product to uk_btc_ix_spc_product_20201009;
Create table  psa.uk_btc_ix_spc_product WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT *
FROM psa.uk_btc_ix_spc_product_20201009;
-------------------------------------------------------------------- modified
Rename Object lod.uk_btc_ix_spc_product to uk_btc_ix_spc_product_20201012;

Create table  lod.uk_btc_ix_spc_product WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT *
FROM lod.uk_btc_ix_spc_product_20201012;

DROP table lod.uk_btc_ix_spc_product_20201012;




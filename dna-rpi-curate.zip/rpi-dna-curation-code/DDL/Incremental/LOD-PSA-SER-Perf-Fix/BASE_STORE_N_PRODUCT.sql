--***********************************************************************
Rename object lod.rawuk_base_store_plan to rawuk_base_store_plan_20201013;
 
CREATE TABLE [lod].[rawuk_base_store_plan]

 WITH

 (

 DISTRIBUTION = ROUND_ROBIN, HEAP

 )

 AS SELECT * from [lod].rawuk_base_store_plan_20201013 where 1=2;

 --***********************************************************************

 Rename object lod.rawuk_base_plan_product to rawuk_base_plan_product_20201013;
 
CREATE TABLE [lod].[rawuk_base_plan_product]

 WITH

 (

 DISTRIBUTION = ROUND_ROBIN, HEAP

 )

 AS SELECT * from [lod].rawuk_base_plan_product_20201013 where 1=2;

--***********************************************************************

Rename object ser.FactInstance to FactInstance_20201013;
 
CREATE TABLE [ser].[FactInstance]

 WITH

 (

 DISTRIBUTION = HASH(FactInstanceId), CLUSTERED COLUMNSTORE INDEX

 )

 AS SELECT * from [ser].FactInstance_20201013;

 --***********************************************************************

 Rename object ser.FactDimensionInstance to FactDimensionInstance_20201013;
 
CREATE TABLE [ser].[FactDimensionInstance]

 WITH

 (

 DISTRIBUTION = HASH(FactInstanceId), CLUSTERED COLUMNSTORE INDEX

 )

 AS SELECT * from [ser].FactDimensionInstance_20201013;

 --***********************************************************************

 Rename object ser.FactMeasureInstance to FactMeasureInstance_20201013;
 
CREATE TABLE [ser].[FactMeasureInstance]

 WITH

 (

 DISTRIBUTION = HASH(FactInstanceId), CLUSTERED COLUMNSTORE INDEX

 )

 AS SELECT * from [ser].FactMeasureInstance_20201013;

 --***********************************************************************

Rename object lod.uk_base_store_plan to uk_base_store_plan_20201014;
 
CREATE TABLE [lod].[uk_base_store_plan]

 WITH

 (

 DISTRIBUTION = ROUND_ROBIN, HEAP

 )

 AS SELECT * from [lod].uk_base_store_plan_20201014;

 DROP table [lod].uk_base_store_plan_20201014;
 --***********************************************************************

 Rename object psa.uk_base_store_plan to uk_base_store_plan_20201014;
 
CREATE TABLE [psa].[uk_base_store_plan]

 WITH

 (

 DISTRIBUTION = REPLICATE, HEAP

 )

 AS SELECT * from [psa].uk_base_store_plan_20201014;

 --***********************************************************************

Rename object lod.uk_base_plan_product to uk_base_plan_product_20201014;
 
CREATE TABLE [lod].[uk_base_plan_product]

 WITH

 (

 DISTRIBUTION = ROUND_ROBIN, HEAP

 )

 AS SELECT * from [lod].uk_base_plan_product_20201014;

 DROP table [lod].uk_base_plan_product_20201014;
 --***********************************************************************

 Rename object psa.uk_base_plan_product to uk_base_plan_product_20201014;
 
CREATE TABLE [psa].[uk_base_plan_product]

 WITH

 (

 DISTRIBUTION = REPLICATE, HEAP

 )

 AS SELECT * from [psa].uk_base_plan_product_20201014;

 --***********************************************************************
Rename object psa.rawuk_base_store_plan to rawuk_base_store_plan_20201013;
 
CREATE TABLE [psa].[rawuk_base_store_plan]

 WITH

 (

 DISTRIBUTION = HASH(store), CLUSTERED COLUMNSTORE INDEX

 )

 AS SELECT * from [psa].rawuk_base_store_plan_20201013;

 --***********************************************************************

 Rename object psa.rawuk_base_plan_product to rawuk_base_plan_product_20201013;
 
CREATE TABLE [psa].[rawuk_base_plan_product]

 WITH

 (

 DISTRIBUTION = HASH(article_id), CLUSTERED COLUMNSTORE INDEX

 )

 AS SELECT * from [psa].rawuk_base_plan_product_20201013;

--***********************************************************************




--***********************************************************************
Rename object lod.rawcl_crp_layout_performance to rawcl_crp_layout_performance_20201015;

CREATE TABLE [lod].[rawcl_crp_layout_performance]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawcl_crp_layout_performance_20201015 where 1=2;

DROP table [lod].rawcl_crp_layout_performance_20201015;

--***********************************************************************

Rename object psa.rawcl_crp_layout_performance to rawcl_crp_layout_performance_20201015;

CREATE TABLE [psa].[rawcl_crp_layout_performance]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawcl_crp_layout_performance_20201015;

--***********************************************************************

Rename object ser.Till to Till_20201015;

CREATE TABLE [ser].[Till]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].Till_20201015;

--***********************************************************************

Rename object ser.Deal to Deal_20201015;

CREATE TABLE [ser].[Deal]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].Deal_20201015;

--***********************************************************************

Rename object ser.LoyaltyAccount to LoyaltyAccount_20201015;

CREATE TABLE [ser].[LoyaltyAccount]
WITH
(
DISTRIBUTION = HASH(LoyaltyAccountId), CLUSTERED COLUMNSTORE INDEX
)
AS SELECT * from [ser].LoyaltyAccount_20201015;

--***********************************************************************

Rename object ser.TransactionLoyaltyAccount to TransactionLoyaltyAccount_20201015;

CREATE TABLE [ser].[TransactionLoyaltyAccount]
WITH
(
DISTRIBUTION = HASH(TransactionId), CLUSTERED COLUMNSTORE INDEX
)
AS SELECT * from [ser].TransactionLoyaltyAccount_20201015;


--***********************************************************************

Rename object psa.rawmx_crp_layout_performance to rawmx_crp_layout_performance_20201015;
 
CREATE TABLE [psa].[rawmx_crp_layout_performance]
 WITH
 (
 DISTRIBUTION = HASH(pog_id), CLUSTERED INDEX(store_number)
 )
 AS SELECT * from [psa].rawmx_crp_layout_performance_20201015;


--***********************************************************************

Rename object psa.rawmx_crp_planogram to rawmx_crp_planogram_20201015;
 
CREATE TABLE [psa].[rawmx_crp_planogram]
 WITH
 (
 DISTRIBUTION = HASH(pog_id), CLUSTERED INDEX(item_code)
 )
 AS SELECT * from [psa].rawmx_crp_planogram_20201015;

--***********************************************************************

Rename object ser.PlanogramProperty to PlanogramProperty_20201015;

CREATE TABLE [ser].[PlanogramProperty]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].PlanogramProperty_20201015;

--***********************************************************************

Rename object ser.LoyaltyAccountCard to LoyaltyAccountCard_20201019;

CREATE TABLE [ser].[LoyaltyAccountCard]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].LoyaltyAccountCard_20201019;

--***********************************************************************



 Rename object psa.rawcl_crp_customer to rawcl_crp_customer_20201022;

 CREATE TABLE [psa].[rawcl_crp_customer]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, CLUSTERED INDEX (customer_identifier)
 )
 AS SELECT * from [psa].rawcl_crp_customer_20201022;

 --******************************************************************


 Rename object psa.rawno_crp_customer to rawno_crp_customer_20201022;

 CREATE TABLE [psa].[rawno_crp_customer]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, CLUSTERED INDEX (customer_identifier)
 )
 AS SELECT * from [psa].rawno_crp_customer_20201022;

 --******************************************************************

 Rename object psa.rawth_crp_customer to rawth_crp_customer_20201022;

 CREATE TABLE [psa].[rawth_crp_customer]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, CLUSTERED COLUMNSTORE INDEX
 )
 AS SELECT * from [psa].rawth_crp_customer_20201022;

 --******************************************************************

 Rename object psa.rawuk_sap_articlesales to rawuk_sap_articlesales_20201022;

 CREATE TABLE [psa].[rawuk_sap_articlesales]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, CLUSTERED INDEX (itemcode)
 )
 AS SELECT * from [psa].rawuk_sap_articlesales_20201022;

 --******************************************************************

  Rename object psa.uk_sap_crp_productivity to uk_sap_crp_productivity_20201022;

 CREATE TABLE [psa].[uk_sap_crp_productivity]
 WITH
 (
 DISTRIBUTION = ROUND_ROBIN, CLUSTERED INDEX (pog_id)
 )
 AS SELECT * from [psa].uk_sap_crp_productivity_20201022;

 --******************************************************************

 Rename object psa.rawth_crp_store_trial_analysis to rawth_crp_store_trial_analysis_20201022;

 CREATE TABLE [psa].[rawth_crp_store_trial_analysis]
 WITH
 (
 DISTRIBUTION = REPLICATE, CLUSTERED INDEX (store_number,item_code)
 )
 AS SELECT * from [psa].rawth_crp_store_trial_analysis_20201022;

 --******************************************************************

 Rename object psa.th_crp_customer to th_crp_customer_20201022;

 CREATE TABLE [psa].[th_crp_customer]
 WITH
 (
 DISTRIBUTION = HASH(row_id), CLUSTERED INDEX (customer_identifier)
 )
 AS SELECT * from [psa].th_crp_customer_20201022;

 --******************************************************************

 Rename object psa.uk_mf_dwoffer to uk_mf_dwoffer_20201022;

 CREATE TABLE [psa].[uk_mf_dwoffer]
 WITH
 (
 DISTRIBUTION = HASH(row_id), CLUSTERED INDEX (item_code)
 )
 AS SELECT * from [psa].uk_mf_dwoffer_20201022;

 --******************************************************************

 Rename object psa.uk_btc_ix_spc_fixture to uk_btc_ix_spc_fixture_20201022;

 CREATE TABLE [psa].[uk_btc_ix_spc_fixture]
 WITH
 (
 DISTRIBUTION = HASH(row_id), CLUSTERED COLUMNSTORE INDEX
 )
 AS SELECT * from [psa].uk_btc_ix_spc_fixture_20201022;

 --******************************************************************


 Rename object psa.uk_btc_ix_spc_planogram to uk_btc_ix_spc_planogram_20201022;

 CREATE TABLE [psa].[uk_btc_ix_spc_planogram]
 WITH
 (
 DISTRIBUTION = HASH(row_id), CLUSTERED COLUMNSTORE INDEX
 )
 AS SELECT * from [psa].uk_btc_ix_spc_planogram_20201022;

 --******************************************************************

 Rename object psa.uk_btc_ix_spc_position to uk_btc_ix_spc_position_20201022;

 CREATE TABLE [psa].[uk_btc_ix_spc_position]
 WITH
 (
 DISTRIBUTION = HASH(row_id), CLUSTERED COLUMNSTORE INDEX
 )
 AS SELECT * from [psa].uk_btc_ix_spc_position_20201022;

 --******************************************************************
 Rename object psa.uk_btc_ix_spc_product to uk_btc_ix_spc_product_20201022;

 CREATE TABLE [psa].[uk_btc_ix_spc_product]
 WITH
 (
 DISTRIBUTION = HASH(row_id), CLUSTERED COLUMNSTORE INDEX
 )
 AS SELECT * from [psa].uk_btc_ix_spc_product_20201022;

 --******************************************************************
  
Rename object psa.cf_stored_proc to cf_stored_proc_20201022;
CREATE TABLE [psa].[cf_stored_proc]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].cf_stored_proc_20201022;

 --******************************************************************
 Rename object psa.rawcl_crp_merchandise to rawcl_crp_merchandise_20201022;
CREATE TABLE [psa].[rawcl_crp_merchandise]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawcl_crp_merchandise_20201022;

 --******************************************************************
 Rename object psa.rawcl_crp_planogram to rawcl_crp_planogram_20201022;
CREATE TABLE [psa].[rawcl_crp_planogram]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawcl_crp_planogram_20201022;

 --******************************************************************
 
    
Rename object psa.rawcl_crp_product to rawcl_crp_product_20201022;
CREATE TABLE [psa].[rawcl_crp_product]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawcl_crp_product_20201022;

 --******************************************************************
 
   
Rename object psa.rawcl_crp_store to rawcl_crp_store_20201022;
CREATE TABLE [psa].[rawcl_crp_store]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawcl_crp_store_20201022;

 --******************************************************************
 
   
Rename object psa.rawmx_crp_merchandise to rawmx_crp_merchandise_20201022;
CREATE TABLE [psa].[rawmx_crp_merchandise]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawmx_crp_merchandise_20201022;

 --******************************************************************
    
Rename object psa.rawmx_crp_product to rawmx_crp_product_20201022;
CREATE TABLE [psa].[rawmx_crp_product]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawmx_crp_product_20201022;

 --******************************************************************
 Rename object psa.rawmx_crp_store to rawmx_crp_store_20201022;
CREATE TABLE [psa].[rawmx_crp_store]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawmx_crp_store_20201022;

 --******************************************************************

   

Rename object psa.rawno_crp_merchandise to rawno_crp_merchandise_20201022;
CREATE TABLE [psa].[rawno_crp_merchandise]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawno_crp_merchandise_20201022;

 --******************************************************************
 
    
Rename object psa.rawno_crp_product to rawno_crp_product_20201022;
CREATE TABLE [psa].[rawno_crp_product]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawno_crp_product_20201022;

 --******************************************************************
    
Rename object psa.rawno_crp_store to rawno_crp_store_20201022;
CREATE TABLE [psa].[rawno_crp_store]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawno_crp_store_20201022;

 --******************************************************************

 Rename object psa.rawuk_btc_mdm_item to rawuk_btc_mdm_item_20201022;
CREATE TABLE [psa].[rawuk_btc_mdm_item]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawuk_btc_mdm_item_20201022;

 --******************************************************************
 Rename object psa.rawuk_btc_mdm_item_hierarchy1 to rawuk_btc_mdm_item_hierarchy1_20201022;
CREATE TABLE [psa].[rawuk_btc_mdm_item_hierarchy1]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawuk_btc_mdm_item_hierarchy1_20201022;

 --******************************************************************
 Rename object psa.rawuk_btc_mdm_item_hierarchy2 to rawuk_btc_mdm_item_hierarchy2_20201022;
CREATE TABLE [psa].[rawuk_btc_mdm_item_hierarchy2]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawuk_btc_mdm_item_hierarchy2_20201022;

 --******************************************************************
  
Rename object psa.rawuk_btc_mdm_item_hierarchy3 to rawuk_btc_mdm_item_hierarchy3_20201022;
CREATE TABLE [psa].[rawuk_btc_mdm_item_hierarchy3]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawuk_btc_mdm_item_hierarchy3_20201022;

 --******************************************************************
 Rename object psa.rawuk_btc_mdm_item_hierarchy4 to rawuk_btc_mdm_item_hierarchy4_20201022;
CREATE TABLE [psa].[rawuk_btc_mdm_item_hierarchy4]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawuk_btc_mdm_item_hierarchy4_20201022;

 --******************************************************************
 Rename object psa.rawuk_btc_mdm_item_hierarchy5 to rawuk_btc_mdm_item_hierarchy5_20201022;
CREATE TABLE [psa].[rawuk_btc_mdm_item_hierarchy5]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawuk_btc_mdm_item_hierarchy5_20201022;

 --******************************************************************
 Rename object psa.rawuk_btc_mdm_item_hierarchy6 to rawuk_btc_mdm_item_hierarchy6_20201022;
CREATE TABLE [psa].[rawuk_btc_mdm_item_hierarchy6]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawuk_btc_mdm_item_hierarchy6_20201022;

 --******************************************************************
  
Rename object psa.rawuk_btc_mdm_store to rawuk_btc_mdm_store_20201022;
CREATE TABLE [psa].[rawuk_btc_mdm_store]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawuk_btc_mdm_store_20201022;

 --******************************************************************
  
Rename object psa.rawuk_btc_promotion_deal to rawuk_btc_promotion_deal_20201022;
CREATE TABLE [psa].[rawuk_btc_promotion_deal]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].rawuk_btc_promotion_deal_20201022;

 --******************************************************************
  
Rename object psa.RDMvaluescheck to RDMvaluescheck_20201022;
CREATE TABLE [psa].[RDMvaluescheck]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].RDMvaluescheck_20201022;

 --******************************************************************
 Rename object psa.RDMvaluescheckconcat to RDMvaluescheckconcat_20201022;
CREATE TABLE [psa].[RDMvaluescheckconcat]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].RDMvaluescheckconcat_20201022;

 --******************************************************************
 Rename object psa.RDMvaluescheckconcatbuk to RDMvaluescheckconcatbuk_20201022;
CREATE TABLE [psa].[RDMvaluescheckconcatbuk]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].RDMvaluescheckconcatbuk_20201022;

 --******************************************************************
 Rename object psa.sap_crm_ad_card to sap_crm_ad_card_20201022;
CREATE TABLE [psa].[sap_crm_ad_card]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].sap_crm_ad_card_20201022;

 --******************************************************************
  
Rename object psa.TransactionExecuteMeta to TransactionExecuteMeta_20201022;
CREATE TABLE [psa].[TransactionExecuteMeta]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].TransactionExecuteMeta_20201022;

 --******************************************************************
  
Rename object psa.UK_AW_MEMBERSHIP_CARD to UK_AW_MEMBERSHIP_CARD_20201022;
CREATE TABLE [psa].[UK_AW_MEMBERSHIP_CARD]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].UK_AW_MEMBERSHIP_CARD_20201022;

 --******************************************************************
 
Rename object psa.uk_btc_promotion_deal to uk_btc_promotion_deal_20201022;
CREATE TABLE [psa].[uk_btc_promotion_deal]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [psa].uk_btc_promotion_deal_20201022;

 --******************************************************************

 Rename object psa.cl_crp_customer to cl_crp_customer_20201022;
CREATE TABLE [psa].[cl_crp_customer]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].cl_crp_customer_20201022;
--******************************
Rename object psa.cl_crp_item_transaction to cl_crp_item_transaction_20201022;
CREATE TABLE [psa].[cl_crp_item_transaction]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].cl_crp_item_transaction_20201022;
--******************************
Rename object psa.cl_crp_layout_performance to cl_crp_layout_performance_20201022;
CREATE TABLE [psa].[cl_crp_layout_performance]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].cl_crp_layout_performance_20201022;
--******************************
Rename object psa.cl_crp_merchandise to cl_crp_merchandise_20201022;
CREATE TABLE [psa].[cl_crp_merchandise]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].cl_crp_merchandise_20201022;
--******************************
Rename object psa.cl_crp_planogram to cl_crp_planogram_20201022;
CREATE TABLE [psa].[cl_crp_planogram]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].cl_crp_planogram_20201022;
--******************************
Rename object psa.cl_crp_product to cl_crp_product_20201022;
CREATE TABLE [psa].[cl_crp_product]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].cl_crp_product_20201022;
--******************************
Rename object psa.cl_crp_store to cl_crp_store_20201022;
CREATE TABLE [psa].[cl_crp_store]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].cl_crp_store_20201022;
--******************************
Rename object psa.cl_crp_store_trial_analysis to cl_crp_store_trial_analysis_20201022;
CREATE TABLE [psa].[cl_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].cl_crp_store_trial_analysis_20201022;
--******************************
Rename object psa.mx_crp_item_transaction to mx_crp_item_transaction_20201022;
CREATE TABLE [psa].[mx_crp_item_transaction]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].mx_crp_item_transaction_20201022;
--******************************
Rename object psa.mx_crp_layout_performance to mx_crp_layout_performance_20201022;
CREATE TABLE [psa].[mx_crp_layout_performance]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].mx_crp_layout_performance_20201022;
--******************************
Rename object psa.mx_crp_merchandise to mx_crp_merchandise_20201022;
CREATE TABLE [psa].[mx_crp_merchandise]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].mx_crp_merchandise_20201022;
--******************************
Rename object psa.mx_crp_planogram to mx_crp_planogram_20201022;
CREATE TABLE [psa].[mx_crp_planogram]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].mx_crp_planogram_20201022;
--******************************
Rename object psa.mx_crp_product to mx_crp_product_20201022;
CREATE TABLE [psa].[mx_crp_product]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].mx_crp_product_20201022;
--******************************
Rename object psa.mx_crp_store to mx_crp_store_20201022;
CREATE TABLE [psa].[mx_crp_store]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].mx_crp_store_20201022;
--******************************
Rename object psa.mx_crp_store_trial_analysis to mx_crp_store_trial_analysis_20201022;
CREATE TABLE [psa].[mx_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].mx_crp_store_trial_analysis_20201022;
--******************************
Rename object psa.no_crp_customer to no_crp_customer_20201022;
CREATE TABLE [psa].[no_crp_customer]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].no_crp_customer_20201022;
--******************************
Rename object psa.no_crp_item_transaction to no_crp_item_transaction_20201022;
CREATE TABLE [psa].[no_crp_item_transaction]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].no_crp_item_transaction_20201022;
--******************************
Rename object psa.no_crp_layout_performance to no_crp_layout_performance_20201022;
CREATE TABLE [psa].[no_crp_layout_performance]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].no_crp_layout_performance_20201022;
--******************************
Rename object psa.no_crp_merchandise to no_crp_merchandise_20201022;
CREATE TABLE [psa].[no_crp_merchandise]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].no_crp_merchandise_20201022;
--******************************
Rename object psa.no_crp_planogram to no_crp_planogram_20201022;
CREATE TABLE [psa].[no_crp_planogram]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].no_crp_planogram_20201022;
--******************************
Rename object psa.no_crp_product to no_crp_product_20201022;
CREATE TABLE [psa].[no_crp_product]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].no_crp_product_20201022;
--******************************
Rename object psa.no_crp_store to no_crp_store_20201022;
CREATE TABLE [psa].[no_crp_store]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].no_crp_store_20201022;
--******************************
Rename object psa.no_crp_store_trial_analysis to no_crp_store_trial_analysis_20201022;
CREATE TABLE [psa].[no_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].no_crp_store_trial_analysis_20201022;
--******************************
Rename object psa.th_crp_item_transaction to th_crp_item_transaction_20201022;
CREATE TABLE [psa].[th_crp_item_transaction]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].th_crp_item_transaction_20201022;
--******************************
Rename object psa.th_crp_layout_performance to th_crp_layout_performance_20201022;
CREATE TABLE [psa].[th_crp_layout_performance]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].th_crp_layout_performance_20201022;
--******************************
Rename object psa.th_crp_merchandise to th_crp_merchandise_20201022;
CREATE TABLE [psa].[th_crp_merchandise]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].th_crp_merchandise_20201022;
--******************************
Rename object psa.th_crp_planogram to th_crp_planogram_20201022;
CREATE TABLE [psa].[th_crp_planogram]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].th_crp_planogram_20201022;
--******************************
Rename object psa.th_crp_product to th_crp_product_20201022;
CREATE TABLE [psa].[th_crp_product]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].th_crp_product_20201022;
--******************************
Rename object psa.th_crp_store to th_crp_store_20201022;
CREATE TABLE [psa].[th_crp_store]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].th_crp_store_20201022;
--******************************
Rename object psa.th_crp_store_trial_analysis to th_crp_store_trial_analysis_20201022;
CREATE TABLE [psa].[th_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].th_crp_store_trial_analysis_20201022;
--******************************
Rename object psa.uk_abacus_header to uk_abacus_header_20201022;
CREATE TABLE [psa].[uk_abacus_header]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].uk_abacus_header_20201022;
--******************************
Rename object psa.uk_abacus_item to uk_abacus_item_20201022;
CREATE TABLE [psa].[uk_abacus_item]
WITH
(
DISTRIBUTION = HASH(row_id), HEAP
)
AS SELECT * from [psa].uk_abacus_item_20201022;
--******************************

Rename object psa.sap_crm_ad_card to sap_crm_ad_card_20201022;
CREATE TABLE [psa].[sap_crm_ad_card]
WITH
(
DISTRIBUTION = HASH(account_number), CLUSTERED COLUMNSTORE INDEX
)
AS SELECT * from [psa].sap_crm_ad_card_20201022;
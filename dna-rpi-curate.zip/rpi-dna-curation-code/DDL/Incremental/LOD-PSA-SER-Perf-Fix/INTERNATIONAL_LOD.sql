--***********************************************************************
Rename object lod.rawcl_crp_item_transaction to rawcl_crp_item_transaction_20201013;

CREATE TABLE [lod].[rawcl_crp_item_transaction]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawcl_crp_item_transaction_20201013 where 1=2;

--***********************************************************************
Rename object lod.rawcl_crp_store_trial_analysis to rawcl_crp_store_trial_analysis_20201013;

CREATE TABLE [lod].[rawcl_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawcl_crp_store_trial_analysis_20201013 where 1=2;

--***********************************************************************

Rename object lod.rawmx_crp_customer to rawmx_crp_customer_20201013;

CREATE TABLE [lod].[rawmx_crp_customer]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawmx_crp_customer_20201013 where 1=2;

--***********************************************************************

Rename object lod.rawmx_crp_item_transaction to rawmx_crp_item_transaction_20201013;

CREATE TABLE [lod].[rawmx_crp_item_transaction]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawmx_crp_item_transaction_20201013  where 1=2;

--***********************************************************************
Rename object lod.rawmx_crp_layout_performance to rawmx_crp_layout_performance_20201013;

CREATE TABLE [lod].[rawmx_crp_layout_performance]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawmx_crp_layout_performance_20201013   where 1=2;

--***********************************************************************

Rename object lod.rawmx_crp_planogram to rawmx_crp_planogram_20201013;

CREATE TABLE [lod].[rawmx_crp_planogram]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawmx_crp_planogram_20201013    where 1=2;
--***********************************************************************

Rename object lod.rawmx_crp_store_trial_analysis to rawmx_crp_store_trial_analysis_20201013;

CREATE TABLE [lod].[rawmx_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawmx_crp_store_trial_analysis_20201013    where 1=2;


--***********************************************************************
Rename object lod.rawno_crp_item_transaction to rawno_crp_item_transaction_20201013;

CREATE TABLE [lod].[rawno_crp_item_transaction]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawno_crp_item_transaction_20201013    where 1=2;
--***********************************************************************

Rename object lod.rawno_crp_layout_performance to rawno_crp_layout_performance_20201013;

CREATE TABLE [lod].[rawno_crp_layout_performance]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawno_crp_layout_performance_20201013  where 1=2;
--***********************************************************************

Rename object lod.rawno_crp_planogram to rawno_crp_planogram_20201013;

CREATE TABLE [lod].[rawno_crp_planogram]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawno_crp_planogram_20201013   where 1=2;

--***********************************************************************
Rename object lod.rawno_crp_store_trial_analysis to rawno_crp_store_trial_analysis_20201013;

CREATE TABLE [lod].[rawno_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawno_crp_store_trial_analysis_20201013  where 1=2;

--***********************************************************************
Rename object lod.rawth_crp_customer to rawth_crp_customer_20201013;

CREATE TABLE [lod].[rawth_crp_customer]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawth_crp_customer_20201013 where 1=2;

--***********************************************************************
Rename object lod.rawth_crp_item_transaction to rawth_crp_item_transaction_20201013;

CREATE TABLE [lod].[rawth_crp_item_transaction]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawth_crp_item_transaction_20201013 where 1=2;

--***********************************************************************
Rename object lod.rawth_crp_layout_performance to rawth_crp_layout_performance_20201013;

CREATE TABLE [lod].[rawth_crp_layout_performance]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawth_crp_layout_performance_20201013 where 1=2;
--***********************************************************************

Rename object lod.rawth_crp_merchandise to rawth_crp_merchandise_20201013;

CREATE TABLE [lod].[rawth_crp_merchandise]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawth_crp_merchandise_20201013 where 1=2;

--***********************************************************************
Rename object lod.rawth_crp_planogram to rawth_crp_planogram_20201013;

CREATE TABLE [lod].[rawth_crp_planogram]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawth_crp_planogram_20201013 where 1=2;

--***********************************************************************
Rename object lod.rawth_crp_product to rawth_crp_product_20201013;

CREATE TABLE [lod].[rawth_crp_product]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawth_crp_product_20201013 where 1=2;

--***********************************************************************
Rename object lod.rawth_crp_store to rawth_crp_store_20201013;

CREATE TABLE [lod].[rawth_crp_store]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawth_crp_store_20201013 where 1=2;

--***********************************************************************
Rename object lod.rawth_crp_store_trial_analysis to rawth_crp_store_trial_analysis_20201013;

CREATE TABLE [lod].[rawth_crp_store_trial_analysis]
WITH
(
DISTRIBUTION = ROUND_ROBIN, HEAP
)
AS SELECT * from [lod].rawth_crp_store_trial_analysis_20201013 where 1=2;
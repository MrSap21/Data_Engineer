
Rename Object ser.PlanogramPositionProperty to PlanogramPositionProperty_20201022;

Create table  ser.PlanogramPositionProperty WITH
(
DISTRIBUTION = REPLICATE, CLUSTERED INDEX(PlanogramPositionId)
)
AS SELECT *
FROM ser.PlanogramPositionProperty_20201022;

--****************************************************************************

Rename Object ser.ProductProperty to ProductProperty_20201022;

Create table  ser.ProductProperty WITH
(
DISTRIBUTION = HASH(ProductId), CLUSTERED INDEX(ProductId, LOVRecordSourceId)
)
AS SELECT *
FROM ser.ProductProperty_20201022;

--****************************************************************************

Rename object ser.Dimension to Dimension_20201022;
CREATE TABLE [ser].[Dimension]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].Dimension_20201022;
--********************************
Rename object ser.Fact to Fact_20201022;
CREATE TABLE [ser].[Fact]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].Fact_20201022;
--********************************
Rename object ser.FactDimension to FactDimension_20201022;
CREATE TABLE [ser].[FactDimension]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].FactDimension_20201022;
--********************************
Rename object ser.FactMeasure to FactMeasure_20201022;
CREATE TABLE [ser].[FactMeasure]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].FactMeasure_20201022;
--********************************
Rename object ser.LoyaltyAccountCardStatus to LoyaltyAccountCardStatus_20201022;
CREATE TABLE [ser].[LoyaltyAccountCardStatus]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].LoyaltyAccountCardStatus_20201022;
--********************************
Rename object ser.TransactionGroup to TransactionGroup_20201022;
CREATE TABLE [ser].[TransactionGroup]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].TransactionGroup_20201022;
--********************************
Rename object ser.TransactionLoyaltyAccountCard to TransactionLoyaltyAccountCard_20201022;
CREATE TABLE [ser].[TransactionLoyaltyAccountCard]
WITH
(
DISTRIBUTION = REPLICATE, HEAP
)
AS SELECT * from [ser].TransactionLoyaltyAccountCard_20201022;
--********************************



CREATE TABLE [psa].[cf_feed_configuration_20201209]
WITH
(
DISTRIBUTION = REPLICATE,
	HEAP
)AS
SELECT * FROM [psa].[cf_feed_configuration];
 
DROP TABLE [psa].[cf_feed_configuration];
RENAME OBJECT [psa].[cf_feed_configuration_20201209] TO cf_feed_configuration;
--**********************************************************************************************

CREATE TABLE [psa].[uk_abacus_deals_20201209]
WITH
(
DISTRIBUTION = HASH(row_id),
CLUSTERED COLUMNSTORE INDEX
)AS
SELECT * FROM [psa].[uk_abacus_deals];
 
DROP TABLE [psa].[uk_abacus_deals];
RENAME OBJECT [psa].[uk_abacus_deals_20201209] TO uk_abacus_deals;
--**********************************************************************************************

CREATE TABLE [psa].[uk_abacus_header_20201209]
WITH
(
DISTRIBUTION = HASH ( row_id ),
CLUSTERED INDEX (TILL_TXN_NUMBER)
)AS
SELECT * FROM [psa].[uk_abacus_header];
 
DROP TABLE [psa].[uk_abacus_header];
RENAME OBJECT [psa].[uk_abacus_header_20201209] TO uk_abacus_header;
--**********************************************************************************************

CREATE TABLE [psa].[uk_abacus_payment_20201209]
WITH
(
DISTRIBUTION = HASH ( row_id ),
CLUSTERED COLUMNSTORE INDEX
)AS
SELECT * FROM [psa].[uk_abacus_payment];
 
DROP TABLE [psa].[uk_abacus_payment];
RENAME OBJECT [psa].[uk_abacus_payment_20201209] TO uk_abacus_payment;
--**********************************************************************************************

CREATE TABLE [psa].[uk_abacus_promotions_20201209]
WITH
(
DISTRIBUTION = HASH ( row_id ),
CLUSTERED COLUMNSTORE INDEX
)AS
SELECT * FROM [psa].[uk_abacus_promotions];
 
DROP TABLE [psa].[uk_abacus_promotions];
RENAME OBJECT [psa].[uk_abacus_promotions_20201209] TO uk_abacus_promotions;
--**********************************************************************************************

CREATE TABLE [psa].[UK_AW_MEMBERSHIP_CARD_20201209]
WITH
(
DISTRIBUTION = HASH ( row_id ),
CLUSTERED INDEX (card_number)
)AS
SELECT * FROM [psa].[UK_AW_MEMBERSHIP_CARD];
 
DROP TABLE [psa].[UK_AW_MEMBERSHIP_CARD];
RENAME OBJECT [psa].[UK_AW_MEMBERSHIP_CARD_20201209] TO UK_AW_MEMBERSHIP_CARD;
--**********************************************************************************************

CREATE TABLE [psa].[uk_sap_crp_distribution_20201209]
WITH
(
DISTRIBUTION = ROUND_ROBIN ,
CLUSTERED INDEX(calendar_year_week, retail_location, pog_id, material )
)AS
SELECT * FROM [psa].[uk_sap_crp_distribution];
 
DROP TABLE [psa].[uk_sap_crp_distribution];
RENAME OBJECT [psa].[uk_sap_crp_distribution_20201209] TO uk_sap_crp_distribution;
--**********************************************************************************************

CREATE TABLE [psa].[uk_sap_storearticlesales_20201209]
WITH
(
DISTRIBUTION = ROUND_ROBIN ,
CLUSTERED INDEX (calender_year_week, itemcode, store_format)
)AS
SELECT * FROM [psa].[uk_sap_storearticlesales];
 
DROP TABLE [psa].[uk_sap_storearticlesales];
RENAME OBJECT [psa].[uk_sap_storearticlesales_20201209] TO uk_sap_storearticlesales;
--**********************************************************************************************

CREATE TABLE [psa].[mx_crp_item_transaction_20201209]
WITH
(
DISTRIBUTION = HASH ( row_id ),
CLUSTERED INDEX (transaction_key)
)AS
SELECT * FROM [psa].[mx_crp_item_transaction];
 
DROP TABLE [psa].[mx_crp_item_transaction];
RENAME OBJECT [psa].[mx_crp_item_transaction_20201209] TO mx_crp_item_transaction;
--**********************************************************************************************

CREATE TABLE [psa].[th_crp_item_transaction_20201209]
WITH
(
DISTRIBUTION = HASH ( row_id ),
CLUSTERED INDEX (transaction_key)
)AS
SELECT * FROM [psa].[th_crp_item_transaction];
 
DROP TABLE [psa].[th_crp_item_transaction];
RENAME OBJECT [psa].[th_crp_item_transaction_20201209] TO th_crp_item_transaction;
IF OBJECT_ID('ser.RefLOVSet') IS NOT NULL
BEGIN
    DROP TABLE ser.RefLOVSet;
    
END
GO

CREATE TABLE [ser].[RefLOVSet](
    [LOVSetId]           int               NOT NULL,
    [LOVSetName]         nvarchar(128)     NOT NULL,
    [LOVSetDescription]  nvarchar(1024)    NULL,
    [LOVSetSequence]     int          NULL,
    [RecordSourceId]     int               NOT NULL,
    [ETLRunLogId]        int               NULL,
    [ActiveFlag]         smallint          NOT NULL,
    [DTCreated]          smalldatetime     NULL,
    [UserCreated]        nvarchar(128)     NULL
)
GO

IF OBJECT_ID('ser.RefLOV') IS NOT NULL
BEGIN
    DROP TABLE ser.RefLOV;
    
END
GO

CREATE TABLE ser.[RefLOV](
    [LOVId]           int               NOT NULL,
    [LOVSetId]        int               NOT NULL,
    [LOVKey]          nvarchar(128)     NOT NULL,
    [LOVName]         nvarchar(128)     NOT NULL,
    [LOVDescription]  nvarchar(1024)    NULL,
    [LOVSequence]     int          NULL,
    [RecordSourceId]  int               NOT NULL,
    [ETLRunLogId]     int               NULL,
    [ActiveFlag]      smallint          DEFAULT 1 NOT NULL,
    [DTCreated]       smalldatetime     NULL,
    [UserCreated]     nvarchar(128)     NULL
)
GO

IF OBJECT_ID('ser.RefLOVSetInfo') IS NOT NULL
BEGIN
    DROP VIEW ser.RefLOVSetInfo;
    
END
GO

CREATE VIEW [ser].[RefLOVSetInfo] 
([LOVId],
 [LOVSetId], 
 [LOVKey],
 [LOVName],
 [LOVDescription],
 [LOVSequence], 
 [LOVRecordSourceId], 
 [LOVSetName], 
 [LOVSetDescription], 
 [LOVSetSequence])
AS SELECT 
r.[LOVId],
r.[LOVSetId],
r.[LOVKey],
r.[LOVName],
r.[LOVDescription],
r.[LOVSequence],
r.[RecordSourceId],
rs.[LOVSetName],
rs.[LOVSetDescription],
rs.[LOVSetSequence]
FROM ser.RefLOV r
INNER JOIN ser.RefLOVSet rs
ON r.LOVSetId=rs.LOVSetId
AND r.[RecordSourceId]=rs.[RecordSourceId]
AND r.ActiveFlag='1'
AND rs.ActiveFlag='1';
GO
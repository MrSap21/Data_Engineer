---------------------------------------DDL for SAPBW-ABACUS tables:------------------------------------------------------
CREATE TABLE [psa].[uk_abacus_item]  --IF_01473_ABACUSITEM_D_*.txt
(
	[row_id] [bigint] NOT NULL,
	[record_type] [nvarchar](2) NULL,
	[ITEM_CODE] [nvarchar](10) NULL,
	[STORE_NUMBER] [nvarchar](10) NULL,
	[TILL_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_DATE] [nvarchar](25) NULL,
	[TILL_TXN_TIME] [nvarchar](25) NULL,
	[SIGN] [nvarchar](2) NULL,
	[SALES_UNITS] [nvarchar](10) NULL,
	[SIGN_TISP] [nvarchar](2) NULL,
	[SALES_AT_TISP] [nvarchar](100) NULL,
	[SIGN_TESP] [nvarchar](2) NULL,
	[SALES_AT_TESP] [nvarchar](100) NULL,
	[SIGN_PROFIT] [nvarchar](2) NULL,
	[EPOS_PROFIT] [nvarchar](100) NULL,
	[SIGN_NCP] [nvarchar](2) NULL,
	[SALES_AT_NCP] [nvarchar](25) NULL,
	[SIGN_DISCPC] [nvarchar](2) NULL,
	[SALE_ITEM_DISC_PC] [nvarchar](100) NULL,
	[SIGN_ITEM] [nvarchar](2) NULL,
	[ITEM_REDUCTION_AMT] [nvarchar](100) NULL,
	[ITEM_DISC_ORIDE_FLG] [nvarchar](1) NULL,
	[PRICE_ORIDE_IT_FLG] [nvarchar](1) NULL,
	[SIGN_TAKINGS] [nvarchar](2) NULL,
	[TAKINGS] [nvarchar](100) NULL,
	[SIGN_REVENUE] [nvarchar](2) NULL,
	[REVENUE] [nvarchar](100) NULL,
	[SIGN_EPOS] [nvarchar](2) NULL,
	[EPOS_PROFIT_ADJ] [nvarchar](100) NULL,
	[SIGN_ITMPNTQTY] [nvarchar](2) NULL,
	[ITEM_POINTS_QUANTITY] [nvarchar](100) NULL,
	[SIGN_ITMPNTVAL] [nvarchar](2) NULL,
	[ITEM_POINTS_VALUE] [nvarchar](100) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_abacus_header]  --IF_01111_ABACUSHEADER_D_*.txt
(
	[row_id] [bigint] NOT NULL,
	[record_type] [nvarchar](2) NULL,
	[STORE_NUMBER] [nvarchar](10) NULL,
	[TILL_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_DATE] [nvarchar](25) NULL,
	[TILL_TXN_TIME] [nvarchar](25) NULL,
	[EPOS_TXN_TYPE_FLAG] [nvarchar](1) NULL,
	[OPERATOR_ID] [nvarchar](10) NULL,
	[CARD_NUMBER] [nvarchar](500) NULL,
	[DISC_CARD_USER_FLG] [nvarchar](1) NULL,
	[DISC_CARD_NUMBER] [nvarchar](500) NULL,
	[ALL_IT_PTS_MULT_PC] [nvarchar](10) NULL,
	[BTC_IT_PTS_MULT_PC] [nvarchar](10) NULL,
	[SIGN] [nvarchar](2) NULL,
	[POINTS_CHANGE] [nvarchar](10) NULL,
	[MAIN_PAYMENT_METH] [nvarchar](10) NULL,
	[VALIDATION_BARCODE] [nvarchar](100) NULL,
	[CHANNEL] [nvarchar](1) NULL,
	[SUBCHANNEL] [nvarchar](1) NULL,
	[TRANSACTION_QUALIFIED_FLAG] [nvarchar](1) NULL,
	[ERROR_IND] [nvarchar](1) NULL,
	[ADCARD_PRESENTATION_METHOD] [nvarchar](30) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_abacus_payment] --IF_01474_ABACUSPAYMENT_D_*.txt
(
	[row_id] [bigint] NOT NULL,
	[record_type] [nvarchar](2) NULL,
	[STORE_NUMBER] [nvarchar](10) NULL,
	[TILL_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_DATE] [nvarchar](25) NULL,
	[TILL_TXN_TIME] [nvarchar](25) NULL,
	[TILL_TXN_PAY_METH] [nvarchar](10) NULL,
	[TILL_TXN_PAY_CARD] [nvarchar](10) NULL,
	[SIGN] [nvarchar](2) NULL,
	[TILL_TXN_PAY_M_VAL] [nvarchar](100) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_abacus_coupon] --IF_01475_ABACUSCOUPON_D_*.txt
(
	[row_id] [bigint] NOT NULL,
	[record_type] [nvarchar](2) NULL,
	[STORE_NUMBER] [nvarchar](10) NULL,
	[TILL_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_DATE] [nvarchar](25) NULL,
	[TILL_TXN_TIME] [nvarchar](25) NULL,
	[COUPON_BAR_CODE] [nvarchar](100) NULL,
	[SIGN_1] [nvarchar](2) NULL,
	[COUPON_WANDED_QTY] [nvarchar](10) NULL,
	[COUPON_TYPE] [nvarchar](1) NULL,
	[SIGN_2] [nvarchar](2) NULL,
	[COUPON_VALUE] [nvarchar](100) NULL,
	[COUPON_VALUE_ORIDE] [nvarchar](1) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_abacus_deals] --IF_01476_ABACUSDEALS_D_*.txt
(
	[row_id] [bigint] NOT NULL,
	[record_type] [nvarchar](2) NULL,
	[STORE_NUMBER] [nvarchar](10) NULL,
	[TILL_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_DATE] [nvarchar](25) NULL,
	[TILL_TXN_TIME] [nvarchar](25) NULL,
	[DEAL_NUMBER] [nvarchar](10) NULL,
	[DEAL_TYPE_FLAG] [nvarchar](1) NULL,
	[DEAL_TOTAL_SAVING_MONEY] [nvarchar](100) NULL,
	[DEAL_TOTAL_SAVING_POINTS] [nvarchar](100) NULL,
	[DEAL_NO_OF_ITEMS] [nvarchar](10) NULL,
	[PROMOTION_NUMBER] [nvarchar](20) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_abacus_promotions] --IF_01477_ABACUSPROMOTIONS_D_*.txt
(
	[row_id] [bigint] NOT NULL,
	[record_type] [nvarchar](2) NULL,
	[STORE_NUMBER] [nvarchar](10) NULL,
	[TILL_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_NUMBER] [nvarchar](10) NULL,
	[TILL_TXN_DATE] [nvarchar](25) NULL,
	[TILL_TXN_TIME] [nvarchar](25) NULL,
	[DEAL_NUMBER] [nvarchar](10) NULL,
	[EPOS_TXN_TYPE_FLAG] [nvarchar](1) NULL,
	[PROMOTION_NUMBER] [nvarchar](20) NULL,
	[DEAL_TIMES_QUALIFIED] [nvarchar](10) NULL,
	[ITEM_DEAL_COUNT] [nvarchar](10) NULL,
	[ITEM_TXN_UNITS] [nvarchar](10) NULL,
	[ITEM_CODE] [nvarchar](10) NULL,
	[SIGN_1] [nvarchar](2) NULL,
	[DEAL_REWARD_MONEY] [nvarchar](100) NULL,
	[SIGN_2] [nvarchar](2) NULL,
	[DEAL_REWARD_PTS] [nvarchar](100) NULL,
	[SIGN_3] [nvarchar](2) NULL,
	[ITEM_TXN_BASE_PTS] [nvarchar](100) NULL,
	[SIGN_4] [nvarchar](2) NULL,
	[ITEM_TXN_BASE_PTS_SPLIT] [nvarchar](100) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO

---------------------------------------DDL for SAPBW-HADOOP tables:---------------------------------------------

CREATE TABLE [psa].[uk_sap_crp_distribution]
(
	[row_id] [bigint] NOT NULL,
	[calendar_year_week] [nvarchar](10) NULL,
	[fiscal_week] [nvarchar](10) NULL,
	[retail_location] [nvarchar](10) NULL,
	[pog_id] [nvarchar](10) NULL,
	[pog_text] [nvarchar](100) NULL,
	[material] [nvarchar](10) NULL,
	[material_text] [nvarchar](100) NULL,
	[sales_at_tesp_cy] [nvarchar](100) NULL,
	[qty_post_adcard_cy] [nvarchar](100) NULL,
	[epos_gross_profit_adjusted] [nvarchar](100) NULL,
	[linear_space] [nvarchar](100) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_sap_crp_productivity]
(
	[row_id] [bigint] NOT NULL,
	[calendar_week] [nvarchar](10) NULL,
	[pog_family] [nvarchar](100) NULL,
	[pog_id] [nvarchar](10) NULL,
	[pog_name] [nvarchar](100) NULL,
	[brand] [nvarchar](100) NULL,
	[meterial] [nvarchar](100) NULL,
	[meterial_name] [nvarchar](100) NULL,
	[build_size] [nvarchar](10) NULL,
	[fiscal_week] [nvarchar](10) NULL,
	[linear_space] [nvarchar](100) NULL,
	[sales_at_tesp] [nvarchar](100) NULL,
	[sales_quantity] [nvarchar](100) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_base_store_plan] 
(
	[row_id] [bigint] NOT NULL,
	[calendar_week] [nvarchar](80) NULL,
	[fiscal_week] [nvarchar](80) NULL,
	[store] [nvarchar](80) NULL,
	[floor_plan] [nvarchar](80) NULL,
	[pog_id] [nvarchar](80) NULL,
	[build_size] [nvarchar](255) NULL,
	[sales_qty] [nvarchar](255) NULL,
	[sales_tisp] [nvarchar](255) NULL,
	[sales_tesp] [nvarchar](255) NULL,
	[sales_epgp] [nvarchar](255) NULL,
	[instances] [nvarchar](255) NULL,
	[modular_build] [nvarchar](255) NULL,	
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_sap_articlesales]
(
	[row_id] [bigint] NOT NULL,
	[calender_year_week] [nvarchar](10) NULL,
	[fiscal_week] [nvarchar](10) NULL,
	[itemcode] [nvarchar](100) NULL,
	[item_description] [nvarchar](100) NULL,
	[reporting_group] [nvarchar](100) NULL,
	[own_brand] [nvarchar](100) NULL,
	[brand] [nvarchar](100) NULL,
	[supplier] [nvarchar](100) NULL,
	[boots_brandandexclusive_flag] [nvarchar](100) NULL,
	[channel] [nvarchar](100) NULL,
	[ladder] [nvarchar](100) NULL,
	[sub_ladder] [nvarchar](100) NULL,
	[company_code] [nvarchar](100) NULL,
	[profit_ty] [nvarchar](100) NULL,
	[currency_profit_ty] [nvarchar](100) NULL,
	[profit_ly] [nvarchar](100) NULL,
	[currency_profit_ly] [nvarchar](100) NULL,
	[vol_ty] [nvarchar](100) NULL,
	[unit_vol_ty] [nvarchar](100) NULL,
	[vol_ly] [nvarchar](100) NULL,
	[unit_vol_ly] [nvarchar](100) NULL,
	[tesp_ty] [nvarchar](100) NULL,
	[currency_tesp_ty] [nvarchar](100) NULL,
	[tesp_ly] [nvarchar](100) NULL,
	[currency_tesp_ly] [nvarchar](100) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_sap_storearticlesales]
(
	[row_id] [bigint] NOT NULL,
	[calender_year_week] [nvarchar](10) NULL,
	[fiscal_week] [nvarchar](10) NULL,
	[itemcode] [nvarchar](100) NULL,
	[item_description] [nvarchar](100) NULL,
	[store_format] [nvarchar](100) NULL,
	[reporting_group] [nvarchar](100) NULL,
	[brand] [nvarchar](100) NULL,
	[supplier] [nvarchar](100) NULL,
	[company_code] [nvarchar](100) NULL,
	[profit_ty] [nvarchar](100) NULL,
	[currency_profit_ty] [nvarchar](100) NULL,
	[profit_ly] [nvarchar](100) NULL,
	[currency_profit_ly] [nvarchar](100) NULL,
	[vol_ty] [nvarchar](100) NULL,
	[unit_vol_ty] [nvarchar](100) NULL,
	[vol_ly] [nvarchar](100) NULL,
	[unit_vol_ly] [nvarchar](100) NULL,
	[tesp_ty] [nvarchar](100) NULL,
	[currency_tesp_ty] [nvarchar](100) NULL,
	[tesp_ly] [nvarchar](100) NULL,
	[currency_tesp_ly] [nvarchar](100) NULL,
	[store_type] [nvarchar](100) NULL,
	[store_text] [nvarchar](100) NULL,
	[channel_code] [nvarchar](100) NULL,
	[channel] [nvarchar](100) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[uk_base_plan_product]
(
	[row_id] [bigint] NOT NULL,
	[calendar_week] [nvarchar](80) NULL,		
	[fiscal_week] [nvarchar](80) NULL,
	[pogid] [nvarchar](80) NULL,
	[article_id] [nvarchar](80) NULL,
	[etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO
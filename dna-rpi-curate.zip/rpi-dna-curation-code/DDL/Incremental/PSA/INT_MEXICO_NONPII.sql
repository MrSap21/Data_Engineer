 CREATE TABLE [psa].[mx_crp_layout_performance]
(
    [row_id] [bigint] NOT NULL,
    [store_number] [nvarchar](80) NULL,
    [floor] [nvarchar](80) NULL,				
    [week]  [nvarchar](80) NULL,				
    [pog_id] [nvarchar](80) NULL,
    [units] [nvarchar](255) NULL,
    [tesp] [nvarchar](255) NULL,
    [tisp] [nvarchar](255) NULL,
    [epos_profit] [nvarchar](255) NULL,
    [modular_space] [nvarchar](255) NULL,
    [date_added] [nvarchar](500) NULL,
    [etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


  CREATE TABLE [psa].[mx_crp_merchandise]
(
    [row_id] [bigint] NOT NULL,
    [db_key] [nvarchar](100) NULL,					
	[pog_id] [nvarchar](80) NULL,
    [planogram_start_date] [nvarchar](25) NULL,		
    [planogram_end_date]  [nvarchar](25) NULL,      
    [pog_description] [nvarchar](80) NULL,
    [shelf_depth] [nvarchar](255) NULL,
    [height] [nvarchar](255) NULL,
    [fitting_type] [nvarchar](255) NULL,
    [build_size] [nvarchar](255) NULL,
    [planner_family] [nvarchar](255) NULL,
    [footprint] [nvarchar](255) NULL,
    [category] [nvarchar](255) NULL,
	[format] [nvarchar](255) NULL,
	[promotional_site] [nvarchar](255) NULL,
    [date_added] [nvarchar](500) NULL,
    [etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


  CREATE TABLE [psa].[mx_crp_planogram]
(
    [row_id] [bigint] NOT NULL,
    [pog_id] [nvarchar](80) NULL,
    [week] [nvarchar](80) NULL,
    [item_code]  [nvarchar](80) NULL,
    [facings] [nvarchar](255) NULL,
    [date_added] [nvarchar](500) NULL,
    [etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


  CREATE TABLE [psa].[mx_crp_product]
(
    [row_id] [bigint] NOT NULL,
    item_code               nvarchar (80) NULL,
	item_description        nvarchar (255) NULL,		
	product_hierarchy1      nvarchar (255) NULL,
	product_hierarchy2      nvarchar (255) NULL,
	product_hierarchy3      nvarchar (255) NULL,
	product_hierarchy4      nvarchar (255) NULL,
	product_hierarchy5      nvarchar (255) NULL,
	product_hierarchy1_code nvarchar (255) NULL,
	product_hierarchy2_code nvarchar (255) NULL,
	product_hierarchy3_code nvarchar (255) NULL,
	product_hierarchy4_code nvarchar (255) NULL,
	product_hierarchy5_code nvarchar (255) NULL,
	brand                   nvarchar (255) NULL,
	subbrand                nvarchar (255) NULL,
	exclusive_flag          nvarchar (10) NULL,
	own_brand_flag          nvarchar (10) NULL,
	item_status             nvarchar (255) NULL,
	upc                     nvarchar (80) NULL,
	supplier_name           nvarchar (80) NULL,
	supplier_number         nvarchar (80) NULL,
	height                  nvarchar (255) NULL,
	width                   nvarchar (255) NULL,
	depth                   nvarchar (255) NULL,
	size                    nvarchar (255) NULL,
    [date_added] [nvarchar](500) NULL,					
    [etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


  CREATE TABLE [psa].[mx_crp_store_trial_analysis]
(
    [row_id] [bigint] NOT NULL,
    [store_number] [nvarchar](100) NULL,
    [trading_week] [nvarchar](100) NULL,
    [item_code]  [nvarchar](10) NULL,
    [units] [nvarchar](10) NULL,
	[tesp] [nvarchar](100) NULL,
	[tisp] [nvarchar](100) NULL,
	[epos_profit] [nvarchar](100) NULL,
	[sales_type] [nvarchar](100) NULL,	
	[prescription] [nvarchar](100) NULL,	
    [date_added] [nvarchar](500) NULL,
    [etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO


CREATE TABLE [psa].[mx_crp_store]  
(
    [row_id] [bigint] NOT NULL,
    [store_number] [nvarchar](80) NULL,
	[store_name] [nvarchar](80) NULL,
	[address_line1] [nvarchar](80) NULL,
	[address_line2] [nvarchar](80) NULL,
	[address_line3] [nvarchar](80) NULL,
	[address_line4] [nvarchar](80) NULL,
	[postal_code] [nvarchar](10) NULL,
	[area_code] [nvarchar](255) NULL,
	[district_code] [nvarchar](255) NULL,
	[region_code] [nvarchar](255) NULL,
	[store_ndsa] [nvarchar](255) NULL,
	[store_size] [nvarchar](255) NULL,
	[store_format] [nvarchar](255) NULL,
	[store_loc] [nvarchar](255) NULL,
	[open_date] [nvarchar](25) NULL,
	[close_date] [nvarchar](25) NULL,
	[longitude] [nvarchar](255) NULL,
	[latitude] [nvarchar](255) NULL,
	[heritage_flag] [nvarchar](1) NULL,		
	[heritage_company] [nvarchar](80) NULL,		
	[date_added] [nvarchar](500) NULL,
    [etl_runlog_id] [int] NULL,
    [asset_id] [int] NULL,
    [record_source_id] [int] NULL,
    [row_status] [int] NULL,
    [created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
    DISTRIBUTION = HASH([row_id]),
    CLUSTERED COLUMNSTORE INDEX
)
GO
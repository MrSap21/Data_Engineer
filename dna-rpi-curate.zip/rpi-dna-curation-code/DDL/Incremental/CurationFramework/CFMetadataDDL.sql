CREATE TABLE [psa].[cf_batch] 
( 
    [batch_id] [int] NOT NULL, 
    [batch_name] [nvarchar](100) NULL, 
    [feed_id] [int] NOT NULL, 
    [order_of_execution] [int] NOT NULL, 
    [active_flag] [smallint] NOT NULL, 
    [dt_created] [datetime] NULL, 
    [user_created] [nvarchar](100) NULL 
) 
WITH 
( 
    DISTRIBUTION = REPLICATE, 
    CLUSTERED COLUMNSTORE INDEX 
) 
GO 

  
CREATE TABLE [psa].[cf_feed_configuration] 
( 
    [feed_id] [int] NOT NULL, 
    [psa_table_name] [nvarchar](50) NULL, 
    [delta_capture_sp] [int] NOT NULL, 
    [curation_sp] [int] NOT NULL, 
    [record_filter_id] int NULL, 
    [depends_on] [nvarchar](25) NULL, 
    [null_conv_char] [nvarchar](255) NULL, 
    [active_flag] [smallint] NOT NULL, 
    [dt_created] [smalldatetime] NULL, 
    [user_created] [nvarchar](100) NULL 
) 
WITH 
( 
    DISTRIBUTION = REPLICATE, 
    CLUSTERED COLUMNSTORE INDEX 
) 
GO 

  

CREATE TABLE [psa].[cf_feed_filter] 
( 
    [filter_id] [int] NOT NULL, 
    [filter_value] [nvarchar](50) NULL, 
    [filter_key_start] [int] NOT NULL, 
    [filter_key_end] [int] NOT NULL, 
    [filter_in_flag] [smallint] NOT NULL,
    [active_flag] [smallint] NOT NULL, 
    [dt_created] [smalldatetime] NULL, 
    [user_created] [nvarchar](100) NULL 
) 
WITH 
( 
    DISTRIBUTION = REPLICATE, 
    CLUSTERED COLUMNSTORE INDEX 
) 
GO 

  
CREATE TABLE [psa].[cf_stored_proc] 
( 
    [sp_id] [int] NOT NULL, 
    [sp_name] [nvarchar](50) NULL, 
    [active_flag] [smallint] NOT NULL, 
    [dt_created] [smalldatetime] NULL, 
    [user_created] [nvarchar](100) NULL 
) 
WITH 
( 
    DISTRIBUTION = REPLICATE, 
    CLUSTERED COLUMNSTORE INDEX 
) 
GO 

  
CREATE TABLE [psa].[cf_etl_audit] 
( 
    [id] [bigint] IDENTITY(1,1) NOT NULL, 
    [feed_id] [int] NOT NULL, 
    [etl_runlog_id] [int] NOT NULL, 
    [feed_status_id] [int] NOT NULL,   
    [dt_created] [datetime] NULL, 
    [user_created] [nvarchar](100) NULL 
) 
WITH 
( 
    DISTRIBUTION = REPLICATE, 
    CLUSTERED COLUMNSTORE INDEX 
) 
GO 

  
CREATE TABLE [psa].[cf_feed_load_status] 
( 
    [id] [int] NOT NULL, 
    [status] [nvarchar](50) NULL,  --STARTED/FAILED/ONHOLD/COMPLETED 
    [active_flag] [smallint] NOT NULL, 
    [dt_created] [smalldatetime] NULL, 
    [user_created] [nvarchar](100) NULL 
) 
WITH 
( 
    DISTRIBUTION = REPLICATE, 
    CLUSTERED COLUMNSTORE INDEX 
) 
GO
CREATE TABLE [psa].[Attribute]
(
    [AttributeId] [int] NOT NULL,
    [EntityId] [int] NOT NULL,
    [AttributeName] [nvarchar](128) NOT NULL,
    [AttributeDescription] [nvarchar](1024) NULL,
    [Position] [smallint] NOT NULL,
    [DataTypeId] [int] NOT NULL,
    [DataLength] [int] NULL,
    [DataScale] [int] NULL,
    [DataPrecision] [int] NULL,
    [IsNullable] [bit] NULL,
    [AttributeType] [int] NULL,
    [ActiveFlag] [smallint] NOT NULL,
    [DTCreated] [smalldatetime] NULL,
    [UserCreated] [nvarchar](128) NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
)
GO
CREATE TABLE [psa].[AttributeBkp]
(
    [AttributeId] [bigint] NOT NULL,
    [EntityId] [bigint] NOT NULL,
    [AttributeName] [nvarchar](128) NOT NULL,
    [AttributeDescription] [nvarchar](1024) NULL,
    [Position] [smallint] NOT NULL,
    [DataTypeId] [int] NOT NULL,
    [DataWidth] [int] NULL,
    [DataLength] [int] NULL,
    [DataScale] [int] NULL,
    [DataPrecision] [int] NULL,
    [ActiveFlag] [smallint] NOT NULL,
    [DTCreated] [smalldatetime] NULL,
    [UserCreated] [nvarchar](128) NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
)
GO

CREATE TABLE [psa].[Entity]
(
    [EntityID] [int] NOT NULL,
    [EntityCode] [nvarchar](32) NOT NULL,
    [EntityName] [nvarchar](128) NOT NULL,
    [EntityDescription] [nvarchar](1024) NULL,
    [LayerID] [int] NOT NULL,
    [DomainID] [int] NOT NULL,
    [SchemaName] [nvarchar](128) NOT NULL,
    [TableName] [nvarchar](128) NOT NULL,
    [ActiveFlag] [smallint] NOT NULL,
    [DTCreated] [smalldatetime] NULL,
    [UserCreated] [nvarchar](128) NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
)
GO
CREATE TABLE [psa].[MappingEntity]
(
    [MappingID] [int] NOT NULL,
    [SourceEntityID] [int] NOT NULL,
    [TargetEntityID] [int] NOT NULL,
    [MappingSequence] [smallint] NULL,
    [DTCreated] [smalldatetime] NULL,
    [UserCreated] [nvarchar](128) NULL
) 
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
)
GO
CREATE TABLE [psa].[Rule]
(
    [RuleID] [int] NOT NULL,
    [RuleCode] [nvarchar](20) NOT NULL,
    [RuleName] [nvarchar](128) NOT NULL,
    [RuleDescription] [nvarchar](1024) NULL,
    [Logic] [nvarchar](4000) NULL,
    [ScopeID] [int] NOT NULL,
    [GroupID] [int] NOT NULL,
    [ActiveFlag] [smallint] NOT NULL,
    [DTCreated] [smalldatetime] NULL,
    [UserCreated] [nchar](100) NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
)
GO

CREATE TABLE [psa].[RuleEntity]
(
    [RuleEntityID] [bigint] IDENTITY(1,1) NOT NULL,
    [RuleID] [int] NOT NULL,
    [EntityID] [int] NOT NULL,
    [AttributeID] [int] NULL,
    [SuccessActionId] [int] NOT NULL,
    [FailureActionId] [int] NOT NULL,
    [ConvertStyle] [nvarchar](4000) NULL,
    [ActiveFlag] [smallint] NOT NULL,
    [DTCreated] [smalldatetime] NULL,
    [UserCreated] [nvarchar](128) NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
)
GO

CREATE TABLE [psa].[RuleEntityInstance]
(
    [RuleEntityInstanceID] [bigint] IDENTITY(1,1) NOT NULL,
    [RuleID] [int] NOT NULL,
    [EntityID] [int] NOT NULL,
    [AttributeID] [int] NULL,
    [RuleDetail] [nvarchar](max) NULL,
    [ETLRunLogID] [int] NULL,
    [SourceEntityID] [int] NOT NULL,
    [SourceAttributeID] [nvarchar](128) NOT NULL,
    [PSARowKey] [bigint] NULL,
    [DTCreated] [smalldatetime] NULL,
    [UserCreated] [nvarchar](128) NULL
)
WITH
(
    DISTRIBUTION = ROUND_ROBIN,
    HEAP
)
GO

CREATE TABLE [psa].[RuleEntityOperation]
(
	[RuleEntityOperationID] [bigint] IDENTITY(1,1) NOT NULL,
	[DQID] [int] NOT NULL,
	[Ordinal] [int] NOT NULL,
	[Part] [int] NOT NULL,
	[EntityID] [int] NOT NULL,
	[ETLRunLogID] [int] NULL,
	[Logic] [nvarchar](4000) NULL,
	[DTCreated] [smalldatetime] NULL,
	[UserCreated] [nvarchar](128) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO
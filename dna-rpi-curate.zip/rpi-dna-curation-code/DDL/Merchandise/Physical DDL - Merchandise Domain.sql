 /* 
 * TABLE: [Planogram] 
 */
CREATE TABLE [ser].[Planogram](
    [PlanogramId]           bigint          NOT NULL,
    [SourceKey]             nvarchar(80)    NULL,
    [LOVSourceKeyTypeId]    int             NOT NULL,
    [PlanogramStartDate]    datetime        NULL,
    [PlanogramEndDate]      datetime        NULL,
    [PlanogramName]         nvarchar(100)    NULL,
    [ParentPlanogramId]     bigint          NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVSourceKeyTypeId],[LOVRecordSourceId])
)
go

/* 
 * TABLE: [PlanogramStatus] 
 */

CREATE TABLE [ser].[PlanogramStatus](
    [PlanogramId]              bigint      NOT NULL,
    [LOVPlanogramStatusSetId]  int         NOT NULL,
    [LOVStatusId]              int         NOT NULL,
    [EffectiveFrom]            datetime    NULL,
    [EffectiveTo]              datetime    NULL,
    [LOVRecordSourceId]        int         NOT NULL,
    [SCDStartDate]             datetime    NULL,
    [SCDEndDate]               datetime    NULL,
    [SCDActiveFlag]            nchar(1)    NULL,
    [SCDVersion]               smallint    NULL,
    [SCDLOVRecordSourceId]     int         NULL,
    [ETLRunLogId]              int         NULL,
    [PSARowKey]                bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVPlanogramStatusSetId],[LOVRecordSourceId])
)
go
/* 
 * TABLE: [PlanogramGroup] 
 */

CREATE TABLE [ser].[PlanogramGroup](
    [PlanogramGroupId]        bigint      NOT NULL,
    [PlanogramId]             bigint      NOT NULL,
    [LOVPlanogramGroupSetId]  int         NOT NULL,
    [LOVGroupId]              int         NOT NULL,
    [ParentPlanogramGroupId]  bigint      NULL,
    [LOVRecordSourceId]       int         NOT NULL,
    [SCDStartDate]            datetime    NULL,
    [SCDEndDate]              datetime    NULL,
    [SCDActiveFlag]           nchar(1)    NULL,
    [SCDVersion]              smallint    NULL,
    [SCDLOVRecordSourceId]    int         NULL,
    [ETLRunLogId]             int         NULL,
    [PSARowKey]               bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVPlanogramGroupSetId],[LOVRecordSourceId])
)
go

/* 
 * TABLE: [PlanogramProperty] 
 */

CREATE TABLE [ser].[PlanogramProperty](
    [PlanogramId]           bigint           NOT NULL,
    [MeasureId]             int              NOT NULL,
    [LOVUOMId]              int              NOT NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  int              NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go
/* 
 * TABLE: [PlanogramFixture] 
 */
CREATE TABLE [ser].[PlanogramFixture](
    [PlanogramFixtureId]    bigint          NOT NULL,
    [PlanogramId]           bigint          NOT NULL,
    [SourceKey]             nvarchar(80)    NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go
/* 
 * TABLE: [PlanogramFixtureProperty] 
 */
CREATE TABLE [ser].[PlanogramFixtureProperty](
    [PlanogramFixtureId]    bigint           NOT NULL,
    [MeasureId]             int              NOT NULL,
    [LOVUOMId]              int              NOT NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  int              NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go
/* 
 * TABLE: [PlanogramPosition] 
 */
CREATE TABLE [ser].[PlanogramPosition](
    [PlanogramPositionId]   bigint          NOT NULL,
    [ProductId]             bigint          NOT NULL,
    [PlanogramId]           bigint          NOT NULL,
    [PlanogramFixtureId]    bigint          NULL,
    [SourceKey]             nvarchar(80)    NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go
/* 
 * TABLE: [PlanogramPositionProperty]
 */
CREATE TABLE [ser].[PlanogramPositionProperty](
    [PlanogramPositionId]   bigint           NOT NULL,
    [MeasureId]             int              NOT NULL,
    [LOVUOMId]              int              NOT NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  int              NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go

/* 
 * TABLE: [PlanogramIndicator]
 */
CREATE TABLE [ser].[PlanogramIndicator]
(
	[PlanogramId] [bigint] NOT NULL,
	[LovIndicatorId] [int] NOT NULL,
	[Value] [nvarchar](255) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
    CLUSTERED COLUMNSTORE INDEX
)
GO

CREATE TABLE [ser].[Fact](
    [FactId]                bigint          NOT NULL,
    [FactName]              nvarchar(80)    NOT NULL,
    [LOVFactTypeId]         int             NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL
)
    WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)

go

CREATE TABLE [ser].[FactDimension](
    [FactId]                bigint      NOT NULL,
    [DimensionId]           int         NOT NULL,
    [Sequence]              smallint    NULL,
    [Mandatory]             nchar(1)    NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL
)
 WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go

CREATE TABLE [ser].[FactDimensionInstance](
    [FactInstanceId]         bigint          NOT NULL,
    [DimensionId]            int             NOT NULL,
    [DimensionSurrogateKey]  int             NULL,
    [DimensionSourceKey]     nvarchar(80)    NULL,
    [LOVRecordSourceId]      int             NOT NULL,
    [SCDStartDate]           datetime        NULL,
    [SCDEndDate]             datetime        NULL,
    [SCDActiveFlag]          nchar(1)        NULL,
    [SCDVersion]             smallint        NULL,
    [SCDLOVRecordSourceId]   int             NULL,
    [ETLRunLogId]            int             NULL,
    [PSARowKey]              bigint          NULL
)
 WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go
CREATE TABLE [ser].[Dimension](
    [DimensionId]           int             NOT NULL,
    [Name]                  nvarchar(80)    NOT NULL,
    [Description]           nvarchar(80)    NULL,
    [Schema]                nvarchar(80)    NULL,
    [Tablename]             nvarchar(80)    NOT NULL,
    [SurrogateKeyColumn]    nvarchar(80)    NOT NULL,
    [SourceKeyColumn]       nvarchar(80)    NOT NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL
)
 WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go
CREATE TABLE [ser].[FactInstance](
    [FactInstanceId]        bigint      NOT NULL,
    [FactId]                bigint      NOT NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [PSARowKey]             bigint      NULL
)
 WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go
CREATE TABLE [ser].[FactMeasure](
    [FactId]                bigint      NOT NULL,
    [MeasureId]             int         NOT NULL,
    [Sequence]              smallint    NULL,
    [Mandatory]             nchar(1)    NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go

CREATE TABLE [ser].[FactMeasureInstance](
    [FactInstanceId]        bigint           NOT NULL,
    [MeasureId]             int              NOT NULL,
    [Value]                 nvarchar(255)    NOT NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  int              NULL,
    [ETLRunLogId]           int              NULL,
    [PSARowKey]             bigint           NULL
)
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go
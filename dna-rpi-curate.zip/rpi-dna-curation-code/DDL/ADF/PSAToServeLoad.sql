/****** Object:  Table [dbo].[serve_sp_mapping]    Script Date: 26/06/2020 12:46:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[serve_sp_mapping]
(
	[Domain] [nvarchar](100) NULL,
	[TableName] [nvarchar](200) NOT NULL,
	[SPName] [nvarchar](200) NOT NULL,
	[SPOrder] [int] NULL,
	[SPStatus] [nvarchar](2) NULL,
 CONSTRAINT [PK_serve_sp_mapping] PRIMARY KEY NONCLUSTERED 
	(
		[TableName] ASC,
		[SPName] ASC
	) NOT ENFORCED 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO
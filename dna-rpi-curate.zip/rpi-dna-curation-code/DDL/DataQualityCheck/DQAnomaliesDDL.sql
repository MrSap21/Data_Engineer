/****** Object:  Table [psa].[DQAnomalies]    Script Date: 16/07/2020 11:37:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [psa].[DQAnomalies]
(
	[RuleType] [varchar](500) NULL,
	[TableName] [varchar](500) NULL,
	[ColumnName] [varchar](500) NULL,
	[KeyValue] [varchar](500) NULL,
	[Recordsourceid] [bigint] NULL,
	[row_id] [bigint] NULL,
	[created_timestamp] [datetime] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO
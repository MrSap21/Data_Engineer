SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[reflovset]
(
	[LOVSetId] [int] NOT NULL,
	[LOVSetKey] [nvarchar](40) NOT NULL,
	[LOVSetName] [nvarchar](255) NOT NULL,
	[LOVSetDescription] [nvarchar](1024) NULL,
	[LOVSetSequence] [smallint] NULL,
	[LOVSetRecordSourceId] [int] NOT NULL,
	[DTCreated] [smalldatetime] NULL,
	[UserCreated] [nvarchar](128) NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [char](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO

/****** Object:  Table [ser].[reflov]****/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[reflov]
(
	[LOVId] [int] NOT NULL,
	[LOVSetId] [int] NOT NULL,
	[LOVKey] [nvarchar](255) NOT NULL,
	[LOVName] [nvarchar](255) NOT NULL,
	[LOVDescription] [nvarchar](1024) NULL,
	[LOVSequence] [bigint] NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[DTCreated] [smalldatetime] NULL,
	[UserCreated] [nvarchar](128) NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [char](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [psa].[DQRules]
(
	[RuleId] [int] IDENTITY(1,1) NOT NULL,
	[RuleType] [varchar](200) NULL,
	[TableName] [nvarchar](500) NULL,
	[ColumnName] [nvarchar](500) NULL,
	[RuleSetName] [nvarchar](500) NULL,
	[RuleKey] [nvarchar](500) NULL,
	[Datatype] [nvarchar](500) NULL,
	[RecordSourceID] [bigint] NULL,
	[ActiveFlag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([RuleId],[RecordSourceID])
)
GO
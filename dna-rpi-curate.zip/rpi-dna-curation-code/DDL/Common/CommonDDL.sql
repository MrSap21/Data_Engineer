/****** Object:  Table [ser].[reflovset]******/
/*SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[reflovset]
(
	[LOVSetId] [int] NOT NULL,
	[LOVSetKey] [nvarchar](40) NOT NULL,
	[LOVSetName] [nvarchar](255) NOT NULL,
	[LOVSetDescription] [nvarchar](1024) NULL,
	[LOVSetSequence] [smallint] NULL,
	[LOVSetRecordSourceId] [int] NOT NULL,
	[DTCreated] [smalldatetime] NULL,
	[UserCreated] [nvarchar](128) NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [char](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO*/

/****** Object:  Table [ser].[reflov]****/
/*SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[reflov]
(
	[LOVId] [int] NOT NULL,
	[LOVSetId] [int] NOT NULL,
	[LOVKey] [nvarchar](255) NOT NULL,
	[LOVName] [nvarchar](255) NOT NULL,
	[LOVDescription] [nvarchar](1024) NULL,
	[LOVSequence] [bigint] NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[DTCreated] [smalldatetime] NULL,
	[UserCreated] [nvarchar](128) NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [char](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO*/

/* 
 * TABLE: [Measure] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[Measure](
    [MeasureId]             int             NOT NULL,
    [LOVMeasureTypeId]      int             NOT NULL,
    [LOVDataTypeId]         int             NOT NULL,
    [MeasureName]           nvarchar(80)    NOT NULL,
    [MeasureDescription]    nvarchar(1000)  NULL,
    [Length]                smallint        NULL,
    [Precision]             smallint        NULL,
    [Scale]                 smallint        NULL,
    [StandardMeasureId]     int             NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVMeasureTypeId],[LOVDataTypeId],[LOVRecordSourceId])
)
go

/* 
 * TABLE: [Party] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[Party](
    [PartyId]               bigint          NOT NULL,
    [LOVPartyTypeId]        int             NOT NULL,
    [SourceKey]             nvarchar(80)    NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVPartyTypeId],[LOVRecordSourceId])
)
go



/* 
 * TABLE: [Organisation] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[Organisation](
    [PartyId]                bigint          NOT NULL,
    [SourceOrganisationKey]  nvarchar(80)    NULL,
    [OrganisationName]       nvarchar(80)    NULL,
    [ParentPartyId]          bigint          NULL,
    [LOVRecordSourceId]      int             NOT NULL,
    [SCDStartDate]           datetime        NULL,
    [SCDEndDate]             datetime        NULL,
    [SCDActiveFlag]          nchar(1)        NULL,
    [SCDVersion]             smallint        NULL,
    [SCDLOVRecordSourceId]   int             NULL,
    [ETLRunLogId]            int             NULL,
    [PSARowKey]              bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRecordSourceId])
)
go

/* 
 * TABLE: [PartyRole] 
 */
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ser].[PartyRole](
    [PartyRoleId]           bigint          NOT NULL,
    [LOVRoleId]             int             NOT NULL,
    [PartyId]               bigint          NOT NULL,
    [SourceKey]             nvarchar(80)    NULL,
    [PartyRoleName]         nvarchar(80)    NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,
    [SCDEndDate]            datetime        NULL,
    [SCDActiveFlag]         nchar(1)        NULL,
    [SCDVersion]            smallint        NULL,
    [SCDLOVRecordSourceId]  int             NULL,
    [ETLRunLogId]           int             NULL,
    [PSARowKey]             bigint          NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVRoleId],[LOVRecordSourceId])
)
go
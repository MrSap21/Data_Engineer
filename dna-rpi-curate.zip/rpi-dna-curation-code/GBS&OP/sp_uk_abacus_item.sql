IF OBJECT_ID('psa.sp_uk_abacus_item') IS NOT NULL
BEGIN
    DROP PROC psa.sp_uk_abacus_item
END;


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
************************************************************************************************************
Procedure Name			: sp_uk_abacus_item
Purpose					: Load Incremental data from Item Feed (01473.txt) source table(#uk_abacus_item_tmp) into Serve Layer Table
Domain					: Transaction
RecordSourceID  for UKROI Transaction	: 12006

**************************************************************************************************************
*/


	


CREATE PROC [psa].[sp_uk_abacus_item] @serveETLRunLogID VARCHAR(MAX), @tablename VARCHAR(MAX), @psaEntityId VARCHAR(MAX) AS

DECLARE @uklc_lovRecordSourceID 			BIGINT; 
DECLARE @uklc_scdLovRecordSourceID 			BIGINT; 
DECLARE @psa_rowstatus 						BIGINT; 
DECLARE @ser_rowstatus 						BIGINT;
DECLARE @uklc_RoleId 						BIGINT;
DECLARE @max_productid 						BIGINT; 
DECLARE @uklc_srckeytypeid 					BIGINT;
DECLARE @uklc_partyroleid					BIGINT;
DECLARE @uklc_lovindicatorid				BIGINT;
DECLARE @uklc_lovuomideur					BIGINT;
DECLARE @uklc_lovuomidgbp					BIGINT;
DECLARE @sourceschema						VARCHAR(20);
DECLARE @sourcetable						VARCHAR(20);
DECLARE @tablecolumns				VARCHAR(500);
declare @exec_sql					VARCHAR(1000);
DECLARE	@mdm_lovRecordSourceID				BIGINT;
DECLARE @max_transactionLineItemMeasureID	BIGINT;
DECLARE @max_transactionLineItemid	BIGINT;
DECLARE @measureTypeID				 		BIGINT;
DECLARE @integer_dataTypeID			 		BIGINT;
DECLARE @decimal_dataTypeID			 		BIGINT;
DECLARE @salesunits_measureID		 		BIGINT;
DECLARE @salesattisp_measureID 		 		BIGINT;
DECLARE @salesattesp_measureID		 		BIGINT;
DECLARE @saleseposprofit_measureID	 		BIGINT;
DECLARE @sapsalesattisp_measureID 	 		BIGINT;
DECLARE @eposprofitadjusted_measureID		BIGINT;
DECLARE @saleitemdispercent_measureID		BIGINT;
DECLARE @takings_measureID		 	 		BIGINT;
DECLARE @revenue_measureID		 	 		BIGINT;
DECLARE @itempointsqty_measureID 	 		BIGINT;
DECLARE @itempointsval_measureID 	 		BIGINT;
DECLARE @mapp_measureID			     		BIGINT;
DECLARE @refundflag_indicatorID		 		BIGINT;
DECLARE @itemdisoverriddenflag_indicatorID	BIGINT;
DECLARE @priceoverriddenitemflag_indicatorID BIGINT;
--DECLARE @max_ruleentityinstanceid			BIGINT;
DECLARE @ruleId 					 		BIGINT;
DECLARE @attributeid						BIGINT;
DECLARE @feed_entityid 						BIGINT;
DECLARE @salesattespgbproi_measureID 		 		BIGINT;
DECLARE @max_TransformationId BIGINT;

BEGIN		

SET @uklc_lovRecordSourceID = 12006; 
SET @uklc_scdLovRecordSourceID = 12006; 
SET @psa_rowstatus = 26001; 
SET @ser_rowstatus = 26002;
SET	@mdm_lovRecordSourceID = 12008;
SET @sourceschema = 'psa';
SET @sourcetable = 'uk_abacus_item';
SET @feed_entityid = (select sourceentityid from psa.[MappingEntity] me inner join psa.[Entity] e on me.sourceentityid = e.EntityID where me.[TargetEntityID] = @psaEntityId and e.SchemaName like '%feed%');






/* Creation of temporary table to store records wit rowstatus 26001 from PSA Source table */
IF OBJECT_ID('tempdb..#uk_abacus_item_tmp') IS NOT NULL
BEGIN
	DROP TABLE #uk_abacus_item_tmp
END

SELECT * INTO #uk_abacus_item_tmp
FROM (SELECT 
row_id,record_type,
ISNULL( NULLIF((Substring(ITEM_CODE, Patindex('%[^0]%', ITEM_CODE + ' '), Len(ITEM_CODE)) ),''),0) ITEM_CODE,
ISNULL( NULLIF((Substring(STORE_NUMBER, Patindex('%[^0]%', STORE_NUMBER + ' '), Len(STORE_NUMBER)) ),''),0) STORE_NUMBER,
ISNULL( NULLIF((Substring(TILL_NUMBER, Patindex('%[^0]%', TILL_NUMBER + ' '), Len(TILL_NUMBER)) ),''),0) TILL_NUMBER,
TILL_TXN_NUMBER,TILL_TXN_DATE,TILL_TXN_TIME,SIGN,SALES_UNITS,SIGN_TISP,SALES_AT_TISP,SIGN_TESP,SALES_AT_TESP,SIGN_PROFIT,EPOS_PROFIT,
SIGN_NCP,SALES_AT_NCP,SIGN_DISCPC,SALE_ITEM_DISC_PC,SIGN_ITEM,ITEM_REDUCTION_AMT,ITEM_DISC_ORIDE_FLG,PRICE_ORIDE_IT_FLG,SIGN_TAKINGS,TAKINGS,SIGN_REVENUE,REVENUE,SIGN_EPOS,EPOS_PROFIT_ADJ,
SIGN_ITMPNTQTY,ITEM_POINTS_QUANTITY,SIGN_ITMPNTVAL,ITEM_POINTS_VALUE,etl_runlog_id,asset_id,record_source_id,row_status,created_timestamp,active_flag
FROM psa.uk_abacus_item WHERE row_status = @psa_rowstatus AND record_type = '2'
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)A;


RAISERROR ('Completed insertion of TEMP ABACUS ITEM PSA table', 0, 1) WITH NOWAIT;


UPDATE #uk_abacus_item_tmp SET till_txn_date = CONCAT(SUBSTRING(till_txn_date,7,4),SUBSTRING(till_txn_date,4,2),SUBSTRING(till_txn_date,1,2));


RAISERROR ('Completed updation of TEMP ABACUS ITEM PSA table', 0, 1) WITH NOWAIT;


/*creation of temp currency conversion table */
IF OBJECT_ID('tempdb..#currency_conversion_tmp') IS NOT NULL
BEGIN
	DROP TABLE #currency_conversion_tmp
END

SELECT * INTO #currency_conversion_tmp
FROM (select distinct cr.ConversionRate, cr.effectiveto,cr.effectiveFrom,cr.lovrecordsourceid
  FROM [ser].[CurrencyConversion]  cc
  INNER JOIN [ser].[CurrencyConversionRate] cr
  ON  [LOVSourceCurrencyId]=(select lovid from ser.reflov where lovkey='EUR' and lovsetid =(select lovsetid from ser.reflovset
  where lovsetname='Global Brands Currency Codes' and recordsourceid=12023) and recordsourceid=12023 )
  AND[LOVTargetCurrencyId]=(select lovid from ser.reflov where lovkey='GBP' and lovsetid =(select lovsetid from ser.reflovset where
  lovsetname='Global Brands Currency Codes' and recordsourceid=12023) and recordsourceid=12023)
  AND [LOVConversionTypeId] = (select lovid from ser.reflov where lovkey='Budget' and lovsetid =(select lovsetid from ser.reflovset
  where lovsetname='Conversion Type' and recordsourceid=12023) and recordsourceid=12023)
  AND [LOVConversionMethodId]= (select lovid from ser.reflov where lovkey='PAVG' and lovsetid =(select lovsetid from ser.reflovset
  where lovsetname='Conversion Method' and recordsourceid=12023) and recordsourceid=12023)
  AND cc.[CurrencyConversionId] = cr.[CurrencyConversionId]
)A;


RAISERROR ('Completed insertion of TEMP currencyconversion table', 0, 1) WITH NOWAIT;



/* Creation of temporary table to store lovindicatorid value for UOMId from SITEROLEINDICATOR table */
IF OBJECT_ID('tempdb..#SITEROLE_ROIIND_temp') IS NOT NULL
BEGIN
	DROP TABLE #SITEROLE_ROIIND_temp
END
	
SET @uklc_lovindicatorid = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Indicator - BUK MDM Site' AND lovkey = 'roi_ind');
SET @uklc_lovuomideur = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Currency ISO 4217' AND lovkey = 'EUR');
SET @uklc_lovuomidgbp = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Currency ISO 4217' AND lovkey = 'GBP');

SELECT * INTO #SITEROLE_ROIIND_temp
FROM (SELECT store_number, row_id, record_source_id, etl_runlog_id, siterole.siteroleid, CASE WHEN value = 1 THEN @uklc_lovuomideur ELSE @uklc_lovuomidgbp END lovuomid FROM 
(SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
) abacusitem
LEFT OUTER JOIN (SELECT DISTINCT siteroleid, sourcekey FROM ser.SiteRole WHERE lovrecordsourceid = @mdm_lovRecordSourceID AND SCDActiveFlag = 'Y') siterole 
ON siterole.sourcekey = abacusitem.store_number
LEFT OUTER JOIN (SELECT siteroleid, value FROM ser.SiteRoleIndicator WHERE SCDActiveFlag = 'Y' AND lovrecordsourceid = @mdm_lovRecordSourceID AND lovindicatorid = @uklc_lovindicatorid) siteroleind
ON siteroleind.siteroleid = siterole.siteroleid)A
;


RAISERROR ('Completed insertion of TEMP SITEROLEINDICATOR table for roi_ind lookup', 0, 1) WITH NOWAIT;


UPDATE #uk_abacus_item_tmp SET till_txn_time = '00:00'
WHERE till_txn_time LIKE '%[A-Za-z]%' OR till_txn_time IS NULL OR TRIM(till_txn_time) = '';


RAISERROR ('Completed updation of till_txn_time in TEMP ABACUS ITEM PSA table', 0, 1) WITH NOWAIT;


/* Raise DQ warning for the insertion of new 000000 time */

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Time Check' AND RuleCode = 'TC');
SET @attributeid = (SELECT AttributeId FROM psa.Attribute WHERE attributename = 'till_txn_time' AND entityid = @feed_entityid);

INSERT INTO psa.RuleEntityInstance(
--	RuleEntityInstanceID	,
	RuleID					,
	EntityID				,
	AttributeID				,
	RuleDetail				,
	ETLRunLogID				,
	SourceEntityID			,
	SourceAttributeID		,
	PSARowKey				,
	DTCreated				,
	UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY row_id) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--till_txn_time--Record value changed to 000000 for till_txn_time due to invalid format' RuleDetail,
@serveETLRunLogID ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM psa.uk_abacus_item 
WHERE (till_txn_time LIKE '%[A-Za-z]%' OR till_txn_time IS NULL OR TRIM(till_txn_time) = '') AND row_status = @psa_rowstatus)Z

UNION

SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY row_id) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--till_txn_time--Record value changed to 000000 for till_txn_time due to invalid format' RuleDetail,
@serveETLRunLogID ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM #uk_abacus_item_tmp 
WHERE (CAST(SUBSTRING(till_txn_time,1,2) AS INT) > 23 OR CAST(SUBSTRING(till_txn_time,4,2) AS INT) > 59) AND row_status = @psa_rowstatus)Z
;


RAISERROR ('Completed insertion in RuleEntityInstance table for invalid time', 0, 1) WITH NOWAIT;


UPDATE #uk_abacus_item_tmp SET till_txn_time = '00:00'
WHERE CAST(SUBSTRING(till_txn_time,1,2) AS INT) > 23 OR CAST(SUBSTRING(till_txn_time,4,2) AS INT) > 59;


RAISERROR ('Completed updation of till_txn_time in TEMP ABACUS ITEM PSA table', 0, 1) WITH NOWAIT;


/* Creation of temporary table to store transactionid from Transaction table for populating transactionlineitem and transactionlineitemmeasure tables */
IF OBJECT_ID('tempdb..#TRANSACTIONID_KEY_temp') IS NOT NULL
BEGIN
	DROP TABLE #TRANSACTIONID_KEY_temp
END
	
SELECT * INTO #TRANSACTIONID_KEY_temp
FROM (SELECT TransactionId, abacusitem.* 
FROM (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
LEFT OUTER JOIN (SELECT * FROM ser.Till WHERE lovrecordsourceid = @uklc_lovRecordSourceID AND SCDActiveFlag = 'Y') till 
ON till.sourcekey = abacusitem.till_number 
LEFT OUTER JOIN (SELECT * FROM ser.SiteRole WHERE lovrecordsourceid = @mdm_lovRecordSourceID AND SCDActiveFlag = 'Y') siterole
ON siterole.sourcekey = abacusitem.store_number
LEFT OUTER JOIN (SELECT * FROM ser.[Transaction] WHERE lovrecordsourceid = @uklc_lovRecordSourceID AND SCDActiveFlag = 'Y') trans
ON trans.tillid = till.tillid
AND trans.siteroleid = siterole.siteroleid
AND trans.tilltransactionnumber = abacusitem.till_txn_number
AND trans.transactiondatetime = CAST(CONCAT(abacusitem.till_txn_date,' ',abacusitem.till_txn_time) AS Datetime)
WHERE trans.LOVRecordSourceId=@uklc_lovRecordSourceID)A
;


RAISERROR ('Completed insertion of TEMP TRANSACTIONID_KEY table for itemcode and epos_txn_typ_flg lookup', 0, 1) WITH NOWAIT;


BEGIN TRY
BEGIN TRANSACTION


/* 1.Table Name : Product */

SET @max_productid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @uklc_srckeytypeid = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Source Key Type' AND lovkey = 'SAP Article Number'); 

INSERT INTO [ser].[Product] (ProductId, SourceKey, LOVSourceKeyTypeId, ProductName, ProductDescription, LOVBrandId, LOVSubBrandId, LOVRecordSourceId, ParentProductId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_productid + ROW_NUMBER() OVER(ORDER BY A.SourceKey ASC) ProductId, 
		A.SourceKey SourceKey, 
		@uklc_srckeytypeid LOVSourceKeyTypeId, 
		NULL ProductName, 
		NULL ProductDescription, 
		NULL LOVBrandId, 
		NULL LOVSubBrandId, 
		@mdm_lovRecordSourceID LOVRecordSourceId,
		NULL ParentProductId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@mdm_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey FROM
(SELECT src.sourcekey, src.date_row FROM 
(SELECT item_code SourceKey, MIN(row_id) date_row, record_source_id FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
GROUP BY item_code, record_source_id) src 
LEFT OUTER JOIN [ser].[Product] P ON src.sourcekey = P.sourcekey AND P.LOVRecordSourceId = @mdm_lovRecordSourceID WHERE P.sourcekey IS NULL AND src.sourcekey IS NOT NULL AND src.sourcekey != '') A

UNION

/* Below scenario to handle Soft Delete of product id/item code */
SELECT	product.ProductId ProductId, 
		abacusitem.item_code SourceKey, 
		@uklc_srckeytypeid LOVSourceKeyTypeId, 
		NULL ProductName, 
		NULL ProductDescription, 
		NULL LOVBrandId, 
		NULL LOVSubBrandId, 
		@mdm_lovRecordSourceID LOVRecordSourceId,
		NULL ParentProductId,
		CURRENT_TIMESTAMP SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		version + 1 SCDVersion, 
		@mdm_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		row_id PSARowKey FROM
(SELECT item_code, MIN(row_id) row_id FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
GROUP BY item_code) abacusitem
JOIN (SELECT sourcekey, productid, version FROM
(SELECT sourcekey, productid, SCDVersion version, SCDActiveFlag, RANK() OVER(PARTITION BY sourcekey,lovrecordsourceid ORDER BY sourcekey,lovrecordsourceid,SCDVersion desc) row_num 
FROM ser.Product WHERE lovrecordsourceid = @mdm_lovRecordSourceID)A WHERE A.row_num = 1 AND A.SCDActiveFlag = 'N') product
ON abacusitem.item_code = product.sourcekey
;


RAISERROR ('Completed insertion of ABACUS source data to PRODUCT table', 0, 1) WITH NOWAIT;


/* Raise DQ warning for the insertion of new product id */

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Skeleton Record Creation' AND RuleCode = 'SRC');
SET @attributeid = (SELECT AttributeId FROM psa.Attribute WHERE attributename = 'item_code' AND entityid = @feed_entityid);

INSERT INTO psa.RuleEntityInstance(
--	RuleEntityInstanceID	,
	RuleID					,
	EntityID				,
	AttributeID				,
	RuleDetail				,
	ETLRunLogID				,
	SourceEntityID			,
	SourceAttributeID		,
	PSARowKey				,
	DTCreated				,
	UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY sourcekey) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--ProductId--Record created for Item code due to non existence of ProductId' RuleDetail,
@serveETLRunLogID ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT sourcekey,psarowkey FROM ser.Product WHERE LOVRecordSourceId = @mdm_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID AND SCDActiveFlag = 'Y') product
JOIN #uk_abacus_item_tmp abacusitem
ON abacusitem.item_code = product.sourcekey
AND abacusitem.row_id = product.psarowkey
;


RAISERROR ('Completed insertion in RuleEntityInstance table for product', 0, 1) WITH NOWAIT;


/* 2.Table Name : ProductPartyRole */

SET @uklc_roleid = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Role' AND lovkey = 'Retailer'); 
SET @uklc_partyroleid = (SELECT PR.PartyRoleId FROM ser.PartyRole PR JOIN [ser].[Party] P ON P.partyid = PR.partyid WHERE P.sourcekey = 'WBA-UK-BTC' AND P.LOVRecordSourceId = @mdm_lovRecordSourceID AND PR.LOVRoleId = @uklc_roleid);

/*INSERT INTO [ser].[ProductPartyRole] (ProductId, PartyRoleId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  A.productId ProductId, 
		@uklc_partyroleid PartyRoleId, 
		@mdm_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@mdm_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey FROM
(SELECT P.productId, src.date_row FROM
(SELECT item_code,record_source_id, MIN(row_id) date_row FROM #uk_abacus_item_tmp 
WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
AND item_code IS NOT NULL AND item_code != '' GROUP BY item_code, record_source_id) src
JOIN [ser].[PRODUCT] P ON src.item_code = P.sourcekey AND P.LOVRecordSourceId = @mdm_lovRecordSourceID AND P.SCDActiveFlag = 'Y'
LEFT OUTER JOIN [ser].[ProductPartyRole]PPR ON P.productId = PPR.productId AND PPR.LOVRecordSourceId = @mdm_lovRecordSourceID WHERE PPR.productId IS NULL) A;*/

INSERT INTO [ser].[ProductPartyRole] (ProductId, PartyRoleId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  A.productId ProductId, 
		@uklc_partyroleid PartyRoleId, 
		@mdm_lovRecordSourceID LOVRecordSourceId,
		CASE WHEN (B.productid IS NULL) THEN '1900-01-01' ELSE CURRENT_TIMESTAMP END SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		CASE WHEN (B.productid IS NULL) THEN 1 ELSE B.version + 1 END SCDVersion, 
		@mdm_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey FROM
(SELECT P.productId, src.date_row FROM
(SELECT item_code,record_source_id, MIN(row_id) date_row FROM #uk_abacus_item_tmp 
WHERE row_status = @psa_rowstatus 
AND item_code IS NOT NULL AND item_code != '' GROUP BY item_code, record_source_id) src
JOIN [ser].[PRODUCT] P ON src.item_code = P.sourcekey AND P.LOVRecordSourceId = @mdm_lovRecordSourceID AND P.LOVSourceKeyTypeId = @uklc_srckeytypeid AND P.SCDActiveFlag = 'Y') A
LEFT OUTER JOIN
(SELECT productid, version, SCDActiveFlag FROM
(SELECT productid, partyroleid, lovrecordsourceid, SCDVersion version, SCDActiveFlag, 
RANK() OVER(PARTITION BY productId,partyroleid,lovrecordsourceid ORDER BY productId,partyroleid,lovrecordsourceid,SCDVersion DESC) row_num 
FROM ser.ProductPartyRole WHERE lovrecordsourceid = @mdm_lovRecordSourceID AND partyroleid = @uklc_partyroleid)A WHERE A.row_num = 1)B
ON A.productid = B.productid
WHERE B.SCDActiveFlag = 'N' OR B.SCDActiveFlag IS NULL;


RAISERROR ('Completed insertion of ABACUS source data to PRODUCTPARTYROLE table', 0, 1) WITH NOWAIT;


/* 3.Table Name  :  TransactionLineItem */

SELECT  @max_transactionLineItemID = COALESCE(MAX(TransactionLineItemId),0) FROM ser.TransactionLineItem
SELECT  @max_transactionLineItemMeasureID = COALESCE(MAX(TransactionLineItemMeasureId),0) FROM ser.TransactionLineItemMeasure	

INSERT INTO ser.TransactionLineItem(
	TransactionLineItemId	,
	TransactionId			,
	ProductId				,
	LOVLineItemTypeId		,
	DealId					,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

SELECT 
@max_transactionLineItemID+ROW_NUMBER() OVER(ORDER BY A.TransactionId) TransactionLineItemId, 
A.TransactionId TransactionId,
product.ProductId ProductId, 
NULL LOVLineItemTypeId, 
--ro.LOVId LOVLineItemTypeId, 
NULL DealId, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
row_id PSARowKey 
FROM
#TRANSACTIONID_KEY_temp A
JOIN (SELECT ProductId, sourcekey FROM ser.Product
WHERE SCDActiveFlag = 'Y' AND LOVRecordSourceId = @mdm_lovRecordSourceID AND lovsourceKeyTypeId = @uklc_srckeytypeid) product
ON product.sourceKey = A.item_code
--LEFT OUTER JOIN(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.reflov rl JOIN ser.reflovset rls 
--ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='till_transaction_type_code') ro
--ON A.LOVRecordSourceId =ro.LOVRecordSourceId AND ro.LOVKey=A.till_transaction_type_code
;


RAISERROR ('Completed insertion of ABACUS source data to TRANSACTION LINE ITEM table', 0, 1) WITH NOWAIT


/* 4.Table Name  :  TransactionLineItemMeasure */





SET @measureTypeID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Measure Type' AND lovkey = 'RETAIL_TRANS_AGG');
SET @salesunits_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'sales_units' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @salesattisp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'sales_at_tisp' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @salesattesp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'sales_at_tesp' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @saleseposprofit_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'sales_epos_profit' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @sapsalesattisp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'sap_sales_at_tisp' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @eposprofitadjusted_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'epos_profit_adjusted' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @saleitemdispercent_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'sale_item_discount_percentage' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @takings_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'takings' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @revenue_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'revenue' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @itempointsqty_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'item_points_quantity' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @itempointsval_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'item_points_value' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @mapp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'mapp' AND LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @salesattespgbproi_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'SALES_AT_TESP_GBP_ROI' AND LOVRecordSourceId = @uklc_lovRecordSourceID);

INSERT INTO ser.TransactionLineItemMeasure(
	TransactionLineItemMeasureId	,
	TransactionLineItemId 			,
	MeasureId  						,
	Value							,
	LOVUOMId						,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

SELECT @max_transactionLineItemMeasureID+DENSE_RANK() OVER(ORDER BY TransactionLineItemId, MeasureId) TransactionLineItemMeasureId, 
TransactionLineItemId, MeasureId, Value, LOVUOMId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey
FROM

(
SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@salesunits_measureID MeasureId,
CONCAT(sign,sales_units) Value, 
NULL LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@salesattisp_measureID MeasureId, 
--sales_at_tisp Value,  
/*  query that the resultant is same for all three conditions   */
CASE WHEN (CAST(CONCAT(sign_tisp,sales_at_tisp) AS decimal(18,6)) = 0
		AND CAST(CONCAT(sign_takings,takings) AS decimal(18,6)) = 0
		AND CAST(CONCAT(sign_itmpntqty,item_points_quantity) AS decimal(18,6)) < 0 AND reflovsetinfo.lovkey = 'R') 
		THEN CAST(CAST(CONCAT(sign_itmpntqty,item_points_quantity) AS decimal(18,6))/(-100) AS VARCHAR(255))
     WHEN (CAST(CONCAT(sign_tisp,sales_at_tisp) AS decimal(18,6)) = 0
		AND CAST(CONCAT(sign_takings,takings) AS decimal(18,6)) = 0
		AND CAST(CONCAT(sign_itmpntqty,item_points_quantity) AS decimal(18,6)) > 0
		AND CAST(CONCAT(sign,sales_units) AS int) >= 0 AND reflovsetinfo.lovkey = 'R')
		THEN CAST(CAST(CONCAT(sign_itmpntqty,item_points_quantity) AS decimal(18,6))/(-100) AS VARCHAR(255))
     WHEN (CAST(CONCAT(sign_tisp,sales_at_tisp) AS decimal(18,6)) = 0
		AND CAST(CONCAT(sign_takings,takings) AS decimal(18,6)) = 0
		AND CAST(CONCAT(sign_itmpntqty,item_points_quantity) AS decimal(18,6)) > 0
		AND CAST(CONCAT(sign,sales_units) AS int) < 0 AND reflovsetinfo.lovkey = 'R')
		THEN CAST(CAST(CONCAT(sign_itmpntqty,item_points_quantity) AS decimal(18,6))/(-100) AS VARCHAR(255))
     ELSE CONCAT(sign_tisp,sales_at_tisp) END Value,
roitmp.lovuomid LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN #TRANSACTIONID_KEY_temp transidtmp 
ON translineitem.PSARowKey = transidtmp.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
JOIN #SITEROLE_ROIIND_temp roitmp
ON roitmp.store_number = transidtmp.store_number
AND roitmp.row_id = transidtmp.row_id
LEFT OUTER JOIN ser.TransactionGroup transgroup
ON transgroup.transactionid = transidtmp.transactionid
LEFT OUTER JOIN (SELECT * FROM ser.RefLovSetInfo WHERE lovsetname = 'till_transaction_type_code' and LOVRecordSourceId = @uklc_lovRecordSourceID) reflovsetinfo
ON reflovsetinfo.LOVId = transgroup.LOVGroupId
/*(SELECT abacusitm.till_txn_number, abacusitm.till_txn_date, abacusitm.till_txn_time, abacusitm.store_number, abacusitm.till_number, row_id, abacusheader.epos_txn_typ_flg FROM 
(SELECT till_txn_number, till_txn_date, till_txn_time, store_number, till_number, row_id
FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitm 
LEFT OUTER JOIN (SELECT distinct till_txn_number, till_txn_date, till_txn_time, store_number, till_number, epos_txn_typ_flg FROM psa.uk_abacus_header) abacusheader
ON abacusheader.store_number = abacusitm.store_number
AND abacusheader.till_txn_number = abacusitm.till_txn_number
AND abacusheader.till_number = abacusitm.till_number
AND abacusheader.till_txn_date = abacusitm.till_txn_date
AND abacusheader.till_txn_time = abacusitm.till_txn_time) epostxnflg
ON epostxnflg.row_id = abacusitem.row_id*/

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@salesattesp_measureID MeasureId, 
CONCAT(sign_tesp,sales_at_tesp) Value,
roitmp.lovuomid LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
JOIN #SITEROLE_ROIIND_temp roitmp
ON roitmp.store_number = abacusitem.store_number
AND roitmp.row_id = abacusitem.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@saleseposprofit_measureID MeasureId, 
CONCAT(sign_profit,epos_profit) Value,
roitmp.lovuomid LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
JOIN #SITEROLE_ROIIND_temp roitmp
ON roitmp.store_number = abacusitem.store_number
AND roitmp.row_id = abacusitem.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@sapsalesattisp_measureID MeasureId, 
CONCAT(sign_tisp,sales_at_tisp) Value,
roitmp.lovuomid LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
JOIN #SITEROLE_ROIIND_temp roitmp
ON roitmp.store_number = abacusitem.store_number
AND roitmp.row_id = abacusitem.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@eposprofitadjusted_measureID MeasureId, 
CONCAT(sign_epos,epos_profit_adj) Value,
roitmp.lovuomid LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
JOIN #SITEROLE_ROIIND_temp roitmp
ON roitmp.store_number = abacusitem.store_number
AND roitmp.row_id = abacusitem.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@saleitemdispercent_measureID MeasureId, 
CONCAT(sign_discpc,sale_item_disc_pc) Value,
NULL LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@takings_measureID MeasureId, 
CONCAT(sign_takings,takings) Value,
roitmp.lovuomid LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
JOIN #SITEROLE_ROIIND_temp roitmp
ON roitmp.store_number = abacusitem.store_number
AND roitmp.row_id = abacusitem.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@revenue_measureID MeasureId, 
CONCAT(sign_revenue,revenue) Value,
roitmp.lovuomid LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
JOIN #SITEROLE_ROIIND_temp roitmp
ON roitmp.store_number = abacusitem.store_number
AND roitmp.row_id = abacusitem.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@itempointsqty_measureID MeasureId, 
CONCAT(sign_itmpntqty,item_points_quantity) Value,
NULL LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@itempointsval_measureID MeasureId, 
CONCAT(sign_itmpntval,item_points_value) Value,
NULL LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@mapp_measureID MeasureId, 
CONCAT(sign_ncp,sales_at_ncp) Value,
roitmp.lovuomid LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
JOIN #SITEROLE_ROIIND_temp roitmp
ON roitmp.store_number = abacusitem.store_number
AND roitmp.row_id = abacusitem.row_id
)Z
;

RAISERROR ('Completed insertion of ABACUS source data to TRANSACTION LINE ITEM MEASURE table', 0, 1) WITH NOWAIT



INSERT INTO ser.TransactionLineItemMeasure(
	TransactionLineItemMeasureId	,
	TransactionLineItemId 			,
	MeasureId  						,
	Value							,
	LOVUOMId						,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

SELECT @max_transactionLineItemMeasureID+DENSE_RANK() OVER(ORDER BY TransactionLineItemId, MeasureId) TransactionLineItemMeasureId, 
TransactionLineItemId, MeasureId, Value, LOVUOMId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey
FROM

(
SELECT distinct
translineitem.TransactionLineItemId TransactionLineItemId,
@salesattespgbproi_measureID MeasureId, 
CONCAT(SIGN_TESP,(SALES_AT_TESP * conversion.ConversionRate)) Value, 
@uklc_lovuomidgbp LOVUOMId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey ,
row_number() over (partition by TransactionLineItemId order by TransactionLineItemId asc) rw_number
FROM
(SELECT * FROM ser.TransactionLineItem	 WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID and SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID) translineitem
join [ser].[transaction] t
on translineitem.transactionid = t.transactionid
and t.lovrecordsourceid = 12006
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
LEFT OUTER JOIN (SELECT DISTINCT siteroleid, sourcekey FROM ser.SiteRole WHERE
lovrecordsourceid = @mdm_lovRecordSourceID AND SCDActiveFlag = 'Y') siterole 
ON siterole.sourcekey = abacusitem.store_number
LEFT OUTER JOIN (SELECT DISTINCT siteroleid, value FROM ser.SiteRoleIndicator WHERE SCDActiveFlag = 'Y' 
AND lovrecordsourceid = @mdm_lovRecordSourceID AND lovindicatorid = @uklc_lovindicatorid and value = 1) siteroleind
ON siteroleind.siteroleid = siterole.siteroleid
join
 (select distinct conversionrate,lovrecordsourceid,effectiveTo,effectiveFrom from #currency_conversion_tmp) conversion
    on conversion.lovrecordsourceid = 12054
		and t.Transactiondatetime between conversion.effectiveFrom and conversion.effectiveTo
	)a
	where rw_number = 1 ;



RAISERROR ('Completed insertion of ABACUS source data to TRANSACTION LINE ITEM MEASURE currency table', 0, 1) WITH NOWAIT

/********************************************************************************************************************************

10 . Table Name  :	Transformation

********************************************************************************************************************************/	

	
	DECLARE @trans_qry nvarchar(max);
	DECLARE @Logictype_sqlid BIGINT;
	DECLARE @Transtype_sqlid BIGINT;
		DECLARE @LOVTransformationComponentTypeId BIGINT;
				DECLARE @TransformationComponentKey BIGINT;
	
	SET @trans_qry = 'select cr.ConversionRate 
  FROM [ser].[CurrencyConversion]  cc
  INNER JOIN [ser].[CurrencyConversionRate] cr
  ON  [LOVSourceCurrencyId]=(select lovid from ser.reflov where lovkey=''EUR'' and lovsetid =(select lovsetid from ser.reflovset where lovsetname=''Global Brands Currency Codes'' and recordsourceid=12023) and recordsourceid=12023)
  AND[LOVTargetCurrencyId]=(select lovid from ser.reflov where lovkey=''GBP'' and lovsetid =(select lovsetid from ser.reflovset where lovsetname=''Global Brands Currency Codes'' and recordsourceid=12023) and recordsourceid=12023)
  AND [LOVConversionTypeId] = (select lovid from ser.reflov where lovkey=''Budget'' and lovsetid =(select lovsetid from ser.reflovset where lovsetname=''Conversion Type'' and recordsourceid=12023) and recordsourceid=12023)
  AND [LOVConversionMethodId]= (select lovid from ser.reflov where lovkey=''PAVG'' and lovsetid =(select lovsetid from ser.reflovset where lovsetname=''Conversion Method'' and recordsourceid=12023) and recordsourceid=12023)
  AND cc.[CurrencyConversionId] = cr.[CurrencyConversionId]'

	SET @Logictype_sqlid = (Select lovid from ser.reflov where lovkey='SQL' and lovsetid = (select lovsetid from ser.reflovset where 
	lovsetname='Logic Type'  and recordsourceid =12012 ) and recordsourceid =12012)
	
	
	SET @Transtype_sqlid = (Select lovid from ser.reflov where lovkey='SQL' and lovsetid = (select lovsetid from ser.reflovset where 
	lovsetname='Logic Type'  and recordsourceid =12012 ) and recordsourceid =12012)
	
	SET @LOVTransformationComponentTypeId = (Select lovid from SER.reflov where lovkey='Measure' and lovsetid = (select lovsetid from SER.reflovset where 
	lovsetname='Transformation Component Type'  and recordsourceid =12012 ) and recordsourceid =12012)
	
		
	SET @TransformationComponentKey = (SELECT MeasureId from SER.Measure where MeasureName = 'SALES_AT_TESP_GBP_ROI'
AND LOVMeasureTypeId = (SELECT LovID from SER.RefLOV where  LOVKey = 'RETAIL_TRANS_AGG' 
AND  LovSetID = (SELECT lovsetid from SER.RefLOVSet where LOVsetName = 'Measure Type')
AND LOVRecordSourceId = 12006))

	SELECT  @max_TransformationId = COALESCE(MAX(TransformationId),0) FROM ser.Transformation

INSERT INTO ser.Transformation(
	TransformationId	,
	Name			,
	Description				,
	TargetTableName		,
	TargetColumnName					,
	LOVLogicTypeId		,
	Logic,
	LOVTransformationTypeId,
	LovRecordSourceID,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				

) 
SELECT @max_TransformationId+DENSE_RANK() OVER(ORDER BY Name,TargetTableName,TargetColumnName,LOVLogicTypeId) TransformationId, 
Name, Description, TargetTableName, TargetColumnName, LOVLogicTypeId, Logic, LOVTransformationTypeId, LovRecordSourceID, SCDStartDate,
 SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId
FROM

( 
SELECT 
					'Compute currency conversion of the TESP from EUR to GBP' as Name,
					'Convert the tesp amount from EUR to GBP currency' as Description,
					'TransactionLineItemmeasure' as TargetTableName,
					'Value' as TargetColumnName,
					@Logictype_sqlid as LOVLogicTypeId,
					@trans_qry as Logic,
					@Transtype_sqlid as LOVTransformationTypeId,
					@uklc_lovRecordSourceID as LovRecordSourceID,
					null as [SCDStartDate],
					null as [SCDEndDate],
					null as [SCDActiveFlag],
					null as [SCDVersion],
					@uklc_scdLovRecordSourceID as [SCDLOVRecordSourceId],
					@serveETLRunLogID as ETLRunLogId)a
					;
					
RAISERROR ('Completed insertion of ABACUS source data to transaformation table', 0, 1) WITH NOWAIT



/********************************************************************************************************************************

11 . Table Name  :	Transformation Component

********************************************************************************************************************************/	



	INSERT INTO ser.TransformationComponent(
	TransformationId	,
	LOVTransformationComponentTypeId			,
	TransformationComponentKey				,
	SequenceNumber		,
	ComponentName,
	LovRecordSourceID,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				


) 
SELECT  @max_TransformationId+DENSE_RANK() OVER(ORDER BY LOVTransformationComponentTypeId,TransformationComponentKey,
TransformationComponentKey) TransformationId, 
LOVTransformationComponentTypeId, TransformationComponentKey, SequenceNumber,ComponentName, LovRecordSourceID,  SCDStartDate,
 SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId
FROM

( 

	SELECT			
					@LOVTransformationComponentTypeId as LOVTransformationComponentTypeId,
					@TransformationComponentKey as TransformationComponentKey,
					1 as SequenceNumber,
					 NULL as ComponentName,
					@uklc_lovRecordSourceID as LovRecordSourceID,
					null as [SCDStartDate],
					null as [SCDEndDate],
					null as [SCDActiveFlag],
					null as [SCDVersion],
					@uklc_scdLovRecordSourceID as [SCDLOVRecordSourceId],
					@serveETLRunLogID as ETLRunLogId,
row_number() over (partition by TargetTableName order by transformationid asc) rw_number	
FROM ser.transformation 
	WHERE TargetTableName = 'TransactionLineItemmeasure' 
	AND TargetColumnName = 'Value'
	AND LOVLogicTypeId = @Logictype_sqlid
	AND LovRecordSourceID = 12006

)a
	where rw_number = 1;
					
	

RAISERROR ('Completed insertion of ABACUS source data to TransformationComponent table', 0, 1) WITH NOWAIT




/* 5.Table Name  :  TransactionLineItemIndicator */

SET @refundflag_indicatorID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Indicator - BUK SAP BW Transaction' AND lovkey = 'refund_flag');
SET @itemdisoverriddenflag_indicatorID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Indicator - BUK SAP BW Transaction' AND lovkey = 'item_discount_overridden_flag');
SET @priceoverriddenitemflag_indicatorID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Indicator - BUK SAP BW Transaction' AND lovkey = 'price_overridden_item_flag');

INSERT INTO ser.TransactionLineItemIndicator(
	TransactionLineItemId 			,
	LOVIndicatorId					,
	Value							,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@refundflag_indicatorID LOVIndicatorId, 
CASE WHEN CAST(CONCAT(sign_tisp,sales_at_tisp) AS decimal(18,6)) < 0 THEN 'Y' ELSE 'N' END Value,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@itemdisoverriddenflag_indicatorID LOVIndicatorId, 
item_disc_oride_flg Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@priceoverriddenitemflag_indicatorID LOVIndicatorId, 
price_oride_it_flg Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId =  @uklc_lovRecordSourceID) translineitem
JOIN (SELECT * FROM #uk_abacus_item_tmp WHERE row_status = @psa_rowstatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)abacusitem 
ON translineitem.PSARowKey = abacusitem.row_id
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
;

RAISERROR ('Completed insertion of ABACUS source data to TRANSACTION LINE ITEM INDICATOR table', 0, 1) WITH NOWAIT


UPDATE psa.uk_abacus_item
SET row_status = 26002
/*  code to be added to join source table with transaction line item */
FROM psa.uk_abacus_item src
JOIN ser.TransactionLineItem translineitem
ON src.row_id = translineitem.psarowkey
AND translineitem.SCDLOVRecordSourceId = @uklc_scdLovRecordSourceID
WHERE row_status = @psa_rowstatus
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
;

RAISERROR ('Completed procedure of UK-ABACUS updated row status to IN SERV', 0, 1) WITH NOWAIT


COMMIT TRANSACTION
END TRY

BEGIN CATCH
DECLARE @error_num VARCHAR(max),
		@error_msg VARCHAR(max),
		@error_sev VARCHAR(max)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

END;
GO
/****** Object:  StoredProcedure [psa].[sp_inc_int_crp_product]    Script Date: 11/26/2020 6:06:32 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_int_crp_product') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_int_crp_product
END
GO

CREATE PROC [psa].[sp_inc_int_crp_product] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max) AS

/*************************************************************************************************************************
Procedure Name					: sp_inc_int_crp_product
Purpose							: Load Incremental data From Product International Sources ( MEXICO, NORWAY & THAILAND )
								  into Serve Layer Table
Domain							: Product
ServeLayer Target Tables		: Product,ProductIdentifier,ProductStatus,ProductIndicator,ProductProperty,ProductGroup,
								  Party,Organization,PartyRole,PrductPartyRole    (Total 10 Tables)
RecordSourceID  for MEXICO		: 12004
RecordSourceID  for NORWAY		: 12005
RecordSourceID  for THAILAND	: 12010

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date          :        Description
24th Nov 2020 : Fix for Leading zero handlingin item_code and upc 
==========================================================================================================================

03-09-2020   :  Added new parameter '@psaEntityId' to the stored procedure. 
				Modified update query for updating the status back in psa table.

**************************************************************************************************************************/


DECLARE			@dateAdded					VARCHAR (max),
				@sourceKey                  VARCHAR (max),
				@lovKeyTemp					VARCHAR (max),
				@inpTableName				VARCHAR (max),
				@srcTableName				VARCHAR (max),
				@indicatorName				VARCHAR (max), 
				@inpServeETLRunLogId		VARCHAR (max),
				@scdDefaultStartDate		DATETIME,
				@scdDefaultEndDate			DATETIME,
				@SCDStartDate				DATETIME,
				@SCDEndDate					DATETIME,		
				@MaxId						BIGINT,
				@Counter					BIGINT,
				@uomCmId					BIGINT,
				@partyId                    BIGINT,
				@dataTypeId					BIGINT,
				@maxPartyId 				BIGINT,
				@partyTypeId				BIGINT,
				@maxProductId				BIGINT,
				@uomUnknownId				BIGINT,
				@measureTypeId				BIGINT,
				@recordSourceId				BIGINT,
				@maxPartyRoleId				BIGINT,
				@upcIdentifierId			BIGINT,
				@rowStatusSERCode			BIGINT,
				@rowStatusPSACode			BIGINT,
				@lovRetailerRoleId 			BIGINT,
				@lovSupplierRoleId			BIGINT,
				@maxProductGroupId			BIGINT,
				@ProductGroupSetIdC1        BIGINT,
				@ProductGroupSetIdC2        BIGINT,
				@ProductGroupSetIdC3        BIGINT,
				@ProductGroupSetIdC4        BIGINT,
				@ProductGroupSetIdC5        BIGINT,
				@ProductGroupSetIdN1        BIGINT,
				@ProductGroupSetIdN2        BIGINT,
				@ProductGroupSetIdN3        BIGINT,
				@ProductGroupSetIdN4        BIGINT,
				@ProductGroupSetIdN5        BIGINT,
				@LOVIndicatorIdOBFlag		BIGINT,
				@LOVIndicatorIdEXFlag		BIGINT,	
				@itemCodeSourceKeyTypeId	BIGINT,
				@rowStatusSERDuplicateCode	BIGINT;
					
				
	BEGIN
			SET		 @rowStatusPSACode			= 26001
			SET		 @rowStatusSERCode			= 26002
			SET		 @rowStatusSERDuplicateCode = 26010	


	IF OBJECT_ID('psa.int_product_cursor_table') is not null
	BEGIN
			DROP TABLE [psa].[int_product_cursor_table]
	END	
			CREATE TABLE [psa].[int_product_cursor_table]
			(
				[row_id] [bigint]  NULL,
				[date_added] [nvarchar](25)  NULL
			)
			WITH
			(
				DISTRIBUTION = ROUND_ROBIN
			)
	IF OBJECT_ID('psa.int_crp_product_stg') is not null
	BEGIN
			DROP TABLE [psa].[int_crp_product_stg]
	END	
	EXEC ('CREATE TABLE psa.int_crp_product_stg
			WITH (DISTRIBUTION=HASH(row_id),
					HEAP)
			AS 
			SELECT [row_id]
				,ISNULL( NULLIF((Substring(item_code, Patindex(''%[^0]%'', item_code + '' ''), Len(item_code)) ),''''),0) [item_code]
				,[item_description]
				,[product_hierarchy1]
				,[product_hierarchy2]
				,[product_hierarchy3]
				,[product_hierarchy4]
				,[product_hierarchy5]
				,[product_hierarchy1_code]
				,[product_hierarchy2_code]
				,[product_hierarchy3_code]
				,[product_hierarchy4_code]
				,[product_hierarchy5_code]
				,[brand]
				,[subbrand]
				,[exclusive_flag]
				,[own_brand_flag]
				,[item_status]
				, (CASE WHEN NULLIF(upc,'''') IS NULL THEN upc
						ELSE ISNULL( NULLIF((Substring(upc, Patindex(''%[^0]%'', upc + '' ''), Len(upc)) ),''''),0) END) [upc]				
				,[supplier_name]
				,[supplier_number]
				,[height]
				,[width]
				,[depth]
				,[size]
				,[date_added]
				,[etl_runlog_id]
				,[asset_id]
				,[record_source_id]
				,[row_status]
				,[created_timestamp]
				,[active_flag]
		FROM [psa].['+@tableName+'] where row_status='+@rowStatusPSACode);

	BEGIN TRANSACTION;
	
			SET		 @srcTableName				='psa.'+@tableName
			SET		 @inpTableName				='psa.int_crp_product_stg'
			SET		 @inpServeETLRunLogId		= @serveETLRunLogID				
			SET		 @SCDDefaultStartDate		= CONVERT(DateTime,'1900-01-01',126)			
			SET		 @SCDDefaultEndDate			= CONVERT(DateTime,'9999-12-31',126)


			DECLARE @RecordSourceIdSQL nvarchar(max) = 'SELECT TOP 1 @recordSourceId = record_source_id FROM ' + @inpTableName
			exec sp_executesql @RecordSourceIdSQL, N'@recordSourceId bigint out', @recordSourceId out
			
			SET @lovKeyTemp =
	CASE
			WHEN @recordSourceId = 12010
			THEN 'Thailand Item Code'

			WHEN @recordSourceId = 12005
			THEN 'Norway Item Code'

			WHEN @recordSourceId = 12004
			THEN 'Mexico Item Code'
	END
			SET @indicatorName = 
	CASE
			WHEN @recordSourceId = 12010
			THEN 'Indicator - Thailand Product'

			WHEN @recordSourceId = 12005
			THEN 'Indicator - Norway Product'

			WHEN @recordSourceId = 12004
			THEN 'Indicator - Mexico Product'
	END
			SET @sourceKey=
    CASE
            WHEN @recordSourceId = 12010
            THEN 'WBA-TH-BT'

            WHEN @recordSourceId = 12005
            THEN 'WBA-NO-BN'

            WHEN @recordSourceId = 12004
            THEN 'WBA-MX-FB'
    END		
			
	
												
		   SELECT @uomCmId				   = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'cm'		         AND LOVSetName = 'Unit of measure';
		   SELECT @partyTypeId		       = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'ORG'	         AND LOVSetName = 'Party Type' ;											
	       SELECT @uomUnknownId			   = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'Unknown'         AND LOVSetName = 'Unit of measure';											
		   SELECT @upcIdentifierId		   = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'UPC'	         AND LOVSetName = 'Identifier';											
		   SELECT @lovRetailerRoleId	   = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'Retailer'        AND LOVSetName = 'Role';											
		   SELECT @lovSupplierRoleId	   = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'Supplier'        AND LOVSetName = 'Role';											
		   SELECT @itemCodeSourceKeyTypeId = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey =  @lovKeyTemp      AND LOVSetName = 'Source Key Type';											
		   SELECT @LOVIndicatorIdOBFlag	   = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'own_brand_flag'  AND LOVSetName = @indicatorName;
		   SELECT @LOVIndicatorIdEXFlag	   = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'exclusive_flag'  AND LOVSetName = @indicatorName;
		   SET    @measureTypeId		   = (SELECT rl.Lovid FROM [ser].[RefLOVSetInfo] rl WHERE rl.LOVKey = 'PROD_DIM' AND rl.LOVSetName = 'Measure Type');
		   SET    @dataTypeId			   = (SELECT rl.Lovid FROM [ser].[RefLOVSetInfo] rl WHERE rl.LOVKey = 'STRING' AND rl.LOVSetName = 'Data Type');
		   SET    @ProductGroupSetIdC1	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy1_code' and LOVRecordSourceId = @recordSourceId );
		   SET    @ProductGroupSetIdC2	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy2_code' and LOVRecordSourceId = @recordSourceId );		
		   SET    @ProductGroupSetIdC3	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy3_code' and LOVRecordSourceId = @recordSourceId );
		   SET    @ProductGroupSetIdC4	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy4_code' and LOVRecordSourceId = @recordSourceId );	 
		   SET    @ProductGroupSetIdN1	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy1_name' and LOVRecordSourceId = @recordSourceId );
		   SET    @ProductGroupSetIdN2	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy2_name' and LOVRecordSourceId = @recordSourceId );
		   SET    @ProductGroupSetIdN3	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy3_name' and LOVRecordSourceId = @recordSourceId );
		   SET    @ProductGroupSetIdN4	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy4_name' and LOVRecordSourceId = @recordSourceId );

IF (@recordSourceId =12005 OR @recordSourceId =12004)

	BEGIN
		  SET    @ProductGroupSetIdC5	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy5_code' and LOVRecordSourceId = @recordSourceId );
		  SET    @ProductGroupSetIdN5	   = (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy5_name' and LOVRecordSourceId = @recordSourceId );
	END

BEGIN TRY
	
	exec('			INSERT INTO [psa].[int_product_cursor_table]
					SELECT  distinct DENSE_RANK() OVER(ORDER BY (inp.date_added )) AS row_id,
							inp.date_added as date_added
					FROM '+@inpTableName+' inp 
					WHERE inp.row_status = '+@rowStatusPSACode+'
		')
			
				SET @MAXID = ( SELECT count(*) from [psa].[int_product_cursor_table] )

				PRINT 'Cursor Table [psa].[int_product_cursor_table] Log  ==> Total No: of Records : '+CAST(@MAXID as varchar)+' ';


				SET @COUNTER = 1
								
			
				print 'Incremental Insertion of data from '+@inpTableName+'  table started ';

				print 'Total Number of Loops : '+CAST(@MAXID as varchar)+'';

	WHILE (@COUNTER <= @MAXID)

		BEGIN
				print 'Loop Number  : '+cast(@COUNTER as varchar)+'';

				SET		@dateAdded			= (SELECT date_added from [psa].[int_product_cursor_table] where row_id = @COUNTER)
				SET		@SCDStartDate		= CURRENT_TIMESTAMP;
				SET		@SCDEndDate			= DATEADD(second,-1,@SCDStartDate);
				SELECT  @maxProductId		= COALESCE(MAX(ProductID),0) FROM ser.product; 
				SELECT  @maxProductGroupId	= COALESCE(MAX(ProductGroupId),0) FROM ser.productGroup;  
				SET     @maxPartyId			= (SELECT COALESCE(max(PartyId),0) FROM ser.party);
				SET     @maxPartyRoleId		= (SELECT COALESCE(max(PartyRoleId),0) FROM ser.partyRole);										
		   
				PRINT 'Current Processing Date: '+CAST(@dateAdded as varchar)+'';
		   

/********************************************************************************************************************************

 1. Table Name  :	Product 

--********************************************************************************************************************************/

				PRINT 'Info: Product Table Serve Loading Started';

				PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

exec('
				WITH Stg_Product AS (SELECT * FROM ser.Product t 
					  WHERE LOVRECORDSOURCEID='+@recordSourceId+'
							AND LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+' 
							AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt 
																	WHERE pdt.ProductID = t.ProductID
																	AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																	AND  pdt.ScdVersion > t.ScdVersion))

		INSERT INTO [ser].[product] (	ProductId,SourceKey,LOVSourceKeyTypeId,ProductName ,ProductDescription,LOVBrandId,LOVSubBrandId ,  					
										LOVRecordSourceId,ParentProductId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,
										SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
									)
		SELECT			ProductID,SourceKey,LOVSourceKeyTypeId,ProductName,ProductDescription,LOVBrandId,LOVSubBrandId,
						LOVRecordSourceId,ParentProductId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId,LOVRecordSourceId ORDER BY date_added ASC)) = 1) 
							 THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
							 ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''')
						END SCDStartDate,
						LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER(PARTITION BY ProductId,LOVRecordSourceId ORDER BY date_added ASC) SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductId,LOVRecordSourceId ORDER BY date_added ASC) SCDActiveFlag,				
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId,LOVRecordSourceId ORDER BY date_added ASC) SCDVersion,						
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey				
		FROM
		(
		SELECT
						
						ISNULL(p.ProductID,prodIdTemp.ProductID) ProductID,
						intprod.item_code SourceKey,
						'+@itemCodeSourceKeyTypeId+' LOVSourceKeyTypeId,
						intprod.item_description ProductName,
						intprod.item_description ProductDescription ,   
						b.lovid LOVBrandId,
						sb.lovid LOVSubBrandId, 
						intprod.record_source_id LOVRecordSourceId, 
						NULL ParentProductID, 
						intprod.date_added date_added,
						CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY intprod.item_code,intprod.item_description,b.lovid,sb.lovid,
						intprod.record_source_id,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag, 
						p.SCDVersion SCDVersion,
						intprod.record_source_id SCDLOVRecordSourceId, 
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+' intprod
						JOIN (SELECT intprod.item_code,intprod.record_source_id,('+@maxProductId+'+ROW_NUMBER() OVER(ORDER BY intprod.item_code,intprod.record_source_id ASC)) ProductID
								FROM  '+@inpTableName+' intprod
								WHERE intprod.row_status='+@rowStatusPSACode+' 
								AND intprod.date_added = '+@dateAdded+' -- Add date_added and move lookup of max product ID inside
								GROUP BY intprod.item_code,intprod.record_source_id) prodIdTemp
							ON prodIdTemp.item_code=intprod.item_code 
								AND prodIdTemp.record_source_id=intprod.record_source_id
						LEFT JOIN Stg_Product p
							ON intprod.item_code =p.sourcekey
								AND intprod.record_source_id = p.LOVRecordSourceId
								AND p.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
						LEFT JOIN  ser.RefLOVSetInfo b                
							ON b.LOVSetName = ''brand'' 
								AND b.LOVRecordSourceId = intprod.record_source_id
								AND b.LOVKey = intprod.brand
						LEFT JOIN ser.RefLOVSetInfo sb                 
							ON sb.LOVSetName = ''subbrand'' 
								AND sb.LOVRecordSourceId = intprod.record_source_id
								AND  sb.LOVKey = intprod.subbrand
						WHERE intprod.row_status='+@rowStatusPSACode+'
						--	AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
							AND (CASE  WHEN ( NULLIF(intprod.ITEM_DESCRIPTION,'''' ) IS NULL AND NULLIF( intprod.brand,'''' ) 
							IS NULL AND NULLIF( intprod.subbrand,'''') IS NULL)  THEN 0
					             ELSE 1 END)=1			-- NULL OR BLANK DONT INSERT
						)t
						where t.SCDActiveFlag=''Y''
						AND t.date_added ='+ @dateAdded+'
					   AND NOT EXISTS (select 1 from ser.Product serp where t.SourceKey =serp.SourceKey 
													AND t.ProductID = serp.productID
													AND t.LOVSourceKeyTypeId= serp.LOVSourceKeyTypeId
					                                AND t.LOVRecordSourceId=serp.LOVRecordSourceId
													AND ISNULL(t.ProductName,'''')=ISNULL(serp.ProductName,'''')
													AND ISNULL(t.productDescription,'''')=ISNULL(serp.productDescription,'''')
													AND ISNULL(t.LOVBrandId,0)  =ISNULL(serp.LOVBrandId,0)
													AND ISNULL(t.LOVSubBrandId,0) = ISNULL(serp.LOVSubBrandId,0)
													AND serp.SCDActiveFlag =''Y'')
													
')								
			PRINT 'Info: Product Table -> Closing off old Records if exists';

exec('
					UPDATE ser.Product set SCDActiveFlag=''N'',SCDEndDate =CONVERT(NVARCHAR,'''+@SCDEndDate+''')
						FROM ser.Product p 
						JOIN 
							(	SELECT productId,SCDactiveflag, SCDVersion,LovRecordSourceId FROM ser.Product t WHERE   
								t.LOVRecordSourceID='+@recordSourceId+' AND t.SCDActiveFlag=''Y''
											AND NOT EXISTS (
															   SELECT 1 FROM ser.Product AS pt 
																		WHERE pt.ProductID = t.ProductID
																		AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																		AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																		AND  pt.ScdVersion > t.ScdVersion
															) 
							) p2
							ON  p.productID=p2.productId
							AND p.LovRecordSourceId=p2.LovRecordSourceId						 
							AND p.SCDactiveflag=p2.SCDactiveflag
							AND p.SCDVersion!=p2.SCDVersion
						JOIN '+@inpTableName+' intprod
							 ON intprod.record_source_id=p.LovRecordSourceId 
							AND p.sourcekey = intprod.item_code
						WHERE	p.SCDActiveFlag=''Y'' 
							AND p.SCDEndDate = CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''')
							AND intprod.row_status='+@rowStatusPSACode+' 
							AND date_added = '+@dateAdded+' ;

')
exec('
				UPDATE ser.product SET SCDActiveFlag= ''N'', SCDEndDate =CONVERT(NVARCHAR,'''+@SCDEndDate+''')
					FROM ser.product p
					JOIN '+@inpTableName+' intprod
						 ON intprod.record_source_id=p.LovRecordSourceId 
						AND p.sourcekey = intprod.item_code
						AND p.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
					WHERE	NULLIF( intprod.ITEM_DESCRIPTION,'''' ) IS NULL
						AND NULLIF( intprod.brand,'''' ) IS NULL 
						AND NULLIF( intprod.subbrand,'''') IS NULL
						AND p.SCDActiveFlag=''Y''
						AND date_added = '+@dateAdded+';
')

				PRINT 'Info: Product Table Loaded Successfully'; 

/********************************************************************************************************************************

 2. Table Name  :	Product Identifier

--********************************************************************************************************************************/

				PRINT 'Info: Product Identifier Table Serve Loading Started';

				PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

exec('		
					WITH Stg_Product AS (SELECT * FROM ser.Product t 
					  WHERE LOVRECORDSOURCEID='+@recordSourceId+'
							AND LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId +'
							AND t.SCDActiveFlag=''Y''
							AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt 
																	WHERE pdt.ProductID = t.ProductID
																	AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																	AND pdt.LOVSourceKeyTypeId = t.LOVSourceKeyTypeId
																	AND  pdt.ScdVersion > t.ScdVersion))

					,Stg_Product_Identifier AS ( SELECT * FROM ser.ProductIdentifier PId
						WHERE LOVRECORDSOURCEID='+@recordSourceId+'
							AND NOT EXISTS (SELECT 1 FROM ser.ProductIdentifier AS pdt 
																	WHERE pdt.ProductID = PId.ProductID
																	AND pdt.LOVIdentifierID = PId.LOVIdentifierID
																	AND pdt.LOVRecordSourceID=PId.LOVRecordSourceID
																	AND  pdt.ScdVersion > PId.ScdVersion))
						
		INSERT INTO [ser].[ProductIdentifier](
					ProductId,LOVIdentifierId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,
					SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey	)
		SELECT
					ProductId,LOVIdentifierId,Value,LOVRecordSourceId,
					CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,LOVRecordSourceId ORDER BY date_added ASC)) = 1)
								 THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
								 ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''')
								 END SCDStartDate,
				
					LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER(PARTITION BY ProductId,LOVRecordSourceId ORDER BY date_added ASC) SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductId,LOVRecordSourceId ORDER BY date_added ASC) SCDActiveFlag,
					ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,LOVRecordSourceId ORDER BY date_added ASC) SCDVersion,
					SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
		FROM(
		SELECT
					product.ProductId ProductId,
					'+@upcIdentifierId+' LOVIdentifierId,
					intprod.upc Value,
					intprod.record_source_id LOVRecordSourceId,
					intprod.date_added date_added,
					CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductId,intprod.upc,intprod.record_source_id,
										intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
					p.SCDVersion SCDVersion,
					intprod.record_source_id SCDLOVRecordSourceId,
					'+@inpServeETLRunLogID+' ETLRunLogId,
					intprod.row_id PSARowKey
						FROM  '+@inpTableName+' intprod
						JOIN Stg_Product product
							ON  product.SourceKey = intprod.item_code
							AND product.LOVRecordSourceID = intprod.record_source_id
							AND product.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
							AND intprod.upc !='''' AND intprod.upc is not null
						LEFT JOIN Stg_Product_Identifier p
							ON product.productId =p.ProductId
							AND product.LOVRecordSourceId = p.LOVRecordSourceId
						--	AND p.SCDActiveFlag = ''Y''
							WHERE intprod.row_status='+@rowStatusPSACode+'
			) prdtIdf
			where prdtIdf.SCDActiveFlag=''Y''
			AND prdtIdf.date_added ='+@dateAdded+'
			AND NOT EXISTS (select 1 from ser.ProductIdentifier serpid 
													  WHERE	  prdtIdf.ProductID = serpid.productID
													    AND	  prdtIdf.LOVIdentifierID= serpid.LOVIdentifierID
														AND	  prdtIdf.LOVRecordSourceId=serpid.LOVRecordSourceId
														AND	  prdtIdf.value = serpid.value
														AND   serpid.SCDActiveFlag =''Y'')

	
		')


		PRINT 'Info: ProductIdentifier Table -> Closing off old Records if exists';

exec('			UPDATE ser.ProductIdentifier set SCDActiveFlag=''N'',SCDEndDate =CONVERT(NVARCHAR,'''+@SCDEndDate+''')
						FROM ser.ProductIdentifier p 
						JOIN 
							(	SELECT productId,LOVIdentifierID,SCDactiveflag, SCDVersion,LovRecordSourceId FROM ser.ProductIdentifier t WHERE   
								t.LOVRecordSourceID='+@recordSourceId+' AND t.SCDActiveFlag=''Y''
											AND NOT EXISTS (
															   SELECT 1 FROM ser.ProductIdentifier AS pt 
																		WHERE pt.ProductID = t.ProductID
																		AND  pt.LOVRecordSourceID=t.LOVRecordSourceID
																		AND	 pt.LOVIdentifierID= t.LOVIdentifierID
																		AND  pt.ScdVersion > t.ScdVersion
															) 
							) p2
							ON  p.productID=p2.productId
							AND p.LovRecordSourceId=p2.LovRecordSourceId	
							AND p.LOVIdentifierID = p2.LOVIdentifierID
							AND p.SCDactiveflag=p2.SCDactiveflag
							AND p.SCDVersion!=p2.SCDVersion
						WHERE	p.SCDActiveFlag=''Y''
							AND p.SCDEndDate = CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''')
	
			')

				
exec('				UPDATE ser.productIdentifier SET SCDActiveFlag= ''N'', SCDEndDate =CONVERT(NVARCHAR,'''+@SCDEndDate+''')
					FROM ser.productIdentifier pid
					JOIN (	SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag, SCDVersion,LovRecordSourceId FROM ser.Product t WHERE   
								t.LOVRecordSourceID='+@recordSourceId+'
											AND NOT EXISTS (
															   SELECT 1 FROM ser.Product AS pt 
																		WHERE pt.ProductID		 = t.ProductID
																		AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																		AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																		AND  pt.ScdVersion > t.ScdVersion
															) 
							) p2
						ON
						pid.productID=p2.productId
						AND pid.LovRecordSourceId=p2.LovRecordSourceId				
					JOIN '+@inpTableName+' intprod
						ON intprod.record_source_id=p2.LovRecordSourceId 
						AND p2.sourcekey = intprod.item_code
						AND p2.LOVSourceKeyTypeId= '+@itemCodeSourceKeyTypeId+'
					WHERE	( NULLIF(intprod.UPC,'''' ) IS NULL OR p2.SCDActiveFlag=''N'') -- THIS OR CONDITION is for closing the child record for inactive product
						AND pid.SCDActiveFlag=''Y''
						AND intprod.row_status='+@rowStatusPSACode +'
						AND date_added ='+@dateAdded+' ;		
	')

				PRINT 'Info: Product Identifier Table Loaded Successfully'; 

/********************************************************************************************************************************

 3. Table Name  :	Product Status

--********************************************************************************************************************************/

				PRINT 'Info: Product Status Table Serve Loading Started';

				PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

exec('			WITH Stg_Product AS (SELECT * FROM ser.Product t 
					  WHERE LOVRECORDSOURCEID='+@recordSourceId+'
							AND LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
							AND t.SCDActiveFlag=''Y''
							AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt 
																	WHERE pdt.ProductID = t.ProductID
																	AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																	AND pdt.LOVSourceKeyTypeId = t.LOVSourceKeyTypeId
																	AND  pdt.ScdVersion > t.ScdVersion))

					,Stg_Product_Status AS ( SELECT * FROM ser.ProductStatus pin
						WHERE LOVRECORDSOURCEID='+@recordSourceId+'
							AND NOT EXISTS (SELECT 1 FROM ser.ProductStatus AS pdt 
																	WHERE pdt.ProductID = pin.ProductID
																	AND pdt.LOVProductStatusSetId = pin.LOVProductStatusSetId
																	AND pdt.LOVRecordSourceID=pin.LOVRecordSourceID
																	AND  pdt.ScdVersion > pin.ScdVersion))

			INSERT INTO [ser].[ProductStatus] (
						ProductID,LOVProductStatusSetId,LOVStatusId,EffectiveFrom,EffectiveTo,LOVRecordSourceId,
						SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey	)
			SELECT
						ProductID,LOVProductStatusSetId,LOVStatusId,EffectiveFrom,EffectiveTo,LOVRecordSourceId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,LOVRecordSourceId ORDER BY date_added ASC)) = 1)
								 THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''') 
								 ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''')
								 END SCDStartDate,
						
						LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER(PARTITION BY ProductId,LOVRecordSourceId ORDER BY date_added ASC) SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductId,LOVRecordSourceId ORDER BY date_added ASC) SCDActiveFlag,
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,LOVRecordSourceId ORDER BY date_added ASC) SCDVersion,
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
			FROM (
			SELECT
						product.ProductID ProductID,
						itmstat.LOVSetId LOVProductStatusSetId,
						itmstat.LOVId LOVStatusId,
						intprod.date_added EffectiveFrom,
						NULL EffectiveTo,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added date_added,        
						CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,    
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductId,itmstat.LOVId,intprod.record_source_id,
							intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						intprod.record_source_id SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+' intprod
						JOIN Stg_Product product				
							ON  product.SourceKey = intprod.item_code
							AND product.LOVRecordSourceID = intprod.record_source_id
							AND product.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
							AND intprod.item_status!= '''' AND intprod.item_status IS NOT NULL
						LEFT JOIN Stg_Product_Status p
							ON  p.productId =product.ProductID 
							AND p.LOVRecordSourceId = product.LOVRecordSourceId
						LEFT JOIN ser.RefLOVSetInfo itmstat                 
							ON  itmstat.LOVSetName = ''item_status'' 
							AND itmstat.LOVRecordSourceId = intprod.record_source_id
							AND itmstat.LOVKey = intprod.item_status	
						WHERE intprod.row_status='+@rowStatusPSACode+'
						--AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
						) PrdtSts
						where PrdtSts.SCDActiveFlag=''Y''
						AND PrdtSts.date_added ='+@dateAdded+'
						AND NOT EXISTS (select 1 from ser.ProductStatus serpst 
													  WHERE	  PrdtSts.ProductID = serpst.productID
													    AND	  PrdtSts.LOVProductStatusSetId= serpst.LOVProductStatusSetId
														AND	  PrdtSts.LOVRecordSourceId=serpst.LOVRecordSourceId
														AND	  PrdtSts.LOVStatusId = serpst.LOVStatusId
														AND   serpst.SCDActiveFlag =''Y'')

						')

				PRINT 'Info: ProductStatus Table -> Closing off old Records if exists';

	exec('		UPDATE ser.ProductStatus set SCDActiveFlag=''N'',SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
						FROM ser.ProductStatus p 
						JOIN 
							(	SELECT productId,LOVProductStatusSetId,SCDactiveflag, SCDVersion,LovRecordSourceId FROM ser.ProductStatus t WHERE   
								t.LOVRecordSourceID='+@recordSourceId+'
								AND t.SCDActiveFlag=''Y''
											AND NOT EXISTS (
															   SELECT 1 FROM ser.ProductStatus AS pt 
																		WHERE pt.ProductID = t.ProductID
																		AND  pt.LOVRecordSourceID=t.LOVRecordSourceID
																		AND	 pt.LOVProductStatusSetId= t.LOVProductStatusSetId
																		AND  pt.ScdVersion > t.ScdVersion
															)  
							) p2  
							ON  p.productID=p2.productId
							AND p.LovRecordSourceId=p2.LovRecordSourceId	
							AND p.LOVProductStatusSetId = p2.LOVProductStatusSetId
							AND p.SCDactiveflag=p2.SCDactiveflag
							AND p.SCDVersion!=p2.SCDVersion	
						WHERE	p.SCDActiveFlag=''Y''
							AND p.SCDEndDate =CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''')

			')

	
	exec('		UPDATE ser.ProductStatus SET SCDActiveFlag= ''N'', SCDEndDate =CONVERT(NVARCHAR,'''+@SCDEndDate+''')
					FROM ser.ProductStatus pin
					JOIN (	SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag, SCDVersion,LovRecordSourceId FROM ser.Product t WHERE   
								t.LOVRecordSourceID='+@recordSourceId+'
											AND NOT EXISTS (
															   SELECT 1 FROM ser.Product AS pt 
																		WHERE pt.ProductID		 =t.ProductID
																		AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																		AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																		AND  pt.ScdVersion > t.ScdVersion
															) 
							) p2
						ON
						pin.productID=p2.productId
						AND pin.LovRecordSourceId=p2.LovRecordSourceId				
					JOIN '+@inpTableName+' intprod
						ON intprod.record_source_id=p2.LovRecordSourceId 
						AND p2.sourcekey = intprod.item_code
						AND p2.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
					WHERE	( NULLIF(intprod.item_status,'''' ) IS NULL OR p2.SCDActiveFlag=''N'') 
						AND pin.SCDActiveFlag=''Y''
						AND intprod.row_status='+@rowStatusPSACode+'
						AND date_added ='+@dateAdded+' ;	
		
			')

				PRINT 'Info: Product Status Table Loaded Successfully'; 

/********************************************************************************************************************************

 4. Table Name  :	Product Indiator

--********************************************************************************************************************************/

				PRINT 'Info: Product Indicator Table Serve Loading Started';

				PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

	exec('			WITH Stg_Product AS (SELECT * FROM ser.Product t 
										  WHERE LOVRECORDSOURCEID='+@recordSourceId+'
												AND LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
												AND t.SCDActiveFlag=''Y''
												AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt 
																						WHERE pdt.ProductID = t.ProductID
																						AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																						AND pdt.LOVSourceKeyTypeId = t.LOVSourceKeyTypeId
																						AND  pdt.ScdVersion > t.ScdVersion))
					,Stg_Indicator AS ( SELECT * FROM ser.ProductIndicator pin
										WHERE LOVRECORDSOURCEID='+@recordSourceId+'
												AND NOT EXISTS (SELECT 1 FROM ser.ProductIndicator AS pdtInd 
																			WHERE pdtInd.ProductID = pin.ProductID
																			AND pdtInd.LOVIndicatorId = pin.LOVIndicatorId
																			AND pdtInd.LOVRecordSourceID=pin.LOVRecordSourceID
																			AND pdtInd.ScdVersion > pin.ScdVersion))

		INSERT INTO [ser].[ProductIndicator]
					( ProductID,LOVIndicatorId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,
					SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey )		
		SELECT		pindTemp.ProductID ProductID,
					pindTemp.LOVIndicatorId LOVIndicatorId,
					pindTemp.PIValue Value,
					pindTemp.LOVRecordSourceId LOVRecordSourceId,
					CASE WHEN ((ISNULL(pind.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId ORDER BY pindTemp.date_added ASC)) = 1)
								 THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
								 ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''')
								 END SCDStartDate,
					LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER(PARTITION BY pindTemp.ProductId,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId ORDER BY pindTemp.date_added ASC) SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId ORDER BY pindTemp.date_added ASC) SCDActiveFlag,
					ISNULL(pind.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId ORDER BY pindTemp.date_added ASC) SCDVersion,
					pindTemp.SCDLOVRecordSourceId SCDLOVRecordSourceId,
					pindTemp.ETLRunLogId ETLRunLogId,
					pindTemp.PSARowKey PSARowKey
		FROM
		(
		SELECT 
					ProductID,
				    (SELECT LOVId FROM ser.RefLOVSetInfo WHERE LOVKey = ''''+PICol+'''' AND
				    LOVSetName = '''+@indicatorName+''' ) LOVIndicatorId,
				    PIValue,
				    LOVRecordSourceId,
				    date_added ,
				    SCDEndDate ,
				    LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductID,PICol,PIValue,date_added ORDER BY date_added ASC) SCDActiveFlag,						
				    SCDLOVRecordSourceId,
				    ETLRunLogId,
				    PSARowKey   
		FROM
		(
		SELECT
					product.ProductID ProductID,   
					intprod.exclusive_flag exclusive_flag,
					intprod.own_brand_flag own_brand_flag,
					intprod.record_source_id LOVRecordSourceId,
					intprod.date_added date_added,		--SCDStartDate,
					CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,
					intprod.record_source_id SCDLOVRecordSourceId,
					'+@inpServeETLRunLogID+' ETLRunLogId,
					intprod.row_id PSARowKey
					FROM  '+@inpTableName+' intprod
					join Stg_Product product
					on product.SourceKey = intprod.item_code
					AND product.LOVRecordSourceID = intprod.record_source_id
					AND product.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+' 
					WHERE intprod.row_status='+@rowStatusPSACode+'
					AND intprod.date_added ='+@dateAdded+'
		) t
					UNPIVOT
						(PIValue FOR PICol in (exclusive_flag,own_brand_flag)
						) AS ProductIndicator WHERE  PIValue!='''' AND PIValue IS NOT NULL
		)pindTemp
					LEFT JOIN Stg_Indicator pind
							ON pindTemp.productid=pind.productid
							AND pindTemp.LOVIndicatorId=pind.LOVIndicatorId
							AND pindTemp.LOVRecordSourceId=pind.LOVRecordSourceId
							WHERE pindTemp.PIValue is not null  
							--AND ISNULL (pind.SCDActiveFlag,''Y'') =''Y''
							AND pindTemp.SCDActiveFlag=''Y''
							AND NOT EXISTS (select 1 from ser.ProductIndicator serpind 
													  WHERE	  pindTemp.ProductID = serpind.productID
													    AND	  pindTemp.LOVIndicatorId= serpind.LOVIndicatorId
														AND	  pindTemp.LOVRecordSourceId=serpind.LOVRecordSourceId
														AND	  pindTemp.PIValue = serpind.Value
														AND   serpind.SCDActiveFlag =''Y'')

			')

		PRINT 'Info: ProductIndicator Table -> Closing off old Records if exists';
		
	exec('			UPDATE ser.ProductIndicator set SCDActiveFlag=''N'',SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
								FROM ser.ProductIndicator p 
								JOIN 
									(	SELECT productId,LOVIndicatorId,SCDactiveflag, SCDVersion,LovRecordSourceId 
										FROM ser.ProductIndicator t WHERE   
										t.LOVRecordSourceID='+@recordSourceId+'
										AND t.SCDActiveFlag=''Y''
													AND NOT EXISTS (
																	   SELECT 1 FROM ser.ProductIndicator AS ptin 
																				WHERE ptin.ProductID = t.ProductID
																				AND  ptin.LOVRecordSourceID=t.LOVRecordSourceID
																				AND	 ptin.LOVIndicatorId= t.LOVIndicatorId
																				AND  ptin.ScdVersion > t.ScdVersion
																	)  
									) p2  
									ON  p.productID=p2.productId
									AND p.LovRecordSourceId=p2.LovRecordSourceId	
									AND p.LOVIndicatorId = p2.LOVIndicatorId
									AND p.SCDactiveflag=p2.SCDactiveflag
									AND p.SCDVersion!=p2.SCDVersion	
								WHERE	p.SCDActiveFlag=''Y''
									AND p.SCDEndDate =CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''')

			')

	exec('				UPDATE ser.ProductIndicator SET SCDActiveFlag= ''N'', SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
									FROM ser.ProductIndicator pin
										JOIN (	SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag, SCDVersion,LovRecordSourceId
												FROM ser.Product t WHERE   
														t.LOVRecordSourceID='+@recordSourceId+'
														AND NOT EXISTS (
																		   SELECT 1 FROM ser.Product AS pt 
																				  WHERE pt.ProductID		 =t.ProductID
																					AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																					AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																					AND pt.ScdVersion > t.ScdVersion
																		) 
											  ) p2
										ON
											pin.productID=p2.productId
										AND pin.LovRecordSourceId=p2.LovRecordSourceId				
										JOIN (
												select	inp.item_code item_code,
														'+@LOVIndicatorIdOBFlag+'	LOVIndicatorId,
														inp.own_brand_flag Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														from '+@inpTableName+' inp
														where inp.row_status='+@rowStatusPSACode+'
														AND date_added ='+@dateAdded+'
												union
												select
														inp.item_code item_code,
														'+@LOVIndicatorIdEXFlag+'	LOVIndicatorId,
														inp.exclusive_flag Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														from '+@inpTableName+' inp
														where inp.row_status='+@rowStatusPSACode+'
														AND date_added ='+@dateAdded+'
											) intprod
										ON intprod.record_source_id=p2.LovRecordSourceId 
										AND p2.sourcekey = intprod.item_code
										AND p2.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
									WHERE	( NULLIF(intprod.value,'''' ) IS NULL OR p2.SCDActiveFlag=''N'') 
										AND pin.LOVIndicatorId = intprod.LOVIndicatorId
										AND pin.SCDActiveFlag=''Y'';
									
				')

				PRINT 'Info: Product Indicator Table Loaded Successfully'; 

/********************************************************************************************************************************

 5. Table Name  :	Product Property

--********************************************************************************************************************************/

				PRINT 'Info: Product Property Table Serve Loading Started';

				PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

exec('			WITH  Stg_Product AS ( SELECT * FROM ser.Product t 
										  WHERE LovRecordSourceId='+@recordSourceId+'
												AND LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
												AND t.SCDActiveFlag=''Y''
												AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt 
																			WHERE pdt.ProductID = t.ProductID
																			AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																			AND pdt.LOVSourceKeyTypeId = t.LOVSourceKeyTypeId
																			AND  pdt.ScdVersion > t.ScdVersion))
				,Stg_Product_Property AS ( SELECT * FROM ser.ProductProperty pty
										WHERE LovRecordSourceId='+@recordSourceId+'
												AND NOT EXISTS (SELECT 1 FROM ser.ProductProperty AS pdtPty 
																			WHERE pdtPty.ProductID = pty.ProductID
																			AND pdtPty.MeasureId = pty.MeasureId
																			AND pdtPty.LOVUOMId = pty.LOVUOMId
																			AND pdtPty.LOVRecordSourceID=pty.LOVRecordSourceID
																			AND pdtPty.ScdVersion > pty.ScdVersion))

			INSERT INTO [ser].[ProductProperty] (
						ProductID,MeasureID,LOVUOMId,value,LOVRecordSourceId,SCDStartDate,SCDEndDate,
						SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey	)
			SELECT 
						ProductID,MeasureID,LOVUOMId,value,LOVRecordSourceId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,MeasureID,LOVRecordSourceId ORDER BY date_added ASC)) = 1)
								 THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
								 ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''')
								 END SCDStartDate,
						LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER(PARTITION BY ProductId,MeasureID,LOVRecordSourceId ORDER BY date_added ASC) SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductId,MeasureID,LOVRecordSourceId ORDER BY date_added ASC) SCDActiveFlag,
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,MeasureID,LOVRecordSourceId ORDER BY date_added ASC) SCDVersion,
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
			FROM 
			(
			
			SELECT 
						product.ProductID ProductID,
						measure.MeasureId MeasureID,
						'+@uomCmId+' LOVUOMId,
						intprod.height value,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added date_added,
						CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductID,measure.MeasureId,intprod.height,intprod.record_source_id,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						intprod.record_source_id SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+' intprod
						JOIN Stg_Product product
							ON product.SourceKey = intprod.item_code 
							AND product.LOVRecordSourceID = intprod.record_source_id
							AND product.SCDActiveFlag = ''Y''
							AND intprod.height != '''' AND intprod.height IS NOT NULL
						JOIN ser.Measure measure 
							ON measure.MeasureName = ''height'' 
							AND measure.LOVRecordSourceId = intprod.record_source_id
							AND measure.LOVMeasureTypeId = '+@measureTypeId+'
							AND measure.LOVDataTypeId = '+@dataTypeId+' -- DO WE NEED TO CONSIDER DATATYPE ID ALSO ???
						LEFT JOIN Stg_Product_Property p
							ON p.ProductID =product.ProductID
							AND p.LOVRecordSourceId = product.LOVRecordSourceId
							AND p.MeasureID = measure.MeasureID 
						--	AND p.SCDActiveFlag = ''Y''
						WHERE intprod.row_status = '+@rowStatusPSACode+'
							AND intprod.date_added = '+@dateAdded+'
						--  AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
	
			UNION
			SELECT
						product.ProductID ProductID,
						measure.MeasureID MeasureID,
						'+@uomCmId+' LOVUOMId,
						intprod.width value,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added date_added,
						CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductID,measure.MeasureId,intprod.width,intprod.record_source_id,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						intprod.record_source_id SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+' intprod
						JOIN Stg_Product product
							ON product.SourceKey =intprod.item_code
							AND product.LOVRecordSourceID = intprod.record_source_id
							AND product.SCDActiveFlag = ''Y''
							AND intprod.width != '''' AND intprod.width IS NOT NULL 
						JOIN ser.Measure measure 
							ON measure.MeasureName =''width'' 
							AND measure.LOVRecordSourceId = intprod.record_source_id
							AND measure.LOVMeasureTypeId = '+@measureTypeId+'
							AND measure.LOVDataTypeId = '+@dataTypeId+' -- DO WE NEED TO CONSIDER DATATYPE ID ALSO ???
						LEFT JOIN Stg_Product_Property p
							ON p.ProductID =product.ProductID 
							AND p.LOVRecordSourceId = product.LOVRecordSourceId
							AND p.MeasureID = measure.MeasureID
						--	AND p.SCDActiveFlag = ''Y''
						WHERE intprod.row_status = '+@rowStatusPSACode+' 
							AND intprod.date_added = '+@dateAdded+'
					   --   AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
				
			UNION
			SELECT
						product.ProductID ProductID,
						measure.MeasureID MeasureID,
						'+@uomCmId+' LOVUOMId,
						intprod.depth value,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added date_added,
						CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductID,measure.MeasureId,intprod.depth,intprod.record_source_id,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						intprod.record_source_id SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+' intprod
						JOIN Stg_Product product
							ON product.SourceKey =intprod.item_code
							AND product.LOVRecordSourceID = intprod.record_source_id
							AND product.SCDActiveFlag =''Y''
							AND intprod.depth != '''' AND intprod.depth IS NOT NULL 
						JOIN ser.Measure measure 
							ON measure.MeasureName = ''depth'' 
							AND measure.LOVRecordSourceId = intprod.record_source_id
							AND measure.LOVMeasureTypeId = '+@measureTypeId+'
							AND measure.LOVDataTypeId = '+@dataTypeId+' -- DO WE NEED TO CONSIDER DATATYPE ID ALSO ???
						LEFT JOIN Stg_Product_Property p
							ON p.ProductID = product.ProductID
							AND p.LOVRecordSourceId = product.LOVRecordSourceId
							AND p.MeasureID = measure.MeasureID 
						--	AND p.SCDActiveFlag = ''Y''
						WHERE intprod.row_status = '+@rowStatusPSACode+'
							AND intprod.date_added ='+ @dateAdded+'
						--  AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
				
			UNION
			SELECT
						product.ProductID ProductID,
						measure.MeasureID MeasureID,
						'+@uomUnknownId+' LOVUOMId,
						intprod.size value,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added date_added,
						CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductID,measure.MeasureId,intprod.size,intprod.record_source_id,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						intprod.record_source_id SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM  '+@inpTableName+' intprod
						JOIN Stg_Product product
							ON product.SourceKey = intprod.item_code
							AND product.LOVRecordSourceID = intprod.record_source_id
							AND product.SCDActiveFlag = ''Y''
							AND intprod.size != '''' AND intprod.size IS NOT NULL 
						JOIN ser.Measure measure 
							ON measure.MeasureName = ''size'' 
							AND measure.LOVRecordSourceId = intprod.record_source_id
							AND measure.LOVMeasureTypeId ='+@measureTypeId+'
							AND measure.LOVDataTypeId = '+@dataTypeId+' -- DO WE NEED TO CONSIDER DATATYPE ID ALSO ???
						LEFT JOIN Stg_Product_Property p
							ON p.ProductID =product.ProductID 
							AND p.LOVRecordSourceId = product.LOVRecordSourceId
							AND p.MeasureID = measure.MeasureID
						--	AND p.SCDActiveFlag = ''Y''
						WHERE intprod.row_status = '+@rowStatusPSACode+'
							AND intprod.date_added = '+@dateAdded+'
						--  AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
						) prdtppty
						WHERE prdtppty.SCDActiveFlag=''Y''
						AND NOT EXISTS (SELECT 1 FROM ser.ProductProperty serppty
													  WHERE	  prdtppty.ProductID = serppty.productID
													    AND	  prdtppty.MeasureId = serppty.MeasureId 
														AND	  prdtppty.LOVUOMId  = serppty.LOVUOMId 
														AND	  prdtppty.LOVRecordSourceId = serppty.LOVRecordSourceId
														AND	  prdtppty.Value = serppty.Value
														AND   serppty.SCDActiveFlag = ''Y'' )
		')

			PRINT 'Info: ProductProperty Table -> Closing off old Records if exists';
			
		exec('			UPDATE ser.ProductProperty set SCDActiveFlag=''N'',SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
											FROM ser.ProductProperty p 
											JOIN 
												(	SELECT productId,MeasureId,LOVUOMId,SCDactiveflag, SCDVersion,LovRecordSourceId 
													FROM ser.ProductProperty t WHERE   
													t.LOVRecordSourceID  = '+@recordSourceId+'
													AND t.SCDActiveFlag=''Y''
																AND NOT EXISTS (
																				   SELECT 1 FROM ser.ProductProperty AS ptpty 
																							WHERE ptpty.ProductID = t.ProductID
																							AND  ptpty.LOVRecordSourceID = t.LOVRecordSourceID
																							AND	 ptpty.MeasureId = t.MeasureId
																							AND  ptpty.LOVUOMId = t.LOVUOMId
																							AND  ptpty.ScdVersion > t.ScdVersion
																				)  
												) p2  
												ON  p.productID = p2.productId
												AND p.LovRecordSourceId = p2.LovRecordSourceId	
												AND p.MeasureId = p2.MeasureId
												AND p.LOVUOMId = p2.LOVUOMId
												AND p.SCDactiveflag = p2.SCDactiveflag
												AND p.SCDVersion != p2.SCDVersion	
											WHERE	p.SCDActiveFlag = ''Y''
												AND p.SCDEndDate = CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''')
				')

	exec('			UPDATE ser.ProductProperty SET SCDActiveFlag= ''N'', SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
										FROM ser.ProductProperty pty
										JOIN (	SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag, SCDVersion,LovRecordSourceId
												FROM ser.Product t WHERE   
														t.LOVRecordSourceID='+@recordSourceId+'
														AND NOT EXISTS (
																		   SELECT 1 FROM ser.Product AS pt 
																				  WHERE pt.ProductID		 =t.ProductID
																					AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																					AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																					AND pt.ScdVersion > t.ScdVersion
																		) 
											  ) p2
										ON
											pty.productID=p2.productId
										AND pty.LovRecordSourceId=p2.LovRecordSourceId				
										JOIN (
												select	inp.item_code item_code,
														measure.MeasureID MeasureID,
														'+@uomCmId+' LOVUOMId,
														inp.height Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														JOIN ser.Measure measure 
															ON measure.MeasureName = ''height'' 
															AND measure.LOVRecordSourceId = inp.record_source_id
															AND measure.LOVMeasureTypeId = '+@measureTypeId+'
															AND measure.LOVDataTypeId = '+@dataTypeId+'
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	inp.item_code item_code,
														measure.MeasureID MeasureID,
														'+@uomCmId+' LOVUOMId,
														inp.width Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														JOIN ser.Measure measure 
															ON measure.MeasureName = ''width'' 
															AND measure.LOVRecordSourceId = inp.record_source_id
															AND measure.LOVMeasureTypeId = '+@measureTypeId+'
															AND measure.LOVDataTypeId = '+@dataTypeId+'
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	inp.item_code item_code,
														measure.MeasureID MeasureID,
														'+@uomCmId+' LOVUOMId,
														inp.depth Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														JOIN ser.Measure measure 
															ON measure.MeasureName = ''depth'' 
															AND measure.LOVRecordSourceId = inp.record_source_id
															AND measure.LOVMeasureTypeId = '+@measureTypeId+'
															AND measure.LOVDataTypeId = '+@dataTypeId+'
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	inp.item_code item_code,
														measure.MeasureID MeasureID,
														'+@uomUnknownId+' LOVUOMId,
														inp.size Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														JOIN ser.Measure measure 
															ON measure.MeasureName = ''size'' 
															AND measure.LOVRecordSourceId = inp.record_source_id
															AND measure.LOVMeasureTypeId = '+@measureTypeId+'
															AND measure.LOVDataTypeId = '+@dataTypeId+'
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'

											) intprod
										ON intprod.record_source_id=p2.LovRecordSourceId 
										AND p2.sourcekey = intprod.item_code
										AND p2.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
									WHERE	( NULLIF(intprod.value,'''' ) IS NULL OR p2.SCDActiveFlag=''N'') 
										AND pty.MeasureID = intprod.MeasureID
										AND pty.LOVUOMId = intprod.LOVUOMId
										AND pty.SCDActiveFlag=''Y'';
					')


				PRINT 'Info: Product Property Table Loaded Successfully'; 

/********************************************************************************************************************************

 6. Table Name  :	Product Group

--********************************************************************************************************************************/

				PRINT 'Info: Product Group Table Serve Loading Started';


IF (@recordSourceId =12005 OR @recordSourceId =12004)

	BEGIN

		exec('	WITH Stg_Product AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID		-- Product Latest
													  FROM ser.Product pt, '+@inpTableName+' intprod 
													  WHERE  pt.LOVSourceKeyTypeId   = '+@itemCodeSourceKeyTypeId+'
															AND	intprod.item_code    = pt.SourceKey
															AND pt.SCDActiveFlag     = ''Y''
															AND pt.LoVRecordSourceID = intprod.record_source_id
															AND intprod.row_status   = '+@rowStatusPSACode+'
															AND intprod.date_added   = '+@dateAdded+'
															  )	
				,Stg_serve_productGroup AS (SELECT t.*,pt.SourceKey							-- Product Group Latest
													  FROM ser.productGroup t,Stg_Product pt 						
															WHERE t.ProductID		= pt.ProductID									
															AND t.LoVRecordSourceID = pt.LoVRecordSourceID												  
															AND NOT EXISTS (SELECT 1 FROM ser.productGroup  pdt 
																					 WHERE pdt.ProductID		  = t.ProductID
																					 AND pdt.LOVProductGroupSetId = t.LOVProductGroupSetId
																					 AND pdt.LOVRecordSourceID	  = t.LOVRecordSourceID
																					 AND pdt.ScdVersion > t.ScdVersion
																			)
											)
				,Stg_src_ProductGroup AS (SELECT			
										ProductId,
										PGCol,		
											( CASE 
												WHEN 
												     PGCol in (''product_hierarchy1'',''product_hierarchy2'',''product_hierarchy3'',''product_hierarchy4'',''product_hierarchy5'') THEN 
													 -- ADD APPEND _name instead of replace _number  => LOVSetName = product_hierarchy4_name or product_hierarchy4_code
													(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = ''''+PGValue+'''' AND  r.LOVSetName = ''''+CONCAT (PGCol,''_name'','''')+'''' 
													and r.LOVRecordSourceID = '+@recordSourceId+') 
						
											     ELSE
													(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = ''''+PGValue+'''' AND r.LOVSetName = ''''+PGCol+'''' 
													and r.LOVRecordSourceID = '+@recordSourceId+')
												
												END ) LOVGroupId,										

										(  CASE 
												WHEN 
													PGCol in (''product_hierarchy1'',''product_hierarchy2'',''product_hierarchy3'',''product_hierarchy4'',''product_hierarchy5'') THEN
													-- ADD APPEND _name instead of replace _number => LOVSetName = product_hierarchy4_name or product_hierarchy4_code
													(SELECT Distinct LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''''+CONCAT (PGCol,''_name'','''')+''''
													and rs.LOVRecordSourceID = '+@recordSourceId+') 
												
												ELSE 
													(SELECT Distinct rs.LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''''+PGCol+'''' and rs.LOVRecordSourceID = '+@recordSourceId+') 
												END ) LOVProductGroupSetId,
										PGValue  value ,
										ParentProductGroupId,
										LOVRecordSourceId LOVRecordSourceId,							 
										LOVRecordSourceId SCDLOVRecordSourceId,
										ETLRunLogId,
										PSARowKey,
										'+@dateAdded+' date_added
										FROM
										(SELECT
											  p.ProductID
											  ,product_hierarchy1
											  ,product_hierarchy2
											  ,product_hierarchy3
											  ,product_hierarchy4
											  ,product_hierarchy5
											  ,product_hierarchy1_code
											  ,product_hierarchy2_code
											  ,product_hierarchy3_code
											  ,product_hierarchy4_code
											  ,product_hierarchy5_code										
											 ,intprod.record_source_id LOVRecordSourceId
											 ,intprod.record_source_id SCDLOVRecordSourceId
											 ,NULL ParentProductGroupId
											 ,'+@inpServeETLRunLogID+'  ETLRunLogId
											 ,intprod.row_id PSARowKey
										FROM '+@inpTableName+' intprod 
										INNER JOIN
										Stg_Product p 
										ON	p.SourceKey =  intprod.item_code 						
										WHERE  intprod.row_status = '+@rowStatusPSACode+'	
											AND intprod.date_added= '+@dateAdded+' ) pg
										UNPIVOT  
													( PGValue FOR PGCol IN (
																			 product_hierarchy1
																			,product_hierarchy2
																			,product_hierarchy3
																			,product_hierarchy4
																			,product_hierarchy5
																			,product_hierarchy1_code
																			,product_hierarchy2_code
																			,product_hierarchy3_code
																			,product_hierarchy4_code
																			,product_hierarchy5_code
																			)
													)	AS LOVGroupId  )

							INSERT  INTO  ser.ProductGroup (	ProductGroupId		  ,
																ProductId			  ,
																LOVGroupId            ,
																LOVProductGroupSetId  ,
																ParentProductGroupId  ,
																LOVRecordSourceId     ,
																SCDStartDate          ,
																SCDEndDate            ,
																SCDActiveFlag         ,
																SCDVersion            ,
																SCDLOVRecordSourceId  ,
																ETLRunLogId           ,
																PSARowKey)
										SELECT  ISNULL(spg.ProductGroupId,(PGTemp.row_num+'+@maxProductGroupId+')) as ProductGroupId,
												pgt.ProductId,
												pgt.LOVGroupId,
												pgt.LOVProductGroupSetId,
												pgt.ParentProductGroupId,
												pgt.LOVRecordSourceId,
												(CASE WHEN ISNULL(spg.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId   ORDER BY   pgt.ProductID,pgt.date_added ASC)=1 
												THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
												ELSE
												LEAD(CONVERT(NVARCHAR,'''+@SCDStartDate+'''),1,CONVERT(NVARCHAR,'''+@SCDStartDate+''')) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId  order by  pgt.ProductID,pgt.date_added)
												END) as SCDStartDate,	
												LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId order by   pgt.ProductID,pgt.date_added) SCDEndDate,
												LEAD(''N'', 1, ''Y'') OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY  pgt.ProductID,pgt.date_added ASC) SCDActiveFlag,				
												ISNULL(spg.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY   pgt.ProductID,pgt.date_added ASC) SCDVersion,
												pgt.SCDLOVRecordSourceId  ,
												pgt.ETLRunLogId,
												pgt.PSARowKey
										FROM Stg_src_ProductGroup pgt	 
										JOIN
										(
											SELECT ProductID, LOVProductGroupSetId,LOVRecordSourceId,ROW_NUMBER() OVER(ORDER BY ProductID,LOVProductGroupSetId,LOVRecordSourceId ASC) row_num
												FROM Stg_src_ProductGroup  
												GROUP BY ProductID,LOVProductGroupSetId,LOVRecordSourceId
										)  PGTemp
											ON pgt.ProductID			 = PGTemp.ProductID
											AND pgt.LOVProductGroupSetId = PGTemp.LOVProductGroupSetId
											AND pgt.LOVRecordSourceId    = PGTemp.LOVRecordSourceId
										LEFT  JOIN Stg_serve_productGroup spg
											ON pgt.productid			 = spg.productid
											AND pgt.LOVProductGroupSetId = spg.LOVProductGroupSetId
											AND pgt.LOVRecordSourceId    = spg.LOVRecordSourceId
								WHERE NOT EXISTS (SELECT 1 FROM ser.ProductGroup serpg where serpg.productid	   = pgt.productid
																					AND serpg.LOVRecordSourceId    = pgt.LOVRecordSourceId
																					AND serpg.SCDActiveFlag        = ''Y''
																					AND serpg.LOVProductGroupSetId = pgt.LOVProductGroupSetId	
																					AND serpg.LOVGroupID		   = pgt.LOVGroupID
																					)
										AND NULLIF(pgt.value,'''') is not null and pgt.LOVGroupID is not null 
										
			')

				PRINT 'Info: ProductGroup Table -> Closing off old Records if exists';

	exec('	UPDATE ser.ProductGroup set SCDActiveFlag=''N'',SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
						  FROM ser.ProductGroup pg 
					  JOIN 
					   ( SELECT productId,LOVProductGroupSetId,SCDactiveflag,SCDVersion,LovRecordSourceId
								FROM ser.ProductGroup t 
								WHERE t.LOVRecordSourceID = '+@recordSourceId+'
									AND t.SCDactiveflag   = ''Y''  
									AND NOT EXISTS (SELECT 1 FROM ser.ProductGroup AS pt 
																			WHERE pt.ProductID				= t.ProductID
																				AND pt.LOVProductGroupSetId = t.LOVProductGroupSetId 
																				AND pt.LOVRecordSourceID	= t.LOVRecordSourceID 
																				AND pt.ScdVersion > t.ScdVersion
													)
						)pg2
						ON  pg.productID				= pg2.productId
						    AND pg.LovRecordSourceId	= pg2.LovRecordSourceId
						    AND pg.LOVProductGroupSetId = pg2.LOVProductGroupSetId						 
						    AND pg.SCDactiveflag		= pg2.SCDactiveflag
						    AND pg.SCDVersion		   != pg2.SCDVersion
						WHERE pg.LovRecordSourceId		= '+@recordSourceId+'
							AND pg.SCDActiveFlag		= ''Y'' 
							AND pg.SCDEndDate			= CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''') ;
	
			')

	exec('	UPDATE ser.ProductGroup SET SCDActiveFlag= ''N'', SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
										FROM ser.ProductGroup pgr
										JOIN (	SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag, SCDVersion,LovRecordSourceId
												FROM ser.Product t WHERE   
														t.LOVRecordSourceID='+@recordSourceId+'
														AND NOT EXISTS (
																		   SELECT 1 FROM ser.Product AS pt 
																				  WHERE pt.ProductID		 =t.ProductID
																					AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																					AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																					AND pt.ScdVersion > t.ScdVersion
																		) 
											  ) p2
										ON
											pgr.productID=p2.productId
										AND pgr.LovRecordSourceId=p2.LovRecordSourceId				
										JOIN (
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdC1+' LOVProductGroupSetId,
														inp.product_hierarchy1_code Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdN1+' LOVProductGroupSetId,
														inp.product_hierarchy1 Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdC2+' LOVProductGroupSetId,
														inp.product_hierarchy2_code Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdN2+' LOVProductGroupSetId,
														inp.product_hierarchy2 Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdC3+' LOVProductGroupSetId,
														inp.product_hierarchy3_code Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdN3+' LOVProductGroupSetId,
														inp.product_hierarchy3 Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdC4+' LOVProductGroupSetId,
														inp.product_hierarchy4_code Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdN4+' LOVProductGroupSetId,
														inp.product_hierarchy4 Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdC5+' LOVProductGroupSetId,
														inp.product_hierarchy5_code Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdN5+' LOVProductGroupSetId,
														inp.product_hierarchy5 Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'

											) intprod
										ON intprod.record_source_id=p2.LovRecordSourceId 
										AND p2.sourcekey = intprod.item_code
										AND p2.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
									WHERE	( NULLIF(intprod.value ,'''' ) IS NULL OR p2.SCDActiveFlag=''N'') 
										AND pgr.LOVProductGroupSetId = intprod.LOVProductGroupSetId
										AND pgr.SCDActiveFlag=''Y''
				')

	END

IF (@recordSourceId =12010)

	BEGIN

exec('			WITH Stg_Product AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID		
													  FROM ser.Product pt, '+@inpTableName+' intprod 
													  WHERE  pt.LOVSourceKeyTypeId   = '+@itemCodeSourceKeyTypeId+'
															AND	intprod.item_code    = pt.SourceKey
															AND pt.SCDActiveFlag     = ''Y''
															AND pt.LoVRecordSourceID = intprod.record_source_id
															AND intprod.row_status   = '+@rowStatusPSACode+'
															AND intprod.date_added   = '+@dateAdded+'
															  )	
				,Stg_serve_productGroup AS (SELECT t.*,pt.SourceKey							
													  FROM ser.productGroup t,Stg_Product pt 						
															WHERE t.ProductID		= pt.ProductID									
															AND t.LoVRecordSourceID = pt.LoVRecordSourceID												  
															AND NOT EXISTS (SELECT 1 FROM ser.productGroup  pdt 
																					 WHERE pdt.ProductID		  = t.ProductID
																					 AND pdt.LOVProductGroupSetId = t.LOVProductGroupSetId
																					 AND pdt.LOVRecordSourceID	  = t.LOVRecordSourceID
																					 AND pdt.ScdVersion > t.ScdVersion
																			)
											)
				,Stg_src_ProductGroup AS (SELECT			
										ProductId,
										PGCol,		
											( CASE 
												WHEN 
												     PGCol in (''product_hierarchy1'',''product_hierarchy2'',''product_hierarchy3'',''product_hierarchy4'') THEN 
													 -- ADD APPEND _name instead of replace _number  => LOVSetName = product_hierarchy4_name or product_hierarchy4_code
													(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = ''''+PGValue+'''' AND  r.LOVSetName = ''''+CONCAT (PGCol,''_name'','''')+'''' 
													and r.LOVRecordSourceID = '+@recordSourceId+') 
						
											     ELSE
													(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = ''''+PGValue+'''' AND r.LOVSetName = ''''+PGCol+'''' 
													and r.LOVRecordSourceID = '+@recordSourceId+')
												
												END ) LOVGroupId,										

										(  CASE 
												WHEN 
													PGCol in (''product_hierarchy1'',''product_hierarchy2'',''product_hierarchy3'',''product_hierarchy4'') THEN
													-- ADD APPEND _name instead of replace _number => LOVSetName = product_hierarchy4_name or product_hierarchy4_code
													(SELECT Distinct LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''''+CONCAT (PGCol,''_name'','''')+''''
													and rs.LOVRecordSourceID = '+@recordSourceId+') 
												
												ELSE 
													(SELECT Distinct rs.LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''''+PGCol+'''' and rs.LOVRecordSourceID = '+@recordSourceId+') 
												END ) LOVProductGroupSetId,
										PGValue  value ,
										ParentProductGroupId,
										LOVRecordSourceId LOVRecordSourceId,							 
										LOVRecordSourceId SCDLOVRecordSourceId,
										ETLRunLogId,
										PSARowKey,
										'+@dateAdded+' date_added
										FROM
										(SELECT
											  p.ProductID
											  ,product_hierarchy1
											  ,product_hierarchy2
											  ,product_hierarchy3
											  ,product_hierarchy4
											  ,product_hierarchy1_code
											  ,product_hierarchy2_code
											  ,product_hierarchy3_code
											  ,product_hierarchy4_code										
											 ,intprod.record_source_id LOVRecordSourceId
											 ,intprod.record_source_id SCDLOVRecordSourceId
											 ,NULL ParentProductGroupId
											 ,'+@inpServeETLRunLogID+'  ETLRunLogId
											 ,intprod.row_id PSARowKey
										FROM '+@inpTableName+' intprod 
										INNER JOIN
										Stg_Product p 
										ON	p.SourceKey =  intprod.item_code 						
										WHERE  intprod.row_status = '+@rowStatusPSACode+'	
											AND intprod.date_added= '+@dateAdded+' ) pg
										UNPIVOT  
													( PGValue FOR PGCol IN (
																			 product_hierarchy1
																			,product_hierarchy2
																			,product_hierarchy3
																			,product_hierarchy4
																			,product_hierarchy1_code
																			,product_hierarchy2_code
																			,product_hierarchy3_code
																			,product_hierarchy4_code
																			)
													)	AS LOVGroupId  )

							INSERT  INTO  ser.ProductGroup (	ProductGroupId		  ,
																ProductId			  ,
																LOVGroupId            ,
																LOVProductGroupSetId  ,
																ParentProductGroupId  ,
																LOVRecordSourceId     ,
																SCDStartDate          ,
																SCDEndDate            ,
																SCDActiveFlag         ,
																SCDVersion            ,
																SCDLOVRecordSourceId  ,
																ETLRunLogId			  ,
																PSARowKey)
										SELECT  ISNULL(spg.ProductGroupId,(PGTemp.row_num+'+@maxProductGroupId+')) as ProductGroupId,
												pgt.ProductId,
												pgt.LOVGroupId,
												pgt.LOVProductGroupSetId,
												pgt.ParentProductGroupId,
												pgt.LOVRecordSourceId,
												(CASE WHEN ISNULL(spg.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId   ORDER BY   pgt.ProductID,pgt.date_added ASC)=1 
												THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
												ELSE
												LEAD(CONVERT(NVARCHAR,'''+@SCDStartDate+'''),1,CONVERT(NVARCHAR,'''+@SCDStartDate+''')) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId  order by  pgt.ProductID,pgt.date_added)
												END) as SCDStartDate,	
												LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId order by   pgt.ProductID,pgt.date_added) SCDEndDate,
												LEAD(''N'', 1, ''Y'') OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY  pgt.ProductID,pgt.date_added ASC) SCDActiveFlag,				
												ISNULL(spg.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY   pgt.ProductID,pgt.date_added ASC) SCDVersion,
												pgt.SCDLOVRecordSourceId  ,
												pgt.ETLRunLogId,
												pgt.PSARowKey
										FROM Stg_src_ProductGroup pgt	 
										JOIN
										(
											SELECT ProductID, LOVProductGroupSetId,LOVRecordSourceId,ROW_NUMBER() OVER(ORDER BY ProductID,LOVProductGroupSetId,LOVRecordSourceId ASC) row_num
												FROM Stg_src_ProductGroup  
												GROUP BY ProductID,LOVProductGroupSetId,LOVRecordSourceId
										)  PGTemp
											ON pgt.ProductID			 = PGTemp.ProductID
											AND pgt.LOVProductGroupSetId = PGTemp.LOVProductGroupSetId
											AND pgt.LOVRecordSourceId    = PGTemp.LOVRecordSourceId
										LEFT  JOIN Stg_serve_productGroup spg
											ON pgt.productid			 = spg.productid
											AND pgt.LOVProductGroupSetId = spg.LOVProductGroupSetId
											AND pgt.LOVRecordSourceId    = spg.LOVRecordSourceId
								WHERE NOT EXISTS (SELECT 1 FROM ser.ProductGroup serpg where serpg.productid	   = pgt.productid
																					AND serpg.LOVRecordSourceId    = pgt.LOVRecordSourceId
																					AND serpg.SCDActiveFlag        = ''Y''
																					AND serpg.LOVProductGroupSetId = pgt.LOVProductGroupSetId	
																					AND serpg.LOVGroupID		   = pgt.LOVGroupID
																					)
										AND NULLIF(pgt.value,'''') is not null and pgt.LOVGroupID is not null 
										
			')

				PRINT 'Info: ProductGroup Table -> Closing off old Records if exists';

exec('				UPDATE ser.ProductGroup set SCDActiveFlag=''N'',SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
						  FROM ser.ProductGroup pg 
					  JOIN 
					   ( SELECT productId,LOVProductGroupSetId,SCDactiveflag,SCDVersion,LovRecordSourceId
								FROM ser.ProductGroup t 
								WHERE t.LOVRecordSourceID = '+@recordSourceId+'
									AND t.SCDactiveflag   = ''Y''  
									AND NOT EXISTS (SELECT 1 FROM ser.ProductGroup AS pt 
																			WHERE pt.ProductID				= t.ProductID
																				AND pt.LOVProductGroupSetId = t.LOVProductGroupSetId 
																				AND pt.LOVRecordSourceID	= t.LOVRecordSourceID 
																				AND pt.ScdVersion > t.ScdVersion
													)
						)pg2
						ON  pg.productID				= pg2.productId
						    AND pg.LovRecordSourceId	= pg2.LovRecordSourceId
						    AND pg.LOVProductGroupSetId = pg2.LOVProductGroupSetId						 
						    AND pg.SCDactiveflag		= pg2.SCDactiveflag
						    AND pg.SCDVersion		   != pg2.SCDVersion
						WHERE pg.LovRecordSourceId		= '+@recordSourceId+'
							AND pg.SCDActiveFlag		= ''Y'' 
							AND pg.SCDEndDate			= CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''') ;
			')
	
exec('				UPDATE ser.ProductGroup SET SCDActiveFlag= ''N'', SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
										FROM ser.ProductGroup pgr
										JOIN (	SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag, SCDVersion,LovRecordSourceId
												FROM ser.Product t WHERE   
														t.LOVRecordSourceID='+@recordSourceId+'
														AND NOT EXISTS (
																		   SELECT 1 FROM ser.Product AS pt 
																				  WHERE pt.ProductID		 =t.ProductID
																					AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																					AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																					AND pt.ScdVersion > t.ScdVersion
																		) 
											  ) p2
										ON
											pgr.productID=p2.productId
										AND pgr.LovRecordSourceId=p2.LovRecordSourceId				
										JOIN (
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdC1+' LOVProductGroupSetId,
														inp.product_hierarchy1_code Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdN1+' LOVProductGroupSetId,
														inp.product_hierarchy1 Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdC2+' LOVProductGroupSetId,
														inp.product_hierarchy2_code Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdN2+' LOVProductGroupSetId,
														inp.product_hierarchy2 Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdC3+' LOVProductGroupSetId,
														inp.product_hierarchy3_code Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdN3+' LOVProductGroupSetId,
														inp.product_hierarchy3 Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdC4+' LOVProductGroupSetId,
														inp.product_hierarchy4_code Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
												union
												select	distinct inp.item_code item_code,
														'+@ProductGroupSetIdN4+' LOVProductGroupSetId,
														inp.product_hierarchy4 Value,
														inp.record_source_id record_source_id,
														inp.row_status row_status,
														inp.etl_runlog_id etl_runlog_id,
														inp.date_added date_added
														FROM '+@inpTableName+' inp
														WHERE inp.row_status='+@rowStatusPSACode+'
															AND date_added ='+@dateAdded+'
											) intprod
										ON intprod.record_source_id=p2.LovRecordSourceId 
										AND p2.sourcekey = intprod.item_code
										AND p2.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
									WHERE	( NULLIF(intprod.value ,'''' ) IS NULL OR p2.SCDActiveFlag=''N'') 
										AND pgr.LOVProductGroupSetId = intprod.LOVProductGroupSetId
										AND pgr.SCDActiveFlag=''Y''
				')

		END
				PRINT 'Info: Product Group Table Loaded Successfully'; 
		
/********************************************************************************************************************************

 7. Table Name  :	Party

--********************************************************************************************************************************/

				PRINT 'Info: Party Table Serve Loading Started';

				PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

		exec('		INSERT INTO [ser].[Party]
							(                         
							PartyId,LOVPartyTypeId,SourceKey,LOVRecordSourceId,SCDEndDate,SCDActiveFlag,
							SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,SCDStartDate,PSARowKey
							)
					SELECT  '+@maxpartyID+'+ROW_NUMBER() OVER(ORDER BY party.SourceKey,party.LOVRecordSourceId ASC) partyId,
							'+@partytypeID+'  LOVPartyTypeId,
							party.SourceKey SourceKey,
							party.LOVRecordSourceId LOVRecordSourceId,
							CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,
							''Y'' SCDActiveFlag,
							1 SCDVersion,
							party.SCDLOVRecordSourceId SCDLOVRecordSourceId, 
							'+@inpServeETLRunLogID+' ETLRunLogId,
							CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''') SCDStartDate ,
							party.PSARowKey PSARowKey
					FROM
						(	SELECT supplier_number SourceKey,
							record_source_id LOVRecordSourceId,
							record_source_id SCDLOVRecordSourceId,
							MIN(row_id) PSARowKey
							FROM '+@inpTableName+' intprod 
							WHERE intprod.supplier_number!='''' AND intprod.supplier_number IS NOT NULL
								AND intprod.record_source_id = '+@recordSourceId+'
								AND intprod.row_status='+@rowStatusPSACode+'
								AND intprod.date_added = '+@dateAdded+'
							GROUP BY supplier_number,record_source_id
									) party
						    WHERE NOT EXISTS
						    	(	SELECT 1 from ser.party pr 
						    		WHERE pr.SourceKey = party.SourceKey 
						    		  AND pr.LOVRecordSourceId =party.LOVRecordSourceId  )
					')


				PRINT 'Info: Party Table Loaded Successfully'; 


/********************************************************************************************************************************

 8. Table Name  :	Organisation

--********************************************************************************************************************************/

				PRINT 'Info: Organisation Table Serve Loading Started';

				PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

		exec('
					WITH	Stg_Organisation AS ( SELECT * FROM ser.Organisation org
														WHERE LovRecordSourceId='+@recordSourceId+'
														AND NOT EXISTS (SELECT 1 FROM ser.Organisation AS serorgn 
																					WHERE serorgn.PartyID = org.PartyID
																					AND serorgn.SourceOrganisationKey = org.SourceOrganisationKey
																					AND serorgn.LOVRecordSourceID=org.LOVRecordSourceID
																					AND serorgn.ScdVersion > org.ScdVersion))
				
				INSERT INTO ser.organisation  (
							PartyId,SourceOrganisationKey,OrganisationName,LOVRecordSourceId,ParentPartyId,SCDStartDate,
							SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey ) 
				
				SELECT		party.PartyId  PartyId,
							t.SourceOrganisationKey SourceOrganisationKey,
							t.OrganisationName OrganisationName,
							t.LOVRecordSourceId LOVRecordSourceId,
							NULL ParentPartyId,
							CASE WHEN ((ISNULL(org.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.date_added ASC)) = 1)
													 THEN	CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
													 ELSE	CONVERT(NVARCHAR,'''+@SCDStartDate+''')
													 END	SCDStartDate,
							LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDEndDate,
							LEAD(''N'', 1, ''Y'') OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDActiveFlag,
							ISNULL(org.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDVersion,
							t.LOVRecordSourceId SCDLOVRecordSourceId, 
							'+@inpServeETLRunLogID+' ETLRunLogId,
							t.PSARowKey PSARowKey
				FROM	(
				SELECT		supplier_number SourceOrganisationKey,
							supplier_name OrganisationName,
							record_source_id LOVRecordSourceId,
							date_added date_added,
							MIN(row_id) PSARowKey
							FROM '+@inpTableName+' intprod 
							WHERE intprod.supplier_number!='''' AND intprod.supplier_number IS NOT NULL 
							  AND intprod.supplier_name !='''' AND intprod.supplier_name IS NOT NULL		
							  AND intprod.row_status= '+@rowStatusPSACode +'
							  AND intprod.date_added = '+@dateAdded+'
							GROUP BY supplier_number,supplier_name,record_source_id,date_added
						)t
					
					JOIN ser.party party
						ON  t.SourceOrganisationKey = party.SourceKey
						AND t.LOVRecordSourceId = party.LOVRecordSourceId
					LEFT JOIN Stg_Organisation org
						ON  org.PartyId = party.PartyId
						AND org.LOVRecordSourceId = t.LOVRecordSourceId
						AND org.SCDActiveFlag = ''Y'' 
					WHERE NOT EXISTS (
										SELECT  1 from ser.Organisation serorg 
										WHERE party.partyId			  = serorg.partyId 
										AND	  t.SourceOrganisationKey = serorg.SourceOrganisationKey 
										AND   t.OrganisationName      = serorg.OrganisationName 
										AND   t.LOVRecordSourceId     = serorg.LOVRecordSourceId 
										AND	  serorg.SCDActiveFlag =''Y''
									 )
				')	
		
						PRINT 'Info: Organisation Table -> Closing off old Records if exists';
		
			exec('			UPDATE ser.Organisation set SCDActiveFlag=''N'',SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
											FROM ser.Organisation p 
												JOIN 
													(	SELECT PartyID,SourceOrganisationKey,SCDactiveflag, SCDVersion,LovRecordSourceId 
														FROM ser.Organisation t WHERE   
														t.LOVRecordSourceID  = '+@recordSourceId+'
														AND t.SCDActiveFlag=''Y''
																	AND NOT EXISTS (
																					   SELECT 1 FROM ser.Organisation AS serorg 
																								WHERE serorg.PartyID = t.PartyID
																								  AND serorg.SourceOrganisationKey = t.SourceOrganisationKey
																								  AND serorg.LOVRecordSourceID = t.LOVRecordSourceID
																								  AND serorg.ScdVersion > t.ScdVersion
																					)  
													) p2  
													ON  p.PartyID = p2.PartyID
													AND p.LovRecordSourceId = p2.LovRecordSourceId	
													AND p.SourceOrganisationKey = p2.SourceOrganisationKey
													AND p.SCDactiveflag = p2.SCDactiveflag
													AND p.SCDVersion != p2.SCDVersion	
												WHERE	p.SCDActiveFlag = ''Y''
													AND p.SCDEndDate = CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''')	
				')
		
		
						PRINT 'Info: Organisation Table Loaded Successfully'; 
		
/********************************************************************************************************************************

 9. Table Name  :	Party Role

--********************************************************************************************************************************/	
		
				PRINT 'Info: Party Role Table Serve Loading Started';

				PRINT 'Info: Inserting the new version of record if there is achange in the attribute';
exec('		
		WITH	Stg_PartyRole AS ( SELECT * FROM ser.PartyRole prole
														WHERE LovRecordSourceId='+@recordSourceId+'
														AND NOT EXISTS (SELECT 1 FROM ser.PartyRole AS ptyrole 
																					WHERE ptyrole.PartyID         = prole.PartyID
																					AND	ptyrole.LOVRoleId		  = prole.LOVRoleId 
																					AND ptyrole.PartyRoleId       = prole.PartyRoleId 
																					AND ptyrole.SourceKey         = prole.SourceKey
																					AND ptyrole.LOVRecordSourceID = prole.LOVRecordSourceID
																					AND ptyrole.ScdVersion > prole.ScdVersion))
		
			INSERT INTO	[ser].[PartyRole] (	
							PartyRoleId,LOVRoleId,PartyId,SourceKey,PartyRoleName,LOVRecordSourceId,SCDStartDate,
							SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey	)
			SELECT			ISNULL(pRole.partyroleid,a.PartyRoleId) PartyRoleId,
							'+@lovSupplierRoleId+' LOVRoleId,
							party.PartyId PartyId,
							t.SourceKey SourceKey,
							t.PartyRoleName PartyRoleName,
							t.LOVRecordSourceId LOVRecordSourceId,
							CASE WHEN ((ISNULL(pRole.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.date_added ASC)) = 1)
										 THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''' )
										 ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''')
										 END SCDStartDate,	
							LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDEndDate,
							LEAD(''N'', 1, ''Y'') OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDActiveFlag,
							ISNULL(pRole.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDVersion,
							t.LOVRecordSourceId SCDLOVRecordSourceId, 
							'+@inpServeETLRunLogID+' ETLRunLogId,
							t.PSARowKey PSARowKey
			FROM
						(
			SELECT				supplier_number SourceKey,
								supplier_name PartyRoleName,
								record_source_id LOVRecordSourceId,
								date_added date_added,
								MIN(row_id) PSARowKey
								FROM '+@inpTableName+' intprod 
								WHERE intprod.supplier_number!='''' AND intprod.supplier_number IS NOT NULL
								  AND intprod.supplier_name !='''' AND intprod.supplier_name IS NOT NULL		
								AND intprod.row_status='+@rowStatusPSACode+'
								AND intprod.date_added = '+@dateAdded+'
								GROUP BY supplier_number,supplier_name,record_source_id,date_added
						)t	
								JOIN (
										SELECT supplier_number,record_source_id,
										('+@maxpartyRoleID+'+ROW_NUMBER() OVER(ORDER BY supplier_number,record_source_id ASC)) PartyRoleId
										FROM '+@inpTableName+' inp
										WHERE inp.supplier_number!='''' AND inp.supplier_number IS NOT NULL
										AND inp.row_status='+@rowStatusPSACode+'
										AND inp.date_added = '+@dateAdded+'
										GROUP BY supplier_number,record_source_id
									 ) a
									ON t.SourceKey = a.supplier_number
									AND t.LOVRecordSourceId = a.record_source_id
								JOIN ser.party party
									ON t.SourceKey = party.SourceKey
									AND t.LOVRecordSourceId = party.LOVRecordSourceId
								LEFT JOIN Stg_PartyRole pRole
									ON pRole.PartyId = party.PartyId
									AND pRole.LOVRecordSourceId = t.LOVRecordSourceId
									WHERE NOT EXISTS (
										SELECT  1 from ser.PartyRole serorg 
										WHERE party.partyId		  = serorg.partyId 
										AND	  pRole.LOVRoleId     = serorg.LOVRoleId  
										AND	  t.SourceKey		  = serorg.SourceKey 
										AND   t.PartyRoleName     = serorg.PartyRoleName 
										AND   t.LOVRecordSourceId = serorg.LOVRecordSourceId 
										AND	  serorg.SCDActiveFlag =''Y''
									 )
				')

				PRINT 'Info: PartyRole Table -> Closing off old Records if exists';
			
			
	exec('		UPDATE ser.PartyRole set SCDActiveFlag=''N'',SCDEndDate = CONVERT(NVARCHAR,'''+@SCDEndDate+''')
											FROM ser.PartyRole p 
												JOIN 
													(	SELECT PartyID,PartyRoleId,LOVRoleId,SourceKey,LovRecordSourceId,SCDactiveflag,SCDVersion
														FROM ser.PartyRole t WHERE   
														t.LOVRecordSourceID  ='+@recordSourceId+'
														AND t.SCDActiveFlag=''Y''
																	AND NOT EXISTS (
																					   SELECT 1 FROM ser.PartyRole AS serprle 
																								WHERE serprle.PartyID = t.PartyID
																								  AND serprle.PartyRoleId = t.PartyRoleId
																								  AND serprle.LOVRoleId = t.LOVRoleId
																								  AND serprle.SourceKey = t.SourceKey
																								  AND serprle.LOVRecordSourceID = t.LOVRecordSourceID
																								  AND serprle.ScdVersion > t.ScdVersion
																					)  
													) p2  
													ON  p.PartyID = p2.PartyID
													AND p.PartyRoleId = p2.PartyRoleId
													AND p.LOVRoleId = p2.LOVRoleId
													AND p.SourceKey = p2.SourceKey
													AND p.LovRecordSourceId = p2.LovRecordSourceId	
													AND p.SCDactiveflag = p2.SCDactiveflag
													AND p.SCDVersion != p2.SCDVersion	
												WHERE	p.SCDActiveFlag = ''Y''
													AND p.SCDEndDate = CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''')

				')

						PRINT 'Info: PartyRole Table Loaded Successfully'; 
		
/********************************************************************************************************************************

 10. Table Name  :	Product Party Role

--********************************************************************************************************************************/	

				PRINT 'Info: Product Party Role Table Serve Loading Started';

				PRINT 'Info: Inserting the new version of record if there is achange in the attribute';
				
				
	exec('			    WITH Stg_src_Product  AS ( 
							SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,intprod.supplier_number,intprod.row_id,intprod.date_added
											  FROM ser.Product pt,'+@inpTableName+' intprod 
											  WHERE  pt.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
													AND	intprod.item_code=pt.SourceKey
													AND pt.SCDActiveFlag=''Y''
													AND intprod.record_source_id=pt.LoVRecordSourceID
													AND intprod.row_status='+@rowStatusPSACode+'
													AND intprod.date_added='+@dateAdded+'
											 )	
			   ,stg_Src_ProductPartyRole AS (
							SELECT p.productid,pr.partyroleid,pr.LOVRoleId,pr.sourcekey,p.row_id,p.date_added,pr.LOvRecordSourceID
											   FROM  ser.PartyRole pr
													JOIN Stg_src_Product p
														ON  pr.sourcekey=p.supplier_number
														AND pr.LOvRecordSourceID=p.LOvRecordSourceID
														AND pr.SCDActiveFlag=''Y''
													LEFT JOIN[ser].[RefLOVSetInfo] rs
														ON pr.LOVRoleID=rs.lovID 
														AND rs.LOVSetName  =''Role''
														AND rs.LOVKey in (''Supplier'')      
											  UNION ALL
											  SELECT p.productid,pr.partyroleid,pr.LOVRoleId,pr.sourcekey ,p.row_id,p.date_added,pr.LOvRecordSourceID
											   FROM  ser.PartyRole pr
													JOIN Stg_src_Product p
														ON  pr.sourcekey='''+@sourceKey+'''
														AND pr.LOvRecordSourceID=p.LOvRecordSourceID
														AND pr.SCDActiveFlag=''Y''
													LEFT JOIN[ser].[RefLOVSetInfo] rs
														ON pr.LOVRoleID=rs.lovID
														AND rs.LOVSetName  =''Role''
														AND rs.LOVKey in (''Retailer'')
												
												)
				,stg_serve_ProductPartyRole AS ( 
							SELECT * FROM (
												SELECT t.*,pt.SourceKey,pr.LOVRoleId
													 FROM ser.ProductPartyRole t,stg_src_Product pt,ser.PartyRole pr
													 WHERE t.ProductID=pt.ProductID
													 AND t.PartyRoleId=pr.PartyRoleId	
													 AND t.LoVRecordSourceID=pr.LoVRecordSourceID
													 AND t.LoVRecordSourceID=pt.LoVRecordSourceID
													 AND pr.ScdActiveFlag=''Y''		
										 ) a
					 WHERE NOT EXISTS (
							SELECT * FROM  (
												SELECT pdt.*,pr.LOVRoleId FROM ser.ProductPartyRole pdt,stg_src_Product pt,ser.PartyRole pr
														WHERE pdt.ProductID=pt.ProductID
															AND pdt.PartyRoleId=pr.PartyRoleId
															AND pdt.LoVRecordSourceID=pr.LoVRecordSourceID
															AND pdt.LoVRecordSourceID=pt.LoVRecordSourceID
															AND pr.ScdActiveFlag=''Y''		
											) b
																				 WHERE a.ProductID = b.ProductID
																				 --AND a.partyroleid=b.partyroleid
																				 AND a.LOVRoleId=b.LOVRoleId
																				 AND a.LOVRecordSourceID=b.LOVRecordSourceID
																				 AND b.ScdVersion > a.ScdVersion
										)
												)																			 

				INSERT INTO ser.ProductPartyRole
							(ProductId,PartyRoleId,LOVRecordSourceId,SCDStartDate,SCDEndDate,          
							SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
				SELECT
							p.ProductId ProductId,
							p.PartyRoleId PartyRoleId ,
							p.LOVRecordSourceId  LOVRecordSourceId,
							CASE WHEN ((ISNULL(ppr.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId ORDER BY  p.ProductID,p.date_added ASC))=1 )
								THEN	CONVERT(NVARCHAR,'''+@SCDDefaultStartDate+''')
								ELSE	CONVERT(NVARCHAR,'''+@SCDStartDate+''')
								END		SCDStartDate,	
							LEAD(CONVERT(NVARCHAR,'''+@SCDEndDate+'''),1,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')) OVER (PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId order by p.ProductID,p.date_added) SCDEndDate,
							LEAD(''N'', 1, ''Y'') OVER(PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId  ORDER BY p.ProductID,p.date_added ASC) SCDActiveFlag,				
							ISNULL(ppr.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId ORDER BY p.ProductID,p.date_added ASC) SCDVersion,
							p.LOVRecordSourceId  SCDLOVRecordSourceId,
							'+@inpServeETLRunLogID+' ETLRunLogId,
							p.row_id PSARowKey
							FROM stg_Src_ProductPartyRole p
							LEFT JOIN stg_serve_ProductPartyRole ppr 
								ON ppr.ProductId=p.ProductId 
								AND ppr.LovRecordSourceID=p.LovRecordSourceID
								AND ppr.LOVRoleId=p.LOVRoleId
							WHERE NOT EXISTS (SELECT 1 FROM ser.ProductPartyRole  pdt 
														JOIN ser.PartyRole pr 
															ON pdt.PartyRoleId=pr.PartyRoleId
															AND pdt.SCDActiveFlag=''Y''
															AND pdt.SCDActiveFlag=pr.SCDActiveFlag
															AND pr.ScdActiveFlag =''Y''	-- MY ADDITION	
															WHERE pdt.ProductID = p.ProductID
															AND pdt.partyroleid=p.partyroleid
															AND pr.LOVRoleId=p.LOVRoleId)	
																			 
				')

		PRINT 'Info: ProductPartyRole Table -> Closing off old Records if exists';

	exec('				UPDATE ser.ProductPartyRole set SCDActiveFlag=''N'',SCDEndDate =CONVERT(NVARCHAR,'''+@SCDEndDate+''')
						FROM ser.ProductPartyRole ppr 
						JOIN (
								SELECT t.productId,t.PartyRoleId,pr.LOVRoleID,t.SCDactiveflag,t.SCDVersion,t.LovRecordSourceId
									FROM ser.ProductPartyRole t,ser.PartyRole pr
										WHERE t.LovRecordSourceId=pr.LovRecordSourceId
										AND t.PartyRoleId=pr.PartyRoleId
										AND pr.LOVRoleId='+@lovSupplierRoleId+'
										AND pr.SCDActiveFlag = ''Y'' -- NEW ADDITION
										AND t.LOVRecordSourceID='+@recordSourceId+'
										AND t.SCDactiveflag=''Y'' 
										AND NOT EXISTS (SELECT 1 FROM ser.ProductPartyRole AS pt ,ser.PartyRole pr
																WHERE pt.ProductID = t.ProductID
																AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																AND pt.PartyRoleId=pr.PartyRoleId
																AND pr.lovroleID=pr.LOVRoleId
																AND pr.SCDACtiveFlag =''Y''		-- NEW ADDITION
																AND pt.ScdVersion > t.ScdVersion)
							) ppr2
									   ON  ppr.productID=ppr2.productId
									   AND ppr.LovRecordSourceId=ppr2.LovRecordSourceId									   
									   AND ppr.SCDactiveflag=ppr2.SCDactiveflag
									   AND ppr.SCDVersion!=ppr2.SCDVersion
									   WHERE ppr.LovRecordSourceId='+@recordSourceId+'
									   AND ppr.SCDActiveFlag=''Y''
									   AND ppr.SCDEndDate =CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')
									   AND ppr.PartyRoleId NOT IN (
													SELECT PartyRoleID FROM ser.PartyRole 
													WHERE LOVRoleid='+@lovRetailerRoleId+'
													  AND LovRecordSourceId='+@recordSourceId+'
													  );
			')			
	
	exec('			WITH stg_Src_ProductPartyRole AS (
									SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,intprod.row_id,intprod.date_added
										  FROM ser.Product pt,'+@inpTableName+' intprod 
										  WHERE  pt.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
												AND	intprod.item_code=pt.SourceKey
												AND intprod.record_source_id=pt.LoVRecordSourceID													
												AND intprod.row_status='+@rowStatusPSACode+'
												AND intprod.date_added='+@dateAdded+'
												AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
															WHERE t.ProductID = pt.ProductID
															AND t.LOVRecordSourceID=pt.LOVRecordSourceID
															AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
															AND t.ScdVersion > pt.ScdVersion)
												AND  pt.SCDActiveFlag=''N''
												)									
					UPDATE ser.ProductPartyRole set SCDActiveFlag=''N'',SCDEndDate =CONVERT(NVARCHAR,'''+@SCDEndDate+''')
						FROM ser.ProductPartyRole ppr 
						JOIN stg_Src_ProductPartyRole p
						   ON ppr.ProductID=p.ProductID
						   AND ppr.LoVRecordSourceID=p.LoVRecordSourceID
						   AND ppr.ScdActiveFlag = ''Y''; 

			')

	exec('			WITH stg_Src_ProductPartyRole AS (
									SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,intprod.row_id,intprod.date_added
										  FROM ser.Product pt,'+@inpTableName+' intprod 
										  WHERE  pt.LOVSourceKeyTypeId='+@itemCodeSourceKeyTypeId+'
												AND	intprod.item_code=pt.SourceKey
												AND intprod.record_source_id=pt.LoVRecordSourceID													
												AND intprod.row_status='+@rowStatusPSACode+'
												AND intprod.date_added='+@dateAdded+'
												AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
															WHERE t.ProductID = pt.ProductID
															AND t.LOVRecordSourceID=pt.LOVRecordSourceID
															AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
															AND t.ScdVersion > pt.ScdVersion)
												AND ( NULLIF( intprod.supplier_number,'''' ) IS NULL  OR  NULLIF( intprod.supplier_name,'''' ) IS NULL )				
												)
			UPDATE ser.ProductPartyRole set SCDActiveFlag=''N'',SCDEndDate =CONVERT(NVARCHAR,'''+@SCDEndDate+''')
					FROM ser.ProductPartyRole pdtpr 
					JOIN stg_Src_ProductPartyRole p
					   ON pdtpr.ProductID=p.ProductID
					   AND pdtpr.LoVRecordSourceID=p.LoVRecordSourceID
					 --  AND pdtpr.ScdActiveFlag = ''Y''
					JOIN ser.partyRole pr
						ON pr.partyRoleId = pdtpr.partyRoleId
						AND pr.LOVRoleID = '+@lovSupplierRoleId+'
						AND pr.LoVRecordSourceID=pdtpr.LoVRecordSourceID
						AND pr.ScdActiveFlag=''Y''
					WHERE pdtpr.ScdActiveFlag = ''Y'';

			')

					 PRINT 'Info: ProductPartyRole Table Incremental Load Completed Successfully'; 

/********************************************************************************************************************************

Update the psa layer table with row_status as 'Loaded to Serve' once after Successful Migration

--********************************************************************************************************************************/	

	exec('				 UPDATE '+@srcTableName+' SET row_status = '+@rowStatusSERCode+'
											 FROM '+@srcTableName+' intprod 
														   INNER JOIN
														   ser.Product p 
															ON p.sourcekey = ISNULL( NULLIF((Substring(intprod.item_code, Patindex(''%[^0]%'', intprod.item_code + '' ''), Len(intprod.item_code)) ),''''),0)
																AND p.LOVSourceKeyTypeId = '+@itemCodeSourceKeyTypeId+'
																AND p.LovRecordSourceID = intprod.record_source_id
															INNER JOIN
																(
																	  (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.Product 
																							WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID= '+@recordSourceId+') 	
															UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductIdentifier  
																							WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID= '+@recordSourceId+') 
															UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductStatus 
																							WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID= '+@recordSourceId+') 	
															UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductProperty
																							WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID= '+@recordSourceId+')
															UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductIndicator
																							WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID= '+@recordSourceId+')
															UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductGroup 
																							WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID= '+@recordSourceId+')
															UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductPartyRole  
																							WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID= '+@recordSourceId+')
																) temp
															ON  temp.scdLovRecordSourceID ='+@recordSourceId+'
															AND temp.productId=p.productID
															AND temp.psarowkey=intprod.row_id
															WHERE intprod.row_status='+@rowStatusPSACode+'
														 	    AND intprod.date_added='+@dateAdded+' ;
		')

IF (@recordSourceId =12005 OR @recordSourceId =12004)

	BEGIN

	exec('			UPDATE '+@srcTableName+' SET Row_Status='+@rowStatusSERCode+'
											FROM '+@srcTableName+' intprod 
														   INNER JOIN
														   ser.Product p 
															ON p.LovRecordSourceId = intprod.record_source_id
																AND p.sourcekey = ISNULL( NULLIF((Substring(intprod.item_code, Patindex(''%[^0]%'', intprod.item_code + '' ''), Len(intprod.item_code)) ),''''),0)
																AND p.LOVSourceKeyTypeId = '+@itemCodeSourceKeyTypeId+'
														 WHERE intprod.Row_Status='+@rowStatusPSACode+'
																AND intprod.date_added ='+@dateAdded+'
																AND
											(
												 (	 NULLIF(intprod.item_description,'''') IS NULL 
												 AND NULLIF(intprod.brand,'''') IS NULL 
												 AND NULLIF(intprod.subbrand,'''') IS NULL
												 )
											OR
												 (  
													 NULLIF(intprod.upc,'''') IS NULL
												  OR NULLIF(intprod.size,'''') IS NULL
												  OR NULLIF(intprod.width,'''') IS NULL
												  OR NULLIF(intprod.depth,'''') IS NULL
												  OR NULLIF(intprod.height,'''') IS NULL
												  OR NULLIF(intprod.item_status,'''') IS NULL 
												  OR NULLIF(intprod.supplier_name,'''') IS NULL
												  OR NULLIF(intprod.exclusive_flag,'''') IS NULL
												  OR NULLIF(intprod.own_brand_flag,'''') IS NULL 
												  OR NULLIF(intprod.supplier_number,'''') IS NULL
												  OR NULLIF(intprod.product_hierarchy1,'''') IS NULL 
												  OR NULLIF(intprod.product_hierarchy2,'''') IS NULL 
												  OR NULLIF(intprod.product_hierarchy3,'''') IS NULL
												  OR NULLIF(intprod.product_hierarchy4,'''') IS NULL
												  OR NULLIF(intprod.product_hierarchy5,'''') IS NULL 
												  OR NULLIF(intprod.product_hierarchy1_code,'''') IS NULL 
												  OR NULLIF(intprod.product_hierarchy2_code,'''') IS NULL
												  OR NULLIF(intprod.product_hierarchy3_code,'''') IS NULL
												  OR NULLIF(intprod.product_hierarchy4_code,'''') IS NULL 
												  OR NULLIF(intprod.product_hierarchy5_code,'''') IS NULL 
												 )
											 );
			')
	END

IF (@recordSourceId =12010)

	BEGIN

	exec('				UPDATE '+@srcTableName+' SET Row_Status='+@rowStatusSERCode+'
											FROM '+@srcTableName+' intprod 
														   INNER JOIN
														   ser.Product p 
															    ON	p.LovRecordSourceId = intprod.record_source_id
																AND p.sourcekey = ISNULL( NULLIF((Substring(intprod.item_code, Patindex(''%[^0]%'', intprod.item_code + '' ''), Len(intprod.item_code)) ),''''),0)
																AND p.LOVSourceKeyTypeId = '+@itemCodeSourceKeyTypeId+'
															WHERE intprod.Row_Status='+@rowStatusPSACode+'
																AND intprod.date_added = '+@dateAdded+'
																AND
											(
												 (	 NULLIF(intprod.item_description,'''') IS NULL 
												 AND NULLIF(intprod.brand,'''') IS NULL 
												 AND NULLIF(intprod.subbrand,'''') IS NULL
												 )
											OR
												 (   
													 NULLIF(intprod.upc,'''') IS NULL
												  OR NULLIF(intprod.height,'''') IS NULL
												  OR NULLIF(intprod.width,'''') IS NULL
												  OR NULLIF(intprod.depth,'''') IS NULL
												  OR NULLIF(intprod.size,'''') IS NULL
												  OR NULLIF(intprod.exclusive_flag,'''') IS NULL
												  OR NULLIF(intprod.own_brand_flag,'''') IS NULL 
												  OR NULLIF(intprod.item_status,'''') IS NULL 
												  OR NULLIF(intprod.product_hierarchy1,'''') IS NULL 
												  OR NULLIF(intprod.product_hierarchy2,'''') IS NULL 
												  OR NULLIF(intprod.product_hierarchy3,'''') IS NULL
												  OR NULLIF(intprod.product_hierarchy4,'''') IS NULL
												  OR NULLIF(intprod.product_hierarchy1_code,'''') IS NULL 
												  OR NULLIF(intprod.product_hierarchy2_code,'''') IS NULL
												  OR NULLIF(intprod.product_hierarchy3_code,'''') IS NULL
												  OR NULLIF(intprod.product_hierarchy4_code,'''') IS NULL 
												  OR NULLIF(intprod.supplier_number,'''') IS NULL
												  OR NULLIF(intprod.supplier_name,'''') IS NULL
												 )
											 );
						')
	END

	exec('			UPDATE '+@srcTableName+' SET row_status='+@rowStatusSERDuplicateCode+'
										FROM '+@srcTableName+' intprod 
										WHERE intprod.row_status='+@rowStatusPSACode+'
									    AND intprod.date_added='+@dateAdded+' 
		')
					PRINT 'Info: updated row_status in Source Table ->  '+@srcTableName+'';

					PRINT '********Info: International Product PSA to Serve Load Completed Successfully********';

				SET @COUNTER = @COUNTER + 1	
				
		END
		

		COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH 
				THROW; 			
				ROLLBACK TRANSACTION ;						
			END CATCH 

			print 'Dropping Cursor Table for Internation Product Source';
				DROP TABLE [psa].[int_product_cursor_table]
			print 'Successfully dropped Cursor Table';
			IF OBJECT_ID('psa.int_crp_product_stg') is not null
			BEGIN
					DROP TABLE [psa].[int_crp_product_stg]
			END
		
	END
GO
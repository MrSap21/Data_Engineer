/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_mdm_article]    Script Date: 11/20/2020 9:29:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_uk_btc_mdm_article') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_uk_btc_mdm_article 
    
END
GO

CREATE PROC [psa].[sp_inc_uk_btc_mdm_article] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS

/***********************************************************************************************************************
Procedure Name					: sp_inc_uk_btc_mdm_article
Purpose							: Load Incremental data From SAP MDM Source(uk_btc_mdm_article) into Serve Layer Table
Domain							: Product
ServeLayer Target Tables		: Product,ProductGroup,ProductIndicator,ProductIdentifier,ProductStatus,
									Party,Organization,PartyRole,PrductPartyRole    (Total 9 Tables)
RecordSourceID  for SAP MDM		: 12008
Feed Frequency					: Daily
***********************************************************************************************************************
***********************************************************************************************************************
Modification History
***********************************************************************************************************************
Date         :        Description
=======================================================================================================================
12/08/2020   :    Initial Version with LMW1 Data Mapping - UKROI_Product_Incremental v1.02 
04/09/2020   :    Added new parameter entityid in SP
                  Removed checking of scdlovrecordsourceid=151 from the rowstatus update 
19/11/2020   :    Handling removal of leading zero in incremental data -item_code,ean_code,vendor_number
***********************************************************************************************************************/
/*Declaring the variables*/

DECLARE		@COUNTER INT,
			@MAXID INT,	
			@asset_id BIGINT,		
			@PartyType_Id BIGINT,
			@max_PartyId BIGINT,
			@max_productID BIGINT,
			@mdm_record_sourceID BIGINT,
			@mainframe_record_source_id BIGINT,
			@max_productgroupId BIGINT,
			@max_partyrole_id  BIGINT ,
			@LOVRoleIDS BIGINT,
			@LOVRoleIdR BIGINT,
			@partyRoleID BIGINT,
			@LovStatusIDD BIGINT ,
			@LovStatusIDI BIGINT ,
			@LOVProductStatusSetId BIGINT,
			@LOVProductStatusSetIdRSC BIGINT,		
			@SCDLOVRecordSourceId VARCHAR(100),
			@SCDDefaultStartDate DATETIME, 	
			@SCDDefaultEndDate DATETIME,
			@created_timestamp DATETIME,
			@SCDStartDate DATETIME,
			@SCDEndDate DATETIME,
			@SCDVersion VARCHAR(100),		
			@SCDActiveFlag  VARCHAR(10),				
			@LOVSourceKeyTypeId BIGINT,
			@row_status_psa BIGINT,
			@row_status_serve BIGINT,
			@row_status_notmigrated BIGINT;	
		
BEGIN
			
            SET NOCOUNT ON;			
			
			/*Setting the up the static values to the variable*/				
			
			SET @SCDActiveFlag = 'Y'
			SET @SCDVersion ='1'
			
			SET @row_status_psa = 26001
			SET @row_status_serve = 26002
			SET @row_status_notmigrated = 26010
			
			SET @mdm_record_sourceID = 12008
			SET @SCDLOVRecordSourceId = 12008
			SET @mainframe_record_source_id = 12003

			SET @SCDDefaultStartDate = CONVERT(DateTime,'1900-01-01')	
			SET @SCDDefaultEndDate = CONVERT(DateTime,'9999-12-31')

			SET @PartyType_Id=(SELECT LOVId FROM ser.RefLOVSetInfo rs WHERE rs.LOVKey = 'ORG'AND  rs.LOVSetName = 'Party Type')					
			SET @LOVRoleIDR = (SELECT rs.LOVId FROM ser.RefLOVSetInfo rs WHERE rs.LOVKey = 'Retailer' AND rs.LOVSetName = 'Role')
			SET @LOVRoleIDS = (SELECT rs.LOVId FROM ser.RefLOVSetInfo rs WHERE rs.LOVKey = 'Supplier' AND rs.LOVSetName = 'Role')
			SET @LovStatusIDD=(SELECT rs.LovID FROM ser.RefLOVSetInfo rs WHERE rs.LOVKey = 'DSCNTND' AND rs.LOVSetName = 'Status Type')	
			SET @LovStatusIDI=(SELECT rs.LovID FROM ser.RefLOVSetInfo rs WHERE rs.LOVKey = 'INTRDCD' AND rs.LOVSetName = 'Status Type'  )	
			SET @LOVProductStatusSetId=	(SELECT distinct rs.LovSetID FROM ser.RefLOVSetInfo rs WHERE rs.LOVSetName = 'Status Type')
			SET @LOVProductStatusSetIdRSC=(SELECT distinct rs.LovSetID FROM ser.RefLOVSetInfo rs WHERE rs.LOVSetName = 'retail_status_code')
			SET @LOVSourceKeyTypeId=(SELECT rs.LOVId FROM  ser.RefLOVSetInfo rs	WHERE rs.LOVKey ='SAP Article Number' AND rs.LOVSetName = 'Source Key Type') ;	        
			
			IF OBJECT_ID('psa.uk_btc_mdm_article_stg') IS NOT NULL
			BEGIN
				DROP table  psa.uk_btc_mdm_article_stg
			END	

			CREATE TABLE [psa].[uk_btc_mdm_article_stg]
			WITH
			(
				DISTRIBUTION = REPLICATE,
				HEAP
			)
			AS
			SELECT row_id
				,RECORD_TYPE
				,ISNULL( NULLIF((Substring(ITEM_CODE, Patindex('%[^0]%', ITEM_CODE + ' '), Len(ITEM_CODE)) ),''),0) ITEM_CODE
				,ITEM_DESCRIPTION
				, (CASE WHEN NULLIF(EAN_CODE,'') IS NULL THEN EAN_CODE
					ELSE ISNULL( NULLIF((Substring(EAN_CODE, Patindex('%[^0]%', EAN_CODE + ' '), Len(EAN_CODE)) ),''),0) 
				  END)      EAN_CODE
				,BRAND_CODE
				,BRAND_DESCRIPTION
				,SUB_BRAND_CODE
				,SUB_BRAND_DESCRIPTION
				,ITEM_INTRODUCTION_DATE
				,ITEM_DELETION_DATE
				,MERCHANDISE_CATEGORY_CODE
				,MERCHANDISE_CATEGORY_DESCRIPTION
				,WAITROSE_LINE_NUMBER
				,(CASE WHEN NULLIF(VENDOR_NUMBER,'') IS NULL THEN VENDOR_NUMBER
					ELSE ISNULL( NULLIF((Substring(VENDOR_NUMBER, Patindex('%[^0]%', VENDOR_NUMBER + ' '), Len(VENDOR_NUMBER)) ),''),0) 
				  END)   VENDOR_NUMBER  
				,VENDOR_NAME
				,ITEM_HIERARCHY1_NUMBER
				,ITEM_HIERARCHY1_DESCRIPTION
				,ITEM_HIERARCHY2_NUMBER
				,ITEM_HIERARCHY2_DESCRIPTION
				,ITEM_HIERARCHY3_NUMBER
				,ITEM_HIERARCHY3_DESCRIPTION
				,ITEM_HIERARCHY4_NUMBER
				,ITEM_HIERARCHY4_DESCRIPTION
				,ITEM_HIERARCHY5_NUMBER
				,ITEM_HIERARCHY5_DESCRIPTION
				,ITEM_HIERARCHY6_NUMBER
				,ITEM_HIERARCHY6_DESCRIPTION
				,ITEM_HIERARCHY7_NUMBER
				,ITEM_HIERARCHY7_DESCRIPTION
				,EXCLUSIVE_FLAG
				,OWN_BRAND_CODE
				,STAFF_DISCOUNT_FLAG
				,ADVANTAGE_PROMOTIONS
				,GWP_FLAG
				,OCCASION_CODE
				,OCCASION_DESCRIPTION
				,ITEM_TYPE
				,RETAIL_STATUS
				,DROP_SHIP_FLAG
				,COLLECT_FROM_STORE_FLAG
				,VALID_FROM_DATE
				,VALID_FROM_TIME
				,LADDER_ID
				,LADDER
				,SUB_LADDER_ID
				,SUB_LADDER
				,BBE_ATTRIBUTE_CODE
				,BBE_ATTRIBUTE_DESCRIPTION
				,etl_runlog_id
				,asset_id
				,record_source_id
				,row_status
				,created_timestamp
				,active_flag
			FROM [psa].[uk_btc_mdm_article] WHERE row_status=@row_status_psa;

			IF OBJECT_ID('tempdb..#TempCurMdmProduct') IS NOT NULL
			BEGIN
				DROP table  #TempCurMdmProduct
			END	

			CREATE TABLE #TempCurMdmProduct
			WITH
			( DISTRIBUTION = ROUND_ROBIN
			)
			AS
			SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (asset_id)) AS RowID,									
																	asset_id
			FROM psa.[uk_btc_mdm_article] WHERE row_status=@row_status_psa 	;

		    SELECT @MAXID = COUNT(*) FROM #TempCurMdmProduct 


			BEGIN TRANSACTION
			 BEGIN TRY
				   --Setting the counter variable for looping with ASset
				SET @COUNTER = 1									
										
				print 'Total Number of Loops/Assets to be processed : '+cASt(@MAXID AS varchar)+'';
				WHILE (@COUNTER <= @MAXID)
				BEGIN	
						SELECT-- @created_timestamp = created_timestamp,
								@asset_id=asset_id 
						FROM #TempCurMdmProduct WHERE  RowID=@COUNTER;

						PRINT 'Current Processing ASSSET: '+CAST(@asset_id AS varchar)+';'

						SET @max_productID=(SELECT COALESCE(MAX(ProductID),0) FROM  ser.Product)
						SET @max_PartyId=(SELECT COALESCE(MAX(PartyID),0) FROM  ser.Party)
						SET @max_productgroupId=(SELECT COALESCE(MAX(ProductGroupId),0)  FROM  ser.ProductGroup)
						SET @max_partyrole_id=(SELECT COALESCE(MAX(PartyRoleID),0) FROM ser.PartyRole)	

						SET @SCDStartDate= CURRENT_TIMESTAMP
						SET @SCDEndDate =DATEADD(second,-1,@SCDStartDate)

						/* 1.Table Name  :Product */				

						PRINT '********Info: MDM Product PSA(uk_btc_mdm_article) to Serve Load Started********'; 
						
						PRINT 'Info: Product Table Serve Serve Incremental Load Started';
						
						WITH Stg_Product AS (SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag,SCDVersion,LovRecordSourceId 
							  FROM ser.Product t 
							  WHERE LOVRECORDSOURCEID=@mdm_record_sourceID 
									AND LOVSourceKeyTypeId=@LOVSourceKeyTypeId 
									AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt 
																			WHERE pdt.ProductID = t.ProductID
																			AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																			AND pdt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																			AND  pdt.ScdVersion > t.ScdVersion))
						INSERT INTO ser.Product (
							ProductId,SourceKey,LOVSourceKeyTypeId,ProductName ,ProductDescription,LOVBrANDId,LOVSubBrANDId ,  					
							LOVRecordSourceId,ParentProductId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
						
						SELECT     ISNULL(p.ProductID,productTemp.row_num) ProductID,				           
									mdmi.item_code SourceKey,
									@LOVSourceKeyTypeId LOVSourceKeyTypeId,
									mdmi.ITEM_DESCRIPTION ProductName,
									null ProductDescription ,	
									br.LOVId LOVBrANDId,
									sbr.LOVId SubBrANDId,       
									mdmi.record_source_id LOVRecordSourceId,
									null ParentProductID,							
									(CASE WHEN ISNULL(p.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY mdmi.item_code,mdmi.record_source_id ORDER BY mdmi.item_code,mdmi.created_timestamp ASC) =1 THEN
											   CONVERT (Datetime,@SCDDefaultStartDate)
										ELSE
									LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY mdmi.item_code,mdmi.record_source_id order by  mdmi.item_code,mdmi.created_timestamp)
									END) AS SCDStartDate,	
									LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY mdmi.item_code,mdmi.record_source_id order by  mdmi.item_code,mdmi.created_timestamp) SCDEndDate,
									LEAD('N', 1, 'Y') OVER(PARTITION BY mdmi.item_code,mdmi.record_source_id ORDER BY mdmi.item_code,mdmi.created_timestamp ASC) SCDActiveFlag,				
									ISNULL(p.SCDVersion,0)+ ROW_NUMBER() OVER(PARTITION BY mdmi.item_code,mdmi.record_source_id ORDER BY mdmi.item_code,mdmi.created_timestamp ASC) SCDVersion,
									@mdm_record_sourceID SCDLOVRecordSourceId,
									@serveETLRunLogID ETLRunLogId,
									row_id PSARowKey
						FROM psa.[uk_btc_mdm_article_stg]   mdmi
						JOIN (SELECT mdmi.item_code,
									mdmi.record_source_id,
									(ROW_NUMBER() OVER(ORDER BY mdmi.item_code,mdmi.record_source_id ASC)+ @max_productID) row_num
							 FROM psa.[uk_btc_mdm_article_stg]  mdmi WHERE mdmi.row_status=@row_status_psa AND  mdmi.asset_id=@asset_id  GROUP BY mdmi.item_code,mdmi.record_source_id) productTemp
						ON mdmi.item_code=productTemp.item_code	
						AND  mdmi.record_source_id=productTemp.record_source_id	
						LEFT JOIN Stg_Product p 
								   ON  mdmi.item_code =p.sourcekey
								   AND mdmi.record_source_id= p.LOVRecordSourceID														
						LEFT JOIN  ser.RefLOVSetInfo br                
								   ON br.LOVSetName = 'brand_code' 
								   AND mdmi.record_source_id=br.LOVRecordSourceId 
								   AND  br.LOVKey = mdmi.brAND_code
						LEFT JOIN ser.RefLOVSetInfo sbr                 
								  ON sbr.LOVSetName = 'sub_brand_code' 
								  AND mdmi.record_source_id=sbr.LOVRecordSourceId 
								  AND  sbr.LOVKey = mdmi.sub_brand_code				
						WHERE mdmi.row_status=@row_status_psa						
							AND mdmi.asset_id=@asset_id
							  AND (CASE  WHEN ( NULLIF(mdmi.ITEM_DESCRIPTION,'' ) IS NULL AND NULLIF( mdmi.brAND_code,'' ) IS NULL AND NULLIF( mdmi.sub_brand_code,'') IS NULL)  THEN 0
										 ELSE 1 END)=1
							  AND NOT EXISTS (SELECT 1 FROM ser.Product serp WHERE mdmi.item_code =serp.SourceKey
															AND mdmi.record_source_id=serp.LOVRecordSourceId
															AND p.LOVSourceKeyTypeId=serp.LOVSourceKeyTypeId
															AND serp.SCDActiveFlag='Y'
															AND ISNULL(mdmi.ITEM_DESCRIPTION,'')=ISNULL(serp.ProductName,'')
															AND ISNULL(br.LOVId,0)  = ISNULL(serp.LOVBrANDId,0)
															AND ISNULL(sbr.LOVId,0) = ISNULL(serp.LOVSubBrANDId,0));

						PRINT 'Info: Product Table -> Closing off old Records if exists';

						
						UPDATE ser.Product SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.Product p 
						JOIN (SELECT productId,SCDactiveflag,LOVSourceKeyTypeId,SCDVersion,LovRecordSourceId FROM ser.Product t WHERE   
							  t.LOVRecordSourceID=@mdm_record_sourceID AND t.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM ser.Product AS pt 
																		WHERE pt.ProductID = t.ProductID
																		AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																		AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId																
																		AND pt.ScdVersion > t.ScdVersion) )p2
							  ON  p.productID=p2.productId
							  AND p.LovRecordSourceId=p2.LovRecordSourceId						 
							  AND p.SCDactiveflag=p2.SCDactiveflag
							  AND p.SCDVersion!=p2.SCDVersion
							  AND p.LOVSourceKeyTypeId=p2.LOVSourceKeyTypeId
						JOIN  psa.[uk_btc_mdm_article_stg] mdmi
							  ON mdmi.record_source_id=p.LovRecordSourceId AND
							  p.sourcekey = mdmi.item_code
						WHERE p.SCDActiveFlag='Y' AND p.SCDEndDate =@SCDDefaultEndDate 
							  AND mdmi.row_status=@row_status_psa					
							  AND asset_id=@asset_id;


						UPDATE ser.product SET SCDActiveFlag= 'N',SCDEndDate =@SCDEndDate
						FROM ser.product p
						JOIN  psa.[uk_btc_mdm_article_stg] mdmi
							  ON mdmi.record_source_id=p.LovRecordSourceId
							  AND p.sourcekey = mdmi.item_code
							  AND p.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
						WHERE NULLIF(mdmi.ITEM_DESCRIPTION,'' ) IS NULL AND NULLIF( mdmi.brAND_code,'' ) IS NULL AND NULLIF( mdmi.sub_brand_code,'') IS NULL
							  AND p.SCDActiveFlag='Y'
							  AND asset_id=@asset_id;					 						
								

						PRINT 'Info: Product Table Loaded Successfully'; 

						/* 2.Table Name  :ProductGroup*/		
						
						PRINT 'Info: ProductGroup Table Serve Incremental Load Started for article'; 
						
						WITH Stg_Product AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID
															  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
															  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
																	AND	mdmi.item_code=pt.SourceKey
																	AND pt.SCDActiveFlag='Y'
																	AND mdmi.record_source_id=@mdm_record_sourceID
																	ANd pt.LoVRecordSourceID= @mdm_record_sourceID
																	AND mdmi.row_status=@row_status_psa														
																	AND mdmi.asset_id=@asset_id 
																	  )	
						,Stg_serve_productGroup AS (SELECT t.*,pt.SourceKey
															  FROM ser.productGroup t,Stg_Product pt 						
																	WHERE t.ProductID=pt.ProductID									
																	AND t.LoVRecordSourceID=pt.LoVRecordSourceID												  
																	AND NOT EXISTS (SELECT 1 FROM ser.productGroup  pdt 
																							 WHERE pdt.ProductID = t.ProductID
																							 AND pdt.LOVProductGroupSetId =t.LOVProductGroupSetId
																							 AND pdt.LOVRecordSourceID =t.LOVRecordSourceID
																							 AND  pdt.ScdVersion > t.ScdVersion))
						,Stg_src_ProductGroup AS (SELECT 
												ProductId,
												PGCol,
												(CASE WHEN PGCol ='item_hierarchy1_number' THEN 
															(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE ISNULL(NULLIF((Substring(r.LOVKey, Patindex('%[^0 ]%', r.LOVKey + ' '), Len(r.LOVKey) )),''),0)  = ''+PGValue+''  AND  r.LOVSetName = ''+REPLACE (PGCol,'_number','')+'' AND r.LOVRecordSourceID = @mdm_record_sourceID)  
														WHEN PGCol in ('item_hierarchy2_number','item_hierarchy3_number','item_hierarchy4_number','item_hierarchy5_number','item_hierarchy6_number') THEN
															(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = ''+PGValue+'' AND  r.LOVSetName = ''+REPLACE (PGCol,'_number','')+'' AND r.LOVRecordSourceID = @mdm_record_sourceID) 
													ELSE (SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey =''+PGValue+''  AND r.LOVSetName = ''+PGCol+'' AND r.LOVRecordSourceID =@mdm_record_sourceID) END) LOVGroupId,										
												(CASE WHEN PGCol in ('item_hierarchy1_number','item_hierarchy2_number','item_hierarchy3_number','item_hierarchy4_number','item_hierarchy5_number','item_hierarchy6_number') THEN
														(SELECT Distinct LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''+REPLACE (PGCol,'_number','')+'' AND rs.LOVRecordSourceID = @mdm_record_sourceID) 
													ELSE (SELECT Distinct rs.LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''+PGCol+'' AND rs.LOVRecordSourceID = @mdm_record_sourceID)  END) LOVProductGroupSetId,
												PGValue  value ,
												ParentProductGroupId,
												@mdm_record_sourceId LOVRecordSourceId,							 
												@SCDLOVRecordSourceId SCDLOVRecordSourceId,
												ETLRunLogId,
												PSARowKey,
												@created_timestamp created_timestamp
												FROM
												(SELECT
													  p.ProductID
													  ,ISNULL( NULLIF((Substring(mdmi.item_hierarchy1_number, Patindex('%[^0 ]%', mdmi.item_hierarchy1_number + ' '), Len(mdmi.item_hierarchy1_number)) ),''),0) item_hierarchy1_number /* Handling removal of leading zeroes */
													 /* Handling Lookup OR If null, then default to 0*/
													 ,ISNULL( NULLIF(mdmi.item_hierarchy2_number,''),0) item_hierarchy2_number
													 ,ISNULL( NULLIF(mdmi.item_hierarchy3_number,''),0) item_hierarchy3_number
													 ,ISNULL( NULLIF(mdmi.item_hierarchy4_number,''),0) item_hierarchy4_number
													 ,ISNULL( NULLIF(mdmi.item_hierarchy5_number,''),0) item_hierarchy5_number
													 ,ISNULL( NULLIF(mdmi.item_hierarchy6_number,''),0) item_hierarchy6_number
													 ,mdmi.merchandise_category_code
													 ,mdmi.occASion_code
													 ,mdmi.item_type
													 ,mdmi.ladder_id
													 ,mdmi.sub_ladder_id
													 ,mdmi.bbe_attribute_code
													 ,CAST (mdmi.ADVANTAGE_PROMOTIONS AS NVARCHAR (255)) advantage_promotions
													 ,mdmi.record_source_id LOVRecordSourceId
													 ,null ParentProductGroupId
													 ,cASt (@serveETLRunLogID AS bigint)  ETLRunLogId
													 ,mdmi.row_id PSARowKey
												FROM psa.uk_btc_mdm_article_stg mdmi 
												INNER JOIN
												Stg_Product p 
															ON p.SourceKey =  mdmi.item_code 						
												WHERE  mdmi.row_status=@row_status_psa										
												AND mdmi.asset_id=@asset_id ) pg
												UNPIVOT  
															( PGValue FOR PGCol IN (
																					pg.item_hierarchy1_number
																					,pg.item_hierarchy2_number
																					,pg.item_hierarchy3_number
																					,pg.item_hierarchy4_number
																					,pg.item_hierarchy5_number
																					,pg.item_hierarchy6_number
																					,pg.merchandise_category_code
																					,pg.occASion_code
																					,pg.item_type
																					,pg.ladder_id
																					,pg.sub_ladder_id
																					,pg.bbe_attribute_code
																					,pg.advantage_promotions)
															)	AS LOVGroupId  )
															
						INSERT  INTO  ser.ProductGroup (ProductGroupId,
																		ProductId     ,
																		LOVGroupId            ,
																		LOVProductGroupSetId  ,
																		ParentProductGroupId  ,
																		LOVRecordSourceId     ,
																		SCDStartDate          ,
																		SCDEndDate            ,
																		SCDActiveFlag         ,
																		SCDVersion            ,
																		SCDLOVRecordSourceId  ,
																		ETLRunLogId,
																		PSARowKey)
												SELECT  ISNULL(spg.ProductGroupId,(PGTemp.row_num+@max_productgroupId)) AS ProductGroupId,
														pgt.ProductId,
														pgt.LOVGroupId,
														pgt.LOVProductGroupSetId,
														pgt.ParentProductGroupId,
														pgt.LOVRecordSourceId,
														(CASE WHEN ISNULL(spg.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId   ORDER BY   pgt.ProductID,pgt.created_timestamp ASC)=1 THEN
														CONVERT (Datetime,@SCDDefaultStartDate)
														ELSE
														LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId  order by  pgt.ProductID,pgt.created_timestamp)
														END) AS SCDStartDate,	
														LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId order by   pgt.ProductID,pgt.created_timestamp) SCDEndDate,
														LEAD('N', 1, 'Y') OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY  pgt.ProductID,pgt.created_timestamp ASC) SCDActiveFlag,				
														ISNULL(spg.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY   pgt.ProductID,pgt.created_timestamp ASC) SCDVersion,
														pgt.SCDLOVRecordSourceId  ,
														pgt.ETLRunLogId,
														pgt.PSARowKey
												FROM Stg_src_ProductGroup pgt	 
												JOIN
												(SELECT ProductID, LOVProductGroupSetId,LOVRecordSourceId,ROW_NUMBER() OVER(ORDER BY ProductID,LOVProductGroupSetId,LOVRecordSourceId ASC) row_num
														FROM Stg_src_ProductGroup   GROUP BY ProductID,LOVProductGroupSetId,LOVRecordSourceId )  PGTemp
													ON pgt.ProductID=PGTemp.ProductID
													AND pgt.LOVProductGroupSetId=PGTemp.LOVProductGroupSetId
													AND pgt.LOVRecordSourceId=PGTemp.LOVRecordSourceId
												LEFT  JOIN Stg_serve_productGroup spg
													ON pgt.productid=spg.productid
													AND pgt.LOVProductGroupSetId=spg.LOVProductGroupSetId
													AND pgt.LOVRecordSourceId=spg.LOVRecordSourceId
										WHERE NOT EXISTS (SELECT 1 FROM ser.ProductGroup serpg WHERE serpg.productid=pgt.productid
																							AND serpg.LOVRecordSourceId=pgt.LOVRecordSourceId
																							AND serpg.SCDActiveFlag='Y'
																							AND serpg.LOVProductGroupSetId=pgt.LOVProductGroupSetId	
																							AND serpg.LOVGroupID=pgt.LOVGroupID
																							)
												AND NULLIF(pgt.value,'') IS NOT NULL AND pgt.LOVGroupID IS NOT NULL 
										
							
						 --Update the active flag AND end date for older version
						PRINT 'Info: ProductGroup Table -> Closing off old Records if exists';

						UPDATE ser.ProductGroup SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
								  FROM ser.ProductGroup pg 
							  JOIN 
							   ( SELECT productId,LOVProductGroupSetId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.ProductGroup t WHERE   
										t.LOVRecordSourceID=@mdm_record_sourceID AND t.SCDactiveflag='Y'  AND NOT EXISTS (SELECT 1 FROM ser.ProductGroup AS pt 
																					WHERE pt.ProductID = t.ProductID
																					AND pt.LOVProductGroupSetId=t.LOVProductGroupSetId 
																					AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
																					AND  pt.ScdVersion > t.ScdVersion))pg2
								   ON  pg.productID=pg2.productId
								   AND pg.LovRecordSourceId=pg2.LovRecordSourceId
								   AND pg.LOVProductGroupSetId=pg2.LOVProductGroupSetId						 
								   AND pg.SCDactiveflag=pg2.SCDactiveflag
								   AND pg.SCDVersion!=pg2.SCDVersion
						WHERE pg.LovRecordSourceId = @mdm_record_sourceID AND
						pg.SCDActiveFlag='Y' AND   pg.SCDEndDate= @SCDDefaultEndDate ;	
						
						PRINT 'Info: ProductGroup Table -> Closing off child records if parent becomes inactive';

						WITH Stg_Product_serveGroup AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.SCDActiveFlag,pt.LOVRecordSourceID,mdmi.created_timestamp
															  FROM ser.Product pt,psa.uk_btc_mdm_article_stg mdmi 
															  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
																	AND	mdmi.item_code=pt.SourceKey
																	AND mdmi.record_source_id=pt.LoVRecordSourceID													
																	AND mdmi.row_status=@row_status_psa															
																	AND mdmi.asset_id=@asset_id
																	AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
																				WHERE t.ProductID = pt.ProductID
																				AND t.LOVRecordSourceID=pt.LOVRecordSourceID
																				AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
																				AND t.ScdVersion > pt.ScdVersion)
																	)
							,Stg_src_ProductGroup AS (
														SELECT 
															ProductId,
															PGCol,													
															(CASE WHEN PGCol in ('item_hierarchy1_number','item_hierarchy2_number','item_hierarchy3_number','item_hierarchy4_number','item_hierarchy5_number','item_hierarchy6_number') THEN
																		(SELECT Distinct LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''+REPLACE (PGCol,'_number','')+'' AND rs.LOVRecordSourceID = @mdm_record_sourceID) 											
																  ELSE (SELECT Distinct rs.LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''+PGCol+'' AND rs.LOVRecordSourceID = @mdm_record_sourceID)  
															END) LOVProductGroupSetId,
															PGValue  value,
															SCDActiveFlag,
															LOVRecordSourceId
															FROM
															(SELECT
																  p.ProductID
																 ,p.SCDActiveFlag
																 ,ISNULL(NULLIF(mdmi.merchANDise_category_code,''),'NULL VALUE') merchANDise_category_code
																 ,ISNULL(NULLIF(mdmi.occASion_code,''),'NULL VALUE') occASion_code
																 ,ISNULL(NULLIF(mdmi.item_type,''),'NULL VALUE') item_type
																 ,ISNULL(NULLIF(mdmi.ladder_id,''),'NULL VALUE') ladder_id
																 ,ISNULL(NULLIF(mdmi.sub_ladder_id,''),'NULL VALUE') sub_ladder_id
																 ,ISNULL(NULLIF(mdmi.bbe_attribute_code,''),'NULL VALUE') bbe_attribute_code
																 ,ISNULL(CAST (NULLIF(mdmi.ADVANTAGE_PROMOTIONS,'') AS NVARCHAR (255)) ,'NULL VALUE') advantage_promotions,mdmi.record_source_id LOVRecordSourceId
																 ,null ParentProductGroupId
																 ,mdmi.row_id PSARowKey
															FROM psa.uk_btc_mdm_article_stg mdmi 
															RIGHT JOIN
															Stg_Product_serveGroup p 
																		ON p.SourceKey =  mdmi.item_code 
															AND mdmi.row_status=@row_status_psa															
															AND mdmi.asset_id=@asset_id	
															) pg
															UNPIVOT  
																		( PGValue FOR PGCol IN (
																								pg.merchANDise_category_code
																								,pg.occASion_code
																								,pg.item_type
																								,pg.ladder_id
																								,pg.sub_ladder_id
																								,pg.bbe_attribute_code
																								,pg.advantage_promotions)
																				)	AS LOVGroupIdtab 										
								WHERE (PGValue = 'NULL VALUE' OR  SCDActiveFlag='N')					
								)															
								UPDATE ser.ProductGroup SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
								FROM ser.ProductGroup pIdf 
								JOIN Stg_src_ProductGroup p
								   ON pidf.ProductID=p.ProductID
								   AND pidf.LoVRecordSourceID=p.LoVRecordSourceID						   
								   AND pidf.LOVProductGroupSetID=(CASE when p.Value='NULL VALUE' THEN p.LOVProductGroupSetID ELSe pidf.LOVProductGroupSetID END) 
								   ANd pidf.SCDACTIVEFlag='Y';	

						PRINT 'Info: ProductGroup Table  Incremental Load Completed Successfully'; 

						/* 3.Table Name  :ProductIndicator*/
						
						PRINT 'Info: ProductIndicator Table Serve Incremental Load Started';
						

						/* Stg_Product                 : Get the Product id for the DeltaRecords
						   Stg_serve_productIndicator  : Get the highest version records for the Delta
						   Stg_Src_productIndicator    : Transformed  Delta Data  

						*/

						WITH Stg_Product AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID
													  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
													  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
															AND	mdmi.item_code=pt.SourceKey
															AND pt.SCDActiveFlag='Y'
															AND mdmi.record_source_id=pt.LoVRecordSourceID
															AND mdmi.row_status=@row_status_psa													
															AND mdmi.asset_id=@asset_id 
															  )			
						,Stg_serve_productIndicator AS (SELECT t.*,pt.SourceKey
													  FROM ser.productIndicator t,Stg_Product pt 						
															WHERE t.ProductID=pt.ProductID									
															AND t.LoVRecordSourceID=pt.LoVRecordSourceID
															AND NOT EXISTS (SELECT 1 FROM ser.productIndicator  pdt 
																					 WHERE pdt.ProductID = t.ProductID
																					 AND pdt.LOVIndicatorId=t.LOVIndicatorId
																					 AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																					 AND  pdt.ScdVersion > t.ScdVersion))
						,Stg_Src_productIndicator AS  (SELECT productIndicator.ProductID , 
														   (SELECT r.LOVId FROM  ser.RefLOVSetInfo r WHERE r.LOVKey = ''+PICol+''AND 
															 LOVSetName = 'Indicator - BUK MDM Product') LOVIndicatorId
														  ,PIValue AS value,
														  productIndicator.LOVRecordSourceId,
														  productIndicator.SCDLOVRecordSourceId,
														  productIndicator.ETLRunLogId ,
														  productIndicator.PSARowKey,
														  productIndicator.created_timestamp
													FROM
														(SELECT p.ProductId,
															(CASE WHEN mdmi.OWN_BRAND_CODE='Y' THEN 1  ELSE 0 END) own_brAND_ind,
															(CASE WHEN mdmi.EXCLUSIVE_FLAG='Y' THEN 1  ELSE 0 END) exclusive_ind,
															(CASE WHEN mdmi.STAFF_DISCOUNT_FLAG ='Y' THEN 1 ELSE 0 END) staff_discount_ind,
															(CASE WHEN mdmi.ADVANTAGE_PROMOTIONS IN ('R','N') THEN 1 ELSE 0 END) earn_points_ind,
															(CASE WHEN mdmi.ADVANTAGE_PROMOTIONS IN ('R') THEN 1 ELSE 0 END) redeem_points_ind,
															(CASE WHEN mdmi.GWP_FLAG ='Y' THEN 1 ELSE 0 END) gift_with_purchASe_ind,
															mdmi.record_source_Id LOVRecordSourceId,
															@SCDLOVRecordSourceId SCDLOVRecordSourceId,
															@serveETLRunLogID ETLRunLogId,
															mdmi.row_id PSARowKey,
															mdmi.created_timestamp
														FROM psa.[uk_btc_mdm_article_stg] mdmi,
															 Stg_Product p
														WHERE mdmi.item_code=p.SourceKey
															AND	p.LOVRecordSourceID = mdmi.record_source_id
															AND mdmi.row_status=@row_status_psa													
															AND mdmi.asset_id=@asset_id													
															 ) t
														UNPIVOT
															(PIValue FOR PICol in  (  own_brAND_ind,
																					  exclusive_ind,
																					  staff_discount_ind,
																					  earn_points_ind,
																					  redeem_points_ind,
																					  gift_with_purchASe_ind)
															) AS  productIndicator  )
						INSERT INTO ser.ProductIndicator(
																				ProductId           ,
																				LOVIndicatorId      ,
																				Value               ,
																				LOVRecordSourceId,
																				SCDStartDate        ,
																				SCDEndDate          ,
																				SCDActiveFlag       ,
																				SCDVersion          ,
																				SCDLOVRecordSourceId,
																				ETLRunLogId ,
																				PSARowKey)
								   SELECT pindTemp.ProductID,
										pindTemp.LOVIndicatorId,
										pindTemp.value ,
										pindTemp.LOVRecordSourceId,	
										(CASE WHEN ISNULL(pind.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId ORDER BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId,pindTemp.created_timestamp ASC) =1 THEN
											   CONVERT (Datetime,@SCDDefaultStartDate)
										ELSE
										LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId order by  pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId,pindTemp.created_timestamp)
										END) AS SCDStartDate,
										LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId order by  pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId,pindTemp.created_timestamp) SCDEndDate,
										LEAD('N', 1, 'Y') OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId ORDER BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId,pindTemp.created_timestamp ASC) SCDActiveFlag,				
										ISNULL(pind.SCDVersion,0)+ ROW_NUMBER() OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId ORDER BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId,pindTemp.created_timestamp ASC) SCDVersion,
										pindTemp.SCDLOVRecordSourceId,
										pindTemp.ETLRunLogId,	
										pindTemp.PSARowKey
										FROM Stg_Src_productIndicator pindTemp
										LEFT JOIN  Stg_serve_productIndicator pind
															ON pindTemp.productid=pind.productid
															AND pindTemp.LOVIndicatorId=pind.LOVIndicatorId
															AND pindTemp.LOVRecordSourceId=pind.LOVRecordSourceId
														WHERE NOT EXISTS (SELECT 1 FROM ser.productIndicator serpInd WHERE serpInd.productid=pindTemp.productid
																				AND serpInd.LOVRecordSourceId=pindTemp.LOVRecordSourceId
																				AND serpInd.SCDActiveFlag='Y'
																				AND serpInd.LOVIndicatorId=pindTemp.LOVIndicatorId
																				AND CAST (serpInd.value AS VARCHAR)=CAST (pindTemp.value AS VARCHAR)
																				);
						--Update the active flag AND end date for older version
						PRINT 'Info: ProductIndicator Table -> Closing off old Records if exists';
						
						UPDATE ser.ProductIndicator SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductIndicator pind 
						JOIN 
						(SELECT productId,SCDactiveflag,LOVIndicatorID,SCDVersion,LovRecordSourceId FROM ser.productIndicator t
									WHERE t.LOVRecordSourceID=@mdm_record_sourceID AND t.SCDactiveflag='Y'
									AND NOT EXISTS (SELECT 1 FROM  ser.productIndicator pt WHERE pt.ProductID = t.ProductID
																								AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																								AND pt.LOVIndicatorID=t.LOVIndicatorID																
																								AND pt.ScdVersion > t.ScdVersion) )pind2
							ON  pind.productID=pind2.productId
							AND pind.LovRecordSourceId=pind2.LovRecordSourceId
							AND pind.LOVIndicatorID=pind2.LOVIndicatorID
							AND pind.SCDactiveflag=pind2.SCDactiveflag
							AND pind.SCDVersion!=pind2.SCDVersion
						WHERE pind.LovRecordSourceId=@mdm_record_sourceID aND
						pind.SCDActiveFlag='Y' AND   pind.SCDEndDate =@SCDDefaultEndDate ;
							
						PRINT 'Info: ProductIndicator Table -> Closing off child records if parent becomes inactive';
						
						WITH Stg_Product AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.row_id,mdmi.created_timestamp
												FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
												WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
														AND	mdmi.item_code=pt.SourceKey
														AND mdmi.record_source_id=pt.LoVRecordSourceID													
														AND mdmi.row_status=@row_status_psa
														AND mdmi.asset_id=@asset_id
														AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
																	WHERE t.ProductID = pt.ProductID
																	AND t.LOVRecordSourceID=pt.LOVRecordSourceID
																	AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
																	AND t.ScdVersion > pt.ScdVersion)
														AND   pt.SCDActiveFlag='N')									
						UPDATE ser.ProductIndicator SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductIndicator pIdf 
						JOIN Stg_Product p
							ON pidf.ProductID=p.ProductID
							AND pidf.LoVRecordSourceID=p.LoVRecordSourceID
							AND pIdf.SCDActiveFlag='Y';
						
						PRINT 'Info: ProductIndicator  Table Incremental Load Completed Successfully'; 

						/* 4.Table Name  :ProductIdentifier	*/		
						
						PRINT 'Info: ProductIdentifier Table Serve Incremental Load Started';
						
						/* Stg_Product_srcIdentifier    : Get the Product id for the DeltaRecords
						   Stg_serve_ProductIdentifier  : Get the highest version records for the Delta
						*/
						
						
						WITH Stg_Product_srcIdentifier AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.ean_code,mdmi.row_id,mdmi.created_timestamp
													  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
													  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
															AND mdmi.item_code=pt.SourceKey
															AND pt.SCDActiveFlag='Y'
															AND mdmi.record_source_id=pt.LoVRecordSourceID
															AND mdmi.row_status=@row_status_psa
															AND mdmi.asset_id=@asset_id)
						,Stg_serve_ProductIdentifier AS(SELECT productId,LOVIdentifierId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.ProductIdentifier t WHERE   
													 t.LOVRecordSourceID=@mdm_record_sourceID
													 AND NOT EXISTS (SELECT 1 FROM ser.ProductIdentifier AS pt 
																				WHERE pt.ProductID = t.ProductID
																				AND pt.LOVIdentifierId=t.LOVIdentifierId 
																				AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
																				AND  pt.ScdVersion > t.ScdVersion)) 
						INSERT INTO ser.ProductIdentifier(
																			ProductId           ,
																			LOVIdentifierId     ,
																			Value               ,
																			LOVRecordSourceId   ,
																			SCDStartDate        ,
																			SCDEndDate          ,
																			SCDActiveFlag       ,     
																			SCDVersion          ,
																			SCDLOVRecordSourceId,
																			ETLRunLogId,
																			PSARowKey)
									SELECT
										p.ProductId  ProductId,					
										rs.LOVID LOVIdentifierId ,
										p.ean_code AS Value,
										@mdm_record_sourceID  LOVRecordSourceId,
										(CASE WHEN ISNULL(pIdf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,rs.LOVID ORDER BY  p.ProductID,p.created_timestamp ASC)=1 THEN
										   CONVERT (Datetime,@SCDDefaultStartDate)
											ELSE
										LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,rs.LOVID  order by p.ProductID,p.created_timestamp)
										END) AS SCDStartDate,	
										LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,rs.LOVID order by p.ProductID,p.created_timestamp) SCDEndDate,
										LEAD('N', 1, 'Y') OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,rs.LOVID ORDER BY  p.ProductID,p.created_timestamp ASC) SCDActiveFlag,				
										ISNULL(pIdf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,rs.LOVID ORDER BY  p.ProductID,p.created_timestamp ASC) SCDVersion,
										@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
										@serveETLRunLogID ETLRunLogId,
										p.row_id PSARowKey
										FROM Stg_Product_srcIdentifier p
										JOIN   ser.RefLOVSetInfo rs
											   ON  rs.LOVKey = 'EAN'
											   AND rs.LOVSetName = 'Identifier'
										LEFT JOIN Stg_serve_ProductIdentifier pIdf ON p.ProductId=pIdf.ProductId 
																				AND p.LovRecordSourceID=pIdf.LovRecordSourceID
										WHERE p.ean_code IS NOT NULL AND p.ean_code !='' 				
											AND NOT EXISTS (SELECT 1 FROM ser.ProductIdentifier serpId WHERE serpId.productid=pIdf.productid
															AND serpId.LOVRecordSourceId=pIdf.LOVRecordSourceId
															AND serpId.SCDActiveFlag='Y'														
															AND serpId.LOVIdentifierId=rs.LOVID
															AND serpId.value=p.ean_code );


							--Update the active flag AND end date for older version
							PRINT 'Info: ProductIdentifier Table -> Closing off old Records if exists';
							
							UPDATE ser.ProductIdentifier SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
							FROM ser.ProductIdentifier pIdf 
							JOIN ( SELECT productId,LOVIdentifierId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.ProductIdentifier t WHERE   
										t.LOVRecordSourceID=@mdm_record_sourceID AND t.SCDactiveflag='Y'  AND NOT EXISTS (SELECT 1 FROM ser.ProductIdentifier AS pt 
																					WHERE pt.ProductID = t.ProductID
																					AND pt.LOVIdentifierId=t.LOVIdentifierId 
																					AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
																					AND  pt.ScdVersion > t.ScdVersion))pIdf2
										   ON  pIdf.productID=pIdf2.productId
										   AND pIdf.LovRecordSourceId=pIdf2.LovRecordSourceId
										   AND pIdf.LOVIdentifierId=pIdf2.LOVIdentifierId
										   AND pIdf.SCDactiveflag=pIdf2.SCDactiveflag
										   AND pIdf.SCDVersion!=pIdf2.SCDVersion
							WHERE pIdf.LovRecordSourceId=@mdm_record_sourceID aND
								pIdf.SCDActiveFlag='Y' AND   pIdf.SCDEndDate =@SCDDefaultEndDate; 								
							
							PRINT 'Info: ProductIdentifier Table -> Closing off child records if parent becomes inactive';
								
							WITH Stg_Product_srcIdentifier AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.ean_code,mdmi.row_id,mdmi.created_timestamp
														  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
														  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
																AND	mdmi.item_code=pt.SourceKey
																AND mdmi.record_source_id=pt.LoVRecordSourceID													
																AND mdmi.row_status=@row_status_psa
																AND mdmi.asset_id=@asset_id
																AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
																			WHERE t.ProductID = pt.ProductID
																			AND t.LOVRecordSourceID=pt.LOVRecordSourceID
																			AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
																			AND t.ScdVersion > pt.ScdVersion)
																AND  (NULLIF( mdmi.ean_code,'' ) IS NULL OR pt.SCDActiveFlag='N'))									
							UPDATE ser.ProductIdentifier SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
							FROM ser.ProductIdentifier pIdf 
							JOIN Stg_Product_srcIdentifier p
								   ON pidf.ProductID=p.ProductID
								   AND pidf.LoVRecordSourceID=p.LoVRecordSourceID
								   AND pIdf.SCDActiveFlag='Y';

						PRINT 'Info: ProductIdentifier Table Incremental Load Completed Successfully';
				 
					   
						/*5.Table Name: ProductStatus*/

						PRINT 'Info: ProductStatus Table Serve Incremental Load Started';

						
						/* Stg_Product              : Get the Product id for the DeltaRecords
						   Stg_serve_productStatus  : Get the highest version records for the Delta
						   Stg_Src_productStatus    : Transformed  Delta Data  

						*/
						
						
						WITH Stg_Product AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.created_timestamp
													  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
													  WHERE  pt.LOVSourceKeyTypeId = @LOVSourceKeyTypeId
															AND	mdmi.item_code=pt.SourceKey
															AND pt.SCDActiveFlag='Y'
															AND mdmi.record_source_id=pt.LoVRecordSourceID
															AND mdmi.row_status = @row_status_psa
															AND mdmi.asset_id=@asset_id
															  )										
						,Stg_serve_productStatus AS ( SELECT t.*,pt.SourceKey
													  FROM ser.ProductStatus t,Stg_Product pt 						
															WHERE t.ProductID=pt.ProductID	
															AND t.LOVProductStatusSetId = @LOVProductStatusSetIdRSC
															AND t.LoVRecordSourceID=pt.LoVRecordSourceID
															AND NOT EXISTS (SELECT 1 FROM ser.ProductStatus  pdt 
																					 WHERE pdt.ProductID = t.ProductID
																					 --AND CASE WHEN t.LOVProductStatusSetId = @LOVProductStatusSetId AND pdt.LOVStatusId=t.LOVStatusId THEN 1 ELSE 0 END = 1
																					 --AND pdt.LOVStatusId=t.LOVStatusId
																					 AND pdt.LOVProductStatusSetId=t.LOVProductStatusSetId
																					 AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																					 AND  pdt.ScdVersion > t.ScdVersion)
														UNION ALL
														SELECT t.*,pt.SourceKey
																					  FROM ser.ProductStatus t,Stg_Product pt 						
																							WHERE t.ProductID=pt.ProductID	
																							AND t.LOVProductStatusSetId = @LOVProductStatusSetId
																							AND t.LoVRecordSourceID=pt.LoVRecordSourceID
																							AND NOT EXISTS (SELECT 1 FROM ser.ProductStatus  pdt 
																													 WHERE pdt.ProductID = t.ProductID
																													 AND pdt.LOVStatusId=t.LOVStatusId
																													 AND pdt.LOVProductStatusSetId=t.LOVProductStatusSetId
																													 AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																													 AND  pdt.ScdVersion > t.ScdVersion)
														)	
						,Stg_Src_productStatus AS  (	SELECT ProductId,
															(CASE   WHEN PSCol ='status_from_date_val' AND NULLIF(retail_status,'' ) IS NOT NULL THEN LOVStatusId
																	WHEN PSCol ='item_introduction_date_val' THEN LovStatusIDI
																	WHEN PSCol ='item_deletion_date_val' THEN LovStatusIDD
																	ELSE NULL
															  END )  LOVStatusId,
															  (CASE   WHEN PSCol ='status_from_date_val' THEN @LOVProductStatusSetIdRSC
																	  WHEN PSCol ='item_introduction_date_val' THEN @LOVProductStatusSetId
																	  WHEN PSCol ='item_deletion_date_val' THEN @LOVProductStatusSetId
															  END )  LOVProductStatusSetId,
															PSValue EffectiveFrom,
															NULL EffectiveTo,
															LOVRecordSourceId,        
															@SCDLOVRecordSourceId SCDLOVRecordSourceId,
															ETLRunLogId,
															PSARowKey,
															created_timestamp
														FROM
															(SELECT p.ProductId,
																	rs.LovID  LOVStatusId,
																	mdmi.retail_status,
																	@LovStatusIDD LovStatusIDD,
																	@LovStatusIDI  LovStatusIDI,
																	(CASE WHEN NULLIF(mdmi.valid_FROM_date,'')IS NULL  AND NULLIF(mdmi.valid_FROM_time,'')IS NULL   THEN  '1800-01-01'
																	      WHEN NULLIF(mdmi.valid_FROM_date,'')IS NULL  AND NULLIF(mdmi.valid_FROM_time,'')IS NOT NULL   THEN  
																		               TRY_CAST(CONCAT(SUBSTRING( mdmi.valid_FROM_time,1,2),
																						':',SUBSTRING(mdmi.valid_FROM_time,3,2),
																						':',SUBSTRING(mdmi.valid_FROM_time,5,2))AS DATETIME) 
																		  WHEN NULLIF(mdmi.valid_FROM_date,'')IS NOT NULL  AND NULLIF(mdmi.valid_FROM_time,'')IS  NULL   THEN 
																						TRY_CAST(SUBSTRING(mdmi.valid_FROM_date,5,4) +
																						SUBSTRING(mdmi.valid_FROM_date,3,2) +
																						SUBSTRING(mdmi.valid_FROM_date,1,2) AS DATETIME)
																		  --WHEN ISDATE(NULLIF(mdmi.valid_FROM_date,''))=0 AND ISDATE(NULLIF(mdmi.valid_FROM_time,''))=0 THEN 
																				ELSE TRY_CAST(CONCAT(SUBSTRING(mdmi.valid_FROM_date,5,4) +
																						SUBSTRING(mdmi.valid_FROM_date,3,2) +
																						SUBSTRING(mdmi.valid_FROM_date,1,2) ,
																						' ',CONCAT(SUBSTRING( mdmi.valid_FROM_time,1,2),
																						':',SUBSTRING(mdmi.valid_FROM_time,3,2),
																						':',SUBSTRING(mdmi.valid_FROM_time,5,2)) )AS DATETIME)
																		  --ELSE CONCAT(mdmi.valid_FROM_date,' ', mdmi.valid_FROM_time) 
																																	END) status_from_date_val,
																	(CASE WHEN  NULLIF(mdmi.item_introduction_date,'')IS NULL  THEN NULL   
																		  WHEN ISDATE(NULLIF(mdmi.item_introduction_date,'')) =0 THEN 
																				TRY_CAST(SUBSTRING(mdmi.item_introduction_date,5,4) + 
																						 SUBSTRING(mdmi.item_introduction_date,3,2) + 
																						 SUBSTRING(mdmi.item_introduction_date,1,2)AS DATETIME)
																		  ELSE CAST(NULLIF(mdmi.item_introduction_date,'') AS NVARCHAR(50)) END) item_introduction_date_val,															
																	(CASE WHEN  NULLIF(mdmi.item_introduction_date,'')IS NULL  THEN NULL
																		  WHEN ISDATE(NULLIF(item_introduction_date,'')) =0 THEN 
																				TRY_CAST(SUBSTRING(mdmi.item_deletion_date,5,4) + 
																						 SUBSTRING(mdmi.item_deletion_date,3,2) +
																						 SUBSTRING(mdmi.item_deletion_date,1,2)AS DATETIME)
																		  ELSE CAST (NULLIF(mdmi.item_deletion_date,'') AS NVARCHAR(50)) END) item_deletion_date_val,
																	mdmi.record_source_Id  LOVRecordSourceId,
																	@serveETLRunLogID ETLRunLogId,
																	mdmi.row_id PSARowKey,
																	mdmi.created_timestamp
															FROM [psa].[uk_btc_mdm_article_stg] mdmi 	
															INNER JOIN Stg_Product p
																				ON p.SourceKey = mdmi.item_code AND
																					p.LovRecordSourceID = mdmi.record_source_id																			
															LEFT JOIN ser.RefLOVSetInfo rs
																			   ON  rs.LOVKey = mdmi.retail_status
																			   AND rs.LOVRecordSourceID = mdmi.record_source_id
																			   AND rs.LOVSetName = 'retail_status_code'
																			   WHERE  mdmi.row_status=@row_status_psa
																					   AND mdmi.asset_id=@asset_id) ps
																				UNPIVOT  
															( PSValue FOR PSCol IN (status_from_date_val,
																					item_introduction_date_val,
																					item_deletion_date_val)
															)	AS PSl 
															
												)
						INSERT INTO ser.ProductStatus (
														ProductId,           
														LOVStatusId,
														LOVProductStatusSetId,
														EffectiveFrom,        
														EffectiveTo, 
														LOVRecordSourceId,
														SCDStartDate,         
														SCDEndDate,           
														SCDActiveFlag,        
														SCDVersion,           
														SCDLOVRecordSourceId, 
														ETLRunLogId,    
														PSARowKey) 
														/*1.Handling Status Type Logic */
													SELECT  psTemp.ProductId,
															psTemp.LOVStatusId,
															psTemp.LOVProductStatusSetId,															
															psTemp.EffectiveFrom ,
															psTemp.EffectiveTo,
															psTemp.LOVRecordSourceId,
															(CASE WHEN ISNULL(ps.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY psTemp.ProductId,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId ORDER BY  psTemp.ProductID,psTemp.created_timestamp ASC)=1 THEN
																CONVERT (Datetime,@SCDDefaultStartDate)
															ELSE
																LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY psTemp.ProductId,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId  order by psTemp.ProductID,psTemp.created_timestamp)
															END) AS SCDStartDate,	
															LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY psTemp.ProductId,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId order by psTemp.ProductID,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId,psTemp.created_timestamp) SCDEndDate,
															LEAD('N', 1, 'Y') OVER(PARTITION BY psTemp.ProductId,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId  ORDER BY psTemp.ProductId,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId,psTemp.created_timestamp ASC) SCDActiveFlag,				
															ISNULL(ps.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY psTemp.ProductId,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId  ORDER BY psTemp.ProductId,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId,psTemp.created_timestamp ASC) SCDVersion,
															psTemp.SCDLOVRecordSourceId,
															psTemp.ETLRunLogId,
															psTemp.PSARowKey
															FROM Stg_Src_productStatus psTemp
															LEFT JOIN Stg_serve_productStatus ps
																		ON psTemp.productid=ps.productid
																		AND psTemp.LOVStatusId=ps.LOVStatusId
																		AND psTemp.LOVProductStatusSetId=ps.LOVProductStatusSetId								
																		AND psTemp.LOVRecordSourceId=ps.LOVRecordSourceId	
															WHERE psTemp.LOVProductStatusSetId = @LOVProductStatusSetId
																AND psTemp.LOVStatusId IS NOT NULL													   
																AND NOT EXISTS ( SELECT 1 FROM ser.ProductStatus serpId WHERE psTemp.productid=serpId.productid
																AND psTemp.LOVRecordSourceId=serpId.LOVRecordSourceId
																AND serpId.SCDActiveFlag='Y'														
																AND psTemp.LOVStatusId=serpId.LOVStatusId
																AND psTemp.LOVProductStatusSetId=serpId.LOVProductStatusSetId
																AND psTemp.EffectiveFrom=serpId.EffectiveFrom
																 )
																 
													UNION ALL
													/*2. Handling Retail Status SCD Logic */
													SELECT  psTemp.ProductId,
															psTemp.LOVStatusId,
															psTemp.LOVProductStatusSetId,
															(CASE WHEN psTemp.EffectiveFrom ='1800-01-01' THEN NULL ELSE  psTemp.EffectiveFrom END) EffectiveFrom,
															--psTemp.EffectiveFrom,
															psTemp.EffectiveTo,
															psTemp.LOVRecordSourceId,
															(CASE WHEN ISNULL(ps.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY psTemp.ProductId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId ORDER BY  psTemp.ProductID,psTemp.created_timestamp ASC)=1 THEN
																CONVERT (Datetime,@SCDDefaultStartDate)
															ELSE
																LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY psTemp.ProductId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId  order by psTemp.ProductID,psTemp.created_timestamp)
															END) AS SCDStartDate,	
															LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY psTemp.ProductId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId order by psTemp.ProductID,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId,psTemp.created_timestamp) SCDEndDate,
															LEAD('N', 1, 'Y') OVER(PARTITION BY psTemp.ProductId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId  ORDER BY psTemp.ProductId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId,psTemp.created_timestamp ASC) SCDActiveFlag,				
															ISNULL(ps.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY psTemp.ProductId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId  ORDER BY psTemp.ProductId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId,psTemp.created_timestamp ASC) SCDVersion,
															psTemp.SCDLOVRecordSourceId,
															psTemp.ETLRunLogId,
															psTemp.PSARowKey
															FROM Stg_Src_productStatus psTemp
															LEFT JOIN Stg_serve_productStatus ps
																		ON psTemp.productid=ps.productid
																		AND psTemp.LOVProductStatusSetId=ps.LOVProductStatusSetId								
																		AND psTemp.LOVRecordSourceId=ps.LOVRecordSourceId	
															WHERE psTemp.LOVProductStatusSetId = @LOVProductStatusSetIdRSC
																AND psTemp.LOVStatusId IS NOT NULL
																AND NOT EXISTS ( SELECT 1 FROM ser.ProductStatus serpId WHERE psTemp.productid=serpId.productid
																AND psTemp.LOVRecordSourceId=serpId.LOVRecordSourceId
																AND serpId.SCDActiveFlag='Y'														
																AND psTemp.LOVStatusId=serpId.LOVStatusId
																AND psTemp.LOVProductStatusSetId=serpId.LOVProductStatusSetId
																AND psTemp.EffectiveFrom=serpId.EffectiveFrom
																 )
						--Update the active flag AND end date for older version
						
						PRINT 'Info: ProductStatus Table -> Closing off old Records if exists';
							/*1.Handling Status Type Logic */
						UPDATE ser.ProductStatus SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
									FROM ser.ProductStatus ps 
									JOIN ( SELECT productId,LOVProductStatusSetId,LOVStatusId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.ProductStatus t WHERE   
									t.LOVRecordSourceID=@mdm_record_sourceID AND t.SCDactiveflag='Y'  AND NOT EXISTS (SELECT 1 FROM ser.ProductStatus AS pt 
																	WHERE pt.ProductID = t.ProductID
																	AND pt.LOVProductStatusSetId=t.LOVProductStatusSetId 
																	AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																	AND pt.LOVStatusId=t.LOVStatusId
																	AND  pt.ScdVersion > t.ScdVersion))ps2
								   ON  ps.productID=ps2.productId
								   AND ps.LovRecordSourceId=ps2.LovRecordSourceId
								   AND ps.LOVProductStatusSetId=ps2.LOVProductStatusSetId
								   AND ps.LOVStatusId=ps2.LOVStatusId
								   AND ps.SCDactiveflag=ps2.SCDactiveflag
								   AND ps.SCDVersion!=ps2.SCDVersion
						WHERE ps.LovRecordSourceId=@mdm_record_sourceID AND ps.LOVProductStatusSetId = @LOVProductStatusSetId
						AND ps.SCDActiveFlag='Y' AND   ps.SCDEndDate =@SCDDefaultEndDate 

							/*2. Handling Retail Status SCD Logic */
						UPDATE ser.ProductStatus SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
									FROM ser.ProductStatus ps 
									JOIN ( SELECT productId,LOVProductStatusSetId,LOVStatusId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.ProductStatus t WHERE   
									t.LOVRecordSourceID=@mdm_record_sourceID AND t.SCDactiveflag='Y'  AND NOT EXISTS (SELECT 1 FROM ser.ProductStatus AS pt 
																	WHERE pt.ProductID = t.ProductID
																	AND pt.LOVProductStatusSetId=t.LOVProductStatusSetId 
																	AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																	AND  pt.ScdVersion > t.ScdVersion))ps2
								   ON  ps.productID=ps2.productId
								   AND ps.LovRecordSourceId=ps2.LovRecordSourceId
								   AND ps.LOVProductStatusSetId=ps2.LOVProductStatusSetId								
								   AND ps.SCDactiveflag=ps2.SCDactiveflag
								   AND ps.SCDVersion!=ps2.SCDVersion
						WHERE ps.LovRecordSourceId=@mdm_record_sourceID AND ps.LOVProductStatusSetId = @LOVProductStatusSetIdRSC
						AND ps.SCDActiveFlag='Y' AND   ps.SCDEndDate =@SCDDefaultEndDate;
						
						PRINT 'Info: ProductStatus Table -> Closing off child records if parent becomes inactive';
						/*1.Handling  Retail Status Logic */
						WITH stg_src_ProductStatus AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.retail_status																
								  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
								  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
										AND	mdmi.item_code=pt.SourceKey
										AND mdmi.record_source_id=pt.LoVRecordSourceID													
										AND mdmi.row_status=@row_status_psa
										AND mdmi.asset_id=@asset_id
										AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
													WHERE t.ProductID = pt.ProductID
													AND t.LOVRecordSourceID=pt.LOVRecordSourceID
													AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
													AND t.ScdVersion > pt.ScdVersion)
										AND  (NULLIF( mdmi.retail_status ,'' ) IS NULL OR pt.SCDActiveFlag='N'))									
						UPDATE ser.ProductStatus SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductStatus ps 
						JOIN stg_src_ProductStatus sps
						   ON ps.ProductID=sps.ProductID
						   AND ps.LoVRecordSourceID=sps.LoVRecordSourceID
						   AND ps.LOVProductStatusSetID = @LOVProductStatusSetIdRSC
						   AND ps.SCDActiveFlag='Y';
                        
						/*1.Handling Status Type Logic */
						WITH stg_src_ProductStatus AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.item_introduction_date
								  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
								  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
										AND	mdmi.item_code=pt.SourceKey
										AND mdmi.record_source_id=pt.LoVRecordSourceID													
										AND mdmi.row_status=@row_status_psa
										AND mdmi.asset_id=@asset_id
										AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
													WHERE t.ProductID = pt.ProductID
													AND t.LOVRecordSourceID=pt.LOVRecordSourceID
													AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
													AND t.ScdVersion > pt.ScdVersion)
										AND  (NULLIF( mdmi.item_introduction_date ,'' ) IS NULL OR pt.SCDActiveFlag='N'))									
						UPDATE ser.ProductStatus SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductStatus ps 
						JOIN stg_src_ProductStatus sps
						   ON ps.ProductID=sps.ProductID
						   AND ps.LoVRecordSourceID=sps.LoVRecordSourceID
						   AND ps.LOVProductStatusSetID = @LOVProductStatusSetId
						   AND ps.LOVStatusID = @LOVStatusIDI
						   AND ps.SCDActiveFlag='Y';

						WITH stg_src_ProductStatus AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.item_deletion_date
								  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
								  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
										AND	mdmi.item_code=pt.SourceKey
										AND mdmi.record_source_id=pt.LoVRecordSourceID													
										AND mdmi.row_status=@row_status_psa
										AND mdmi.asset_id=@asset_id
										AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
													WHERE t.ProductID = pt.ProductID
													AND t.LOVRecordSourceID=pt.LOVRecordSourceID
													AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
													AND t.ScdVersion > pt.ScdVersion)
										AND  (NULLIF( mdmi.item_deletion_date ,'' ) IS NULL OR pt.SCDActiveFlag='N'))									
						UPDATE ser.ProductStatus SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductStatus ps 
						JOIN stg_src_ProductStatus sps
						   ON ps.ProductID=sps.ProductID
						   AND ps.LoVRecordSourceID=sps.LoVRecordSourceID
						   AND ps.LOVProductStatusSetID = @LOVProductStatusSetId
						   AND ps.LOVStatusID = @LOVStatusIDD
						   AND ps.SCDActiveFlag='Y';
							
						PRINT 'Info: ProductStatus Table Loaded Successfully';

						/* 6.Table Name : Party*/  
						PRINT 'Info: Party Table Serve Incremental Load Started';  

						INSERT INTO ser.Party(
							PartyId            ,
							LOVPartyTypeId     ,
							SourceKey          ,
							LOVRecordSourceId  ,
							SCDStartDate        ,
							SCDEndDate          ,
							SCDActiveFlag       ,
							SCDVersion          ,
							SCDLOVRecordSourceId,
							ETLRunLogId,
							PSARowKey)
						
						SELECT  ROW_NUMBER() OVER(ORDER BY SourceKey,LOVRecordSourceId ASC)+@max_PartyId PartyId,
								LOVPartyTypeId, 
								SourceKey,
								LOVRecordSourceId,
								@SCDDefaultStartDate AS SCDStartDate,
								@SCDDefaultEndDate SCDEndDate,
								@SCDActiveFlag     SCDActiveFlag ,
								@SCDVersion  SCDVersion ,
								@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
								ETLRunLogId,
								PSARowKey
							FROM
							(
							SELECT DISTINCT
									@PartyType_Id LOVPartyTypeId,
									mdmi.vendor_number  AS SourceKey,
									mdmi.record_source_id AS LOVRecordSourceId,
									@serveETLRunLogID  AS ETLRunLogId,
									Min(mdmi.row_id) PSARowKey
							FROM psa.[uk_btc_mdm_article_stg] mdmi
								WHERE mdmi.row_status=@row_status_psa AND mdmi.vendor_number IS NOT NULL AND mdmi.vendor_number!=''
								AND mdmi.asset_id=@asset_id
								GROUP BY mdmi.vendor_number,mdmi.record_source_id)  party                        
							WHERE NOT EXISTS  (SELECT 1 FROM ser.party pr WHERE pr.SourceKey =party.SourceKey AND party.LOVRecordSourceId =pr.LOVRecordSourceId  )
			
			
						PRINT 'Info: Party Table  Incremental Load Completed Successfully' ; 
								
						 /*7.Table Name: Organization*/ 

						PRINT 'Info: Organisation Table Serve Incremental Load Started';					
						
						INSERT INTO ser.Organisation(
													PartyId            ,
													SourceOrganisationKey  ,
													OrganisationName    ,
													ParentPartyId       ,
													LOVRecordSourceId	,
													SCDStartDate        ,
													SCDEndDate          ,
													SCDActiveFlag       ,
													SCDVersion          ,
													SCDLOVRecordSourceId,
													ETLRunLogId,
													PSARowKey)
						SELECT  
							PartyId                ,
							SourceOrganisationKey  ,
							OrganisationName       ,
							ParentPartyId,
							LOVRecordSourceId,
							@SCDDefaultStartDate SCDStartDate,
							@SCDDefaultEndDate SCDEndDate,
							@SCDActiveFlag    SCDActiveFlag      ,
							@SCDVersion   SCDVersion          ,
							@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
							ETLRunLogId,
							PSARowKey
						FROM 
						(SELECT DISTINCT
									pt.PartyId AS  PartyId,
									mdmi.vendor_number  AS SourceOrganisationKey,
									null OrganisationName,
									null ParentPartyId,
									mdmi.record_source_Id  LOVRecordSourceId,
									@serveETLRunLogID ETLRunLogId,
									MIN(mdmi.row_id) PSARowKey
							FROM psa.[uk_btc_mdm_article_stg] mdmi  
									JOIN  ser.Party pt  ON pt.sourcekey= mdmi.vendor_number AND
														pt.LOVRecordSourceID=mdmi.record_source_id
														AND pt.SCDActiveFlag='Y'
							WHERE mdmi.row_status=@row_status_psa AND 	mdmi.vendor_number IS NOT NULL AND mdmi.vendor_number!=''
							AND mdmi.asset_id=@asset_id
							GROUP BY mdmi.vendor_number,mdmi.record_source_Id,pt.PartyId
							)  org
							WHERE  NOT EXISTS(SELECT 1 FROM ser.Organisation o WHERE o.SourceOrganisationKey =org.SourceOrganisationKey AND o.LOVRecordSourceId =org.LOVRecordSourceId );
							
						PRINT 'Info: Organisation Table  Incremental Load Completed Successfully'; 
						
						/*8.Table Name: PartyRole*/ 
						
						PRINT 'Info: PartyRole Table Serve Incremental Load Started'; 
						
						INSERT INTO ser.PartyRole(
													PartyRoleId          ,
													LOVRoleId            ,
													PartyId             ,
													SourceKey            ,
													PartyRoleName        ,
													LOVRecordSourceId    ,
													SCDStartDate        ,
													SCDEndDate          ,
													SCDActiveFlag       ,
													SCDVersion          ,
													SCDLOVRecordSourceId,
													ETLRunLogId ,
													PSARowKey) 
							SELECT ROW_NUMBER() OVER(ORDER BY  PartyId,LOVRoleId ASC)+@max_partyrole_id PartyRoleId,
							LOVRoleId,
							PartyId,
							SourceKey,
							PartyRoleName,
							LOVRecordSourceId,
							@SCDDefaultStartDate SCDStartDate,
							@SCDDefaultEndDate SCDEndDate,
							@SCDActiveFlag     SCDActiveFlag      ,
							@SCDVersion   SCDVersion          ,
							@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
							ETLRunLogId,
							PSARowKey
						FROM 
							(
							SELECT DISTINCT
							@LOVRoleIDS LOVRoleId,
							pt.PartyId  PartyId,
							mdmi.vendor_number  AS SourceKey,
							null PartyRoleName,
							mdmi.Record_Source_id LOVREcordSourceID,
							@serveETLRunLogID ETLRunLogId,
							Min(mdmi.row_id) PSARowKey
							FROM psa.[uk_btc_mdm_article_stg] mdmi
									LEFT JOIN  ser.Party pt ON mdmi.vendor_number = pt.SourceKey								 
							AND mdmi.record_source_id =pt.LOVRecordSourceId 
							WHERE mdmi.row_status=@row_status_psa AND mdmi.vendor_number IS NOT NULL AND mdmi.vendor_number!=''
							AND mdmi.asset_id=@asset_id
							GROUP BY mdmi.vendor_number,mdmi.record_source_Id,pt.PartyId) t
							WHERE NOT EXISTS ( SELECT 1 FROM ser.PartyRole pr WHERE pr.SourceKey =t.SourceKey AND pr.LOVRecordSourceId =t.LOVRecordSourceId )  ;
						
						
						PRINT 'Info: PartyRole Table Incremental Load Completed Successfully'; 
						 
						 
						 /*9.Table Name: ProductPartyRole*/
						
						PRINT 'Info: ProductPartyRole Table Serve Incremental Load Started for Supplier/Retailer';  

						/* Stg_src_Product              : Get the Product id for the DeltaRecords
						   stg_serve_ProductPartyRole   : Get the highest version records for the Delta
						   stg_Src_ProductPartyRole     : Transformed  Delta Data  

						*/										
						

						WITH Stg_src_Product AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.vendor_number,mdmi.row_id,mdmi.created_timestamp
													  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
													  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
															AND	mdmi.item_code=pt.SourceKey
															AND pt.SCDActiveFlag='Y'
															AND mdmi.record_source_id=pt.LoVRecordSourceID
															AND mdmi.row_status=@row_status_psa
															AND mdmi.asset_id=@asset_id 
															  )	
						,stg_Src_ProductPartyRole AS ( SELECT p.productid,pr.partyroleid,pr.LOVRoleId,pr.sourcekey,p.row_id,p.created_timestamp,pr.LOvRecordSourceID FROM  ser.PartyRole pr
																 JOIN Stg_src_Product p
																	 ON  pr.sourcekey=p.vendor_number
																	 AND pr.LOvRecordSourceID=p.LOvRecordSourceID AND pr.SCDActiveFlag='Y'
																 LEFT JOIN[ser].[RefLOVSetInfo] rs
																	ON pr.LOVRoleID=rs.lovID AND rs.LOVSetName  ='Role'
																	AND rs.LOVKey in ('Supplier')      
													UNION ALL
													SELECT p.productid,pr.partyroleid,pr.LOVRoleId,pr.sourcekey ,p.row_id,p.created_timestamp,pr.LOvRecordSourceID FROM  ser.PartyRole pr
																	 JOIN Stg_src_Product p
																		 ON  pr.sourcekey='WBA-UK-BTC'
																		 AND pr.LOvRecordSourceID=p.LOvRecordSourceID
																		 AND pr.SCDActiveFlag='Y'
																	 LEFT JOIN[ser].[RefLOVSetInfo] rs
																		ON pr.LOVRoleID=rs.lovID
																		AND rs.LOVSetName  ='Role'
																		AND rs.LOVKey in ('Retailer')
													
													)
					   
						,stg_serve_ProductPartyRole AS ( SELECT * FROM 
																 (SELECT t.*,pt.SourceKey,pr.LOVRoleId
																  FROM ser.ProductPartyRole t,stg_src_Product pt,ser.PartyRole pr
																  WHERE t.ProductID=pt.ProductID
																  AND t.PartyRoleId=pr.PartyRoleId	
																  AND t.LoVRecordSourceID=pr.LoVRecordSourceID
																  AND t.LoVRecordSourceID=pt.LoVRecordSourceID) a
														WHERE NOT EXISTS (SELECT * FROM (SELECT pdt.*,pr.LOVRoleId FROM ser.ProductPartyRole pdt,stg_src_Product pt,ser.PartyRole pr
																						WHERE pdt.ProductID=pt.ProductID
																							AND pdt.PartyRoleId=pr.PartyRoleId
																							AND pdt.LoVRecordSourceID=pr.LoVRecordSourceID
																							AND pdt.LoVRecordSourceID=pt.LoVRecordSourceID)b
																												 WHERE a.ProductID = b.ProductID
																												 --AND a.partyroleid=b.partyroleid
																												 AND a.LOVRoleId=b.LOVRoleId
																												 AND a.LOVRecordSourceID=b.LOVRecordSourceID
																												 AND b.ScdVersion > a.ScdVersion)
													)																			 

						INSERT INTO ser.ProductPartyRole(
													ProductId,           
													PartyRoleId,
													LOVRecordSourceId,
													SCDStartDate,        
													SCDEndDate,          
													SCDActiveFlag,       
													SCDVersion,          
													SCDLOVRecordSourceId,
													ETLRunLogId,
													PSARowKey)
						SELECT
							p.ProductId ProductId,
							p.PartyRoleId PartyRoleId ,
							p.LOVRecordSourceId  LOVRecordSourceId,
							(CASE WHEN ISNULL(ppr.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId ORDER BY  p.ProductID,p.created_timestamp ASC)=1 THEN
							@SCDDefaultStartDate
							ELSE
							LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId  order by p.ProductID,p.created_timestamp)
							END) AS SCDStartDate,	
							LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId order by p.ProductID,p.created_timestamp) SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId  ORDER BY p.ProductID,p.created_timestamp ASC) SCDActiveFlag,				
							ISNULL(ppr.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId ORDER BY p.ProductID,p.created_timestamp ASC) SCDVersion,
							@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
							@serveETLRunLogID ETLRunLogId,
							p.row_id PSARowKey
							FROM stg_Src_ProductPartyRole p
							LEFT JOIN stg_serve_ProductPartyRole ppr ON ppr.ProductId=p.ProductId 
															  AND ppr.LovRecordSourceID=p.LovRecordSourceID
															  AND ppr.LOVRoleId=p.LOVRoleId
							WHERE NOT EXISTS (SELECT 1 FROM ser.ProductPartyRole  pdt JOIN ser.PartyRole pr 
																					ON pdt.PartyRoleId=pr.PartyRoleId
																					AND pdt.SCDActiveFlag='Y'
																					AND pdt.SCDActiveFlag=pr.SCDActiveFlag
																				 WHERE pdt.ProductID = p.ProductID
																				 AND pdt.partyroleid=p.partyroleid
																				 AND pr.LOVRoleId=p.LOVRoleId)					

											
						 --Update the active flag AND end-date for older version

						PRINT 'Info: ProductPartyRole Table -> Closing off old Records if exists';

						UPDATE ser.ProductPartyRole SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductPartyRole ppr 
						JOIN (SELECT t.productId,t.PartyRoleId,pr.LOVRoleID,t.SCDactiveflag,t.SCDVersion,t.LovRecordSourceId FROM ser.ProductPartyRole t,ser.PartyRole pr WHERE   
									t.LovRecordSourceId=pr.LovRecordSourceId
									AND t.PartyRoleId=pr.PartyRoleId
									AND pr.LOVRoleId=@LOVRoleIDS
									AND t.LOVRecordSourceID=@mdm_record_sourceID AND t.SCDactiveflag='Y'  AND NOT EXISTS (SELECT 1 FROM ser.ProductPartyRole AS pt ,ser.PartyRole pr
																				WHERE pt.ProductID = t.ProductID
																				AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																				AND pt.PartyRoleId=pr.PartyRoleId
																				AND pr.lovroleID=pr.LOVRoleId
																				AND pt.ScdVersion > t.ScdVersion)) ppr2
										   ON  ppr.productID=ppr2.productId
										   AND ppr.LovRecordSourceId=ppr2.LovRecordSourceId									   
										   AND ppr.SCDactiveflag=ppr2.SCDactiveflag
										   AND ppr.SCDVersion!=ppr2.SCDVersion
						WHERE ppr.LovRecordSourceId=@mdm_record_sourceID AND
						ppr.SCDActiveFlag='Y' AND   ppr.SCDEndDate =@SCDDefaultEndDate 
						AND ppr.PartyRoleId not in (SELECT PartyRoleID FROM ser.PartyRole WHERE
														LOVRoleid=@LOVRoleIDR AND LovRecordSourceId=@mdm_record_sourceID );
							
						WITH stg_Src_ProductPartyRole AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.ean_code,mdmi.row_id,mdmi.created_timestamp
											  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
											  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
													AND	mdmi.item_code=pt.SourceKey
													AND mdmi.record_source_id=pt.LoVRecordSourceID													
													AND mdmi.row_status=@row_status_psa
													AND mdmi.asset_id=@asset_id
													AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
																WHERE t.ProductID = pt.ProductID
																AND t.LOVRecordSourceID=pt.LOVRecordSourceID
																AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
																AND t.ScdVersion > pt.ScdVersion)
																AND  pt.SCDActiveFlag='N')									
						UPDATE ser.ProductPartyRole SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductPartyRole pIdf 
						JOIN stg_Src_ProductPartyRole p
						   ON pidf.ProductID=p.ProductID
						   AND pidf.LoVRecordSourceID=p.LoVRecordSourceID
						   AND pidf.SCDActiveFlag='Y';

						PRINT 'Info: ProductPartyRole Table -> Closing off child records where parent becomes inactive';
						
						WITH stg_Src_ProductPartyRole AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,mdmi.ean_code,mdmi.row_id,mdmi.created_timestamp
											  FROM ser.Product pt,psa.[uk_btc_mdm_article_stg] mdmi 
											  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
													AND	mdmi.item_code=pt.SourceKey
													AND mdmi.record_source_id=pt.LoVRecordSourceID													
													AND mdmi.row_status=@row_status_psa
													AND mdmi.asset_id=@asset_id
													AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
																WHERE t.ProductID = pt.ProductID
																AND t.LOVRecordSourceID=pt.LOVRecordSourceID
																AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
																AND t.ScdVersion > pt.ScdVersion)
													AND  (NULLIF( mdmi.vendor_number ,'' ) IS NULL OR pt.SCDActiveFlag='N'))									
						UPDATE ser.ProductPartyRole SET SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductPartyRole pIdf 
						JOIN stg_Src_ProductPartyRole p
						   ON pidf.ProductID=p.ProductID
						   AND pidf.LoVRecordSourceID=p.LoVRecordSourceID					
						JOIN ser.partyRole pr
							  ON pr.partyRoleId = pidf.partyRoleId
							  AND pr.LOVRoleID = @LOVRoleIDS
							  AND pr.LoVRecordSourceID=pidf.LoVRecordSourceID
						   AND pidf.SCDActiveFlag='Y';

						PRINT 'Info: ProductPartyRole Table Incremental Load Completed Successfully'; 

						/*Update the psa layer table with row_status AS 'Loaded to Serve' once after Successful Migration*/	

						UPDATE psa.uk_btc_mdm_article SET Row_Status=@row_status_serve
						FROM psa.uk_btc_mdm_article mdmi 
						INNER JOIN
						ser.Product p 
								ON ISNULL( NULLIF((Substring(mdmi.item_code, Patindex('%[^0]%', mdmi.item_code + ' '), Len(mdmi.item_code)) ),''),0) =p.sourcekey
								AND  mdmi.record_source_id=p.LovRecordSourceID
								AND  LOVSourceKeyTypeId=@LOVSourceKeyTypeId 
						INNER JOIN
						((SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.Product WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@mdm_record_sourceID) 	
						UNION ALL (SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductStatus  WHERE SCDACTiveFlag='Y'AND LOVRecordsourceID=@mdm_record_sourceID) 									
						UNION ALL  (SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductGroup WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@mdm_record_sourceID) 									
						UNION ALL  (SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductPartyRole  WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@mdm_record_sourceID)
						UNION ALL  (SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductIdentifier  WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@mdm_record_sourceID) 									     
						UNION ALL  (SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductIndicator WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@mdm_record_sourceID)
							) temp
								ON temp.scdLovRecordSourceID =@mdm_record_sourceID    
								AND temp.productId=p.productID							
								AND temp.psarowkey=mdmi.row_id
						WHERE mdmi.Row_Status=@row_status_psa
							  AND mdmi.asset_id=@asset_id ;
					
						UPDATE psa.uk_btc_mdm_article SET Row_Status=@row_status_serve
						FROM psa.uk_btc_mdm_article mdmi 
						INNER JOIN
						ser.Product p 
							ON mdmi.record_source_id=LovRecordSourceID
							AND  ISNULL( NULLIF((Substring(mdmi.item_code, Patindex('%[^0]%', mdmi.item_code + ' '), Len(mdmi.item_code)) ),''),0) =p.sourcekey
							AND  LOVSourceKeyTypeId=@LOVSourceKeyTypeId
						WHERE mdmi.Row_Status=@row_status_psa   
							AND asset_id=@asset_id
							AND ((NULLIF(mdmi.ITEM_DESCRIPTION,'' ) IS NULL AND NULLIF( mdmi.brand_code,'' ) IS NULL AND NULLIF( mdmi.sub_brand_code,'') IS NULL) 
							 OR (NULLIF(mdmi.retail_status,'') IS NULL OR NULLIF(mdmi.item_deletion_date,'') IS NULL OR NULLIF(mdmi.item_introduction_date,'') IS NULL 
							 OR NULLIF(mdmi.ean_code,'') IS NULL  OR  NULLIF(mdmi.vendor_number,'') IS NULL
							 OR NULLIF(mdmi.merchandise_category_code,'') IS NULL OR NULLIF(mdmi.occasion_code,'') IS NULL
							 OR	NULLIF(mdmi.item_type,'') IS NULL OR NULLIF(mdmi.ladder_id,'') IS NULL OR NULLIF(mdmi.sub_ladder_id,'') IS NULL 
							 OR NULLIF(mdmi.bbe_attribute_code,'') IS NULL OR NULLIF(mdmi.ADVANTAGE_PROMOTIONS,'') IS NULL));

						UPDATE psa.uk_btc_mdm_article  SET row_status=@row_status_notmigrated						
						WHERE row_status=@row_status_psa
							  AND asset_id=@asset_id; 

						PRINT 'Info: updated Row_status in Source Table -> rawuk_btc_mdm_article';
						PRINT '********Info: MDM Product PSA to Serve Load Completed Successfully********';



						SET @COUNTER = @COUNTER + 1	;
				END
						COMMIT TRANSACTION;
						
			 END TRY
			 BEGIN CATCH     
				THROW
				ROLLBACK TRANSACTION;
			 END CATCH
			IF OBJECT_ID('tempdb..#TempCurMdmProduct') IS NOT NULL
			BEGIN
				DROP table  #TempCurMdmProduct
			END	

			IF OBJECT_ID('psa.uk_btc_mdm_article_stg') IS NOT NULL
			BEGIN
				DROP table  psa.uk_btc_mdm_article_stg
			END	
	 END
GO
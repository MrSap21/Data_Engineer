/****** Object:  StoredProcedure [psa].[sp_inc_cl_crp_product]    Script Date: 11/26/2020 5:56:13 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_cl_crp_product') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_cl_crp_product
   
END
GO

CREATE PROC [psa].[sp_inc_cl_crp_product] @tableName [varchar](max),@psaEntityId [varchar](max),@serveETLRunLogID [varchar](max) AS 
/**************************************************************************************************************************
Procedure Name					: sp_inc_cl_crp_product
Purpose							: Load Incremental data From Product International Source- Chili into Serve Layer Table
Domain							: Product
ServeLayer Target Tables		: Product,ProductStatus,ProductIndicator,ProductProperty,ProductGroup,
									Party,Organization,PartyRole,PrductPartyRole    (Total 9 Tables)
RecordSourceID  for Chili		: 12001

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :        Description
11/26/2020   :        Leading zero removal from item_code and upc columns
==========================================================================================================================


**************************************************************************************************************************/
BEGIN
	IF OBJECT_ID('psa.cl_crp_product_temp') is not null
		BEGIN
			DROP TABLE [psa].[cl_crp_product_temp]
		END
	BEGIN
		CREATE TABLE [psa].[cl_crp_product_temp]
		(
			[PSARowKey] [bigint] NOT NULL,
			[LOVSourceKeyTypeId] [int] NULL,
			[ProductID] [bigint] NULL,
			[ParentProductID] [bigint] NULL,
			[sourceKey] [nvarchar](500) NULL,
			[item_description] [nvarchar](500) NULL,
			[product_hierarchy1] [nvarchar](500) NULL,
			[product_hierarchy2] [nvarchar](500) NULL,
			[product_hierarchy3] [nvarchar](500) NULL,
			[product_hierarchy4] [nvarchar](500) NULL,
			[product_hierarchy5] [nvarchar](500) NULL,
			[product_hierarchy1_code] [nvarchar](500) NULL,
			[product_hierarchy2_code] [nvarchar](500) NULL,
			[product_hierarchy3_code] [nvarchar](500) NULL,
			[product_hierarchy4_code] [nvarchar](500) NULL,
			[product_hierarchy5_code] [nvarchar](500) NULL,
			[brand] [nvarchar](500) NULL,
			[subbrand] [nvarchar](500) NULL,
			[exclusive_flag] [nvarchar](500) NULL,
			[own_brand_flag] [nvarchar](500) NULL,
			[item_status] [nvarchar](500) NULL,
			[supplier_name] [nvarchar](500) NULL,
			[supplier_number] [nvarchar](500) NULL,
			[height] [nvarchar](500) NULL,
			[width] [nvarchar](500) NULL,
			[depth] [nvarchar](500) NULL,
			[size] [nvarchar](500) NULL,
			[date_added] [nvarchar](500) NULL,
			[etl_runlog_id] [int] NULL,
			[asset_id] [int] NULL,
			[LOVRecordSourceId] [int] NULL,
			[row_status] [int] NULL,
			[created_timestamp] [datetime] NULL
		)
		WITH
		(
			DISTRIBUTION = REPLICATE,
			CLUSTERED COLUMNSTORE INDEX
		)
	END

	DECLARE 
		@inpServeETLRunLogID		VARCHAR (max),
		@dateAdded					VARCHAR (MAX),
		@inpTableName				VARCHAR (max),
		@sourceKey                  VARCHAR (max),
		@SCDDefaultStartDate		DATETIME,
		@SCDStartDate				DATETIME,
		@SCDDefaultEndDate			DATETIME,
		@SCDEndDate					DATETIME,
		@max_productID				BIGINT,
		@itemCode_sourceKeyTypeID	BIGINT,		
		@upc_sourceKeyTypeID		BIGINT,
		@max_productTempID			BIGINT,
		@COUNTER					BIGINT,
		@MAXID						BIGINT,		
		@LOVIndicatorIdOBFlag		BIGINT,
		@uomCmId					BIGINT,
		@measureTypeId				BIGINT,
		@dataTypeId					BIGINT,
		@uomUnknownId				BIGINT,
		@party_typeID				BIGINT,
		@max_partyID				BIGINT,		
		@lovSupplierRoleId			BIGINT,
		@lovRetailerRoleId 			BIGINT,
		@maxPartyRoleId				BIGINT,
		@maxProductGroupId			BIGINT,
		@ProductGroupSetIdC1        BIGINT,
		@ProductGroupSetIdC2        BIGINT,
		@ProductGroupSetIdC3        BIGINT,
		@ProductGroupSetIdC4        BIGINT,
		@ProductGroupSetIdC5        BIGINT,
		@ProductGroupSetIdN1        BIGINT,
		@ProductGroupSetIdN2        BIGINT,
		@ProductGroupSetIdN3        BIGINT,
		@ProductGroupSetIdN4        BIGINT,
		@ProductGroupSetIdN5        BIGINT,
		@rowStatusSERCode			BIGINT,
		@rowStatusSERDuplicateCode	BIGINT,		
		@LOVIndicatorIdEXFlag		BIGINT,
		@rowStatusPSACode			BIGINT = 26001,
		@chile_lovRecordSourceID	BIGINT = 12001,
		@SCDDefaultVersion			smallint=1,
		@SCDDefaultActiveFlag		char='Y',
		@maxTempProductId			BIGINT;
		
		

	BEGIN TRANSACTION
		SET	@rowStatusSERCode				= 26002;
		SET	@rowStatusSERDuplicateCode 		= 26010;
		SET @sourceKey						= 'WBA-CL-FA';
		SET @inpTableName					= 'psa.cl_crp_product';
		SET	@inpServeETLRunLogID			= @serveETLRunLogID 
		SET @SCDDefaultStartDate			= CONVERT(DateTime,'1900-01-01')
		SET @SCDDefaultEndDate				= CONVERT(DateTime,'9999-12-31')
		SET @measureTypeId					= (SELECT rl.Lovid FROM [ser].[RefLOVSetInfo] rl WHERE rl.LOVKey = 'PROD_DIM' AND rl.LOVSetName = 'Measure Type');
		SET @dataTypeId					    = (SELECT rl.Lovid FROM [ser].[RefLOVSetInfo] rl WHERE rl.LOVKey = 'STRING' AND rl.LOVSetName = 'Data Type');
		SET @ProductGroupSetIdC1	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy1_code' and LOVRecordSourceId = @chile_lovRecordSourceID );
		SET @ProductGroupSetIdC2	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy2_code' and LOVRecordSourceId = @chile_lovRecordSourceID );		
		SET @ProductGroupSetIdC3	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy3_code' and LOVRecordSourceId = @chile_lovRecordSourceID );
		SET @ProductGroupSetIdC4	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy4_code' and LOVRecordSourceId = @chile_lovRecordSourceID );	 
		SET @ProductGroupSetIdN1	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy1_name' and LOVRecordSourceId = @chile_lovRecordSourceID);
		SET @ProductGroupSetIdN2	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy2_name' and LOVRecordSourceId = @chile_lovRecordSourceID );
		SET @ProductGroupSetIdN3	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy3_name' and LOVRecordSourceId = @chile_lovRecordSourceID);
		SET @ProductGroupSetIdN4	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy4_name' and LOVRecordSourceId = @chile_lovRecordSourceID );
		SET @ProductGroupSetIdC5	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy5_code' and LOVRecordSourceId = @chile_lovRecordSourceID );
		SET @ProductGroupSetIdN5	   		= (SELECT distinct LovSetId from [ser].[RefLOVSetInfo] WHERE LOVSetName = 'product_hierarchy5_name' and LOVRecordSourceId = @chile_lovRecordSourceID );
		SELECT @max_productID				= COALESCE(MAX(ProductID),0) FROM ser.PRODUCT
		SELECT @itemCode_sourceKeyTypeID	= LOVId FROM ser.RefLOVSetInfo WHERE LOVKey = 'Chile Item Code'  AND LOVSetName = 'Source Key Type'
		SELECT @upc_sourceKeyTypeID			= LOVId FROM ser.RefLOVSetInfo WHERE LOVKey = 'UPC' AND LOVSetName = 'Source Key Type'
		SELECT @LOVIndicatorIdOBFlag		= [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'own_brand_flag'  AND LOVSetName = 'Indicator - Chile Product'
		SELECT @LOVIndicatorIdEXFlag		= [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'exclusive_flag'  AND LOVSetName = 'Indicator - Chile Product'
		SELECT @uomCmId						= [LOVId] FROM [ser].[RefLOVSetInfo]  WHERE LOVKey = 'cm'		AND LOVSetName = 'Unit of measure';
		SELECT @uomUnknownId			    = [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'Unknown'	AND LOVSetName = 'Unit of measure';
		SELECT @party_typeID				= [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'ORG' and  LOVSetName = 'Party Type' 
		SELECT @lovRetailerRoleId			= [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'Retailer'  AND LOVSetName = 'Role';							
		SELECT @lovSupplierRoleId			= [LOVId] FROM [ser].[RefLOVSetInfo] WHERE LOVKey = 'Supplier'  AND LOVSetName = 'Role';
									

			
		BEGIN TRY

			PRINT 'Info: cl_crp_product_temp temporary table loading for parent records started';
			/*stg_product - selecting the  latest  version  from product table  where source key is item code both active and closed records */
			WITH stg_product AS (
								SELECT *  FROM ser.Product t
											WHERE LOVRECORDSOURCEID = @chile_lovRecordSourceID 
												AND LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
												AND NOT EXISTS (
																SELECT 1 FROM ser.Product AS pdt
																		 WHERE pdt.ProductID = t.ProductID
																			AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																			AND  pdt.SCDVersion > t.SCDVersion
																)
								),sourceTable AS (
								SELECT   [row_id]
									    ,ISNULL( NULLIF((Substring(item_code, Patindex('%[^0]%', item_code + ' '), Len(item_code)) ),''),0) item_code
									    ,[item_description]
									    ,[product_hierarchy1]
									    ,[product_hierarchy2]
									    ,[product_hierarchy3]
									    ,[product_hierarchy4]
									    ,[product_hierarchy5]
									    ,[product_hierarchy1_code]
									    ,[product_hierarchy2_code]
									    ,[product_hierarchy3_code]
									    ,[product_hierarchy4_code]
									    ,[product_hierarchy5_code]
									    ,[brand]
									    ,[subbrand]
									    ,[exclusive_flag]
									    ,[own_brand_flag]
									    ,[item_status]
									    ,(CASE WHEN NULLIF(upc,'') IS NULL THEN upc
											       ELSE ISNULL( NULLIF((Substring(upc, Patindex('%[^0]%', upc + ' '), Len(upc)) ),''),0)
												   END) upc
									    ,[supplier_name]
									    ,[supplier_number]
									    ,[height]
									    ,[width]
									    ,[depth]
									    ,[size]
									    ,[date_added]
									    ,[etl_runlog_id]
									    ,[asset_id]
									    ,[record_source_id]
									    ,[row_status]
									    ,[created_timestamp]
									    ,[active_flag]
									FROM [psa].[cl_crp_product] WHERE row_status = @rowStatusPSACode
								)
			/* inserting to psa.cl_crp_product_temp for itemcode  */
			INSERT INTO psa.cl_crp_product_temp
				select 
					PSARowKey,
					LOVSourceKeyTypeId,
					ProductID,
					ParentProductID,
					sourceKey,
					item_description,
					product_hierarchy1,
					product_hierarchy2,
					product_hierarchy3,
					product_hierarchy4,
					product_hierarchy5,
					product_hierarchy1_code,
					product_hierarchy2_code,
					product_hierarchy3_code,
					product_hierarchy4_code,
					product_hierarchy5_code,
					brand,
					subbrand,
					exclusive_flag,
					own_brand_flag,
					item_status,
					supplier_name,
					supplier_number,
					height,
					width,
					depth,
					size,
					date_added,
					etl_runlog_id,
					asset_id,
					LOVRecordSourceId,
					row_status,
					created_timestamp
				from 
				(
					SELECT
						clprod.row_id PSARowKey,
						@itemCode_sourceKeyTypeID LOVSourceKeyTypeId,
						ISNULL(p.ProductID,prodIdTemp.ProductID) ProductID, /*if product is in the  ser.product that id will pick up or take the new id created with max+rownumber */
						NULL ParentProductID,
						clprod.item_code sourceKey,
						item_description,
						product_hierarchy1,
						product_hierarchy2,
						product_hierarchy3,
						product_hierarchy4,
						product_hierarchy5,
						product_hierarchy1_code,
						product_hierarchy2_code,
						product_hierarchy3_code,
						product_hierarchy4_code,
						product_hierarchy5_code,
						brand,
						subbrand,
						exclusive_flag,
						own_brand_flag,
						item_status,
						supplier_name,
						supplier_number,
						height,
						width,
						depth,
						size,
						date_added,
						CAST(@serveETLRunLogID AS INT) etl_runlog_id,
						asset_id,
						clprod.record_source_id LOVRecordSourceId,
						clprod.row_status row_status ,
						created_timestamp,
						LEAD('N', 1, 'Y') OVER(PARTITION BY clprod.item_code,clprod.date_added,clprod.record_source_id ORDER BY clprod.date_added ASC) duplicate_Check 
				FROM sourceTable clprod
				/*creating product id for all the entries in the psa product table  by adding row number to the max product id of ser  table*/
				JOIN (SELECT clprod.item_code,
							clprod.record_source_id,
							(@max_productID+ROW_NUMBER() OVER(ORDER BY clprod.item_code,clprod.record_source_id	ASC)) ProductID
						FROM sourceTable clprod  
						WHERE clprod.row_status=@rowStatusPSACode 
						GROUP BY clprod.item_code,clprod.record_source_id) prodIdTemp
					ON prodIdTemp.item_code=clprod.item_code 
						AND prodIdTemp.record_source_id=clprod.record_source_id
				LEFT JOIN stg_product p
					ON clprod.item_code =p.sourcekey  
						AND clprod.record_source_id = p.LOVRecordSourceId
						AND p.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
				WHERE clprod.row_status = CAST(@rowStatusPSACode AS INT)				
				) t
				WHERE t.duplicate_Check ='Y'
			PRINT 'Info: cl_crp_product_temp temporary table loaded with parent records successfully';		
			SELECT @maxTempProductId = COALESCE(MAX(ProductID),0) FROM psa.cl_crp_product_temp;
			SELECT @max_productTempID = (CASE WHEN @max_productID >= @maxTempProductId THEN @max_productID 
											 ELSE @maxTempProductId END)
	
			PRINT 'Info: cl_crp_product_temp temporary table loading for child records started';
			/*stg_product - selecting the  latest  version  from product table  where source key is upc both active and closed records */
	
			WITH stg_product AS (SELECT *  FROM ser.Product t
									WHERE LOVRECORDSOURCEID = @chile_lovRecordSourceID 
									AND LOVSourceKeyTypeId = @upc_sourceKeyTypeID --source ky  = UPC
									AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt
													WHERE pdt.ProductID = t.ProductID
													AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
													AND  pdt.SCDVersion > t.SCDVersion))
				,sourceTable AS (
								SELECT   [row_id]
									    ,ISNULL( NULLIF((Substring(item_code, Patindex('%[^0]%', item_code + ' '), Len(item_code)) ),''),0) item_code
									    ,[item_description]
									    ,[product_hierarchy1]
									    ,[product_hierarchy2]
									    ,[product_hierarchy3]
									    ,[product_hierarchy4]
									    ,[product_hierarchy5]
									    ,[product_hierarchy1_code]
									    ,[product_hierarchy2_code]
									    ,[product_hierarchy3_code]
									    ,[product_hierarchy4_code]
									    ,[product_hierarchy5_code]
									    ,[brand]
									    ,[subbrand]
									    ,[exclusive_flag]
									    ,[own_brand_flag]
									    ,[item_status]
									    ,(CASE WHEN NULLIF(upc,'') IS NULL THEN upc
											       ELSE ISNULL( NULLIF((Substring(upc, Patindex('%[^0]%', upc + ' '), Len(upc)) ),''),0)
												   END) upc
									    ,[supplier_name]
									    ,[supplier_number]
									    ,[height]
									    ,[width]
									    ,[depth]
									    ,[size]
									    ,[date_added]
									    ,[etl_runlog_id]
									    ,[asset_id]
									    ,[record_source_id]
									    ,[row_status]
									    ,[created_timestamp]
									    ,[active_flag]
									FROM [psa].[cl_crp_product] WHERE row_status = @rowStatusPSACode
								)
			/* inserting to psa.cl_crp_product_temp for upc	
				create parent product id and product id
			*/
			INSERT INTO psa.cl_crp_product_temp
				SELECT
					clprod.row_id PSARowKey,
					@upc_sourceKeyTypeID LOVSourceKeyTypeId,
					ISNULL(p.ProductID,prodIdTemp.ProductID) ProductID,
					ISNULL(p.ParentProductID,productTemp.ProductID) ParentProductID,
					clprod.upc SourceKey,
					item_description,
					product_hierarchy1,
					product_hierarchy2,
					product_hierarchy3,
					product_hierarchy4,
					product_hierarchy5,
					product_hierarchy1_code,
					product_hierarchy2_code,
					product_hierarchy3_code,
					product_hierarchy4_code,
					product_hierarchy5_code,
					brand,
					subbrand,
					exclusive_flag,
					own_brand_flag,
					item_status,
					supplier_name,
					supplier_number,
					height,
					width,
					depth,
					size,
					date_added,
					CAST(@serveETLRunLogID AS INT) etl_runlog_id,
					asset_id,
					clprod.record_source_id LOVRecordSourceId,
					clprod.row_status,
					created_timestamp
				FROM sourceTable clprod
	
				JOIN (SELECT clprod.item_code,
							clprod.upc,
							clprod.record_source_id,
							(@max_productTempID+ROW_NUMBER() OVER(ORDER BY clprod.item_code,clprod.upc,clprod.record_source_id ASC)) ProductID
						FROM sourceTable clprod 
							WHERE clprod.row_status=@rowStatusPSACode 
							GROUP BY clprod.item_code,clprod.upc,clprod.record_source_id
					) prodIdTemp
				ON prodIdTemp.item_code=clprod.item_code 
				AND prodIdTemp.upc=clprod.upc 
				AND prodIdTemp.record_source_id=clprod.record_source_id
				/* parent product id creation  ???*/
				JOIN (SELECT SourceKey,
							LOVRecordSourceId,
							ProductID,
							LOVSourceKeyTypeId 
						FROM psa.cl_crp_product_temp
						GROUP BY SourceKey,LOVRecordSourceId,ProductID,LOVSourceKeyTypeId
					) productTemp
	
				ON productTemp.SourceKey = clprod.item_code
				AND productTemp.LOVRecordSourceId = clprod.record_source_id
				AND productTemp.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
				LEFT JOIN stg_product p
				ON clprod.upc = p.sourcekey 
				AND clprod.record_source_id = p.LOVRecordSourceId
				AND p.ParentProductId  = 	(SELECT DISTINCT ProductId 
												from ser.Product 
												WHERE SourceKey = clprod.item_code
													AND clprod.record_source_id = LOVRecordSourceId 
													AND LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID)
				AND p.LOVSourceKeyTypeId = @upc_sourceKeyTypeID
				WHERE clprod.upc IS NOT NULL 
				and clprod.upc !='' 
				AND clprod.row_status = CAST(@rowStatusPSACode AS INT)
				
	
			PRINT 'Info: cl_crp_product_temp temporary table loaded with child records successfully';

			SET @COUNTER = 1
			SELECT @MAXID = COUNT(DISTINCT date_added) FROM psa.cl_crp_product_temp
			print 'Total Number of Loops : '+CAST(@MAXID as varchar)+''
	
			WHILE (@COUNTER <= @MAXID)
			
				BEGIN
					print 'Loop Number  : '+cast(@COUNTER as varchar)+'';
					WITH TempCur AS( 
									SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (date_added)) AS RowID,
										date_added as dateAdded
									FROM  psa.cl_crp_product_temp
									)
					SELECT @dateAdded = dateAdded from TempCur where  RowID = @COUNTER		
					PRINT 'Current Processing Date: '+CAST(@dateAdded AS VARCHAR)+'';
					
					SET		@SCDStartDate	= CURRENT_TIMESTAMP;
					SET		@SCDEndDate		= DATEADD(second,-1,@SCDStartDate);				
					SET     @max_partyID			= (SELECT COALESCE(max(PartyId),0) FROM ser.party);
					SET     @maxPartyRoleId		= (SELECT COALESCE(max(PartyRoleId),0) FROM ser.partyRole);	
					SELECT  @maxProductGroupId	= COALESCE(MAX(ProductGroupId),0) FROM ser.productGroup;  
	
/******************************************************************************************************************************** 
 1. Table Name  :    Product
 ********************************************************************************************************************************/    
	
					PRINT 'Info: Product Table Serve Loading Started';
			
					PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
					/*stg_product table created with all the latest product id both active and close product included  */
					WITH stg_product AS (SELECT *  FROM ser.Product t
											WHERE LOVRecordSourceId = @chile_lovRecordSourceID
											AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt
																WHERE pdt.ProductID = t.ProductID
																AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																AND  pdt.SCDVersion > t.SCDVersion
															)
										)
					INSERT INTO ser.PRODUCT
					(	ProductId,
						SourceKey,
						LOVSourceKeyTypeId,
						ProductName,
						ProductDescription,
						LOVBrandId,
						LOVSubBrandId,
						LOVRecordSourceId,
						ParentProductId,
						SCDStartDate,
						SCDEndDate,
						SCDActiveFlag,
						SCDVersion,
						SCDLOVRecordSourceId,
						ETLRunLogId,
						PSARowKey
					)
						SELECT ProductId,
							SourceKey,
							LOVSourceKeyTypeId,
							ProductName,
							ProductDescription,
							LOVBrandId,
							LOVSubBrandId,
							LOVRecordSourceId,
							ParentProductId,
							CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId ORDER BY date_added ASC)) = 1)
									THEN @SCDDefaultStartDate 
									ELSE @SCDStartDate
							END 
							SCDStartDate,
							LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY ProductId ORDER BY date_added ASC) SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY ProductId ORDER BY date_added ASC) SCDActiveFlag,
							ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId ORDER BY date_added ASC) SCDVersion,
							SCDLOVRecordSourceId,
							ETLRunLogId,PSARowKey
						FROM
						(
							SELECT
								clprod.PSARowKey,
								clprod.ProductID,
								clprod.SourceKey,
								clprod.LOVSourceKeyTypeId,
								clprod.item_description ProductName,
								clprod.item_description ProductDescription ,
								b.lovid LOVBrandId,
								sb.lovid LOVSubBrandId,
								clprod.ParentProductID,
								clprod.LOVRecordSourceId,
								clprod.date_added,
								@SCDDefaultEndDate SCDEndDate,
								clprod.LOVRecordSourceId SCDLOVRecordSourceId,
								p.SCDVersion SCDVersion,
								clprod.etl_runlog_id ETLRunLogId,
								LEAD('N', 1, 'Y') OVER(PARTITION BY clprod.ProductID,clprod.item_description,b.lovid,sb.lovid,
								clprod.date_added ORDER BY clprod.date_added ASC) SCDActiveFlag
							FROM psa.cl_crp_product_temp clprod
							LEFT JOIN stg_product p
								ON clprod.ProductId = p.ProductId
								AND ISNULL(clprod.ParentProductID,'') = ISNULL(p.ParentProductID,'')
								AND clprod.LOVRecordSourceId = p.LOVRecordSourceId
								AND p.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
							LEFT JOIN ser.RefLOVSetInfo b
								ON  b.LOVSetName='brand' 
								AND b.LOVRecordSourceId = clprod.LOVRecordSourceId
								AND b.LOVKey=clprod.brand
							LEFT JOIN ser.RefLOVSetInfo sb
								ON sb.LOVSetName='subbrand' 
								AND sb.LOVRecordSourceId = clprod.LOVRecordSourceId 
								AND sb.LOVKey = clprod.subbrand
							WHERE clprod.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID 
								AND clprod.date_added = @dateAdded
								AND (CASE  WHEN ( NULLIF(clprod.item_description,'' ) IS NULL 
												AND NULLIF( clprod.brand,'' ) IS NULL 
												AND NULLIF( clprod.subbrand,'') IS NULL)  
											THEN 0
											ELSE 1 
									END
									)=1			
							UNION
							SELECT   clprod.PSARowKey,
								clprod.ProductID,
								clprod.SourceKey,
								clprod.LOVSourceKeyTypeId,
								clprod.item_description ProductName,
								clprod.item_description ProductDescription ,
								b.lovid LOVBrandId,
								sb.lovid LOVSubBrandId,
								clprod.ParentProductID,
								clprod.LOVRecordSourceId,
								clprod.date_added,
								@SCDDefaultEndDate SCDEndDate,
								clprod.LOVRecordSourceId SCDLOVRecordSourceId,							
								p.SCDVersion SCDVersion,
								clprod.etl_runlog_id ETLRunLogId,
								LEAD('N', 1, 'Y') OVER(PARTITION BY clprod.ProductID,clprod.item_description,b.lovid,sb.lovid,
								clprod.date_added ORDER BY clprod.date_added ASC) SCDActiveFlag
							FROM psa.cl_crp_product_temp clprod
							LEFT JOIN stg_product p
								ON clprod.ProductId = p.ProductId 
								AND ISNULL(clprod.ParentProductID,'') = ISNULL(p.ParentProductID,'') 
								AND clprod.LOVRecordSourceId = p.LOVRecordSourceId
								AND p.LOVSourceKeyTypeId = @upc_sourceKeyTypeID
							LEFT JOIN ser.RefLOVSetInfo b
								ON  b.LOVSetName='brand' 
								AND b.LOVRecordSourceId = clprod.LOVRecordSourceId 
								AND b.LOVKey=clprod.brand
							LEFT JOIN ser.RefLOVSetInfo sb
								ON sb.LOVSetName='subbrand' 
								AND sb.LOVRecordSourceId = clprod.LOVRecordSourceId 
								AND sb.LOVKey = clprod.subbrand
							WHERE clprod.LOVSourceKeyTypeId = @upc_sourceKeyTypeID 
								AND clprod.date_added = @dateAdded
								AND (CASE  WHEN ( NULLIF(clprod.item_description,'' ) IS NULL 
												AND NULLIF( clprod.brand,'' ) IS NULL
												AND NULLIF( clprod.subbrand,'') IS NULL)  
											THEN 0
											ELSE 1 
									END)=1		
						)t
						WHERE t.SCDActiveFlag='Y'
							AND NOT EXISTS ( SELECT 1 FROM ser.Product p 
												WHERE t.ProductId = p.ProductId
												AND t.LOVSourceKeyTypeId= p.LOVSourceKeyTypeId
												AND t.LOVRecordSourceId=p.LOVRecordSourceId
												AND ISNULL(t.ProductName,'') = ISNULL(p.ProductName,'')
												AND ISNULL(t.productDescription,'''')=ISNULL(p.productDescription,'')
												AND ISNULL(t.LOVBrandId,0) = ISNULL(p.LOVBrandId,0)
												AND ISNULL(t.LOVSubBrandId,0) = ISNULL(p.LOVSubBrandId,0)
												AND p.SCDActiveFlag ='Y'
											)
			
					PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key';
			
					UPDATE ser.Product set SCDActiveFlag='N',SCDEndDate = @SCDEndDate
						FROM ser.Product p
						JOIN
							(SELECT productId,
									SCDactiveflag, 
									SCDVersion,
									LovRecordSourceId 
								FROM ser.Product t 
								WHERE
									t.LOVRecordSourceID = @chile_lovRecordSourceID 
									AND t.SCDActiveFlag='Y'
									AND NOT EXISTS (
										SELECT 1 FROM ser.Product AS pt
												WHERE pt.ProductID = t.ProductID
												AND pt.LOVRecordSourceID=t.LOVRecordSourceID
												AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
												AND  pt.ScdVersion > t.ScdVersion
											)
							) p2
							ON  p.productID=p2.productId
								AND p.LovRecordSourceId=p2.LovRecordSourceId
								AND p.SCDactiveflag=p2.SCDactiveflag
								AND p.SCDVersion!=p2.SCDVersion
							JOIN psa.cl_crp_product_temp clprod
							ON p.productID = clprod.productID
							WHERE p.SCDActiveFlag='Y'
								AND p.SCDEndDate = @scdDefaultEndDate
								AND date_added = @dateAdded
					PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key -- finished';			
					PRINT 'Info: second update started';
					UPDATE ser.product SET SCDActiveFlag= 'N', SCDEndDate = @SCDEndDate
						FROM ser.product p
						JOIN psa.cl_crp_product_temp clprod
						ON p.productID = clprod.productID
						WHERE NULLIF(clprod.item_description,'' ) IS NULL
							AND NULLIF( clprod.brand,'' ) IS NULL
							AND NULLIF( clprod.subbrand,'') IS NULL
							AND p.SCDActiveFlag = 'Y'
							AND date_added = @dateAdded
			
					PRINT 'Info: Product Table Loaded Successfully';
/******************************************************************************************************************************** 
 2. Table Name  :    Product Status
********************************************************************************************************************************/    
	
					PRINT 'Info: Product Status Table Serve Loading Started';		
					PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
		
					WITH stg_product AS (SELECT * FROM ser.Product t
													WHERE LOVRecordSourceId = @chile_lovRecordSourceID
													AND LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
													AND t.SCDActiveFlag = 'Y'
													AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt
																				WHERE pdt.ProductID = t.ProductID
																				AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																				AND pdt.LOVSourceKeyTypeId = t.LOVSourceKeyTypeId
																				AND  pdt.ScdVersion > t.ScdVersion
																	)
										)
						,stg_product_status AS ( SELECT * FROM ser.ProductStatus pst
															WHERE LOVRecordSourceId = @chile_lovRecordSourceID
															AND NOT EXISTS (SELECT 1 FROM ser.ProductStatus AS pdt
																				WHERE pdt.ProductID = pst.ProductID
																				AND pdt.LOVProductStatusSetId = pst.LOVProductStatusSetId
																				AND pdt.LOVRecordSourceID=pst.LOVRecordSourceID
																				AND  pdt.ScdVersion > pst.ScdVersion
																			)
												)
					INSERT INTO ser.ProductStatus
						(
						ProductId			,
						LOVStatusId			,
						LOVProductStatusSetId,
						LOVRecordSourceId   ,
						EffectiveFrom		,
						EffectiveTo			,
						SCDStartDate		,
						SCDEndDate			,
						SCDActiveFlag		,
						SCDVersion			,
						SCDLOVRecordSourceId,
						ETLRunLogId			,
						PSARowKey
						)
						SELECT
							ProductID,
							LOVStatusId,
							LOVProductStatusSetId,
							LOVRecordSourceId,
							EffectiveFrom,
							EffectiveTo,
							CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID ORDER BY date_added ASC)) = 1)
									THEN  @SCDDefaultStartDate 
									ELSE @SCDStartDate
							END SCDStartDate,
							LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY ProductID ORDER BY date_added ASC) SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY ProductId,LOVRecordSourceId ORDER BY date_added ASC) SCDActiveFlag,
							ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID ORDER BY date_added ASC) SCDVersion,
							SCDLOVRecordSourceId,
							ETLRunLogId,
							PSARowKey
						FROM (
						SELECT
							temp.ProductID,
							itmstat.LOVId LOVStatusId,
							itmstat.LOVSetId LOVProductStatusSetId,
							temp.LOVRecordSourceId,
							temp.date_added EffectiveFrom,
							NULL EffectiveTo,
							temp.date_added,
							@SCDDefaultEndDate SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY temp.ProductID,itmstat.LOVId,temp.date_added ORDER BY temp.date_added ASC) SCDActiveFlag,
							pstatus.SCDVersion SCDVersion,
							temp.LOVRecordSourceId SCDLOVRecordSourceId,
							temp.etl_runlog_id ETLRunLogId,
							temp.PSARowKey
						FROM psa.cl_crp_product_temp temp
						JOIN stg_product product
						ON  product.ProductID = temp.ProductID
								AND product.LOVRecordSourceID = temp.LOVRecordSourceId
								AND product.LOVSourceKeyTypeId = temp.LOVSourceKeyTypeId
								AND temp.item_status!= '' AND temp.item_status IS NOT NULL
								AND temp.date_added = @dateAdded
						LEFT JOIN ser.RefLOVSetInfo itmstat 
						ON temp.LOVRecordSourceId =itmstat.LOVRecordSourceId
							AND temp.item_status=itmstat.LOVKey 
							AND itmstat.LOVSetName='item_status'
						LEFT JOIN stg_product_status pstatus
						ON  pstatus.ProductID =product.ProductID
							AND pstatus.LOVRecordSourceId = product.LOVRecordSourceId
						) PrdtSts
						WHERE PrdtSts.SCDActiveFlag='Y'					
						AND NOT EXISTS (SELECT 1 FROM ser.ProductStatus serpst
												WHERE PrdtSts.ProductID = serpst.productID
												AND PrdtSts.LOVProductStatusSetId= serpst.LOVProductStatusSetId
												AND	  PrdtSts.LOVRecordSourceId=serpst.LOVRecordSourceId
												AND	  PrdtSts.LOVStatusId = serpst.LOVStatusId
												AND   serpst.SCDActiveFlag ='Y'
										)
		
					PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key';
		
					UPDATE ser.ProductStatus set SCDActiveFlag='N',SCDEndDate = @SCDEndDate
						FROM ser.ProductStatus p
						JOIN
						(	SELECT productId,
									LOVProductStatusSetId,
									SCDactiveflag, 
									SCDVersion,
									LovRecordSourceId 
								FROM ser.ProductStatus t 
								WHERE t.LOVRecordSourceID = @chile_lovRecordSourceID
									AND t.SCDActiveFlag='Y'
									AND NOT EXISTS (
													SELECT 1 FROM ser.ProductStatus AS pt
																WHERE pt.ProductID = t.ProductID
																AND  pt.LOVRecordSourceID=t.LOVRecordSourceID
																AND	 pt.LOVProductStatusSetId= t.LOVProductStatusSetId
																AND  pt.ScdVersion > t.ScdVersion
													)
						) p2
						ON  p.productID=p2.productId
							AND p.LovRecordSourceId=p2.LovRecordSourceId
							AND p.LOVProductStatusSetId = p2.LOVProductStatusSetId
							AND p.SCDactiveflag=p2.SCDactiveflag
							AND p.SCDVersion!=p2.SCDVersion
						WHERE	p.SCDActiveFlag='Y'
							AND p.SCDEndDate = @SCDDefaultEndDate
					PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key -- finished';			
					PRINT 'Info: second update started';
					UPDATE ser.ProductStatus SET SCDActiveFlag= 'N', SCDEndDate = @SCDEndDate
						FROM ser.ProductStatus pst
						JOIN 
						(	SELECT productId,
										SourceKey,
										LOVSourceKeyTypeId,
										SCDactiveflag, 
										SCDVersion,
										LovRecordSourceId 
									FROM ser.Product t 
									WHERE t.LOVRecordSourceID = @chile_lovRecordSourceID 
										AND t.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
										AND NOT EXISTS (
														SELECT 1 FROM ser.Product AS pt
																WHERE pt.ProductID		  = t.ProductID
																AND pt.LOVRecordSourceID  = t.LOVRecordSourceID
																AND pt.LOVSourceKeyTypeId = t.LOVSourceKeyTypeId
																AND  pt.ScdVersion > t.ScdVersion
													)
						) p2
						ON 	pst.productID = p2.productId
							AND pst.LovRecordSourceId = p2.LovRecordSourceId
						JOIN psa.cl_crp_product_temp temp
						ON temp.productID = p2.productID
						WHERE ( NULLIF(temp.item_status,'' ) IS NULL OR p2.SCDActiveFlag = 'N')
								AND pst.SCDActiveFlag = 'Y'
								AND temp.date_added = @dateAdded
		
					PRINT 'Info: Product Status Table Loaded Successfully';
/******************************************************************************************************************************** 
 3. Table Name  :    Product Indicator
 ********************************************************************************************************************************/ 	
					PRINT 'Info: Product Indicator Table Serve Loading Started';
		
					PRINT 'Info: Inserting the new version of record if there is achange in the attribute';
		
					WITH stg_product AS (SELECT * FROM ser.Product t
													WHERE LOVRecordSourceId = @chile_lovRecordSourceID
														AND LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
														AND t.SCDActiveFlag = 'Y'
														AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt
																			WHERE pdt.ProductID = t.ProductID
																			AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																			AND pdt.LOVSourceKeyTypeId = t.LOVSourceKeyTypeId
																			AND  pdt.ScdVersion > t.ScdVersion
																		)
										)
						,stg_indicator AS (SELECT * FROM ser.ProductIndicator pin
													WHERE LOVRecordSourceId = @chile_lovRecordSourceID
														AND NOT EXISTS (SELECT 1 FROM ser.ProductIndicator AS pdt
																			WHERE pdt.ProductID = pin.ProductID
																			AND pdt.LOVIndicatorId = pin.LOVIndicatorId
																			AND pdt.LOVRecordSourceID=pin.LOVRecordSourceID
																			AND pdt.ScdVersion > pin.ScdVersion
																		)
											)
					INSERT INTO ser.ProductIndicator
							(
								ProductId           ,
								LOVIndicatorId      ,
								LOVRecordSourceId   ,
								Value               ,
								SCDStartDate        ,
								SCDEndDate          ,
								SCDActiveFlag       ,
								SCDVersion          ,
								SCDLOVRecordSourceId,
								ETLRunLogId			,
								PSARowKey
							)
							SELECT	temp.ProductID,
								temp.LOVIndicatorId,
								temp.LOVRecordSourceId,
								temp.PIValue Value,
								CASE WHEN ((ISNULL(indicator.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,temp.LOVIndicatorId ORDER BY temp.date_added ASC)) = 1)
									THEN @SCDDefaultStartDate 
									ELSE @SCDStartDate
								END SCDStartDate,
								LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY temp.ProductId,temp.LOVIndicatorId ORDER BY temp.date_added ASC) SCDEndDate,
								LEAD('N', 1, 'Y') OVER(PARTITION BY temp.ProductID,temp.LOVIndicatorId ORDER BY temp.date_added ASC) SCDActiveFlag,
								ISNULL(indicator.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,temp.LOVIndicatorId ORDER BY temp.date_added ASC) SCDVersion,
								temp.SCDLOVRecordSourceId SCDLOVRecordSourceId,
								temp.ETLRunLogId ETLRunLogId,
								temp.PSARowKey PSARowKey
							FROM
								(
								SELECT
									ProductID ,
									LOVRecordSourceId,
										( 	SELECT 
												LOVId 
												FROM ser.RefLOVSetInfo 
												WHERE LOVKey = ''+PICol+'' 
													AND LOVSetName = 'Indicator - Chile Product'
										) LOVIndicatorId,
									PIValue,
									date_added,
									SCDEndDate,
									LEAD('N', 1, 'Y') OVER(PARTITION BY ProductID,PICol,PIValue,date_added ORDER BY date_added ASC) SCDActiveFlag,
									SCDLOVRecordSourceId,
									ETLRunLogId,
									PSARowKey
								FROM
									(
									SELECT product.ProductID,
										clprod.LOVRecordSourceId,
										clprod.exclusive_flag,
										clprod.own_brand_flag,
										clprod.date_added,
										@SCDDefaultEndDate SCDEndDate,
										clprod.LOVRecordSourceId SCDLOVRecordSourceId,
										clprod.etl_runlog_id ETLRunLogId,
										clprod.PSARowKey
									FROM psa.cl_crp_product_temp clprod
									JOIN stg_product product
									ON product.ProductID = clprod.ProductID
										AND product.LOVRecordSourceID = clprod.LOVRecordSourceID
										AND product.LOVSourceKeyTypeId = clprod.LOVSourceKeyTypeId ---need to check
										AND clprod.date_added = @dateAdded
									) t
									UNPIVOT
										( PIValue FOR PICol in (exclusive_flag,own_brand_flag)
										) AS ProductIndicator 
										WHERE PIValue!='' AND PIValue IS NOT NULL
								) temp
								LEFT JOIN stg_indicator indicator
									ON indicator.ProductId = temp.ProductId
										AND indicator.LOVIndicatorId = temp.LOVIndicatorId
										AND indicator.LOVRecordSourceId = temp.LOVRecordSourceId									
									WHERE temp.SCDActiveFlag='Y'
										AND NOT EXISTS (SELECT 1 FROM ser.ProductIndicator serpind
																WHERE temp.ProductID = serpind.ProductID
																	AND	temp.LOVIndicatorId= serpind.LOVIndicatorId
																	AND temp.LOVRecordSourceId=serpind.LOVRecordSourceId
																	AND	temp.PIValue = serpind.Value
																	AND serpind.SCDActiveFlag ='Y'
														)
		
					PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key';
		
					UPDATE ser.ProductIndicator set SCDActiveFlag='N',SCDEndDate = @SCDEndDate
						FROM ser.ProductIndicator p
							JOIN
							(	SELECT productId,
									LOVIndicatorId,
									SCDactiveflag,
									SCDVersion,
									LovRecordSourceId
								FROM ser.ProductIndicator t 
								WHERE t.LOVRecordSourceID = @chile_lovRecordSourceID 
									AND t.SCDActiveFlag = 'Y'
									AND NOT EXISTS (
														SELECT 1 FROM ser.ProductIndicator AS pt
																	WHERE pt.ProductID = t.ProductID
																		AND  pt.LOVRecordSourceID = t.LOVRecordSourceID
																		AND	 pt.LOVIndicatorId = t.LOVIndicatorId
																		AND  pt.ScdVersion > t.ScdVersion
													)
							) p2
							ON  p.productID=p2.productId
								AND p.LovRecordSourceId=p2.LovRecordSourceId
								AND p.LOVIndicatorId = p2.LOVIndicatorId
								AND p.SCDactiveflag=p2.SCDactiveflag
								AND p.SCDVersion!=p2.SCDVersion
							WHERE	p.SCDActiveFlag='Y'
								AND p.SCDEndDate = @SCDDefaultEndDate
					PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key -- finished';			
					PRINT 'Info: second update started';	
					UPDATE ser.ProductIndicator SET SCDActiveFlag= 'N', SCDEndDate = @SCDEndDate
						FROM ser.ProductIndicator pin
							JOIN (
									SELECT productId,
										SourceKey,
										LOVSourceKeyTypeId,
										SCDactiveflag, 
										SCDVersion,
										LovRecordSourceId
										FROM ser.Product t
										WHERE t.LOVRecordSourceID = @chile_lovRecordSourceID 
											AND t.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
											AND NOT EXISTS (
															SELECT 1 FROM ser.Product AS pt
																	WHERE pt.ProductID		 =t.ProductID
																		AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																		AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																		AND pt.ScdVersion > t.ScdVersion
															)
								) p2
							ON	pin.productID=p2.productId
								AND pin.LovRecordSourceId=p2.LovRecordSourceId
							JOIN (
									SELECT	inp.ProductId,
											@LOVIndicatorIdOBFlag LOVIndicatorId,
											inp.own_brand_flag value,
											inp.LOVRecordSourceId,
											inp.date_added
										FROM psa.cl_crp_product_temp inp
										WHERE inp.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID 
										AND date_added = @dateAdded
								UNION
									SELECT
											inp.ProductId,
											@LOVIndicatorIdEXFlag LOVIndicatorId,
											inp.exclusive_flag value,
											inp.LOVRecordSourceId,
											inp.date_added
											FROM psa.cl_crp_product_temp inp
											WHERE inp.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID 
												AND date_added = @dateAdded
								) intprod
							ON intprod.LOVRecordSourceId=p2.LovRecordSourceId
								AND p2.ProductId = intprod.ProductId
							WHERE	( NULLIF(intprod.value,'' ) IS NULL OR p2.SCDActiveFlag='N')
								AND pin.LOVIndicatorId = intprod.LOVIndicatorId
								AND pin.SCDActiveFlag='Y'
		
					PRINT 'Info: Product Indicator Table Loaded Successfully';
/******************************************************************************************************************************** 
 4. Table Name  :    Product property
 ********************************************************************************************************************************/  
					PRINT 'Info: Product Property Table Serve Loading Started';
					PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
					
					WITH Stg_Product AS (SELECT * FROM ser.Product t
													WHERE LOVRecordSourceId = @chile_lovRecordSourceID 
														AND LOVSourceKeyTypeId = @upc_sourceKeyTypeID  
														AND t.SCDActiveFlag = 'Y'
														AND NOT EXISTS (SELECT 1 FROM ser.Product AS pdt
																			WHERE pdt.ProductID = t.ProductID
																			AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																			AND pdt.LOVSourceKeyTypeId = t.LOVSourceKeyTypeId
																			AND  pdt.ScdVersion > t.ScdVersion
																		)
										)															
					,Stg_Product_Property AS ( SELECT * FROM ser.ProductProperty pty
														WHERE LovRecordSourceId=  @chile_lovRecordSourceID 
														AND NOT EXISTS (SELECT 1 FROM ser.ProductProperty AS pdtPty 
																				WHERE pdtPty.ProductID = pty.ProductID
																				AND pdtPty.MeasureId = pty.MeasureId
																				AND pdtPty.LOVUOMId = pty.LOVUOMId
																				AND pdtPty.LOVRecordSourceID=pty.LOVRecordSourceID
																				AND pdtPty.ScdVersion > pty.ScdVersion
																		)
											)
	
					INSERT INTO [ser].[ProductProperty] 
						(
							ProductID,
							MeasureID,
							LOVUOMId,
							value,
							LOVRecordSourceId,
							SCDStartDate,
							SCDEndDate,
							SCDActiveFlag,
							SCDVersion,
							SCDLOVRecordSourceId,
							ETLRunLogId,
							PSARowKey	
						)
						SELECT 
							ProductID,
							MeasureID,
							LOVUOMId,
							value,
							LOVRecordSourceId,
							CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId,MeasureID ORDER BY date_added ASC)) = 1)
									THEN @SCDDefaultStartDate 
									ELSE @SCDStartDate
							END SCDStartDate,
							LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY ProductId,MeasureID ORDER BY date_added ASC) SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY ProductId,MeasureID,LOVRecordSourceId ORDER BY date_added ASC) SCDActiveFlag,
							ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,MeasureID ORDER BY date_added ASC) SCDVersion,
							SCDLOVRecordSourceId,
							ETLRunLogId,PSARowKey
						FROM 
						(
				
							SELECT 
								product.ProductID ProductID,
								measure.MeasureId MeasureID,
								@uomCmId LOVUOMId,
								intprod.height value,
								intprod.LOVRecordSourceId LOVRecordSourceId,
								intprod.date_added date_added,
								@scdDefaultEndDate SCDEndDate,
								LEAD('N', 1, 'Y') OVER(PARTITION BY product.ProductID,measure.MeasureId,intprod.height,intprod.LOVRecordSourceId,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
								p.SCDVersion SCDVersion,
								intprod.LOVRecordSourceId SCDLOVRecordSourceId,
								intprod.etl_runlog_id ETLRunLogId,
								intprod.PSARowKey PSARowKey
								FROM psa.cl_crp_product_temp intprod 
								JOIN Stg_Product product
									ON product.ProductID = intprod.ProductID 
									AND product.LOVRecordSourceID = intprod.LOVRecordSourceId
									AND product.SCDActiveFlag = 'Y' 
									AND intprod.height != '' AND intprod.height IS NOT NULL
								JOIN ser.Measure measure 
									ON measure.MeasureName = 'height' 
									AND measure.LOVRecordSourceId = intprod.LOVRecordSourceId
									AND measure.LOVMeasureTypeId = @measureTypeId
									AND measure.LOVDataTypeId = @dataTypeId 
								LEFT JOIN Stg_Product_Property p
									ON p.ProductID =product.ProductID
									AND p.LOVRecordSourceId = product.LOVRecordSourceId
									AND p.MeasureID = measure.MeasureID 
								WHERE  intprod.date_added = @dateAdded
				
						UNION
							SELECT
								product.ProductID ProductID,
								measure.MeasureID MeasureID,
								@uomCmId LOVUOMId,
								intprod.width value,
								intprod.LOVRecordSourceId LOVRecordSourceId,
								intprod.date_added date_added,
								@scdDefaultEndDate SCDEndDate,
								LEAD('N', 1, 'Y')  OVER(PARTITION BY product.ProductID,measure.MeasureId,intprod.width,intprod.LOVRecordSourceId,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
								p.SCDVersion SCDVersion,
								intprod.LOVRecordSourceId SCDLOVRecordSourceId,
								intprod.etl_runlog_id ETLRunLogId,
								intprod.PSARowKey PSARowKey
								FROM psa.cl_crp_product_temp intprod
								JOIN Stg_Product product
									ON product.ProductID = intprod.ProductID
									AND product.LOVRecordSourceID = intprod.LOVRecordSourceId
									AND product.SCDActiveFlag = 'Y'
									AND intprod.width != '' AND intprod.width IS NOT NULL 
								JOIN ser.Measure measure 
									ON measure.MeasureName ='width'
									AND measure.LOVRecordSourceId = intprod.LOVRecordSourceId
									AND measure.LOVMeasureTypeId = @measureTypeId
									AND measure.LOVDataTypeId = @dataTypeId 
								LEFT JOIN Stg_Product_Property p
									ON p.ProductID =product.ProductID 
									AND p.LOVRecordSourceId = product.LOVRecordSourceId
									AND p.MeasureID = measure.MeasureID
								WHERE  intprod.date_added = @dateAdded
						
						UNION
							SELECT
								product.ProductID ProductID,
								measure.MeasureID MeasureID,
								@uomCmId LOVUOMId,
								intprod.depth value,
								intprod.LOVRecordSourceId LOVRecordSourceId,
								intprod.date_added date_added,
								@scdDefaultEndDate SCDEndDate,
								LEAD('N', 1, 'Y')  OVER(PARTITION BY product.ProductID,measure.MeasureId,intprod.depth,intprod.LOVRecordSourceId,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
								p.SCDVersion SCDVersion,
								intprod.LOVRecordSourceId SCDLOVRecordSourceId,
								intprod.etl_runlog_id ETLRunLogId,
								intprod.PSARowKey PSARowKey
								FROM psa.cl_crp_product_temp intprod
								JOIN Stg_Product product
									ON product.ProductID = intprod.ProductID
									AND product.LOVRecordSourceID = intprod.LOVRecordSourceId
									AND product.SCDActiveFlag ='Y'
									AND intprod.depth != '' AND intprod.depth IS NOT NULL 
								JOIN ser.Measure measure 
									ON measure.MeasureName = 'depth' 
									AND measure.LOVRecordSourceId = intprod.LOVRecordSourceId
									AND measure.LOVMeasureTypeId = @measureTypeId
									AND measure.LOVDataTypeId = @dataTypeId 
								LEFT JOIN Stg_Product_Property p
									ON p.ProductID = product.ProductID
									AND p.LOVRecordSourceId = product.LOVRecordSourceId
									AND p.MeasureID = measure.MeasureID 							
								WHERE intprod.date_added = @dateAdded
						
						UNION
							SELECT
								product.ProductID ProductID,
								measure.MeasureID MeasureID,
								@uomUnknownId LOVUOMId,
								intprod.size value,
								intprod.LOVRecordSourceId LOVRecordSourceId,
								intprod.date_added date_added,
								@scdDefaultEndDate SCDEndDate,
								LEAD('N', 1, 'Y')  OVER(PARTITION BY product.ProductID,measure.MeasureId,intprod.size,intprod.LOVRecordSourceId,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
								p.SCDVersion SCDVersion,
								intprod.LOVRecordSourceId SCDLOVRecordSourceId,
								intprod.etl_runlog_id ETLRunLogId,
								intprod.PSARowKey PSARowKey
								FROM psa.cl_crp_product_temp intprod
								JOIN Stg_Product product
									ON product.ProductID = intprod.ProductID
									AND product.LOVRecordSourceID = intprod.LOVRecordSourceId
									AND product.SCDActiveFlag = 'Y'
									AND intprod.size != '' AND intprod.size IS NOT NULL 
								JOIN ser.Measure measure 
									ON measure.MeasureName = 'size' 
									AND measure.LOVRecordSourceId = intprod.LOVRecordSourceId
									AND measure.LOVMeasureTypeId =@measureTypeId
									AND measure.LOVDataTypeId = @dataTypeId 
								LEFT JOIN Stg_Product_Property p
									ON p.ProductID =product.ProductID 
									AND p.LOVRecordSourceId = product.LOVRecordSourceId
									AND p.MeasureID = measure.MeasureID							
								WHERE intprod.date_added = @dateAdded
						) prdtppty
						WHERE prdtppty.SCDActiveFlag='Y'
							AND NOT EXISTS (SELECT 1 FROM ser.ProductProperty serppty
														WHERE	  prdtppty.ProductID = serppty.productID
															AND	  prdtppty.MeasureId = serppty.MeasureId 
															AND	  prdtppty.LOVUOMId  = serppty.LOVUOMId 
															AND	  prdtppty.LOVRecordSourceId = serppty.LOVRecordSourceId
															AND	  prdtppty.Value = serppty.Value
															AND   serppty.SCDActiveFlag = 'Y' 
											)
			
	
					PRINT 'Info: ProductProperty Table -> Closing off old Records if exists';				
	
					UPDATE ser.ProductProperty 	set SCDActiveFlag='N',SCDEndDate = @SCDEndDate
						FROM ser.ProductProperty p 
							JOIN 
							(	SELECT productId,
									MeasureId,
									LOVUOMId,
									SCDactiveflag,
									SCDVersion,
									LovRecordSourceId 
								FROM ser.ProductProperty t 
								WHERE   t.LOVRecordSourceID  = @chile_lovRecordSourceID
										AND t.SCDActiveFlag='Y'
										AND NOT EXISTS 
											(
												SELECT 1 FROM ser.ProductProperty AS ptpty 
													WHERE ptpty.ProductID = t.ProductID
													AND  ptpty.LOVRecordSourceID = t.LOVRecordSourceID
													AND	 ptpty.MeasureId = t.MeasureId
													AND  ptpty.LOVUOMId = t.LOVUOMId
													AND  ptpty.ScdVersion > t.ScdVersion									  
											)  
							) p2  
							ON  p.productID = p2.productId
								AND p.LovRecordSourceId = p2.LovRecordSourceId	
								AND p.MeasureId = p2.MeasureId
								AND p.LOVUOMId = p2.LOVUOMId
								AND p.SCDactiveflag = p2.SCDactiveflag
								AND p.SCDVersion != p2.SCDVersion	
							WHERE	p.SCDActiveFlag = 'Y'
								AND p.SCDEndDate = @scdDefaultEndDate
					PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key -- finished';			
					PRINT 'Info: second update started';
		
					UPDATE ser.ProductProperty 	SET SCDActiveFlag= 'N',	SCDEndDate = @SCDEndDate
						FROM ser.ProductProperty pty
							JOIN
							(	SELECT productId,
									SourceKey,
									LOVSourceKeyTypeId,
									SCDactiveflag, 
									SCDVersion,
									LovRecordSourceId
									FROM ser.Product t 
									WHERE   
										t.LOVRecordSourceID= @chile_lovRecordSourceID
										AND NOT EXISTS (
														SELECT 1 FROM ser.Product AS pt 
															WHERE pt.ProductID		 =t.ProductID
																AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																AND pt.ScdVersion > t.ScdVersion
														) 
							) p2
							ON	pty.productID=p2.productId
								AND pty.LovRecordSourceId=p2.LovRecordSourceId				
							JOIN (
									select	inp.productID productID,
											measure.MeasureID MeasureID,
											@uomCmId LOVUOMId,
											inp.height Value,
											inp.LOVRecordSourceId record_source_id,
											inp.row_status row_status,
											inp.etl_runlog_id etl_runlog_id,
											inp.date_added date_added
									FROM  psa.cl_crp_product_temp inp
									JOIN ser.Measure measure 
									ON measure.MeasureName = 'height'
										AND measure.LOVRecordSourceId = inp.LOVRecordSourceId
										AND measure.LOVMeasureTypeId = @measureTypeId
										AND measure.LOVDataTypeId = @dataTypeId
									WHERE date_added =@dateAdded
								union
										
									select	inp.productID productID,
											measure.MeasureID MeasureID,
											@uomCmId LOVUOMId,
											inp.width Value,
											inp.LOVRecordSourceId record_source_id,
											inp.row_status row_status,
											inp.etl_runlog_id etl_runlog_id,
											inp.date_added date_added
									FROM  psa.cl_crp_product_temp inp
									JOIN ser.Measure measure 
									ON measure.MeasureName = 'width'
										AND measure.LOVRecordSourceId = inp.LOVRecordSourceId
										AND measure.LOVMeasureTypeId = @measureTypeId
										AND measure.LOVDataTypeId = @dataTypeId
									WHERE	date_added =@dateAdded
								union
										
									select	inp.productID productID,
											measure.MeasureID MeasureID,
											@uomCmId LOVUOMId,
											inp.depth Value,
											inp.LOVRecordSourceId record_source_id,
											inp.row_status row_status,
											inp.etl_runlog_id etl_runlog_id,
											inp.date_added date_added
									FROM  psa.cl_crp_product_temp inp
									JOIN ser.Measure measure 
									ON measure.MeasureName = 'depth'
										AND measure.LOVRecordSourceId = inp.LOVRecordSourceId
										AND measure.LOVMeasureTypeId = @measureTypeId
										AND measure.LOVDataTypeId = @dataTypeId
									WHERE date_added =@dateAdded
								union
										
									select	inp.productID productID,
											measure.MeasureID MeasureID,
											@uomUnknownId LOVUOMId,
											inp.size Value,
											inp.LOVRecordSourceId record_source_id,
											inp.row_status row_status,
											inp.etl_runlog_id etl_runlog_id,
											inp.date_added date_added
									FROM  psa.cl_crp_product_temp inp
									JOIN ser.Measure measure 
									ON measure.MeasureName = 'size'
										AND measure.LOVRecordSourceId = inp.LOVRecordSourceId
										AND measure.LOVMeasureTypeId = @measureTypeId
										AND measure.LOVDataTypeId = @dataTypeId
									WHERE date_added =@dateAdded					
	
								) intprod
								ON intprod.record_source_id=p2.LovRecordSourceId 
									AND p2.productID = intprod.productID
									AND p2.LOVSourceKeyTypeId=@upc_sourceKeyTypeID 
								WHERE( NULLIF(intprod.value,'' ) IS NULL OR p2.SCDActiveFlag='N') 
										AND pty.MeasureID = intprod.MeasureID
										AND pty.LOVUOMId = intprod.LOVUOMId
										AND pty.SCDActiveFlag='Y'									
	
					PRINT 'Info: Product Property Table Loaded Successfully'; 
 
 /******************************************************************************************************************************** 
 5. Table Name  :    Product Group
 ********************************************************************************************************************************/ 
					PRINT 'Info: Product Group Table Serve Loading Started';
		
		
					WITH Stg_Product AS 
							(SELECT pt.ProductID,
									pt.SourceKey,
									pt.SCDVersion,
									pt.LOVRecordSourceID	
							FROM ser.Product pt, psa.cl_crp_product_temp intprod 
							WHERE  pt.LOVSourceKeyTypeId   = @itemCode_sourceKeyTypeID
								AND	intprod.sourceKey    = pt.SourceKey
								AND pt.SCDActiveFlag     = 'Y'
								AND pt.LoVRecordSourceID = intprod.LOVRecordSourceId
								AND intprod.date_added   = @dateAdded
							)	
					,Stg_serve_productGroup AS 
							(SELECT t.*,
								pt.SourceKey					
							FROM ser.productGroup t,Stg_Product pt 						
							WHERE t.ProductID		= pt.ProductID									
								AND t.LoVRecordSourceID = pt.LoVRecordSourceID												  
								AND NOT EXISTS (SELECT 1 FROM ser.productGroup  pdt 
														WHERE pdt.ProductID		  = t.ProductID
															AND pdt.LOVProductGroupSetId = t.LOVProductGroupSetId
															AND pdt.LOVRecordSourceID	  = t.LOVRecordSourceID
															AND pdt.ScdVersion > t.ScdVersion
												)
							)
					,Stg_src_ProductGroup AS 
							(SELECT		
								ProductId,
								PGCol,		
								( CASE 
										WHEN 
											PGCol in ('product_hierarchy1','product_hierarchy2','product_hierarchy3','product_hierarchy4','product_hierarchy5') 
											THEN 
												(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = ''+PGValue+'' AND  r.LOVSetName = ''+CONCAT (PGCol,'_name','')+'' and r.LOVRecordSourceID = @chile_lovRecordSourceID) 
																		ELSE
												(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = ''+PGValue+'' AND r.LOVSetName = ''+PGCol+'' and r.LOVRecordSourceID = @chile_lovRecordSourceID)
										END 
								) LOVGroupId,										
		
								(  CASE 
										WHEN 
											PGCol in ('product_hierarchy1','product_hierarchy2','product_hierarchy3','product_hierarchy4','product_hierarchy5')
											THEN
												(SELECT Distinct LOVSetId FROM ser.RefLOVSetInfo rs 	WHERE  rs.LOVSetName = ''+CONCAT (PGCol,'_name','')+'' and rs.LOVRecordSourceID = @chile_lovRecordSourceID) 
											ELSE 
												(SELECT Distinct rs.LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''+PGCol+'' and rs.LOVRecordSourceID = @chile_lovRecordSourceID) 
										END 
								) LOVProductGroupSetId,
								PGValue  value ,
								ParentProductGroupId,
								LOVRecordSourceId LOVRecordSourceId,							 
								LOVRecordSourceId SCDLOVRecordSourceId,
								ETLRunLogId,
								PSARowKey,
								@dateAdded date_added
							FROM
								( SELECT
									p.ProductID
									,product_hierarchy1
									,product_hierarchy2
									,product_hierarchy3
									,product_hierarchy4
									,product_hierarchy5
									,product_hierarchy1_code
									,product_hierarchy2_code
									,product_hierarchy3_code
									,product_hierarchy4_code
									,product_hierarchy5_code										
									,intprod.LOVRecordSourceId LOVRecordSourceId
									,intprod.LOVRecordSourceId SCDLOVRecordSourceId
									,NULL ParentProductGroupId
									,intprod.etl_runlog_id  ETLRunLogId
									,intprod.PSARowKey PSARowKey
								FROM psa.cl_crp_product_temp intprod 
								INNER JOIN 	Stg_Product p 
									ON	p.SourceKey =  intprod.sourceKey 						
								WHERE  	intprod.date_added= @dateAdded 
								) pg
									UNPIVOT  
										( PGValue FOR PGCol IN 
											(
												product_hierarchy1
												,product_hierarchy2
												,product_hierarchy3
												,product_hierarchy4
												,product_hierarchy5
												,product_hierarchy1_code
												,product_hierarchy2_code
												,product_hierarchy3_code
												,product_hierarchy4_code
												,product_hierarchy5_code
											)
										)	AS LOVGroupId  
							)
		
					INSERT  INTO  ser.ProductGroup 
						(	ProductGroupId		  ,
							ProductId			  ,
							LOVGroupId            ,
							LOVProductGroupSetId  ,
							ParentProductGroupId  ,
							LOVRecordSourceId     ,
							SCDStartDate          ,
							SCDEndDate            ,
							SCDActiveFlag         ,
							SCDVersion            ,
							SCDLOVRecordSourceId  ,
							ETLRunLogId           ,
							PSARowKey
						)
						SELECT  ISNULL(spg.ProductGroupId,(PGTemp.row_num+ @maxProductGroupId)) as ProductGroupId,
								pgt.ProductId,
								pgt.LOVGroupId,
								pgt.LOVProductGroupSetId,
								pgt.ParentProductGroupId,
								pgt.LOVRecordSourceId,
								(CASE 
									WHEN ISNULL(spg.SCDVersion,0)+ROW_NUMBER() 
										OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId   ORDER BY   pgt.ProductID,pgt.date_added ASC)=1 
									THEN @SCDDefaultStartDate
									ELSE
										LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId  order by  pgt.ProductID,pgt.date_added)
								END
								) as SCDStartDate,	
								LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId order by   pgt.ProductID,pgt.date_added) SCDEndDate,
								LEAD('N', 1, 'Y') OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY  pgt.ProductID,pgt.date_added ASC) SCDActiveFlag,				
								ISNULL(spg.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY   pgt.ProductID,pgt.date_added ASC) SCDVersion,
								pgt.SCDLOVRecordSourceId  ,
								pgt.ETLRunLogId,
								pgt.PSARowKey
						FROM Stg_src_ProductGroup pgt	 
						JOIN
						(
							SELECT ProductID, 
								LOVProductGroupSetId,
								LOVRecordSourceId,
								ROW_NUMBER() OVER(ORDER BY ProductID,LOVProductGroupSetId,LOVRecordSourceId ASC) row_num
							FROM Stg_src_ProductGroup  
							GROUP BY ProductID,LOVProductGroupSetId,LOVRecordSourceId
						)  PGTemp
						ON pgt.ProductID			 = PGTemp.ProductID
							AND pgt.LOVProductGroupSetId = PGTemp.LOVProductGroupSetId
							AND pgt.LOVRecordSourceId    = PGTemp.LOVRecordSourceId
						LEFT  JOIN Stg_serve_productGroup spg
						ON pgt.productid			 = spg.productid
							AND pgt.LOVProductGroupSetId = spg.LOVProductGroupSetId
							AND pgt.LOVRecordSourceId    = spg.LOVRecordSourceId
						WHERE NOT EXISTS (SELECT 1 FROM ser.ProductGroup serpg 
													where serpg.productid	   = pgt.productid
														AND serpg.LOVRecordSourceId    = pgt.LOVRecordSourceId
														AND serpg.SCDActiveFlag        = 'Y'
														AND serpg.LOVProductGroupSetId = pgt.LOVProductGroupSetId	
														AND serpg.LOVGroupID		   = pgt.LOVGroupID
										)
							AND NULLIF(pgt.value,'') is not null 
							AND pgt.LOVGroupID is not null 
											
				
					PRINT 'Info: ProductGroup Table -> Closing off old Records if exists';
		
				UPDATE ser.ProductGroup set SCDActiveFlag='N',SCDEndDate = @SCDEndDate
					FROM ser.ProductGroup pg 
					  JOIN 
					   ( SELECT productId,LOVProductGroupSetId,SCDactiveflag,SCDVersion,LovRecordSourceId
								FROM ser.ProductGroup t 
								WHERE t.LOVRecordSourceID = @chile_lovRecordSourceID
									AND t.SCDactiveflag   = 'Y'  
									AND NOT EXISTS (SELECT 1 FROM ser.ProductGroup AS pt 
															WHERE pt.ProductID				= t.ProductID
																AND pt.LOVProductGroupSetId = t.LOVProductGroupSetId 
																AND pt.LOVRecordSourceID	= t.LOVRecordSourceID 
																AND pt.ScdVersion > t.ScdVersion
													)
						)pg2
						ON  pg.productID				= pg2.productId
						    AND pg.LovRecordSourceId	= pg2.LovRecordSourceId
						    AND pg.LOVProductGroupSetId = pg2.LOVProductGroupSetId						 
						    AND pg.SCDactiveflag		= pg2.SCDactiveflag
						    AND pg.SCDVersion		   != pg2.SCDVersion
						WHERE pg.LovRecordSourceId		= @chile_lovRecordSourceID
							AND pg.SCDActiveFlag		= 'Y' 
							AND pg.SCDEndDate			= @SCDDefaultEndDate ;
	
					PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key -- finished';			
					PRINT 'Info: second update started';
					UPDATE ser.ProductGroup SET SCDActiveFlag= 'N', SCDEndDate = @SCDEndDate
						FROM ser.ProductGroup pgr
						JOIN (	
								SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag, SCDVersion,LovRecordSourceId
										FROM ser.Product t 
										WHERE   t.LOVRecordSourceID=@chile_lovRecordSourceID
												AND NOT EXISTS (
																SELECT 1 FROM ser.Product AS pt 
																		WHERE pt.ProductID		 =t.ProductID
																			AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																			AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																			AND pt.ScdVersion > t.ScdVersion
																) 
									) p2
								ON
									pgr.productID=p2.productId
								AND pgr.LovRecordSourceId=p2.LovRecordSourceId				
								JOIN (
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdC1 LOVProductGroupSetId,
													inp.product_hierarchy1_code Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
												FROM psa.cl_crp_product_temp inp													
												WHERE  date_added =@dateAdded
										union
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdN1 LOVProductGroupSetId,
													inp.product_hierarchy1 Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
													FROM psa.cl_crp_product_temp inp												
													WHERE date_added =@dateAdded
										union
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdC2 LOVProductGroupSetId,
													inp.product_hierarchy2_code Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
												FROM psa.cl_crp_product_temp inp												
												WHERE date_added =@dateAdded
										union
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdN2 LOVProductGroupSetId,
													inp.product_hierarchy2 Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
												FROM psa.cl_crp_product_temp inp												
												WHERE date_added =@dateAdded
										union
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdC3 LOVProductGroupSetId,
													inp.product_hierarchy3_code Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
												FROM psa.cl_crp_product_temp inp
												WHERE date_added =@dateAdded
										union
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdN3 LOVProductGroupSetId,
													inp.product_hierarchy3 Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
												FROM psa.cl_crp_product_temp inp
												WHERE  date_added =@dateAdded
										union
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdC4 LOVProductGroupSetId,
													inp.product_hierarchy4_code Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
												FROM psa.cl_crp_product_temp inp													
												WHERE date_added =@dateAdded
										union
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdN4 LOVProductGroupSetId,
													inp.product_hierarchy4 Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
												FROM psa.cl_crp_product_temp inp													
												WHERE  date_added =@dateAdded
										union
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdC5 LOVProductGroupSetId,
													inp.product_hierarchy5_code Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
												FROM psa.cl_crp_product_temp inp												
												WHERE date_added =@dateAdded
										union
											select	distinct inp.sourceKey sourceKey,
													@ProductGroupSetIdN5 LOVProductGroupSetId,
													inp.product_hierarchy5 Value,
													inp.LOVRecordSourceId record_source_id,
													inp.row_status row_status,
													inp.etl_runlog_id etl_runlog_id,
													inp.date_added date_added
												FROM psa.cl_crp_product_temp inp													
												WHERE  date_added =@dateAdded

									) intprod
									ON intprod.record_source_id=p2.LovRecordSourceId 
										AND p2.sourcekey = intprod.sourceKey
										AND p2.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
									WHERE	( NULLIF(intprod.value ,'' ) IS NULL OR p2.SCDActiveFlag='N') 
										AND pgr.LOVProductGroupSetId = intprod.LOVProductGroupSetId
										AND pgr.SCDActiveFlag='Y'
				

/********************************************************************************************************************************

 7. Table Name  :	Party

********************************************************************************************************************************/

					PRINT 'Info: Party Table Serve Loading Started';
	
					PRINT 'Info: Inserting the new version of record if there is achange in the attribute';
	
					INSERT INTO [ser].[Party]
						(                         
							PartyId,
							LOVPartyTypeId,
							SourceKey,
							LOVRecordSourceId,
							SCDStartDate,
							SCDEndDate,
							SCDActiveFlag,
							SCDVersion,
							SCDLOVRecordSourceId,
							ETLRunLogId,
							PSARowKey
						)
						SELECT  @max_partyID + ROW_NUMBER() OVER(ORDER BY Party.SourceKey,Party.LOVRecordSourceId ASC) partyId,
								@party_typeID  LOVPartyTypeId,
								Party.SourceKey SourceKey,
								Party.LOVRecordSourceId LOVRecordSourceId,
								@scdDefaultStartDate SCDStartDate ,
								@SCDDefaultEndDate SCDEndDate,
								@SCDDefaultActiveFlag SCDActiveFlag,
								@SCDDefaultVersion SCDVersion,
								Party.SCDLOVRecordSourceId SCDLOVRecordSourceId, 
								@inpServeETLRunLogID ETLRunLogId,
								Party.PSARowKey PSARowKey
						FROM
							(	SELECT supplier_number SourceKey,
									LOVRecordSourceId LOVRecordSourceId,
									LOVRecordSourceId SCDLOVRecordSourceId,
									Min(PSARowKey) PSARowKey
								FROM psa.cl_crp_product_temp clprod 
								WHERE clprod.supplier_number!='' 
									AND clprod.supplier_number IS NOT NULL
									AND clprod.date_added = @dateAdded
								GROUP BY supplier_number,LOVRecordSourceId
							) Party
							WHERE NOT EXISTS
							(
								SELECT 1 from ser.Party pr 	WHERE pr.SourceKey = Party.SourceKey AND pr.LOVRecordSourceId =Party.LOVRecordSourceId 
							)
					PRINT 'Info: Party Table Loaded Successfully'; 

/********************************************************************************************************************************
 7. Table Name  :	Organisation
********************************************************************************************************************************/
					PRINT 'Info: Organisation Table Serve Loading Started';
	
					PRINT 'Info: Inserting the new version of record if there is achange in the attribute';	
			
					WITH	Stg_Organisation AS ( SELECT * FROM ser.Organisation org
															WHERE LovRecordSourceId= @chile_lovRecordSourceID
															AND NOT EXISTS (SELECT 1 FROM ser.Organisation AS serorgn 
																						WHERE serorgn.PartyID = org.PartyID
																						AND serorgn.SourceOrganisationKey = org.SourceOrganisationKey
																						AND serorgn.LOVRecordSourceID=org.LOVRecordSourceID
																						AND serorgn.ScdVersion > org.ScdVersion
																			)
												)
					
					INSERT INTO ser.organisation  
						(
							PartyId,
							SourceOrganisationKey,
							OrganisationName,
							LOVRecordSourceId,
							ParentPartyId,
							SCDStartDate,
							SCDEndDate,
							SCDActiveFlag,
							SCDVersion,
							SCDLOVRecordSourceId,
							ETLRunLogId,
							PSARowKey 
						) 
					
						SELECT	party.PartyId  PartyId,
							t.SourceOrganisationKey SourceOrganisationKey,
							t.OrganisationName OrganisationName,
							t.LOVRecordSourceId LOVRecordSourceId,
							NULL ParentPartyId,
							CASE WHEN ((ISNULL(org.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.date_added ASC)) = 1)
										THEN	@scdDefaultStartDate
										ELSE	@SCDStartDate 
							END	SCDStartDate,
							LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDActiveFlag,
							ISNULL(org.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDVersion,
							t.LOVRecordSourceId SCDLOVRecordSourceId, 
							@inpServeETLRunLogID ETLRunLogId,
							t.PSARowKey PSARowKey
						FROM	
							( 	SELECT 	supplier_number SourceOrganisationKey,
										supplier_name OrganisationName,
										LOVRecordSourceId LOVRecordSourceId,
										date_added date_added,
										MIN(PSARowKey) PSARowKey
								FROM psa.cl_crp_product_temp intprod 
								WHERE intprod.supplier_number!='' AND intprod.supplier_number IS NOT NULL
									AND intprod.supplier_name!='' AND intprod.supplier_name IS NOT NULL
									AND intprod.date_added = @dateAdded
								GROUP BY supplier_number,supplier_name,LOVRecordSourceId,date_added
							)t
						
							JOIN ser.party party
								ON  t.SourceOrganisationKey = party.SourceKey
								AND t.LOVRecordSourceId = party.LOVRecordSourceId
							LEFT JOIN Stg_Organisation org
								ON  org.PartyId = party.PartyId
								AND org.LOVRecordSourceId = t.LOVRecordSourceId
								AND org.SCDActiveFlag = 'Y'
							WHERE NOT EXISTS (	SELECT  1 from ser.Organisation serorg 
														WHERE party.partyId			  = serorg.partyId 
															AND	  t.SourceOrganisationKey = serorg.SourceOrganisationKey 
															AND   t.OrganisationName      = serorg.OrganisationName 
															AND   t.LOVRecordSourceId     = serorg.LOVRecordSourceId 
															AND	  serorg.SCDActiveFlag ='Y'
											)
						
			
					PRINT 'Info: Organisation Table -> Closing off old Records if exists';			
					UPDATE ser.Organisation set SCDActiveFlag='N',SCDEndDate = @SCDEndDate
						FROM ser.Organisation p 
						JOIN 
							(	SELECT PartyID,
									SourceOrganisationKey,
									SCDactiveflag, 
									SCDVersion,
									LovRecordSourceId 
								FROM ser.Organisation t
								WHERE  t.LOVRecordSourceID  = @chile_lovRecordSourceID
									AND t.SCDActiveFlag='Y'
									AND NOT EXISTS (SELECT 1 FROM ser.Organisation AS serorg 
															WHERE serorg.PartyID = t.PartyID
															AND serorg.SourceOrganisationKey = t.SourceOrganisationKey
															AND serorg.LOVRecordSourceID = t.LOVRecordSourceID
															AND serorg.ScdVersion > t.ScdVersion
													)  
							) p2  
						ON  p.PartyID = p2.PartyID
							AND p.LovRecordSourceId = p2.LovRecordSourceId	
							AND p.SourceOrganisationKey = p2.SourceOrganisationKey
							AND p.SCDactiveflag = p2.SCDactiveflag
							AND p.SCDVersion != p2.SCDVersion	
						WHERE	p.SCDActiveFlag = 'Y'
							AND p.SCDEndDate = @scdDefaultEndDate	
					PRINT 'Info: Organisation Table Loaded Successfully'; 
 

 /********************************************************************************************************************************

 8. Table Name  :	Party Role

********************************************************************************************************************************/	
	 
					PRINT 'Info: Party Role Table Serve Loading Started';
					PRINT 'Info: Inserting the new version of record if there is achange in the attribute';
						
					WITH	Stg_PartyRole AS 
						( SELECT * FROM ser.PartyRole prole
									WHERE LovRecordSourceId=@chile_lovRecordSourceID
										AND NOT EXISTS (SELECT 1 FROM ser.PartyRole AS ptyrole 
																WHERE ptyrole.PartyID = prole.PartyID
																	AND	ptyrole.LOVRoleId		  = prole.LOVRoleId 
																	AND ptyrole.PartyRoleId       = prole.PartyRoleId 
																	AND ptyrole.SourceKey         = prole.SourceKey
																	AND ptyrole.LOVRecordSourceID = prole.LOVRecordSourceID
																	AND ptyrole.ScdVersion > prole.ScdVersion
														)
						)
				
					INSERT INTO	[ser].[PartyRole] 
					(	
						PartyRoleId,
						LOVRoleId,
						PartyId,
						SourceKey,
						PartyRoleName,
						LOVRecordSourceId,
						SCDStartDate,
						SCDEndDate,
						SCDActiveFlag,
						SCDVersion,
						SCDLOVRecordSourceId,
						ETLRunLogId,
						PSARowKey
					)
					SELECT	ISNULL(pRole.partyroleid,a.PartyRoleId) PartyRoleId,
						@lovSupplierRoleId LOVRoleId,
						party.PartyId PartyId,
						t.SourceKey SourceKey,
						t.PartyRoleName PartyRoleName,
						t.LOVRecordSourceId LOVRecordSourceId,
						CASE WHEN ((ISNULL(pRole.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.date_added ASC)) = 1)
							THEN @scdDefaultStartDate
							ELSE @SCDStartDate
						END SCDStartDate,	
						LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDEndDate,
						LEAD('N', 1, 'Y') OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDActiveFlag,
						ISNULL(pRole.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.date_added ASC) SCDVersion,
						t.LOVRecordSourceId SCDLOVRecordSourceId, 
						@inpServeETLRunLogID ETLRunLogId,
						t.PSARowKey PSARowKey
					FROM
						(
							SELECT supplier_number SourceKey,
								supplier_name PartyRoleName,
								LOVRecordSourceId LOVRecordSourceId,
								date_added date_added,
								MIN(PSARowKey) PSARowKey
							FROM psa.cl_crp_product_temp intprod 
							WHERE intprod.supplier_number!='' 
								AND intprod.supplier_number IS NOT NULL
								AND  intprod.supplier_name!=''
								AND intprod.supplier_name IS NOT NULL
								AND intprod.date_added = @dateAdded
							GROUP BY supplier_number,supplier_name,LOVRecordSourceId,date_added
						)t	
					JOIN (
								SELECT supplier_number,
									LOVRecordSourceId,
									(@maxpartyRoleID+ROW_NUMBER() OVER(ORDER BY supplier_number,LOVRecordSourceId ASC)) PartyRoleId
								FROM psa.cl_crp_product_temp inp
								WHERE inp.supplier_number!='' 
									AND inp.supplier_number IS NOT NULL
									AND inp.date_added = @dateAdded
								GROUP BY supplier_number,LOVRecordSourceId
						 ) a
					ON t.SourceKey = a.supplier_number	AND t.LOVRecordSourceId = a.LOVRecordSourceId
					JOIN ser.party party
					ON t.SourceKey = party.SourceKey AND t.LOVRecordSourceId = party.LOVRecordSourceId
					LEFT JOIN Stg_PartyRole pRole
					ON pRole.PartyId = party.PartyId AND pRole.LOVRecordSourceId = t.LOVRecordSourceId
					WHERE NOT EXISTS 
						(
							SELECT  1 from ser.PartyRole serorg 
									WHERE party.partyId		  = serorg.partyId 
										AND	  pRole.LOVRoleId     = serorg.LOVRoleId  -- NEW ADDITION SUBJECT TO REVIEW
										AND	  t.SourceKey		  = serorg.SourceKey 
										AND   t.PartyRoleName     = serorg.PartyRoleName 
										AND   t.LOVRecordSourceId = serorg.LOVRecordSourceId 
										AND	  serorg.SCDActiveFlag ='Y'
						)	
		
					PRINT 'Info: PartyRole Table -> Closing off old Records if exists';				
					UPDATE ser.PartyRole set SCDActiveFlag='N',SCDEndDate = @SCDEndDate
						FROM ser.PartyRole p 
						JOIN 
							(	SELECT PartyID,
									PartyRoleId,
									LOVRoleId,
									SourceKey,
									LovRecordSourceId,
									SCDactiveflag,
									SCDVersion
								FROM ser.PartyRole t 
								WHERE   t.LOVRecordSourceID  =@chile_lovRecordSourceID
									AND t.SCDActiveFlag='Y'
									AND NOT EXISTS (
													SELECT 1 FROM ser.PartyRole AS serprle 
															WHERE serprle.PartyID = t.PartyID
																AND serprle.PartyRoleId = t.PartyRoleId
																AND serprle.LOVRoleId = t.LOVRoleId
																AND serprle.SourceKey = t.SourceKey
																AND serprle.LOVRecordSourceID = t.LOVRecordSourceID
																AND serprle.ScdVersion > t.ScdVersion
													)  
							) p2  
							ON  p.PartyID = p2.PartyID
								AND p.PartyRoleId = p2.PartyRoleId
								AND p.LOVRoleId = p2.LOVRoleId
								AND p.SourceKey = p2.SourceKey
								AND p.LovRecordSourceId = p2.LovRecordSourceId	
								AND p.SCDactiveflag = p2.SCDactiveflag
								AND p.SCDVersion != p2.SCDVersion	
							WHERE	p.SCDActiveFlag = 'Y'
								AND p.SCDEndDate = @scdDefaultEndDate	
					
					PRINT 'Info: PartyRole Table Loaded Successfully'; 
	
/********************************************************************************************************************************
 9. Table Name  :	Product Party Role
********************************************************************************************************************************/	

					PRINT 'Info: Product Party Role Table Serve Loading Started';
					PRINT 'Info: Inserting the new version of record if there is achange in the attribute';
				
					WITH Stg_src_Product  AS 
						( 
							SELECT pt.ProductID,
								pt.SourceKey,
								pt.SCDVersion,
								pt.LOVRecordSourceID,
								intprod.supplier_number,
								intprod.PSARowKey,
								intprod.date_added,
								pt.LOVSourceKeyTypeId
							FROM ser.Product pt,psa.cl_crp_product_temp intprod 
							WHERE  	pt.ProductID =intprod.productid
									AND pt.SCDActiveFlag='Y'
									AND intprod.LOVRecordSourceId=pt.LoVRecordSourceID									 
									AND intprod.date_added=@dateAdded
						)	
					,stg_Src_ProductPartyRole AS
						(
							SELECT p.productid,
								pr.partyroleid,
								pr.LOVRoleId,
								pr.sourcekey,
								p.PSARowKey,
								p.date_added,
								pr.LOvRecordSourceID
							FROM  ser.PartyRole pr
							JOIN Stg_src_Product p
							ON  pr.sourcekey=p.supplier_number 
								AND pr.LOvRecordSourceID=p.LOvRecordSourceID
								AND    p.LOVSourceKeyTypeId = @upc_sourceKeyTypeID
								AND pr.SCDActiveFlag='Y'
							LEFT JOIN[ser].[RefLOVSetInfo] rs
							ON pr.LOVRoleID=rs.lovID 
								AND rs.LOVSetName  ='Role'
								AND rs.LOVKey in ('Supplier')      
						  UNION ALL
							SELECT p.productid,pr.partyroleid,pr.LOVRoleId,pr.sourcekey ,p.PSARowKey,p.date_added,pr.LOvRecordSourceID
							FROM  ser.PartyRole pr
								JOIN Stg_src_Product p
									ON  pr.sourcekey=@sourceKey 
									AND pr.LOvRecordSourceID=p.LOvRecordSourceID
									AND pr.SCDActiveFlag='Y'
								LEFT JOIN[ser].[RefLOVSetInfo] rs
									ON pr.LOVRoleID=rs.lovID
									AND rs.LOVSetName  ='Role'
									AND rs.LOVKey in ('Retailer')
							
						)
						,stg_serve_ProductPartyRole AS 
						( 
							SELECT * FROM (
											SELECT t.*,pt.SourceKey,pr.LOVRoleId
												 FROM ser.ProductPartyRole t,stg_src_Product pt,ser.PartyRole pr
												 WHERE t.ProductID=pt.ProductID
												 AND t.PartyRoleId=pr.PartyRoleId	
												 AND t.LoVRecordSourceID=pr.LoVRecordSourceID
												 AND t.LoVRecordSourceID=pt.LoVRecordSourceID
												 AND pr.ScdActiveFlag='Y'		
										 ) a
								WHERE NOT EXISTS 
								(
									SELECT * FROM  
									(
										SELECT pdt.*,pr.LOVRoleId FROM ser.ProductPartyRole pdt,stg_src_Product pt,ser.PartyRole pr
												WHERE pdt.ProductID=pt.ProductID
													AND pdt.PartyRoleId=pr.PartyRoleId
													AND pdt.LoVRecordSourceID=pr.LoVRecordSourceID
													AND pdt.LoVRecordSourceID=pt.LoVRecordSourceID
													AND pr.ScdActiveFlag='Y'		
									) b
									WHERE a.ProductID = b.ProductID
										AND a.LOVRoleId=b.LOVRoleId
										AND a.LOVRecordSourceID=b.LOVRecordSourceID
										AND b.ScdVersion > a.ScdVersion
								)
						)																			 

					INSERT INTO ser.ProductPartyRole
						(
							ProductId,
							PartyRoleId,
							LOVRecordSourceId,
							SCDStartDate,
							SCDEndDate,          
							SCDActiveFlag,
							SCDVersion,
							SCDLOVRecordSourceId,
							ETLRunLogId,
							PSARowKey
						)
						SELECT
							p.ProductId ProductId,
							p.PartyRoleId PartyRoleId ,
							p.LOVRecordSourceId  LOVRecordSourceId,
							CASE WHEN ((ISNULL(ppr.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId ORDER BY  p.ProductID,p.date_added ASC))=1 )
								THEN	@SCDDefaultStartDate
								ELSE	@SCDStartDate
							END		SCDStartDate,								
							LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId order by p.ProductID,p.date_added) SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId  ORDER BY p.ProductID,p.date_added ASC) SCDActiveFlag,				
							ISNULL(ppr.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductId,p.LOVRoleId,p.LOVRecordSourceId ORDER BY p.ProductID,p.date_added ASC) SCDVersion,
							p.LOVRecordSourceId  SCDLOVRecordSourceId,
							@inpServeETLRunLogID ETLRunLogId,
							p.PSARowKey PSARowKey
							FROM stg_Src_ProductPartyRole p
							LEFT JOIN stg_serve_ProductPartyRole ppr 
								ON ppr.ProductId=p.ProductId 
								AND ppr.LovRecordSourceID=p.LovRecordSourceID
								AND ppr.LOVRoleId=p.LOVRoleId
							WHERE NOT EXISTS (SELECT 1 FROM ser.ProductPartyRole  pdt 
														JOIN ser.PartyRole pr 
														ON pdt.PartyRoleId=pr.PartyRoleId
															AND pdt.SCDActiveFlag='Y'
															AND pdt.SCDActiveFlag=pr.SCDActiveFlag
															AND pr.ScdActiveFlag ='Y'	
														WHERE pdt.ProductID = p.ProductID
															AND pdt.partyroleid=p.partyroleid
															AND pr.LOVRoleId=p.LOVRoleId
											 )	
																			 
				

					PRINT 'Info: ProductPartyRole Table -> Closing off old Records if exists-update 1';

					UPDATE ser.ProductPartyRole set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductPartyRole ppr 
						JOIN (
								SELECT t.productId,
									t.PartyRoleId,
									pr.LOVRoleID,
									t.SCDactiveflag,
									t.SCDVersion,
									t.LovRecordSourceId
								FROM ser.ProductPartyRole t,ser.PartyRole pr
								WHERE t.LovRecordSourceId=pr.LovRecordSourceId
									AND t.PartyRoleId=pr.PartyRoleId
									AND pr.LOVRoleId=@lovSupplierRoleId 
									AND pr.SCDActiveFlag = 'Y' 
									AND t.LOVRecordSourceID=@chile_lovRecordSourceID
									AND t.SCDactiveflag='Y' 
									AND NOT EXISTS (SELECT 1 FROM ser.ProductPartyRole AS pt ,ser.PartyRole pr
																WHERE pt.ProductID = t.ProductID
																AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																AND pt.PartyRoleId=pr.PartyRoleId
																AND pr.lovroleID=pr.LOVRoleId
																AND pr.SCDACtiveFlag ='Y'		
																AND pt.ScdVersion > t.ScdVersion
													)
							) ppr2
							 ON  ppr.productID=ppr2.productId  
								AND ppr.LovRecordSourceId=ppr2.LovRecordSourceId									   
								AND ppr.SCDactiveflag=ppr2.SCDactiveflag
								AND ppr.SCDVersion!=ppr2.SCDVersion
							 WHERE ppr.LovRecordSourceId=@chile_lovRecordSourceID
								AND ppr.SCDActiveFlag='Y'
								AND ppr.SCDEndDate =@SCDDefaultEndDate
								AND ppr.PartyRoleId NOT IN 
													(
													SELECT PartyRoleID FROM ser.PartyRole WHERE LOVRoleid=@lovRetailerRoleId 
														AND LovRecordSourceId=@chile_lovRecordSourceID
													);
					
						PRINT 'Info: ProductPartyRole Table -> Closing off old Records if exists-update 2';

					WITH stg_Src_ProductPartyRole AS 
					(
						SELECT pt.ProductID,
							pt.SourceKey,
							pt.SCDVersion,
							pt.LOVRecordSourceID,
							intprod.PSARowKey,
							intprod.date_added
						FROM ser.Product pt,psa.cl_crp_product_temp intprod 
						WHERE  pt.	ProductID=intprod.ProductID 
							AND intprod.LOVRecordSourceId=pt.LoVRecordSourceID					
							AND intprod.date_added=@dateAdded
							AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
												WHERE t.ProductID = pt.ProductID
												AND t.LOVRecordSourceID=pt.LOVRecordSourceID																									
												AND t.ScdVersion > pt.ScdVersion
											)
							AND  pt.SCDActiveFlag='N'
					)									
					UPDATE ser.ProductPartyRole set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductPartyRole pIdf 
						JOIN stg_Src_ProductPartyRole p
						   ON pidf.ProductID=p.ProductID
						   AND pidf.LoVRecordSourceID=p.LoVRecordSourceID
						   AND pIdf.ScdActiveFlag = 'Y';

			
					PRINT 'Info: ProductPartyRole Table -> Closing off old Records if exists-update 3';

					WITH stg_Src_ProductPartyRole AS 
					(
						SELECT pt.ProductID,
							pt.SourceKey,
							pt.SCDVersion,
							pt.LOVRecordSourceID,
							intprod.PSARowKey,
							intprod.date_added
						FROM ser.Product pt,psa.cl_crp_product_temp intprod 
						WHERE  pt.ProductID=intprod.ProductID
							AND intprod.LOVRecordSourceId=pt.LoVRecordSourceID
							AND intprod.date_added=@dateAdded
							AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
												WHERE t.ProductID = pt.ProductID
												AND t.LOVRecordSourceID=pt.LOVRecordSourceID																											
												AND t.ScdVersion > pt.ScdVersion
											)
							AND  (NULLIF( intprod.supplier_number,'' ) IS NULL OR  NULLIF( intprod.supplier_name,'' ) IS NULL )				
					)
					UPDATE ser.ProductPartyRole set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
						FROM ser.ProductPartyRole pIdf 
						JOIN stg_Src_ProductPartyRole p
						ON pidf.ProductID=p.ProductID AND pidf.LoVRecordSourceID=p.LoVRecordSourceID					
						JOIN ser.partyRole pr
						ON pr.partyRoleId = pidf.partyRoleId
							AND pr.LOVRoleID = @lovSupplierRoleId
							AND pr.LoVRecordSourceID=pidf.LoVRecordSourceID
							AND pr.ScdActiveFlag='Y'
						WHERE pIdf.ScdActiveFlag = 'Y';
					PRINT 'Info: ProductPartyRole Table Incremental Load Completed Successfully'; 


	
	
/********************************************************************************************************************************

Update the psa layer table with row_status as 'Loaded to Serve' once after Successful Migration

********************************************************************************************************************************/	
					PRINT 'Info: Update the psa layer table with row_status  started'; 
					UPDATE psa.cl_crp_product SET row_status = @rowStatusSERCode
						FROM psa.cl_crp_product intprod 
						INNER JOIN 	ser.Product p 
						ON p.sourcekey = ISNULL( NULLIF((Substring(intprod.item_code, Patindex('%[^0]%', intprod.item_code + ' '), Len(intprod.item_code)) ),''),0) 						
							AND p.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
							AND p.LovRecordSourceID = intprod.record_source_id
						INNER JOIN
							(
									(select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.Product WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID= @chile_lovRecordSourceID ) 	
								UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductIdentifier WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID= @chile_lovRecordSourceID) 
								UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductStatus WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID= @chile_lovRecordSourceID) 	
								UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductProperty WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID= @chile_lovRecordSourceID)
								UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductIndicator WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID= @chile_lovRecordSourceID)
								UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductGroup WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID= @chile_lovRecordSourceID)
								UNION ALL (select distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductPartyRole WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID= @chile_lovRecordSourceID)
							) temp
							ON  temp.scdLovRecordSourceID = @chile_lovRecordSourceID
							AND temp.productId=p.productID
							AND temp.psarowkey=intprod.row_id
							WHERE intprod.row_status=@rowStatusPSACode
								AND intprod.date_added=@dateAdded ;				
		
					PRINT 'Info: Update the psa layer table with row_status  in second update'; 

					UPDATE psa.cl_crp_product SET Row_Status=@rowStatusSERCode
						FROM psa.cl_crp_product intprod 
				    	INNER JOIN  ser.Product p 
				    	ON p.LovRecordSourceId = intprod.record_source_id
				    		AND p.sourcekey = ISNULL( NULLIF((Substring(intprod.item_code, Patindex('%[^0]%', intprod.item_code + ' '), Len(intprod.item_code)) ),''),0)
				    		AND p.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
				    	WHERE intprod.Row_Status=@rowStatusPSACode
				    		AND intprod.date_added =@dateAdded
				    		AND
							(
								(
								NULLIF(intprod.item_description,'') IS NULL 
								AND NULLIF(intprod.brand,'') IS NULL 
								AND NULLIF(intprod.subbrand,'') IS NULL
								)
							OR
								(  
								NULLIF(intprod.upc,'') IS NULL
								OR NULLIF(intprod.size,'') IS NULL
								OR NULLIF(intprod.width,'') IS NULL
								OR NULLIF(intprod.depth,'') IS NULL
								OR NULLIF(intprod.height,'') IS NULL
								OR NULLIF(intprod.item_status,'') IS NULL 
								OR NULLIF(intprod.supplier_name,'') IS NULL
								OR NULLIF(intprod.exclusive_flag,'') IS NULL
								OR NULLIF(intprod.own_brand_flag,'') IS NULL 
								OR NULLIF(intprod.supplier_number,'') IS NULL
								OR NULLIF(intprod.product_hierarchy1,'') IS NULL 
								OR NULLIF(intprod.product_hierarchy2,'') IS NULL 
								OR NULLIF(intprod.product_hierarchy3,'') IS NULL
								OR NULLIF(intprod.product_hierarchy4,'') IS NULL
								OR NULLIF(intprod.product_hierarchy5,'') IS NULL 
								OR NULLIF(intprod.product_hierarchy1_code,'') IS NULL 
								OR NULLIF(intprod.product_hierarchy2_code,'') IS NULL
								OR NULLIF(intprod.product_hierarchy3_code,'') IS NULL
								OR NULLIF(intprod.product_hierarchy4_code,'') IS NULL 
								OR NULLIF(intprod.product_hierarchy5_code,'') IS NULL 
								)
							);	
					PRINT 'Info: Update the psa layer table with row_status  duplicate code'; 
					UPDATE psa.cl_crp_product SET row_status=@rowStatusSERDuplicateCode
						FROM psa.cl_crp_product intprod 
						WHERE intprod.row_status=@rowStatusPSACode  AND intprod.date_added=@dateAdded 
	
					PRINT 'Info: updated row_status in Source Table ->  psa.cl_crp_product';
					PRINT '********Info: International Product PSA to Serve Load Completed Successfully********';


			SET @COUNTER = @COUNTER + 1
			END
		COMMIT TRANSACTION;
		END TRY
		BEGIN CATCH
			THROW;
			ROLLBACK TRANSACTION ;
		END CATCH
		END 
GO
/****** Object:  StoredProcedure [psa].[sp_inc_uk_mf_dwtoffer]    Script Date: 11/26/2020 8:57:48 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_uk_mf_dwtoffer') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_uk_mf_dwtoffer 
    
END
GO

CREATE PROC [psa].[sp_inc_uk_mf_dwtoffer] @tableName [Varchar](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS

/***********************************************************************************************************************
Procedure Name					: sp_inc_uk_mf_dwtoffer
Purpose							: Load Incremental data From UK Mainframe Source(uk_mf_dwoffer) into Serve Layer Table
Domain							: Product
ServeLayer Target Tables		: ProductGroup   (Total 1 Table)
RecordSourceID  for SAP MDM		: 12008
RecordSourceID  for Mainframe	: 12003
***********************************************************************************************************************
***********************************************************************************************************************
Modification History
***********************************************************************************************************************
Date         :        Description
=======================================================================================================================
12/08/2020   :    Initial Version with LMW1 Data Mapping - UKROI_Product_Incremental v1.02 
10/09/2020   :    Bugfix - The scenario "Lookup OR If null, then default to 0" not working in ProductGroup 
17/09/2020   :    Added row_status update for duplicate(not migrated) records
28/10/2020   :    Added row_status update  logic for MissingLookup Parent (not parent product exists) records
19/11/2020   :    Removed leading zero from item_code by creating a temporary table.

***********************************************************************************************************************/
/*Declaring the variables*/
DECLARE 	@mainframe_record_source_id BIGINT,
			@SCDLOVRecordSourceId BIGINT,
			@mdm_record_sourceID BIGINT,
			@LOVSourceKeyTypeId BIGINT,
			@row_status_psa BIGINT,
			@row_status_serve BIGINT,
			@row_status_duplicate BIGINT,
			@row_status_MissingParent BIGINT,
			@SCDDefaultStartDate DATETIME, 
			@SCDStartDate DATETIME,
			@SCDDefaultEndDate DATETIME,
			@SCDEndDate DATETIME,
			@max_productgroupId BIGINT,
			@COUNTER INT,
			@MAXID INT,
			@asset_id INT;
BEGIN
			SET @row_status_psa = 26001
			SET @row_status_serve = 26002
			SET @row_status_duplicate = 26010
			SET @row_status_MissingParent=26007
			SET @mainframe_record_source_id = 12003
			SET @SCDLOVRecordSourceId = 12003
			SET @mdm_record_sourceID = 12008
			SET @SCDDefaultStartDate = CONVERT(DateTime,'1900-01-01')			
			SET @SCDDefaultEndDate = CONVERT(DateTime,'9999-12-31')
			SET @LOVSourceKeyTypeId=(SELECT rs.LOVId FROM  ser.RefLOVSetInfo rs	WHERE rs.LOVKey ='SAP Article Number' and rs.LOVSetName = 'Source Key Type') 			
			SET NOCOUNT ON;

			--drop temp table if exists

			IF OBJECT_ID('psa.uk_mf_dwoffer_temp') IS NOT NULL
			BEGIN
			DROP TABLE psa.uk_mf_dwoffer_temp;
			END

			--create target temp table to remove leading zero from item_code
			CREATE TABLE psa.uk_mf_dwoffer_temp			
			WITH
			(
				DISTRIBUTION = REPLICATE,
			    CLUSTERED COLUMNSTORE INDEX
			) AS
		SELECT  row_id,
		ISNULL(NULLIF((Substring(item_code, Patindex('%[^0]%', item_code + ' '), Len(item_code))),''),0) item_code,
		item_status,item_description,item_intro_date,item_deletion_date,unit_ncp,own_brand_flag,
		business_centre_no,concept_group_no,concept_seq_no,adv_points_exempt,
		adv_redeemable_flg,merch_group_no,current_std_tisp,		offer_start_date,offer_end_date,
		ibmsnap_logmarker,product_group_no,merchandise_grp_no,merch_range,merch_sub_range,ean_code,
		etl_runlog_id,asset_id,record_source_id,row_status,created_timestamp
		from psa.uk_mf_dwoffer mfd 
		where mfd.row_status=@row_status_psa 


			IF OBJECT_ID('tempdb..#TempCurMdmProduct') IS NOT NULL
			BEGIN
				DROP table  #TempCurMdmProduct
			END	

			CREATE TABLE #TempCurMdmProduct
			WITH
			( DISTRIBUTION = ROUND_ROBIN
			)
			AS
			SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (asset_id)) AS RowID,									
									asset_id
							    FROM psa.[uk_mf_dwoffer] md							  
							   where row_status=@row_status_psa 
								   and md.record_source_id=@mainframe_record_source_id;


		   SELECT @MAXID = COUNT(*) FROM #TempCurMdmProduct
	 BEGIN TRY
	 BEGIN TRANSACTION
	 	   --Setting the counter variable for looping with asset_id
		SET @COUNTER = 1

		PRINT  'Total Number of Assets/Loops : '+cast(@MAXID as varchar)+'';

		WHILE (@COUNTER <= @MAXID)
		BEGIN
					SELECT @asset_id = asset_id from #TempCurMdmProduct where  RowID=@COUNTER;
					
					SET @max_productgroupId=(SELECT COALESCE(MAX(ProductGroupId),0)  FROM  ser.ProductGroup);

					PRINT 'Current Processing Asset: '+CAST(@asset_id as varchar)+'';

					SET @SCDStartDate= CURRENT_TIMESTAMP
					SET @SCDEndDate =DATEADD(second,-1,@SCDStartDate)

					PRINT '********Info: MDM Product DWTOFFER PSA(uk_mf_dwoffer) to Serve Load Started********';  


					PRINT 'Info: ProductGroup Table Serve Incemental  Load Started';  

					WITH Stg_Product AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID
															  FROM ser.Product pt,psa.[uk_mf_dwoffer_temp] mdmd 
															  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
																	AND	mdmd.item_code=pt.SourceKey
																	AND pt.SCDActiveFlag='Y'
																	AND mdmd.record_source_id=@mainframe_record_source_id
																	ANd pt.LoVRecordSourceID=@mdm_record_sourceID
																	AND mdmd.row_status=@row_status_psa																	
																	AND mdmd.asset_id=@asset_id 
																	  )	
					 ,Stg_serve_productGroup AS (SELECT t.*,pt.SourceKey
															  FROM ser.productGroup t,Stg_Product pt 						
																	WHERE t.ProductID=pt.ProductID									
																	AND t.LoVRecordSourceID=@mainframe_record_source_id
																	ANd pt.LoVRecordSourceID =@mdm_record_sourceID												  
																	AND NOT EXISTS (SELECT 1 FROM ser.productGroup  pdt 
																							 WHERE pdt.ProductID = t.ProductID
																							 AND pdt.LOVProductGroupSetId=t.LOVProductGroupSetId
																							 AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																							 AND  pdt.ScdVersion > t.ScdVersion))
					,Stg_src_ProductGroup AS (SELECT 
												ProductId,
												PGCol,
												(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey =''+PGValue+'' AND r.LOVSetName = ''+PGCol+'' and r.LOVRecordSourceID =@mainframe_record_source_id) LOVGroupId,
												(SELECT Distinct rs.LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''+PGCol+'' and rs.LOVRecordSourceID = @mainframe_record_source_id) LOVProductGroupSetId,
												PGValue  value ,
												ParentProductGroupId,
												@mainframe_record_source_id LOVRecordSourceId,							 
												@SCDLOVRecordSourceId SCDLOVRecordSourceId,
												ETLRunLogId,
												PSARowKey,							
												created_timestamp
												FROM
												(SELECT
													 p.ProductID
													 /* Handling Lookup OR If null, then default to 0 */
													 ,ISNULL( NULLIF(mdmd.merch_group_no,''),0)  merchandise_group_number
													 ,ISNULL( NULLIF(mdmd.business_centre_no,''),0)  business_centre_number
													 ,ISNULL( NULLIF(mdmd.concept_group_no,''),0)  concept_group_number
													 ,ISNULL( NULLIF(mdmd.concept_seq_no,''),0)   concept_seq_number					
													 ,mdmd.record_source_id LOVRecordSourceId
													 ,null ParentProductGroupId
													 ,cast (@serveETLRunLogID as bigint)  ETLRunLogId
													 ,mdmd.row_id PSARowKey,
													 mdmd.created_timestamp
												FROM psa.uk_mf_dwoffer_temp mdmd 
												INNER JOIN
												Stg_Product p 
															ON p.SourceKey =  mdmd.item_code 						
												WHERE  mdmd.row_status=@row_status_psa
												AND asset_id=@asset_id 
												) pg
												UNPIVOT  
															( PGValue FOR PGCol IN ( 
																					 pg.merchandise_group_number
																					,pg.business_centre_number
																					,pg.concept_group_number
																					,pg.concept_seq_number)
															)	AS LOVGroupId  )
													
					INSERT  INTO  ser.ProductGroup (ProductGroupId,
																		ProductId     ,
																		LOVGroupId            ,
																		LOVProductGroupSetId  ,
																		ParentProductGroupId  ,
																		LOVRecordSourceId     ,
																		SCDStartDate          ,
																		SCDEndDate            ,
																		SCDActiveFlag         ,
																		SCDVersion            ,
																		SCDLOVRecordSourceId  ,
																		ETLRunLogId,
																		PSARowKey)
												SELECT  ISNULL(spg.ProductGroupId,(PGTemp.row_num+@max_productgroupId)) as ProductGroupId,
														pgt.ProductId,
														pgt.LOVGroupId,
														pgt.LOVProductGroupSetId,
														pgt.ParentProductGroupId,
														pgt.LOVRecordSourceId,
														(CASE WHEN ISNULL(spg.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId   ORDER BY   pgt.ProductID,pgt.created_timestamp ASC)=1 THEN
														CONVERT (Datetime,@SCDDefaultStartDate)
														ELSE
														LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId  order by  pgt.ProductID,pgt.created_timestamp)
														END) as SCDStartDate,	
														LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId order by   pgt.ProductID,pgt.created_timestamp) SCDEndDate,
														LEAD('N', 1, 'Y') OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY  pgt.ProductID,pgt.created_timestamp ASC) SCDActiveFlag,				
														ISNULL(spg.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY   pgt.ProductID,pgt.created_timestamp ASC) SCDVersion,
														pgt.SCDLOVRecordSourceId  ,
														pgt.ETLRunLogId,
														pgt.PSARowKey
												FROM Stg_src_ProductGroup pgt	 
												JOIN
												(SELECT ProductID, LOVProductGroupSetId,LOVRecordSourceId,ROW_NUMBER() OVER(ORDER BY ProductID,LOVProductGroupSetId,LOVRecordSourceId ASC) row_num
														FROM Stg_src_ProductGroup   GROUP BY ProductID,LOVProductGroupSetId,LOVRecordSourceId )  PGTemp
													ON pgt.ProductID=PGTemp.ProductID
													AND pgt.LOVProductGroupSetId=PGTemp.LOVProductGroupSetId
													AND pgt.LOVRecordSourceId=PGTemp.LOVRecordSourceId
												LEFT  JOIN Stg_serve_productGroup spg
													ON pgt.productid=spg.productid
													AND pgt.LOVProductGroupSetId=spg.LOVProductGroupSetId
													AND pgt.LOVRecordSourceId=spg.LOVRecordSourceId
										WHERE NULLIF(pgt.LOVGroupId,'') IS NOT NULL
										    AND NOT EXISTS (SELECT 1 FROM ser.ProductGroup serpg where serpg.productid=pgt.productid
																							AND serpg.LOVRecordSourceId=pgt.LOVRecordSourceId
																							AND serpg.SCDActiveFlag='Y'																					
																							AND serpg.LOVProductGroupSetId=pgt.LOVProductGroupSetId																	
																							AND serpg.LOVGroupID=pgt.LOVGroupID
																							)
								
					
					 --Update the active flag and end date for older version
					PRINT 'Info: ProductGroup Table -> Closing off old Records if exists';

					UPDATE ser.ProductGroup set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
							  FROM ser.ProductGroup pg 
						  JOIN 
						   ( SELECT productId,LOVProductGroupSetId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.ProductGroup t WHERE   
									t.LOVRecordSourceID=@mainframe_record_source_id AND t.SCDactiveflag='Y'  AND NOT EXISTS (SELECT 1 FROM ser.ProductGroup AS pt 
																				WHERE pt.ProductID = t.ProductID
																				AND pt.LOVProductGroupSetId=t.LOVProductGroupSetId 
																				AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
																				AND  pt.ScdVersion > t.ScdVersion))pg2
							   ON  pg.productID=pg2.productId
							   AND pg.LovRecordSourceId=pg2.LovRecordSourceId
							   AND pg.LOVProductGroupSetId=pg2.LOVProductGroupSetId						 
							   AND pg.SCDactiveflag=pg2.SCDactiveflag
							   AND pg.SCDVersion!=pg2.SCDVersion
					WHERE pg.LovRecordSourceId in (@mainframe_record_source_id) AND
					pg.SCDActiveFlag='Y' AND   pg.SCDEndDate= @SCDDefaultEndDate ;	
			
					PRINT 'Info: ProductGroup Table -> Closing off child reords if parent becomes inactive';
					WITH Stg_Product_srcGroup AS (SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,@mainframe_record_source_id LOVRecordSourceID,mdmd.created_timestamp
														  FROM ser.Product pt,psa.uk_mf_dwoffer_temp mdmd 
														  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
																AND	mdmd.item_code=pt.SourceKey
																AND mdmd.record_source_id=@mainframe_record_source_id
																AND pt.LoVRecordSourceID=@mdm_record_sourceID													
																AND mdmd.row_status=@row_status_psa																
																AND mdmd.asset_id =@asset_id
																AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
																			WHERE t.ProductID = pt.ProductID
																			AND t.LOVRecordSourceID=pt.LOVRecordSourceID
																			AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
																			AND t.ScdVersion > pt.ScdVersion)
																AND  pt.SCDActiveFlag='N')									
					UPDATE ser.ProductGroup set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
					FROM ser.ProductGroup pidf 
					JOIN Stg_Product_srcGroup p
					   ON pidf.ProductID=p.ProductID
					   AND pidf.LoVRecordSourceID=p.LoVRecordSourceID
					   AND pidf.SCDActiveFlag='Y';
			
					PRINT 'Info: ProductGroup Table  Incremental Load Completed Successfully'; 

			
					UPDATE mdmd SET row_status=@row_status_serve 
					FROM  psa.uk_mf_dwoffer mdmd ,ser.Product p,ser.ProductGroup pg  
					WHERE ISNULL(NULLIF((Substring(mdmd.item_code, Patindex('%[^0]%', mdmd.item_code + ' '), Len(mdmd.item_code))),''),0)=p.SourceKey  
						AND p.LovRecordSourceID =@mdm_record_sourceID
						AND p.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
						AND p.ProductID=pg.ProductID
					    AND mdmd.record_source_id=pg.SCDLOvRecordSourceID
						AND mdmd.row_id=pg.psarowkey 
						AND mdmd.row_status=@row_status_psa
						AND mdmd.asset_id=@asset_id ;

					PRINT 'Info: Updated row_status to 26002 for Loaded(to serve) records'; 	
						
					WITH cte_duplicate AS(SELECT mdmd.item_code,mdmd.record_source_id,mdmd.asset_id,mdmd.row_status
                    FROM  psa.uk_mf_dwoffer mdmd ,ser.Product p,ser.ProductGroup pg
                    WHERE mdmd.item_code=p.SourceKey
                        AND p.LovRecordSourceID =@mdm_record_sourceID
                        AND p.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
                        AND p.ProductID=pg.ProductID
                        AND p.SCDActiveFlag='Y'
                        AND mdmd.record_source_id=pg.LOvRecordSourceID               
                        AND mdmd.row_status=@row_status_psa
                        AND mdmd.asset_id=@asset_id )
					UPDATE mdmd SET row_status = @row_status_duplicate 
					FROM psa.uk_mf_dwoffer mdmd join cte_duplicate C 
					ON ISNULL(NULLIF((Substring(mdmd.item_code, Patindex('%[^0]%', mdmd.item_code + ' '), Len(mdmd.item_code))),''),0) = C.item_code  
					and mdmd.asset_id=C.asset_id
					and mdmd.row_status=C.row_status

					PRINT 'Info: Updated row_status to 26010 for duplicate(not migrated) records'; 


					UPDATE mdmd SET row_status = @row_status_MissingParent 
					FROM psa.uk_mf_dwoffer mdmd 
					where mdmd.asset_id=@asset_id
					and mdmd.row_status=@row_status_psa

					PRINT 'Info: Updated row_status to 26007 for Parent missing records'; 

					PRINT '********Info: MDM Product DWTOFFER PSA(uk_mf_dwoffer) to Serve Load Completed********';  
	
				SET @COUNTER = @COUNTER + 1	;
		END
				COMMIT TRANSACTION;
				
	 END TRY
	 BEGIN CATCH     
		THROW
		ROLLBACK TRANSACTION;
	 END CATCH

	 IF OBJECT_ID('tempdb..#TempCurMdmProduct') IS NOT NULL
			BEGIN
				DROP table  #TempCurMdmProduct
			END	

	IF OBJECT_ID('psa.uk_mf_dwoffer_temp') IS NOT NULL
			BEGIN
				DROP TABLE psa.uk_mf_dwoffer_temp;
			END	
END
GO
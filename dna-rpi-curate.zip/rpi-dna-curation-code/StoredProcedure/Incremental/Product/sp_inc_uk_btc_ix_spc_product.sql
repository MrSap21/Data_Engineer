/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_ix_spc_product]    Script Date: 11/20/2020 10:10:27 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_uk_btc_ix_spc_product') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_uk_btc_ix_spc_product
END
GO

CREATE PROC [psa].[sp_inc_uk_btc_ix_spc_product] @serveETLRunLogID [varchar](max),@tableName [varchar](max),@psaEntityId [varchar](max) AS
/*
************************************************************************************************************************************************************************
Procedure Name				: sp_inc_uk_btc_ix_spc_product
Purpose						: Load Incremental weekly data From International Intactix Product in psa layer(Intactix) into Serve Layer Table
Domain						: Product
ServeLayer Target Tables	: Total 9 tables involved
							Through SP		   -> Product,ProductStatus,ProductIdentifier,ProductProperty,ProductPartyRole
							DML One Off Insert -> Measure,Party,Organization,PartyRole ( Already gone in History)
RecordSourceID  for INTACTIX : 12002
RecordSourceID for INTACTIX-ProductPartyRole : 12012
*************************************************************************************************************************************************************************
SCD Columns and Concept (CDC data is inserted with respect SCD LOGIC defined) - Applicable for parent and its child target tables
************************************************************************************************************************************************************************
***INCREMENTAL NEW RECORDS******
				productId			:	ROW_NUMBER() OVER(ORDER BY surrogate business keys)+max(productID)
				SCDStartDate        :  '1900-01-01 00:00:00'
				SCDEndDate          :  '9999-12-31 00:00:00'
				SCDActiveFlag       :  'Y'   
				SCDVersion          :   1 (Min version for new records) 
				SCDLOVRecordSourceId: 12002 
				serveETLRunLogId    : RunlogID from API passing as a parameter
*******INCREMENTAL Existing Records - UPSERT(corresponding to column value changes in Parent and Child tables)*******
a) close Existing records
				productId			: No change
				SCDStartDate        : No change
				SCDEndDate          : PROCESSING DATE-1sec
				SCDActiveFlag       : 'N'   
				SCDVersion          : No change
				SCDLOVRecordSourceId: 12002
				serveETLRunLogId    : No change
b)Insert changed records
				productId			: same as existing
				SCDStartDate        :  PROCESSING DATE
				SCDEndDate          :  '9999-12-31 00:00:00'
				SCDActiveFlag       :  'Y'   
				SCDVersion          :  Increment existing version by 1 for that product id
				SCDLOVRecordSourceId: 12002
				serveETLRunLogId    : RunlogID from API passing as a parameter
*******INCREMENTAL NULL data arrives for Existing Records- only UPDATE(parent and child tables for that productid)*******
a) close Exisitng records
				productId			: No change
				SCDStartDate        : No change
				SCDEndDate          : PROCESSING DATE-1sec
				SCDActiveFlag       : 'N'   
				SCDVersion          : No change
				SCDLOVRecordSourceId: 12002
				serveETLRunLogId    : No change

*************************************************************************************************************************************************************************
Modification History
*************************************************************************************************************************************************************************
25-June-2020  : Incorporated v1.0 mapping changes 
19-Nov-2020   : Removed leading zeros from id column
**********************************************************************************************************************************************************************
*/ 
--drop temp table if exists

IF OBJECT_ID('ser.Ixp_product_src') IS NOT NULL
BEGIN
DROP TABLE ser.Ixp_product_src;
END

--create target temp table to hold only required 8 columns out of 200+ columns
CREATE TABLE ser.Ixp_product_src
(
	[row_id] [bigint] NOT NULL,
	[upc] [nvarchar](80) NULL,			
	[id]	[nvarchar](80) NULL,		
	[name]	[nvarchar](100) NULL,
	[width]	[nvarchar](255) NULL,		
	[height]	[nvarchar](255) NULL,  
	[depth]	[nvarchar](255) NULL,   
	[brand]	[nvarchar](255) NULL,	
	[status]	[nvarchar](255) NULL,
	[etl_runlog_id] [int] NULL,
	[asset_id] [int] NULL,
	[record_source_id] [int] NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX
);




/*-------DECLARE Variables-------*/

DECLARE 
	@max_productID BIGINT,
	@LOVMeasureTypeId BIGINT,
	@LOVDataTypeId BIGINT,
	@max_measureID BIGINT, 
	@UOMId BIGINT,
	@max_PartyId BIGINT,
	@max_PartyRoleId BIGINT,
	@SCDDefaultStartDate DATETIME,
	@SCDDefaultEndDate DATETIME,
	@SCDActiveFlag char='Y',
	@SCDVersion smallint=1,
	@SCDLOVRecordSourceId BIGINT,
	@LOVRecordSourceId BIGINT=12002,
	@Sourcekey nvarchar(30),
	@PtyLOVRecordSourceId BIGINT=12012,
	@SourceOrganisationKey nvarchar(30),
	@OrganisationName nvarchar(30),
	@PartyRoleName nvarchar(30),
	@Partyid BIGINT, 
	@LOVPartyTypeId BIGINT,
	@LOVRoleId BIGINT,
	@PdctPartyRoleId BIGINT,
	@LOVSourceKeyTypeId BIGINT,
	@LOVIdentifierId BIGINT,
	@LOVProductStatusSetId BIGINT,
	@psaRowStatus BIGINT=26001,
	@serRowStatus BIGINT=26002,
	@NotMigratedRowStatus BIGINT=26010,
	@SCDStartDate DATETIME ,
	@SCDEndDate DATETIME,
	@created_timestamp DATETIME,
	@COUNTER  INT,
	@MAXID INT,
	@asset_id BIGINT;

BEGIN

  SET NOCOUNT ON;	

/*-------Derive the lookup table constant values and Set to Variables-------*/

SELECT @LOVSourceKeyTypeId		= rl.LOVId FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'SAP Article Number' AND rl.LOVSetName = 'Source Key Type'
SELECT @LOVMeasureTypeId		= rl.Lovid FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'PROD_DIM' AND rl.LOVSetName = 'Measure Type'
SELECT @LOVDataTypeId			= rl.Lovid FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'FLOAT' AND rl.LOVSetName = 'Data Type'
SELECT @UOMId					= rl.Lovid FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'Unknown' AND rl.LOVSetName = 'Unit Of Measure'
SELECT @LOVIdentifierId			= rl.LOVId FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'UPC' AND rl.LOVSetName = 'Identifier'
SELECT @LOVPartyTypeId			= rl.LOVId FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'ORG' AND rl.LOVSetName = 'Party Type'
SELECT @LOVRoleId				= rl.LOVId FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'Retailer' AND rl.LOVSetName = 'Role'
SET	   @LOVProductStatusSetId	= (SELECT DISTINCT rl.LovSetID FROM ser.RefLOVSetInfo rl WHERE rl.LOVSetName = 'Status' AND rl.LOVRecordSourceId = @LOVRecordSourceId);
SET	   @SCDDefaultStartDate		= CONVERT(DateTime,'1900-01-01')			
SET    @SCDDefaultEndDate		= CONVERT(DateTime,'9999-12-31')

--GET all cdc RECORDS from PSA TO  Temp TABLE
INSERT INTO  ser.Ixp_product_src 
		SELECT  row_id,upc,
		ISNULL(NULLIF((Substring(id, Patindex('%[^0]%', id + ' '), Len(id))),''),0),
		name,width,height,depth,brand,status,etl_runlog_id,asset_id,record_source_id,row_status,created_timestamp from psa.uk_btc_ix_spc_product ixp 
		where ixp.row_status=@psaRowStatus 

IF OBJECT_ID('tempdb..#TempCurIntxProduct') IS NOT NULL
	BEGIN
		DROP table  #TempCurIntxProduct
	END	

	CREATE TABLE #TempCurIntxProduct
	WITH
	( DISTRIBUTION = ROUND_ROBIN
	)
	AS
	SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (asset_id)) AS RowID,asset_id
						FROM ser.Ixp_product_src WHERE 
						row_status=@psaRowStatus 	;
	SELECT @MAXID = COUNT(*) FROM #TempCurIntxProduct 


BEGIN TRANSACTION
	 BEGIN TRY
	   --Setting the counter variable for looping with Asset
	 	SET @COUNTER = 1									
										
		print 'Total Number of Loops/Assets to be processed : '+CASt(@MAXID AS varchar)+'';
		WHILE (@COUNTER <= @MAXID)
		BEGIN	
			SELECT @asset_id=asset_id FROM #TempCurIntxProduct WHERE  RowID=@COUNTER;
			PRINT '##########Intactix Product PSA to Serve Load###########'; 
			PRINT 'Current ASSSET: '+CAST(@asset_id as varchar)+'';
			PRINT 'Current Loop: '+cast(@COUNTER as varchar)+'';
				SET @SCDStartDate	= CURRENT_TIMESTAMP;
				SET @SCDEndDate		= DATEADD(SECOND,-1, @SCDStartDate);
 
 
	
/********************************************************************************************************************************
 1. Table Name  :ser.product 
--********************************************************************************************************************************/

PRINT '##########Info: Intactix Product PSA to Serve Load Started###########';  
PRINT '**********Info: Product Table Serve Loading Started**********';
PRINT 'Info: Inserting the new or updated records depending on SourceKeys & its attributes';  

--Insert Product Table	

/*-------Set the MAX value of surrogate Keys to particular Variables-------*/

SET @max_productID=(SELECT COALESCE(MAX(ProductID),0) FROM  ser.product	);

WITH Stg_Product as( 
				SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag,SCDVersion,LovRecordSourceId 
					  FROM ser.product t 
					  WHERE LovRecordSourceId=@LovRecordSourceId 
							AND LOVSourceKeyTypeId=@LOVSourceKeyTypeId 
							AND NOT EXISTS (SELECT 1 FROM ser.product AS pdt 
																	WHERE pdt.ProductID = t.ProductID
																	AND pdt.LOVRecordSourceID=t.LOVRecordSourceID
																	AND pdt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																	AND  pdt.ScdVersion > t.ScdVersion))
insert into ser.product
SELECT  
			ISNULL(p.ProductID,productTemp.row_num) ProductID,
            ixp.id  SourceKey,
			@LOVSourceKeyTypeId LOVSourceKeyTypeId,
			ixp.name  ProductName,
			NULL  ProductDescription,
			rl.LOVId  LOVBrANDId,
			NULL  LOVSubBRANDId,
			ixp.record_source_id  LOVRecordSourceId,
			NULL  ParentProductId,                
			(CASE WHEN ISNULL(p.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id,ixp.created_timestamp ASC) =1 THEN
					CONVERT (Datetime,@SCDDefaultStartDate)
					ELSE
					LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY ixp.id,ixp.record_source_id order by  ixp.id,ixp.created_timestamp)
					END) as SCDStartDate,	
			LEAD(@SCDEndDate,1,@SCDDefaultEndDate)  OVER (PARTITION BY ixp.id,ixp.record_source_id order by  ixp.id,ixp.created_timestamp) SCDEndDate,
			LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id,ixp.created_timestamp ASC) SCDActiveFlag,				
			ISNULL(p.SCDVersion,0)+ ROW_NUMBER() OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id,ixp.created_timestamp ASC) SCDVersion,
			@LOVRecordSourceId SCDLOVRecordSourceId,
            CAST(@serveETLRunLogID AS INT) ETLRunLogId,
			ixp.row_id as PSARowKey
    FROM ser.Ixp_product_src ixp
		JOIN (SELECT 
			ixp.id,
			ixp.record_source_id,
			(ROW_NUMBER() OVER(ORDER BY ixp.id,ixp.record_source_id ASC)+@max_productID) row_num
			FROM ser.Ixp_product_src ixp  
			WHERE ixp.row_status=@psaRowStatus 
			AND ixp.asset_id=@asset_id
			GROUP BY ixp.id,ixp.record_source_id) productTemp 
		  ON ixp.id=productTemp.id and ixp.record_source_id=productTemp.record_source_id
		LEFT JOIN Stg_Product p 
		  ON ixp.id =p.sourcekey 
			AND ixp.record_source_id=p.LOVRecordSourceId 
			AND p.LOVSourceKeyTypeId = @LOVSourceKeyTypeId			
		LEFT JOIN  ser.RefLOVSetInfo rl 
		  ON rl.LOVSetName = 'Brand' 
			AND ixp.record_source_id=rl.LOVRecordSourceId  
			AND  rl.LOVKey = ixp.BRAND
	WHERE ixp.row_status=@psaRowStatus  
		AND  (CASE  WHEN (NULLIF(ixp.name,'' ) IS NULL AND NULLIF( ixp.brand,'' ) IS NULL)  then 0 ELSE 1 END)=1
		AND ixp.asset_id=@asset_id
		AND NOT EXISTS (select 1 from ser.product serp 
													where ixp.id =serp.SourceKey
					                                AND ixp.record_source_id=serp.LOVRecordSourceId
													AND p.LOVSourceKeyTypeId=serp.LOVSourceKeyTypeId
													AND p.SCDActiveFlag='Y'
													AND ISNULL(ixp.name,'')=ISNULL(serp.ProductName,'')
													AND ISNULL(rl.LOVId,0) = ISNULL(serp.LOVBrandId,0));
		
 
--Update the active flag and end date for older version
PRINT 'Info: product Table -> Update SCDActiveFlag & SCDEndDate and Closing off old Records if exists';

UPDATE ser.product set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
				FROM ser.product p 
				JOIN (SELECT productId,SCDactiveflag,LOVSourceKeyTypeId,SCDVersion,LovRecordSourceId FROM ser.product t WHERE   
				      t.LOVRecordSourceID=@LOVRecordSourceID AND t.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM ser.product AS pt 
																WHERE pt.ProductID = t.ProductID
																AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId																
																AND pt.ScdVersion > t.ScdVersion) )p2
					  ON  p.productID=p2.productId
					  AND p.LovRecordSourceId=p2.LovRecordSourceId						 
					  AND p.SCDactiveflag=p2.SCDactiveflag
					  AND p.SCDVersion!=p2.SCDVersion
					  AND p.LOVSourceKeyTypeId=p2.LOVSourceKeyTypeId
				JOIN  ser.Ixp_product_src ixp
					  ON ixp.record_source_id=p.LovRecordSourceId and
					  p.sourcekey = ixp.id
				WHERE p.SCDActiveFlag='Y' AND p.SCDEndDate =@scdDefaultEndDate 
					  AND ixp.row_status=@psaRowStatus 
					  AND ixp.asset_id=@asset_id;


PRINT 'Info: product Table -> Update SCDActiveFlag & SCDEndDate and Closing off old Records in Column Null cases';
UPDATE ser.product SET SCDActiveFlag= 'N',SCDEndDate =@SCDEndDate
				FROM ser.product p
				JOIN  ser.Ixp_product_src ixp
					  ON ixp.record_source_id=p.LovRecordSourceId
					  AND p.sourcekey = ixp.id
					  AND p.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
				WHERE NULLIF(ixp.name,'' ) IS NULL AND NULLIF( ixp.brand,'' ) IS NULL
					  AND p.SCDActiveFlag='Y'
					  AND ixp.asset_id=@asset_id;					
						

				PRINT 'Info: Product Table Incremental data Loaded Successfully'; 



/********************************************************************************************************************************
 2. Table Name  :ProductStatus 
	Condition: Source Status Column Value Not Null or Blank
--********************************************************************************************************************************/
 
PRINT '**********Info: ProductStatus Table Serve Loading Started**********';
PRINT 'Info: Inserting the new or updated records depending on SourceKeys & its attributes';  

--Insert Productstatus Table
 
 WITH Stg_Product as( 
				SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,ixp.status,ixp.row_id,ixp.created_timestamp,ixp.asset_id
					  FROM ser.product pt ,ser.Ixp_product_src ixp 
											  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
													AND	ixp.id=pt.SourceKey
													AND pt.SCDActiveFlag='Y'
													AND ixp.record_source_id=pt.LOVRecordSourceID
													AND ixp.row_status=@psaRowStatus
													AND ixp.asset_id=@asset_id),

 Stg_Productstatus as
	(SELECT * FROM ser.Productstatus t WHERE   
											 t.LOVRecordSourceID=@LOVRecordSourceID   
											 AND NOT EXISTS (SELECT 1 FROM ser.Productstatus AS pt 
																		WHERE pt.ProductID = t.ProductID
																		AND pt.LOVProductStatusSetId=t.LOVProductStatusSetId 
																		AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
																		AND  pt.ScdVersion > t.ScdVersion))



INSERT INTO 
	[ser].[ProductStatus](ProductId,LOVProductStatusSetId,LOVStatusId,EffectiveFROM,EffectiveTo,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)

SELECT	ProductId,LOVProductStatusSetId,LOVStatusId,EffectiveFROM,EffectiveTo,LOVRecordSourceId,SCDStartDate,
		SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
FROM (
SELECT
			p.ProductId   ProductId,
			@LOVProductStatusSetId  LOVProductStatusSetId,
			rl.LovID  LOVStatusId,
			null  EffectiveFROM,
			null EffectiveTo,
			p.LOVRecordSourceID  LOVRecordSourceId,              
			(CASE WHEN ISNULL(psdf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVProductStatusSetId ORDER BY  p.ProductID,p.created_timestamp ASC)=1 THEN
							           CONVERT (Datetime,@SCDDefaultStartDate)
										ELSE
									LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVProductStatusSetId  order by p.ProductID,p.created_timestamp)
									END) as SCDStartDate,	
			LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVProductStatusSetId order by p.ProductID,p.created_timestamp) SCDEndDate,
			LEAD('N', 1, 'Y') OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVProductStatusSetId ORDER BY  p.ProductID,p.created_timestamp ASC) SCDActiveFlag,				
			ISNULL(psdf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVProductStatusSetId ORDER BY  p.ProductID,p.created_timestamp ASC) SCDVersion,
			@LOVRecordSourceId SCDLOVRecordSourceId,
			CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
			p.row_id as PSARowKey
		FROM Stg_Product p 
		LEFT JOIN Stg_Productstatus psdf 
			ON p.productid=psdf.productid 
			AND p.LOVRecordSourceId=psdf.LOVRecordSourceId
		LEFT JOIN  ser.RefLOVSetInfo rl 
			ON rl.LOVSetName = 'Status' 
			AND rl.LOVRecordSourceId=p.LOVRecordSourceId
			AND rl.LOVKey = p.status 
		WHERE  p.status is not null AND p.status !='' ) pstat
			where NOT EXISTS (select 1 from ser.productstatus ps where ps.productid=pstat.productid
																			AND ps.LOVStatusId=pstat.LOVStatusId
																			AND ps.LOVProductStatusSetId=pstat.LOVProductStatusSetId																		
																			AND ps.LOVRecordSourceId=pstat.LOVRecordSourceId
																			AND ps.SCDActiveFlag='Y'
																			);

--Update the active flag and end date for older version
PRINT 'Info: productstatus Table -> Update SCDActiveFlag , SCDEndDate and Closing off old Records if exists';

UPDATE ser.productstatus set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
	FROM ser.productstatus psdf 
	 JOIN 
		( SELECT productId,LOVProductStatusSetId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.Productstatus t WHERE   
		t.LOVRecordSourceID=@LOVRecordSourceID AND t.SCDactiveflag='Y'  AND NOT EXISTS (SELECT 1 FROM ser.Productstatus AS pt 
													WHERE pt.ProductID = t.ProductID
													AND pt.LOVProductStatusSetId=t.LOVProductStatusSetId 
													AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
													AND  pt.ScdVersion > t.ScdVersion))psdf2
			ON  psdf.productID=psdf2.productId
			AND psdf.LovRecordSourceId=psdf2.LovRecordSourceId
			AND psdf.LOVProductStatusSetId=psdf2.LOVProductStatusSetId
			AND psdf.SCDactiveflag=psdf2.SCDactiveflag
			AND psdf.SCDVersion!=psdf2.SCDVersion
	WHERE psdf.LovRecordSourceId=@LOVRecordSourceID aND
	psdf.SCDActiveFlag='Y' AND   psdf.SCDEndDate =@SCDDefaultEndDate;				

PRINT 'Info: productstatus Table -> Update SCDActiveFlag , SCDEndDate and Closing off old Records in Status Column Null cases';
			
				
WITH Stg_Product AS 
(SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,ixp.status,ixp.row_id,ixp.created_timestamp,ixp.asset_id
			FROM ser.Product pt,ser.Ixp_product_src ixp 
			WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
				AND	ixp.id=pt.SourceKey
				AND ixp.record_source_id=pt.LoVRecordSourceID													
				AND ixp.row_status=@psaRowStatus
				AND ixp.asset_id=@asset_id
				AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
							WHERE t.ProductID = pt.ProductID
							AND t.LOVRecordSourceID=pt.LOVRecordSourceID
							AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
							AND t.ScdVersion > pt.ScdVersion)
				AND  (NULLIF( ixp.status,'' ) IS NULL OR pt.SCDActiveFlag='N'))									
UPDATE ser.Productstatus set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
FROM ser.Productstatus psdf 
JOIN Stg_Product p
	ON psdf.ProductID=p.ProductID
	AND psdf.LOVRecordSourceID=p.LOVRecordSourceID;


PRINT 'Info: ProductStatus Table Incremetal data Loaded Successfully';

/********************************************************************************************************************************
 2. Table Name  :ProductIdentifier 
	Condition: Source Status Column Value Not Null or Blank
--********************************************************************************************************************************/
 
PRINT '**********Info: ProductIdentifier Table Serve Loading Started**********';
PRINT 'Info: Inserting the new or updated records depending on SourceKeys & its attributes';  

--Insert ProductIdentifier Table
 
 WITH Stg_Product as( 
				SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,ixp.UPC,ixp.row_id,ixp.created_timestamp,ixp.asset_id
					  FROM ser.product pt ,ser.Ixp_product_src ixp 
											  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
													AND	ixp.id=pt.SourceKey
													AND pt.SCDActiveFlag='Y'
													AND ixp.record_source_id=pt.LOVRecordSourceID
													AND ixp.row_status=@psaRowStatus
													AND ixp.asset_id=@asset_id),

 Stg_ProductIdentifier as
	(SELECT productId,LOVIdentifierId,value,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.ProductIdentifier t WHERE   
											 t.LOVRecordSourceID=@LOVRecordSourceID   
											 AND NOT EXISTS (SELECT 1 FROM ser.ProductIdentifier AS pt 
																		WHERE pt.ProductID = t.ProductID
																		AND pt.LOVIdentifierId=t.LOVIdentifierId 
																		AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
																		AND  pt.ScdVersion > t.ScdVersion))

INSERT INTO [ser].[ProductIdentifier] 
	(ProductId,LOVIdentifierId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
SELECT ProductId,LOVIdentifierId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
FROM (SELECT
		p.ProductId  ProductId,
		@LOVIdentifierId  LOVIdentifierId,
		p.UPC  Value,
		p.LOVRecordSourceID  LOVRecordSourceId,              
		(CASE WHEN ISNULL(pidf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVIdentifierId ORDER BY  p.ProductID,p.created_timestamp ASC)=1 THEN
							           CONVERT (Datetime,@SCDDefaultStartDate)
										ELSE
									LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVIdentifierId  order by p.ProductID,p.created_timestamp)
									END) as SCDStartDate,	
		LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVIdentifierId order by p.ProductID,p.created_timestamp) SCDEndDate,
		LEAD('N', 1, 'Y') OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVIdentifierId ORDER BY  p.ProductID,p.created_timestamp ASC) SCDActiveFlag,				
		ISNULL(pidf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,@LOVIdentifierId ORDER BY  p.ProductID,p.created_timestamp ASC) SCDVersion,
		@LOVRecordSourceId SCDLOVRecordSourceId,
		CAST(@serveETLRunLogID AS INT)  ETLRunLogId ,
		p.row_id as PSARowKey  
		FROM Stg_Product p
		LEFT JOIN Stg_ProductIdentifier pidf on pidf.productid=p.productid and pidf.LOVRecordSourceId=p.LOVRecordSourceId
			WHERE p.upc is not null AND p.upc !='' ) ptidf
			WHERE NOT EXISTS (select 1 from ser.productidentifier pid where pid.productid=ptidf.productid
									AND pid.LOVRecordSourceId=ptidf.LOVRecordSourceId
									AND pid.LOVIdentifierId=ptidf.LOVIdentifierId
									AND pid.value=ptidf.value
									AND pid.SCDActiveFlag='Y'													
									);

--Update the active flag and end date for older version
PRINT 'Info: productidentifier Table -> Update SCDActiveFlag , SCDEndDate and Closing off old Records if exists';

UPDATE ser.productidentifier set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
	FROM ser.productidentifier pidf 
	 JOIN 
		( SELECT productId,LOVIdentifierId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.ProductIdentifier t WHERE   
		t.LOVRecordSourceID=@LOVRecordSourceID AND t.SCDactiveflag='Y'  AND NOT EXISTS (SELECT 1 FROM ser.ProductIdentifier AS pt 
													WHERE pt.ProductID = t.ProductID
													AND pt.LOVIdentifierId=t.LOVIdentifierId 
													AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
													AND  pt.ScdVersion > t.ScdVersion))pIdf2
			ON  pIdf.productID=pIdf2.productId
			AND pIdf.LovRecordSourceId=pIdf2.LovRecordSourceId
			AND pIdf.LOVIdentifierId=pIdf2.LOVIdentifierId
			AND pIdf.SCDactiveflag=pIdf2.SCDactiveflag
			AND pIdf.SCDVersion!=pIdf2.SCDVersion
	WHERE pIdf.LovRecordSourceId=@LOVRecordSourceID aND
	pIdf.SCDActiveFlag='Y' AND   pIdf.SCDEndDate =@SCDDefaultEndDate;				

				
--Update the active flag and end date for older version
PRINT 'Info: productidentifier Table -> Update SCDActiveFlag , SCDEndDate and Closing off old Records for UPC column Null case';


WITH Stg_Product AS 
(SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,ixp.UPC,ixp.row_id,ixp.created_timestamp,ixp.asset_id
			FROM ser.Product pt,ser.Ixp_product_src ixp 
			WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
				AND	ixp.id=pt.SourceKey
				AND ixp.record_source_id=pt.LoVRecordSourceID													
				AND ixp.row_status=@psaRowStatus
				AND ixp.asset_id=@asset_id
				AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
							WHERE t.ProductID = pt.ProductID
							AND t.LOVRecordSourceID=pt.LOVRecordSourceID
							AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
							AND t.ScdVersion > pt.ScdVersion)
				AND  (NULLIF( ixp.UPC,'' ) IS NULL OR pt.SCDActiveFlag='N'))									
UPDATE ser.ProductIdentifier set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
FROM ser.ProductIdentifier pIdf 
JOIN Stg_Product p
	ON pidf.ProductID=p.ProductID
	AND pidf.LOVRecordSourceID=p.LOVRecordSourceID;

				PRINT 'Info: ProductIdentifier Table Incremental Load Completed Successfully';







/********************************************************************************************************************************
4.	Table Name  :ProductProperty 
	Condition: Create/modify an entry for Height,Width,Depth against each row of the Product Data,if Height,Width,Depth resp is not
				null or not blank.
**********************************************************************************************************************************/
PRINT '***********Loading ProductProperty Table**********';  
PRINT 'INSERT New and Updated records into ProductProperty Table';  



 WITH Stg_Product as( 
				SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,ixp.height,ixp.width,ixp.depth,ixp.row_id,ixp.created_timestamp,ixp.asset_id
					  FROM ser.product pt ,ser.Ixp_product_src ixp 
											  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
													AND	ixp.id=pt.SourceKey
													AND pt.SCDActiveFlag='Y'
													AND ixp.record_source_id=pt.LOVRecordSourceID
													AND ixp.row_status=@psaRowStatus
													AND ixp.asset_id=@asset_id),
													
Stg_Productproperty as
	(SELECT productId,MeasureId,LOVUOMId,value,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.Productproperty t WHERE   
											 t.LOVRecordSourceID=@LOVRecordSourceId 
											 AND NOT EXISTS (SELECT 1 FROM ser.Productproperty AS pt 
																		WHERE pt.ProductID = t.ProductID
																		AND pt.MeasureId=t.MeasureId
																		AND pt.LOVUOMId=t.LOVUOMId
																		AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
																		AND pt.ScdVersion > t.ScdVersion))
INSERT INTO ser.ProductProperty
(ProductId,MeasureId,LOVUOMId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey) 
	
SELECT ProductId,MeasureId,LOVUOMId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
 FROM (
	SELECT 
	p.productid ProductId,
	m.MeasureId MeasureId,
	@UOMId LOVUOMId,
	p.Height Value,
	p.LOVRecordSourceID LOVRecordSourceId,                
	(CASE WHEN ISNULL(pptydf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId ORDER BY  p.ProductID,p.asset_id ASC)=1 THEN
		CONVERT (Datetime,@SCDDefaultStartDate)
		ELSE
		LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId  order by p.ProductID,p.asset_id)
		END) as SCDStartDate,	
	LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId order by p.ProductID,p.asset_id) SCDEndDate,
	LEAD('N', 1, 'Y') OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId ORDER BY  p.ProductID,p.asset_id ASC) SCDActiveFlag,				
	ISNULL(pptydf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId ORDER BY  p.ProductID,p.asset_id ASC) SCDVersion,
	@LOVRecordSourceId SCDLOVRecordSourceId,
	CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	max(p.row_id) as PSARowKey
		FROM Stg_Product p 
		LEFT JOIN Stg_Productproperty pptydf ON pptydf.productid=p.productid AND pptydf.LOVRecordSourceId=p.LOVRecordSourceId
		JOIN ser.Measure m ON p.LOVRecordSourceId = m.LOVRecordSourceId AND m.MeasureName = 'Height' 
			AND m.lovmeasuretypeid=@LOVMeasureTypeId 
			AND m.lovdatatypeid=@LOVDataTypeId
		WHERE  p.height is not null AND p.height !=''
		GROUP BY p.productid,m.MeasureId,p.Height,pptydf.SCDVersion,p.LOVRecordSourceId,p.asset_id) pptyh  --p.created_timestamp) pptyh
			WHERE NOT EXISTS (select 1 from ser.productproperty pid where pid.productid=pptyh.productid
									AND pid.LOVRecordSourceId=pptyh.LOVRecordSourceId
									AND pid.MeasureId=pptyh.MeasureId
									AND pid.LOVUOMId=pptyh.LOVUOMId
									AND pid.value=pptyh.value
									AND pid.SCDActiveFlag='Y'													
									)
			
union all
SELECT ProductId,MeasureId,LOVUOMId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
 FROM (
SELECT 
	p.productid ProductId,
	m.MeasureId MeasureId,
	@UOMId LOVUOMId,
	p.Width Value,
	p.LOVRecordSourceID LOVRecordSourceId,                
	(CASE WHEN ISNULL(pptydf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId ORDER BY  p.ProductID,p.asset_id ASC)=1 THEN
		CONVERT (Datetime,@SCDDefaultStartDate)
		ELSE
		LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId  order by p.ProductID,p.asset_id)
		END) as SCDStartDate,	
	LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId order by p.ProductID,p.asset_id) SCDEndDate,
	LEAD('N', 1, 'Y') OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId ORDER BY  p.ProductID,p.asset_id ASC) SCDActiveFlag,				
	ISNULL(pptydf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId ORDER BY  p.ProductID,p.asset_id ASC) SCDVersion,
	@LOVRecordSourceId SCDLOVRecordSourceId,
	CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	max(p.row_id) as PSARowKey
		FROM Stg_Product p 
		LEFT JOIN Stg_Productproperty pptydf ON pptydf.productid=p.productid AND pptydf.LOVRecordSourceId=p.LOVRecordSourceId
		JOIN ser.Measure m ON p.LOVRecordSourceId = m.LOVRecordSourceId AND m.MeasureName = 'Width' 
			AND m.lovmeasuretypeid=@LOVMeasureTypeId 
			AND m.lovdatatypeid=@LOVDataTypeId
		WHERE  p.Width is not null AND p.Width !=''
		GROUP BY p.productid,m.MeasureId,p.Width,pptydf.SCDVersion,p.LOVRecordSourceId,p.asset_id) pptyw --p.created_timestamp ) pptyw
			WHERE NOT EXISTS (select 1 from ser.productproperty pid where pid.productid=pptyw.productid
									AND pid.LOVRecordSourceId=pptyw.LOVRecordSourceId
									AND pid.MeasureId=pptyw.MeasureId
									AND pid.LOVUOMId=pptyw.LOVUOMId
									AND pid.value=pptyw.value
									AND pid.SCDActiveFlag='Y'													
									)
			
union all
SELECT ProductId,MeasureId,LOVUOMId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
 FROM (
SELECT 
	p.productid ProductId,
	m.MeasureId MeasureId,
	@UOMId LOVUOMId,
	p.Depth Value,
	p.LOVRecordSourceID LOVRecordSourceId,                
	(CASE WHEN ISNULL(pptydf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId ORDER BY  p.ProductID,p.asset_id ASC)=1 THEN
		CONVERT (Datetime,@SCDDefaultStartDate)
		ELSE
		LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId  order by p.ProductID,p.asset_id)
		END) as SCDStartDate,	
	LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId order by p.ProductID,p.asset_id) SCDEndDate,
	LEAD('N', 1, 'Y') OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId ORDER BY  p.ProductID,p.asset_id ASC) SCDActiveFlag,				
	ISNULL(pptydf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,m.measureid,@UOMId ORDER BY  p.ProductID,p.asset_id ASC) SCDVersion,
	@LOVRecordSourceId SCDLOVRecordSourceId,
	CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	max(p.row_id) as PSARowKey
		FROM Stg_Product p 
		LEFT JOIN Stg_Productproperty pptydf ON pptydf.productid=p.productid AND pptydf.LOVRecordSourceId=p.LOVRecordSourceId
		JOIN ser.Measure m ON p.LOVRecordSourceId = m.LOVRecordSourceId AND m.MeasureName = 'Depth' 
			AND m.lovmeasuretypeid=@LOVMeasureTypeId 
			AND m.lovdatatypeid=@LOVDataTypeId
		WHERE  p.Depth is not null AND p.Depth !=''
		GROUP BY p.productid,m.MeasureId,p.depth,pptydf.SCDVersion,p.LOVRecordSourceId,p.asset_id) pptyd --p.created_timestamp ) pptyd
			WHERE NOT EXISTS (select 1 from ser.productproperty pid where pid.productid=pptyd.productid
									AND pid.LOVRecordSourceId=pptyd.LOVRecordSourceId
									AND pid.MeasureId=pptyd.MeasureId
									AND pid.LOVUOMId=pptyd.LOVUOMId
									AND pid.value=pptyd.value
									AND pid.SCDActiveFlag='Y'													
									)
			
			
			


--Update the active flag and end date for older version
PRINT 'Info: productproperty Table -> Update SCDActiveFlag , SCDEndDate and Closing off old Records if exists';

UPDATE ser.ProductProperty set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
	FROM ser.ProductProperty pptydf 
	 JOIN 
		( SELECT productId,MeasureId,LOVUOMId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.ProductProperty t WHERE   
		t.LOVRecordSourceID=@LOVRecordSourceID AND t.SCDactiveflag='Y'  AND NOT EXISTS (SELECT 1 FROM ser.ProductProperty AS pt 
													WHERE pt.ProductID = t.ProductID
													AND pt.Measureid=t.Measureid
													AND pt.LOVUOMId=t.LOVUOMId 
													AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
													AND pt.ScdVersion > t.ScdVersion))pptydf2
			ON  pptydf.productID=pptydf2.productId
			AND pptydf.LovRecordSourceId=pptydf2.LovRecordSourceId
			AND pptydf.Measureid=pptydf2.Measureid
			AND pptydf.LOVUOMId=pptydf2.LOVUOMId 
			AND pptydf.SCDactiveflag=pptydf2.SCDactiveflag
			AND pptydf.SCDVersion!=pptydf2.SCDVersion
	WHERE pptydf.LovRecordSourceId=@LOVRecordSourceID AND
	pptydf.SCDActiveFlag='Y' AND   pptydf.SCDEndDate =@SCDDefaultEndDate;	

--Update the active flag and end date for older version
PRINT 'Info: productproperty Table -> Update SCDActiveFlag , SCDEndDate and Closing off old Records for respective height,width,depth columns Null case';

	UPDATE ser.Productproperty SET SCDActiveFlag= 'N', SCDEndDate = @SCDEndDate
								FROM ser.Productproperty ppty
								JOIN (	SELECT productId,SourceKey,LOVSourceKeyTypeId,SCDactiveflag, SCDVersion,LovRecordSourceId FROM ser.Product t WHERE   
											t.LOVRecordSourceID=@LOVrecordSourceId
														AND NOT EXISTS (SELECT 1 FROM ser.Product AS pt 
																				  WHERE pt.ProductID		 =t.ProductID
																					AND pt.LOVRecordSourceID =t.LOVRecordSourceID
																					AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
																					AND pt.ScdVersion > t.ScdVersion)) p2
									ON 	ppty.productID=p2.productId AND ppty.LovRecordSourceId=p2.LovRecordSourceId	
								JOIN (select	
										ixp.id id,
										m.measureid Measureid,
										@UOMID	LOVUOMId,
										ixp.Height Value,
										ixp.record_source_id record_source_id,
										ixp.row_status row_status,
										ixp.etl_runlog_id etl_runlog_id,
										ixp.created_timestamp created_timestamp,
										ixp.asset_id
										from ser.Ixp_product_src ixp 
										join ser.measure m ON ixp.record_source_id = m.LOVRecordSourceId 
														AND m.MeasureName = 'Height' 
														AND m.lovmeasuretypeid=@LOVMeasureTypeId 
														AND m.lovdatatypeid=@LOVDataTypeId
										where ixp.row_status=@psaRowStatus
											AND ixp.asset_id=@asset_id
									
									union all
									select
										ixp.id id,
										m.measureid Measureid,
										@UOMID	LOVUOMId,
										ixp.Width Value,
										ixp.record_source_id record_source_id,
										ixp.row_status row_status,
										ixp.etl_runlog_id etl_runlog_id,
										ixp.created_timestamp created_timestamp,
										ixp.asset_id
										from ser.Ixp_product_src ixp 
										join ser.measure m ON ixp.record_source_id = m.LOVRecordSourceId 
														AND m.MeasureName = 'Width' 
														AND m.lovmeasuretypeid=@LOVMeasureTypeId 
														AND m.lovdatatypeid=@LOVDataTypeId
										where ixp.row_status=@psaRowStatus
											AND ixp.asset_id=@asset_id
									union all
									select
										ixp.id id,
										m.measureid Measureid,
										@UOMID	LOVUOMId,
										ixp.Depth Value,
										ixp.record_source_id record_source_id,
										ixp.row_status row_status,
										ixp.etl_runlog_id etl_runlog_id,
										ixp.created_timestamp created_timestamp,
										ixp.asset_id
										from ser.Ixp_product_src ixp 
										join ser.measure m ON ixp.record_source_id = m.LOVRecordSourceId 
														AND m.MeasureName = 'Depth' 
														AND m.lovmeasuretypeid=@LOVMeasureTypeId 
														AND m.lovdatatypeid=@LOVDataTypeId
										where ixp.row_status=@psaRowStatus
											AND ixp.asset_id=@asset_id
										) srcppty
									ON srcppty.record_source_id=p2.LovRecordSourceId 
									AND p2.sourcekey = srcppty.id
									AND p2.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
								WHERE	( NULLIF(srcppty.value,'' ) IS NULL OR p2.SCDActiveFlag='N') 
									AND ppty.Measureid = srcppty.Measureid
									AND ppty.LOVUOMId = srcppty.LOVUOMId
									AND ppty.SCDActiveFlag='Y'
									AND srcppty.row_status=@psaRowStatus
										AND srcppty.asset_id=@asset_id;


PRINT 'Info: ProductProperty Table Incremental Data Loaded Successfully';  

/********************************************************************************************************************************
5.	Table Name  :ProductPartyRole 
	Condition: Link Retailer Party with Product.(PSASourceTable ID and Recordsourceid matches with that of product table)
**********************************************************************************************************************************/
PRINT '**********Info: ProductPartyRole Table Serve Loading Started**********';
PRINT 'Info: Inserting the new or updated records depending on SourceKeys & its attributes';  


select @PdctPartyRoleId = ptr.PartyRoleId from ser.PartyRole ptr join ser.party pty on ptr.partyid = pty.partyid where ptr.lovrecordsourceid=12012 and ptr.LOVRoleId = @LOVRoleId;


 
 WITH Stg_Product as( 
				SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,ixp.row_id,ixp.created_timestamp,ixp.asset_id
					  FROM ser.product pt ,ser.Ixp_product_src ixp 
											  WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
													AND	ixp.id=pt.SourceKey
													AND pt.SCDActiveFlag='Y'
													AND ixp.record_source_id=pt.LOVRecordSourceID
													AND ixp.row_status=@psaRowStatus
													AND ixp.asset_id=@asset_id),

 Stg_Productpartyrole as
	(SELECT productId,PartyRoleId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.Productpartyrole t WHERE   
											 t.LOVRecordSourceID=@PtyLOVRecordSourceId  
											 AND NOT EXISTS (SELECT 1 FROM ser.Productpartyrole AS pt 
																		WHERE pt.ProductID = t.ProductID
																		AND pt.PartyRoleId=t.PartyRoleId 
																		AND pt.LOVRecordSourceID=t.LOVRecordSourceID 
																		AND  pt.ScdVersion > t.ScdVersion))
INSERT INTO ser.Productpartyrole (ProductId,PartyRoleId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
SELECT ProductId,PartyRoleId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
FROM(
SELECT 
	p.ProductId	ProductId,
	@PdctPartyRoleId  PartyRoleId,
	@PtyLOVRecordSourceId  LOVRecordSourceId,                
	(CASE WHEN ISNULL(pprdf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,@PdctPartyRoleId ORDER BY  p.ProductID,p.created_timestamp ASC)=1 THEN
							           CONVERT (Datetime,@SCDDefaultStartDate)
										ELSE
									LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,@PdctPartyRoleId  order by p.ProductID,p.created_timestamp)
									END) as SCDStartDate,	
	LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY p.ProductID,p.Lovrecordsourceid,@PdctPartyRoleId order by p.ProductID,p.created_timestamp) SCDEndDate,
	LEAD('N', 1, 'Y') OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,@PdctPartyRoleId ORDER BY  p.ProductID,p.created_timestamp ASC) SCDActiveFlag,				
	ISNULL(pprdf.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY p.ProductID,p.Lovrecordsourceid,@PdctPartyRoleId ORDER BY  p.ProductID,p.created_timestamp ASC) SCDVersion,
	@PtyLOVRecordSourceId SCDLOVRecordSourceId,
	CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	p.row_id as PSARowKey
	FROM Stg_Product p  
	LEFT JOIN Stg_Productpartyrole pprdf
		on pprdf.productid=p.productid and p.LOVRecordSourceId=@LOVRecordSourceId and pprdf.LOVRecordSourceId=@PtyLOVRecordSourceId
		) pdpr
		WHERE NOT EXISTS (select 1 from ser.productpartyrole pr where pr.productid=pdpr.productid
																	AND pr.PartyRoleId=pdpr.PartyRoleId
																	AND pr.LOVRecordSourceId=pdpr.LOVRecordSourceId
																	AND pr.SCDActiveFlag='Y'
																	);


--Update the active flag and end date for older version
PRINT 'Info: Update Productpartyrole Table -> Closing off Null Records/Updating existing Null records in line with product table';

WITH Stg_Product AS 
(SELECT pt.ProductID,pt.SourceKey,pt.SCDVersion,pt.LOVRecordSourceID,ixp.row_id,ixp.created_timestamp,ixp.asset_id
			FROM ser.Product pt,ser.Ixp_product_src ixp 
			WHERE  pt.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
				AND	ixp.id=pt.SourceKey
				AND ixp.record_source_id=pt.LoVRecordSourceID													
				AND ixp.row_status=@psaRowStatus
				AND ixp.asset_id=@asset_id
				AND NOT EXISTS (SELECT 1 FROM ser.Product AS t 
							WHERE t.ProductID = pt.ProductID
							AND t.LOVRecordSourceID=pt.LOVRecordSourceID
							AND t.LOVSourceKeyTypeId=pt.LOVSourceKeyTypeId																
							AND t.ScdVersion > pt.ScdVersion)
				AND  pt.SCDActiveFlag='N')									
UPDATE ser.Productpartyrole set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
		FROM ser.Productpartyrole pprdf 
		JOIN Stg_Product p
		ON pprdf.ProductID=p.ProductID
		AND pprdf.LoVRecordSourceID=@PtyLoVRecordSourceID
		AND p.LoVRecordSourceID=@LoVRecordSourceID;

PRINT 'Info: ProductPartyrole Table Incremental Load Completed Successfully';

/********************************************************************************************************************************
6.	Update Source Table  :psa.uk_btc_ix_spc_product 
	Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
**********************************************************************************************************************************/
PRINT '********************Updating Source Table as LoadedToServe Status -> psa.uk_btc_ix_spc_product****************';  

	UPDATE psa.uk_btc_ix_spc_product
	SET row_status=@serRowStatus
	FROM psa.uk_btc_ix_spc_product ixp
	INNER JOIN
	ser.Product p 
		ON ISNULL(NULLIF((Substring(ixp.id, Patindex('%[^0]%', ixp.id + ' '), Len(ixp.id))),''),0) =p.sourcekey
		AND  ixp.record_source_id=p.LovRecordSourceID
		AND  LOVSourceKeyTypeId=@LOVSourceKeyTypeId 
	INNER JOIN
	((SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.Product WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@LOVRecordsourceID) 	
	UNION ALL (SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductStatus  WHERE SCDACTiveFlag='Y'AND LOVRecordsourceID=@LOVRecordsourceID) 									
	UNION ALL  (SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductIdentifier WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@LOVRecordsourceID) 									
	UNION ALL  (SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductPartyRole  WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@LOVRecordsourceID)
	UNION ALL  (SELECT distinct productID ,SCDLovRecordSourceID ,psarowkey FROM ser.ProductProperty  WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@LOVRecordsourceID) 									     
	) temp
			ON  temp.scdLovRecordSourceID = @LovRecordSourceID
			AND temp.productId=p.productID							
			AND temp.psarowkey=ixp.row_id
	WHERE ixp.Row_Status=@psaRowStatus 
			AND ixp.asset_id=@asset_id 




	UPDATE psa.uk_btc_ix_spc_product
	SET row_status=@serRowStatus
	FROM psa.uk_btc_ix_spc_product ixp
	INNER JOIN
	ser.Product p 
		ON ixp.record_source_id=p.LovRecordSourceID
		AND ISNULL(NULLIF((Substring(ixp.id, Patindex('%[^0]%', ixp.id + ' '), Len(ixp.id))),''),0) =p.sourcekey
		AND  LOVSourceKeyTypeId=@LOVSourceKeyTypeId
	WHERE 
		ixp.row_status=@psaRowStatus 
		AND ixp.asset_id=@asset_id		
		AND (
			(NULLIF(ixp.name,'' ) IS NULL AND NULLIF( ixp.brand,'' ) IS NULL) 
			OR 
			(NULLIF(ixp.status,'') IS NULL 
				OR NULLIF(ixp.UPC,'') IS NULL 
				OR NULLIF(ixp.Height,'') IS NULL 
				OR NULLIF(ixp.Width,'') IS NULL  
				OR NULLIF(ixp.Depth,'') IS NULL)
			);

	--Update NotProcessed rowstatus '26010' for all other rows whose status is psa rowstatus 26001
	UPDATE psa.uk_btc_ix_spc_product
	SET row_status=@NotMigratedRowStatus
	FROM psa.uk_btc_ix_spc_product ixp
	WHERE 
		ixp.row_status=@psaRowStatus 
		AND ixp.asset_id=@asset_id		
						

		PRINT 'Info: Source Table Updated accordingly -> psa.uk_btc_ix_spc_product'; 
	
PRINT '###########################Info: Incremental Data Load Completed Successfully for Parent and Child Tables for ASSSET: '+CAST(@asset_id as varchar)+'####################'; 
		

SET @COUNTER = @COUNTER + 1
	
		END
		
				COMMIT TRANSACTION;
			
	 END TRY
	 BEGIN CATCH     
		THROW
		ROLLBACK TRANSACTION;
	 END CATCH
PRINT 'Info: Dropping Temp table ....... ser.Ixp_product_src';
DROP table [ser].[Ixp_product_src]
PRINT 'Info: Dropped Temp table -> ser.Ixp_product_src';
END
GO
/****** Object:  UserDefinedFunction [psa].[fn_GetDQSelect]    Script Date: 8/27/2020 8:28:05 PM ******/
IF OBJECT_ID('psa.validateNULL') IS NOT NULL
BEGIN
	DROP FUNCTION [psa].[validateNULL]
END;
GO
/****** Object:  UserDefinedFunction [psa].[validateNULL]    Script Date: 28/08/2020 13:05:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [psa].[validateNULL] (@ValidationVar [VARCHAR](MAX)) RETURNS VARCHAR(MAX)
AS
BEGIN
RETURN Case When @ValidationVar is NULL OR len(@ValidationVar)=0 OR @ValidationVar='-' OR @ValidationVar='NULL' OR @ValidationVar='\N'
THEN NULL ELSE @ValidationVar END
END
GO
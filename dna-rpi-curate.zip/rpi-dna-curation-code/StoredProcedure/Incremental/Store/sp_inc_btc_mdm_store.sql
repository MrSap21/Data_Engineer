/****** Object:  StoredProcedure [psa].[sp_inc_btc_mdm_store]    Script Date: 11/20/2020 10:09:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_btc_mdm_store') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_btc_mdm_store
   
END
GO

CREATE PROC [psa].[sp_inc_btc_mdm_store] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS

IF OBJECT_ID('psa.uk_btc_mdm_store_stg') IS NOT NULL
BEGIN
DROP TABLE psa.uk_btc_mdm_store_stg;
END

IF OBJECT_ID('ser.PartyRole_mdm_tempg_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PartyRole_mdm_tempg_STG;
END

IF OBJECT_ID('ser.Organisation_mdm_tempg_STG') IS NOT NULL
BEGIN
DROP TABLE ser.Organisation_mdm_tempg_STG;
END

IF OBJECT_ID('ser.PartyRoleSiteRoleRelationship_mdm_tempg_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PartyRoleSiteRoleRelationship_mdm_tempg_STG;
END

IF OBJECT_ID('ser.SiteRoleProperty_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleProperty_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.PostalAddress_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PostalAddress_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.PostalAddress_SiteProperty_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PostalAddress_SiteProperty_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleContactMethod_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleContactMethod_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleTerritory_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleTerritory_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleGrp_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleGrp_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleIndicator_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleIndicator_STG;
END


--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleStatus_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleStatus_STG;
END
--drop temp table if exists
IF OBJECT_ID('tempdb..#TempCurMdmStore') IS NOT NULL
BEGIN
	DROP table  #TempCurMdmStore
END

-----------------------------------------------creating temp tables------------------------------------------------------
Print 'Info: Creating all necessary Temp Tables ';
--temp table
CREATE TABLE [ser].[PartyRole_mdm_tempg_STG]
(
	[ExistsFlag] [int] NULL,
	[PartyRoleId] [bigint] NOT NULL,
	[LOVRoleId] [int] NOT NULL,
	[PartyId] [bigint] NOT NULL,
	[SourceKey] [varchar](80) NULL,
	[PartyRoleName] [varchar](80) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [char](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[row_id] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)



CREATE TABLE [ser].[Organisation_mdm_tempg_STG]
(
	[ExistsFlag] [int] NULL,
	[PartyId] [bigint] NOT NULL,
	[SourceOrganisationKey] [nvarchar](80) NULL,
	[OrganisationName] [nvarchar](80) NULL,
	[ParentPartyId] [bigint] NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[row_id] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)

CREATE TABLE ser.[PartyRoleSiteRoleRelationship_mdm_tempg_STG](
    [ExistsFlag] int null,
    [PartyRoleId]            bigint       NULL,
    [SiteRoleId]             bigint       NULL,
    [LOVRelationshipTypeId]  int          NULL,
    [EffectiveFrom]          datetime    NULL,
    [EffectiveTo]            datetime    NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          nchar(1)    NULL,
    [SCDVersion]             smallint    NULL,
    [SCDLOVRecordSourceId]   int         NULL,
    [ETLRunLogId]            int         NULL,
    [row_id]                 bigint      NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)

CREATE TABLE [ser].[SiteRoleProperty_STG](
        [ExistsFlag] int null,
    [SiteRoleId]            bigint            NULL,
    [MeasureId]             int               NULL,
    [LOVUOMId]              int               NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  bigint           NULL,
    [ETLRunLogId]           int              NULL,
    [row_id]             bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)


--temp table
CREATE TABLE [ser].[PostalAddress_STG](
    [SiteId]                bigint          NULL,
    [LocationName]          nvarchar(80)    NULL,
    [AddressLine1]          nvarchar(255)    NULL,
    [AddressLine2]          nvarchar(255)    NULL,
    [Town]                  nvarchar(80)    NULL,
    [County]                nvarchar(80)    NULL,
    [PostalCode]            nvarchar(10)    NULL,
	[z_grid_reference_northing]              nvarchar(255)    NULL,
	[z_grid_reference_easting]               nvarchar(255)    NULL,
	[z_grid_reference_latitude]              nvarchar(255)    NULL,
	[z_grid_reference_longitude]              nvarchar(255)   NULL,
	[recordsourceId]            int Null
    )
WITH
(
    DISTRIBUTION = ROUND_ROBIN,
    HEAP
)

--temp table
CREATE TABLE [ser].[PostalAddress_SiteProperty_STG](
    [SiteId]                bigint          NULL,
    [AddressLine1]          nvarchar(255)    NULL,
    [AddressLine2]          nvarchar(255)    NULL,
    [Town]                  nvarchar(80)    NULL,
    [County]                nvarchar(80)    NULL,
    [PostalCode]            nvarchar(10)    NULL,
	[z_grid_reference_northing]              nvarchar(255)    NULL,
	[z_grid_reference_easting]               nvarchar(255)    NULL,
	[z_grid_reference_latitude]              nvarchar(255)    NULL,
	[z_grid_reference_longitude]              nvarchar(255)   NULL,
	[LOVCountryId]              int Null,
	[EtlRunlogId]               int null,
	[PsaRowKey] bigint null,
	[recordsourceId] int null
	)
WITH
(
    DISTRIBUTION = ROUND_ROBIN,
    HEAP
)

--temp table
CREATE TABLE ser.[SiteRoleContactMethod_STG](
    [ExistsFlag] int null,
    [SiteRoleId]              bigint            NULL,
    [LOVContactMethodTypeId]  int               NULL,
    [LOVUsageTypeId]          int               NULL,
    [ContactDetail]           nvarchar(255)    NULL,
    [LOVRecordSourceId]       int              NULL,
    [SCDStartDate]            datetime         NULL,
    [SCDEndDate]              datetime         NULL,
    [SCDActiveFlag]           nchar(1)         NULL,
    [SCDVersion]              smallint         NULL,
    [SCDLOVRecordSourceId]    int              NULL,
    [ETLRunLogId]             int              NULL,
    [row_id]               bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)

--temp table 
CREATE TABLE ser.[SiteRoleTerritory_STG](
     [ExistsFlag] int null,
    [SiteRoleId]                 bigint       NULL,
    [LOVSiteRoleTerritorySetId]  int          NULL,
    [LOVTerritoryId]             int          NULL,
    [LOVRecordSourceId]          int          NULL,
    [SCDStartDate]               datetime    NULL,
    [SCDEndDate]                 datetime    NULL,
    [SCDActiveFlag]              nchar(1)    NULL,
    [SCDVersion]                 smallint    NULL,
    [SCDLOVRecordSourceId]       int         NULL,
    [ETLRunLogId]                int         NULL,
    [row_id]                  bigint      NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)

CREATE TABLE [ser].[SiteRoleGrp_STG](
    [ExistsFlag]             int         NULL,
    [SiteRoleGroupId]        bigint      NULL,
    [SiteRoleId]             bigint      NOT NULL,
    [LOVSiteRoleGroupSetId]  int         NULL,
    [LOVGroupId]             int         NULL,
    [ParentSiteRoleGroupId]  bigint      NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          nchar(1)    NULL,
    [SCDVersion]             smallint    NULL,
    [SCDLOVRecordSourceId]   int         NULL,
    [ETLRunLogId]            int         NULL,
    [row_id]                 bigint      NULL 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)
--temp table
 CREATE TABLE [ser].[SiteRoleIndicator_STG](
    [ExistsFlag] int null,		 
    [SiteRoleId]            bigint       NULL,
    [LOVIndicatorId]        int          NULL,
    [Value]                 nchar(1)    NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [row_id]             bigint      NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)

--temp table
CREATE TABLE [ser].[SiteRoleStatus_STG](
    [ExistsFlag] int null,
    [SiteRoleId]              bigint       NULL,
    [LOVSiteRoleStatusSetId]  int          NULL,
    [LOVStatusId]             int          NULL,
    [EffectiveFrom]           datetime    NULL,
    [EffectiveTo]             datetime    NULL,
    [LOVRecordSourceId]       int         NOT NULL,
    [SCDStartDate]            datetime    NULL,
    [SCDEndDate]              datetime    NULL,
    [SCDActiveFlag]           nchar(1)    NULL,
    [SCDVersion]              smallint    NULL,
    [SCDLOVRecordSourceId]    int         NULL,
    [ETLRunLogId]             int         NULL,
    [row_id]                  bigint      NULL,
	[store_status]            nvarchar(255)    NULL,
	[store_open_status]       nvarchar(255)    NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)



Print 'Info: All necessary Temp Tables created Successfully';
/***declare variables***/
DECLARE @website_type_id int,
@physical_store_type_id int,
@role_id int,
--@party_type_id int ,
@record_source_id int,
@site_role_status_id int,
@party_relationship_type int,
@max_siteId int,
@max_partyId int,
@max_site_role_id int ,
@max_party_id int,
@max_party_role_id int,
@max_measure_id int,
@MAXSRGpID int,
@max_siterole_group_id int,
@PostalLOVRecordSourceId int,
@maxpostalsite_id int,
@row_status int =26001,
@serRowStatus int =26002,
@row_status_notmigrated int = 26010,
@SCDStartDate datetime,
@SCDStartDate_new datetime=CONVERT(DATETIME,'19000101'),
@SCDEndDate datetime=CONVERT(DATETIME,'99991231'),
@SCDLOVRecordSourceId Varchar(100)= '12008',
@PartyTypeId int,
@MAXPartyId int,
@role_id_partyrole_sorg int,
@role_id_partyrole int,
@role_id_partyrole_health int,
@MAXPartyRoleId int,
@party_relationship_type_of int,
@party_relationship_type_aw int,
@contact_method_type_id int,
@usage_type_id int,
@setid_area_number int ,
@setid_nhs_market int ,
@OpenStatus int, 
@LOVSiteRoleStatusSetId_status int,
@LOVSiteRoleStatusSetId_floor int,
@LOVSiteRoleStatusSetId_nonf_ifl int,
@LOVSiteRoleStatusSetId_pharmacy int,
@uom_idm2 int,
@uom_idunit int,
@uom_id_degree int,
@uom_id_m int,
@data_type_id int,
@data_type_double_id int,
@data_type_int_id int,
@measure_type_id int,
@measure_type_geocode_id int,
@easting_measureId int,
@northing_measureId int,
@latitude_measureId int,
@longitude_measureId int,
@COUNTER INT,
@MAXID INT,
@created_timestamp DATETIME,
@NULLSiteId int,
@assetId int;

BEGIN



SET @PostalLOVRecordSourceId=12012
SET @record_source_id =12008


/*-------Derive the lookup table constant values and Set to Variables-------*/
--SELECT @website_type_id=r.LOVId from [ser].[RefLOVSetInfo] r where r.LOVKey='WEBSITE' and r.LOVSetName='Site Type' 

SELECT @physical_store_type_id=LOVId from ser.[RefLOVSetInfo]   where LOVKey='POSTAL ADDRESS' 
and LOVSetName='Site Type' AND lovrecordSourceId=@PostalLOVRecordSourceId

SELECT @role_id=LOVId from ser.[RefLOVSetInfo]   where LOVKey='Store' and LOVSetName='Role'

--SELECT @data_type_id=LOVId from ser.[RefLOVSetInfo]  where LOVKey='STRING' and LOVSetName='Data Type' 


SELECT @measure_type_geocode_id=LOVId from ser.[RefLOVSetInfo]  where LOVKey='GEOCODE' and LOVSetName='Measure Type' 


SELECT  @data_type_double_id=LOVId from ser.[RefLOVSetInfo]  where LOVKey='DOUBLE' and LOVSetName='Data Type' 


SELECT @data_type_int_id=LOVId from ser.[RefLOVSetInfo]  where LOVKey='INT' and LOVSetName='Data Type' 


--SELECT @measure_type_id=LOVId from ser.[RefLOVSetInfo]  where LOVKey='FLOOR_AREA' and LOVSetName='Measure Type' 

SELECT @longitude_measureId= MeasureId from ser.Measure where MeasureName = 'z_grid_reference_longitude' AND LOVRecordSourceId = @record_source_id 
and LOVDatatypeId = @data_type_double_id and LovMeasureTypeId = @measure_type_geocode_id and SCDActiveFlag = 'Y'

SELECT  @latitude_measureId=MeasureId from ser.Measure where MeasureName = 'z_grid_reference_latitude' AND LOVRecordSourceId = @record_source_id 
and LOVDatatypeId = @data_type_double_id and LovMeasureTypeId = @measure_type_geocode_id and SCDActiveFlag = 'Y'


SELECT  @easting_measureId=MeasureId from ser.Measure where MeasureName = 'z_grid_reference_easting' AND LOVRecordSourceId = @record_source_id 
and LOVDatatypeId = @data_type_int_id and LovMeasureTypeId = @measure_type_geocode_id and SCDActiveFlag = 'Y'

SELECT  @northing_measureId=MeasureId from ser.Measure where MeasureName = 'z_grid_reference_northing' AND LOVRecordSourceId = @record_source_id 
and LOVDatatypeId = @data_type_int_id and LovMeasureTypeId = @measure_type_geocode_id and SCDActiveFlag = 'Y'
--table	
CREATE TABLE [psa].[uk_btc_mdm_store_stg]
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
)
AS
SELECT row_id
	  ,ISNULL( NULLIF((Substring(STORE_NUMBER, Patindex('%[^0]%', STORE_NUMBER + ' '), Len(STORE_NUMBER)) ),''),0) STORE_NUMBER
      ,STORE_NAME
      ,LOCATION_NAME
      ,LOCATION_TYPE
      ,SALES_ORGANISATION
      ,DISTRIBUTION_CHANNEL
      ,COMPANY_NAME
      ,STORE_ADDRESS_LINE_1
      ,STORE_ADDRESS_LINE_2
      ,STORE_TOWN
      ,STORE_COUNTY
      ,POSTCODE
      ,DIVISION_NUMBER
      ,DIVISION_NAME
      ,REGION_NUMBER
      ,REGION_NAME
      ,AREA_NUMBER
      ,AREA_NAME
      ,COUNTRY_CODE
      ,COUNTRY_DESCRIPTION
      ,CURRENCY_CODE
      ,STORE_OPENING_DATE
      ,STORE_CLOSURE_DATE
      ,STORE_OPEN_STATUS
      ,TRADING_FORMAT
      ,TYPE_OF_STORE_DESCRIPTION
      ,SAG
      ,MINI_SAG
      ,PRICE_BAND_CODE
      ,PRICE_BAND_DESCRIPTION
      ,VAT_FREE_FLAG
      ,STORE_TOTAL_SALES_AREA
      ,NUMBER_OF_FLOORS
      ,NON_DISPENSING_SALES_AREA
      ,BABY_CHANGING_ROOM_AREA
      ,CUSTOMER_TOILETS_AREA
      ,INTERVENTION_END_DATE
      ,INTERVENTION_START_DATE
      ,NON_LFL_REASON_CODE
      ,NON_LFL_REASON_DESCRIPTION
      ,PHARMACY_REGISTRATION_STATUS
      ,PRIMARY_CARE_ORGANISATION_DESCRIPTION
      ,NAME_OF_HEALTH_AUTHORITY
      ,Z_GRID_REFERENCE_EASTING
      ,Z_GRID_REFERENCE_NORTHING
      ,Z_GRID_REFERENCE_LATITUDE
      ,Z_GRID_REFERENCE_LONGITUDE
      ,STORE_SHORT_NAME
      ,TELEPHONE_NUMBER
      ,BENCHMARK_GROUP
      ,HEALTH_CLINIC_AREA
      ,OPTICANS_OFF_SALES_AREA
      ,OPTICANS_ON_SALES_AREA
      ,PHARMACY_CONSULTATION_AREA
      ,PHOTOLAB_OFF_SALES_AREA
      ,PHOTOLAB_ON_SALES_AREA
      ,WAITROSE_FOOD_OFFER_TYPE_CODE
      ,WAITROSE_FOOD_OFFER_TYPE_DESCRIPTION
      ,MIDNIGHT_PHARMACY
      ,NHS_CONTRACT_FLAG
      ,NHS_MARKET
      ,MDS_ROOM_FLAG
      ,etl_runlog_id
      ,asset_id
      ,record_source_id
      ,row_status
      ,created_timestamp
      ,active_flag
  FROM [psa].[uk_btc_mdm_store] where row_status=@row_status;


CREATE TABLE #TempCurMdmStore
			WITH
			( DISTRIBUTION = ROUND_ROBIN
			)
			AS
			SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (asset_id)) AS RowID,
									--created_timestamp AS created_timestamp,
									asset_id
							   FROM psa.[uk_btc_mdm_store] WHERE 
							    row_status=@row_status 	;
		    SELECT @MAXID = COUNT(*) FROM #TempCurMdmStore 
BEGIN TRANSACTION
BEGIN TRY
--Setting the counter variable for looping with ASset
				SET @COUNTER = 1									
										
				print 'Total Number of Loops/Assets to be processed : '+cASt(@MAXID AS varchar)+'';
				WHILE (@COUNTER <= @MAXID)
				BEGIN	
						SELECT 	@assetId=asset_id 
						FROM #TempCurMdmStore WHERE  RowID=@COUNTER;

						PRINT 'Current ASSSET: '+CAST(@assetId AS varchar)+';'
SET @SCDStartDate = current_timestamp;
/*-------Set the MAX value of surrogate Keys to particular Variables-------*/
SELECT @max_siteId= COALESCE((SELECT MAX(SiteId) FROM  ser.Site),0)

SELECT @maxpostalsite_id=COALESCE((SELECT MAX(SiteId) FROM  ser.PostalAddress),0)

SELECT @max_site_role_id=COALESCE((SELECT MAX(SiteRoleId) FROM  ser.SiteRole),0)

SELECT @max_siterole_group_id=COALESCE((SELECT MAX(SiteRoleGroupId) FROM  ser.SiteRoleGroup),0)

---------------------------------------Table1-Postal Address----------------------------------------------------------------------------
Print 'Info: PostalAddress Table Load Started ';

--create and load postal address temp table for finding the distinct duplicate records
exec('INSERT INTO [ser].[PostalAddress_STG](SiteId,AddressLine1,AddressLine2, Town, County, PostalCode
,z_grid_reference_longitude ,z_grid_reference_latitude,z_grid_reference_easting,z_grid_reference_northing,recordsourceId )
select Postal.SiteId,Postal.AddressLine1,Postal.AddressLine2, Postal.Town, Postal.County, Postal.PostalCode
,psa.validateNull(SP.z_grid_reference_longitude)
,psa.validateNull(SP.z_grid_reference_latitude),
SP.z_grid_reference_easting,SP.z_grid_reference_northing,12008
from ser.PostalAddress Postal
left join
(select [SiteId] as SiteId,['+@longitude_measureId+'] z_grid_reference_longitude ,['+@latitude_measureId+'] z_grid_reference_latitude,['+@easting_measureId+'] z_grid_reference_easting,['+@northing_measureId+'] z_grid_reference_northing
 FROM (select siteID,MeasureId,Value from ser.SiteProperty) SourceTable
PIVOT ( MAX(Value)
       FOR MeasureId in (['+@longitude_measureId+'],['+@latitude_measureId+'],['+@easting_measureId+'],['+@northing_measureId+'])) PivotTable) SP
on Postal.SiteId=SP.SiteId ')



Print 'Info: PostalAddress Table which doesnot exists are  ';
--create and load PostalAddressSitePropertyStaging Table
INSERT INTO ser.PostalAddress_SiteProperty_STG([SiteId],[AddressLine1],[AddressLine2],[Town],[County],[PostalCode],
[z_grid_reference_northing],[z_grid_reference_easting],[z_grid_reference_latitude],[z_grid_reference_longitude],
[LOVCountryId],[EtlRunlogId],[PsaRowKey],recordsourceId )
SELECT (COALESCE(@maxpostalsite_id,0) + ROW_NUMBER() OVER(ORDER BY  Ser.AddressLine1, Ser.AddressLine2, Ser.Town, Ser.County, Ser.PostalCode,Ser.z_grid_reference_northing,
Ser.z_grid_reference_easting,Ser.z_grid_reference_latitude,Ser.z_grid_reference_longitude ))SiteId  ,
Ser.AddressLine1,
Ser.AddressLine2,
Ser.Town,
Ser.County,
Ser.PostalCode,
Ser.z_grid_reference_northing,
Ser.z_grid_reference_easting,
Ser.z_grid_reference_latitude,
Ser.z_grid_reference_longitude,
Ser.LOVCountryId,
@serveETLRunLogID ETLRunLogId,
Ser.row_id,
12008
FROM
(
SELECT Source.AddressLine1,Source.AddressLine2, Source.Town,Source.County, Source.PostalCode,
Source.z_grid_reference_northing,Source.z_grid_reference_easting
,Source.z_grid_reference_latitude,Source.z_grid_reference_longitude,
Source.LOVCountryId,Source.SCDStartDate,Source.row_id
,CASE WHEN  POSTAL.SiteId is NULL THEN  0 ELSE 1  END AS ExistsFlag
FROM (
SELECT AddressLine1, AddressLine2,Town,County,PostalCode,z_grid_reference_northing,z_grid_reference_easting
,z_grid_reference_latitude,z_grid_reference_longitude,LOVCountryId,P.SCDStartDate,min(row_id) row_id FROM
(SELECT  psa.validateNull(Stage.store_address_line_1)  AddressLine1,
psa.validateNull(Stage.store_address_line_2)  AddressLine2,      
psa.validateNull(Stage.store_town)  Town,
psa.validateNull(Stage.store_county)  County,
psa.validateNull(Stage.postcode)  PostalCode,
psa.validateNull(Stage.z_grid_reference_northing) z_grid_reference_northing,
psa.validateNull(Stage.z_grid_reference_easting) z_grid_reference_easting,
psa.validateNull(Stage.z_grid_reference_latitude) z_grid_reference_latitude,
psa.validateNull(Stage.z_grid_reference_longitude) z_grid_reference_longitude,
rls.LOVId LOVCountryId,
@SCDStartDate_new  as SCDStartDate,
row_id
FROM psa.uk_btc_mdm_store_stg Stage
join ser.[RefLOVSetInfo] rls on Stage.country_code=rls.LOVKey
where rls.LovSetName='Country ISO 3166-2' and rls.lovrecordSourceId=@PostalLOVRecordSourceId
and Stage.asset_id=@assetId
and Stage.row_status=@row_status )P
group by AddressLine1, AddressLine2, Town,County, PostalCode,LOVCountryId,SCDStartDate,
z_grid_reference_northing,z_grid_reference_easting,z_grid_reference_latitude,z_grid_reference_longitude
) Source
LEFT JOIN ser.PostalAddress_STG Postal
ON ISNULL(Source.AddressLine1,'')=ISNULL(psa.validateNull(POSTAL.AddressLine1),'') AND  
ISNULL(Source.AddressLine2,'') =ISNULL(psa.validateNull(POSTAL.AddressLine2),'') AND
ISNULL(Source.Town,'')=ISNULL(psa.validateNull(POSTAL.Town),'') AND
ISNULL(Source.County,'')=ISNULL(psa.validateNull(POSTAL.County),'') AND  
ISNULL(Source.PostalCode,'')=ISNULL(psa.validateNull(POSTAL.PostalCode) ,'') AND
ISNULL(Source.z_grid_reference_northing,'')=ISNULL(psa.validateNull(POSTAL.z_grid_reference_northing) ,'') AND
ISNULL(Source.z_grid_reference_easting,'')=ISNULL(psa.validateNull(POSTAL.z_grid_reference_easting) ,'') AND
ISNULL(cast(Source.z_grid_reference_latitude as float),'')=ISNULL(cast(psa.validateNull(POSTAL.z_grid_reference_latitude) as float),'')
 AND ISNULL(cast(Source.z_grid_reference_longitude as float),'')=ISNULL(cast(psa.validateNull(POSTAL.z_grid_reference_longitude) as float),'')
 )Ser WHERE Ser.ExistsFlag=0

Print 'Info: PostalAddress Inserting Table  ';
----siteId is the combination of store_numbeer and record_source_id
INSERT INTO ser.PostalAddress
(SiteId, AddressLine1, AddressLine2, Town, County, PostalCode, LOVCountryId, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag,SCDVersion,
SCDLOVRecordSourceId,ETLRunLogId,PsaRowkey )
SELECT Ser.SiteId  ,Ser.AddressLine1, Ser.AddressLine2, Ser.Town, Ser.County, Ser.PostalCode, Ser.LOVCountryId,
@PostalLOVRecordSourceId,@SCDStartDate_new,@SCDEndDate,'Y', 1, @SCDLOVRecordSourceId,Ser.ETLRunLogId,Ser.PsaRowKey  from
ser.PostalAddress_SiteProperty_STG Ser
Print 'Info: PostalAddress Table Loaded Successfully ';

Delete from ser.PostalAddress_STG;

------------------------------------------Table2-SITE--------------------------------------------------------------------
Print 'Info: site Table Load Started ';
INSERT INTO ser.Site(SiteId,SourceKey,SiteName,LOVSiteTypeId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSArowKey)
SELECT SiteId,NULL SourceKey,NULL SiteName,@physical_store_type_id LOVSiteTypeId,@PostalLOVRecordSourceId,@SCDStartDate_new,--
@SCDEndDate,'Y',1,@SCDLOVRecordSourceId,ETLRunLogId,PsaRowKey  from
ser.PostalAddress_SiteProperty_STG
Print 'Info: site Table Loaded Successfully ';

------------------------------------------Table3-SITEPROPERTY--------------------------------------------------------------
PRINT 'Info: SITE PROPERTY Table Load Started ';
--refernce value
SELECT @uom_id_degree=LOVId from ser.[RefLOVSetInfo]   where LOVKey='°'  and LOVSetName='Unit Of Measure'  
SELECT @uom_id_m=LOVId from ser.[RefLOVSetInfo]   where LOVKey='m' and LOVSetName='Unit Of Measure'
Insert INTO [ser].[SiteProperty] (SiteId,          
  MeasureId,          
  LOVUOMId,            
  Value,
  LOVRecordSourceId,
  SCDStartDate,
  SCDEndDate,
  SCDActiveFlag,      
  SCDVersion,          
  SCDLOVRecordSourceId,
  ETLRunLogID,PsaRowKey)
 SELECT pvt.SiteId,pvt.MeasureId,pvt.LOVUOMId,pvt.Value,@record_source_id LOVRecordSourceId,@SCDStartDate_new,@SCDEndDate,'Y',1,@SCDLovRecordSourceId,EtlRunLogId,PsaRowKey FROM
 (Select SiteID,
(CASE WHEN (PICol='z_grid_reference_longitude') or (PICol='z_grid_reference_latitude') THEN @uom_id_degree ELSE @uom_id_m END ) LOVUOMId,
(CASE WHEN (PICol='z_grid_reference_longitude') or (PICol='z_grid_reference_latitude') THEN (SELECT  MeasureId from ser.Measure where MeasureName = ''+PICol+'' AND LOVRecordSourceId = @record_source_id and LOVDatatypeId = @data_type_double_id and LovMeasureTypeId = @measure_type_geocode_id)
ELSE (SELECT  MeasureId from ser.Measure where MeasureName = ''+PICol+'' AND LOVRecordSourceId = @record_source_id and LOVDatatypeId = @data_type_int_id and LovMeasureTypeId = @measure_type_geocode_id) END) MeasureId,
PIValue as Value,ETLRunLogId,PsaRowKey from
(select SiteId ,AddressLine1, AddressLine2, Town, County, PostalCode,z_grid_reference_northing,
z_grid_reference_easting,z_grid_reference_latitude,z_grid_reference_longitude,ETLRunLogId,PsaRowKey from
ser.PostalAddress_SiteProperty_STG)t
 UNPIVOT
(PIValue FOR PICol in         (t.z_grid_reference_longitude,
                                t.z_grid_reference_latitude,
                                t.z_grid_reference_easting,
                                t.z_grid_reference_northing
                                ))AS LOVGroupId  )pvt  where pvt.Value is not null AND pvt.Value!=''
PRINT 'Info: SITE PROPERTY Table Loaded Successfully ';
delete from ser.PostalAddress_SiteProperty_STG

-----------------------------------------------TABLE4-SITEROLE-----------------------------------------------------------
Print 'Info: siteRole Table Load Started ';
---Inserting PostalAddress_STG table for getting the updated entry for postal address table with Site property columns
PRINT 'Info:Inserting entries in PostalAddress_STG table for getting refreshed data'
--create and load postal address temp table for finding the distinct duplicate records
exec('INSERT INTO [ser].[PostalAddress_STG](SiteId,AddressLine1,AddressLine2, Town, County, PostalCode
,z_grid_reference_longitude ,z_grid_reference_latitude,z_grid_reference_easting,z_grid_reference_northing )
select Postal.SiteId,Postal.AddressLine1,Postal.AddressLine2, Postal.Town, Postal.County, Postal.PostalCode,
psa.validateNull(SP.z_grid_reference_longitude)
,psa.validateNull(SP.z_grid_reference_latitude),
SP.z_grid_reference_easting,SP.z_grid_reference_northing
from ser.PostalAddress Postal
left join
(select [SiteId] as SiteId,['+@longitude_measureId+'] z_grid_reference_longitude ,['+@latitude_measureId+'] z_grid_reference_latitude,['+@easting_measureId+'] z_grid_reference_easting,['+@northing_measureId+'] z_grid_reference_northing
 FROM (select siteID,MeasureId,Value from ser.SiteProperty) SourceTable
PIVOT ( MAX(Value)
       FOR MeasureId in (['+@longitude_measureId+'],['+@latitude_measureId+'],['+@easting_measureId+'],['+@northing_measureId+'])) PivotTable) SP
on Postal.SiteId=SP.SiteId')


SELECT @NULLSiteId=siteId from ser.PostalAddress_STG where AddressLine1 is NULL and Addressline2 IS NULL
and town IS NULL and county IS NULL and PostalCode IS NULL and z_grid_reference_longitude IS NULL AND
z_grid_reference_latitude IS NULL AND z_grid_reference_easting IS NULL AND z_grid_reference_northing IS NULL

SELECT @max_site_role_id= COALESCE((SELECT MAX(SiteRoleId) FROM  ser.SiteRole),0)

--updating the existing records in SiteRole table if exists
UPDATE ser.SiteRole   set SCDEndDate=DATEADD(second,-1,@SCDStartDate),SCDActiveFlag='N'
FROM  ser.SiteRole sr  
join
		(select siteroleId,sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
		where lovrecordsourceId=12008 group by siteroleId,sourcekey,lovrecordsourceId)P  
		 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId
		 and p.siteroleID=sr.siteroleid
		 and  sr.scdversion=P.scdversion 
join psa.uk_btc_mdm_store_stg mdms
ON mdms.record_source_id=sr.LovRecordSourceId and
 sr.sourcekey = mdms.store_number
JOIN ser.PostalAddress_STG POSTAL
on ISNULL(psa.validateNULL(mdms.store_address_line_1),'')=ISNULL(psa.validateNULL(POSTAL.AddressLine1),'') AND  
ISNULL(psa.validateNULL(mdms.store_address_line_2),'') =ISNULL(psa.validateNULL(POSTAL.AddressLine2),'') AND
ISNULL(psa.validateNULL(mdms.store_town),'')=ISNULL(psa.validateNULL(POSTAL.Town),'') AND
ISNULL(psa.validateNULL(mdms.store_county),'')=ISNULL(psa.validateNULL(POSTAL.County),'') AND  
ISNULL(psa.validateNULL(mdms.postcode),'')=ISNULL(psa.validateNULL(POSTAL.PostalCode) ,'') AND
ISNULL(psa.validateNULL(mdms.z_grid_reference_northing),'')=ISNULL(psa.validateNULL(POSTAL.z_grid_reference_northing) ,'') AND
ISNULL(psa.validateNULL(mdms.z_grid_reference_easting),'')=ISNULL(psa.validateNULL(POSTAL.z_grid_reference_easting) ,'') AND
ISNULL(cast(psa.validateNULL(mdms.z_grid_reference_latitude) as float),'')=ISNULL(cast(psa.validateNull(POSTAL.z_grid_reference_latitude) as float),'')
 AND ISNULL(cast(psa.validateNULL(mdms.z_grid_reference_longitude) as float),'')=ISNULL(cast(psa.validateNull(POSTAL.z_grid_reference_longitude) as float),'')
Where mdms.row_status=@row_status AND  mdms.asset_id=@assetId
AND NOT EXISTS (select * from ser.SiteRole srp where mdms.Store_number =srp.SourceKey
                               AND mdms.record_source_id=srp.LOVRecordSourceId
AND ISNULL(mdms.store_name,'')=ISNULL(srp.SiteRoleName,'')
AND ISNULL(mdms.store_short_name,'')  = ISNULL(srp.SiteRoleShortName,'')
AND sr.SCDVersion=srp.ScdVersion and postal.siteid=srp.siteid AND srp.SCDActiveFlag='Y'
                       );
--insertion
INSERT INTO ser.SiteRole(SiteRoleId,SiteId,LOVRoleId,SourceKey,SiteRoleName,SiteRoleShortName,LOVRecordSourceId,SCDSTartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowkey)
SELECT CASE When tr.SourceKey is not null  and tr.lovrecordsourceId is not null      
Then  tr.SiteroleId  ELSE  @max_site_role_id + ROW_NUMBER() OVER(ORDER BY  store_number,record_source_id) END SiteRoleId,
 postal.Siteid,
 @role_id LOVRoleId,
 store_number,
 store_name,
 store_short_name,12008,
 CASe When tr.SCDStartdate is null then @SCDStartDate_new
 ELSE  @SCDStartDate END  SCDStartDate,                
                convert (datetime,'9999-12-31') SCDEndDate,
 'Y',
 COALESCE(tr.SCDVERSION,0) + 1 AS SCDVERSION ,
                @SCDLOVRecordSourceId SCDLOVRecordSourceId,
                @serveETLRunLogID ETLRunLogId,
mdms.row_id
 
FROM psa.uk_btc_mdm_store_stg  mdms Join
ser.PostalAddress_STG POSTAL on
ISNULL(psa.validateNULL(mdms.store_address_line_1),'')=ISNULL(psa.validateNULL(POSTAL.AddressLine1),'')AND  
ISNULL(psa.validateNULL(mdms.store_address_line_2),'') =ISNULL(psa.validateNULL(POSTAL.AddressLine2),'') AND
ISNULL(psa.validateNULL(mdms.store_town),'')=ISNULL(psa.validateNULL(POSTAL.Town),'') AND
ISNULL(psa.validateNULL(mdms.store_county),'')=ISNULL(psa.validateNULL(POSTAL.County),'') AND  
ISNULL(psa.validateNULL(mdms.postcode),'')=ISNULL(psa.validateNULL(POSTAL.PostalCode) ,'')  AND
ISNULL(psa.validateNULL(mdms.z_grid_reference_northing),'')=ISNULL(psa.validateNULL(POSTAL.z_grid_reference_northing ),'') AND
ISNULL(psa.validateNULL(mdms.z_grid_reference_easting),'')=ISNULL(psa.validateNULL(POSTAL.z_grid_reference_easting) ,'') AND
ISNULL(cast(psa.validateNULL(mdms.z_grid_reference_latitude) as float),'')=ISNULL(cast(psa.validateNull(POSTAL.z_grid_reference_latitude) as float),'')
 AND ISNULL(cast(psa.validateNULL(mdms.z_grid_reference_longitude) as float),'')=ISNULL(cast(psa.validateNull(POSTAL.z_grid_reference_longitude) as float),'')
left join (
select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate from ser.siterole sr
join
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
where lovrecordsourceId=12008 group by sourcekey,lovrecordsourceId)P  
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId
 where sr.scdversion=P.scdversion)tr
 on mdms.store_number=tr.sourcekey and tr.lovrecordsourceId =mdms.record_source_id
WHERE mdms.Row_Status=@row_status and mdms.asset_id=@assetId
and (CASE  WHEN ( NULLIF(mdms.store_name,'' ) IS NULL AND NULLIF( mdms.store_short_name,'' ) IS NULL )  THEN 0
   ELSE 1 END)=1
 AND (NOT EXISTS (                                                    
        SELECT *  FROM ser.siterole srr where
        tr.sourcekey=srr.sourcekey and tr.lovrecordsourceid=srr.lovrecordsourceid and
         tr.scdversion=srr.scdversion
        AND tr.lovrecordsourceId=mdms.record_source_id AND ISNULL(mdms.store_name,'')=ISNULL(tr.SiteRoleName,'')
        and postal.siteid=tr.siteid and srr.SCDActiveFlag='Y'
     )  
or (CASE   WHEN (Postal.SiteId = @NULLSiteId AND len( trim(mdms.store_name)) =0 and mdms.store_name
IS NULL AND (len( trim(mdms.store_short_name)) =0 or mdms.store_short_name
IS NULL))   THEN 0 ELSE 1 END)=0)

--updating sitrole entry which is inactive
UPDATE ser.SiteRole SET SCDActiveFlag= 'N',SCDEndDate =DATEADD(second,-1,@SCDStartDate )
                        FROM ser.SiteRole sr
                        JOIN  psa.[uk_btc_mdm_store_stg] mdms
                              ON mdms.record_source_id=sr.LovRecordSourceId
                              AND sr.sourcekey = mdms.store_number
                        WHERE NULLIF(mdms.store_name,'' ) IS NULL AND NULLIF( mdms.store_short_name,'' ) IS NULL
                              AND sr.SCDActiveFlag='Y'
                              AND asset_id=@assetId;
Print 'Info: siteRole Table Loaded Successfully ';
---clearing the records for PostalAddress_STG tables
delete from [ser].[PostalAddress_STG]
-----------------------------------------------TABLE5-SITEROLECONTACTMETHOD----------------------------------------------
PRINT 'Info: SITEROLE CONTACT METHOD Table Load Started ';  
--reference value
SELECT @contact_method_type_id=LOVId from ser.[RefLOVSetInfo]  where LOVKey='TEL' and LOVSetName='Contact Method Type' and LovRecordSourceId=12012

--reference value
SELECT @usage_type_id=LOVId from ser.[RefLOVSetInfo]  where LOVKey='BUS' and LOVSetName='Usage Type' and LovRecordSourceId=12012


--create staging table
INSERT INTO ser.SiteRoleContactMethod_STG(
[ExistsFlag],[SiteRoleId],[LOVContactMethodTypeId],[LOVUsageTypeId],[ContactDetail],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])
SELECT CASE WHEN SiteRoleContactMethod.SiteRoleId IS NULL THEN 0 ELSE 1 END ExistsFlag,
STG.SiteRoleId,
@contact_method_type_id as LOVContactMethodTypeId,
@usage_type_id as LovUsageTypeId,
STG.telephone_number as ContactDetail,
STG.lovrecordsourceId, 
CASE WHEN SiteRoleContactMethod.SiteRoleId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
@SCDEndDate SCDEndDate,
'Y' SCDActiveFlag,
COALESCE(SiteRoleContactMethod.SCDVersion,0) + 1 SCDVersion,@SCDLOVRecordSourceId SCDLOVRecordSourceId , @serveETLRunLogID ETLRunLogId,STG.row_id
 FROM (
 
select s.SiteRoleId,store.telephone_number,store.ETLRunLogId,store.lovrecordsourceId,store.SCDStartDate,store.row_status,store.asset_id,store.row_id from
(select store_number,ISNULL(NULLIF(telephone_number,''),'NULL VALUE') telephone_number,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,asset_id,Min(row_id) row_id  
from psa.uk_btc_mdm_store_stg where row_status=@row_status and asset_id=@assetId group by  store_number,telephone_number,etl_runlog_id,record_source_id,row_status,asset_id)store,
(
select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate from ser.siterole sr 
join 
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
where lovrecordsourceId=12008 and SCDActiveFlag='Y' group by sourcekey,lovrecordsourceId)P  
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId 
 where sr.scdversion=P.scdversion)s 
 WHERE store.store_number=s.SourceKey and store.LOVRecordSourceId=s.LOVRecordSourceId 
)STG
LEFT JOIN (
select src.siteroleid,src.ContactDetail,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LOVContactMethodTypeId from ser.siteroleContactMethod src 
join 
(select SiteRoleId,max(scdversion) scdversion,lovrecordsourceId from ser.SiteroleContactMethod 
where lovrecordsourceId=12008 group by SiteRoleId,lovrecordsourceId)P  
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId 
 where src.scdversion=P.scdversion)SiteRoleContactMethod
on STG.lovrecordsourceId=SiteRoleContactMethod.lovrecordsourceId 
AND STG.SiteRoleId=SiteRoleContactMethod.SiteRoleId
where --STG.telephone_number is not null and STG.telephone_number!='' and 
STG.row_status=@row_status and STG.asset_id=@assetId --AND  mdms.created_timestamp=@assetId
AND NOT EXISTS (                                                     
        SELECT *  FROM ser.siteroleContactMethod contact where 
        SiteRoleContactMethod.SiteRoleId=contact.SiteRoleId and SiteRoleContactMethod.lovrecordsourceid=contact.lovrecordsourceid and 
         SiteRoleContactMethod.scdversion=contact.scdversion 
        AND SiteRoleContactMethod.lovrecordsourceId=STG.lovrecordsourceId AND ISNULL(STG.telephone_number,'')=ISNULL(SiteRoleContactMethod.ContactDetail,'') 
        AND @contact_method_type_id=ISNULL(SiteRoleContactMethod.LOVContactMethodTypeId,'') AND contact.SCDActiveFlag='Y'
       )




--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.SiteRoleContactMethod SET SCDEndDate=DATEADD(second,-1,result.SCDStartDate ) ,SCDActiveFlag='N'  
  FROM  ser.SiteRoleContactMethod cont
 join( select SiteRoleContactMethod_mdm.siteroleid,UPD.LOVContactMethodTypeId,UPD.ContactDetail,UPD.SCDStartDate,UPD.lovrecordsourceId
 from (select src.siteroleid,src.ContactDetail,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LOVContactMethodTypeId from ser.siteroleContactMethod src
join
(select SiteRoleId,max(scdversion) scdversion,lovrecordsourceId from ser.SiteroleContactMethod
where lovrecordsourceId=12008 group by SiteRoleId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId
 where src.scdversion=P.scdversion)SiteRoleContactMethod_mdm
 JOIN (
SELECT * FROM ser.SiteRoleContactMethod_STG)UPD
ON SiteRoleContactMethod_mdm.SiteRoleId=UPD.SiteRoleId 
WHERE SiteRoleContactMethod_mdm.lovRecordSourceId=UPD.LOVRecordSourceId
AND NOT EXISTS (                                                    
        SELECT *  FROM ser.siteroleContactMethod contact where
        SiteRoleContactMethod_mdm.SiteRoleId=contact.SiteRoleId and SiteRoleContactMethod_mdm.lovrecordsourceid=contact.lovrecordsourceid and
         SiteRoleContactMethod_mdm.scdversion=contact.scdversion  AND
         ISNULL(UPD.ContactDetail,'')=ISNULL(contact.ContactDetail,'')
         AND ISNULL(UPD.LOVContactMethodTypeId,'')=ISNULL(contact.LOVContactMethodTypeId,'') AND contact.SCDActiveFlag='Y'
           )
            AND UPD.ExistsFlag=1  )result
           on cont.SiteRoleId=result.SiteRoleId where cont.lovrecordsourceId=result.lovrecordsourceId




--Inserting data to table with existing version increment by 1 and new record version as 1.
INSERT INTO ser.SiteRoleContactMethod([SiteRoleId]
           ,[LOVContactMethodTypeId]
           ,[LOVUsageTypeId]
           ,[ContactDetail]
		   ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId],
		   [Psarowkey])
SELECT SiteRoleId, LOVContactMethodTypeId,LOVUsageTypeId,ContactDetail,LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,row_id
FROM
(SELECT * FROM ser.SiteRoleContactMethod_STG)Stage
WHERE Stage.SCDActiveFlag='Y' AND Stage.ContactDetail!='NULL VALUE'

update ser.SiteRoleContactMethod set SCDEndDate=siterole.SCDEndDate ,SCDActiveFlag='N'
FROM ser.SiteRoleContactMethod src join ( select src.siteroleid,src.ContactDetail,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LOVContactMethodTypeId from ser.siteroleContactMethod src
join
(select SiteRoleId,max(scdversion) scdversion,lovrecordsourceId from ser.SiteroleContactMethod
where lovrecordsourceId=12008 group by SiteRoleId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId
 where src.scdversion=P.scdversion)SiteRoleContactMethod_mdm
on SiteRoleContactMethod_mdm.SiteRoleId=src.SiteRoleId and SiteRoleContactMethod_mdm.lovrecordsourceId=src.lovrecordsourceId
JOIN (select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate,sr.SCDEndDate,sr.SCDActiveFlag from ser.siterole sr
join
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole
where lovrecordsourceId=12008 group by sourcekey,lovrecordsourceId)P
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId
 where sr.scdversion=P.scdversion)siterole on SiteRoleContactMethod_mdm.SiteRoleId=siterole.SiteRoleId
 where siterole.SCDActiveFlag='N'

PRINT 'Info: SITEROLE CONTACT METHOD Table Loaded Successfully ';
delete from ser.SiteRoleContactMethod_STG; 
----------------------------------------------TABLE6-SITEROLESTATUS---------------------------------------------------

PRINT 'Info: SiteRoleStatus Table Load Started ';
--reference value
SELECT @OpenStatus = r.Lovid from ser.[RefLOVSetInfo] r 
WHERE r.LOVKey =  'Open (for trading)'  and r.LOVSETName = 'store_open_status' and r.LoVRecordSourceId=@record_source_id

--reference value
SELECT @LOVSiteRoleStatusSetId_status = refs.LovSetid from ser.[RefLOVSetInfo] refs WHERE  refs.LOVSETName = 'store_open_status' 
and refs.LoVRecordSourceId=@record_source_id

--reference value
SELECT @LOVSiteRoleStatusSetId_floor = r.Lovid from ser.[RefLOVSetInfo] r 
WHERE r.LOVKey =  'FLOOR_AREA'  and r.LOVSETName = 'Measure Type'

--reference value
SELECT @LOVSiteRoleStatusSetId_nonf_ifl =refs.LovSetid from ser.[RefLOVSetInfo] refs WHERE  refs.LOVSETName = 'non_lfl_reason_code' 
and refs.LoVRecordSourceId=@record_source_id

SELECT @LOVSiteRoleStatusSetId_pharmacy = refs.LovSetid from ser.[RefLOVSetInfo] refs WHERE  refs.LOVSETName = 'pharmacy_registration_status' 
and refs.LoVRecordSourceId=@record_source_id

--create staging table
INSERT INTO ser.SiteRoleStatus_STG( [ExistsFlag],[SiteRoleId],[LOVSiteRoleStatusSetId],[LOVStatusId],[EffectiveFrom],[EffectiveTo],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id],[store_status],[store_open_status])
SELECT distinct CASE WHEN SiteRoleStatus.SiteRoleId IS NULL THEN 0 ELSE 1 END ExistsFlag,
si.SiteRoleId,
STG.LOVSiteRoleStatusSetId LOVSiteRoleStatusSetId,
STG.statusId as LOVStatusId,
STG.EffectiveFrom as EffectiveFrom,
STG.EffectiveTo as EffectiveTo,
STG.lovrecordsourceId, 
CASE WHEN SiteRoleStatus.SiteRoleId IS NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
@SCDEndDate SCDEndDate,
'Y' SCDActiveFlag,
COALESCE(SiteRoleStatus.SCDVersion,0) + 1 SCDVersion,@SCDLOVRecordSourceId SCDLOVRecordSourceId , @serveETLRunLogID ETLRunLogId,STG.row_id,STG.store_status,STG.store_open_status
 
 FROM (
 --First ---
(select  store_number,(select LovID from ser.RefLOVSetInfo where LOVKey = store_open_status and  LOVSetName = 'store_open_status' and LOVrecordSourceId=12008) statusId,
case when store_open_status='Open (for trading)' Then  CONVERT(datetime,psa.validateNull(store_opening_date),104)
when store_open_status='Closed (ceased trading)' Then  CONVERT(datetime,psa.validateNull(store_closure_date),104) ELSE null END  EffectiveFrom, 
case when store_open_status='Open (for trading)' Then  CONVERT(datetime,psa.validateNull(store_closure_date),104)
when store_open_status='Closed (ceased trading)' Then  null ELSE null END EffectiveTo ,@LOVSiteRoleStatusSetId_status LOVSiteRoleStatusSetId ,
etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,asset_id,row_id,'open/close' store_status,store_open_status from psa.uk_btc_mdm_store_stg where record_source_id=@record_source_id and row_status=@row_status and asset_id=@assetId)

union
--2nd--
(select  store_number,(select LovID from ser.RefLOVSetInfo where LOVKey = non_lfl_reason_code and  LOVSetName = 'non_lfl_reason_code' and LOVrecordSourceId=@record_source_id) statusId,
  CONVERT(datetime,psa.validateNull(intervention_start_date),104)  EffectiveFrom, 
 CONVERT(datetime,psa.validateNull(intervention_end_date),104) EffectiveTo ,@LOVSiteRoleStatusSetId_nonf_ifl LOVSiteRoleStatusSetId,
etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,asset_id,row_id,'non_lfl_reason_code' store_status,store_open_status from psa.uk_btc_mdm_store_stg where record_source_id=@record_source_id
and non_lfl_reason_code is not null and non_lfl_reason_code!='' and row_status=@row_status and asset_id=@assetId)

union
--3rd
(select  store_number,(select LovID from ser.RefLOVSetInfo where LOVKey = pharmacy_registration_status and  LOVSetName = 'pharmacy_registration_status' and LOVrecordSourceId=@record_source_id) statusId,
 null as EffectiveFrom, 
null  EffectiveTo ,@LOVSiteRoleStatusSetId_pharmacy LOVSiteRoleStatusSetId ,
etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,asset_id,row_id ,'pharmacy_registration_status' store_status,store_open_status from psa.uk_btc_mdm_store_stg
where record_source_id=@record_source_id and pharmacy_registration_status is not null and pharmacy_registration_status!='' and row_status=@row_status and asset_id=@assetId)
  )STG
  join (select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate from ser.siterole sr 
join 
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
where lovrecordsourceId=12008 and SCDActiveFlag='Y' group by sourcekey,lovrecordsourceId)P  
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId 
 where sr.scdversion=P.scdversion)si on si.SourceKey=STG.store_number and si.lovrecordsourceId=STG.lovrecordsourceId 
LEFT JOIN (
select src.siteroleid,src.EffectiveFrom,src.EffectiveTo,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LOVStatusId statusId,src.LovSiteRoleStatusSetId from ser.siteroleStatus src 
join 
(select SiteRoleId,max(scdversion) scdversion,LovSiteRoleStatusSetId,lovrecordsourceId from ser.SiteroleStatus
where lovrecordsourceId=12008 group by SiteRoleId,lovrecordsourceId,LovSiteRoleStatusSetId)P  
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId and  p.LovSiteRoleStatusSetId=src.LovSiteRoleStatusSetId
 where src.scdversion=P.scdversion)SiteRoleStatus
on STG.lovrecordsourceId=SiteRoleStatus.lovrecordsourceId and Si.SiteRoleId=SiteRolestatus.SiteRoleId 
and STG.LovSiteRoleStatusSetId=SiteRolestatus.LovSiteRoleStatusSetId where
STG.statusId is not null and STG.statusId!='' and STG.row_status=@row_status AND  STG.asset_id=@assetId
 AND NOT EXISTS (                                                     
        SELECT *  FROM ser.siteroleStatus status_sr where 
        SiteRoleStatus.SiteRoleId=status_sr.SiteRoleId and SiteRoleStatus.lovrecordsourceid=status_sr.lovrecordsourceid and 
		ISNULL(STG.EffectiveFrom,'')=ISNULL(status_sr.EffectiveFrom,'') 
		 AND    ISNULL(STG.EffectiveTo,'')=ISNULL(status_sr.EffectiveTo,'') 
         AND ISNULL(STG.LovSiteRoleStatusSetId,'')=ISNULL(status_sr.LovSiteRoleStatusSetId,'') 
		 AND ISNULL(STG.StatusId,'')=ISNULL(status_sr.LOVStatusId,'') 
           )

		   --select  * FROM ser.SiteRoleStatus_STG where ExistsFlag=1

--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate and EffectiveTodate changed to  efefctivefrom of currect record.
UPDATE  ser.SiteRoleStatus SET SCDEndDate=DATEADD(second,-1,result.SCDStartDate ),SCDActiveFlag= 'N',
EffectiveTo= result.EffectiveFrom 
 FROM  ser.SiteRoleStatus srs JOIN
(select distinct UPD.EffectiveFrom,UPD.EffectiveTo,SiteRoleStatus_mdm.siteroleid,UPD.LovstatusId,UPD.LovSiteRoleStatusSetId,UPD.SCDStartDate,UPD.store_status,UPD.store_open_status FROM
(
select distinct src.siteroleid,src.EffectiveFrom,src.EffectiveTo,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LOVStatusId statusId,src.LovSiteRoleStatusSetId from ser.siteroleStatus src
join
(select SiteRoleId,max(scdversion) scdversion,LovSiteRoleStatusSetId,lovrecordsourceId from ser.SiteroleStatus
where lovrecordsourceId=12008 group by SiteRoleId,lovrecordsourceId,LovSiteRoleStatusSetId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId
 where src.scdversion=P.scdversion)SiteRoleStatus_mdm
 JOIN (
SELECT distinct  * FROM ser.SiteRoleStatus_STG)UPD
ON SiteRoleStatus_mdm.SiteRoleId=UPD.SiteRoleId AND SiteRoleStatus_mdm.lovRecordSourceId=UPD.LOVRecordSourceId
--and SiteRoleStatus_mdm.LovSiteRoleStatusSetId=UPD.LovSiteRoleStatusSetId--and
WHERE  UPD.ExistsFlag=1 AND UPD.store_status='open/close'
AND NOT EXISTS (                                                   
        SELECT status_sr.SiteRoleId,status_sr.LovSiteRoleStatusSetId,status_sr.LovStatusId  FROM ser.siteroleStatus status_sr where
        SiteRoleStatus_mdm.SiteRoleId=status_sr.SiteRoleId and SiteRoleStatus_mdm.lovrecordsourceid=status_sr.lovrecordsourceid and
         --SiteRoleStatus_mdm.scdversion=status_sr.scdversion  AND
         ISNULL(UPD.EffectiveFrom,'')=ISNULL(status_sr.EffectiveFrom,'')
         AND    ISNULL(UPD.EffectiveTo,'')=ISNULL(status_sr.EffectiveTo,'')
         AND ISNULL(UPD.LovSiteRoleStatusSetId,'')=ISNULL(status_sr.LovSiteRoleStatusSetId,'')
         AND ISNULL(UPD.LOVStatusId,'')=ISNULL(status_sr.LOVStatusId,'')
           ))result on  srs.SiteRoleId=result.SiteRoleId 
           where srs.lovstatusId in (select LovID from ser.RefLOVSetInfo where LOVKey in('Closed (ceased trading)','Open (for trading)')
           and  LOVSetName = 'store_open_status' and LOVrecordSourceId=12008)
--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate and EffectiveTodate changed to  efefctivefrom of currect record.
UPDATE ser.SiteRoleStatus SET SCDEndDate=DATEADD(second,-1,result.SCDStartDate ),SCDActiveFlag= 'N'
 FROM  ser.SiteRoleStatus srs JOIN 
(select distinct UPD.EffectiveFrom,UPD.EffectiveTo,SiteRoleStatus_mdm.siteroleid,UPD.LovstatusId,UPD.LovSiteRoleStatusSetId,UPD.SCDStartDate,UPD.store_status,UPD.store_open_status FROM  
(
select distinct src.siteroleid,src.EffectiveFrom,src.EffectiveTo,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LOVStatusId statusId,src.LovSiteRoleStatusSetId from ser.siteroleStatus src 
join 
(select SiteRoleId,max(scdversion) scdversion,LovSiteRoleStatusSetId,lovrecordsourceId from ser.SiteroleStatus
where lovrecordsourceId=12008 group by SiteRoleId,lovrecordsourceId,LovSiteRoleStatusSetId)P  
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId 
 where src.scdversion=P.scdversion)SiteRoleStatus_mdm
 JOIN (
SELECT distinct  * FROM ser.SiteRoleStatus_STG)UPD
ON SiteRoleStatus_mdm.SiteRoleId=UPD.SiteRoleId AND SiteRoleStatus_mdm.lovRecordSourceId=UPD.LOVRecordSourceId 
--and SiteRoleStatus_mdm.LovSiteRoleStatusSetId=UPD.LovSiteRoleStatusSetId--and 
WHERE  UPD.ExistsFlag=1 
AND NOT EXISTS (                                                     
        SELECT status_sr.SiteRoleId,status_sr.LovSiteRoleStatusSetId,status_sr.LovStatusId  FROM ser.siteroleStatus status_sr where 
        SiteRoleStatus_mdm.SiteRoleId=status_sr.SiteRoleId and SiteRoleStatus_mdm.lovrecordsourceid=status_sr.lovrecordsourceid and 
         --SiteRoleStatus_mdm.scdversion=status_sr.scdversion  AND
         ISNULL(UPD.EffectiveFrom,'')=ISNULL(status_sr.EffectiveFrom,'') 
		 AND    ISNULL(UPD.EffectiveTo,'')=ISNULL(status_sr.EffectiveTo,'') 
         AND ISNULL(UPD.LovSiteRoleStatusSetId,'')=ISNULL(status_sr.LovSiteRoleStatusSetId,'') 
		 --AND ISNULL(UPD.LOVStatusId,'')=ISNULL(status_sr.LOVStatusId,'') 
           ))result on  srs.SiteRoleId=result.SiteRoleId and srs.LovSiteRoleStatusSetId=result.LovSiteRoleStatusSetId  
		   where srs.lovstatusId not in (select LovID from ser.RefLOVSetInfo where LOVKey in('Closed (ceased trading)','Open (for trading)') 
		   and  LOVSetName = 'store_open_status' and LOVrecordSourceId=12008)
		   

	   

INSERT INTO ser.SiteRoleStatus([SiteRoleId]
           ,[LOVSiteRoleStatusSetId]
           ,[LOVStatusId]
           ,[EffectiveFrom]
		   ,[EffectiveTo]
		   ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId],
		   [Psarowkey])
SELECT SiteRoleId, [LOVSiteRoleStatusSetId],[LOVStatusId],[EffectiveFrom],[EffectiveTo],LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,row_id
FROM
(SELECT distinct * FROM ser.SiteRoleStatus_STG)Stage
WHERE Stage.SCDActiveFlag='Y'

update ser.siteroleStatus set SCDEndDate=siterole.SCDEndDate ,SCDActiveFlag='N'
FROM ser.siteroleStatus src join ( select src.siteroleid,src.LOVSiteRoleStatusSetId,src.scdversion,src.lovrecordsourceId,src.SCDStartdate from ser.siteroleStatus src
join
(select SiteRoleId,max(scdversion) scdversion,LOVSiteRoleStatusSetId,lovrecordsourceId from ser.siteroleStatus
where lovrecordsourceId=12008 group by SiteRoleId,LOVSiteRoleStatusSetId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId and P.LOVSiteRoleStatusSetId=src.LOVSiteRoleStatusSetId
 where src.scdversion=P.scdversion)siteroleStatus_mdm
 on siteroleStatus_mdm.SiteRoleId=src.SiteRoleId and siteroleStatus_mdm.lovrecordsourceId=src.lovrecordsourceId and siteroleStatus_mdm.LOVSiteRoleStatusSetId=src.LOVSiteRoleStatusSetId

JOIN (select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate,sr.SCDEndDate,sr.SCDActiveFlag from ser.siterole sr
join
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole
where lovrecordsourceId=12008 group by sourcekey,lovrecordsourceId)P
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId
 where sr.scdversion=P.scdversion)siterole on siteroleStatus_mdm.SiteRoleId=siterole.SiteRoleId
 where siterole.SCDActiveFlag='N'

PRINT 'Info: SITEROLE STATUS Table Loaded Successfully '; 
delete from ser.SiteRoleStatus_STG;
--------------------------------------------TABLE7-SITEROLETERRITORY--------------------------------------------------
PRINT 'Info: SITEROLE TERRITORY Table Load Started '; 
--reference value
SELECT @setid_area_number=LOVSetId FROM [ser].[RefLOVSetInfo] WHERE LOVSetName = 'area_number' and LOVRecordSourceId=@record_source_id

--reference value
SELECT @setid_nhs_market=LOVSetId FROM [ser].[RefLOVSetInfo] WHERE LOVSetName = 'nhs_market' and LOVRecordSourceId=@record_source_id

--create staging table

INSERT INTO ser.[SiteRoleTerritory_STG]([ExistsFlag],[SiteRoleId],[LOVSiteRoleTerritorySetId],[LOVTerritoryId],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])
SELECT CASE WHEN SiteRoleTerritory.SiteRoleId IS NULL THEN 0 ELSE 1 END ExistsFlag,
s.SiteRoleId,
store.LOVSiteRoleTerritorySetId,
store.territorysourceKey LovTerritoryId,	 
store.lovrecordsourceId, 
CASE WHEN SiteRoleTerritory.SiteRoleId IS NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
@SCDEndDate SCDEndDate,
'Y' SCDActiveFlag,
COALESCE(SiteRoleTerritory.SCDVersion,0) + 1 SCDVersion,@SCDLOVRecordSourceId SCDLOVRecordSourceId , @serveETLRunLogID ETLRunLogId,store.row_id
FROM (
(select store_number ,ISNULL((select LOVId from ser.reflovsetInfo where LOVKey = ''+area_number+'' and LOVSetName='area_number' and lovrecordsourceId=12008),0) territorysourceKey,etl_runlog_id ETLRunLogId,@setid_area_number LOVSiteRoleTerritorySetId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,asset_id,row_id,'area_number' as typename from 
psa.uk_btc_mdm_store_stg where record_source_id=@record_source_id and row_status=@row_status and asset_id=@assetId)
union
(select store_number ,ISNULL((select LOVId from ser.reflovsetInfo where LOVKey = ''+nhs_market+'' and LOVSetName='nhs_market' and lovrecordsourceId=12008),0)territorysourceKey,etl_runlog_id ETLRunLogId,@setid_nhs_market LOVSiteRoleTerritorySetId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,asset_id,row_id,'nhs_market' as typename from psa.uk_btc_mdm_store_stg 
where record_source_id=@record_source_id and row_status=@row_status and asset_id=@assetId)
)store
LEFT JOIN (
select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate from ser.siterole sr 
join 
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
where lovrecordsourceId=12008 and SCDActiveFlag='Y' group by sourcekey,lovrecordsourceId)P  
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId 
 where sr.scdversion=P.scdversion)s  on store.store_number=s.SourceKey and store.lovrecordsourceId=s.lovrecordsourceId
LEFT JOIN (
select src.siteroleid,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LOVSiteRoleTerritorySetId,src.LovTerritoryId  from ser.SiteRoleTerritory src 
join 
(select SiteRoleId,max(scdversion) scdversion,lovSiteRoleTerritorySetId,lovrecordsourceId from ser.SiteRoleTerritory 
where lovrecordsourceId=12008 group by SiteRoleId,lovSiteRoleTerritorySetId,lovrecordsourceId)P  
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId and P.lovSiteRoleTerritorySetId=src.lovSiteRoleTerritorySetId
 where src.scdversion=P.scdversion)SiteRoleTerritory
on store.lovrecordsourceId=SiteRoleTerritory.lovrecordsourceId AND SiteRoleTerritory.SiteRoleId=s.SiteRoleId and SiteRoleTerritory.LOVSiteRoleTerritorySetId=store.LOVSiteRoleTerritorySetId
where s.LOVRecordSourceId=store.lovrecordsourceId and store.row_status=@row_status and store.asset_id=@assetId
--AND  mdms.created_timestamp=@assetId
AND NOT EXISTS (                                                     
        SELECT lovTerritoryId ,LOVSiteRoleTerritorySetId FROM ser.SiteRoleTerritory territory where 
        SiteRoleTerritory.SiteRoleId=territory.SiteRoleId and SiteRoleTerritory.lovrecordsourceid=territory.lovrecordsourceid and 
         SiteRoleTerritory.scdversion=territory.scdversion 
        AND SiteRoleTerritory.lovrecordsourceId=store.lovrecordsourceId AND ISNULL(store.territorysourceKey,'')=ISNULL(SiteRoleTerritory.LovTerritoryId,'') 
        AND store.LOVSiteRoleTerritorySetId=ISNULL(SiteRoleTerritory.LOVSiteRoleTerritorySetId,'') AND territory.SCDACTIVEFLAG='Y'      
     )
--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.SiteRoleTerritory SET SCDEndDate=DATEADD(second,-1,result.SCDStartDate ) ,SCDActiveFlag='N' 
 FROM  ser.SiteRoleTerritory ter join(select SiteRoleTerritory_mdm.LOVSiteRoleTerritorySetId,SiteRoleTerritory_mdm.LovTerritoryId,SiteRoleTerritory_mdm.siteroleid,UPD.SCDStartDate from
(select src.siteroleid,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LovTerritoryId,src.LOVSiteRoleTerritorySetId from ser.SiteRoleTerritory src 
join 
(select SiteRoleId,max(scdversion) scdversion,lovSiteRoleTerritorySetId,lovrecordsourceId from ser.SiteRoleTerritory
where lovrecordsourceId=12008 group by SiteRoleId,lovSiteRoleTerritorySetId,lovrecordsourceId)P  
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId  and P.lovSiteRoleTerritorySetId=src.lovSiteRoleTerritorySetId
 where src.scdversion=P.scdversion)SiteRoleTerritory_mdm JOIN (
SELECT * FROM ser.SiteRoleTerritory_STG)UPD
ON SiteRoleTerritory_mdm.SiteRoleId=UPD.SiteRoleId AND SiteRoleTerritory_mdm.LOVSiteRoleTerritorySetId=UPD.LOVSiteRoleTerritorySetId
WHERE SiteRoleTerritory_mdm.lovRecordSourceId=UPD.LOVRecordSourceId 
AND NOT EXISTS (                                                     
        SELECT lovTerritoryId ,LOVSiteRoleTerritorySetId  FROM ser.SiteRoleTerritory territory_sr where 
        SiteRoleTerritory_mdm.SiteRoleId=territory_sr.SiteRoleId and SiteRoleTerritory_mdm.lovrecordsourceid=territory_sr.lovrecordsourceid and 
         SiteRoleTerritory_mdm.scdversion=territory_sr.scdversion  
         AND ISNULL(UPD.LOVSiteRoleTerritorySetId,'')=ISNULL(territory_sr.LOVSiteRoleTerritorySetId,'') 
		 AND ISNULL(UPD.LovTerritoryId,'')=ISNULL(territory_sr.LovTerritoryId,'') AND territory_sr.SCDActiveFlag='Y'
          )
		   AND UPD.ExistsFlag=1  )result 
		   on ter.LOVSiteRoleTerritorySetId=result.LOVSiteRoleTerritorySetId and ter.SiteRoleId=result.SiteRoleId --and ter.LovTerritoryId=result.LovTerritoryId
		   


--Inserting data to table with existing version increment by 1 and new record version as 1.
INSERT INTO ser.SiteRoleTerritory(SiteRoleId, LOVSiteRoleTerritorySetId,LovTerritoryId,LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,Psarowkey)
SELECT SiteRoleId, LOVSiteRoleTerritorySetId,LovTerritoryId,LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,row_id
FROM
(SELECT * FROM ser.SiteRoleTerritory_STG)Stage
WHERE Stage.SCDActiveFlag='Y' and Stage.LovTerritoryId!=0
Print 'Info: SiteRoleTerritory Table Loaded Successfully ';


update ser.SiteRoleTerritory set SCDEndDate=siterole.SCDEndDate ,SCDActiveFlag='N'
FROM ser.SiteRoleTerritory src join ( select src.siteroleid,src.LOVSiteRoleTerritorySetId,src.scdversion,src.lovrecordsourceId,src.SCDStartdate from ser.SiteRoleTerritory src
join
(select SiteRoleId,max(scdversion) scdversion,LOVSiteRoleTerritorySetId,lovrecordsourceId from ser.SiteRoleTerritory
where lovrecordsourceId=12008 group by LOVSiteRoleTerritorySetId,SiteRoleId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId and P.LOVSiteRoleTerritorySetId=src.LOVSiteRoleTerritorySetId
 where src.scdversion=P.scdversion)SiteRoleTerritory_mdm
on SiteRoleTerritory_mdm.SiteRoleId=src.SiteRoleId and SiteRoleTerritory_mdm.lovrecordsourceId=src.lovrecordsourceId and SiteRoleTerritory_mdm.LOVSiteRoleTerritorySetId=src.LOVSiteRoleTerritorySetId
JOIN (select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate,sr.SCDEndDate,sr.SCDActiveFlag from ser.siterole sr
join
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole
where lovrecordsourceId=12008 group by sourcekey,lovrecordsourceId)P
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId
 where sr.scdversion=P.scdversion)siterole on SiteRoleTerritory_mdm.SiteRoleId=siterole.SiteRoleId
 where siterole.SCDActiveFlag='N'

delete from ser.[SiteRoleTerritory_STG];
-----------------------------------------TABLE8-SITEROLEINDICATOR---------------------------------------------------
PRINT 'Info: SITEROLE INDICATOR Table Load Started '; 

--create staging table
INSERT INTO [ser].[SiteRoleIndicator_STG]([ExistsFlag],[SiteRoleId],[LOVIndicatorId],[Value],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])
   
               SELECT CASE WHEN SRG.SiteRoleId is  NULL AND SRG.LOVIndicatorId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag, 
				pvt.SiteRoleId, 
				pvt.LOVIndicatorId,
				pvt.Value,
				pvt.LOVRecordSourceId,
				case when SRG.SiteRoleId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
				LEAD(pvt.SCDStartDate,1,CONVERT(DATETIME,'99991231') )OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVIndicatorId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC)	AS SCDEndDate,
               LEAD('N', 1,'Y') OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVIndicatorId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC) SCDActiveFlag
                ,COALESCE(SRG.SCDVersion,0) SCDVersion,pvt.SCDLOVRecordSourceId,@serveETLRunLogID ETLRunLogId ,pvt.row_id 
                 FROM
                 (
                    SELECT SiteRoleID,
       (SELECT LOVId FROM ser.RefLOVSetInfo WHERE LOVKey = ''+PICol+'' AND  LOVSetName = 'Indicator - BUK MDM Site' and lovrecordsourceId=12008) LOVIndicatorId,
	  PIValue as value ,LOVRecordSourceId,SCDStartDate,SCDLOVRecordSourceId,ETLRunLogId,row_id
							FROM
								(
								SELECT sr.SiteRoleId,
								cast(case when mdms.midnight_pharmacy='' or mdms.midnight_pharmacy is null THEN 'F' ELSE mdms.midnight_pharmacy END as varchar(50))  midnight_pharmacy, 
								cast(case when mdms.nhs_contract_flag='' or  mdms.nhs_contract_flag is null THEN 'F' ELSE mdms.nhs_contract_flag END as varchar(50))  nhs_contract_flag, 
								cast(case when mdms.mds_room_flag='' or mdms.mds_room_flag is null THEN 'F' ELSE mdms.mds_room_flag END as varchar(50))  mds_room_flag, 
								
								cast(CASE  WHEN  country_Code='GB'  or  country_Code='UK' THEN 1 ELSE 0 END as varchar(50)) uk_ind  ,
								cast(CASE  WHEN  country_Code='IE'  THEN 1 ELSE 0 END  as varchar(50))roi_ind,
							    cast(CASE  WHEN  store_Number BETWEEN 4910 AND 4919 THEN 1 ELSE 0 END  as varchar(50))online_ind,
								cast(CASE  WHEN  trading_format='Optician' THEN 1 ELSE 0 END  as varchar(50))optician_ind,
								mdms.record_source_Id LOVRecordSourceId,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								CONVERT (date, GETDATE()) as SCDStartDate ,
								null ETLRunLogId,
								mdms.row_id row_id
								FROM psa.uk_btc_mdm_store_stg mdms,
									 (
							select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate from ser.siterole sr 
									join 
							(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
									where lovrecordsourceId=12008 and SCDActiveFlag='Y' group by sourcekey,lovrecordsourceId)P  
										on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId 
											where sr.scdversion=P.scdversion) sr
								WHERE CAST (mdms.store_number as VARCHAR)=sr.SourceKey
									AND mdms.row_status=26001 and mdms.asset_id=@assetId
									AND mdms.record_source_id=sr.LovrecordSourceId
									 ) t
								unpivot
(
  PIValue FOR PICol in    
    (uk_ind,roi_ind,online_ind,optician_ind,midnight_pharmacy,nhs_contract_flag,mds_room_flag)
) as unpiv  )pvt 
LEFT JOIN (select src.siteroleid,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LovIndicatorId,src.Value from ser.SiteRoleIndicator src 
join 
(select SiteRoleId,max(scdversion) scdversion,lovrecordsourceId from ser.SiteRoleIndicator
where lovrecordsourceId=12008 group by SiteRoleId,lovrecordsourceId)P  
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId 
 where src.scdversion=P.scdversion) SRG  on pvt.SiteRoleId=SRG.SiteRoleId AND
            pvt.LOVIndicatorId=SRG.LOVIndicatorId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId   
		where NOT EXISTS (                                                     
        SELECT *  FROM ser.SiteRoleIndicator indicator_sr where 
        pvt.SiteRoleId=indicator_sr.SiteRoleId and pvt.lovrecordsourceid=indicator_sr.lovrecordsourceid  
		AND ISNULL(pvt.LOVIndicatorId,'')=ISNULL(indicator_sr.LOVIndicatorId,'') 
		 AND ISNULL(pvt.Value,'')=ISNULL(indicator_sr.Value,'') AND indicator_sr.SCDActiveFlag='Y'
           )

--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.SiteRoleIndicator SET SCDEndDate=DATEADD(second,-1,result.SCDStartDate ) ,SCDActiveFlag='N' 
FROM ser.SiteRoleIndicator  ind join 
(select SiteRoleIndicator_mdm.LovIndicatorId,SiteRoleIndicator_mdm.Value,SiteRoleIndicator_mdm.siteroleid,UPD.SCDStartDate 
from (select src.siteroleid,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LovIndicatorId,src.Value from ser.SiteRoleIndicator src 
join 
(select SiteRoleId,max(scdversion) scdversion,LovIndicatorId,lovrecordsourceId from ser.SiteRoleIndicator
where lovrecordsourceId=12008 group by SiteRoleId,LovIndicatorId,lovrecordsourceId)P  
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId 
 where src.scdversion=P.scdversion)SiteRoleIndicator_mdm 
 JOIN (
SELECT * FROM ser.SiteRoleIndicator_STG )UPD
ON SiteRoleIndicator_mdm.SiteRoleId=UPD.SiteRoleId   AND SiteRoleIndicator_mdm.LovIndicatorId=UPD.LovIndicatorId
WHERE SiteRoleIndicator_mdm.lovRecordSourceId=UPD.LOVRecordSourceId
AND (UPD.ExistsFlag=1 or UPD.Value='F') )result 
		   on ind.LovIndicatorId=result.LovIndicatorId and ind.SiteRoleId=result.SiteRoleId 
		   


--Inserting data to table with existing version increment by 1 and new record version as 1.
Insert INTO [ser].[SiteRoleIndicator] (SiteRoleId,          
  LOVIndicatorId,            
  Value,
  LOVRecordSourceId,
  SCDStartDate,
  SCDEndDate,  
  SCDActiveFlag,       
  SCDVersion,          
  SCDLOVRecordSourceId,
  ETLRunLogID,PsaRowKey)
  SELECT STAGE.[SiteRoleId] ,
 STAGE.[LOVIndicatorId],
 STAGE.[Value],STAGE.[LOVRecordSourceId] ,STAGE.[SCDStartDate] , STAGE.SCDEndDate,				 
 STAGE.[SCDActiveFlag] , STAGE.SCDVersion +1 ,@SCDLOVRecordSourceId SCDLOVRecordSourceId,
 @serveETLRunLogId  ETLRunLogId,STAGE.row_id FROM (
SELECT *  FROM ser.SiteRoleIndicator_STG    STG WHERE STG.SCDActiveFlag='Y' and  STG.Value!='F' )STAGE

update ser.SiteRoleIndicator set SCDEndDate=siterole.SCDEndDate ,SCDActiveFlag='N'
FROM ser.SiteRoleIndicator src join 
( select src.siteroleid,src.LOVIndicatorId,src.scdversion,src.lovrecordsourceId,src.SCDStartdate from ser.SiteRoleIndicator src
join
(select SiteRoleId,max(scdversion) scdversion,LOVIndicatorId,lovrecordsourceId from ser.SiteRoleIndicator
where lovrecordsourceId=12008 group by SiteRoleId,LOVIndicatorId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId and P.LOVIndicatorId=src.LOVIndicatorId
 where src.scdversion=P.scdversion)SiteRoleIndicator_mdm
 on SiteRoleIndicator_mdm.SiteRoleId=src.SiteRoleId and SiteRoleIndicator_mdm.lovrecordsourceId=src.lovrecordsourceId and SiteRoleIndicator_mdm.LOVIndicatorId=src.LOVIndicatorId

 JOIN (select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate,sr.SCDEndDate,sr.SCDActiveFlag from ser.siterole sr
join
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole
where lovrecordsourceId=12008 group by sourcekey,lovrecordsourceId)P
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId
 where sr.scdversion=P.scdversion)siterole on SiteRoleIndicator_mdm.SiteRoleId=siterole.SiteRoleId
 where siterole.SCDActiveFlag='N'

		
PRINT 'Info: SiteRoleIndicator Table Loaded Successfully ';
delete from [ser].[SiteRoleIndicator_STG]; 
--------------------------------------TABLE9-SITEROLEGROUP--------------------------------------------------------------
Print 'Info: SiteRoleGroup Table Load Started ';
 -- DECLARE @MAXSRGpID int;
SELECT @MAXSRGpID=COALESCE(max(siterolegroupid),0) from ser.siterolegroup;

Insert Into [ser].[SiteRoleGrp_STG](ExistsFlag,SiteRoleGroupId,SiteRoleId,LOVSiteRoleGroupSetId,LOVGroupId,ParentSiteRoleGroupId,LOVRecordSourceId,SCDStartDate
,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,row_id)
    
               
	 SELECT CASE WHEN SRG.SiteRoleGroupId is  NULL AND SRG.LOVGroupId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag, 
				SRG.SiteRoleGroupId,
				pvt.SiteRoleId, 
				pvt.LOVSiteRoleGroupSetId,
				pvt.Lovid as LOVGroupId,
				NULL as ParentSiteRoleGroupId, 
				pvt.LOVRecordSourceId,
				CASE WHEN SRG.SiteRoleGroupId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
				LEAD(pvt.SCDStartDate,1,CONVERT(DATETIME,'99991231') )OVER(PARTITION BY pvt.SiteRoleId,pvt.Lovid,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC)	AS SCDEndDate,
                LEAD('N', 1,'Y') OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVSiteRoleGroupSetId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC) SCDActiveFlag,
				COALESCE(SRG.SCDVersion,0) SCDVersion,pvt.SCDLOVRecordSourceId,@serveETLRunLogID ETLRunLogId,pvt.row_id 
                 FROM
                 (
                    Select SiteRoleID,(SELECT TOP 1 LOVSetId FROM ser.RefLOVSetInfo WHERE LOVSetName = ''+PICol+'' and LOVRecordSourceId=@record_source_id) LOVSiteRoleGroupSetId,
       (SELECT LOVId FROM ser.RefLOVsetInfo WHERE LOVKey = ''+PIValue+''AND 
      LOVSetName = ''+PICol+'' and lovrecordsourceId=12008) Lovid,null as ParentSiteRoleGroupId,
	  LOVRecordSourceId,SCDStartDate,SCDLOVRecordSourceId,@serveETLRunLogID ETLRunLogId,row_id
                 FROM
                (SELECT 
    ISNULL(NULLIF(mdms.distribution_channel,''),'NULL VALUE') distribution_channel,
	ISNULL(NULLIF(mdms.trading_format,''),'NULL VALUE') trading_format,
    ISNULL(NULLIF(mdms.type_of_store_description,''),'NULL VALUE') type_of_store_description,
    ISNULL(NULLIF(mdms.sag,''),'NULL VALUE') sag,
    ISNULL(NULLIF(mdms.mini_sag,''),'NULL VALUE') mini_sag,
    ISNULL(NULLIF(mdms.price_band_code,''),'NULL VALUE') price_band_code,
	ISNULL(NULLIF(mdms.benchmark_group,''),'NULL VALUE') benchmark_group,
	s.SiteRoleId as SiteRoleID,
	mdms.record_source_id as LOVRecordSourceId,
	CONVERT (date, GETDATE()) as SCDStartDate ,
    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	 mdms.etl_runlog_id as ETLRunLogId,
	 mdms.row_id as row_id
  FROM psa.uk_btc_mdm_store_stg mdms ,
     (
select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate from ser.siterole sr 
join 
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
where lovrecordsourceId=12008 AND SCDActiveflag='Y' group by sourcekey,lovrecordsourceId)P  
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId 
 where sr.scdversion=P.scdversion)s 
     WHERE cast(mdms.store_number  as varchar)=s.SourceKey
     and s.LOVRecordSourceId=@record_source_id and mdms.row_status=@row_status and mdms.asset_id=@assetId )t
	 
	 UNPIVOT
(PIValue FOR PICol in         (t.distribution_channel,
                                t.trading_format,
                                t.type_of_store_description,
                                t.sag,
                                t.mini_sag,
                                t.price_band_code,
                                t.benchmark_group))AS LOVGroupIdSS  )pvt 
								LEFT JOIN (
select src.siteroleid,src.SiteRoleGroupId,src.scdversion,src.lovrecordsourceId,src.SCDStartdate,src.LOVSiteRoleGroupSetId,src.LovGroupId  from ser.SiteRoleGroup src 
join 
(select SiteRoleId,max(scdversion) scdversion,SiteRoleGroupId,LOVSiteRoleGroupSetId,lovrecordsourceId from ser.SiteRoleGroup 
where lovrecordsourceId=12008 group by SiteRoleId,SiteRoleGroupId,LOVSiteRoleGroupSetId,lovrecordsourceId)P  
 on P.SiteRoleId=src.SiteRoleId and P.SiteRoleGroupId=src.SiteRoleGroupId and P.lovrecordsourceId=src.lovrecordsourceId and P.LOVSiteRoleGroupSetId=src.LOVSiteRoleGroupSetId
 where src.scdversion=P.scdversion)SRG on pvt.SiteRoleId=SRG.SiteRoleId AND 
            pvt.LOVSiteRoleGroupSetId=SRG.LOVSiteRoleGroupSetId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId 
            where --pvt.Lovid is not NULL AND  pvt.Lovid!='' 
			--AND 
			NOT EXISTS (                                                     
        SELECT LOVGroupId,LOVSiteRoleGroupSetId  FROM ser.SiteRoleGroup sgroup where 
        SRG.SiteRoleId=sgroup.SiteRoleId and SRG.lovrecordsourceid=sgroup.lovrecordsourceid and 
         SRG.scdversion=sgroup.scdversion 
        AND SRG.lovrecordsourceId=pvt.lovrecordsourceId AND ISNULL(pvt.Lovid,'')=ISNULL(SRG.LOVGroupId,'') 
        AND pvt.LOVSiteRoleGroupSetId=ISNULL(SRG.LOVSiteRoleGroupSetId,'')  AND SCDActiveFlag='Y'     
     ) 
			   
	

--updating previous record 
UPDATE ser.SiteRoleGroup SET SCDEndDate=DATEADD(second,-1,UPD.SCDStartDate ) ,SCDActiveFlag='N' 
from ser.SiteRoleGroup sg join (
select src.SiteRoleGroupId,src.siteroleid,src.LOVSiteRoleGroupSetId,src.LOVGroupId,src.scdversion,
src.lovrecordsourceId from ser.siteroleGroup src
join
(select SiteRoleGroupId,SiteRoleId,max(scdversion) scdversion,lovrecordsourceId from ser.SiteroleGroup
where lovrecordsourceId=12008 group by SiteRoleGroupId,SiteRoleId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId and P.SiteRoleGroupId=src.SiteRoleGroupId 
 where src.scdversion=P.scdversion)SiteRoleGroup_mdm 
 on sg.SiteRoleGroupId=SiteRoleGroup_mdm.SiteRoleGroupId and sg.lovrecordsourceId=SiteRoleGroup_mdm.lovrecordsourceId
 JOIN (
SELECT * FROM ser.SiteRoleGrp_STG)UPD
ON SiteRoleGroup_mdm.SiteRoleId=UPD.SiteRoleId AND SiteRoleGroup_mdm.lovRecordSourceId=UPD.LOVRecordSourceId 
AND SiteRoleGroup_mdm.LOVSiteRoleGroupSetId=UPD.LOVSiteRoleGroupSetId 
WHERE UPD.ExistsFlag=1 or UPD.lovGroupId is null

--Inserting to Siterolegroup
 INSERT  INTO  ser.SiteRoleGroup (SiteRoleGroupId,
                                    SiteRoleId     ,
                                    LOVSiteRoleGroupSetId   ,
                                    LOVGroupId  ,
                                    ParentSiteRoleGroupId  ,
                                    LOVRecordSourceId     ,
                                    SCDStartDate          , 
                                    SCDEndDate            ,									
                                    SCDActiveFlag         ,
                                    SCDVersion            ,
                                    SCDLOVRecordSourceId  ,
                                    ETLRunLogId,
									PSARowKey)
									SELECT CASE WHEN STAGE.existsFlag=1 THEN STAGE.SiteRoleGroupId
									ELSE ROW_NUMBER() OVER(ORDER BY STAGE.SiteRoleId,STAGE.LOVSiteRoleGroupSetId,STAGE.LOVRecordSourceId ASC)+0 END  SiteRoleGroupId,
									STAGE.[SiteRoleId] ,
									STAGE.[LOVSiteRoleGroupSetId] ,
                                    STAGE.[LOVGroupId],
                                    STAGE.[ParentSiteRoleGroupId],
									STAGE.[LOVRecordSourceId] ,
									STAGE.[SCDStartDate] , 
									STAGE.SCDEndDate,				 
 STAGE.[SCDActiveFlag] , STAGE.SCDVersion +1 ,@SCDLOVRecordSourceId SCDLOVRecordSourceId,
 @serveETLRunLogId  ETLRunLogId,STAGE.row_id FROM (
 SELECT *  FROM ser.SiteRoleGrp_STG   STG WHERE STG.SCDActiveFlag='Y' and STG.LOVGroupId is not null)STAGE
 
 update ser.SiteRoleGroup set SCDEndDate=siterole.SCDEndDate,SCDActiveFlag='N'
 FROM ser.SiteRoleGroup src join 
( select src.siteroleid,src.LOVSiteRoleGroupSetId,src.scdversion,src.lovrecordsourceId,src.SCDStartdate from ser.SiteRoleGroup src
join
(select SiteRoleId,max(scdversion) scdversion,LOVSiteRoleGroupSetId,lovrecordsourceId from ser.SiteRoleGroup
where lovrecordsourceId=12008 group by SiteRoleId,LOVSiteRoleGroupSetId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId and P.LOVSiteRoleGroupSetId=src.LOVSiteRoleGroupSetId
 where src.scdversion=P.scdversion)SiteRoleGroup_mdm
 on SiteRoleGroup_mdm.SiteRoleId=src.SiteRoleId and SiteRoleGroup_mdm.lovrecordsourceId=src.lovrecordsourceId and SiteRoleGroup_mdm.LOVSiteRoleGroupSetId=src.LOVSiteRoleGroupSetId

JOIN (select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate,sr.SCDEndDate,sr.SCDActiveFlag from ser.siterole sr
join
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole
where lovrecordsourceId=12008 group by sourcekey,lovrecordsourceId)P
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId
 where sr.scdversion=P.scdversion)siterole on SiteRoleGroup_mdm.SiteRoleId=siterole.SiteRoleId
 where siterole.SCDActiveFlag='N'

PRINT 'Info: SiteRoleGroup Table Loaded Successfully ';
delete from [ser].[SiteRoleGrp_STG];

-----------------------------------------TABLE10-SITEROLEPROPERTY---------------------------------------------------
PRINT 'Info: SITEROLE PROPERTY Table Load Started '; 

--create staging table
--reference value
SELECT @uom_idm2 = LovID from [ser].[RefLOVSetInfo]  where LOVKey = 'M2' AND  LOVSetName = 'Unit Of Measure' AND LOVRecordSourceId= 12012
--reference value
SELECT @uom_idunit = LovID from [ser].[RefLOVSetInfo] where LOVKey = 'unit' AND LOVSetName = 'Unit Of Measure' AND LOVRecordSourceId= 12012

SELECT @data_type_id=LOVId from [ser].[RefLOVSetInfo]  where
 LOVKey='STRING' and LOVSetName='Data Type'

SELECT @measure_type_id=LOVId from [ser].[RefLOVSetInfo] where
LOVKey='FLOOR_AREA' and LOVSetName='Measure Type' 
--create staging table
INSERT INTO [ser].[SiteRoleProperty_STG] ([ExistsFlag],[SiteRoleId],[MeasureId],[LOVUOMId],[Value],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])
                SELECT CASE WHEN SRG.SiteRoleId is NULL THEN 0 ELSE 1 END ExistsFlag, 
				pvt.SiteRoleId, 
				pvt.MeasureId,
				pvt.LOVUOMId,
				pvt.Value,
				pvt.LOVRecordSourceId,
				CASE WHEN SRG.SiteRoleId IS NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
				LEAD(pvt.SCDStartDate,1,CONVERT(DATETIME,'99991231') )OVER(PARTITION BY pvt.SiteRoleId,pvt.MeasureId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC)	AS SCDEndDate,
                LEAD('N', 1,'Y') OVER(PARTITION BY pvt.SiteRoleId,pvt.MeasureId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC) SCDActiveFlag,
				COALESCE(SRG.SCDVersion,0) SCDVersion,pvt.SCDLOVRecordSourceId,pvt.ETLRunLogId ,pvt.row_id 
                 FROM
                 (
                    Select SiteRoleID,
					(CASE WHEN PICol='number_of_floors' THEN @uom_idunit ELSE @uom_idm2 END ) LOVUOMId,
				(SELECT  MeasureId from ser.Measure where MeasureName = ''+PICol+'' AND LOVRecordSourceId = @record_source_id and LOVDataTypeId=@data_type_id and LOVMeasureTypeId=@measure_type_id)	MeasureId,
				PIValue as Value,
	  LOVRecordSourceId,SCDStartDate,SCDLOVRecordSourceId,@serveETLRunLogID ETLRunLogId,row_status,asset_id,row_id
                 FROM
                (SELECT 
   

	ISNULL(NULLIF(mdms.store_total_sales_area,''),'NULL VALUE') store_total_sales_area,
    ISNULL(NULLIF(mdms.number_of_floors,''),'NULL VALUE') number_of_floors,
    ISNULL(NULLIF(mdms.non_dispensing_sales_area,''),'NULL VALUE') non_dispensing_sales_area,
    ISNULL(NULLIF(mdms.baby_changing_room_area,''),'NULL VALUE') baby_changing_room_area,
    ISNULL(NULLIF(mdms.customer_toilets_area,''),'NULL VALUE') customer_toilets_area,
    ISNULL(NULLIF(mdms.health_clinic_area,''),'NULL VALUE') health_clinic_area,
    ISNULL(NULLIF(mdms.opticans_off_sales_area,''),'NULL VALUE') opticans_off_sales_area,
	ISNULL(NULLIF(mdms.opticans_on_sales_area,''),'NULL VALUE') opticans_on_sales_area,
	ISNULL(NULLIF(mdms.pharmacy_consultation_area,''),'NULL VALUE') pharmacy_consultation_area,
	ISNULL(NULLIF(mdms.photolab_off_sales_area,''),'NULL VALUE') photolab_off_sales_area,
	ISNULL(NULLIF(mdms.photolab_on_sales_area,''),'NULL VALUE') photolab_on_sales_area,
	s.SiteRoleId as SiteRoleID,
	mdms.record_source_id as LOVRecordSourceId,
	CONVERT (date, GETDATE()) as SCDStartDate ,
    @record_source_id as SCDLOVRecordSourceId,
	mdms.etl_runlog_id as ETLRunLogId,
	mdms.row_status as row_status,
	mdms.asset_id as asset_id,
	mdms.row_id as row_id
  FROM psa.uk_btc_mdm_store_stg mdms ,
(
select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate from ser.siterole sr 
join 
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
where lovrecordsourceId=12008 and SCDActiveFlag='Y'  group by sourcekey,lovrecordsourceId)P  
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId 
 where sr.scdversion=P.scdversion)s 
	  
	  
  WHERE cast(mdms.store_number  as varchar)=s.SourceKey and s.LOVRecordSourceId=@record_source_id and mdms.asset_id=@assetId 
  and mdms.row_status=@row_status 
   )t
   
	 UNPIVOT
(PIValue FOR PICol in         (t.store_total_sales_area,
                                t.number_of_floors,
                                t.non_dispensing_sales_area,
                                t.baby_changing_room_area,
                                t.customer_toilets_area,
                                t.health_clinic_area,
                                t.opticans_off_sales_area,
								t.opticans_on_sales_area,
								t.pharmacy_consultation_area,
								t.photolab_off_sales_area,
								t.photolab_on_sales_area))AS LOVGroupId  )pvt 
								
								LEFT JOIN (
select src.SiteRoleId,src.MeasureId,src.LOVUOMId,src.Value,src.LOVRecordSourceId,src.SCDStartDate,src.SCDVersion  from ser.SiteRoleProperty src 
join 
(select SiteRoleId,max(scdversion) scdversion,MeasureId,LOVUOMId,lovrecordsourceId from ser.SiteRoleProperty 
where lovrecordsourceId=12008 group by SiteRoleId,MeasureId,LOVUOMId,lovrecordsourceId)P  
 on P.SiteRoleId=src.SiteRoleId and P.MeasureId=src.MeasureId and P.lovrecordsourceId=src.lovrecordsourceId and P.LOVUOMId=src.LOVUOMId --and P.Value=src.Value
 where src.scdversion=P.scdversion)SRG on pvt.SiteRoleId=SRG.SiteRoleId AND 
            pvt.MeasureId=SRG.MeasureId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId 
            where 
			 NOT EXISTS (                                                     
        SELECT LOVUOMId,MeasureId,Value  FROM ser.SiteRoleProperty sproperty where 
        SRG.SiteRoleId=sproperty.SiteRoleId and SRG.lovrecordsourceid=sproperty.lovrecordsourceid and 
        SRG.scdversion=sproperty.scdversion 
        AND SRG.lovrecordsourceId=pvt.lovrecordsourceId AND ISNULL(pvt.LOVUOMId,'')=ISNULL(SRG.LOVUOMId,'') 
		AND ISNULL(pvt.Value,'')=ISNULL(SRG.Value,'')
        AND ISNULL(pvt.MeasureId,'')=ISNULL(SRG.MeasureId,'')  AND sproperty.SCDActiveFlag= 'Y'     
     )
												

UPDATE ser.SiteRoleProperty SET SCDEndDate=DATEADD(second,-1,result.SCDStartDate ) ,SCDActiveFlag='N'
FROM ser.SiteRoleProperty  prop join
(select SiteRoleProperty_mdm.LOVUOMId,SiteRoleProperty_mdm.MeasureId,SiteRoleProperty_mdm.Value,SiteRoleProperty_mdm.siteroleid,UPD.SCDStartDate
from (select src.SiteRoleId,src.MeasureId,src.LOVUOMId,src.Value,src.LOVRecordSourceId,src.SCDStartDate,src.SCDVersion from ser.SiteRoleProperty src
join
(select SiteRoleId,max(scdversion) scdversion,MeasureId,lovrecordsourceId from ser.SiteRoleProperty
where lovrecordsourceId=12008 group by SiteRoleId,MeasureId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId
 where src.scdversion=P.scdversion)SiteRoleProperty_mdm
 JOIN (
SELECT * FROM ser.SiteRoleProperty_STG )UPD
ON SiteRoleProperty_mdm.SiteRoleId=UPD.SiteRoleId AND SiteRoleProperty_mdm.LOVUOMId=UPD.LOVUOMId AND SiteRoleProperty_mdm.MeasureId=UPD.MeasureId
WHERE SiteRoleProperty_mdm.lovRecordSourceId=UPD.LOVRecordSourceId
AND (UPD.ExistsFlag=1 or UPD.Value='NULL VALUE')  )result
           on prop.LOVUOMId=result.LOVUOMId and prop.SiteRoleId=result.SiteRoleId AND prop.MeasureId=result.MeasureId 
		   

		   
		   

Insert INTO [ser].[SiteRoleProperty] (SiteRoleId,          
  MeasureId,           
  LOVUOMId,            
  Value,
  LOVRecordSourceId,
  SCDStartDate,        
  SCDEndDate ,      
  SCDActiveFlag,       
  SCDVersion,          
  SCDLOVRecordSourceId,
  ETLRunLogID,PsaRowKey)
 SELECT STAGE.[SiteRoleId] ,
 STAGE.[MeasureId],STAGE.[LOVUOMId] ,
 STAGE.[Value],STAGE.[LOVRecordSourceId] ,STAGE.[SCDStartDate] , STAGE.SCDEndDate,				 
 STAGE.[SCDActiveFlag] , STAGE.SCDVersion +1 ,@SCDLOVRecordSourceId SCDLOVRecordSourceId,
 @serveETLRunLogId  ETLRunLogId,STAGE.row_id FROM (
SELECT *  FROM ser.SiteRoleProperty_STG    STG WHERE STG.SCDActiveFlag='Y' AND STG.Value!='NULL VALUE'
)STAGE

update ser.SiteRoleProperty set SCDEndDate=siterole.SCDEndDate ,SCDActiveFlag='N'
 FROM ser.SiteRoleProperty src join
( select src.siteroleid,src.scdversion,src.MeasureId,src.lovrecordsourceId,src.SCDStartdate from ser.SiteRoleProperty src
join
(select SiteRoleId,max(scdversion) scdversion,MeasureId,lovrecordsourceId from ser.SiteRoleProperty
where lovrecordsourceId=12008 group by MeasureId,SiteRoleId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId and src.Measureid=P.MeasureId
 where src.scdversion=P.scdversion )SiteRoleProperty_mdm
on SiteRoleProperty_mdm.SiteRoleId=src.SiteRoleId and SiteRoleProperty_mdm.lovrecordsourceId=src.lovrecordsourceId and SiteRoleProperty_mdm.Measureid=src.MeasureId
JOIN (select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate,sr.SCDEndDate,sr.SCDActiveFlag from ser.siterole sr
join
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole
where lovrecordsourceId=12008 group by sourcekey,lovrecordsourceId)P
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId
 where sr.scdversion=P.scdversion)siterole on SiteRoleProperty_mdm.SiteRoleId=siterole.SiteRoleId
 where siterole.SCDActiveFlag='N' 
			
Delete from ser.SiteRoleProperty_STG;  

-----------------------------------------TABLE11-PARTY---------------------------------------------------
PRINT 'Info: PARTY Table Load Started '; 



select @MAXPartyId=ISNULL(max(PartyId),0) FROM ser.Party;

select @PartyTypeId= r.LOVId FROM [ser].[RefLOVSetInfo] r WHERE r.LOVKey = 'ORG'  AND r.LOVSetName ='Party Type' AND r.LOVRecordSourceId= 12012

INSERT INTO ser.Party(PartyId, LOVPartyTypeId, SourceKey, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,Psarowkey)
select COALESCE( @MAXPartyId,0) + ROW_NUMBER() OVER(ORDER BY  ser.SourceKey,ser.lovrecordsourceId) PartyId,ser.PartyTypeId,
ser.SourceKey,ser.lovrecordsourceId,ser.SCDStartDate,@SCDEndDate,'Y', 1, @SCDLOVRecordSourceId,ser.ETLRunLogId,ser.row_id from 
(SELECT CASE WHEN Party.PartyId IS NULL THEN 0 ELSE 1 END ExistsFlag,
Party.PartyId,
@PartyTypeId PartyTypeId,
store.SourceKey, 
store.lovrecordsourceId, 
@SCDStartDate_new  as SCDStartDate,
@serveETLRunLogID ETLRunLogId,
store.row_id 
FROM (
(select sales_organisation SourceKey,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id,asset_id from [psa].[uk_btc_mdm_store_stg]
where row_status=@row_status and asset_id=@assetId group by sales_organisation ,etl_runlog_id ,record_source_id ,row_status,asset_id )
union
(select primary_care_organisation_description SourceKey,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id,asset_id from [psa].[uk_btc_mdm_store_stg] 
where row_status=@row_status and asset_id=@assetId group by primary_care_organisation_description ,etl_runlog_id ,record_source_id ,row_status,asset_id)
union
(select name_of_health_authority SourceKey,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id,asset_id from [psa].[uk_btc_mdm_store_stg]
where row_status=@row_status and asset_id=@assetId group by name_of_health_authority ,etl_runlog_id ,record_source_id ,row_status,asset_id))store
LEFT JOIN ser.Party Party
on store.lovrecordsourceId=Party.lovrecordsourceId AND Party.SourceKey=store.SourceKey AND PArty.SCDActiveFlag='Y' 
AND Party.LOVPartyTypeId=@PartyTypeId where store.Sourcekey is not null and store.Sourcekey!='' and store.row_status=@row_status and store.asset_id=@assetId)ser
where ser.ExistsFlag=0


-----------------------------------------TABLE12-PARTYROLE---------------------------------------------------
PRINT 'Info: PARTY ROLE Table Load Started '; 






SELECT @role_id_partyrole_sorg=r.LOVId from [ser].[RefLOVSetInfo] r where r.LOVKey='Retailer' and r.LOVSetName='Role' AND r.LOVRecordSourceId= 12012

--referencevalue
SELECT @role_id_partyrole=r.LOVId from [ser].[RefLOVSetInfo] r where r.LOVKey='Primary Care Trust' and r.LOVSetName='Role' AND r.LOVRecordSourceId= 12012

--referencevalue
SELECT @role_id_partyrole_health=r.LOVId from [ser].[RefLOVSetInfo] r where r.LOVKey='Health Authority' and r.LOVSetName='Role' AND r.LOVRecordSourceId= 12012

--maxvalue for partyRoleId
SELECT @MAXPartyRoleId=isnull(max(PartyRoleId),0) FROM ser.PartyRole;

--create staging table
INSERT INTO ser.PartyRole_mdm_tempg_STG([ExistsFlag],[PartyRoleId],[LOVRoleId],[PartyId],[SourceKey],[PartyRoleName],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate]
          ,[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])

SELECT CASE WHEN PartyRole.PartyRoleId IS NULL THEN 0 ELSE 1 END AS ExistsFlag,
ISNULL(PartyRole.PartyRoleId,(@MAXPartyRoleId + ROW_NUMBER() OVER(ORDER BY  PartyRole.SourceKey,PartyRole.LOVRoleId,PartyRole.LOVRecordSourceId))) PartyRoleId,
CASE WHEN ST.roletype='sales_organisation' THEN  @role_id_partyrole_sorg 
WHEN ST.roletype='primary_care_organisation_description' THEN @role_id_partyrole  
ELSE @role_id_partyrole_health END  LOVRoleId,
ST.PartyId,
ST.SourceKey,
ST.PartyRoleName,
ST.LOVRecordSourceId, 
CASE WHEN PartyRole.PartyRoleId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
LEAD(CONVERT(DateTime,ST.SCDStartDate),1,'99991231') OVER(PARTITION BY ST.PartyId,ST.LOVRecordSourceId ORDER BY ST.SCDStartDate) SCDEndDate,
LEAD('N',1,'Y') OVER(PARTITION BY ST.PartyId,ST.LOVRecordSourceId ORDER BY ST.SCDStartDate) SCDActiveFlag,
COALESCE(PartyRole.SCDVersion,0) + 1 SCDVersion,
@SCDLOVRecordSourceId SCDLOVRecordSourceId , @serveETLRunLogID ETLRunLogId,ST.row_id
FROM (
select party.PartyId,store.SourceKey,store.PartyRoleName,store.ETLRunLogId,store.LOVRecordSourceId,store.SCDStartDate,store.row_status,store.asset_id,store.row_id,store.roletype from

( ( select sales_organisation SourceKey,company_name as PartyRoleName,etl_runlog_id ETLRunLogId,record_source_id LOVRecordSourceId,@SCDStartDate SCDStartDate,row_status,asset_id,Min(row_id) row_id,'sales_organisation' roletype from [psa].[uk_btc_mdm_store_stg]
where row_status=@row_status and asset_id=@assetId group by sales_organisation ,company_name,etl_runlog_id ,record_source_id ,row_status,asset_id)
union
(select primary_care_organisation_description SourceKey,primary_care_organisation_description as PartyRoleName,etl_runlog_id ETLRunLogId,record_source_id LOVRecordSourceId,@SCDStartDate SCDStartDate,row_status,asset_id,Min(row_id) row_id,'primary_care_organisation_description' roletype from [psa].[uk_btc_mdm_store_stg]
where row_status=@row_status and asset_id=@assetId group by primary_care_organisation_description,primary_care_organisation_description ,etl_runlog_id ,record_source_id ,row_status,asset_id)
union
(select name_of_health_authority SourceKey,name_of_health_authority as PartyRoleName,etl_runlog_id ETLRunLogId,record_source_id LOVRecordSourceId,@SCDStartDate SCDStartDate,row_status,asset_id,Min(row_id) row_id,'name_of_health_authority' roletype from [psa].[uk_btc_mdm_store_stg]
where row_status=@row_status and asset_id=@assetId group by name_of_health_authority ,name_of_health_authority,etl_runlog_id ,record_source_id ,row_status,asset_id))store,
(
select sr.PartyId,sr.SourceKey,sr.SCDVersion,sr.LOVRecordSourceId,sr.SCDStartdate from ser.Party sr 
join 
(select SourceKey,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.Party
where LOVRecordSourceId=12008 group by SourceKey,LOVRecordSourceId)P  
 on P.SourceKey=sr.SourceKey and P.LOVRecordSourceId=sr.LOVRecordSourceId 
 where sr.SCDVersion=P.SCDVersion)party where store.SourceKey=party.SourceKey and store.LOVRecordSourceId =party.LOVRecordSourceId 
)ST

LEFT JOIN (
select src.PartyRoleId,src.PartyId,src.SourceKey,src.PartyRoleName,src.SCDVersion,src.LOVRecordSourceId,src.SCDStartdate,src.LOVRoleId from ser.PartyRole src 
join 
(select PartyRoleId,PartyId,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.PartyRole
where LOVRecordSourceId=12008 group by PartyId,LOVRecordSourceId,PartyRoleId)P  
 on P.PartyId=src.PartyId and P.LOVRecordSourceId=src.LOVRecordSourceId 
 where src.SCDVersion=P.SCDVersion)PartyRole
on ST.LOVRecordSourceId=PartyRole.LOVRecordSourceId 
AND ST.PartyId=PartyRole.PartyId
where ST.SourceKey is not null and ST.SourceKey!='' and ST.row_status=@row_status and ST.asset_id=@assetId

AND NOT EXISTS (SELECT Pr.PartyRoleName,Pr.SourceKey  FROM (select src.PartyRoleId,src.PartyId,src.SourceKey,src.PartyRoleName,src.SCDVersion,src.LOVRecordSourceId,src.SCDStartdate,src.LOVRoleId from ser.PartyRole src 
join 
(select PartyRoleId,PartyId,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.PartyRole
where LOVRecordSourceId=12008 group by PartyId,LOVRecordSourceId,PartyRoleId)P  
 on P.PartyId=src.PartyId and P.LOVRecordSourceId=src.LOVRecordSourceId 
 where src.SCDVersion=P.SCDVersion) Pr where 
        PartyRole.PartyId=Pr.PartyId and PartyRole.LOVRecordSourceId=Pr.LOVRecordSourceId and 
         PartyRole.SCDVersion=Pr.SCDVersion 
         AND ISNULL(ST.PartyRoleName,'')=ISNULL(PartyRole.PartyRoleName,'') 
        )

UPDATE ser.PartyRole   set SCDEndDate=DATEADD(second,-1,@SCDStartDate),SCDActiveFlag='N'
 FROM ser.PartyRole pr 
 join
(select PartyRoleId,SourceKey,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.PartyRole
where LOVRecordSourceId=12008 group by PartyRoleId,SourceKey,LOVRecordSourceId)P
 on P.SourceKey=pr.SourceKey and P.LOVRecordSourceId=pr.LOVRecordSourceId
 AND pr.SCDVersion=P.SCDVersion
 AND pr.PartyRoleID=p.PartyRoleID
join ((select sales_organisation SourceKey,record_source_id,company_name PartyRoleName,row_status,asset_id from psa.uk_btc_mdm_store_stg 
where row_status=@row_status and asset_id=@assetId group by sales_organisation,record_source_id,company_name,row_status,asset_id)
union (select primary_care_organisation_description SourceKey,record_source_id,primary_care_organisation_description PartyRoleName,row_status,asset_id from psa.uk_btc_mdm_store_stg
 where row_status=@row_status and asset_id=@assetId group by primary_care_organisation_description,record_source_id,row_status,asset_id)
union (select name_of_health_authority SourceKey,record_source_id,name_of_health_authority PartyRoleName,row_status,asset_id from psa.uk_btc_mdm_store_stg 
where row_status=@row_status and asset_id=@assetId group by name_of_health_authority,record_source_id,row_status,asset_id)) mdms
ON mdms.record_source_id=pr.LovRecordSourceId 
AND pr.SourceKey = mdms.SourceKey
Where mdms.row_status=@row_status and mdms.asset_id=@assetId--AND  mdms.created_timestamp=@created_timestamp
AND NOT EXISTS (select * from ser.PartyRole srp where srp.SourceKey=mdms.SourceKey 
                                                    AND mdms.record_source_id=srp.LOVRecordSourceId
                                                    AND ISNULL(mdms.PartyRoleName,'')=ISNULL(srp.PartyRoleName,'')                                                     
                                                    AND pr.SCDVersion=srp.ScdVersion
                                                );

--Inserting data to table with existing version increment by 1 and new record version as 1.
INSERT INTO ser.PartyRole([PartyRoleId],[LOVRoleId],[PartyId],[SourceKey],[PartyRoleName],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate]
          ,[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[PSARowKey])
SELECT PartyRoleId,LOVRoleId,PartyId,SourceKey,PartyRoleName,LOVRecordSourceId,SCDStartDate,SCDEndDate
          ,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,row_id
FROM
(SELECT * FROM ser.PartyRole_mdm_tempg_STG)Stage
WHERE Stage.SCDActiveFlag='Y'

Delete from ser.PartyRole_mdm_tempg_STG;

-----------------------------------------TABLE13-ORGANISATION---------------------------------------------------
PRINT 'Info: ORGANISATION Table Load Started '; 


INSERT INTO ser.Organisation_mdm_tempg_STG(ExistsFlag,PartyId, SourceOrganisationKey,OrganisationName,ParentPartyID, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,row_id)


SELECT CASE WHEN Organisation.PartyId IS NULL THEN 0 ELSE 1 END ExistsFlag,
STG.PartyId,
STG.SourceOrganisationKey,
STG.OrganisationName,
NULL as ParentPartyID,
STG.lovrecordsourceId, 
CASE WHEN Organisation.PartyId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
--store.SCDStartDate,
LEAD(CONVERT(DateTime,STG.SCDStartDate),1,'99991231') OVER(PARTITION BY STG.PartyId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDEndDate,
LEAD('N',1,'Y') OVER(PARTITION BY STG.PartyId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDActiveFlag,
COALESCE(Organisation.SCDVersion,0) + 1 SCDVersion,@SCDLOVRecordSourceId SCDLOVRecordSourceId , @serveETLRunLogID ETLRunLogId,STG.row_id

FROM (

select party.PartyId,store.SourceOrganisationKey,store.OrganisationName,store.ETLRunLogId,store.lovrecordsourceId,store.SCDStartDate,store.row_status,store.asset_id,store.row_id from

((select sales_organisation SourceOrganisationKey,company_name OrganisationName,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,asset_id,Min(row_id) row_id from [psa].[uk_btc_mdm_store_stg]
 where row_status=@row_status and asset_id=@assetId group by sales_organisation ,company_name,etl_runlog_id ,record_source_id ,row_status,asset_id )
union
(select primary_care_organisation_description SourceOrganisationKey,primary_care_organisation_description OrganisationName,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,asset_id,Min(row_id) row_id from [psa].[uk_btc_mdm_store_stg] 
where primary_care_organisation_description is not null or primary_care_organisation_description!='' and row_status=@row_status and asset_id=@assetId group by primary_care_organisation_description ,primary_care_organisation_description,etl_runlog_id ,record_source_id ,row_status,asset_id)
union
(select name_of_health_authority SourceOrganisationKey,name_of_health_authority OrganisationName,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,asset_id,Min(row_id) row_id from [psa].[uk_btc_mdm_store_stg]
where name_of_health_authority is not null or name_of_health_authority!='' and row_status=@row_status and asset_id=@assetId group by name_of_health_authority ,name_of_health_authority,etl_runlog_id ,record_source_id ,row_status,asset_id))store,
(
select sr.PartyId,sr.SourceKey,sr.SCDVersion,sr.LOVRecordSourceId,sr.SCDStartdate from ser.Party sr 
join 
(select SourceKey,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.Party 
where LOVRecordSourceId=12008 group by SourceKey,LOVRecordSourceId)P  
 on P.SourceKey=sr.SourceKey and P.LOVRecordSourceId=sr.LOVRecordSourceId 
 where sr.SCDVersion=P.SCDVersion)party where store.SourceOrganisationKey=party.SourceKey and store.LOVRecordSourceId =party.LOVRecordSourceId 
 
)STG


LEFT JOIN (

select src.PartyId,src.SourceOrganisationKey,src.OrganisationName,src.SCDVersion,src.lovrecordsourceId,src.SCDStartDate from ser.Organisation src 
join 
(select PartyId,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.Organisation 
where LOVRecordSourceId=12008 group by PartyId,LOVRecordSourceId)P  
 on P.PartyId=src.PartyId and P.LOVRecordSourceId=src.LOVRecordSourceId 
 where src.SCDVersion=P.SCDVersion)Organisation
on STG.LOVRecordSourceId=Organisation.LOVRecordSourceId 
AND STG.PartyId=Organisation.PartyId
where STG.SourceOrganisationKey is not null and STG.SourceOrganisationKey!='' and STG.row_status=@row_status and STG.asset_id=@assetId

AND NOT EXISTS (SELECT O.OrganisationName,O.SourceOrganisationKey  FROM ser.Organisation O where 
        Organisation.PartyId=O.PartyId and Organisation.LOVRecordSourceId=O.LOVRecordSourceId and 
         Organisation.SCDVersion=O.SCDVersion 
        AND Organisation.LOVRecordSourceId=STG.LOVRecordSourceId AND ISNULL(STG.OrganisationName,'')=ISNULL(Organisation.OrganisationName,'') 
        )
		
--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.Organisation   set SCDEndDate=DATEADD(second,-1,@SCDStartDate),SCDActiveFlag='N'
 FROM ser.Organisation sr
 join
(select PartyId,SourceOrganisationKey,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.Organisation
where LOVRecordSourceId=12008 group by PartyId,SourceOrganisationKey,LOVRecordSourceId)P
 on P.SourceOrganisationKey=sr.SourceOrganisationKey and P.LOVRecordSourceId=sr.LOVRecordSourceId
 AND sr.SCDVersion=P.SCDVersion
 AND sr.PartyID=P.partyID
join ((select sales_organisation SourceOrganisationKey,record_source_id,company_name OrganisationName,row_status,asset_id from psa.uk_btc_mdm_store_stg
where row_status=@row_status and asset_id=@assetId group by sales_organisation,record_source_id,company_name,row_status,asset_id)
union (select primary_care_organisation_description SourceOrganisationKey,record_source_id,primary_care_organisation_description OrganisationName,row_status,asset_id from psa.uk_btc_mdm_store_stg
where row_status=@row_status and asset_id=@assetId group by primary_care_organisation_description,record_source_id,row_status,asset_id)
union (select name_of_health_authority SourceOrganisationKey,record_source_id,name_of_health_authority OrganisationName,row_status,asset_id from psa.uk_btc_mdm_store_stg
where row_status=@row_status and asset_id=@assetId  group by name_of_health_authority,record_source_id,row_status,asset_id)) mdms
ON mdms.record_source_id=sr.LovRecordSourceId 
AND sr.SourceOrganisationKey = mdms.SourceOrganisationKey
Where mdms.row_status=@row_status and mdms.asset_id=@assetId --AND  mdms.created_timestamp=@created_timestamp
AND NOT EXISTS (select * from ser.Organisation srp where srp.SourceOrganisationKey=mdms.SourceOrganisationKey 
                                                    AND mdms.record_source_id=srp.LOVRecordSourceId
                                                    AND ISNULL(mdms.OrganisationName,'')=ISNULL(srp.OrganisationName,'')
                                                    AND sr.SCDVersion=srp.ScdVersion
                                                );


--Inserting data to table with existing version increment by 1 and new record version as 1.
INSERT INTO ser.Organisation(PartyId, SourceOrganisationKey,OrganisationName,ParentPartyID, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT PartyId, SourceOrganisationKey,OrganisationName,ParentPartyID, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,row_id
FROM
(SELECT * FROM ser.Organisation_mdm_tempg_STG)Stage
WHERE Stage.SCDActiveFlag='Y'

Delete from ser.Organisation_mdm_tempg_STG;

-----------------------------------------TABLE14-PARTYROLESITEROLERELATIONSHIP---------------------------------------------------
PRINT 'Info: PARTYROLESITEROLERELATIONSHIP Table Load Started '; 

--refernce value
SELECT @party_relationship_type_of = r.LOVId FROM [ser].[RefLOVSetInfo] r where
r.LOVKey='Operates From' AND r.LOVSetName='Relationship Type' AND r.LOVRecordSourceId= 12012

--reference value
SELECT @party_relationship_type_aw = r.LOVId FROM [ser].[RefLOVSetInfo] r where
r.LOVKey='Associated With' AND r.LOVSetName='Relationship Type'  AND r.LOVRecordSourceId= 12012

SELECT @role_id_partyrole_sorg=r.LOVId from [ser].[RefLOVSetInfo] r where r.LOVKey='Retailer' and r.LOVSetName='Role' AND r.LOVRecordSourceId= 12012

--referencevalue
SELECT @role_id_partyrole=r.LOVId from [ser].[RefLOVSetInfo] r where r.LOVKey='Primary Care Trust' and r.LOVSetName='Role' AND r.LOVRecordSourceId= 12012

--referencevalue
SELECT @role_id_partyrole_health=r.LOVId from [ser].[RefLOVSetInfo] r where r.LOVKey='Health Authority' and r.LOVSetName='Role' AND r.LOVRecordSourceId= 12012

--create staging table
INSERT  INTO ser.[PartyRoleSiteRoleRelationship_mdm_tempg_STG](ExistsFlag,PartyRoleId,SiteRoleId,LOVRelationshipTypeId,LOVRecordSourceId,SCDStartDate,
SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,row_id)

SELECT CASE WHEN PartyRoleSiteRoleRelationship.PartyRoleId IS NULL THEN 0 ELSE 1 END ExistsFlag,
STG.PartyRoleId,
STG.SiteRoleId SiteRoleId,
STG.LOVRelationshipTypeId,
STG.lovrecordsourceId, 
CASE WHEN PartyRoleSiteRoleRelationship.PartyRoleId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
LEAD(CONVERT(DateTime,STG.SCDStartDate),1,'99991231') OVER(PARTITION BY STG.sourceKey,STG.PartyRoleId,STG.SiteRoleId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDEndDate,
LEAD('N',1,'Y') OVER(PARTITION BY STG.sourceKey,STG.PartyRoleId,STG.SiteRoleId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDActiveFlag,
COALESCE(PartyRoleSiteRoleRelationship.SCDVersion,0) + 1 SCDVersion,@SCDLOVRecordSourceId SCDLOVRecordSourceId ,@serveETLRunLogID,STG.row_id

FROM (
select store.SourceKey,
PartyRole.PartyRoleId,
SiteRole.SiteRoleId,
store.roleTypeId,store.lovrecordsourceId,store.SCDStartDate,store.row_status,store.asset_id,store.ETLRunLogId,store.row_id, store.LOVRelationshipTypeId
from (--sales_organisation
(select sales_organisation sourceKey,store_number,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,asset_id,Min(row_id) row_id,'sales_organisation' roleTypeId,@role_id_partyrole_sorg roleId,@party_relationship_type_of LOVRelationshipTypeId  from psa.uk_btc_mdm_store_stg
where row_status=@row_status and asset_id=@assetId and record_source_id=@record_source_id group by sales_organisation ,store_number,etl_runlog_id ,record_source_id ,row_status,asset_id )
union
--primary_care_organisation_description
(select primary_care_organisation_description sourceKey,store_number,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,asset_id,Min(row_id) row_id,'primary_care_organisation_description' roleTypeId,@role_id_partyrole roleId,@party_relationship_type_aw LOVRelationshipTypeId from psa.uk_btc_mdm_store_stg
where row_status=@row_status and asset_id=@assetId and record_source_id=@record_source_id and primary_care_organisation_description is not null and primary_care_organisation_description!='' group by primary_care_organisation_description ,store_number,etl_runlog_id ,record_source_id ,row_status,asset_id)
union
--name_of_health_authority
(select name_of_health_authority sourceKey,store_number,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,asset_id,Min(row_id) row_id,'name_of_health_authority' roleTypeId,@role_id_partyrole_health  roleId,@party_relationship_type_aw LOVRelationshipTypeId from psa.uk_btc_mdm_store_stg --@role_id_partyrole_health
where row_status=@row_status and asset_id=@assetId and record_source_id=@record_source_id and name_of_health_authority is not null and name_of_health_authority!='' group by name_of_health_authority ,store_number,etl_runlog_id ,record_source_id ,row_status,asset_id)

)store,

(
select src.PartyRoleId,src.PartyId,src.SourceKey,src.PartyRoleName,src.SCDVersion,src.LOVRecordSourceId,src.SCDStartdate,src.LOVRoleId from ser.PartyRole src 
join 
(select PartyRoleId,PartyId,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.PartyRole 
where LOVRecordSourceId=12008 group by PartyRoleId,PartyId,LOVRecordSourceId)P  
 on P.PartyId=src.PartyId and P.LOVRecordSourceId=src.LOVRecordSourceId 
 where src.SCDVersion=P.SCDVersion)PartyRole,
--ser.PartyRole p,
(select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate from ser.SiteRole sr 
join 
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.SiteRole  
where lovrecordsourceId=12008 and SCDActiveFlag='Y'  group by sourcekey,lovrecordsourceId)P  
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId 
 where sr.scdversion=P.scdversion)SiteRole
 --ser.SiteRole s
  where 
  store.sourcekey=PartyRole.SourceKey and store.lovrecordSourceid=PartyRole.lovrecordsourceid
  and store.row_status=@row_status and store.roleId=PartyRole.LoVRoleId
   and SiteRole.sourcekey=store.store_number and 
	 store.lovrecordsourceId=SiteRole.LOVRecordSourceId 
	--and  p.SCDActiveFlag='Y' and s.SCDActiveFlag='Y'  
) STG  

LEFT JOIN (
select src.PartyRoleId,src.SiteRoleId,src.LOVRelationshipTypeId,src.LOVRecordSourceId,src.SCDStartDate,src.SCDVersion from
ser.PartyRoleSiteRoleRelationship src
join
(select PartyRoleId,SiteRoleId,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.PartyRoleSiteRoleRelationship
where LOVRecordSourceId=12008 group by PartyRoleId,SiteRoleId,LOVRecordSourceId)P  
on P.PartyRoleId=src.PartyRoleId and P.SiteRoleId=src.SiteRoleId and P.LOVRecordSourceId=src.LOVRecordSourceId
where src.SCDVersion=P.SCDVersion)PartyRoleSiteRoleRelationship
on STG.lovrecordsourceId=PartyRoleSiteRoleRelationship.lovrecordsourceId  and STG.SiteRoleId=PartyRoleSiteRoleRelationship.SiteRoleId
and STG.PartyRoleId=PartyRoleSiteRoleRelationship.PartyRoleId --AND  PartyRoleSiteRoleRelationship.SCDActiveFlag='Y' 
where  
STG.SourceKey is not null and STG.SourceKey!='' and STG.row_status=@row_status and STG.asset_id=@assetId
 and STG.lovrecordsourceId=@record_source_id
	 

AND NOT EXISTS (SELECT Pr.LOVRelationshipTypeId  FROM ser.PartyRoleSiteRoleRelationship Pr where 
        PartyRoleSiteRoleRelationship.PartyRoleId=Pr.PartyRoleId and PartyRoleSiteRoleRelationship.SiteRoleId=Pr.SiteRoleId 
		and PartyRoleSiteRoleRelationship.LOVRecordSourceId=Pr.LOVRecordSourceId and 
         PartyRoleSiteRoleRelationship.SCDVersion=Pr.SCDVersion 
        AND PartyRoleSiteRoleRelationship.LOVRecordSourceId=STG.LOVRecordSourceId 
		AND ISNULL(STG.LOVRelationshipTypeId,0)=ISNULL(PartyRoleSiteRoleRelationship.LOVRelationshipTypeId,0) 
        )
	



--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.PartyRoleSiteRoleRelationship SET SCDEndDate=DATEADD(second,-1,SCDStartDate ) ,SCDActiveFlag='N' 
FROM ser.PartyRoleSiteRoleRelationship  sr 
join
(select PartyRoleId,SiteRoleId,LOVRelationshipTypeId,max(SCDVersion) SCDVersion,LOVRecordSourceId from ser.PartyRoleSiteRoleRelationship
where LOVRecordSourceId=12008 group by LOVRelationshipTypeId,PartyRoleId,SiteRoleId,LOVRecordSourceId)P
on P.PartyRoleId=sr.PartyRoleId and P.SiteRoleId=sr.SiteRoleId and P.LOVRecordSourceId=sr.LOVRecordSourceId
 AND sr.SCDVersion=P.SCDVersion
 and sr. LOVRelationshipTypeId=sr.LOVRelationshipTypeId 
join ((select sales_organisation sourceKey,record_source_id,'sales_organisation' roleTypeId,row_status,asset_id,@party_relationship_type_of LOVRelationshipTypeId from psa.uk_btc_mdm_store_stg
where row_status=@row_status and asset_id=@assetId group by sales_organisation,record_source_id,row_status,asset_id)
union (select primary_care_organisation_description SourceKey,record_source_id,'primary_care_organisation_description' roleTypeId,row_status,asset_id,@party_relationship_type_aw LOVRelationshipTypeId from psa.uk_btc_mdm_store_stg
where row_status=@row_status and asset_id=@assetId group by primary_care_organisation_description,record_source_id,row_status,asset_id)
union (select name_of_health_authority SourceKey,record_source_id,'name_of_health_authority' roleTypeId,row_status,asset_id,@party_relationship_type_aw LOVRelationshipTypeId from psa.uk_btc_mdm_store_stg
where row_status=@row_status and asset_id=@assetId group by name_of_health_authority,record_source_id,row_status,asset_id)) mdms
ON mdms.record_source_id=sr.LovRecordSourceId 
--AND sr.SourceKey = mdms.SourceKey
Where mdms.row_status=@row_status and mdms.asset_id=@assetId--AND  mdms.created_timestamp=@created_timestamp
AND NOT EXISTS (select * from ser.PartyRoleSiteRoleRelationship srp where --srp.SourceKey=mdms.SourceKey AND 
                                                    mdms.record_source_id=srp.LOVRecordSourceId
                                                    AND ISNULL(mdms.LOVRelationshipTypeId,0)=ISNULL(srp.LOVRelationshipTypeId,0)
                                                            
                                                   -- AND ISNULL(mdms.store_short_name,0)  = ISNULL(srp.SiteRoleShortName,0)
                                                    AND sr.SCDVersion=srp.ScdVersion
                                                ); 


--Inserting data to table with existing version increment by 1 and new record version as 1.
INSERT INTO ser.PartyRoleSiteRoleRelationship(PartyRoleId, SiteRoleId,LOVRelationshipTypeId,LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT PartyRoleId, SiteRoleId,LOVRelationshipTypeId,LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId,ETLRunLogId,row_id
FROM
(SELECT * FROM ser.PartyRoleSiteRoleRelationship_mdm_tempg_STG)Stage
WHERE Stage.SCDActiveFlag='Y'

update ser.PartyRoleSiteRoleRelationship set SCDEndDate=siterole.SCDEndDate ,SCDActiveFlag='N'
 FROM ser.PartyRoleSiteRoleRelationship src join
( select src.siteroleid,src.PartyRoleId,src.scdversion,src.LOVRelationshipTypeId,src.lovrecordsourceId,src.SCDStartdate from ser.PartyRoleSiteRoleRelationship src
join
(select SiteRoleId,PartyRoleId,max(scdversion) scdversion,LOVRelationshipTypeId,lovrecordsourceId from ser.PartyRoleSiteRoleRelationship
where lovrecordsourceId=12008 group by LOVRelationshipTypeId,SiteRoleId,PartyRoleId,lovrecordsourceId)P
 on P.SiteRoleId=src.SiteRoleId and P.lovrecordsourceId=src.lovrecordsourceId and src.LOVRelationshipTypeId=P.LOVRelationshipTypeId and src.PartyRoleId=P.PartyRoleId
 where src.scdversion=P.scdversion )PartyRoleSiteRoleRelationship_mdm
on PartyRoleSiteRoleRelationship_mdm.SiteRoleId=src.SiteRoleId and PartyRoleSiteRoleRelationship_mdm.lovrecordsourceId=src.lovrecordsourceId and PartyRoleSiteRoleRelationship_mdm.LOVRelationshipTypeId=src.LOVRelationshipTypeId 
and PartyRoleSiteRoleRelationship_mdm.PartyRoleId=src.PartyRoleId
JOIN (select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId,sr.SCDStartdate,sr.SCDEndDate,sr.SCDActiveFlag from ser.siterole sr
join
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole
where lovrecordsourceId=12008 group by sourcekey,lovrecordsourceId)P
 on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId
 where sr.scdversion=P.scdversion)siterole on PartyRoleSiteRoleRelationship_mdm.SiteRoleId=siterole.SiteRoleId
 where siterole.SCDActiveFlag='N' 

Delete from ser.PartyRoleSiteRoleRelationship_mdm_tempg_STG;





 
 

--code end

    
/*Update the psa layer table with row_status AS 'Loaded to Serve' once after Successful Migration*/    

                        UPDATE psa.uk_btc_mdm_store SET Row_Status=@serRowStatus
                        FROM psa.uk_btc_mdm_store mdms 
                        INNER JOIN
                        ser.SiteRole sr 
                                ON ISNULL( NULLIF((Substring(mdms.store_number, Patindex('%[^0 ]%', mdms.store_number + ' '), Len(mdms.store_number)) ),''),0) =sr.sourcekey
                                AND  mdms.record_source_id=sr.LovRecordSourceID
                        INNER JOIN
                        ((SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRole WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@record_source_id)     
                        UNION ALL (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleStatus  WHERE SCDACTiveFlag='Y'AND LOVRecordsourceID=@record_source_id)                                     
                        UNION ALL  (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleGroup WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@record_source_id)                                     
                        UNION ALL  (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleTerritory  WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@record_source_id)
                        UNION ALL  (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleContactMethod  WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@record_source_id)                                          
                        UNION ALL  (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleIndicator WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@record_source_id)
                        UNION ALL  (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleProperty WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@record_source_id)
                            ) temp
                                ON  temp.scdLovRecordSourceID in (@record_source_id)
                                AND temp.SiteRoleId=sr.SiteRoleId                            
                                AND temp.psarowkey=mdms.row_id
                        WHERE mdms.Row_Status=@row_status
                              AND mdms.asset_id=@assetId ;


                        UPDATE psa.uk_btc_mdm_store SET Row_Status=@serRowStatus
                        FROM psa.uk_btc_mdm_store mdms 
                        INNER JOIN
                        ser.SiteRole sr 
                            ON mdms.record_source_id=LovRecordSourceID
                            AND  ISNULL( NULLIF((Substring(mdms.store_number, Patindex('%[^0 ]%', mdms.store_number + ' '), Len(mdms.store_number)) ),''),0) =sr.sourcekey
                        WHERE mdms.Row_Status=@row_status  
                            AND asset_id=@assetId
                            AND ((NULLIF(mdms.store_name,'' ) IS NULL AND NULLIF( mdms.store_short_name,'' ) IS NULL ) 
                             OR (NULLIF(mdms.telephone_number,'') IS NULL OR NULLIF(mdms.non_lfl_reason_code,'') IS NULL OR NULLIF(mdms.pharmacy_registration_status,'') IS NULL 
                             OR NULLIF(mdms.area_number,'') IS NULL  OR  NULLIF(mdms.nhs_market,'') IS NULL
                             OR NULLIF(mdms.midnight_pharmacy,'') IS NULL OR NULLIF(mdms.nhs_contract_flag,'') IS NULL
                             OR    NULLIF(mdms.mds_room_flag,'') IS NULL OR NULLIF(mdms.distribution_channel,'') IS NULL OR NULLIF(mdms.trading_format,'') IS NULL 
                             OR NULLIF(mdms.type_of_store_description,'') IS NULL OR NULLIF(mdms.sag,'') IS NULL
                             OR NULLIF(mdms.mini_sag,'') IS NULL OR NULLIF(mdms.price_band_code,'') IS NULL
                             OR NULLIF(mdms.benchmark_group,'') IS NULL ));


                        UPDATE psa.uk_btc_mdm_store  SET row_status=@row_status_notmigrated                        
                        WHERE row_status=@row_status
                              AND asset_id=@assetId; 






SET @COUNTER = @COUNTER + 1 ;
END
COMMIT TRANSACTION;
END TRY
BEGIN CATCH     
THROW
ROLLBACK TRANSACTION;
END CATCH

IF OBJECT_ID('ser.PartyRole_mdm_tempg_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PartyRole_mdm_tempg_STG;
END

IF OBJECT_ID('ser.Organisation_mdm_tempg_STG') IS NOT NULL
BEGIN
DROP TABLE ser.Organisation_mdm_tempg_STG;
END

IF OBJECT_ID('ser.PartyRoleSiteRoleRelationship_mdm_tempg_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PartyRoleSiteRoleRelationship_mdm_tempg_STG;
END

IF OBJECT_ID('ser.SiteRoleProperty_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleProperty_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.PostalAddress_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PostalAddress_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.PostalAddress_SiteProperty_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PostalAddress_SiteProperty_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleContactMethod_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleContactMethod_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleTerritory_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleTerritory_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleGrp_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleGrp_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleIndicator_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleIndicator_STG;
END


--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleStatus_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleStatus_STG;
END
--drop temp table if exists
IF OBJECT_ID('tempdb..#TempCurMdmStore') IS NOT NULL
BEGIN
	DROP table  #TempCurMdmStore
END

IF OBJECT_ID('psa.uk_btc_mdm_store_stg') IS NOT NULL
BEGIN
DROP TABLE psa.uk_btc_mdm_store_stg;
END

END
GO
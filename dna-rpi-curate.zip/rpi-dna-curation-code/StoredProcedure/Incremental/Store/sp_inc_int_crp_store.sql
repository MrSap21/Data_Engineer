﻿/****** Object:  StoredProcedure [psa].[sp_inc_int_crp_store]    Script Date: 11/26/2020 6:18:11 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('psa.sp_inc_int_crp_store') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_int_crp_store
END
GO

CREATE PROC [psa].[sp_inc_int_crp_store] @tableName [varchar](200),@serveETLRunLogID [varchar](MAX),@psaEntityId [varchar](max) AS
DECLARE 
@recordSourceId int,
@scdLovRecordSourceID int,
@PostalLOVRecordSourceId  int,
@PSARowStatus int,
@serRowStatus int,
@PSARowStatus_NotMigrated int,
@MAXSiteId int,
@MAXSRGpID int,
@LOVCountryId int,
@LOVSiteTypeId int,
@CountryCode varchar(2),
@date_added varchar(max),
@inpTableName varchar(max),
@db varchar(max),
@NULLSiteId varchar(max),
@maxSiteRoleId int,
@LOVRoleId int,
@cur_TMSTMP datetime,
@lovIndicator varchar(max),
@LOVIndicatorId int,
@CurDate varchar(max),
@MAXPartyId int,@PartyTypeId int,
@MAXPartyRoleId int,
@RetailerRoleId int,
@LOVGeoCodeMeasureTypeId int,
@LOVFloorAreaMeasureTypeId int,
@LOVDataTypeId int,
@UOMID1 int,
@UOMID2 int,
@UOMID3 int,
@SCDDefaultStartDate DATETIME,
@SCDDefaultEndDate DATETIME,
@SCDStartDate	DATETIME,
@SCDEndDate		DATETIME,
@OpenStatus int,
@ClosedStatus int,
@LOVSiteRoleStatusSetId int,
@partyroleid_const int,
@partyrole_const_srckey varchar(MAX),
@RelationshipTypeId1 int,
@RelationshipTypeId2 int;

BEGIN
IF OBJECT_ID('psa.TempIntCrpStore_STG') IS NOT NULL
BEGIN

DROP TABLE psa.TempIntCrpStore_STG
END

IF OBJECT_ID('ser.TempIntStore_SiteRole_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRole_STG
END

IF OBJECT_ID('ser.TempIntStore_SiteRoleGroup_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRoleGroup_STG
END

IF OBJECT_ID('ser.TmpIntStore_SiteRoleProp_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TmpIntStore_SiteRoleProp_STG
END
IF OBJECT_ID('ser.TmpIntStore_SiteRoleTerritory_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TmpIntStore_SiteRoleTerritory_STG
END

IF OBJECT_ID('ser.TempIntStore_SiteRoleStatus_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRoleStatus_STG
END

CREATE TABLE  ser.TempIntStore_SiteRole_STG(     
	SiteRoleId            bigint         NULL,
    SiteId                bigint         NOT NULL,    
    SourceKey             varchar(80)    NULL,
    SiteRoleName          varchar(80)    NULL,    
    LOVRecordSourceId     int            NOT NULL,   
    SCDActiveFlag         char(1)        NULL,
    SCDVersion            smallint       NULL
   )

CREATE TABLE ser.TempIntStore_SiteRoleGroup_STG(
    ExistsFlag               int           NULL, 
	SiteRoleGroupId 		 bigint        NULL,
    SiteRoleId               bigint        NOT NULL,
	PGCol                    nvarchar(255) NULL,
	PGValue                  nvarchar(255) NULL,
    LOVSiteRoleGroupSetId    int           NULL,
    LOVGroupId               int           NULL,
    ParentSiteRoleGroupId    bigint        NULL,
    LOVRecordSourceId        int           NOT NULL,    
    SCDVersion               smallint      NULL,    
    PSARowKey                bigint        NULL,
	siteroleidactive         char(1)       NULL
)
CREATE TABLE ser.TmpIntStore_SiteRoleProp_STG(
    ExistsFlag              int             NOT NULL,
    SiteRoleId              bigint          NOT NULL,
	PGCol                   nvarchar(255)   NULL,   
    MeasureId               int             NULL,
    LOVUOMId                int             NULL,
    Value                   varchar(255)    NULL,
    LOVRecordSourceId       int             NOT NULL,       
    SCDActiveFlag           char(1)         NULL,
	SCDVersion              smallint        NULL,    
	PSARowKey               bigint 			NULL,
	siteroleidactive        char(1)         NULL	
)

CREATE TABLE ser.TmpIntStore_SiteRoleTerritory_STG(
    ExistsFlag                   int           NOT NULL,
    SiteRoleId                   bigint        NOT NULL,
	PGCol                        nvarchar(255) NOT NULL,
	Value                        nvarchar(255) NULL,
    LOVSiteRoleTerritorySetId    int           NULL,
    LOVTerritoryId               int           NULL,
    LOVRecordSourceId            int           NOT NULL,   
    SCDActiveFlag                char(1)       NULL, 
    SCDVersion                   smallint      NULL,  
	PSARowKey                    bigint        NULL,
	siteroleidactive             char(1)       NULL
)
CREATE TABLE ser.TempIntStore_SiteRoleStatus_STG(
    ExistsFlag                int           NOT NULL,
    SiteRoleId                bigint        NOT NULL,
    LOVSiteRoleStatusSetId    int           NOT NULL,
	OpenStatusFlag            int           NOT NULL,
    LOVStatusId               int           NULL,
    EffectiveFrom             datetime      NULL,
    EffectiveTo               datetime      NULL,
	openDate                  nvarchar(500) NULL,
	closeDate                 nvarchar(500) NULL,
    LOVRecordSourceId         int           NOT NULL,    
    SCDActiveFlag             char(1)       NULL,
	SCDEndDate                datetime      NULL,
    SCDVersion                smallint      NULL,
    PSARowKey                 bigint        NULL,
	siteroleidactive          char(1)       NULL
)

if (@tableName='cl_crp_store')
BEGIN
SET @CountryCode='CL'
SET @lovIndicator='Indicator - CHILE Site'
SET @partyrole_const_srckey='WBA-CL-FA'
END

ELSE if (@tableName='th_crp_store')
BEGIN
SET @CountryCode='TH'
SET @lovIndicator='Indicator - THAILAND Site'
SET @partyrole_const_srckey='WBA-TH-BT'
END

ELSE if (@tableName='mx_crp_store')
BEGIN
SET @CountryCode='MX'
SET @lovIndicator='Indicator - MEXICO Site' 
SET @partyrole_const_srckey='WBA-MX-FB'
END

ELSE if (@tableName='no_crp_store')
BEGIN
SET @CountryCode='NO'
SET @lovIndicator='Indicator - Norway Site' 
SET @partyrole_const_srckey='WBA-NO-BN'
END

SET @db='psa'
SET @PostalLOVRecordSourceId  = 12012
SET @PSARowStatus             = 26001
SET @serRowStatus			  = 26002
SET @PSARowStatus_NotMigrated = 26010
SET	@SCDDefaultStartDate      =	CONVERT(DateTime,'1900-01-01',126)			
SET	@SCDDefaultEndDate        = CONVERT(DateTime,'9999-12-31',126)
SET  @inpTableName= CONCAT(@db, '.','TempIntCrpStore_STG')

 
SELECT  @tablename= CONCAT(@db, '.',@tablename)
DECLARE @RecordSourceIdSQL nvarchar(max) = 'SELECT TOP 1 @recordSourceId = record_source_id FROM ' + @tableName
exec sp_executesql @RecordSourceIdSQL, N'@recordSourceId int out', @recordSourceId out
-- CTAS from psa
IF @tablename='psa.no_crp_store'  
	   BEGIN			
			EXEC('CREATE TABLE psa.TempIntCrpStore_STG
						  WITH (DISTRIBUTION=REPLICATE, HEAP)
						  AS 
						  SELECT [row_id]
						  , ISNULL( NULLIF((Substring(store_number, Patindex(''%[^0]%'', store_number + '' ''), Len(store_number)) ),''''),0) [store_number]
						  ,[store_name]
						  ,[address_line1]
						  ,[address_line2]
						  ,[address_line3]
						  ,[address_line4]
						  ,(CASE WHEN NULLIF(postal_code,'''') IS NULL THEN postal_code
								ELSE ISNULL( NULLIF((Substring(postal_code, Patindex(''%[^0]%'', postal_code + '' ''), Len(postal_code)) ),''''),0) END) [postal_code]
						  ,[area_code]
						  ,[district_code]
						  ,[store_ndsa]
						  ,[store_size]
						  ,[store_format]
						  ,[store_loc]
						  ,[open_date]
						  ,[close_date]
						  ,[longitude]
						  ,[latitude]
						  ,[heritage_flag]
						  ,[heritage_company]
						  ,[date_added]
						  ,[etl_runlog_id]
						  ,[asset_id]
						  ,[record_source_id]
						  ,[row_status]
						  ,[created_timestamp]
						  ,[active_flag]
					  FROM '+@tablename+' WHERE row_status='+@PSARowStatus)

	   END
   ELSE 
		BEGIN 
					EXEC('CREATE TABLE psa.TempIntCrpStore_STG
						  WITH (DISTRIBUTION=REPLICATE, HEAP)
						  AS 
						  SELECT [row_id]
						  , ISNULL( NULLIF((Substring(store_number, Patindex(''%[^0]%'', store_number + '' ''), Len(store_number)) ),''''),0) [store_number]
						  ,[store_name]
						  ,[address_line1]
						  ,[address_line2]
						  ,[address_line3]
						  ,[address_line4]
						  ,(CASE WHEN NULLIF(postal_code,'''') IS NULL THEN postal_code
								ELSE ISNULL( NULLIF((Substring(postal_code, Patindex(''%[^0]%'', postal_code + '' ''), Len(postal_code)) ),''''),0) END) [postal_code]
						  ,[area_code]
						  ,[district_code]
						  ,[region_code]
						  ,[store_ndsa]
						  ,[store_size]
						  ,[store_format]
						  ,[store_loc]
						  ,[open_date]
						  ,[close_date]
						  ,[longitude]
						  ,[latitude]
						  ,[heritage_flag]
						  ,[heritage_company]
						  ,[date_added]
						  ,[etl_runlog_id]
						  ,[asset_id]
						  ,[record_source_id]
						  ,[row_status]
						  ,[created_timestamp]
						  ,[active_flag]
					  FROM '+@tablename+' WHERE row_status='+@PSARowStatus)
				END


-- Temporary table to store distinct date_added

IF OBJECT_ID('ser.TempIncr_DateCountStore') IS NOT NULL
BEGIN
drop table ser.TempIncr_DateCountStore
END

CREATE TABLE  ser.TempIncr_DateCountStore( 
    rowId              int            NULL,
    datevalue             nvarchar(25)    NULL)

DECLARE @COUNTER int,@MAXID int;
DECLARE @DATETIME varchar(max), @currTime varchar(max);
SET @COUNTER= 1;

BEGIN TRANSACTION
BEGIN TRY	
--used in PostalAddress
SELECT @LOVCountryId=r.LOVId FROM [ser].[RefLOVSetInfo] r WHERE r.LOVKey = @CountryCode  AND 
 r.LOVSetName = 'Country ISO 3166-2' AND r.LOVRecordsourceId=12012;
SELECT @MAXSiteId=COALESCE(max(SiteId),0) FROM ser.PostalAddress;
--used in Site 
SELECT @LOVSiteTypeId=r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = 'POSTAL ADDRESS' AND 
r.LOVSetName = 'Site Type';  
--used in Party
SELECT @MAXPartyId= COALESCE(max(PartyId),0) from ser.Party;
SELECT @PartyTypeId= r.LOVId FROM [ser].[RefLOVSetInfo] r WHERE r.LOVKey = 'ORG'  AND r.LOVSetName ='Party Type'  ;
SELECT @MAXPartyRoleId= COALESCE(max(PartyRoleId),0) from ser.PartyRole;
SELECT @RetailerRoleId= r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = 'Retailer'  AND r.LOVSetName ='Role'  ;

--used in SiteRole
SELECT @LOVRoleId= LOVID from ser.RefLOVSetInfo where LovKey='Store'  and  LOVSetName = 'Role';   
SELECT @NULLSiteId=STRING_AGG(siteId,',') from ser.PostalAddress where AddressLine1 is NULL and Addressline2 IS NULL
and town IS NULL and county IS NULL and PostalCode IS NULL

--used in SiteRoleIndicator
SELECT  @LOVIndicatorId=r.LOVId FROM  ser.RefLOVSetInfo r WHERE r.LOVKey = 'heritage_flag'   AND 
LOVSetName = @lovIndicator ;
PRINT @LOVIndicatorId

--SiteRoleGroup


--used in SiteRoleProperty

SELECT @LOVGeoCodeMeasureTypeId =  Lovid from ser.reflovsetinfo WHERE LOVKey = 'GEOCODE' and LOVSETName = 'Measure Type' 
 
SELECT @LOVFloorAreaMeasureTypeId =  Lovid from ser.reflovsetinfo  WHERE LOVKey = 'FLOOR_AREA' and LOVSETName = 'Measure Type' 
        
SELECT @LOVDataTypeId = Lovid from ser.reflovsetinfo WHERE LOVKey = 'STRING' and LOVSETName = 'Data Type' 

	 
SELECT @UOMID1= r.LOVId FROM ser.reflovsetinfo r WHERE r.LOVKey =  'Unknown' AND r.LOVSetName ='Unit Of Measure' ;

SELECT @UOMID2= r.LOVId FROM ser.reflovsetinfo r WHERE r.LOVKey =  'm2'  AND r.LOVSetName ='Unit Of Measure' ;


SELECT @UOMID3= r.LOVId FROM ser.reflovsetinfo r WHERE r.LOVKey =  '°'  AND r.LOVSetName ='Unit Of Measure' ;

--siterolestatus
SELECT @OpenStatus = ref.Lovid from ser.reflovsetinfo ref WHERE ref.LOVKey =  'O'  and ref.LOVSETName = 'Status Type'
SELECT @ClosedStatus = ref.Lovid from ser.reflovsetinfo ref WHERE ref.LOVKey =  'C'  and ref.LOVSETName = 'Status Type'
SELECT TOP 1 @LOVSiteRoleStatusSetId= refs.LOVSetId FROM ser.reflovsetinfo refs WHERE refs.LOVSETName = 'Status Type'

--PartRoleSiteRelationship
SELECT @RelationshipTypeId1= r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = 'Operates From'   
AND r.LOVSetName ='Relationship Type'  ;
SELECT @RelationshipTypeId2= r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = 'Previously Operated From'  
AND r.LOVSetName ='Relationship Type'  ;
select @partyroleid_const=partyroleId from  ser.partyrole where partyrole.SourceKey=@partyrole_const_srckey AND 
partyrole.SCDActiveFlag='Y' AND partyrole.lovroleid=@RetailerRoleId

PRINT 'Starting execution....'


PRINT '****************************** INFO: 1.LOADING POSTAL ADDRESS*************************'


exec ( '
INSERT INTO ser.PostalAddress (SiteId, LocationName, AddressLine1, AddressLine2, Town, County, PostalCode, LOVCountryId, LOVRecordSourceId, SCDStartDate,SCDEndDate,
SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey ) 
SELECT 
		CASE WHEN Ser.ExistsFlag=0 THEN '+@MAXSiteId+ '  + ROW_NUMBER() OVER(ORDER BY  Ser.LocationName,Ser.AddressLine1, Ser.AddressLine2, Ser.Town, Ser.County,Ser.PostalCode) END SiteId, 
		Ser.LOCATIONNAME,
		Ser.AddressLine1,
		Ser.AddressLine2, 
		Ser.Town, 
		Ser.County,
		Ser.PostalCode,
		'+@LOVCountryId+' LOVCountryId, 
		'+@PostalLOVRecordSourceId+' PostalLOVRecordSourceId,
		CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''') SCDStartDate,
		CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate, 
		''Y'' SCDActiveFlag, 
		1 SCDVersion, 
		'+@recordSourceId+' scdLovRecordSourceID, 
		'+@serveETLRunLogID+' ETLRunLogId,
		Ser.PSARowKey
		FROM 
			(SELECT 
				Source.LOCATIONNAME,
				Source.AddressLine1,
				Source.AddressLine2, 
				Source.Town,
				Source.County,
				Source.PostalCode,
				CONVERT(DATETIME,Source.SCDStartDate) SCDStartDate,
				Source.PSARowKey,
				CASE WHEN  POSTAL.SiteId is NULL THEN  0 ELSE 1  END AS ExistsFlag
				FROM 
					( SELECT 
						LOCATIONNAME,
						AddressLine1,
						AddressLine2,
						Town,
						County,
						PostalCode,
						max(SCDStartDate) SCDStartDate ,
						max(PSARowKey) PSARowKey
							FROM 
								(SELECT  
									NULL LOCATIONNAME,
									Case When Stage.address_line1 is NULL 
									OR Stage.address_line1 = ''NULL''
									OR len(Stage.address_line1)=0 
									OR Stage.address_line1=''-'' 
									then NULL 
									ELSE trim(Stage.address_line1) END  AddressLine1,
									Case When Stage.address_line2 is NULL
									OR Stage.address_line2 = ''NULL''
									OR len(Stage.address_line2)=0 
									OR Stage.address_line2=''-'' 
									then NULL ELSE trim(Stage.address_line2) END  AddressLine2,       
									Case When Stage.address_line3 is NULL 
									OR Stage.address_line3 = ''NULL''
									OR len(Stage.address_line3)=0 
									OR Stage.address_line3=''-'' 
									then NULL ELSE trim(Stage.address_line3) END  Town,
									Case When Stage.address_line4 is NULL 
									OR  Stage.address_line4 = ''NULL''
									OR  len(Stage.address_line4)=0 
									OR Stage.address_line4=''-'' 
									then NULL ELSE trim(Stage.address_line4) END  County,
									Case When Stage.postal_code is NULL 
									OR  Stage.postal_code = ''NULL''
									OR len(Stage.postal_code)=0 
									OR Stage.postal_code=''-'' 
									then NULL ELSE trim(Stage.postal_code) END  PostalCode,  
									date_added  SCDStartDate, 
									Stage.row_id PSARowKey
									FROM '+ @inpTableName+ '  Stage Where Stage.Row_status='+@PSARowStatus+'									
									)P
							group by LOCATIONNAME,AddressLine1, AddressLine2, Town,County, PostalCode) Source
				LEFT JOIN ser.PostalAddress Postal 
					ON ISNULL(trim(Source.AddressLine1),'''')=ISNULL(trim(POSTAL.AddressLine1),'''') AND   
					ISNULL(trim(Source.AddressLine2),'''') =ISNULL(trim(POSTAL.AddressLine2),'''') AND 
					ISNULL(trim(Source.Town),'''')=ISNULL(trim(POSTAL.Town),'''') AND 
					ISNULL(trim(Source.County),'''')=ISNULL(trim(POSTAL.County),'''') AND	
					ISNULL(trim(Source.PostalCode),'''')=ISNULL(trim(POSTAL.PostalCode) ,''''))Ser WHERE Ser.ExistsFlag=0 
					')
					
					
	PRINT '****************************** INFO: POSTAL ADDRESS LOADED*************************'
	


PRINT '****************************** INFO: 2. LOADING Site*************************'				
exec('
INSERT INTO ser.Site
(SiteId,SourceKey,SiteName,LOVSiteTypeId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSArowKey)
select distinct postal.siteid,null,null,'+@LOVSiteTypeId+','+@PostalLOVRecordSourceId+' PostalLOVRecordSourceId,
CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''') SCDStartDate,
CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate, 
''Y'' SCDActiveFlag, 
1 SCDVersion, 
store.record_source_id scdLovRecordSourceID, '+@serveETLRunLogID+' ETLRunLogId, postal.psarowkey
from '+ @inpTableName+ ' store
JOIN ser.PostalAddress POSTAL
on ISNULL(trim(psa.validateNULL(store.address_line1)),'''')=ISNULL(trim(POSTAL.AddressLine1),'''') AND  
ISNULL(trim(psa.validateNULL(store.address_line2)),'''') =ISNULL(trim(POSTAL.AddressLine2),'''') AND
ISNULL(trim(psa.validateNULL(store.address_line3)),'''')=ISNULL(trim(POSTAL.Town),'''') AND
ISNULL(trim(psa.validateNULL(store.address_line4)),'''')=ISNULL(trim(POSTAL.County),'''') AND   
ISNULL(trim(psa.validateNULL(store.postal_code)),'''')=ISNULL(trim(POSTAL.PostalCode) ,'''') AND
Postal.LovRecordSourceId='+@PostalLOVRecordSourceId+' AND
Postal.SCDActiveFlag=''Y'' and store.row_status='+@PSARowStatus + '
where not exists(select siteid from ser.site  where site.siteid=postal.siteid and 
site.lovrecordsourceId='+@postallovrecordsourceid+'
)
')


PRINT '****************************** INFO: Site LOADED*************************'




PRINT '****************************** INFO: 3.  LOADING Party*************************'

exec ('
INSERT INTO ser.Party (PartyId, LOVPartyTypeId, SourceKey, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, 
SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
	SELECT 
		PartyId, 
		PartyTypeId, 
		SourceKey, 
		LOVRecordSourceId, 
		SCDStartDate,SCDEndDate, 
		SCDActiveFlag, 
		SCDVersion, 
		SCDLOVRecordSourceId, 
		ETLRunLogId,
		PSARowKey
		FROM 
			(SELECT 
				CASE WHEN Party.PartyId IS NULL 
				THEN '+ @MAXPartyId+' + ROW_NUMBER() 
				OVER(ORDER BY  store.SourceKey,store.lovrecordsourceId) END PartyId,
				CASE WHEN Party.PartyId IS NULL THEN 0 ELSE 1 END ExistsFlag,
				PartyTypeId,
				store.SourceKey,
				store.lovrecordsourceid,
				CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''') SCDStartDate,
				CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate, 
				''Y'' SCDActiveFlag,
				1 SCDVersion,
				store.lovrecordsourceid SCDLOVRecordSourceId ,'
				+@serveETLRunLogId+' ETLRunLogId,
				store.row_id PSARowKey
				FROM 
					(select 
						'+@PartyTypeId+' PartyTypeId, 
						SourceKey,
						lovrecordsourceid,
						max(date_added) date_added, 
						max(row_id) row_id 
						FROM (
							select 
								heritage_company  SourceKey , 
								record_source_id  lovrecordsourceId,
								date_added date_added,row_id
								FROM '+ @inpTableName+ ' WHERE Row_status='+@PSARowStatus+' )stage 
						group by SourceKey,lovrecordsourceId having SourceKey IS NOT NULL AND LEN(TRIM(SourceKey)) >0 AND SourceKey <> ''NULL'' )store
				LEFT JOIN ser.Party
						on store.lovrecordsourceId=Party.lovrecordsourceId 
							AND Party.SourceKey=store.SourceKey 
							AND Party.SCDActiveFlag=''Y'' 
							AND Party.LOVPartyTypeId=store.PartyTypeId)STG 
			where STG.ExistsFlag=0 ')


PRINT '****************************** INFO: Party LOADED *************************' 


PRINT '****************************** INFO: 4. LOADING Organisation *************************'
	
exec ('INSERT INTO [ser].[Organisation]
           ([PartyId]
           ,[SourceOrganisationKey]
           ,[OrganisationName]
           ,[ParentPartyId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])
				select  
					Party.PartyId,
					store.SourceKey,
					store.SourceKey,
					NULL ParentPartyId,
					store.lovrecordsourceid,
					CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''') SCDStartDate,
					CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate, 
					''Y'' SCDActiveFlag,
					1 SCDVersion,
					store.lovrecordsourceid SCDLOVRecordSourceId ,'
					+@serveETLRunLogId+'  ETLRunLogId,
					store.row_id PSARowKey 
					from 
						(select 
							SourceKey,
							lovrecordsourceid,
							max(date_added) date_added, 
							max(row_id) row_id 
								FROM (
									select 
										heritage_company SourceKey , 
										record_source_id lovrecordsourceId,
										date_added date_added,
										row_id
										FROM '+ @inpTableName+ ' WHERE Row_status='+@PSARowStatus+' )stage 
								group by SourceKey,lovrecordsourceId  having SourceKey IS NOT NULL AND LEN(TRIM(SourceKey)) >0 AND SourceKey <> ''NULL'')store 
				JOIN ser.Party ON Party.SourceKey=store.SourceKey 
						AND Party.lovrecordsourceId=store.lovrecordsourceId 
						AND Party.SCDActiveFlag=''Y''
				LEFT JOIN ser.Organisation Org ON Org.PartyId=Party.PartyId 
						AND Org.lovrecordsourceId=store.lovrecordsourceId 
						AND Org.SourceOrganisationKey=Party.SourceKey
						AND Org.SCDActiveFlag=''Y''
				Where Org.PartyId IS NULL
')



PRINT '****************************** INFO: Organisation LOADED *************************' 


PRINT '****************************** INFO: 5. LOADING PARTYROLE *************************'
exec ('INSERT INTO [ser].[PartyRole]
           ([PartyRoleId]
           ,[LOVRoleId]
           ,[PartyId]
           ,[SourceKey]
           ,[PartyRoleName]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])
		   select 
			CASE WHEN PartyRole.PartyRoleId IS NULL THEN '+ @MAXPartyRoleId+' + ROW_NUMBER() OVER(ORDER BY  STG.PartyId,STG.LovRoleId,STG.lovrecordsourceId) END PartyRoleId,
			STG.LovRoleId, 
			STG.PartyId,
			STG.SourceKey,
			STG.SourceKey, 
			STG.lovrecordsourceid,
			CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''') SCDStartDate,
			CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') SCDEndDate,
			''Y'' SCDActiveFlag,
			1 SCDVersion,
			STG.lovrecordsourceid SCDLOVRecordSourceId ,'
			+@serveETLRunLogId+' ETLRunLogId,
			STG.row_id PSARowKey
			from 
				(select 
					Party.PartyId ,
					LovRoleId ,
					store.SourceKey,
					store.lovrecordsourceid,
					date_added,  
					row_id 
					from 
						(select 
							'+@RetailerRoleId+' LovRoleId, 
							SourceKey,
							lovrecordsourceid,
							max(date_added) date_added, 
							max(row_id) row_id 
							FROM (
								select 
									heritage_company  SourceKey , 
									record_source_id lovrecordsourceId,
									date_added date_added,
									row_id 
									FROM '+ @inpTableName+ ' WHERE Row_status='+@PSARowStatus+' )stage 
							group by SourceKey,lovrecordsourceId  having SourceKey IS NOT NULL AND LEN(TRIM(SourceKey)) >0 AND SourceKey <> ''NULL'' )store 
						JOIN ser.Party ON Party.SourceKey=store.SourceKey 
							AND Party.lovrecordsourceId=store.lovrecordsourceId 
							AND PArty.SCDActiveFlag=''Y'')STG
			LEFT JOIN ser.PartyRole
				on STG.lovrecordsourceId=PartyRole.lovrecordsourceId 
				AND PartyRole.SourceKey=STG.SourceKey 
				AND PArtyRole.SCDActiveFlag=''Y'' 
				AND PartyRole.LOVRoleId=STG.LovRoleId 
				AND PartyRole.PartyId=STG.PartyId 
			WHERE PartyRole.PartyRoleId IS NULL
')

PRINT 'Info: PartyRole Table Loaded Successfully';


--Insert distinct date_added in asc order to the table TempIncr_DateCountStore
exec('
INSERT INTO ser.TempIncr_DateCountStore 
SELECT  ROW_NUMBER() OVER (ORDER BY date_added) AS rowId,date_added FROM   
(SELECT DISTINCT date_added FROM '+@inpTableName+' where row_status='+@PSARowStatus + ') store')

SELECT @MAXID = MAX(rowId) FROM ser.TempIncr_DateCountStore;

--Counter to iterate through distinct date_added

WHILE (@COUNTER <= @MAXID)
BEGIN
		    
SELECT  @CurDate=datevalue  FROM ser.TempIncr_DateCountStore WHERE @COUNTER=rowId;
PRINT '*********************************************************************************'
PRINT @CurDate ;

--Set the Processing time as scd start and scd end dates
SET	@SCDStartDate		      = CURRENT_TIMESTAMP;
SET	@SCDEndDate			      = DATEADD(second,-1,@SCDStartDate);



PRINT '****************************** INFO: 6. LOADING SITEROLE *************************'

SELECT @maxSiteRoleId=COALESCE(max(siteroleId),0) from ser.SiteRole

exec('
UPDATE ser.SiteRole   set SCDEndDate= CONVERT(NVARCHAR,'''+@SCDEndDate+'''), 
SCDActiveFlag=''N'' FROM ser.siterole join
(select str.siteroleid,str.siteid,str.SourceKey,str.siterolename, str.lovrecordsourceid,str.scdversion,str.scdactiveflag from ser.siterole str 
join 
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
where lovrecordsourceId='+@recordSourceId + ' group by sourcekey,lovrecordsourceId)P  
 on P.sourcekey=str.sourcekey and P.lovrecordsourceId=str.lovrecordsourceId 
 where str.scdversion=P.scdversion )  sr
on siterole.siteroleid=sr.siteroleid and siterole.lovrecordsourceid=sr.lovrecordsourceId and siterole.scdactiveflag=''Y''
join '+@inpTableName + '  store
ON store.record_source_id=sr.LovRecordSourceId and
sr.sourcekey = store.store_number and sr.SCDActiveFlag=''Y''
AND 
store.row_status='+@PSARowStatus + ' and store.date_added='+@CurDate + ' 
JOIN ser.PostalAddress POSTAL 
on ISNULL(trim(psa.validateNULL(store.address_line1)),'''')=ISNULL(trim(POSTAL.AddressLine1),'''') AND   
ISNULL(trim(psa.validateNULL(store.address_line2)),'''') =ISNULL(trim(POSTAL.AddressLine2),'''') AND 
ISNULL(trim(psa.validateNULL(store.address_line3)),'''')=ISNULL(trim(POSTAL.Town),'''') AND 
ISNULL(trim(psa.validateNULL(store.address_line4)),'''')=ISNULL(trim(POSTAL.County),'''') AND	
ISNULL(trim(psa.validateNULL(store.postal_code)),'''')=ISNULL(trim(POSTAL.PostalCode) ,'''') AND 
Postal.LovRecordSourceId=12012 AND 
Postal.SCDActiveFlag=''Y'' 
Where
(NOT EXISTS (select strole.siteid,strole.SourceKey,strole.siterolename from
ser.siterole strole     
 where strole.scdversion=sr.scdversion and
  store.record_source_id=strole.lovrecordsourceId
  AND store.store_number=strole.sourcekey
  AND ISNULL(store.store_name,'''')=ISNULL(strole.SiteRoleName,'''') 
and postal.siteid=strole.siteid	AND strole.scdactiveflag=''Y''
) 
or 
(Postal.SiteId in (SELECT value FROM STRING_SPLIT('''+ @NULLSiteId + ''','','')) AND psa.validateNULL(store.store_name) IS  NULL))');



exec('
INSERT INTO ser.SiteRole (SiteRoleId,SiteId,LOVRoleId,SourceKey,SiteRoleName,SiteRoleShortName,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)

SELECT 
CASE When tr.SourceKey is not null  and tr.lovrecordsourceId is not null 		
Then  tr.SiteroleId
ELSE '+@maxSiteRoleId+ ' + ROW_NUMBER() OVER(ORDER BY  store_number,store.record_source_id) END SiteRoleId,
postal.Siteid,
'+@LOVRoleId+ ' lovroleid,store_number,store_name,NULL,store.record_source_id, CASE WHEN (COALESCE(tr.SCDVERSION,0) + 1)=1  THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''') END SCDStartDate,	CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''') SCDEndDate,			
''Y'',
COALESCE(tr.SCDVERSION,0) + 1 AS SCDVERSION ,
store.record_source_id, '+@serveETLRunLogID+ ' ETLRunLogId, row_id PSARowKey 
from '+@inpTableName+ ' store 
JOIN ser.PostalAddress POSTAL 
on ISNULL(trim(psa.validateNULL(store.address_line1)),'''')=ISNULL(trim(POSTAL.AddressLine1),'''') AND   
ISNULL(trim(psa.validateNULL(store.address_line2)),'''') =ISNULL(trim(POSTAL.AddressLine2),'''') AND 
ISNULL(trim(psa.validateNULL(store.address_line3)),'''')=ISNULL(trim(POSTAL.Town),'''') AND 
ISNULL(trim(psa.validateNULL(store.address_line4)),'''')=ISNULL(trim(POSTAL.County),'''') AND	
ISNULL(trim(psa.validateNULL(store.postal_code)),'''')=ISNULL(trim(POSTAL.PostalCode) ,'''') AND 
Postal.LovRecordSourceId='+@PostalLOVRecordSourceId+ ' AND 
Postal.SCDActiveFlag=''Y''  
and
store.row_status='+@PSARowStatus + ' and store.date_added='+@CurDate+ ' 
LEFT JOIN (
select sr.siteroleid,sr.siteid,sr.SourceKey,sr.siterolename,sr.scdversion,sr.lovrecordsourceId from ser.siterole sr 
JOIN (select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
where lovrecordsourceId='+@recordSourceId + ' group by sourcekey,lovrecordsourceId)P  
on P.sourcekey=sr.sourcekey and P.lovrecordsourceId=sr.lovrecordsourceId 
where sr.scdversion=P.scdversion)tr
on store.store_number=tr.sourcekey and tr.lovrecordsourceId =store.record_source_id

where  (Postal.SiteId not in  (SELECT value FROM STRING_SPLIT('''+ @NULLSiteId + ''','','')) OR ( len( trim(store.store_name)) >0 AND store.store_name 
IS NOT NULL AND store.store_name <> ''NULL''))		-- NULL OR BLANK DONT INSERT 
and  NOT EXISTS (								
	SELECT *  FROM ser.siterole srr where 
	tr.sourcekey=srr.sourcekey and tr.lovrecordsourceid=srr.lovrecordsourceid and 
	 tr.scdversion=srr.scdversion 
	AND tr.lovrecordsourceId=store.record_source_id AND ISNULL(store.store_name,'''')=ISNULL(tr.SiteRoleName,'''') 
	AND postal.siteid=tr.siteid AND srr.scdactiveflag=''Y''
) 
')

PRINT '****************************** INFO: Siterole LOADED*************************'



exec('DELETE FROM ser.TempIntStore_SiteRole_STG');
exec('INSERT INTO ser.TempIntStore_SiteRole_STG
SELECT str.siteroleid,str.siteid,str.SourceKey,str.siterolename, str.lovrecordsourceid,str.scdactiveflag, str.scdversion from ser.siterole str 
join 
(select sourcekey,max(scdversion) scdversion,lovrecordsourceId from ser.Siterole  
where lovrecordsourceId='+@recordSourceId + ' group by sourcekey,lovrecordsourceId)P  
 on P.sourcekey=str.sourcekey and P.lovrecordsourceId=str.lovrecordsourceId 
 where str.scdversion=P.scdversion ')



PRINT '********************************INFO : 7. LOADING Siteroleindicator**************'



exec('
UPDATE ser.SiteRoleIndicator   set SCDEndDate= CONVERT(NVARCHAR,'''+@SCDEndDate+'''),  
SCDActiveFlag=''N'' 
FROM ser.SiteRoleIndicator join
(select str.siteroleid,str.LOVIndicatorId,str.Value, str.lovrecordsourceid,str.scdversion,str.scdactiveflag from ser.SiteRoleIndicator str 
join 
(select siteroleid,LOVIndicatorId,max(scdversion) scdversion,lovrecordsourceId from ser.SiteRoleIndicator  
where lovrecordsourceId='+@recordSourceId + ' group by siteroleid,LOVIndicatorId,lovrecordsourceId)P  
 on P.siteroleid=str.siteroleid and P.LOVIndicatorId=str.LOVIndicatorId and P.lovrecordsourceId=str.lovrecordsourceId 
 where str.scdversion=P.scdversion )  sr
on SiteRoleIndicator.siteroleid=sr.siteroleid and 
SiteRoleIndicator.LOVIndicatorId=sr.LOVIndicatorId and 
SiteRoleIndicator.lovrecordsourceid=sr.lovrecordsourceId and 
SiteRoleIndicator.scdactiveflag=''Y''
join '+ @inpTableName+ '  store
on store.record_source_id= SiteRoleIndicator.lovrecordsourceid AND store.Row_status='+@PSARowStatus + ' and store.date_added='+@CurDate + ' 

join 
ser.TempIntStore_SiteRole_STG  siterole  on 
SiteRole.SourceKey=store.store_number AND SiteRole.LOVRecordSourceId=store.record_source_id 
and SiteRoleIndicator.siteroleid=siterole.siteroleid	
Where  siterole.scdactiveflag=''N'' or (psa.validateNULL(store.heritage_flag) IS NULL ) or NOT EXISTS (								
SELECT *  FROM ser.siteroleindicator srr where 
sr.LOVIndicatorId=srr.LOVIndicatorId and sr.lovrecordsourceid=srr.lovrecordsourceid and  sr.siteroleid=srr.siteroleid and
sr.scdversion=srr.scdversion AND srr.scdactiveflag=''Y''
AND sr.lovrecordsourceId=store.record_source_id AND ISNULL(store.heritage_flag,'''')=ISNULL(srr.value,'''') 	
) 
');


exec('INSERT INTO ser.SiteRoleIndicator
(SiteRoleId,LOVIndicatorId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)

SELECT SiteRole.SiteroleId,'+@LOVIndicatorId+',heritage_flag,record_source_id,
CASE WHEN (COALESCE(tr.SCDVERSION,0) + 1)=1  THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''') END SCDStartDate,CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''') SCDEndDate,
''Y'',COALESCE(tr.SCDVERSION,0) + 1 AS SCDVERSION ,record_source_id, '+@serveETLRunLogID+ ' ETLRunLogId,  
row_id PSARowKey from '+ @inpTableName+ '  store 
join 
ser.TempIntStore_SiteRole_STG  siterole  on 
SiteRole.SourceKey=store.store_number AND SiteRole.LOVRecordSourceId=store.record_source_id 
AND store.Row_status='+@PSARowStatus + ' and store.date_added='+@CurDate + ' and (len( trim(store.heritage_flag)) >0 and
store.heritage_flag IS NOT NULL and store.heritage_flag <> ''NULL'') 			-- NULL OR BLANK DONT INSERT
LEFT JOIN (
select sri.siteroleid,sri.LOVIndicatorId,sri.Value,sri.scdversion,sri.lovrecordsourceId from ser.siteroleindicator sri 
JOIN (select siteroleid,LOVIndicatorId,max(scdversion) scdversion,lovrecordsourceId from ser.siteroleindicator  
where lovrecordsourceId='+@recordSourceId + ' group by siteroleid,LOVIndicatorId,lovrecordsourceId)P  
on P.siteroleid=sri.siteroleid and P.LOVIndicatorId=sri.LOVIndicatorId and P.lovrecordsourceId=sri.lovrecordsourceId 
where sri.scdversion=P.scdversion)tr
on  tr.lovrecordsourceId =store.record_source_id and siterole.siteroleid=tr.siteroleid and 
tr.LOVIndicatorId='+@LOVIndicatorId + ' where NOT EXISTS (								
SELECT *  FROM ser.siteroleindicator srr where 
tr.LOVIndicatorId=srr.LOVIndicatorId and tr.lovrecordsourceid=srr.lovrecordsourceid and  tr.siteroleid=srr.siteroleid and
tr.scdversion=srr.scdversion AND srr.scdactiveflag=''Y''
AND tr.lovrecordsourceId=store.record_source_id AND ISNULL(store.heritage_flag,'''')=ISNULL(srr.value,'''') 

) AND siterole.scdactiveflag=''Y'' ')

PRINT '****************************** INFO: Siteroleindicator LOADED*************************'


PRINT '****************************** INFO: 8. LOADING SiteroleGroup*************************'

SELECT @MAXSRGpID=COALESCE(max(siterolegroupid),0) from ser.siterolegroup;

exec('DELETE FROM ser.TempIntStore_SiteRoleGroup_STG')
exec('
INSERT INTO ser.TempIntStore_SiteRoleGroup_STG
SELECT CASE WHEN SRGrp.SiteRoleId is  NULL AND SRGrp.LOVSiteRoleGroupSetId IS NULL AND SRGrp.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag,
SRGrp.SiteRoleGroupId,
pvt.SiteRoleId, pvt.PGCol,pvt.PGValue,pvt.LOVSiteRoleGroupSetId,pvt.LOVGroupId,NULL as ParentSiteRoleGroupId, pvt.LOVRecordSourceId, 
COALESCE(SRGrp.SCDVERSION,0) +1  SCDVERSION,row_id PSARowKey,siteroleidactive
FROM (
SELECT 
SiteRoleId,
PGCol,
PGValue,
(CASE 
WHEN PGCol in (''store_format'')  THEN
(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = PGValue AND 
r.LOVSetName = PGCol and r.LOVRecordSourceID =record_source_id )
WHEN PGCol in (''store_loc'') THEN
(SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = PGValue AND 
r.LOVSetName = PGCol and r.LOVRecordSourceID =record_source_id)

END ) LOVGroupId, 
(CASE 
WHEN PGCol in (''store_format'') THEN
(SELECT TOP 1 LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''store_format'' AND
rs.LOVRecordSourceID = record_source_id) 
WHEN PGCol in (''store_loc'') THEN
(SELECT TOP 1 LOVSetId FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = ''store_loc'' AND
rs.LOVRecordSourceID = record_source_id ) 

END ) LOVSiteRoleGroupSetId,

record_source_id LOVRecordSourceId,
date_added  ,                            

row_id, siteroleidactive
FROM  
(

SELECT
sr.SiteRoleID 
,ISNULL(NULLIF(store_format,''''),''NULL VALUE'') store_format 
,ISNULL(NULLIF(store_loc,''''),''NULL VALUE'') store_loc
,store.record_source_id 
,date_added date_added
,store.row_id 
,sr.scdactiveflag siteroleidactive
FROM '+ @inpTableName+ ' store 
INNER JOIN
ser.TempIntStore_SiteRole_STG sr on sr.lovrecordsourceid = store.record_source_id and sr.SourceKey=store.store_number
AND store.Row_status='+@PSARowStatus+'  and store.date_added='+@CurDate+ '
) pg 
UNPIVOT  
( PGValue FOR PGCol IN ( pg.store_format
,pg.store_loc
)
) AS LOVGroupId  ) 
pvt LEFT JOIN 
(SELECT SRG.SiteRoleGroupId,SRG.siteroleid,SRG.LOVSiteRoleGroupSetId,SRG.LOVRecordSourceId,P.scdversion FROM ser.SiteRoleGroup SRG join
(SELECT siteroleid,LOVSiteRoleGroupSetId,LOVRecordSourceId,max(scdversion) scdversion from ser.SiteRoleGroup where lovrecordsourceId='+@recordSourceId + ' 
group by siteroleid,LOVSiteRoleGroupSetId,LOVRecordSourceId)P on SRG.SiteRoleId=P.SiteRoleId AND 
P.LOVSiteRoleGroupSetId=SRG.LOVSiteRoleGroupSetId AND P.LOVRecordSourceId=SRG.LOVRecordSourceId
and P.scdversion=SRG.scdversion) SRGrp on pvt.SiteRoleId=SRGrp.SiteRoleId AND 
pvt.LOVSiteRoleGroupSetId=SRGrp.LOVSiteRoleGroupSetId AND pvt.LOVRecordSourceId=SRGrp.LOVRecordSourceId 
Where not exists (
SELECT *  FROM ser.siterolegroup srr where 
	SRGrp.SiteRoleId=srr.SiteRoleId and SRGrp.lovrecordsourceid=srr.lovrecordsourceid and SRGrp.LOVSiteRoleGroupSetId=srr.LOVSiteRoleGroupSetId and 
	 SRGrp.scdversion=srr.scdversion 
	AND SRGrp.lovrecordsourceId=pvt.lovrecordsourceId AND pvt.LOVGroupId=srr.LOVGroupId AND srr.scdactiveflag=''Y''
	) OR (pvt.siteroleidactive=''N'')
')



exec('
UPDATE ser.SiteRoleGroup   set SCDEndDate= CONVERT(NVARCHAR,'''+@SCDEndDate+'''),  
SCDActiveFlag=''N'' 
FROM ser.SiteRoleGroup SRG join
(select src.SiteRoleGroupId,src.siteroleid,src.LOVSiteRoleGroupSetId,src.LOVGroupId,src.scdversion,
src.lovrecordsourceId from ser.siteroleGroup src join 
(SELECT SiteRoleId,LOVSiteRoleGroupSetId,LOVRecordSourceId,max(scdversion) scdversion 
 from ser.siterolegroup where lovrecordsourceId='+@recordSourceId + '  
group by
SiteRoleId,LOVSiteRoleGroupSetId,LOVRecordSourceId)P 
on P.SiteRoleId=src.SiteRoleId and P.LOVSiteRoleGroupSetId=src.LOVSiteRoleGroupSetId and P.lovrecordsourceId=src.lovrecordsourceId
and P.scdversion=src.scdversion ) tr  on
tr.SiteRoleId=srg.SiteRoleId and tr.LOVSiteRoleGroupSetId=srg.LOVSiteRoleGroupSetId and tr.lovrecordsourceId=srg.lovrecordsourceId
and tr.scdversion=srg.scdversion and SRG.scdactiveflag=''Y''
join 
ser.TempIntStore_SiteRoleGroup_STG STG
ON  STG.SiteRoleId=SRG.SiteRoleId and STG.LOVSiteRoleGroupSetId=SRG.LOVSiteRoleGroupSetId and STG.lovrecordsourceId=SRG.lovrecordsourceId
Where STG.ExistsFlag=1 OR  (PGValue =''NULL VALUE'' OR STG.siteroleidactive=''N'')')



exec('INSERT INTO [ser].[SiteRoleGroup]
           ([SiteRoleGroupId]
           ,[SiteRoleId]
           ,[LOVSiteRoleGroupSetId]
           ,[LOVGroupId]
           ,[ParentSiteRoleGroupId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])
			SELECT  
			CASE WHEN INS.existsFlag=1 THEN INS.SiteRoleGroupId
			ELSE ROW_NUMBER() OVER(ORDER BY INS.SiteRoleId,LOVSiteRoleGroupSetId,LOVRecordSourceId ASC)+'+@MAXSRGpID+' END  SiteRoleGroupId,
			        INS.SiteRoleId,
					LOVSiteRoleGroupSetId,
					LOVGroupId,					
					ParentSiteRoleGroupId,
					LOVRecordSourceId,
					CASE WHEN INS.SCDVERSION=1  THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
							 ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''') END SCDStartDate,			
					CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''') SCDEndDate,					
					''Y''         ,
					INS.SCDVERSION  SCDVERSION,
					LOVRecordSourceId   SCDLOVRecordSourceId,'
					+@serveETLRunLogId+'  ETLRunLogId,INS.PSARowKey
			FROM  
			(SELECT * FROM ser.TempIntStore_SiteRoleGroup_STG STG WHERE LOVGroupId is not NULL			
			AND STG.siteroleidactive=''Y'' 
			)INS
			
			')


 
PRINT '****************************** INFO: 10. SiteroleProperty LOADING*************************'

PRINT '****Deleting from ser.TmpIntStore_SiteRoleProp_STG****'

exec('DELETE FROM ser.TmpIntStore_SiteRoleProp_STG')

PRINT '****Loading to ser.TmpIntStore_SiteRoleProp_STG****'

exec(  '
INSERT INTO  ser.TmpIntStore_SiteRoleProp_STG
SELECT CASE WHEN SRG.SiteRoleId is  NULL AND SRG.MeasureId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag,
pvt.SiteRoleId, pvt.PGCol,pvt.MeasureId,pvt.UOMID,  pvt.Value,pvt.LOVRecordSourceId, ''Y'' SCDActiveFlag,
COALESCE(SRG.SCDVersion,0)  +1  SCDVersion,pvt.PSARowKey, siteroleidactive
FROM(SELECT SiteRoleId,
	PGCol,
	Case When PGCol =''store_ndsa'' Then (SELECT Measure.MeasureId FROM ser.Measure WHERE MeasureName = ''store_ndsa''
	AND Measure.lovrecordsourceId = record_source_id AND Measure.lovmeasuretypeid= '+@LOVFloorAreaMeasureTypeId+'  
	AND Measure.lovdatatypeid='+ @LOVDataTypeId+' )
	When PGCol =''store_size'' Then (SELECT Measure.MeasureId FROM ser.Measure WHERE MeasureName = ''store_size''
	AND Measure.lovrecordsourceId = record_source_id AND Measure.lovmeasuretypeid= '+@LOVFloorAreaMeasureTypeId+' 
	and Measure.lovdatatypeid='+ @LOVDataTypeId+')
	When PGCol =''latitude'' Then (SELECT Measure.MeasureId FROM ser.Measure WHERE MeasureName = ''latitude''
	AND Measure.lovrecordsourceId = record_source_id AND Measure.lovmeasuretypeid= '+@LOVGeoCodeMeasureTypeId+' 
	and Measure.lovdatatypeid='+ @LOVDataTypeId+')
	When PGCol =''longitude'' Then (SELECT Measure.MeasureId FROM ser.Measure WHERE MeasureName = ''longitude''
	AND Measure.lovrecordsourceId = record_source_id AND Measure.lovmeasuretypeid= '+@LOVGeoCodeMeasureTypeId+' 
	and Measure.lovdatatypeid='+ @LOVDataTypeId+')	  
	END AS MeasureId,
	
	Case When PGCol =''store_ndsa'' Then '+@UOMID2 + '
	When PGCol =''store_size'' 		Then '+@UOMID1 + ' 
	When PGCol =''latitude'' Then '+@UOMID3 + '  
	When PGCol =''longitude'' Then '+@UOMID3 + '  End AS  UOMID,
	PGValue  Value ,							
	record_source_id LOVRecordSourceId,
	date_added  ,	
	PSARowKey , siteroleidactive FROM (
		SELECT
		sr.SiteRoleID,		
		CASE WHEN '''+ @CountryCode +''' in (''NO'') THEN ISNULL((SELECT cast(replace(psa.validateNULL(store_ndsa) ,'','',''.'') as nvarchar)), ''NULL VALUE'')												
		ELSE ISNULL(cast(psa.validateNULL(store_ndsa) as nvarchar), ''NULL VALUE'') END store_ndsa,			

		CASE WHEN '''+ @CountryCode +''' in (''NO'') THEN ISNULL((SELECT cast(replace(psa.validateNULL(store_size) ,'','',''.'') as nvarchar))	, ''NULL VALUE'')
		ELSE ISNULL(cast(psa.validateNULL(store_size) as nvarchar), ''NULL VALUE'') END store_size
		
		,ISNULL(cast(psa.validateNULL(latitude) as nvarchar), ''NULL VALUE'') latitude
		,ISNULL(cast(psa.validateNULL(longitude) as nvarchar), ''NULL VALUE'')   longitude					
		,store.record_source_id record_source_id
		,date_added	date_added
		,store.row_id PSARowKey
		,sr.scdactiveflag siteroleidactive
		FROM '+ @inpTableName+ '  store
				INNER JOIN
				ser.TempIntStore_SiteRole_STG  sr on sr.lovrecordsourceid = store.record_source_id and sr.SourceKey=store.store_number AND
				store.Row_status='+@PSARowStatus+'  and store.date_added='+@CurDate+ ' 
				) pg
								UNPIVOT  
							( PGValue FOR PGCol IN ( pg.store_ndsa
													,pg.store_size
													,pg.latitude
													,pg.longitude
													)
							)	AS LOVGroupId ) pvt  
							LEFT JOIN 
							(SELECT SRP.SiteRoleId,SRP.MeasureId,SRP.LOVRecordSourceId, SRP.scdversion from ser.SiteRoleProperty SRP
join (select SiteRoleId,MeasureId,LOVRecordSourceId, max(scdversion) scdversion from ser.SiteRoleProperty	where lovrecordsourceId='+@recordSourceId + ' 
group by SiteRoleId,MeasureId,LOVRecordSourceId	)P 
ON P.SiteRoleId=SRP.SiteroleId and P.MeasureId=SRP.MeasureId and P.lovrecordsourceId=SRP.lovrecordsourceId and P.scdversion=SRP.scdversion
			)SRG  on pvt.SiteRoleId=SRG.SiteRoleId AND 
			pvt.MeasureId=SRG.MeasureId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId 
			Where not exists (
	SELECT *  FROM ser.SiteRoleProperty srr where 
	SRG.SiteRoleId=srr.SiteRoleId and SRG.MeasureId=srr.MeasureId and 
	SRG.scdversion=srr.scdversion 
	AND SRG.lovrecordsourceId=pvt.lovrecordsourceId AND pvt.UOMID=srr.LOVUOMId AND pvt.Value=srr.Value AND srr.scdactiveflag=''Y''
	) OR (pvt.siteroleidactive=''N'')'
			
)

PRINT '****Updating to ser.SiteRoleProperty****'

exec('
UPDATE ser.SiteRoleProperty   set SCDEndDate= CONVERT(NVARCHAR,'''+@SCDEndDate+'''), 
SCDActiveFlag=''N'' 
FROM ser.SiteRoleProperty SRG join
(SELECT SRP.SiteRoleId,SRP.MeasureId,SRP.LOVRecordSourceId, SRP.scdversion from ser.SiteRoleProperty SRP
join (select SiteRoleId,MeasureId,LOVRecordSourceId, max(scdversion) scdversion from ser.SiteRoleProperty	where lovrecordsourceId='+@recordSourceId + ' 
group by SiteRoleId,MeasureId,LOVRecordSourceId	)P 
ON P.SiteRoleId=SRP.SiteroleId and P.MeasureId=SRP.MeasureId and P.lovrecordsourceId=SRP.lovrecordsourceId and P.scdversion=SRP.scdversion ) tr  on
tr.SiteRoleId=srg.SiteRoleId and tr.MeasureId=srg.MeasureId and tr.lovrecordsourceId=srg.lovrecordsourceId
and tr.scdversion=srg.scdversion and SRG.scdactiveflag=''Y''
join 
ser.TmpIntStore_SiteRoleProp_STG STG
ON  STG.SiteRoleId=SRG.SiteRoleId and STG.MeasureId=SRG.MeasureId and STG.lovrecordsourceId=SRG.lovrecordsourceId
Where STG.ExistsFlag=1 OR  (stg.Value =''NULL VALUE'' OR STG.siteroleidactive=''N'')')



exec('INSERT INTO ser.SiteRoleProperty 
	(SiteRoleId ,
	MeasureId,
	LOVUOMId,
	Value,
	LOVRecordSourceId,
	SCDStartDate, 
	SCDEndDate,
	SCDActiveFlag, 
	SCDVersion,
	SCDLOVRecordSourceId,
	ETLRunLogId,
	PSARowKey)
	SELECT  INS.SiteRoleId,
			MeasureId,
			LOVUOMId,					
			Value,
			LOVRecordSourceId,
			CASE WHEN INS.SCDVERSION=1  THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
							 ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''') END SCDStartDate,			
			CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''') SCDEndDate,					
			''Y''         ,
			INS.SCDVERSION  SCDVERSION,
			LOVRecordSourceId   SCDLOVRecordSourceId,'
			+@serveETLRunLogId+'  ETLRunLogId,INS.PSARowKey
	FROM  
	(SELECT * FROM ser.TmpIntStore_SiteRoleProp_STG STG WHERE STG.Value <> ''NULL VALUE'' AND STG.siteroleidactive=''Y'' )INS')




PRINT '****************************** INFO: 10 SiteroleTerritory LOADING*************************'

PRINT '****Deleting from ser.TmpIntStore_SiteRoleTerritory_STG****'

exec('DELETE FROM ser.TmpIntStore_SiteRoleTerritory_STG')

PRINT '****Loading to ser.TmpIntStore_SiteRoleTerritory_STG****'
if (@countryCode in ('NO'))
BEGIN
exec('INSERT INTO ser.TmpIntStore_SiteRoleTerritory_STG
SELECT 
				CASE WHEN SRG.SiteRoleId is  NULL AND SRG.LOVSiteRoleTerritorySetId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag,
				pvt.SiteRoleId, pvt.PGCol,pvt.Value, pvt.LOVSiteRoleTerritorySetId,pvt.LOVTerritoryId, pvt.LOVRecordSourceId,
				
				''Y'' SCDActiveFlag,
				COALESCE(SRG.SCDVersion,0) +1  SCDVersion,pvt.PSARowKey,  siteroleidactive
				FROM
				 (
                    SELECT 
							SiteRoleId,
							PGCol,
							Case When PGValue is not null Then (SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = PGValue AND 
												r.LOVSetName =PGCol	and r.LOVRecordSourceID = record_source_id) End AS  LOVTerritoryId,
											
							Case When PGValue is not null Then (SELECT distinct LOVSetID FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = PGCol AND
										rs.LOVRecordSourceID = record_source_id) End AS LOVSiteRoleTerritorySetId,
							PGValue  Value ,							
							record_source_id LOVRecordSourceId,
							date_added,
							PSARowKey, siteroleidactive
				 FROM
				(SELECT
						 SiteRoleID		
						,ISNULL(cast(psa.validateNULL(area_code) as nvarchar), ''NULL VALUE'') area_code
						,ISNULL(cast(psa.validateNULL(district_code) as nvarchar), ''NULL VALUE'') district_code						
						,store.record_source_id 
						,date_added	date_added		
						,store.row_id PSARowKey,
						sr.scdactiveflag siteroleidactive
				FROM '+ @inpTableName+ '   store
				INNER JOIN
				ser.TempIntStore_SiteRole_STG sr on sr.lovrecordsourceid = store.record_source_id and sr.SourceKey=store.store_number
				AND store.Row_status='+@PSARowStatus+'  and store.date_added='+@CurDate+ '
				) pg
								UNPIVOT  
							( PGValue FOR PGCol IN ( pg.area_code
													,pg.district_code													
													)
							)	AS LOVGroupId  
							) pvt
							LEFT JOIN 
							(SELECT srt.siteroleid,srt.LOVSiteRoleTerritorySetId,srt.LOVRecordSourceId,srt.scdversion from ser.SiteRoleTerritory srt
							JOIN (SELECT siteroleid,LOVSiteRoleTerritorySetId,LOVRecordSourceId,max(scdversion) scdversion from ser.SiteRoleTerritory 
							where lovrecordsourceId='+@recordSourceId + ' group by siteroleid,LOVSiteRoleTerritorySetId,LOVRecordSourceId)P 
							ON srt.SiteRoleId=P.SiteRoleId AND srt.LOVSiteRoleTerritorySetId=P.LOVSiteRoleTerritorySetId AND 
							srt.LOVRecordSourceId=P.LOVRecordSourceId and srt.scdversion=P.scdversion
			) SRG  on pvt.SiteRoleId=SRG.SiteRoleId AND 
			pvt.LOVSiteRoleTerritorySetId=SRG.LOVSiteRoleTerritorySetId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId 
			Where not exists (
	SELECT *  FROM ser.SiteRoleTerritory srr where 
	SRG.SiteRoleId=srr.SiteRoleId and SRG.LOVSiteRoleTerritorySetId=srr.LOVSiteRoleTerritorySetId and 
	SRG.scdversion=srr.scdversion 
	AND srr.lovrecordsourceId=pvt.lovrecordsourceId AND srr.LOVTerritoryId=pvt.LOVTerritoryId AND srr.scdactiveflag=''Y''
	) OR (pvt.siteroleidactive=''N'')');
	
End

--region_code is not mapped to siteroleterritory for country Norway
if (@countryCode in ('CL','MX','TH'))
BEGIN

exec('INSERT INTO ser.TmpIntStore_SiteRoleTerritory_STG
SELECT 
				CASE WHEN SRG.SiteRoleId is  NULL AND SRG.LOVSiteRoleTerritorySetId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag,
				pvt.SiteRoleId, pvt.PGCol,pvt.Value, pvt.LOVSiteRoleTerritorySetId,pvt.LOVTerritoryId, pvt.LOVRecordSourceId,
				
				''Y'' SCDActiveFlag,
				COALESCE(SRG.SCDVersion,0) +1  SCDVersion,pvt.PSARowKey,  siteroleidactive
				FROM
				 (
                    SELECT 
							SiteRoleId,
							PGCol,
							Case When PGValue is not null Then (SELECT r.LOVId FROM ser.RefLOVSetInfo r WHERE r.LOVKey = PGValue AND 
												r.LOVSetName =PGCol	and r.LOVRecordSourceID = record_source_id) End AS  LOVTerritoryId,
											
							Case When PGValue is not null Then (SELECT distinct LOVSetID FROM ser.RefLOVSetInfo rs WHERE  rs.LOVSetName = PGCol AND
										rs.LOVRecordSourceID = record_source_id) End AS LOVSiteRoleTerritorySetId,
							PGValue  Value ,							
							record_source_id LOVRecordSourceId,
							date_added,
							PSARowKey, siteroleidactive
				 FROM
				(SELECT
						 SiteRoleID		
						,ISNULL(cast(psa.validateNULL(area_code) as nvarchar), ''NULL VALUE'') area_code
						,ISNULL(cast(psa.validateNULL(district_code) as nvarchar), ''NULL VALUE'') district_code
						,CASE WHEN '''+ @CountryCode +''' in (''NO'') THEN NULL
						ELSE ISNULL(cast(psa.validateNULL(region_code) as nvarchar), ''NULL VALUE'')	END region_code
						,store.record_source_id 
						,date_added	date_added		
						,store.row_id PSARowKey,
						sr.scdactiveflag siteroleidactive
				FROM '+ @inpTableName+ '   store
				INNER JOIN
				ser.TempIntStore_SiteRole_STG sr on sr.lovrecordsourceid = store.record_source_id and sr.SourceKey=store.store_number
				AND store.Row_status='+@PSARowStatus+'  and store.date_added='+@CurDate+ '
				) pg
								UNPIVOT  
							( PGValue FOR PGCol IN ( pg.area_code
													,pg.district_code
													,pg.region_code
													)
							)	AS LOVGroupId  
							) pvt
							LEFT JOIN 
							(SELECT srt.siteroleid,srt.LOVSiteRoleTerritorySetId,srt.LOVRecordSourceId,srt.scdversion from ser.SiteRoleTerritory srt
							JOIN (SELECT siteroleid,LOVSiteRoleTerritorySetId,LOVRecordSourceId,max(scdversion) scdversion from ser.SiteRoleTerritory 
							where lovrecordsourceId='+@recordSourceId + ' group by siteroleid,LOVSiteRoleTerritorySetId,LOVRecordSourceId)P 
							ON srt.SiteRoleId=P.SiteRoleId AND srt.LOVSiteRoleTerritorySetId=P.LOVSiteRoleTerritorySetId AND 
							srt.LOVRecordSourceId=P.LOVRecordSourceId and srt.scdversion=P.scdversion
			) SRG  on pvt.SiteRoleId=SRG.SiteRoleId AND 
			pvt.LOVSiteRoleTerritorySetId=SRG.LOVSiteRoleTerritorySetId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId 
			Where not exists (
	SELECT *  FROM ser.SiteRoleTerritory srr where 
	SRG.SiteRoleId=srr.SiteRoleId and SRG.LOVSiteRoleTerritorySetId=srr.LOVSiteRoleTerritorySetId and 
	SRG.scdversion=srr.scdversion 
	AND srr.lovrecordsourceId=pvt.lovrecordsourceId AND srr.LOVTerritoryId=pvt.LOVTerritoryId AND srr.scdactiveflag=''Y''
	) OR (pvt.siteroleidactive=''N'')');
			

END 
PRINT '****Updating to ser.SiteRoleTerritory****'

exec('
UPDATE ser.SiteRoleTerritory   set SCDEndDate= CONVERT(NVARCHAR,'''+@SCDEndDate+'''), 
SCDActiveFlag=''N'' 
FROM ser.SiteRoleTerritory SRG join
(SELECT srt.siteroleid,srt.LOVSiteRoleTerritorySetId,srt.LOVRecordSourceId,srt.scdversion from ser.SiteRoleTerritory srt
JOIN (SELECT siteroleid,LOVSiteRoleTerritorySetId,LOVRecordSourceId,max(scdversion) scdversion from ser.SiteRoleTerritory 
where lovrecordsourceId='+@recordSourceId + ' group by siteroleid,LOVSiteRoleTerritorySetId,LOVRecordSourceId)P 
ON srt.SiteRoleId=P.SiteRoleId AND srt.LOVSiteRoleTerritorySetId=P.LOVSiteRoleTerritorySetId AND 
srt.LOVRecordSourceId=P.LOVRecordSourceId and srt.scdversion=P.scdversion ) tr  on
tr.SiteRoleId=srg.SiteRoleId and tr.LOVSiteRoleTerritorySetId=srg.LOVSiteRoleTerritorySetId and tr.lovrecordsourceId=srg.lovrecordsourceId
and tr.scdversion=srg.scdversion and SRG.scdactiveflag=''Y''
join 
ser.TmpIntStore_SiteRoleTerritory_STG STG
ON  STG.SiteRoleId=SRG.SiteRoleId and STG.LOVSiteRoleTerritorySetId=SRG.LOVSiteRoleTerritorySetId and STG.lovrecordsourceId=SRG.lovrecordsourceId
Where STG.ExistsFlag=1 OR (stg.Value =''NULL VALUE'' OR STG.siteroleidactive=''N'')')


PRINT '****Inserting to ser.SiteRoleTerritory****'
exec('INSERT INTO ser.SiteRoleTerritory 
(SiteRoleId ,LOVSiteRoleTerritorySetId ,LOVTerritoryId
 ,LOVRecordSourceId ,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId
 ,ETLRunLogId ,PSARowKey)
 SELECT  INS.SiteRoleId,
			LOVSiteRoleTerritorySetId,
			LOVTerritoryId,								
			LOVRecordSourceId,
			CASE WHEN INS.SCDVERSION=1  THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
										ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''') END SCDStartDate,			
			CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''') SCDEndDate,					
			''Y''         ,
			INS.SCDVERSION  SCDVERSION,
			LOVRecordSourceId   SCDLOVRecordSourceId,'
			+@serveETLRunLogId+'  ETLRunLogId,INS.PSARowKey
	FROM  
	(SELECT * FROM ser.TmpIntStore_SiteRoleTerritory_STG STG WHERE LOVTerritoryId IS NOT NULL 
	--STG.Value <> ''NULL VALUE'' 
	AND STG.siteroleidactive=''Y'' )INS')




PRINT 'Info: 11. Loading SiteRoleStatus *******************************';  
-- opendate and closedate are both null ignore that record for current entry and closeoff the previous record
-- opendate alone is present , openstatus with eff from as opendate and effTo of the previous record is populated with opendate
-- closedate alone is present, closestatus with eff from as closedate and effTo of the previous record is populated with closedate
-- both are present, ClosedStatus and efffrom-closedate and effto-null , version n+1 

exec('DELETE FROM ser.TempIntStore_SiteRoleStatus_STG');
exec(' INSERT INTO ser.TempIntStore_SiteRoleStatus_STG

SELECT CASE WHEN SRStatus.SiteRoleId IS NULL AND SRStatus.LOVSiteRoleStatusSetId IS NULL 
AND SRStatus.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag,
 sr.siteroleid, store.LOVSiteRoleStatusSetId, 
 Case When (psa.validateNULL(open_date) is not NULL) and (psa.validateNULL(close_date) is not NULL) AND 
((SRStatus.SiteRoleId IS NULL AND SRStatus.LOVSiteRoleStatusSetId IS NULL AND SRStatus.LOVRecordSourceId IS NULL)
OR ( SRStatus.SiteRoleId IS NOT NULL AND SRStatus.LOVSiteRoleStatusSetId IS NOT NULL AND SRStatus.LOVRecordSourceId IS NOT NULL 
AND SRStatus.LOVStatusId =  '+@OpenStatus+'  AND SRStatus.EffectiveFrom <> open_date )
OR
( SRStatus.SiteRoleId IS NOT NULL AND SRStatus.LOVSiteRoleStatusSetId IS NOT NULL AND SRStatus.LOVRecordSourceId IS NOT NULL 
AND SRStatus.LOVStatusId <>  '+@OpenStatus+' ))
Then 1 ELSE 0 END OpenStatusFlag, store.StatusId, store.EffectiveFrom, store.EffectiveTo,store.open_date,store.close_date,store.record_source_id,
store.SCDActiveFlag, store.SCDEndDate, 
CASE WHEN 
(psa.validateNULL(open_date) is not NULL) and (psa.validateNULL(close_date) is not NULL) and ((SRStatus.SiteRoleId IS NULL AND SRStatus.LOVSiteRoleStatusSetId IS NULL AND SRStatus.LOVRecordSourceId IS NULL)
OR ( SRStatus.SiteRoleId IS NOT NULL AND SRStatus.LOVSiteRoleStatusSetId IS NOT NULL AND SRStatus.LOVRecordSourceId IS NOT NULL 
AND SRStatus.LOVStatusId =  '+@OpenStatus+'  AND SRStatus.EffectiveFrom <> open_date )
OR
( SRStatus.SiteRoleId IS NOT NULL AND SRStatus.LOVSiteRoleStatusSetId IS NOT NULL AND SRStatus.LOVRecordSourceId IS NOT NULL 
AND SRStatus.LOVStatusId <>  '+@OpenStatus+' ))
THEN COALESCE(SRStatus.SCDVersion,0) +2 ELSE COALESCE(SRStatus.SCDVersion,0) +1  END SCDVersion,   store.row_id PSARowKey, sr.scdactiveflag siteroleidactive   FROM 
(
SELECT  store_number,
psa.validateNULL(open_date) open_date,
psa.validateNULL(close_date) close_date,'
+@LOVSiteRoleStatusSetId+' LOVSiteRoleStatusSetId,
CASE When (psa.validateNULL(open_date) is NULL ) AND (psa.validateNULL(close_date) is NULL) Then NULL
When (psa.validateNULL(open_date) is not NULL) and (psa.validateNULL(close_date) is not NULL) Then '+@ClosedStatus+'
When (psa.validateNULL(open_date) is not NULL) and (psa.validateNULL(close_date) is NULL) Then '+@OpenStatus+' 
When (psa.validateNULL(open_date) is NULL ) and (psa.validateNULL(close_date) is not NULL) Then '+@ClosedStatus+'

END AS StatusId,

CASE When (psa.validateNULL(open_date) is NULL ) AND (psa.validateNULL(close_date) is NULL) Then NULL
When (psa.validateNULL(open_date) is not NULL) and (psa.validateNULL(close_date) is not NULL) Then (CONVERT(DATETIME,close_date)) 
When (psa.validateNULL(open_date) is not NULL) and (psa.validateNULL(close_date) is NULL) Then (CONVERT(DATETIME,open_date)) 
When (psa.validateNULL(open_date) is NULL ) and (psa.validateNULL(close_date) is not NULL) Then (CONVERT(DATETIME,close_date))
END AS EffectiveFrom,

NULL EffectiveTo ,
''Y''  SCDActiveFlag,
CONVERT(NVARCHAR,'''+@SCDDefaultEndDate+''')  SCDEndDate,
record_source_id, row_id , date_added date_added 
from '+ @inpTableName+ ' 
where ( Row_status='+@PSARowStatus+' ) and date_added='+@CurDate+ '
 )store
join ser.TempIntStore_SiteRole_STG sr on sr.sourcekey = store.store_number  and 
sr.lovrecordsourceid = store.record_source_id 
left join (SELECT srt.siteroleid,srt.LOVSiteRoleStatusSetId,srt.LOVRecordSourceId,srt.scdversion,lovstatusId,EffectiveFrom,scdactiveflag from ser.SiteRoleStatus srt
							JOIN (SELECT siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId,max(scdversion) scdversion from ser.SiteRoleStatus 
							where lovrecordsourceId='+@recordSourceId + ' group by siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId)P 
							ON srt.SiteRoleId=P.SiteRoleId AND srt.LOVSiteRoleStatusSetId=P.LOVSiteRoleStatusSetId AND 
							srt.LOVRecordSourceId=P.LOVRecordSourceId and srt.scdversion=P.scdversion) SRStatus
							ON  SRStatus.SiteRoleId=sr.SiteRoleId AND SRStatus.LOVSiteRoleStatusSetId=store.LOVSiteRoleStatusSetId
AND SRStatus.LOVRecordSourceId=store.record_source_id 
Where not exists (
	SELECT *  FROM ser.SiteRoleStatus srr where 
	SRStatus.SiteRoleId=srr.SiteRoleId and SRStatus.LOVSiteRoleStatusSetId=srr.LOVSiteRoleStatusSetId  
	and SRStatus.scdversion=srr.scdversion 
	AND srr.lovrecordsourceId=store.record_source_id AND srr.EffectiveFrom=store.EffectiveFrom AND
    ISNULL(srr.EffectiveTo,'''')=ISNULL(store.EffectiveTo,'''') AND 	
	srr.LOVStatusId=store.StatusId AND srr.scdactiveflag=''Y'')  OR (sr.scdactiveflag=''N'') 
	OR (
	psa.validateNULL(open_date) is not null and psa.validateNULL(close_date) is not null
	AND 
	not exists (
	SELECT *  FROM ser.SiteRoleStatus srr where 
	SRStatus.SiteRoleId=srr.SiteRoleId and SRStatus.LOVSiteRoleStatusSetId=srr.LOVSiteRoleStatusSetId  
	and srr.scdversion=SRStatus.scdversion-1
	AND srr.lovrecordsourceId=store.record_source_id AND
	ISNULL(psa.validateNULL(srr.EffectiveFrom),'''')=ISNULL(CONVERT(DATETIME,store.open_date),'''') AND
	ISNULL(psa.validateNULL(srr.EffectiveTo),'''')=ISNULL(CONVERT(DATETIME,store.close_date),'''')
    AND srr.LOVStatusId='+@OpenStatus + ' AND SRStatus.scdactiveflag=''Y''
	  ) )

')



-- to insert an additional Openstatus(if not already present in siterole) and effFrom-opendate and effTo-closedate, version n  
exec('INSERT INTO ser.TempIntStore_SiteRoleStatus_STG
SELECT ExistsFlag, siteroleid, LOVSiteRoleStatusSetId,OpenStatusFlag,
Case When (psa.validateNULL(opendate) is not NULL) and (psa.validateNULL(closedate) is not NULL) AND OpenStatusFlag=1 Then '+@OpenStatus+'  
END AS StatusId,
CASE 
When (psa.validateNULL(opendate) is not NULL) and (psa.validateNULL(closedate) is not NULL) AND OpenStatusFlag=1 Then opendate 
END AS EffectiveFrom ,
closedate AS  EffectiveTo, opendate,closedate,lovrecordsourceid, ''N'', CONVERT(NVARCHAR,'''+@SCDEndDate+''') SCDEndDate, SCDVersion-1, PSARowkey, siteroleidactive 
from ser.TempIntStore_SiteRoleStatus_STG where (psa.validateNULL(opendate) is not NULL) and (psa.validateNULL(closedate) is not NULL)

')	

Print 'Updating SiteroleStatus ----------------'

exec('
UPDATE ser.SiteRoleStatus   set SCDEndDate= CONVERT(NVARCHAR,'''+@SCDEndDate+'''),
EffectiveTo=
Case When stg.LOVStatusId is null AND OpenStatusFlag =0 Then   STG.EffectiveTo Else STG.EffectiveFrom End ,
SCDActiveFlag=''N'' 
FROM ser.SiteRoleStatus SRG join
(SELECT srt.siteroleid,srt.LOVSiteRoleStatusSetId,srt.LOVRecordSourceId,srt.scdversion from ser.SiteRoleStatus srt
JOIN (SELECT siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId,max(scdversion) scdversion from ser.SiteRoleStatus 
where lovrecordsourceId='+@recordSourceId + ' group by siteroleid,LOVSiteRoleStatusSetId,LOVRecordSourceId)P 
ON srt.SiteRoleId=P.SiteRoleId AND srt.LOVSiteRoleStatusSetId=P.LOVSiteRoleStatusSetId AND 
srt.LOVRecordSourceId=P.LOVRecordSourceId and srt.scdversion=P.scdversion) tr  on
tr.SiteRoleId=srg.SiteRoleId and tr.LOVSiteRoleStatusSetId=srg.LOVSiteRoleStatusSetId and tr.lovrecordsourceId=srg.lovrecordsourceId
and tr.scdversion=srg.scdversion join 
ser.TempIntStore_SiteRoleStatus_STG STG 
ON  STG.SiteRoleId=SRG.SiteRoleId and STG.LOVSiteRoleStatusSetId=SRG.LOVSiteRoleStatusSetId and STG.lovrecordsourceId=SRG.lovrecordsourceId
Where STG.scdversion=tr.scdversion+1 and (STG.ExistsFlag=1 OR (stg.LOVStatusId is NULL OR STG.siteroleidactive=''N''))')



exec('
INSERT INTO [ser].[SiteRoleStatus]
           (SiteRoleId
           ,LOVSiteRoleStatusSetId
           ,LOVStatusId
           ,EffectiveFrom
           ,EffectiveTo
           ,LOVRecordSourceId
           ,SCDStartDate
           ,SCDEndDate
           ,SCDActiveFlag
           ,SCDVersion
           ,SCDLOVRecordSourceId
           ,ETLRunLogId
           ,PSARowKey)
SELECT SiteRoleId
           ,LOVSiteRoleStatusSetId
           ,LOVStatusId
           ,EffectiveFrom
           ,EffectiveTo
           ,LOVRecordSourceId
           ,CASE WHEN SCDVERSION=1  THEN CONVERT(NVARCHAR,'''+@scdDefaultStartDate+''')
			ELSE CONVERT(NVARCHAR,'''+@SCDStartDate+''') END SCDStartDate,			
			STG.SCDEndDate,					
			STG.SCDActiveFlag         ,
			SCDVERSION  SCDVERSION,
			LOVRecordSourceId   SCDLOVRecordSourceId
		   ,'+@serveETLRunLogId+'  ETLRunLogId
           ,PSARowKey FROM ser.TempIntStore_SiteRoleStatus_STG STG WHERE stg.LOVStatusId is NOT NULL AND STG.siteroleidactive=''Y'' ') 


PRINT 'Info: 12.1 PartyRoleSiteRoleRelationship Table Loading*******************************';  
exec('INSERT INTO [ser].[PartyRoleSiteRoleRelationship]
           ([PartyRoleId]
           ,[SiteRoleId]
           ,[LOVRelationshipTypeId]
           ,[EffectiveFrom]
           ,[EffectiveTo]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])

	SELECT STG.partyroleId, STG.siteroleId, STG.RelationshipTypeId, NULL, NULL, STG.lovrecordsourceId, 
	CONVERT(NVARCHAR,'''+@scdDefaultStartDate+'''),CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') ,''Y'' ,
	1,STG.lovrecordsourceId,'+@serveETLRunLogId+'  ETLRunLogId ,STG.PSARowKey
	 FROM ( SELECT '+@RelationshipTypeId2+' RelationshipTypeId,
					store.SourceKey,
					partyrole.partyroleId,
					siterole.siteroleId,	
					store.record_source_id lovrecordsourceId,
					store.row_id PSARowKey,
					siterole.SCDActiveFlag siteroleidactive
					FROM 
						(
						SELECT 
							store_number, 
							heritage_company SourceKey,
							record_source_id ,date_added,
							row_id FROM '+ @inpTableName+ ' WHERE  Row_status='+@PSARowStatus+' AND date_added='+@CurDate + '
						) store
				join ser.partyrole on partyrole.SourceKey=store.SourceKey 
					AND partyrole.lovrecordsourceId=store.record_source_id AND partyrole.SCDActiveFlag=''Y''
					AND partyrole.lovroleid='+@RetailerRoleId+' AND psa.validateNULL(store.SourceKey) IS NOT NULL 
				join ser.TempIntStore_SiteRole_STG siterole on siterole.SourceKey =store.store_number 
					AND siterole.lovrecordsourceId=store.record_source_id )STG
	LEFT JOIN ser.PartyRoleSiteRoleRelationship prsr 
			ON   prsr.siteroleid=STG.siteroleid AND prsr.partyroleId=STG.partyroleId 
				AND prsr.LOVRelationshipTypeId='+@RelationshipTypeId2+' 
				AND prsr.lovrecordsourceid=STG.lovrecordsourceId 
				WHERE (prsr.siteroleid IS NULL) AND (prsr.partyroleId IS NULL) AND (prsr.lovrecordsourceId IS NULL)
			')



PRINT 'Info: 12.2 PartyRoleSiteRoleRelationship Table Loading*******************************'; 

exec('INSERT INTO [ser].[PartyRoleSiteRoleRelationship]
           ([PartyRoleId]
           ,[SiteRoleId]
           ,[LOVRelationshipTypeId]
           ,[EffectiveFrom]
           ,[EffectiveTo]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])

		SELECT STG.partyroleId, STG.siteroleId, STG.RelationshipTypeId, NULL, NULL, STG.lovrecordsourceId, 
		CONVERT(NVARCHAR,'''+@scdDefaultStartDate+'''),CONVERT(NVARCHAR,'''+@scdDefaultEndDate+''') ,''Y'' ,
		1,STG.lovrecordsourceId,'+@serveETLRunLogId+'  ETLRunLogId ,STG.PSARowKey
		 FROM (SELECT '+@RelationshipTypeId1+' RelationshipTypeId, 
		siterole.siteroleId, 
		'+@partyroleid_const+' partyroleid,		
		store.record_source_id lovrecordsourceId,
		store.row_id PSARowKey FROM 
		(
		SELECT 
		store_number, 
		record_source_id , date_added,
		row_id FROM '+ @inpTableName+ ' WHERE  Row_status='+@PSARowStatus+'  AND date_added='+@CurDate + '
		) store
		join ser.TempIntStore_SiteRole_STG siterole on siterole.SourceKey =store.store_number 
		AND siterole.lovrecordsourceId=store.record_source_id )STG
		LEFT JOIN ser.PartyRoleSiteRoleRelationship prsr 
		ON   prsr.siteroleid=STG.siteroleid AND prsr.partyroleId='+@partyroleid_const + '
		AND prsr.LOVRelationshipTypeId='+@RelationshipTypeId1 + '
		AND prsr.lovrecordsourceid=STG.lovrecordsourceId 
		WHERE (prsr.siteroleid IS NULL) AND (prsr.partyroleId IS NULL) AND (prsr.lovrecordsourceId IS NULL)')


exec(' update [ser].[PartyRoleSiteRoleRelationship] set SCDActiveFlag=siterole.SCDActiveFlag
	FROM [ser].[PartyRoleSiteRoleRelationship] PRSR JOIN ser.TempIntStore_SiteRole_STG siterole ON
	PRSR.lovrecordsourceId=siterole.lovrecordsourceId and siterole.lovrecordsourceId= '+@recordSourceId + ' 
	and PRSR.siteroleid=siterole.siteroleid')
/******
Start of PSA Updation - Update the psa layer table with row_status AS 'Loaded to Serve' once after Successful Migration
***/
 

 
					exec('
                        UPDATE '+ @tableName+ '  SET Row_Status='+@serRowStatus + '
                        FROM '+ @tableName+ '  store 
                        INNER JOIN
                        ser.SiteRole sr 
                        ON ISNULL( NULLIF((Substring(store.store_number, Patindex(''%[^0]%'', store.store_number + '' ''), Len(store.store_number)) ),''''),0) =sr.sourcekey
                        AND  store.record_source_id=sr.LovRecordSourceID
                        INNER JOIN
                        ((SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRole WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID='+@recordSourceId+')     
                        UNION ALL (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleStatus  WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID='+@recordSourceId+')                                     
                        UNION ALL  (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleGroup WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID='+@recordSourceId+')                                     
                        UNION ALL  (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleTerritory  WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID='+@recordSourceId+')
                        UNION ALL  (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleIndicator WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID='+@recordSourceId+')
                        UNION ALL  (SELECT distinct SiteRoleId ,SCDLovRecordSourceID ,psarowkey FROM ser.SiteRoleProperty WHERE SCDACTiveFlag=''Y'' AND LOVRecordsourceID='+@recordSourceId+')
                            ) temp
                                ON  temp.scdLovRecordSourceID in ('+@recordSourceId+')
                                AND temp.SiteRoleId=sr.SiteRoleId                            
                                AND temp.psarowkey=store.row_id
                        WHERE store.Row_Status='+@PSARowStatus + ' 
                              AND store.date_added='+@CurDate+ ' ');

 
 if (@countryCode in ('CL','MX','TH'))
BEGIN

                       exec('UPDATE '+ @tableName+ ' SET Row_Status='+@serRowStatus + '
                        FROM '+ @tableName+ '  store 
                        INNER JOIN
                        ser.SiteRole sr 
                            ON store.record_source_id=LovRecordSourceID
                            AND  ISNULL( NULLIF((Substring(store.store_number, Patindex(''%[^0]%'', store.store_number + '' ''), Len(store.store_number)) ),''''),0) =sr.sourcekey
                        WHERE store.Row_Status='+@PSARowStatus + '
                            AND store.date_added='+@CurDate + '
                            AND ((psa.validateNULL(store.store_name) IS NULL AND psa.validateNULL( store.address_line1 ) IS NULL 
							AND psa.validateNULL(store.address_line2) IS NULL AND psa.validateNULL( store.address_line3 ) IS NULL
							AND psa.validateNULL(store.address_line4) IS NULL AND psa.validateNULL( store.postal_code ) IS NULL) 
                             
                             OR psa.validateNULL(store.area_code) IS NULL  OR  psa.validateNULL(store.district_code) IS NULL
                             OR psa.validateNULL(store.region_code) IS NULL OR psa.validateNULL(store.store_format) IS NULL
                             OR    psa.validateNULL(store.store_loc) IS NULL OR psa.validateNULL(store.store_ndsa) IS NULL
							 OR psa.validateNULL(store.latitude) IS NULL
                             OR psa.validateNULL(store.longitude) IS NULL OR psa.validateNULL(store.store_size) IS NULL
                             )');

 END
if (@countryCode in ('NO'))
BEGIN
exec('UPDATE '+ @tableName+ ' SET Row_Status='+@serRowStatus + '
                        FROM '+ @tableName+ '  store 
                        INNER JOIN
                        ser.SiteRole sr 
                            ON store.record_source_id=LovRecordSourceID
                            AND  ISNULL( NULLIF((Substring(store.store_number, Patindex(''%[^0]%'', store.store_number + '' ''), Len(store.store_number)) ),''''),0) =sr.sourcekey
                        WHERE store.Row_Status='+@PSARowStatus + ' 
                            AND store.date_added='+@CurDate + '
                            AND ((psa.validateNULL(store.store_name) IS NULL AND psa.validateNULL( store.address_line1 ) IS NULL 
							AND psa.validateNULL(store.address_line2) IS NULL AND psa.validateNULL( store.address_line3 ) IS NULL
							AND psa.validateNULL(store.address_line4) IS NULL AND psa.validateNULL( store.postal_code ) IS NULL) 
                             
                             OR psa.validateNULL(store.area_code) IS NULL  OR  psa.validateNULL(store.district_code) IS NULL
                             OR psa.validateNULL(store.store_format) IS NULL
                             OR    psa.validateNULL(store.store_loc) IS NULL OR psa.validateNULL(store.store_ndsa) IS NULL
							 OR psa.validateNULL(store.latitude) IS NULL
                             OR psa.validateNULL(store.longitude) IS NULL OR psa.validateNULL(store.store_size) IS NULL
                             )');

END

                        exec('UPDATE '+ @tableName+ ' SET row_status='+@PSARowStatus_NotMigrated + '                       
                        WHERE row_status='+@PSARowStatus + '
                              AND date_added='+ @CurDate + ' ') ; 
							  
/***
END of PSA Updation
**/							  

SET @COUNTER = @COUNTER + 1	;
END




COMMIT TRANSACTION;
			
 END TRY
 BEGIN CATCH     
	THROW
	ROLLBACK TRANSACTION;
 END CATCH
 
	 
	 
	 
IF OBJECT_ID('ser.TempIntStore_SiteRole_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRole_STG
END

IF OBJECT_ID('ser.TempIntStore_SiteRoleGroup_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRoleGroup_STG
END

IF OBJECT_ID('ser.TmpIntStore_SiteRoleProp_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TmpIntStore_SiteRoleProp_STG
END
IF OBJECT_ID('ser.TmpIntStore_SiteRoleTerritory_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TmpIntStore_SiteRoleTerritory_STG
END

IF OBJECT_ID('ser.TempIntStore_SiteRoleStatus_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRoleStatus_STG
END

IF OBJECT_ID('ser.TempIncr_DateCountStore') IS NOT NULL
BEGIN

drop table ser.TempIncr_DateCountStore
END

IF OBJECT_ID('psa.TempIntCrpStore_STG') IS NOT NULL
BEGIN
	DROP TABLE psa.TempIntCrpStore_STG
END

END
GO
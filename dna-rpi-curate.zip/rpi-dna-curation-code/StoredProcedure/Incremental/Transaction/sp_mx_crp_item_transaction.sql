/****** Object:  StoredProcedure [psa].[sp_mx_crp_item_transaction]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
************************************************************************************************************
Procedure Name							: sp_mx_crp_item_transaction
Purpose									: Load Incremental data from mexico transaction source table(rawmx.crp_item_transaction) into Serve Layer Table
Domain									: Transaction
ServeLayer Target Tables	 			: Till, SiteRole, Product, ProductIdentifier, Deal, Transaction, TransactionLineItem, TransactionLineItemIndicator, TransactionLineItemMeasure, 
										  Measure, LoyaltyAccount, TransactionLoyaltyAccount
RecordSourceID  for mexico Transaction	: 12004

**************************************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  12004 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
*/

IF OBJECT_ID('psa.sp_mx_crp_item_transaction') IS NOT NULL
BEGIN
	DROP PROC psa.sp_mx_crp_item_transaction
END
GO

CREATE PROC [psa].[sp_mx_crp_item_transaction] @serveETLRunLogID VARCHAR(MAX), @tablename VARCHAR(MAX), @psaEntityId VARCHAR(MAX) AS

	DECLARE	@mx_lovRecordSourceID		 BIGINT;
	DECLARE	@mx_lovPSAStatus    		 BIGINT;
	DECLARE	@mx_scdLovRecordSourceID	 BIGINT;
	DECLARE	@max_tillID				 	 BIGINT;
	DECLARE	@max_siteID 				 BIGINT;
	DECLARE	@max_siteRoleID				 BIGINT;
	DECLARE	@siteId 					 BIGINT;
	DECLARE	@mx_lovRoleId				 BIGINT;
	DECLARE	@max_transactionID			 BIGINT;
	DECLARE	@transactionTypeId 			 BIGINT;
	DECLARE	@mx_lovSourceKeyTypeId 		 BIGINT;
	DECLARE	@max_productID 				 BIGINT;
	DECLARE	@upc_identifierID 			 BIGINT;
	DECLARE	@max_dealID 				 BIGINT;
	DECLARE	@max_transactionLineItemID   BIGINT;
	DECLARE	@measureTypeID				 BIGINT;
	DECLARE	@units_measureID			 BIGINT;
	DECLARE	@tisp_measureID	    		 BIGINT;
	DECLARE	@tesp_measureID 			 BIGINT;
	DECLARE	@eposprofit_measureID 		 BIGINT;
	DECLARE	@discountappl_measureID 	 BIGINT;
	DECLARE	@max_transactionLineItemMeasureID 	BIGINT;
	DECLARE	@prescription_indicatorID	 BIGINT;
	DECLARE	@max_loyaltyAccountID   	 BIGINT;
	DECLARE @units_lovuomID				 BIGINT;
	DECLARE @others_lovuomID			 BIGINT;
	DECLARE	@max_transactionGroupID   	 BIGINT;
	DECLARE	@salestypeRefLOVSetID   	 BIGINT;
--	DECLARE @max_ruleentityinstanceid 	 BIGINT;
	DECLARE @ruleId 					 BIGINT;
	DECLARE @attributeid				 BIGINT;
	DECLARE @feed_entityid 				 BIGINT;

BEGIN		

	SET		@mx_lovRecordSourceID	 = 12004;
	SET		@mx_scdLovRecordSourceID = 12004;
	SET		@mx_lovPSAStatus    	 = 26001;
	SET @feed_entityid = (select sourceentityid from psa.[MappingEntity] me inner join psa.[Entity] e on me.sourceentityid = e.EntityID where me.[TargetEntityID] = @psaEntityId and e.SchemaName like '%feed%');
	
	/* Creation of temporary table to store records wit rowstatus 26001 from PSA Source table */
	IF OBJECT_ID('tempdb..#mx_crp_item_transaction_tmp') IS NOT NULL
	BEGIN
		DROP TABLE #mx_crp_item_transaction_tmp
	END
	
	SELECT * INTO #mx_crp_item_transaction_tmp
	FROM (SELECT * FROM psa.mx_crp_item_transaction WHERE row_status = @mx_lovPSAStatus 
	--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
	)A;


	RAISERROR ('Completed insertion of TEMP MEXICO PSA table', 0, 1) WITH NOWAIT;
	
	
	/* Creation of temporary table to store records to be inserted in productidentifier target table */
	IF OBJECT_ID('tempdb..#ProductIdentifier_temp') IS NOT NULL
	BEGIN
		DROP TABLE #ProductIdentifier_temp
	END
	
	SELECT * INTO #ProductIdentifier_temp
	FROM (SELECT * FROM ser.productidentifier WHERE etlrunlogid = -1
	)A;


	RAISERROR ('Completed creation of productidentifier temp table', 0, 1) WITH NOWAIT;
	
	
	BEGIN TRY
	BEGIN TRANSACTION;
	
	
UPDATE #mx_crp_item_transaction_tmp SET transaction_time = '00:00'
WHERE transaction_time LIKE '%[A-Za-z]%' OR transaction_time IS NULL OR TRIM(transaction_time) = '';


RAISERROR ('Completed updation of transaction_time in TEMP MEXICO PSA table', 0, 1) WITH NOWAIT;

	
/* Raise DQ warning for the insertion of new 000000 time */

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Time Check' AND RuleCode = 'TC');
SET @attributeid = (SELECT AttributeId FROM psa.Attribute WHERE attributename = 'transaction_time' AND entityid = @feed_entityid);

INSERT INTO psa.RuleEntityInstance(
--	RuleEntityInstanceID	,
	RuleID					,
	EntityID				,
	AttributeID				,
	RuleDetail				,
	ETLRunLogID				,
	SourceEntityID			,
	SourceAttributeID		,
	PSARowKey				,
	DTCreated				,
	UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY row_id) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--Transaction_Time--Record value changed to 000000 for Transaction_time due to invalid format' RuleDetail,
@serveETLRunLogID ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM psa.mx_crp_item_transaction 
WHERE (transaction_time LIKE '%[A-Za-z]%' OR transaction_time IS NULL OR TRIM(transaction_time) = '') AND row_status = @mx_lovPSAStatus)Z

UNION

SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY row_id) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--Transaction_Time--Record value changed to 000000 for Transaction_time due to invalid format' RuleDetail,
@serveETLRunLogID ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM #mx_crp_item_transaction_tmp 
WHERE (CAST(SUBSTRING(transaction_time,1,2) AS INT) > 23 OR CAST(SUBSTRING(transaction_time,4,2) AS INT) > 59) AND row_status = @mx_lovPSAStatus)Z
;


RAISERROR ('Completed insertion in RuleEntityInstance table for invalid time', 0, 1) WITH NOWAIT;


UPDATE #mx_crp_item_transaction_tmp SET transaction_time = '00:00'
WHERE CAST(SUBSTRING(transaction_time,1,2) AS INT) > 23 OR CAST(SUBSTRING(transaction_time,4,2) AS INT) > 59;


RAISERROR ('Completed updation of transaction_time in TEMP MEXICO PSA table', 0, 1) WITH NOWAIT;


	SELECT  @max_tillID = COALESCE(MAX(TillId),0) FROM ser.Till;
    SELECT  @max_siteID = COALESCE(MAX(SiteId),0) FROM ser.Site;
    SELECT  @max_siteRoleID = COALESCE(MAX(SiteRoleId),0) FROM ser.SiteRole;
    SELECT  @max_transactionID = COALESCE(MAX(TransactionId),0) FROM ser.[Transaction];
    SELECT  @max_productID = COALESCE(MAX(ProductId),0) FROM ser.Product;
    SELECT  @max_dealID = COALESCE(MAX(DealId),0) FROM ser.Deal;
    SELECT  @max_transactionLineItemID = COALESCE(MAX(TransactionLineItemId),0) FROM ser.TransactionLineItem;
    SELECT  @max_transactionLineItemMeasureID = COALESCE(MAX(TransactionLineItemMeasureId),0) FROM ser.TransactionLineItemMeasure;
    SELECT  @max_loyaltyAccountID = COALESCE(MAX(LoyaltyAccountId),0) FROM ser.LoyaltyAccount;
	SELECT 	@max_transactionGroupID = COALESCE(MAX(TransactionGroupId),0) FROM ser.TransactionGroup;

/* Table Name  :  Till */

INSERT INTO ser.Till(
	TillId				,
	SourceKey			,
	LOVRecordSourceId	,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId			,
	PSARowKey
)

SELECT 
@max_tillID+ROW_NUMBER() OVER(ORDER BY till_id) TillId, 
till_id SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId,
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
FROM
(SELECT till_id, MIN(CONCAT(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid, record_source_id FROM #mx_crp_item_transaction_tmp mxitemtrans 
WHERE till_id IS NOT NULL AND TRIM(till_id) != '' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
GROUP BY till_id,record_source_id) A
LEFT OUTER JOIN ser.Till till 
ON A.till_id = till.sourceKey
AND A.record_source_id = till.LOVRecordSourceID
WHERE till.sourceKey IS NULL
;


RAISERROR ('Completed insertion of MEXICO source data to TILL table', 0, 1) WITH NOWAIT


/* Table Name  :  SiteRole */

SET @mx_lovRoleId = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Role' AND lovkey = 'Store');
SET @siteId = (SELECT siteId siteId FROM ser.Site WHERE sourceKey = 0 AND LOVRecordSourceID = 12012 AND SCDActiveFlag = 'Y'
AND lovSiteTypeId =(SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Site Type' AND lovkey = '0'));

INSERT INTO ser.SiteRole(
	SiteRoleId			,
	SiteId				,
	LOVRoleId			,
	SourceKey			,
	SiteRoleName		,
	SiteRoleShortName	,
	LOVRecordSourceId	,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId			,
	PSARowKey
)  

SELECT 
@max_siteRoleID+ROW_NUMBER() OVER(ORDER BY store_number) SiteRoleId, 
@siteId siteId,
@mx_lovRoleId LOVRoleId, 
store_number SourceKey, 
NULL SiteRoleName, 
NULL SiteRoleShortName, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
FROM
(SELECT store_number, MIN(CONCAT(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid,record_source_id FROM #mx_crp_item_transaction_tmp mxitemtrans 
WHERE store_number IS NOT NULL AND TRIM(store_number) != '' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
GROUP BY store_number,record_source_id) A
LEFT OUTER JOIN ser.SiteRole siterole 
ON A.store_number = siterole.sourceKey
AND A.record_source_id = siterole.LOVRecordSourceID
WHERE siterole.sourceKey IS NULL

UNION

/* Below scenario to handle Soft Delete of siterole id/store number */
SELECT 
siterole.SiteRoleId SiteRoleId, 
@siteId siteId,
@mx_lovRoleId LOVRoleId, 
store_number SourceKey, 
NULL SiteRoleName, 
NULL SiteRoleShortName, 
@mx_lovRecordSourceID LOVRecordSourceId, 
CURRENT_TIMESTAMP SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
version + 1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
FROM
(SELECT store_number, MIN(CONCAT(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid FROM #mx_crp_item_transaction_tmp mxitemtrans 
WHERE store_number IS NOT NULL AND TRIM(store_number) != '' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
GROUP BY store_number) A
JOIN (SELECT sourcekey, siteroleid, version FROM
(SELECT sourcekey, siteroleid, SCDVersion version, SCDActiveFlag, RANK() OVER(PARTITION BY sourcekey,lovrecordsourceid ORDER BY sourcekey,lovrecordsourceid,SCDVersion desc) row_num 
FROM ser.SiteRole WHERE lovrecordsourceid = @mx_lovRecordSourceID)A WHERE A.row_num = 1 AND A.SCDActiveFlag = 'N') siterole
ON A.store_number = siterole.sourcekey
;


RAISERROR ('Completed insertion of MEXICO source data to SITEROLE table', 0, 1) WITH NOWAIT


/* Raise DQ warning for the insertion of new siterole id */

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Skeleton Record Creation' AND RuleCode = 'SRC');
SET @attributeid = (SELECT AttributeId FROM psa.Attribute WHERE attributename = 'store_number' AND entityid = @feed_entityid);

INSERT INTO psa.RuleEntityInstance(
--	RuleEntityInstanceID	,
	RuleID					,
	EntityID				,
	AttributeID				,
	RuleDetail				,
	ETLRunLogID				,
	SourceEntityID			,
	SourceAttributeID		,
	PSARowKey				,
	DTCreated				,
	UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY sourcekey) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--SiteRoleId--Record created for Store number due to non existence of SiteRoleId' RuleDetail,
@serveETLRunLogID ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT sourcekey,psarowkey FROM ser.SiteRole WHERE LOVRecordSourceId = @mx_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID AND SCDActiveFlag = 'Y') siterole
JOIN #mx_crp_item_transaction_tmp mxitemtrans
ON mxitemtrans.store_number = siterole.sourcekey
AND mxitemtrans.row_id = siterole.psarowkey
;


RAISERROR ('Completed insertion in RuleEntityInstance table for SiteRole', 0, 1) WITH NOWAIT;


/* Table Name  :  Transaction */

SET @transactionTypeId = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Transaction Type' AND lovkey = 'RETAIL');

INSERT INTO ser.[Transaction](
	TransactionId			,
	SourceKey				,
	LOVTransactionTypeId	,
	SiteRoleId				,
	TransactionDatetime		,
	TillId					,
	TillTransactionNumber	,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  
    
SELECT 
@max_transactionID+ROW_NUMBER() OVER(ORDER BY transaction_key) TransactionId, 
transaction_key SourceKey, 
@transactionTypeId LOVTransactionTypeId, 
siterole.siteroleid SiteRoleId, 
CONVERT(datetime, CONCAT(SUBSTRING(transaction_date,1,4),'-',SUBSTRING(transaction_date,5,2),'-',SUBSTRING(transaction_date,7,2),' ',transaction_time,':00'),120) TransactionDatetime,
till.tillId TillId, 
NULL TillTransactionNumber, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate,  
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
FROM
(SELECT transaction_key, store_number, till_id, transaction_date, transaction_time,
MIN(CONCAT(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid, record_source_id
FROM #mx_crp_item_transaction_tmp mxitemtrans WHERE transaction_date IS NOT NULL AND TRIM(transaction_date) != '' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
GROUP BY transaction_key, store_number,till_id, transaction_date,transaction_time,record_source_id) A
LEFT OUTER JOIN (SELECT * FROM ser.Till WHERE SCDActiveFlag = 'Y' AND LOVRecordSourceID = @mx_lovRecordSourceID) till
ON till.sourcekey = A.till_id
AND till.LOVRecordSourceId = @mx_lovRecordSourceID
JOIN (SELECT siteroleid, sourceKey, LOVRecordSourceID FROM ser.SiteRole WHERE SCDActiveFlag = 'Y' AND siteroleid IS NOT NULL AND LOVRecordSourceID = @mx_lovRecordSourceID)siterole
ON siterole.sourcekey = A.store_number
AND siterole.LOVRecordSourceID = @mx_lovRecordSourceID
LEFT OUTER JOIN ser.[Transaction] trans
ON A.transaction_key = trans.sourceKey
AND CONVERT(datetime, CONCAT(SUBSTRING(A.transaction_date,1,4),'-',SUBSTRING(A.transaction_date,5,2),'-',SUBSTRING(A.transaction_date,7,2),' ',A.transaction_time,':00'),120) = trans.transactiondatetime
AND A.record_source_id = trans.LOVRecordSourceID
WHERE trans.sourceKey IS NULL
;


RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION table', 0, 1) WITH NOWAIT


/* Table Name  :  Product */

SET @mx_lovSourceKeyTypeId = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Source Key Type' AND lovkey = 'Mexico Item Code');

INSERT INTO ser.Product(
	ProductId			,
	SourceKey			,
	LOVSourceKeyTypeId	,
	ProductName			,
	ProductDescription	,
	LOVBrandId 			,
	LOVSubBrandId 		,
--	LOVCostCentreId 	,
	LOVRecordSourceId	,
	ParentProductId		,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId			,
	PSARowKey
)  

SELECT 
@max_productID+ROW_NUMBER() OVER(ORDER BY item_code) ProductId, 
item_code SourceKey,
@mx_lovSourceKeyTypeId LOVSourceKeyTypeId, 
NULL ProductName, 
NULL ProductDescription, 
NULL LOVBrandId,
NULL LOVSubBrandId,
--NULL LOVCostCentreId,
@mx_lovRecordSourceID LOVRecordSourceId, 
NULL ParentProductId,
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
FROM
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') item_code, MIN(CONCAT(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid, record_source_id FROM #mx_crp_item_transaction_tmp mxitemtrans 
WHERE item_code IS NOT NULL AND TRIM(item_code) != '' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'),record_source_id)A
LEFT OUTER JOIN ser.Product product
ON A.item_code = product.sourceKey
AND A.record_source_id = product.LOVRecordSourceID
WHERE product.sourceKey IS NULL

UNION

/* Below scenario to handle Soft Delete of product id/item code */
SELECT 
product.ProductId ProductId, 
item_code SourceKey,
@mx_lovSourceKeyTypeId LOVSourceKeyTypeId, 
NULL ProductName, 
NULL ProductDescription, 
NULL LOVBrandId,
NULL LOVSubBrandId,
@mx_lovRecordSourceID LOVRecordSourceId, 
NULL ParentProductId,
CURRENT_TIMESTAMP SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
version + 1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
FROM
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') item_code, MIN(CONCAT(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid FROM #mx_crp_item_transaction_tmp mxitemtrans 
WHERE item_code IS NOT NULL AND TRIM(item_code) != '' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'))A
JOIN (SELECT sourcekey, productid, version FROM
(SELECT sourcekey, productid, SCDVersion version, SCDActiveFlag, RANK() OVER(PARTITION BY sourcekey,lovrecordsourceid ORDER BY sourcekey,lovrecordsourceid,SCDVersion desc) row_num 
FROM ser.Product WHERE lovrecordsourceid = @mx_lovRecordSourceID)A WHERE A.row_num = 1 AND A.SCDActiveFlag = 'N') product
ON A.item_code = product.sourcekey
;


RAISERROR ('Completed insertion of MEXICO source data to PRODUCT table', 0, 1) WITH NOWAIT


/* Raise DQ warning for the insertion of new product id */

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Skeleton Record Creation' AND RuleCode = 'SRC');
SET @attributeid = (SELECT AttributeId FROM psa.Attribute WHERE attributename = 'item_code' AND entityid = @feed_entityid);

INSERT INTO psa.RuleEntityInstance(
--	RuleEntityInstanceID	,
	RuleID					,
	EntityID				,
	AttributeID				,
	RuleDetail				,
	ETLRunLogID				,
	SourceEntityID			,
	SourceAttributeID		,
	PSARowKey				,
	DTCreated				,
	UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY sourcekey) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--ProductId--Record created for Item code due to non existence of ProductId' RuleDetail,
@serveETLRunLogID ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT sourcekey,psarowkey FROM ser.Product WHERE LOVRecordSourceId = @mx_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID AND SCDActiveFlag = 'Y') product
JOIN #mx_crp_item_transaction_tmp mxitemtrans
ON REPLACE(LTRIM(REPLACE(mxitemtrans.item_code,'0',' ')),' ','0') = product.sourcekey
AND mxitemtrans.row_id = product.psarowkey
;


RAISERROR ('Completed insertion in RuleEntityInstance table for product', 0, 1) WITH NOWAIT;


/* Table Name  :  Product Identifier */

SET @upc_identifierID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Identifier' AND lovkey = 'UPC');

/*INSERT INTO ser.ProductIdentifier(
	ProductId			,
	LOVIdentifierId		,
	Value				,
	LOVRecordSourceId	,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId 		,
	PSARowKey
)

SELECT 
A.ProductId ProductId, 
@upc_identifierID LOVIdentifierId,
upc Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
FROM
(SELECT sourcekey, ProductId ProductId, mxitemtrans.upc as upc, MIN(CONCAT(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid, record_source_id FROM ser.Product product 
JOIN #mx_crp_item_transaction_tmp mxitemtrans 
ON product.sourcekey = REPLACE(LTRIM(REPLACE(mxitemtrans.item_code,'0',' ')),' ','0') 
AND product.SCDActiveFlag = 'Y'
AND product.LOVSourceKeyTypeId = @mx_lovSourceKeyTypeId
WHERE product.LOVRecordSourceId=@mx_lovRecordSourceID AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
GROUP BY sourcekey, ProductId, upc,record_source_id) A
LEFT OUTER JOIN ser.ProductIdentifier prodidentifier
ON A.productId = prodidentifier.productId
AND COALESCE(A.upc,'DUMMY_UPC_VALUE') = COALESCE(prodidentifier.value,'DUMMY_UPC_VALUE')
AND A.record_source_id = prodidentifier.LOVRecordSourceID
WHERE prodidentifier.ProductId IS NULL
;*/

DECLARE @datetime_val nvarchar(100);
SET @datetime_val = CURRENT_TIMESTAMP;

INSERT INTO #ProductIdentifier_temp
SELECT 
A.ProductId ProductId, 
@upc_identifierID LOVIdentifierId,
upc Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
date_added SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
rowid PSARowKey 
FROM
(SELECT sourcekey, ProductId ProductId, mxitemtrans.upc as upc, MIN(row_id) rowid, record_source_id, date_added FROM ser.Product product 
JOIN #mx_crp_item_transaction_tmp mxitemtrans 
ON product.sourcekey = REPLACE(LTRIM(REPLACE(mxitemtrans.item_code,'0',' ')),' ','0') 
AND product.SCDActiveFlag = 'Y'
AND product.LOVSourceKeyTypeId = @mx_lovSourceKeyTypeId
WHERE product.LOVRecordSourceId=@mx_lovRecordSourceID AND row_status = @mx_lovPSAStatus AND upc IS NOT NULL AND TRIM(upc) != '' 
GROUP BY sourcekey, ProductId, upc,record_source_id,date_added) A
LEFT OUTER JOIN ser.ProductIdentifier prodidentifier
ON A.productId = prodidentifier.productId
AND COALESCE(A.upc,'DUMMY_UPC_VALUE') = COALESCE(prodidentifier.value,'DUMMY_UPC_VALUE')
AND A.record_source_id = prodidentifier.LOVRecordSourceID
AND prodidentifier.SCDActiveFlag = 'Y'
WHERE prodidentifier.ProductId IS NULL
;


--update 1: This update statement updates the SCD Active Flag, SCD Start Date, SCD End date and SCD Version
    UPDATE #ProductIdentifier_temp
    SET scdactiveflag = A.scdactiveflag,
        SCDStartDate = @datetime_val,
        SCDEndDate = A.SCDEndDate,
        SCDVersion = A.SCDVersion FROM #ProductIdentifier_temp P JOIN
    (SELECT 
    LEAD('N',1,'Y') OVER(PARTITION BY i.productId, i.LOVIdentifierId, i.LOVRecordSourceID ORDER BY SCDStartDate) scdactiveflag,
    LEAD(@datetime_val,1,'9999-12-31') OVER(PARTITION BY i.productId, i.LOVIdentifierId, i.LOVRecordSourceID ORDER BY SCDStartDate) SCDEndDate ,
    ROW_NUMBER() OVER (PARTITION BY i.productId, i.LOVIdentifierId, i.LOVRecordSourceID  ORDER BY SCDStartDate) SCDVersion,
    psarowkey FROM #ProductIdentifier_temp i
    )A
    ON P.psarowkey = A.psarowkey;
    
RAISERROR ('update 1: This update statement updates the SCD Active Flag, SCD Start Date, SCD End date and SCD Version', 0, 1) WITH NOWAIT
    
	
--update 2: This update statement updates the SCD version of the temporary table (temporary table version = mainn table max version for that key + temporary table version)
    UPDATE #ProductIdentifier_temp
    SET SCDVersion = SCDVersion + version
    FROM #ProductIdentifier_temp t
    JOIN 
    (SELECT B.productId, B.SCDVersion version FROM 
    (SELECT ProductId, SCDVersion, RANK() OVER(PARTITION BY productId, LOVIdentifierId, LOVRecordSourceID ORDER BY SCDVersion DESC) row_num FROM 
    ser.productidentifier WHERE lovrecordsourceid = @mx_lovRecordSourceID) B WHERE B.row_num = 1 ) s
    ON t.productId = s.productId ;
    
RAISERROR ('update 2: This update statement updates the SCD version of the temporary table', 0, 1) WITH NOWAIT


--update 3: This update statement updates the SCD Start Date to 1900-01-01 wherever the SCDActiveFlag = 'Y' and SCDVersion = 1
    UPDATE #ProductIdentifier_temp
    SET SCDStartDate = '1900-01-01'
    WHERE SCDVersion = 1 ;
        
RAISERROR ('update 3: This update statement updates the SCD Start Date to 1900-01-01 wherever the SCDActiveFlag = Y and SCDVersion = 1', 0, 1) WITH NOWAIT
 

--update 4: This update statement updates the SCD Active Flag and SCD End Date of the main table
--Set Active Flag = N and SCD End date = current timestamp wherever the product id matches and the flag is 'Y' in both the tables
    UPDATE ser.productidentifier
    SET SCDActiveFlag = 'N', SCDEndDate = @datetime_val
    FROM ser.productidentifier main
    JOIN (SELECT productId FROM #ProductIdentifier_temp WHERE SCDActiveFlag = 'Y') tmp
    ON tmp.productId = main.productId
    AND main.SCDActiveFlag = 'Y';
    
RAISERROR ('update 4: This update statement updates the SCD Active Flag and SCD End Date of the main table', 0, 1) WITH NOWAIT


--insert the records of the temporary table into the main table
    
INSERT INTO ser.productidentifier SELECT * FROM #ProductIdentifier_temp ; 

RAISERROR ('final insert: This inserts the records of the temporary table into the main table', 0, 1) WITH NOWAIT
		
RAISERROR ('Completed insertion of MEXICO source data to PRODUCT IDENTIFIER table', 0, 1) WITH NOWAIT


/* Table Name  :  Deal */

INSERT INTO ser.Deal(
	DealId				,
	SourceKey			,
	LOVRecordSourceId	,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId			,
	PSARowKey
)

SELECT 
@max_dealID+ROW_NUMBER() OVER(ORDER BY deal_id) DealId, 
deal_id SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId,
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
FROM
(SELECT deal_id, MIN(CONCAT(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid,record_source_id FROM #mx_crp_item_transaction_tmp mxitemtrans 
WHERE deal_id IS NOT NULL AND TRIM(deal_id) != '' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
GROUP BY deal_id,record_source_id) A
LEFT OUTER JOIN ser.Deal deal
ON A.deal_id = deal.sourceKey
AND A.record_source_id = deal.LOVRecordSourceID
WHERE deal.sourceKey IS NULL
;


RAISERROR ('Completed insertion of MEXICO source data to DEAL table', 0, 1) WITH NOWAIT


/* Table Name  :  TransactionLineItem */

INSERT INTO ser.TransactionLineItem(
	TransactionLineItemId	,
	TransactionId			,
	ProductId				,
	LOVLineItemTypeId		,
	DealId					,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

SELECT 
@max_transactionLineItemID+ROW_NUMBER() OVER(ORDER BY A.TransactionId) TransactionLineItemId, 
A.TransactionId TransactionId,
product.ProductId ProductId, 
--ro.LOVId LOVLineItemTypeId, 
NULL LOVLineItemTypeId, 
deal.dealid DealId, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(date_added,1,4),'-',SUBSTRING(date_added,5,2),'-',SUBSTRING(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
row_id PSARowKey 
FROM
(SELECT sourcekey sourcekey,TransactionId TransactionId, LOVRecordSourceId LOVRecordSourceId, item_code, deal_id, sales_type,transaction_date,transaction_time,transactiondatetime, date_added,row_id,record_source_id FROM ser.[Transaction] trans 
JOIN (SELECT transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, ISNULL(date_added,'19000101') date_added,row_id row_id,record_source_id record_source_id,transaction_date,transaction_time
FROM #mx_crp_item_transaction_tmp WHERE row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans ON trans.sourcekey = mxitemtrans.transaction_key AND trans.SCDActiveFlag = 'Y'
AND CONVERT(datetime, CONCAT(SUBSTRING(mxitemtrans.transaction_date,1,4),'-',SUBSTRING(mxitemtrans.transaction_date,5,2),'-',SUBSTRING(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
WHERE trans.TransactionId IS NOT NULL AND trans.LOVRecordSourceId=@mx_lovRecordSourceID) A
LEFT OUTER JOIN (SELECT * FROM ser.Deal WHERE SCDActiveFlag = 'Y' AND LOVRecordSourceID = @mx_lovRecordSourceID) deal
ON deal.sourcekey = A.deal_id
AND deal.LOVRecordSourceId = @mx_lovRecordSourceID
JOIN (SELECT ProductId, sourcekey FROM ser.Product
WHERE SCDActiveFlag = 'Y' AND ProductId IS NOT NULL AND LOVRecordSourceId = @mx_lovRecordSourceID AND lovsourceKeyTypeId = @mx_lovSourceKeyTypeId) product
ON product.sourceKey = REPLACE(LTRIM(REPLACE(A.item_code,'0',' ')),' ','0')
--LEFT OUTER JOIN ser.RefLOVSetInfo ro
--ON ro.LOVSetName = 'sales_type'
--AND ro.LOVKey=A.sales_type
--AND A.LOVRecordSourceId =ro.LOVRecordSourceId
;


RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION LINE ITEM table', 0, 1) WITH NOWAIT


/* Table Name  :  TransactionLineItemMeasure */

SET @measureTypeID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Measure Type' AND lovkey = 'RETAIL_TRANS_AGG');
SET @units_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'units' AND LOVRecordSourceId = @mx_lovRecordSourceID);
SET @tisp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tisp' AND LOVRecordSourceId = @mx_lovRecordSourceID);
SET @tesp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tesp' AND LOVRecordSourceId = @mx_lovRecordSourceID);
SET @eposprofit_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'epos_profit' AND LOVRecordSourceId = @mx_lovRecordSourceID);
SET @discountappl_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'discount_applied' AND LOVRecordSourceId = @mx_lovRecordSourceID);
SET @units_lovuomID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Unit Of Measure' AND lovkey = 'Unit');
SET @others_lovuomID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Currency ISO 4217' AND lovkey = 'MXN' AND LOVRecordSourceID = 12012);

INSERT INTO ser.TransactionLineItemMeasure(
	TransactionLineItemMeasureId	,
	TransactionLineItemId 			,
	MeasureId  						,
	Value							,
	LOVUOMId						,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

SELECT @max_transactionLineItemMeasureID+DENSE_RANK() OVER(ORDER BY TransactionLineItemId, MeasureId) TransactionLineItemMeasureId, 
TransactionLineItemId, MeasureId, Value, LOVUOMId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey
FROM

(
SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@units_measureID MeasureId, 
units Value, 
@units_lovuomID LOVUOMId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(date_added,1,4),'-',SUBSTRING(date_added,5,2),'-',SUBSTRING(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId = @mx_lovRecordSourceID AND SCDActiveFlag = 'Y' AND ETLRunLogId = @serveETLRunLogID) translineitem
JOIN (SELECT transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, units units,ISNULL(date_added,'19000101') date_added,
row_id row_id,record_source_id record_source_id FROM #mx_crp_item_transaction_tmp WHERE row_status = @mx_lovPSAStatus AND units IS NOT NULL AND TRIM(units) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
ON translineitem.PSARowKey = mxitemtrans.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@tisp_measureID MeasureId, 
tisp Value, 
@others_lovuomID LOVUOMId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(date_added,1,4),'-',SUBSTRING(date_added,5,2),'-',SUBSTRING(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId = @mx_lovRecordSourceID AND SCDActiveFlag = 'Y' AND ETLRunLogId = @serveETLRunLogID) translineitem
JOIN (SELECT transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, tisp tisp,ISNULL(date_added,'19000101') date_added,
row_id row_id,record_source_id record_source_id FROM #mx_crp_item_transaction_tmp WHERE row_status = @mx_lovPSAStatus AND tisp IS NOT NULL AND TRIM(tisp) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
ON translineitem.PSARowKey = mxitemtrans.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@tesp_measureID MeasureId, 
tesp Value, 
@others_lovuomID LOVUOMId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(date_added,1,4),'-',SUBSTRING(date_added,5,2),'-',SUBSTRING(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId = @mx_lovRecordSourceID AND SCDActiveFlag = 'Y' AND ETLRunLogId = @serveETLRunLogID) translineitem
JOIN (SELECT transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, tesp tesp,ISNULL(date_added,'19000101') date_added,
row_id row_id,record_source_id record_source_id FROM #mx_crp_item_transaction_tmp WHERE row_status = @mx_lovPSAStatus AND tesp IS NOT NULL AND TRIM(tesp) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
ON translineitem.PSARowKey = mxitemtrans.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@eposprofit_measureID MeasureId, 
epos_profit Value, 
@others_lovuomID LOVUOMId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(date_added,1,4),'-',SUBSTRING(date_added,5,2),'-',SUBSTRING(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId = @mx_lovRecordSourceID AND SCDActiveFlag = 'Y' AND ETLRunLogId = @serveETLRunLogID) translineitem
JOIN (SELECT transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, epos_profit epos_profit, ISNULL(date_added,'19000101') date_added,
row_id row_id,record_source_id record_source_id FROM #mx_crp_item_transaction_tmp WHERE row_status = @mx_lovPSAStatus AND epos_profit IS NOT NULL AND TRIM(epos_profit) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
ON translineitem.PSARowKey = mxitemtrans.row_id

UNION

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@discountappl_measureID MeasureId, 
discount_applied Value, 
@others_lovuomID LOVUOMId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(date_added,1,4),'-',SUBSTRING(date_added,5,2),'-',SUBSTRING(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId = @mx_lovRecordSourceID AND SCDActiveFlag = 'Y' AND ETLRunLogId = @serveETLRunLogID) translineitem
JOIN (SELECT transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, discount_applied discount_applied,ISNULL(date_added,'19000101') date_added,
row_id row_id,record_source_id record_source_id FROM #mx_crp_item_transaction_tmp WHERE row_status = @mx_lovPSAStatus AND discount_applied IS NOT NULL AND TRIM(discount_applied) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
ON translineitem.PSARowKey = mxitemtrans.row_id
)Z
;


RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION LINE ITEM MEASURE table', 0, 1) WITH NOWAIT


/* Table Name  :  TransactionLineItemIndicator */

SET @prescription_indicatorID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Indicator - MEXICO Transaction' AND lovkey = 'prescription');

INSERT INTO ser.TransactionLineItemIndicator(
	TransactionLineItemId 			,
	LOVIndicatorId					,
	Value							,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

SELECT 
translineitem.TransactionLineItemId TransactionLineItemId,
@prescription_indicatorID LOVIndicatorId, 
--prescription Value, 
CASE WHEN (UPPER(prescription) = 'YES' OR UPPER(prescription) = 'Y') THEN 'Y' ELSE 'N' END Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(date_added,1,4),'-',SUBSTRING(date_added,5,2),'-',SUBSTRING(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
FROM
(SELECT * FROM ser.TransactionLineItem WHERE LOVRecordSourceId = @mx_lovRecordSourceID AND SCDActiveFlag = 'Y' AND ETLRunLogId = @serveETLRunLogID) translineitem
JOIN (SELECT transaction_key transaction_key, item_code item_code, prescription prescription,ISNULL(date_added,'19000101') date_added,row_id row_id,record_source_id record_source_id FROM #mx_crp_item_transaction_tmp
WHERE prescription IS NOT NULL AND TRIM(prescription) != '' AND row_status = @mx_lovPSAStatus AND prescription IS NOT NULL AND TRIM(prescription) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
)mxitemtrans 
ON translineitem.PSARowKey = mxitemtrans.row_id
;


RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION LINE ITEM INDICATOR table', 0, 1) WITH NOWAIT


/* Table Name  :  TransactionGroup */

SET @salestypeRefLOVSetID = (SELECT DISTINCT lovsetid FROM ser.RefLovSetInfo WHERE lovsetname = 'sales_type' AND LOVRecordSourceID = @mx_lovRecordSourceID);

INSERT INTO ser.TransactionGroup(
	TransactionGroupId		,
	TransactionId			,
	LOVTransactionGroupSetId,
	LOVGroupId				,
	ParentTransactionGroupId,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

SELECT 
@max_transactionGroupID+ROW_NUMBER() OVER(ORDER BY A.TransactionId) TransactionGroupId, 
A.TransactionId TransactionId,
@salestypeRefLOVSetID LOVTransactionGroupSetId, 
ro.LOVId LOVGroupId, 
NULL ParentTransactionGroupId, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
row_id PSARowKey 
FROM
(SELECT sourcekey,TransactionId, LOVRecordSourceId, sales_type,transaction_date,transaction_time,transactiondatetime, date_added,row_id,record_source_id FROM ser.[Transaction] trans 
JOIN (SELECT ROW_NUMBER() OVER(PARTITION BY transaction_key, transaction_date, transaction_time ORDER BY transaction_key, sales_type) row_num, 
transaction_key, sales_type, ISNULL(date_added,'19000101') date_added,row_id, record_source_id,transaction_date,transaction_time
FROM #mx_crp_item_transaction_tmp WHERE row_status = @mx_lovPSAStatus AND sales_type IS NOT NULL AND TRIM(sales_type) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans ON trans.sourcekey = mxitemtrans.transaction_key AND trans.SCDActiveFlag = 'Y' AND mxitemtrans.row_num = 1
AND CONVERT(datetime, CONCAT(SUBSTRING(mxitemtrans.transaction_date,1,4),'-',SUBSTRING(mxitemtrans.transaction_date,5,2),'-',SUBSTRING(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
WHERE trans.TransactionId IS NOT NULL AND trans.LOVRecordSourceId=@mx_lovRecordSourceID) A
JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'sales_type'
AND ro.LOVKey=A.sales_type
AND A.LOVRecordSourceId = ro.LOVRecordSourceId
LEFT OUTER JOIN ser.TransactionGroup transgroup
ON A.transactionId = transgroup.transactionId
AND @salestypeRefLOVSetID = transgroup.LOVTransactionGroupSetId
AND A.record_source_id = transgroup.LOVRecordSourceID
WHERE transgroup.transactionId IS NULL
;


RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION GROUP table', 0, 1) WITH NOWAIT


/* Table Name  :  LoyaltyAccount */

INSERT INTO ser.LoyaltyAccount(
	LoyaltyAccountId 				,
	LOVLoyaltyProgramId				,
	SourceKey						,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

SELECT @max_loyaltyAccountID+ROW_NUMBER() OVER(ORDER BY LOVLoyaltyProgramId, SourceKey) LoyaltyAccountId,
LOVLoyaltyProgramId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey
FROM
(
SELECT 
LOVId LOVLoyaltyProgramId, 
customer_identifier SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
FROM
(SELECT customer_identifier,ro.LOVId,record_source_id, MIN(date_added_rowid) date_added_rowid FROM
(SELECT CASE WHEN customer_identifier_type IS NULL OR TRIM(customer_identifier_type) = '' OR TRIM(customer_identifier_type) = 'NULL' THEN 'Unknown' ELSE customer_identifier_type END customer_identifier_type,
customer_identifier,CONCAT(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id FROM #mx_crp_item_transaction_tmp 
WHERE customer_identifier IS NOT NULL AND TRIM(customer_identifier) !='' AND TRIM(customer_identifier) != 'NULL' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
) mxitemtrans
LEFT OUTER JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'customer_identifier_type'
AND ro.LOVKey=mxitemtrans.customer_identifier_type
AND ro.LOVRecordSourceId = @mx_lovRecordSourceID
LEFT OUTER JOIN ser.LoyaltyAccount loyaltyaccount
ON customer_identifier = loyaltyaccount.sourceKey
AND ro.LOVId = loyaltyaccount.LOVLoyaltyProgramId
AND record_source_id = loyaltyaccount.LOVRecordSourceID
WHERE loyaltyaccount.sourceKey IS NULL
GROUP BY customer_identifier,LOVId,record_source_id
) X

UNION

SELECT 
LOVId LOVLoyaltyProgramId, 
customer_number SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
FROM
(SELECT customer_number,ro.LOVId,record_source_id, MIN(date_added_rowid) date_added_rowid FROM
(SELECT CASE WHEN customer_number_type IS NULL OR TRIM(customer_number_type) = '' OR TRIM(customer_number_type) = 'NULL' THEN 'Unknown' ELSE customer_number_type END customer_number_type, 
customer_number,CONCAT(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id FROM #mx_crp_item_transaction_tmp 
WHERE customer_number IS NOT NULL AND TRIM(customer_number) !='' AND TRIM(customer_number) != 'NULL' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
) mxitemtrans
LEFT OUTER JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'customer_number_type'
AND ro.LOVKey=mxitemtrans.customer_number_type
AND ro.LOVRecordSourceId = @mx_lovRecordSourceID
LEFT OUTER JOIN ser.LoyaltyAccount loyaltyaccount
ON customer_number = loyaltyaccount.sourceKey
AND ro.LOVId = loyaltyaccount.LOVLoyaltyProgramId
AND record_source_id = loyaltyaccount.LOVRecordSourceID
WHERE loyaltyaccount.sourceKey IS NULL
GROUP BY customer_number,LOVId,record_source_id
) X

UNION

SELECT 
LOVId LOVLoyaltyProgramId, 
other_customer_id SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
FROM
(SELECT other_customer_id,ro.LOVId,record_source_id, MIN(date_added_rowid) date_added_rowid FROM
(SELECT CASE WHEN other_customer_id_type IS NULL OR TRIM(other_customer_id_type) = '' OR TRIM(other_customer_id_type) = 'NULL' THEN 'Unknown' ELSE other_customer_id_type END other_customer_id_type, 
other_customer_id,CONCAT(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id FROM #mx_crp_item_transaction_tmp 
WHERE other_customer_id IS NOT NULL AND TRIM(other_customer_id) !='' AND TRIM(other_customer_id) != 'NULL' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
) mxitemtrans
LEFT OUTER JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'other_customer_id_type'
AND ro.LOVKey=mxitemtrans.other_customer_id_type
AND ro.LOVRecordSourceId = @mx_lovRecordSourceID
LEFT OUTER JOIN ser.LoyaltyAccount loyaltyaccount
ON other_customer_id = loyaltyaccount.sourceKey
AND ro.LOVId = loyaltyaccount.LOVLoyaltyProgramId
AND record_source_id = loyaltyaccount.LOVRecordSourceID
WHERE loyaltyaccount.sourceKey IS NULL
GROUP BY other_customer_id,LOVId,record_source_id
) X
)Z
;


RAISERROR ('Completed insertion of MEXICO source data to LOYALTY ACCOUNT table', 0, 1) WITH NOWAIT


/* Table Name  :  TransactionLoyaltyAccount */

INSERT INTO ser.TransactionLoyaltyAccount(
	TransactionId			,
	LoyaltyAccountId		,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

SELECT 
TransactionId TransactionId,
LoyaltyAccountId LoyaltyAccountId, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
FROM
(SELECT A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id, MIN(date_added_rowid) date_added_rowid FROM
(SELECT sourcekey sourcekey,TransactionId TransactionId, LOVRecordSourceId LOVRecordSourceId, transactiondatetime,transaction_date,transaction_time,
CASE WHEN customer_identifier_type IS NULL OR TRIM(customer_identifier_type) = '' OR TRIM(customer_identifier_type) = 'NULL' THEN 'Unknown' ELSE customer_identifier_type END customer_identifier_type, customer_identifier customer_identifier,
date_added_rowid,record_source_id FROM ser.[Transaction] trans 
JOIN (SELECT transaction_key transaction_key, customer_identifier_type customer_identifier_type, customer_identifier customer_identifier,CONCAT(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id,transaction_date,transaction_time
FROM #mx_crp_item_transaction_tmp WHERE customer_identifier IS NOT NULL AND TRIM(customer_identifier) !='' AND TRIM(customer_identifier) != 'NULL' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans ON trans.sourcekey = mxitemtrans.transaction_key AND trans.SCDActiveFlag = 'Y'
AND CONVERT(datetime, CONCAT(SUBSTRING(mxitemtrans.transaction_date,1,4),'-',SUBSTRING(mxitemtrans.transaction_date,5,2),'-',SUBSTRING(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
WHERE trans.LOVRecordSourceId=@mx_lovRecordSourceID) A
LEFT OUTER JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'customer_identifier_type'
AND ro.LOVKey=A.customer_identifier_type
AND ro.LOVRecordSourceId = @mx_lovRecordSourceID
LEFT OUTER JOIN (SELECT * FROM ser.LoyaltyAccount WHERE SCDActiveFlag = 'Y' AND LOVRecordSourceId = @mx_lovRecordSourceID) loyaltyacc
ON loyaltyacc.sourcekey = A.customer_identifier
AND loyaltyacc.LOVLoyaltyProgramId = ro.LOVId
LEFT OUTER JOIN ser.TransactionLoyaltyAccount transLoyaltyaccount
ON A.TransactionId = transLoyaltyaccount.TransactionId
AND loyaltyacc.LoyaltyAccountId = transLoyaltyaccount.LoyaltyAccountId
AND A.record_source_id = transLoyaltyaccount.LOVRecordSourceID
WHERE transLoyaltyaccount.LoyaltyAccountId IS NULL
GROUP BY A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id
) X

UNION

SELECT 
TransactionId TransactionId,
LoyaltyAccountId LoyaltyAccountId, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
FROM
(SELECT A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id, MIN(date_added_rowid) date_added_rowid FROM
(SELECT sourcekey sourcekey,TransactionId TransactionId, LOVRecordSourceId LOVRecordSourceId, transactiondatetime,transaction_date,transaction_time,
CASE WHEN customer_number_type IS NULL OR TRIM(customer_number_type) = '' OR TRIM(customer_number_type) = 'NULL' THEN 'Unknown' ELSE customer_number_type END customer_number_type, customer_number customer_number,
date_added_rowid,record_source_id FROM ser.[Transaction] trans 
JOIN (SELECT transaction_key transaction_key, customer_number_type customer_number_type, customer_number customer_number, CONCAT(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id,transaction_date,transaction_time
FROM #mx_crp_item_transaction_tmp WHERE customer_number IS NOT NULL AND TRIM(customer_number) !='' AND TRIM(customer_number) != 'NULL' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans ON trans.sourcekey = mxitemtrans.transaction_key AND trans.SCDActiveFlag = 'Y'
AND CONVERT(datetime, CONCAT(SUBSTRING(mxitemtrans.transaction_date,1,4),'-',SUBSTRING(mxitemtrans.transaction_date,5,2),'-',SUBSTRING(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
WHERE trans.LOVRecordSourceId=@mx_lovRecordSourceID) A
LEFT OUTER JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'customer_number_type'
AND ro.LOVKey=A.customer_number_type
AND ro.LOVRecordSourceId = @mx_lovRecordSourceID
LEFT OUTER JOIN (SELECT * FROM ser.LoyaltyAccount WHERE SCDActiveFlag = 'Y' AND LOVRecordSourceId = @mx_lovRecordSourceID) loyaltyacc
ON loyaltyacc.sourcekey = A.customer_number
AND loyaltyacc.LOVLoyaltyProgramId = ro.LOVId
LEFT OUTER JOIN ser.TransactionLoyaltyAccount transLoyaltyaccount
ON A.TransactionId = transLoyaltyaccount.TransactionId
AND loyaltyacc.LoyaltyAccountId = transLoyaltyaccount.LoyaltyAccountId
AND A.record_source_id = transLoyaltyaccount.LOVRecordSourceID
WHERE transLoyaltyaccount.LoyaltyAccountId IS NULL
GROUP BY A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id
) X

UNION

SELECT 
TransactionId TransactionId,
LoyaltyAccountId LoyaltyAccountId, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--CONCAT(SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',SUBSTRING(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
FROM
(SELECT A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id, MIN(date_added_rowid) date_added_rowid FROM
(SELECT sourcekey sourcekey,TransactionId TransactionId, LOVRecordSourceId LOVRecordSourceId, transactiondatetime,transaction_date,transaction_time,
CASE WHEN other_customer_id_type IS NULL OR TRIM(other_customer_id_type) = '' OR TRIM(other_customer_id_type) = 'NULL' THEN 'Unknown' ELSE other_customer_id_type END other_customer_id_type, other_customer_id other_customer_id,
date_added_rowid,record_source_id FROM ser.[Transaction] trans 
JOIN (SELECT transaction_key transaction_key, other_customer_id_type other_customer_id_type, other_customer_id other_customer_id,CONCAT(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id,transaction_date,transaction_time
FROM #mx_crp_item_transaction_tmp WHERE other_customer_id IS NOT NULL AND TRIM(other_customer_id) !='' AND TRIM(other_customer_id) != 'NULL' AND row_status = @mx_lovPSAStatus 
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans ON trans.sourcekey = mxitemtrans.transaction_key AND trans.SCDActiveFlag = 'Y'
AND CONVERT(datetime, CONCAT(SUBSTRING(mxitemtrans.transaction_date,1,4),'-',SUBSTRING(mxitemtrans.transaction_date,5,2),'-',SUBSTRING(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
WHERE trans.LOVRecordSourceId=@mx_lovRecordSourceID) A
LEFT OUTER JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'other_customer_id_type'
AND ro.LOVKey=A.other_customer_id_type
AND ro.LOVRecordSourceId = @mx_lovRecordSourceID
LEFT OUTER JOIN (SELECT * FROM ser.LoyaltyAccount WHERE SCDActiveFlag = 'Y' AND LOVRecordSourceId = @mx_lovRecordSourceID) loyaltyacc
ON loyaltyacc.sourcekey = A.other_customer_id
AND loyaltyacc.LOVLoyaltyProgramId = ro.LOVId
LEFT OUTER JOIN ser.TransactionLoyaltyAccount transLoyaltyaccount
ON A.TransactionId = transLoyaltyaccount.TransactionId
AND loyaltyacc.LoyaltyAccountId = transLoyaltyaccount.LoyaltyAccountId
AND A.record_source_id = transLoyaltyaccount.LOVRecordSourceID
WHERE transLoyaltyaccount.LoyaltyAccountId IS NULL
GROUP BY A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id
) X
;


RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION LOYALTY ACCOUNT table', 0, 1) WITH NOWAIT


UPDATE psa.mx_crp_item_transaction
SET row_status = 26002
/*  code to be added to join source table with transaction line item */
FROM psa.mx_crp_item_transaction src
JOIN ser.TransactionLineItem translineitem
ON src.row_id = translineitem.psarowkey
AND translineitem.LOVRecordSourceID = @mx_lovRecordSourceID
AND translineitem.ETLRunLogId = @serveETLRunLogID
WHERE row_status = @mx_lovPSAStatus
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
;


RAISERROR ('Completed procedure of MEXICO updated row status to IN SERV', 0, 1) WITH NOWAIT


COMMIT TRANSACTION;
END TRY
BEGIN CATCH
DECLARE @error_num VARCHAR(MAX),
		@error_msg VARCHAR(MAX),
		@error_sev VARCHAR(MAX)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

END;
GO
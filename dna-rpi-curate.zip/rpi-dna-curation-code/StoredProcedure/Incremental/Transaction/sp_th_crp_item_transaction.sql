IF OBJECT_ID('psa.sp_th_crp_item_transaction') IS NOT NULL
BEGIN
	DROP PROC psa.sp_th_crp_item_transaction;
END

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
************************************************************************************************************
Procedure Name			: sp_th_crp_item_transaction
Purpose					: Load History data from thailand transaction source table(psa.th_crp_item_transaction) into Serve Layer Table
Domain					: Transaction
RecordSourceID  for thailand Transaction	: 12010

**************************************************************************************************************
*/

CREATE PROC [psa].[sp_th_crp_item_transaction] (@serveETLRunLogID varchar(max), @tablename varchar(max), @psaEntityId varchar(max)) AS
DECLARE @th_lovRecordSourceID 		bigint; 
DECLARE @th_scdLovRecordSourceID 	bigint; 
DECLARE @psa_rowstatus 				bigint; 
DECLARE @ser_rowstatus 				bigint;
DECLARE @max_tillid 				bigint;
DECLARE @max_siteroleid 			bigint; 
DECLARE @th_Siteid 					bigint; 
DECLARE @th_RoleId 					bigint;
DECLARE @max_transactionid 			bigint; 
DECLARE @th_trantypeid 				bigint;
DECLARE @max_productid 				bigint; 
DECLARE @th_srckeytypeid 			bigint;
DECLARE @max_upcproductid 			bigint; 
DECLARE @th_upcsrckeytypeid 		bigint; 
DECLARE @max_dealid 				bigint;
DECLARE @max_tranlineitemid 		bigint; 
DECLARE @th_lineitemtypeid 			bigint;
DECLARE @max_measureid 				bigint; 
DECLARE @th_measuretypeid			bigint; 
DECLARE @th_measuretypeid_unit 		bigint; 
DECLARE @th_measuretypeid_tisp 		bigint; 
DECLARE @th_measuretypeid_tesp 		bigint; 
DECLARE @th_measuretypeid_epos 		bigint; 
DECLARE @th_measuretypeid_disc 		bigint;
DECLARE @th_intdatatypeid 			bigint; 
DECLARE @th_decdatatypeid 			bigint; 
DECLARE @th_strdatatypeid 			bigint;
DECLARE @max_trnlineitemmeasureid 	bigint; 
DECLARE @th_unitmeasureid 			bigint; 
DECLARE @th_tispmeasureid 			bigint; 
DECLARE @th_tespmeasureid 			bigint; 
DECLARE @th_eposmeasureid 			bigint; 
DECLARE @th_discmeasureid 			bigint;  
DECLARE @max_loyaltyacctid 			bigint;
DECLARE @catchup_row 				bigint;
DECLARE @th_indicatorid 			bigint;
DECLARE @th_uomid_unit				bigint;
DECLARE @th_uomid_nonunit			bigint;
DECLARE @max_trangroupid 			bigint;
DECLARE @ch_trangroupsetid 			bigint;
DECLARE @dq_status					INT;
DECLARE	@th_trangroupsetid			bigint;
DECLARE @feed_entityid 				bigint;
--DECLARE @serveETLRunLogID 		bigint;
DECLARE @ruleId BIGINT;
DECLARE @attributeid BIGINT;


/**********   need to declare the schema    ******************/

BEGIN		

SET @th_lovRecordSourceID = 12010; 
SET @th_scdLovRecordSourceID = 152; 
SET @psa_rowstatus = 26001; 
SET @ser_rowstatus = 26002;
SET @dq_status = 7777;
SET @feed_entityid = (select sourceentityid from psa.[MappingEntity] me inner join psa.[Entity] e on me.sourceentityid = e.EntityID where me.[TargetEntityID] = @psaEntityId and e.SchemaName like '%feed%');
--SET @serveETLRunLogID = 54321;

/* Creation of temporary table to store records wit rowstatus 26001 from PSA Source table */
    IF OBJECT_ID('tempdb..#th_crp_item_transaction_tmp') IS NOT NULL
    BEGIN
        DROP TABLE #th_crp_item_transaction_tmp
    END
    
    SELECT * INTO #th_crp_item_transaction_tmp FROM 
	(SELECT 
		row_id,transaction_key,
		ISNULL( NULLIF((Substring(till_id, Patindex('%[^0]%', till_id + ' '), Len(till_id)) ),''),0) till_id,
		transaction_date,transaction_time,item_code,units,tisp,tesp,store_number,customer_identifier,customer_identifier_type,customer_number,customer_number_type,other_customer_id,
		other_customer_id_type,epos_profit,discount_applied,deal_id,
		ISNULL( NULLIF((Substring(upc, Patindex('%[^0]%', upc + ' '), Len(upc)) ),''),0) upc,
		sales_type,prescription,date_added,etl_runlog_id,asset_id,record_source_id,row_status,created_timestamp,active_flag
		FROM psa.th_crp_item_transaction 
		WHERE row_status = @psa_rowstatus 
    )A;

 
RAISERROR ('Completed insertion of TEMP THAILAND PSA table', 0, 1) WITH NOWAIT;

	/* Creation of temporary table to store records to be inserted in productidentifier target table */
	IF OBJECT_ID('tempdb..#ProductIdentifier_temp') IS NOT NULL
	BEGIN
		DROP TABLE #ProductIdentifier_temp
	END
	
	SELECT * INTO #ProductIdentifier_temp
	FROM (SELECT * FROM ser.productidentifier WHERE etlrunlogid = -1
	)A;


	RAISERROR ('Completed creation of productidentifier temp table', 0, 1) WITH NOWAIT;

BEGIN TRY
	BEGIN TRANSACTION
	

/*  update the temp table where transaction_time is null or blank or contains alphabets */

	UPDATE #th_crp_item_transaction_tmp
	SET transaction_time = '0000' where transaction_time is null or trim(transaction_time) = '' or transaction_time like '%[A-Za-z]%';
	
RAISERROR ('Completed updating the temp table where transaction_time is null or blank or contains alphabets', 0, 1) WITH NOWAIT;

/*--- Insert records into RuleEntityInstance for those records with invalid transaction_time ---*/

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Time Check' AND RuleCode = 'TC');
--SET @entityId = (SELECT EntityID FROM psa.[Entity] WHERE SchemaName like '%Feed%' AND EntityName = 'Thailand_crp_item_transaction_Incremental_Load_txt');
SET @attributeid = (select attributeid from psa.attribute  where entityid = @feed_entityid and trim(AttributeName) = 'transaction_time');

INSERT INTO psa.RuleEntityInstance(
               --RuleEntityInstanceID
               RuleID
               ,EntityID
               ,AttributeID
               ,RuleDetail
               ,ETLRunLogID
               ,SourceEntityID
               ,SourceAttributeID
               ,PSARowKey
               ,DTCreated
               ,UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--Transaction_time--Record created for invalid transaction_time' RuleDetail,
A.etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
A.row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM psa.th_crp_item_transaction 
	WHERE (transaction_time LIKE '%[A-Za-z]%' OR transaction_time IS NULL OR TRIM(transaction_time) = '') 
	AND row_status = 26001) A

UNION

SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--Transaction_time--Record created for invalid transaction_time' RuleDetail,
A.etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
A.row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM #th_crp_item_transaction_tmp 
	WHERE cast(substring(trim(transaction_time),1,2) as int) > 23 or cast(substring(trim(transaction_time),3,2) as int) > 59) A;
	
RAISERROR ('Completed insertion of CHILE source data to RULEENTITYINSTANCE table for invalid transaction_time', 0, 1) WITH NOWAIT;

/*  update the temp table where transaction_time_hour > 23 OR transaction_time_minute > 59 */

	UPDATE #th_crp_item_transaction_tmp
	SET transaction_time = '0000' where cast(substring(trim(transaction_time),1,2) as int) > 23 or cast(substring(trim(transaction_time),3,2) as int) > 59;

RAISERROR ('Completed updating the temp table where transaction_time_hour > 23 OR transaction_time_minute > 59', 0, 1) WITH NOWAIT;

/*  update the temp table : Include ':' between transaction_time_hour and transaction_time_minute */

	UPDATE #th_crp_item_transaction_tmp
	SET transaction_time = concat(substring(trim(transaction_time),1,2), ':', substring(trim(transaction_time),3,2));
	
RAISERROR ('Completed updating the temp table to include colon between transaction_time_hour and transaction_time_minute', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 1.Table Name : Till */

SET @max_tillid = (SELECT COALESCE(MAX(TillId),0) FROM  [ser].[Till]);

INSERT INTO [ser].[Till] (TillId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_tillid + ROW_NUMBER() OVER(ORDER BY A.till_id ASC) TillId, 
		A.till_id SourceKey, 
		@th_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(
SELECT src.till_id, src.date_row from 
(SELECT till_id, record_source_id, MIN(row_id) date_row from #th_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus
	GROUP BY till_id,record_source_id)src 
LEFT OUTER JOIN [ser].[Till] slf on 
	src.till_id = slf.sourcekey 
	and src.record_source_id = slf.LOVRecordSourceId 
	where slf.sourcekey IS NULL 
)A ;

RAISERROR ('Completed insertion of THAILAND source data to TILL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 2.Table Name : Site_Role */

SET @max_siteroleid = (SELECT COALESCE(MAX(SiteRoleId),0) FROM  [ser].[SiteRole]);
SET @th_SiteId = (select siteid from ser.[site] s where s.sourcekey = '0' and lovrecordsourceid = 12012 and SCDActiveFlag = 'Y'
				and lovsitetypeid = (select lovid from ser.reflovsetinfo where lovkey='0' and LOVsetname = 'Site Type'));
SET @th_RoleId = (select lovid from ser.reflovsetinfo where lovkey='Store' and LOVsetname = 'Role');


INSERT INTO [ser].[Siterole] (SiteRoleId, SiteId, LOVRoleId, SourceKey, SiteRoleName, SiteRoleShortName, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT S.* from
(
/*--- Inserting records for NEW business keys ---*/
SELECT  @max_siteroleid + ROW_NUMBER() OVER(ORDER BY A.sourcekey ASC) SiteRoleId, 
		@th_SiteId SiteId,    
		@th_RoleId LOVRoleId, 
		A.sourcekey SourceKey, 
		NULL SiteRoleName, 
		NULL SiteRoleShortName, 
		@th_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion,  
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(
SELECT src.sourcekey, src.date_row from 
(SELECT store_number sourcekey, record_source_id, MIN(row_id) date_row 
from #th_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	and store_number IS NOT NULL and store_number != '' 
	GROUP BY store_number,record_source_id) src
LEFT OUTER JOIN [ser].[Siterole] slf 
	on src.sourcekey = slf.sourcekey 
	and src.record_source_id = slf.LOVRecordSourceId 
	where slf.sourcekey IS NULL
)A 

UNION

/*--- Inserting records for EXISTING business keys which encountered soft delete ---*/
SELECT  A.SiteRoleId SiteRoleId, 
		@th_SiteId SiteId,   
		@th_RoleId LOVRoleId, 
		A.sourcekey SourceKey, 
		NULL SiteRoleName, 
		NULL SiteRoleShortName, 
		@th_lovRecordSourceID LOVRecordSourceId, 
		current_timestamp SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		A.new_SCDVersion SCDVersion,  
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(
SELECT slf.SiteRoleId, (slf.SCDVersion + 1) new_SCDVersion, src.sourcekey, src.date_row from 
(SELECT store_number sourcekey, record_source_id, MIN(row_id) date_row 
from #th_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY store_number,record_source_id)src
JOIN (Select B.* from 
(Select *, RANK() OVER(partition by sourcekey,lovrecordsourceid order by sourcekey,lovrecordsourceid,SCDVersion desc) row_num from  
[ser].[SiteRole] 	where lovrecordsourceid = 12010) B where B.row_num = 1 and B.SCDActiveFlag = 'N'
) slf 
	on src.sourcekey = slf.sourcekey
)A
)S;

RAISERROR ('Completed insertion of THAILAND source data to SITEROLE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/*--- Insert records into RuleEntityInstance for those store_number which are new or which have encountered soft delete ---*/

--DECLARE @max_ruleentityinstanceid BIGINT;
--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Skeleton Record Creation' AND RuleCode = 'SRC');
--SET @entityId = (SELECT EntityID FROM psa.[Entity] WHERE SchemaName like '%Feed%' AND EntityName = 'Thailand_crp_item_transaction_Incremental_Load_txt');
SET @attributeid = (select attributeid from psa.attribute  where entityid = @feed_entityid and trim(AttributeName) = 'store_number');

INSERT INTO psa.RuleEntityInstance(
               --RuleEntityInstanceID
               RuleID
               ,EntityID
               ,AttributeID
               ,RuleDetail
               ,ETLRunLogID
               ,SourceEntityID
               ,SourceAttributeID
               ,PSARowKey
               ,DTCreated
               ,UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--SiteRoleId--Record created for Store number due to non existence of SiteRoleId' RuleDetail,
etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT * FROM ser.SiteRole WHERE LOVRecordSourceId = 12010 AND ETLRunLogId = @serveETLRunLogID AND SCDActiveFlag = 'Y') siterole
JOIN #th_crp_item_transaction_tmp noitemtrans
	ON noitemtrans.store_number = siterole.sourcekey
	AND noitemtrans.row_id = siterole.psarowkey


RAISERROR ('Completed insertion of THAILAND source data to RULEENTITYINSTANCE table for new store_number', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 4.Table Name : Transaction */

SET @max_transactionid = (SELECT COALESCE(MAX(TransactionId),0) FROM  [ser].[Transaction]);
SET @th_trantypeid = (select lovid from ser.reflovsetinfo where lovkey='RETAIL' and LOVsetname = 'Transaction Type'); 


INSERT INTO [ser].[Transaction]
(TransactionId, SourceKey, LOVTransactionTypeId, SiteRoleId, TransactionDatetime, TillId, TillTransactionNumber, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_transactionid + ROW_NUMBER() OVER(ORDER BY trnx.transaction_key ASC) TransactionId, 
		trnx.transaction_key SourceKey, 
		@th_trantypeid LOVTransactionTypeId, 
		trnx.SiteRoleId SiteRoleId, 
		CAST (CONCAT(trnx.transaction_date,' ',trnx.transaction_time) as Datetime) TransactionDatetime, 
		trnx.tillId TillId, 
		null TillTransactionNumber, 
		@th_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		trnx.row_num PSARowKey from 
(
SELECT P.transaction_key,P.siteroleid, P.transaction_date, 
P.transaction_time,
P.tillid, P.record_source_id, P.row_num from
(SELECT src.transaction_key,B.siteroleid, src.transaction_date, src.transaction_time,till.tillid, src.record_source_id, src.date_row row_num from 
(SELECT transaction_key, store_number, transaction_date, transaction_time, till_id,record_source_id, MIN(row_id) date_row  
from #th_crp_item_transaction_tmp  	
	where row_status = @psa_rowstatus 
	GROUP BY transaction_key, store_number, till_id, transaction_date, transaction_time,record_source_id) src 
JOIN (SELECT SiteRoleId, sourcekey from [ser].[Siterole] where lovrecordsourceid = 12010 and SCDActiveFlag = 'Y')B 
	on B.sourcekey = src.store_number
JOIN (SELECT * from [ser].[Till] where lovrecordsourceid = 12010 and SCDActiveFlag = 'Y') till 
	on src.till_id = till.sourcekey 
) P
LEFT OUTER JOIN [ser].[Transaction] T 
	on P.transaction_key = T.sourcekey 
	and CAST (CONCAT(P.transaction_date,' ',P.transaction_time) as Datetime) = T.TransactionDatetime
	and P.record_source_id = T.LOVRecordSourceId 
	where T.sourcekey IS NULL 
)trnx ;


RAISERROR ('Completed insertion of THAILAND source data to TRANSACTION table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/



/* 5.Table Name : Product */

SET @max_productid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @th_srckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='Thailand Item Code' and LOVsetname = 'Source Key Type'); 

INSERT INTO [ser].[Product] (ProductId, SourceKey, LOVSourceKeyTypeId, ProductName, ProductDescription, LOVBrandId, LOVSubBrandId, LOVRecordSourceId, ParentProductId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT S.* from 
(
/*--- Inserting records for NEW business keys ---*/
SELECT  @max_productid + ROW_NUMBER() OVER(ORDER BY A.SourceKey ASC) ProductId, 
		A.SourceKey SourceKey, 
		@th_srckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		@th_lovRecordSourceID LOVRecordSourceId,
		null ParentProductId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey from
(
SELECT src.sourcekey, src.date_row from 
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') SourceKey, record_source_id, min(row_id) date_row from #th_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), record_source_id) src 
LEFT OUTER JOIN [ser].[Product] P on 
	src.sourcekey = P.sourcekey 
	and src.record_source_id = P.LOVRecordSourceId 
	where P.sourcekey IS NULL 
)A

UNION
/*--- Inserting records for EXISTING business keys which encountered soft delete ---*/
SELECT  A.ProductId ProductId, 
		A.SourceKey SourceKey, 
		@th_srckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		@th_lovRecordSourceID LOVRecordSourceId,
		null ParentProductId,
		current_timestamp SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		A.new_SCDVersion SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey from
(
SELECT slf.ProductId, (slf.SCDVersion + 1) new_SCDVersion, src.sourcekey, src.date_row from 
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') SourceKey, record_source_id, min(row_id) date_row from #th_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), record_source_id) src 
/*--- Joining with the max scd_version of those item_code which is having SCDActiveFlag='N' (that is, it encountered a soft delete) ---*/
JOIN (Select B.* from 
(Select *, RANK() OVER(partition by sourcekey,lovrecordsourceid order by sourcekey,lovrecordsourceid,SCDVersion desc) row_num from  
[ser].[PRODUCT] where lovrecordsourceid = 12010) B where B.row_num = 1 and B.SCDActiveFlag = 'N'
) slf 
	on src.sourcekey = slf.sourcekey
)A

)S;


RAISERROR ('Completed insertion of THAILAND source data to PRODUCT table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/*--- Insert records into RuleEntityInstance for those item_code which are new or which have encountered soft delete ---*/

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Skeleton Record Creation' AND RuleCode = 'SRC');
--SET @entityId = (SELECT EntityID FROM psa.[Entity] WHERE SchemaName like '%Feed%' AND EntityName = 'Thailand_crp_item_transaction_Incremental_Load_txt');
SET @attributeid = (select attributeid from psa.attribute  where entityid = @feed_entityid and trim(AttributeName) = 'item_code');

INSERT INTO psa.RuleEntityInstance(
               --RuleEntityInstanceID
               RuleID
               ,EntityID
               ,AttributeID
               ,RuleDetail
               ,ETLRunLogID
               ,SourceEntityID
               ,SourceAttributeID
               ,PSARowKey
               ,DTCreated
               ,UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--ProductId--Record created for Item Code due to non existence of ProductId' RuleDetail,
etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT * FROM ser.Product WHERE LOVRecordSourceId = 12010 AND ETLRunLogId = @serveETLRunLogID AND SCDActiveFlag = 'Y') product
JOIN #th_crp_item_transaction_tmp noitemtrans
	ON REPLACE(LTRIM(REPLACE(noitemtrans.item_code,'0',' ')),' ','0') = product.sourcekey
	AND noitemtrans.row_id = product.psarowkey

RAISERROR ('Completed insertion of THAILAND source data to RULEENTITYINSTANCE table for new item_code', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 6.Table Name : ProductIdentifier */

SET @max_upcproductid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @th_upcsrckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='UPC' and LOVsetname = 'Identifier'); 
SET @th_srckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='Thailand Item Code' and LOVsetname = 'Source Key Type');


/*INSERT INTO [ser].[ProductIdentifier] (ProductId, LOVIdentifierId, [Value], LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  A.productId ProductId, 
		@th_upcsrckeytypeid LOVIdentifierId, 
		A.upc [Value], 
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey from
(
SELECT P.productId, src.upc, src.date_row from
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') item_code, upc, record_source_id, min(row_id) date_row from #th_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), upc, record_source_id) src
JOIN [ser].[PRODUCT] P on 
	src.item_code = P.sourcekey 
	and P.LOVSourceKeyTypeId = @th_srckeytypeid
	and P.LOVRecordSourceId = @th_lovRecordSourceID 
	and SCDActiveFlag = 'Y'
LEFT OUTER JOIN [ser].[ProductIdentifier] U on 
	isnull(src.upc,'dummy_upc') = isnull(U.[Value],'dummy_upc') 
	and src.record_source_id = U.LOVRecordSourceId 
	and U.productId = P.productId 
	where U.productId IS NULL
) A;*/

DECLARE @datetime_val nvarchar(100);
SET @datetime_val = CURRENT_TIMESTAMP;

INSERT INTO #ProductIdentifier_temp
SELECT 
A.ProductId ProductId, 
@th_upcsrckeytypeid LOVIdentifierId,
upc Value, 
@th_lovRecordSourceID LOVRecordSourceId, 
date_added SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@th_lovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
rowid PSARowKey 
FROM
(SELECT sourcekey, ProductId ProductId, thitemtrans.upc as upc, MIN(row_id) rowid, record_source_id, date_added FROM ser.Product product 
JOIN #th_crp_item_transaction_tmp thitemtrans 
ON product.sourcekey = REPLACE(LTRIM(REPLACE(thitemtrans.item_code,'0',' ')),' ','0') 
AND product.SCDActiveFlag = 'Y'
AND product.LOVSourceKeyTypeId = @th_srckeytypeid
WHERE product.LOVRecordSourceId=@th_lovRecordSourceID AND row_status = @psa_rowstatus AND upc IS NOT NULL AND TRIM(upc) != '' 
GROUP BY sourcekey, ProductId, upc,record_source_id,date_added) A
LEFT OUTER JOIN ser.ProductIdentifier prodidentifier
ON A.productId = prodidentifier.productId
AND COALESCE(A.upc,'DUMMY_UPC_VALUE') = COALESCE(prodidentifier.value,'DUMMY_UPC_VALUE')
AND A.record_source_id = prodidentifier.LOVRecordSourceID
AND prodidentifier.SCDActiveFlag = 'Y'
WHERE prodidentifier.ProductId IS NULL
;


--update 1: This update statement updates the SCD Active Flag, SCD Start Date, SCD End date and SCD Version
    UPDATE #ProductIdentifier_temp
    SET scdactiveflag = A.scdactiveflag,
        SCDStartDate = @datetime_val,
        SCDEndDate = A.SCDEndDate,
        SCDVersion = A.SCDVersion FROM #ProductIdentifier_temp P JOIN
    (SELECT 
    LEAD('N',1,'Y') OVER(PARTITION BY i.productId, i.LOVIdentifierId, i.LOVRecordSourceID ORDER BY SCDStartDate) scdactiveflag,
    LEAD(@datetime_val,1,'9999-12-31') OVER(PARTITION BY i.productId, i.LOVIdentifierId, i.LOVRecordSourceID ORDER BY SCDStartDate) SCDEndDate ,
    ROW_NUMBER() OVER (PARTITION BY i.productId, i.LOVIdentifierId, i.LOVRecordSourceID  ORDER BY SCDStartDate) SCDVersion,
    psarowkey FROM #ProductIdentifier_temp i
    )A
    ON P.psarowkey = A.psarowkey;
    
RAISERROR ('update 1: This update statement updates the SCD Active Flag, SCD Start Date, SCD End date and SCD Version', 0, 1) WITH NOWAIT
    
	
--update 2: This update statement updates the SCD version of the temporary table (temporary table version = mainn table max version for that key + temporary table version)
    UPDATE #ProductIdentifier_temp
    SET SCDVersion = SCDVersion + version
    FROM #ProductIdentifier_temp t
    JOIN 
    (SELECT B.productId, B.SCDVersion version FROM 
    (SELECT ProductId, SCDVersion, RANK() OVER(PARTITION BY productId, LOVIdentifierId, LOVRecordSourceID ORDER BY SCDVersion DESC) row_num FROM 
    ser.productidentifier WHERE lovrecordsourceid = @th_lovRecordSourceID) B WHERE B.row_num = 1 ) s
    ON t.productId = s.productId ;
    
RAISERROR ('update 2: This update statement updates the SCD version of the temporary table', 0, 1) WITH NOWAIT


--update 3: This update statement updates the SCD Start Date to 1900-01-01 wherever the SCDActiveFlag = 'Y' and SCDVersion = 1
    UPDATE #ProductIdentifier_temp
    SET SCDStartDate = '1900-01-01'
    WHERE SCDVersion = 1 ;
        
RAISERROR ('update 3: This update statement updates the SCD Start Date to 1900-01-01 wherever the SCDActiveFlag = Y and SCDVersion = 1', 0, 1) WITH NOWAIT
 

--update 4: This update statement updates the SCD Active Flag and SCD End Date of the main table
--Set Active Flag = N and SCD End date = current timestamp wherever the product id matches and the flag is 'Y' in both the tables
    UPDATE ser.productidentifier
    SET SCDActiveFlag = 'N', SCDEndDate = @datetime_val
    FROM ser.productidentifier main
    JOIN (SELECT productId FROM #ProductIdentifier_temp WHERE SCDActiveFlag = 'Y') tmp
    ON tmp.productId = main.productId
    AND main.SCDActiveFlag = 'Y';
    
RAISERROR ('update 4: This update statement updates the SCD Active Flag and SCD End Date of the main table', 0, 1) WITH NOWAIT


--insert the records of the temporary table into the main table
    
INSERT INTO ser.productidentifier SELECT * FROM #ProductIdentifier_temp ; 

RAISERROR ('final insert: This inserts the records of the temporary table into the main table', 0, 1) WITH NOWAIT

RAISERROR ('Completed insertion of THAILAND source data to PRODUCTIDENTIFIER table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 7.Table Name : Deal */

SET @max_dealid = (SELECT COALESCE(MAX(DealId),0) FROM  [ser].[Deal]);

INSERT INTO [ser].[Deal] (DealId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_dealid + ROW_NUMBER() OVER(ORDER BY src.deal_id ASC) DealId,
		src.deal_id SourceKey,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		src.date_row PSARowKey from 
(
SELECT T.deal_id, T.date_row from 
(SELECT deal_id, record_source_id, min(row_id) date_row from #th_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY deal_id, record_source_id)T 
LEFT OUTER JOIN [ser].[Deal] D on 
	T.deal_id = D.sourcekey 
	and T.record_source_id = D.LOVRecordSourceId 
	where D.sourcekey IS NULL and T.deal_id IS NOT NULL and T.deal_id != ''
) src ;

RAISERROR ('Completed insertion of THAILAND source data to DEAL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 8.Table Name : Transaction Line Item */

SET @max_tranlineitemid = (SELECT COALESCE(MAX(TransactionLineItemId),0) FROM  [ser].[TransactionLineItem]);
SET @th_upcsrckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='UPC' and LOVsetname = 'Source Key Type'); 
SET @th_srckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='Thailand Item Code' and LOVsetname = 'Source Key Type');


INSERT INTO [ser].[TransactionLineItem] (TransactionLineItemId, TransactionId, ProductId, LOVLineItemTypeId, DealId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_tranlineitemid + ROW_NUMBER() OVER(ORDER BY final.sourcekey ASC) TransactionLineItemId,
		final.transactionid TransactionId,
		final.productid ProductId,
		NULL LOVLineItemTypeId,    
		final.deal_id DealId,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
SELECT trnx.transactionid, trnx.sourcekey, A.productid , A.dealid deal_id, A.row_id row_num from [ser].[Transaction] trnx 
JOIN 
(
SELECT P.productId,src.transaction_key, src.sales_type, src.dealid, src.row_id, src.transaction_date, src.transaction_time  from 
(SELECT REPLACE(LTRIM(REPLACE(M.item_code,'0',' ')),' ','0') item_code, M.transaction_key, M.sales_type, D.dealid, M.row_id, M.transaction_date, M.transaction_time  from
(SELECT * from #th_crp_item_transaction_tmp where row_status = @psa_rowstatus) M
LEFT OUTER JOIN [ser].[Deal] D on 
	D.sourcekey = M.deal_id and D.LOVRecordSourceId = 12010 and D.SCDActiveFlag = 'Y'
)src
JOIN [ser].[product] P on 
	P.sourcekey = src.item_code 
	and P.lovsourcekeytypeid = @th_srckeytypeid 
	and P.SCDActiveFlag = 'Y'
)A 
	on trnx.sourcekey = A.transaction_key 
	and trnx.lovrecordsourceid = 12010 
	and CAST (CONCAT(A.transaction_date,' ',A.transaction_time) as Datetime) = trnx.TransactionDatetime 
) final;

RAISERROR ('Completed insertion of THAILAND source data to TRANSACTIONLINEITEM table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 10.Table Name : Transaction Line Item Measure */

SET @max_trnlineitemmeasureid = (SELECT COALESCE(MAX(TransactionLineItemMeasureId),0) FROM  [ser].[TransactionLineItemMeasure]);
SET @th_measuretypeid = (select lovid from ser.reflovsetinfo where lovkey='RETAIL_TRANS_AGG' and LOVsetname = 'Measure Type');
SET @th_unitmeasureid = (SELECT MAX(MeasureId) from [ser].[Measure] msr where msr.measurename = 'units' and msr.LOVMeasureTypeId = @th_measuretypeid and msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @th_tispmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'tisp' and msr.LOVMeasureTypeId = @th_measuretypeid and msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @th_tespmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'tesp' and msr.LOVMeasureTypeId = @th_measuretypeid and msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @th_eposmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'epos_profit' and msr.LOVMeasureTypeId = @th_measuretypeid and 	msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @th_discmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'discount_applied' and msr.LOVMeasureTypeId = @th_measuretypeid and 	msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);

SET @th_uomid_unit = (SELECT lovid from ser.reflovsetinfo where lovkey='Unit' and LOVsetname = 'Unit Of Measure' and LOVRecordsourceid = 12012);
SET @th_uomid_nonunit = (SELECT lovid from ser.reflovsetinfo where lovkey='THB' and LOVsetname = 'Currency ISO 4217' and LOVRecordsourceid = 12012);

INSERT INTO [ser].[TransactionLineItemMeasure] (TransactionLineItemMeasureId, TransactionLineItemId, MeasureId, Value, LOVUOMId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	DENSE_RANK() OVER(ORDER BY final.TransactionLineItemId, final.MeasureId) TransactionLineItemMeasureId,
		final.TransactionLineItemId TransactionLineItemId,
		final.MeasureId MeasureId,
		final.Value Value,
		final.LOVUOMId LOVUOMId,
		final.LOVRecordSourceId LOVRecordSourceId,
		final.SCDStartDate SCDStartDate,
		final.SCDEndDate SCDEndDate,
		final.SCDActiveFlag SCDActiveFlag,
		final.SCDVersion SCDVersion,
		final.SCDLOVRecordSourceId SCDLOVRecordSourceId,
		final.ETLRunLogId ETLRunLogId,
		final.PSARowKey PSARowKey from
(	
SELECT	A.TransactionLineItemId TransactionLineItemId,
		@th_unitmeasureid MeasureId,
		A.units [Value],
		@th_uomid_unit LOVUOMId,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		A.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.units , src.row_id row_num from [ser].[TransactionLineItem] trln     
JOIN #th_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id 
	and trln.LOVRecordSourceId = src.record_source_id 
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.units is not null and src.units != '') A

UNION

SELECT  B.TransactionLineItemId TransactionLineItemId,
		@th_tispmeasureid MeasureId,
		B.tisp [Value],
		@th_uomid_nonunit LOVUOMId,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		B.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.tisp , src.row_id row_num from [ser].[TransactionLineItem] trln     
JOIN #th_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id 
	and trln.LOVRecordSourceId = src.record_source_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.tisp is not null and src.tisp != '') B

UNION

SELECT  C.TransactionLineItemId TransactionLineItemId,
		@th_tespmeasureid MeasureId,
		C.tesp Value,
		@th_uomid_nonunit LOVUOMId,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		C.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.tesp , src.row_id row_num from [ser].[TransactionLineItem] trln     
JOIN #th_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id  
	and trln.LOVRecordSourceId = src.record_source_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.tesp is not null and src.tesp != '') C

UNION

SELECT  D.TransactionLineItemId TransactionLineItemId,
		@th_eposmeasureid MeasureId,
		D.epos_profit Value,
		@th_uomid_nonunit LOVUOMId,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		D.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.epos_profit , src.row_id row_num from [ser].[TransactionLineItem] trln  
JOIN #th_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id  
	and trln.LOVRecordSourceId = src.record_source_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.epos_profit is not null and src.epos_profit != '') D

UNION

SELECT  E.TransactionLineItemId TransactionLineItemId,
		@th_discmeasureid MeasureId,
		E.discount_applied Value,
		@th_uomid_nonunit LOVUOMId,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		E.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.discount_applied , src.row_id row_num from [ser].[TransactionLineItem] trln     
JOIN #th_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id  
	and trln.LOVRecordSourceId = src.record_source_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.discount_applied is not null and src.discount_applied != '') E
)final;

RAISERROR ('Completed insertion of THAILAND source data to TRANSACTIONLINEITEMMEASURE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 11.Table Name : TransactionLineItemIndicator */

SET @th_indicatorid = (SELECT lovid from ser.reflovsetinfo where lovkey='prescription' and LOVsetname = 'Indicator - Thailand Transaction');

INSERT INTO [ser].[TransactionLineItemIndicator] (TransactionLineItemId, LOVIndicatorId, [Value], LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  A.TransactionLineItemId TransactionLineItemId,
		@th_indicatorid LOVIndicatorId,
		(case when upper(A.prescription) = 'Y' or upper(A.prescription) = 'YES' then 'Y' else 'N' end) [VALUE],
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		A.row_num PSARowKey from
(
SELECT trln.TransactionLineItemId, src.prescription, src.record_source_id, src.row_id row_num from 
(SELECT prescription, record_source_id, row_id from #th_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	and prescription IS NOT NULL and prescription != '') src
JOIN [ser].[TransactionLineItem] trln on 
	trln.PSARowKey = src.row_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	and trln.LOVRecordSourceId = 12010
) A;

RAISERROR ('Completed insertion of THAILAND source data to TransactionLineItemIndicator table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 12.Table Name : LoyaltyAccount */

SET @max_loyaltyacctid = (SELECT COALESCE(MAX(LoyaltyAccountId),0) FROM  [ser].[LoyaltyAccount]);

INSERT INTO [ser].[LoyaltyAccount] (LoyaltyAccountId,LOVLoyaltyProgramId,SourceKey,LOVRecordSourceId,SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	@max_loyaltyacctid + ROW_NUMBER() OVER(ORDER BY final.lovid, final.SourceKey ASC) LoyaltyAccountId, 
		final.lovid LOVLoyaltyProgramId,
		final.SourceKey SourceKey,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
SELECT M.lovid, M.sourcekey, M.date_row row_num from 
(
SELECT rlov.lovid lovid, B.customer_identifier sourcekey, B.record_source_id, MIN(B.row_id) date_row 
from (SELECT * from ser.reflovsetinfo where LOVsetname = 'customer_identifier_type' and LOVRecordSourceId = 12010)rlov 
JOIN 
(
SELECT (CASE WHEN (trim(A.customer_identifier_type) = '' OR A.customer_identifier_type IS NULL OR trim(A.customer_identifier_type) = 'NULL') THEN 'Unknown'
ELSE A.customer_identifier_type END) lovkey, A.customer_identifier, A.row_id, A.record_source_id from
(select * from #th_crp_item_transaction_tmp where row_status=@psa_rowstatus
	and customer_identifier IS NOT NULL and TRIM(customer_identifier) != '' and trim(customer_identifier) != 'NULL'
) A
) B on 
	rlov.lovkey = B.lovkey
	GROUP BY rlov.lovid, B.customer_identifier,B.record_source_id
) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T 
	on M.lovid=T.LOVLoyaltyProgramId 
	and M.SourceKey=T.SourceKey 
	and M.record_source_id=T.LOVRecordSourceId 
	where LOVLoyaltyProgramId IS NULL

UNION

SELECT M.lovid, M.sourcekey, M.date_row row_num from 
(
SELECT rlov.lovid lovid, B.customer_number sourcekey, B.record_source_id, MIN(B.row_id) date_row 
from (SELECT * from ser.reflovsetinfo where LOVsetname = 'customer_number_type' and LOVRecordSourceId = 12010)rlov 
JOIN 
(
SELECT (CASE WHEN (trim(A.customer_number_type) = '' OR A.customer_number_type IS NULL OR trim(A.customer_number_type) = 'NULL') THEN 'Unknown'
ELSE A.customer_number_type END) lovkey, A.customer_number, A.row_id, A.record_source_id from
(select * from #th_crp_item_transaction_tmp where row_status= @psa_rowstatus
	and customer_number IS NOT NULL and TRIM(customer_number) != '' and trim(customer_number) != 'NULL'
) A
) B on 
	rlov.lovkey = B.lovkey
	GROUP BY rlov.lovid, B.customer_number,B.record_source_id
) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T 
	on M.lovid=T.LOVLoyaltyProgramId 
	and M.SourceKey=T.SourceKey 
	and M.record_source_id=T.LOVRecordSourceId 
	where LOVLoyaltyProgramId IS NULL

UNION

SELECT M.lovid, M.sourcekey, M.date_row row_num from 
(
SELECT rlov.lovid lovid, B.other_customer_id sourcekey, B.record_source_id, MIN(B.row_id) date_row 
from (SELECT * from ser.reflovsetinfo where LOVsetname = 'other_customer_id_type' and LOVRecordSourceId = 12010)rlov 
JOIN 
(
SELECT (CASE WHEN (trim(A.other_customer_id_type) = '' OR A.other_customer_id_type IS NULL OR trim(A.other_customer_id_type) = 'NULL') THEN 'Unknown'
ELSE A.other_customer_id_type END) lovkey, A.other_customer_id, A.row_id, A.record_source_id from
(select * from #th_crp_item_transaction_tmp where row_status= @psa_rowstatus
	and other_customer_id IS NOT NULL and TRIM(other_customer_id) != '' and trim(other_customer_id) != 'NULL'
) A
) B on 
	rlov.lovkey = B.lovkey
	GROUP BY rlov.lovid, B.other_customer_id,B.record_source_id
) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T 
	on M.lovid=T.LOVLoyaltyProgramId 
	and M.SourceKey=T.SourceKey 
	and M.record_source_id=T.LOVRecordSourceId 
	where LOVLoyaltyProgramId IS NULL

) final;

RAISERROR ('Completed insertion of THAILAND source data to LOYALTYACCOUNT table', 0, 1) WITH NOWAIT;


/*************************************************************************************************************************************************************/

/* 13.Table Name : TransactionLoyaltyAccount */

INSERT INTO [ser].[TransactionLoyaltyAccount] (TransactionId, LoyaltyAccountId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	final.TransactionId TransactionId, 
		final.loyaltyaccountid LoyaltyAccountId,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--final.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
/*--- Customer Identifier ---*/
SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, M.date_row row_num from 
[ser].[LoyaltyAccount] LA 
JOIN 
(SELECT B.TransactionId, rlov.lovid lovid, B.customer_identifier sourcekey, B.record_source_id, MIN(B.date_row) date_row from 
(SELECT * from ser.reflovsetinfo where LOVsetname = 'customer_identifier_type' and LOVRecordSourceId = 12010)rlov
JOIN 
(
SELECT (CASE WHEN (trim(A.customer_identifier_type) = '' OR A.customer_identifier_type IS NULL OR trim(A.customer_identifier_type) = 'NULL') THEN 'Unknown'
ELSE A.customer_identifier_type END) lovkey, A.customer_identifier, A.date_row, A.record_source_id, A.Transactionid from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_identifier_type, src.customer_identifier, src.row_id date_row,src.record_source_id from 
[ser].[Transaction] trnx
JOIN 
(SELECT M.transaction_key, M.row_id, M.transaction_date, M.transaction_time, M.customer_identifier, M.customer_identifier_type, M.record_source_id from
(select * from #th_crp_item_transaction_tmp where row_status=@psa_rowstatus
	and customer_identifier IS NOT NULL and TRIM(customer_identifier) != '' and trim(customer_identifier) != 'NULL'
) M
)src  
	on trnx.sourcekey = src.transaction_key 
	and trnx.lovrecordsourceid = 12010 
	and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime  
) A
) B 
	on rlov.lovkey = B.lovkey
	GROUP BY B.TransactionId, rlov.lovid, B.customer_identifier,B.record_source_id
)M 
	on LA.LOVLoyaltyProgramId = M.lovid 
	and LA.sourcekey = M.sourcekey 
	and LA.SCDActiveFlag = 'Y'
) P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

UNION

/*--- Customer Number ---*/
SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, M.date_row row_num from 
[ser].[LoyaltyAccount] LA 
JOIN 
(SELECT B.TransactionId, rlov.lovid lovid, B.customer_number sourcekey, B.record_source_id, MIN(B.date_row) date_row from 
(SELECT * from ser.reflovsetinfo where LOVsetname = 'customer_number_type' and LOVRecordSourceId = 12010)rlov
JOIN 
(
SELECT (CASE WHEN (trim(A.customer_number_type) = '' OR A.customer_number_type IS NULL OR trim(A.customer_number_type) = 'NULL') THEN 'Unknown'
ELSE A.customer_number_type END) lovkey, A.customer_number, A.date_row, A.record_source_id, A.Transactionid from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_number_type, src.customer_number, src.row_id date_row,src.record_source_id from 
[ser].[Transaction] trnx
JOIN 
(SELECT M.transaction_key, M.row_id, M.transaction_date, M.transaction_time, M.customer_number, M.customer_number_type, M.record_source_id from
(select * from #th_crp_item_transaction_tmp where row_status=@psa_rowstatus
	and customer_number IS NOT NULL and TRIM(customer_number) != '' and trim(customer_number) != 'NULL'
) M
)src  
	on trnx.sourcekey = src.transaction_key 
	and trnx.lovrecordsourceid = 12010 
	and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime 
) A
) B 
	on rlov.lovkey = B.lovkey
	GROUP BY B.TransactionId, rlov.lovid, B.customer_number,B.record_source_id
)M 
	on LA.LOVLoyaltyProgramId = M.lovid 
	and LA.sourcekey = M.sourcekey 
	and LA.SCDActiveFlag = 'Y'
) P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

UNION

/*--- Other Customer Id ---*/
SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, M.date_row row_num from 
[ser].[LoyaltyAccount] LA 
JOIN 
(SELECT B.TransactionId, rlov.lovid lovid, B.other_customer_id sourcekey, B.record_source_id, MIN(B.date_row) date_row from 
(SELECT * from ser.reflovsetinfo where LOVsetname = 'other_customer_id_type' and LOVRecordSourceId = 12010)rlov
JOIN 
(
SELECT (CASE WHEN (trim(A.other_customer_id_type) = '' OR A.other_customer_id_type IS NULL OR trim(A.other_customer_id_type) = 'NULL') THEN 'Unknown'
ELSE A.other_customer_id_type END) lovkey, A.other_customer_id, A.date_row, A.record_source_id, A.Transactionid from
(SELECT trnx.TransactionId, trnx.sourcekey, src.other_customer_id_type, src.other_customer_id, src.row_id date_row,src.record_source_id from 
[ser].[Transaction] trnx
JOIN 
(SELECT M.transaction_key, M.row_id, M.transaction_date, M.transaction_time, M.other_customer_id, M.other_customer_id_type, M.record_source_id from
(select * from #th_crp_item_transaction_tmp where row_status=@psa_rowstatus
	and other_customer_id IS NOT NULL and TRIM(other_customer_id) != '' and trim(other_customer_id) != 'NULL'
) M
)src  
	on trnx.sourcekey = src.transaction_key 
	and trnx.lovrecordsourceid = 12010 
	and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime 
) A
) B 
	on rlov.lovkey = B.lovkey
	GROUP BY B.TransactionId, rlov.lovid, B.other_customer_id,B.record_source_id
)M 
	on LA.LOVLoyaltyProgramId = M.lovid 
	and LA.sourcekey = M.sourcekey 
	and LA.SCDActiveFlag = 'Y'
) P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

)final;

RAISERROR ('Completed insertion of THAILAND source data to TRANSACTIONLOYALTYACCOUNT table', 0, 1) WITH NOWAIT;


/*************************************************************************************************************************************************************/

/* 14.Table Name : TransactionGroup */

SET @max_trangroupid = (SELECT COALESCE(MAX(TransactionGroupId),0) FROM  [ser].[TransactionGroup]);
SET @th_trangroupsetid = (select distinct lovsetid from ser.reflovsetinfo where LOVsetname = 'sales_type' and lovrecordsourceid = 12010); 

INSERT INTO [ser].[TransactionGroup] (TransactionGroupId, TransactionId, LOVTransactionGroupSetId, LOVGroupId, ParentTransactionGroupId, LOVRecordSourceId,  SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_trangroupid + ROW_NUMBER() OVER(ORDER BY A.TransactionId ASC) TransactionGroupId, 
		A.TransactionId TransactionId,
		@th_trangroupsetid LOVTransactionGroupSetId, 
		A.lovid LOVGroupId, 
		null ParentTransactionGroupId, 
		12010 LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.row_num PSARowKey from
(
SELECT T.TransactionId, src.row_num, R.lovid from 
(SELECT M.transaction_key, M.till_id, M.store_number, M.transaction_date, M.transaction_time, M.sales_type, M.row_num from
(SELECT transaction_key, store_number, till_id, transaction_date, transaction_time, record_source_id, sales_type, MIN(row_id) row_num,
ROW_NUMBER() OVER(PARTITION BY transaction_key, store_number, till_id, transaction_date, transaction_time, record_source_id ORDER BY sales_type ASC) key_seq 
from #th_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	and sales_type is not null and sales_type != '' 
	group by transaction_key, store_number, till_id, transaction_date, transaction_time, record_source_id, sales_type
) M
where M.key_seq = 1
)src
JOIN [ser].[TRANSACTION] T 
	on T.LOVRecordSourceId = 12010 
	and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = T.TransactionDatetime 
	and	src.transaction_key = T.sourcekey
JOIN ser.reflovsetinfo R 
	on	R.lovkey = src.sales_type 
	and R.lovsetid = @th_trangroupsetid
LEFT OUTER JOIN [ser].[TransactionGroup] TG 
	on 	T.TransactionId = TG.TransactionId 
	and T.LOVRecordSourceId = TG.LOVRecordSourceId 
	and	@th_trangroupsetid = TG.LOVTransactionGroupSetId
	where TG.TransactionId IS NULL
) A ;


RAISERROR ('Completed insertion of THAILAND source data to TRANSACTIONGROUP table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 14.Table Name : psa.th_crp_item_transaction */
/* Update the row_status in the psa.th_crp_item_transaction from 26001(PSA) to 26002(SERVE) */

UPDATE psa.th_crp_item_transaction
SET row_status = @ser_rowstatus
where row_status = @psa_rowstatus and row_id in 
(select psarowkey from ser.transactionlineitem where lovrecordsourceid = 12010 and ETLRunLogId = @serveETLRunLogID) ;

RAISERROR ('Completed updating the row_status from 26001(PSA) to 26002(SERVE) in psa.th_crp_item_transaction', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
DECLARE @error_num varchar(max),
		@error_msg varchar(max),
		@error_sev varchar(max)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

END;
GO
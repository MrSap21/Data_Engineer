IF OBJECT_ID('psa.sp_uk_abacus_header') IS NOT NULL
BEGIN
    DROP PROC psa.sp_uk_abacus_header
END;


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
************************************************************************************************************
Procedure Name			: sp_uk_abacus_header
Purpose					: Load History data from sapbw header feed(IF_01111_HEADER) into Serve Layer Table
Domain					: Transaction
RecordSourceID  for sapbw Transaction	: 12006

**************************************************************************************************************
*/

CREATE PROC [psa].[sp_uk_abacus_header] (@serveETLRunLogID varchar(max), @tablename varchar(max), @psaEntityId varchar(max)) AS

DECLARE 	@uklc_lovRecordSourceID 				BIGINT, 
			@uklc_scdLovRecordSourceID 				BIGINT, 
			@psa_rowstatus 							BIGINT, 
			@ser_rowstatus 							BIGINT,
			@max_tillid 							BIGINT,
			@max_siteroleid 						BIGINT, 
			@uklc_Siteid 							BIGINT, 
			@uklc_RoleId 							BIGINT,
			@max_transactionid 						BIGINT,
			@uklc_trantypeid 						BIGINT,
			@uklc_indicatorid 						BIGINT,
			@mdm_lovRecordSourceID  	 			BIGINT,
			@max_trangroupid						BIGINT,
			@uk_trangroupsetid						BIGINT,
			@source_db								VARCHAR(80),
			@source_table							VARCHAR(200),
			@feed_entityid 							BIGINT,
			@ruleId 								BIGINT,
			@attributeid 							BIGINT;
			
BEGIN		

SET @uklc_lovRecordSourceID = 12006; 
SET @uklc_scdLovRecordSourceID = 12006; 
SET @psa_rowstatus = 26001; 
SET @ser_rowstatus = 26002;
SET @feed_entityid = (select sourceentityid from psa.[MappingEntity] me inner join psa.[Entity] e on me.sourceentityid = e.EntityID where me.[TargetEntityID] = @psaEntityId and e.SchemaName like '%feed%');
--SET @serveETLRunLogID = 12345;
SET	@mdm_lovRecordSourceID = 12008;
--SET @source_db = psa;
--SET @source_table = source_table_name;

/* Creation of temporary table to store records wit rowstatus 26001 and record_type ='2' from PSA Source table */

    IF OBJECT_ID('tempdb..#uk_abacus_header_tmp') IS NOT NULL
    BEGIN
        DROP TABLE #uk_abacus_header_tmp
    END
    
    SELECT * INTO #uk_abacus_header_tmp FROM 
	(SELECT 
		row_id,record_type,
		ISNULL( NULLIF((Substring(STORE_NUMBER, Patindex('%[^0]%', STORE_NUMBER + ' '), Len(STORE_NUMBER)) ),''),0) STORE_NUMBER,
		ISNULL( NULLIF((Substring(TILL_NUMBER, Patindex('%[^0]%', TILL_NUMBER + ' '), Len(TILL_NUMBER)) ),''),0) TILL_NUMBER,
		TILL_TXN_NUMBER,TILL_TXN_DATE,TILL_TXN_TIME,EPOS_TXN_TYPE_FLAG,OPERATOR_ID,CARD_NUMBER,DISC_CARD_USER_FLG,DISC_CARD_NUMBER,ALL_IT_PTS_MULT_PC,BTC_IT_PTS_MULT_PC,SIGN,POINTS_CHANGE,
		MAIN_PAYMENT_METH,VALIDATION_BARCODE,CHANNEL,SUBCHANNEL,TRANSACTION_QUALIFIED_FLAG,ERROR_IND,ADCARD_PRESENTATION_METHOD,etl_runlog_id,asset_id,record_source_id,row_status,created_timestamp,active_flag
		FROM psa.uk_abacus_header 
		WHERE row_status = @psa_rowstatus 
		and record_type = '2'    
    )A;

RAISERROR ('Completed insertion of TEMP IF_01111_HEADER PSA table', 0, 1) WITH NOWAIT;

/* Updating the temporary table to change the date format from dd/mm/yyyy to yyyy-mm-dd to avoid time format issues */

	UPDATE #uk_abacus_header_tmp
	SET till_txn_date = concat(substring (till_txn_date,7,4),substring (till_txn_date,4,2),substring (till_txn_date,1,2))
	
RAISERROR ('Completed updation of TEMP IF_01111_HEADER PSA table', 0, 1) WITH NOWAIT;

BEGIN TRY
	BEGIN TRANSACTION
	
/*--- update the source table with row_status=8888 if that card_number could not be found in ser.LoyaltyAccountCard ---*/

update #uk_abacus_header_tmp	
SET row_status = 8888
FROM #uk_abacus_header_tmp tmp
JOIN 
(SELECT * from 
(select * from #uk_abacus_header_tmp where row_status = @psa_rowstatus and card_number is not null and card_number != '') src
LEFT OUTER JOIN ser.LoyaltyAccountCard LC on
	LC.sourcekey = src.card_number 
	and LC.lovrecordsourceid = 12011
	where LC.sourcekey is null
)M
on M.row_id = tmp.row_id;
	
RAISERROR ('Completed updating the temp table setting row_status to 8888 if that card_number could not be found in ser.LoyaltyAccountCard', 0, 1) WITH NOWAIT;
	

/*  update the temp table where till_txn_time is null or blank or contains alphabets */

	UPDATE #uk_abacus_header_tmp
	SET till_txn_time = '00:00' where till_txn_time is null or trim(till_txn_time) = '' or till_txn_time like '%[A-Za-z]%';
	
RAISERROR ('Completed updating the temp table where till_txn_time is null or blank or contains alphabets', 0, 1) WITH NOWAIT;


/*--- Insert records into RuleEntityInstance for those records with invalid till_txn_time ---*/

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Time Check' AND RuleCode = 'TC');
--SET @entityId = (SELECT EntityID FROM psa.[Entity] WHERE SchemaName like '%Feed%' AND EntityName = 'IF_01111_HEADER_Incremental_Load_txt');
SET @attributeid = (select attributeid from psa.attribute  where entityid = @feed_entityid and trim(AttributeName) = 'till_txn_time');

INSERT INTO psa.RuleEntityInstance(
               --RuleEntityInstanceID
               RuleID
               ,EntityID
               ,AttributeID
               ,RuleDetail
               ,ETLRunLogID
               ,SourceEntityID
               ,SourceAttributeID
               ,psarowkey
               ,DTCreated
               ,UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY A.row_id ASC) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--till_txn_time--Record created for invalid till_txn_time' RuleDetail,
A.etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
A.row_id psarowkey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM psa.uk_abacus_header 
	WHERE (till_txn_time LIKE '%[A-Za-z]%' OR till_txn_time IS NULL OR TRIM(till_txn_time) = '') 
	AND row_status = @psa_rowstatus) A

UNION

SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY A.row_id ASC) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--till_txn_time--Record created for invalid till_txn_time' RuleDetail,
A.etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
A.row_id psarowkey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM #uk_abacus_header_tmp 
	WHERE cast(substring(trim(till_txn_time),1,2) as int) > 23 or cast(substring(trim(till_txn_time),4,2) as int) > 59) A;
	
RAISERROR ('Completed insertion of UK HEADER source data to RULEENTITYINSTANCE table for invalid till_txn_time', 0, 1) WITH NOWAIT;

/*  update the temp table where till_txn_time_hour > 23 OR till_txn_time_minute > 59 */

	UPDATE #uk_abacus_header_tmp
	SET till_txn_time = '00:00' where cast(substring(trim(till_txn_time),1,2) as int) > 23 or cast(substring(trim(till_txn_time),4,2) as int) > 59;

RAISERROR ('Completed updating the temp table where transaction_time_hour > 23 OR transaction_time_minute > 59', 0, 1) WITH NOWAIT;
	
/* ---------------------------------------------------    PSA to SERVE loading starts    -------------------------------------------------------------- */

/* 1.Table Name : Till */

SET @max_tillid = (SELECT COALESCE(MAX(TillId),0) FROM  [ser].[Till]);

INSERT INTO [ser].[Till] (TillId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_tillid + ROW_NUMBER() OVER(ORDER BY A.till_number ASC) TillId, 
		A.till_number SourceKey, 
		@uklc_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(
SELECT src.till_number, src.date_row from 
(SELECT till_number, record_source_id, MIN(row_id) date_row from #uk_abacus_header_tmp 
	where row_status = @psa_rowstatus 
	--and till_number IS NOT NULL and till_number != '' 
	GROUP BY till_number,record_source_id)src 
LEFT OUTER JOIN [ser].[Till] slf 
	on src.till_number = slf.sourcekey and src.record_source_id = slf.LOVRecordSourceId 
	where slf.sourcekey IS NULL 
)A ;

RAISERROR ('Completed insertion of SAPBW source data to TILL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 2.Table Name : Site_Role */

SET @max_siteroleid = (SELECT COALESCE(MAX(SiteRoleId),0) FROM  [ser].[SiteRole]);
SET @uklc_SiteId = (select siteid from ser.[site] s where s.sourcekey = '0' and lovrecordsourceid = 12012 and SCDActiveFlag = 'Y'
				and lovsitetypeid = (select lovid from ser.reflovsetinfo where lovkey='0' and LOVsetname = 'Site Type'));
SET @uklc_RoleId = (select lovid from ser.reflovsetinfo where lovkey='Store' and LOVsetname = 'Role');

INSERT INTO [ser].[Siterole] (SiteRoleId, SiteId, LOVRoleId, SourceKey, SiteRoleName, SiteRoleShortName, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT S.* from
(
/*--- Inserting records for NEW business keys ---*/
SELECT  @max_siteroleid + ROW_NUMBER() OVER(ORDER BY A.sourcekey ASC) SiteRoleId, 
		isnull(@uklc_SiteId,9999) SiteId,   
		@uklc_RoleId LOVRoleId, 
		A.sourcekey SourceKey, 
		NULL SiteRoleName, 
		NULL SiteRoleShortName, 
		12008 LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion,  
		12008 SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(
SELECT src.sourcekey, src.date_row from 
(SELECT store_number sourcekey, record_source_id, MIN(row_id) date_row 
from #uk_abacus_header_tmp 
	where row_status = @psa_rowstatus
	GROUP BY store_number,record_source_id)src
LEFT OUTER JOIN [ser].[Siterole] slf 
	on src.sourcekey = slf.sourcekey 
	and slf.LOVRecordSourceId = 12008 
	where slf.sourcekey IS NULL
)A 

UNION

/*--- Inserting records for EXISTING business keys which encountered soft delete ---*/
SELECT  A.SiteRoleId SiteRoleId, 
		@uklc_SiteId SiteId,   
		@uklc_RoleId LOVRoleId, 
		A.sourcekey SourceKey, 
		NULL SiteRoleName, 
		NULL SiteRoleShortName, 
		12008 LOVRecordSourceId, 
		current_timestamp SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		A.new_SCDVersion SCDVersion,  
		12008 SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(
SELECT slf.SiteRoleId, (slf.SCDVersion + 1) new_SCDVersion, src.sourcekey, src.date_row from 
(SELECT store_number sourcekey, record_source_id, MIN(row_id) date_row 
from #uk_abacus_header_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY store_number,record_source_id)src
JOIN (Select B.* from 
(Select *, RANK() OVER(partition by sourcekey,lovrecordsourceid order by sourcekey,lovrecordsourceid,SCDVersion desc) row_num from  
[ser].[SiteRole] 	where lovrecordsourceid = 12008) B where B.row_num = 1 and B.SCDActiveFlag = 'N'
) slf 
	on src.sourcekey = slf.sourcekey 
)A 
)S;

RAISERROR ('Completed insertion of SAPBW source data to SITEROLE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/*--- Insert records into RuleEntityInstance for those store_number which are new or which have encountered soft delete ---*/

--DECLARE @max_ruleentityinstanceid BIGINT;
--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Skeleton Record Creation' AND RuleCode = 'SRC');
--SET @entityId = (SELECT EntityID FROM psa.[Entity] WHERE SchemaName like '%Feed%' AND EntityName = 'IF_01111_HEADER_Incremental_Load_txt');
SET @attributeid = (select attributeid from psa.attribute  where entityid = @feed_entityid and trim(AttributeName) = 'store_number');

INSERT INTO psa.RuleEntityInstance(
               --RuleEntityInstanceID
               RuleID
               ,EntityID
               ,AttributeID
               ,RuleDetail
               ,ETLRunLogID
               ,SourceEntityID
               ,SourceAttributeID
               ,psarowkey
               ,DTCreated
               ,UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() OVER(ORDER BY sourcekey ASC) RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--SiteRoleId--Record created for Store number due to non existence of SiteRoleId' RuleDetail,
etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id psarowkey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT * FROM ser.SiteRole WHERE LOVRecordSourceId = 12008 AND ETLRunLogId = @serveETLRunLogID AND SCDActiveFlag = 'Y') siterole
JOIN #uk_abacus_header_tmp noitemtrans
	ON noitemtrans.store_number = siterole.sourcekey
	AND noitemtrans.row_id = siterole.psarowkey


RAISERROR ('Completed insertion of SAPBW source data to RULEENTITYINSTANCE table for new store_number', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 3.Table Name : Transaction */

SET @max_transactionid = (SELECT COALESCE(MAX(TransactionId),0) FROM  [ser].[Transaction]);
SET @uklc_trantypeid = (select lovid from ser.reflovsetinfo where lovkey='RETAIL' and LOVsetname = 'Transaction Type'); 


INSERT INTO [ser].[Transaction]
(TransactionId, SourceKey, LOVTransactionTypeId, SiteRoleId, TransactionDatetime, TillId, TillTransactionNumber, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_transactionid + ROW_NUMBER() OVER(ORDER BY trnx.siteroleid, trnx.till_txn_date, trnx.till_txn_time, trnx.tillid, trnx.till_txn_number ASC) TransactionId, 
		NULL SourceKey, 
		@uklc_trantypeid LOVTransactionTypeId, 
		trnx.SiteRoleId SiteRoleId, 
		CAST (CONCAT(trnx.till_txn_date,' ',trnx.till_txn_time) as Datetime) TransactionDatetime, 
		trnx.tillId TillId, 
		trnx.till_txn_number TillTransactionNumber, 
		@uklc_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		trnx.row_num PSARowKey from 
(
SELECT P.siteroleid, P.till_txn_date, 
P.till_txn_time, 
P.tillid, P.record_source_id, P.row_num, P.till_txn_number from
(SELECT B.siteroleid, src.till_txn_date, src.till_txn_time,till.tillid, src.record_source_id, src.till_txn_number, row_num from 
(SELECT store_number, till_txn_date, till_txn_time, till_number,till_txn_number, record_source_id, MIN(row_id) row_num  
from #uk_abacus_header_tmp  
	where row_status = @psa_rowstatus 
	GROUP BY store_number, till_txn_date, till_txn_time, till_number,till_txn_number, record_source_id) src 
JOIN (SELECT SiteRoleId, sourcekey from [ser].[Siterole] where lovrecordsourceid = 12008 and SCDActiveFlag = 'Y')B on
	B.sourcekey = src.store_number and 
	12006 = src.record_source_id
LEFT OUTER JOIN (SELECT * from [ser].[Till] where LOVRecordSourceID = 12006 and SCDActiveFlag = 'Y') till on
	src.till_number = till.sourcekey and 
	till.lovrecordsourceid = src.record_source_id
) P
LEFT OUTER JOIN [ser].[Transaction] T on 
	--isnull(P.till_txn_number,'dummyval') = isnull(T.TillTransactionNumber,'dummyval') and 
	P.till_txn_number = T.TillTransactionNumber and
	CAST (CONCAT(P.till_txn_date,' ',P.till_txn_time) as Datetime) = T.TransactionDatetime and 
	P.record_source_id = T.LOVRecordSourceId
	and P.tillid = T.tillid
	and P.siteroleid = T.siteroleid
	where T.TillTransactionNumber IS NULL
)trnx ;


RAISERROR ('Completed insertion of SAPBW source data to TRANSACTION table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/


/* 4.Table Name : TransactionGroup */

SET @max_trangroupid = (SELECT COALESCE(MAX(TransactionGroupId),0) FROM  [ser].[TransactionGroup]);
SET @uk_trangroupsetid = (select distinct lovsetid from ser.reflovsetinfo where LOVsetname = 'till_transaction_type_code' and lovrecordsourceid = 12006); 

INSERT INTO [ser].[TransactionGroup] (TransactionGroupId, TransactionId, LOVTransactionGroupSetId, LOVGroupId, ParentTransactionGroupId, LOVRecordSourceId,  SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_trangroupid + ROW_NUMBER() OVER(ORDER BY A.TransactionId ASC) TransactionGroupId, 
		A.TransactionId TransactionId,
		@uk_trangroupsetid LOVTransactionGroupSetId, 
		A.lovid LOVGroupId, 
		null ParentTransactionGroupId, 
		12006 LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.row_num PSARowKey from
(
SELECT T.TransactionId, src.row_num, R.lovid from 
(SELECT M.till_number, M.store_number, M.till_txn_date, M.till_txn_time, M.till_txn_number, M.EPOS_TXN_TYPE_FLAG, M.row_num, S.SiteRoleId, TL.TillId from
(SELECT store_number, till_number, till_txn_date, till_txn_time, till_txn_number, record_source_id, EPOS_TXN_TYPE_FLAG, MIN(row_id) row_num,
ROW_NUMBER() OVER(PARTITION BY store_number, till_number, till_txn_date, till_txn_time, till_txn_number, record_source_id ORDER BY EPOS_TXN_TYPE_FLAG ASC) key_seq 
from #uk_abacus_header_tmp 
	where row_status = @psa_rowstatus 
	and EPOS_TXN_TYPE_FLAG is not null and EPOS_TXN_TYPE_FLAG != '' 
	group by store_number, till_number, till_txn_date, till_txn_time, till_txn_number, record_source_id, EPOS_TXN_TYPE_FLAG
) M
JOIN ser.siterole S on
	M.store_number = S.sourcekey and S.lovrecordsourceid = 12008 and S.SCDActiveflag = 'Y'
JOIN ser.till TL on
	M.till_number = TL.sourcekey and TL.lovrecordsourceid = 12006 and S.SCDActiveflag = 'Y'
where M.key_seq = 1
)src
JOIN [ser].[TRANSACTION] T on 
	T.LOVRecordSourceId = 12006 and 
	CAST (CONCAT(src.till_txn_date,' ',src.till_txn_time) as Datetime) = T.TransactionDatetime and 
	--isnull(src.till_txn_number,'dummyval') = isnull(T.TillTransactionNumber,'dummyval') and
	src.till_txn_number = T.TillTransactionNumber and
	src.SiteRoleId = T.SiteRoleId and 
	src.TillId = T.TillId
JOIN ser.reflovsetinfo R on
	R.lovkey = src.EPOS_TXN_TYPE_FLAG and 
	R.lovsetid = @uk_trangroupsetid
LEFT OUTER JOIN [ser].[TransactionGroup] TG on 
	T.TransactionId = TG.TransactionId and 
	T.LOVRecordSourceId = TG.LOVRecordSourceId and
	@uk_trangroupsetid = TG.LOVTransactionGroupSetId
	where TG.TransactionId IS NULL
) A ;


RAISERROR ('Completed insertion of SAPBW source data to TRANSACTIONGROUP table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 5.Table Name : TransactionIndicator */

SET @uklc_indicatorid = (select lovid from ser.reflovsetinfo where lovkey='card_flag' and LOVsetname = 'Indicator - BUK SAP BW Transaction');

INSERT INTO [ser].[TransactionIndicator] (TransactionId, LOVIndicatorId, [Value], LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  A.TransactionId TransactionId,
		@uklc_indicatorid LOVIndicatorId,
		A.card_number [Value],
		12006 LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		A.row_num PSARowKey from 
(
SELECT T.TransactionId, src.row_num, 
case when (src.card_number is not null and src.card_number != '') then 'Y' else 'N' end card_number from 
(SELECT M.till_number, M.store_number, M.till_txn_date, M.till_txn_time, M.till_txn_number, M.card_number, M.row_num, S.SiteRoleId, TL.TillId from
(SELECT store_number, till_number, till_txn_date, till_txn_time, till_txn_number, record_source_id, card_number, MIN(row_id) row_num 
from #uk_abacus_header_tmp 
	where row_status = @psa_rowstatus 
	group by store_number, till_number, till_txn_date, till_txn_time, till_txn_number, record_source_id, card_number
)M
JOIN ser.siterole S on
	M.store_number = S.sourcekey and S.lovrecordsourceid = 12008 and S.SCDActiveflag = 'Y'
JOIN ser.till TL on
	M.till_number = TL.sourcekey and TL.lovrecordsourceid = 12006 and S.SCDActiveflag = 'Y'
)src
JOIN [ser].[TRANSACTION] T on 
	T.LOVRecordSourceId = 12006 and 
	CAST (CONCAT(src.till_txn_date,' ',src.till_txn_time) as Datetime) = T.TransactionDatetime and 
	--isnull(src.till_txn_number,'dummyval') = isnull(T.TillTransactionNumber,'dummyval') and
	src.till_txn_number = T.TillTransactionNumber and
	src.SiteRoleId = T.SiteRoleId and 
	src.TillId = T.TillId
LEFT OUTER JOIN [ser].[TransactionIndicator] TI on 
	T.TransactionId = TI.TransactionId and 
	T.LOVRecordSourceId = TI.LOVRecordSourceId 
	where TI.TransactionId IS NULL
) A ;

RAISERROR ('Completed insertion of SAPBW source data to TRANSACTIONINDICATOR table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 6.Table Name : TransactionLoyaltyAccountCard */

SET @max_trangroupid = (SELECT COALESCE(MAX(TransactionGroupId),0) FROM  [ser].[TransactionGroup]);
SET @uk_trangroupsetid = (select distinct lovsetid from ser.reflovsetinfo where LOVsetname = 'till_transaction_type_code' and lovrecordsourceid = 12006); 

INSERT INTO [ser].[TransactionLoyaltyAccountCard] (TransactionId, LoyaltyAccountCardId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  A.TransactionId TransactionId,
		A.LoyaltyAccountCardId LoyaltyAccountCardId,
		12006 LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.row_num PSARowKey from
(
SELECT T.TransactionId, LC.LoyaltyAccountCardId, src.row_num from 
(SELECT M.till_number, M.store_number, M.till_txn_date, M.till_txn_time, M.till_txn_number, M.card_number, M.row_num, S.SiteRoleId, TL.TillId from
(SELECT store_number, till_number, till_txn_date, till_txn_time, till_txn_number, record_source_id, card_number, MIN(row_id) row_num 
from #uk_abacus_header_tmp 
	where row_status = @psa_rowstatus 
	and card_number is not null and card_number != '' 
	group by store_number, till_number, till_txn_date, till_txn_time, till_txn_number, record_source_id, card_number
) M
JOIN ser.siterole S on
	M.store_number = S.sourcekey and S.lovrecordsourceid = 12008 and S.SCDActiveflag = 'Y'
JOIN ser.till TL on
	M.till_number = TL.sourcekey and TL.lovrecordsourceid = 12006 and S.SCDActiveflag = 'Y'
)src
JOIN [ser].[TRANSACTION] T on 
	T.LOVRecordSourceId = 12006 and 
	CAST (CONCAT(src.till_txn_date,' ',src.till_txn_time) as Datetime) = T.TransactionDatetime and 
	--isnull(src.till_txn_number,'dummyval') = isnull(T.TillTransactionNumber,'dummyval') and
	src.till_txn_number = T.TillTransactionNumber and
	src.SiteRoleId = T.SiteRoleId and 
	src.TillId = T.TillId
JOIN ser.LoyaltyAccountCard LC on
	LC.sourcekey = src.card_number and 
	LC.lovrecordsourceid = 12011
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccountCard] TG on 
	T.TransactionId = TG.TransactionId and 
	T.LOVRecordSourceId = TG.LOVRecordSourceId 
	where TG.TransactionId IS NULL
) A ;


RAISERROR ('Completed insertion of SAPBW source data to TRANSACTIONLOYALTYACCOUNTCARD table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/*--- update the source table with row_status = 26002 for those records which are having row_status = 26001 and entered in ser.transaction table---*/

update #uk_abacus_header_tmp
set row_status = 26002
from #uk_abacus_header_tmp slf
JOIN
( select src.store_number, src.till_number, src.till_txn_date, src.till_txn_time, src.till_txn_number, src.row_id from
(SELECT M.*, S.SiteRoleId, TL.TillId from
(SELECT store_number, till_number, till_txn_date, till_txn_time, till_txn_number, record_source_id, row_id 
from #uk_abacus_header_tmp 
	where row_status = 26001 and record_type = '2'
) M
JOIN ser.siterole S on
	M.store_number = S.sourcekey and S.lovrecordsourceid = 12008 and S.SCDActiveflag = 'Y'
JOIN ser.till TL on
	M.till_number = TL.sourcekey and TL.lovrecordsourceid = 12006 and S.SCDActiveflag = 'Y'
)src
join ser.[Transaction] T on
	T.LOVRecordSourceId = 12006 and 
	CAST (CONCAT(src.till_txn_date,' ',src.till_txn_time) as Datetime) = T.TransactionDatetime and 
	--isnull(src.till_txn_number,'dummyval') = isnull(T.TillTransactionNumber,'dummyval') and
	src.till_txn_number = T.TillTransactionNumber and
	src.SiteRoleId = T.SiteRoleId and 
	src.TillId = T.TillId 
)F 
	on slf.store_number = F.store_number
	and slf.till_number = F.till_number
	--and concat(substring (slf.till_txn_date,7,4),substring (slf.till_txn_date,4,2),substring (slf.till_txn_date,1,2)) = F.till_txn_date
	and slf.till_txn_date = F.till_txn_date
	and slf.till_txn_time = F.till_txn_time
	and slf.till_txn_number = F.till_txn_number
	where slf.row_id = F.row_id
;

RAISERROR ('Update the TEMP table with row_status = 26002 from row_status = 26001', 0, 1) WITH NOWAIT

UPDATE psa.uk_abacus_header
SET row_status = 26002 
where row_id in (Select row_id from #uk_abacus_header_tmp where row_status = 26002)

RAISERROR ('Update the ORIGINAL table with row_status = 26002 from row_status = 26001', 0, 1) WITH NOWAIT

/*--- update the source table with row_status = 26001 for those records which are currently having row_status = 8888 to wait for CRM data to come ---*/
update psa.uk_abacus_header
set row_status = @psa_rowstatus
from psa.uk_abacus_header src
JOIN #uk_abacus_header_tmp tmp
	on tmp.row_id = src.row_id
	where tmp.row_status = 8888;

RAISERROR ('Update the source table with row_status = 26001 from row_status = 8888 to wait for CRM data', 0, 1) WITH NOWAIT

/*************************************************************************************************************************************************************/

COMMIT TRANSACTION
END TRY

BEGIN CATCH
DECLARE @error_num varchar(max),
		@error_msg varchar(max),
		@error_sev varchar(max);

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH



END;
GO
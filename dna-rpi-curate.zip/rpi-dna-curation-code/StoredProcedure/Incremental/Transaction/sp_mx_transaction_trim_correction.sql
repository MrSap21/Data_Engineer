/****** Object:  StoredProcedure [psa].[sp_mx_transaction_trim_correction]    Script Date: 10/29/2020 12:19:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_mx_transaction_trim_correction') IS NOT NULL
BEGIN
	DROP PROC psa.sp_mx_transaction_trim_correction
END
GO

CREATE PROC [psa].[sp_mx_transaction_trim_correction] @serveETLRunLogID [VARCHAR](MAX),@assetID [VARCHAR](MAX),@dateadded [VARCHAR](MAX),@scdlovrecordsource [VARCHAR](MAX) AS

BEGIN		
	
BEGIN TRY	

IF OBJECT_ID('tempdb..#trim_untrim_customer_identifier_tmp') IS NOT NULL
BEGIN
	DROP TABLE #trim_untrim_customer_identifier_tmp
END

IF OBJECT_ID('tempdb..#trim_untrim_customer_number_tmp') IS NOT NULL
BEGIN
	DROP TABLE #trim_untrim_customer_number_tmp
END

IF OBJECT_ID('tempdb..#trim_untrim_other_customer_id_tmp') IS NOT NULL
BEGIN
	DROP TABLE #trim_untrim_other_customer_id_tmp
END

SELECT * INTO #trim_untrim_customer_identifier_tmp FROM
(SELECT DISTINCT customer_identifier_trimmed, customer_identifier FROM psa.rawmx_transaction_custtrim WHERE customer_identifier_trimmed <> customer_identifier
AND asset_id IN (SELECT value FROM STRING_SPLIT(@assetID, ',')) AND row_status = 26001)A;

SELECT * INTO #trim_untrim_customer_number_tmp FROM
(SELECT DISTINCT customer_number_trimmed, customer_number FROM psa.rawmx_transaction_custtrim WHERE customer_number_trimmed <> customer_number
AND asset_id IN (SELECT value FROM STRING_SPLIT(@assetID, ',')) AND row_status = 26001)A;

SELECT * INTO #trim_untrim_other_customer_id_tmp FROM
(SELECT DISTINCT other_customer_id_trimmed, other_customer_id FROM psa.rawmx_transaction_custtrim WHERE other_customer_id_trimmed <> other_customer_id
AND asset_id IN (SELECT value FROM STRING_SPLIT(@assetID, ',')) AND row_status = 26001)A;

RAISERROR ('Completed creation of tmp tables trim and untrim values', 0, 1) WITH NOWAIT;

UPDATE psa.rawmx_crp_item_transaction
SET customer_identifier = citmp.customer_identifier_trimmed
FROM psa.rawmx_crp_item_transaction mxitem
JOIN #trim_untrim_customer_identifier_tmp citmp
ON citmp.customer_identifier = mxitem.customer_identifier
;

RAISERROR ('Completed updation of customer_identifier in MEXICO PSA table', 0, 1) WITH NOWAIT;

UPDATE psa.rawmx_crp_item_transaction
SET customer_number = cntmp.customer_number_trimmed
FROM psa.rawmx_crp_item_transaction mxitem
JOIN #trim_untrim_customer_number_tmp cntmp
ON cntmp.customer_number = mxitem.customer_number
;

RAISERROR ('Completed updation of customer_number in MEXICO PSA table', 0, 1) WITH NOWAIT;

UPDATE psa.rawmx_crp_item_transaction
SET other_customer_id = octmp.other_customer_id_trimmed
FROM psa.rawmx_crp_item_transaction mxitem
JOIN #trim_untrim_other_customer_id_tmp octmp
ON octmp.other_customer_id = mxitem.other_customer_id
;

RAISERROR ('Completed updation of other_customer_id in MEXICO PSA table', 0, 1) WITH NOWAIT;


DECLARE @max_loyaltyAccountID BIGINT;
SELECT  @max_loyaltyAccountID = COALESCE(MAX(LoyaltyAccountId),0) FROM ser.LoyaltyAccount;

IF OBJECT_ID('tempdb..#mx_crp_item_transaction_tmp') IS NOT NULL
BEGIN
	DROP TABLE #mx_crp_item_transaction_tmp
END
	
SELECT * INTO #mx_crp_item_transaction_tmp
FROM (SELECT * FROM psa.rawmx_crp_item_transaction WHERE date_added = @dateadded 
)A;

RAISERROR ('Completed creation of tmp PSA table', 0, 1) WITH NOWAIT;


IF OBJECT_ID('tempdb..#transactionloyaltyaccount_update_temp') IS NOT NULL
BEGIN
	DROP TABLE #transactionloyaltyaccount_update_temp
END


SELECT * INTO #transactionloyaltyaccount_update_temp FROM
(SELECT tla.*, 
CASE WHEN customer_identifier_type IS NULL OR TRIM(customer_identifier_type) = '' OR TRIM(customer_identifier_type) = 'NULL' THEN 'Unknown' ELSE customer_identifier_type END customer_identifier_type,
CASE WHEN customer_number_type IS NULL OR TRIM(customer_number_type) = '' OR TRIM(customer_number_type) = 'NULL' THEN 'Unknown' ELSE customer_number_type END customer_number_type,
CASE WHEN other_customer_id_type IS NULL OR TRIM(other_customer_id_type) = '' OR TRIM(other_customer_id_type) = 'NULL' THEN 'Unknown' ELSE other_customer_id_type END other_customer_id_type 
FROM
(SELECT * FROM ser.TransactionLoyaltyAccount WHERE lovrecordsourceid = 12004) tla
JOIN (SELECT * FROM ser.[Transaction] WHERE lovrecordsourceid = 12004) t 
ON t.transactionid = tla.transactionid
JOIN (SELECT * FROM ser.SiteRole WHERE lovrecordsourceid = 12004 AND SCDActiveFlag = 'Y') s
ON s.siteroleid = t.siteroleid
JOIN (SELECT distinct transaction_key, store_number, transaction_date, transaction_time, customer_identifier_type, customer_number_type, other_customer_id_type FROM psa.rawmx_transaction_custtrim
WHERE asset_id IN (SELECT value FROM STRING_SPLIT(@assetID, ',')) AND row_status = 26001) np
ON np.transaction_key = t.sourceKey
AND np.store_number = s.sourceKey
AND CONVERT(datetime, CONCAT(SUBSTRING(np.transaction_date,1,4),'-',SUBSTRING(np.transaction_date,5,2),'-',SUBSTRING(np.transaction_date,7,2),' ',np.transaction_time,':00'),120) = t.transactiondatetime
)Z;

RAISERROR ('Completed creation of tmp table transactionloyaltyaccount', 0, 1) WITH NOWAIT;

BEGIN TRANSACTION;

INSERT INTO ser.LoyaltyAccount(
	LoyaltyAccountId 				,
	LOVLoyaltyProgramId				,
	SourceKey						,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

SELECT @max_loyaltyAccountID+ROW_NUMBER() OVER(ORDER BY LOVLoyaltyProgramId, SourceKey) LoyaltyAccountId,
LOVLoyaltyProgramId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey
FROM
(
SELECT 
LOVId LOVLoyaltyProgramId, 
customer_identifier SourceKey, 
12004 LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@scdlovrecordsource SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
FROM
(SELECT customer_identifier,ro.LOVId,record_source_id, MIN(date_added_rowid) date_added_rowid FROM
(SELECT CASE WHEN customer_identifier_type IS NULL OR TRIM(customer_identifier_type) = '' OR TRIM(customer_identifier_type) = 'NULL' THEN 'Unknown' ELSE customer_identifier_type END customer_identifier_type,
customer_identifier,CONCAT(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id FROM #mx_crp_item_transaction_tmp 
WHERE customer_identifier IS NOT NULL AND TRIM(customer_identifier) !='' AND TRIM(customer_identifier) != 'NULL' AND row_status = 26002 
) mxitemtrans
LEFT OUTER JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'customer_identifier_type'
AND ro.LOVKey=mxitemtrans.customer_identifier_type
AND ro.LOVRecordSourceId = 12004
LEFT OUTER JOIN ser.LoyaltyAccount loyaltyaccount
ON customer_identifier = loyaltyaccount.sourceKey
AND ro.LOVId = loyaltyaccount.LOVLoyaltyProgramId
AND record_source_id = loyaltyaccount.LOVRecordSourceID
WHERE loyaltyaccount.sourceKey IS NULL
GROUP BY customer_identifier,LOVId,record_source_id
) X

UNION

SELECT 
LOVId LOVLoyaltyProgramId, 
customer_number SourceKey, 
12004 LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@scdlovrecordsource SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
FROM
(SELECT customer_number,ro.LOVId,record_source_id, MIN(date_added_rowid) date_added_rowid FROM
(SELECT CASE WHEN customer_number_type IS NULL OR TRIM(customer_number_type) = '' OR TRIM(customer_number_type) = 'NULL' THEN 'Unknown' ELSE customer_number_type END customer_number_type, 
customer_number,CONCAT(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id FROM #mx_crp_item_transaction_tmp 
WHERE customer_number IS NOT NULL AND TRIM(customer_number) !='' AND TRIM(customer_number) != 'NULL' AND row_status = 26002 
) mxitemtrans
LEFT OUTER JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'customer_number_type'
AND ro.LOVKey=mxitemtrans.customer_number_type
AND ro.LOVRecordSourceId = 12004
LEFT OUTER JOIN ser.LoyaltyAccount loyaltyaccount
ON customer_number = loyaltyaccount.sourceKey
AND ro.LOVId = loyaltyaccount.LOVLoyaltyProgramId
AND record_source_id = loyaltyaccount.LOVRecordSourceID
WHERE loyaltyaccount.sourceKey IS NULL
GROUP BY customer_number,LOVId,record_source_id
) X

UNION

SELECT 
LOVId LOVLoyaltyProgramId, 
other_customer_id SourceKey, 
12004 LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@scdlovrecordsource SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
FROM
(SELECT other_customer_id,ro.LOVId,record_source_id, MIN(date_added_rowid) date_added_rowid FROM
(SELECT CASE WHEN other_customer_id_type IS NULL OR TRIM(other_customer_id_type) = '' OR TRIM(other_customer_id_type) = 'NULL' THEN 'Unknown' ELSE other_customer_id_type END other_customer_id_type, 
other_customer_id,CONCAT(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id FROM #mx_crp_item_transaction_tmp 
WHERE other_customer_id IS NOT NULL AND TRIM(other_customer_id) !='' AND TRIM(other_customer_id) != 'NULL' AND row_status = 26002 
) mxitemtrans
LEFT OUTER JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'other_customer_id_type'
AND ro.LOVKey=mxitemtrans.other_customer_id_type
AND ro.LOVRecordSourceId = 12004
LEFT OUTER JOIN ser.LoyaltyAccount loyaltyaccount
ON other_customer_id = loyaltyaccount.sourceKey
AND ro.LOVId = loyaltyaccount.LOVLoyaltyProgramId
AND record_source_id = loyaltyaccount.LOVRecordSourceID
WHERE loyaltyaccount.sourceKey IS NULL
GROUP BY other_customer_id,LOVId,record_source_id
) X
)Z
;

RAISERROR ('Completed insertion of LoyaltyAccount Serve table', 0, 1) WITH NOWAIT;

UPDATE ser.TransactionLoyaltyAccount
SET loyaltyaccountid = lanew.loyaltyaccountid
FROM ser.TransactionLoyaltyAccount tla
JOIN #transactionloyaltyaccount_update_temp tlatmp
ON tla.loyaltyaccountid = tlatmp.loyaltyaccountid
AND tla.transactionid = tlatmp.transactionid
JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'customer_identifier_type'
AND ro.LOVKey=tlatmp.customer_identifier_type
AND ro.LOVRecordSourceId = 12004
JOIN ser.LoyaltyAccount laold
ON laold.loyaltyaccountid = tlatmp.loyaltyaccountid
AND laold.lovloyaltyprogramid = ro.LOVId
AND laold.LOVRecordSourceId = 12004
JOIN #trim_untrim_customer_identifier_tmp tutmp
ON tutmp.customer_identifier = laold.sourceKey
JOIN ser.LoyaltyAccount lanew
ON lanew.sourcekey = tutmp.customer_identifier_trimmed
AND lanew.LOVLoyaltyProgramId = ro.LOVId
AND lanew.LOVRecordSourceId = 12004
;

RAISERROR ('Completed updation of loyaltyaccountid in transactionloyaltyaccount table for customer_identifier', 0, 1) WITH NOWAIT;

UPDATE ser.TransactionLoyaltyAccount
SET loyaltyaccountid = lanew.loyaltyaccountid
FROM ser.TransactionLoyaltyAccount tla
JOIN #transactionloyaltyaccount_update_temp tlatmp
ON tla.loyaltyaccountid = tlatmp.loyaltyaccountid
AND tla.transactionid = tlatmp.transactionid
JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'customer_number_type'
AND ro.LOVKey=tlatmp.customer_number_type
AND ro.LOVRecordSourceId = 12004
JOIN ser.LoyaltyAccount laold
ON laold.loyaltyaccountid = tlatmp.loyaltyaccountid
AND laold.lovloyaltyprogramid = ro.LOVId
AND laold.LOVRecordSourceId = 12004
JOIN #trim_untrim_customer_number_tmp tutmp
ON tutmp.customer_number = laold.sourceKey
JOIN ser.LoyaltyAccount lanew
ON lanew.sourcekey = tutmp.customer_number_trimmed
AND lanew.LOVLoyaltyProgramId = ro.LOVId
AND lanew.LOVRecordSourceId = 12004
;

RAISERROR ('Completed updation of loyaltyaccountid in transactionloyaltyaccount table for customer_number', 0, 1) WITH NOWAIT;

UPDATE ser.TransactionLoyaltyAccount
SET loyaltyaccountid = lanew.loyaltyaccountid
FROM ser.TransactionLoyaltyAccount tla
JOIN #transactionloyaltyaccount_update_temp tlatmp
ON tla.loyaltyaccountid = tlatmp.loyaltyaccountid
AND tla.transactionid = tlatmp.transactionid
JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'other_customer_id_type'
AND ro.LOVKey=tlatmp.other_customer_id_type
AND ro.LOVRecordSourceId = 12004
JOIN ser.LoyaltyAccount laold
ON laold.loyaltyaccountid = tlatmp.loyaltyaccountid
AND laold.lovloyaltyprogramid = ro.LOVId
AND laold.LOVRecordSourceId = 12004
JOIN #trim_untrim_other_customer_id_tmp tutmp
ON tutmp.other_customer_id = laold.sourceKey
JOIN ser.LoyaltyAccount lanew
ON lanew.sourcekey = tutmp.other_customer_id_trimmed
AND lanew.LOVLoyaltyProgramId = ro.LOVId
AND lanew.LOVRecordSourceId = 12004
;

RAISERROR ('Completed updation of loyaltyaccountid in transactionloyaltyaccount table for other_customer_id', 0, 1) WITH NOWAIT;

UPDATE psa.rawmx_transaction_custtrim
SET row_status = 26002 WHERE asset_id IN (SELECT value FROM STRING_SPLIT(@assetID, ',')) AND row_status = 26001
;

RAISERROR ('Completed procedure', 0, 1) WITH NOWAIT

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
DECLARE @error_num VARCHAR(MAX),
		@error_msg VARCHAR(MAX),
		@error_sev VARCHAR(MAX)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

END;
GO
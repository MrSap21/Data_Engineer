IF OBJECT_ID('psa.sp_cl_crp_item_transaction') IS NOT NULL
BEGIN
	DROP PROC psa.sp_cl_crp_item_transaction;
END;

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
************************************************************************************************************
Procedure Name			: sp_cl_crp_item_transaction
Purpose					: Load History data from Chile transaction source table(psa.cl_crp_item_transaction) into Serve Layer Table
Domain					: Transaction
RecordSourceID  for Chile Transaction	: 12001

**************************************************************************************************************
*/

CREATE PROC [psa].[sp_cl_crp_item_transaction] (@serveETLRunLogID varchar(max), @tablename varchar(max), @psaEntityId varchar(max)) AS
DECLARE @ch_lovRecordSourceID bigint; 
DECLARE @ch_scdLovRecordSourceID bigint; 
DECLARE @psa_rowstatus bigint; 
DECLARE @ser_rowstatus bigint;
DECLARE @max_tillid bigint;
DECLARE @max_siteroleid bigint; 
DECLARE @ch_Siteid bigint; 
DECLARE @ch_RoleId bigint;
DECLARE @max_transactionid bigint; 
DECLARE @ch_trantypeid bigint;
DECLARE @max_productid bigint; 
DECLARE @ch_srckeytypeid bigint;
DECLARE @max_upcproductid bigint; 
DECLARE @ch_upcsrckeytypeid bigint; 
DECLARE @max_dealid bigint;
DECLARE @max_tranlineitemid bigint; 
DECLARE @ch_lineitemtypeid bigint;
DECLARE @max_measureid bigint; 
DECLARE @ch_measuretypeid bigint; 
DECLARE @ch_measuretypeid_unit bigint; 
DECLARE @ch_measuretypeid_tisp bigint; 
DECLARE @ch_measuretypeid_tesp bigint; 
DECLARE @ch_measuretypeid_epos bigint; 
DECLARE @ch_measuretypeid_disc bigint;
DECLARE @ch_intdatatypeid bigint; 
DECLARE @ch_decdatatypeid bigint; 
DECLARE @ch_strdatatypeid bigint;
DECLARE @max_trnlineitemmeasureid bigint; 
DECLARE @ch_unitmeasureid bigint; 
DECLARE @ch_tispmeasureid bigint; 
DECLARE @ch_tespmeasureid bigint; 
DECLARE @ch_eposmeasureid bigint; 
DECLARE @ch_discmeasureid bigint;  
DECLARE @max_loyaltyacctid bigint;
DECLARE @catchup_row bigint;
DECLARE @ch_uomid_unit bigint;
DECLARE @ch_uomid_nonunit bigint;
DECLARE @ch_indicatorid bigint;
DECLARE @max_trangroupid bigint;
DECLARE @ch_trangroupsetid bigint;
DECLARE @feed_entityid bigint;
DECLARE @ruleId BIGINT;
DECLARE @attributeid BIGINT;
--DECLARE @serveETLRunLogID bigint;

BEGIN		

SET @ch_lovRecordSourceID = 12001; 
SET @ch_scdLovRecordSourceID = 12001; 
SET @psa_rowstatus = 26001; 
SET @ser_rowstatus = 26002;
SET @feed_entityid = (select sourceentityid from psa.[MappingEntity] me inner join psa.[Entity] e on me.sourceentityid = e.EntityID where me.[TargetEntityID] = @psaEntityId and e.SchemaName like '%feed%');
--SET @serveETLRunLogID = 7788;

/* Creation of temporary table to store records wit rowstatus 26001 from PSA Source table */
    IF OBJECT_ID('tempdb..#cl_crp_item_transaction_tmp') IS NOT NULL
    BEGIN
        DROP TABLE #cl_crp_item_transaction_tmp
    END
    
    SELECT * INTO #cl_crp_item_transaction_tmp FROM 
	(SELECT * FROM psa.cl_crp_item_transaction 
		WHERE row_status = @psa_rowstatus 
    )A;

 
RAISERROR ('Completed insertion of TEMP CHILE PSA table', 0, 1) WITH NOWAIT;

BEGIN TRY
	BEGIN TRANSACTION
	
update psa.cl_crp_item_transaction
set row_status = 26005
where REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') = '' OR REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0') = ''
	and row_status = 26001;

RAISERROR ('Completed updating the original table setting row_status to 26005 where item or upc is all zeroes', 0, 1) WITH NOWAIT;

update #cl_crp_item_transaction_tmp
set row_status = 26005
where REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') = '' OR REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0') = '';

RAISERROR ('Completed updating the temp table setting row_status to 26005 where item or upc is all zeroes', 0, 1) WITH NOWAIT;

/*  update the temp table where transaction_time is null or blank or contains alphabets */

	UPDATE #cl_crp_item_transaction_tmp
	SET transaction_time = '00:00:00' where transaction_time is null or trim(transaction_time) = '' or transaction_time like '%[A-Za-z]%';
	
RAISERROR ('Completed updating the temp table where transaction_time is null or blank or contains alphabets', 0, 1) WITH NOWAIT;



/*--- Insert records into RuleEntityInstance for those records with invalid transaction_time ---*/

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Time Check' AND RuleCode = 'TC');
--SET @entityId = (SELECT EntityID FROM psa.[Entity] WHERE SchemaName like '%Feed%' AND EntityName = 'Chile_crp_item_transaction_Incremental_Load_txt');
SET @attributeid = (select attributeid from psa.attribute  where entityid = @feed_entityid and trim(AttributeName) = 'transaction_time');

INSERT INTO psa.RuleEntityInstance(
               --RuleEntityInstanceID
               RuleID
               ,EntityID
               ,AttributeID
               ,RuleDetail
               ,ETLRunLogID
               ,SourceEntityID
               ,SourceAttributeID
               ,PSARowKey
               ,DTCreated
               ,UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--Transaction_time--Record created for invalid transaction_time' RuleDetail,
A.etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
A.row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM psa.cl_crp_item_transaction 
	WHERE (transaction_time LIKE '%[A-Za-z]%' OR transaction_time IS NULL OR TRIM(transaction_time) = '') 
	AND row_status = @psa_rowstatus) A

UNION

SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--Transaction_time--Record created for invalid transaction_time' RuleDetail,
A.etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
A.row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT row_id,etl_runlog_id FROM #cl_crp_item_transaction_tmp 
	WHERE cast(substring(trim(transaction_time),1,2) as int) > 23 or cast(substring(trim(transaction_time),4,2) as int) > 59 or cast(substring(trim(transaction_time),7,2) as int) > 59) A;
	
RAISERROR ('Completed insertion of CHILE source data to RULEENTITYINSTANCE table for invalid transaction_time', 0, 1) WITH NOWAIT;

/*  update the temp table where transaction_time_hour > 23 OR transaction_time_minute > 59 */

	UPDATE #cl_crp_item_transaction_tmp
	SET transaction_time = '00:00:00' where cast(substring(trim(transaction_time),1,2) as int) > 23 or cast(substring(trim(transaction_time),4,2) as int) > 59 or cast(substring(trim(transaction_time),7,2) as int) > 59;

RAISERROR ('Completed updating the temp table where transaction_time_hour > 23 OR transaction_time_minute > 59', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 1.Table Name : Till */

SET @max_tillid = (SELECT COALESCE(MAX(TillId),0) FROM  [ser].[Till]);

INSERT INTO [ser].[Till] (TillId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_tillid + ROW_NUMBER() OVER(ORDER BY A.till_id ASC) TillId, 
		A.till_id SourceKey, 
		@ch_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(
SELECT src.till_id, src.date_row from 
(SELECT till_id, record_source_id, MIN(row_id) date_row from #cl_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus
	GROUP BY till_id,record_source_id)src 
LEFT OUTER JOIN [ser].[Till] slf on 
	src.till_id = slf.sourcekey 
	and src.record_source_id = slf.LOVRecordSourceId 
	where slf.sourcekey IS NULL 
)A ;

RAISERROR ('Completed insertion of CHILE source data to TILL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 2.Table Name : Site_Role */

SET @max_siteroleid = (SELECT COALESCE(MAX(SiteRoleId),0) FROM  [ser].[SiteRole]);
SET @ch_SiteId = (select siteid from ser.[site] s where s.sourcekey = '0' and lovrecordsourceid = 12012 and SCDActiveFlag = 'Y'
				and lovsitetypeid = (select lovid from ser.reflovsetinfo where lovkey='0' and LOVsetname = 'Site Type'));
SET @ch_RoleId = (select lovid from ser.reflovsetinfo where lovkey='Store' and LOVsetname = 'Role');


INSERT INTO [ser].[Siterole] (SiteRoleId, SiteId, LOVRoleId, SourceKey, SiteRoleName, SiteRoleShortName, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT S.* from
(
/*--- Inserting records for NEW business keys ---*/
SELECT  @max_siteroleid + ROW_NUMBER() OVER(ORDER BY A.sourcekey ASC) SiteRoleId, 
		@ch_SiteId SiteId,    
		@ch_RoleId LOVRoleId, 
		A.sourcekey SourceKey, 
		NULL SiteRoleName, 
		NULL SiteRoleShortName, 
		@ch_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion,  
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(
SELECT src.sourcekey, src.date_row from 
(SELECT REPLACE(LTRIM(REPLACE(store_number,'0',' ')),' ','0') sourcekey, record_source_id, MIN(row_id) date_row 
from #cl_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	and store_number IS NOT NULL and store_number != '' 
	GROUP BY REPLACE(LTRIM(REPLACE(store_number,'0',' ')),' ','0'),record_source_id) src
LEFT OUTER JOIN [ser].[Siterole] slf 
	on src.sourcekey = slf.sourcekey 
	and src.record_source_id = slf.LOVRecordSourceId 
	where slf.sourcekey IS NULL
)A 

UNION

/*--- Inserting records for EXISTING business keys which encountered soft delete ---*/
SELECT  A.SiteRoleId SiteRoleId, 
		@ch_SiteId SiteId,   
		@ch_RoleId LOVRoleId, 
		A.sourcekey SourceKey, 
		NULL SiteRoleName, 
		NULL SiteRoleShortName, 
		@ch_lovRecordSourceID LOVRecordSourceId, 
		current_timestamp SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		A.new_SCDVersion SCDVersion,  
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(
SELECT slf.SiteRoleId, (slf.SCDVersion + 1) new_SCDVersion, src.sourcekey, src.date_row from 
(SELECT REPLACE(LTRIM(REPLACE(store_number,'0',' ')),' ','0') sourcekey, record_source_id, MIN(row_id) date_row 
from #cl_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY REPLACE(LTRIM(REPLACE(store_number,'0',' ')),' ','0'),record_source_id)src
JOIN (Select B.* from 
(Select *, RANK() OVER(partition by sourcekey,lovrecordsourceid order by sourcekey,lovrecordsourceid,SCDVersion desc) row_num from  
[ser].[SiteRole] 	where lovrecordsourceid = 12001) B where B.row_num = 1 and B.SCDActiveFlag = 'N'
) slf 
	on src.sourcekey = slf.sourcekey
)A
)S;

RAISERROR ('Completed insertion of CHILE source data to SITEROLE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/*--- Insert records into RuleEntityInstance for those store_number which are new or which have encountered soft delete ---*/

--DECLARE @max_ruleentityinstanceid BIGINT;
--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Skeleton Record Creation' AND RuleCode = 'SRC');
--SET @entityId = (SELECT EntityID FROM psa.[Entity] WHERE SchemaName like '%Feed%' AND EntityName = 'Chile_crp_item_transaction_Incremental_Load_txt');
SET @attributeid = (select attributeid from psa.attribute  where entityid = @feed_entityid and trim(AttributeName) = 'store_number');

INSERT INTO psa.RuleEntityInstance(
               --RuleEntityInstanceID
               RuleID
               ,EntityID
               ,AttributeID
               ,RuleDetail
               ,ETLRunLogID
               ,SourceEntityID
               ,SourceAttributeID
               ,PSARowKey
               ,DTCreated
               ,UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--SiteRoleId--Record created for Store number due to non existence of SiteRoleId' RuleDetail,
etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT * FROM ser.SiteRole WHERE LOVRecordSourceId = 12001 AND ETLRunLogId = @serveETLRunLogID AND SCDActiveFlag = 'Y') siterole
JOIN #cl_crp_item_transaction_tmp noitemtrans
	ON REPLACE(LTRIM(REPLACE(noitemtrans.store_number,'0',' ')),' ','0') = siterole.sourcekey
	AND noitemtrans.row_id = siterole.psarowkey


RAISERROR ('Completed insertion of CHILE source data to RULEENTITYINSTANCE table for new store_number', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 3.Table Name : Transaction */

SET @max_transactionid = (SELECT COALESCE(MAX(TransactionId),0) FROM  [ser].[Transaction]);
SET @ch_trantypeid = (select lovid from ser.reflovsetinfo where lovkey='RETAIL' and LOVsetname = 'Transaction Type'); 

INSERT INTO [ser].[Transaction]
(TransactionId, SourceKey, LOVTransactionTypeId, SiteRoleId, TransactionDatetime, TillId, TillTransactionNumber, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_transactionid + ROW_NUMBER() OVER(ORDER BY trnx.transaction_key ASC) TransactionId, 
		trnx.transaction_key SourceKey, 
		@ch_trantypeid LOVTransactionTypeId, 
		trnx.SiteRoleId SiteRoleId, 
		CAST (CONCAT(trnx.transaction_date,' ',trnx.transaction_time) as Datetime) TransactionDatetime, 
		trnx.tillId TillId, 
		null TillTransactionNumber, 
		@ch_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		trnx.row_num PSARowKey from 
(
SELECT P.transaction_key,P.siteroleid, P.transaction_date, 
P.transaction_time,
P.tillid, P.record_source_id, P.row_num from
(SELECT src.transaction_key,B.siteroleid, src.transaction_date, src.transaction_time,till.tillid, src.record_source_id, src.date_row row_num from 
(SELECT transaction_key, REPLACE(LTRIM(REPLACE(store_number,'0',' ')),' ','0') store_number, transaction_date, transaction_time, till_id,record_source_id, MIN(row_id) date_row  
from #cl_crp_item_transaction_tmp  	
	where row_status = @psa_rowstatus 
	GROUP BY transaction_key, REPLACE(LTRIM(REPLACE(store_number,'0',' ')),' ','0'), till_id, transaction_date, transaction_time,record_source_id
) src 
JOIN (SELECT SiteRoleId, sourcekey from [ser].[Siterole] where lovrecordsourceid = 12001 and SCDActiveFlag = 'Y')B 
	on B.sourcekey = REPLACE(LTRIM(REPLACE(src.store_number,'0',' ')),' ','0')
JOIN (SELECT * from [ser].[Till] where lovrecordsourceid = 12001 and SCDActiveFlag = 'Y') till 
	on src.till_id = till.sourcekey 
) P
LEFT OUTER JOIN [ser].[Transaction] T 
	on P.transaction_key = T.sourcekey 
	and CAST (CONCAT(P.transaction_date,' ',P.transaction_time) as Datetime) = T.TransactionDatetime
	and P.record_source_id = T.LOVRecordSourceId 
	where T.sourcekey IS NULL 
)trnx ;


RAISERROR ('Completed insertion of CHILE source data to TRANSACTION table', 0, 1) WITH NOWAIT;


/*************************************************************************************************************************************************************/

/* 4.Table Name : Product(Parent) */

SET @max_productid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @ch_srckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='Chile Item Code' and LOVsetname = 'Source Key Type'); 

INSERT INTO [ser].[Product] (ProductId, SourceKey, LOVSourceKeyTypeId, ProductName, ProductDescription, LOVBrandId, LOVSubBrandId, LOVRecordSourceId, ParentProductId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT S.* from 
(
/*--- Inserting records for NEW business keys ---*/
SELECT  @max_productid + ROW_NUMBER() OVER(ORDER BY A.SourceKey ASC) ProductId, 
		A.SourceKey SourceKey, 
		@ch_srckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		@ch_lovRecordSourceID LOVRecordSourceId,
		null ParentProductId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey from
(
SELECT src.sourcekey, src.date_row from 
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') SourceKey, record_source_id, min(row_id) date_row from #cl_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), record_source_id) src 
LEFT OUTER JOIN [ser].[Product] P on 
	REPLACE(LTRIM(REPLACE(src.SourceKey,'0',' ')),' ','0') = P.sourcekey 
	and src.record_source_id = P.LOVRecordSourceId 
	where P.sourcekey IS NULL 
)A

UNION
/*--- Inserting records for EXISTING business keys which encountered soft delete ---*/
SELECT  A.ProductId ProductId, 
		A.SourceKey SourceKey, 
		@ch_srckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		@ch_lovRecordSourceID LOVRecordSourceId,
		null ParentProductId,
		current_timestamp SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		A.new_SCDVersion SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey from
(
SELECT slf.ProductId, (slf.SCDVersion + 1) new_SCDVersion, src.sourcekey, src.date_row from 
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') SourceKey, record_source_id, min(row_id) date_row from #cl_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), record_source_id) src 
/*--- Joining with the max scd_version of those item_code which is having SCDActiveFlag='N' (that is, it encountered a soft delete) ---*/
JOIN (Select B.* from 
(Select *, RANK() OVER(partition by sourcekey,lovrecordsourceid order by sourcekey,lovrecordsourceid,SCDVersion desc) row_num from  
[ser].[PRODUCT] where lovrecordsourceid = 12001) B where B.row_num = 1 and B.SCDActiveFlag = 'N'
) slf 
	on REPLACE(LTRIM(REPLACE(src.sourcekey,'0',' ')),' ','0') = slf.sourcekey
)A

)S;


RAISERROR ('Completed insertion of CHILE source data to PRODUCT(parent) table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/*--- Insert records into RuleEntityInstance for those item_code which are new or which have encountered soft delete ---*/

--SET @max_ruleentityinstanceid = (SELECT COALESCE(MAX(RuleEntityInstanceID),0) FROM  psa.RuleEntityInstance);
SET @ruleId = (SELECT RuleID FROM psa.[Rule] WHERE RuleName = 'Skeleton Record Creation' AND RuleCode = 'SRC');
--SET @entityId = (SELECT EntityID FROM psa.[Entity] WHERE SchemaName like '%Feed%' AND EntityName = 'Chile_crp_item_transaction_Incremental_Load_txt');
SET @attributeid = (select attributeid from psa.attribute  where entityid = @feed_entityid and trim(AttributeName) = 'item_code');

INSERT INTO psa.RuleEntityInstance(
               --RuleEntityInstanceID
               RuleID
               ,EntityID
               ,AttributeID
               ,RuleDetail
               ,ETLRunLogID
               ,SourceEntityID
               ,SourceAttributeID
               ,PSARowKey
               ,DTCreated
               ,UserCreated
)
SELECT 
--@max_ruleentityinstanceid+ROW_NUMBER() RuleEntityInstanceID,
@ruleId RuleID,
@psaEntityId EntityID,
@attributeid AttributeID,
'DQWarning--ProductId--Record created for Item Code due to non existence of ProductId' RuleDetail,
etl_runlog_id ETLRunLogID,
@psaEntityId SourceEntityID,
@attributeid SourceAttributeID,
row_id PSARowKey,
CURRENT_TIMESTAMP DTCreated,
SYSTEM_USER UserCreated
FROM
(SELECT * FROM ser.Product WHERE LOVRecordSourceId = 12001 AND ETLRunLogId = @serveETLRunLogID AND SCDActiveFlag = 'Y') product
JOIN #cl_crp_item_transaction_tmp noitemtrans
	ON REPLACE(LTRIM(REPLACE(noitemtrans.item_code,'0',' ')),' ','0') = product.sourcekey
	AND noitemtrans.row_id = product.psarowkey
	
RAISERROR ('Completed insertion of CHILE source data to RULEENTITYINSTANCE table for new item_code', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 5.Table Name : Product(Child) */

SET @max_upcproductid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @ch_upcsrckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='UPC' and LOVsetname = 'Source Key Type'); 
SET @ch_srckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='Chile Item Code' and LOVsetname = 'Source Key Type');


INSERT INTO [ser].[Product] (ProductId, SourceKey, LOVSourceKeyTypeId, ProductName, ProductDescription, LOVBrandId, LOVSubBrandId, LOVRecordSourceId, ParentProductId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_upcproductid + ROW_NUMBER() OVER(ORDER BY prod.upc ASC) ProductId, 
		prod.upc SourceKey, 
		@ch_upcsrckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		/*null LOVCostCentreId, */
		@ch_lovRecordSourceID LOVRecordSourceId,
		prod.ProductId ParentProductId,
		'1900-01-01' SCDStartDate,
		--LEFT(prod.date_row,CHARINDEX('_',prod.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		prod.date_row PSARowKey from
(
SELECT T.upc, T.date_row, T.parent, T.ProductId from 
(
SELECT par.upc ,par.date_row, par.record_source_id, par.item parent, cld.ProductId from
(
SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') item, REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0') upc, MIN(row_id) date_row , record_source_id 
from [psa].[cl_crp_item_transaction] 
	where row_status = @psa_rowstatus 
	GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0'), record_source_id
) par
JOIN [ser].[product] cld 
	on REPLACE(LTRIM(REPLACE(par.item,'0',' ')),' ','0') = cld.sourcekey 
	and cld.lovrecordsourceid = 12001 
	and cld.LOVSourceKeyTypeId = @ch_srckeytypeid 
	and cld.SCDActiveFlag = 'Y'
) T
LEFT OUTER JOIN [ser].[product] P 
	on T.upc = P.sourcekey 
	and T.ProductId = P.ParentProductId 
	and T.record_source_id = P.LOVRecordSourceId 
	where P.sourcekey IS NULL and T.upc != '' and T.upc IS NOT NULL
) prod

union

SELECT  prod.ProductId ProductId, 
		prod.sourcekey SourceKey, 
		@ch_upcsrckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		/*null LOVCostCentreId, */
		@ch_lovRecordSourceID LOVRecordSourceId,
		prod.ParentProductId ParentProductId,
		current_timestamp SCDStartDate,
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		prod.new_SCDVersion SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		prod.date_row PSARowKey from
(
SELECT slf.ProductId, (slf.SCDVersion + 1) new_SCDVersion, slf.parentproductid, slf.sourcekey, src.date_row from 
(SELECT par.upc, cld.productid, par.date_row from 
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') item, REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0') upc, record_source_id, min(row_id) date_row from #cl_crp_item_transaction_tmp 	where row_status = @psa_rowstatus 
GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0'), record_source_id) par
JOIN [ser].[product] cld 
	on REPLACE(LTRIM(REPLACE(par.item,'0',' ')),' ','0') = cld.sourcekey 
	and cld.lovrecordsourceid = 12001 
	and cld.LOVSourceKeyTypeId = @ch_srckeytypeid 
	and cld.SCDActiveFlag = 'Y'
)src
/*--- Joining with the max scd_version of those item_code,upc which is having SCDActiveFlag='N' (that is, it encountered a soft delete) ---*/
JOIN (Select B.* from 
(Select *, RANK() OVER(partition by sourcekey,ParentProductId,lovrecordsourceid order by sourcekey,ParentProductId,lovrecordsourceid,SCDVersion desc) row_num from  [ser].[PRODUCT] where lovrecordsourceid = 12001 and LOVSourceKeyTypeId = @ch_upcsrckeytypeid) B where B.row_num = 1 and B.SCDActiveFlag = 'N'
) slf 
	on src.upc = slf.sourcekey
	and src.productid = slf.parentproductid
	and src.upc is not null and src.upc != ''
)prod
;

RAISERROR ('Completed insertion of CHILE source data to PRODUCT(child) table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 6.Table Name : Deal */

SET @max_dealid = (SELECT COALESCE(MAX(DealId),0) FROM  [ser].[Deal]);

INSERT INTO [ser].[Deal] (DealId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_dealid + ROW_NUMBER() OVER(ORDER BY src.deal_id ASC) DealId,
		src.deal_id SourceKey,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		src.date_row PSARowKey from 
(
SELECT T.deal_id, T.date_row from 
(SELECT deal_id, record_source_id, min(row_id) date_row from #cl_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	GROUP BY deal_id, record_source_id)T 
LEFT OUTER JOIN [ser].[Deal] D on 
	T.deal_id = D.sourcekey 
	and T.record_source_id = D.LOVRecordSourceId 
	where D.sourcekey IS NULL and T.deal_id IS NOT NULL and T.deal_id != ''
) src ;

RAISERROR ('Completed insertion of CHILE source data to DEAL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 7.Table Name : Transaction Line Item */

SET @max_tranlineitemid = (SELECT COALESCE(MAX(TransactionLineItemId),0) FROM  [ser].[TransactionLineItem]);
SET @ch_upcsrckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='UPC' and LOVsetname = 'Source Key Type'); 
SET @ch_srckeytypeid = (select lovid from ser.reflovsetinfo where lovkey='Chile Item Code' and LOVsetname = 'Source Key Type');


INSERT INTO [ser].[TransactionLineItem] (TransactionLineItemId, TransactionId, ProductId, LOVLineItemTypeId, DealId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_tranlineitemid + ROW_NUMBER() OVER(ORDER BY final.sourcekey ASC) TransactionLineItemId,
		final.transactionid TransactionId,
		final.productid ProductId,
		NULL LOVLineItemTypeId,    
		final.deal_id DealId,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
SELECT trnx.transactionid, trnx.sourcekey, A.productid , A.dealid deal_id, A.row_id row_num from [ser].[Transaction] trnx 
JOIN 
(
SELECT P.productId, src.dealid, src.row_id, src.transaction_key, src.transaction_date, src.transaction_time from 
(SELECT M.item_code, M.upc, M.transaction_key, D.dealid, M.row_id, M.transaction_date, M.transaction_time from
(SELECT * from #cl_crp_item_transaction_tmp where row_status = @psa_rowstatus) M
LEFT OUTER JOIN [ser].[Deal] D on 
	D.sourcekey = M.deal_id and D.LOVRecordSourceId = 12001 and D.SCDActiveFlag = 'Y'
)src
JOIN [ser].[product] P 
	on 	P.sourcekey = REPLACE(LTRIM(REPLACE(src.upc,'0',' ')),' ','0')
	and P.lovsourcekeytypeid = @ch_upcsrckeytypeid 
	and P.SCDActiveFlag = 'Y'
	and P.ParentProductId in (select ProductId from ser.product where sourcekey = REPLACE(LTRIM(REPLACE(src.item_code,'0',' ')),' ','0') )
)A 
	on trnx.sourcekey = A.transaction_key 
	and trnx.lovrecordsourceid = 12001 
	and CAST (CONCAT(A.transaction_date,' ',A.transaction_time) as Datetime) = trnx.TransactionDatetime 
) final;


RAISERROR ('Completed insertion of CHILE source data to TRANSACTIONLINEITEM table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 8.Table Name : Transaction Line Item Measure */

SET @max_trnlineitemmeasureid = (SELECT COALESCE(MAX(TransactionLineItemMeasureId),0) FROM  [ser].[TransactionLineItemMeasure]);
SET @ch_measuretypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 			'RETAIL_TRANS_AGG' and rlovset.LOVsetname = 'Measure Type');
SET @ch_unitmeasureid = (SELECT MAX(MeasureId) from [ser].[Measure] msr where msr.measurename = 'units' and msr.LOVMeasureTypeId = @ch_measuretypeid and msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @ch_tispmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'tisp' and msr.LOVMeasureTypeId = @ch_measuretypeid and msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @ch_tespmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'tesp' and msr.LOVMeasureTypeId = @ch_measuretypeid and msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @ch_eposmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'epos_profit' and msr.LOVMeasureTypeId = @ch_measuretypeid and 	msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @ch_discmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'discount_applied' and msr.LOVMeasureTypeId = @ch_measuretypeid and 	msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);

SET @ch_uomid_unit = (SELECT lovid from ser.reflovsetinfo where lovkey='Unit' and LOVsetname = 'Unit Of Measure' and LOVRecordsourceid = 12012);
SET @ch_uomid_nonunit = (SELECT lovid from ser.reflovsetinfo where lovkey='CLP' and LOVsetname = 'Currency ISO 4217' and LOVRecordsourceid = 12012);

INSERT INTO [ser].[TransactionLineItemMeasure] (TransactionLineItemMeasureId, TransactionLineItemId, MeasureId, Value, LOVUOMId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	DENSE_RANK() OVER(ORDER BY final.TransactionLineItemId, final.MeasureId) TransactionLineItemMeasureId,
		final.TransactionLineItemId TransactionLineItemId,
		final.MeasureId MeasureId,
		final.Value Value,
		final.LOVUOMId LOVUOMId,
		final.LOVRecordSourceId LOVRecordSourceId,
		final.SCDStartDate SCDStartDate,
		final.SCDEndDate SCDEndDate,
		final.SCDActiveFlag SCDActiveFlag,
		final.SCDVersion SCDVersion,
		final.SCDLOVRecordSourceId SCDLOVRecordSourceId,
		final.ETLRunLogId ETLRunLogId,
		final.PSARowKey PSARowKey from
(	
SELECT	A.TransactionLineItemId TransactionLineItemId,
		@ch_unitmeasureid MeasureId,
		A.units [Value],
		@ch_uomid_unit LOVUOMId,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		A.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.units , src.row_id row_num from [ser].[TransactionLineItem] trln     
JOIN #cl_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id 
	and trln.LOVRecordSourceId = src.record_source_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.units is not null and src.units != '') A

UNION

SELECT  B.TransactionLineItemId TransactionLineItemId,
		@ch_tispmeasureid MeasureId,
		B.tisp [Value],
		@ch_uomid_nonunit LOVUOMId,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		B.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.tisp , src.row_id row_num from [ser].[TransactionLineItem] trln     
JOIN #cl_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id 
	and trln.LOVRecordSourceId = src.record_source_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.tisp is not null and src.tisp != '') B

UNION

SELECT  C.TransactionLineItemId TransactionLineItemId,
		@ch_tespmeasureid MeasureId,
		C.tesp Value,
		@ch_uomid_nonunit LOVUOMId,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		C.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.tesp , src.row_id row_num from [ser].[TransactionLineItem] trln     
JOIN #cl_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id  
	and trln.LOVRecordSourceId = src.record_source_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.tesp is not null and src.tesp != '') C

UNION

SELECT  D.TransactionLineItemId TransactionLineItemId,
		@ch_eposmeasureid MeasureId,
		D.epos_profit Value,
		@ch_uomid_nonunit LOVUOMId,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		D.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.epos_profit , src.row_id row_num from [ser].[TransactionLineItem] trln  
JOIN #cl_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id  
	and trln.LOVRecordSourceId = src.record_source_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.epos_profit is not null and src.epos_profit != '') D

UNION

SELECT  E.TransactionLineItemId TransactionLineItemId,
		@ch_discmeasureid MeasureId,
		E.discount_applied Value,
		@ch_uomid_nonunit LOVUOMId,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		E.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.discount_applied , src.row_id row_num from [ser].[TransactionLineItem] trln     
JOIN #cl_crp_item_transaction_tmp src on 
	trln.psarowkey = src.row_id  
	and trln.LOVRecordSourceId = src.record_source_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	where src.row_status = @psa_rowstatus and src.discount_applied is not null and src.discount_applied != '') E
)final;

RAISERROR ('Completed insertion of CHILE source data to TRANSACTIONLINEITEMMEASURE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 9.Table Name : TransactionLineItemIndicator */

SET @ch_indicatorid = (SELECT lovid from ser.reflovsetinfo where lovkey='prescription' and LOVsetname = 'Indicator - CHILE Transaction');

INSERT INTO [ser].[TransactionLineItemIndicator] (TransactionLineItemId, LOVIndicatorId, [Value], LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  A.TransactionLineItemId TransactionLineItemId,
		@ch_indicatorid LOVIndicatorId,
		(case when upper(A.prescription) = 'Y' or upper(A.prescription) = 'YES' then 'Y' else 'N' end) [VALUE],
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		A.row_num PSARowKey from
(
SELECT trln.TransactionLineItemId, src.prescription, src.record_source_id, src.row_id row_num from 
(SELECT prescription, record_source_id, row_id from #cl_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	and prescription IS NOT NULL and prescription != '') src
JOIN [ser].[TransactionLineItem] trln on 
	trln.PSARowKey = src.row_id  
	and trln.ETLRunLogId = @serveETLRunLogID
	and trln.LOVRecordSourceId = 12001
) A;

RAISERROR ('Completed insertion of CHILE source data to TransactionLineItemIndicator table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 10.Table Name : Loyalty Account */

SET @max_loyaltyacctid = (SELECT COALESCE(MAX(LoyaltyAccountId),0) FROM  [ser].[LoyaltyAccount]);

INSERT INTO [ser].[LoyaltyAccount] (LoyaltyAccountId,LOVLoyaltyProgramId,SourceKey,LOVRecordSourceId,SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	@max_loyaltyacctid + ROW_NUMBER() OVER(ORDER BY final.lovid, final.SourceKey ASC) LoyaltyAccountId, 
		final.lovid LOVLoyaltyProgramId,
		final.SourceKey SourceKey,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
SELECT M.lovid, M.sourcekey, M.date_row row_num from 
(
SELECT rlov.lovid lovid, B.customer_identifier sourcekey, B.record_source_id, MIN(B.row_id) date_row 
from (SELECT * from ser.reflovsetinfo where LOVsetname = 'customer_identifier_type' and LOVRecordSourceId = 12001)rlov 
JOIN 
(
SELECT (CASE WHEN (trim(A.customer_identifier_type) = '' OR A.customer_identifier_type IS NULL OR trim(A.customer_identifier_type) = 'NULL') THEN 'Unknown'
ELSE A.customer_identifier_type END) lovkey, A.customer_identifier, A.row_id, A.record_source_id from
(select * from #cl_crp_item_transaction_tmp where row_status=@psa_rowstatus
	and customer_identifier IS NOT NULL and TRIM(customer_identifier) != '' and trim(customer_identifier) != 'NULL'
) A
) B on 
	rlov.lovkey = B.lovkey
	GROUP BY rlov.lovid, B.customer_identifier,B.record_source_id
) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T 
	on M.lovid=T.LOVLoyaltyProgramId 
	and M.SourceKey=T.SourceKey 
	and M.record_source_id=T.LOVRecordSourceId 
	where LOVLoyaltyProgramId IS NULL

UNION

SELECT M.lovid, M.sourcekey, M.date_row row_num from 
(
SELECT rlov.lovid lovid, B.customer_number sourcekey, B.record_source_id, MIN(B.row_id) date_row 
from (SELECT * from ser.reflovsetinfo where LOVsetname = 'customer_number_type' and LOVRecordSourceId = 12001)rlov 
JOIN 
(
SELECT (CASE WHEN (trim(A.customer_number_type) = '' OR A.customer_number_type IS NULL OR trim(A.customer_number_type) = 'NULL') THEN 'Unknown'
ELSE A.customer_number_type END) lovkey, A.customer_number, A.row_id, A.record_source_id from
(select * from #cl_crp_item_transaction_tmp where row_status= @psa_rowstatus
	and customer_number IS NOT NULL and TRIM(customer_number) != '' and trim(customer_number) != 'NULL'
) A
) B on 
	rlov.lovkey = B.lovkey
	GROUP BY rlov.lovid, B.customer_number,B.record_source_id
) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T 
	on M.lovid=T.LOVLoyaltyProgramId 
	and M.SourceKey=T.SourceKey 
	and M.record_source_id=T.LOVRecordSourceId 
	where LOVLoyaltyProgramId IS NULL

UNION

SELECT M.lovid, M.sourcekey, M.date_row row_num from 
(
SELECT rlov.lovid lovid, B.other_customer_id sourcekey, B.record_source_id, MIN(B.row_id) date_row 
from (SELECT * from ser.reflovsetinfo where LOVsetname = 'other_customer_id_type' and LOVRecordSourceId = 12001)rlov 
JOIN 
(
SELECT (CASE WHEN (trim(A.other_customer_id_type) = '' OR A.other_customer_id_type IS NULL OR trim(A.other_customer_id_type) = 'NULL') THEN 'Unknown'
ELSE A.other_customer_id_type END) lovkey, A.other_customer_id, A.row_id, A.record_source_id from
(select * from #cl_crp_item_transaction_tmp where row_status= @psa_rowstatus
	and other_customer_id IS NOT NULL and TRIM(other_customer_id) != '' and trim(other_customer_id) != 'NULL'
) A
) B on 
	rlov.lovkey = B.lovkey
	GROUP BY rlov.lovid, B.other_customer_id,B.record_source_id
) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T 
	on M.lovid=T.LOVLoyaltyProgramId 
	and M.SourceKey=T.SourceKey 
	and M.record_source_id=T.LOVRecordSourceId 
	where LOVLoyaltyProgramId IS NULL

) final;

RAISERROR ('Completed insertion of CHILE source data to LOYALTYACCOUNT table', 0, 1) WITH NOWAIT;


/*************************************************************************************************************************************************************/

/* 11.Table Name : TransactionLoyaltyAccount */

INSERT INTO [ser].[TransactionLoyaltyAccount] (TransactionId, LoyaltyAccountId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	final.TransactionId TransactionId, 
		final.loyaltyaccountid LoyaltyAccountId,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
/*--- Customer Identifier ---*/
SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, M.date_row row_num from 
[ser].[LoyaltyAccount] LA 
JOIN 
(SELECT B.TransactionId, rlov.lovid lovid, B.customer_identifier sourcekey, B.record_source_id, MIN(B.date_row) date_row from 
(SELECT * from ser.reflovsetinfo where LOVsetname = 'customer_identifier_type' and LOVRecordSourceId = 12001)rlov
JOIN 
(
SELECT (CASE WHEN (trim(A.customer_identifier_type) = '' OR A.customer_identifier_type IS NULL OR trim(A.customer_identifier_type) = 'NULL') THEN 'Unknown'
ELSE A.customer_identifier_type END) lovkey, A.customer_identifier, A.date_row, A.record_source_id, A.Transactionid from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_identifier_type, src.customer_identifier, src.row_id date_row,src.record_source_id from 
[ser].[Transaction] trnx
JOIN 
(SELECT M.transaction_key, M.row_id, M.transaction_date, M.transaction_time, M.customer_identifier, M.customer_identifier_type, M.record_source_id from
(select * from #cl_crp_item_transaction_tmp where row_status=@psa_rowstatus
	and customer_identifier IS NOT NULL and TRIM(customer_identifier) != '' and trim(customer_identifier) != 'NULL'
) M
)src  
	on trnx.sourcekey = src.transaction_key 
	and trnx.lovrecordsourceid = 12001 
	and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime 
) A
) B 
	on rlov.lovkey = B.lovkey
	GROUP BY B.TransactionId, rlov.lovid, B.customer_identifier,B.record_source_id
)M 
	on LA.LOVLoyaltyProgramId = M.lovid 
	and LA.sourcekey = M.sourcekey 
	and LA.SCDActiveFlag = 'Y'
) P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

UNION

/*--- Customer Number ---*/
SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, M.date_row row_num from 
[ser].[LoyaltyAccount] LA 
JOIN 
(SELECT B.TransactionId, rlov.lovid lovid, B.customer_number sourcekey, B.record_source_id, MIN(B.date_row) date_row from 
(SELECT * from ser.reflovsetinfo where LOVsetname = 'customer_number_type' and LOVRecordSourceId = 12001)rlov
JOIN 
(
SELECT (CASE WHEN (trim(A.customer_number_type) = '' OR A.customer_number_type IS NULL OR trim(A.customer_number_type) = 'NULL') THEN 'Unknown'
ELSE A.customer_number_type END) lovkey, A.customer_number, A.date_row, A.record_source_id, A.Transactionid from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_number_type, src.customer_number, src.row_id date_row,src.record_source_id from 
[ser].[Transaction] trnx
JOIN 
(SELECT M.transaction_key, M.row_id, M.transaction_date, M.transaction_time, M.customer_number, M.customer_number_type, M.record_source_id from
(select * from #cl_crp_item_transaction_tmp where row_status=@psa_rowstatus
	and customer_number IS NOT NULL and TRIM(customer_number) != '' and trim(customer_number) != 'NULL'
) M
)src  
	on trnx.sourcekey = src.transaction_key 
	and trnx.lovrecordsourceid = 12001 
	and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime 
) A
) B 
	on rlov.lovkey = B.lovkey
	GROUP BY B.TransactionId, rlov.lovid, B.customer_number,B.record_source_id
)M 
	on LA.LOVLoyaltyProgramId = M.lovid 
	and LA.sourcekey = M.sourcekey 
	and LA.SCDActiveFlag = 'Y'
) P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

UNION

/*--- Other Customer Id ---*/
SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, M.date_row row_num from 
[ser].[LoyaltyAccount] LA 
JOIN 
(SELECT B.TransactionId, rlov.lovid lovid, B.other_customer_id sourcekey, B.record_source_id, MIN(B.date_row) date_row from 
(SELECT * from ser.reflovsetinfo where LOVsetname = 'other_customer_id_type' and LOVRecordSourceId = 12001)rlov
JOIN 
(
SELECT (CASE WHEN (trim(A.other_customer_id_type) = '' OR A.other_customer_id_type IS NULL OR trim(A.other_customer_id_type) = 'NULL') THEN 'Unknown'
ELSE A.other_customer_id_type END) lovkey, A.other_customer_id, A.date_row, A.record_source_id, A.Transactionid from
(SELECT trnx.TransactionId, trnx.sourcekey, src.other_customer_id_type, src.other_customer_id, src.row_id date_row,src.record_source_id from 
[ser].[Transaction] trnx
JOIN 
(SELECT M.transaction_key, M.row_id, M.transaction_date, M.transaction_time, M.other_customer_id, M.other_customer_id_type, M.record_source_id from
(select * from #cl_crp_item_transaction_tmp where row_status=@psa_rowstatus
	and other_customer_id IS NOT NULL and TRIM(other_customer_id) != '' and trim(other_customer_id) != 'NULL'
) M
)src  
	on trnx.sourcekey = src.transaction_key 
	and trnx.lovrecordsourceid = 12001 
	and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime 
) A
) B 
	on rlov.lovkey = B.lovkey
	GROUP BY B.TransactionId, rlov.lovid, B.other_customer_id,B.record_source_id
)M 
	on LA.LOVLoyaltyProgramId = M.lovid 
	and LA.sourcekey = M.sourcekey 
	and LA.SCDActiveFlag = 'Y'
) P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

)final;


RAISERROR ('Completed insertion of CHILE source data to TRANSACTIONLOYALTYACCOUNT table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 12.Table Name : TransactionGroup */

SET @max_trangroupid = (SELECT COALESCE(MAX(TransactionGroupId),0) FROM  [ser].[TransactionGroup]);
SET @ch_trangroupsetid = (select distinct lovsetid from ser.reflovsetinfo where LOVsetname = 'sales_type' and lovrecordsourceid = 12001); 

INSERT INTO [ser].[TransactionGroup] (TransactionGroupId, TransactionId, LOVTransactionGroupSetId, LOVGroupId, ParentTransactionGroupId, LOVRecordSourceId,  SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_trangroupid + ROW_NUMBER() OVER(ORDER BY A.TransactionId ASC) TransactionGroupId, 
		A.TransactionId TransactionId,
		@ch_trangroupsetid LOVTransactionGroupSetId, 
		A.lovid LOVGroupId, 
		null ParentTransactionGroupId, 
		12001 LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@ch_lovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.row_num PSARowKey from
(
SELECT T.TransactionId, src.row_num, R.lovid from 
(SELECT M.transaction_key, M.till_id, M.store_number, M.transaction_date, M.transaction_time, M.sales_type, M.row_num from
(SELECT transaction_key, store_number, till_id, transaction_date, transaction_time, record_source_id, sales_type, MIN(row_id) row_num,
ROW_NUMBER() OVER(PARTITION BY transaction_key, store_number, till_id, transaction_date, transaction_time, record_source_id ORDER BY sales_type ASC) key_seq 
from #cl_crp_item_transaction_tmp 
	where row_status = @psa_rowstatus 
	and sales_type is not null and sales_type != '' 
	group by transaction_key, store_number, till_id, transaction_date, transaction_time, record_source_id, sales_type
) M
where M.key_seq = 1
)src
JOIN [ser].[TRANSACTION] T 
	on T.LOVRecordSourceId = 12001 
	and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = T.TransactionDatetime 
	and	src.transaction_key = T.sourcekey
JOIN ser.reflovsetinfo R 
	on	R.lovkey = src.sales_type 
	and R.lovsetid = @ch_trangroupsetid
LEFT OUTER JOIN [ser].[TransactionGroup] TG 
	on 	T.TransactionId = TG.TransactionId 
	and T.LOVRecordSourceId = TG.LOVRecordSourceId 
	and	@ch_trangroupsetid = TG.LOVTransactionGroupSetId
	where TG.TransactionId IS NULL
) A ;


RAISERROR ('Completed insertion of CHILE source data to TRANSACTIONGROUP table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 13.Table Name : psa.cl_crp_item_transaction */
/* Update the row_status in the psa.cl_crp_item_transaction from 26001(PSA) to 26002(SERVE) */

UPDATE psa.cl_crp_item_transaction
SET row_status = @ser_rowstatus
where row_status = @psa_rowstatus and row_id in 
(select psarowkey from ser.transactionlineitem where lovrecordsourceid = 12001 and ETLRunLogId = @serveETLRunLogID) ;

RAISERROR ('Completed updating the row_status from 26001(PSA) to 26002(SERVE) in psa.cl_crp_item_transaction', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
DECLARE @error_num varchar(max),
		@error_msg varchar(max),
		@error_sev varchar(max)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

END;
GO
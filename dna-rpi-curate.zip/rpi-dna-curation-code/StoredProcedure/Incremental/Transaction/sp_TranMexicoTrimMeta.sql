/****** Object:  StoredProcedure [psa].[sp_TranMexicoTrimMeta]    Script Date: 10/29/2020 12:14:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_TranMexicoTrimMeta') IS NOT NULL
BEGIN
	DROP PROC psa.sp_TranMexicoTrimMeta
END
GO

CREATE PROC [psa].[sp_TranMexicoTrimMeta] @tableName [varchar](max),@psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max) AS
DECLARE
@tserveETLRunLogID varchar(1000),
@tAssetVal varchar(200),
@tfilecount int,
@curr_status varchar(1),
@tfeedtype varchar(10),
@tdateadded varchar(200),
@trownumber int;

BEGIN

SET @tserveETLRunLogID = @serveETLRunLogID
SET @tfilecount = (select count(*) from psa.TranMexicoTrimMeta)
SET @trownumber = 1
SET @curr_status = (select assetstatus from psa.TranMexicoTrimMeta where row_id = @trownumber)


WHILE (@trownumber <= @tfilecount) 
	BEGIN
	SET @curr_status = (select assetstatus from psa.TranMexicoTrimMeta where row_id = @trownumber)
	SET @tAssetVal = (select assetId from psa.TranMexicoTrimMeta where row_id = @trownumber)
	SET @tdateadded = (select dateadded from psa.TranMexicoTrimMeta where row_id = @trownumber)
	SET @tfeedtype = (select (case when feedtype = 'H' then '151' when feedtype = 'I' then '12004' end) from psa.TranMexicoTrimMeta where row_id = @trownumber)

	if (@curr_status = 'Y')
	begin
	
		RAISERROR ( '%d' , 0, 1, @trownumber) WITH NOWAIT
		RAISERROR ( @tAssetVal  , 0, 1) WITH NOWAIT
		RAISERROR ( @tfeedtype  , 0, 1) WITH NOWAIT
		RAISERROR ( @tserveETLRunLogID  , 0, 1) WITH NOWAIT
		
		EXEC ('EXEC psa.sp_mx_transaction_trim_correction @serveETLRunLogID = ' + @tserveETLRunLogID + ',@AssetId = ' + @tAssetVal + ',@dateadded = ' + @tdateadded + ',@scdlovrecordsource = ' + @tfeedtype);

		UPDATE psa.TranMexicoTrimMeta SET assetstatus = 'N'  where assetId = @tAssetVal;
	
	END 
	SET @trownumber = (@trownumber + 1) 
			
	END
END
GO
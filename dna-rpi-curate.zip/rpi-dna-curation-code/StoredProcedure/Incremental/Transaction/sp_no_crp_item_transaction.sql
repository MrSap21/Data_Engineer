/****** Object:  StoredProcedure [psa].[sp_no_crp_item_transaction]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
************************************************************************************************************
Procedure Name							: sp_no_crp_item_transaction
Purpose									: Load Incremental data from norway transaction source table(rawno.crp_item_transaction) into Serve Layer Table
Domain									: Transaction
ServeLayer Target Tables	 			: Till(onetime insert done), SiteRole(onetimeinsert done),paryrolesiterolerelationship(onetimeinsert done), Product, Transaction, TransactionLineItem, TransactionLineItemMeasure, 
										  
RecordSourceID  for norway Transaction	: 12005

**************************************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  12005 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		                     : Description
==========================================================================================================================

11-nov-2022  :  Pranathi Reddy Mendu 				  pervious the data was coming in transaction level but now the data 
                                                      is coming as product level so modified according to it

**************************************************************************************************************************/


IF OBJECT_ID('psa.sp_no_crp_item_transaction') IS NOT NULL
BEGIN
	DROP PROC psa.sp_no_crp_item_transaction
END
GO

CREATE PROC [psa].[sp_no_crp_item_transaction] @serveETLRunLogID VARCHAR(MAX), @tablename VARCHAR(MAX), @psaEntityId VARCHAR(MAX) AS

DECLARE			@rowStatusPSACode			BIGINT,
				@scdLovRecordSourceId       BIGINT,
				@LOVSourceKeyTypeId         BIGINT,
				@LovRecordSourceId			INT,				 							
				@lovTransactionTypeId       INT,
				@LOVIndicatorID             INT,				
				@LovLevelId                 INT,
				@SiteRoleId                 INT,				
				@tablecolumns				VARCHAR(MAX),
				@exec_sql					VARCHAR(1000),
				@msg 						varchar(8000),
				@LOVMeasureTypeId           BIGINT,
				@inpServeETLRunLogId        VARCHAR (20),
				@MeasureId                  BIGINT,
				@MeasureId1                 BIGINT,
				@MeasureId2                 BIGINT,
				@LOVUOMId                   BIGINT,
				@LOVUOMId1                   BIGINT,
			    @ruleId 					 BIGINT,
                @attributeid				 BIGINT,
				@feed_entityid  			 BIGINT,
				@psaEntityId                 varchar(30);
				
				
				
					
SET	@rowStatusPSACode	   = 26001	
SET @LovRecordSourceId     = 12005
SET @scdLovRecordSourceId  = 12012
SET @inpServeETLRunLogId   = @serveETLRunLogID 
	

BEGIN


	

	--Set the variables with constant references to use in the code below

	Select @lovTransactionTypeId=LovID  from ser.RefLOV where LOVKey = 'RETAIL' AND 
          LovSetID = (select LovSetID from ser.RefLOVSet where LOVsetName = 'Transaction Type' )	
	      AND ActiveFlag = 1
	
	Select @LovLevelId=LovID from ser.RefLOV where LOVKey = 'D' AND 
            LovSetID =  (select LovSetID from ser.RefLOVSet where LOVsetName = 'Level')
	
	Select @LOVSourceKeyTypeId= LOVId from ser.RefLOV where LOVKey = 'Norway Item Code'
            AND LOVSetId = (select  LOVSetId from ser.RefLOVSet where LOVsetName = 'Source Key Type'
            AND ActiveFlag = '1'and RecordSourceId = 12012)
            AND ActiveFlag = '1'and RecordSourceId = 12012
	
	
	
	
	select @LOVMeasureTypeId = LovID from ser.RefLOV where  
           LOVKey = 'RETAIL_TRANS_AGG' 
           AND  LovSetID = (select  LovSetID from ser.RefLOVSet where LOVsetName = 'Measure Type' and RecordSourceID = 12012)

SELECT  @MeasureId =  MeasureID FROM ser.MEASURE WHERE MeasureName = ('units') 
			AND LovMeasureTypeID = (select LovID from ser.RefLOV where LOVKey = 'RETAIL_TRANS_AGG' 
            AND  LovSetID = (select  LovSetID from ser.RefLOVSet where LOVsetName = 'Measure Type' and activeflag = '1'))
			AND LOVRecordSourceID =@LovRecordSourceID AND SCDactiveflag = 'Y'

SELECT  @MeasureId1 =  MeasureID FROM ser.MEASURE WHERE MeasureName = ('tisp') 
			AND LovMeasureTypeID = (select LovID from ser.RefLOV where LOVKey = 'RETAIL_TRANS_AGG' 
            AND  LovSetID = (select  LovSetID from ser.RefLOVSet where LOVsetName = 'Measure Type' and activeflag = '1'))
			AND LOVRecordSourceID =@LovRecordSourceID AND SCDactiveflag = 'Y'

SELECT  @MeasureId2 =  MeasureID FROM ser.MEASURE WHERE MeasureName = ('tesp') 
			AND LovMeasureTypeID = (select LovID from ser.RefLOV where LOVKey = 'RETAIL_TRANS_AGG' 
            AND  LovSetID = (select  LovSetID from ser.RefLOVSet where LOVsetName = 'Measure Type' and activeflag = '1'))
			AND LOVRecordSourceID =@LovRecordSourceID AND SCDactiveflag = 'Y'
SELECT @LOVUOMId = LOVID from ser.RefLov where 
LOVKey = 'Unit'
AND LOVSetID = (select  LOVSetID from ser.RefLovSet where LOVSetName = 'Unit Of Measure'and recordsourceid = 12012) 
and activeflag = '1'


SELECT @LOVUOMId1 = LOVID from ser.RefLov where 
LOVKey = 'NOK'
AND LOVSetID = (select  LOVSetID from ser.RefLovSet where LOVSetName = 'Currency ISO 4217' and recordsourceid = 12012) 
and activeflag = '1'

	
	
	--Start Processing for the serve layer load

	/********************************************************************************************************************************

	1. Table Name  :	Transaction 

	********************************************************************************************************************************/
	BEGIN TRY
	SET @tablecolumns =	   '[TransactionId]'+
	',[SourceKey]'+
	',[LOVTransactionTypeId]'+
	',[SiteRoleId]'+
	',[TransactionDatetime]'+
	',[TillId]'+
	',[TillTransactionNumber]'+
	',[LOVLevelId]'+
	',[LovRecordSourceId]'+
	',[SCDStartDate]'+
	',[SCDEndDate]'+
	',[SCDActiveFlag]'+
	',[SCDVersion]'+
	',[SCDLovRecordSourceId]'+
	',[ETLRunLogId]'+
	',[PSARowKey]'  


	IF OBJECT_ID('tempdb..#no_crp_item_transaction_Transaction') IS NOT NULL
		DROP TABLE #no_crp_item_transaction_Transaction;

	SET @exec_sql = ' SELECT TOP 0 '+@tablecolumns+' INTO #no_crp_item_transaction_Transaction FROM [ser].[Transaction]'
	EXEC(@exec_sql)	

	PRINT 'Info: Starting Transaction Table Serve Load';

	PRINT 'Info: Inserting the new version of record if there is a change in the attribute';

		

	INSERT INTO #no_crp_item_transaction_Transaction
	select 
	 [TransactionId],
	 [SourceKey],
	 [LOVTransactionTypeId],
	 [SiteRoleId],
	 [TransactionDatetime],
	 [TillId],
	 [TillTransactionNumber],
	 [LOVLevelId],
	 [LovRecordSourceId],
	 [SCDStartDate],
	 [SCDEndDate],
	 [SCDActiveFlag],
	 [SCDVersion],
	 [SCDLovRecordSourceId],
	 [ETLRunLogId],
	 [PSARowKey] 
	 from 
	 (
		Select 
		       0 as TransactionID,		
				Concat (src.[transaction_date],'-','DUMSTRNorway01','-','NorwayTill01') as SourceKey,
				@lovTransactionTypeId as LOVTransactionTypeId,
				t.SiteRoleId as SiteRoleID,
				concat(substring(src.[transaction_date],1,4),'-',substring(src.[transaction_date],5,2),'-',substring(src.[transaction_date],7,2)) as TransactionDatetime,
				ti.tillid as TillId,
				null as TillTransactionNumber,
				null as LovLevelId,	
				@LovRecordSourceId as LovRecordSourceId,
				null as SCDStartDate,
				null as SCDEndDate,
				null as SCDActiveFlag,
				null as SCDVersion,
				@scdLovRecordSourceId as SCDLovRecordSourceId,
				@inpServeETLRunLogId  as ETLRunLogId,
				src.[row_id] as PSARowKey
				
			    FROM
			    (select transaction_date,max(row_id) as row_id from 
				psa.[no_crp_item_transaction] where active_Flag = 'Y' and row_status=26001 group by  transaction_date )src			
				INNER JOIN
				ser.Siterole t  ON t.SourceKey ='DUMSTRNorway01'
				AND t.LovrecordsourceID =  @LovRecordSourceId
				AND t.SCDActiveFlag = 'Y'
				INNER JOIN 
				ser.till ti ON ti.sourcekey ='NorwayTill01'
				AND t.LovrecordsourceID =  @LovRecordSourceId
				AND t.SCDActiveFlag = 'Y'

				)
				a;
				



	--/* Perform SCD and Load into Target Table */

	SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	/* 

	Change Following Parameters

	1.  @l_source_table = N'XXXX' : Needs to be either the Temp table name or 
		the existing table name which contains the records.
	2.  @l_drop_target = 0	: If you don't need to know the PK's which have been created you can drop this.

	*/

	EXEC [psa].[sp_inc_perform_scd]
	@l_source_table = N'#no_crp_item_transaction_Transaction',
	@l_target_schema = N'ser',
	@l_target_table = N'[Transaction]',
	@l_table_bus_pk = N' SourceKey,LOVTransactionTypeId,SiteRoleId,TransactionDatetime,TillId,LovRecordSourceId',
	@l_table_pk = N'TransactionId',
	@l_table_columns = @tablecolumns,
	@l_drop_source = 1, 
	@l_drop_target = 0



	PRINT 'Info: Transaction Table Loaded Successfully'; 
	END TRY
	
	BEGIN CATCH
		SET @msg = 'psa.sp_no_crp_item_transaction FAILED. Error inserting into [ser].[Transaction] table:'+ error_message();
		RAISERROR (@msg, 16, 1);
		throw;
		END CATCH
		
/********************************************************************************************************************************

 2. Table Name  :	Product 

--********************************************************************************************************************************/
	BEGIN TRY
	SET @tablecolumns =		'[ProductId]'+
							',[SourceKey]'+
							',[LOVSourceKeyTypeId]'+
							',[ProductName]'+
							',[ProductDescription]'+
							',[LOVBrandId]'+
							',[LOVSubBrandId]'+
							',[LOVRecordSourceId]'+
							',[ParentProductId]'+
							',[SCDStartDate]'+
							',[SCDEndDate]'+
							',[SCDActiveFlag]'+
							',[SCDVersion]'+
							',[SCDLOVRecordSourceId]'+
							',[ETLRunLogId]'+
							',[PSARowKey]'

	PRINT 'Info: Product Table Serve Loading Started';

	PRINT 'Info: Inserting the new version of record if there is a change in the attribute';

	
	/* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */

	IF OBJECT_ID('tempdb..#no_crp_item_transaction_product') IS NOT NULL
	DROP TABLE #no_crp_item_transaction_product;

	SET @exec_sql = ' SELECT TOP 0 '+@tablecolumns+' INTO #no_crp_item_transaction_product FROM [ser].[Product]'
	EXEC(@exec_sql)


	INSERT INTO #no_crp_item_transaction_product
	SELECT		ProductID,SourceKey,LOVSourceKeyTypeId,ProductName,ProductDescription,LOVBrandId,LOVSubBrandId,LovRecordSourceID,ParentProductId,SCDStartDate,
				SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PsaRowID 
				FROM
				(
				SELECT distinct
				0							as ProductID,
				src.item_code         		as SourceKey, 
				@LOVSourceKeyTypeId			as LOVSourceKeyTypeId,
				NULL                    	as ProductName,
				NULL						as ProductDescription,
				NULL   					    as LOVBrandId,
				NULL						as LOVSubBrandId,
				@LovRecordSourceID 			as LovRecordSourceID,
				NULL 						as [ParentProductId],
				NULL 						as [SCDStartDate],
				NULL 						as [SCDEndDate],
				NULL 						as [SCDActiveFlag],
				NULL 						as [SCDVersion],
				@SCDLOVRecordSourceId 		as [SCDLOVRecordSourceId],
				@inpServeETLRunLogId 		as  ETLRunLogId,
				src.[row_id]    			as 	PsaRowID,
				ROW_NUMBER() OVER (PARTITION BY src.item_code ORDER BY convert(date,src.[transaction_date]) DESC) AS rno
    FROM		[psa].[no_crp_item_transaction] src
	WHERE  		TRIM(src.item_code) IS NOT NULL and src.item_code !=''
				AND src.active_flag = 'Y'
				AND src.row_status = 26001
				)a
	WHERE a.rno = 1
	;

	/* Perform SCD and Load into Target Table */

	SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	/* 
	
	Change Following Parameters
	
	1.  @l_source_table = N'XXXX' : Needs to be either the Temp table name or the existing table name which contains the records.
	2.  @l_drop_target = 0	: If you don't need to know the PK's which have been created you can drop this.

	*/

	EXEC	[psa].[sp_inc_perform_scd]
		@l_source_table = N'#no_crp_item_transaction_product',
		@l_target_schema = N'ser',
		@l_target_table = N'Product',
		@l_table_bus_pk = N'SourceKey,LovRecordSourceID',
		@l_table_pk = N'ProductID',
		@l_table_columns = @tablecolumns,
		@l_drop_source = 1, 
		@l_drop_target = 0

	PRINT 'Info: Product Table -> Closing off old Records if exists';

	PRINT 'Info: Product Table Loaded Successfully'; 

	END TRY
	
	BEGIN CATCH
		SET @msg = 'psa.sp_no_crp_item_transaction FAILED. Error inserting into [ser].[product] table:'+ error_message();
		RAISERROR (@msg, 16, 1);
		throw;
		END CATCH
		


		

	
	/********************************************************************************************************************************

	3 . Table Name  :	Transaction Line Item

	********************************************************************************************************************************/	
	BEGIN TRY
	SET @tablecolumns ='[TransactionLineItemId]'+',
	[TransactionId]'+',
	[SourceKey]'+',
	[ProductId]'+',
	[LOVLineItemTypeId]'+',
	[DealId]'+',
	[LovRecordSourceId]'+',
	[SCDStartDate]'+',
	[SCDEndDate]'+',
	[SCDActiveFlag]'+',
	[SCDVersion]'+',
	[SCDLovRecordSourceId]'+',
	[ETLRunLogId]'+',
	[PSARowKey]' 

	PRINT 'Info: Starting Transaction Line Item Serve Load';

	IF OBJECT_ID('tempdb..#no_crp_item_transaction_Transaction_Line_Item') IS NOT NULL
	DROP TABLE #no_crp_item_transaction_Transaction_Line_Item;

	SET @exec_sql = ' SELECT TOP 0 '+@tablecolumns+' INTO #no_crp_item_transaction_Transaction_Line_Item 
	FROM ser.TransactionLineItem'
	EXEC(@exec_sql)



	Insert into #no_crp_item_transaction_Transaction_Line_Item
	select TransactionLineItemId,
	       TransactionId,
           SourceKey,
		   ProductId,
		   LOVLineItemTypeId,
		   DealId,
		   LovRecordSourceId,
		   SCDStartDate,
		   SCDEndDate,
		   SCDActiveFlag,
		   SCDVersion,
		   SCDLovRecordSourceId,
		   ETLRunLogId,
		   PSARowKey
		   from 
		   (
           		   
		Select  0 as TransactionLineItemId,			
			trcn.TransactionId  as TransactionId,
            Concat (src.[transaction_date],'-','DUMSTRNorway01','-','NorwayTill01','-',src.[item_code]) as SourceKey,
			prdt.ProductId as ProductId,
			NULL as LOVLineItemTypeId,
			NULL as DealId,
			@LovRecordSourceId  as LovRecordSourceId,
			null as SCDStartDate,
			null as SCDEndDate,
			null as SCDActiveFlag,
			null as SCDVersion,
			@scdLovRecordSourceId as SCDLovRecordSourceId,
			@inpServeETLRunLogId   as ETLRunLogId,
			src.row_id  as PSARowKey
			FROM
            (select item_code,transaction_date, max(row_id) as row_id from  psa.[no_crp_item_transaction]  where row_status=26001 and active_flag='Y'
			And item_code is not null and item_code != '' group by item_code,transaction_date)src	
			INNER JOIN ser.[Transaction] trcn on trcn.SourceKey = Concat (src.[transaction_date],'-','DUMSTRNorway01','-','NorwayTill01')  and trcn.LovRecordSourceId= @LovRecordSourceId and trcn.SCDActiveFlag = 'Y'	
		    INNER JOIN ser.Product prdt on prdt.sourcekey = src.item_code and prdt.LOVSourceKeyTypeId =@LOVSourceKeyTypeId
			AND prdt.LovRecordSourceId =  @LovRecordSourceId and prdt.SCDActiveFlag = 'Y'
			
			
			)a
			;



		
		SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	EXEC	[psa].[sp_inc_perform_scd]
			@l_source_table = N'#no_crp_item_transaction_Transaction_Line_Item',
			@l_target_schema = N'ser',
			@l_target_table = N'TransactionLineItem',
			@l_table_bus_pk = N'TransactionId,ProductId,LovRecordSourceId',
			@l_table_pk = N'TransactionLineItemId',
			@l_table_columns = @tablecolumns,
			@l_drop_source = 1, 
			@l_drop_target = 0
			

	PRINT 'Info: Transaction Line Item Table Loaded Successfully'; 
	END TRY
	
	BEGIN CATCH
		SET @msg = 'psa.sp_no_crp_item_transaction FAILED. Error inserting into [ser].[TransactionLineItem] table:'+ error_message();
		RAISERROR (@msg, 16, 1);
		throw;
		END CATCH
		

/********************************************************************************************************************************

	3. Table Name  :	Transaction Line Item Measure

	********************************************************************************************************************************/	
		BEGIN TRY
		 SET @tablecolumns = '[TransactionLineItemMeasureId]'+					
                        ',[TransactionLineItemId]'+
                        ',[MeasureId]'+
						',[Value]'+
						',[LOVUOMId]'+
                        ',[LOVRecordSourceId]'+
                        ',[SCDStartDate]'+
                        ',[SCDEndDate]'+
                        ',[SCDActiveFlag]'+
                        ',[SCDVersion]'+
                        ',[SCDLOVRecordSourceId]'+
                        ',[ETLRunLogId]'+
                        ',[PSARowKey]';

    PRINT 'Info: TransactionLineItemMeasure Table Serve Loading Started';
    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';

    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */

    IF OBJECT_ID('tempdb..#no_crp_item_transactio_transactionlineitemmeasure') IS NOT NULL
    DROP TABLE #no_crp_item_transactio_transactionlineitemmeasure;

    SET @exec_sql = ' SELECT TOP 0 '+@tablecolumns+' INTO #no_crp_item_transactio_transactionlineitemmeasure FROM [ser].[TransactionLineItemMeasure]'
    EXEC(@exec_sql)

    INSERT INTO #no_crp_item_transactio_transactionlineitemmeasure
    SELECT TransactionLineItemMeasureId,TransactionLineItemId,MeasureId,Value,LOVUOMId,LovRecordSourceID,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
        FROM(SELECT distinct
			0						     as TransactionLineItemMeasureId,
			tgt.TransactionLineItemId    as TransactionLineItemId,
            @MeasureId  	             as MeasureId,
            cast (SUM(cast(src.units as decimal(10,2))) as varchar)        as Value,
			@LOVUOMId                    as LOVUOMId,
            @LovRecordSourceID      as LovRecordSourceID,
            NULL                    as [SCDStartDate],
            NULL                    as [SCDEndDate],
            NULL                    as [SCDActiveFlag],
            NULL                    as [SCDVersion],
            @SCDLOVRecordSourceId   as [SCDLOVRecordSourceId],
            @inpServeETLRunLogId    as ETLRunLogId,
            max(src.row_id)             as PSARowKey
		   FROM 
		    (select units,item_code,transaction_date,row_id FROM  psa.[no_crp_item_transaction] WHERE  units IS NOT NULL and units != ''
			and item_code IS NOT NULL and item_code!= ''
		    and active_flag ='Y' and row_status = 26001)src
			JOIN ser.TransactionLineItem tgt
			ON (tgt.sourcekey = Concat (src.[transaction_date],'-','DUMSTRNorway01','-','NorwayTill01','-',src.[item_code]) and tgt.LovRecordSourceID =@LovRecordSourceId AND tgt.SCDActiveFlag = 'Y' )
			 GROUP BY tgt.TransactionLineItemId

		
			
			UNION ALL
			
			
			SELECT distinct
			0						     as TransactionLineItemMeasureId,
			tgt.TransactionLineItemId    as TransactionLineItemId,
            @MeasureId1  	             as MeasureId,
            cast (SUM(cast(src.tisp as decimal(10,2))) as varchar)     as Value,
			@LOVUOMId1                    as LOVUOMId,
            @LovRecordSourceID      as LovRecordSourceID,
            NULL                    as [SCDStartDate],
            NULL                    as [SCDEndDate],
            NULL                    as [SCDActiveFlag],
            NULL                    as [SCDVersion],
            @SCDLOVRecordSourceId   as [SCDLOVRecordSourceId],
            @inpServeETLRunLogId    as ETLRunLogId,
            max(src.row_id)             as PSARowKey

			FROM 
		    (select tisp,item_code,transaction_date,row_id FROM  psa.[no_crp_item_transaction] WHERE  tisp IS NOT NULL and tisp != ''
			and item_code IS NOT NULL and item_code!= ''
		    and active_flag ='Y' and row_status = 26001)src
			JOIN ser.TransactionLineItem tgt
			ON (tgt.sourcekey = Concat (src.[transaction_date],'-','DUMSTRNorway01','-','NorwayTill01','-',src.[item_code]) and tgt.LovRecordSourceID = @LovRecordSourceId AND tgt.SCDActiveFlag = 'Y' )
            GROUP BY tgt.TransactionLineItemId
		

			UNION ALL 

			SELECT distinct
			0						     as TransactionLineItemMeasureId,
			tgt.TransactionLineItemId    as TransactionLineItemId,
            @MeasureId2	             as MeasureId,
            cast (SUM(cast(src.tesp as decimal(10,2))) as varchar)         as Value,
			@LOVUOMId1               as LOVUOMId,
            @LovRecordSourceID      as LovRecordSourceID,
            NULL                    as [SCDStartDate],
            NULL                    as [SCDEndDate],
            NULL                    as [SCDActiveFlag],
            NULL                    as [SCDVersion],
            @SCDLOVRecordSourceId   as [SCDLOVRecordSourceId],
            @inpServeETLRunLogId    as ETLRunLogId,
            max(src.row_id)             as PSARowKey
			FROM 
		    (select tesp,item_code,transaction_date,row_id FROM  psa.[no_crp_item_transaction] WHERE  tesp IS NOT NULL and tesp != ''
			and item_code IS NOT NULL and item_code!= ''
		    and active_flag ='Y' and row_status = 26001)src
			JOIN ser.TransactionLineItem tgt
			ON (tgt.sourcekey = Concat (src.[transaction_date],'-','DUMSTRNorway01','-','NorwayTill01','-',src.[item_code]) and tgt.LovRecordSourceID =@LovRecordSourceId AND tgt.SCDActiveFlag = 'Y' )
			 GROUP BY tgt.TransactionLineItemId


        )a;
		
    /* Perform SCD and Load into Target Table */
    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''');

    EXEC	[psa].[sp_inc_perform_scd]
            @l_source_table = N'#no_crp_item_transactio_transactionlineitemmeasure',
            @l_target_schema = N'ser',
            @l_target_table = N'[TransactionLineItemMeasure]',
            @l_table_bus_pk = N'TransactionLineItemId,MeasureId,LovRecordSourceID',
            @l_table_pk = N'TransactionLineItemMeasureId',
            @l_table_columns = @tablecolumns,
            @l_drop_source = 1, 
            @l_drop_target = 0
			
    PRINT 'Info: TransactionLineItemMeasure Table -> Closing off old Records if exists';
    PRINT 'Info: TransactionLineItemMeasure Table Loaded Successfully'; 

  	END TRY
       
    BEGIN CATCH
        SET @msg = 'psa.sp_no_crp_item_transaction FAILED. Error inserting into [ser].[TransactionLineItemMeasure] table:'+ error_message();
        RAISERROR (@msg, 16, 1);
        throw;
     END CATCH

	 
	/********************************************************************************************************************************

	updating PSA table row status

	********************************************************************************************************************************/	
	 
	BEGIN TRY
	
	UPDATE psa.[no_crp_item_transaction]
	SET row_status = 26002 
	WHERE active_flag = 'Y'
	AND row_status = 26001
	
	END TRY
	
	BEGIN CATCH
		SET @msg = 'psa.sp_no_crp_item_transaction FAILED. Error updating row_status in table psa.[no_crp_item_transaction]'+ error_message();
		RAISERROR (@msg, 16, 1);
		throw;
		END CATCH

END
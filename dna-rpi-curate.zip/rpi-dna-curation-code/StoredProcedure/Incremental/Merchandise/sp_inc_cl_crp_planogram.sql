SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_cl_crp_planogram') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_cl_crp_planogram]
END
GO


CREATE PROCEDURE [psa].[sp_inc_cl_crp_planogram]  @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max)
AS 
/*
************************************************************************************************************
Procedure Name				: sp_inc_cl_crp_planogram
Purpose						: Load Incremental data From International Chile 
Domain						: Merchandise
ServeLayer Target Tables	: Factinstance, Factdimensioninstance, FactmeasureInstance
RecordSourceID  for International Chile : 12001
*****************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  12001 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
 */

	/*--Declarations---*/
	DECLARE @max_FactInstanceId BIGINT,
	        @cl_measureId BIGINT,
			@cl_measuretypeid BIGINT,
	        @rowStatusPSACode BIGINT,	
	        @rowStatusSERCode BIGINT,
	        @rowStatusNotMigratedCode BIGINT,
	        @cl_factId  BIGINT,
	        @cl_recordSourceId BIGINT,
	        @merchandiseRecordSourceId BIGINT,
	        @SCDLOVRecordSourceId BIGINT,
	        @sourcekeytypeid BIGINT,
            @planogramDimId BIGINT,
	        @productDimId BIGINT,
	        @weekDimId BIGINT,
	        @defaultSCDStartDate DATETIME,
	        @defaultSCDEndDate DATETIME;
			
			
			
	/*-------------------------------Create temporary source table-------------------------------*/
	
	IF OBJECT_ID('psa.cl_crp_planogram_temp') IS NOT NULL
	BEGIN
		drop table psa.cl_crp_planogram_temp;
	END
	
	CREATE TABLE [psa].[cl_crp_planogram_temp]
(
    [FactInstanceId]  [bigint] NULL,
	[row_id] [bigint] NOT NULL,
	[pog_id] [nvarchar](80) NULL,
	[week] [nvarchar](80) NULL,
	[item_code] [nvarchar](80) NULL,
	[facings] [nvarchar](255) NULL,
	[date_added] [nvarchar](25) NULL,
	[etl_runlog_id] [int] NULL,
	[asset_id] [int] NULL,
	[record_source_id] [int] NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
);

BEGIN	
	BEGIN TRANSACTION;

	SET @rowStatusPSACode = 26001
    SET @rowStatusSERCode = 26002
    SET @rowStatusNotMigratedCode = 26010	
	SET @cl_recordSourceId = 12001
	SET @SCDLOVRecordSourceId = 12001
	SET @merchandiseRecordSourceId = 12012
	SET @defaultSCDStartDate =  CONVERT(DateTime,'1900-01-01',126)
	SET @defaultSCDEndDate = CONVERT(DateTime,'9999-12-31',126)

	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_FactInstanceId = COALESCE(MAX(FactInstanceId),0) FROM [ser].[FactInstance];
	
	
    -- Fact Id 
	SET @cl_factId = (SELECT FactId FROM  [ser].[fact] WHERE FactName = 'CRP Planogram' AND LOVRecordSourceId = @cl_recordSourceId AND SCDActiveFlag = 'Y' AND LOVFactTypeId in (SELECT LOVId from [ser].RefLOVSetInfo where LOVsetName='Fact Type' and LOVRecordSourceId = @merchandiseRecordSourceId and LOVKey = 'TBC'))
	
	--Source keytype Id
	SET @sourcekeytypeid = (select LOVId from [ser].[reflovsetinfo] where LOVsetName='Source Key Type' and LOVKey = 'Chile Planogram Id(pog_id)' and LOVRecordSourceId = @merchandiseRecordSourceId);
	
	-- Planogram Dimension Id
	SET @planogramDimId = (select DimensionId from [ser].[dimension] where name =  'Planogram' AND  LOVRecordSourceId = @cl_recordSourceId AND SCDActiveFlag = 'Y');
	
	-- Product Dimension Id
	SET @productDimId = (select DimensionId from [ser].[dimension] where name =  'Product' AND  LOVRecordSourceId = @cl_recordSourceId AND SCDActiveFlag = 'Y');
	
	-- Week Dimension Id
	SET @weekDimId = (select DimensionId from [ser].[dimension] where name =  'Week' AND  LOVRecordSourceId = @cl_recordSourceId AND SCDActiveFlag = 'Y');
	
	-- Measure Type Id
	SET @cl_measuretypeid = (SELECT LOVId from [ser].[RefLOVSetInfo] where LOVsetName='Measure Type' AND LovRecordSourceId = @merchandiseRecordSourceId AND LOVKey='PLANOGRAM_AGGREGATION');
	
	-- Facings Measure Id
	SET @cl_measureId = (select MeasureId from ser.measure where MeasureName = 'facings' and LOVRecordSourceId = @cl_recordSourceId and SCDActiveFlag = 'Y' AND LOVMeasureTypeId = @cl_measuretypeid);
	
	
	/* If the date_added value in the new file <= the date_added for the previous  data load , then change status of those records to 26010 */
   
    update [psa].[cl_crp_planogram]       
        set row_status = @rowStatusNotMigratedCode
        where row_id in (
                    SELECT
                        A.row_id
                    from [psa].[cl_crp_planogram] A
                    JOIN (select distinct pog_id,record_source_id,Max(date_added) as date_added from [psa].[cl_crp_planogram]
                    where row_status = @rowStatusSERCode group by pog_id,record_source_id) B
                    on  A.pog_id=B.pog_id 
                    and A.record_source_id = B.record_source_id					
                    and A.date_added<=B.date_added
                    and A.row_status = @rowStatusPSACode
                );
	
	PRINT 'INFO : Completed row_status updation of source after checking previously processed dates'
	

 BEGIN TRY
	
	INSERT INTO psa.cl_crp_planogram_temp 
	(
	[FactInstanceId],
	[row_id],
	[pog_id],
	[week],
	[item_code],
	[facings],
	[date_added],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp]
	)
	SELECT
    @max_FactInstanceId + (ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS [FactInstanceId],a.* 
	FROM (select distinct * from psa.cl_crp_planogram where row_status = @rowStatusPSACode )a ;
	
	PRINT 'Info : Completed insertion of International Chile Incremental source data to temporary table psa.cl_crp_planogram_temp'
	


	
	
    /*--------------------------------Loading Fact Instance table---------------------------------*/
	
	
	INSERT INTO [ser].[FactInstance]
	(
	[FactInstanceId]
    ,[FactId]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
	SELECT
		[FactInstanceId]
		,@cl_factId AS [FactId]
		,@cl_recordSourceId AS [LOVRecordSourceId]
		,@defaultSCDStartDate AS [SCDStartDate]
		,@defaultSCDEndDate AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS [SCDVersion]
		,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		,row_id AS [PSARowKey]
		FROM psa.cl_crp_planogram_temp ;

	PRINT 'Info : Completed insertion of International Chile Incremental source data (planogram) to FactInstance table'	
		
		
		
			/*--------------------------------Loading Fact Dimension Instance table---------------------------------*/
		
	PRINT 'Info: Updating Planogram Dimensions for existing DimensionSurrogateKey NULL records ';	
			
	    UPDATE [ser].[FactDimensionInstance]
		SET DimensionSurrogateKey = lkp_plan.PlanogramId
		FROM
		[ser].[FactDimensionInstance] src
		JOIN 
		(select PlanogramId,SourceKey from [ser].[Planogram] where SCDActiveFlag='Y' and Lovrecordsourceid=@cl_recordSourceId AND LOVSourceKeyTypeId = @sourcekeytypeid 
		-- and SCDLOVRecordSourceId = @SCDLOVRecordSourceId 
		)lkp_plan
        ON src.DimensionSourceKey = lkp_plan.SourceKey
        JOIN
        (select DimensionSourceKey,count(*) as cnt  from 
        (select distinct p.DimensionSourceKey,plano.PlanogramId 
        from [ser].[FactDimensionInstance] p 
        join 
        (select PlanogramId,SourceKey from [ser].[Planogram] where SCDActiveFlag='Y' and Lovrecordsourceid=@cl_recordSourceId AND LOVSourceKeyTypeId = @sourcekeytypeid 
		-- and SCDLOVRecordSourceId = @SCDLOVRecordSourceId 
		)plano
        ON p.DimensionSourceKey = plano.SourceKey )A group by DimensionSourceKey having count(*)=1)lkp_pog
        ON lkp_plan.SourceKey = lkp_pog.DimensionSourceKey
		where src.DimensionSurrogateKey is NULL and src.DimensionId = @planogramDimId and src.LOVRecordSourceId = @cl_recordSourceId 
		-- and src.SCDLOVRecordSourceId = @SCDLOVRecordSourceId;
		
		
	
	PRINT 'Info: Updating Product Dimensions for existing DimensionSurrogateKey NULL records ';

    UPDATE [ser].[FactDimensionInstance]
		SET DimensionSurrogateKey = lkp_prod.ProductId
		FROM
		[ser].[FactDimensionInstance] src
		JOIN 
		(select * from [ser].[product] where SCDActiveFlag = 'Y' AND LOVRecordSourceId = @cl_recordSourceId 
		-- AND SCDLOVRecordSourceId = @SCDLOVRecordSourceId
		) lkp_prod
     	ON lkp_prod.SourceKey = src.DimensionSourceKey
		AND src.LOVRecordSourceId = lkp_prod.LOVRecordSourceId
		where src.DimensionSurrogateKey is NULL and src.DimensionId = @productDimId and src.LOVRecordSourceId = @cl_recordSourceId 
		-- and src.SCDLOVRecordSourceId = @SCDLOVRecordSourceId;
		
		
	
	PRINT 'Info: Existing DimensionSurrogateKey NULL update completed ';
	

	INSERT INTO [ser].[FactDimensionInstance]
     	([FactInstanceId]
         ,[DimensionId]
         ,[DimensionSurrogateKey]
         ,[DimensionSourceKey]
     	 ,[LOVRecordSourceId]
         ,[SCDStartDate]
         ,[SCDEndDate]
         ,[SCDActiveFlag]
         ,[SCDVersion]
         ,[SCDLOVRecordSourceId]
         ,[ETLRunLogId]
     	,[PSARowKey]
     	)
  		SELECT
     		 [FactInstanceId]
     		,[DimensionId]
     		,[DimensionSurrogateKey]
     		,[DimensionSourceKey]
     		,[LOVRecordSourceId]
     		,[SCDStartDate]
     		,@defaultSCDEndDate  AS [SCDEndDate]
     		,'Y'  AS [SCDActiveFlag]
     		,1 AS [SCDVersion]
     		,[SCDLOVRecordSourceId]
     		,[ETLRunLogId]
     		,[PSARowKey]
     		FROM
     		(
     			SELECT distinct 
				 src.FactInstanceId AS [FactInstanceId]
     		    ,@planogramDimId AS [DimensionId]
     			,CASE WHEN lkp_pog.cnt = 1 THEN lkp_plan.PlanogramId ELSE NULL END AS [DimensionSurrogateKey]
     			,cast(src.pog_id as varchar(80)) AS [DimensionSourceKey]
     			,@cl_recordSourceId AS [LOVRecordSourceId]
     			,@defaultSCDStartDate AS [SCDStartDate]
     			,NULL AS [SCDEndDate]
     			,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
     			,@serveETLRunLogID AS [ETLRunLogId]
     			,src.row_id AS [PSARowKey]
     			FROM 
     			 psa.cl_crp_planogram_temp src
     			LEFT OUTER JOIN
     			(select PlanogramId,SourceKey from [ser].[Planogram] where SCDActiveFlag='Y' and Lovrecordsourceid=@cl_recordSourceId AND LOVSourceKeyTypeId = @sourcekeytypeid 
				-- and SCDLOVRecordSourceId = @SCDLOVRecordSourceId 
				)lkp_plan
     			ON src.pog_id = lkp_plan.SourceKey
     			LEFT OUTER JOIN
     			(select pog_id,count(*) as cnt  from 
                 (select distinct p.pog_id,plano.PlanogramId 
     			from psa.cl_crp_planogram_temp p 
     			join 
     			(select PlanogramId,SourceKey from [ser].[Planogram] where SCDActiveFlag='Y' and Lovrecordsourceid=@cl_recordSourceId AND LOVSourceKeyTypeId = @sourcekeytypeid 
				-- and SCDLOVRecordSourceId = @SCDLOVRecordSourceId 
				)plano
     			ON p.pog_id = plano.SourceKey )A group by pog_id )lkp_pog
     			ON src.pog_id = lkp_pog.pog_id
     			
     			UNION
     			
     			SELECT
     			src.[FactInstanceId] AS [FactInstanceId]
     			,@productDimId AS [DimensionId]
     			,lkp_prod.ProductId AS [DimensionSurrogateKey]
     			,cast(src.item_code as varchar(80)) AS [DimensionSourceKey]
     			,@cl_recordSourceId AS [LOVRecordSourceId]
     			,@defaultSCDStartDate AS [SCDStartDate]
     			,NULL AS [SCDEndDate]
     			,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
     			,@serveETLRunLogID AS [ETLRunLogId]
     			,src.row_id AS [PSARowKey]
     			FROM 
     			psa.cl_crp_planogram_temp src
     			LEFT OUTER JOIN
     			(select * from [ser].[product] where SCDActiveFlag = 'Y' AND LOVRecordSourceId = @cl_recordSourceId 
				--AND SCDLOVRecordSourceId = @SCDLOVRecordSourceId
				) lkp_prod
     			ON (lkp_prod.SourceKey = src.item_code AND lkp_prod.LOVRecordSourceId = @cl_recordSourceId)
     			
     			UNION
     			
     			SELECT
     			src.[FactInstanceId] AS [FactInstanceId]
     			,@weekDimId AS [DimensionId]
     			,lkp_refl.LOVId AS [DimensionSurrogateKey]
     			,cast(src.week as varchar(80)) AS [DimensionSourceKey]
     			,@cl_recordSourceId AS [LOVRecordSourceId]
     			,@defaultSCDStartDate AS [SCDStartDate]
     			,NULL AS [SCDEndDate]
     			,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
     			,@serveETLRunLogID AS [ETLRunLogId]
     			,src.row_id AS [PSARowKey]
     			FROM 
     			psa.cl_crp_planogram_temp src
     			LEFT OUTER JOIN
     			(SELECT LOVId,LOVKey from [ser].[RefLOVSetInfo] where LOVsetName='week' AND LovRecordSourceId = @cl_recordSourceId) lkp_refl
     			ON src.week = lkp_refl.LOVKey 
     		)a
     		;
	
		
		PRINT 'Info : Completed insertion of International Chile Incremental source data (planogram) to FactDimensionInstance table'
	
	
		/*--------------------------------Loading Fact Measure Instance table---------------------------------*/
	
    INSERT INTO [ser].[FactMeasureInstance]
    	(
    	 [FactInstanceId]
        ,[MeasureId]
        ,[Value]
    	,[LOVRecordSourceId]
        ,[SCDStartDate]
        ,[SCDEndDate]
        ,[SCDActiveFlag]
        ,[SCDVersion]
        ,[SCDLOVRecordSourceId]
        ,[ETLRunLogId]
    	,[PSARowKey]
    	)
    		SELECT
    		 [FactInstanceId]
    		,[MeasureId]
    		,[Value]
    		,[LOVRecordSourceId]
    		,[SCDStartDate]
    		,@defaultSCDEndDate AS [SCDEndDate]
    		,'Y' AS [SCDActiveFlag]
    		,1 AS [SCDVersion]
    		,[SCDLOVRecordSourceId]
    		,[ETLRunLogId]
    		,[PSARowKey]
    		FROM
    		(
    			SELECT
    			 FactInstanceId AS [FactInstanceId]
    			,@cl_measureId AS [MeasureId]
    			,facings AS [Value]
    			,@cl_recordSourceId AS [LOVRecordSourceId]
    			,@defaultSCDStartDate AS [SCDStartDate]
    			,NULL AS [SCDEndDate]
    			,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
    			,@serveETLRunLogID AS [ETLRunLogId]
    			,row_id AS [PSARowKey]
    			FROM psa.cl_crp_planogram_temp 
    			WHERE facings IS NOT NULL AND facings <> ''
    		)a
    		;
    		
		
		PRINT 'Info : Completed insertion of International Chile Incremental source data (planogram) to FactMeasureInstance table'	

        
			UPDATE [psa].[cl_crp_planogram] SET [row_status]=@rowStatusSERCode
                FROM [psa].[cl_crp_planogram] cl  
				JOIN 
				(select distinct FactInstanceId,PSARowKey,LOVRecordSourceId FROM [ser].[FactInstance] where [LOVRecordSourceId] = @cl_recordSourceId 
				-- and SCDLOVRecordSourceId = @SCDLOVRecordSourceId 
				and ETLRunLogId = @serveETLRunLogID )temp
				ON cl.row_id = temp.PSARowKey
				AND cl.record_source_id = temp.LOVRecordSourceId
                WHERE cl.row_status=@rowStatusPSACode ;
				
				
			PRINT 'Info : Updated Row Status to ''Loaded to Serve'' for psa.[cl_crp_planogram] International Chile  '
			

    COMMIT TRANSACTION;					
		END TRY
	    BEGIN CATCH
				THROW;
				ROLLBACK TRANSACTION ;	
			END CATCH 

END 
GO
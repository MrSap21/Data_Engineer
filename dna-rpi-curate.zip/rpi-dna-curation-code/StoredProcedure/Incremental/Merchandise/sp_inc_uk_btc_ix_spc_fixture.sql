SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_uk_btc_ix_spc_fixture') IS NOT NULL
BEGIN
DROP PROC [psa].[sp_inc_uk_btc_ix_spc_fixture];
END
GO


CREATE PROC [psa].[sp_inc_uk_btc_ix_spc_fixture] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityID [varchar](max) AS
/*
************************************************************************************************************
Procedure Name				: sp_inc_uk_btc_ix_spc_fixture
Purpose						: Load incremental data from Intactix Planogram Fixture in PSA into Serve Layer Tables
Domain						: Merchandise
ServeLayer Target Tables	: PlanogramFixture, PlanogramFixtureProperty
RecordSourceID  for INTACTIX : 12002
SCDRecordSourceID  for INTACTIX : 12002

*************************************************************************************************************
SCD:
Latest Version: SCD End Date as '31-12-9999' and SCD Active Flag as 'Y'
Previous Version(s): SCD End Date as 1 second less of next versions SCD Start Date and SCD Active Flag as 'N'

Insert of same record:
For an active business key(dbkey), if the same value1 and dbparentplanogramkey are trying to be curated, the record will not be inserted.
The row status in PSA for that record will be marked as 26010.

NULL entries:
If value1 is NULL/blank in PSA, the record will not be inserted, but the current record for the corresponding business key in Serve will be made inactive if exists.
The row status in PSA for that record will still be marked as 26002.

Data Quality:
If a dbparentplanogramkey does not get a match with SourceKey in ser.Planogram, the record will not be processed. A DQ warning will be raised
by making an insert into psa.RuleEntityInstance.
*************************************************************************************************************

Modification History:
21-09-2020: Changed Entity ID to be used to fetch AttributeID from psa.Attribute
28-09-2020: Removed Join with ser.PlanogramFixtureProperty while updating row status to 26002 for records that have NULL/blank value1

*/

DECLARE @SCDLOVRecordSourceID int,
@psaETLRunLogID [varchar](max),
@maxPlanogramFixtureID bigint,
@rlsLOVRecordSourceID bigint,
@SCDDefaultEndDate datetime,
@duplicateRowStatus bigint,
@LOVSourceKeyTypeID bigint,
@LOVRecordSourceID bigint,
@SCDStartDate datetime,
@SCDEndDate datetime,
@psaRowStatus bigint,
@serRowStatus bigint,
@DQCOUNTER bigint, 
@MeasureId bigint,
@LOVUOMID bigint,
@COUNTER bigint,
@MAXID bigint,
@rule_id int,
@asset_id int, 
@DQROWS bigint,
@DQrowid bigint,
@rule_entity_id bigint,
@rule_attribute_id bigint,
@DQcolumn [varchar](max),
@rule_source_entity_id bigint,
@rule_detail [varchar](max),
@rule_dt_created smalldatetime,
@rule_user_created [varchar](max),
@rule_source_attribute_id [varchar](max);


IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
BEGIN
DROP TABLE [psa].[fixture_cursor_table];
END


IF OBJECT_ID('psa.TmpPSATable') IS NOT NULL
BEGIN
DROP TABLE [psa].[TmpPSATable];
END

/**********Creating a temporary table to iterate through all the asset IDs present in PSA table********/
CREATE TABLE [psa].[fixture_cursor_table] (
[RowID] bigint,
[asset_id] int
);

/********Creating a temporary table that will store all dbkey,dbparentplanogramkey,value1 from PSA*****/
CREATE TABLE [psa].[TmpPSATable] (
[dbkey] [nvarchar](80),
[dbparentplanogramkey] [nvarchar](80),
[value1] [nvarchar](255),
[row_id] bigint,
[record_source_id] int,
[dupfixcheck] int,
[dupfixprocheck] int
);


IF OBJECT_ID('ser.TmpRowIDList') IS NOT NULL
BEGIN
DROP TABLE [ser].[TmpRowIDList];
END

CREATE TABLE [ser].[TmpRowIDList] (
[row_id] bigint 
);

BEGIN
BEGIN TRANSACTION

SET @SCDDefaultEndDate=(SELECT CONVERT(datetime,'9999-12-31'));
SET @LOVRecordSourceID=12002;
SET @rlsLOVRecordSourceID=12012;
SET @psaRowStatus=26001;
SET @serRowStatus=26002;
SET @duplicateRowStatus=26010;
SET @SCDLOVRecordSourceID=@LOVRecordSourceID;

SET @LOVSourceKeyTypeID=(SELECT r.LOVID FROM [ser].[RefLOVSetInfo] r where r.LOVKey='Intactix Planogram dbkey' 
AND r.LOVSetName = 'Source Key Type' AND r.LOVRecordSourceID=@rlsLOVRecordSourceID);

SET @MeasureId= (SELECT m.MeasureID FROM [ser].[Measure] m WHERE m.MeasureName='shelf_number' 
AND m.LOVRECORDSOURCEID = @LOVRecordSourceID AND m.SCDActiveFlag = 'Y');

SET @LOVUOMID=(SELECT r.LOVID FROM [ser].[RefLOVSetInfo] r WHERE r.LOVKey = 'Unknown' 
AND r.LOVSetName = 'Unit Of Measure' AND r.LOVRecordSourceID=@rlsLOVRecordSourceID);

SET @rule_id =  (SELECT RuleID FROM [psa].[Rule] WHERE  RuleName = 'Forigen Key Lookup' AND ActiveFlag=1);
SET @rule_entity_id =(SELECT EntityID FROM [psa].[Entity] WHERE EntityName = 'btc_ix_spc_fixture_Incremental_Load_txt' AND ActiveFlag = 1);
SET @rule_attribute_id = (SELECT AttributeID FROM [psa].[Attribute] WHERE AttributeName='dbparentplanogramkey' AND EntityID=@rule_entity_id);
SET @rule_source_entity_id = cast (@psaEntityID as bigint);
SET @rule_source_attribute_id = cast (@rule_attribute_id as varchar);
SET @rule_user_created = SYSTEM_USER;

BEGIN TRY
SET @COUNTER = 1
		SELECT @MAXID = COUNT(distinct asset_id) FROM [psa].[uk_btc_ix_spc_fixture] ixf WHERE row_status=@psaRowStatus;
		print 'Total Number of Loops : '+cast(@MAXID as varchar)+'';
		
		INSERT INTO [psa].[fixture_cursor_table]
		SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (asset_id)) AS RowID,
													asset_id as asset_id
		FROM [psa].[uk_btc_ix_spc_fixture] WHERE row_status=@psaRowStatus;
		
		WHILE (@COUNTER <= @MAXID)
		BEGIN
		Print 'The loop count is '+cast(@COUNTER as varchar);
				/*WITH TempCur AS(
							   SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (asset_id)) AS RowID,
									asset_id as asset_id
							   FROM [psa].[uk_btc_ix_spc_fixture]
							   --WHERE row_status=@psaRowStatus To be reviewed later 
							  
							   )*/
				SELECT @asset_id = asset_id from [psa].[fixture_cursor_table] where  RowID=@COUNTER; 
				PRINT 'Current Asset ID: '+CAST(@asset_id as varchar)+'';
				


SET @maxPlanogramFixtureID= (SELECT COALESCE(MAX(PlanogramFixtureID),0) FROM [ser].[PlanogramFixture] );




DELETE FROM [psa].[TmpPSATable] ;

INSERT INTO [psa].[TmpPSATable] (
				[dbkey],
				[dbparentplanogramkey],
				[value1],
				[row_id],
				[record_source_id],
				[dupfixcheck],
				[dupfixprocheck])
				
SELECT dbkey,
dbparentplanogramkey,
value1,
row_id,
record_source_id,
0 as dupfixcheck,
0 as dupfixprocheck
FROM [psa].[uk_btc_ix_spc_fixture] WHERE asset_id=@asset_id AND row_status=@psaRowStatus;

PRINT 'Setting the flag as 1 for duplicate records, so that they will be assigned duplicate-record row status';
UPDATE [psa].[TmpPSATable] SET dupfixcheck=1 
FROM [psa].[TmpPSATable] tmp 
WHERE EXISTS(SELECT 1 from [ser].[PlanogramFixture] temp WHERE 
					  tmp.dbkey=temp.SourceKey
					  AND temp.PlanogramId IN(SELECT p.PlanogramID from [ser].[Planogram] p WHERE tmp.DBParentPlanogramKey = p.SourceKey AND p.SCDActiveFlag='Y' AND p.LOVRecordSourceID=@LOVRecordSourceID)
					  AND temp.SCDActiveFlag='Y'
					  );
					  
/********Join with Planogramfixture and Planogramfixtureproperty since maximum SCDVersion required instead of SCDActiveFlag check********/
UPDATE [psa].[TmpPSATable] SET dupfixprocheck=1 
FROM [psa].[TmpPSATable] tmp 
JOIN [ser].[PlanogramFixture] pf ON pf.SourceKey=tmp.dbkey and pf.SCDActiveFlag='Y' and pf.LOVRECORDSOURCEID=@LOVRecordSourceID
LEFT JOIN (SELECT PlanogramFixtureID,MAX(SCDVersion) SCDVersion1 FROM [ser].[PlanogramFixtureProperty] WHERE LOVRecordSourceID=@LOVRecordSourceID group by PlanogramFixtureID) pfp 
ON pfp.PlanogramFixtureId = pf.PlanogramFixtureId  and pf.SCDActiveFlag = 'Y' 
WHERE EXISTS (SELECT 1 FROM [ser].[PlanogramFixtureProperty] temp WHERE
					  tmp.dbkey IN (SELECT DISTINCT SourceKey from [ser].[PlanogramFixture] temp1 where temp1.PlanogramFixtureID=temp.PlanogramFixtureID AND temp1.SCDActiveFlag='Y')
					  AND tmp.value1=temp.Value
					  AND temp.SCDVersion=pfp.SCDVersion1
					  AND temp.SCDEndDate=@SCDDefaultEndDate
					  );


SET @SCDStartDate= current_timestamp;
PRINT '****************Inserting into PlanogramFixture Table *********************';
INSERT INTO [ser].[PlanogramFixture] (
	[PlanogramFixtureID]         	,
	[PlanogramID]					,
	[SourceKey]						,
    [LOVRecordSourceID]       		,
    [SCDStartDate]         			,
    [SCDEndDate]         			,
    [SCDActiveFlag]         		,
    [SCDVersion]         			,
    [SCDLOVRecordSourceID]        	,
    [ETLRunLogID]					,
	[PSARowKey])	
	
SELECT ISNULL(pf.PlanogramFixtureID ,@maxPlanogramFixtureID+ROW_NUMBER() OVER(ORDER BY ixf.dbkey)) PlanogramFixtureID, 
	p.PlanogramID PlanogramID,
	ixf.dbkey SourceKey,
    ixf.record_source_id LOVRecordSourceID,
	@SCDStartDate SCDStartDate,
	@SCDDefaultEndDate SCDEndDate,
	'Y' SCDActiveFlag, 
    ISNULL(pf.SCDVersion1,0)+1 SCDVersion,
	@SCDLOVRecordSourceId  SCDLOVRecordSourceID,
	@serveETLRunLogID ETLRunLogID,
	ixf.row_id PSARowKey
FROM [psa].[TmpPSATable] ixf         
    JOIN [ser].[Planogram] p on ixf.DBParentPlanogramKey = p.SourceKey 
	and p.LOVSourceKeyTypeId= @LOVSourceKeyTypeID and p.LOVRecordSourceId= @LOVRecordSourceID AND p.SCDActiveFlag='Y'	
    LEFT JOIN(SELECT PlanogramFixtureID,SourceKey,MAX(SCDVersion) SCDVersion1 FROM [ser].[PlanogramFixture] WHERE LOVRecordSourceID=@LOVRecordSourceID group by PlanogramFixtureID,SourceKey) pf 
	on ixf.dbkey =pf.SourceKey
	WHERE ixf.dupfixcheck=0;

	
PRINT '****************Inserting into PlanogramFixture Table completed *********************';


PRINT '****************Closing current active records, if any, in PlanogramFixture Table *********************';

UPDATE [ser].[PlanogramFixture]  SET SCDEndDate=(SELECT DATEADD(second,-1,@SCDStartDate)),SCDActiveFlag='N'
					FROM [ser].[PlanogramFixture]  pf
					JOIN (SELECT PlanogramFixtureID,PlanogramID,SourceKey,SCDActiveFlag,SCDVersion,LOVRecordSourceID FROM [ser].[PlanogramFixture] temp WHERE
					temp.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM [ser].[PlanogramFixture] AS temp1 
																WHERE temp1.PlanogramFixtureID = temp.PlanogramFixtureID
																AND temp1.SourceKey=temp.SourceKey
																AND temp1.LOVRecordSourceID=temp.LOVRecordSourceID
																AND temp1.SCDVersion > temp.SCDVersion) )pf2
					 ON  pf.PlanogramFixtureID=pf2.PlanogramFixtureID
					 AND pf.SourceKey=pf2.SourceKey
					 AND pf.LOVRecordSourceID=pf2.LOVRecordSourceID						 
					 AND pf.SCDActiveFlag=pf2.SCDActiveFlag
					 AND pf.SCDVersion!=pf2.SCDVersion
					 JOIN [psa].[TmpPSATable] ixf
					 ON ixf.dbkey=pf.SourceKey
					 AND pf.SCDActiveFlag='Y'
					 WHERE ixf.dupfixcheck=0;
					 
					 
					 
					 





PRINT '****************Inserting into PlanogramFixtureProperty Table *********************';
INSERT INTO [ser].[PlanogramFixtureProperty] (
	[PlanogramFixtureId]        ,
    [MeasureID]         		,
    [LOVUOMID]         			,
    [Value]       			    ,
    [LOVRecordSourceID]        	,
    [SCDStartDate]         		,
    [SCDEndDate]         		,
    [SCDActiveFlag]         	,
    [SCDVersion]         		,
    [SCDLOVRecordSourceID]      ,
    [ETLRunLogID]				,
    [PSARowKey]	)
	

SELECT 	pf.PlanogramFixtureID PlanogramFixtureID,
		@MeasureID MeasureID,
		@LOVUOMID LOVUOMID,
		ixf.value1 [Value],
		ixf.record_source_id LOVRecordSourceID,
		@SCDStartDate SCDStartDate,
		@SCDDefaultEndDate SCDEndDate,
		'Y' SCDActiveFlag,
		ISNULL(pfp.SCDVersion1,0)+1 SCDVersion,
		@SCDLOVRecordSourceId  SCDLOVRecordSourceID,
		@serveETLRunLogID ETLRunLogID,
		ixf.row_id PSARowKey
FROM [psa].[TmpPSATable] ixf
	 JOIN [ser].[PlanogramFixture] pf ON pf.SourceKey=ixf.dbkey and pf.SCDActiveFlag='Y' and pf.LOVRECORDSOURCEID=@LOVRecordSourceID
	 LEFT JOIN (SELECT PlanogramFixtureID,MAX(SCDVersion) SCDVersion1 FROM [ser].[PlanogramFixtureProperty] WHERE LOVRecordSourceID=@LOVRecordSourceID group by PlanogramFixtureID) pfp 
	 ON pfp.PlanogramFixtureId = pf.PlanogramFixtureId  and pf.SCDActiveFlag = 'Y' 
	 WHERE ixf.dupfixprocheck=0 AND ixf.value1 IS NOT NULL AND ixf.value1!='' AND ixf.value1!='NULL'

	
PRINT '****************Inserting into PlanogramFixtureProperty completed *********************';

PRINT '****************Closing current active records, if any, in PlanogramFixtureProperty Table *********************';

UPDATE [ser].[PlanogramFixtureProperty]  SET SCDEndDate=(SELECT DATEADD(second,-1,@SCDStartDate)),SCDActiveFlag='N'
					FROM [ser].[PlanogramFixtureProperty]  pfp
					JOIN (SELECT PlanogramFixtureID,LOVUOMID,Value,SCDActiveFlag,SCDVersion,LOVRecordSourceID FROM [ser].[PlanogramFixtureProperty] temp WHERE   
					temp.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM [ser].[PlanogramFixtureProperty] AS temp1 
																WHERE temp1.PlanogramFixtureID = temp.PlanogramFixtureID
																AND temp1.LOVUOMID=temp.LOVUOMID
																AND temp1.LOVRecordSourceID=temp.LOVRecordSourceID
																AND temp1.SCDVersion > temp.SCDVersion) )pfp2
					 ON  pfp.PlanogramFixtureID=pfp2.PlanogramFixtureID
					 AND pfp.LOVRecordSourceID=pfp2.LOVRecordSourceID						 
					 AND pfp.SCDActiveFlag=pfp2.SCDActiveFlag
					 AND pfp.SCDVersion!=pfp2.SCDVersion
					 AND pfp.LOVUOMID=pfp2.LOVUOMID
					 LEFT JOIN [ser].[PlanogramFixture] pftemp
					 ON pftemp.PlanogramFixtureID=pfp.PlanogramFixtureID and pftemp.SCDActiveFlag='Y'
					 JOIN [psa].[TmpPSATable] ixf
					 ON ixf.dbkey=pftemp.SourceKey
					 AND pfp.SCDActiveFlag='Y'
					 WHERE ixf.dupfixprocheck=0;
					 
/********Closing current active records that have null/blank value1***************/
UPDATE [ser].[PlanogramFixtureProperty]  SET SCDEndDate=(SELECT DATEADD(second,-1,@SCDStartDate)),SCDActiveFlag='N'
					FROM [ser].[PlanogramFixtureProperty]  pfp
					LEFT JOIN [ser].[PlanogramFixture] pftemp
					ON pftemp.PlanogramFixtureID=pfp.PlanogramFixtureID AND pftemp.SCDActiveFlag='Y'
					JOIN  [psa].[TmpPSATable] ixf
					ON ixf.dbkey=pftemp.SourceKey
					WHERE NULLIF(ixf.value1,'' ) IS NULL
					AND pfp.SCDActiveFlag='Y'
					AND ixf.dupfixprocheck=0;
					 
					 


					 
DELETE FROM [ser].[TmpRowIDList];

INSERT INTO [ser].[TmpRowIDList] 
select distinct PSARowKey from [ser].[PlanogramFixture] where SCDActiveFlag='Y' AND SCDStartDate=@SCDStartDate;
INSERT INTO [ser].[TmpRowIDList] 
select distinct PSARowKey from [ser].[PlanogramFixtureProperty] where SCDActiveFlag='Y' AND SCDStartDate=@SCDStartDate;

PRINT 'Setting row status to duplicate-record(26010)';
UPDATE [psa].[uk_btc_ix_spc_fixture] SET row_status=@duplicateRowStatus
FROM [psa].[uk_btc_ix_spc_fixture] ixf JOIN [psa].[TmpPSATable] tmp
ON ixf.dbkey=tmp.dbkey AND ixf.dbparentplanogramkey=tmp.dbparentplanogramkey 
AND ixf.value1=tmp.value1 AND tmp.dupfixcheck=1 AND tmp.dupfixprocheck=1 AND ixf.asset_id=@asset_id;

PRINT 'Setting row status to processed(26002)';
UPDATE [psa].[uk_btc_ix_spc_fixture] SET row_status=@serRowStatus
FROM [psa].[uk_btc_ix_spc_fixture] ixf WHERE ixf.row_id IN (SELECT distinct t.row_id from [ser].[TmpRowIDList] t) AND ixf.row_status!=@duplicateRowStatus
AND row_status=@psaRowStatus AND ixf.asset_id=@asset_id;

PRINT 'Setting row status to processed(26002) for records that were processed but not inserted due to blank or NULL value1';
UPDATE [psa].[uk_btc_ix_spc_fixture] SET row_status=@serRowStatus
FROM [psa].[uk_btc_ix_spc_fixture] ixf 
JOIN [ser].[PlanogramFixture] pftemp
ON ixf.dbkey=pftemp.SourceKey and pftemp.LOVRecordSourceID=@LOVRecordSourceID AND pftemp.SCDActiveFlag='Y'
WHERE ixf.row_status=@psaRowStatus
AND ixf.asset_id=@asset_id
AND NULLIF(ixf.value1,'' ) IS NULL;



PRINT 'Raising DQ Warning for missing dbparentplanogramkey, if any';
SET @DQCOUNTER = 1;
		SELECT @DQROWS = COUNT(*) FROM [psa].[uk_btc_ix_spc_fixture] ixf WHERE row_status=@psaRowStatus and asset_id=@asset_id;
		IF @DQROWS =0
		BEGIN
		PRINT 'No DQ warning to be raised for Asset ID ' +cast(@asset_id as varchar) + '.';
		END
		WHILE (@DQCOUNTER <= @DQROWS)
		BEGIN
				WITH DQWarning AS(
							   SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (row_id)) AS RowID,
									row_id as row_id,
									dbparentplanogramkey as dbparentplanogramkey
							   FROM [psa].[uk_btc_ix_spc_fixture] WHERE row_status=@psaRowStatus and asset_id=@asset_id
							  
							   )
				SELECT @DQrowid = row_id, @DQcolumn= dbparentplanogramkey FROM DQWarning WHERE RowID=@DQCOUNTER;
				
SET @rule_dt_created = CAST(GETDATE() AS SMALLDATETIME);
SET @rule_detail='DQ Warning- The dbparentplanogramkey ' +@DQcolumn + ' of Asset ID ' +cast(@asset_id as varchar) + ' in psa.uk_btc_ix_spc_fixture does not have corresponding match in ser.Planogram.';


				
INSERT INTO [psa].[RuleEntityInstance] (
	[RuleID]			,
    [EntityID]			,
    [AttributeID]		,
    [RuleDetail]		,
    [ETLRunLogID]		,
    [SourceEntityID]	,
    [SourceAttributeID]	,
    [PSARowKey]			,
    [DTCreated]			,
    [UserCreated] )
	
VALUES
           (@rule_id
           --,@rule_entity_id
		   ,@psaEntityID
           ,@rule_attribute_id
           ,@rule_detail
           ,@serveETLRunLogID
           ,@rule_source_entity_id
           ,@rule_source_attribute_id
           ,@DQrowid
           ,@rule_dt_created
           ,@rule_user_created)
		   
SET @DQCOUNTER = @DQCOUNTER + 1 ;
		END
		
					 
					 
					 
SET @COUNTER = @COUNTER + 1    ;
        END

COMMIT TRANSACTION;
END TRY
            BEGIN CATCH
                THROW;                   
                ROLLBACK TRANSACTION ;                       
            END CATCH
			
 END
 
IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
BEGIN
DROP TABLE [psa].[fixture_cursor_table];
END
IF OBJECT_ID('psa.TmpPSATable') IS NOT NULL
BEGIN
DROP TABLE [psa].[TmpPSATable];
END
IF OBJECT_ID('ser.TmpRowIDList') IS NOT NULL
BEGIN
DROP TABLE [ser].[TmpRowIDList];
END

 
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[psa].[sp_inc_th_crp_merchandise]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_th_crp_merchandise] 
END
GO

CREATE PROC [psa].[sp_inc_th_crp_merchandise] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max) AS 
BEGIN
IF OBJECT_ID('psa.th_crp_merchandise_temp') is not null
	BEGIN
	DROP TABLE [psa].[th_crp_merchandise_temp]
	END
BEGIN
	CREATE TABLE [psa].[th_crp_merchandise_temp]
	(
		[PSARowKey] [bigint] NOT NULL,
		[LOVSourceKeyTypeId] [int] NULL,
		[PlanogramID] [bigint] NULL,
		[ParentPlanogramID] [bigint] NULL,
		[sourceKey] [nvarchar](80) NULL,
		[pog_description] [nvarchar](80) NULL,
		[planogram_start_date] datetime NULL,	
		[planogram_end_date] datetime NULL, 
		[shelf_depth] [nvarchar](255) NULL,
		[height] [nvarchar](255) NULL,
		[fitting_type] [nvarchar](255) NULL,
		[build_size] [nvarchar](255) NULL,
		[planner_family] [nvarchar](255) NULL,
		[footprint] [nvarchar](255) NULL,
		[category] [nvarchar](255) NULL,
		[format] [nvarchar](255) NULL,
		[promotional_site] [nvarchar](255) NULL,
		[date_added] DATETIME NULL,
		[etl_runlog_id] [int] NULL,
		[asset_id] [int] NULL,
		[LOVRecordSourceId] [int] NULL,
		[row_status] [int] NULL,
		[created_timestamp] [datetime] NULL
	)
	WITH
	(
		DISTRIBUTION = REPLICATE,
		CLUSTERED COLUMNSTORE INDEX
	)
END

DECLARE @max_planogramID				BIGINT,
		@pogid_sourceKeyTypeID	BIGINT,
		@rowStatusPSACode	BIGINT = 26001,
		@rowStatusSERCode	BIGINT = 26002,
		@rowStatusNotmigratedCode BIGINT = 26010,
		--@psaETLRunLogID			VARCHAR(250) = '101',
		--@serveETLRunLogID			VARCHAR(250) = '100',
		@dbkey_sourceKeyTypeID		BIGINT,
		@max_planogramTempID		BIGINT,
		@SCDDefaultStartDate		DATETIME,
		@SCDStartDate				DATETIME,
		@SCDDefaultEndDate			DATETIME,
		@SCDEndDate					DATETIME,
		@COUNTER					BIGINT,
		@MAXID						BIGINT,
		@dateAdded					DATETIME,
		@th_lovRecordSourceID	BIGINT = 12010,
		@RecordSourceIdMerchANDise BIGINT = 12012,
		@SCDDefaultActiveFlag		char='Y',
		@SCDDefaultVersion			smallint=1,
		@LOVIndicatorIdEXFlag		BIGINT,
		@measureTypeIdPlanoDim BIGINT,
		@shelfDepthMeasureID BIGINT,
		@heightMeasureID BIGINT,
		@buildSizeMeasureID BIGINT,
		@LOVIdUnitCM BIGINT,
		@LOVIdUnitUnKnown BIGINT,
		@max_PlanogramGroupId BIGINT,
		@indicatorLOVID BIGINT,
		@dbKeyTypeId BIGINT,
		@fittingTypeLOVSetID BIGINT,
		@plannerFamilyLOVSetID BIGINT,
		@footprintLOVSetID BIGINT,
		@categoryLOVSetID BIGINT,
		@formatLOVSetID BIGINT;
		
IF OBJECT_ID('psa.int_planogram_cursor_table') is not null
	BEGIN
			DROP TABLE [psa].[int_planogram_cursor_table]
	END	

IF OBJECT_ID('psa.th_crp_merchandise_stg') is not null
	BEGIN
			DROP TABLE [psa].[th_crp_merchandise_stg]
	END

	BEGIN
	CREATE TABLE [psa].[int_planogram_cursor_table]
			(
				[row_id] [bigint]  NULL,
				[date_added] [nvarchar](25)  NULL
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				HEAP
			);
		/*Removing the leading zeros from psa data */
		CREATE TABLE [psa].[th_crp_merchandise_stg]
	             (
				 [row_id] [bigint] NOT NULL,
	             [db_key] [nvarchar](80) NULL,
	             [pog_id] [nvarchar](80) NULL,
	             [planogram_start_date] [nvarchar](25) NULL,
	             [planogram_end_date] [nvarchar](25) NULL,
	             [pog_description] [nvarchar](80) NULL,
	             [shelf_depth] [nvarchar](255) NULL,
	             [height] [nvarchar](255) NULL,
	             [fitting_type] [nvarchar](255) NULL,
	             [build_size] [nvarchar](255) NULL,
	             [planner_family] [nvarchar](255) NULL,
	             [footprint] [nvarchar](255) NULL,
	             [category] [nvarchar](255) NULL,
	             [format] [nvarchar](255) NULL,
	             [promotional_site] [nvarchar](255) NULL,
	             [date_added] [nvarchar](25) NULL,
	             [etl_runlog_id] [int] NULL,
	             [asset_id] [int] NULL,
	             [record_source_id] [int] NULL,
	             [row_status] [int] NULL,
	             [created_timestamp] [datetime] NULL,
	             [active_flag] [char](1) NULL	 
                 )
		WITH
			(
			DISTRIBUTION = HASH ( [row_id] ),
			HEAP
			)
	END

BEGIN TRANSACTION

--Assigning values to lookup variables
		SET @SCDDefaultStartDate	= CONVERT(DateTime,'1900-01-01');
		SET @SCDDefaultEndDate		= CONVERT(DateTime,'9999-12-31');
		SET @max_planogramID		= (SELECT COALESCE(MAX(PlanogramID),0) FROM ser.planogram);
		SET @pogid_sourceKeyTypeID	= (SELECT LOVId FROM ser.RefLOVSetInfo WHERE LOVKey = 'Thailand Planogram Id(pog_id)'  AND LOVSetName = 'Source Key Type');
		SET @dbkey_sourceKeyTypeID	= (SELECT LOVId FROM ser.RefLOVSetInfo WHERE LOVKey = 'Thailand Planogram dbkey' AND LOVSetName = 'Source Key Type');
		SET @indicatorLOVID			= (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE LOVsetName='Indicator - THAILAND Merchandise' AND LOVKey = 'promotional_site' AND LOVRecordSourceId = @th_lovRecordSourceID);
		SET @dbKeyTypeId			= (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE LOVsetName='Source Key Type' AND LOVKey = 'Thailand Planogram dbkey' AND LOVRecordSourceId =@RecordSourceIdMerchANDise);
		SET @fittingTypeLOVSetID	= (SELECT DISTINCT(LOVSetId) FROM [ser].[reflovsetinfo] WHERE LOVsetName='fitting_type' and LOVRecordSourceId = @th_lovRecordSourceID);		
		SET @plannerFamilyLOVSetID	= (select distinct(LOVSetId) from [ser].[reflovsetinfo] where LOVsetName='planner_family' and LOVRecordSourceId = @th_lovRecordSourceID);		
		SET @footprintLOVSetID		= (select distinct(LOVSetId) from [ser].[reflovsetinfo] where LOVsetName='footprint' and LOVRecordSourceId = @th_lovRecordSourceID);	
		SET @categoryLOVSetID		= (select distinct(LOVSetId) from [ser].[reflovsetinfo] where LOVsetName='category' and LOVRecordSourceId = @th_lovRecordSourceID);	
		SET @formatLOVSetID			= (select distinct(LOVSetId) from [ser].[reflovsetinfo] where LOVsetName='format' and LOVRecordSourceId = @th_lovRecordSourceID);	
		SET @measureTypeIdPlanoDim	= (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE LOVsetName='Measure Type' AND LOVKey = 'PLANOGRAM_DIM' AND LOVRecordSourceId = @RecordSourceIdMerchANDise);
		SET @shelfDepthMeasureID	= (SELECT MeasureId FROM [ser].[measure] WHERE MeasureName = 'shelf_depth' AND LOVMeasureTypeId = @measureTypeIdPlanoDim AND LOVRecordSourceId = @th_lovRecordSourceID);
		SET @heightMeasureID		= (SELECT MeasureId FROM [ser].[measure]  WHERE MeasureName = 'height' AND LOVMeasureTypeId = @measureTypeIdPlanoDim AND LOVRecordSourceId = @th_lovRecordSourceID);
		SET @buildSizeMeasureID		= (SELECT MeasureId FROM [ser].[measure]  WHERE MeasureName = 'build_size' AND LOVMeasureTypeId = @measureTypeIdPlanoDim AND LOVRecordSourceId = @th_lovRecordSourceID);
		SET @LOVIdUnitCM			= (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE  LOVsetName='Unit Of Measure' AND LOVKey = 'cm' AND LOVRecordSourceId = @RecordSourceIdMerchANDise);
		SET @LOVIdUnitUnKnown 		= (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE  LOVsetName='Unit Of Measure' AND LOVKey = 'Unknown'  AND LOVRecordSourceId = @RecordSourceIdMerchANDise);
	
BEGIN TRY

/*********Date added filter - IF the date_added value in the new file <= the date_added for the previous  data load 
Then DO NOT LOAD DATA Else LOAD ALL DATA****************************************/

	update [psa].[th_crp_merchandise]      
        set row_status = @rowStatusNotmigratedCode
        where row_id in (
						SELECT
							A.row_id
							from [psa].[th_crp_merchandise] A
							JOIN (select 
								distinct pog_id,
								record_source_id,
								Max(date_added) as date_added 
								from [psa].[th_crp_merchandise]
								where row_status =@rowStatusSERCode 
								group by pog_id,record_source_id) B
							on  A.pog_id=B.pog_id    
							AND A.record_source_id = B.record_source_id 							
							and A.date_added<=B.date_added
							and A.row_status = @rowStatusPSACode
						);

INSERT INTO [psa].[th_crp_merchandise_stg] 
	SELECT		       [row_id]
					  ,[db_key]
					  ,ISNULL( NULLIF((Substring(pog_id, Patindex('%[^0]%', pog_id + ' '), Len(pog_id)) ),''),0) [pog_id]
					  ,[planogram_start_date]
					  ,[planogram_end_date]
					  ,[pog_description]
					  ,[shelf_depth]
					  ,[height]
					  ,[fitting_type]
					  ,[build_size]
					  ,[planner_family]
					  ,[footprint]
					  ,[category]
					  ,[format]
					  ,[promotional_site]
					  ,[date_added]
					  ,[etl_runlog_id]
					  ,[asset_id]
					  ,[record_source_id]
					  ,[row_status]
					  ,[created_timestamp]
					  ,[active_flag]	 
		 FROM [psa].[th_crp_merchandise] WHERE row_status=@rowStatusPSACode;

/*********************************Insert parent Records to Temp Table***************/
PRINT 'Info: th_crp_merchandise_temp temporary table loading for parent records started';
		WITH stg_planogram AS (SELECT *  FROM ser.Planogram pg
									WHERE LOVRECORDSOURCEID = @th_lovRecordSourceID 
									AND LOVSourceKeyTypeId = @pogid_sourceKeyTypeID
									AND NOT EXISTS (SELECT 1 FROM ser.planogram AS pgm
														WHERE pgm.PlanogramId = pg.PlanogramId
														AND pgm.LOVRecordSourceID=pg.LOVRecordSourceID
														AND  pgm.SCDVersion >pg.SCDVersion)),
		stg_deduplicate as (SELECT a.POG_ID,
										a.DATE_ADDED,     
										ROW_NUMBER() OVER (  PARTITION BY a.pog_id,a.DATE_ADDED ORDER BY a.POG_ID,a.DATE_ADDED) as row_id
										FROM psa.th_crp_merchandise_stg a,
									(SELECT POG_ID,
										max(DATE_ADDED ) DATE_ADDED
										FROM psa.th_crp_merchandise_stg 
										GROUP BY POG_ID,DATE_ADDED ) temp
								WHERE a.pog_id=temp.pog_id and a.date_added=temp.date_added
								) 		
		INSERT INTO psa.th_crp_merchandise_temp
		(	PSARowKey,
			LOVSourceKeyTypeId,
			PlanogramID,
			ParentPlanogramID,
			sourceKey,
			pog_description,
			planogram_start_date,	
			planogram_end_date, 
			shelf_depth,
			height,
			fitting_type,
			build_size,
			planner_family,
			footprint,
			category,
			format,
			promotional_site,
			date_added,
			etl_runlog_id,
			asset_id,
			LOVRecordSourceId,
			row_status,
			created_timestamp)

			SELECT
			t.PSARowKey,
			t.LOVSourceKeyTypeId,
			t.PlanogramId,
			t.ParentPlanogramId,
			t.sourceKey,
			t.pog_description,
			t.planogram_start_date,	
			t.planogram_end_date, 
			t.shelf_depth,
			t.height,
			t.fitting_type,
			t.build_size,
			t.planner_family,
			t.footprint,
			t.category,
			t.format,
			t.promotional_site,
			t.date_added,
			t.etl_runlog_id,
			t.asset_id,
			t.LOVRecordSourceId,
			t.row_status,
			t.created_timestamp
			FROM (

				SELECT
					thmer.row_id PSARowKey,
					@pogid_sourceKeyTypeID LOVSourceKeyTypeId,
					ISNULL(P.PlanogramId,mechIdTemp.PlanogramId) PlanogramId, 
					NULL ParentPlanogramId,
					--ISNULL( NULLIF((Substring(thmer.pog_id, Patindex('%[^0 ]%', thmer.pog_id + ' '), Len(thmer.pog_id)) ),''),0) sourceKey,
					thmer.pog_id sourceKey,
					thmer.pog_description pog_description,
					NULL planogram_start_date,	
					NULL planogram_end_date, 
					shelf_depth,
					height,
					fitting_type,
					build_size,
					planner_family,
					footprint,
					category,
					format,
					promotional_site,
					NULLIF(thmer.date_added,'')  date_added,
					CAST(@serveETLRunLogID AS INT) etl_runlog_id,
					asset_id,
					thmer.record_source_id LOVRecordSourceId,
					thmer.row_status,
					created_timestamp,
					LEAD('N', 1, 'Y') OVER(PARTITION BY thmer.pog_id,thmer.date_added,thmer.record_source_id ORDER BY thmer.date_added ASC) duplicate_Check
				FROM psa.th_crp_merchandise_stg thmer
				LEFT JOIN stg_deduplicate sd
					ON thmer.pog_id=sd.pog_id
					ANd thmer.date_added=sd.date_added
					and sd.row_id=1
				JOIN (SELECT thmer.pog_id, --creating planogram, id for all the entries in the psa planogram table  by adding row number to the max planogram id of ser  table
						thmer.record_source_id,
						(@max_planogramID+DENSE_RANK() OVER(ORDER BY thmer.pog_id,thmer.record_source_id ASC)) PlanogramId
						FROM psa.th_crp_merchandise_stg thmer  
						WHERE thmer.row_status=@rowStatusPSACode 
						GROUP BY thmer.pog_id,thmer.record_source_id) mechIdTemp
					ON mechIdTemp.pog_id=thmer.pog_id 
					AND mechIdTemp.record_source_id=thmer.record_source_id
					 LEFT JOIN Stg_planogram P
						ON --ISNULL( NULLIF((Substring(thmer.pog_id, Patindex('%[^0 ]%', thmer.pog_id + ' '), Len(thmer.pog_id)) ),''),0) =P.sourcekey 
						thmer.pog_id =P.sourcekey  
                        AND thmer.record_source_id = P.LOVRecordSourceId
                        AND P.LOVSourceKeyTypeId = @pogid_sourceKeyTypeID
				WHERE thmer.row_status = CAST(@rowStatusPSACode AS INT)
			) t
			WHERE t.duplicate_Check ='Y' 

PRINT 'Info: th_crp_merchandise_temp temporary table loaded with parent records successfully';
/************************************ Insert Child Records*********************************************************/
PRINT 'Info: th_crp_merchandise_temp temporary table loading for child records started';

/*stg_planogram- selecting the  latest  version  from planogram table  where source key is db_key both active and closed records */
		
		SELECT  @max_planogramID = COALESCE(MAX(PlanogramID),0) FROM [ser].[Planogram];
		SELECT @max_planogramTempID = COALESCE(MAX(PlanogramId),0) FROM psa.th_crp_merchandise_temp;
		SELECT  @max_planogramID = CASE
			WHEN @max_planogramID >= @max_planogramTempID THEN @max_planogramID
			ELSE	@max_planogramTempID
		END

		PRINT 'Info: [psa].[th_crp_merchandise_temp] table loading for Child records';
		WITH Stg_planogram AS
        (
			SELECT
					*
			FROM [ser].[Planogram] pg
			WHERE LOVRECORDSOURCEID = @th_lovRecordSourceID
			AND LOVSourceKeyTypeId = @dbkey_sourceKeyTypeID
			AND NOT EXISTS (
													SELECT 1 FROM [ser].[Planogram] AS pgm
													WHERE pgm.PlanogramID = pg.PlanogramID
													AND pgm.LOVRecordSourceID= pg.LOVRecordSourceID
													AND  pgm.SCDVersion > pg.SCDVersion
											)
        )

		INSERT INTO psa.th_crp_merchandise_temp								-- inserting to psa.th_crp_merchandise_temp for dbkey create parent planogram id and planogram id
			(PSARowKey,LOVSourceKeyTypeId,PlanogramID,ParentPlanogramID,sourceKey,pog_description,
			planogram_start_date,	
				planogram_end_date, 
				shelf_depth,
				height,
				fitting_type,
				build_size,
				planner_family,
				footprint,
				category,
				format,
				promotional_site,
				date_added,
				etl_runlog_id,
				asset_id,
				LOVRecordSourceId,
				row_status,
				created_timestamp)
			SELECT
				thmer.row_id PSARowKey,
				@dbkey_sourceKeyTypeID LOVSourceKeyTypeId,
				pgmIdTemp.PlanogramID PlanogramID,
				planogramTemp.PlanogramID ParentPlanogramID,
				thmer.db_key  sourceKey,
				pog_description, 
				NULLIF(pgmIdTemp.planogram_start_date,''),	
				NULLIF(pgmIdTemp.planogram_end_date,''), 
				shelf_depth,
				height,
				fitting_type,
				build_size,
				planner_family,
				footprint,
				category,
				format,
				promotional_site,
				NULLIF(pgmIdTemp.date_added,'') ,
				CAST(@serveETLRunLogID AS INT) etl_runlog_id,
				asset_id,
				thmer.record_source_id LOVRecordSourceId,
				thmer.row_status,
				created_timestamp
			FROM psa.th_crp_merchandise_stg thmer
				JOIN (SELECT thmer.pog_id,
						 thmer.db_key,
						 thmer.planogram_start_date,
						 thmer.planogram_end_date,
						 thmer.date_added,
						 thmer.record_source_id,
						 (@max_planogramID+DENSE_RANK() OVER(ORDER BY thmer.pog_id,thmer.db_key,thmer.planogram_start_date,thmer.planogram_end_date,thmer.date_added,thmer.record_source_id ASC)) PlanogramID
					FROM psa.th_crp_merchandise_stg thmer 
						WHERE thmer.row_status=@rowStatusPSACode 
						GROUP BY thmer.pog_id,thmer.db_key,thmer.planogram_start_date,thmer.planogram_end_date,thmer.date_added,thmer.record_source_id
				 ) pgmIdTemp
			  ON pgmIdTemp.pog_id=thmer.pog_id 
			  AND pgmIdTemp.db_key=thmer.db_key 
			  AND pgmIdTemp.planogram_start_date=thmer.planogram_start_date
			  AND pgmIdTemp.planogram_end_date=thmer.planogram_end_date
			  AND pgmIdTemp.date_added=thmer.date_added
			  AND pgmIdTemp.record_source_id=thmer.record_source_id
			JOIN (SELECT SourceKey,
						 LOVRecordSourceId,
						 PlanogramID,
						 LOVSourceKeyTypeId 
					FROM psa.th_crp_merchandise_temp
					GROUP BY SourceKey,LOVRecordSourceId,PlanogramID,LOVSourceKeyTypeId
				  ) planogramTemp
		ON planogramTemp.SourceKey = ISNULL( NULLIF((Substring(thmer.pog_id, Patindex('%[^0]%', thmer.pog_id + ' '), Len(thmer.pog_id)) ),''),0) 
			  AND planogramTemp.LOVRecordSourceId = thmer.record_source_id
			  AND planogramTemp.LOVSourceKeyTypeId = @pogid_sourceKeyTypeID
			  LEFT JOIN Stg_planogram P
			  ON thmer.db_key = P.sourcekey
			  AND thmer.record_source_id = P.LOVRecordSourceId
			  AND P.LOVSourceKeyTypeId = @dbkey_sourceKeyTypeID
			  AND P.ParentPlanogramId =
				(
					SELECT distinct PlanogramId from [ser].[Planogram]
					WHERE thmer.db_key IS NOT NULL and thmer.db_key !=''
					AND thmer.record_source_id = LOVRecordSourceId 
					AND LOVSourceKeyTypeId = @pogid_sourceKeyTypeID
					AND SourceKey = ISNULL( NULLIF((Substring(thmer.pog_id, Patindex('%[^0]%', thmer.pog_id + ' '), Len(thmer.pog_id)) ),''),0)
				)
				
			  WHERE 
			  thmer.db_key IS NOT NULL and thmer.db_key !=''
			  AND thmer.date_added IS NOT NULL and thmer.date_added!=''
			  AND thmer.row_status = CAST(@rowStatusPSACode AS INT)
			  



PRINT 'Info: th_crp_merchandise_temp temporary table loaded with child records successfully';


		SET	@SCDStartDate	= CURRENT_TIMESTAMP;
		SET	@SCDEndDate		= @SCDStartDate;			
 
 /******************************************************************************************************************************** 
 1. Table Name  :    Planogram - Parent Records
 ********************************************************************************************************************************/    

        PRINT 'Info: [ser].[Planogram] Loading Parent Started';
        WITH Stg_planogram AS
        (
            SELECT
                    *
            FROM [ser].[Planogram] pg
            WHERE LOVRECORDSOURCEID = @th_lovRecordSourceID
            AND NOT EXISTS (
                                SELECT 1 FROM [ser].[Planogram] AS pgm
                                WHERE pgm.PlanogramID = pg.PlanogramID
                                AND pgm.LOVRecordSourceID= pg.LOVRecordSourceID
                                AND  pgm.SCDVersion > pg.SCDVersion
							)
        )
		
		INSERT INTO ser.planogram
		(PlanogramId,
		SourceKey,
		LOVSourceKeyTypeId,
		planogramStartDate,	
		planogramEndDate, 
		planogramName,
		ParentPlanogramId,
		LOVRecordSourceId,
		SCDStartDate,
		SCDEndDate,
		SCDActiveFlag,
		SCDVersion,
		SCDLOVRecordSourceId,
		ETLRunLogId,
		PSARowKey
		)
		SELECT 
			PlanogramId,
			SourceKey,
			LOVSourceKeyTypeId,
			CASE WHEN (PlanogramStartDate = '' or PlanogramStartDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramStartDate END AS PlanogramStartDate,
	        CASE WHEN (PlanogramEndDate = '' or PlanogramEndDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramEndDate END AS PlanogramEndDate,
			PlanogramName,
			ParentPlanogramId,
			LOVRecordSourceId,
			CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY PlanogramId ORDER BY date_added ASC)) = 1)
					THEN @SCDDefaultStartDate 
					ELSE @SCDStartDate
				END SCDStartDate,
			LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY PlanogramId ORDER BY date_added ASC) SCDEndDate,
			LEAD('N', 1, 'Y') OVER(PARTITION BY PlanogramId,sourceKey ORDER BY date_added ASC) SCDActiveFlag,
			ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY PlanogramId,sourceKey ORDER BY date_added ASC) SCDVersion,
			SCDLOVRecordSourceId,
			ETLRunLogId,PSARowKey
		FROM
		(
			SELECT
				thmerc.PSARowKey,
				thmerc.PlanogramId,
				thmerc.SourceKey,
				thmerc.LOVSourceKeyTypeId,
				thmerc.planogram_start_date PlanogramStartDate,	
				thmerc.planogram_end_date PlanogramEndDate, 
				thmerc.pog_description PlanogramName ,
				thmerc.ParentPlanogramId,
				thmerc.LOVRecordSourceId,
				thmerc.date_added,
				@SCDDefaultEndDate SCDEndDate,
				thmerc.LOVRecordSourceId SCDLOVRecordSourceId,
				@serveETLRunLogID ETLRunLogId,
				LEAD('N', 1, 'Y') OVER(PARTITION BY thmerc.PlanogramId,thmerc.pog_description ORDER BY thmerc.date_added ASC) SCDActiveFlag,
				P.SCDVersion as SCDVersion
			FROM psa.th_crp_merchandise_temp thmerc
			LEFT JOIN Stg_planogram P
				ON thmerc.PlanogramId = p.PlanogramId
				AND ISNULL(thmerc.ParentPlanogramId,'') = ISNULL(p.ParentPlanogramId,'')
				AND thmerc.LOVRecordSourceId = p.LOVRecordSourceId
				AND p.LOVSourceKeyTypeId = @pogid_sourceKeyTypeID
			WHERE 
				thmerc.LOVSourceKeyTypeId = @pogid_sourceKeyTypeID 
				AND (CASE  WHEN ( NULLIF(thmerc.pog_description,'' ) IS NULL )  
							THEN 0
							ELSE 1 
					END
					)=1			-- NULL OR BLANK DONT INSERT
		)t
			WHERE t.SCDActiveFlag='Y'
			AND NOT EXISTS ( SELECT 1 FROM ser.planogram p 
											WHERE t.planogramId = p.planogramId
											AND t.LOVSourceKeyTypeId= p.LOVSourceKeyTypeId
											AND t.LOVRecordSourceId=p.LOVRecordSourceId
											AND ISNULL(t.PlanogramName,'') = ISNULL(p.PlanogramName,'')
											AND ISNULL(t.PlanogramStartDate,'')=ISNULL(p.PlanogramStartDate,'')
											AND ISNULL(t.PlanogramEndDate,'')=ISNULL(p.PlanogramEndDate,'')
											AND p.SCDActiveFlag ='Y'
											)
											
		UPDATE ser.Planogram set SCDActiveFlag='N',SCDEndDate = @SCDEndDate
		FROM ser.Planogram p
		JOIN
			(SELECT planogramId,
				SCDactiveflag, 
				SCDVersion,
				LovRecordSourceId 
			FROM ser.Planogram t 
			WHERE
				t.LOVRecordSourceID = @th_lovRecordSourceID 
				AND t.SCDActiveFlag='Y'
				AND NOT EXISTS (
					SELECT 1 FROM ser.Planogram AS pt
							WHERE pt.PlanogramID = t.PlanogramID
							AND pt.LOVRecordSourceID=t.LOVRecordSourceID
							AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
							AND  pt.ScdVersion > t.ScdVersion
						)
			) p2
		ON  p.PlanogramID=p2.PlanogramId
			AND p.LovRecordSourceId=p2.LovRecordSourceId
			AND p.SCDactiveflag=p2.SCDactiveflag
			AND p.SCDVersion!=p2.SCDVersion
		JOIN psa.th_crp_merchandise_temp thmerc
		ON p.PlanogramID = thmerc.PlanogramID
		WHERE p.SCDActiveFlag='Y'
			AND p.SCDEndDate = @SCDDefaultEndDate
		

 /******************************************************************************************************************************** 
  Create cursor table for looping  --> int_planogram_cursor_table 
 ********************************************************************************************************************************/    


INSERT INTO [psa].[int_planogram_cursor_table]
					SELECT  distinct DENSE_RANK() OVER(ORDER BY (inp.date_added )) AS row_id,
							inp.date_added as date_added
					FROM psa.th_crp_merchandise_temp inp 
					WHERE inp.row_status =@rowStatusPSACode

SET	@COUNTER = 1
SELECT @MAXID =  COUNT(DISTINCT date_added) FROM psa.th_crp_merchandise_temp
print 'Total Number of Loops : '+CAST(@MAXID as varchar)+''
	WHILE (@COUNTER <= @MAXID)

		BEGIN
		print 'Loop Number  : '+cast(@COUNTER as varchar)+'';
		PRINT 'Current Processing Date: '+CAST(@dateAdded AS VARCHAR)+'';
				

		SET @dateAdded		= (SELECT date_added from [psa].[int_planogram_cursor_table] where row_id = @COUNTER)
		SET	@SCDStartDate	= CURRENT_TIMESTAMP;
		SET	@SCDEndDate		= @SCDStartDate;			
 
 /******************************************************************************************************************************** 
 1. Table Name  :    Planogram - Loading Child Records
 ********************************************************************************************************************************/    
	
				PRINT 'Info: Planogram Table Serve Loading Started';
	
				PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
					
				INSERT INTO ser.planogram
					(PlanogramId,
					SourceKey,
					LOVSourceKeyTypeId,
					planogramStartDate,	
					planogramEndDate, 
					planogramName,
					ParentPlanogramId,
					LOVRecordSourceId,
					SCDStartDate,
					SCDEndDate,
					SCDActiveFlag,
					SCDVersion,
					SCDLOVRecordSourceId,
					ETLRunLogId,
					PSARowKey
					)
					SELECT 
						PlanogramId,
						SourceKey,
						LOVSourceKeyTypeId,
						CASE WHEN (PlanogramStartDate = '' or PlanogramStartDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramStartDate END AS PlanogramStartDate,
	                    CASE WHEN (PlanogramEndDate = '' or PlanogramEndDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramEndDate END AS PlanogramEndDate,
						PlanogramName,
						ParentPlanogramId,
						LOVRecordSourceId,
						CASE WHEN ((ROW_NUMBER() OVER(PARTITION BY PlanogramId ORDER BY date_added ASC)) = 1)
								THEN @SCDDefaultStartDate 
								ELSE @SCDStartDate
							END SCDStartDate,
						LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY PlanogramId ORDER BY date_added ASC) SCDEndDate,
						LEAD('N', 1, 'Y') OVER(PARTITION BY PlanogramId,sourceKey ORDER BY date_added ASC) SCDActiveFlag,
						ROW_NUMBER() OVER(PARTITION BY PlanogramId,sourceKey ORDER BY date_added ASC) SCDVersion,
						SCDLOVRecordSourceId,
						ETLRunLogId,PSARowKey
					FROM
					(
					SELECT   
							thmerc.PSARowKey,
							thmerc.PlanogramId,
							thmerc.SourceKey,
							thmerc.LOVSourceKeyTypeId,
							thmerc.planogram_start_date PlanogramStartDate,	
							thmerc.planogram_end_date PlanogramEndDate, 
							thmerc.pog_description PlanogramName ,
							thmerc.ParentPlanogramId,
							thmerc.LOVRecordSourceId,
							thmerc.date_added,
							@SCDDefaultEndDate SCDEndDate,
							thmerc.LOVRecordSourceId SCDLOVRecordSourceId,
							@serveETLRunLogID ETLRunLogId,
							LEAD('N', 1, 'Y') OVER(PARTITION BY thmerc.PlanogramId,thmerc.pog_description,thmerc.planogram_start_date,thmerc.planogram_end_date,
							thmerc.date_added,thmerc.sourceKey ORDER BY thmerc.date_added ASC) SCDActiveFlag
						FROM psa.th_crp_merchandise_temp thmerc
						WHERE 
							thmerc.LOVSourceKeyTypeId = @dbkey_sourceKeyTypeID 
							AND thmerc.date_added = @dateAdded
							AND (CASE  WHEN ( NULLIF(thmerc.pog_description,'' ) IS NULL)   
										THEN 0
										ELSE 1 
								END)=1			-- NULL OR BLANK DONT INSERT
					)t
						WHERE t.SCDActiveFlag='Y'
						
				PRINT 'Info: Planogram Table Loaded Successfully';


 /******************************************************************************************************************************** 
 2. Table Name  :    PlanogramGroup
 ********************************************************************************************************************************/    

	PRINT 'Info: Planogram Group Table Loading started....';
	SELECT @max_PlanogramGroupId = COALESCE(MAX(PlanogramGroupId),0) FROM [ser].[planogramgroup];



		WITH Stg_Planogram AS
		(
			SELECT 
				SourceKey
				,LOVRecordSourceId
				,LOVSourceKeyTypeId
				,ParentPlanogramID
				,max(PlanogramId) as PlanogramId
			FROM [ser].[Planogram] A
				WHERE LOVRecordSourceId = @th_lovRecordSourceID
				AND LOVSourceKeyTypeId = @dbKeyTypeId
				AND ETLRunLogId = @serveETLRunLogID
				AND NOT EXISTS	(
									SELECT 1 FROM [ser].[Planogram] B
										WHERE A.PlanogramId = B.PlanogramId
										AND A.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
										AND A.LOVRecordSourceId = B.LOVRecordSourceId
										AND A.ScdVersion > B.ScdVersion
								)
				group by SourceKey,LOVRecordSourceId,LOVSourceKeyTypeId,ParentPlanogramID
		),
		Stg_th_crp_merchandise AS
		(
			SELECT 
				A.[sourceKey]
				,A.[ParentPlanogramID]
				,A.[date_added]
				,A.[LOVRecordSourceId]
				,A.[PSARowKey]
				,A.[ColumnValue]
				,A.[ColumnName]  
				,A.[columnId]
				,B.[LOVID]
			FROM 
			(
				SELECT 
					[sourceKey]
					,[ParentPlanogramID]
					,[date_added]
					,[LOVRecordSourceId]
					,[PSARowKey]
					,[ColumnValue]
					,[ColumnName]  		
					,CASE
						WHEN ColumnName ='fitting_type' THEN @fittingTypeLOVSetID
						WHEN ColumnName ='planner_family' THEN @plannerFamilyLOVSetID
						WHEN ColumnName ='footprint' THEN @footprintLOVSetID
						WHEN ColumnName ='category' THEN @categoryLOVSetID
						WHEN ColumnName ='format' THEN @formatLOVSetID
						ELSE NULL
					END AS [columnId]
				FROM
				(
					SELECT * FROM psa.th_crp_merchandise_temp A
						WHERE row_status=@rowStatusPSACode 
						AND lovsourcekeytypeid=@dbKeyTypeId
						AND date_added=@dateAdded
				) A
				UNPIVOT
				(
					ColumnValue for ColumnName in (fitting_type,planner_family,footprint,category,[format])
				) as U
			) A
			JOIN [ser].[reflovsetinfo] B
				on B.LOVSetId = A.columnId
				AND A.ColumnValue=B.LovName
			WHERE A.ColumnValue IS NOT NULL AND A.ColumnValue <> ''
		)
		
		

INSERT INTO [ser].[PlanogramGroup]
		(
			[PlanogramGroupId]
			,[PlanogramId]
			,[LOVPlanogramGroupSetId]
			,[LOVGroupId]
			,[ParentPlanogramGroupId]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT 
				[PlanogramGroupId]
				,[PlanogramId]
				,[LOVPlanogramGroupSetId]
				,[LOVGroupId]
				,[ParentPlanogramGroupId]
				,[LOVRecordSourceId]
				,CASE WHEN ((ROW_NUMBER() OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC)) = 1)
												THEN @SCDDefaultStartDate
												ELSE @SCDStartDate
												END 
					[SCDStartDate]
				,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) [SCDEndDate]
				,LEAD('N', 1, 'Y') OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) AS [SCDActiveFlag]
				,ROW_NUMBER() OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) AS [SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey] 
			FROM 
			(
				SELECT 
					@max_PlanogramGroupId + (dense_rank() over (order by PlanogramId,LOVGroupId asc)) as [PlanogramGroupId]
					,[PlanogramId]
					,[LOVPlanogramGroupSetId]
					,[LOVGroupId]
					,[ParentPlanogramGroupId]
					,[LOVRecordSourceId]
					,date_added AS [date_added]
					,[SCDEndDate]
					,LEAD('N', 1, 'Y') OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) AS [SCDActiveFlag]
					,[SCDLOVRecordSourceId]
					,[ETLRunLogId]
					,[PSARowKey] 
				FROM
				(
					SELECT 
						B.PlanogramID as			[PlanogramId]
						,A.ColumnID AS	[LOVPlanogramGroupSetId]
						,A.LOVId AS					[LOVGroupId]
						,NULL AS					[ParentPlanogramGroupId]
						,A.date_added AS [date_added]
						,@SCDDefaultEndDate [SCDEndDate]
						,@th_lovRecordSourceID AS		[LOVRecordSourceId]
						,@th_lovRecordSourceID AS	[SCDLOVRecordSourceId]
						,@serveETLRunLogID AS		[ETLRunLogId]
						,A.PSARowKey as				[PSARowKey]
					FROM Stg_th_crp_merchandise A
					JOIN Stg_Planogram B
						ON A.SourceKey = B.SourceKey
						AND A.LOVRecordSourceId = B.LOVRecordSourceId
						AND A.[ParentPlanogramID] = B.[ParentPlanogramID]
						AND B.LOVSourceKeyTypeId = @dbKeyTypeId
					
				) temp
			) A
			WHERE A.[SCDActiveFlag] = 'Y'
			AND A.[date_added] = @dateAdded
		)
PRINT 'Info: Planogram Group Table inserted';

 /******************************************************************************************************************************** 
 3. Table Name  :    PlanogramIndicator
 ********************************************************************************************************************************/    

		PRINT 'Info: Processing [ser].[PlanogramIndicator] ';
		WITH Stg_Planogram AS
		(
			SELECT 
				SourceKey
				,LOVRecordSourceId
				,LOVSourceKeyTypeId
				,ParentPlanogramID
				,max(PlanogramId) as PlanogramId
			FROM [ser].[Planogram] A
				WHERE LOVRecordSourceId = @th_lovRecordSourceID
				AND LOVSourceKeyTypeId = @dbKeyTypeId
				AND ETLRunLogId = @serveETLRunLogID
				AND NOT EXISTS	(
									SELECT 1 FROM [ser].[Planogram] B
										WHERE A.PlanogramId = B.PlanogramId
										AND A.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
										AND A.LOVRecordSourceId = B.LOVRecordSourceId
										AND A.ScdVersion > B.ScdVersion
								)
				group by SourceKey,LOVRecordSourceId,LOVSourceKeyTypeId,ParentPlanogramID
		),
		Stg_th_crp_merchandise AS
		(
			SELECT * FROM psa.th_crp_merchandise_temp A
						WHERE row_status=@rowStatusPSACode 
						AND lovsourcekeytypeid=@dbKeyTypeId
						AND date_added=@dateAdded
		)
		
		INSERT INTO [ser].[PlanogramIndicator]
		(	[PlanogramId]
			,[LovIndicatorId]
			,[Value]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT 
			[PlanogramId]
			,[LovIndicatorId]
			,[Value]
			,[LOVRecordSourceId]
			,CASE WHEN ((ROW_NUMBER() OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC)) = 1)
												THEN @SCDDefaultStartDate
												ELSE @SCDStartDate
												END 
					[SCDStartDate]
			,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC) [SCDEndDate]
			,LEAD('N', 1, 'Y') OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC) AS [SCDActiveFlag]
			,ROW_NUMBER() OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC) AS [SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey] 
			FROM 
			(
				SELECT 
					[PlanogramId]
					,[LovIndicatorId]
					,[Value]
					,[LOVRecordSourceId]
					,[date_added]
					,[SCDEndDate]
					,LEAD('N', 1, 'Y') OVER(PARTITION BY [PlanogramId],[LovIndicatorId],[Value] ORDER BY [date_added] ASC) AS [SCDActiveFlag]
					,[SCDLOVRecordSourceId]
					,[ETLRunLogId]
					,[PSARowKey]
				FROM 
				(		
					SELECT 
						B.PlanogramId AS [PlanogramId]
						,@indicatorLOVID AS [LovIndicatorId]
						,A.promotional_site AS [Value]
						,@th_lovRecordSourceID AS [LOVRecordSourceId]
						,A.date_added AS [date_added]
						,@SCDDefaultEndDate [SCDEndDate]
						,@th_lovRecordSourceID [SCDLOVRecordSourceId]
						,@serveETLRunLogID AS [ETLRunLogId]
						,A.PSARowKey AS [PSARowKey]
					FROM Stg_th_crp_merchandise A
					JOIN Stg_Planogram B
						ON A.SourceKey = B.SourceKey
						AND A.LOVRecordSourceId = B.LOVRecordSourceId
						AND B.LOVSourceKeyTypeId = @dbKeyTypeId
						AND A.[ParentPlanogramID] = B.[ParentPlanogramID]
						AND A.promotional_site IS NOT NULL AND A.promotional_site <> ''
				) temp
			) A
			WHERE A.[SCDActiveFlag] = 'Y'
			AND A.[date_added] = @dateAdded
		)
		
		PRINT 'Info: Data Loaded IN [ser].[PlanogramIndicator] ';
		

/******************************************************************************************************************************** 
 4. Table Name  :    PlanogramProperty
 ********************************************************************************************************************************/    

		PRINT 'Info: Processing [ser].[PlanogramProperty] ';
		WITH Stg_Planogram AS
		(
			SELECT 
				SourceKey
				,LOVRecordSourceId
				,LOVSourceKeyTypeId
				,ParentPlanogramID
				,max(PlanogramId) as PlanogramId
			FROM [ser].[Planogram] A
				WHERE LOVRecordSourceId = @th_lovRecordSourceID
				AND LOVSourceKeyTypeId = @dbKeyTypeId
				AND ETLRunLogId = @serveETLRunLogID
				AND NOT EXISTS	(
									SELECT 1 FROM [ser].[Planogram] B
										WHERE A.PlanogramId = B.PlanogramId
										AND A.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
										AND A.LOVRecordSourceId = B.LOVRecordSourceId
										AND A.ScdVersion > B.ScdVersion
								)
				group by SourceKey,LOVRecordSourceId,LOVSourceKeyTypeId,ParentPlanogramID
		),
		Stg_th_crp_merchandise AS
		(
			SELECT 
				[Sourcekey]
				,[date_added]
				,LOVRecordSourceId
				,[PSARowKey]
				,[ColumnValue]
				,[ColumnName]  
				,[MeasureId]
				,[LOVUOMId]
			FROM
			(
				SELECT 
					[Sourcekey]
					,[date_added]
					,LOVRecordSourceId
					,[PSARowKey]
					,[ColumnValue]
					,[ColumnName]  
					,CASE
						WHEN ColumnName ='shelf_depth' THEN @shelfDepthMeasureID
						WHEN ColumnName ='height' THEN @heightMeasureID
						WHEN ColumnName ='build_size' THEN @buildSizeMeasureID
						ELSE NULL
					END AS [MeasureId]
					,CASE
						WHEN ColumnName ='shelf_depth' THEN @LOVIdUnitCM
						WHEN ColumnName ='height' THEN @LOVIdUnitCM
						WHEN ColumnName ='build_size' THEN @LOVIdUnitUnKnown
						ELSE NULL
					END AS [LOVUOMId]
				FROM
				(
					SELECT * FROM psa.th_crp_merchandise_temp A
						WHERE row_status=@rowStatusPSACode 
						AND lovsourcekeytypeid=@dbKeyTypeId
						AND date_added=@dateAdded
				) A
				UNPIVOT
				(
					[ColumnValue] FOR [ColumnName] IN ([shelf_depth],[height],[build_size])
				) AS U
			) T
			WHERE ColumnValue IS NOT NULL AND ColumnValue <> ''
			
		)
		
		INSERT INTO [ser].[PlanogramProperty]
		(
			[PlanogramId]
			,[MeasureId]
			,[LOVUOMId]
			,[Value]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT 
				[PlanogramId]
				,[MeasureId]
				,[LOVUOMId]
				,[Value]
				,[LOVRecordSourceId]
				,CASE WHEN ((ROW_NUMBER() OVER(PARTITION BY [PlanogramId],[MeasureId] ORDER BY [date_added] ASC)) = 1)
														THEN @SCDDefaultStartDate
														ELSE @SCDStartDate
														END 
							[SCDStartDate]
				,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [date_added] ASC) AS [SCDEndDate]
				,LEAD('N',1,'Y') OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [date_added] ASC) AS [SCDActiveFlag]
				,ROW_NUMBER() OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [date_added] ASC) AS [SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			FROM
			(
				SELECT
					[PlanogramId]
					,[MeasureId]
					,[LOVUOMId]
					,[Value]
					,[LOVRecordSourceId]
					,[date_added]
					,[SCDEndDate]
					,LEAD('N',1,'Y') OVER (PARTITION BY PlanogramId,MeasureId,value ORDER BY [date_added] ASC) AS [SCDActiveFlag]
					,[SCDLOVRecordSourceId]
					,[ETLRunLogId]
					,[PSARowKey]
				FROM
				(
					SELECT 
						B.PlanogramId AS [PlanogramId]
						,A.MeasureId AS [MeasureId]
						,A.LOVUOMId AS [LOVUOMId]
						,A.ColumnValue AS [Value]
						,@th_lovRecordSourceID AS [LOVRecordSourceId]
						,A.date_added AS [date_added]
						,@SCDDefaultEndDate [SCDEndDate]
						,@th_lovRecordSourceID AS [SCDLOVRecordSourceId]
						,@serveETLRunLogID AS [ETLRunLogId]
						,A.PSARowKey AS [PSARowKey]
					FROM Stg_th_crp_merchandise A
					JOIN Stg_Planogram B
						ON A.SourceKey = B.SourceKey
						AND A.LOVRecordSourceId = B.LOVRecordSourceId
						AND B.LOVSourceKeyTypeId = @dbKeyTypeId
				) temp
			)  A
			WHERE A.[SCDActiveFlag] = 'Y'
			AND A.[date_added] = @dateAdded
		)
		
		PRINT 'Info: Data Loaded IN [ser].[PlanogramProperty] ';

	
/********************************************************************************************************************************

Update the psa layer table with row_status as 'Loaded to Serve' once after Successful Migration

********************************************************************************************************************************/	
			


UPDATE psa.th_crp_merchandise  SET Row_Status=@rowStatusSERCode
	 FROM psa.th_crp_merchandise thmer
INNER JOIN
((SELECT distinct psarowkey FROM ser.Planogram WHERE  SCDLOVRecordsourceID = @th_lovRecordSourceID)
UNION ALL  (SELECT distinct psarowkey FROM ser.PlanogramGroup WHERE  SCDLOVRecordsourceID =@th_lovRecordSourceID)                         
UNION ALL  (SELECT distinct psarowkey FROM ser.PlanogramProperty  WHERE SCDLOVRecordsourceID = @th_lovRecordSourceID)       
UNION ALL  (SELECT distinct psarowkey FROM ser.PlanogramIndicator  WHERE SCDLOVRecordsourceID = @th_lovRecordSourceID)
            ) temp
                            ON  temp.psarowkey=thmer.row_id
WHERE thmer.Row_Status=@rowStatusPSACode
     AND thmer.date_added=@dateAdded ;


UPDATE psa.th_crp_merchandise 
SET Row_Status=@rowStatusSERCode
FROM psa.th_crp_merchandise thmer 
INNER JOIN
ser.Planogram p 
            ON thmer.record_source_id=LovRecordSourceID
			/*Modified on Oct 27*/ AND ISNULL( NULLIF((Substring(thmer.pog_id, Patindex('%[^0]%', thmer.pog_id + ' '), Len(thmer.pog_id)) ),''),0) =P.sourcekey 
            --AND  thmer.pog_id =p.sourcekey
            AND  LOVSourceKeyTypeId=@pogid_sourceKeyTypeID
WHERE thmer.Row_Status=@rowStatusPSACode   
            AND date_added=@dateAdded
            AND (
					(NULLIF(thmer.pog_description,'' ) IS NULL
					) 
					OR 
					(
					NULLIF(thmer.fitting_type,'') IS NULL 
					OR NULLIF(thmer.planner_family,'') IS NULL 
					OR NULLIF(thmer.footprint,'') IS NULL 
					OR NULLIF(thmer.category,'') IS NULL  
					OR NULLIF(thmer.format,'') IS NULL
					OR NULLIF(thmer.promotional_site ,'') IS NULL 
					OR NULLIF(thmer. shelf_depth,'') IS NULL
					OR NULLIF(thmer.height,'') IS NULL
					OR NULLIF(thmer.build_size,'') IS NULL

					)
				);

PRINT 'Info: Update the psa layer table with row_status  duplicate code'; 

UPDATE psa.th_crp_merchandise  SET row_status=@rowStatusNotmigratedCode                                                                                         
WHERE row_status=@rowStatusPSACode
AND date_added=@dateAdded;

PRINT 'Info: updated row_status in Source Table ->  psa.th_crp_merhandise';
PRINT '********Info: International crp_merchandise-thailand PSA to Serve Load Completed Successfully********';
 
			SET @COUNTER = @COUNTER + 1;
		END
			COMMIT TRANSACTION;
		END TRY
		BEGIN CATCH
			THROW;
			ROLLBACK TRANSACTION ;
		END CATCH

IF OBJECT_ID('psa.th_crp_merchandise_stg') is not null
	BEGIN
			DROP TABLE [psa].[th_crp_merchandise_stg]
	END
IF OBJECT_ID('psa.int_planogram_cursor_table') is not null
	BEGIN
			DROP TABLE [psa].[int_planogram_cursor_table]
	END	
IF OBJECT_ID('psa.th_crp_merchandise_temp') is not null
	BEGIN
			DROP TABLE [psa].[th_crp_merchandise_temp]
	END


END
GO
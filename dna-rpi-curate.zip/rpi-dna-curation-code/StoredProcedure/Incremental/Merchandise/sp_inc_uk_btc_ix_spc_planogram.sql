/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_ix_spc_planogram]    Script Date: 26/09/2020 12:35:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('psa.sp_inc_uk_btc_ix_spc_planogram') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_uk_btc_ix_spc_planogram 
END
GO
CREATE PROC [psa].[sp_inc_uk_btc_ix_spc_planogram] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS
/*
************************************************************************************************************
Procedure Name				: sp_inc_uk_btc_ix_spc_planogram
Purpose						: Load History dataetl_runlog_id From International Intactix Planogram in psa layer(Intactix ) into Serve Layer Table
Domain						: Merchandise
ServeLayer Target Tables	: Planogram,PlanogramStatus,PlanogramGroup,PlanogramProperty(Total 4 Tables)
RecordSourceID  for INTACTIX : 12002

*************************************************************************************************************
Modification History
*************************************************************************************************************
20-Aug-2020  : Incorporated v1.3 mapping changes
27-Aug-2020  : Incorporated v1.4 mapping changes
************************************************************************************************************
*/

/* Creating a intermediate physical table for child and parent values */
		IF OBJECT_ID('psa.uk_btc_ix_spc_planogram_temp') is not null
		BEGIN
			DROP TABLE psa.uk_btc_ix_spc_planogram_temp
		END			
			CREATE TABLE [psa].[uk_btc_ix_spc_planogram_temp]
			(
				[PSARowKey] [bigint] NOT NULL,
				[record_type] [nvarchar](100) NULL,
				PlanogramId bigint NULL,
				SourceKey [nvarchar](80) NULL,
				LOVSourceKeyTypeId int NULL,
				ParentPlanogramId bigint NULL,
				LOVRecordSourceId int NULL,
				dbkey [nvarchar](500) NULL,
				value50 [nvarchar](500) NULL,
				name nvarchar(100) NULL,
                etl_runlog_id int null,
                DBDateEffectiveFrom [nvarchar](500) NULL,
                DBDateEffectiveTo [nvarchar](500) NULL,
                livedate [nvarchar](500) null,
                desc1 [nvarchar](500) NULL,
                desc2 [nvarchar](500) NULL,
				desc3 [nvarchar](500) NULL,
				desc4 [nvarchar](500) NULL,
				desc5 [nvarchar](500) NULL,
				desc28 [nvarchar](500) NULL,
				desc29 [nvarchar](500) NULL,
                Category [nvarchar](500) NULL,
                width [nvarchar](500) NULL,
                record_source_id INT NULL,
                asset_id int NULL,
                row_status int NULL ,
                created_timestamp datetime NULL,
				PlanogramStartDate datetime NULL,
				PlanogramEndDate datetime NULL,
				SCDStartDate datetime NULL,
				SCDEndDate datetime NULL,
				SCDVersion int null,
				SCDLOVRecordSourceId int null,
				SCDActiveFlag char(1) null						
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			);
--Table for grouping values based on the value50 
IF OBJECT_ID('ser.PLANOGRAM_TEMP') IS NOT NULL
BEGIN
DROP TABLE ser.PLANOGRAM_TEMP;
END
				CREATE TABLE ser.PLANOGRAM_TEMP
				(dbkey [nvarchar](500) ,
				value50 [nvarchar](500))
				WITH
				(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
				);
	IF OBJECT_ID('psa.btc_ix_spc_planogram_cursor_table') is not null
	BEGIN
			DROP TABLE [psa].[btc_ix_spc_planogram_cursor_table]
	END	
			CREATE TABLE [psa].[btc_ix_spc_planogram_cursor_table]
			(
				[row_id] [bigint]  NULL,
				[asset_id] [int]  NULL
			)
			WITH
			(
				DISTRIBUTION = ROUND_ROBIN
			)

/*-------DECLARE Variables-------*/
DECLARE @max_PlanogramId int,@LOVRecordSourceId int,@SCDStartDate datetime,@SCDEndDate datetime,@SCDActiveFlag char,@SCDVersion smallint,@SCDLOVRecordSourceId int,
@LOVSetId_planogramgroup_desc5 int,@LOVSetId_planogramgroup_desc2 int,@LOVSetId_planogramgroup_desc1 int,@LOVStatusId int,@max_PlanogramGroupId int,
@LOVSetId_planogramgroup_desc3 int,@LOVSetId_planogramgroup_Category int,@LOVMeasureTypeId int,@LOVDataTypeId_string int,@LOVDataTypeId_float int,@LOVDataTypeId_int int,@UOMId int,
@LOVSetId_planogram int,@max_measureID int,@Sourcekeytypeid_parent int,@Sourcekeytypeid_child int,@psaRowStatus int,@serRowStatus int,@serRowStatus_duplicate INT,@SCDStartDate_initial datetime,
@COUNTER int,@MAXID int,@asset_id int,@SCDEndDate_final DATETIME,@shelfdepthmeasureID bigint, @shelfheightmeasureID bigint, @shelfwidthmeasureID bigint, @buildsizemeasureID bigint;


BEGIN
BEGIN TRANSACTION;
/*-------Set the MAX value of surrogate Keys to particular Variables-------*/
SET @max_PlanogramId=(SELECT COALESCE(MAX(PlanogramId),0) FROM  ser.Planogram)
SET @max_PlanogramGroupId=(SELECT COALESCE(MAX(PlanogramGroupId),0) FROM  ser.PlanogramGroup)
SET @max_measureID=(SELECT COALESCE(MAX(MeasureId),0) FROM  ser.Measure)


/*-------Set the Constant Values to Variables-------*/
SET @LOVRecordSourceId = 12002
SET @SCDStartDate_initial=(SELECT CONVERT(datetime,'1900-01-01 00:00:00'))
SET @SCDEndDate=(SELECT CONVERT(datetime,'9999-12-31 00:00:00'))
SET @SCDActiveFlag='Y'
SET @SCDVersion=1
SET @SCDLOVRecordSourceId=12002
SET @psaRowStatus=26001
SEt @serRowStatus=26002
SET @serRowStatus_duplicate=26010
/*-------Derive the lookup table constant values and Set to Variables-------*/
SELECT @LOVMeasureTypeId = rl.Lovid FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rl.LOVSetName = 'Measure Type'

SELECT @LOVDataTypeId_string = rl.Lovid FROM ser.RefLOVSetInfo rl  WHERE rl.LOVKey = 'STRING' AND rl.LOVSetName = 'Data Type'
SELECT @LOVDataTypeId_float = rl.Lovid FROM ser.RefLOVSetInfo rl  WHERE rl.LOVKey = 'FLOAT' AND rl.LOVSetName = 'Data Type'
SELECT @LOVDataTypeId_int = rl.Lovid FROM ser.RefLOVSetInfo rl  WHERE rl.LOVKey = 'INT' AND rl.LOVSetName = 'Data Type' 
SELECT @UOMId = rl.Lovid FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'Unknown' AND rl.LOVSetName = 'Unit Of Measure' 

select  @LOVStatusId = rl.LOVId FROM ser.RefLOVSetInfo rl	WHERE rl.LOVKey = 'livedate' AND rl.LOVSetName = 'Status Type'

select @Sourcekeytypeid_parent = rl.LOVId FROM ser.RefLOVSetInfo rl	WHERE rl.LOVKey = 'Intactix Planogram Id(value50)' AND rl.LOVSetName = 'Source Key Type'
									
select @Sourcekeytypeid_child = rl.LOVId FROM ser.RefLOVSetInfo rl WHERE rl.LOVKey = 'Intactix Planogram dbkey' AND rl.LOVSetName = 'Source Key Type'

set @LOVSetId_planogram=(select distinct LOVSetId from ser.RefLOVSetInfo rls where rls.LOVSetName = 'Status Type' and rls.LOVRecordSourceID = 12012)
set @LOVSetId_planogramgroup_desc5=(select distinct LOVSetId from ser.RefLOVSetInfo rls	where rls.LOVSetName = 'fitting_type' and rls.LOVRecordSourceID = 12002)
set @LOVSetId_planogramgroup_desc2=(select distinct LOVSetId from ser.RefLOVSetInfo rls	where rls.LOVSetName = 'planner_family'	and rls.LOVRecordSourceID = 12002)
set @LOVSetId_planogramgroup_desc1=(select distinct LOVSetId from ser.RefLOVSetInfo rls	where rls.LOVSetName = 'footprint'	and rls.LOVRecordSourceID = 12002)
set @LOVSetId_planogramgroup_desc3=(select distinct LOVSetId from ser.RefLOVSetInfo rls	where rls.LOVSetName = 'format'	and rls.LOVRecordSourceID = 12002)
set @LOVSetId_planogramgroup_Category=(select distinct LOVSetId from ser.RefLOVSetInfo rls	where rls.LOVSetName = 'category'	and rls.LOVRecordSourceID = 12002)
SET @shelfdepthmeasureID=(SELECT m.MeasureID from [ser].[Measure] m WHERE m.MeasureName='shelf_depth' AND m.LOVRecordSourceID=@LOVRecordSourceID)
SET @shelfheightmeasureID=(SELECT m.MeasureID from [ser].[Measure] m WHERE m.MeasureName='shelf_height' AND m.LOVRecordSourceID=@LOVRecordSourceID)
SET @shelfwidthmeasureID=(SELECT m.MeasureID from [ser].[Measure] m WHERE m.MeasureName='shelf_width' AND m.LOVRecordSourceID=@LOVRecordSourceID)
SET @buildsizemeasureID=(SELECT m.MeasureID from [ser].[Measure] m WHERE m.MeasureName='build_size' AND m.LOVRecordSourceID=@LOVRecordSourceID)
		PRINT '*******Loop starts here*******'
  BEGIN TRY
	--Setting tthe counter variable for looping with created timestamp
		SET @COUNTER = 1
		SELECT @MAXID = COUNT(distinct asset_id) FROM [psa].[uk_btc_ix_spc_planogram] ixp WHERE 
								row_status=@psaRowStatus;
		print 'Total Number of Loops : '+cast(@MAXID as varchar)+'';
		print 'Insert to cursor table started'
		INSERT INTO [psa].[btc_ix_spc_planogram_cursor_table]
					SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (asset_id)),
					asset_id 
					 FROM [psa].[uk_btc_ix_spc_planogram] 
					WHERE row_status=@psaRowStatus
		print 'Insert to cursor table completed'
		WHILE (@COUNTER <= @MAXID)
		BEGIN
		SET @SCDStartDate=current_timestamp
		SET @SCDEndDate_final=DATEADD(second,-1,@SCDStartDate)
		Print 'The loop count is '+cast(@COUNTER as varchar);

				SELECT @asset_id = asset_id from [psa].[btc_ix_spc_planogram_cursor_table] where  row_id=@COUNTER;  
				PRINT 'Current Processing Asset: '+CAST(@asset_id as varchar)+'';

				/*-------Set the MAX value of surrogate Keys to particular Variables-------*/
				DECLARE @max_planogramTempID BIGINT	;
				SELECT @max_planogramTempID = COALESCE(MAX(PlanogramId),0) FROM ser.Planogram;

				-- Loading a intermediate physical table with values corresponding to distinct values of  parent 
				--Insert into the temp table group by value50 for generating parent records
				PRINT '****************Deleting Planogram_Temp Started*********************'
					delete from  ser.PLANOGRAM_TEMP;
				PRINT '****************Deleting Planogram_Temp Completed*********************'
				PRINT '****************Loading Planogram_Temp Started*********************'

				insert into ser.PLANOGRAM_TEMP
				SELECT
					 MAX(DBKEY),cast(convert(float,value50)as nvarchar) FROM psa.uk_btc_ix_spc_planogram spl     
					where row_status=@psaRowStatus AND asset_id=@asset_id group by cast(convert(float,value50)as nvarchar) 
					
				PRINT '****************Loading of Planogram_Temp Completed *********************'
				
				PRINT '****************Deleting psa.uk_btc_ix_spc_planogram_temp Started*********************'
						delete from psa.uk_btc_ix_spc_planogram_temp;
				PRINT '****************Deleting psa.uk_btc_ix_spc_planogram_temp Completed*********************'

				PRINT '****************Loading psa.uk_btc_ix_spc_planogram_temp for parent case*********************'
					INSERT INTO psa.uk_btc_ix_spc_planogram_temp
						SELECT 
							PSARowKey,record_type,PlanogramId,SourceKey,LOVSourceKeyTypeId,ParentPlanogramId,LOVRecordSourceId,dbkey,value50,name,
							etl_runlog_id,DBDateEffectiveFrom,DBDateEffectiveTo,livedate,desc1,desc2,desc3,desc4,desc5,desc28,desc29,
							Category,width,record_source_id,asset_id,row_status,created_timestamp,
							PlanogramStartDate ,
							PlanogramEndDate ,
							SCDStartDate,
							SCDEndDate ,
							SCDVersion ,
							SCDLOVRecordSourceId,
							SCDActiveFlag				
						FROM
						  (SELECT 
							 ixp.row_id  AS PSARowKey,
							'parent' as record_type,
							(CASE When plgm.PlanogramId is null then   NULL ELSE  plgm.PlanogramId  END)  as PlanogramId,
							cast(convert(float,ixp.value50)as nvarchar) as SourceKey,
							@Sourcekeytypeid_parent    as LOVSourceKeyTypeId, 
							NULL as ParentPlanogramId,
							@LOVRecordSourceId as LOVRecordSourceId,
							ixp.dbkey as dbkey,
							cast(convert(float,ixp.value50)as nvarchar) as value50,
							ixp.name as name,
							 CAST(@serveETLRunLogID AS INT) as etl_runlog_id,
							ixp.DBDateEffectiveFrom as DBDateEffectiveFrom,
							ixp.DBDateEffectiveTo as DBDateEffectiveTo,
							ixp.livedate as livedate,
							ixp.desc1 as desc1,
							ixp.desc2 as desc2,
							ixp.desc3 as desc3,
							ixp.desc4 as desc4,
							ixp.desc5 as desc5,
							ixp.desc28 as desc28,
							ixp.desc29 as desc29,
							ixp.Category as Category,
							ixp.width as width,
							ixp.record_source_id as record_source_id,
							ixp.asset_id as asset_id,
							ixp.row_status as row_status,
							ixp.created_timestamp as created_timestamp,
							NULL PlanogramStartDate ,
							NULL PlanogramEndDate ,
							NULL SCDStartDate,
							NULL SCDEndDate ,
							(CASE When plgm.SCDVersion is null then 1 ELSE plgm.SCDVersion+1 END) as SCDVersion ,
							NULL SCDLOVRecordSourceId,
							NULL SCDActiveFlag
							from [psa].[uk_btc_ix_spc_planogram] ixp
							inner join ser.PLANOGRAM_TEMP temp
							on temp.dbkey=ixp.dbkey
								and temp.value50=cast(convert(float,ixp.value50)as nvarchar)
								and ixp.row_status=@psaRowStatus 
								AND asset_id=@asset_id
							LEFT JOIN ser.Planogram plgm 
								ON cast(convert(float,ixp.value50)as nvarchar)  = plgm.sourcekey 
								AND ixp.record_source_id = plgm.LOVRecordSourceId 
								AND plgm.SCDActiveFlag = 'Y'
								and plgm.parentplanogramid is null
							where ixp.value50 is not NULL and ixp.value50!='' 
							AND asset_id=@asset_id
							)t ;
			PRINT '****************Loading of psa.uk_btc_ix_spc_planogram_temp for parent case Completed*********************'	
					
			-----------closing the active record for Paremt if exists 
			SELECT @max_planogramTempID = COALESCE(MAX(PlanogramId),0) FROM ser.Planogram;
			PRINT '****************Loading Planogram Table for Parent case*********************'				
					--Insert parent to ser.Planogram		
						Insert into ser.Planogram	
						SELECT PlanogramId,
								SourceKey,
								LOVSourceKeyTypeId,
								PlanogramStartDate,
								PlanogramEndDate,
								PlanogramName,
								ParentPlanogramId,
								LOVRecordSourceId,
								SCDStartDate ,
								@SCDEndDate SCDEndDate,
								SCDActiveFlag  SCDActiveFlag,
								SCDVersion SCDVersion,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								ETLRunLogId,
								PSARowKey
							from
							(select  
								(CASE When ixp.PlanogramId is null then  @max_planogramTempID + ROW_NUMBER() OVER(ORDER BY convert(float,ixp.value50),ixp.record_source_id ASC) ELSE  ixp.PlanogramId  END) as PlanogramId,
								SourceKey as SourceKey,
								LOVSourceKeyTypeId  as LOVSourceKeyTypeId,
								NULL as PlanogramStartDate,
								NULL as PlanogramEndDate,
								name  as PlanogramName,
								ParentPlanogramId  as ParentPlanogramId,
								@LOVRecordSourceId as LOVRecordSourceId,
								@SCDStartDate as SCDStartDate,
								@SCDActiveFlag SCDActiveFlag,
								SCDVersion as SCDVersion,
								CAST(@serveETLRunLogID AS INT) ETLRunLogId,
								cast(PSARowkey as bigint) as PSARowkey
								from psa.uk_btc_ix_spc_planogram_temp ixp
								where record_type='parent'								
								and  not exists ( select 1 from ser.Planogram plgm where
															ixp.Sourcekey=plgm.Sourcekey
														and isnull(cast(ixp.LOVSourceKeyTypeId as int),0) = isnull(plgm.LOVSourceKeyTypeId,0)
														and ISNULL(ixp.name,'') = ISNULL(plgm.PlanogramName,'')
														and plgm.LOVRecordSourceId=@LOVRecordSourceId
														and plgm.SCDActiveFlag='Y'
														and plgm.parentplanogramid is null))t	
		--Closing the records with flag as N for the parent records 

		PRINT '****************Updation of Planogram Table for parent case Started*********************'
					UPDATE ser.Planogram   set SCDActiveFlag='N',SCDEndDate =@SCDEndDate_final
					FROM ser.Planogram  p 
					JOIN (SELECT PlanogramId,SCDactiveflag,LOVSourceKeyTypeId,SCDVersion,LovRecordSourceId FROM ser.Planogram t WHERE   
							t.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM ser.Planogram AS pt 
																WHERE pt.PlanogramId = t.PlanogramId
																AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId																
																AND pt.ScdVersion > t.ScdVersion) )p2
					 ON  p.PlanogramId=p2.PlanogramId
					 AND p.LovRecordSourceId=p2.LovRecordSourceId						 
					 AND p.SCDactiveflag=p2.SCDactiveflag
					 AND p.SCDVersion!=p2.SCDVersion
					 AND p.LOVSourceKeyTypeId=p2.LOVSourceKeyTypeId
					 join psa.uk_btc_ix_spc_planogram_temp ixp
					 ON ixp.record_source_id=p.LovRecordSourceId and
					 p.sourcekey = ixp.value50
					 and p.SCDActiveFlag='Y'
					 Where 
					 p.ParentPlanogramId is null   and ixp.row_status=@psaRowStatus 
					 
					 AND asset_id=@asset_id
	
		PRINT '****************Updation of Planogram Table for parent case Finished*********************'

					SELECT @max_planogramTempID = COALESCE(MAX(PlanogramId),0) FROM ser.Planogram;
			PRINT '****************Loading psa.uk_btc_ix_spc_planogram_temp for child case*********************'
						INSERT INTO psa.uk_btc_ix_spc_planogram_temp
						SELECT 
						PSARowKey,record_type,
						PlanogramId,
						SourceKey,
						LOVSourceKeyTypeId,
						ParentPlanogramId,
						LOVRecordSourceId,
						dbkey,
						value50,
						name,
						etl_runlog_id,
						DBDateEffectiveFrom,
						DBDateEffectiveTo,
						livedate,desc1,desc2,desc3,desc4,desc5,desc28,desc29,
						Category,width,record_source_id,asset_id,row_status,created_timestamp,
						PlanogramStartDate ,
							PlanogramEndDate ,
							SCDStartDate,
							SCDEndDate ,
							SCDVersion ,
							SCDLOVRecordSourceId,
							SCDActiveFlag
						FROM
						(SELECT  
						 ixp.row_id  AS PSARowKey,
						 'child' as record_type,
						  (CASE When plgm.PlanogramId is null then NULL ELSE  plgm.PlanogramId  END) as PlanogramId,
						  ixp.dbkey as SourceKey,
						  @Sourcekeytypeid_child  as LOVSourceKeyTypeId,
						  (pt.PlanogramId)  as ParentPlanogramId,
						  @LOVRecordSourceId as LOVRecordSourceId,
						  ixp.dbkey as dbkey,
						  cast(convert(float,ixp.value50)as nvarchar) as value50,
						  ixp.name as name,
						  CAST(@serveETLRunLogID AS INT) as etl_runlog_id,
						  ixp.DBDateEffectiveFrom as DBDateEffectiveFrom,
						  ixp.DBDateEffectiveTo as DBDateEffectiveTo,
						  ixp.livedate as livedate,
						  ixp.desc1 as desc1,
						  ixp.desc2 as desc2,
						  ixp.desc3 as desc3,
						  ixp.desc4 as desc4,
						  ixp.desc5 as desc5,
						  ixp.desc28 as desc28,
						  ixp.desc29 as desc29,
						  ixp.Category as Category,
						  ixp.width as width,
						  ixp.record_source_id as record_source_id,
						  ixp.asset_id as asset_id,
						  ixp.row_status as row_status,
						  ixp.created_timestamp as created_timestamp,
						   CASE When (ixp.DBDateEffectiveFrom is null or ixp.DBDateEffectiveFrom='')  
								then NULL
							ELSE convert(datetime,ixp.DBDateEffectiveFrom) END  as PlanogramStartDate,
						   CASE When (ixp.DBDateEffectiveTo is null or ixp.DBDateEffectiveTo='')  
								then NULL
							ELSE convert(datetime,ixp.DBDateEffectiveTo) END  as PlanogramEndDate,
							@SCDStartDate as SCDStartDate,
							@SCDEndDate SCDEndDate,
					  		(CASE When plgm.SCDVersion is null then 1 ELSE plgm.SCDVersion+1 END) as SCDVersion,
							@SCDLOVRecordSourceId as SCDLOVRecordSourceId, 			 
							LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.dbkey ORDER BY ixp.dbkey ASC) SCDActiveFlag	
							from psa.uk_btc_ix_spc_planogram ixp
							LEFT JOIN ser.Planogram plgm 
								ON ixp.dbkey  = plgm.sourcekey 
								AND ixp.record_source_id = plgm.LOVRecordSourceId
								and plgm.ParentPlanogramId is not null
							left join (Select  PlanogramId,Sourcekey,LovRecordSourceId from ser.Planogram 
													where LOVRecordSourceId = @LOVRecordSourceId 
														AND SCDActiveFlag = 'Y' 
														and parentplanogramid is null)  pt
							on pt.Sourcekey=cast(convert(float,ixp.value50)as nvarchar)  
							and pt.LOVRecordSourceId = ixp.record_source_id																
							where  ixp.dbkey is not NULL and ixp.dbkey!='' 
							
							and ISNULL(plgm.SCDActiveFlag,'Y')='Y'
							and ixp.row_status=@psaRowStatus 
							AND asset_id=@asset_id
							)t where ISNULL(t.SCDActiveFlag,'Y')='Y' 
							--and asset_id=@asset_id;
			PRINT '****************Loading psa.uk_btc_ix_spc_planogram_temp for child case completed*********************'

			/********************************************************************************************************************************
			1.	Table Name  :Planogram
				Condition : Entry for all data in Source table against surrogate key (SourceID & record_source_id)
			**********************************************************************************************************************************/
			--closing the active record for child if exists 

			SET @max_PlanogramId=(SELECT COALESCE(MAX(PlanogramId),0) FROM  ser.Planogram)
			
			--Child insert into planogram
			PRINT '****************Insertion of  Planogram Table for child case Started*********************'
			INSERT INTO ser.Planogram 
			SELECT 
						PlanogramId,
						SourceKey,
						LOVSourceKeyTypeId,
						PlanogramStartDate,
						PlanogramEndDate,
						PlanogramName,
						ParentPlanogramId,
						LOVRecordSourceId,
	   					SCDStartDate,
						SCDEndDate,
						@SCDActiveFlag SCDActiveFlag,	
						SCDVersion,
						SCDLOVRecordSourceId,
						ETLRunLogId,
						PSARowKey
						from 
							(				
								 SELECT 
								(CASE When temp.PlanogramId is null then  @max_PlanogramId+ROW_NUMBER() OVER(ORDER BY convert(float,temp.value50),temp.dbkey ASC) ELSE  temp.PlanogramId  END) as PlanogramId,
								temp.SourceKey as SourceKey,
								temp.LOVSourceKeyTypeId as LOVSourceKeyTypeId,
								temp.PlanogramStartDate as PlanogramStartDate,
								temp.PlanogramEndDate as PlanogramEndDate,
								temp.ParentPlanogramId as ParentPlanogramId,
								temp.name  as PlanogramName,
								@LOVRecordSourceId as LOVRecordSourceId,
								temp.SCDStartDate as SCDStartDate ,
								temp.SCDEndDate as SCDEndDate,
								temp.SCDVersion as SCDVersion,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
								temp.PSARowkey as PSARowkey
								from psa.uk_btc_ix_spc_planogram_temp temp
								where 
								ISNULL(temp.SCDActiveFlag,'Y')='Y'   and record_type='child' and temp.row_status=@psaRowStatus 
								and  not exists ( select 1 from ser.Planogram plgm where
															temp.Sourcekey=plgm.Sourcekey
														and isnull(cast(temp.LOVSourceKeyTypeId as int),0) = isnull(plgm.LOVSourceKeyTypeId,0)
														and isnull(convert(datetime,temp.DBDateEffectiveFrom),0)=isnull(plgm.PlanogramStartDate,0) 
														and isnull(convert(datetime,temp.DBDateEffectiveTo),0)=isnull(plgm.PlanogramEndDate,0) 
														and ISNULL(temp.name,'') = ISNULL(plgm.PlanogramName,'')
														and plgm.LOVRecordSourceId=@LOVRecordSourceId
														and plgm.SCDActiveFlag='Y'
														and plgm.parentplanogramid is not null))t
					 
	 
			PRINT '****************Insertion of  Planogram Table for child case Completed *********************'

		--Closing the records with flag as N for the child records 

		PRINT '****************Updation of Planogram Table Started*********************'
					UPDATE ser.Planogram   set SCDActiveFlag='N',SCDEndDate =@SCDEndDate_final
					FROM ser.Planogram  p 
					JOIN (SELECT PlanogramId,SCDactiveflag,LOVSourceKeyTypeId,SCDVersion,LovRecordSourceId FROM ser.Planogram t WHERE   
							t.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM ser.Planogram AS pt 
																WHERE pt.PlanogramId = t.PlanogramId
																AND pt.LOVRecordSourceID=t.LOVRecordSourceID
																AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId																
																AND pt.ScdVersion > t.ScdVersion) )p2
					 ON  p.PlanogramId=p2.PlanogramId
					 AND p.LovRecordSourceId=p2.LovRecordSourceId						 
					 AND p.SCDactiveflag=p2.SCDactiveflag
					 AND p.SCDVersion!=p2.SCDVersion
					 AND p.LOVSourceKeyTypeId=p2.LOVSourceKeyTypeId
					join psa.uk_btc_ix_spc_planogram_temp ixp
					ON ixp.record_source_id=p.LovRecordSourceId and
					 p.sourcekey = ixp.dbkey
					 and p.SCDActiveFlag='Y'
					Where 
					p.ParentPlanogramId is not null   and ixp.row_status=@psaRowStatus  					
					AND asset_id=@asset_id;
	
		PRINT '****************Updation of Planogram Table Finished*********************'			
		/********************************************************************************************************************************
			 2. Table Name  :PlanogramStatus 
				Condition: Source livedate Column Value Not Null or Blank
			--********************************************************************************************************************************/

			PRINT '****************Loading PlanogramStatus Table*********************';

					with stg_plgmstatus as (SELECT PlanogramId,LOVPlanogramStatusSetId,LOVStatusId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.PlanogramStatus t WHERE   
					LOVRecordSourceID = @LOVRecordSourceID AND NOT EXISTS (SELECT 1 FROM ser.PlanogramStatus AS pt 
																WHERE pt.PlanogramId=t.PlanogramId
																AND pt.LOVPlanogramStatusSetId = t.LOVPlanogramStatusSetId
																AND pt.LOVStatusId=t.LOVStatusId
																AND pt.LOVRecordSourceID=t.LOVRecordSourceID																
																AND pt.ScdVersion > t.ScdVersion) ) 													
					INSERT INTO ser.PlanogramStatus
					 select 
						t.PlanogramId,
						t.LOVPlanogramStatusSetId,
						t.LOVStatusId,
						t.EffectiveFrom,
						t.EffectiveTo,
						t.LOVRecordSourceId,
						t.SCDStartDate,
						t.SCDEndDate,
						t.SCDActiveFlag,
						ISNULL(plg.SCDVersion,0)+1 SCDVersion,
						t.SCDLOVRecordSourceId,
						t.ETLRunLogId,
						t.PSARowKey
						from 
						(select distinct
						plgm.PlanogramId as PlanogramId,
						@LOVSetId_planogram as LOVPlanogramStatusSetId,
						@LOVStatusId as LOVStatusId,
						convert(datetime,ixp.livedate) as EffectiveFrom,
						NULL as EffectiveTo,
						@LOVRecordSourceId LOVRecordSourceId,
						@SCDStartDate SCDStartDate ,
						@SCDEndDate SCDEndDate,
						@SCDActiveFlag SCDActiveFlag,
						@SCDLOVRecordSourceId SCDLOVRecordSourceId,
						CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
						plgm.PSARowKey PSARowKey
						from psa.uk_btc_ix_spc_planogram_temp ixp
						inner join ser.Planogram plgm
						on plgm.Sourcekey=ixp.dbkey
						and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
						and plgm.SCDActiveFlag='Y'	
						where ixp.livedate is not null and ixp.livedate!=''
						and plgm.LOVRecordSourceId=@LOVRecordSourceId
						and plgm.ParentPlanogramId is not null
						and ixp.record_type='child' and ixp.row_status=@psaRowStatus and asset_id=@asset_id
						and  not exists ( select 1 from ser.PlanogramStatus temp where
															ixp.dbkey=plgm.Sourcekey
															and temp.PlanogramId=plgm.PlanogramId 												
														and isnull(temp.EffectiveFrom,0) = isnull(convert(datetime,ixp.livedate),0)
														and temp.LOVRecordSourceId=@LOVRecordSourceId
														and temp.LOVPlanogramStatusSetId=@LOVSetId_planogram
														and temp.LOVStatusId=@LOVStatusId
														and temp.SCDActiveFlag='Y')
														)t
						left join stg_plgmstatus plg
						 on plg.PlanogramId=t.PlanogramId 						 
						 and plg.LOVRecordSourceId=@LOVRecordSourceId
						 and plg.LOVPlanogramStatusSetId=@LOVSetId_planogram
						 and plg.LOVStatusId=@LOVStatusId;								
																				
			PRINT '****************Insertion of  PlanogramStatus Table Completed*********************'
																				
			
			PRINT '****************Updation of PlanogramStatus Table Started*********************'
						UPDATE ser.PlanogramStatus
						set SCDActiveFlag='N',SCDEndDate =@SCDEndDate_final
						FROM ser.PlanogramStatus  p 
					
						JOIN (SELECT PlanogramId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.PlanogramStatus t WHERE   
							t.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM ser.PlanogramStatus AS pt 
																WHERE pt.PlanogramId = t.PlanogramId
																AND pt.LOVRecordSourceID=t.LOVRecordSourceID																
																AND pt.ScdVersion > t.ScdVersion) )p2
					 ON  p.PlanogramId=p2.PlanogramId
					 AND p.LovRecordSourceId=p2.LovRecordSourceId						 
					 AND p.SCDactiveflag=p2.SCDactiveflag
					 AND p.SCDVersion!=p2.SCDVersion					 
						join psa.uk_btc_ix_spc_planogram_temp ixp
						ON ixp.record_source_id=p.LovRecordSourceId and
						 p.PlanogramId = ixp.PlanogramId
						Where p.SCDActiveFlag='Y'
						and ixp.ParentPlanogramId is not null   and ixp.record_type='child' and ixp.row_status=@psaRowStatus 
						AND asset_id=@asset_id

						UPDATE ser.PlanogramStatus
						set SCDActiveFlag='N',SCDEndDate =@SCDEndDate_final
						FROM ser.PlanogramStatus  p 
						join psa.uk_btc_ix_spc_planogram_temp ixp
						ON ixp.record_source_id=p.LovRecordSourceId and
						 p.PlanogramId = ixp.PlanogramId
						Where NULLIF(ixp.livedate,'' ) IS NULL
						and p.SCDActiveFlag='Y'
						and ixp.ParentPlanogramId is not null   and ixp.record_type='child' and ixp.row_status=@psaRowStatus 
						AND asset_id=@asset_id	
			PRINT '****************Updation of PlanogramStatus Table Completed*********************'

			/********************************************************************************************************************************/



			/********************************************************************************************************************************
			3.	Table Name  :PlanogramGroup 
				Condition: Source column such as desc5,desc2,desc1,Category,desc3 should be not null or not blank
			**********************************************************************************************************************************/
			SET @max_PlanogramGroupId=(SELECT COALESCE(MAX(PlanogramGroupId),0) FROM  ser.PlanogramGroup)
			--1.
			--********************************************************************************************************************************/

			PRINT '****************Loading PlanogramGroup Table*********************';
					with stg_plgmgroup as (SELECT PlanogramGroupId,PlanogramId,LOVPlanogramGroupSetId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.PlanogramGroup t WHERE   
					LOVRecordSourceID = @LOVRecordSourceID AND NOT EXISTS (SELECT 1 FROM ser.PlanogramGroup AS pt 
																WHERE pt.PlanogramGroupId=t.PlanogramGroupId
																AND pt.PlanogramId = t.PlanogramId
																AND pt.LOVPlanogramGroupSetId=t.LOVPlanogramGroupSetId
																AND pt.LOVRecordSourceID=t.LOVRecordSourceID																
																AND pt.ScdVersion > t.ScdVersion) ) 
					INSERT INTO ser.PlanogramGroup
					(PlanogramGroupId,PlanogramId,LOVPlanogramGroupSetId,LOVGroupId,ParentPlanogramGroupId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
					    select 
						(case when PlanogramGroupId is null then ROW_NUMBER() OVER(ORDER BY t.PlanogramId ,t.LOVGroupId ASC)+@max_PlanogramGroupId else plg.PlanogramGroupId end) as PlanogramGroupId,
						t.PlanogramId,
						t.LOVPlanogramGroupSetId,
						t.LOVGroupId,
						t.ParentPlanogramGroupId,
						t.LOVRecordSourceId,
						t.SCDStartDate,
						t.SCDEndDate,
						t.SCDActiveFlag,
						ISNULL(plg.SCDVersion,0)+1 SCDVersion,
						t.SCDLOVRecordSourceId,
						t.ETLRunLogId,
						t.PSARowKey
						from
						(select distinct 
						plgm.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_desc5 LOVPlanogramGroupSetId,
						c.LovId LOVGroupId,
						NULL ParentPlanogramGroupId,
						@LOVRecordSourceId LOVRecordSourceId,
						@SCDStartDate SCDStartDate ,
						@SCDEndDate SCDEndDate,
						@SCDActiveFlag SCDActiveFlag,
						@SCDLOVRecordSourceId SCDLOVRecordSourceId,
						CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
						ixp.PSARowKey PSARowKey
						from psa.uk_btc_ix_spc_planogram_temp ixp
						inner join ser.Planogram plgm
						on plgm.Sourcekey=ixp.dbkey
						and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
						and plgm.SCDActiveFlag='Y'
						and ixp.row_status=@psaRowStatus and asset_id=@asset_id
						INNER JOIN (SELECT  rl.LOVId as LovId,rl.LOVRecordSourceId,rl.lovkey FROM
								ser.RefLOVSetInfo rl
								WHERE rl.LOVSetName = 'fitting_type'							
								 AND rl.LOVRecordSourceId = @LOVRecordSourceId)c
						on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.desc5
						where ixp.desc5 is not null and ixp.desc5!=''
						and plgm.LOVRecordSourceId=@LOVRecordSourceId
						and plgm.ParentPlanogramId is not null
						and ixp.record_type='child'

						union all
						
						select distinct 
						plgm.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_desc2 LOVPlanogramGroupSetId,
						c.LovId LOVGroupId,
						NULL ParentPlanogramGroupId,
						@LOVRecordSourceId LOVRecordSourceId,
						@SCDStartDate SCDStartDate ,
						@SCDEndDate SCDEndDate,
						@SCDActiveFlag SCDActiveFlag,
						@SCDLOVRecordSourceId SCDLOVRecordSourceId,
						CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
						ixp.PSARowKey PSARowKey
						from psa.uk_btc_ix_spc_planogram_temp ixp
						inner join ser.Planogram plgm
						on plgm.Sourcekey=ixp.dbkey
						and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
						and plgm.SCDActiveFlag='Y'
						and ixp.row_status=@psaRowStatus and asset_id=@asset_id
						INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
								ser.RefLOVSetInfo rl
								WHERE rl.LOVSetName = 'planner_family'
								 AND rl.LOVRecordSourceId = @LOVRecordSourceId)c
						on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.desc2
						where ixp.desc2 is not null and ixp.desc2!=''
						and plgm.LOVRecordSourceId=@LOVRecordSourceId
						and plgm.ParentPlanogramId is not null
						and ixp.record_type='child'

						union all

						select distinct 
						plgm.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_desc1 LOVPlanogramGroupSetId,
						c.LovId LOVGroupId,
						NULL ParentPlanogramGroupId,
						@LOVRecordSourceId LOVRecordSourceId,
						@SCDStartDate SCDStartDate ,
						@SCDEndDate SCDEndDate,
						@SCDActiveFlag SCDActiveFlag,
						@SCDLOVRecordSourceId SCDLOVRecordSourceId,
						CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
						ixp.PSARowKey PSARowKey
						from psa.uk_btc_ix_spc_planogram_temp ixp
						inner join ser.Planogram plgm
						on plgm.Sourcekey=ixp.dbkey
						and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
						and plgm.SCDActiveFlag='Y'
						and ixp.row_status=@psaRowStatus and asset_id=@asset_id
						INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
								ser.RefLOVSetInfo rl
								WHERE rl.LOVSetName = 'footprint'
								 AND rl.LOVRecordSourceId = @LOVRecordSourceId)c
						on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.desc1
						where ixp.desc1 is not null and ixp.desc1!=''
						and plgm.LOVRecordSourceId=@LOVRecordSourceId
						and plgm.ParentPlanogramId is not null
						and ixp.record_type='child'

						union all

						select distinct 
						plgm.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_Category LOVPlanogramGroupSetId,
						c.LovId LOVGroupId,
						NULL ParentPlanogramGroupId,
						@LOVRecordSourceId LOVRecordSourceId,
						@SCDStartDate SCDStartDate ,
						@SCDEndDate SCDEndDate,
						@SCDActiveFlag SCDActiveFlag,
						@SCDLOVRecordSourceId SCDLOVRecordSourceId,
						CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
						ixp.PSARowKey PSARowKey
						from psa.uk_btc_ix_spc_planogram_temp ixp
						inner join ser.Planogram plgm
						on plgm.Sourcekey=ixp.dbkey
						and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
						and plgm.SCDActiveFlag='Y'
						and ixp.row_status=@psaRowStatus and asset_id=@asset_id
						INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
								ser.RefLOVSetInfo rl
								WHERE rl.LOVSetName = 'category'
								 AND rl.LOVRecordSourceId = @LOVRecordSourceId)c
						on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.Category
						where ixp.Category is not null and ixp.Category!=''
						and plgm.LOVRecordSourceId=@LOVRecordSourceId
						and plgm.ParentPlanogramId is not null
						and ixp.record_type='child'

						union all

						select distinct 
						plgm.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_desc3 LOVPlanogramGroupSetId,
						c.LovId LOVGroupId,
						NULL ParentPlanogramGroupId,
						@LOVRecordSourceId LOVRecordSourceId,
						@SCDStartDate SCDStartDate ,
						@SCDEndDate SCDEndDate,
						@SCDActiveFlag SCDActiveFlag,
						@SCDLOVRecordSourceId SCDLOVRecordSourceId,
						CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
						ixp.PSARowKey PSARowKey
						from psa.uk_btc_ix_spc_planogram_temp ixp
						inner join ser.Planogram plgm
						on plgm.Sourcekey=ixp.dbkey
						and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
						and plgm.SCDActiveFlag='Y'
						and ixp.row_status=@psaRowStatus and asset_id=@asset_id
						INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
								ser.RefLOVSetInfo rl
								WHERE rl.LOVSetName = 'format'
								 AND rl.LOVRecordSourceId = @LOVRecordSourceId)c
						on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.desc3
						where ixp.desc3 is not null and ixp.desc3!=''
						and plgm.LOVRecordSourceId=@LOVRecordSourceId
						and plgm.ParentPlanogramId is not null
						and ixp.record_type='child')t
						left join stg_plgmgroup plg
						on plg.PlanogramId=t.PlanogramId 
						and plg.LOVRecordSourceId=@LOVRecordSourceId
						and plg.LOVPlanogramGroupSetId=t.LOVPlanogramGroupSetId
						where not exists ( select 1 from ser.PlanogramGroup temp where
															
														 t.Planogramid=temp.Planogramid
														and isnull(t.LOVGroupId,0) = isnull(temp.LOVGroupId,0)											
														and temp.LOVRecordSourceId=@LOVRecordSourceId
														and temp.SCDActiveFlag='Y')
													

			
			 PRINT '****************Insertion of  PlanogramGroup Table Completed*********************'
			 PRINT '****************Updation of PlanogramGroup Table Started*********************'
					UPDATE ser.PlanogramGroup
						set SCDActiveFlag='N',SCDEndDate =@SCDEndDate_final
						FROM ser.PlanogramGroup  p 
					
						JOIN (SELECT PlanogramGroupId,PlanogramId,LOVPlanogramGroupSetId,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.PlanogramGroup t WHERE   
							t.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM ser.PlanogramGroup AS pt 
																WHERE pt.PlanogramGroupId=t.PlanogramGroupId
																AND pt.PlanogramId = t.PlanogramId
																AND pt.LOVPlanogramGroupSetId=t.LOVPlanogramGroupSetId
																AND pt.LOVRecordSourceID=t.LOVRecordSourceID																
																AND pt.ScdVersion > t.ScdVersion) )p2
					 ON   p.PlanogramGroupId=p2.PlanogramGroupId
					 AND p.PlanogramId = p2.PlanogramId
					 AND p.LOVPlanogramGroupSetId=p2.LOVPlanogramGroupSetId				 
					 AND p.LovRecordSourceId=p2.LovRecordSourceId						 
					 AND p.SCDactiveflag=p2.SCDactiveflag
					 AND p.SCDVersion!=p2.SCDVersion					 
						join psa.uk_btc_ix_spc_planogram_temp ixp
						ON ixp.record_source_id=p.LovRecordSourceId and
						 p.PlanogramId = ixp.PlanogramId
						Where p.SCDActiveFlag='Y'
						and ixp.ParentPlanogramId is not null   and ixp.record_type='child' and ixp.row_status=@psaRowStatus 
						AND asset_id=@asset_id

					UPDATE ser.PlanogramGroup
						set SCDActiveFlag='N',SCDEndDate =@SCDEndDate_final
						FROM ser.PlanogramGroup  p 
						join (
						select planogramid,LOVPlanogramGroupSetId
						from
						(select 
						ixp.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_desc5 LOVPlanogramGroupSetId,
						ixp.desc5 as Value1
						from psa.uk_btc_ix_spc_planogram_temp ixp
						Where ixp.record_type='child' 	
						and  NULLIF(ixp.desc5,'' ) IS NULL 
						union all
						select 
						ixp.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_desc2 LOVPlanogramGroupSetId,
						ixp.desc2 as Value1
						from psa.uk_btc_ix_spc_planogram_temp ixp
						Where ixp.record_type='child' 
						and  NULLIF(ixp.desc2,'' ) IS NULL
						union all
						select 
						ixp.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_desc1 LOVPlanogramGroupSetId,
						ixp.desc1 as Value1
						from psa.uk_btc_ix_spc_planogram_temp ixp	
						Where ixp.record_type='child' 	
						and  NULLIF(ixp.desc1,'' ) IS NULL
						union all
						select 
						ixp.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_Category LOVPlanogramGroupSetId,
						ixp.Category as Value1
						from psa.uk_btc_ix_spc_planogram_temp ixp
						Where ixp.record_type='child' 
						and  NULLIF(ixp.Category,'' ) IS NULL
						union all
						select 
						ixp.PlanogramId PlanogramId,
						@LOVSetId_planogramgroup_desc3 LOVPlanogramGroupSetId,
						ixp.desc3 as Value1
						from psa.uk_btc_ix_spc_planogram_temp ixp
						Where ixp.record_type='child' 
						and  NULLIF(ixp.desc3,'' ) IS NULL)t1	
						group by t1.PlanogramId,t1.LOVPlanogramGroupSetId)t2
						on	 p.PlanogramId = t2.PlanogramId
						and p.LOVPlanogramGroupSetId = t2.LOVPlanogramGroupSetId
						and p.SCDActiveFlag='Y' 
						
				PRINT '****************Updation of PlanogramGroup Table Completed*********************'

			 /********************************************************************************************************************************
			4.	Table Name  :PlanogramProperty 
				Condition: Create/modify an entry for Height,Width,Depth,build_size against each row of the Planogram Data,if Height,Width,Depth,build_size resp is not
							null or not blank.
			**********************************************************************************************************************************/

			PRINT '****************Loading of  PlanogramProperty Table *********************';
			WITH Stg_input_data AS
				(
                SELECT 
                    *
					FROM
				 (
                    SELECT 
                        [ColumnValue],PSARowkey,dbkey
                        ,CASE
                            WHEN ColumnName ='desc29' THEN replace(replace([ColumnValue],'cm',''),'mm','')
                            WHEN ColumnName ='desc28' THEN replace(replace([ColumnValue],'cm',''),'mm','')
                            WHEN ColumnName ='width' THEN  replace(replace([ColumnValue],'cm',''),'mm','')
                            WHEN ColumnName ='desc4' THEN  [ColumnValue]
                        END AS [FinalValue]
                        ,[ColumnName]  
                        ,CASE
                            WHEN ColumnName ='desc29' THEN @shelfdepthmeasureID
                            WHEN ColumnName ='desc28' THEN @shelfheightmeasureID
                            WHEN ColumnName ='width' THEN  @shelfwidthmeasureID
                            WHEN ColumnName ='desc4' THEN  @buildsizemeasureID
                        END AS [MeasureId]
                        ,
                        @UOMId AS [LOVUOMId]
                    FROM
                    (
                        SELECT  * FROM [psa].[uk_btc_ix_spc_planogram_temp] A
										WHERE 
									    a.record_type='child'
										and a.row_status=26001 
					)A
                    UNPIVOT
                    (
                        [ColumnValue] FOR [ColumnName] IN ([desc29],[desc28],[width],[desc4])
                    ) AS U
                ) T
                WHERE ColumnValue IS NOT NULL AND ColumnValue <> ''
            ),
				stg_plgmppty as (SELECT PlanogramID,MeasureID,SCDActiveFlag,SCDVersion,LOVRecordSourceID FROM [ser].[PlanogramProperty] temp WHERE   
									 temp.LOVRecordSourceID=@LOVRecordSourceId AND NOT EXISTS (SELECT 1 FROM [ser].[PlanogramProperty] AS temp1 
																				WHERE temp1.PlanogramID = temp.PlanogramID
																				AND temp1.MeasureID=temp.MeasureID
																				AND temp1.LOVRecordSourceID=temp.LOVRecordSourceID
																				AND temp1.SCDVersion > temp.SCDVersion))
            	INSERT INTO [ser].[PlanogramProperty] (
							  PlanogramId			,
							  MeasureId				,
							  LOVUOMId				,
							  Value					,
							  LOVRecordSourceId		,
							  SCDStartDate			,
							  SCDEndDate			,
							  SCDActiveFlag			,
							  SCDVersion			,
							  SCDLOVRecordSourceId	,
							  ETLRunLogId			,
							  PSARowkey)

			SELECT PlanogramId,MeasureId,LOVUOMId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowkey
							FROM (
									SELECT
									plgm.PlanogramId PlanogramId,
									ixp.[MeasureId] MeasureId,
									ixp.[LOVUOMId] LOVUOMId,
									ixp.[FinalValue] as Value,
									@LOVRecordSourceId LOVRecordSourceId,
									@SCDStartDate SCDStartDate ,
									@SCDEndDate SCDEndDate,
									@SCDActiveFlag SCDActiveFlag,
									ISNULL(pp.SCDVersion,0)+1 SCDVersion,
									@SCDLOVRecordSourceId SCDLOVRecordSourceId,
									CAST(@serveETLRunLogID AS INT) ETLRunLogId,
									ixp.PSARowkey PSARowkey
									FROM Stg_input_data ixp   			
										JOIN [ser].[Planogram] plgm
										on plgm.Sourcekey=ixp.dbkey
										and plgm.SCDActiveFlag='Y'
										and plgm.LOVRecordSourceId=@LOVRecordSourceId
										and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child 
										LEFT JOIN stg_plgmppty pp
										ON pp.PlanogramId = plgm.PlanogramId and pp.LOVRecordSourceID=@LOVRecordSourceID
										and pp.MeasureId=ixp.MeasureId )ppfinal
										WHERE NOT EXISTS (SELECT 1 FROM [ser].[PlanogramProperty] temp WHERE
									  ppfinal.PlanogramID=temp.PlanogramID
									  AND ppfinal.Value=temp.Value
									  AND ppfinal.MeasureID=temp.MeasureID
									  AND ppfinal.LOVRecordSourceId=temp.LOVRecordSourceId
										 and temp.SCDActiveFlag='Y')
	
				PRINT '****************Insertion of  PlanogramProperty Table Completed*********************'
						
				PRINT '**************** Updation of  PlanogramProperty Table Started*********************';
						
				UPDATE [ser].[PlanogramProperty] 
				SET SCDEndDate=(SELECT DATEADD(second,-1,@SCDStartDate)),SCDActiveFlag='N'
									FROM [ser].[PlanogramProperty]  pp
									JOIN (SELECT PlanogramID,MeasureID,SCDActiveFlag,SCDVersion,LOVRecordSourceID FROM [ser].[PlanogramProperty] temp WHERE   
									temp.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM [ser].[PlanogramProperty] AS temp1 
																				WHERE temp1.PlanogramID = temp.PlanogramID
																				AND temp1.MeasureID=temp.MeasureID
																				AND temp1.LOVRecordSourceID=temp.LOVRecordSourceID
																				AND temp1.SCDVersion > temp.SCDVersion) )pp2
									 ON  pp.PlanogramID=pp2.PlanogramID
									 AND pp.LOVRecordSourceID=pp2.LOVRecordSourceID						 
									 AND pp.SCDActiveFlag=pp2.SCDActiveFlag
									 AND pp.SCDVersion!=pp2.SCDVersion
									 AND pp.MeasureID=pp2.MeasureID
						join psa.uk_btc_ix_spc_planogram_temp ixp
						ON ixp.record_source_id=pp.LovRecordSourceId and
						 pp.PlanogramId = ixp.PlanogramId
						Where pp.SCDActiveFlag='Y'
						and ixp.ParentPlanogramId is not null   and ixp.record_type='child' and ixp.row_status=@psaRowStatus 
						AND asset_id=@asset_id

					UPDATE [ser].[PlanogramProperty] 
				SET SCDEndDate=(SELECT DATEADD(second,-1,@SCDStartDate)),SCDActiveFlag='N'
									FROM [ser].[PlanogramProperty]  pp		 
									JOIN (	select planogramid,measureid,LOVRecordSourceId
											from(
												SELECT 
												PlanogramId PlanogramId,
												@shelfdepthmeasureID MeasureId,
												replace(replace(ixp.desc29,'cm',''),'mm','') Value,
												@LOVRecordSourceId LOVRecordSourceId
												FROM [psa].[uk_btc_ix_spc_planogram_temp]  ixp 
												WHERE ixp.record_type='child'
												and NULLIF(ixp.desc29,'' ) IS NULL
												
											union all
											SELECT 
												PlanogramId PlanogramId,
												@shelfheightmeasureID MeasureId,
												replace(replace(ixp.desc28,'cm',''),'mm','') Value,
												@LOVRecordSourceId LOVRecordSourceId
												FROM [psa].[uk_btc_ix_spc_planogram_temp]  ixp 
												WHERE ixp.record_type='child'
												and NULLIF(ixp.desc28,'' ) IS NULL
											union all	
											SELECT 
												PlanogramId PlanogramId,
												@shelfwidthmeasureID MeasureId,
												replace(replace(ixp.width,'cm',''),'mm','') Value,
												@LOVRecordSourceId LOVRecordSourceId
												FROM [psa].[uk_btc_ix_spc_planogram_temp]  ixp 
												WHERE ixp.record_type='child'
												and NULLIF(ixp.width,'' ) IS NULL
											union all
											SELECT 
												PlanogramId PlanogramId,
												@buildsizemeasureID MeasureId,
												ixp.desc4 Value,
												@LOVRecordSourceId LOVRecordSourceId
												FROM [psa].[uk_btc_ix_spc_planogram_temp]  ixp 
												WHERE ixp.record_type='child'
												and NULLIF(ixp.desc4,'' ) IS NULL)t1
												group by planogramid,measureid,LOVRecordSourceId)t2
											on t2.planogramid=pp.planogramid
											and t2.MeasureId=pp.MeasureId
											and t2.LOVRecordSourceId=pp.LOVRecordSourceId										
											AND pp.SCDActiveFlag='Y'										
											
						PRINT '**************** Updation of  PlanogramProperty Table Completed*********************';
			/********************************************************************************************************************************
			5.	Update Source Table  :psa.uk_btc_ix_spc_planogram 
				Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
			**********************************************************************************************************************************/

			PRINT '********************Updating Source Table accordingly -> uk_btc_ix_spc_planogram****************' 


						UPDATE [psa].[uk_btc_ix_spc_planogram] SET Row_Status=@serRowStatus
                        FROM [psa].[uk_btc_ix_spc_planogram] ixp
                        INNER JOIN
                        [ser].[Planogram] p
                        ON ixp.dbkey=p.SourceKey
                        AND  ixp.record_source_id=p.LovRecordSourceID
                        AND  LOVSourceKeyTypeId=@Sourcekeytypeid_child
						INNER JOIN
						((SELECT distinct planogramid ,SCDLovRecordSourceID ,psarowkey FROM ser.Planogram WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@LovRecordSourceID and etlrunlogid=@serveETLRunLogID) 	
						UNION ALL (SELECT distinct planogramid ,SCDLovRecordSourceID ,psarowkey FROM ser.PlanogramStatus WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@LovRecordSourceID and etlrunlogid=@serveETLRunLogID) 									
						UNION ALL  (SELECT distinct planogramid ,SCDLovRecordSourceID ,psarowkey FROM ser.PlanogramGroup WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@LovRecordSourceID and etlrunlogid=@serveETLRunLogID) 									
						UNION ALL  (SELECT distinct planogramid ,SCDLovRecordSourceID ,psarowkey FROM ser.PlanogramProperty WHERE SCDACTiveFlag='Y' AND LOVRecordsourceID=@LovRecordSourceID and etlrunlogid=@serveETLRunLogID)
						) temp
								ON  temp.SCDLovRecordSourceID =@LovRecordSourceID
								AND temp.planogramid=p.planogramid							
								AND temp.psarowkey=ixp.row_id
						WHERE ixp.row_Status=@psaRowStatus
                        AND ixp.asset_id=@asset_id ;   
					
				

						UPDATE [psa].[uk_btc_ix_spc_planogram] SET Row_Status=@serRowStatus
                        FROM [psa].[uk_btc_ix_spc_planogram] ixp
                        INNER JOIN
                        [ser].[Planogram] p
                        ON cast(convert(float,ixp.value50)as nvarchar)=p.SourceKey
                        AND  ixp.record_source_id=p.LovRecordSourceID
                        AND  LOVSourceKeyTypeId=@Sourcekeytypeid_parent
                        AND p.SCDActiveFlag='Y'
                        WHERE ixp.row_Status=@psaRowStatus
                        AND ixp.asset_id=@asset_id ;


						UPDATE [psa].[uk_btc_ix_spc_planogram] SET Row_Status=@serRowStatus
                        FROM [psa].[uk_btc_ix_spc_planogram] ixp
                        INNER JOIN
                        [ser].[Planogram] p
                        ON ixp.dbkey=p.SourceKey
                        AND  ixp.record_source_id=p.LovRecordSourceID
                        AND  LOVSourceKeyTypeId=@Sourcekeytypeid_child
						and (NULLIF(ixp.livedate ,'') IS NULL or NULLIF(ixp.desc1 ,'') IS NULL or NULLIF(ixp.desc2 ,'') IS NULL or NULLIF(ixp.desc3 ,'') IS NULL or 
						NULLIF(ixp.desc4 ,'') IS NULL or NULLIF(ixp.desc5 ,'') IS NULL or NULLIF(ixp.desc28 ,'') IS NULL or NULLIF(ixp.desc29 ,'') IS NULL or 
						NULLIF(ixp.Category ,'') IS NULL or NULLIF(ixp.width,'')IS NULL)	
						   WHERE ixp.row_Status=@psaRowStatus
                       AND ixp.asset_id=@asset_id ;

						UPDATE [psa].[uk_btc_ix_spc_planogram] SET Row_Status=@serRowStatus_duplicate
                        FROM [psa].[uk_btc_ix_spc_planogram] ixp
					   WHERE ixp.row_Status=@psaRowStatus
                       AND ixp.asset_id=@asset_id ;					

					PRINT 'Info: Source Table Updated accordingly -> uk_btc_ix_spc_planogram'; 
	


	SET @COUNTER = @COUNTER + 1	;
		END

COMMIT TRANSACTION;
END TRY
			BEGIN CATCH 
				THROW;					
				ROLLBACK TRANSACTION ;						
			END CATCH 


		IF OBJECT_ID('psa.uk_btc_ix_spc_planogram_temp') is not null
		BEGIN
			DROP TABLE psa.uk_btc_ix_spc_planogram_temp
			PRINT 'Info: Dropped Temp table -> [psa].[uk_btc_ix_spc_planogram_temp]';
		END	

		IF OBJECT_ID('ser.PLANOGRAM_TEMP') is not null
		BEGIN
			drop table ser.PLANOGRAM_TEMP
			PRINT 'Info: Dropped Temp table -> ser.PLANOGRAM_TEMP';
		END	

		IF OBJECT_ID('psa.btc_ix_spc_planogram_cursor_table') is not null
		BEGIN
			drop table psa.btc_ix_spc_planogram_cursor_table
			PRINT 'Info: Dropped Temp table -> psa.btc_ix_spc_planogram_cursor_table';
		END	

		END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[psa].[sp_inc_th_crp_layout_performance]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_th_crp_layout_performance] 
END
GO


CREATE PROC [psa].[sp_inc_th_crp_layout_performance] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max) AS

BEGIN

	DECLARE 

            @crpLayoutFactId bigint,
	        @pogIdTypeId bigint,
	        @storeDimId bigint,
	        @storeLOVID bigint,
	        @floorDimId bigint,
	        @weekDimId bigint,
	        @planogramDimId bigint,
	        @measureTypeId bigint,
	        @unitId bigint,
	        @tespId bigint,
	        @tispId bigint,
	        @eposProfitId bigint,
	        @modularSpaceId bigint,
	        @max_FactInstanceId bigint,
	        @fact_type_id bigint,
            @rowStatusPSACode int = 26001,
            @rowStatusSERCode int = 26002,
			@rowStatusNotmigratedCode int = 26010,
            @LOVRecordSourceId int = 12010,
            @RecordSourceIdMerchandise int = 12012,
            @SCDStartDate datetime = (SELECT CONVERT(datetime,'1900-01-01')),
            @SCDEndDate datetime = (SELECT CONVERT(datetime,'9999-12-31')),
            @SCDActiveFlag char = 'Y',
            @SCDVersion smallint = 1;
	
	
	SET     @fact_type_id = (SELECT LOVId FROM [ser].[reflovsetinfo]
						     WHERE 	LOVSetName= 'Fact Type'
						     AND LOVRecordSourceId=@RecordSourceIdMerchandise
						     AND LOVKey='TBC');
	
	SET     @crpLayoutFactId = (SELECT FactId FROM [ser].[Fact] 
								WHERE FactName = 'CRP Layout Performance'
								AND LOVRecordSourceId = @LOVRecordSourceId
								AND LOVFactTypeId = @fact_type_id
								AND SCDActiveFlag = 'Y');
		
	SET     @pogIdTypeId = (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
							LOVsetName='Source Key Type' 			
							AND LOVKey = 'Thailand Planogram Id(pog_id)' 	
							AND LOVRecordSourceId = @RecordSourceIdMerchandise);	
								
	SET     @storeDimId = (SELECT DimensionId FROM [ser].[dimension]
						   WHERE name = 'store' 
						   AND LOVRecordSourceId = @LOVRecordSourceId   
						   AND SCDActiveFlag = 'Y');
							
							
	SET     @storeLOVID = (SELECT LOVId FROM [ser].[reflovsetinfo] 
						   WHERE LOVSetName= 'Role'
						   AND LOVKey='Store'												
						   AND LOVRecordSourceId = @RecordSourceIdMerchandise);    
							
							
	SET     @floorDimId = (SELECT DimensionId FROM [ser].[dimension]
						   WHERE name =  'Floor' 
						   AND LOVRecordSourceId = @LOVRecordSourceId    
						   AND SCDActiveFlag = 'Y');
								

	SET     @weekDimId = (SELECT DimensionId FROM [ser].[dimension]
						  WHERE name =  'Week' 
						  AND LOVRecordSourceId = @LOVRecordSourceId       
						  AND SCDActiveFlag = 'Y');
							
							
	SET     @planogramDimId =(SELECT DimensionId FROM [ser].[dimension]
							  WHERE name =  'Planogram' 
							  AND LOVRecordSourceId = @LOVRecordSourceId             
							  AND SCDActiveFlag = 'Y');
							
							
	SET     @measureTypeId =(SELECT LOVId FROM [ser].[reflovsetinfo]  
                             WHERE LOVSetName= 'Measure Type'
                             AND LOVKey='PLANOGRAM_AGGREGATION');
                            
						
	
	SET     @unitId = (SELECT MeasureId FROM [ser].[measure] WHERE measureName = 'units'
					   AND LOVRecordSourceId = @LOVRecordSourceId
					   AND SCDActiveFLag = 'Y'
					   AND LOVMeasureTypeId = @measureTypeId); 
							
							
	SET     @tespId = (SELECT MeasureId FROM [ser].[measure] WHERE measureName = 'tesp'
		    		   AND LOVRecordSourceId = @LOVRecordSourceId
		    		   AND SCDActiveFLag = 'Y'
		    		   AND LOVMeasureTypeId = @measureTypeId);
		    					
		    					
	SET     @tispId = (SELECT MeasureId FROM [ser].[measure] WHERE measureName = 'tisp'
		    		   AND LOVRecordSourceId = @LOVRecordSourceId
		    		   AND SCDActiveFLag = 'Y'
		    		   AND LOVMeasureTypeId = @measureTypeId);
		    					
		    					
	SET     @eposProfitId =(SELECT MeasureId FROM [ser].[measure] WHERE measureName = 'epos_profit'
		    				AND LOVRecordSourceId = @LOVRecordSourceId
		    				AND SCDActiveFLag = 'Y'
		    				AND LOVMeasureTypeId = @measureTypeId); 
		    					
		    					
	SET     @modularSpaceId =(SELECT MeasureId FROM [ser].[measure] WHERE measureName = 'modular_space'
							  AND LOVRecordSourceId = @LOVRecordSourceId
							  AND SCDActiveFLag = 'Y'
							  AND LOVMeasureTypeId = @measureTypeId); 
							  
							  
	/* If the date_added value in the new file <= the date_added for the previous  data load , then change status of those records to 26010 */						
	

        UPDATE [psa].[th_crp_layout_performance] 
		SET row_status = @rowStatusNotmigratedCode
        WHERE row_id in
                       (SELECT
                        A.row_id
                        FROM [psa].[th_crp_layout_performance] A
                        JOIN (SELECT distinct pog_id,record_source_id,max(date_added) as date_added FROM [psa].[th_crp_layout_performance]
                        WHERE row_status = @rowStatusSERCode
					    GROUP BY pog_id,record_source_id) B
                        ON  A.pog_id=B.pog_id 
						and A.record_source_id = B.record_source_id
                        AND A.date_added <= B.date_added
                        AND A.row_status = @rowStatusPSACode);
					 
		Print 'Completed row_status updation of source after checking previously processed dates'
	
	
		/*-------------------------------Create temporary source table-------------------------------*/				 
              
   
	
	
	SELECT @max_FactInstanceId = COALESCE(MAX(FactInstanceId),0) FROM [ser].[FactInstance];

	IF OBJECT_ID('tempdb..#th_crp_layout_temp') is not null
	BEGIN
		DROP TABLE #th_crp_layout_temp
	END 
	
	IF OBJECT_ID('tempdb..#th_crp_layout_join') is not null
	BEGIN
		DROP TABLE #th_crp_layout_join
	END
	
	SELECT
		*
	INTO #th_crp_layout_temp
	FROM 
	(
		SELECT 
			 FactInstanceId
			,pog_id
			,row_id 
			,store_number
			,floor
			,week
			,units
			,tesp
			,tisp
			,epos_profit
			,modular_space
			,date_added
	
		FROM 
		(
			SELECT 
			    @max_FactInstanceId + (ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS FactInstanceId
				,ISNULL( NULLIF((Substring(pog_id, Patindex('%[^0]%', pog_id + ' '), Len(pog_id)) ),''),0) pog_id
				,row_id 
				,store_number
				,floor
				,week
				,CASE WHEN (units IS NOT NULL AND units <> '') THEN CAST(CAST(CAST(units AS NUMERIC) AS INT) AS nVARCHAR(50)) ELSE NULL END AS units
				,CAST(tesp as nVARCHAR(50)) as tesp
				,CAST(tisp as nVARCHAR(50)) as tisp
				,CAST(epos_profit as nVARCHAR(50)) as epos_profit
				,CAST(modular_space as nVARCHAR(50)) as modular_space
				,date_added
				
			FROM  [psa].[th_crp_layout_performance]
			WHERE [row_status]=@rowStatusPSACode
			 
			)C
        )A
		
			SELECT
		        *
	        INTO #th_crp_layout_join
	        FROM 
	        (
				SELECT
				    (ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS RowNumber
					,A.FactInstanceId
					,A.pog_id
					,A.row_id 
					,A.store_number
					,A.floor
					,A.week
					,A.units
					,A.tesp
					,A.tisp
					,A.epos_profit
					,A.modular_space
					,A.date_added
					,B.PlanogramId
				FROM 
				(
				    SELECT
					    FactInstanceId 
					   ,pog_id 
                       ,row_id 
	                   ,store_number
	                   ,floor
	                   ,week
	                   ,units
	                   ,tesp
	                   ,tisp
	                   ,epos_profit
	                   ,modular_space
	                   ,date_added
	                FROM #th_crp_layout_temp
	            )A
				LEFT OUTER JOIN
				(
			        SELECT * FROM [ser].[Planogram] 
			        	WHERE SCDActiveFlag='Y' 
			        	AND LOVRecordSourceId=@LOVRecordSourceId 
			        	AND LOVSourceKeyTypeId = @pogIdTypeId
			        	-- AND SCDLOVRecordSourceId = @LOVRecordSourceId
		) B 
		ON ISNULL( NULLIF((Substring(A.pog_id, Patindex('%[^0 ]%', A.pog_id + ' '), Len(A.pog_id)) ),''),0)  = ISNULL( NULLIF((Substring(B.SourceKey, Patindex('%[^0 ]%', B.SourceKey + ' '), Len(B.SourceKey)) ),''),0)  
	) A	
	
	
	Print 'Completed insertion  into temporary tables'
	
	BEGIN TRANSACTION;
    BEGIN TRY
	
	/*
		Insert Data into [ser].[FactInstance] TABLE
	*/
		
	PRINT 'Info: Processing [ser].[FactInstance] ';
	
	INSERT INTO [ser].[FactInstance]
	(
		 [FactInstanceId]
		,[FactId]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
	)
	(
		SELECT
			 FactInstanceId AS			[FactInstanceId]
			,@crpLayoutFactId AS		[FactId]
			,@LOVRecordSourceId AS		[LOVRecordSourceId]
			,@SCDStartDate AS 			[SCDStartDate]
			,@SCDEndDate AS 			[SCDEndDate]
			,@SCDActiveFLag  AS 		[SCDActiveFlag]
			,@SCDVersion AS 			[SCDVersion]
			,@LOVRecordSourceId AS		[SCDLOVRecordSourceId]
			,@serveETLRunLogID as		[ETLRunLogId]
			,row_id as 				    [PSARowKey]
		FROM #th_crp_layout_temp 
	)
	
	Print 'Completed insertion  to FactInstance table'
	
	/*
		TABLE 02	: [ser].[FactDimensionInstance]
	*/
	
	PRINT 'Info: Updating Store Dimensions for existing DimensionSurrogateKey NULL records ';
	
	UPDATE [ser].[FactDimensionInstance]
		SET DimensionSurrogateKey = site_role.siteroleid
		FROM
		[ser].[FactDimensionInstance] src
		JOIN 
		(
				SELECT * 
				FROM [ser].[siterole] 
				where
				LOVRecordSourceId = @LOVRecordSourceId
				AND scdactiveflag = 'Y' AND LOVRoleId = @storeLOVID 
				-- AND SCDLOVRecordSourceId = @LOVRecordSourceId
			)site_role
     	ON site_role.SourceKey = src.DimensionSourceKey
		where src.DimensionSurrogateKey is NULL and src.DimensionId = @storeDimId and src.LOVRecordSourceId = @LOVRecordSourceId AND src.ETLRunLogId = @serveETLRunLogID 
		--AND src.SCDLOVRecordSourceId = @LOVRecordSourceId;
	
	PRINT 'Info: Updating Planogram Dimensions for existing DimensionSurrogateKey NULL records ';	
	
		UPDATE  [ser].[FactDimensionInstance]
		SET DimensionSurrogateKey = lkp_plan.PlanogramId
		FROM
		[ser].[FactDimensionInstance] src
		JOIN 
		(SELECT PlanogramId,SourceKey FROM [ser].[Planogram] WHERE SCDActiveFlag='Y' AND LOVRecordSourceId=@LOVRecordSourceId 
		AND LOVSourceKeyTypeId = @pogIdTypeId 
		-- AND SCDLOVRecordSourceId=@LOVRecordSourceId
		)lkp_plan
        ON src.DimensionSourceKey = ISNULL( NULLIF((Substring(lkp_plan.SourceKey, Patindex('%[^0 ]%', lkp_plan.SourceKey + ' '), Len(lkp_plan.SourceKey)) ),''),0) 
        JOIN
        (SELECT DimensionSourceKey,count(*) AS cnt  FROM 
        (SELECT DISTINCT p.DimensionSourceKey,plano.PlanogramId 
        FROM [ser].[FactDimensionInstance] p 
        JOIN 
        (SELECT PlanogramId,SourceKey FROM [ser].[Planogram] WHERE SCDActiveFlag='Y' AND LOVRecordSourceId=@LOVRecordSourceId 
		AND LOVSourceKeyTypeId = @pogIdTypeId 
		-- AND SCDLOVRecordSourceId=@LOVRecordSourceId
		)plano
        ON p.DimensionSourceKey = ISNULL( NULLIF((Substring(plano.SourceKey, Patindex('%[^0 ]%', plano.SourceKey + ' '), Len(plano.SourceKey)) ),''),0)  )A GROUP BY DimensionSourceKey HAVING COUNT(*)=1)lkp_pog
        ON ISNULL( NULLIF((Substring(lkp_plan.SourceKey, Patindex('%[^0 ]%', lkp_plan.SourceKey + ' '), Len(lkp_plan.SourceKey)) ),''),0) = lkp_pog.DimensionSourceKey
		WHERE src.DimensionSurrogateKey IS NULL AND src.DimensionId = @planogramDimId AND src.LOVRecordSourceId = @LOVRecordSourceId  
		AND src.ETLRunLogId = @serveETLRunLogID 
		--AND src.SCDLOVRecordSourceId = @LOVRecordSourceId ;
		
	PRINT 'Info: Existing DimensionSurrogateKey NULL update completed ';	
	
	PRINT 'Info: Processing [ser].[FactDimensionInstance] ';
	
	INSERT INTO [ser].[FactDimensionInstance]
	(
		[FactInstanceId]
		,[DimensionId]
		,[DimensionSurrogateKey]
		,[DimensionSourceKey]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
	)
	(
		SELECT
			[FactInstanceId]
			,[DimensionId]
			,[DimensionSurrogateKey]
			,[DimensionSourceKey]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		FROM
		(
			SELECT 
				A.FactInstanceId AS [FactInstanceId]
				,@storeDimId AS [DimensionId]
				,B.SiteRoleId AS [DimensionSurrogateKey]
				,A.store_number AS [DimensionSourceKey]
				,@LOVRecordSourceId AS [LOVRecordSourceId]
				,@SCDStartDate AS 			[SCDStartDate]
				,@SCDEndDate AS 			[SCDEndDate]
				,@SCDActiveFLag  AS 		[SCDActiveFlag]
				,@SCDVersion AS 			[SCDVersion]
				,@LOVRecordSourceId AS	[SCDLOVRecordSourceId]
				,@serveETLRunLogID as [ETLRunLogId]
				,A.row_id as [PSARowKey]
			FROM #th_crp_layout_temp	A
			left outer join 
			(SELECT  * FROM [ser].[siterole] WHERE 
				LOVRecordSourceId=@LOVRecordSourceId 
				AND SCDActiveFlag='Y' 
				AND LOVRoleId = @storeLOVID
			)B
			on A.store_number = B.SourceKey
			
			UNION
			
			SELECT 
				A.FactInstanceId AS [FactInstanceId]
				,@floorDimId AS [DimensionId]
				,B.LOVId AS [DimensionSurrogateKey]
				,A.floor AS [DimensionSourceKey]
				,@LOVRecordSourceId AS [LOVRecordSourceId]
				,@SCDStartDate AS 			[SCDStartDate]
				,@SCDEndDate AS 			[SCDEndDate]
				,@SCDActiveFLag  AS 		[SCDActiveFlag]
				,@SCDVersion AS 			[SCDVersion]
				,@LOVRecordSourceId AS	[SCDLOVRecordSourceId]
				,@serveETLRunLogID as [ETLRunLogId]
				,A.row_id as [PSARowKey]
			FROM #th_crp_layout_temp A
			LEFT OUTER JOIN
			(
				SELECT * FROM [ser].[reflovsetinfo] 
					WHERE LOVSetName = 'floor'
					AND LOVRecordSourceId = @LOVRecordSourceId
			) B
			on A.floor = B.LOVKey
			
			UNION
			
			SELECT 
				A.FactInstanceId AS [FactInstanceId]
				,@weekDimId AS [DimensionId]
				,B.LOVId AS [DimensionSurrogateKey]
				,A.week AS [DimensionSourceKey]
				,@LOVRecordSourceId AS [LOVRecordSourceId]
				,@SCDStartDate AS 			[SCDStartDate]
				,@SCDEndDate AS 			[SCDEndDate]
				,@SCDActiveFLag  AS 		[SCDActiveFlag]
				,@SCDVersion AS 			[SCDVersion]
				,@LOVRecordSourceId AS	[SCDLOVRecordSourceId]
				,@serveETLRunLogID as [ETLRunLogId]
				,A.row_id as [PSARowKey]	
				FROM #th_crp_layout_temp A
			LEFT OUTER JOIN
			(
			SELECT * FROM [ser].[reflovsetinfo] 
				WHERE LOVSetName = 'week'
				AND LOVRecordSourceId = @LOVRecordSourceId
			) B
			on A.week = B.LOVKey
				
			UNION

				SELECT 
					 B.FactInstanceId AS [FactInstanceId]
					,B.DimensionId AS [DimensionId]
					,B.DimensionSurrogateKey AS [DimensionSurrogateKey]
					,B.DimensionSourceKey AS [DimensionSourceKey]
					,B.LOVRecordSourceId AS [LOVRecordSourceId]
					,B.SCDStartDate AS [SCDStartDate]
					,B.SCDEndDate AS [SCDEndDate]
					,B.SCDActiveFLag AS [SCDActiveFlag]
					,B.SCDVersion AS [SCDVersion]
					,B.SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,B.ETLRunLogId AS [ETLRunLogId]
					,B.PSARowKey AS [PSARowKey] 
				FROM 			
		           (
		        	SELECT distinct
					     A.RowNumber AS RowNumber
		        		,A.FactInstanceId AS [FactInstanceId]
		        		,@planogramDimId AS [DimensionId]
		        		,(case when
		        	             (SELECT count(row_id) FROM (SELECT row_id FROM #th_crp_layout_join WHERE row_id=A.row_id) X)= 1 then A.PlanogramId else NULL end ) AS [DimensionSurrogateKey]
		        		,ISNULL( NULLIF((Substring(A.pog_id, Patindex('%[^0 ]%', A.pog_id + ' '), Len(A.pog_id)) ),''),0)   AS [DimensionSourceKey]
		        		,@LOVRecordSourceId AS [LOVRecordSourceId]
		        		,@SCDStartDate AS 			[SCDStartDate]
		        		,@SCDEndDate AS 			[SCDEndDate]
		        		,@SCDActiveFLag  AS 		[SCDActiveFlag]
		        		,@SCDVersion AS 			[SCDVersion]
		        		,@LOVRecordSourceId AS	[SCDLOVRecordSourceId]
		        		,@serveETLRunLogID as [ETLRunLogId]
		        		,A.row_id as [PSARowKey]
		        	FROM #th_crp_layout_join A
					                )B

                    WHERE RowNumber IN
				    (
					     SELECT MIN(RowNumber) FROM
					     (
					     	SELECT  
					     		 A.RowNumber AS [RowNumber]
					     		,A.row_id AS [PSARowKey]
					     	from  #th_crp_layout_join A
					     ) X
					GROUP BY PSARowKey
				) 
		) A
    )
	
	Print 'Completed insertion  into FactDimensionInstance table'
	
	/*
		TABLE 03	: [ser].[FactMeasureInstance]
	*/
	PRINT 'Info: Processing [ser].[FactMeasureInstance] ';
	
	WITH Stg_th_crp_layout_performance AS
	(
		SELECT 
			[FactInstanceId]
			,[row_id]
			,[ColumnName]
			,[ColumnValue]
			,CASE
				WHEN ColumnName ='units' THEN @unitId
				WHEN ColumnName ='tesp' THEN @tespId
				WHEN ColumnName ='tisp' THEN @tispId
				WHEN ColumnName ='epos_profit' THEN @eposProfitId
				WHEN ColumnName ='modular_space' THEN @modularSpaceId
				ELSE NULL
			END AS [MeasureId]
		FROM #th_crp_layout_temp
		UNPIVOT
		(
			ColumnValue FOR ColumnName IN (units, tesp, tisp, epos_profit, modular_space)
		) U
		WHERE ColumnValue IS NOT NULL AND ColumnValue <> ''
	)
	
	INSERT INTO [ser].[FactMeasureInstance]
	(
	 [FactInstanceId]
    ,[MeasureId]
    ,[Value]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
	(
		SELECT
			[FactInstanceId]
			,[MeasureId]
			,[Value]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		FROM
		(
			SELECT
				FactInstanceId AS [FactInstanceId]
				,MeasureId AS [MeasureId]
				,ColumnValue AS [Value]
				,@LOVRecordSourceId AS [LOVRecordSourceId]
				,@SCDStartDate AS 			[SCDStartDate]
				,@SCDEndDate AS 			[SCDEndDate]
				,@SCDActiveFLag  AS 		[SCDActiveFlag]
				,@SCDVersion AS 			[SCDVersion]
				,@LOVRecordSourceId AS	[SCDLOVRecordSourceId]
				,@serveETLRunLogID as [ETLRunLogId]
				,row_id as [PSARowKey]
			FROM Stg_th_crp_layout_performance
		) X
	)
	
	Print 'Completed insertion  into FactMeasureinstance table'
	
	    PRINT 'Updating Source Table accordingly -> [psa].[th_crp_layout_performance]****************';  

    UPDATE [psa].[th_crp_layout_performance] SET [row_status]=@rowStatusSERCode
                FROM [psa].[th_crp_layout_performance] tclp
                JOIN
                (SELECT distinct FactInstanceId,PSARowKey,LOVRecordSourceId FROM [ser].[FactInstance] 
				WHERE [LOVRecordSourceId] = @LOVRecordSourceId
                AND ETLRunLogId = @serveETLRunLogID 
				-- AND SCDLOVRecordSourceId=@LOVRecordSourceId
				)temp
                ON tclp.row_id = temp.PSARowKey
                AND tclp.record_source_id = temp.LOVRecordSourceId
                WHERE tclp.row_status=@rowStatusPSACode;
				
				
    PRINT ('Updated Row Status to ''Loaded to Serve'' for [psa].[th_crp_layout_performance] International Thailand  ')
			

			COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH
            THROW;
			ROLLBACK TRANSACTION;	
			END CATCH 
END
GO
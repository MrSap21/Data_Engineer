SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('[psa].[sp_inc_mx_crp_merchandise]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_mx_crp_merchandise]
END
GO



CREATE PROC [psa].[sp_inc_mx_crp_merchandise] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS

BEGIN


--drop temp table if exists

IF OBJECT_ID('psa.mx_crp_merchandise_tmptable') is not null
	BEGIN
	DROP TABLE [psa].[mx_crp_merchandise_tmptable]
	END
	
--create target temp table to hold only required 8 columns out of 200+ columns
	


	CREATE TABLE [psa].[mx_crp_merchandise_tmptable]
	(
		[PSARowKey] [bigint] NOT NULL,
		[LOVSourceKeyTypeId] [int] NULL,
		[PlanogramID] [bigint] NULL,
		[ParentPlanogramID] [bigint] NULL,
		[sourceKey] [nvarchar](80) NULL,
		[pog_description] [nvarchar](80) NULL,
		[planogram_start_date] datetime NULL,	
		[planogram_end_date] datetime NULL, 
		[shelf_depth] [nvarchar](255) NULL,
		[height] [nvarchar](255) NULL,
		[fitting_type] [nvarchar](255) NULL,
		[build_size] [nvarchar](255) NULL,
		[planner_family] [nvarchar](255) NULL,
		[footprint] [nvarchar](255) NULL,
		[category] [nvarchar](255) NULL,
		[format] [nvarchar](255) NULL,
		[promotional_site] [nvarchar](255) NULL,
		[date_added] [nvarchar](500) NULL,
		[etl_runlog_id] [int] NULL,
		[asset_id] [int] NULL,
		[LOVRecordSourceId] [int] NULL,
		[row_status] [int] NULL,
		[created_timestamp] [datetime] NULL
	)
	WITH
	(
		DISTRIBUTION = REPLICATE,
		CLUSTERED COLUMNSTORE INDEX
	)

    DECLARE @SCDDefaultStartDate DATETIME,
	        @scdDefaultEndDate DATETIME,
	        @SCDStartDate DATETIME,
	        @SCDEndDate DATETIME,
	        @dateAdded VARCHAR (max),
	        @MAXID BIGINT,
	        @COUNTER BIGINT,
	        @LOVRecordSourceId BIGINT,
	        @RecordSourceIdMerchANDise BIGINT,
	        @indicatorLOVID BIGINT,
	        @LOVSourceKeyTypeId BIGINT,
	        @fittingTypeLOVSetID BIGINT,
	        @plannerFamilyLOVSetID BIGINT,
	        @footprintLOVSetID BIGINT,
	        @categoryLOVSetID BIGINT,
	        @formatLOVSetID BIGINT,
	        @rowStatusPSACode BIGINT,
	       	@rowStatusSERCode BIGINT,
	       	@measureTypeIdPlanoDim BIGINT,
	        @shelfDepthMeasureID BIGINT,
	        @heightMeasureID BIGINT,
	        @buildSizeMeasureID BIGINT,
	        @LOVIdUnitCM BIGINT,
	        @LOVIdUnitUnKnown BIGINT,
	        @max_PlanogramGroupId BIGINT,
	        @max_planogramID	BIGINT,
	        @rowStatusNotmigratedCode BIGINT = 26010,
	        @SCDActiveFlag char;
	
	
	IF OBJECT_ID('psa.int_planogram_cursor_table') is not null
	BEGIN
			DROP TABLE [psa].[int_planogram_cursor_table]
	END	
	
	CREATE TABLE [psa].[int_planogram_cursor_table]
			(
				[row_id] [bigint]  NULL,
				[date_added] [nvarchar](25)  NULL
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			)

	
	BEGIN TRANSACTION

	SET @SCDDefaultStartDate = CONVERT(DateTime,'1900-01-01')	
	SET @SCDDefaultEndDate = CONVERT(DateTime,'9999-12-31')
	SET @SCDStartDate = CURRENT_TIMESTAMP;
	SET @SCDEndDate = DATEADD(second,-1,@SCDStartDate);
	SET @LOVRecordSourceId = 12004
	SET @RecordSourceIdMerchANDise = 12012
	SET @rowStatusPSACode = 26001
	SET @rowStatusSERCode = 26002
	set @SCDActiveFlag = 'Y' 
	
	
	SELECT  @max_planogramID		= COALESCE(MAX(PlanogramID),0) FROM ser.planogram;
	
	SET @indicatorLOVID = (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
								LOVsetName='Indicator - MEXICO Merchandise'
								AND LOVKey = 'promotional_site'
								AND LOVRecordSourceId = @LOVRecordSourceId)
								
	SET @LOVSourceKeyTypeId = (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
								LOVsetName='Source Key Type' 
								AND LOVKey = 'Mexico Planogram Id(pog_id)' 
								AND LOVRecordSourceId = @RecordSourceIdMerchANDise)
								
								
	SET @fittingTypeLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='fitting_type' 			
									and LOVRecordSourceId = @LOVRecordSourceId)		
									
	SET @plannerFamilyLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='planner_family' 			
									and LOVRecordSourceId = @LOVRecordSourceId)		
									
	SET @footprintLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='footprint' 			
									and LOVRecordSourceId = @LOVRecordSourceId)		
									
	SET @categoryLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='category' 			
									and LOVRecordSourceId = @LOVRecordSourceId)		
									
	SET @formatLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='format' 			
									and LOVRecordSourceId = @LOVRecordSourceId)		
								
	SET @measureTypeIdPlanoDim = (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
									LOVsetName='Measure Type' 
									AND LOVKey = 'PLANOGRAM_DIM' 
									AND LOVRecordSourceId = @RecordSourceIdMerchANDise)
									
	SET @shelfDepthMeasureID = (SELECT MeasureId FROM [ser].[measure] 
									WHERE
									MeasureName = 'shelf_depth' AND
									LOVMeasureTypeId = @measureTypeIdPlanoDim AND
									LOVRecordSourceId = @LOVRecordSourceId)
									
	SET @heightMeasureID = (SELECT MeasureId FROM [ser].[measure] 
									WHERE
									MeasureName = 'height' AND
									LOVMeasureTypeId = @measureTypeIdPlanoDim AND
									LOVRecordSourceId = @LOVRecordSourceId)
									
	SET @buildSizeMeasureID = (SELECT MeasureId FROM [ser].[measure] 
									WHERE
									MeasureName = 'build_size' AND
									LOVMeasureTypeId = @measureTypeIdPlanoDim AND
									LOVRecordSourceId = @LOVRecordSourceId)
									
	SET @LOVIdUnitCM		= (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
								LOVsetName='Unit Of Measure'
								AND LOVKey = 'cm' 
								AND LOVRecordSourceId = @RecordSourceIdMerchANDise)
								
	SET @LOVIdUnitUnKnown 	= (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
								LOVsetName='Unit Of Measure'
								AND LOVKey = 'Unknown' 	
								AND LOVRecordSourceId = @RecordSourceIdMerchANDise) 
								
								

BEGIN TRY

/*IF the date_added value in the new file <= the date_added for the previous  data load 
Then 
   DO NOT LOAD DATA
Else
  LOAD ALL DATA*/
  
  
	update psa.mx_crp_merchandise      
        set row_status = @rowStatusNotmigratedCode
        where row_id in (
                    SELECT
                        A.row_id
                    from psa.mx_crp_merchandise A
                    JOIN (select distinct pog_id,record_source_id,Max(date_added) 
					as date_added from psa.mx_crp_merchandise
                    where row_status = @rowStatusSERCode group by pog_id,record_source_id) B
                    on  A.pog_id=B.pog_id     
                    and A.record_source_id = B.record_source_id								
                    and A.date_added<=B.date_added
                    and A.row_status = @rowStatusPSACode
                );
				
				 
   
	------------------------------------------------------
	
	PRINT 'Info: mx_crp_merchandise_tmptable  loading started';
	
		WITH stg_planogram AS (SELECT *  FROM ser.planogram pg  
									WHERE LOVRecordSourceID = @lovRecordSourceID 
									AND LOVSourceKeyTypeId = @LOVsourceKeyTypeID
									AND NOT EXISTS (SELECT 1 FROM ser.planogram AS pgm
														WHERE pgm.PlanogramId = pg.PlanogramId
														AND pgm.LOVRecordSourceID=pg.LOVRecordSourceID
														AND  pgm.SCDVersion > pg.SCDVersion)
							  ),
							  
			stg_deduplicate as (SELECT a.pog_id,
										a.date_added,     
										ROW_NUMBER() OVER (  PARTITION BY CONVERT(INT,a.pog_id),a.date_added ORDER BY a.pog_id,a.date_added) as row_id
								FROM psa.mx_crp_merchandise a,
										(SELECT pog_id,
												max(date_added ) date_added									
										FROM psa.mx_crp_merchandise 
										GROUP BY pog_id,date_added ) temp
								WHERE a.pog_id=temp.pog_id and a.date_added=temp.date_added
								) 		

		INSERT INTO psa.mx_crp_merchandise_tmptable
		(	PSARowKey,
			LOVSourceKeyTypeId,
			PlanogramID,
			ParentPlanogramID,
			sourceKey,
			pog_description,
			planogram_start_date,	
			planogram_end_date, 
			shelf_depth,
			height,
			fitting_type,
			build_size,
			planner_family,
			footprint,
			category,
			format,
			promotional_site,
			date_added,
			etl_runlog_id,
			asset_id,
			LOVRecordSourceId,
			row_status,
			created_timestamp)

			SELECT
			t.PSARowKey,
			t.LOVSourceKeyTypeId,
			t.PlanogramId,
			t.ParentPlanogramId,
			t.sourceKey,
			t.pog_description,
			t.planogram_start_date,	
			t.planogram_end_date, 
			t.shelf_depth,
			t.height,
			t.fitting_type,
			t.build_size,
			t.planner_family,
			t.footprint,
			t.category,
			t.format,
			t.promotional_site,
			t.date_added,
			t.etl_runlog_id,
			t.asset_id,
			t.LOVRecordSourceId,
			t.row_status,
			t.created_timestamp
			FROM (

				SELECT
					A.row_id PSARowKey,
					@LOVSourceKeyTypeId LOVSourceKeyTypeId,
					ISNULL(p.PlanogramId,B.PlanogramId) PlanogramId, /*if planogram is in the  ser.planogram that id will pick up or take the new id created with max+rownumber */
					NULL ParentPlanogramId,
					A.pog_id sourceKey,
					pog_description,
					ISNULL(planogram_start_date,'') as planogram_start_date,	
					ISNULL(planogram_end_date,'') as planogram_end_date, 
					shelf_depth,
					height,
					fitting_type,
					build_size,
					planner_family,
					footprint,
					category,
					format,
					promotional_site,
					NULLIF(A.date_added,'') date_added, 
					CAST(@serveETLRunLogID AS INT) etl_runlog_id,
					asset_id,
					A.record_source_id LOVRecordSourceId,
					A.row_status,
					created_timestamp
				FROM psa.mx_crp_merchandise A
				LEFT JOIN stg_deduplicate sd
					ON A.pog_id=sd.pog_id
					ANd A.date_added=sd.date_added 
					AND sd.row_id = 1					
				JOIN (SELECT A.pog_id, --creating planogram id for all the entries in the psa planogram table  by adding row number to the max planogram id of ser  table
						A.record_source_id,
						--A.date_added,
						(@max_planogramID+dense_rank() OVER(ORDER BY Convert(int, A.pog_id) ,A.record_source_id ASC)) PlanogramId
						FROM psa.mx_crp_merchandise A  
						WHERE A.row_status=@rowStatusPSACode 
						GROUP BY A.pog_id,A.record_source_id) B
					ON B.pog_id = A.pog_id 
					AND B.record_source_id = A.record_source_id
					--and B.date_added = A.date_added
				LEFT JOIN stg_planogram p
					ON A.pog_id = p.sourcekey  
					AND A.record_source_id = p.LOVRecordSourceId
					AND p.LOVSourceKeyTypeId = @LOVSourceKeyTypeId
					where /*A.pog_id IS NOT NULL and A.pog_id !=''
					AND A.date_added IS NOT NULL and A.date_added!=''
					AND*/ A.row_status = CAST(@rowStatusPSACode AS INT)
			) t
			

		PRINT 'Info: mx_crp_merchandise_temp temporary table loaded with  records successfully';		


 /******************************************************************************************************************************** 
  Create cursor table for looping  --> int_planogram_cursor_table 
 ********************************************************************************************************************************/    
	INSERT INTO [psa].[int_planogram_cursor_table]
					SELECT  distinct DENSE_RANK() OVER(ORDER BY (A.date_added )) AS row_id,
							A.date_added as date_added
					FROM psa.mx_crp_merchandise_tmptable A 
					WHERE A.row_status =@rowStatusPSACode
		
								
		SET @COUNTER = 1
		SELECT @MAXID =  COUNT(DISTINCT date_added) FROM psa.mx_crp_merchandise_tmptable
		print 'Total Number of Loops : '+CAST(@MAXID as varchar)+''

		WHILE (@COUNTER <= @MAXID)

			BEGIN
				print 'Loop Number  : '+cast(@COUNTER as varchar)+'';
				PRINT 'Current Processing Date: '+CAST(@dateAdded AS VARCHAR)+'';
				
				SET 	@dateAdded		= (SELECT date_added from [psa].[int_planogram_cursor_table] where row_id = @COUNTER)
				SET		@SCDStartDate	= CURRENT_TIMESTAMP;
				SET		@SCDEndDate		= @SCDStartDate;									
		
	/******************************************************************************************************************************** 
 1. Table Name  :    Planogram
 *******************************************************************************************************************************/   
	
				PRINT 'Info: Planogram Table Serve Loading Started';
	
				PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
					
			

			WITH stg_planogram AS (SELECT * FROM ser.planogram pg     
								WHERE LOVRECORDSOURCEID = @LOVRecordSourceID 
								AND NOT EXISTS ( SELECT 1 FROM ser.planogram AS pgm
												WHERE pgm.PlanogramID = pg.PlanogramID
												AND pgm.LOVRecordSourceID= pg.LOVRecordSourceID
												AND  pgm.SCDVersion > pg.SCDVersion ))
												
				INSERT INTO ser.planogram
					(PlanogramId,
					SourceKey,
					LOVSourceKeyTypeId,
					planogramStartDate,	
					planogramEndDate, 
					planogramName,
					ParentPlanogramId,
					LOVRecordSourceId,
					SCDStartDate,
					SCDEndDate,
					SCDActiveFlag,
					SCDVersion,
					SCDLOVRecordSourceId,
					ETLRunLogId,
					PSARowKey
					)
					SELECT 
						PlanogramId,
						SourceKey,
						LOVSourceKeyTypeId,
						CASE WHEN (PlanogramStartDate = '' or PlanogramStartDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramStartDate END AS [PlanogramStartDate],
	                    CASE WHEN (PlanogramEndDate = '' or PlanogramEndDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramEndDate END AS [PlanogramEndDate],
						PlanogramName,
						ParentPlanogramId,
						LOVRecordSourceId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY PlanogramId ORDER BY date_added ASC)) = 1) 
								THEN @SCDDefaultStartDate 
								ELSE @SCDStartDate
							END SCDStartDate,
						LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY PlanogramId ORDER BY date_added ASC) SCDEndDate,
						LEAD('N', 1, 'Y') OVER(PARTITION BY PlanogramId ORDER BY date_added ASC) SCDActiveFlag,
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY PlanogramId ORDER BY date_added ASC) SCDVersion,
						SCDLOVRecordSourceId,
						ETLRunLogId,
						PSARowKey
					FROM
					(
						SELECT
							A.PSARowKey,
							A.PlanogramId,
							A.SourceKey,
							A.LOVSourceKeyTypeId,
							ISNULL(A.planogram_start_date,'') PlanogramStartDate,	
							ISNULL(A.planogram_end_date,'') PlanogramEndDate, 
							A.pog_description PlanogramName ,
							A.ParentPlanogramId,
							A.LOVRecordSourceId,
							A.date_added,
							@SCDDefaultEndDate SCDEndDate,
							A.LOVRecordSourceId SCDLOVRecordSourceId,				
							p.SCDVersion SCDVersion,
							@serveETLRunLogID ETLRunLogId,
							LEAD('N', 1, 'Y') OVER(PARTITION BY A.PlanogramId,A.pog_description,A.planogram_start_date,A.planogram_end_date,
							A.date_added ORDER BY A.date_added ASC) SCDActiveFlag
						FROM psa.mx_crp_merchandise_tmptable A
						LEFT JOIN stg_planogram p
							ON A.PlanogramId = p.PlanogramId 	                 
							AND A.LOVRecordSourceId = p.LOVRecordSourceId
							AND p.LOVSourceKeyTypeId = @LOVsourceKeyTypeID
							where 	A.date_added = @dateAdded
							and A.LOVSourceKeyTypeId = @LOVsourceKeyTypeID 
						    AND (CASE  WHEN ( NULLIF(A.pog_description,'' ) IS NULL 
											AND NULLIF( A.planogram_start_date,'' ) IS NULL 
											AND NULLIF( A.planogram_end_date,'') IS NULL)  
										THEN 0
										ELSE 1 
								END
								)=1		
				)t 
					WHERE t.SCDActiveFlag=@SCDActiveFlag
						AND NOT EXISTS ( SELECT 1 FROM ser.planogram p 
											WHERE t.sourcekey = p.sourcekey  
											AND t.LOVSourceKeyTypeId= p.LOVSourceKeyTypeId
											AND t.LOVRecordSourceId=p.LOVRecordSourceId
											AND ISNULL(t.PlanogramName,'') = ISNULL(p.PlanogramName,'')
											AND ISNULL(t.PlanogramStartDate,'')=ISNULL(p.PlanogramStartDate,'')
											AND ISNULL(t.PlanogramEndDate,'')=ISNULL(p.PlanogramEndDate,'')
											AND p.SCDActiveFlag =@SCDActiveFlag
											)		
											
											
		PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key';
	
				UPDATE ser.planogram set SCDActiveFlag='N',SCDEndDate = @SCDEndDate
					FROM ser.planogram p
					JOIN
						(SELECT planogramId,
							SCDactiveflag, 
							SCDVersion,
							LovRecordSourceId 
						FROM ser.planogram t 
						WHERE
							t.LOVRecordSourceID = @lovRecordSourceID 
							AND t.SCDActiveFlag=@SCDActiveFlag
							AND NOT EXISTS (
								SELECT 1 FROM ser.planogram AS pt
										WHERE pt.PlanogramID = t.PlanogramID
										AND pt.LOVRecordSourceID=t.LOVRecordSourceID
										AND pt.LOVSourceKeyTypeId=t.LOVSourceKeyTypeId
										AND  pt.ScdVersion > t.ScdVersion
									)
						) pl
					ON  p.PlanogramID=pl.PlanogramId
						AND p.LovRecordSourceId=pl.LovRecordSourceId
						AND p.SCDactiveflag=pl.SCDactiveflag
						AND p.SCDVersion!=pl.SCDVersion
					JOIN psa.mx_crp_merchandise_tmptable B
					ON p.PlanogramID = B.PlanogramID
					WHERE p.SCDActiveFlag=@SCDActiveFlag
						AND p.SCDEndDate = @scdDefaultEndDate
						AND date_added = @dateAdded
	
				UPDATE ser.planogram SET SCDActiveFlag= 'N', SCDEndDate = @SCDEndDate
					FROM ser.planogram p
					JOIN psa.mx_crp_merchandise_tmptable B
					ON p.PlanogramID = B.PlanogramID
					WHERE NULLIF(B.pog_description,'' ) IS NULL
						AND NULLIF( B.planogram_start_date,'' ) IS NULL
						AND NULLIF( B.planogram_end_date,'') IS NULL
						AND p.SCDActiveFlag = @SCDActiveFlag
						AND date_added = @dateAdded
	
				PRINT 'Info: Planogram Table Loaded Successfully';
				
				
				
						
			

		/**
			TABLE 02	: [ser].[ PlanogramGroup]
		*/

		PRINT 'Info: Processing [ser].[ PlanogramGroup] for Date : '+@dateAdded+'';
		
		
	SELECT @max_PlanogramGroupId = COALESCE(MAX(PlanogramGroupId),0) FROM [ser].[planogramgroup];
	
	
		WITH Stg_Planogram_Group AS 
		(
			SELECT * FROM [ser].[planogramgroup] A
			WHERE LOVRecordSourceId=@LOVRecordSourceId
			AND LOVPlanogramGroupSetId IN (@fittingTypeLOVSetID, @plannerFamilyLOVSetID, @footprintLOVSetID, @categoryLOVSetID, @formatLOVSetID)
			AND NOT EXISTS	(
								SELECT 1 FROM [ser].[planogramgroup] B
									WHERE A.PlanogramId = B.PlanogramId
									AND A.LOVPlanogramGroupSetId = B.LOVPlanogramGroupSetId
									AND A.LOVRecordSourceId = B.LOVRecordSourceId
									AND  B.ScdVersion > A.ScdVersion
							)
		),	
	Stg_Planogram AS
		(
			SELECT  * FROM ser.planogram A
				WHERE LOVRecordSourceId = @LOVRecordSourceId
				AND LOVSourceKeyTypeId = @LOVSourceKeyTypeId
				AND NOT EXISTS	(
									SELECT 1 FROM ser.planogram B
										WHERE A.PlanogramId = B.PlanogramId
										AND A.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
										AND A.LOVRecordSourceId = B.LOVRecordSourceId
										AND A.ScdVersion > B.ScdVersion
								)
		),
		Stg_mx_crp_merchandise AS
		(
			SELECT 
				A.[sourcekey]
				,A.[date_added]
				,A.[LOVRecordSourceId]
				,A.[PSARowKey]
				,A.[ColumnValue]
				,A.[ColumnName]  
				,A.[columnId]
				,B.[LOVID]
			FROM 
			(
			    SELECT 
					[sourceKey]
					,[date_added]
					,[LOVRecordSourceId]
					,[PSARowKey]
					,[ColumnValue]
					,[ColumnName]
					,CASE
						WHEN ColumnName ='fitting_type' THEN @fittingTypeLOVSetID
						WHEN ColumnName ='planner_family' THEN @plannerFamilyLOVSetID
						WHEN ColumnName ='footprint' THEN @footprintLOVSetID
						WHEN ColumnName ='category' THEN @categoryLOVSetID
						WHEN ColumnName ='format' THEN @formatLOVSetID
						ELSE NULL
					END AS [columnId]
				FROM
				(
					SELECT * FROM [psa].[mx_crp_merchandise_tmptable] A
						WHERE [row_status]=@rowStatusPSACode 
						AND lovsourcekeytypeid=@LOVSourceKeyTypeId
						AND [date_added]=@dateAdded
				) A
				UNPIVOT
				(
					[ColumnValue] for [ColumnName] in ([fitting_type],[planner_family],[footprint], [category], [format])
				) as U
			) A
			JOIN [ser].[reflovsetinfo] B
				on B.LOVSetId = A.columnId
				AND A.ColumnValue=B.LovName
			WHERE A.ColumnValue IS NOT NULL AND A.ColumnValue <> ''
		)
		INSERT INTO [ser].[planogramgroup]
		(
			[PlanogramGroupId]
			,[PlanogramId]
			,[LOVPlanogramGroupSetId]
			,[LOVGroupId]
			,[ParentPlanogramGroupId]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT 
				[PlanogramGroupId]
				,[PlanogramId]
				,[LOVPlanogramGroupSetId]
				,[LOVGroupId]
				,[ParentPlanogramGroupId]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,[SCDEndDate]
				,[SCDActiveFlag]
				,[SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey] 
			FROM 
			(
				SELECT 
					ISNULL(PlanogramGroupId,@max_PlanogramGroupId + (dense_rank() over (order by PlanogramId,LOVGroupId asc))) as [PlanogramGroupId]
					,[PlanogramId]
					,[LOVPlanogramGroupSetId]
					,[LOVGroupId]
					,[ParentPlanogramGroupId]
					,[LOVRecordSourceId]
					,date_added AS [date_added]
					,CASE WHEN ((ISNULL([SCDVersion],0)+ROW_NUMBER() OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC)) = 1)
												THEN @scdDefaultStartDate
												ELSE @SCDStartDate
												END 
					[SCDStartDate]
					,LEAD (SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) [SCDEndDate]
					,LEAD('N', 1, 'Y') OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) AS [SCDActiveFlag]
					,ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) AS [SCDVersion]
					,[SCDLOVRecordSourceId]
					,[ETLRunLogId]
					,[PSARowKey] 
					
					
				FROM
				(
					SELECT 
						C.PlanogramGroupId as 		[PlanogramGroupId]
						,B.PlanogramID as			[PlanogramId]
						,A.ColumnID AS				[LOVPlanogramGroupSetId]
						,A.LOVId AS					[LOVGroupId]
						,NULL AS					[ParentPlanogramGroupId]
						,A.date_added AS 			[date_added]
						,@scdDefaultEndDate [SCDEndDate]
						,@LOVRecordSourceId AS		[LOVRecordSourceId]
						,@LOVRecordSourceId AS		[SCDLOVRecordSourceId]
						,@serveETLRunLogID AS		[ETLRunLogId]
						,A.PSARowKey as				[PSARowKey]
						,C.SCDVersion as [SCDVersion]
						,row_number() over (partition by C.PlanogramGroupId,B.PlanogramID,A.ColumnID,A.LOVId,A.date_added order by A.PSARowKey) as r
					FROM Stg_mx_crp_merchandise A
					JOIN Stg_Planogram B
						ON A.sourceKey = B.SourceKey
						and A.LOVRecordSourceId = B.LOVRecordSourceId
						AND B.LOVSourceKeyTypeId = @LOVSourceKeyTypeId
					left JOIN Stg_Planogram_Group C
						ON B.PlanogramId = C.PlanogramId
						AND A.LOVId=C.LOVGroupId
					
				) temp
				where r = 1
			) A
			WHERE  A.[date_added] = @dateAdded
			AND NOT EXISTS (
								SELECT 1 FROM [ser].[planogramgroup] B
									WHERE A.PlanogramId = B.PlanogramId
									AND A.LOVPlanogramGroupSetId = B.LOVPlanogramGroupSetId
									AND A.LOVRecordSourceId = B.LOVRecordSourceId
									AND A.LOVGroupId = B.LOVGroupId
									AND  B.SCDActiveFlag =@SCDActiveFlag
							)
		)
		
			PRINT 'Info: Data Loaded IN [ser].[planogramgroup] FOR Date : '+@dateAdded+'';
		
		
		
		UPDATE [ser].[planogramgroup] 
			SET SCDActiveFlag= 'N'
				,SCDEndDate = @SCDEndDate
		FROM [ser].[planogramgroup] A
		JOIN 
			(
				SELECT 
					LOVRecordSourceId
					,PlanogramGroupId
					,PlanogramId
					,LOVPlanogramGroupSetId
					,LOVGroupId
					,SCDActiveFlag		
					,SCDVersion
				FROM [ser].[planogramgroup] B
				WHERE B.LOVRecordSourceId = @LOVRecordSourceId
				AND B.SCDActiveFlag=@SCDActiveFlag
				AND NOT EXISTS	(
									SELECT 1 FROM [ser].[planogramgroup] C
									WHERE C.PlanogramId = B.PlanogramId
									AND C.LOVRecordSourceId = B.LOVRecordSourceId
									AND C.LOVGroupId = B.LOVGroupId
									AND C.SCDVersion > B.SCDVersion
								)
			) D ON A.PlanogramId = D.PlanogramId
				AND A.LOVRecordSourceId = D.LOVRecordSourceId
				AND A.LOVGroupId = D.LOVGroupId				
				AND A.SCDActiveFlag = D.SCDActiveFlag
				AND A.SCDVersion != D.SCDVersion
		WHERE A.SCDActiveFlag = @SCDActiveFlag
		AND A.SCDEndDate = @scdDefaultEndDate
	
		PRINT 'Info: Closing the active record when there is an incremental data for the existing Business Key -- finished';			
PRINT 'Info: second update started';
		
		 -- Close the records if Planogram records are closed due to NULL values 

    UPDATE ser.PlanogramGroup SET SCDActiveFlag= 'N', SCDEndDate = @SCDEndDate
					FROM ser.PlanogramGroup pg
					JOIN ser.Planogram p
					ON pg.PlanogramId = p.PlanogramId
					AND pg.LOVRecordSourceId = p.LOVRecordSourceId
					JOIN psa.mx_crp_merchandise_tmptable src
					ON p.SourceKey = src.sourceKey
					WHERE NULLIF(src.pog_description,'' ) IS NULL
						AND NULLIF(src.planogram_start_date,'' ) IS NULL
						AND NULLIF(src.planogram_end_date,'') IS NULL 
						AND pg.SCDActiveFlag = 'Y' 
						AND p.LOVRecordSourceId = @LOVRecordSourceId
						AND p.LOVSourceKeyTypeId = @LOVSourceKeyTypeId
						AND src.date_added = @dateAdded;
						
					
						
	-- Close the corresponding record if any of fitting_type, planner_family,footprint,category and format is NULL 

 						
	UPDATE ser.PlanogramGroup SET SCDActiveFlag= 'N', SCDEndDate = @SCDEndDate
	    FROM ser.PlanogramGroup tgt
	    JOIN 
	    (SELECT 
		     p.[PlanogramId] as PlanogramId
			,lkp_refl.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS LOVGroupId
			FROM 
		    (
			SELECT 
			SourceKey
			,PSARowKey
			,ColumnValue
			,ColumnName
			FROM 
			(SELECT
			 [SourceKey]
			,[PSARowKey]
			,ISNULL(fitting_type,'') as fitting_type
			,ISNULL(planner_family,'') as planner_family
			,ISNULL(footprint,'') as footprint
			,ISNULL(category,'') as category
			,ISNULL(format,'') as format
			FROM psa.mx_crp_merchandise_tmptable
			where date_added = @dateAdded )s
			UNPIVOT
			([ColumnValue] for [ColumnName] in ([fitting_type],[planner_family],[footprint], [category], [format])) as U 
			)src
			JOIN 
			(select * from ser.Planogram where lovrecordsourceid = @LOVRecordSourceId and lovsourcekeytypeid = @LOVSourceKeyTypeId and SCDActiveFlag = 'Y' ) p
			ON src.SourceKey = p.SourceKey
			LEFT OUTER JOIN
			(select LOVId,trim(LOVKey) as LOVKey,LOVSetID,LOVsetName from [ser].[reflovsetinfo] where LOVRecordSourceId = @LOVRecordSourceId) lkp_refl
			ON lkp_refl.LOVsetName = src.ColumnName		
			WHERE NULLIF(src.ColumnValue,'') IS NULL 
		    )src
			ON 	tgt.PlanogramId = src.PlanogramId
            AND tgt.LOVPlanogramGroupSetId = src.LOVPlanogramGroupSetId
			AND tgt.LOVGroupId = src.LOVGroupId
        WHERE tgt.SCDActiveFlag = 'Y' and tgt.lovrecordsourceid = @LOVRecordSourceId;
			
		
			
			PRINT 'Info: Updated  SCDVersion IN [ser].[planogramgroup] FOR Date : '+@dateAdded+'';
			
			
			
		
		/**
			TABLE 03	: [ser].[PlanogramIndicator]
		*/
	
		PRINT 'Info: Processing [ser].[PlanogramIndicator] FOR Date : '+@dateAdded+'';
		WITH Stg_PlanogramIndicator AS
		(
			SELECT * FROM [ser].[PlanogramIndicator] A
				WHERE LOVRecordSourceId = @LOVRecordSourceId
				AND LovIndicatorId = @indicatorLOVID
				AND NOT EXISTS	(
									SELECT 1 FROM [ser].[PlanogramIndicator] B
										WHERE A.PlanogramId = B.PlanogramId
										AND A.LovIndicatorId = B.LovIndicatorId
										AND A.LOVRecordSourceId = B.LOVRecordSourceId
										AND  B.ScdVersion > A.ScdVersion
								)
		
		),
		Stg_Planogram AS
		(
			SELECT * FROM ser.planogram A
				WHERE LOVRecordSourceId = @LOVRecordSourceId
				AND LOVSourceKeyTypeId = @LOVSourceKeyTypeId
				AND NOT EXISTS	(
									SELECT 1 FROM ser.planogram B
										WHERE A.PlanogramId = B.PlanogramId
										AND A.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
										AND A.LOVRecordSourceId = B.LOVRecordSourceId
										AND A.ScdVersion > B.ScdVersion
								)
		),
		Stg_mx_crp_merchandise AS
		(
			SELECT * FROM [psa].[mx_crp_merchandise_tmptable] A
				WHERE [row_status]=@rowStatusPSACode 
				AND lovsourcekeytypeid=@lovsourceKeyTypeID
				AND [date_added]=@dateAdded
		)
		
		INSERT INTO [ser].[PlanogramIndicator]
		(	[PlanogramId]
			,[LovIndicatorId]
			,[Value]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT 
			[PlanogramId]
			,[LovIndicatorId]
			,[Value]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey] 
			FROM 
			(
				SELECT 
					[PlanogramId]
					,[LovIndicatorId]
					,[Value]
					,[LOVRecordSourceId]
					,[date_added]
					,CASE WHEN ((ISNULL([SCDVersion],0)+ROW_NUMBER() OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC)) = 1)
												THEN @scdDefaultStartDate
												ELSE @SCDStartDate
												END [SCDStartDate]
					,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC) [SCDEndDate]
					,LEAD('N', 1, 'Y') OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC) AS [SCDActiveFlag]
					,ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC) AS [SCDVersion]
					,[SCDLOVRecordSourceId]
					,[ETLRunLogId]
					,[PSARowKey]
				FROM 
				(		
					SELECT 
						B.PlanogramId AS [PlanogramId]
						,@indicatorLOVID AS [LovIndicatorId]
						,A.promotional_site AS [Value]
						,@LOVRecordSourceId AS [LOVRecordSourceId]
						,A.date_added AS [date_added]
						,@scdDefaultEndDate [SCDEndDate]												
						,@LOVRecordSourceId [SCDLOVRecordSourceId]
						,@serveETLRunLogID AS [ETLRunLogId]
						,A.PSARowKey AS [PSARowKey]
						,C.SCDVersion AS [SCDVersion]
						,row_number() over (partition by B.PlanogramId,A.promotional_site order by A.PSARowKey ) as r
					FROM Stg_mx_crp_merchandise A
					JOIN Stg_Planogram B
						ON A.SourceKey = B.SourceKey
						AND A.LOVRecordSourceId = B.LOVRecordSourceId
						AND B.LOVSourceKeyTypeId = @LOVSourceKeyTypeId
						AND A.promotional_site IS NOT NULL AND A.promotional_site <> ''
					LEFT JOIN Stg_PlanogramIndicator C
						ON B.PlanogramId = C.PlanogramId
				) temp
				where r = 1
			) A
			WHERE  A.[date_added] = @dateAdded
			AND NOT EXISTS (
								SELECT 1 FROM [ser].[PlanogramIndicator] B
									WHERE A.PlanogramId = B.PlanogramId
									AND A.LovIndicatorId = B.LovIndicatorId
									AND A.LOVRecordSourceId = B.LOVRecordSourceId
									AND A.Value = B.Value
									AND  B.SCDActiveFlag =@SCDActiveFlag
							)
		)
		
		PRINT 'Info: Data Loaded IN [ser].[PlanogramIndicator] FOR Date : '+@dateAdded+'';
		
		UPDATE [ser].[PlanogramIndicator] 
			SET SCDActiveFlag= 'N'
				,SCDEndDate = @SCDEndDate
		FROM [ser].[PlanogramIndicator] A
		JOIN 
			(
				SELECT 
					LOVRecordSourceId
					,PlanogramId
					,LovIndicatorId
					,SCDActiveFlag		
					,SCDVersion
				FROM [ser].[PlanogramIndicator] B
				WHERE B.LOVRecordSourceId = @LOVRecordSourceId
				AND B.SCDActiveFlag=@SCDActiveFlag
				AND NOT EXISTS	(
									SELECT 1 FROM [ser].[PlanogramIndicator] C
									WHERE C.PlanogramId = B.PlanogramId
									AND C.LOVRecordSourceId = B.LOVRecordSourceId
									AND C.LovIndicatorId = B.LovIndicatorId
									AND C.SCDVersion > B.SCDVersion
								)
			) D ON A.PlanogramId = D.PlanogramId
				AND A.LOVRecordSourceId = D.LOVRecordSourceId
				AND A.LovIndicatorId = D.LovIndicatorId
				AND A.SCDActiveFlag = D.SCDActiveFlag
				AND A.SCDVersion != D.SCDVersion
		WHERE A.SCDActiveFlag = @SCDActiveFlag
		AND A.SCDEndDate = @scdDefaultEndDate
				
				
				
		UPDATE [ser].[PlanogramIndicator] 
			SET SCDActiveFlag= 'N'
				,SCDEndDate = @SCDEndDate
		FROM [ser].[PlanogramIndicator] A
		JOIN 
			(
				SELECT 
					PlanogramId
					,SourceKey
					,LOVSourceKeyTypeId
					,LOVRecordSourceId
					,SCDVersion
					,SCDActiveFlag
				FROM ser.planogram B
				WHERE B.LOVRecordSourceId=@LOVRecordSourceId
				AND NOT EXISTS	(
									SELECT 1 FROM ser.planogram C
									WHERE C.PlanogramId = B.PlanogramId
									AND C.LOVRecordSourceId = B.LOVRecordSourceId
									AND C.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
									AND C.SCDVersion > B.SCDVersion
								)
			) D 
		ON A.PlanogramId = D.PlanogramId
				AND A.LovRecordSourceId = D.LovRecordSourceId
			JOIN psa.mx_crp_merchandise_tmptable E
				ON E.LovRecordSourceId = D.LovRecordSourceId
				AND D.SourceKey = E.SourceKey
				AND D.LOVSourceKeyTypeId=@LOVSourceKeyTypeId
			WHERE	( NULLIF(E.promotional_site,'' ) IS NULL OR D.SCDActiveFlag='N') 
			AND A.SCDActiveFlag=@SCDActiveFlag
			AND E.row_status=@rowStatusPSACode
			AND e.date_added = @dateAdded
			
		PRINT 'Info: Updated  SCDVersion IN [ser].[PlanogramIndicator] FOR Date : '+@dateAdded+'';
		
		
		
		/**
			TABLE 04	: [ser].[PlanogramProperty]
		*/
		PRINT 'Info: Processing [ser].[PlanogramProperty] FOR Date : '+@dateAdded+'';
		WITH Stg_PlanogramProperty AS
		(
			SELECT * FROM [ser].[PlanogramProperty] A
				WHERE LOVRecordSourceId = @LOVRecordSourceId
				AND LOVUOMId IN (@LOVIdUnitCM, @LOVIdUnitUnKnown)
				AND NOT EXISTS	(
									SELECT 1 FROM [ser].[PlanogramProperty] B
										WHERE A.PlanogramId = B.PlanogramId
										AND A.LOVUOMId = B.LOVUOMId
										AND A.MeasureId = B.MeasureId
										AND A.LOVRecordSourceId = B.LOVRecordSourceId
										AND  B.ScdVersion > A.ScdVersion
								)
		
		),
		Stg_Planogram AS
		(
			SELECT * FROM ser.planogram A
				WHERE LOVRecordSourceId = @LOVRecordSourceId
				AND LOVSourceKeyTypeId = @LOVSourceKeyTypeId
				AND NOT EXISTS	(
									SELECT 1 FROM ser.planogram B
										WHERE A.PlanogramId = B.PlanogramId
										AND A.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
										AND A.LOVRecordSourceId = B.LOVRecordSourceId
										AND A.ScdVersion > B.ScdVersion
								)
		),
		Stg_mx_crp_merchandise AS
		(
			SELECT 
				[Sourcekey]
				,[date_added]
				,LOVRecordSourceId
				,[PSARowKey]
				,[ColumnValue]
				,[ColumnName]  
				,[MeasureId]
				,[LOVUOMId]
			FROM
			(
				SELECT 
					[Sourcekey]
					,[date_added]
					,LOVRecordSourceId
					,[PSARowKey]
					,[ColumnValue]
					,[ColumnName]  
					,CASE
						WHEN ColumnName ='shelf_depth' THEN @shelfDepthMeasureID
						WHEN ColumnName ='height' THEN @heightMeasureID
						WHEN ColumnName ='build_size' THEN @buildSizeMeasureID
					END AS [MeasureId]
					,CASE
						WHEN ColumnName ='shelf_depth' THEN @LOVIdUnitCM
						WHEN ColumnName ='height' THEN @LOVIdUnitCM
						WHEN ColumnName ='build_size' THEN @LOVIdUnitUnKnown					
					END AS [LOVUOMId]
				FROM
				(
					SELECT * FROM [psa].[mx_crp_merchandise_tmptable] A
						WHERE [row_status]=@rowStatusPSACode 
						AND lovsourcekeytypeid=@lovsourcekeytypeid 
						AND [date_added]=@dateAdded
				) A
				UNPIVOT
				(
					[ColumnValue] FOR [ColumnName] IN ([shelf_depth],[height],[build_size]	
				)
				) AS U
			) T
			WHERE ColumnValue IS NOT NULL AND ColumnValue <> ''
			
		)

		
		INSERT INTO [ser].[PlanogramProperty]
		(
			[PlanogramId]
			,[MeasureId]
			,[LOVUOMId]
			,[Value]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT 
				[PlanogramId]
				,[MeasureId]
				,[LOVUOMId]
				,[Value]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,[SCDEndDate]
				,[SCDActiveFlag]
				,[SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			FROM
			(
				SELECT
					[PlanogramId]
					,[MeasureId]
					,[LOVUOMId]
					,[Value]
					,[LOVRecordSourceId]
					,[date_added]
					,CASE WHEN ((ISNULL([SCDVersion],0)+ROW_NUMBER() OVER(PARTITION BY [PlanogramId],[MeasureId] ORDER BY [date_added] ASC)) = 1)
														THEN @scdDefaultStartDate
														ELSE @SCDStartDate
														END 
							[SCDStartDate]
					,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [date_added] ASC) AS [SCDEndDate]
					,LEAD('N',1,'Y') OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [date_added] ASC) AS [SCDActiveFlag]
					,ISNULL(SCDVersion,0)+ROW_NUMBER() OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [date_added] ASC) AS [SCDVersion]
					,[SCDLOVRecordSourceId]
					,[ETLRunLogId]
					,[PSARowKey]
				FROM
				(
					SELECT 
						B.PlanogramId AS [PlanogramId]
						,A.MeasureId AS [MeasureId]
						,A.LOVUOMId AS [LOVUOMId]
						,A.ColumnValue AS [Value]
						,@LOVRecordSourceId AS [LOVRecordSourceId]
						,A.date_added AS [date_added]
						,@scdDefaultEndDate [SCDEndDate]
						,@LOVRecordSourceId AS [SCDLOVRecordSourceId]
						,@serveETLRunLogID AS [ETLRunLogId]
						,A.PSARowKey AS [PSARowKey]
						,C.SCDVersion AS [SCDVersion]
						,row_number() over (partition by B.PlanogramId,A.MeasureId,A.LOVUOMId,A.ColumnName,A.ColumnValue order by A.PSARowKey) as r
					FROM Stg_mx_crp_merchandise A
					JOIN Stg_Planogram B
						ON A.SourceKey = B.SourceKey
						AND A.LOVRecordSourceID = B.LOVRecordSourceId
						AND B.LOVSourceKeyTypeId = @LOVSourceKeyTypeId
					LEFT JOIN Stg_PlanogramProperty C
						ON B.PlanogramId = C.PlanogramId
						AND C.MeasureId = A.MeasureId
						AND C.LOVUOMId = A.LOVUOMId
				) temp
				where r = 1
			)  A
			WHERE  A.[date_added] = @dateAdded
			AND NOT EXISTS (
								SELECT 1 FROM [ser].[PlanogramProperty] B
									WHERE A.PlanogramId = B.PlanogramId
									AND A.MeasureId = B.MeasureId
									AND A.LOVUOMId = B.LOVUOMId
									AND A.LOVRecordSourceId = B.LOVRecordSourceId
									AND A.Value = B.Value
									AND  B.SCDActiveFlag =@SCDActiveFlag
							)
		)
		
		PRINT 'Info: Data Loaded IN [ser].[PlanogramProperty] FOR Date : '+@dateAdded+'';
		
		--UPDATE row_status
		
		UPDATE [ser].[PlanogramProperty] 
			SET SCDActiveFlag= 'N'
				,SCDEndDate = @SCDEndDate
		FROM [ser].[PlanogramProperty] A
		JOIN 
			(
				SELECT 
					LOVRecordSourceId
					,PlanogramId
					,MeasureId
					,LOVUOMId
					,SCDActiveFlag		
					,SCDVersion
				FROM [ser].[PlanogramProperty] B
				WHERE B.LOVRecordSourceId = @LOVRecordSourceId
				AND B.SCDActiveFlag=@SCDActiveFlag
				AND NOT EXISTS	(
									SELECT 1 FROM [ser].[PlanogramProperty] C
									WHERE C.PlanogramId = B.PlanogramId
									AND C.LOVRecordSourceId = B.LOVRecordSourceId
									AND C.MeasureId = B.MeasureId
									AND C.LOVUOMId = B.LOVUOMId
									AND C.SCDVersion > B.SCDVersion
								)
			) D ON A.PlanogramId = D.PlanogramId
				AND A.LOVRecordSourceId = D.LOVRecordSourceId
				AND A.MeasureId = D.MeasureId
				AND A.LOVUOMId = D.LOVUOMId
				AND A.SCDActiveFlag = D.SCDActiveFlag
				AND A.SCDVersion != D.SCDVersion
		WHERE A.SCDActiveFlag = @SCDActiveFlag
		AND A.SCDEndDate = @scdDefaultEndDate
		
		
PRINT 'Info: Closing the active record when there is an incremetal data for the existing Business Key -- finished';	
		
		UPDATE [ser].[PlanogramProperty] 
			SET SCDActiveFlag= 'N'
				,SCDEndDate = @SCDEndDate
		FROM [ser].[PlanogramProperty] A
		JOIN 
		(
			SELECT 
				PlanogramId
				,SourceKey
				,LOVSourceKeyTypeId
				,LOVRecordSourceId
				,SCDVersion
				,SCDActiveFlag
			FROM ser.planogram B
			WHERE B.LOVRecordSourceId=@LOVRecordSourceId
			AND NOT EXISTS	(
								SELECT 1 FROM ser.planogram C
								WHERE C.PlanogramId = B.PlanogramId
								AND C.LOVRecordSourceId = B.LOVRecordSourceId
								AND C.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
								AND C.SCDVersion > B.SCDVersion
							)
		) D 
		ON A.PlanogramId = D.PlanogramId
			AND A.LovRecordSourceId = D.LovRecordSourceId
		JOIN 
			(SELECT	distinct 		E.PlanogramId  PlanogramId,
									@shelfDepthMeasureID MeasureId,
									@LOVIdUnitCM LOVUOMId,
									E.shelf_depth Value,
									E.LOVRecordSourceId  LOVRecordSourceId,
									E.row_status row_status,
									E.etl_runlog_id etl_runlog_id,
									E.date_added date_added
					FROM psa.mx_crp_merchandise_tmptable E
					WHERE  date_added =@dateAdded
			union
			
			SELECT	distinct 		E.PlanogramId  PlanogramId,
									@buildSizeMeasureID MeasureId,
									@LOVIdUnitUnKnown LOVUOMId,
									E.build_size Value,
									E.LOVRecordSourceId LOVRecordSourceId,
									E.row_status row_status,
									E.etl_runlog_id etl_runlog_id,
									E.date_added date_added
					FROM psa.mx_crp_merchandise_tmptable E
					WHERE  date_added =@dateAdded
					
			UNION
			
			SELECT	distinct 		E.PlanogramId  PlanogramId,
									@heightMeasureID MeasureId,
									@LOVIdUnitCM LOVUOMId,
									E.height Value,
									E.LOVRecordSourceId LOVRecordSourceId,
									E.row_status row_status,
									E.etl_runlog_id etl_runlog_id,
									E.date_added date_added
					FROM psa.mx_crp_merchandise_tmptable E
					WHERE  date_added =@dateAdded
					
			) F	
		ON F.LovRecordSourceId	 = D.LovRecordSourceId
		AND D.PlanogramID 		 = F.PlanogramID
		AND D.LOVSourceKeyTypeId = @LOVSourceKeyTypeId
		WHERE	( NULLIF(F.value,'' ) IS NULL OR D.SCDActiveFlag='N')
		AND A.MeasureID = F.MeasureID
        AND A.LOVUOMId = F.LOVUOMId		
		AND A.SCDActiveFlag=@SCDActiveFlag;
			
		
		PRINT 'Info: Updated  SCDVersion IN [ser].[PlanogramProperty] FOR Date : '+@dateAdded+''; 
			
			--UPDATE row_status



UPDATE psa.mx_crp_merchandise
  SET Row_Status=@rowStatusSERCode
	FROM psa.mx_crp_merchandise A
INNER JOIN
((SELECT distinct psarowkey FROM ser.planogram WHERE  LOVRecordsourceID=@lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) 
UNION ALL  (SELECT distinct psarowkey FROM ser.PlanogramGroup WHERE LOVRecordsourceID=@lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID)                                                                                                                                                 
UNION ALL  (SELECT distinct psarowkey FROM ser.PlanogramProperty  WHERE  LOVRecordsourceID=@lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID)                                                                                                                                                      
UNION ALL  (SELECT distinct psarowkey FROM ser.PlanogramIndicator  WHERE  LOVRecordsourceID=@lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID)
            ) temp
                            ON   temp.psarowkey=A.row_id
WHERE A.Row_Status=@rowStatusPSACode
                AND A.date_added=@dateAdded ;
				
UPDATE psa.mx_crp_merchandise SET Row_Status=@rowStatusSERCode
FROM psa.mx_crp_merchandise 
WHERE Row_Status=@rowStatusPSACode   
            AND date_added=@dateAdded
            AND (
			( NULLIF(pog_description,'' ) IS NULL AND 
			  NULLIF( planogram_start_date,'' ) IS NULL AND 
			  NULLIF( planogram_end_date,'') IS NULL ) 
                OR 
			( NULLIF(fitting_type,'') IS NULL OR 
			  NULLIF(planner_family,'') IS NULL OR 
			  NULLIF(footprint,'') IS NULL OR 
			  NULLIF(category,'') IS NULL  OR  
			  NULLIF(format,'') IS NULL OR 
			  NULLIF(promotional_site ,'') IS NULL OR 
			  NULLIF( shelf_depth,'') IS NULL OR 
			  NULLIF(height ,'') IS NULL OR 
			  NULLIF(build_size,'') IS NULL ));

UPDATE psa.mx_crp_merchandise  SET row_status=@rowStatusNotmigratedCode                                                                                         
WHERE row_status=@rowStatusPSACode
                AND date_added=@dateAdded;

 
			SET @COUNTER = @COUNTER + 1;
		END
		
			COMMIT TRANSACTION;
		END TRY
		BEGIN CATCH
			THROW;
			ROLLBACK TRANSACTION ;
		END CATCH

END
GO
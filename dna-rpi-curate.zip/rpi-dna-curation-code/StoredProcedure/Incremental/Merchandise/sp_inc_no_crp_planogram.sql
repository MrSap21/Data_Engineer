SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[psa].[sp_inc_no_crp_planogram]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_no_crp_planogram] 
END
GO

CREATE PROC [psa].[sp_inc_no_crp_planogram] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max) AS

BEGIN

	DECLARE @rowStatusPSACode BIGINT
	DECLARE	@rowStatusSERCode BIGINT
	DECLARE	@rowStatusNotmigratedCode BIGINT
	DECLARE @max_FactInstanceId BIGINT
	DECLARE @LOVRecordSourceId BIGINT
	DECLARE @RecordSourceIdMerchandise BIGINT
	DECLARE @crpPlanogramFactId BIGINT
	DECLARE @SCDLOVRecordSourceId BIGINT
	DECLARE @pogIdTypeId BIGINT
	DECLARE @planogramDimId BIGINT
	DECLARE @productDimensionId BIGINT
	DECLARE @weekDimentionId BIGINT
	DECLARE @planoAggregation BIGINT
	DECLARE @measureId BIGINT
	DECLARE @SCDVersion SMALLINT
	DECLARE @SCDActiveFlag CHAR
	
	SET @rowStatusPSACode = 26001
	SET @rowStatusSERCode = 26002
	SET @rowStatusNotmigratedCode = 26010
	SET @LOVRecordSourceId = 12005
	SET @RecordSourceIdMerchandise = 12012
	SET @SCDLOVRecordSourceId = 12005
	SET @SCDVersion = 1
	SET @SCDActiveFlag  = 'Y'
	
	SET @pogIdTypeId = 			(SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
									LOVsetName='Source Key Type' 			-- LOVsetName='Source Key Type'
									and LOVKey = 'Norway Planogram Id(pog_id)' 	-- LOVKey = 'Norway Planogram Id(pog_id)'
									and LOVRecordSourceId = @RecordSourceIdMerchandise)		-- Record Source ID = 12012
	
	SET @crpPlanogramFactId = 	(SELECT FactId FROM [ser].[fact] where
									FactName = 'CRP Planogram'
									AND LOVRecordSourceId = @LOVRecordSourceId
									AND LOVFactTypeId = (
															SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
																LOVSetName= 'Fact Type'
																and LOVRecordSourceId=@RecordSourceIdMerchandise
																and LOVKey='TBC'
														)
								)
								
	SET @planogramDimId =		(	SELECT DimensionId FROM [ser].[dimension]
										where name =  'Planogram' 
										AND  LOVRecordSourceId = @LOVRecordSourceId
								)
								
	SET @productDimensionId = 	(	SELECT DimensionId FROM [ser].[dimension]
										where name =  'Product' 
										AND  LOVRecordSourceId = @LOVRecordSourceId
								)
								
	SET @weekDimentionId = 		(	SELECT DimensionId FROM [ser].[dimension]
										where name =  'Week' 
										AND  LOVRecordSourceId = @LOVRecordSourceId
								)
								
	SET @planoAggregation = 	(	select LOVId from [ser].[reflovsetinfo] where 
										LOVSetName= 'Measure Type'
										and LOVRecordSourceId=@RecordSourceIdMerchandise
										and LOVKey='PLANOGRAM_AGGREGATION'
								)
	
	SET @measureId = 			(	select MeasureId from [ser].[measure] where measureName = 'facings'
										AND LOVRecordSourceId = @LOVRecordSourceId
										AND SCDActiveFLag = 'Y'
										AND  LOVMeasureTypeId = @planoAggregation 
								)
								
	/*
		Update rowstatus for entries < currentDate
	*/
	
	UPDATE [psa].[no_crp_planogram]     
		SET row_status= @rowStatusNotmigratedCode
    WHERE row_id in
                    (SELECT
						A.row_id
                     FROM [psa].[no_crp_planogram] A
                     JOIN 
						(	SELECT distinct 
								pog_id
								,record_source_id
								,max(date_added) as date_added 
							FROM [psa].[no_crp_planogram]
							WHERE row_status = @rowStatusSERCode
							GROUP BY pog_id,record_source_id
						) B
                     ON  A.pog_id=B.pog_id 
					 and A.record_source_id = B.record_source_id
                     AND A.date_added<=B.date_added
                     AND A.row_status = @rowStatusPSACode);

	IF OBJECT_ID('tempdb..#no_crp_planogram_temp') is not null
	BEGIN
		DROP TABLE #no_crp_planogram_temp
	END
	
	IF OBJECT_ID('tempdb..#no_crp_planogram_join') is not null
	BEGIN
		DROP TABLE #no_crp_planogram_join
	END
	
	PRINT 'Info: Drop tempTable if exists ';
	
	/*
		Load Data to NO_PLANOGRAM_DATE_TABLE
	*/
	SELECT @max_FactInstanceId = COALESCE(MAX(FactInstanceId),0) FROM [ser].[FactInstance];
	
	SELECT
		*
	INTO #no_crp_planogram_temp
	FROM 
	(
		SELECT 
			FactInstanceId
			,pog_id
			,row_id
			,item_code
			,week
			,facings
			,date_added
		FROM 
		(
			SELECT
				@max_FactInstanceId + (ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS FactInstanceId
				,pog_id
				,row_id 
				,item_code
				,week
				,facings
				,date_added
			FROM [psa].[no_crp_planogram] 
			WHERE [row_status]=@rowStatusPSACode
		) C
	) A
	
	
	SELECT
		*
	INTO #no_crp_planogram_join
	FROM 
	(
		SELECT 
			(ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS RowNumber
			,A.FactInstanceId
			,A.pog_id
			,A.row_id 
			,A.item_code
			,A.week
			,A.facings
			,A.date_added
			,B.PlanogramId
		FROM 
		(
			SELECT
				FactInstanceId
				,pog_id
				,row_id 
				,item_code
				,week
				,facings
				,date_added
			FROM #no_crp_planogram_temp
		) A
		LEFT OUTER JOIN 
		(
			SELECT * FROM [ser].[Planogram] 
				WHERE SCDActiveFlag='Y' 
				AND Lovrecordsourceid=@LOVRecordSourceId 
				AND lovsourcekeytypeid = @pogIdTypeId
				-- AND scdlovrecordsourceid = @LOVRecordSourceId
		) B 
		ON A.pog_id=B.SourceKey
	) A
	
	PRINT('Loaded temp Tables')
	
	/*
		Start Transaction and populate data
	*/
	BEGIN TRANSACTION;
	BEGIN TRY
	
		/*
			TABLE 01	: [ser].[FactInstance]
		*/
		
		PRINT 'Info: Processing [ser].[FactInstance] ';
		
		/*
			Insert Data into [ser].[FactInstance] TABLE
		*/
		INSERT INTO [ser].[FactInstance]
		(
			[FactInstanceId]
			,[FactId]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT
				FactInstanceId AS			[FactInstanceId]
				,@crpPlanogramFactId AS		[FactId]
				,@LOVRecordSourceId AS		[LOVRecordSourceId]
				,'1900-01-01 00:00:00' AS 	[SCDStartDate]
				,'9999-12-31 00:00:00' AS 	[SCDEndDate]
				,@SCDActiveFlag AS 			[SCDActiveFlag]
				,@SCDVersion AS 			[SCDVersion]
				,@SCDLOVRecordSourceId AS	[SCDLOVRecordSourceId]
				,@serveETLRunLogID as		[ETLRunLogId]
				,row_id AS 				[PSARowKey]
			FROM #no_crp_planogram_temp 
		)
		
		/*
			TABLE 02	: [ser].[FactDimensionInstance]
		*/
		
		PRINT 'Info: Updating FactDimensionInstance for existing DimensionSurrogateKey NULL records';	
		
		UPDATE [ser].[FactDimensionInstance]
			SET DimensionSurrogateKey = A.PlanogramId
		FROM
		[ser].[FactDimensionInstance] src
		JOIN 
		(	select 
				PlanogramId,SourceKey 
			from [ser].[Planogram] 
			where SCDActiveFlag='Y' 
			AND Lovrecordsourceid=@lovrecordSourceId 
			AND LOVSourceKeyTypeId = @pogIdTypeId 
			-- AND SCDLOVRecordSourceId = @lovrecordSourceId 
		) A
		ON src.DimensionSourceKey = A.SourceKey
		-- AND src.SCDLOVRecordSourceId = @lovrecordSourceId		
		JOIN
		(
			select 
				DimensionSourceKey,count(*) as cnt  
			from 
			(	select 
					distinct fdi.DimensionSourceKey,pl.PlanogramId 
				from [ser].[FactDimensionInstance] fdi 
				join 
				(	select 
						PlanogramId,SourceKey from [ser].[Planogram] 
					where SCDActiveFlag='Y' 
					AND Lovrecordsourceid=@lovrecordSourceId 
					AND LOVSourceKeyTypeId = @pogIdTypeId)pl 
					-- AND SCDLOVRecordSourceId = @lovrecordSourceId
				ON fdi.DimensionSourceKey = pl.SourceKey 
				-- AND fdi.SCDLOVRecordSourceId = @LOVRecordSourceId
			)C group by DimensionSourceKey having count(*)=1
		)B
		ON A.SourceKey = B.DimensionSourceKey
		where src.DimensionSurrogateKey is NULL 
		AND src.DimensionId = @planogramDimId 
		AND src.LOVRecordSourceId = @lovrecordSourceId  
		-- AND src.SCDLOVRecordSourceId = @lovrecordSourceId;	
		
		UPDATE [ser].[FactDimensionInstance]
			SET DimensionSurrogateKey = B.ProductId
		FROM
		[ser].[FactDimensionInstance] A
		JOIN 
		(	select * from [ser].[product] 
			where SCDActiveFlag = 'Y' 
			AND LOVRecordSourceId = @lovrecordsourceid 
			-- AND SCDLOVRecordSourceId = @lovrecordSourceId  
		) B
		ON B.SourceKey = A.DimensionSourceKey
		AND A.LOVRecordSourceId = B.LOVRecordSourceId
		where A.DimensionSurrogateKey is NULL 
		AND A.DimensionId = @productDimensionId 
		AND A.LOVRecordSourceId = @lovrecordsourceid  
		-- AND A.SCDLOVRecordSourceId = @lovrecordSourceId;
		
		PRINT 'Info: Existing DimensionSurrogateKey NULL update completed ';
		
		PRINT 'Info: Processing [ser].[FactDimensionInstance]';
		
		INSERT INTO [ser].[FactDimensionInstance]
		(
			[FactInstanceId]
			,[DimensionId]
			,[DimensionSurrogateKey]
			,[DimensionSourceKey]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT
				[FactInstanceId]
				,[DimensionId]
				,[DimensionSurrogateKey]
				,[DimensionSourceKey]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
				,@SCDActiveFlag AS [SCDActiveFlag]
				,@SCDVersion AS [SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			FROM
			(
				SELECT 
					B.FactInstanceId AS [FactInstanceId]
					,B.DimensionId AS [DimensionId]
					,B.DimensionSurrogateKey AS [DimensionSurrogateKey]
					,B.DimensionSourceKey AS [DimensionSourceKey]
					,B.LOVRecordSourceId AS [LOVRecordSourceId]
					,B.SCDStartDate AS [SCDStartDate]
					,B.SCDEndDate AS [SCDEndDate]
					,B.SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,B.ETLRunLogId AS [ETLRunLogId]
					,B.PSARowKey AS [PSARowKey] 
				FROM 
				(
					SELECT distinct
						A.RowNumber AS RowNumber
						,A.FactInstanceId AS [FactInstanceId]
						,@planogramDimId AS [DimensionId]
						,(case when
							
								(SELECT count(row_id) FROM (SELECT row_id FROM #no_crp_planogram_join WHERE row_id=A.row_id) X)=1 then A.PlanogramId else NULL end
							)
							AS [DimensionSurrogateKey]
						,cast(A.pog_id AS varchar(80)) AS [DimensionSourceKey]
						,@LOVRecordSourceId AS [LOVRecordSourceId]
						,'1900-01-01 00:00:00' AS [SCDStartDate]
						,NULL AS [SCDEndDate]
						,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
						,@serveETLRunLogID AS [ETLRunLogId]
						,A.row_id AS [PSARowKey]
					FROM #no_crp_planogram_join A
				) B
				WHERE RowNumber IN
				(
					SELECT MIN(RowNumber) FROM
					(
						SELECT  
							A.RowNumber AS [RowNumber]
							,A.row_id AS [PSARowKey]
						from  #no_crp_planogram_join A
					) X
					GROUP BY PSARowKey
				) 
				
				UNION
		
				SELECT 
					A.FactInstanceId AS [FactInstanceId]
					,@productDimensionId AS [DimensionId]
					,B.ProductId AS [DimensionSurrogateKey]
					,cast(A.item_code AS varchar(80)) AS [DimensionSourceKey]
					,@LOVRecordSourceId AS [LOVRecordSourceId]
					,'1900-01-01 00:00:00' AS [SCDStartDate]
					,NULL AS [SCDEndDate]
					,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,@serveETLRunLogID AS [ETLRunLogId]
					,A.row_id AS [PSARowKey]
				FROM #no_crp_planogram_temp A
				LEFT OUTER JOIN
					(SELECT ProductId, SourceKey FROM [ser].[product] WHERE LOVRecordSourceId=@LOVRecordSourceId AND SCDActiveFLag = 'Y') B
				ON A.item_code=B.SourceKey
				
				UNION
				
				SELECT
					A.FactInstanceId AS [FactInstanceId]
					,@weekDimentionId AS [DimensionId]
					,B.LOVId AS [DimensionSurrogateKey]
					,CAST(A.week AS varchar(80)) AS [DimensionSourceKey]
					,@LOVRecordSourceId AS [LOVRecordSourceId]
					,'1900-01-01 00:00:00' AS [SCDStartDate]
					,NULL AS [SCDEndDate]
					,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,@serveETLRunLogID AS [ETLRunLogId]
					,A.row_id AS [PSARowKey]
				FROM #no_crp_planogram_temp A
				LEFT OUTER JOIN
					(SELECT * FROM [ser].[reflovsetinfo] WHERE 
						LOVSetName= 'week'
						and LOVRecordSourceId=@LOVRecordSourceId) B
				ON A.week = B.LOVKey
			) A
		)
		
		/*
			TABLE 03	: [ser].[FactMeasureInstance]
		*/
		PRINT 'Info: Processing [ser].[FactDimensionInstance] ';
		
		INSERT INTO [ser].[FactMeasureInstance]
		(
			[FactInstanceId]
			,[MeasureId]
			,[Value]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT
				[FactInstanceId]
				,[MeasureId]
				,[Value]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
				,@SCDActiveFlag AS [SCDActiveFlag]
				,@SCDVersion AS [SCDVersion]
				--,NULL AS [SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			FROM
			(
				SELECT
					FactInstanceId AS [FactInstanceId]
					,@measureId AS [MeasureId]
					,facings AS [Value]
					,@LOVRecordSourceId AS [LOVRecordSourceId]
					,'1900-01-01 00:00:00' AS [SCDStartDate]
					,NULL AS [SCDEndDate]
					,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,@serveETLRunLogID as [ETLRunLogId]
					,row_id as [PSARowKey]
				FROM #no_crp_planogram_temp
				WHERE facings IS NOT NULL AND facings <> ''
			) A
		)
		
		PRINT 'Updating rowStatus of [psa].[no_crp_planogram] ';  
	
		UPDATE [psa].[no_crp_planogram] 
			SET [row_status]=@rowStatusSERCode
		FROM [psa].[no_crp_planogram] tcp
		JOIN
		(
			SELECT distinct 
				FactInstanceId,PSARowKey,LOVRecordSourceId 
			FROM [ser].[FactInstance]
			WHERE [LOVRecordSourceId] = @LOVRecordSourceId
				AND ETLRunLogId = @serveETLRunLogID 
				-- AND SCDLOVRecordSourceId=@LOVRecordSourceId
		)temp
		ON tcp.row_id = temp.PSARowKey
		AND tcp.record_source_id = temp.LOVRecordSourceId
		WHERE tcp.row_status=@rowStatusPSACode;
	
	COMMIT TRANSACTION;		

	END TRY
    BEGIN CATCH
    THROW;
    ROLLBACK TRANSACTION;    
    END CATCH 	
	
END
GO
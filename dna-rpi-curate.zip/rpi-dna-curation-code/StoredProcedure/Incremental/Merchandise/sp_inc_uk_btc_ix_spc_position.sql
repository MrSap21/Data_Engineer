SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_uk_btc_ix_spc_position') IS NOT NULL
BEGIN
DROP PROC [psa].[sp_inc_uk_btc_ix_spc_position];
END
GO

CREATE PROC [psa].[sp_inc_uk_btc_ix_spc_position] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max) AS

/*Declaring the variables*/
DECLARE  
		@max_planogram_position_id BIGINT,
		@LOVProductStatusSetId BIGINT,
		@SCDDefaultStartDate DATETIME, 
		@SCDDefaultEndDate DATETIME,
		@SCDStartDate DATETIME,		
		@SCDEndDate DATETIME,
		@created_timestamp DATETIME,
		@SCDActiveFlag  CHAR,
		@SCDVersion SMALLINT,
		@SCDLOVRecordSourceId INT,
		@record_source_id INT,
		@ProductLOVSourceKeyTypeId BIGINT,
		@row_status_success BIGINT,
		@row_status_duplicate BIGINT,
		@psaRowStatus BIGINT, 
		@LOVSourceKeyTypeID_Child BIGINT,
		@COUNTER INT,
		@PRODUCT_COUNTER INT,
		@PRODUCT_MAXID INT,
		@max_productID INT,
		@new_productID INT,
		@ParentProductkey VARCHAR(20),
		@MAXID INT,		
		@LOVUOMID BIGINT,
		@asset_id INT,
		@prod_exist_flag INT ,
		@t_ProductId BIGINT,
		@t_SourceKey NVARCHAR(80),
		@t_SCDEndDate DATETIME,
		@t_PSARowKey BIGINT,
		@product_rule_id INT,
		@rule_id INT,
		@rule_entity_id INT,
		@rule_attribute_id INT,
		@rule_detail NVARCHAR(1000),
		@rule_dt_created SMALLDATETIME,
		@rule_user_created NVARCHAR(128),
		@product_location_mid BIGINT,
		@product_facing_mid BIGINT,
		@item_segment_mid BIGINT;		

IF OBJECT_ID('psa.int_position_cursor_table') is not null
	BEGIN
			DROP TABLE [psa].[int_position_cursor_table]
	END	
			CREATE TABLE [psa].[int_position_cursor_table]
			(
				[row_id] [bigint]  NULL,
				[asset_id] [int]  NULL
			)
			WITH
			(
				DISTRIBUTION = ROUND_ROBIN
			)

IF OBJECT_ID('ser.ser_positiontemp') IS NOT NULL
BEGIN
DROP TABLE ser.ser_positiontemp;
END
create table ser.ser_positiontemp(
Positiondbkey nvarchar(80),
planogrampositionid bigint,
productid bigint,
planogramid bigint,
planogramfixtureid bigint,
lovrecordsourceid int,
scdactiveflag nchar(2),
scdversion smallint
)

IF OBJECT_ID('ser.psa_positiontemp') IS NOT NULL
BEGIN
DROP TABLE ser.psa_positiontemp;
END
create table ser.psa_positiontemp(
PlanogramPositionId bigint,
ProductId bigint,
PlanogramId bigint,
PlanogramFixtureId bigint,
SourceKey nvarchar(80),
LOVRecordSourceId int,
SCDStartDate datetime,
SCDEndDate datetime,
SCDActiveFlag nchar(2),
SCDVersion smallint,
SCDLOVRecordSourceId int,
ETLRunLogId int,
PSARowKey bigint,
ParentProductkey nvarchar(80),
ParentPlanogramkey nvarchar(80),
ParentPlanogramFixturekey nvarchar(80)
) 

IF OBJECT_ID('ser.psa_productkey') IS NOT NULL
BEGIN
DROP TABLE ser.psa_productkey;
END
create table ser.psa_productkey(
rowkey int,
ParentProductkey nvarchar(80) 
 
) 

IF OBJECT_ID('ser.psa_skel_prod_check') IS NOT NULL
BEGIN
DROP TABLE ser.psa_skel_prod_check;
END
create table ser.psa_skel_prod_check(
ProductId bigint,
SourceKey nvarchar(80),
SCDEndDate datetime,
PSARowKey bigint,
SCDVersion int
) 

BEGIN
BEGIN TRANSACTION
/*Setting the up the static values to the variable*/
           	SET @SCDDefaultStartDate = CONVERT(DateTime,'1900-01-01')			
			SET @SCDDefaultEndDate = CONVERT(DateTime,'9999-12-31')
			SET @SCDStartDate=current_timestamp
			SET @SCDEndDate =DATEADD(second,-1,@SCDStartDate)
			SET @SCDActiveFlag = 'Y'
			SET @SCDVersion = 1
			SET @SCDLOVRecordSourceId = 12002
			SET @psaRowStatus = 26001
			SET @row_status_success = 26002
			SET @row_status_duplicate = 26010
			SET @record_source_id = 12002
			SET	@LOVProductStatusSetId	= (SELECT DISTINCT rl.LovSetID FROM ser.RefLOVSetInfo rl WHERE rl.LOVSetName = 'Status' AND rl.LOVRecordSourceId = @record_source_id);
			SET @ProductLOVSourceKeyTypeId=(SELECT rs.LOVId FROM  ser.RefLOVSetInfo rs	WHERE rs.LOVKey ='SAP Article Number' and rs.LOVSetName = 'Source Key Type') 
			SET @LOVSourceKeyTypeID_Child=(SELECT r.LOVID FROM [ser].[RefLOVSetInfo] r where r.LOVKey='Intactix Planogram dbkey' 
			AND r.LOVSetName = 'Source Key Type' AND r.LOVRecordSourceID= 12012)
			SET @LOVUOMID=(SELECT rs.LovID from ser.RefLOVSetInfo rs where rs.LOVKey = 'Unknown' AND rs.LOVSetName = 'Unit Of Measure'  )
			SET @product_rule_id =  (select distinct ruleid from [psa].[Rule] where  RuleName = 'Skeleton Record Creation' AND ActiveFlag=1 )	
			SET @rule_id =  (select distinct ruleid from [psa].[Rule] where  RuleName = 'Forigen Key Lookup' AND ActiveFlag=1 )
			SET @rule_entity_id=(SELECT EntityID FROM [psa].[Entity] WHERE EntityName = 'btc_ix_spc_position_Incremental_Load_txt' AND ActiveFlag = 1);
			SET @rule_attribute_id = (select distinct attributeid from psa.attribute where entityid = @rule_entity_id and attributename = 'dbparentproductkey' )	
       		SET @product_location_mid = (SELECT MeasureId FROM ser.Measure me WHERE me.MeasureName = 'product_location' AND  me.LOVRecordSourceId =12002)	
       		SET @product_facing_mid = (SELECT MeasureId FROM ser.Measure me WHERE me.MeasureName = 'product_facing' AND  me.LOVRecordSourceId =12002)	
       		SET @item_segment_mid = (SELECT MeasureId FROM ser.Measure me WHERE me.MeasureName = 'item_segment' AND  me.LOVRecordSourceId =12002)	
		 	SET @rule_user_created = SYSTEM_USER;
BEGIN TRY
SET @COUNTER = 1
		SELECT @MAXID = COUNT(distinct asset_id) FROM [psa].[UK_BTC_IX_SPC_POSITION] ixf WHERE row_status=@psaRowStatus;
		print 'Total Number of Loops : '+cast(@MAXID as varchar)+'';
		
		INSERT INTO [psa].[int_position_cursor_table]
		SELECT  DISTINCT DENSE_RANK() OVER(ORDER BY (asset_id)) AS row_id,
									asset_id AS asset_id
							   FROM [psa].[UK_BTC_IX_SPC_POSITION] 
							  WHERE row_status=@psaRowStatus;

		--Outer loop
WHILE (@COUNTER <= @MAXID)
		BEGIN --outer loop begin		
			    SELECT @asset_id = asset_id FROM [psa].[int_position_cursor_table] WHERE  row_id=@COUNTER; 
				PRINT 'START ----------------------------------------Current Asset ID: '+ CAST(@asset_id as varchar)+'';
				
			SET @max_planogram_position_id= (SELECT COALESCE(MAX(PlanogramPositionId),0) FROM [ser].[PlanogramPosition])
			
			SET @SCDStartDate = current_timestamp;
			SET @SCDEndDate = DATEADD(second,-1,@SCDStartDate)
			
DELETE FROM ser.ser_positiontemp;
			
INSERT INTO ser.ser_positiontemp
			SELECT pp.sourcekey as Positiondbkey,
													pp.planogrampositionid,
													pp.productid,
													pp.planogramid,
													pp.planogramfixtureid,
													pp.lovrecordsourceid,
													pp.scdactiveflag,
													pp.scdversion
													from ser.planogramposition pp
													JOIN ser.Product p on p.ProductId = pp.ProductId AND  p.lovrecordsourceid = 12002
													JOIN ser.Planogram pl on pl.PlanogramId = pp.PlanogramId AND pl.lovrecordsourceid = 12002 
													LEFT JOIN ser.PlanogramFixture pf on pf.PlanogramFixtureId = pp.PlanogramFixtureId AND pf.lovrecordsourceid = 12002
													WHERE    pp.lovrecordsourceid = 12002 AND
													p.lovrecordsourceid = 12002 and p.SCDActiveFlag = 'Y'
													AND pl.lovrecordsourceid = 12002 and pl.SCDActiveFlag = 'Y'												 
													AND ISNULL(pf.LOVRecordSourceId, 12002) =  12002 AND ISNULL(pf.SCDActiveFlag,'Y')='Y' 								
													AND NOT EXISTS (SELECT 1 FROM ser.planogramposition AS ppt 
																	WHERE ppt.planogrampositionid = pp.planogrampositionid
																	AND ppt.LOVRecordSourceID=pp.LOVRecordSourceID
																	AND  ppt.scdactiveflag = 'Y' -- We need to take the max version.
																	AND  ppt.ScdVersion > pp.ScdVersion)
							
DELETE FROM  ser.psa_positiontemp;

INSERT INTO ser.psa_positiontemp	
SELECT 
--only assin key to planogram id if it is not null.
(CASE WHEN pp.PlanogramPositionId IS NULL THEN NULL ELSE pp.PlanogramPositionId END) as PlanogramPositionId ,
pr.ProductId, 
pl.PlanogramId,
pf.PlanogramFixtureId,
pps.dbkey AS SourceKey,
pps.record_source_id AS LOVRecordSourceId,
LEAD(@SCDStartDate,1,@SCDStartDate) OVER (PARTITION BY pps.dbkey,pps.record_source_id ORDER BY   pps.dbkey) as SCDStartDate,								 
LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY pps.dbkey,pps.record_source_id ORDER BY   pps.dbkey) SCDEndDate,
LEAD('N', 1, 'Y') OVER(PARTITION BY pps.dbkey,pps.record_source_id ORDER BY   pps.dbkey ASC) SCDActiveFlag,				
ISNULL(pp.SCDVersion,0)+ ROW_NUMBER() OVER(PARTITION BY pps.dbkey,pps.record_source_id ORDER BY   pps.dbkey ASC) SCDVersion,
@record_source_id AS SCDLOVRecordSourceId,
CAST(@serveETLRunLogID AS INT) ETLRunLogId,
pps.row_id AS PSARowKey,
pps.dbparentproductkey AS ParentProductkey,
pps.DBParentPlanogramKey AS ParentPlanogramkey,
pps.DBParentFixtureKey AS ParentPlanogramFixturekey
FROM psa.UK_BTC_IX_SPC_POSITION pps 
JOIN  (select distinct dbkey,id,record_source_id from psa.UK_BTC_IX_SPC_PRODUCT) ixpr ON ixpr.dbkey =  pps.dbparentproductkey AND pps.record_source_id= ixpr.record_source_id 
LEFT JOIN ( SELECT  ProductId, SourceKey FROM ser.Product WHERE SCDActiveFlag = 'Y' AND LOVRecordSourceId = 12002 GROUP BY ProductId, SourceKey ) pr
ON ixpr.id  = pr.SourceKey 
JOIN ser.Planogram pl ON pps.DBParentPlanogramKey = pl.SourceKey AND pps.record_source_id=  pl.LOVRecordSourceID
LEFT JOIN ( SELECT  PlanogramFixtureId, SourceKey FROM ser.PlanogramFixture WHERE SCDActiveFlag = 'Y' AND LOVRecordSourceId = 12002 GROUP BY PlanogramFixtureId, SourceKey ) pf
ON pf.SourceKey = pps.DBParentFixtureKey
LEFT JOIN ser.ser_positiontemp pp ON pp.Positiondbkey = pps.dbkey AND pps.record_source_id= pp.LOVRecordSourceID
WHERE 
pl.LOVSourceKeyTypeId= @LOVSourceKeyTypeID_Child
AND pps.row_status= 26001
AND ISNULL(pl.SCDActiveFlag,'Y')='Y' 
AND ISNULL(pp.SCDActiveFlag,'Y')='Y' 
AND pps.record_source_id =  12002
AND pl.LOVRecordSourceId =  12002
AND ISNULL(pp.LOVRecordSourceId, 12002) =  12002
AND pps.asset_id=@asset_id; 									
		
--Iterate through each record ( product id is null)
DELETE FROM ser.psa_productkey;
 
WITH psa_product_id_temp AS (SELECT DISTINCT ParentProductkey FROM ser.psa_positiontemp WHERE ProductId IS NULL)

INSERT INTO ser.psa_productkey SELECT (ROW_NUMBER()  over (order by P.ParentProductkey) ),P.ParentProductkey  from psa_product_id_temp AS P; 

SET @PRODUCT_COUNTER = 1;

SELECT @PRODUCT_MAXID = COUNT(*) FROM ser.psa_productkey
print 'Total Number of Product need to create : '+cast(@PRODUCT_MAXID  as varchar)+'';
 
--Inner while loop to create skeleton product records
WHILE ( @PRODUCT_COUNTER <= @PRODUCT_MAXID )
BEGIN    
print 'In Product Loop : '+cast(@PRODUCT_COUNTER as varchar)+'';
  --Fetch each record using the rowid
SELECT @ParentProductkey = P.ParentProductkey FROM ser.psa_productkey AS P  WHERE rowkey = @PRODUCT_COUNTER

INSERT INTO ser.psa_skel_prod_check
SELECT TOP 1 pr.ProductId,pr.SourceKey,pr.SCDEndDate,pr.PSARowKey,pr.SCDVersion FROM psa.UK_BTC_IX_SPC_POSITION pps 
JOIN psa.UK_BTC_IX_SPC_PRODUCT ixpr ON ixpr.dbkey =  pps.dbparentproductkey AND pps.record_source_id= ixpr.record_source_id	
JOIN ser.Product pr ON  ixpr.id  =   pr.SourceKey AND pps.record_source_id= pr.LOVRecordSourceID	
WHERE pr.lovrecordsourceid = 12002 AND  pr.SCDActiveFlag = 'N' 
AND pps.dbparentproductkey = @ParentProductkey
ORDER BY pr.SCDVersion,pr.SCDEndDate DESC  

SELECT @prod_exist_flag = count(ProductId) FROM ser.psa_skel_prod_check;
--If the product exist then the flag value become 1 otherwise we need to create the new skeleton product
IF  @prod_exist_flag = 1   
BEGIN
 print 'Product ID with N status is Present -- Start'
SELECT @t_ProductId = p.ProductId , @t_SourceKey = p.SourceKey, @t_SCDEndDate = p.SCDEndDate, @t_PSARowKey = p.PSARowKey FROM ser.psa_skel_prod_check AS p;

UPDATE ser.Product  SET SCDActiveFlag = 'Y' WHERE  SourceKey = @t_SourceKey AND ProductId = @t_ProductId AND  SCDEndDate = @t_SCDEndDate AND PSARowKey = @t_PSARowKey;

UPDATE ser.ProductStatus  SET SCDActiveFlag = 'Y' WHERE  ProductId = @t_ProductId AND  SCDEndDate = @t_SCDEndDate AND PSARowKey = @t_PSARowKey;

UPDATE ser.psa_positiontemp SET productid = @t_ProductId FROM [ser].[psa_positiontemp] pt INNER JOIN ser.Product p
ON pt.ProductId = p.ProductId AND pt.LOVRecordSourceId = p.LOVRecordSourceId 
WHERE p.SCDActiveFlag = 'Y' AND pt.ParentProductkey =  @ParentProductkey

DELETE FROM ser.psa_skel_prod_check;

print 'Product ID with N status is Present -- End'
END

ELSE
BEGIN 
SET @max_productID = (SELECT COALESCE(MAX(ProductID),0) FROM  ser.Product );
SET @new_productID = @max_productID + 1;
 print 'Going to create a new Product and new Id : '+cast(@new_productID as varchar)+''; 
   --Inserting into the prod status table.
  INSERT INTO ser.Product	
	SELECT  @new_productID ProductID,
            ixp.id  SourceKey,
			@ProductLOVSourceKeyTypeId  LOVSourceKeyTypeId,
			ixp.name  ProductName,
			NULL  ProductDescription,
			c.LOVId  LOVBrANDId,
			NULL  LOVSubBRANDId,
			12002  LOVRecordSourceId,
			NULL  ParentProductId,                
			@SCDStartDate SCDStartDate,
            @SCDEndDate SCDEndDate,
            LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id ASC) SCDActiveFlag,                
            1 SCDVersion,
            @SCDLOVRecordSourceId SCDLOVRecordSourceId,
            CAST(@serveETLRunLogID AS INT) ETLRunLogId,
			ixp.row_id AS PSARowKey
    FROM psa.UK_BTC_IX_SPC_PRODUCT ixp
	JOIN ( SELECT  DISTINCT p.dbparentproductkey,p.asset_id FROM psa.UK_BTC_IX_SPC_POSITION p 
                JOIN psa.UK_BTC_IX_SPC_PRODUCT ixp ON ixp.dbkey = p.dbparentproductkey AND ixp.record_source_id=p.record_source_id 
				WHERE p.asset_id=@asset_id) pkey				
    ON ixp.dbkey = pkey.dbparentproductkey AND ixp.record_source_id = 12002	 
    LEFT JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
					ser.RefLovsetInfo rl                
					WHERE rl.LOVSetName = 'Brand')c
		ON ixp.record_source_id=c.LOVRecordSourceId AND  c.LOVKey = ixp.BRAND
	WHERE 
		pkey.asset_id=@asset_id  AND pkey.dbparentproductkey = @ParentProductkey
	
	 print 'Product is created : '+CAST(@new_productID AS varchar)+''; 	
INSERT INTO 
	[ser].[ProductStatus](ProductId,LOVProductStatusSetId,LOVStatusId,EffectiveFROM,EffectiveTo,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
		SELECT DISTINCT
		    pdct.ProductId   ProductId,
			@LOVProductStatusSetId  LOVProductStatusSetId,
			rl.LovID  LOVStatusId,
			null  EffectiveFROM,
			null EffectiveTo,
			ixp.record_source_id  LOVRecordSourceId,              
			@SCDStartDate   SCDStartDate,
			@SCDEndDate SCDEndDate,       
			LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id ASC) SCDActiveFlag,  
            1 AS SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
			ixp.row_id as PSARowKey
		FROM ser.Product	 pdct		
		JOIN psa.UK_BTC_IX_SPC_PRODUCT ixp ON pdct.SourceKey = ixp.ID AND pdct.LOVRecordSourceId = ixp.record_source_id
		INNER JOIN psa.UK_BTC_IX_SPC_POSITION p 
		ON ixp.dbkey = p.dbparentproductkey AND ixp.record_source_id=p.record_source_id
		INNER JOIN ser.RefLOVSetInfo rl 
		ON rl.LOVSetName = 'Status' 
		AND rl.LOVRecordSourceId=ixp.record_source_id
		AND rl.LOVKey = ixp.status 
		WHERE   p.asset_id=@asset_id  AND ixp.status IS NOT NULL AND ixp.status !='' AND pdct.SCDActiveFlag = 'Y'  
		AND pdct.LOVRecordSourceId = 12002  
		AND ixp.record_source_id = 12002
		AND p.record_source_id = 12002
		AND pdct.ProductId = @new_productID			

	print 'inserted record update is going to start'
	
UPDATE ser.psa_positiontemp SET productid = @new_productID FROM ser.Product p 
	WHERE   p.ProductId = @new_productID AND p.LOVRecordSourceId = 12002 AND p.SCDActiveFlag = 'Y' 
	AND ParentProductkey = @ParentProductkey;

		
	SET @rule_detail = 'Info - The dbparentproductkey of  psa.UK_BTC_IX_SPC_POSITION does not have corresponding match in ser.Product.'  
	 + 'Created new skeleton Product in ser.PRODUCT having following details DBPARENTPRODUCTKEY in psa.UK_BTC_IX_SPC_POSITION :  '  
	 + CAST ( @ParentProductkey AS varchar)
	 + ' Current Asset ID:: ' + CAST(@asset_id AS varchar)
				  + ' ETL Run Log Id : ' + @serveETLRunLogID
			      + ' New Product Id in ser.Product : '+  CAST(@new_productID AS varchar)
				  + ' LOVRecordSourceId in ser.Product : '+  CAST(12002 AS varchar) 
		print 'Rule Error sting going to insert : ' + @rule_detail
		
 SET @rule_dt_created = CAST(GETDATE() AS SMALLDATETIME);

	INSERT INTO [psa].[RuleEntityInstance]
           ([RuleID]
           ,[EntityID]
           ,[AttributeID]
           ,[RuleDetail]
           ,[ETLRunLogID]
           ,[SourceEntityID]
           ,[SourceAttributeID]
           ,[PSARowKey]
           ,[DTCreated]
           ,[UserCreated])
     VALUES
           (@product_rule_id
          	,@psaEntityId		   
           ,@rule_attribute_id 
           ,@rule_detail
           ,@serveETLRunLogID
           ,@psaEntityId		   
           ,@rule_attribute_id 
           ,NULL
           ,@rule_dt_created 
           ,@rule_user_created)	  
    print 'DQ Insert also completed'
    --increment the counter to take the next record.
	
END	
	
    SET @PRODUCT_COUNTER = @PRODUCT_COUNTER + 1
END
print 'New Records insersion ended'
--Inserting all the new records from the source table which are not existing in the server table [ser].[PlanogramPosition]
INSERT INTO [ser].[PlanogramPosition]
           (
		   [PlanogramPositionId]
           ,[ProductId]
           ,[PlanogramId]
           ,[PlanogramFixtureId]
           ,[SourceKey]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
		   ,[PSARowKey])
select 
 		  ISNULL(src.PlanogramPositionId ,@max_planogram_position_id+ROW_NUMBER() OVER(ORDER BY src.SourceKey)) PlanogramPositionId
           ,ISNULL(src.ProductId ,-1)
           ,src.PlanogramId
           ,src.PlanogramFixtureId
           ,src.SourceKey
           ,src.LOVRecordSourceId
           ,src.SCDStartDate
           ,src.SCDEndDate
           ,src.SCDActiveFlag
           ,src.SCDVersion
           ,src.SCDLOVRecordSourceId
           ,src.ETLRunLogId
		   ,src.PSARowKey FROM ser.psa_positiontemp	 src
		   LEFT JOIN ser.ser_positiontemp tar ON src.sourcekey =  tar.Positiondbkey
		   WHERE tar.Positiondbkey IS NULL
print 'New Records insersion end'
--Inserting the common records which have change in ProductId,PlanogramId or planogramfixtureid

print 'Changed Records insersion Start'
INSERT INTO [ser].[PlanogramPosition]
           ([PlanogramPositionId]
           ,[ProductId]
           ,[PlanogramId]
           ,[PlanogramFixtureId]
           ,[SourceKey]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
		   ,[PSARowKey])
SELECT 
src.PlanogramPositionId
           ,ISNULL(src.ProductId ,-1) -- TODO Need to check
           ,src.PlanogramId
           ,src.PlanogramFixtureId
           ,src.SourceKey
           ,src.LOVRecordSourceId
           ,src.SCDStartDate
           ,src.SCDEndDate
           ,src.SCDActiveFlag
           ,src.SCDVersion
           ,src.SCDLOVRecordSourceId
           ,src.ETLRunLogId
		   ,src.PSARowKey FROM ser.psa_positiontemp	 src
JOIN  ser.ser_positiontemp tar ON src.Sourcekey = tar.Positiondbkey
WHERE  
  src.LOVRecordSourceId=tar.LOVRecordSourceId
  AND  
  ( 
 src.ProductId != tar.ProductId OR
 ISNULL(src.planogramid,'') != ISNULL(tar.PlanogramId,'') OR
 ISNULL(src.PlanogramFixtureId,'') != ISNULL(tar.planogramfixtureid,'') ) 
	print 'Changed Records insersion End'
	
--Closing the active record when there is an incremetal data for the existing Business Key
UPDATE ser.PlanogramPosition set SCDActiveFlag='N',SCDEndDate =@SCDEndDate
				FROM ser.PlanogramPosition pp 
				JOIN (SELECT planogrampositionid,SCDactiveflag,SCDVersion,LovRecordSourceId FROM ser.PlanogramPosition t WHERE   
				      t.LOVRecordSourceID=12002 AND t.SCDActiveFlag='Y' 
					  AND NOT EXISTS (SELECT 1 FROM ser.planogramposition AS ppt 
																	WHERE ppt.planogrampositionid = t.planogrampositionid
																	AND ppt.LOVRecordSourceID=t.LOVRecordSourceId
																	AND  ppt.scdactiveflag = 'Y'
																	AND  ppt.ScdVersion > t.ScdVersion ) )p2
					  ON  pp.PlanogramPositionId=p2.planogrampositionid
					  AND pp.LovRecordSourceId=p2.LovRecordSourceId						 
					  AND pp.SCDactiveflag=p2.SCDactiveflag
					  AND pp.SCDVersion!=p2.SCDVersion
				      JOIN  psa.[UK_BTC_IX_SPC_POSITION] pps
					  ON pps.record_source_id=pp.LovRecordSourceId AND  pp.sourcekey = pps.dbkey
				      WHERE pp.SCDActiveFlag='Y'
     				  AND pps.row_status=@psaRowStatus
					  AND pps.asset_id=@asset_id;


print 'Changed Records insersion End'
---Property Insert / Update
INSERT INTO [ser].[PlanogramPositionProperty] (
	PlanogramPositionId          ,
    MeasureID         		    ,
    LOVUOMID         			,
    [Value]       			    ,
    LOVRecordSourceID        	,
    SCDStartDate         		,
    SCDEndDate         			,
    SCDActiveFlag         		,
    SCDVersion         			,
    SCDLOVRecordSourceID        ,
    ETLRunLogID					,
    PSARowKey	)	
SELECT 	pp.PlanogramPositionId PlanogramPositionId,
		@product_location_mid AS MeasureId,
		@LOVUOMID LOVUOMID,
		ixp.locationid [Value],
		ixp.record_source_id LOVRecordSourceID,
		@SCDStartDate SCDStartDate,
		@SCDDefaultEndDate SCDEndDate,
		LEAD('N',1,'Y') OVER (PARTITION BY pp.PlanogramPositionId ORDER BY pp.PlanogramPositionId) SCDActiveFlag,
		ISNULL(ppp.SCDVersion1,0)+1 SCDVersion,
		@SCDLOVRecordSourceId  SCDLOVRecordSourceID,
		@serveETLRunLogID ETLRunLogID,
		ixp.row_id PSARowKey
FROM [psa].[UK_BTC_IX_SPC_POSITION] ixp
	 JOIN [ser].[PlanogramPosition] pp ON pp.SourceKey=ixp.dbkey and pp.SCDActiveFlag='Y' and pp.LOVRECORDSOURCEID=@record_source_id
	 LEFT JOIN (SELECT PlanogramPositionId,MeasureId,MAX(SCDVersion) SCDVersion1 FROM [ser].[PlanogramPositionProperty] group by PlanogramPositionId,MeasureId having MeasureId in 
	 (@product_location_mid)) ppp 
	 ON ppp.PlanogramPositionId = pp.PlanogramPositionId  and pp.SCDActiveFlag = 'Y'
	 WHERE ixp.row_status= @psaRowStatus  
     AND ixp.asset_id=@asset_id	 
	 AND ixp.locationid IS NOT NULL AND ixp.locationid != ''
	 AND NOT EXISTS (SELECT 1 FROM [ser].[PlanogramPositionProperty] temp WHERE
					  ixp.dbkey IN (SELECT DISTINCT SourceKey from [ser].[PlanogramPosition] temp1 where temp1.PlanogramPositionId=temp.PlanogramPositionId AND temp1.SCDActiveFlag='Y')
					  AND temp.MeasureId in (@product_location_mid)
					  AND CAST(ixp.locationid AS BIGINT) = CAST(temp.Value AS BIGINT)
					  AND ixp.record_source_id=@record_source_id
					  AND temp.SCDActiveFlag='Y'
					  )
UNION
SELECT 	pp.PlanogramPositionId PlanogramPositionId,
		(@product_facing_mid) AS MeasureId,
		@LOVUOMID LOVUOMID,
		ixp.hfacings [Value],
		ixp.record_source_id LOVRecordSourceID,
		@SCDStartDate SCDStartDate,
		@SCDDefaultEndDate SCDEndDate,
		LEAD('N',1,'Y') OVER (PARTITION BY pp.PlanogramPositionId ORDER BY pp.PlanogramPositionId) SCDActiveFlag,
		ISNULL(ppp.SCDVersion1,0)+1 SCDVersion,
		@SCDLOVRecordSourceId  SCDLOVRecordSourceID,
		@serveETLRunLogID ETLRunLogID,
		ixp.row_id PSARowKey
FROM [psa].[UK_BTC_IX_SPC_POSITION] ixp
	 JOIN [ser].[PlanogramPosition] pp ON pp.SourceKey=ixp.dbkey AND pp.SCDActiveFlag='Y' AND pp.LOVRECORDSOURCEID=@record_source_id
	 LEFT JOIN (SELECT PlanogramPositionId,MeasureId,MAX(SCDVersion) SCDVersion1 FROM [ser].[PlanogramPositionProperty] GROUP BY PlanogramPositionId,MeasureId
	 HAVING MeasureId IN (@product_facing_mid) ) ppp 
	 ON ppp.PlanogramPositionId = pp.PlanogramPositionId  AND pp.SCDActiveFlag = 'Y'
	 WHERE ixp.row_status= @psaRowStatus  
	 AND ixp.asset_id=@asset_id	 
	 AND ixp.hfacings IS NOT NULL AND ixp.hfacings != ''
	 AND NOT EXISTS (SELECT 1 FROM [ser].[PlanogramPositionProperty] temp WHERE
					  ixp.dbkey IN (SELECT DISTINCT SourceKey from [ser].[PlanogramPosition] temp1 where temp1.PlanogramPositionId=temp.PlanogramPositionId AND temp1.SCDActiveFlag='Y')
					  AND temp.MeasureId IN ( @product_facing_mid)
					  AND CAST(ixp.hfacings AS BIGINT) = CAST(temp.Value AS BIGINT)
					  AND ixp.record_source_id=@record_source_id
					  AND temp.SCDActiveFlag='Y'
					  )
UNION
SELECT 	pp.PlanogramPositionId PlanogramPositionId,
		(@item_segment_mid) AS MeasureId,
		@LOVUOMID LOVUOMID,
		ixp.segment [Value],
		ixp.record_source_id LOVRecordSourceID,
		@SCDStartDate SCDStartDate,
		@SCDDefaultEndDate SCDEndDate,
		LEAD('N',1,'Y') OVER (PARTITION BY pp.PlanogramPositionId ORDER BY pp.PlanogramPositionId) SCDActiveFlag,
		ISNULL(ppp.SCDVersion1,0)+1 SCDVersion,
		@SCDLOVRecordSourceId  SCDLOVRecordSourceID,
		@serveETLRunLogID ETLRunLogID,
		ixp.row_id PSARowKey
FROM [psa].[UK_BTC_IX_SPC_POSITION] ixp
	 JOIN [ser].[PlanogramPosition] pp ON pp.SourceKey=ixp.dbkey and pp.SCDActiveFlag='Y' and pp.LOVRECORDSOURCEID=@record_source_id
	 LEFT JOIN (SELECT PlanogramPositionId,MeasureId,MAX(SCDVersion) SCDVersion1 FROM [ser].[PlanogramPositionProperty] GROUP BY PlanogramPositionId,MeasureId having 
	 MeasureId IN (@item_segment_mid)) ppp 
	 ON ppp.PlanogramPositionId = pp.PlanogramPositionId  and pp.SCDActiveFlag = 'Y'
	 WHERE ixp.row_status= @psaRowStatus  
	 AND ixp.asset_id=@asset_id	
	 AND ixp.segment IS NOT NULL AND ixp.segment != ''
	 AND NOT EXISTS (SELECT 1 FROM [ser].[PlanogramPositionProperty] temp WHERE
					  ixp.dbkey IN (SELECT DISTINCT SourceKey from [ser].[PlanogramPosition] temp1 where temp1.PlanogramPositionId=temp.PlanogramPositionId AND temp1.SCDActiveFlag='Y')
					  AND temp.MeasureId in ( @item_segment_mid )
					  AND CAST(ixp.segment AS BIGINT) = CAST(temp.Value AS BIGINT)
					  AND ixp.record_source_id=@record_source_id
					  AND temp.SCDActiveFlag='Y'
					  )				  
		 
PRINT '****************Inserting into PlanogramPositionProperty completed *********************';

PRINT '****************Closing current active records, if any, in PlanogramPositionProperty Table *********************';

UPDATE [ser].[PlanogramPositionProperty]  SET SCDEndDate=(SELECT DATEADD(second,-1,@SCDStartDate)),SCDActiveFlag='N'
					FROM [ser].[PlanogramPositionProperty]  ppp
					JOIN (SELECT PlanogramPositionId,MeasureId,Value,SCDActiveFlag,SCDVersion,LOVRecordSourceID FROM [ser].[PlanogramPositionProperty] temp WHERE   
					temp.SCDActiveFlag='Y' AND NOT EXISTS (SELECT 1 FROM [ser].[PlanogramPositionProperty] AS temp1 
																WHERE temp1.PlanogramPositionId = temp.PlanogramPositionId
																AND temp1.MeasureId=temp.MeasureId
																AND temp1.LOVRecordSourceID=temp.LOVRecordSourceID
																AND temp1.SCDVersion > temp.SCDVersion) )pfp2
					 ON  ppp.PlanogramPositionId=pfp2.PlanogramPositionId
					 AND ppp.LOVRecordSourceID=pfp2.LOVRecordSourceID						 
					 AND ppp.SCDActiveFlag=pfp2.SCDActiveFlag
					 AND ppp.SCDVersion!=pfp2.SCDVersion
					 AND ppp.MeasureId=pfp2.MeasureId
					 LEFT JOIN [ser].[PlanogramPosition] pftemp
					 ON pftemp.PlanogramPositionId=ppp.PlanogramPositionId and pftemp.SCDActiveFlag='Y'
					 JOIN [psa].[UK_BTC_IX_SPC_POSITION] ixp
					 ON ixp.dbkey=pftemp.SourceKey
					 AND ppp.SCDActiveFlag='Y'
					 WHERE ixp.row_status=@psaRowStatus AND ixp.asset_id=@asset_id	

PRINT 'Info: PlanogramPositionProperty Table -> Closing off old Records if it is null in the target';
-- Update all the records if it is null in the target
UPDATE [ser].[PlanogramPositionProperty] SET SCDActiveFlag= 'N',SCDEndDate =@SCDEndDate
						FROM [ser].[PlanogramPosition] pp 				
						JOIN  psa.[UK_BTC_IX_SPC_POSITION] ixp
							  ON ixp.record_source_id=pp.LovRecordSourceId
							  AND pp.sourcekey = ixp.dbkey
						JOIN [ser].[PlanogramPositionProperty] ppp		
						     ON ppp.PlanogramPositionId = pp.PlanogramPositionId
							 AND ppp.LovRecordSourceId = pp.LovRecordSourceId
							 AND ppp.MeasureID=@item_segment_mid
					WHERE NULLIF(ixp.segment,'' ) IS NULL 
							  AND ppp.SCDActiveFlag='Y'
							  AND asset_id=@asset_id;	
							  
UPDATE [ser].[PlanogramPositionProperty] SET SCDActiveFlag= 'N',SCDEndDate =@SCDEndDate
						FROM [ser].[PlanogramPosition] pp 				
						JOIN  psa.[UK_BTC_IX_SPC_POSITION] ixp
							  ON ixp.record_source_id=pp.LovRecordSourceId
							  AND pp.sourcekey = ixp.dbkey
						JOIN [ser].[PlanogramPositionProperty] ppp		
						     ON ppp.PlanogramPositionId = pp.PlanogramPositionId
							 AND ppp.LovRecordSourceId = pp.LovRecordSourceId
							 AND ppp.MeasureID=@product_facing_mid
					WHERE  NULLIF( ixp.hfacings,'' ) IS NULL 
							  AND ppp.SCDActiveFlag='Y'
							  AND asset_id=@asset_id;
							  
UPDATE [ser].[PlanogramPositionProperty] SET SCDActiveFlag= 'N',SCDEndDate =@SCDEndDate
						FROM [ser].[PlanogramPosition] pp 				
						JOIN  psa.[UK_BTC_IX_SPC_POSITION] ixp
							  ON ixp.record_source_id=pp.LovRecordSourceId
							  AND pp.sourcekey = ixp.dbkey
						JOIN [ser].[PlanogramPositionProperty] ppp		
						     ON ppp.PlanogramPositionId = pp.PlanogramPositionId
							 AND ppp.LovRecordSourceId = pp.LovRecordSourceId
							 AND ppp.MeasureID=@product_location_mid
					WHERE  NULLIF( ixp.locationid,'') IS NULL
							  AND ppp.SCDActiveFlag='Y'
							  AND asset_id=@asset_id;	
-- DQ Warning for non matching product records
SET @rule_dt_created = CAST(GETDATE() AS SMALLDATETIME); 
SET @rule_attribute_id = (SELECT DISTINCT attributeid FROM psa.attribute WHERE entityid = @rule_entity_id AND attributename = 'dbparentproductkey' )	
         
INSERT INTO [psa].[RuleEntityInstance]
           ([RuleID]
           ,[EntityID]
           ,[AttributeID]
           ,[RuleDetail]
           ,[ETLRunLogID]
           ,[SourceEntityID]
           ,[SourceAttributeID]
           ,[PSARowKey]
           ,[DTCreated]
           ,[UserCreated])
		   
SELECT 
    @rule_id AS RuleID,
	@psaEntityId AS EntityID,	   
	@rule_attribute_id  AS AttributeID ,
	'DQ Warning - The dbparentproductkey of  psa.UK_BTC_IX_SPC_POSITION does not have corresponding match in psa.UK_BTC_IX_SPC_PRODUCT (dbkey)'  
	 + 'Details : DBPARENTPRODUCTKEY '  
	 + cast ( pps.dbparentproductkey AS varchar)
	 + ' DbKey of psa.UK_BTC_IX_SPC_POSITION : '+  CAST(pps.dbkey as varchar)
	 + ' Current Asset ID:: ' + CAST(pps.asset_id as varchar)
	+ ' ETL Run Log Id : ' +  CAST( pps.etl_runlog_id as varchar) AS RuleDetail,	
	@serveETLRunLogID AS ETLRunLogID,
	@psaEntityId AS SourceEntityID,	
	@rule_attribute_id AS SourceAttributeID,
	pps.row_id AS PSARowKey,
	@rule_dt_created AS DTCreated,
	@rule_user_created AS UserCreated	 
FROM  psa.UK_BTC_IX_SPC_PRODUCT ixp 
RIGHT JOIN psa.UK_BTC_IX_SPC_POSITION pps  ON ixp.dbkey = pps.dbparentproductkey AND ixp.record_source_id = pps.record_source_id
where ixp.dbkey IS NULL 
AND ISNULL(ixp.record_source_id,@record_source_id) = @record_source_id
AND pps.row_status= 26001
AND pps.asset_id=@asset_id;

-- DQ Warning for non matching planogram records							 
SET @rule_dt_created = CAST(GETDATE() AS SMALLDATETIME); 
SET @rule_attribute_id = (SELECT DISTINCT attributeid FROM psa.attribute WHERE entityid = @rule_entity_id AND attributename = 'dbparentplanogramkey')	
         
INSERT INTO [psa].[RuleEntityInstance]
           ([RuleID]
           ,[EntityID]
           ,[AttributeID]
           ,[RuleDetail]
           ,[ETLRunLogID]
           ,[SourceEntityID]
           ,[SourceAttributeID]
           ,[PSARowKey]
           ,[DTCreated]
           ,[UserCreated])
		   
SELECT 
    @rule_id AS RuleID,
	@psaEntityId AS EntityID,	   
	@rule_attribute_id  AS AttributeID ,
	'DQ Warning - The dbparentplanogramkey of  psa.UK_BTC_IX_SPC_POSITION does not have corresponding match in ser.Planogram.'  
	 + 'Details : DBParentPlanogramKey '  
	 + cast ( pps.DBParentPlanogramKey AS varchar)
	 + ' DbKey of psa.UK_BTC_IX_SPC_POSITION : '+  CAST(pps.dbkey as varchar)
	 + ' Current Asset ID:: ' + CAST(pps.asset_id as varchar)
	+ ' ETL Run Log Id : ' +  CAST( pps.etl_runlog_id as varchar) AS RuleDetail,	
	@serveETLRunLogID AS ETLRunLogID,
	--@rule_source_entity_id AS SourceEntityID,
	@psaEntityId AS SourceEntityID,	
	@rule_attribute_id AS SourceAttributeID,
	pps.row_id AS PSARowKey,
	@rule_dt_created AS DTCreated,
	@rule_user_created AS UserCreated
	FROM 
ser.Planogram pl
RIGHT JOIN psa.UK_BTC_IX_SPC_POSITION pps  ON pps.DBParentPlanogramKey = pl.SourceKey AND pps.record_source_id=  pl.LOVRecordSourceID
WHERE
pl.SourceKey IS NULL  
AND ISNULL(pl.LOVRecordSourceID,@record_source_id) = @record_source_id
AND ISNULL(pl.LOVSourceKeyTypeId,@LOVSourceKeyTypeID_Child) = @LOVSourceKeyTypeID_Child
AND ISNULL(pl.SCDActiveFlag,'Y')='Y' 
AND pps.row_status= 26001
AND pps.asset_id=@asset_id;

-- DQ Warning for non matching planogram fixture records							 
SET @rule_dt_created = CAST(GETDATE() AS SMALLDATETIME);
SET @rule_attribute_id = (SELECT DISTINCT attributeid FROM psa.attribute WHERE entityid = @rule_entity_id AND attributename = 'dbparentfixturekey')	
INSERT INTO [psa].[RuleEntityInstance]
           ([RuleID]
           ,[EntityID]
           ,[AttributeID]
           ,[RuleDetail]
           ,[ETLRunLogID]
           ,[SourceEntityID]
           ,[SourceAttributeID]
           ,[PSARowKey]
           ,[DTCreated]
           ,[UserCreated])
		   
SELECT 
    @rule_id AS RuleID,
	@psaEntityId AS EntityID,	   
	@rule_attribute_id  AS AttributeID ,
	'DQ Warning - The DBParentFixtureKey of  psa.UK_BTC_IX_SPC_POSITION does not have corresponding match in ser.PlanogramFixture.'  
	 + 'Details : DBParentFixtureKey '  
	 + CAST ( pps.DBParentFixtureKey AS varchar)
	 + ' DbKey of psa.UK_BTC_IX_SPC_POSITION : '+  CAST(pps.dbkey as varchar)
	 + ' Current Asset ID:: ' + CAST(pps.asset_id as varchar)
	+ ' ETL Run Log Id : ' +  CAST( pps.etl_runlog_id as varchar) AS RuleDetail,	
	@serveETLRunLogID AS ETLRunLogID,
	@psaEntityId AS SourceEntityID,	
	@rule_attribute_id AS SourceAttributeID,
	pps.row_id AS PSARowKey,
	@rule_dt_created AS DTCreated,
	@rule_user_created AS UserCreated
FROM 
ser.PlanogramFixture pl
RIGHT JOIN psa.UK_BTC_IX_SPC_POSITION pps  ON pps.DBParentFixtureKey = pl.SourceKey AND pps.record_source_id=  pl.LOVRecordSourceID
WHERE
pl.SourceKey IS NULL  
AND pps.row_status= 26001
AND ISNULL(pl.LOVRecordSourceID,@record_source_id) = @record_source_id
AND ISNULL(pl.SCDActiveFlag,'Y')='Y' 
AND pps.asset_id=@asset_id;							  
						  
--Update back to PSA Layer table
UPDATE psa.UK_BTC_IX_SPC_POSITION SET 
     row_status=@row_status_success
	 					FROM psa.UK_BTC_IX_SPC_POSITION ixp 
						INNER JOIN
						ser.PlanogramPosition pp 
						ON ixp.dbkey =pp.sourcekey AND  ixp.record_source_id=pp.LovRecordSourceID
						INNER JOIN
						((SELECT DISTINCT PlanogramPositionId ,SCDLovRecordSourceID ,psarowkey FROM ser.PlanogramPosition WHERE SCDACTiveFlag='Y' AND 
						   LOVRecordsourceID=12002) 
						   UNION ALL (SELECT DISTINCT PlanogramPositionId ,SCDLovRecordSourceID ,psarowkey FROM ser.PlanogramPositionProperty  WHERE SCDACTiveFlag='Y' AND 
						   LOVRecordsourceID=12002) 
								) temp
								ON temp.PlanogramPositionId=pp.PlanogramPositionId
								AND  temp.psarowkey=ixp.row_id
						WHERE 
							pp.LOVRecordSourceId = @record_source_id
						    AND ixp.Row_Status=@psaRowStatus							 
						    AND ixp.asset_id=@asset_id
							AND  ixp.row_id 
							NOT IN (
							SELECT DISTINCT rl.PSARowKey FROM psa.UK_BTC_IX_SPC_POSITION pps 
							JOIN [psa].[RuleEntityInstance] rl ON  pps.row_id = rl.PSARowKey 
							WHERE rl.EntityID = @psaEntityId AND rl.RuleID = @rule_id AND rl.ETLRunLogID=@serveETLRunLogID
							AND rl.RuleDetail not like '%DBParentFixtureKey%'
							)							;							  
--Update back to PSA Layer table for NULL case as well
UPDATE psa.UK_BTC_IX_SPC_POSITION SET 
     row_status=@row_status_success
	 						FROM psa.UK_BTC_IX_SPC_POSITION ixp 
						INNER JOIN
						ser.PlanogramPosition pp 
						ON ixp.dbkey =pp.sourcekey	AND  ixp.record_source_id=pp.LovRecordSourceID
						WHERE ixp.Row_Status=@psaRowStatus   
							AND ixp.asset_id=@asset_id
							AND pp.LOVRecordSourceId = @record_source_id
							AND (
							 NULLIF(ixp.locationid,'') IS NULL 
							 OR NULLIF(ixp.hfacings,'') IS NULL 
							 OR NULLIF(ixp.segment,'') IS NULL 
							 )
							 AND  ixp.row_id 
							NOT IN (
							SELECT DISTINCT rl.PSARowKey FROM psa.UK_BTC_IX_SPC_POSITION pps 
							JOIN [psa].[RuleEntityInstance] rl ON  pps.row_id = rl.PSARowKey 
							WHERE rl.EntityID = @psaEntityId AND rl.RuleID = @rule_id AND rl.ETLRunLogID=@serveETLRunLogID
							AND rl.RuleDetail not like '%DBParentFixtureKey%'
							);
--NON matching records update to quarantine , going to set as duplicate	
UPDATE psa.UK_BTC_IX_SPC_POSITION SET row_status=@row_status_duplicate 
WHERE row_status=@psaRowStatus AND asset_id= @asset_id AND  row_id 
NOT IN (
SELECT DISTINCT rl.PSARowKey FROM psa.UK_BTC_IX_SPC_POSITION pps 
JOIN [psa].[RuleEntityInstance] rl ON  pps.row_id = rl.PSARowKey 
WHERE rl.EntityID = @psaEntityId AND rl.RuleID = @rule_id AND rl.ETLRunLogID=@serveETLRunLogID
AND rl.RuleDetail not like '%DBParentFixtureKey%'
) 
PRINT 'End ----------------------------------------Current Asset ID: '+ CAST(@asset_id as varchar)+'';			
					 
SET @COUNTER = @COUNTER + 1    ;
END --outer loop end

COMMIT TRANSACTION;
END TRY
            BEGIN CATCH
                THROW;                   
                ROLLBACK TRANSACTION ;                       
            END CATCH
			
 END  
 
IF OBJECT_ID('psa.int_position_cursor_table') is not null
BEGIN
DROP TABLE [psa].[int_position_cursor_table];
END	
IF OBJECT_ID('ser.ser_positiontemp') IS NOT NULL
BEGIN
DROP TABLE ser.ser_positiontemp;
END
IF OBJECT_ID('ser.psa_positiontemp') IS NOT NULL
BEGIN
DROP TABLE ser.psa_positiontemp;
END
IF OBJECT_ID('ser.psa_productkey') IS NOT NULL
BEGIN
DROP TABLE ser.psa_productkey;
END
IF OBJECT_ID('ser.psa_skel_prod_check') IS NOT NULL
BEGIN
DROP TABLE ser.psa_skel_prod_check;
END
GO
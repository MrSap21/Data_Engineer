SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[psa].[sp_inc_cl_crp_merchandise]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_cl_crp_merchandise]
END
GO

CREATE PROC [psa].[sp_inc_cl_crp_merchandise] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max) AS 
/*
************************************************************************************************************
Procedure Name				: sp_inc_cl_crp_merchandise
Purpose						: Load Incremental data From International Chile 
Domain						: Merchandise
ServeLayer Target Tables	: Planogram, Planogramgroup, PlanogramIndicator, PlanogramProperty
RecordSourceID  for International Chile : 12001
*****************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for highest version  :  '9999-12-31' 
				SCDLOVRecordSourceId			:  12001 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
 */ 


	/*--Declarations---*/
	DECLARE @max_PlanogramId BIGINT,
	        @max_PlanogramGroupId BIGINT,
	        @cl_unitmeasureid_cm BIGINT,
			@cl_unitmeasureid_Unknown BIGINT,
	        @rowStatusPSACode BIGINT,	
	        @rowStatusSERCode BIGINT,
	        @rowStatusNotMigratedCode BIGINT,
	        @lovsourcekeytypeid BIGINT,
	        @lovparentkeytypeid BIGINT,
	        @cl_recordSourceId BIGINT,
	        @cl_measuretypeid BIGINT,
	        @merchandiseRecordSourceId BIGINT,
	        @SCDLOVRecordSourceId BIGINT, 
	        @lovindicatorkeytypeid BIGINT,
	        @shelfDepthMeasureId BIGINT,
	        @heightMeasureId BIGINT,
	        @buildSizeMeasureId BIGINT,
	        @COUNTER BIGINT,
	        @MAXID BIGINT,
	        @dateAdded VARCHAR (max),
	        @defaultSCDStartDate DATETIME,
	        @defaultSCDEndDate DATETIME,
	        @SCDStartDate DATETIME,
	        @SCDEndDate DATETIME;
			
			
			
   IF OBJECT_ID('psa.cl_Date_table') IS NOT NULL
	BEGIN
		DROP TABLE psa.cl_Date_table
	END
   
   PRINT 'Info: Drop date tempTable if exists ';
   
   CREATE TABLE psa.cl_Date_table
   (
    [RowID] [bigint] NOT NULL,
	[dateAdded] [nvarchar](500) NULL
   )
   WITH
	(
		DISTRIBUTION = REPLICATE,
		CLUSTERED COLUMNSTORE INDEX
	);
	
		/*-------------------------------Create temporary source table-------------------------------*/
	
	IF OBJECT_ID('psa.cl_crp_merchandise_temp') IS NOT NULL
	BEGIN
		drop table psa.cl_crp_merchandise_temp;
	END
   
   PRINT 'Info: temp Table if exists ';
   
   CREATE TABLE [psa].[cl_crp_merchandise_temp]
(
	[row_id] [bigint] NOT NULL,
	[db_key] [nvarchar](80) NULL,
	[pog_id] [nvarchar](80) NULL,
	[planogram_start_date] [nvarchar](25) NULL,
	[planogram_end_date] [nvarchar](25) NULL,
	[pog_description] [nvarchar](80) NULL,
	[shelf_depth] [nvarchar](255) NULL,
	[height] [nvarchar](255) NULL,
	[fitting_type] [nvarchar](255) NULL,
	[build_size] [nvarchar](255) NULL,
	[planner_family] [nvarchar](255) NULL,
	[footprint] [nvarchar](255) NULL,
	[category] [nvarchar](255) NULL,
	[format] [nvarchar](255) NULL,
	[promotional_site] [nvarchar](255) NULL,
	[date_added] [nvarchar](25) NULL,
	[etl_runlog_id] [int] NULL,
	[asset_id] [int] NULL,
	[record_source_id] [int] NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
);


BEGIN
	BEGIN TRANSACTION;
	
    SET @rowStatusPSACode = 26001
    SET @rowStatusSERCode = 26002
    SET @rowStatusNotMigratedCode = 26010	
    SET @cl_recordSourceId = 12001
	SET @SCDLOVRecordSourceId = 12001
	SET @merchandiseRecordSourceId = 12012
	SET @defaultSCDStartDate =  CONVERT(DateTime,'1900-01-01',126)
	SET @defaultSCDEndDate = CONVERT(DateTime,'9999-12-31',126)
	SET @SCDStartDate = current_timestamp
	SET @SCDEndDate = @SCDStartDate

	-- Child keytype
	SET @lovsourcekeytypeid = (select LOVId from [ser].[reflovsetinfo] where LOVsetName='Source Key Type' and LOVKey = 'Chile Planogram dbkey' and LOVRecordSourceId = @merchandiseRecordSourceId);
	
	-- Parent keytype
	SET @lovparentkeytypeid = (select LOVId from [ser].[reflovsetinfo] where LOVsetName='Source Key Type' and LOVKey = 'Chile Planogram Id(pog_id)' and LOVRecordSourceId = @merchandiseRecordSourceId);
	
	-- Indicator Id 
    SET @lovindicatorkeytypeid = (select LOVId from [ser].[reflovsetinfo] where LOVsetName='Indicator - CHILE Merchandise' and LOVKey = 'promotional_site' and LOVRecordSourceId = @cl_recordSourceId);	
	
	-- cm Unit Measure Id
	SET @cl_unitmeasureid_cm = (SELECT LOVId from [ser].[reflovsetinfo] where LOVKey = 'cm' AND LOVSetName = 'Unit of Measure' AND LOVRecordSourceId = @merchandiseRecordSourceId);
	
	-- Unknown Unit Measure Id
	SET @cl_unitmeasureid_Unknown = (SELECT LOVId from [ser].[reflovsetinfo] where LOVKey = 'Unknown' AND LOVSetName = 'Unit of Measure' AND LOVRecordSourceId = @merchandiseRecordSourceId);
	
	-- Measure Type Id
	SET @cl_measuretypeid = (SELECT LOVId from [ser].[RefLOVSetInfo] where LOVsetName='Measure Type' AND LovRecordSourceId = @merchandiseRecordSourceId AND LOVKey='PLANOGRAM_DIM');

    -- Shelf Depth measure id
	SET @shelfDepthMeasureId = (SELECT MeasureId FROM [ser].[measure] WHERE MeasureName = 'shelf_depth' AND LOVRecordSourceId = @cl_recordSourceId AND SCDActiveFlag = 'Y' AND LOVMeasureTypeId = @cl_measuretypeid );
	
	-- Height measure id
	SET @heightMeasureId = (SELECT MeasureId FROM [ser].[measure] WHERE MeasureName = 'height' AND LOVRecordSourceId = @cl_recordSourceId AND SCDActiveFlag = 'Y' AND LOVMeasureTypeId = @cl_measuretypeid );
	
	-- Build size measure id
	SET @buildSizeMeasureId = (SELECT MeasureId FROM [ser].[measure] WHERE MeasureName = 'build_size' AND LOVRecordSourceId = @cl_recordSourceId AND SCDActiveFlag = 'Y' AND LOVMeasureTypeId = @cl_measuretypeid );



   /* If the date_added value in the new file <= the date_added for the previous  data load , then change status of those records to 26010 */
   
   update [psa].[cl_crp_merchandise]       
        set row_status = @rowStatusNotMigratedCode
        where row_id in (
                    SELECT
                        A.row_id
                    from [psa].[cl_crp_merchandise] A
                    JOIN (select distinct pog_id,record_source_id,Max(date_added) as date_added from [psa].[cl_crp_merchandise]
                    where row_status = @rowStatusSERCode group by pog_id,record_source_id) B
                    on  A.pog_id=B.pog_id 
                    and A.record_source_id = B.record_source_id					
                    and A.date_added<=B.date_added
                    and A.row_status = @rowStatusPSACode
                );
	
	PRINT 'INFO : Completed row_status updation of source after checking previously processed dates'
	
	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_PlanogramId = COALESCE(MAX(PlanogramId),0) FROM [ser].[Planogram];
	
	/*-------------------------------Loading Parent records in Planogram table -------------------*/
	
	INSERT INTO [ser].[Planogram]
	(
	[PlanogramId]
	,[SourceKey]
	,[LOVSourceKeyTypeId]
	,[ParentPlanogramId]
	,[PlanogramStartDate]
	,[PlanogramEndDate]
	,[PlanogramName]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
	SELECT * FROM 
	(SELECT
		case when S.PlanogramId is NULL then (@max_PlanogramId + (DENSE_RANK() OVER(ORDER BY B.pog_id))) else S.PlanogramId end AS PlanogramId
		,B.[SourceKey]
		,B.[LOVSourceKeyTypeId]
		,B.[ParentPlanogramId]
		,B.[PlanogramStartDate]
		,B.[PlanogramEndDate]
		,B.[PlanogramName]
		,B.[LOVRecordSourceId]
		,B.[SCDStartDate]
		,@defaultSCDEndDate AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,(ISNULL(S.SCDVersion,0) + ROW_NUMBER() OVER (PARTITION BY B.pog_id ORDER BY B.SCDStartDate,B.psarowkey ASC)) AS [SCDVersion]
		,B.[SCDLOVRecordSourceId]
		,B.[ETLRunLogId]
		,B.[PSARowKey]
		FROM
			(select * from
			(
			SELECT
			src.pog_id as [pog_id]
            ,src.pog_id AS [SourceKey]
			,@lovparentkeytypeid AS [LOVSourceKeyTypeId]
			,NULL AS [ParentPlanogramId]
			,NULL AS [PlanogramStartDate]
			,NULL AS [PlanogramEndDate]
			,src.pog_description AS [PlanogramName]
			,@SCDStartDate as [SCDStartDate]
			,@cl_recordSourceId AS [LOVRecordSourceId]
			,NULL AS [SCDEndDate]
			,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			,ROW_NUMBER() OVER (partition by pog_id order by date_added desc) rno
			,row_status
			,etl_runlog_id
			FROM psa.cl_crp_merchandise src
			WHERE src.row_status=@rowStatusPSACode  
			AND (CASE  WHEN ( NULLIF(src.pog_description,'') IS NULL) THEN 0 ELSE 1 END)=1
			)a
		WHERE a.rno =1)B
		LEFT OUTER JOIN  (select PlanogramId,SourceKey,LOVRecordSourceId,ParentPlanogramId,max(SCDVersion) as SCDVersion from [ser].[Planogram] where LOVSourceKeyTypeId = @lovparentkeytypeid and LOVRecordSourceId =  @cl_recordSourceId group by PlanogramId,SourceKey,LOVRecordSourceId,ParentPlanogramId )S 
		ON  B.SourceKey = S.SourceKey 
		and B.LOVRecordSourceId = S.LOVRecordSourceId 
		and S.ParentPlanogramId is NULL )parent
		WHERE NOT EXISTS
        (SELECT 1 FROM ser.Planogram tgt 
		 where parent.PlanogramId = tgt.PlanogramId
		 AND parent.SourceKey = tgt.SourceKey 
		 AND parent.LOVRecordSourceId = tgt.LOVRecordSourceId 
		 AND ISNULL(parent.PlanogramName,'') = ISNULL(tgt.PlanogramName,'')
		 AND tgt.ParentPlanogramId is NULL
		 AND tgt.SCDActiveFlag = 'Y' )		
		;
		

--Updates the SCD Start Date,SCD Active Flag and  SCD End date 
	
	UPDATE [ser].[Planogram] 
	set SCDStartDate = F.SCDStartDate,
	    scdactiveflag = F.scdactiveflag,
		SCDEndDate 	= F.SCDEndDate
		from  [ser].[Planogram] P join
	(select 
	PlanogramId,
	case when A.scdenddate = @defaultSCDEndDate then @SCDStartDate else A.SCDStartDate end as SCDStartDate,
	case when A.scdenddate = @defaultSCDEndDate then 'Y' else 'N' end as scdactiveflag, 
	A.SCDEndDate,
	A.psarowkey 
	from
	(SELECT 
	PlanogramId,
	SCDStartDate,
	scdactiveflag,
    LEAD(@SCDEndDate,1,@defaultSCDEndDate) OVER (PARTITION BY [PlanogramId],[SourceKey]
    ORDER BY [SCDStartDate],psarowkey ASC) SCDEndDate ,
	psarowkey    
	FROM ser.Planogram 
    where  LOVRecordSourceId =@cl_recordSourceId  and SCDActiveFlag = 'Y'  and LOVSourceKeyTypeId = @lovparentkeytypeid
	and PlanogramId in (select distinct PlanogramId from ser.Planogram where LOVRecordSourceId = @cl_recordSourceId and LOVSourceKeyTypeId = @lovparentkeytypeid and psarowkey in (select distinct row_id from psa.cl_crp_merchandise))) A ) F
	ON P.psarowkey = F.psarowkey
	AND P.PlanogramId = F.PlanogramId
	where P.LOVRecordSourceId =@cl_recordSourceId ;
	
	-- Updates the SCD Start Date of first inserted record to '1900-01-01'

	UPDATE [ser].[Planogram]
	set SCDStartDate = @defaultSCDStartDate
	where SCDVersion = 1 and LOVRecordSourceId =@cl_recordSourceId  and LOVSourceKeyTypeId = @lovparentkeytypeid 
	and PlanogramId in (select distinct PlanogramId from ser.Planogram where LOVRecordSourceId = @cl_recordSourceId and LOVSourceKeyTypeId = @lovparentkeytypeid and psarowkey in (select distinct row_id from psa.cl_crp_merchandise )) 
	;			
		
	PRINT 'Info : Completed insertion of International Chile Incremental source parent data to Planogram table'
		
	

	
   /*----------------------------- Checking for multiple dates added and processing for each date -------------------------*/
  
	
	/* Load Data to cl_Date_table	*/
	
	INSERT INTO psa.cl_Date_table 
	(
	[RowID]
	,[dateAdded]
	)
		SELECT  
			DISTINCT DENSE_RANK() OVER(ORDER BY (date_added)) AS [RowID],
			date_added AS [dateAdded]
		FROM psa.cl_crp_merchandise
			WHERE [row_status]=@rowStatusPSACode;
	
	PRINT 'Info: Date table loaded ';


 BEGIN TRY
 
	SET @COUNTER = 1
	SET @MAXID = (SELECT COUNT(*) FROM psa.cl_Date_table)

	
	
WHILE (@COUNTER <= @MAXID)
BEGIN

    SELECT @dateAdded = dateAdded FROM psa.cl_Date_table WHERE  RowID=@Counter;
	
	SET @SCDStartDate = current_timestamp
	SET @SCDEndDate = @SCDStartDate
	
	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_PlanogramId = COALESCE(MAX(PlanogramId),0) FROM [ser].[Planogram];
	SELECT @max_PlanogramGroupId = COALESCE(MAX(PlanogramGroupId),0) FROM [ser].[PlanogramGroup];


    PRINT 'Info: Processing cl_crp_merchandise FOR Date : '+@dateAdded+'';

    PRINT 'Info: Loading temp Table  : ';
	
	INSERT INTO psa.cl_crp_merchandise_temp
	(
	[row_id],
	[db_key],
	[pog_id],
	[planogram_start_date],
	[planogram_end_date],
	[pog_description],
	[shelf_depth],
	[height],
	[fitting_type],
	[build_size],
	[planner_family],
	[footprint],
	[category],
	[format],
	[promotional_site],
	[date_added],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp]
	)
	SELECT * from [psa].[CL_CRP_MERCHANDISE] where [row_status]=@rowStatusPSACode and date_added = @dateAdded;

	PRINT 'Info : Completed insertion of International Chile source data to temporary table temp table cl_crp_merchandise_temp'


    /*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_PlanogramId = COALESCE(MAX(PlanogramId),0) FROM [ser].[Planogram] ;	
	
	/*-------------------------------Loading child records in Planogram table--------------------------------------*/
 
	
     INSERT INTO [ser].[Planogram] 
	([PlanogramId]
	,[SourceKey]
	,[LOVSourceKeyTypeId]
	,[ParentPlanogramId]
	,[PlanogramStartDate]
	,[PlanogramEndDate]
	,[PlanogramName]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
SELECT
	[PlanogramId]
	,[SourceKey]
	,[LOVSourceKeyTypeId]
	,[ParentPlanogramId]
	,CASE WHEN (PlanogramStartDate = '' or PlanogramStartDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramStartDate END AS [PlanogramStartDate]
	,CASE WHEN (PlanogramEndDate = '' or PlanogramEndDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramEndDate END AS [PlanogramEndDate]
	,[PlanogramName]
	,[LOVRecordSourceId]
	,case when (ROW_NUMBER() OVER (PARTITION BY SourceKey,pog_id,PlanogramStartDate,PlanogramEnddate,date_added ORDER BY date_added,[PSARowKey]) = 1) then @defaultSCDStartDate else SCDStartDate end as [SCDStartDate] 
	,LEAD(@SCDEndDate,1,@defaultSCDEndDate) OVER (PARTITION BY SourceKey,pog_id,PlanogramStartDate,PlanogramEnddate,date_added ORDER BY date_added,[PSARowKey]) AS [SCDEndDate]
	,LEAD('N',1,'Y') OVER (PARTITION BY SourceKey,pog_id,PlanogramStartDate,PlanogramEnddate,date_added ORDER BY date_added,[PSARowKey]) AS [SCDActiveFlag]
	,ROW_NUMBER() OVER (PARTITION BY SourceKey,pog_id,PlanogramStartDate,PlanogramEnddate,date_added ORDER BY date_added,[PSARowKey])  AS [SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
FROM
	(
      SELECT distinct
        (@max_PlanogramId + (DENSE_RANK() OVER(ORDER BY db_key,pog_id,planogram_start_date,planogram_end_date,date_added)))  AS PlanogramId
		,src.db_key AS [SourceKey]
		,@lovsourcekeytypeid AS [LOVSourceKeyTypeId]
		,lkp_plan.PlanogramId AS [ParentPlanogramId]
		,src.planogram_start_date AS [PlanogramStartDate]
		,src.planogram_end_date AS [PlanogramEndDate]
		,src.pog_description AS [PlanogramName]
		,@cl_recordSourceId AS [LOVRecordSourceId]
		,@SCDStartDate AS [SCDStartDate]
		,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		,src.row_id AS [PSARowKey]
		,src.pog_id AS [pog_id]
		,src.date_added as date_added
		FROM
		(select * from 
		(select *,row_number() over (partition by pog_id,db_key,planogram_start_date,planogram_end_date,date_added,pog_description order by row_id) as r
         from psa.cl_crp_merchandise_temp where date_added = @dateAdded)A where r=1) src 
		JOIN
		(select SourceKey,max(PlanogramId) as PlanogramId from [ser].[Planogram] where LOVSourceKeyTypeId = @lovparentkeytypeid and LOVRecordSourceId = @cl_recordSourceId and SCDActiveFlag = 'Y' group by SourceKey) lkp_plan
		ON lkp_plan.SourceKey = src.pog_id
		WHERE src.date_added = @dateAdded and (CASE  WHEN ( NULLIF(src.pog_description,'' ) IS NULL )  
										THEN 0
										ELSE 1 
								END
								)=1		
								)A
     ;


	PRINT 'Info : Completed insertion of International Chile Incremental source child data to Planogram table'
	

	/*--------------------------Loading Planogramgroup table---------------------------*/
	
INSERT INTO [ser].[PlanogramGroup]
	([PlanogramGroupId]
	,[PlanogramId]
	,[LOVPlanogramGroupSetId]
	,[LOVGroupId]
	,[ParentPlanogramGroupId]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
	SELECT
		(@max_PlanogramGroupId + (dense_rank() over (order by a.PlanogramId,a.LOVGroupId asc))) AS [PlanogramGroupId]
		,a.[PlanogramId]
		,a.[LOVPlanogramGroupSetId]
		,a.[LOVGroupId]
		,a.[ParentPlanogramGroupId]
		,a.[LOVRecordSourceId]
		,case when (ROW_NUMBER() OVER (PARTITION BY a.PlanogramId,a.LOVGroupId ORDER BY [PSARowKey]) = 1) then @defaultSCDStartDate else a.SCDStartDate end as [SCDStartDate] 
		,LEAD(@SCDEndDate,1,@defaultSCDEndDate) OVER (PARTITION BY a.PlanogramId,a.LOVGroupId ORDER BY [PSARowKey]) AS [SCDEndDate]
	    ,LEAD('N',1,'Y') OVER (PARTITION BY a.PlanogramId,a.LOVGroupId ORDER BY [PSARowKey]) AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY a.PlanogramId,a.LOVGroupId ORDER BY [PSARowKey]) AS [SCDVersion]
		,a.[SCDLOVRecordSourceId]
		,a.[ETLRunLogId]
		,a.[PSARowKey]
		FROM
		(
		   SELECT 
		     p.[PlanogramId] as PlanogramId
			,lkp_refl.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,@cl_recordSourceId AS [LOVRecordSourceId]
			,@SCDStartDate AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.PSARowKey AS [PSARowKey]
			FROM 
		    (select * from 
			(SELECT
			 db_key AS [SourceKey]
			,row_id AS [PSARowKey]
			,ISNULL(planogram_start_date,'') as PlanogramStartDate
			,ISNULL(planogram_end_date,'') as PlanogramEndDate
			,ColumnValue
			,ColumnName
			,row_number() over (partition by db_key,ISNULL(planogram_start_date,''),ISNULL(planogram_end_date,''),ColumnName,ColumnValue order by row_id) as r
			FROM psa.cl_crp_merchandise_temp 
			UNPIVOT
			([ColumnValue] for [ColumnName] in ([fitting_type],[planner_family],[footprint], [category], [format])) as U 
			where date_added = @dateAdded)A
			where r=1
			)src
			JOIN 
			(select SourceKey,PlanogramStartDate,PlanogramEndDate,max(PlanogramId) as PlanogramId from ser.Planogram where lovrecordsourceid = @cl_recordSourceId and lovsourcekeytypeid = @lovsourcekeytypeid and SCDActiveFlag = 'Y' AND ETLRunLogId = @serveETLRunLogID group by SourceKey,PlanogramStartDate,PlanogramEndDate) p
			ON  src.SourceKey = p.SourceKey
			AND ISNULL(src.PlanogramStartDate,'') = ISNULL(p.PlanogramStartDate,'')
			AND ISNULL(src.PlanogramEndDate,'') = ISNULL(p.PlanogramEndDate,'')
		    JOIN
			(select LOVId,LOVKey,LOVSetID,LOVsetName from [ser].[reflovsetinfo] where LOVRecordSourceId = @cl_recordSourceId) lkp_refl
			ON trim(src.ColumnValue) = trim(lkp_refl.LOVKey)
            AND lkp_refl.LOVsetName = src.ColumnName		
			WHERE src.ColumnValue IS NOT NULL AND src.ColumnValue <> '' 
		)a
		;
						
					
						
    PRINT 'Info : Completed insertion of International Chile Incremental source data to Planogram Group table'


	/*---------------------------------Loading PlanogramIndicator table---------------------------------*/
	
	
INSERT INTO [ser].[PlanogramIndicator]
	([PlanogramId]
	,[LovIndicatorId]
	,[Value]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
  SELECT
	a.[PlanogramId]
	,a.[LovIndicatorId]
	,a.[Value]
	,a.[LOVRecordSourceId]
	,case when (ROW_NUMBER() OVER (PARTITION BY a.PlanogramId,a.LovIndicatorId ORDER BY [PSARowKey]) = 1) then @defaultSCDStartDate else a.SCDStartDate end as [SCDStartDate] 
	,LEAD(@SCDEndDate,1,@defaultSCDEndDate) OVER (PARTITION BY a.PlanogramId,a.LovIndicatorId ORDER BY [PSARowKey]) AS [SCDEndDate]
	,LEAD('N',1,'Y') OVER (PARTITION BY a.PlanogramId,a.LovIndicatorId ORDER BY [PSARowKey]) AS [SCDActiveFlag]
	,ROW_NUMBER() OVER (PARTITION BY a.PlanogramId,a.LovIndicatorId ORDER BY [PSARowKey])  as [SCDVersion]
	,a.[SCDLOVRecordSourceId]
	,a.[ETLRunLogId]
	,a.[PSARowKey]
	FROM
	(
	  select * from 
		(SELECT distinct
		 p.PlanogramId AS [PlanogramId]
		,@lovindicatorkeytypeid AS [LovIndicatorId]
		,src.promotional_site AS [Value]
		,@cl_recordSourceId AS [LOVRecordSourceId]
		,@SCDStartDate AS [SCDStartDate]
		,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		,src.row_id AS [PSARowKey]
		,row_number() over (partition by p.PlanogramId,src.promotional_site order by src.row_id) as r
		FROM psa.cl_crp_merchandise_temp src
		JOIN 
	    (select SourceKey,PlanogramStartDate,PlanogramEndDate,max(PlanogramId) as PlanogramId from ser.Planogram where lovrecordsourceid = @cl_recordSourceId and lovsourcekeytypeid = @lovsourcekeytypeid and SCDLOVRecordSourceId = @SCDLOVRecordSourceId and SCDActiveFlag = 'Y' AND ETLRunLogId = @serveETLRunLogID group by SourceKey,PlanogramStartDate,PlanogramEndDate) p
	    ON  src.db_key = p.SourceKey 
		AND ISNULL(src.planogram_start_date,'') = ISNULL(p.PlanogramStartDate,'')
		AND ISNULL(src.planogram_end_date,'') = ISNULL(p.PlanogramEndDate,'')
		WHERE src.date_added = @dateAdded and src.promotional_site IS NOT NULL AND src.promotional_site <> '')A
		where r=1
	)a 	
	;


	PRINT 'Info : Completed insertion of International Chile Incremental source data to Planogram Indicator table'
	

	/*--------------------------------Loading Planogram Property table---------------------------------*/
	
	
INSERT INTO [ser].[PlanogramProperty]
	(
	[PlanogramId]
    ,[MeasureId]
    ,[LOVUOMId]
    ,[Value]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
    SELECT
		 a.[PlanogramId]
		,a.[MeasureId]
		,a.[LOVUOMId]
		,a.[Value]
		,a.[LOVRecordSourceId]
		,case when (ROW_NUMBER() OVER (PARTITION BY a.PlanogramId,a.MeasureId,a.LOVUOMId ORDER BY [PSARowKey]) = 1) then @defaultSCDStartDate else @SCDStartDate end as [SCDStartDate] 
	    ,LEAD(@SCDEndDate,1,@defaultSCDEndDate) OVER (PARTITION BY a.PlanogramId,a.MeasureId,a.LOVUOMId ORDER BY [PSARowKey]) AS [SCDEndDate]
	    ,LEAD('N',1,'Y') OVER (PARTITION BY a.PlanogramId,a.MeasureId,a.LOVUOMId ORDER BY [PSARowKey]) AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY a.PlanogramId,a.MeasureId,a.LOVUOMId ORDER BY [PSARowKey])  as [SCDVersion]
		,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		,a.[PSARowKey]
		FROM
		(
		  SELECT p.PlanogramId,
		  src.*
		  FROM 
			(
			select * from 
			(SELECT
			CASE
				WHEN ColumnName ='shelf_depth' THEN @cl_unitmeasureid_cm
				WHEN ColumnName ='height' THEN @cl_unitmeasureid_cm
				WHEN ColumnName ='build_size' THEN @cl_unitmeasureid_Unknown 
			END AS [LOVUOMId]
			,@cl_recordSourceId AS [LOVRecordSourceId]
			,row_id AS [PSARowKey]
			,db_key AS [SourceKey]
			,ISNULL(planogram_start_date,'')  AS [PlanogramStartDate]
			,ISNULL(planogram_end_date,'') AS [PlanogramEndDate]
			,[ColumnName] 
			,[ColumnValue] as [Value]
			,CASE
				WHEN ColumnName ='shelf_depth' THEN @shelfDepthMeasureId
				WHEN ColumnName ='height' THEN @heightMeasureId
				WHEN ColumnName ='build_size' THEN @buildSizeMeasureId
			END AS [MeasureId]
			,row_number() over (partition by db_key,[ColumnName],[ColumnValue] order by row_id) AS r
			FROM psa.cl_crp_merchandise_temp 
			UNPIVOT
		    (
		    	ColumnValue FOR ColumnName IN (shelf_depth, height, build_size)
		    ) U		
		    where date_added = @dateAdded and ColumnValue IS NOT NULL AND ColumnValue <> '')A
			where r=1
			)src
			JOIN 
	        (select SourceKey,PlanogramStartDate,PlanogramEndDate,max(PlanogramId) as PlanogramId from ser.Planogram where lovrecordsourceid = @cl_recordSourceId and lovsourcekeytypeid = @lovsourcekeytypeid  and SCDActiveFlag = 'Y'  and SCDLOVRecordSourceId = @SCDLOVRecordSourceId AND ETLRunLogId = @serveETLRunLogID group by SourceKey,PlanogramStartDate,PlanogramEndDate) p
	        ON  src.SourceKey = p.SourceKey
            AND ISNULL(src.PlanogramStartDate,'') = ISNULL(p.PlanogramStartDate,'')
			AND ISNULL(src.PlanogramEndDate,'') = ISNULL(p.PlanogramEndDate,'')	
		
		)a
	;
			
	
		PRINT 'Info : Completed insertion of International Chile Incremental source data to Planogram Property table'
		
	
	--  Update status of records in CL_CRP_MERCHANDISE to 26002
		
			UPDATE [psa].[CL_CRP_MERCHANDISE] SET [row_status]=@rowStatusSERCode
                FROM [psa].[CL_CRP_MERCHANDISE] cl  
				INNER JOIN 
				(
				(SELECT distinct psarowkey FROM ser.Planogram WHERE LOVRecordsourceID=@cl_recordSourceId AND ETLRunLogId = @serveETLRunLogID)
				UNION ALL  
				(SELECT distinct psarowkey FROM ser.PlanogramGroup WHERE  LOVRecordsourceID=@cl_recordSourceId AND ETLRunLogId = @serveETLRunLogID)
				UNION ALL  
				(SELECT distinct psarowkey FROM ser.PlanogramProperty  WHERE LOVRecordsourceID=@cl_recordSourceId AND ETLRunLogId = @serveETLRunLogID)
				UNION ALL  
				(SELECT distinct psarowkey FROM ser.PlanogramIndicator  WHERE  LOVRecordsourceID=@cl_recordSourceId AND ETLRunLogId = @serveETLRunLogID)
				)temp
				ON  temp.psarowkey = cl.row_id
                WHERE cl.row_status=@rowStatusPSACode and date_added = @dateAdded;
				
				
			UPDATE [psa].[CL_CRP_MERCHANDISE] SET [row_status]=@rowStatusSERCode
                FROM [psa].[CL_CRP_MERCHANDISE] cl 
                INNER JOIN  [ser].[Planogram] p ON cl.pog_id=p.SourceKey and cl.record_source_id=p.LovRecordSourceID
				and  LOVSourceKeyTypeId=@lovparentkeytypeid 
			WHERE cl.row_status=@rowStatusPSACode and date_added = @dateAdded 
			AND ((NULLIF(cl.pog_description,'' ) IS NULL ) 
            OR 
			(  NULLIF(cl.fitting_type,'') IS NULL OR 
			   NULLIF(cl.planner_family,'') IS NULL OR 
			   NULLIF(cl.footprint,'') IS NULL OR 
			   NULLIF(cl.category,'') IS NULL  OR  
			   NULLIF(cl.format,'') IS NULL OR 
			   NULLIF(cl.promotional_site ,'') IS NULL OR 
			   NULLIF(cl. shelf_depth,'') IS NULL  OR 
			   NULLIF(cl.height ,'') IS NULL  OR 
			   NULLIF(cl.build_size ,'') IS NULL));
			
			
			
		PRINT 'Info: Update the psa layer table with row_status  duplicate code'; 
        
            UPDATE psa.cl_crp_merchandise  
		    SET row_status = @rowStatusNotMigratedCode                                                                              
            WHERE row_status = @rowStatusPSACode
            AND date_added = @dateAdded;
		
		
				
	     PRINT 'Info : Updated Row Status to ''Loaded to Serve'' for psa.[cl_crp_merchandise] International Chile '
		 
		 
		 


        	-- UPDATE COUNTER
		SET @COUNTER = @COUNTER + 1	;
	END

    COMMIT TRANSACTION;					
		END TRY
	    BEGIN CATCH
				THROW;
				ROLLBACK TRANSACTION ;	
			END CATCH 
    	



END 
GO
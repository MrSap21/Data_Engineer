/****** Object:  StoredProcedure [psa].[sp_inc_uk_base_plan_product]    Script Date: 04/09/2020 10:59:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*************************************************************************************************************************************************************************
Procedure Name                      : sp_inc_uk_base_plan_product
Purpose                             : Load Incremental daily data From Base Plan Product table in psa layer(SAP BW) into Serve Layer Table
Domain                              : Merchandise
ServeLayer Target Tables            : Total 5 tables involved
                                      Through SP           -> FactInstance,FactDimensionInstance
                                      DML One Off Insert   -> Fact,Dimension,FactDimension
RecordSourceID for base_plan_product  : 12006
*************************************************************************************************************************************************************************
Modification History
*************************************************************************************************************************************************************************
04-Aug-20  : Incorporated BUK_ROI_Merchandise_Incremental_v1.3 mapping changes
*************************************************************************************************************************************************************************/

IF OBJECT_ID('[psa].[sp_inc_uk_base_plan_product]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_uk_base_plan_product] 
END
GO

CREATE PROC [psa].[sp_inc_uk_base_plan_product] @serveETLRunLogID [varchar](MAX),@tableName [varchar](200),@psaEntityId [varchar](MAX) AS

----drop temp table if exists
IF OBJECT_ID('ser.TmpBasePlanProduct_Inc') IS NOT NULL
BEGIN
DROP TABLE ser.TmpBasePlanProduct_Inc;
END

-----create temp table
CREATE TABLE [ser].[TmpBasePlanProduct_Inc]
(
[row_num] [bigint] NOT NULL,
planogramid [bigint]  NULL,
productid [bigint]  NULL,
calender_id [bigint]  NULL,
fiscal_id [bigint]  NULL,
row_id [bigint] NOT NULL,
pogid [nvarchar](200)  NULL,
article_id [nvarchar](200)  NULL,
calendar_week [nvarchar](200)  NULL,
fiscal_week [nvarchar](200)  NULL,
record_source_id [int] NOT NULL,
row_status [bigint] NULL,
etl_runlog_id [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([row_num],[record_source_id])
)
BEGIN
BEGIN TRANSACTION;

--Declare Variables
DECLARE 
			@max_FactInstanceID bigint,
			@psaRowStatus int, 
			@serRowStatus int,
			@planogram_type_id int,
			@fact_type_id int,
			@planogramDimId bigint,
			@productDimId bigint,
			@SCDStartDate datetime=(SELECT CONVERT(DateTime,'1900-01-01')),
			@SCDEndDate datetime= (SELECT CONVERT(DateTime,'9999-12-31')),
			@SCDActiveFlag char='Y',
			@SCDVersion smallint=1,
			@LOVRecordSourceId int =12006,
			@PlnLOVRecordSourceId int =12002,
			@RefLOVRecordSourceId int =12012,
			@SCDLOVRecordSourceId int =12006;

--Set Maximum factInstnace id from the table  ser.FactInstance and Rowstatus values for both PSA and SERVE Layer
SET @max_FactInstanceId=(SELECT COALESCE(MAX(FactInstanceId),0)  from ser.FactInstance);
SET @psaRowStatus=26001;
SET @serRowStatus=26002;

/*-------Derive the lookup table constant values and Set to Variables-------*/
SET @planogram_type_id= (SELECT rl.LovId from ser.RefLOVSetInfo rl where rl.LOVKey = 'Intactix Planogram Id(value50)' AND rl.LOVSetName = 'Source Key Type' and rl.LOVRecordSourceId = @RefLOVRecordSourceId);  
SET @fact_type_id = (SELECT rl.LovId from ser.RefLOVSetInfo rl where rl.LOVKey = 'TBC' AND rl.LOVSetName = 'Fact Type' AND rl.LOVRecordSourceId =@RefLOVRecordSourceId);
SET @planogramDimId =( select DimensionId from ser.Dimension where Name = 'Planogram' and LOVRecordSourceId = @PlnLOVRecordSourceId);
SET @productDimId = (select DimensionId from ser.Dimension where Name = 'Product' and LOVRecordSourceId = @PlnLOVRecordSourceId);
BEGIN TRY
---INSERT TO TEMP TABLE
INSERT INTO  ser.TmpBasePlanProduct_Inc

select ROW_NUMBER() OVER (ORDER BY row_id) + @max_FactInstanceId row_num,
(case when 
(SELECT COUNT(PlanogramId) FROM (select PlanogramId,LOVSourceKeyTypeId,LOVRecordSourceId,SCDActiveFlag from ser.Planogram pl where pl.sourcekey = bp.pogid 
AND pl.LOVSourceKeyTypeId = @planogram_type_id and pl.LOVRecordSourceId=@PlnLOVRecordSourceId AND pl.SCDActiveFlag = 'Y'
group by LOVSourceKeyTypeId,LOVRecordSourceId,PlanogramId,SCDActiveFlag) SS)=1 THEN (select  PlanogramId from ser.Planogram pl where pl.sourcekey = bp.pogid
AND pl.LOVSourceKeyTypeId = @planogram_type_id and pl.LOVRecordSourceId=@PlnLOVRecordSourceId AND pl.SCDActiveFlag = 'Y' ) ELSE NULL END)planogramid,
pp.ProductId as productid,
cw.LOVId as calender_id,
fw.LOVId as fiscal_id,
row_id,
pogid,
article_id,
calendar_week,
fiscal_week,
record_source_id,
row_status,
CAST(@serveETLRunLogID AS INT) etl_runlog_id
from psa.uk_base_plan_product bp 
--AND bp.etl_runlog_id in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,','));
left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
                            ser.RefLOVSetInfo rl
                            where rl.LOVSetName = 'calendar_week' and rl.LOVRecordSourceId = @LOVRecordSourceId)cw
                             on bp.record_source_id=cw.LOVRecordSourceId and  cw.LOVKey = bp.calendar_week

left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
                            ser.RefLOVSetInfo rl
                            where rl.LOVSetName = 'fiscal_week' and rl.LOVRecordSourceId = @LOVRecordSourceId)fw
                             on bp.record_source_id=fw.LOVRecordSourceId and  fw.LOVKey = bp.fiscal_week

left join ser.Product pp ON  pp.SourceKey=bp.article_id AND pp.LOVRecordSourceId = @PlnLOVRecordSourceId  AND pp.SCDActiveFlag = 'Y' 

where bp.row_status =@psaRowStatus;



--select * from #tempTable_BPP
 
/********************************************************************************************************************************
1.	Table Name  :FactInstance 
	
**********************************************************************************************************************************/
WITH FactInstanceCTE AS 
(select temp.row_num factInstanceId,temp.record_source_id,temp.row_id,f.factId,fd.DimensionId from ser.TmpBasePlanProduct_Inc temp join ser.FactDimension fd 
on temp.record_source_id = fd.LovRecordSourceId 
join ser.Fact f on 
fd.factId=f.factId where f.factName='BASE PLAN PRODUCT' and f.LOVFactTypeId = @fact_type_id
and  f.LOVrecordSourceId=@LOVRecordSourceId and f.SCDActiveFlag = 'Y')

INSERT INTO ser.FactInstance(FactInstanceId,FactId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)		
						SELECT
						distinct(fi.factInstanceId) FactInstanceId,
								fi.factId Factid,
								@LOVRecordSourceId LOVRecordSourceID,
								@SCDStartDate SCDStartDate,
								@SCDEndDate SCDEndDate,
								@SCDActiveFlag SCDActiveFlag,
								@SCDVersion SCDVersion,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								@serveETLRunLogID ETLRunLogId,
								fi.row_id PSARowKey
									FROM FactInstanceCTE fi							   
			   
						PRINT ' Info : FactInstance  Table Loaded Successfully' ;
/********************************************************************************************************************************
2.	Table Name  :FactDimensionInstance 
	
**********************************************************************************************************************************/
UPDATE  [ser].[FactDimensionInstance]
        SET DimensionSurrogateKey = lkp_plan.PlanogramId
        FROM
        [ser].[FactDimensionInstance] src
        JOIN
        (select PlanogramId,SourceKey from [ser].[Planogram] where SCDActiveFlag='Y' and Lovrecordsourceid=@PlnLOVRecordSourceId AND LOVSourceKeyTypeId = @planogram_type_id and SCDLOVRecordSourceId = @PlnLOVRecordSourceId )lkp_plan
        ON src.DimensionSourceKey = lkp_plan.SourceKey
        JOIN
        (select DimensionSourceKey,count(*) as cnt  from
        (select distinct p.DimensionSourceKey,plano.PlanogramId
        from [ser].[FactDimensionInstance] p
        join
        (select PlanogramId,SourceKey from [ser].[Planogram] where SCDActiveFlag='Y' and Lovrecordsourceid=@PlnLOVRecordSourceId AND LOVSourceKeyTypeId = @planogram_type_id and SCDLOVRecordSourceId = @PlnLOVRecordSourceId)plano
        ON p.DimensionSourceKey = plano.SourceKey )A group by DimensionSourceKey having count(*)=1)lkp_pog
        ON lkp_plan.SourceKey = lkp_pog.DimensionSourceKey
        where src.DimensionSurrogateKey is NULL and src.DimensionId = @planogramDimId and src.LOVRecordSourceId = @LOVRecordSourceId and src.ETLRunLogId = @serveETLRunLogID and src.SCDLOVRecordSourceId =@SCDLOVRecordSourceId ;
		
UPDATE [ser].[FactDimensionInstance]
		SET DimensionSurrogateKey = lkp_prod.ProductId
		FROM
		[ser].[FactDimensionInstance] src
		JOIN
		(select * from [ser].[product] where SCDActiveFlag = 'Y' AND LOVRecordSourceId = @PlnLOVRecordSourceId and SCDLOVRecordSourceId = @PlnLOVRecordSourceId) lkp_prod
		ON lkp_prod.SourceKey = src.DimensionSourceKey
		AND src.LOVRecordSourceId = lkp_prod.LOVRecordSourceId
		where src.DimensionSurrogateKey is NULL and src.DimensionId = @productDimId and src.LOVRecordSourceId = @LOVRecordSourceId and src.ETLRunLogId = @serveETLRunLogID and src.SCDLOVRecordSourceId =@SCDLOVRecordSourceId;		


WITH FactDimesionInstanceCTE AS 
(select temp.row_num factInstanceId,temp.article_id,temp.pogid,temp.calendar_week,temp.fiscal_week,temp.calender_id,temp.fiscal_id,temp.planogramid,temp.ProductId,temp.record_source_id,temp.row_id,f.factId,fd.DimensionId from ser.TmpBasePlanProduct_Inc temp join ser.FactDimension fd 
on temp.record_source_id = fd.LovRecordSourceId 
join ser.Fact f on 
fd.factId=f.factId where f.factName='BASE PLAN PRODUCT' and f.LOVFactTypeId = @fact_type_id
and  f.LOVrecordSourceId=@LOVRecordSourceId and f.SCDActiveFlag = 'Y')


--select * from ser.FactDimensionInstance where LOVRecordSourceId = 12006
INSERT INTO ser.FactDimensionInstance(
				[FactInstanceId],[DimensionId], [DimensionSurrogateKey],[DimensionSourceKey],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId] ,[ETLRunLogId], [PSARowKey] )	
SELECT 
									fdi.factInstanceId FactInstanceId,
									fdi.DimensionId DimensionId,
									fdi.planogramId	DimensionSurrogateKey,   
									fdi.pogid	[DimensionSourceKey],   
									@LOVRecordSourceId	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
									fdi.row_id PSARowKey									
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='planogram' and d.LOVRecordSourceId = @PlnLOVRecordSourceId
UNION ALL								

SELECT 
									fdi.factInstanceId FactInstanceId,
									fdi.DimensionId DimensionId,
									fdi.ProductId	DimensionSurrogateKey,   
									fdi.article_id	[DimensionSourceKey],   
									@LOVRecordSourceId	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
									fdi.row_id PSARowKey
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='product' and d.LOVRecordSourceId = @PlnLOVRecordSourceId
UNION ALL

SELECT 
									fdi.factInstanceId FactInstanceId,
									fdi.DimensionId DimensionId,
									fdi.calender_id	DimensionSurrogateKey,   
									fdi.calendar_week	[DimensionSourceKey],   
									@LOVRecordSourceId	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
									fdi.row_id PSARowKey
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='calendar_week' and d.LOVRecordSourceId = @LOVRecordSourceId
UNION ALL

SELECT 
									fdi.factInstanceId FactInstanceId,
									fdi.DimensionId DimensionId,
									fdi.fiscal_id	DimensionSurrogateKey,   
									fdi.fiscal_week	[DimensionSourceKey],   
									@LOVRecordSourceId	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
									fdi.row_id PSARowKey
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='fiscal_week' and d.LOVRecordSourceId = @LOVRecordSourceId;
								
								PRINT ' Info : FactDimesnionInstance  Table Loaded Successfully';
/********************************************************************************************************************************
3.	Update Source Table  :psa.uk_base_plan_product 
	Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
**********************************************************************************************************************************/
PRINT '********************Updating Source Table accordingly -> psa.uk_base_plan_product****************';  

				UPDATE psa.uk_base_plan_product SET [row_status]=@serRowStatus
                FROM psa.uk_base_plan_product bpp
                JOIN
                (select distinct FactInstanceId,PSARowKey,LOVRecordSourceId,SCDLOVRecordSourceId FROM [ser].[FactInstance]
                where [LOVRecordSourceId] = @LOVRecordSourceId
                and ETLRunLogId = @serveETLRunLogID
				and SCDLOVRecordSourceId = @SCDLOVRecordSourceId)temp
                ON bpp.row_id = temp.PSARowKey
                AND bpp.record_source_id = temp.LOVRecordSourceId
                WHERE bpp.row_status=@psaRowStatus;
PRINT 'Info: Source Table Updated accordingly -> psa.uk_base_plan_product'; 		
COMMIT TRANSACTION;
END TRY
BEGIN CATCH 
	THROW;
	   ROLLBACK TRANSACTION ;
END CATCH 
drop table [ser].[TmpBasePlanProduct_Inc]
PRINT 'Info: Dropped Temp table -> ser.TmpBasePlanProduct_Inc';
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[psa].[sp_inc_no_crp_layout_performance]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_no_crp_layout_performance] 
END
GO

CREATE PROC [psa].[sp_inc_no_crp_layout_performance] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max) AS

BEGIN

	DECLARE @rowStatusPSACode BIGINT
	DECLARE	@rowStatusSERCode BIGINT
	DECLARE @LOVRecordSourceId BIGINT
	DECLARE @RecordSourceIdMerchandise BIGINT
	DECLARE @SCDLOVRecordSourceId BIGINT
	DECLARE @crpLayoutFactId BIGINT
	DECLARE @pogIdTypeId BIGINT
	DECLARE @storeDimId BIGINT
	DECLARE @storeLOVID BIGINT
	DECLARE @floorDimId BIGINT
	DECLARE @weekDimId BIGINT
	DECLARE @planogramDimId BIGINT
	DECLARE @measureTypeId BIGINT
	DECLARE @unitId BIGINT;
	DECLARE @tespId BIGINT;
	DECLARE @tispId BIGINT;
	DECLARE @eposProfitId BIGINT;
	DECLARE @modularSpaceId BIGINT;
	DECLARE @max_FactInstanceId BIGINT
	DECLARE @rowStatusNotmigratedCode BIGINT
	DECLARE @SCDVersion SMALLINT
	DECLARE @SCDActiveFlag CHAR
	
	SET @rowStatusPSACode = 26001
	SET @rowStatusSERCode = 26002
	SET @LOVRecordSourceId = 12005
	SET @RecordSourceIdMerchandise = 12012
	SET @SCDLOVRecordSourceId = 12005
	SET @rowStatusNotmigratedCode = 26010
	SET @SCDVersion = 1
	SET @SCDActiveFlag  = 'Y'
	
	
	SET @crpLayoutFactId = 	(	select FactId from [ser].[Fact] where
									FactName = 'CRP Layout Performance'
									AND LOVRecordSourceId = @LOVRecordSourceId
									AND LOVFactTypeId = (
															select LOVId from [ser].[reflovsetinfo] where 
																LOVSetName= 'Fact Type'
																and LOVRecordSourceId=@RecordSourceIdMerchandise
																and LOVKey='TBC'
														)
							)
		
	SET @pogIdTypeId = 		(	SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
									LOVsetName='Source Key Type' 			-- LOVsetName='Source Key Type'
									and LOVKey = 'Norway Planogram Id(pog_id)' 	-- LOVKey = 'Norway Planogram Id(pog_id)'
									and LOVRecordSourceId = @RecordSourceIdMerchandise)		-- Record Source ID = 12012
								
	SET @storeDimId = 		(	select DimensionId from [ser].[dimension]
											where name =  'store' 
											AND LOVRecordSourceId = @LOVRecordSourceId
											AND SCDActiveFlag = 'Y'
							)
							
	SET @storeLOVID = 		(	select LOVId from [ser].[reflovsetinfo] 
									where LOVSetName= 'Role'
									and LOVKey='Store'
									and LOVRecordSourceId = @RecordSourceIdMerchandise
							)
							
	SET @floorDimId = 		(	select DimensionId from [ser].[dimension]
									where name =  'Floor' 
									AND LOVRecordSourceId = @LOVRecordSourceId
									AND SCDActiveFlag = 'Y'
							)	

	SET @weekDimId = 		(	select DimensionId from [ser].[dimension]
									where name =  'Week' 
									AND LOVRecordSourceId = @LOVRecordSourceId
									AND SCDActiveFlag = 'Y'
							)
							
	SET @planogramDimId = 	(	select DimensionId from [ser].[dimension]
									where name =  'Planogram' 
									AND LOVRecordSourceId = @LOVRecordSourceId
									AND SCDActiveFlag = 'Y'
							)
							
	SET @measureTypeId = 	(	select LOVId from [ser].[reflovsetinfo] where 
									LOVSetName= 'Measure Type'
									and LOVRecordSourceId=@RecordSourceIdMerchandise
									and LOVKey='PLANOGRAM_AGGREGATION'
							)
	
	SET @unitId = 			(	select MeasureId from [ser].[measure] where measureName = 'units'
										AND LOVRecordSourceId = @LOVRecordSourceId
										AND SCDActiveFLag = 'Y'
										AND LOVMeasureTypeId = @measureTypeId 
							)
							
	SET @tespId = 			(	select MeasureId from [ser].[measure] where measureName = 'tesp'
										AND LOVRecordSourceId = @LOVRecordSourceId
										AND SCDActiveFLag = 'Y'
										AND LOVMeasureTypeId = @measureTypeId 
							)
							
	SET @tispId = 			(	select MeasureId from [ser].[measure] where measureName = 'tisp'
										AND LOVRecordSourceId = @LOVRecordSourceId
										AND SCDActiveFLag = 'Y'
										AND LOVMeasureTypeId = @measureTypeId 
							)
							
	SET @eposProfitId = 	(	select MeasureId from [ser].[measure] where measureName = 'epos_profit'
										AND LOVRecordSourceId = @LOVRecordSourceId
										AND SCDActiveFLag = 'Y'
										AND LOVMeasureTypeId = @measureTypeId 
							)
							
	SET @modularSpaceId = 	(	select MeasureId from [ser].[measure] where measureName = 'modular_space'
										AND LOVRecordSourceId = @LOVRecordSourceId
										AND SCDActiveFLag = 'Y'
										AND LOVMeasureTypeId = @measureTypeId 
							)
							
	/* 
		If the date_added value in the new file <= the date_added for the previous  data load , change status to 26010 
	*/
	
	UPDATE [psa].[no_crp_layout_performance]     
		SET row_status= @rowStatusNotmigratedCode
    WHERE row_id in
                (	SELECT
						A.row_id
					FROM [psa].[no_crp_layout_performance] A
					JOIN 
					(
						SELECT 
							distinct pog_id,record_source_id,max(date_added) as date_added 
						FROM [psa].[no_crp_layout_performance]
						WHERE row_status = @rowStatusSERCode
						GROUP BY pog_id,record_source_id
					) B
					ON  A.pog_id=B.pog_id
                    and A.record_source_id = B.record_source_id					
					AND A.date_added<=B.date_added
					AND A.row_status = @rowStatusPSACode
				);
	Print 'Completed row_status updation of source after checking previously processed dates'
	
	SELECT @max_FactInstanceId = COALESCE(MAX(FactInstanceId),0) FROM [ser].[FactInstance];

	IF OBJECT_ID('tempdb..#no_crp_layout_join') IS NOT NULL
	BEGIN
		DROP TABLE #no_crp_layout_join
	END
	
	IF OBJECT_ID('tempdb..#no_crp_layout_temp') is not null
	BEGIN
		DROP TABLE #no_crp_layout_temp
	END
	
	SELECT
		*
	INTO #no_crp_layout_temp
	FROM 
	(
		SELECT 
			FactInstanceId
			,pog_id
			,row_id 
			,store_number
			,floor
			,week
			,units
			,tesp
			,tisp
			,epos_profit
			,modular_space
			,date_added
		FROM 
		(
			
			SELECT
				@max_FactInstanceId + (ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS FactInstanceId
				,pog_id
				,row_id 
				,store_number
				,floor
				,week
				,CASE WHEN (units IS NOT NULL AND units <> '') THEN CAST(CAST(CAST(units AS NUMERIC) AS INT) AS nVARCHAR(50)) ELSE NULL END AS units
				,CAST(tesp as nVARCHAR(50)) as tesp
				,CAST(tisp as nVARCHAR(50)) as tisp 
				,CAST(epos_profit as nVARCHAR(50)) as epos_profit  
				,CAST(modular_space as nVARCHAR(50)) as modular_space
				,date_added
			FROM [psa].[no_crp_layout_performance] 
			WHERE [row_status]=@rowStatusPSACode
			
		) C
	) A
	
	SELECT
		*
	INTO #no_crp_layout_join
	FROM 
	(
		SELECT 
			(ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS RowNumber
			,FactInstanceId
			,pog_id
			,row_id 
			,store_number
			,floor
			,week
			,units
			,tesp
			,tisp
			,epos_profit
			,modular_space
			,date_added
			,PlanogramId
		FROM 
		(
			SELECT 
				A.FactInstanceId
				,A.pog_id
				,A.row_id 
				,A.store_number
				,A.floor
				,A.week
				,A.units
				,A.tesp
				,A.tisp
				,A.epos_profit
				,A.modular_space
				,A.date_added
				,B.PlanogramId
			FROM 
			(
				SELECT
					FactInstanceId
					,pog_id
					,row_id 
					,store_number
					,floor
					,week
					,units
					,tesp
					,tisp 
					,epos_profit  
					,modular_space
					,date_added
				FROM #no_crp_layout_temp
			) A
			LEFT OUTER JOIN 
			(
				SELECT * FROM [ser].[Planogram] 
					WHERE SCDActiveFlag='Y' 
					AND Lovrecordsourceid=@LOVRecordSourceId 
					AND lovsourcekeytypeid = @pogIdTypeId
					-- AND scdlovrecordsourceid = @LOVRecordSourceId
			) B 
			ON A.pog_id=B.SourceKey
		) C
	) A
	
	PRINT('Loaded temp Table #no_crp_layout_temp')
	
	/*
		Start Transaction and populate data
	*/
	BEGIN TRANSACTION;
	BEGIN TRY
	
	
		/*
			TABLE 01	: [ser].[FactInstance]
		*/
		PRINT 'Info: Processing [ser].[FactInstance] ';
		/*
			Insert Data into [ser].[FactInstance] TABLE
		*/
		INSERT INTO [ser].[FactInstance]
		(
			[FactInstanceId]
			,[FactId]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT
				FactInstanceId AS			[FactInstanceId]
				,@crpLayoutFactId AS		[FactId]
				,@LOVRecordSourceId AS		[LOVRecordSourceId]
				,'1900-01-01 00:00:00' AS 	[SCDStartDate]
				,'9999-12-31 00:00:00' AS 	[SCDEndDate]
				,@SCDActiveFlag AS			[SCDActiveFlag]
				,@SCDVersion AS 			[SCDVersion]
				,@SCDLOVRecordSourceId AS	[SCDLOVRecordSourceId]
				,@serveETLRunLogID as		[ETLRunLogId]
				,row_id as 				[PSARowKey]
			FROM #no_crp_layout_temp
		)
		
		/*
			TABLE 02	: [ser].[FactDimensionInstance]
		*/
		UPDATE [ser].[FactDimensionInstance]
			SET DimensionSurrogateKey = site_role.siteroleid
		FROM [ser].[FactDimensionInstance] src
		JOIN 
		(
			SELECT * FROM [ser].[siterole] 
			WHERE LOVRecordSourceId = @LOVRecordSourceId
			AND scdactiveflag = 'Y' 
			AND LOVRoleId = @storeLOVID 
			-- AND SCDLOVRecordSourceId = @LOVRecordSourceId
		)site_role
		ON site_role.SourceKey = src.DimensionSourceKey
		WHERE src.DimensionSurrogateKey IS NULL 
		AND src.DimensionId = @storeDimId 
		AND src.LOVRecordSourceId = @LOVRecordSourceId 
		AND src.ETLRunLogId = @serveETLRunLogID 
		-- AND src.SCDLOVRecordSourceId = @LOVRecordSourceId;
		
		UPDATE [ser].[FactDimensionInstance]
			SET DimensionSurrogateKey = A.PlanogramId
		FROM [ser].[FactDimensionInstance] src
		JOIN (
				select 
					PlanogramId,SourceKey 
				from [ser].[Planogram] 
				where SCDActiveFlag='Y' 
				AND LOVRecordSourceId=@LOVRecordSourceId 
				AND LOVSourceKeyTypeId = @pogIdTypeId 
				-- AND SCDLOVRecordSourceId = @LOVRecordSourceId 
			)A
		ON src.DimensionSourceKey = A.SourceKey
		-- AND src.SCDLOVRecordSourceId = @LOVRecordSourceId		
		JOIN (
				select DimensionSourceKey,count(*) as cnt  
				from 
				(
					select distinct fdi.DimensionSourceKey,pl.PlanogramId 
					from [ser].[FactDimensionInstance] fdi 
					join (
						select PlanogramId,SourceKey 
						from [ser].[Planogram] 
						where SCDActiveFlag='Y' and 
						LOVRecordSourceId=@LOVRecordSourceId AND 
						LOVSourceKeyTypeId = @pogIdTypeId  
						-- SCDLOVRecordSourceId = @LOVRecordSourceId
					)pl
					ON fdi.DimensionSourceKey = pl.SourceKey
					-- AND fdi.SCDLOVRecordSourceId = @LOVRecordSourceId
				)C 
				group by DimensionSourceKey having count(*)=1
			)B
		ON A.SourceKey = B.DimensionSourceKey
		where src.DimensionSurrogateKey is NULL 
		and src.DimensionId = @planogramDimId 
		and src.LOVRecordSourceId = @LOVRecordSourceId  
		-- and src.SCDLOVRecordSourceId = @LOVRecordSourceId;
		
		PRINT 'Info: Updating [ser].[FactDimensionInstance] for existing DimensionSurrogateKey NULL records ';	
		
		PRINT 'Info: Processing [ser].[FactDimensionInstance] ';
		INSERT INTO [ser].[FactDimensionInstance]
		(
			[FactInstanceId]
			,[DimensionId]
			,[DimensionSurrogateKey]
			,[DimensionSourceKey]
			,[LOVRecordSourceId]
			,[SCDStartDate]
			,[SCDEndDate]
			,[SCDActiveFlag]
			,[SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		)
		(
			SELECT
				[FactInstanceId]
				,[DimensionId]
				,[DimensionSurrogateKey]
				,[DimensionSourceKey]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
				,@SCDActiveFlag AS [SCDActiveFlag]
				,@SCDVersion AS [SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			FROM
			(
				select 
					A.FactInstanceId AS [FactInstanceId]
					,@storeDimId AS [DimensionId]
					,B.SiteRoleId AS [DimensionSurrogateKey]
					,CAST(A.store_number AS varchar(80))AS [DimensionSourceKey]
					,@LOVRecordSourceId AS [LOVRecordSourceId]
					,'1900-01-01 00:00:00' AS [SCDStartDate]
					,'9999-12-31 00:00:00' AS [SCDEndDate]
					,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,@serveETLRunLogID as [ETLRunLogId]
					,A.row_id as [PSARowKey]
				from #no_crp_layout_temp	A
				left outer join 
				(select  * from [ser].[SiteRole] where 
					LOVRecordSourceId=@LOVRecordSourceId 
					and SCDActiveFlag='Y' 
					and LOVRoleId = @storeLOVID
				)B
				on A.store_number = B.SourceKey
				
				UNION
				
				select 
					A.FactInstanceId AS [FactInstanceId]
					,@floorDimId AS [DimensionId]
					,B.LOVId AS [DimensionSurrogateKey]
					,A.floor AS [DimensionSourceKey]
					,@LOVRecordSourceId AS [LOVRecordSourceId]
					,'1900-01-01 00:00:00' AS [SCDStartDate]
					,'9999-12-31 00:00:00' AS [SCDEndDate]
					,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,@serveETLRunLogID as [ETLRunLogId]
					,A.row_id as [PSARowKey]
				from #no_crp_layout_temp A
				LEFT OUTER JOIN
				(
					select * from [ser].[reflovsetinfo] 
						WHERE LOVSetName = 'floor'
						AND LOVRecordSourceId = @LOVRecordSourceId
				) B
				on A.floor = B.LOVKey
				
				UNION
				
				select 
					A.FactInstanceId AS [FactInstanceId]
					,@weekDimId AS [DimensionId]
					,B.LOVId AS [DimensionSurrogateKey]
					,CAST(A.week AS varchar(80))AS [DimensionSourceKey]
					,@LOVRecordSourceId AS [LOVRecordSourceId]
					,'1900-01-01 00:00:00' AS [SCDStartDate]
					,'9999-12-31 00:00:00' AS [SCDEndDate]
					,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,@serveETLRunLogID as [ETLRunLogId]
					,A.row_id as [PSARowKey]	
					from #no_crp_layout_temp A
				LEFT OUTER JOIN
				(
				select * from [ser].[reflovsetinfo] 
					WHERE LOVSetName = 'week'
					AND LOVRecordSourceId = @LOVRecordSourceId) B
				on A.week = B.LOVKey
					
				UNION
				
				SELECT 
					B.FactInstanceId AS [FactInstanceId]
					,B.DimensionId AS [DimensionId]
					,B.DimensionSurrogateKey AS [DimensionSurrogateKey]
					,B.DimensionSourceKey AS [DimensionSourceKey]
					,B.LOVRecordSourceId AS [LOVRecordSourceId]
					,B.SCDStartDate AS [SCDStartDate]
					,B.SCDEndDate AS [SCDEndDate]
					,B.SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,B.ETLRunLogId AS [ETLRunLogId]
					,B.PSARowKey AS [PSARowKey] 
				FROM 
				(
					select 
						A.RowNumber AS [RowNumber]
						,A.FactInstanceId AS [FactInstanceId]
						,@planogramDimId AS [DimensionId]
						,(case when
							
								(select count(row_id) from (select row_id from #no_crp_layout_join where row_id=A.row_id) X)=1 then A.PlanogramId else NULL end
							)
							AS [DimensionSurrogateKey]
						,cast(A.pog_id as varchar(80)) AS [DimensionSourceKey]
						,@LOVRecordSourceId AS [LOVRecordSourceId]
						,'1900-01-01 00:00:00' AS [SCDStartDate]
						,'9999-12-31 00:00:00' AS [SCDEndDate]
						,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
						,@serveETLRunLogID as [ETLRunLogId]
						,A.row_id as [PSARowKey]
					from #no_crp_layout_join A
				) B
				WHERE RowNumber IN
				(
					SELECT MIN(RowNumber) FROM
					(
						SELECT  
							A.RowNumber AS [RowNumber]
							,A.row_id AS [PSARowKey]
						from  #no_crp_layout_join A
					) X
					GROUP BY PSARowKey
				) 
				
			) A
		)
		
		/*
			TABLE 03	: [ser].[FactMeasureInstance]
		*/
		PRINT 'Info: Processing [ser].[FactDimensionInstance] ';
		WITH Stg_no_crp_planogram AS
		(
			select 
				[FactInstanceId]
				,[row_id]
				,[ColumnName]
				,[ColumnValue]
				,CASE
					WHEN ColumnName ='units' THEN @unitId
					WHEN ColumnName ='tesp' THEN @tespId
					WHEN ColumnName ='tisp' THEN @tispId
					WHEN ColumnName ='epos_profit' THEN @eposProfitId
					WHEN ColumnName ='modular_space' THEN @modularSpaceId
					ELSE NULL
				END AS [MeasureId]
			from #no_crp_layout_temp
			UNPIVOT
			(
				ColumnValue FOR ColumnName IN (units, tesp, tisp, epos_profit, modular_space)
			) U
			where ColumnValue IS NOT NULL AND ColumnValue <> ''
		)
		
		INSERT INTO [ser].[FactMeasureInstance]
		(
		[FactInstanceId]
		,[MeasureId]
		,[Value]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		)
		(
			SELECT
				[FactInstanceId]
				,[MeasureId]
				,[Value]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
				,@SCDActiveFlag AS [SCDActiveFlag]
				,@SCDVersion AS [SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			FROM
			(
				SELECT
					FactInstanceId AS [FactInstanceId]
					,MeasureId AS [MeasureId]
					,ColumnValue AS [Value]
					,@LOVRecordSourceId AS [LOVRecordSourceId]
					,'1900-01-01 00:00:00' AS [SCDStartDate]
					,NULL AS [SCDEndDate]
					,@SCDLOVRecordSourceId AS [SCDLOVRecordSourceId]
					,@serveETLRunLogID as [ETLRunLogId]
					,row_id as [PSARowKey]
				FROM Stg_no_crp_planogram
			) X
		)
		
		UPDATE [psa].[no_crp_layout_performance]
			SET [row_status]=@rowStatusSERCode
		FROM [psa].[no_crp_layout_performance] tclp
		JOIN
			(
				SELECT 
					distinct FactInstanceId,PSARowKey,LOVRecordSourceId 
				FROM [ser].[FactInstance]
				WHERE [LOVRecordSourceId] = @LOVRecordSourceId
				AND ETLRunLogId = @serveETLRunLogID 
				-- AND SCDLOVRecordSourceId=@LOVRecordSourceId
			)temp
		ON tclp.row_id = temp.PSARowKey
		AND tclp.record_source_id = temp.LOVRecordSourceId
		WHERE tclp.row_status=@rowStatusPSACode;
		
		PRINT ('Updated Row Status for [psa].[no_crp_layout_performance]')
	
	
	COMMIT TRANSACTION;					
	END TRY
	BEGIN CATCH
    THROW;
    ROLLBACK TRANSACTION;    
    END CATCH 	
END
GO
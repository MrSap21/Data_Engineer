SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('[psa].[sp_inc_no_crp_merchandise]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_no_crp_merchandise] 
END
GO

CREATE PROC [psa].[sp_inc_no_crp_merchandise] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max) AS

BEGIN
	
	DECLARE @SCDDefaultStartDate DATETIME
	DECLARE @scdDefaultEndDate DATETIME
	DECLARE @SCDStartDate DATETIME
	DECLARE @SCDEndDate DATETIME
	DECLARE @dateAdded VARCHAR (max)
	DECLARE @MAXID BIGINT
	DECLARE @COUNTER BIGINT
	DECLARE @LOVRecordSourceId BIGINT
	DECLARE @RecordSourceIdMerchandise BIGINT
	DECLARE @SCDLOVRecordSourceId BIGINT
	DECLARE @pogIdTypeId BIGINT
	DECLARE @indicatorLOVID BIGINT
	DECLARE @dbKeyTypeId BIGINT
	DECLARE @fittingTypeLOVSetID BIGINT
	DECLARE @plannerFamilyLOVSetID BIGINT
	DECLARE @footprintLOVSetID BIGINT
	DECLARE @categoryLOVSetID BIGINT
	DECLARE @formatLOVSetID BIGINT
	DECLARE @rowStatusPSACode BIGINT
	DECLARE	@rowStatusSERCode BIGINT
	DECLARE	@rowStatusNotmigratedCode BIGINT
	DECLARE	@measureTypeIdPlanoDim BIGINT
	DECLARE @shelfDepthMeasureID BIGINT
	DECLARE @heightMeasureID BIGINT
	DECLARE @buildSizeMeasureID BIGINT
	DECLARE @LOVIdUnitCM BIGINT
	DECLARE @LOVIdUnitUnKnown BIGINT
	DECLARE @max_planogramID	BIGINT
	DECLARE @max_planogramID_temp BIGINT
	DECLARE @max_PlanogramGroupId BIGINT
	
	SET @SCDDefaultStartDate = CONVERT(DateTime,'1900-01-01',126)	
	SET @SCDDefaultEndDate = CONVERT(DateTime,'9999-12-31',126)
	SET @LOVRecordSourceId = 12005
	SET @RecordSourceIdMerchandise = 12012
	SET @SCDLOVRecordSourceId = 12005
	SET @rowStatusPSACode = 26001
	SET @rowStatusSERCode = 26002
	SET @rowStatusNotmigratedCode = 26010
	
	--Assigning values to lookup variables
	
	SET @pogIdTypeId = 		(select LOVId from [ser].[reflovsetinfo] where 
								LOVsetName='Source Key Type' 			-- LOVsetName='Source Key Type'
								and LOVKey = 'Norway Planogram Id(pog_id)' 	-- LOVKey = 'Norway Planogram Id(pog_id)'
								and LOVRecordSourceId = @RecordSourceIdMerchandise)		-- Record Source ID = 12012
	SET @indicatorLOVID = (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
								LOVsetName='Indicator - NORWAY MerchANDise'  	
								AND LOVKey = 'promotional_site'
								AND LOVRecordSourceId = @LOVRecordSourceId)
								
	SET @dbKeyTypeId = (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
								LOVsetName='Source Key Type' 
								AND LOVKey = 'Norway Planogram dbkey' 
								AND LOVRecordSourceId = @RecordSourceIdMerchandise)
								
	SET @fittingTypeLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='fitting_type' 			-- LOVsetName='fitting_type'
									and LOVRecordSourceId = @LOVRecordSourceId)		-- Record Source ID = 12005	
									
	SET @plannerFamilyLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='planner_family' 			-- LOVsetName='planner_family'
									and LOVRecordSourceId = @LOVRecordSourceId)		-- Record Source ID = 12005
									
	SET @footprintLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='footprint' 			-- LOVsetName='footprint'
									and LOVRecordSourceId = @LOVRecordSourceId)		-- Record Source ID = 12005
									
	SET @categoryLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='category' 			-- LOVsetName='category'
									and LOVRecordSourceId = @LOVRecordSourceId)		-- Record Source ID = 12005
									
	SET @formatLOVSetID = (select distinct(LOVSetId) from [ser].[reflovsetinfo] where 
									LOVsetName='format' 			-- LOVsetName='format'
									and LOVRecordSourceId = @LOVRecordSourceId)		-- Record Source ID = 12005
								
	SET @measureTypeIdPlanoDim = (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
									LOVsetName='Measure Type' 
									AND LOVKey = 'PLANOGRAM_DIM' 
									AND LOVRecordSourceId = @RecordSourceIdMerchandise)
									
	SET @shelfDepthMeasureID = (SELECT MeasureId FROM [ser].[measure] 
									WHERE
									MeasureName = 'shelf_depth' AND
									LOVMeasureTypeId = @measureTypeIdPlanoDim AND
									LOVRecordSourceId = @LOVRecordSourceId)
									
	SET @heightMeasureID = (SELECT MeasureId FROM [ser].[measure] 
									WHERE
									MeasureName = 'height' AND
									LOVMeasureTypeId = @measureTypeIdPlanoDim AND
									LOVRecordSourceId = @LOVRecordSourceId)
									
	SET @buildSizeMeasureID = (SELECT MeasureId FROM [ser].[measure] 
									WHERE
									MeasureName = 'build_size' AND
									LOVMeasureTypeId = @measureTypeIdPlanoDim AND
									LOVRecordSourceId = @LOVRecordSourceId)
									
	SET @LOVIdUnitCM		= (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
								LOVsetName='Unit Of Measure'
								AND LOVKey = 'cm' 
								AND LOVRecordSourceId = @RecordSourceIdMerchandise)
								
	SET @LOVIdUnitUnKnown 	= (SELECT LOVId FROM [ser].[reflovsetinfo] WHERE 
								LOVsetName='Unit Of Measure'
								AND LOVKey = 'Unknown' 	
								AND LOVRecordSourceId = @RecordSourceIdMerchandise)
	
	
	/*
		Updating records to "rowStatusNotmigratedCode"
	*/
	UPDATE [psa].[no_crp_merchandise]      
		SET row_status = @rowStatusNotmigratedCode
	WHERE row_id IN (
						SELECT
							A.row_id
						FROM [psa].[no_crp_merchandise] A
						JOIN (
								SELECT DISTINCT pog_id,record_source_id,
									MAX(date_added) AS date_added 
								FROM [psa].[no_crp_merchandise]
								WHERE row_status = @rowStatusSERCode 
								GROUP BY pog_id,record_source_id
							) B
						ON A.pog_id=B.pog_id    
						AND A.record_source_id = B.record_source_id								
						AND A.date_added<=B.date_added
						AND A.row_status = @rowStatusPSACode
					);
	
	/*
		Reset & Load Data to [psa].[no_merchandise_date_table]
	*/
	IF OBJECT_ID('[psa].[no_merchandise_date_table]') IS NOT NULL
	BEGIN
		DROP TABLE [psa].[no_merchandise_date_table]
	END
	
	SELECT
		A.*
	INTO [psa].[no_merchandise_date_table]
	FROM (
		SELECT  
			DISTINCT DENSE_RANK() OVER(ORDER BY (date_added)) AS [RowID],
			date_added AS [dateAdded]
		FROM [psa].[no_crp_merchandise]
			WHERE [row_status]=@rowStatusPSACode 
	) A;
	
	/*
		Reset & Load Data to [psa].[no_crp_merchandise_temp]
	*/
	IF OBJECT_ID('[psa].[no_crp_merchandise_temp]') is not null
	BEGIN
	DROP TABLE [psa].[no_crp_merchandise_temp]
	END
	
	CREATE TABLE [psa].[no_crp_merchandise_temp]
	(
		[PSARowKey] 			[BIGINT] NOT NULL,
		[LOVSourceKeyTypeId] 	[INT] NULL,
		[PlanogramID] 			[BIGINT] NULL,
		[ParentPlanogramID] 	[BIGINT] NULL,
		[sourceKey] 			[NVARCHAR](80) NULL,
		[pog_description] 		[NVARCHAR](80) NULL,
		[planogram_start_date] 	[DATETIME] NULL,	
		[planogram_end_date] 	[DATETIME] NULL, 
		[shelf_depth] 			[NVARCHAR](255) NULL,
		[height] 				[NVARCHAR](255) NULL,
		[fitting_type] 			[NVARCHAR](255) NULL,
		[build_size] 			[NVARCHAR](255) NULL,
		[planner_family] 		[NVARCHAR](255) NULL,
		[footprint] 			[NVARCHAR](255) NULL,
		[category] 				[NVARCHAR](255) NULL,
		[format] 				[NVARCHAR](255) NULL,
		[promotional_site] 		[NVARCHAR](255) NULL,
		[date_added] 			[DATETIME] NULL,
		[etl_runlog_id] 		[INT] NULL,
		[asset_id] 				[INT] NULL,
		[LOVRecordSourceId] 	[INT] NULL,
		[row_status] 			[INT] NULL,
		[created_timestamp] 	[DATETIME] NULL
	)
	WITH
	(
		DISTRIBUTION = REPLICATE,
		CLUSTERED COLUMNSTORE INDEX
	)
	
	PRINT 'Info: [psa].[no_crp_merchandise_temp] table loading for parent records started';
	SELECT  @max_planogramID = COALESCE(MAX(PlanogramID),0) FROM [ser].[Planogram];
	WITH Stg_planogram AS 
	(
		SELECT 
			*  
		FROM [ser].[Planogram] pg
		WHERE LOVRECORDSOURCEID = @LOVRecordSourceId 
		AND LOVSourceKeyTypeId = @pogIdTypeId
		AND NOT EXISTS (
							SELECT 1 FROM [ser].[Planogram] AS pgm
							WHERE pgm.PlanogramId = pg.PlanogramId
							AND pgm.LOVRecordSourceID=pg.LOVRecordSourceID
							AND  pgm.SCDVersion >pg.SCDVersion
						)
	),
	Stg_deduplicate AS 
	(
		SELECT 
			A.POG_ID
			,A.DATE_ADDED
			,ROW_NUMBER() OVER (PARTITION BY A.POG_ID,A.DATE_ADDED ORDER BY A.POG_ID,A.DATE_ADDED) AS row_id
		FROM [psa].[no_crp_merchandise] A
		JOIN (
				SELECT POG_ID,
					max(DATE_ADDED) DATE_ADDED
					FROM [psa].[no_crp_merchandise] 
					GROUP BY POG_ID,DATE_ADDED 
			) temp
		ON A.pog_id=temp.pog_id 
		AND A.date_added=temp.date_added
	) 
	
	INSERT INTO [psa].[no_crp_merchandise_temp]
	(
		[PSARowKey]
		,[LOVSourceKeyTypeId]
		,[PlanogramId]
		,[ParentPlanogramId] 
		,[sourceKey]
		,[pog_description]
		,[planogram_start_date]
		,[planogram_end_date]
		,[shelf_depth]
		,[height]
		,[fitting_type]
		,[build_size]
		,[planner_family]
		,[footprint]
		,[category]
		,[format]
		,[promotional_site]
		,[date_added]
		,[etl_runlog_id]
		,[asset_id]
		,[LOVRecordSourceID]
		,[row_status]
		,[created_timestamp]
	)
	(
		select 
			T.[PSARowKey]
			,T.[LOVSourceKeyTypeId]
			,T.[PlanogramId]
			,T.[ParentPlanogramId] 
			,T.[sourceKey]
			,T.[pog_description]
			,T.[planogram_start_date]
			,T.[planogram_end_date]
			,T.[shelf_depth]
			,T.[height]
			,T.[fitting_type]
			,T.[build_size]
			,T.[planner_family]
			,T.[footprint]
			,T.[category]
			,T.[format]
			,T.[promotional_site]
			,T.[date_added]
			,T.[etl_runlog_id]
			,T.[asset_id]
			,T.[LOVRecordSourceID]
			,T.[row_status]
			,T.[created_timestamp]
		from
		(
			select 
				A.row_id					AS [PSARowKey]
				,@pogIdTypeId				AS [LOVSourceKeyTypeId]
				,ISNULL(P.PlanogramId,C.PlanogramId)
											AS [PlanogramId]
				,NULL						AS [ParentPlanogramId] 
				,A.pog_id					AS [sourceKey]
				,A.pog_description			AS [pog_description]
				,NULL						AS [planogram_start_date]
				,NULL						AS [planogram_end_date]
				,A.shelf_depth				AS [shelf_depth]
				,A.height					AS [height]
				,A.fitting_type				AS [fitting_type]
				,A.build_size				AS [build_size]
				,A.planner_family			AS [planner_family]
				,A.footprint				AS [footprint]
				,A.category					AS [category]
				,A.format					AS [format]
				,A.promotional_site			AS [promotional_site]
				,NULLIF(A.date_added,'')	AS [date_added]
				,@serveETLRunLogID			AS [etl_runlog_id]
				,A.asset_id					AS [asset_id]
				,A.record_source_id			AS [LOVRecordSourceId]
				,A.row_status				AS [row_status]
				,A.created_timestamp		AS [created_timestamp]
				,LEAD('N', 1, 'Y') OVER(PARTITION BY A.pog_id,A.date_added,A.record_source_id ORDER BY A.date_added ASC) 
											AS [duplicate_Check]
			from [psa].[no_crp_merchandise] A
			LEFT JOIN Stg_deduplicate B
				ON A.pog_id=B.pog_id
				AND A.date_added=B.date_added
				AND B.row_id=1
			JOIN 
			(
				SELECT 
					pog_id
					,record_source_id
					,(@max_planogramID+DENSE_RANK() OVER(ORDER BY convert(int,pog_id),record_source_id ASC)) PlanogramId
				FROM [psa].[no_crp_merchandise]  
				WHERE row_status=@rowStatusPSACode 
				GROUP BY pog_id,record_source_id
			) C
				ON C.pog_id=A.pog_id 
				AND C.record_source_id=A.record_source_id
			LEFT JOIN Stg_planogram P
							ON A.pog_id =P.sourcekey  
							AND A.record_source_id = P.LOVRecordSourceId
							AND P.LOVSourceKeyTypeId = @pogIdTypeId
							WHERE A.row_status = CAST(@rowStatusPSACode AS INT)
		) T
		WHERE T.duplicate_Check ='Y' 
	)
	
	SELECT  @max_planogramID = COALESCE(MAX(PlanogramID),0) FROM [ser].[Planogram];
	SELECT  @max_planogramID_temp = COALESCE(MAX(PlanogramID),0) FROM [psa].[no_crp_merchandise_temp];
	SELECT  @max_planogramID = CASE
        WHEN @max_planogramID >= @max_planogramID_temp THEN @max_planogramID
        ELSE	@max_planogramID_temp
    END 
	
	PRINT 'Info: [psa].[no_crp_merchandise_temp] table loading for Child records started';
	
	WITH Stg_planogram AS 
	(
		SELECT 
			*
		FROM [ser].[Planogram] pg
		WHERE LOVRECORDSOURCEID = @LOVRecordSourceId 
		AND LOVSourceKeyTypeId = @dbKeyTypeId 
		AND NOT EXISTS (
							SELECT 1 FROM [ser].[Planogram] AS pgm
							WHERE pgm.PlanogramID = pg.PlanogramID
							AND pgm.LOVRecordSourceID= pg.LOVRecordSourceID
							AND  pgm.SCDVersion > pg.SCDVersion
						)
	)
	
	INSERT INTO [psa].[no_crp_merchandise_temp]
	(
		[PSARowKey]
		,[LOVSourceKeyTypeId]
		,[PlanogramId]
		,[ParentPlanogramId] 
		,[sourceKey]
		,[pog_description]
		,[planogram_start_date]
		,[planogram_end_date]
		,[shelf_depth]
		,[height]
		,[fitting_type]
		,[build_size]
		,[planner_family]
		,[footprint]
		,[category]
		,[format]
		,[promotional_site]
		,[date_added]
		,[etl_runlog_id]
		,[asset_id]
		,[LOVRecordSourceID]
		,[row_status]
		,[created_timestamp]
	)
	(
		select 
			A.row_id					AS [PSARowKey]
			,@dbKeyTypeId				AS [LOVSourceKeyTypeId]
			,B.PlanogramID				AS [PlanogramId]
			,ISNULL(P.ParentPlanogramID, C.PlanogramID)
										AS [ParentPlanogramId] 
			,A.db_key					AS [sourceKey]
			,A.pog_description			AS [pog_description]
			,NULLIF(A.planogram_start_date,'')
										AS [planogram_start_date]
			,NULLIF(A.planogram_end_date,'')
										AS [planogram_end_date]
			,A.shelf_depth				AS [shelf_depth]
			,A.height					AS [height]
			,A.fitting_type				AS [fitting_type]
			,A.build_size				AS [build_size]
			,A.planner_family			AS [planner_family]
			,A.footprint				AS [footprint]
			,A.category					AS [category]
			,A.format					AS [format]
			,A.promotional_site			AS [promotional_site]
			,NULLIF(A.date_added,'')	AS [date_added]
			,@serveETLRunLogID			AS [etl_runlog_id]
			,A.asset_id					AS [asset_id]
			,A.record_source_id			AS [LOVRecordSourceId]
			,A.row_status				AS [row_status]
			,A.created_timestamp		AS [created_timestamp]
		FROM [psa].[no_crp_merchandise] A
		JOIN
			(
				SELECT 
					pog_id
					,db_key
					,date_added
					,record_source_id
					,(@max_planogramID+DENSE_RANK() OVER(ORDER BY convert(int,pog_id),db_key,date_added,record_source_id ASC)) PlanogramID 
				FROM [psa].[no_crp_merchandise]
				WHERE row_status=@rowStatusPSACode 
				GROUP BY pog_id,db_key,date_added,record_source_id
			) B
		ON B.pog_id=A.pog_id 
			AND B.db_key=A.db_key 
			AND B.date_added=A.date_added
			AND B.record_source_id=A.record_source_id
		JOIN 
			(
				SELECT 
					SourceKey
					,LOVRecordSourceId
					,PlanogramID
					,LOVSourceKeyTypeId 
				FROM [psa].[no_crp_merchandise_temp]
				GROUP BY SourceKey,LOVRecordSourceId,PlanogramID,LOVSourceKeyTypeId
			) C
		ON C.SourceKey = A.pog_id
			AND C.LOVRecordSourceId = A.record_source_id
			AND C.LOVSourceKeyTypeId = @pogIdTypeId
		LEFT JOIN Stg_planogram P
		ON A.db_key = P.sourcekey 
			AND A.record_source_id = P.LOVRecordSourceId
			AND P.LOVSourceKeyTypeId = @dbKeyTypeId
			AND P.ParentPlanogramId = 	(
											SELECT distinct PlanogramId 
											from [ser].[Planogram] 
											WHERE SourceKey = A.pog_id
											AND A.record_source_id = LOVRecordSourceId 
											AND LOVSourceKeyTypeId = @pogIdTypeId
										)
		WHERE A.db_key IS NOT NULL and A.db_key !=''
		AND A.date_added IS NOT NULL and A.date_added!=''
		AND A.row_status = CAST(@rowStatusPSACode AS INT)
	)

	BEGIN TRANSACTION;
	BEGIN TRY
	
	SET @SCDStartDate = CURRENT_TIMESTAMP;
	SET @SCDEndDate = @SCDStartDate;
	
	/*
		TABLE 01	: [ser].[Planogram] - Parent Records
	*/
	PRINT 'Info: [ser].[Planogram] Loading Parent Started';
	WITH Stg_planogram AS 
	(
		SELECT 
			*
		FROM [ser].[Planogram] pg
		WHERE LOVRECORDSOURCEID = @LOVRecordSourceId 
		AND NOT EXISTS (
							SELECT 1 FROM [ser].[Planogram] AS pgm
							WHERE pgm.PlanogramID = pg.PlanogramID
							AND pgm.LOVRecordSourceID= pg.LOVRecordSourceID
							AND  pgm.SCDVersion > pg.SCDVersion
						)
	)
	INSERT INTO [ser].[Planogram]
	(
		[PlanogramId]
		,[SourceKey]
		,[LOVSourceKeyTypeId]
		,[planogramStartDate]	
		,[planogramEndDate] 
		,[planogramName]
		,[ParentPlanogramId]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
	)
	(
		SELECT 
			[PlanogramId]
			,[SourceKey]
			,[LOVSourceKeyTypeId]
			,CASE WHEN (PlanogramStartDate = '' or PlanogramStartDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramStartDate END AS [PlanogramStartDate]
	        ,CASE WHEN (PlanogramEndDate = '' or PlanogramEndDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramEndDate END AS [PlanogramEndDate]
			,[PlanogramName]
			,[ParentPlanogramId]
			,[LOVRecordSourceId]
			,CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY PlanogramId ORDER BY date_added ASC)) = 1)
					THEN @SCDDefaultStartDate 
					ELSE @SCDStartDate
				END [SCDStartDate]
			,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY PlanogramId ORDER BY date_added ASC) [SCDEndDate]
			,LEAD('N', 1, 'Y') OVER(PARTITION BY PlanogramId,sourceKey ORDER BY date_added,[PSARowKey] ASC) [SCDActiveFlag]
			,ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY PlanogramId,sourceKey ORDER BY date_added,[PSARowKey] ASC) [SCDVersion]
			,[SCDLOVRecordSourceId]
			,[ETLRunLogId]
			,[PSARowKey]
		FROM
		(
			SELECT
				A.PSARowKey				AS [PSARowKey]
				,A.PlanogramId			AS [PlanogramId]
				,A.SourceKey				AS [SourceKey]
				,A.LOVSourceKeyTypeId	AS [LOVSourceKeyTypeId]
				,A.ParentPlanogramId		AS [ParentPlanogramId]
				,A.planogram_start_date 	AS [PlanogramStartDate]
				,A.planogram_end_date 	AS [PlanogramEndDate]
				,A.pog_description 		AS [PlanogramName]
				,A.LOVRecordSourceId		AS [LOVRecordSourceId]
				,A.date_added			AS [date_added]
				,@SCDDefaultEndDate 		AS [SCDEndDate]
				,A.LOVRecordSourceId 	AS [SCDLOVRecordSourceId]
				,@serveETLRunLogID		AS [ETLRunLogId]
				,LEAD('N', 1, 'Y') OVER(PARTITION BY A.PlanogramId,A.pog_description ORDER BY A.date_added,A.PSARowKey ASC) 
												AS [SCDActiveFlag]
				,P.SCDVersion 			AS [SCDVersion]
			FROM [psa].[no_crp_merchandise_temp] A
			LEFT JOIN Stg_planogram P
						ON A.PlanogramId = P.PlanogramId
						AND ISNULL(A.ParentPlanogramId,'') = ISNULL(P.ParentPlanogramId,'')
						AND A.LOVRecordSourceId = P.LOVRecordSourceId
						AND P.LOVSourceKeyTypeId = @pogIdTypeId
			WHERE 
				A.LOVSourceKeyTypeId = @pogIdTypeId 
				AND (CASE  WHEN ( NULLIF(A.pog_description,'' ) IS NULL )  
							THEN 0
							ELSE 1 
					END
					)=1			-- NULL OR BLANK DONT INSERT
					
		) T
		WHERE T.SCDActiveFlag='Y'
		AND NOT EXISTS ( SELECT 1 FROM [ser].[Planogram] P 
							WHERE T.planogramId = P.planogramId
							AND T.LOVSourceKeyTypeId= P.LOVSourceKeyTypeId
							AND T.LOVRecordSourceId=P.LOVRecordSourceId
							AND ISNULL(T.PlanogramName,'') = ISNULL(P.PlanogramName,'')
							AND ISNULL(T.PlanogramStartDate,'')=ISNULL(P.PlanogramStartDate,'')
							AND ISNULL(T.PlanogramEndDate,'')=ISNULL(P.PlanogramEndDate,'')
							AND P.SCDActiveFlag ='Y'
						)
	)
	
	UPDATE [ser].[Planogram] 
		set SCDActiveFlag='N'
		,SCDEndDate = @SCDEndDate
	FROM [ser].[Planogram] P
	JOIN
	(
		SELECT 
			planogramId
			,SCDactiveflag
			,SCDVersion
			,LOVRecordSourceID 
		FROM [ser].[Planogram]  T 
		WHERE
			T.LOVRecordSourceID = @LOVRecordSourceID
			AND T.SCDActiveFlag='Y'
			AND NOT EXISTS (
								SELECT 1 FROM [ser].[Planogram]  AS C
								WHERE C.PlanogramID = T.PlanogramID
								AND C.LOVRecordSourceID=T.LOVRecordSourceID
								AND C.LOVSourceKeyTypeId=T.LOVSourceKeyTypeId
								AND C.ScdVersion > T.ScdVersion
							)
	) A
	ON  P.PlanogramID=A.PlanogramId
		AND P.LovRecordSourceId=A.LovRecordSourceId
		AND P.SCDactiveflag=A.SCDactiveflag
		AND P.SCDVersion!=A.SCDVersion
	JOIN [psa].[no_crp_merchandise_temp] B
	ON P.PlanogramID = B.PlanogramID
	WHERE P.SCDActiveFlag='Y'
	AND P.SCDEndDate = @SCDDefaultEndDate

		SET @COUNTER = 1
		SET @MAXID = (SELECT COUNT(*) FROM [psa].[no_merchandise_date_table])
		
		WHILE (@COUNTER <= @MAXID)
		BEGIN
			SELECT @dateAdded = dateAdded FROM [psa].[no_merchandise_date_table] WHERE  RowID=@Counter;
			
			SET @SCDStartDate = CURRENT_TIMESTAMP;
			SET @SCDEndDate = @SCDStartDate;
			
			PRINT 'Info: Processing no_crp_merchandise FOR Date : '+@dateAdded+'';
			
			/*
				TABLE 01	: [ser].[Planogram] - Child Records
			*/
			PRINT 'Info: [ser].[Planogram] Loading Child Started';
			
			INSERT INTO [ser].[Planogram]
			(
				[PlanogramId]
				,[SourceKey]
				,[LOVSourceKeyTypeId]
				,[planogramStartDate]	
				,[planogramEndDate] 
				,[planogramName]
				,[ParentPlanogramId]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,[SCDEndDate]
				,[SCDActiveFlag]
				,[SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			)
			(
				SELECT 
					[PlanogramId]
					,[SourceKey]
					,[LOVSourceKeyTypeId]
					,CASE WHEN (PlanogramStartDate = '' or PlanogramStartDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramStartDate END AS [PlanogramStartDate]
	                ,CASE WHEN (PlanogramEndDate = '' or PlanogramEndDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramEndDate END AS [PlanogramEndDate]
					,[PlanogramName]
					,[ParentPlanogramId]
					,[LOVRecordSourceId]
					,CASE WHEN ((ROW_NUMBER() OVER(PARTITION BY PlanogramId ORDER BY date_added ASC)) = 1)
							THEN @SCDDefaultStartDate 
							ELSE @SCDStartDate
						END [SCDStartDate]
					,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY PlanogramId ORDER BY date_added ASC) [SCDEndDate]
					,LEAD('N', 1, 'Y') OVER(PARTITION BY PlanogramId,sourceKey ORDER BY date_added ASC) [SCDActiveFlag]
					,ROW_NUMBER() OVER(PARTITION BY PlanogramId,sourceKey ORDER BY date_added ASC) [SCDVersion]
					,[SCDLOVRecordSourceId]
					,[ETLRunLogId]
					,[PSARowKey]
				FROM
				(
					
					SELECT
						A.PSARowKey				AS [PSARowKey]
						,A.PlanogramId			AS [PlanogramId]
						,A.SourceKey			AS [SourceKey]
						,A.LOVSourceKeyTypeId	AS [LOVSourceKeyTypeId]
						,A.ParentPlanogramId	AS [ParentPlanogramId]
						,A.planogram_start_date AS [PlanogramStartDate]
						,A.planogram_end_date 	AS [PlanogramEndDate]
						,A.pog_description 		AS [PlanogramName]
						,A.LOVRecordSourceId	AS [LOVRecordSourceId]
						,A.date_added			AS [date_added]
						,@SCDDefaultEndDate 	AS [SCDEndDate]
						,A.LOVRecordSourceId 	AS [SCDLOVRecordSourceId]
						,@serveETLRunLogID		AS [ETLRunLogId]
						,LEAD('N', 1, 'Y') OVER(PARTITION BY A.PlanogramId,A.pog_description,A.date_added,A.sourceKey ORDER BY A.date_added, A.PSARowKey ASC) 
												AS [SCDActiveFlag]
					FROM [psa].[no_crp_merchandise_temp] A
					WHERE 
						A.LOVSourceKeyTypeId = @dbKeyTypeId 
						AND A.date_added = @dateAdded
						AND (CASE  WHEN ( NULLIF(A.pog_description,'' ) IS NULL)   
									THEN 0
									ELSE 1 
							END)=1			-- NULL OR BLANK DONT INSERT
				) T
				WHERE T.[SCDActiveFlag]='Y'
			)
			
			
			PRINT 'Info: [ser].[Planogram] Loaded Successfully';
			/*
				TABLE 02	: [ser].[PlanogramGroup]
			*/
			SELECT @max_PlanogramGroupId = COALESCE(MAX(PlanogramGroupId),0) FROM [ser].[PlanogramGroup]
			PRINT 'Info: Processing [ser].[PlanogramGroup] for Date : '+@dateAdded+'';
	
			WITH Stg_Planogram AS
			(
				SELECT 
					SourceKey
					,LOVRecordSourceId
					,LOVSourceKeyTypeId
					,ParentPlanogramId
					,max(PlanogramId) as PlanogramId
				FROM [ser].[Planogram] A
					WHERE LOVRecordSourceId = @LOVRecordSourceId
					AND LOVSourceKeyTypeId = @dbKeyTypeId
					AND ETLRunLogId = @serveETLRunLogID
					AND NOT EXISTS	(
										SELECT 1 FROM [ser].[Planogram] B
											WHERE A.PlanogramId = B.PlanogramId
											AND A.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
											AND A.LOVRecordSourceId = B.LOVRecordSourceId
											AND A.ScdVersion > B.ScdVersion
									)
					group by SourceKey,LOVRecordSourceId,LOVSourceKeyTypeId,ParentPlanogramId
			),
			Stg_no_crp_merchandise AS
			(
				SELECT 
					A.[sourceKey]
					,A.[ParentPlanogramID]
					,A.[date_added]
					,A.[LOVRecordSourceId]
					,A.[PSARowKey]
					,A.[ColumnValue]
					,A.[ColumnName]  
					,A.[columnId]
					,B.[LOVID]
				FROM 
				(
					SELECT 
						[sourceKey]
						,[ParentPlanogramID]
						,[date_added]
						,[LOVRecordSourceId]
						,[PSARowKey]
						,[ColumnValue]
						,[ColumnName]  		
						,CASE
							WHEN ColumnName ='fitting_type' THEN @fittingTypeLOVSetID
							WHEN ColumnName ='planner_family' THEN @plannerFamilyLOVSetID
							WHEN ColumnName ='footprint' THEN @footprintLOVSetID
							WHEN ColumnName ='category' THEN @categoryLOVSetID
							WHEN ColumnName ='format' THEN @formatLOVSetID
							ELSE NULL
						END AS [columnId]
					FROM
					(
						SELECT * FROM [psa].[no_crp_merchandise_temp] A
							WHERE [row_status]=@rowStatusPSACode 
							AND [date_added]=@dateAdded
							AND LOVRecordSourceId = @LOVRecordSourceId
							AND LOVSourceKeyTypeId = @dbKeyTypeId
					) A
					UNPIVOT
					(
						[ColumnValue] for [ColumnName] in ([fitting_type],[planner_family],[footprint], [category], [format])
					) as U
				) A
				JOIN [ser].[reflovsetinfo] B
					on B.LOVSetId = A.columnId
					AND A.ColumnValue=B.LovName
				WHERE A.ColumnValue IS NOT NULL AND A.ColumnValue <> ''
			)
			
			INSERT INTO [ser].[PlanogramGroup]
			(
				[PlanogramGroupId]
				,[PlanogramId]
				,[LOVPlanogramGroupSetId]
				,[LOVGroupId]
				,[ParentPlanogramGroupId]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,[SCDEndDate]
				,[SCDActiveFlag]
				,[SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			)
			(
				SELECT 
					[PlanogramGroupId]
					,[PlanogramId]
					,[LOVPlanogramGroupSetId]
					,[LOVGroupId]
					,[ParentPlanogramGroupId]
					,[LOVRecordSourceId]
					,CASE WHEN ((ROW_NUMBER() OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC)) = 1)
													THEN @SCDDefaultStartDate
													ELSE @SCDStartDate
													END 
						[SCDStartDate]
					,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) [SCDEndDate]
					,[SCDActiveFlag]
					,ROW_NUMBER() OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) AS [SCDVersion]
					,[SCDLOVRecordSourceId]
					,[ETLRunLogId]
					,[PSARowKey] 
				FROM 
				(
					SELECT 
						@max_PlanogramGroupId + (dense_rank() over (order by PlanogramId,LOVGroupId asc)) as [PlanogramGroupId]
						,[PlanogramId]
						,[LOVPlanogramGroupSetId]
						,[LOVGroupId]
						,[ParentPlanogramGroupId]
						,[LOVRecordSourceId]
						,date_added AS [date_added]
						,[SCDEndDate]
						,LEAD('N', 1, 'Y') OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY PlanogramId,LOVGroupId,date_added ASC) AS [SCDActiveFlag]
						,[SCDLOVRecordSourceId]
						,[ETLRunLogId]
						,[PSARowKey]
					FROM
					(
						SELECT 
							B.PlanogramID 				AS	[PlanogramId]
							,A.ColumnID 				AS	[LOVPlanogramGroupSetId]
							,A.LOVId 					AS	[LOVGroupId]
							,NULL 						AS	[ParentPlanogramGroupId]
							,A.date_added 				AS	[date_added]
							,@SCDDefaultEndDate 		AS	[SCDEndDate]
							,@LOVRecordSourceId 		AS	[LOVRecordSourceId]
							,@SCDLOVRecordSourceId 		AS	[SCDLOVRecordSourceId]
							,@serveETLRunLogID 			AS	[ETLRunLogId]
							,A.PSARowKey 				AS	[PSARowKey]
						FROM Stg_no_crp_merchandise A
						JOIN Stg_Planogram B
							ON A.SourceKey = B.SourceKey
							AND A.LOVRecordSourceId = B.LOVRecordSourceId
							AND A.[ParentPlanogramID] = B.[ParentPlanogramID]
							AND B.LOVSourceKeyTypeId = @dbKeyTypeId
						
					) temp
				) A
				WHERE A.[SCDActiveFlag] = 'Y'
				AND A.[date_added] = @dateAdded
			)
			
			/*
				TABLE 03	: [ser].[PlanogramIndicator]
			*/
		
			PRINT 'Info: Processing [ser].[PlanogramIndicator] FOR Date : '+@dateAdded+'';
			WITH Stg_Planogram AS
			(
				SELECT 
					SourceKey
					,LOVRecordSourceId
					,LOVSourceKeyTypeId
					,ParentPlanogramID
					,max(PlanogramId) as PlanogramId
				FROM [ser].[Planogram] A
					WHERE LOVRecordSourceId = @LOVRecordSourceId
					AND LOVSourceKeyTypeId = @dbKeyTypeId
					AND ETLRunLogId = @serveETLRunLogID
					AND NOT EXISTS	(
										SELECT 1 FROM [ser].[Planogram] B
											WHERE A.PlanogramId = B.PlanogramId
											AND A.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
											AND A.LOVRecordSourceId = B.LOVRecordSourceId
											AND A.ScdVersion > B.ScdVersion
									)
					group by SourceKey,LOVRecordSourceId,LOVSourceKeyTypeId,ParentPlanogramID
			),
			Stg_no_crp_merchandise AS
			(
				SELECT * FROM [psa].[no_crp_merchandise_temp] A
							WHERE row_status=@rowStatusPSACode 
							AND LOVSourceKeyTypeId=@dbKeyTypeId
							AND date_added=@dateAdded
			)
			
			INSERT INTO [ser].[PlanogramIndicator]
			(	[PlanogramId]
				,[LovIndicatorId]
				,[Value]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,[SCDEndDate]
				,[SCDActiveFlag]
				,[SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			)
			(
				SELECT 
				[PlanogramId]
				,[LovIndicatorId]
				,[Value]
				,[LOVRecordSourceId]
				,CASE WHEN ((ROW_NUMBER() OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC)) = 1)
													THEN @SCDDefaultStartDate
													ELSE @SCDStartDate
													END 
						[SCDStartDate]
				,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC) [SCDEndDate]
				,LEAD('N', 1, 'Y') OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC) AS [SCDActiveFlag]
				,ROW_NUMBER() OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [date_added] ASC) AS [SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey] 
				FROM 
				(
					SELECT 
						[PlanogramId]
						,[LovIndicatorId]
						,[Value]
						,[LOVRecordSourceId]
						,[date_added]
						,[SCDEndDate]
						,LEAD('N', 1, 'Y') OVER(PARTITION BY [PlanogramId],[LovIndicatorId],[Value] ORDER BY [date_added] ASC) AS [SCDActiveFlag]
						,[SCDLOVRecordSourceId]
						,[ETLRunLogId]
						,[PSARowKey]
					FROM 
					(		
						SELECT 
							B.PlanogramId AS [PlanogramId]
							,@indicatorLOVID AS [LovIndicatorId]
							,A.promotional_site AS [Value]
							,@LOVRecordSourceId AS [LOVRecordSourceId]
							,A.date_added AS [date_added]
							,@SCDDefaultEndDate [SCDEndDate]
							,@LOVRecordSourceId [SCDLOVRecordSourceId]
							,@serveETLRunLogID AS [ETLRunLogId]
							,A.PSARowKey AS [PSARowKey]
						FROM Stg_no_crp_merchandise A
						JOIN Stg_Planogram B
							ON A.SourceKey = B.SourceKey
							AND A.LOVRecordSourceId = B.LOVRecordSourceId
							AND B.LOVSourceKeyTypeId = @dbKeyTypeId
							AND A.[ParentPlanogramID] = B.[ParentPlanogramID]
							AND A.promotional_site IS NOT NULL AND A.promotional_site <> ''
					) temp
				) A
				WHERE A.[SCDActiveFlag] = 'Y'
				AND A.[date_added] = @dateAdded
			)
			
			PRINT 'Info: Data Loaded IN [ser].[PlanogramIndicator] FOR Date : '+@dateAdded+'';
			
			/*
				TABLE 04	: [ser].[PlanogramProperty]
			*/
			PRINT 'Info: Processing [ser].[PlanogramProperty] FOR Date : '+@dateAdded+'';
			WITH Stg_Planogram AS
			(
				SELECT 
					SourceKey
					,LOVRecordSourceId
					,LOVSourceKeyTypeId
					,ParentPlanogramID
					,max(PlanogramId) as PlanogramId
				FROM [ser].[Planogram] A
					WHERE LOVRecordSourceId = @LOVRecordSourceId
					AND LOVSourceKeyTypeId = @dbKeyTypeId
					AND ETLRunLogId = @serveETLRunLogID
					AND NOT EXISTS	(
										SELECT 1 FROM [ser].[Planogram] B
											WHERE A.PlanogramId = B.PlanogramId
											AND A.LOVSourceKeyTypeId = B.LOVSourceKeyTypeId
											AND A.LOVRecordSourceId = B.LOVRecordSourceId
											AND A.ScdVersion > B.ScdVersion
									)
					group by SourceKey,LOVRecordSourceId,LOVSourceKeyTypeId,ParentPlanogramID
			),
			Stg_no_crp_merchandise AS
			(
				SELECT 
					[Sourcekey]
					,[ParentPlanogramID]
					,[date_added]
					,LOVRecordSourceId
					,[PSARowKey]
					,[ColumnValue]
					,[ColumnName]  
					,[MeasureId]
					,[LOVUOMId]
				FROM
				(
					SELECT 
						[Sourcekey]
						,[ParentPlanogramID]
						,[date_added]
						,LOVRecordSourceId
						,[PSARowKey]
						,[ColumnValue]
						,[ColumnName]  
						,CASE
							WHEN ColumnName ='shelf_depth' THEN @shelfDepthMeasureID
							WHEN ColumnName ='height' THEN @heightMeasureID
							WHEN ColumnName ='build_size' THEN @buildSizeMeasureID
							ELSE NULL
						END AS [MeasureId]
						,CASE
							WHEN ColumnName ='shelf_depth' THEN @LOVIdUnitCM
							WHEN ColumnName ='height' THEN @LOVIdUnitCM
							WHEN ColumnName ='build_size' THEN @LOVIdUnitUnKnown
							ELSE NULL
						END AS [LOVUOMId]
					FROM
					(
						SELECT * FROM [psa].[no_crp_merchandise_temp] A
							WHERE row_status=@rowStatusPSACode 
							AND lovsourcekeytypeid=@dbKeyTypeId
							AND date_added=@dateAdded
					) A
					UNPIVOT
					(
						[ColumnValue] FOR [ColumnName] IN ([shelf_depth],[height],[build_size])
					) AS U
				) T
				WHERE ColumnValue IS NOT NULL AND ColumnValue <> ''
				
			)
	
			INSERT INTO [ser].[PlanogramProperty]
			(
				[PlanogramId]
				,[MeasureId]
				,[LOVUOMId]
				,[Value]
				,[LOVRecordSourceId]
				,[SCDStartDate]
				,[SCDEndDate]
				,[SCDActiveFlag]
				,[SCDVersion]
				,[SCDLOVRecordSourceId]
				,[ETLRunLogId]
				,[PSARowKey]
			)
			(
				SELECT 
					[PlanogramId]
					,[MeasureId]
					,[LOVUOMId]
					,[Value]
					,[LOVRecordSourceId]
					,CASE WHEN ((ROW_NUMBER() OVER(PARTITION BY [PlanogramId],[MeasureId] ORDER BY [date_added] ASC)) = 1)
															THEN @SCDDefaultStartDate
															ELSE @SCDStartDate
															END 
								[SCDStartDate]
					,LEAD(@SCDEndDate,1,@SCDDefaultEndDate) OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [date_added] ASC) AS [SCDEndDate]
					,LEAD('N',1,'Y') OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [date_added] ASC) AS [SCDActiveFlag]
					,ROW_NUMBER() OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [date_added] ASC) AS [SCDVersion]
					,[SCDLOVRecordSourceId]
					,[ETLRunLogId]
					,[PSARowKey]
				FROM
				(
					SELECT
						[PlanogramId]
						,[MeasureId]
						,[LOVUOMId]
						,[Value]
						,[LOVRecordSourceId]
						,[date_added]
						,[SCDEndDate]
						,LEAD('N',1,'Y') OVER (PARTITION BY PlanogramId,MeasureId,Value ORDER BY [date_added] ASC) AS [SCDActiveFlag]
						,[SCDLOVRecordSourceId]
						,[ETLRunLogId]
						,[PSARowKey]
					FROM
					(
						SELECT 
								B.PlanogramId AS [PlanogramId]
								,A.MeasureId AS [MeasureId]
								,A.LOVUOMId AS [LOVUOMId]
								,A.ColumnValue AS [Value]
								,@LOVRecordSourceId AS [LOVRecordSourceId]
								,A.date_added AS [date_added]
								,@SCDDefaultEndDate [SCDEndDate]
								,@LOVRecordSourceId AS [SCDLOVRecordSourceId]
								,@serveETLRunLogID AS [ETLRunLogId]
								,A.PSARowKey AS [PSARowKey]
							FROM Stg_no_crp_merchandise A
							JOIN Stg_Planogram B
								ON A.SourceKey = B.SourceKey
								AND A.LOVRecordSourceId = B.LOVRecordSourceId
								AND A.[ParentPlanogramID] = B.[ParentPlanogramID]
								AND B.LOVSourceKeyTypeId = @dbKeyTypeId
					) temp
				)  A
				WHERE A.[SCDActiveFlag] = 'Y'
				AND A.[date_added] = @dateAdded
			)
			
			PRINT 'Info: Data Loaded IN [ser].[PlanogramProperty] FOR Date : '+@dateAdded+'';
			
			UPDATE [psa].[no_crp_merchandise]   
				SET row_status=@rowStatusSERCode
			FROM [psa].[no_crp_merchandise]  thmer
			INNER JOIN
			(
				(
					SELECT distinct 
						[PSARowKey] 
					FROM [ser].[Planogram] 
					WHERE LOVRecordsourceID = @LOVRecordsourceID 
				)
			
				UNION ALL  
				
				(
					SELECT distinct 
						[PSARowKey] 
					FROM [ser].[PlanogramGroup]
					WHERE LOVRecordsourceID=@LOVRecordsourceID
				)
					
				UNION ALL  
				
				(
					SELECT distinct 
						[PSARowKey]  
					FROM [ser].[PlanogramIndicator]
					WHERE LOVRecordsourceID = @LOVRecordsourceID
				)
			
				UNION ALL  
				
				(	
					SELECT distinct 
						psarowkey 
					FROM [ser].[PlanogramIndicator]  
					WHERE LOVRecordsourceID = @LOVRecordsourceID
				)
			) temp
			ON   temp.psarowkey=thmer.row_id
			WHERE thmer.row_status=@rowStatusPSACode
			AND thmer.date_added=@dateAdded;
			
			UPDATE [psa].[no_crp_merchandise]  
				SET Row_Status=@rowStatusSERCode
			FROM [psa].[no_crp_merchandise]  thmer 
			INNER JOIN [ser].[Planogram] p 
			ON thmer.record_source_id=LovRecordSourceID
				AND  thmer.pog_id =p.sourcekey
				AND  LOVSourceKeyTypeId=@pogIdTypeId
				AND ETLRunLogId = @serveETLRunLogID
			WHERE thmer.Row_Status=@rowStatusPSACode   
			AND date_added=@dateAdded
			AND (
					(
						NULLIF(thmer.pog_description,'' ) IS NULL
						AND NULLIF( thmer.planogram_start_date,'' ) IS NULL 
						AND NULLIF( thmer.planogram_end_date,'') IS NULL
					) 
					OR 
					(
						NULLIF(thmer.fitting_type,'') IS NULL 
						OR NULLIF(thmer.planner_family,'') IS NULL 
						OR NULLIF(thmer.footprint,'') IS NULL 
						OR NULLIF(thmer.category,'') IS NULL  
						OR NULLIF(thmer.format,'') IS NULL
						OR NULLIF(thmer.promotional_site ,'') IS NULL 
						OR NULLIF(thmer. shelf_depth,'') IS NULL
						OR NULLIF(thmer.height,'') IS NULL
						OR NULLIF(thmer.build_size,'') IS NULL
					)
				)	
				
			UPDATE [psa].[no_crp_merchandise]
				SET row_status=@rowStatusNotmigratedCode                                                                                      
			WHERE row_status=@rowStatusPSACode
			AND date_added=@dateAdded;
			
			-- UPDATE COUNTER
			SET @COUNTER = @COUNTER + 1	
		END
		
	COMMIT TRANSACTION;		
		
	END TRY
    BEGIN CATCH
    THROW;
    ROLLBACK TRANSACTION;    
    END CATCH 
END
GO
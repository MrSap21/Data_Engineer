/****** Object:  UserDefinedFunction [psa].[fn_GetDQSelect]    Script Date: 9/9/2020 2:02:11 PM ******/
IF OBJECT_ID('psa.fn_GetDQSelect') IS NOT NULL
BEGIN
	DROP FUNCTION [psa].[fn_GetDQSelect]
END;
GO

/****** Object:  UserDefinedFunction [psa].[fn_GetDQSelect]    Script Date: 9/9/2020 2:02:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [psa].[fn_GetDQSelect] (@pEntityID [bigint],@pSchemaName [nvarchar](500),@pTableName [nvarchar](500),@pDQTable [nvarchar](500),@pAttributeName [nvarchar](500),@pRuleID [int],@pRuleEntityID [int],@pAttributeID [int],@pAttributeExpression [nvarchar](4000),@petl_runlog_id [bigint]) RETURNS nvarchar(4000)
AS
BEGIN  
    DECLARE @Expression nvarchar(4000) = N'';  
	declare @nl nchar(2);
	set @nl = concat(char(13),char(10));

	set @Expression = concat(@Expression, N'SELECT ', @nl)
	set @Expression = concat(@Expression, @pRuleID, N' RuleID,', @nl)
	set @Expression = concat(@Expression, @pEntityID, N' EntityID,', @nl)
	set @Expression = concat(@Expression, @pAttributeID, N' AttributeID,', @nl)
	set @Expression = concat(@Expression, N' [etl_runlog_id] ETLRunLogID,', @nl) -- select column as ETLRunLogID
	set @Expression = concat(@Expression, N' [asset_id] AssetID,', @nl) -- select column as ETLRunLogID
	set @Expression = concat(@Expression, @pEntityID, N' [SourceEntityID],', @nl)
	set @Expression = concat(@Expression, @pAttributeID, N' [SourceAttributeID],', @nl)
	set @Expression = concat(@Expression, N' [row_id] PSARowKey,', @nl) -- -- select column as PSARowKey
	if @pRuleID = 13
	begin
		set @Expression = concat(@Expression, @pAttributeExpression, @nl)
	end
	else
	begin
		set @Expression = concat(@Expression, @pAttributeExpression, N' RuleExpression,', @nl)
		set @Expression = concat(@Expression, N'''', replace(@pAttributeExpression, '''', ''''''), N' + [' + @pSchemaName + N'].[' + @pTableName + N'].[' + @pAttributeName + N'] = ', N'''', N' + isnull([' + @pSchemaName + N'].[' + @pTableName + N'].[' + @pAttributeName + N'], ''NULL'') RuleDescription', @nl)
	end
	set @Expression = concat(@Expression, N'FROM [', @pSchemaName, N'].[', @pTableName, N']', @nl)
	set @Expression = concat(@Expression, N'WHERE row_status = 26001', @nl)
	if @petl_runlog_id is not null 
	begin
		set @Expression = concat(@Expression, N'	and [etl_runlog_id] = ', @petl_runlog_id, @nl)
	end
	RETURN(@Expression);  
END
GO
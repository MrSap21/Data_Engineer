/****** Object:  StoredProcedure [psa].[sp_cf_ref_reprocess]    Script Date: 8/28/2020 4:06:45 AM ******/
IF OBJECT_ID('psa.sp_cf_ref_reprocess') IS NOT NULL
BEGIN
	DROP PROC psa.sp_cf_ref_reprocess
END;
GO

/****** Object:  StoredProcedure [psa].[sp_cf_ref_reprocess]    Script Date: 8/28/2020 4:06:45 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [psa].[sp_cf_ref_reprocess] @TableName [varchar](500),@BusinessKeys [varchar](500) AS
/*
ProcedureName : [sp_cf_ref_reprocess]
Purpose       : This Procedure does the check against entries in PSA . Duplicate 26006 records along with active records (26001)
				will be quarantined (26009)
*/
DECLARE 
@sql varchar(8000),
@COUNTER int,
@MAXID int,
@keyQuery varchar(8000)='',
@KeyValue varchar(50),
@quarantine_status varchar(40) =26009,
@RuleTypeCode varchar(40) =26006,
@row_status varchar(40) =26001

SET @COUNTER = 1	
	BEGIN	
			IF OBJECT_ID('tempdb..#TempKeys') IS NOT NULL
				BEGIN
					DROP TABLE #TempKeys					
				END

				SELECT ROW_NUMBER() OVER(ORDER BY Value) AS RowNo ,Value into #TempKeys FROM STRING_SPLIT(@BusinessKeys, ',')
				SELECT @MAXID = COUNT(*) FROM #TempKeys
				
				WHILE (@COUNTER <= @MAXID)	
					BEGIN
						SELECT @KeyValue=Value FROM #TempKeys WHERE RowNo=@COUNTER				
						IF(@keyQuery != '')
							BEGIN 
								SET @keyQuery = @keyQuery+' AND cte.'+@KeyValue+'=t1.'+@KeyValue;
							END
						ELSE
							BEGIN	
								SET @keyQuery = 'cte.'+@KeyValue+'=t1.'+@KeyValue;
							END
					SET @COUNTER = @COUNTER + 1
					END

					SET @sql='WITH businesskey_cte AS (select distinct '+@BusinessKeys+',row_status from [psa].['+@TableName+']
														where row_status in ('+@row_status+','+@RuleTypeCode+')) 
								,quarantine_cte as (select '+@BusinessKeys+' from businesskey_cte group by '+@BusinessKeys+' having count(*) > 1  )
					UPDATE [psa].['+@TableName+ '] SET row_status='+@quarantine_status+' from [psa].['+@TableName+'] t1
					INNER JOIN quarantine_cte cte ON '+@keyQuery+' WHERE row_status ='+@RuleTypeCode				
					BEGIN TRANSACTION
					BEGIN TRY
						EXEC (@sql)
						COMMIT TRANSACTION;
					END TRY
					BEGIN CATCH 
						THROW;        
	        			ROLLBACK TRANSACTION ;
					END CATCH 
	END 
GO
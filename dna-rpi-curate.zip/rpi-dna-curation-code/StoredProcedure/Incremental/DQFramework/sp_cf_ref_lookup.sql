/****** Object:  StoredProcedure [psa].[sp_cf_ref_lookup]    Script Date: 03/09/2020 17:46:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_cf_ref_lookup') IS NOT NULL
BEGIN
	DROP PROC psa.sp_cf_ref_lookup
END;
GO

CREATE PROC [psa].[sp_cf_ref_lookup] @TableName [varchar](500),@RuleType [varchar](500),@EntityId [varchar](500) AS
/*
ProcedureName : [sp_cf_ref_lookup]
Purpose       : This Procedure Does the Quality Check against the refLOV and ReflovSet table values
                and update the psa table row_status with the error code 26006(Missing Lookup Reference)
*/
DECLARE 
@sql varchar(8000),
@dqEntityRows varchar(8000),
@sqlReprocess varchar(8000),
@sqlupdate varchar(8000),
@COUNTER int,
@MAXID int,
@RuleSetName varchar(500),
@ColumnName varchar(500),
@RefLovSetTab  varchar(4000)='reflovsetInfo',
@RuleTypeCode varchar(40) =26006,
@row_status varchar(40) =26001,
@flag int =0,
@RecordSourceID  varchar(40),
@RuleId int =0,
@RuleCode varchar(40) ='RVC',
@AttributeId int =0,
@RuleDetails varchar(500),
@fnToApply varchar(500),
@etlUser varchar(40)=CURRENT_USER,
@currentDateTime varchar(500)=CURRENT_TIMESTAMP,
@SrcColumnwithExp  varchar(500),
@TargetColumnwithExp  varchar(500);
SET @COUNTER = 1	
	BEGIN
	SET NOCOUNT ON;
	   IF OBJECT_ID('tempdb..#TempIncDQRulesCheck') IS NOT NULL
				BEGIN
					DROP TABLE #TempIncDQRulesCheck					
				END
		SELECT  ROW_NUMBER() OVER(ORDER BY RecordSourceID,ColumnName) rowid,RuleSetName,ColumnName,fnToApply,RecordSourceID,TableName 
		INTO #TempIncDQRulesCheck 
		FROM psa.[RuleRefLookup] WHERE ActiveFlag ='Y' and RuleKey is null and lower(RuleType)=lower(''+@RuleType+'') and lower(TableName)=lower(''+@TableName+'');
		
		SELECT @MAXID = COUNT(*) FROM #TempIncDQRulesCheck;
		
		SELECT @RuleId=RuleId FROM [psa].[Rule] where RuleCode = @RuleCode;

		BEGIN TRANSACTION
		BEGIN TRY
			WHILE (@COUNTER <= @MAXID)	
				BEGIN 
						Print 'Counter '+cast(@COUNTER as varchar(10))
						SET @sql=null
						SET @sqlReprocess=null
						SET @dqEntityRows=null
						SET @RuleDetails=null

						SELECT @RuleSetName=dq.RuleSetName ,@ColumnName=dq.ColumnName,@fnToApply=fnToApply,@RecordSourceID=dq.RecordSourceID, @TableName=dq.TableName
						from #TempIncDQRulesCheck as dq WHERE rowid=@COUNTER;
						SELECT @AttributeId=[AttributeId] FROM [psa].[Attribute] WHERE [AttributeName] = ''+@ColumnName+''
						SELECT @TargetColumnwithExp=  ISNULL(NULLIF(REPLACE(@fnToApply,'$Column','rf.LOVKey'),''),'rf.LOVKey' )
						--PRINT  '@TargetColumnwithExp:'+ @TargetColumnwithExp;
						SELECT @SrcColumnwithExp =  ISNULL(NULLIF(REPLACE(@fnToApply,'$Column','SrcTab.'+@ColumnName),''),'SrcTab.'+@ColumnName ) 
						--PRINT  '@SrcColumnwithExp:'+ @SrcColumnwithExp
						IF (@RecordSourceID !='' and @RecordSourceID is not null)					
							BEGIN							
						  		-- Set the status of missing refLOV records as 26006 in PSA table
								SET @sql ='UPDATE [psa].['+@TableName+']
									SET row_status = CAST ('+@RuleTypeCode+' as int)
									FROM [psa].['+@TableName+'] SrcTab
									left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
									ser.'+@RefLovSetTab+' rl
									where rl.LOVSetName = trim('''+@RuleSetName+''') )rf
									on rf.LOVRecordsourceId = '+@RecordSourceID+' and '+@TargetColumnwithExp+' = '+@SrcColumnwithExp+' 
									WHERE (SrcTab.'+@ColumnName+' is not null  and SrcTab.'+@ColumnName+'!= '''') AND
									  SrcTab.row_status = '+@row_status+' AND 
									rf.LOVRecordsourceId is null'
									
								-- Reprocess query to change the status to 26001 for records that have entry in RefLOV in PSA table
								SET @sqlReprocess ='UPDATE [psa].['+@TableName+']
									SET row_status = CAST ('+@row_status+' as int)
									FROM [psa].['+@TableName+'] SrcTab
									left join (select  rl.LOVId,rl.LOVRecordsourceId,rl.lovkey FROM
									ser.'+@RefLovSetTab+' rl                  
									where rl.LOVSetName = trim('''+@RuleSetName+''') )rf on rf.LOVRecordsourceId = '+@RecordSourceID+
									' and '+@TargetColumnwithExp+' = '+@SrcColumnwithExp+' 
									WHERE (SrcTab.'+@ColumnName+' is not null  
									and SrcTab.'+@ColumnName+'!= '''') AND SrcTab.row_status = '+@RuleTypeCode+' AND rf.LOVRecordsourceId is not null'
									
								-- INSERT Query to RuleInstanceEntity table
								SET @RuleDetails = 	'Look up failed for the column '+@ColumnName + ' for table '+@TableName
								SET @dqEntityRows = 'INSERT INTO [psa].[RuleEntityInstance] ([RuleID],[EntityID],[AttributeID],[RuleDetail],
									[ETLRunLogID],[SourceEntityID],[SourceAttributeID],[PSARowKey],[DTCreated],[UserCreated]) 
									SELECT '+cast(@RuleId as VARCHAR)+','+@EntityId+','+cast(@AttributeId as VARCHAR)+','''+ @RuleDetails+''',
									SrcTab.etl_runlog_id,'+@EntityId+','+cast(@AttributeId as VARCHAR)+' ,SrcTab.row_id,'''+@currentDateTime+''','''+@etlUser+
									''' FROM [psa].['+@TableName+'] SrcTab left join (select rl.LOVId,rl.LOVRecordsourceId,rl.lovkey FROM 
									ser.'+@RefLovSetTab+' rl where rl.LOVSetName = trim('''+@RuleSetName+''') )rf 
									on rf.LOVRecordsourceId = '+@RecordSourceID+' and '+@TargetColumnwithExp+' = '+@SrcColumnwithExp+' WHERE (SrcTab.'+@ColumnName+' is not null  
									and SrcTab.'+@ColumnName+'!= '''') AND SrcTab.row_status = '+@row_status+' AND rf.LOVRecordsourceId is null'
									
							 END
						  
						ELSE 
						BEGIN
								-- Set the status of missing refLOV records as 26006 in PSA table
								SET @sql ='UPDATE [psa].['+@TableName+']
									SET row_status = CAST ('+@RuleTypeCode+' as int)
									FROM [psa].['+@TableName+'] SrcTab
									left join (select  rl.LOVId,rl.LOVRecordsourceId,rl.lovkey FROM
									ser.'+@RefLovSetTab+' rl
									where rl.LOVSetName = trim('''+@RuleSetName+''' ) )rf
									on '+@TargetColumnwithExp+' = '+@SrcColumnwithExp+'
									WHERE (SrcTab.'+@ColumnName+' is not null  and SrcTab.'+@ColumnName+'!= '''') 
											AND SrcTab.row_status = '+@row_status+' AND 
											rf.LOVRecordsourceId is null'

								-- INSERT Query to RuleInstanceEntity table
								SET @RuleDetails = 	'Look up failed for the column '+@ColumnName + ' for table '+@TableName
								SET @dqEntityRows = 'INSERT INTO [psa].[RuleEntityInstance] ([RuleID],[EntityID],[AttributeID],[RuleDetail],
									[ETLRunLogID],[SourceEntityID],[SourceAttributeID],[PSARowKey],[DTCreated],[UserCreated]) 
									SELECT '+cast(@RuleId as VARCHAR)+','+@EntityId+','+cast(@AttributeId as VARCHAR)+','''+ @RuleDetails+'''
									,SrcTab.etl_runlog_id,'+@EntityId+','+cast(@AttributeId as VARCHAR)+' ,SrcTab.row_id,'''+@currentDateTime+''','''+@etlUser+
									''' FROM [psa].['+@TableName+'] SrcTab left join (select  rl.LOVId,rl.LOVRecordsourceId,rl.lovkey FROM
									ser.'+@RefLovSetTab+' rl								                
									where rl.LOVSetName = trim('''+@RuleSetName+''' ) )rf
									on '+@TargetColumnwithExp+' = '+@SrcColumnwithExp+'
									WHERE (SrcTab.'+@ColumnName+' is not null  and SrcTab.'+@ColumnName+'!= '''')
											AND SrcTab.row_status = '+@row_status+' AND 
											rf.LOVRecordsourceId is null'

								-- Reprocess query to change the status to 26001 for records that have entry in RefLOV in PSA table
								SET @sqlReprocess ='UPDATE [psa].['+@TableName+']
										SET row_status = CAST ('+@row_status+' as int)
										FROM [psa].['+@TableName+'] SrcTab
									left join (select  rl.LOVId,rl.LOVRecordsourceId,rl.lovkey FROM
									ser.'+@RefLovSetTab+' rl								                 
									where rl.LOVSetName = trim('''+@RuleSetName+''' ) )rf
									on '+@TargetColumnwithExp+' = '+@SrcColumnwithExp+'  
									WHERE (SrcTab.'+@ColumnName+' is not null  and SrcTab.'+@ColumnName+'!= '''')  
										   AND SrcTab.row_status = '+@RuleTypeCode+' AND   rf.LOVRecordsourceId is not null'									
														
							END	
							BEGIN
							        EXEC (@sqlReprocess);	
									EXEC (@dqEntityRows);						
									--EXEC (@sql);
							END

						SET @COUNTER = @COUNTER + 1			
	         
				 END

				 SET @sqlupdate='UPDATE [psa].['+@TableName+']
									SET row_status = CAST ('+@RuleTypeCode+' as int)
									FROM [psa].['+@TableName+'] SrcTab,[psa].[RuleEntityInstance] rei
									where rei.EntityID='+@EntityId+' and RuleID='+cast(@RuleId as VARCHAR)+'and DtCreated='''+@currentDateTime+''' 
									and SrcTab.row_id=rei.psarowkey and SrcTab.etl_runlog_id=rei.ETLrunlogid'
				EXEC (@sqlupdate);

		COMMIT TRANSACTION;
		END TRY
					
		BEGIN CATCH 
			THROW;        
	        ROLLBACK TRANSACTION ;
		END CATCH 
 END
GO
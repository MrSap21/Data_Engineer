/****** Object:  StoredProcedure [psa].[sp_inc_DQAnomaliesCheck]    Script Date: 10/5/2020 6:15:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_DQAnomaliesCheck') IS NOT NULL
BEGIN
	DROP PROC psa.sp_inc_DQAnomaliesCheck
END;
GO

CREATE PROC [psa].[sp_inc_DQAnomaliesCheck] @table_Name [nvarchar](max) AS
/*Purpose : The procedure will identify and log the Anomalies in Data Quality(incremental)
 TableName(logs) : psa.[DQAnomalies]
 */
DECLARE 
@sql varchar(8000),
@COUNTER int,
@Cnt int,
@MAXID int,
@RuleSetName varchar(500),
@ColumnName varchar(500),
@RecordSourceId [varchar](500),
@TableName [varchar](500),
@fnToApply [varchar](500),
@RuleType [varchar](500),
@RuleKey [varchar](500),
@row_status [varchar] (20)=26001,
@SrcColumnwithExp  varchar(500),
@TargetColumnwithExp  varchar(500);
SET @COUNTER = 1
IF  OBJECT_ID('tempdb..#TempIncDQAnomaliesCheck') IS NOT NULL
BEGIN
    DROP TABLE #TempIncDQAnomaliesCheck
END
IF trim(upper(@table_Name))=trim(upper('ALLSOURCES'))
BEGIN
	SET @table_Name=  (SELECT STRING_AGG(tablename, ',')  
                     FROM (select distinct tablename FROM psa.DQRules) t); 						 
END
    PRINT 'TableName : ' +@table_Name
	BEGIN	     
		SELECT  ROW_NUMBER() OVER(ORDER BY RecordSourceID) rowid,
		        RuleType,RuleSetName,RuleKey,ColumnName,
				RecordSourceID,TableName,fnToApply 
		INTO #TempIncDQAnomaliesCheck
		FROM psa.[RuleRefLookup] WHERE ActiveFlag ='Y' and tableName in  (SELECT value FROM STRING_SPLIT(@table_Name, ',')) ;
		SELECT @MAXID = COUNT(*) FROM #TempIncDQAnomaliesCheck;		
		WHILE (@COUNTER <= @MAXID)
		BEGIN
			BEGIN TRY
				SELECT @RuleSetName=dq.RuleSetName ,@ColumnName=dq.ColumnName,@RecordSourceID=dq.RecordSourceID, @TableName=dq.TableName,@RuleType=dq.RuleType,@fnToApply=dq.fnToApply,@RuleKey=dq.RuleKey
				from #TempIncDQAnomaliesCheck as dq WHERE rowid=@COUNTER ;	
				SELECT @TargetColumnwithExp=  ISNULL(NULLIF(REPLACE(@fnToApply,'$Column','rf.LOVKey'),''),'rf.LOVKey' )
						--PRINT  '@TargetColumnwithExp:'+ @TargetColumnwithExp;
				SELECT @SrcColumnwithExp =  ISNULL(NULLIF(REPLACE(@fnToApply,'$Column','Tab.'+@ColumnName),''),'Tab.'+@ColumnName ) 
						--PRINT  '@SrcColumnwithExp:'+ @SrcColumnwithExp					
				IF @RuleType='MissingLookupKeys' 
						BEGIN
							--PRINT  'Rowid:' +cast (@COUNTER  as varchar)+'RuleType:'+@RuleType+';TableName:'+@TableName+';Column :'+@ColumnName+';RuleSetName:'+@RuleSetName+';RecordSourceID :'+@RecordSourceID;
							SET @sql ='INSERT INTO psa.[DQAnomalies](RuleType,tableName,ColumnName,KeyValue,row_id,RecordSourceId,created_timestamp)
										SELECT DISTINCT  '''+@RuleType+''' as RuleType, '''+@TableName+''' as tableName,'''+@RuleSetName+''' LOVSetName, 
											tab.'+@ColumnName+' as LOVKEY,tab.row_id,'+@RecordSourceID+',current_timestamp
										FROM [psa].['+@TableName+'] tab
												left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
												ser.RefLovSetInfo rl where rl.LOVSetName = trim('''+@RuleSetName+''') )rf
											 on rf.LOVRecordSourceId='+@RecordSourceID+' and  
												'+@TargetColumnwithExp+' = '+@SrcColumnwithExp+'
											   WHERE  (tab.'+@ColumnName+' is not null  and tab.'+@ColumnName+'!= '''') and												 
											  rf.LOVRecordSourceId is null and Tab.row_status = '+@row_status ;
							--PRINT (@sql )
							EXEC (@sql )
						END
			END TRY
			BEGIN CATCH
				PRINT '!!ERROR: RuleType : '+@RuleType+'; TableName :'+@TableName+' ; Rowid:'+cast (@COUNTER  as varchar);
				PRINT 'ErrorNumber : '+ cast (ERROR_NUMBER()  as varchar)+ ', ErrorMessage : ' +ERROR_MESSAGE() ;    
				THROW	       
			END CATCH 
			SET @COUNTER = @COUNTER + 1;
	    END
END
GO
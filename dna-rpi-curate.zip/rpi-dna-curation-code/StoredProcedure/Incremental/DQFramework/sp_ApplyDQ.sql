/****** Object:  StoredProcedure [psa].[sp_ApplyDQ]    Script Date: 9/10/2020 9:52:58 AM ******/
IF OBJECT_ID('psa.sp_ApplyDQ') IS NOT NULL
BEGIN
	DROP PROC [psa].[sp_ApplyDQ]
END;

GO

/****** Object:  StoredProcedure [psa].[sp_ApplyDQ]    Script Date: 9/30/2020 9:44:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [psa].[sp_ApplyDQ] @pCleansedEntityId [bigint],@pPSAEntityId [bigint],@pETLRunlogId [bigint] AS
BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON

	declare @Table nvarchar(500);
	declare @Schema nvarchar(500);
	declare @DQTableC nvarchar(500); --column rules
	declare @DQTableR nvarchar(500); --row rules
	declare @today nchar(10);
	declare @currenttime datetime;
	declare @nl nchar(2);
	declare @CTASExprsssionC nvarchar(max);
	declare @CTASExprsssionR nvarchar(max);
	declare @checktableC nvarchar(4000);
	declare @checktableR nvarchar(4000);
	declare @dqid bigint;

	set @Table = (select TableName from [psa].[Entity] where EntityID = @pPSAEntityID);
	set @Schema = (select SchemaName from [psa].[Entity] where EntityID = @pPSAEntityID);
	set @today = CONVERT(nchar(30), GETDATE(), 23);
	set @currenttime = CURRENT_TIMESTAMP;
	set @DQTableC = concat( N'[', @Schema, N'].[DQC_', @Table, N'_', @today, N']');
	set @DQTableR = concat( N'[', @Schema, N'].[DQR_', @Table, N'_', @today, N']');
	set @nl = concat(char(13),char(10));
	set @dqid = (select ISNULL(MAX([DQID]),0)+1 from [psa].[RuleEntityOperation])
	--check if no entity
	print concat('@pCleansedEntityId ',@pCleansedEntityId);
	print concat('@pPSAEntityId ', @pPSAEntityId);
	print concat('@Table ', @Table);
	print concat('@Schema ', @Schema);
	
	if not (
		exists(select 1 from psa.Entity where EntityId = @pPSAEntityId) --we have entity
		and exists(select 1 from psa.Attribute where EntityId = @pCleansedEntityId) --we have attribute
		and exists(select 1 from [psa].[RuleEntity] where EntityId = @pPSAEntityId and activeflag=1) --we have rule entity
		and   (		
				(
					exists( --we have a rule 13
						select 1
						from [psa].[RuleEntity] re
						where
						re.RuleID = 13
						and re.EntityId = @pPSAEntityId
						and re.activeflag=1
					) 
					and  exists(--if we have rule 13 we also have a business key and data key
								select 1 
								from [psa].[RuleEntity] re 
								inner join psa.Attribute ab on re.EntityId = @pPSAEntityId and ab.EntityId = @pCleansedEntityId
								inner join psa.Attribute ad on ad.EntityId = @pCleansedEntityId
								where 
								re.RuleID = 13
								and re.activeflag=1								
								and ab.AttributeType = 40001
								and ad.AttributeType = 40003
							)			
				)
			or 
			 not exists( --we do not have a rule 13
				select 1
				from [psa].[RuleEntity] re
				where
				re.RuleID = 13
				and re.activeflag=1
				and re.EntityId = @pPSAEntityId
				)
			)
	)
	begin
		--something is wrong, list out the config issue
		--no entity
		if not exists(select 1 from psa.Entity where EntityId = @pPSAEntityId)
		begin
			print concat(N'No entries in psa.Entity for ', @pPSAEntityId);
		end
		--no attributes
		if not exists(select 1 from psa.Attribute where EntityId = @pCleansedEntityId)
		begin
			print concat(N'No entries in psa.Attribute for ', @pCleansedEntityId);
		end
		--check if no rules entity
		if not exists(select 1 from [psa].[RuleEntity] where EntityId = @pPSAEntityId)
		begin
			print concat(N'No entries in [psa].[RuleEntity] for ', @pPSAEntityId);
		end
		if not exists( --if we have rule 13 we also have a business key and data key
			select 1 
			from [psa].[RuleEntity] re 
			inner join psa.Attribute ab on re.EntityId = @pPSAEntityId and ab.EntityId = @pCleansedEntityId
			inner join psa.Attribute ad on ad.EntityId = @pCleansedEntityId
			where 
			re.RuleID = 13
			and re.activeflag=1
			and ab.AttributeType = 40001
			and ad.AttributeType = 40003
		)
		begin
			print concat(N'In [psa].[RuleEntity] for ', @pPSAEntityId, N' rule 13 exists but ', case when exists(select 1 from psa.Attribute where EntityId = @pCleansedEntityId and AttributeType = 40001) then concat('no business key in psa.Attribute for entity ', @pCleansedEntityId) else concat('no data key in psa.Attribute for entity ', @pCleansedEntityId) end);
		end

	end

	else
	begin
		/*
		passed initail validity checks
		we can start doing real work
		*/
		--done
		--log table operations to another log table
		--check for missing config
		--failed values to the rule comment
		--fixed a null empty string bug
		--isnullable datatype check
		--logic for business duplicate check (add attributeType to attribute)
		--date logic for other date formats isdate does not recognize (add a column to entity attribtue for optional date format)
		--peformance
		--	create two dq tables
		--		remove union in rule selection
		--			two case column selection
		--			another parameter for rule function
		--improve performance
		--	create two CTAS
		--		add CI 
		--	create a different dq table for column and row rules
		--		add two variables to get rule expression
		--		remove pivot logic
		--		remove vector
		--  add to comments ordinal, dqid
		--  test out abacus product table with hash over row_id
		--	add the same row_id has to dq tables
		--	add clustered column or hash to dq tables (on row_id?)
		--  test out the big abacus product
		--bug for mismatching column names
			--Invalid column name 'psarowstatus'. (row_status)
			--Invalid column name 'ETLRunLogID'. (etl_runlog_id)
			--Invalid column name 'PSARowKey'. (row_id)
		--  add a custom date format
		--  add a custom time format
		--bug for missing asset id from business duplicate logic - fix applied in pre prod
		--added explicit rule ids for DQ 
		--added ETLRunLogIDs to DQR rule instances
		--remove dq tables after using them
		--	exit with no config with a message
		--  exit with no business key (on rule 13) with a relevant message
		--make the configuration tests more complete
		--handle large sql statement into statement log
		--fix for large number of attributes with tile windowing function

		--pending
		--cache algorithms 
		--  can one hash sys.sql_module and the tables?

		--  use sp_executesql
		--  is the hash binary or nvarchar faster?
		--	is the false/true faster than bit?
		--	Add ETL run log id to row logic
		--add the ability to simulate actions - only generate queries
		--plugin algorithms
		set @checktableC = concat(N'if object_id(N''',@DQTableC,''', N''U'') is not null drop table ',@DQTableC,';');
		set @checktableR = concat(N'if object_id(N''',@DQTableR,''', N''U'') is not null drop table ',@DQTableR,';');
		--print concat('@checktableC ', @checktableC);
		--print concat('@checktableR ', @checktableR);
		set @currenttime = CURRENT_TIMESTAMP;
		insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
		values (@dqid, 1, 1, @pPSAEntityId, @pETLRunlogId, @checktableC, @currenttime, N'DQ Framework');
		exec (@checktableC);
		set @currenttime = CURRENT_TIMESTAMP;
		insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
		values (@dqid, 2, 1, @pPSAEntityId, @pETLRunlogId, @checktableR, @currenttime, N'DQ Framework');
		exec (@checktableR);

	--try if other 	
	--CREATE TABLE dbo.DimProduct_upsert
	--WITH
	--(		Distribution=HASH([row_id])
	--,		CLUSTERED INDEX ([row_id])
	--,		CLUSTERED COLUMNSTORE INDEX
	--)
		set @CTASExprsssionC = concat(N'CREATE TABLE ', @DQTableC, @nl);
		set @CTASExprsssionC = concat(@CTASExprsssionC, N'WITH', @nl);
		set @CTASExprsssionC = concat(@CTASExprsssionC, N'(', @nl);
		set @CTASExprsssionC = concat(@CTASExprsssionC, N'	DISTRIBUTION = HASH([PSARowKey])', @nl);
		set @CTASExprsssionC = concat(@CTASExprsssionC, N'	,CLUSTERED COLUMNSTORE INDEX', @nl); --let's add
		set @CTASExprsssionC = concat(@CTASExprsssionC, N')', @nl);
		set @CTASExprsssionC = concat(@CTASExprsssionC, N'AS', @nl);
		--print @CTASExprsssionC;

		set @CTASExprsssionR = concat(N'CREATE TABLE ', @DQTableR, @nl);
		set @CTASExprsssionR = concat(@CTASExprsssionR, N'WITH', @nl);
		set @CTASExprsssionR = concat(@CTASExprsssionR, N'(', @nl);
		set @CTASExprsssionR = concat(@CTASExprsssionR, N'	DISTRIBUTION = HASH([PSARowKey])', @nl);
		set @CTASExprsssionR = concat(@CTASExprsssionR, N'	,CLUSTERED COLUMNSTORE INDEX', @nl); --let's add
		set @CTASExprsssionR = concat(@CTASExprsssionR, N')', @nl);
		set @CTASExprsssionR = concat(@CTASExprsssionR, N'AS', @nl);
		--print len(@CTASExprsssionR);

		IF OBJECT_ID('tempdb..#rules') IS NOT NULL
		BEGIN
			DROP TABLE #rules
			--PRINT 'DROP #rules'
		END
		--print 'create #rules'
		CREATE TABLE #rules(
			RuleEntityID bigint not null
			,EntityId bigint not null
			,RuleID bigint not null
			,SchemaName nvarchar(500) not null
			,TableName nvarchar(500) not null
			,AttributeName nvarchar(500) null
			,DQInsertExpression nvarchar(4000)
		)
		WITH
		(
			DISTRIBUTION = HASH(RuleEntityID)
		,    HEAP
		);

		with EntityRule1 as (
		select 
		EntityId
		,RuleID
		,AttributeId
		,RuleEntityID
		,SchemaName
		,TableName
		,AttributeName
		,IsNullable
		,psa.fn_GetRuleExpression(RuleID, SchemaName, TableName, AttributeName, IsNullable
	,case 
		when RuleId = 13 --business duplicate
		then 
			(
			case
			when (select count(AttributeName) from psa.Attribute where EntityId = @pCleansedEntityId and AttributeType = 40001) = 1
			then
				(
					select concat(N'HASHBYTES(''SHA2_256'', ', AttributeName, N')')
					from psa.Attribute
					where EntityId = @pCleansedEntityId 
					and AttributeType = 40001 --business keys columns
				)
			when (select count(AttributeName) from psa.Attribute where EntityId = @pCleansedEntityId and AttributeType = 40001) < 250
			then
				(
					select concat(N'HASHBYTES(''SHA2_256'', ', cnct, N')')
					from
					(
						select concat(N'concat(',AttributeName,N')') cnct
						from (
							select
								string_agg(AttributeName, ',') AttributeName
							from 
								(
								select AttributeName
								from psa.Attribute
								where EntityId = @pCleansedEntityId 
								and AttributeType = 40001 --data columns
								) attr
						) cnct
					) hashb
				)
			else
				(
					select concat(N'HASHBYTES(''SHA2_256'', ', cnct, N')')
					from
					(
					select concat(N'concat(',string_agg(concat(N'concat(',AttributeName,N')'), N','),')') cnct
					from (
					select
						string_agg(AttributeName, ',') AttributeName
					from 
						(
					select AttributeName
					,NTILE(4) OVER(ORDER BY AttributeId) tile
					from psa.Attribute
					where EntityId = @pCleansedEntityId 
					and AttributeType = 40001 --business key columns
						) attr
					group by 
						tile
					) attr_tile
					) cnct
				)
			end
			) 
		else 
			NULL 
	end --BusinessColumns
	,case 
		when RuleId = 13 --business duplicate
		then 
			(
			case
			when (select count(AttributeName) from psa.Attribute where EntityId = @pCleansedEntityId and AttributeType = 40003) = 1
			then
				(
					select concat(N'HASHBYTES(''SHA2_256'', ', AttributeName, N')')
					from psa.Attribute
					where EntityId = @pCleansedEntityId 
					and AttributeType = 40003 --data columns
				)
			when (select count(AttributeName) from psa.Attribute where EntityId = @pCleansedEntityId and AttributeType = 40003) < 250
			then 
				(
					select concat(N'HASHBYTES(''SHA2_256'', ', cnct, N')')
					from
					(
						select concat(N'concat(',AttributeName,N')') cnct
						from (
							select
								string_agg(AttributeName, ',') AttributeName
							from 
								(
								select AttributeName
								from psa.Attribute
								where EntityId = @pCleansedEntityId 
								and AttributeType = 40003 --data columns
								) attr
						) cnct
					) hashb
				)
			else
				(
					select concat(N'HASHBYTES(''SHA2_256'', ', cnct, N')')
					from
					(
					select concat(N'concat(',string_agg(concat(N'concat(',AttributeName,N')'), N','),')') cnct
					from (
					select
						string_agg(AttributeName, ',') AttributeName
					from 
						(
					select AttributeName
					,NTILE(4) OVER(ORDER BY AttributeId) tile
					from psa.Attribute
					where EntityId = @pCleansedEntityId 
					and AttributeType = 40003 --data columns
						) attr
					group by 
						tile
					) attr_tile
					) cnct
				)
			end
			) 
		else 
			NULL 
	end --DataColumns
	,(SELECT Value FROM OPENJSON([ConvertStyle])) ) AttributeExpression
		from 
		(
			select 
				e.EntityId
				,r.RuleID
				,a.AttributeId
				,re.RuleEntityID
				,e.SchemaName
				,e.TableName
				,a.AttributeName
				,a.IsNullable
				,re.ConvertStyle
			from
				[psa].[Attribute] a
				inner join [psa].[Entity] e on @pCleansedEntityId = a.EntityID
				inner join [psa].[RuleEntity] re on re.EntityID = e.EntityID and re.AttributeId = a.AttributeId 
				inner join [psa].[Rule] r on r.RuleID = re.RuleID
			where
				a.ActiveFlag = 1
				and e.ActiveFlag = 1
				and r.ActiveFlag = 1
				and re.ActiveFlag = 1
				and e.EntityId = @pPSAEntityId 
				and r.RuleId in (3, 5, 6)
			union all
			select 
				e.EntityId
				,r.RuleID
				,99999 AttributeId
				,re.RuleEntityID
				,e.SchemaName
				,e.TableName
				,NULL AttributeName
				,NULL IsNullable
				,NULL ConvertStyle
			from
				[psa].[Entity] e
				inner join [psa].[RuleEntity] re on re.EntityID = e.EntityID and re.AttributeId = 99999
				inner join [psa].[Rule] r on r.RuleID = re.RuleID
			where
				e.ActiveFlag = 1
				and r.ActiveFlag = 1
				and re.ActiveFlag = 1
				and e.EntityId = @pPSAEntityId 
				and r.RuleID = 13 --row rules
		) a
		), EntityRule4 as (
		select
		RuleEntityID
		,EntityId
		,RuleID
		,SchemaName
		,TableName
		,AttributeName
		,[psa].[fn_GetDQSelect](
			EntityID
			, SchemaName
			, TableName
			, case when RuleID = 13 then @DQTableC else @DQTableR end
			, AttributeName
			, RuleID
			, RuleEntityID
			, AttributeID
			, AttributeExpression
			, @pETLRunlogId
		) DQInsertExpression
		from
		EntityRule1
		)

		INSERT INTO #rules(
			RuleEntityID 
			,EntityId 
			,RuleID 
			,SchemaName
			,TableName 
			,AttributeName 
			,DQInsertExpression 
		)
		SELECT
		RuleEntityID
		,EntityId
		,RuleID
		,SchemaName
		,TableName
		,AttributeName
		,DQInsertExpression
		FROM
		EntityRule4
		;

		--select * from #rules;
		--loop over #rules
		--count how many rows
		--while loop 
		declare @lRuleEntityID bigint;
		declare @lEntityId bigint;
		declare @lDQInsertExpression nvarchar(max);
		declare @lRuleID int;
		declare @message nvarchar(100);

		While (Select Count(*) From #rules) > 0
		Begin
			--set @message = concat((Select Count(*) From #rules), N' rules left');
			--print @message;
			Select Top 1 
			@lRuleEntityID = RuleEntityID
			,@lEntityId = EntityId
			,@lDQInsertExpression = DQInsertExpression
			,@lRuleID = RuleID
			From #rules
			--print @lDQInsertExpression;
			--print convert(varchar,@lVector)
			--print convert(varchar, @lRuleEntityID)
			if @lRuleID = 13
			begin
				--row rule
				print 'row rule';
				--print concat('@lDQInsertExpression ', @lDQInsertExpression);
				set @CTASExprsssionR = concat(@CTASExprsssionR, @lDQInsertExpression, @nl);
			end
			else
			begin
				--column rule
				--print 'column rule'
				set @CTASExprsssionC = concat(@CTASExprsssionC, @lDQInsertExpression, @nl);
				set @CTASExprsssionC = concat(@CTASExprsssionC, N'union all', @nl);
				--print @CTASExprsssionC
			end
			Delete #rules Where RuleEntityID = @lRuleEntityID 
		End
		;

		if len(@CTASExprsssionC) > (len(@table) + 120) -- we have no column rules
		begin
			set @CTASExprsssionC = left(@CTASExprsssionC, len(@CTASExprsssionC)-11);--remove the last union all
		end

		--create row ctas
		--print concat('@CTASExprsssionR ', @CTASExprsssionR);
		--select @CTASExprsssionR;
		set @currenttime = CURRENT_TIMESTAMP;

		declare @loop int = 1;
		declare @step int = 4000;
		declare @part int = 1;
		declare @chunk nvarchar(4000);
		if len(@CTASExprsssionR) > (len(@table) + 120) --we have rule 13
		begin
			while @loop < len(@CTASExprsssionR)
			begin
				set @chunk = substring(@CTASExprsssionR,@loop, @step)
				insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
				values (@dqid, 3, @part, @pPSAEntityId, @pETLRunlogId, @chunk, @currenttime, N'Ignore - test data');	
				set @loop = @loop + @step;
				set @part = @part + 1;
			end
			exec(@CTASExprsssionR);
		end

		--create column ctas
		--print concat('@CTASExprsssionC ', @CTASExprsssionC);
		--select @CTASExprsssionC

		set @currenttime = CURRENT_TIMESTAMP;

		set @loop = 1;
		set @part = 1;

		if len(@CTASExprsssionC) > (len(@table) + 120) -- we have no column rules
		begin
			while @loop < len(@CTASExprsssionC)
			begin
				set @chunk = substring(@CTASExprsssionC,@loop, @step)
				insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
				values (@dqid, 4, @part, @pPSAEntityId, @pETLRunlogId, @chunk, @currenttime, N'Ignore - test data');	
				set @loop = @loop + @step;
				set @part = @part + 1;
			end
			exec(@CTASExprsssionC);
		end

		--print 'rules done';
		--sepecific logic for business duplicate - ruleid 13
		--pivot hash values of business keys and data keys to columns
		--join to self over business keys hash
		--if all data kyes hash do not match - rank or dense rank
		--all rows should go to quarentine (if failure id is to go to quarentine)
		--else pick one row to survive - send the other rows to quarentine (if failure id is to go to quarentine)

		declare @dupSelect nvarchar(max);
		set @dupSelect = concat(N'with ', @nl)
		set @dupSelect = concat(@dupSelect, N'	pivotHashRankRow as', @nl);
		set @dupSelect = concat(@dupSelect, N'	(', @nl);
		set @dupSelect = concat(@dupSelect, N'	select ', @nl);
		set @dupSelect = concat(@dupSelect, N'	EntityID', @nl);
		set @dupSelect = concat(@dupSelect, N'	,PSARowKey', @nl);
		set @dupSelect = concat(@dupSelect, N'	,ETLRunLogID', @nl);
		set @dupSelect = concat(@dupSelect, N'	,[BusinessHash]', @nl);
		set @dupSelect = concat(@dupSelect, N'	,[DataHash]', @nl);
		set @dupSelect = concat(@dupSelect, N'	,dense_rank() over(order by AssetID, BusinessHash) BusinessHashDRank', @nl);
		set @dupSelect = concat(@dupSelect, N'	,dense_rank() over(partition by AssetID, BusinessHash order by DataHash) DataHashDRank', @nl);
		set @dupSelect = concat(@dupSelect, N'	,row_number() over(partition by AssetID, BusinessHash order by DataHash) BusinessHashFirst ', @nl); --one row has to win
		set @dupSelect = concat(@dupSelect, N'	from ', @DQTableR, @nl);
		set @dupSelect = concat(@dupSelect, N'	where ', @nl);
		set @dupSelect = concat(@dupSelect, N'	EntityID = ', @pPSAEntityID, @nl);
		if @pETLRunlogId is not null set @dupSelect = concat(@dupSelect, N'	and ETLRunLogID = ', @pETLRunlogId, @nl);
		set @dupSelect = concat(@dupSelect, N'	and RuleID = 13 ', @nl); --business duplicates
		set @dupSelect = concat(@dupSelect, N'	)', @nl);
		set @dupSelect = concat(@dupSelect, N'	, mismatchDataDuplicates as (', @nl);
		set @dupSelect = concat(@dupSelect, N'	select distinct BusinessHashDRank, ETLRunLogID', @nl);
		set @dupSelect = concat(@dupSelect, N'	from pivotHashRankRow', @nl);
		set @dupSelect = concat(@dupSelect, N'	where DataHashDRank > 1', @nl);
		set @dupSelect = concat(@dupSelect, N'	)', @nl);
		set @dupSelect = concat(@dupSelect, N'	, row_idsMismatchedDuplicates as', @nl);
		set @dupSelect = concat(@dupSelect, N'	(', @nl);
		set @dupSelect = concat(@dupSelect, N'	select distinct phrr.PSARowKey, phrr.ETLRunLogID', @nl);
		set @dupSelect = concat(@dupSelect, N'	from', @nl);
		set @dupSelect = concat(@dupSelect, N'	pivotHashRankRow phrr', @nl);
		set @dupSelect = concat(@dupSelect, N'	inner join mismatchDataDuplicates mdp on phrr.BusinessHashDRank = mdp.BusinessHashDRank', @nl);
		set @dupSelect = concat(@dupSelect, N'	)', @nl);
		set @dupSelect = concat(@dupSelect, N'	, dataMatchesLosers as (', @nl);
		set @dupSelect = concat(@dupSelect, N'	select distinct PSARowKey, ETLRunLogID', @nl);
		set @dupSelect = concat(@dupSelect, N'	from pivotHashRankRow', @nl);
		set @dupSelect = concat(@dupSelect, N'	where DataHashDRank = 1 ', @nl); --datahash is matching
		set @dupSelect = concat(@dupSelect, N'	and BusinessHashFirst > 1', @nl); --it is a loser
		set @dupSelect = concat(@dupSelect, N'	)', @nl);
		set @dupSelect = concat(@dupSelect, N'	, duprow_id as (', @nl);
		set @dupSelect = concat(@dupSelect, N'	select distinct PSARowKey, Reason, ETLRunLogID', @nl);
		set @dupSelect = concat(@dupSelect, N'	from ', @nl); --combine the mismatch duplicate row keys with with matched loser 
		set @dupSelect = concat(@dupSelect, N'	(', @nl);
		set @dupSelect = concat(@dupSelect, N'	select PSARowKey, ''data key mismatches'' Reason,ETLRunLogID from row_idsMismatchedDuplicates ', @nl);
		set @dupSelect = concat(@dupSelect, N'	union all', @nl);
		set @dupSelect = concat(@dupSelect, N'	select PSARowKey, ''random loser for matching rows'' Reason,ETLRunLogID from dataMatchesLosers ', @nl);
		set @dupSelect = concat(@dupSelect, N'	) a', @nl);
		set @dupSelect = concat(@dupSelect, N'	)', @nl);

		if len(@CTASExprsssionR) > (len(@table) + 120) --we have rule 13
		begin
			declare @dupInsert nvarchar(max);
		--	insert into rule entity instance for row rules
			set @dupInsert = concat(@dupSelect, N'INSERT INTO [psa].[RuleEntityInstance](', @nl) --use the select first
			set @dupInsert = concat(@dupInsert, N'[RuleID]', @nl)
			set @dupInsert = concat(@dupInsert, N',[EntityID]', @nl)
			set @dupInsert = concat(@dupInsert, N',[AttributeID]', @nl)
			set @dupInsert = concat(@dupInsert, N',[RuleDetail]', @nl)
			set @dupInsert = concat(@dupInsert, N',[ETLRunLogID]', @nl)
			set @dupInsert = concat(@dupInsert, N',[SourceEntityID]', @nl)
			set @dupInsert = concat(@dupInsert, N',[SourceAttributeID]', @nl)
			set @dupInsert = concat(@dupInsert, N',[PSARowKey]', @nl)
			set @dupInsert = concat(@dupInsert, N',[DTCreated]', @nl)
			set @dupInsert = concat(@dupInsert, N',[UserCreated]', @nl)
			set @dupInsert = concat(@dupInsert, N')', @nl)
			set @dupInsert = concat(@dupInsert, N'SELECT', @nl)
			set @dupInsert = concat(@dupInsert, N'13 RuleID', @nl)
			set @dupInsert = concat(@dupInsert, N',', @pPSAEntityID, ' EntityID', @nl)
			set @dupInsert = concat(@dupInsert, N',99999 AttributeID', @nl)
			set @dupInsert = concat(@dupInsert, N',Reason RuleDescription', @nl)
			set @dupInsert = concat(@dupInsert, N',[ETLRunLogID]', @nl)
			set @dupInsert = concat(@dupInsert, N',', @pPSAEntityID, ' SourceEntityID', @nl)
			set @dupInsert = concat(@dupInsert, N',99999 SoureAttributeID', @nl)
			set @dupInsert = concat(@dupInsert, N',[PSARowKey]', @nl)
			set @dupInsert = concat(@dupInsert, N',CURRENT_TIMESTAMP [DTCreated]', @nl)
			set @dupInsert = concat(@dupInsert, N',''DQ Framework'' [UserCreated]', @nl)
			set @dupInsert = concat(@dupInsert, N'from', @nl)
			set @dupInsert = concat(@dupInsert, N'duprow_id', @nl) 
			set @dupInsert = concat(@dupInsert, N';', @nl);
		--	--print @dupInsert;
			set @currenttime = CURRENT_TIMESTAMP;
			--print concat('@dupInsert ', @dupInsert);
			insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
			values (@dqid, 5, 1, @pPSAEntityId, @pETLRunlogId, @dupInsert, @currenttime, N'DQ Framework');
			exec (@dupInsert);
		end


	--	insert into rule entity instance for column rules
		declare @insertExp nvarchar(max);
		set @insertExp = concat(N'INSERT INTO [psa].[RuleEntityInstance](', @nl)
		set @insertExp = concat(@insertExp, N'[RuleID]', @nl)
		set @insertExp = concat(@insertExp, N',[EntityID]', @nl)
		set @insertExp = concat(@insertExp, N',[AttributeID]', @nl)
		set @insertExp = concat(@insertExp, N',[RuleDetail]', @nl)
		set @insertExp = concat(@insertExp, N',[ETLRunLogID]', @nl)
		set @insertExp = concat(@insertExp, N',[SourceEntityID]', @nl)
		set @insertExp = concat(@insertExp, N',[SourceAttributeID]', @nl)
		set @insertExp = concat(@insertExp, N',[PSARowKey]', @nl)
		set @insertExp = concat(@insertExp, N',[DTCreated]', @nl)
		set @insertExp = concat(@insertExp, N',[UserCreated]', @nl)
		set @insertExp = concat(@insertExp, N')', @nl)
		set @insertExp = concat(@insertExp, N'SELECT', @nl)
		set @insertExp = concat(@insertExp, N'RuleID', @nl)
		set @insertExp = concat(@insertExp, N',EntityID', @nl)
		set @insertExp = concat(@insertExp, N',AttributeID', @nl)
		set @insertExp = concat(@insertExp, N',RuleDescription', @nl)
		set @insertExp = concat(@insertExp, N',ETLRunLogID', @nl)
		set @insertExp = concat(@insertExp, N',EntityID', @nl)
		set @insertExp = concat(@insertExp, N',AttributeID', @nl)
		set @insertExp = concat(@insertExp, N',PSARowKey', @nl)
		set @insertExp = concat(@insertExp, N',CURRENT_TIMESTAMP', @nl)
		set @insertExp = concat(@insertExp, N',''DQ Framework''', @nl)
		set @insertExp = concat(@insertExp, N'from', @nl)
		set @insertExp = concat(@insertExp, @DQTableC, @nl) 
		set @insertExp = concat(@insertExp, N'where', @nl)
		set @insertExp = concat(@insertExp, N'[RuleExpression] = ''False''', @nl) --failure
		set @insertExp = concat(@insertExp, N'AND RuleID <> 13;') --not business duplicate rule
		--print @insertExp;
		--print concat('@insertExp ', @insertExp);
		if len(@CTASExprsssionC) > (len(@table) + 120) -- we have no column rules
		begin
			set @currenttime = CURRENT_TIMESTAMP;
			insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
			values (@dqid, 6, 1, @pPSAEntityId, @pETLRunlogId, @insertExp, @currenttime, N'DQ Framework');
			exec (@insertExp);
		end

		if len(@CTASExprsssionR) > (len(@table) + 120) --we have rule 13
		begin
		----update row status to 26009 for Quarantine for row rules
			declare @dupUpdate nvarchar(max);
			set @dupUpdate = concat(@dupSelect, N'update [',@Schema,N'].[',@Table,N']', @nl) --use the select first
			set @dupUpdate = concat(@dupUpdate, N'set [row_status] = 26009', @nl)	--quarantine --- psa table status update, hence row_status
			set @dupUpdate = concat(@dupUpdate, N'from ', @nl) 
			set @dupUpdate = concat(@dupUpdate, N'[',@Schema,N'].[',@Table,N'] a', @nl)		--original table
			set @dupUpdate = concat(@dupUpdate, N'inner join duprow_id b', @nl)			--dq table
			set @dupUpdate = concat(@dupUpdate, N'	on a.[row_id] = b.[PSARowKey]', @nl) 
			set @dupUpdate = concat(@dupUpdate, N'inner join [psa].[RuleEntity] c', @nl)	--rule entity
			set @dupUpdate = concat(@dupUpdate, N'	on c.[EntityID] = ', @pPSAEntityID, @nl) 
			set @dupUpdate = concat(@dupUpdate, N'	and c.AttributeID = 99999', @nl)  -- business duplicate 
			set @dupUpdate = concat(@dupUpdate, N'	and c.[FailureActionId] = 28001', @nl)	--failure action quarantine
			set @dupUpdate = concat(@dupUpdate, N'	and c.ActiveFlag = 1', @nl) 
			set @dupUpdate = concat(@dupUpdate, N'inner join [psa].[Rule] d', @nl) 
			set @dupUpdate = concat(@dupUpdate, N'	on c.RuleID = d.RuleID', @nl) 
			set @dupUpdate = concat(@dupUpdate, N'	and d.ActiveFlag = 1', @nl);
			set @dupUpdate = concat(@dupUpdate, N'	AND c.RuleID = 13;') -- business duplicate rule
			--print @dupUpdate;
			set @currenttime = CURRENT_TIMESTAMP;
			insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
			values (@dqid, 7, 1, @pPSAEntityId, @pETLRunlogId, @dupUpdate, @currenttime, N'DQ Framework');
			exec (@dupUpdate);
		end
		----update row status to 26009 for Quarantine from column rules
		----todo - add to the rule entity definition failure target to go to quarentine or not
		declare @updateExp nvarchar(max);
		set @updateExp = concat(N'update [',@Schema,N'].[',@Table,N']', @nl)
		set @updateExp = concat(@updateExp, N'set [row_status] = 26009', @nl)	--quarantine -- psa table status update , hence row_status
		set @updateExp = concat(@updateExp, N'from ', @nl) 
		set @updateExp = concat(@updateExp, N'[',@Schema,N'].[',@Table,N'] a', @nl)		--original table
		set @updateExp = concat(@updateExp, N'inner join ',@DQTableC,' b', @nl)			--dq table
		set @updateExp = concat(@updateExp, N'	on a.[row_id] = b.[PSARowKey]', @nl) 
		set @updateExp = concat(@updateExp, N'	and [RuleExpression] = ''False''', @nl)			--failed records
		set @updateExp = concat(@updateExp, N'inner join [psa].[RuleEntity] c', @nl)	--rule entity
		set @updateExp = concat(@updateExp, N'	on b.[EntityID] = c.[EntityID]', @nl) 
		set @updateExp = concat(@updateExp, N'	and b.AttributeID = c.AttributeID', @nl) 
		set @updateExp = concat(@updateExp, N'	and c.[FailureActionId] = 28001', @nl)	--failure action quarantine
		set @updateExp = concat(@updateExp, N'	and c.ActiveFlag = 1', @nl) 
		set @updateExp = concat(@updateExp, N'inner join [psa].[Rule] d', @nl) 
		set @updateExp = concat(@updateExp, N'	on c.RuleID = d.RuleID', @nl) 
		set @updateExp = concat(@updateExp, N'	and d.ActiveFlag = 1', @nl);
		set @updateExp = concat(@updateExp, N'	AND b.RuleID <> 13;') --not business duplicate rule
		--print @updateExp;
		if len(@CTASExprsssionC) > (len(@table) + 120) -- we have no column rules
		begin
			set @currenttime = CURRENT_TIMESTAMP;
			insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
			values (@dqid, 8, 1, @pPSAEntityId, @pETLRunlogId, @updateExp, @currenttime, N'DQ Framework');
			exec (@updateExp);
		end

		set @currenttime = CURRENT_TIMESTAMP;
		insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
		values (@dqid, 9, 1, @pPSAEntityId, @pETLRunlogId, @checktableC, @currenttime, N'DQ Framework');
		exec (@checktableC);
		set @currenttime = CURRENT_TIMESTAMP;
		insert into [psa].[RuleEntityOperation]([DQID],[Ordinal],[Part],[EntityID],[ETLRunLogID],[Logic],[DTCreated],[UserCreated])
		values (@dqid, 10, 1, @pPSAEntityId, @pETLRunlogId, @checktableR, @currenttime, N'DQ Framework');
		exec (@checktableR);
	end
END
GO
/****** Object:  UserDefinedFunction [psa].[fn_GetRuleExpression]    Script Date: 9/9/2020 2:00:53 PM ******/
IF OBJECT_ID('psa.fn_GetRuleExpression') IS NOT NULL
BEGIN
	DROP FUNCTION [psa].[fn_GetRuleExpression]
END;
GO

/****** Object:  UserDefinedFunction [psa].[fn_GetRuleExpression]    Script Date: 9/9/2020 2:00:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [psa].[fn_GetRuleExpression] (@pRuleID [int],@pSchemaName [nvarchar](500),@pTableName [nvarchar](500),@pAttributeName [nvarchar](500),@pAttributeIsNullable [bit],@pBusinessHash [nvarchar](4000),@pDataHash [nvarchar](4000),@pConvertStyle [nvarchar](4000)) RETURNS nvarchar(4000)
AS
BEGIN  
    DECLARE @Expression nvarchar(4000);
	declare @ddIndex int;
	declare @mmIndex int;
	declare @yyyyIndex int;
	declare @hhIndex int;
	declare @miIndex int;
	declare @ssIndex int;
	SET @Expression ='';
	if @pRuleID = 5 --isdate
	begin
		if ISNUMERIC(@pConvertStyle) <> 1 --not sql style
		begin
			if CHARINDEX('dd',@pConvertStyle) > 0 --custome date 
			begin
				set	@ddIndex = CHARINDEX('dd', @pConvertStyle)
				set @mmIndex = CHARINDEX('mm', @pConvertStyle)
				set @yyyyIndex = CHARINDEX('yyyy', @pConvertStyle)
			end
			else --custome time
			begin
				set @hhIndex = CHARINDEX('hh', @pConvertStyle)
				set @miIndex = CHARINDEX('mi', @pConvertStyle)
				set @ssIndex = CHARINDEX('ss', @pConvertStyle)
			end
		end
    end
	SET @Expression = CASE @pRuleID
		WHEN 3 --NOT NULL
			THEN CONCAT(N'CONVERT(NVARCHAR(32), CASE WHEN [', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'] IS NOT NULL AND LEN([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N']) > 0 THEN ''True'' ELSE ''False'' END) ')
		WHEN 5 --ISDATE
			THEN 
				CASE 
				WHEN ISNUMERIC(@pConvertStyle) = 1 --NUMERIC DATE STYLE
				THEN 
					CONCAT(N'CONVERT(NVARCHAR(32), CASE WHEN ',
					CASE 
					WHEN (@pAttributeIsNullable = 1) 
					THEN CONCAT(N'([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'] IS NULL) OR LEN([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'])=0 OR ') 
					END, 
					' TRY_CONVERT(DATE, [', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N']',
					CASE
					WHEN (@pConvertStyle IS NOT NULL)
					THEN CONCAT(N',', @PConvertStyle)
					END,
					') IS NOT NULL THEN ''True'' ELSE ''False'' END) ')
				ELSE 
					CASE --NOT NUMRIC DATE OR TIME?
					WHEN CHARINDEX('dd',@pConvertStyle) > 0 --date ddmmyyyy
					THEN
						CONCAT(N'CONVERT(NVARCHAR(32), CASE WHEN ',
						CASE 
						WHEN (@pAttributeIsNullable = 1) 
						THEN CONCAT(N'([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'] IS NULL) OR LEN([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'])=0 OR ') 
						END, 
						' isdate(concat(substring([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'],',@yyyyIndex,N',4), N''-'',substring([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'],',@mmIndex,N',2), N''-'',substring([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'],',@ddIndex,N',2)))'
						,' = 1 THEN ''True'' ELSE ''False'' END) ')
					ELSE --time {"TimeFormatCustom":"hhmiss"} 
						CONCAT(N'CONVERT(NVARCHAR(32), CASE WHEN ',
						CASE 
						WHEN (@pAttributeIsNullable = 1) 
						THEN CONCAT(N'([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'] IS NULL) OR LEN([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'])=0 OR ') 
						END, 
						' try_convert(time,concat(substring([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'],',@hhIndex,N',2), N'':'',substring([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'],',@miIndex,N',2), N'':'',substring([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'],',@ssIndex,N',2)))'
						,' is not null THEN ''True'' ELSE ''False'' END) ')
					END
				END
		WHEN 6 --ISNUMERIC
			THEN CONCAT(N'CONVERT(NVARCHAR(32), CASE WHEN ' + CASE WHEN (@pAttributeIsNullable = 1) THEN CONCAT(N'([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'] IS NULL) OR LEN([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N'])=0 OR ') ELSE N'' END  + ' ISNUMERIC([', @pSchemaName, N'].[', @pTableName, N'].[', @pAttributeName, N']) = 1 THEN ''True'' ELSE ''False'' END) ')
		WHEN 13 --Business Key Duplicate Check
			THEN concat(@pBusinessHash, N' BusinessHash,', @pDataHash, N' DataHash')
		--ELSE N'NOT KNOWN RULE'
	END
	RETURN(@Expression);  
END
GO
/****** Object:  StoredProcedure [psa].[sp_IncrementalDataCapture]    Script Date: 04/09/2020 12:48:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_IncrementalDataCapture') IS NOT NULL
BEGIN
    DROP PROC psa.sp_IncrementalDataCapture   
END
GO

CREATE PROC [psa].[sp_IncrementalDataCapture] @tableName [varchar](max),@businessKeys [varchar](max),@fileType [varchar](max) AS
/*
************************************************************************************************************
Procedure Name				: sp_IncrementalDataCapture
Purpose						: Load data from tables in lod schema into corresponding tables in psa schema
							  after considering the change in data based on business keys passed as parameters	
*****************************************************************************************
Modification History

************************************************************************************************************
30-July-2020      : Initial Version
04-September-2020 : Bug fix for 1. ETLRunLogID being null when lod table is empty
								2. STRING_AGG aggregation result exceeded the limit of 8000 bytes
09-September-2020 : Changes to incorporate the addition of row_id in LOD tables and removal of identity 
					from PSA tables									
 */ 

 /*Declare  and initialize the Variables required for serve layer processing*/

 DECLARE @columnNames NVARCHAR(MAX),
		 @selectCond NVARCHAR(MAX),
		 @exceptCond NVARCHAR(MAX),
		 --@etlRunLogID VARCHAR(MAX),
		 @assetID VARCHAR(MAX),
		 @busKeyCond NVARCHAR(MAX),
		 @createdTimeStamp DATETIME
 BEGIN
		BEGIN TRANSACTION;
			BEGIN TRY
					SET @createdTimeStamp= CURRENT_TIMESTAMP
					--DECLARE @distinctQuery NVARCHAR(MAX) = ' SELECT @etlRunLogID = COALESCE((SELECT DISTINCT etl_runlog_id FROM lod.' + @tableName + '),0)'
					DECLARE @distinctQuery NVARCHAR(MAX) = ' SELECT @assetID = COALESCE((SELECT DISTINCT asset_id FROM lod.' + @tableName + '),0)'
					--EXEC sp_executesql @distinctQuery, N'@etlRunLogID VARCHAR(MAX) OUT', @etlRunLogID OUT
					EXEC sp_executesql @distinctQuery, N'@assetID VARCHAR(MAX) OUT', @assetID OUT

					SET @columnNames = (SELECT STRING_AGG(column_name, ',') columnNames FROM 
										(SELECT DISTINCT CAST(column_name AS VARCHAR(MAX)) AS column_name FROM INFORMATION_SCHEMA.COLUMNS info WHERE table_schema='lod' AND table_name = @tableName
										) t) 	
	
					SET @selectCond =  (SELECT STRING_AGG('a.'+column_name, ',') columnNames FROM 
										(SELECT DISTINCT CAST(column_name AS VARCHAR(MAX)) AS column_name FROM INFORMATION_SCHEMA.COLUMNS info WHERE table_schema='lod' AND table_name = @tableName
										) t)

					SET @exceptCond = (SELECT STRING_AGG('ISNULL(a.'+column_name+','''') = ISNULL(b.'+column_name+','''')', ' AND ') columnNames FROM 
										(SELECT DISTINCT CAST(column_name AS VARCHAR(MAX)) AS column_name FROM INFORMATION_SCHEMA.COLUMNS info WHERE table_schema='lod' AND table_name = @tableName
										AND column_name NOT IN ('row_id','asset_id','etl_runlog_id')
										) t)

					IF(@businessKeys IS NOT NULL AND @businessKeys != '')
						BEGIN
							SET @busKeyCond = (SELECT STRING_AGG('ISNULL(a.'+value+','''') = ISNULL(b.'+value+','''')', ' AND ') busKeyCond FROM 
												(SELECT CAST(value AS VARCHAR(MAX)) AS value FROM STRING_SPLIT(@businessKeys, ','))t)

							IF(@fileType = 'refresh')
								EXEC('WITH stg_PSA AS ( SELECT * FROM lod.' + @tableName + ' a WHERE NOT EXISTS 
									 (SELECT 1 FROM psa.' + @tableName + ' b WHERE '+ @exceptCond + ' AND b.active_flag = ''Y''))
									 INSERT INTO psa.' + @tableName + ' (' + @columnNames + ',created_timestamp,row_status,active_flag) 
									 SELECT ' + @selectCond + ',''' + @createdTimeStamp + ''' created_timestamp,
									 (CASE   
									       WHEN b.row_status = 26006 THEN 26006 ELSE 26001   
									 END) row_status,''Y'' active_flag FROM stg_PSA a 
									 LEFT JOIN (SELECT DISTINCT row_status,' + @businessKeys + ' FROM psa.' + @tableName +  ' WHERE active_flag = ''Y'') b 
									 ON row_status = 26006 AND '+ @busKeyCond)
							ELSE IF(@fileType = 'delta')
								EXEC('INSERT INTO psa.' + @tableName + ' (' + @columnNames + ',created_timestamp,row_status,active_flag) SELECT ' + @selectCond +
									 ',''' + @createdTimeStamp + ''' created_timestamp, 
									 (CASE   
									       WHEN b.row_status = 26006 THEN 26006 ELSE 26001   
									 END) row_status,''Y'' active_flag FROM lod.' + @tableName + ' a
									 LEFT JOIN (SELECT DISTINCT row_status,' + @businessKeys + ' FROM psa.' + @tableName +  ' WHERE active_flag = ''Y'') b 
									 ON row_status = 26006 AND '+ @busKeyCond)							

							EXEC('UPDATE a SET active_flag = ''N'' FROM psa.' + @tableName + ' a JOIN (SELECT ' + 
								 --@businessKeys + ' FROM psa.' + @tableName + ' WHERE etl_runlog_id = CAST(' + @etlRunLogID + ' AS INT))b ' +
								 @businessKeys + ' FROM psa.' + @tableName + ' WHERE asset_id = CAST(' + @assetID + ' AS INT))b ' +
								 'ON ' + @busKeyCond + 'WHERE active_flag = ''Y'' AND asset_id != CAST(' +
								 --@etlRunLogID + ' AS INT)')
								 @assetID + ' AS INT)')

						END
					ELSE IF(@fileType = 'delta')
						BEGIN
							EXEC('INSERT INTO psa.' + @tableName + ' (' + @columnNames + ',created_timestamp,row_status,active_flag) SELECT ' + @columnNames +
								 ',''' + @createdTimeStamp + ''' created_timestamp,'+ --CAST(' + @psaRowStatus + ' AS INT)
								 '26001 row_status,NULL active_flag FROM lod.' + @tableName)
						END
					ELSE IF(@fileType = 'refresh')
						BEGIN
							EXEC('UPDATE psa.' + @tableName + ' SET active_flag = ''N'' WHERE active_flag = ''Y''')
							EXEC('INSERT INTO psa.' + @tableName + ' (' + @columnNames + ',created_timestamp,row_status,active_flag) SELECT ' + @columnNames +
								 ',''' + @createdTimeStamp + ''' created_timestamp,' + --CAST(' + @psaRowStatus + ' AS INT)
								 '26001 row_status,''Y'' active_flag FROM lod.' + @tableName)
						END
						
		COMMIT TRANSACTION
			END TRY
			BEGIN CATCH 
				THROW;					
				ROLLBACK TRANSACTION ;						
			END CATCH 
 END
	 
GO
/****** Object:  StoredProcedure [psa].[sp_IncrementalDataCapture_Intactix]    Script Date: 10/15/2020 6:10:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_IncrementalDataCapture_Intactix') IS NOT NULL
BEGIN
    DROP PROC psa.sp_IncrementalDataCapture_Intactix   
END
GO

CREATE PROC [psa].[sp_IncrementalDataCapture_Intactix] @tableName [nvarchar](50),@businessKeys [varchar](max),@fileType [varchar](max) AS 
BEGIN

declare @pPSASchemaName nvarchar(50) = 'psa';
declare @pLODSchemaName nvarchar(50) = 'lod';
declare @lLODInsertExpression varchar(max);
declare @lPSAInsertExpression varchar(max);

declare @RCTableLOD nvarchar(500); 
declare @RCTablePSA nvarchar(500); 
declare @today nchar(10);
declare @currenttime datetime;
declare @nl nchar(2);
declare @CTASExprsssionLOD nvarchar(max);
declare @CTASExprsssionPSA nvarchar(max);
declare @checktableLOD nvarchar(4000);
declare @checktablePSA nvarchar(4000);

set @today = CONVERT(nchar(30), GETDATE(), 23);
set @currenttime = CURRENT_TIMESTAMP;
set @RCTableLOD = concat( N'[', @pLODSchemaName, N'].[RC_', @tableName, N'_', @today, N']');
set @RCTablePSA = concat( N'[', @pPSASchemaName, N'].[RC_', @tableName, N'_', @today, N']');
set @nl = concat(char(13),char(10));


--change the name @RCTable
set @checktableLOD = concat(N'if object_id(N''',@RCTableLOD,''', N''U'') is not null drop table ',@RCTableLOD,';');
exec (@checktableLOD);

set @CTASExprsssionLOD = concat(N'CREATE TABLE ', @RCTableLOD, @nl);
set @CTASExprsssionLOD = concat(@CTASExprsssionLOD, N'WITH', @nl);
set @CTASExprsssionLOD = concat(@CTASExprsssionLOD, N'(', @nl);
set @CTASExprsssionLOD = concat(@CTASExprsssionLOD, N'	DISTRIBUTION = HASH([row_id])', @nl);
set @CTASExprsssionLOD = concat(@CTASExprsssionLOD, N'	,CLUSTERED COLUMNSTORE INDEX', @nl); --let's add
set @CTASExprsssionLOD = concat(@CTASExprsssionLOD, N')', @nl);
set @CTASExprsssionLOD = concat(@CTASExprsssionLOD, N'AS', @nl);

set @checktablePSA = concat(N'if object_id(N''',@RCTablePSA,''', N''U'') is not null drop table ',@RCTablePSA,';');
exec (@checktablePSA);

set @CTASExprsssionPSA = concat(N'CREATE TABLE ', @RCTablePSA, @nl);
set @CTASExprsssionPSA = concat(@CTASExprsssionPSA, N'WITH', @nl);
set @CTASExprsssionPSA = concat(@CTASExprsssionPSA, N'(', @nl);
set @CTASExprsssionPSA = concat(@CTASExprsssionPSA, N'	DISTRIBUTION = HASH([row_id])', @nl);
set @CTASExprsssionPSA = concat(@CTASExprsssionPSA, N'	,CLUSTERED COLUMNSTORE INDEX', @nl); --let's add
set @CTASExprsssionPSA = concat(@CTASExprsssionPSA, N')', @nl);
set @CTASExprsssionPSA = concat(@CTASExprsssionPSA, N'AS', @nl);

with selectexr as
(
select top 1
case
when (select count(value) as numBusKeys from string_split(@businessKeys, ',')) = 1
then
	(
		select concat(N'HASHBYTES(''SHA2_256'', nullif(', AttributeName, N', ''\N'') )')
		from (select value AS AttributeName from string_split(@businessKeys, ','))t --business key columns
	)
when (SELECT count(value) AS numBusKeys FROM string_split(@businessKeys, ',')) < 250
then
	(
		select concat(N'HASHBYTES(''SHA2_256'', ', cnct, N')')
		from
		(
			select concat(N'concat(',AttributeName,N')') cnct
			from (
				select
					string_agg(AttributeExp, ',') AttributeName
				from 
					(
					select cast(concat('nullif(',AttributeName,',''\N'')') as varchar(max)) AttributeExp
					from (select value AS AttributeName from string_split(@businessKeys, ','))t --business key columns
					) attr
			) cnct
		) hashb
	)
end BusinessHash
,--if more than 2500 columns this code will fail
case
when (select count(*) as numDataCols from INFORMATION_SCHEMA.COLUMNS info where table_schema = @pLODSchemaName AND table_name = @tableName
				and column_name not in (@businessKeys,'row_id','asset_id','etl_runlog_id','record_source_id')) = 1
then
	(
		select concat(N'HASHBYTES(''SHA2_256'', ', AttributeName, N')')
		from (select distinct column_name as AttributeName from INFORMATION_SCHEMA.COLUMNS info where table_schema = @pLODSchemaName AND table_name = @tableName
				and column_name not in (@businessKeys,'row_id','asset_id','etl_runlog_id','record_source_id')
				) t --data columns
	)
when (select count(*) as numDataCols from INFORMATION_SCHEMA.COLUMNS info where table_schema = @pLODSchemaName AND table_name = @tableName
				and column_name not in (@businessKeys,'row_id','asset_id','etl_runlog_id','record_source_id')) < 250
then 
	(
		select concat(N'HASHBYTES(''SHA2_256'', ', cnct, N')')
		from
		(
			select concat(N'concat(',AttributeName,N')') cnct
			from (
				select
					string_agg(AttributeExp, ',') AttributeName
				from 
					(
					select cast(concat('nullif(',AttributeName,',''\N'')') as varchar(max)) AttributeExp
					from (select distinct column_name as AttributeName from INFORMATION_SCHEMA.COLUMNS info where table_schema = @pLODSchemaName AND table_name = @tableName
							and column_name not in (@businessKeys,'row_id','asset_id','etl_runlog_id','record_source_id')
							) t --data columns
					) attr
			) cnct
		) hashb
	)
else
	(
		select concat(N'HASHBYTES(''SHA2_256'', ', cnct, N')')
		from
		(
		select concat(N'concat(',string_agg(concat(N'concat(',AttributeName,N')'), N','),')') cnct
		from (
		select
			string_agg(AttributeExp, ',') AttributeName
		from 
			(
		select cast(concat('nullif(',AttributeName,',''\N'')') as varchar(max)) AttributeExp
		,NTILE(10) OVER(ORDER BY ORDINAL_POSITION) tile
		from (select distinct column_name as AttributeName, ORDINAL_POSITION from INFORMATION_SCHEMA.COLUMNS info where table_schema = @pLODSchemaName AND table_name = @tableName
							and column_name not in (@businessKeys,'row_id','asset_id','etl_runlog_id','record_source_id')
							) t --data columns
			) attr
		group by 
			tile
		) attr_tile
		) cnct
	)
end DataHash
from
	INFORMATION_SCHEMA.COLUMNS info
)

select 
@lLODInsertExpression = concat('select row_id, ',BusinessHash,' bus_hash, ',DataHash,' data_hash from ',@pLODSchemaName,'.',@tableName)
,@lPSAInsertExpression = concat('select row_id, ',BusinessHash,' bus_hash, ',DataHash,' data_hash, row_status, active_flag from ',@pPSASchemaName,'.',@tableName,' where active_flag = ''Y''')
from 
selectexr;

SET @CTASExprsssionPSA = concat(@CTASExprsssionPSA, @nl, @lPSAInsertExpression);
SET @CTASExprsssionLOD = concat(@CTASExprsssionLOD, @nl, @lLODInsertExpression);

--print concat('@CTASExprsssionPSA ', @CTASExprsssionPSA);
--print concat('@CTASExprsssionLOD ', @CTASExprsssionLOD);

exec(@CTASExprsssionLOD);
IF object_id(@RCTablePSA, N'U') is null
BEGIN
	exec(@CTASExprsssionPSA);
END

/*
--LOD and PSA bus key are matching and data differs 
	-- insert new rows to psa 
		if old psa rows have row status 26006 active flag 'y' then new row would have row status 26006 else new rows would have row status 26001
	-- update existing business keys flag to false
--LOD buss hash is not in PSA bus hash - insert
	--insert new rows to psa

1. update existing rows in psa with modified data to be inactive (active flag 'n')
2. insert new rows to psa with bus hash and new data
*/
/*
if psa table already has bus key 'a' and the row_status is 26006 and active_flag 'y' 
and the lod table contains bus key 'a' with modified data then
load psa table with bus key 'a' and row_status 26006 and active flag 'y'
mark the stale bus key 'a' to have active flag of 'n'

*/
BEGIN TRANSACTION;
			BEGIN TRY
--1
declare @stmt nvarchar(max) = '';
set @stmt = concat('update ',@pPSASchemaName,'.',@tableName); 
set @stmt = concat(@stmt, @nl, 'set active_flag = ''N''');
set @stmt = concat(@stmt, @nl, 'from');
set @stmt = concat(@stmt, @nl, @pPSASchemaName, '.', @tableName, ' p');
set @stmt = concat(@stmt, @nl, 'inner join ',@RCTablePSA,' rcp on p.row_id = rcp.row_id'); --bus matching and data mismatching
set @stmt = concat(@stmt, @nl, 'inner join ',@RCTableLOD,' rcl on rcl.bus_hash = rcp.bus_hash and rcl.data_hash <> rcp.data_hash');
--print @stmt
exec(@stmt)

----2
declare @columnNames varchar(max);
set @columnNames = (select STRING_AGG(column_name, ',') within group (order by ORDINAL_POSITION asc) columnNames from 
	(select distinct CAST(column_name as varchar(max)) as column_name, ORDINAL_POSITION from INFORMATION_SCHEMA.COLUMNS info 
	where table_schema = @pLODSchemaName AND table_name = @tableName and column_name not in ('row_id','asset_id','etl_runlog_id','record_source_id')
	) t
	) 	

declare @selectColNames varchar(max);
set @selectColNames = (select STRING_AGG('NULLIF('+column_name+',''\N'')', ',') within group (order by ORDINAL_POSITION asc) columnNames from 
	(select distinct CAST(column_name as varchar(max)) as column_name, ORDINAL_POSITION from INFORMATION_SCHEMA.COLUMNS info 
	where table_schema = @pLODSchemaName AND table_name = @tableName and column_name not in ('row_id','asset_id','etl_runlog_id','record_source_id')
	) t
	) 

set @stmt = concat('insert into ',@pPSASchemaName,'.',@tableName,'('); 
set @stmt = concat(@stmt, @nl, @columnNames)
set @stmt = concat(@stmt, @nl, ',[row_id],[asset_id],[etl_runlog_id],[record_source_id]')	--exiting cols
set @stmt = concat(@stmt, @nl, ',[active_Flag], [created_timestamp], [row_status])')				--calculated cols
set @stmt = concat(@stmt, @nl, 'select');
set @stmt = concat(@stmt, @nl, @selectColNames)
set @stmt = concat(@stmt, @nl, ',l.[row_id],[asset_id],[etl_runlog_id],[record_source_id]')
set @stmt = concat(@stmt, @nl, ',[active_Flag] = ''y'', [created_timestamp] = current_timestamp, [row_status] = case when rcp.row_status=26006 and rcp.active_flag=''y'' then 26006 else 26001 end') -- needs correcting for 26006 (if there an active bus hash with 26006 then 26006 else 26001 ));
set @stmt = concat(@stmt, @nl, 'from');
set @stmt = concat(@stmt, @nl, @RCTableLOD, ' rcl');
set @stmt = concat(@stmt, @nl, 'left join ', @RCTablePSA, ' rcp on rcl.bus_hash = rcp.bus_hash');
set @stmt = concat(@stmt, @nl, 'inner join ', @pLODSchemaName,'.',@tableName, ' l on rcl.row_id = l.row_id');
set @stmt = concat(@stmt, @nl, 'where (rcl.data_hash <> rcp.data_hash) or rcp.data_hash is null'); --these are new records (includes updated as well)
--print @stmt
exec(@stmt)

COMMIT TRANSACTION
			END TRY
			BEGIN CATCH 
				THROW;					
				ROLLBACK TRANSACTION ;						
			END CATCH 
--tidy up lod helper
exec (@checktableLOD);
exec (@checktablePSA);
			
END
	 
GO
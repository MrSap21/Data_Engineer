/****** Object:  StoredProcedure [psa].[sp_cf_etl_audit]    Script Date: 8/7/2020 8:28:52 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_cf_etl_audit') IS NOT NULL
BEGIN
DROP PROC psa.sp_cf_etl_audit
END;
GO

CREATE PROC [psa].[sp_cf_etl_audit] @feed_id [int],@etl_runlog_id [int],@feed_status [varchar](10) AS
/*
ProcedureName : [sp_cf_etl_audit]
Purpose       : This Procedure Does the Curation Framework ETL Audit 
*/

DECLARE @cur_date datetime = getutcdate(),
		@cur_user varchar(50) = system_user,
		@feed_status_id int

BEGIN
	SET @feed_status_id = (SELECT ID FROM [psa].[cf_feed_load_status] WHERE status=@feed_status)
	INSERT INTO [psa].[cf_etl_audit] VALUES (@feed_id, @etl_runlog_id, @feed_status_id,@cur_date, @cur_user)
END
GO
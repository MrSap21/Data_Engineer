IF OBJECT_ID('psa.sp_SAPCRMAdcardSerLoad') IS NOT NULL
BEGIN
DROP PROC psa.sp_SAPCRMAdcardSerLoad
END;
GO

/****** Object:  StoredProcedure [psa].[sp_SAPCRMAdcardSerLoad]    Script Date: 9/17/2020 8:31:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [psa].[sp_SAPCRMAdcardSerLoad] @psaETLRunLogID [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@tableName [VARCHAR](max) AS

BEGIN

DECLARE
	@tETLRunLogId BigInt,
	@tMaxLoyaltyAccountId BigInt,
	@tMaxLoyaltyAccountCardId Bigint,
	@tLOVRecordSourceId BigInt,
	@tSCDLOVRecordSourceId BigInt,
	@tSCDVersion Int,
	@tSCDActiveFlag NChar(1),
	@tNSCDActiveFlag Nchar(1),
	@tSCDEndDate datetime,
	@tSCDStartDate datetime,
	@tCurTimestamp datetime,
	@tsqlqry Nvarchar(max),
	@tDandASourceId Int ,
	@tSAPCRMSourceId Int,
	@tStatusStart Int,
	@tStatusEnd Int,
	@tStatusMissingP Int,
	@tStatusMissingRef Int,
	@tProcCondition Nvarchar(max),
	@tStartVal BigInt,
	@tEndVal BigInt,
	@xact_state smallint;


	SET @tETLRunLogId=@serveETLRunLogID
	SET @tDandASourceId=12012
	SET @tSAPCRMSourceId=12011
	SET @tLOVRecordSourceId=12006
	SET @tSCDLOVRecordSourceId=114
	SET @tSCDVersion=1
	SET @tSCDActiveFlag='Y'
	SET @tNSCDActiveFlag='N'
	SET @tSCDEndDate='9999-12-31 00:00:00'
	SET @tSCDStartDate='1900-01-01 00:00:00'
	SET @tCurTimestamp=current_timestamp
	SET @tStatusStart =26001
	SET @tStatusEnd=26002
	SET @tStatusMissingP = 26003
	SET @tStatusMissingRef=26004 
	SET @xact_state=0

		SELECT @tMaxLoyaltyAccountId=COALESCE(max(LoyaltyAccountId),0) FROM ser.LoyaltyAccount ;
		SELECT @tMaxLoyaltyAccountCardId=COALESCE(max(LoyaltyAccountCardId),0) FROM ser.LoyaltyAccountCard;

	-- remove the temporary tables
		IF OBJECT_ID('tempdb..#tempSAPCRMAdCard') IS NOT NULL
		BEGIN
			DROP TABLE #tempSAPCRMAdCard;
		END


		IF OBJECT_ID('tempdb..#tempLoyaltyAccountCardStatus') IS NOT NULL
		BEGIN
			DROP TABLE #tempLoyaltyAccountCardStatus;
		END

			IF OBJECT_ID('tempdb..#temptgtLoyaltyAccountCardStatus') IS NOT NULL
		BEGIN
			DROP TABLE #temptgtLoyaltyAccountCardStatus;
		END

		IF OBJECT_ID('tempdb..#tempLoyaltyAccount') IS NOT NULL
		BEGIN
			DROP TABLE #tempLoyaltyAccount;
		END

		IF OBJECT_ID('tempdb..#temptgtLoyaltyAccount') IS NOT NULL
		BEGIN
			DROP TABLE #temptgtLoyaltyAccount;
		END
		

		IF OBJECT_ID('tempdb..#tempLoyaltyAccountCard') IS NOT NULL
		BEGIN
			DROP TABLE #tempLoyaltyAccountCard;
		END

			IF OBJECT_ID('tempdb..#temptgtLoyaltyAccountCard') IS NOT NULL
		BEGIN
			DROP TABLE #temptgtLoyaltyAccountCard;
		END

	-- Create the temporary tables

CREATE TABLE #tempSAPCRMAdCard
(
	[row_id] [bigint] NULL ,
	[account_number] [nvarchar](300) NULL,
	[full_card_number] [nvarchar](300) NULL,
	[card_status_code] [nvarchar](100) NULL,
	[card_type_code] [nvarchar](300) NULL,
	[account_status_code] [nvarchar](300) NULL,
	[account_status_reason_code] [nvarchar](300) NULL,
	[record_source_id] [int] NULL
)
WITH
(DISTRIBUTION = HASH(account_number));


CREATE TABLE #tempLoyaltyAccount
(
	[LoyaltyAccountId] [bigint] NOT NULL,
	[LOVLoyaltyProgramId] [int] NOT NULL,
	[SourceKey] [nvarchar](300) NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH(SourceKey)	
);


CREATE TABLE #tempTgtLoyaltyAccount
(
	[LoyaltyAccountId] [bigint] NOT NULL,
	[LOVLoyaltyProgramId] [int] NOT NULL,
	[SourceKey] [nvarchar](300) NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH(SourceKey)	
);

CREATE TABLE #tempLoyaltyAccountCard
(
	[LoyaltyAccountCardId] [bigint] NOT NULL,
	[LoyaltyAccountId] [bigint] NOT NULL,
	[LOVCardTypeId] [bigint] NOT NULL,
	[account_number] [nvarchar](300) NOT NULL,
	[SourceKey] [nvarchar](300) NOT NULL,
	[card_type_code] [nvarchar](300) NOT NULL,
	[LOVRecordSourceId] [bigint] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL,
	[lac_status] int NULL
)
WITH
(
	DISTRIBUTION =HASH(Sourcekey)
);


CREATE TABLE #temptgtLoyaltyAccountCard
(
	[LoyaltyAccountCardId] [bigint] NOT NULL,
	[LoyaltyAccountId] [bigint] NOT NULL,
	[LOVCardTypeId] [bigint] NOT NULL,
	[account_number] [nvarchar](300) NOT NULL,
	[SourceKey] [nvarchar](300) NOT NULL,
	[card_type_code] [nvarchar](300) NOT NULL,
	[LOVRecordSourceId] [bigint] NOT NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION =HASH(Sourcekey)
)
;

CREATE TABLE #tempLoyaltyAccountCardStatus
(
	[LoyaltyAccountCardId] [bigint] NOT NULL,
	[LOVLoyaltyAccountCardStatusSetId] [int] NOT NULL,
	[LOVStatusId] [int] NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[EffectiveFrom] [datetime]  NULL,
	[EffectiveTo] [datetime] NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [char](1) NULL,
	[SCDVersion] [smallint] NULL,
	[ETLRunLogId] [bigint] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH(LoyaltyAccountCardId)	
);

CREATE TABLE #temptgtLoyaltyAccountCardStatus
(
	[LoyaltyAccountCardId] [bigint] NOT NULL,
	[LOVLoyaltyAccountCardStatusSetId] [int] NOT NULL,
	[LOVStatusId] [int] NOT NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[EffectiveFrom] [datetime]  NULL,
	[EffectiveTo] [datetime] NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [char](1) NULL,
	[SCDVersion] [smallint] NULL,
	[ETLRunLogId] [bigint] NULL,
	[PSARowKey] [bigint] NULL,
	[updateInd] [int] NULL
)
WITH
(
	DISTRIBUTION = HASH(LoyaltyAccountCardId)	
);



BEGIN TRANSACTION;
	BEGIN TRY

	--  insert into temp table for psa data

INSERT INTO #tempSAPCRMAdCard
(
row_id
,account_number
,full_card_number
,card_status_code
,card_type_code
,account_status_code
,account_status_reason_code
,record_source_id
)
SELECT 
max(row_id) as row_id
,account_number
,full_card_number
,card_status_code
,card_type_code
,account_status_code
,account_status_reason_code
,max(record_source_id) as record_source_id
FROM psa.sap_crm_ad_card Where row_status=@tStatusStart group by account_number
,full_card_number
,card_status_code
,card_type_code
,account_status_code
,account_status_reason_code
;

RAISERROR ('INsert into temp table for psa data ', 0, 1) WITH NOWAIT

	--  insert into temp table for loyalty account data

INSERT INTO #tempLoyaltyAccount
(
LoyaltyAccountId
,LOVLoyaltyProgramId
,SourceKey
,LOVRecordSourceId
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,SCDLOVRecordSourceId
,ETLRunLogId
,PSARowKey
)
SELECT 
row_number() over(order by account_number) + @tMaxLoyaltyAccountId as LoyaltyAccountId
,(select DISTINCT LOVID from ser.reflovsetinfo where lovsetname='loyalty_program' and lovkey='ADCARD' and LOVRecordSourceId=@tSAPCRMSourceId  ) as LOVLoyaltyProgramId
,acc.account_number as SourceKey
,acc.record_source_id as LOVRecordSourceId
,@tSCDStartDate as SCDStartDate
,@tSCDEndDate as SCDEndDate
,@tSCDActiveFlag as SCDActiveFlag
,@tSCDVersion as SCDVersion
,@tSCDLOVRecordSourceId as SCDLOVRecordSourceId
,@tETLRunLogId as ETLRunLogId
,acc.row_id as PSARowKey
FROM (SELECT  account_number, max(row_id) as row_id, max(record_source_id) as record_source_id  FROM #tempSAPCRMAdCard group by account_number) acc
WHERE NOT EXISTS (SELECT 1 FROM ser.LoyaltyAccount la WHERE 
la.sourcekey=acc.account_number 
and la.SCDActiveFlag='Y'
and la.LOVRecordSourceId=@tSAPCRMSourceId
and la.LOVRecordSourceId=acc.record_source_id)
;

RAISERROR ('Insert for loyalty account temp table completed', 0, 1) WITH NOWAIT

	--  insert into target table for loyalty account data
INSERT INTO ser.LoyaltyAccount
(
LoyaltyAccountId
,LOVLoyaltyProgramId
,SourceKey
,LOVRecordSourceId
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,SCDLOVRecordSourceId
,ETLRunLogId
,PSARowKey
)
SELECT 
LoyaltyAccountId
,LOVLoyaltyProgramId
,SourceKey
,LOVRecordSourceId
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,SCDLOVRecordSourceId
,ETLRunLogId
,PSARowKey FROM #tempLoyaltyAccount;

RAISERROR ('Insert into loyalty accoun target completed', 0, 1) WITH NOWAIT

	--  insert into temp table for loyalty account target data matching psa data

INSERT INTO #temptgtLoyaltyAccount
(
LoyaltyAccountId
,LOVLoyaltyProgramId
,SourceKey
,LOVRecordSourceId
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,SCDLOVRecordSourceId
,ETLRunLogId
,PSARowKey
)
SELECT 
LoyaltyAccountId
,LOVLoyaltyProgramId
,SourceKey
,LOVRecordSourceId
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,SCDLOVRecordSourceId
,ETLRunLogId
,PSARowKey FROM ser.LoyaltyAccount la
WHERE la.SCDActiveFlag='Y' and la.LOVRecordSourceId=@tSAPCRMSourceId AND 
EXISTS (
SELECT 1 FROM #tempSAPCRMAdCard ps WHERE ps.account_number=la.SourceKey and ps.record_source_id=@tSAPCRMSourceId
)
;

RAISERROR ('Completed the temp table load for the loyalty account target data', 0, 1) WITH NOWAIT


	--  insert into temp table for loyalty account card data

INSERT INTO #tempLoyaltyAccountCard
(
LoyaltyAccountCardId
,LoyaltyAccountId
,LOVCardTypeId
,account_number
,SourceKey
,card_type_code
,LOVRecordSourceId
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,SCDLOVRecordSourceId
,ETLRunLogId
,PSARowKey
,lac_status
)
SELECT 
 CASE when lac.LoyaltyAccountCardId  IS NULL then row_number() over(order by ps.full_card_number) + @tMaxLoyaltyAccountCardId ELSE lac.LoyaltyAccountCardId END as LoyaltyAccountCardId
,la.LoyaltyAccountId as LoyaltyAccountId
,ref.LovId as LOVCardTypeId
,ps.account_number as account_number
,ps.full_card_number as SourceKey
,ps.card_type_code as card_type_code
,@tSAPCRMSourceId as LOVRecordSourceId
,@tSCDStartDate as SCDStartDate
,@tSCDEndDate as SCDEndDate
,@tSCDActiveFlag as SCDActiveFlag
,@tSCDVersion as SCDVersion
,@tSCDLOVRecordSourceId as SCDLOVRecordSourceId
,@tETLRunLogId as ETLRunLogId
,ps.row_id as PSARowKey
,CASE WHEN lac.LoyaltyAccountCardId IS NULL then 1 else 0 END as lac_status
FROM (select max(row_id) as row_id
,account_number
,full_card_number 
,card_type_code
FROM #tempSAPCRMAdCard group by account_number,full_card_number ,card_type_code) ps
INNER JOIN ser.reflovsetinfo ref
ON ref.lovsetname='card_type'
AND ref.lovkey=ps.card_type_code
AND ref.LOVrecordSourceId=@tSAPCRMSourceId
INNER JOIN #temptgtLoyaltyAccount la
ON ps.account_number=la.SourceKey
LEFT JOIN  ser.LoyaltyAccountCard lac
ON la.LoyaltyAccountId=lac.LoyaltyAccountId
AND ref.LOVId=lac.LOVCardTypeId
AND ps.full_card_number =lac.SourceKey
AND lac.SCDActiveFlag='Y'
;

RAISERROR ('Completed the load to loyalty account card status temp table', 0, 1) WITH NOWAIT

	--  insert into tgt table for loyalty account card data

INSERT INTO ser.LoyaltyAccountCard
(
LoyaltyAccountCardId
,LoyaltyAccountId
,LOVCardTypeId
,SourceKey
,LOVRecordSourceId
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,SCDLOVRecordSourceId
,ETLRunLogId
,PSARowKey
)
SELECT 
 LoyaltyAccountCardId
,LoyaltyAccountId
,LOVCardTypeId
,SourceKey
,LOVRecordSourceId
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,SCDLOVRecordSourceId
,ETLRunLogId
,PSARowKey
FROM #tempLoyaltyAccountCard ac where lac_status=1
;

RAISERROR ('Completed insert into loyalty account card tgt table', 0, 1) WITH NOWAIT



--  insert into temp table for loyalty account card status 


INSERT INTO #tempLoyaltyAccountCardStatus
(
[LoyaltyAccountCardId]
,[LOVLoyaltyAccountCardStatusSetId]
,[LOVStatusId]
,[LOVRecordSourceId]
,[SCDLOVRecordSourceId]
,[EffectiveFrom]
,[EffectiveTo]
,[SCDStartDate]
,[SCDEndDate]
,[SCDActiveFlag]
,[SCDVersion]
,[ETLRunLogId]
,[PSARowKey]
)
SELECT
 lac.LoyaltyAccountCardId as [LoyaltyAccountCardId]
,refs.lovsetid as [LOVLoyaltyAccountCardStatusSetId]
,refs.lovid as [LOVStatusId]
,@tSAPCRMSourceId as [LOVRecordSourceId]
,@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId]
,cast(NULL as datetime) as EffectiveFrom
,cast(NULL as datetime) as EffectiveTo
,@tSCDStartDate as SCDStartDate
,@tSCDEndDate as SCDEndDate
,@tSCDActiveFlag as SCDActiveFlag
,@tSCDVersion as SCDVersion
,@tETLRunLogId as ETLRunLogId
,ps.row_id as PSARowKey
FROM (select max(row_id) as row_id
,account_number
,full_card_number 
,card_type_code
,max(card_status_code) as card_status_code
FROM #tempSAPCRMAdCard group by account_number,full_card_number ,card_type_code) ps
INNER JOIN #tempLoyaltyAccountCard lac
ON ps.account_number=lac.account_number
AND ps.full_card_number = lac.sourcekey
AND ps.card_type_code=lac.card_type_code
INNER JOIN ser.reflovsetinfo refs
ON refs.lovsetname='card_status'
AND refs.lovkey=ps.card_status_code
AND refs.LOVrecordSourceId=@tSAPCRMSourceId

RAISERROR ('Completed insert into temp loyalty account card status table', 0, 1) WITH NOWAIT


--  insert into tmp tgt table for loyalty account card status 

INSERT INTO #temptgtLoyaltyAccountCardStatus
(
LoyaltyAccountCardId
,LOVLoyaltyAccountCardStatusSetId
,LOVStatusId
,LOVRecordSourceId
,SCDLOVRecordSourceId
,EffectiveFrom
,EffectiveTo
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,ETLRunLogId
,PSARowKey
,updateInd
)
SELECT
lcas.LoyaltyAccountCardId
,lcas.LOVLoyaltyAccountCardStatusSetId
,lcas.LOVStatusId
,lcas.LOVRecordSourceId
,lcas.SCDLOVRecordSourceId
,lcas.EffectiveFrom
,lcas.EffectiveTo
,lcas.SCDStartDate
,lcas.SCDEndDate
,lcas.SCDActiveFlag
,lcas.SCDVersion
,lcas.ETLRunLogId
,lcas.PSARowKey
,case when lcas.LOVstatusId <> tlcas.LOVstatusId THEN 1 else 0 END as  updateInd
FROM ser.LoyaltyAccountCardStatus lcas
INNER JOIN #tempLoyaltyAccountCardStatus tlcas
ON lcas.LoyaltyAccountCardId=tlcas.LoyaltyAccountCardId
AND lcas.LOVLoyaltyAccountCardStatusSetId =tlcas.LOVLoyaltyAccountCardStatusSetId
AND lcas.SCDActiveFlag='Y'
;

RAISERROR ('Completed insert into loyalty account card status temp tgt table', 0, 1) WITH NOWAIT

--  insert into tgt table for loyalty account card status 

INSERT INTO ser.LoyaltyAccountCardStatus
(
LoyaltyAccountCardId
,LOVLoyaltyAccountCardStatusSetId
,LOVStatusId
,LOVRecordSourceId
,SCDLOVRecordSourceId
,EffectiveFrom
,EffectiveTo
,SCDStartDate
,SCDEndDate
,SCDActiveFlag
,SCDVersion
,ETLRunLogId
,PSARowKey
)
SELECT 
 tlacs.LoyaltyAccountCardId
,tlacs.LOVLoyaltyAccountCardStatusSetId
,tlacs.LOVStatusId
,@tSAPCRMSourceId as LOVRecordSourceId
,@tSCDLOVRecordSourceId as SCDLOVRecordSourceId
,tlacs.EffectiveFrom
,tlacs.EffectiveTo
,case when lacs.LoyaltyAccountCardId IS NULL then @tSCDStartDate else  @tCurTimestamp END as  SCDStartDate
,@tSCDEndDate as SCDEndDate
,@tSCDActiveFlag as SCDActiveFlag
,case when lacs.LoyaltyAccountCardId IS NULL then @tSCDVersion else lacs.SCDVersion + 1  END AS  SCDVersion
,@tETLRunLogId as ETLRunLogId
,tlacs.PSARowKey
FROM (SELECT * FROM #tempLoyaltyAccountCardStatus t WHERE NOT EXISTS (SELECT 1 FROM #temptgtLoyaltyAccountCardStatus tl
WHERE t.LoyaltyAccountCardId=tl.LoyaltyAccountCardId
AND t.LOVLoyaltyAccountCardStatusSetId =tl.LOVLoyaltyAccountCardStatusSetId
AND t.LOVStatusid=tl.LOVStatusId) )tlacs
LEFT JOIN #temptgtLoyaltyAccountCardStatus lacs
ON tlacs.LoyaltyAccountCardId=lacs.LoyaltyAccountCardId
AND tlacs.LOVLoyaltyAccountCardStatusSetId=lacs.LOVLoyaltyAccountCardStatusSetId
;

RAISERROR ('Completed insert into loyalty account card status tgt table', 0, 1) WITH NOWAIT


--  UPDATE into tgt table for loyalty account card status 

UPDATE ser.LoyaltyAccountCardStatus
SET SCDActiveFlag='N' , SCDEndDate=dateadd(second,-1,@tCurTimestamp)
FROM ser.LoyaltyAccountCardStatus lacs
INNER JOIN #temptgtLoyaltyAccountCardStatus tlacs
ON tlacs.LoyaltyAccountCardId=lacs.LoyaltyAccountCardId
AND tlacs.LOVLoyaltyAccountCardStatusSetId=lacs.LOVLoyaltyAccountCardStatusSetId
AND tlacs.updateInd=1
AND tlacs.SCDVersion=lacs.SCDVersion


RAISERROR ('update loyalty account card status tgt table', 0, 1) WITH NOWAIT

Update psa.sap_crm_ad_card SET row_status=26002
FROM psa.sap_crm_ad_card  tgt
INNER JOIN #tempSAPCRMAdCard temp
ON tgt.account_number=temp.account_number
AND tgt.full_card_number=temp.full_card_number
AND tgt.card_status_code=temp.card_status_code
AND tgt.card_type_code=temp.card_type_code;


END TRY

BEGIN CATCH
DECLARE @error_num varchar(max),
		@error_msg varchar(max),
		@error_sev varchar(max)
		;
		ROLLBACK TRANSACTION;
SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',18,1,@error_num,@error_msg,@error_sev) WITH NOWAIT
	
END CATCH
 COMMIT TRANSACTION;

END
GO
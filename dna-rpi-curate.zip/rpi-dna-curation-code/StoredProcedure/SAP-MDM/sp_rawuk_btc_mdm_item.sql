/****** Object:  StoredProcedure [psa].[sp_rawuk_btc_mdm_item]    Script Date: 03/08/2020 17:39:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_rawuk_btc_mdm_item') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawuk_btc_mdm_item
END
GO

CREATE PROC [psa].[sp_rawuk_btc_mdm_item] @tableName [varchar](max),@psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max) AS
/*
************************************************************************************************************
Procedure Name					: sp_rawuk_btc_mdm_item
Purpose							: Load History data From SAP MDM Source(btc_mdm_item) into Serve Layer Table
Domain							: Product
ServeLayer Target Tables		: Product,ProductGroup,ProductIndicator,ProductIdentifier,ProductStatus,
									Party,Organization,PartyRole,PrductPartyRole    (Total 9 Tables)
RecordSourceID  for SAP MDM		: 12008
RecordSourceID  for Mainframe	: 12003
************************************************************************************************************
Default values for SCD Columns (as there is no duplicate entries for item_code in Production History Data)
************************************************************************************************************
***HISTORY/HISTORY CATCH UP NEW RECORDS******
SCDStartDate        :   1900-01-01 /ProcessingDateTime 
SCDEndDate          :  '9999-12-31' 
SCDActiveFlag       :  'Y'   
SCDVersion          :  '1' 
SCDLOVRecordSourceId: 151 
ETLRunLogId         : serveRunlogID taken as input parameter from Framework API
*************************************************************************************************************
Modification History
Incorporated v1.6 mapping changes
Incorporated History Catchup logic
Incorporated v2.0 mapping changes
       a) Remove CostCentreId mapping from product
	   b) Migrate cost_centre as item_hierachy6 to ProductGroup
14-July-2020: 	 Added THROW Statement in Catch block and added print statements
23-July-2020: Incorporated v2.1 mapping  and SCDRules v2.12 changes	 
				a) Added new mapping for ProductPartyRole Table
				b) Added SCD Changes, first record should start at a min date
					i.e. ‘1900-01-01 00:00:00’ and at the end record end at a max
					date i.e. ‘9999-12-31 00:00:00’
					
 03-08-2020: Bug fix-ScdStartDate in Part,Organisation,PartyRole Table
 
 */ 

 /*Declare  and initialize the Variables required for serve layer processing*/

DECLARE @mdm_record_sourceID bigint,
		@max_productID bigint,
		@PartyType_Id bigint,
		@max_PartyId bigint,
		@max_productgroupId bigint,
		@max_partyrole_id  bigint ,
		@LOVRoleIDS bigint,
		@LOVRoleIdR bigint,
		@partyRoleID bigint,
		@LovStatusIDD bigint ,
		@LovStatusIDI bigint ,
		@LOVProductStatusSetId bigint,
		@LOVProductStatusSetIdRSC bigint,
        @SCDDefaultStartDate Varchar(100)= '1900-01-01', 
		@SCDStartDate Varchar(100)= current_timestamp,
		@SCDEndDate Varchar(100)= '9999-12-31' ,
		@SCDActiveFlag  Varchar(10) ='Y'  ,
		@SCDVersion Varchar(100) ='1',
		@SCDLOVRecordSourceId Varchar(100)= '151' ,
		@ETLRunLogId int =0,
		@mainframe_record_source_id int=12003,
		@LOVSourceKeyTypeId bigint,
		@row_status bigint =26001,
		@row_status_final bigint =26002,
		@flag int
		
BEGIN
	
	BEGIN TRANSACTION;	
			/*Setting the up the static values to the variable*/
			SET @mdm_record_sourceID =12008
			SET @max_productID=(SELECT COALESCE(MAX(ProductID),0) FROM  ser.Product)
			SET @max_PartyId=(SELECT COALESCE(MAX(PartyID),0) FROM  ser.Party)
			SET @max_productgroupId=(SELECT COALESCE(MAX(ProductGroupId),0)  FROM  ser.ProductGroup)
			SELECT @PartyType_Id=LOVId FROM ser.RefLOV r,ser.RefLOVSet rs WHERE r.LOVKey = 'ORG'AND r.LOVSetId =  rs.LOVSetId and rs.LOVSetName = 'Party Type'
			SET @max_partyrole_id=(SELECT COALESCE(MAX(PartyRoleID),0) from ser.PartyRole)
			SELECT @LOVRoleIDR = r.LOVId FROM ser.RefLOV r ,ser.RefLOVSet rs WHERE r.LOVKey = 'Retailer' AND r.LOVSetId = rs.LOVSetId and rs.LOVSetName = 'Role'
			SELECT @LOVRoleIDS = r.LOVId FROM ser.RefLOV r ,ser.RefLOVSet rs WHERE r.LOVKey = 'Supplier' AND r.LOVSetId = rs.LOVSetId and rs.LOVSetName = 'Role'
			SET @LovStatusIDD=(SELECT LovID from ser.RefLOV where LOVKey = 'DSCNTND' AND LovSetId = (SELECT rs.LovSetID from ser.RefLOVSet rs   WHERE rs.LOVSetName = 'Status Type'  ))	
			SET @LovStatusIDI=(SELECT r.LovID from ser.RefLOV r where r.LOVKey = 'INTRDCD' AND r.LovSetId = (SELECT rs.LovSetID from ser.RefLOVSet rs   WHERE rs.LOVSetName = 'Status Type'  ))	
			SET @LOVProductStatusSetId=	(SELECT  rs.LovSetID FROM ser.RefLOVSet rs WHERE rs.LOVSetName = 'Status Type')
			SET @LOVProductStatusSetIdRSC=(SELECT  rs.LovSetID FROM ser.RefLOVSet rs WHERE rs.LOVSetName = 'retail_status_code')
			SET @LOVSourceKeyTypeId=(SELECT rl.LOVId FROM  ser.RefLov rl
									LEFT JOIN ser.RefLovSet rls   on rl.LOVSETId=rls.LOVSetID	           
									WHERE rl.LOVKey ='SAP Article Number' and rls.LOVSetName = 'Source Key Type') 
		BEGIN TRY 
	
				/* 1.Table Name  :Product*/				

				PRINT '********Info: MDM Product PSA(rawuk_btc_mdm_item) to Serve Load Started********';  
				PRINT 'Info: Product Table Serve Loading Started';
				INSERT INTO ser.Product (
					ProductId,SourceKey,LOVSourceKeyTypeId,ProductName ,ProductDescription,LOVBrandId,LOVSubBrandId ,  					
					LOVRecordSourceId,ParentProductId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
				SELECT      ISNULL(p.ProductID,row_num+@max_productID) ProductID, 
							mdmi.item_code SourceKey,
							@LOVSourceKeyTypeId LOVSourceKeyTypeId,
							mdmi.Item_name ProductName,
							null ProductDescription ,	
							br.LOVId LOVBrandId,
							sbr.LOVId SubBrandId,       
							mdmi.record_source_id LOVRecordSourceId,
							null ParentProductID,
							(CASE WHEN p.SCDStartDate is null THEN CONVERT (Datetime,@SCDDefaultStartDate)
								  ELSE CONVERT (Datetime,@SCDStartDate)
							END) as SCDStartDate,				
							convert (datetime,@SCDEndDate) SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY mdmi.item_code,mdmi.record_source_id ORDER BY mdmi.item_code ASC) SCDActiveFlag,				
							(CASe When p.SCDVersion is null then 1
								ELSE 
									p.SCDVersion+1 
							END) SCDVersion,
							@SCDLOVRecordSourceId SCDLOVRecordSourceId,
							@serveETLRunLogID ETLRunLogId,
							row_id PSARowKey
				FROM psa.[rawuk_btc_mdm_item]  mdmi
				join (SELECT mdmi.item_code,
							mdmi.record_source_id,
							ROW_NUMBER() OVER(ORDER BY mdmi.item_code,mdmi.record_source_id ASC) row_num
					FROM psa.[rawuk_btc_mdm_item] mdmi WHERE mdmi.row_status=@row_status  GROUP BY mdmi.item_code,mdmi.record_source_id) productTemp
				ON mdmi.item_code=productTemp.item_code	
				AND  mdmi.record_source_id=productTemp.record_source_id	
				Left join ser.product p 
				on  mdmi.item_code =p.sourcekey
				AND p.LOVRecordSourceID = mdmi.record_source_id
				left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
							ser.RefLov rl
							join ser.RefLovSet rls
							on rl.LOVSETId=rls.LOVSetID                 
							where rls.LOVSetName = 'brand_code' )br
				on mdmi.record_source_id=br.LOVRecordSourceId and  br.LOVKey = mdmi.brand_code
				left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
							ser.RefLov rl
							join ser.RefLovSet rls
							on rl.LOVSETId=rls.LOVSetID                 
							where rls.LOVSetName = 'sub_brand_code' )sbr
				on mdmi.record_source_id=sbr.LOVRecordSourceId and  sbr.LOVKey = mdmi.sub_brand_code				
				WHERE mdmi.row_status=@row_status
					AND ISNULL (p.SCDActiveFlag,'Y')='Y'
					AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','));		
	          

				 --Update the active flag and end date for older version	
				PRINT 'Info: Product Table -> Closing off old Records if exists'; 

				UPDATE ser.Product set SCDActiveFlag='N',SCDEndDate =DATEADD(second,-1,@SCDStartDate)
                 FROM ser.Product p 
					  JOIN 
					 (SELECT   productId,SCDactiveflag,max(SCDVersion) SCDVersion,LovRecordSourceId from ser.Product
					            Where SCDactiveflag='Y' group by productId,SCDactiveflag,LovRecordSourceId)p2
				           ON  p.productID=p2.productId
				           AND p.LovRecordSourceId=p2.LovRecordSourceId						 
						   AND p.SCDactiveflag=p2.SCDactiveflag
						   AND p.SCDVersion!=p2.SCDVersion
				join psa.[rawuk_btc_mdm_item] mdmi
				ON mdmi.record_source_id=p.LovRecordSourceId and
				p.sourcekey = mdmi.item_code
				WHERE p.LovRecordSourceId=@mdm_record_sourceID aND
				p.SCDActiveFlag='Y' AND p.SCDEndDate =convert (datetime,@SCDEndDate) 
				AND p.etlrunlogid not in (@serveETLRunLogID)
				AND mdmi.row_status=@row_status 
				and etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','));
				
				PRINT 'Info: Product Table Loaded Successfully ';  
				
				/*Table 2:  ProductGroup*/
	
				/* Logic:  16 Source Columns are mapped to ProductGroup able as different rows
				item_hierarchy1_number,item_hierarchy2_number,item_hierarchy3_number,item_hierarchy4_number,item_hierarchy5_number,cost_center		
				merchandise_category_code,occasion_code,item_type,ladder_id,sub_ladder_id,bbe_attribute_code,(11 columns uses MDM recordsourceid to get the Reflov and Reflovset values)
				merchandise_group_number,business_centre_number,concept_group_number,concept_seq_number  (5 Colums uses Mainframe record sourceID to get the Reflov and Reflovset values) 
				*************************************************************************************************************************************************************************
				Query Tracker#55 : In the mapping file we have data that originates from 2 different sources: SAP MDM (12008) and UK Mainframe (12003)
				
				The transpose Logic is done using unpivot */					
				PRINT 'Info: ProductGroup Table Serve Loading Started';  
	            
				WITH ProductGroup_CTE AS
				(SELECT 
								ProductId,
								PGCol,
								(CASE 
										WHEN PGCol in ('item_hierarchy1_number','item_hierarchy2_number','item_hierarchy3_number','item_hierarchy4_number','item_hierarchy5_number') THEN
													(SELECT r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = ''+PGValue+'' AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = ''+REPLACE (PGCol,'_number','')+'' and rs.LOVSetRecordSourceID = @mdm_record_sourceID)) 
										WHEN PGCol in ('cost_center') THEN
													(SELECT r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = ''+PGValue+'' AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = 'item_hierarchy6' and rs.LOVSetRecordSourceID = @mdm_record_sourceID)) 
										WHEN PGCol in ('merchandise_group_number','business_centre_number','concept_group_number','concept_seq_number') THEN
													(SELECT r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = ''+PGValue+'' AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = ''+PGCol+'' and rs.LOVSetRecordSourceID =@mainframe_record_source_id))
										ELSE 
											(SELECT r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = ''+PGValue+'' AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = ''+PGCol+'' and rs.LOVSetRecordSourceID =@mdm_record_sourceID))
								END ) LOVGroupId,
								(CASE 
									WHEN PGCol in ('item_hierarchy1_number','item_hierarchy2_number','item_hierarchy3_number','item_hierarchy4_number','item_hierarchy5_number') THEN
											(SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = ''+REPLACE (PGCol,'_number','')+'' and rs.LOVSetRecordSourceID = @mdm_record_sourceID) 
									WHEN PGCol in ('cost_center') THEN
											(SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = 'item_hierarchy6' and rs.LOVSetRecordSourceID = @mdm_record_sourceID) 
									WHEN PGCol in ('merchandise_group_number','business_centre_number','concept_group_number','concept_seq_number') THEN
											(SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = ''+PGCol+'' and rs.LOVSetRecordSourceID = @mainframe_record_source_id ) 
									ELSE
										(SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = ''+PGCol+'' and rs.LOVSetRecordSourceID = @mdm_record_sourceID )
								END ) LOVProductGroupSetId,
								PGValue  value ,
								ParentProductGroupId,
								(CASE WHEN PGCol in ('merchandise_group_number','business_centre_number','concept_group_number','concept_seq_number') THEN
								             @mainframe_record_source_id
								       ELSE   LOVRecordSourceId END ) LOVRecordSourceId,							 
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								ETLRunLogId,
								PSARowKey
				FROM
				(SELECT
					 p.ProductID		
					 ,mdmi.item_hierarchy1_number  item_hierarchy1_number
					 ,mdmi.item_hierarchy2_number  item_hierarchy2_number
					 ,mdmi.item_hierarchy3_number  item_hierarchy3_number
					 ,mdmi.item_hierarchy4_number  item_hierarchy4_number
					 ,mdmi.item_hierarchy5_number  item_hierarchy5_number
					 ,mdmi.cost_center  cost_center
					 ,mdmi.merchandise_category_code
					 ,mdmi.occasion_code
					 ,mdmi.item_type
					 ,mdmi.merchandise_group_number  merchandise_group_number
					 ,mdmi.business_centre_number  business_centre_number
					 ,mdmi.concept_group_number  concept_group_number
					 ,mdmi.concept_seq_number   concept_seq_number
					 ,mdmi.ladder_id
					 ,mdmi.sub_ladder_id
					 ,mdmi.bbe_attribute_code
					 ,mdmi.record_source_id LOVRecordSourceId
					 ,null ParentProductGroupId
					 ,cast (@serveETLRunLogID as bigint)  ETLRunLogId
					 ,mdmi.row_id PSARowKey
				FROM psa.rawuk_btc_mdm_item mdmi 
				INNER JOIN
				ser.Product p 
							ON p.SourceKey =  mdmi.item_code AND
								p.LOVRecordSourceID = mdmi.record_source_id
								and p.SCDActiveFlag='Y'
				WHERE  mdmi.row_status=@row_status	
				AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','))
				) pg
				UNPIVOT  
							( PGValue FOR PGCol IN ( pg.item_hierarchy1_number
													,pg.item_hierarchy2_number
													,pg.item_hierarchy3_number
													,pg.item_hierarchy4_number
													,pg.item_hierarchy5_number
													,pg.cost_center
													,pg.merchandise_category_code
													,pg.occasion_code
													,pg.item_type
													,pg.merchandise_group_number
													,pg.business_centre_number
													,pg.concept_group_number
													,pg.concept_seq_number
													,pg.ladder_id
													,pg.sub_ladder_id
													,pg.bbe_attribute_code)
							)	AS LOVGroupId  

                   )			

				INSERT  INTO  ser.ProductGroup (ProductGroupId,
													ProductId     ,
													LOVGroupId            ,
													LOVProductGroupSetId  ,
													ParentProductGroupId  ,
													LOVRecordSourceId     ,
													SCDStartDate          ,
													SCDEndDate            ,
													SCDActiveFlag         ,
													SCDVersion            ,
													SCDLOVRecordSourceId  ,
													ETLRunLogId,
													PSARowKey)
							SELECT  ISNULL(spg.ProductGroupId,(PGTemp.row_num+@max_productgroupId)) as ProductGroupId,
									pgt.ProductId,
									pgt.LOVGroupId,
									pgt.LOVProductGroupSetId,
									pgt.ParentProductGroupId,
									pgt.LOVRecordSourceId,
									(CASE WHEN spg.SCDStartDate is null THEN CONVERT (Datetime,@SCDDefaultStartDate)
									ELSE CONVERT (Datetime,@SCDStartDate)
									END) as SCDStartDate,									
									CONVERT (datetime,@SCDEndDate) SCDEndDate,
									LEAD('N', 1, 'Y') OVER(PARTITION BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ORDER BY pgt.ProductID,pgt.LOVProductGroupSetId,pgt.LOVRecordSourceId ASC) SCDActiveFlag,				
									(CASe When spg.SCDVersion is null then 1
											ELSE spg.SCDVersion+1 	END) as SCDVersion, 
									pgt.SCDLOVRecordSourceId  ,
									pgt.ETLRunLogId,
									pgt.PSARowKey
							FROM ProductGroup_CTE  pgt	 
							JOIN
							(SELECT ProductID, LOVProductGroupSetId,LOVRecordSourceId,ROW_NUMBER() OVER(ORDER BY ProductID,LOVProductGroupSetId,LOVRecordSourceId ASC) row_num
									FROM ProductGroup_CTE   GROUP BY ProductID,LOVProductGroupSetId,LOVRecordSourceId )  PGTemp
								ON pgt.ProductID=PGTemp.ProductID
								AND pgt.LOVProductGroupSetId=PGTemp.LOVProductGroupSetId
								AND pgt.LOVRecordSourceId=PGTemp.LOVRecordSourceId
							LEFT  JOIN ser.productGroup spg
								ON pgt.productid=spg.productid
								AND pgt.LOVProductGroupSetId=spg.LOVProductGroupSetId
								AND pgt.LOVRecordSourceId=spg.LOVRecordSourceId
							WHERE pgt.value is not null AND pgt.LOVGroupId is not null
														AND pgt.value !='' 
														AND ISNULL (spg.SCDActiveFlag,'Y') ='Y' ;
				
				 --Update the active flag and end date for older version
				PRINT 'Info: ProductGroup Table -> Closing off old Records if exists';

				UPDATE ser.ProductGroup set SCDActiveFlag='N',SCDEndDate =DATEADD(second,-1,@SCDStartDate)
                 FROM ser.ProductGroup pg 
					  JOIN 
					 (SELECT   productId,LOVProductGroupSetId,SCDactiveflag,max(SCDVersion) SCDVersion,LovRecordSourceId from ser.ProductGroup
					            Where SCDactiveflag='Y' group by productId,LOVProductGroupSetId,SCDactiveflag,LovRecordSourceId)pg2
				           ON  pg.productID=pg2.productId
				           AND pg.LovRecordSourceId=pg2.LovRecordSourceId
						   AND pg.LOVProductGroupSetId=pg2.LOVProductGroupSetId						 
						   AND pg.SCDactiveflag=pg2.SCDactiveflag
						   AND pg.SCDVersion!=pg2.SCDVersion
				WHERE pg.LovRecordSourceId in (@mdm_record_sourceID,@mainframe_record_source_id) AND
				pg.SCDActiveFlag='Y' AND   pg.SCDEndDate =convert (datetime,@SCDEndDate) 
				AND pg.etlrunlogid not in (@serveETLRunLogID);				
			
				PRINT 'Info: ProductGroup Table Loaded Successfully';  
						
						/* 3.Table Name  :ProductIndicator*/
				PRINT 'Info: ProductIndicator Table Serve Loading Started';  

				INSERT INTO ser.ProductIndicator(
													ProductId           ,
													LOVIndicatorId      ,
													Value               ,
													LOVRecordSourceId,
													SCDStartDate        ,
													SCDEndDate          ,
													SCDActiveFlag       ,
													SCDVersion          ,
													SCDLOVRecordSourceId,
													ETLRunLogId ,
													PSARowKey)
	
	
				SELECT      pindTemp.ProductID,
							pindTemp.LOVIndicatorId,
							pindTemp.value ,
							pindTemp.LOVRecordSourceId,	
							(CASE WHEN pind.SCDStartDate is null THEN CONVERT (Datetime,@SCDDefaultStartDate)
									ELSE CONVERT (Datetime,@SCDStartDate)
							END) as SCDStartDate,
							CONVERT (datetime,@SCDEndDate) SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId ORDER BY pindTemp.ProductID,pindTemp.LOVIndicatorId,pindTemp.LOVRecordSourceId ASC) SCDActiveFlag,				
							(CASe When pind.SCDVersion is null then 1
								 ELSE pind.SCDVersion+1 	END) as SCDVersion,											
							pindTemp.SCDLOVRecordSourceId,
							pindTemp.ETLRunLogId,
							pindTemp.PSARowKey
				FROM 
					  (SELECT ProductID , 
								(SELECT r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = ''+PICol+''AND 
								LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = 'Indicator - BUK MDM Product')) LOVIndicatorId,PIValue as value,
								LOVRecordSourceId,
								SCDLOVRecordSourceId,
								ETLRunLogId ,
								PSARowKey
							FROM
								(SELECT p.ProductId,
								mdmi.own_brand_ind,
								mdmi.exclusive_ind,
								mdmi.staff_discount_ind,
								mdmi.earn_points_ind,
								mdmi.redeem_points_ind,
								mdmi.gift_with_purchase_ind,
								mdmi.record_source_Id LOVRecordSourceId,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								@serveETLRunLogID ETLRunLogId,
								mdmi.row_id PSARowKey
								FROM psa.rawuk_btc_mdm_item mdmi,
									 ser.Product p
								WHERE mdmi.item_code=p.SourceKey
								AND	p.LOVRecordSourceID = mdmi.record_source_id
									AND mdmi.row_status=@row_status
									AND p.SCDActiveFlag='Y'
									AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ',')) ) t
								UNPIVOT
								(PIValue FOR PICol in   (own_brand_ind,
														exclusive_ind,
														staff_discount_ind,
														earn_points_ind,
														redeem_points_ind,
														gift_with_purchase_ind)
								) as  productIndicator  ) as  pindTemp
							LEFT JOIN ser.ProductIndicator pind
								ON pindTemp.productid=pind.productid
								AND pindTemp.LOVIndicatorId=pind.LOVIndicatorId
								AND pindTemp.LOVRecordSourceId=pind.LOVRecordSourceId
							WHERE pindTemp.value is not null AND pindTemp.value!='' AND
							ISNULL (pind.SCDActiveFlag,'Y') ='Y'  ;	

				--Update the active flag and end date for older version
				PRINT 'Info: ProductIndicator Table -> Closing off old Records if exists';

				UPDATE ser.ProductIndicator set SCDActiveFlag='N',SCDEndDate =DATEADD(second,-1,@SCDStartDate)
                 FROM ser.ProductIndicator pind 
					  JOIN 
					 (SELECT   productId,LOVIndicatorID,SCDactiveflag,max(SCDVersion) SCDVersion,LovRecordSourceId from ser.productIndicator
					            Where SCDactiveflag='Y' group by productId,LOVIndicatorID,SCDactiveflag,LovRecordSourceId)pind2
				           ON  pind.productID=pind2.productId
				           AND pind.LovRecordSourceId=pind2.LovRecordSourceId
						   AND pind.LOVIndicatorID=pind2.LOVIndicatorID
						   AND pind.SCDactiveflag=pind2.SCDactiveflag
						   AND pind.SCDVersion!=pind2.SCDVersion
				WHERE pind.LovRecordSourceId=@mdm_record_sourceID aND
				pind.SCDActiveFlag='Y' AND   pind.SCDEndDate =convert (datetime,@SCDEndDate) 
				AND pind.etlrunlogid not in (@serveETLRunLogID)

				PRINT 'Info: ProductIndicator Table Loaded Successfully ';    
						
						/* 4.Table Name  :ProductIdentifier*/

				 PRINT 'Info: ProductIdentifier Table Serve Loading Started';  

				 INSERT INTO ser.ProductIdentifier(
																		ProductId           ,
																		LOVIdentifierId     ,
																		Value               ,
																		LOVRecordSourceId   ,
																		SCDStartDate        ,
																		SCDEndDate          ,
																		SCDActiveFlag       ,     
																		SCDVersion          ,
																		SCDLOVRecordSourceId,
																		ETLRunLogId,
																		PSARowKey)
			
								SELECT
									p.ProductId  ProductId,					
									(SELECT r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'EAN' and r.LOVSetId = (SELECT rs.LOVSetId FROM ser.RefLOVSet rs  WHERE rs.LOVSetName = 'Identifier')) LOVIdentifierId ,
									mdmi.ean as Value,
									mdmi.record_source_Id  LOVRecordSourceId,
									(CASE WHEN pIdf.SCDStartDate is null THEN CONVERT (Datetime,@SCDDefaultStartDate)
									ELSE CONVERT (Datetime,@SCDStartDate)
									END) as SCDStartDate,
									CONVERT (datetime,@SCDEndDate) SCDEndDate,
									LEAD('N', 1, 'Y') OVER(PARTITION BY mdmi.item_code,mdmi.record_source_Id  ORDER BY mdmi.item_code,mdmi.record_source_Id ASC) SCDActiveFlag,				
									(CASE WHEN pIdf.SCDVersion is null THEN 1
												 ELSE pIdf.SCDVersion+1 	END) as SCDVersion,
									@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
									@serveETLRunLogID ETLRunLogId,
									mdmi.row_id PSARowKey
									FROM psa.rawuk_btc_mdm_item  mdmi 
									JOIN ser.Product p ON p.SourceKey = mdmi.item_code AND
														p.LovRecordSourceID = mdmi.record_source_Id AND p.SCDActiveFlag='Y'
									LEFT JOIN ser.ProductIdentifier pIdf ON p.ProductId=pIdf.ProductId AND
																			p.LovRecordSourceID=pIdf.LovRecordSourceID 															
									WHERE mdmi.ean is not null and mdmi.ean !=''and 
										mdmi.row_status=@row_status
										AND ISNULL(pIdf.SCDActiveFlag,'Y')='Y'
										AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','))
										;	 

					 --Update the active flag and end date for older version
					PRINT 'Info: ProductIdentifier Table -> Closing off old Records if exists';

					UPDATE ser.ProductIdentifier set SCDActiveFlag='N',SCDEndDate =DATEADD(second,-1,@SCDStartDate)
					 FROM ser.ProductIdentifier pIdf 
						  JOIN 
						 (SELECT   productId,LOVIdentifierId,SCDactiveflag,max(SCDVersion) SCDVersion,LovRecordSourceId from ser.ProductIdentifier
									Where SCDactiveflag='Y' group by productId,LOVIdentifierId,SCDactiveflag,LovRecordSourceId)pIdf2
							   ON  pIdf.productID=pIdf2.productId
							   AND pIdf.LovRecordSourceId=pIdf2.LovRecordSourceId
							   AND pIdf.LOVIdentifierId=pIdf2.LOVIdentifierId
							   AND pIdf.SCDactiveflag=pIdf2.SCDactiveflag
							   AND pIdf.SCDVersion!=pIdf2.SCDVersion
					WHERE pIdf.LovRecordSourceId=@mdm_record_sourceID aND
					pIdf.SCDActiveFlag='Y' AND   pIdf.SCDEndDate =convert (datetime,@SCDEndDate) 
					AND pIdf.etlrunlogid not in (@serveETLRunLogID)

						PRINT 'Info: ProductIdentifier Table Loaded Successfully';  	
					
					/*5.Table Name: ProductStatus*/
					PRINT 'Info: ProductStatus Table Serve Loading Started';  
						
					INSERT INTO ser.ProductStatus (
																			ProductId,           
																			LOVStatusId,
																			LOVProductStatusSetId,
																			EffectiveFrom,        
																			EffectiveTo, 
																			LOVRecordSourceId,
																			SCDStartDate,         
																			SCDEndDate,           
																			SCDActiveFlag,        
																			SCDVersion,           
																			SCDLOVRecordSourceId, 
																			ETLRunLogId,
																			PSARowKey) 
								SELECT  psTemp.ProductId,
										psTemp.LOVStatusId,
										psTemp.LOVProductStatusSetId,
										psTemp.EffectiveFrom,
										psTemp.EffectiveTo,
										psTemp.LOVRecordSourceId,
										(CASE WHEN ps.SCDStartDate is null THEN CONVERT (Datetime,@SCDDefaultStartDate)
										ELSE CONVERT (Datetime,@SCDStartDate)
										END) as SCDStartDate,
										CONVERT (datetime,@SCDEndDate) SCDEndDate,
										LEAD('N', 1, 'Y') OVER(PARTITION BY psTemp.ProductId,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId  ORDER BY psTemp.ProductId,psTemp.LOVStatusId,psTemp.LOVProductStatusSetId,psTemp.LOVRecordSourceId ASC) SCDActiveFlag,				
										(CASE When ps.SCDVersion is null then 1
																	 ELSE ps.SCDVersion+1 	END) as SCDVersion,
										psTemp.SCDLOVRecordSourceId,
										psTemp.ETLRunLogId,
										psTemp.PSARowKey
									FROM
											(SELECT ProductId,
													(CASE   WHEN PSCol ='status_from_date_val' THEN LOVStatusId
															WHEN PSCol ='item_introduction_date_val' THEN LovStatusIDI
															WHEN PSCol ='item_deletion_date_val' THEN LovStatusIDD
													  END )  LOVStatusId,
													  (CASE   WHEN PSCol ='status_from_date_val' THEN @LOVProductStatusSetIdRSC
															  WHEN PSCol ='item_introduction_date_val' THEN @LOVProductStatusSetId
															  WHEN PSCol ='item_deletion_date_val' THEN @LOVProductStatusSetId
													  END )  LOVProductStatusSetId,
													PSValue EffectiveFrom,
													null EffectiveTo,
													LOVRecordSourceId,        
													@SCDLOVRecordSourceId SCDLOVRecordSourceId,
													ETLRunLogId,
													PSARowKey
												FROM
													(  Select p.ProductId,
															(SELECT r.LovID from ser.RefLOV r where 
															r.LOVKey = mdmi.retail_status_code
															AND 
															LovSetId = (SELECT rs.LovSetID from ser.RefLOVSet rs
															where LOVSetName = 'retail_status_code'
															and rs.LOVSetRecordSourceID = mdmi.record_source_id)) LOVStatusId,
															@LovStatusIDD LovStatusIDD,
															@LovStatusIDI  LovStatusIDI,
															(CASE WHEN ISDATE(concat(mdmi.status_from_date,' ', mdmi.status_from_time)) = 1 THEN convert(datetime, concat(mdmi.status_from_date,' ', mdmi.status_from_time),120) ELSE NULL END) status_from_date_val,
															(CASE WHEN ISDATE(mdmi.item_introduction_date) = 1 THEN convert(datetime,mdmi.item_introduction_date)  ELSE NULL END) item_introduction_date_val,
															(CASE WHEN  ISDATE(mdmi.item_deletion_date) = 1 THEN convert(DateTime,mdmi.item_deletion_date) ELSE NULL END) item_deletion_date_val,
															mdmi.record_source_Id  LOVRecordSourceId,
															@serveETLRunLogID ETLRunLogId,
															mdmi.row_id PSARowKey
													FROM [psa].[rawuk_btc_mdm_item] mdmi 	
													INNER JOIN ser.Product p
																		ON p.SourceKey = mdmi.item_code AND
																			p.LovRecordSourceID = mdmi.record_source_id
																			AND p.SCDActiveFlag='Y'
																		WHERE mdmi.retail_status_code is not null and  mdmi.retail_status_code!=''
																				AND mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','))
																				AND mdmi.row_status=@row_status) ps
																		UNPIVOT  
													( PSValue FOR PSCol IN (status_from_date_val,
																			item_introduction_date_val,
																			item_deletion_date_val)
													)	AS PSl ) as psTemp
													LEFT JOIN ser.ProductStatus ps
													ON psTemp.productid=ps.productid
													AND psTemp.LOVStatusId=ps.LOVStatusId
													AND psTemp.LOVStatusId=ps.LOVStatusId
													AND psTemp.LOVProductStatusSetId=ps.LOVProductStatusSetId								
													AND psTemp.LOVRecordSourceId=ps.LOVRecordSourceId
												WHERE psTemp.EffectiveFrom is not null and psTemp.EffectiveFrom !='' AND
												ISNULL (ps.SCDActiveFlag,'Y') ='Y'; 
					 --Update the active flag and end date for older version
					  PRINT 'Info: ProductStatus Table ->Closing off old Records if exists';

					 UPDATE ser.ProductStatus set SCDActiveFlag='N',SCDEndDate =DATEADD(second,-1,@SCDStartDate)
							 FROM ser.ProductStatus ps 
								  JOIN 
								 (SELECT   productId,LOVProductStatusSetId,LOVStatusId,SCDactiveflag,max(SCDVersion) SCDVersion,LovRecordSourceId from ser.ProductStatus
											Where SCDactiveflag='Y' group by productId,LOVProductStatusSetId,LOVStatusId,SCDactiveflag,LovRecordSourceId)ps2
									   ON  ps.productID=ps2.productId
									   AND ps.LovRecordSourceId=ps2.LovRecordSourceId
									   AND ps.LOVProductStatusSetId=ps2.LOVProductStatusSetId
									   AND ps.LOVStatusId=ps2.LOVStatusId
									   AND ps.SCDactiveflag=ps2.SCDactiveflag
									   AND ps.SCDVersion!=ps2.SCDVersion
							WHERE ps.LovRecordSourceId=@mdm_record_sourceID aND
							ps.SCDActiveFlag='Y' AND   ps.SCDEndDate =convert (datetime,@SCDEndDate) 
							AND ps.etlrunlogid not in (@serveETLRunLogID)

					PRINT 'Info: ProductStatus Table Loaded Successfully';
	
	
					/* 6.Table Name : Party*/  
					PRINT 'Info: Party Table Serve Loading Started';  

					INSERT INTO ser.Party(
						PartyId            ,
						LOVPartyTypeId     ,
						SourceKey          ,
						LOVRecordSourceId  ,
						SCDStartDate        ,
						SCDEndDate          ,
						SCDActiveFlag       ,
						SCDVersion          ,
						SCDLOVRecordSourceId,
						ETLRunLogId,
						PSARowKey)
					
					SELECT  ROW_NUMBER() OVER(ORDER BY SourceKey,LOVRecordSourceId ASC)+@max_PartyId PartyId,
							LOVPartyTypeId, 
							SourceKey,
							LOVRecordSourceId,
							CONVERT (datetime,@SCDDefaultStartDate) as SCDStartDate,
							CONVERT (datetime,@SCDEndDate) SCDEndDate,
							@SCDActiveFlag     SCDActiveFlag ,
							@SCDVersion  SCDVersion ,
							@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
							ETLRunLogId,
							PSARowKey
						FROM
						(
						SELECT DISTINCT
								@PartyType_Id LOVPartyTypeId,
								mdmi.vendor_number  as SourceKey,
								mdmi.record_source_id as LOVRecordSourceId,
								@serveETLRunLogID  as ETLRunLogId,
								Min(mdmi.row_id) PSARowKey
						FROM psa.rawuk_btc_mdm_item mdmi
							WHERE mdmi.row_status=@row_status and mdmi.vendor_number is not null and mdmi.vendor_number!=''
								AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','))
							GROUP BY mdmi.vendor_number,mdmi.record_source_id		)  party                        
						WHERE not exists  (select 1 from ser.party pr where pr.SourceKey =party.SourceKey and party.LOVRecordSourceId =pr.LOVRecordSourceId  )
	
	
							PRINT 'Info: Party Table Loaded Successfully' ;   
							
						
					/*7.Table Name: Organisation*/ 

					PRINT 'Info: Organisation Table Serve Loading Started';					
					
					INSERT INTO ser.Organisation(
												PartyId            ,
												SourceOrganisationKey  ,
												OrganisationName    ,
												ParentPartyId       ,
												LOVRecordSourceId	,
												SCDStartDate        ,
												SCDEndDate          ,
												SCDActiveFlag       ,
												SCDVersion          ,
												SCDLOVRecordSourceId,
												ETLRunLogId,
												PSARowKey)
					SELECT  
						PartyId                ,
						SourceOrganisationKey  ,
						OrganisationName       ,
						ParentPartyId,
						LOVRecordSourceId,
						CONVERT (datetime,@SCDDefaultStartDate) as SCDStartDate,
						CONVERT (datetime,@SCDEndDate) SCDEndDate,
						@SCDActiveFlag    SCDActiveFlag      ,
						@SCDVersion   SCDVersion          ,
						@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
						ETLRunLogId,
						PSARowKey
					FROM 
					(SELECT DISTINCT
								pt.PartyId as  PartyId,
								mdmi.vendor_number  as SourceOrganisationKey,
								null OrganisationName,
								null ParentPartyId,
								mdmi.record_source_Id  LOVRecordSourceId,
								@serveETLRunLogID ETLRunLogId,
								MIN(mdmi.row_id) PSARowKey
						FROM psa.rawuk_btc_mdm_item mdmi  
								JOIN  ser.Party pt  ON pt.sourcekey= mdmi.vendor_number AND
													pt.LOVRecordSourceID=mdmi.record_source_id
						WHERE mdmi.row_status=@row_status and 	mdmi.vendor_number is not null and mdmi.vendor_number!=''	
						AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','))
						GROUP BY mdmi.vendor_number,mdmi.record_source_Id,pt.PartyId
						)  org
						WHERE  not exists(select 1 from ser.Organisation o where o.SourceOrganisationKey =org.SourceOrganisationKey and o.LOVRecordSourceId =org.LOVRecordSourceId );
						
						PRINT 'Info: Organisation Table Loaded Successfully'; 
						
													
					/* 8.TableNmame : Party Role */  
					
					PRINT 'Info: PartyRole Table Serve Loading Started'; 
					
					INSERT INTO ser.PartyRole(
												PartyRoleId          ,
												LOVRoleId            ,
												PartyId             ,
												SourceKey            ,
												PartyRoleName        ,
												LOVRecordSourceId    ,
												SCDStartDate        ,
												SCDEndDate          ,
												SCDActiveFlag       ,
												SCDVersion          ,
												SCDLOVRecordSourceId,
												ETLRunLogId ,
												PSARowKey) 
						SELECT ROW_NUMBER() OVER(ORDER BY  PartyId,LOVRoleId ASC)+@max_partyrole_id PartyRoleId,
						LOVRoleId,
						PartyId,
						SourceKey,
						PartyRoleName,
						LOVRecordSourceId,
						CONVERT (datetime,@SCDDefaultStartDate) as SCDStartDate,
						CONVERT (datetime,@SCDEndDate) SCDEndDate,
						@SCDActiveFlag     SCDActiveFlag      ,
						@SCDVersion   SCDVersion          ,
						@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
						ETLRunLogId,
						PSARowKey
					FROM 
						(
						SELECT DISTINCT
						@LOVRoleIDS LOVRoleId,
						pt.PartyId  PartyId,
						mdmi.vendor_number  as SourceKey,
						null PartyRoleName,
						mdmi.Record_Source_id LOVREcordSourceID,
						@serveETLRunLogID ETLRunLogId,
						Min(mdmi.row_id) PSARowKey
						FROM psa.rawuk_btc_mdm_item mdmi
								LEFT JOIN  ser.Party pt ON mdmi.vendor_number = pt.SourceKey								 
						AND mdmi.record_source_id =pt.LOVRecordSourceId 
						WHERE mdmi.row_status=@row_status and 	mdmi.vendor_number is not null and mdmi.vendor_number!=''
						AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','))
						GROUP BY 	mdmi.vendor_number,mdmi.record_source_Id,pt.PartyId) t
						WHERE NOT EXISTS ( select 1 from ser.PartyRole pr where pr.SourceKey =t.SourceKey and pr.LOVRecordSourceId =t.LOVRecordSourceId )  ;
					
					
					PRINT 'Info: PartyRole Table Loaded Successfully';  
					
					/*9.Table Name: ProductPartyRole*/
	
									
					PRINT 'Info: ProductPartyRole Table Serve Loading Started'; 
					PRINT 'Info: ProductPartyRole Loading Retailer data'; 
					INSERT INTO ser.ProductPartyRole(
												ProductId,           
												PartyRoleId,
												LOVRecordSourceId,
												SCDStartDate,        
												SCDEndDate,          
												SCDActiveFlag,       
												SCDVersion,          
												SCDLOVRecordSourceId,
												ETLRunLogId,
												PSARowKey
					
					)
					SELECT
						p.ProductId ProductId,
						pr.PartyRoleId PartyRoleId ,
						mdmi.record_source_Id  LOVRecordSourceId,
						(CASE WHEN ppr.SCDStartDate is null THEN CONVERT (Datetime,@SCDDefaultStartDate)
						ELSE CONVERT (Datetime,@SCDStartDate)
						END) as SCDStartDate,
						CONVERT (datetime,@SCDEndDate) SCDEndDate,
						LEAD('N', 1, 'Y') OVER(PARTITION BY mdmi.item_code,mdmi.record_source_id,pr.LOVRoleId ORDER BY mdmi.item_code ASC) SCDActiveFlag,				
						(CASE When ppr.SCDVersion is null then 1
								ELSE 
									ppr.SCDVersion+1 
							END) SCDVersion,
						@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
						@serveETLRunLogID ETLRunLogId,
						mdmi.row_id PSARowKey
						FROM [psa].[rawuk_btc_mdm_item] mdmi 
						JOIN ser.Product p ON p.SourceKey = mdmi.item_code AND										
											p.LovRecordSourceID = mdmi.record_source_id
											AND p.SCDActiveFlag='Y'							
						JOIN ser.PartyRole pr	ON  p.LovRecordSourceID=pr.LovRecordSourceID
													  AND pr.SourceKey ='WBA-UK-BTC'
													  AND pr.SCDActiveFlag = 'Y'
													  AND pr.LOVRoleId = (select  rl.LOVId LOVId FROM
														ser.RefLov rl
														join ser.RefLovSet rls
														on rl.LOVSETId=rls.LOVSetID
														AND rl.LOVKey ='Retailer'
														where rls.LOVSetName  ='Role' )
						LEFT JOIN ser.ProductPartyRole ppr ON ppr.ProductId=p.ProductId AND
														 ppr.LovRecordSourceID=p.LovRecordSourceID AND
														 ppr.PartyRoleId= pr.PartyRoleId																			 
						WHERE mdmi.row_status=@row_status
						AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','))
						AND ISNULL (ppr.SCDActiveFlag,'Y') ='Y' ;		    
						

						PRINT 'Info: ProductPartyRole Loading Supplier data'; 
						INSERT INTO ser.ProductPartyRole(
													ProductId,           
													PartyRoleId,
													LOVRecordSourceId,
													SCDStartDate,        
													SCDEndDate,          
													SCDActiveFlag,       
													SCDVersion,          
													SCDLOVRecordSourceId,
													ETLRunLogId,
													PSARowKey
					
						)
						SELECT
							p.ProductId ProductId,
							pr.PartyRoleId PartyRoleId,
							mdmi.record_source_Id  LOVRecordSourceId,
							(CASE WHEN t.SCDStartDate is null THEN CONVERT (Datetime,@SCDDefaultStartDate)
								  ELSE CONVERT (Datetime,@SCDStartDate)
							END) as SCDStartDate,
							CONVERT (datetime,@SCDEndDate) SCDEndDate,
							LEAD('N', 1, 'Y') OVER(PARTITION BY mdmi.item_code,mdmi.record_source_id,pr.LOVRoleId ORDER BY mdmi.item_code ASC) SCDActiveFlag,				
							(CASE When t.SCDVersion is null then 1
								ELSE
								 t.SCDVersion+1 
							 END) SCDVersion,
							@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
							@serveETLRunLogID ETLRunLogId,
							mdmi.row_id PSARowKey
							FROM [psa].[rawuk_btc_mdm_item] mdmi    
							JOIN ser.Product p ON p.SourceKey = mdmi.item_code AND										
												p.LovRecordSourceID = mdmi.record_source_id
												AND p.SCDActiveFlag='Y'																				
							JOIN ser.PartyRole pr	ON	mdmi.vendor_number=pr.sourceKey
														  AND p.LovRecordSourceID=pr.LovRecordSourceID
														  AND pr.SCDActiveFlag = 'Y'							
							LEFT JOIN (SELECT pPRole.ProductId,pPRole.SCDStartDate,pPRole.LOVRecordSourceId,pPRole.SCDVersion,pRole.LOVRoleId FROM ser.ProductPartyRole pPRole 
										JOIN ser.PartyRole pRole
										ON pPRole.LOVRecordSourceId = pRole.LOVRecordSourceId
										AND pPRole.PartyRoleId = pRole.PartyRoleId
										AND pRole.LOVRoleId = (select  rl.LOVId LOVId FROM
										ser.RefLov rl
										join ser.RefLovSet rls
										on rl.LOVSETId=rls.LOVSetID
										AND rl.LOVKey ='Supplier'
										where rls.LOVSetName  ='Role')
										AND ISNULL(pPRole.SCDActiveFlag,'Y')='Y')t
						    ON t.ProductId=p.ProductId AND
							t.LovRecordSourceID=p.LovRecordSourceID 
							AND t.LOVRoleId = pr.LOVRoleId
							WHERE mdmi.row_status=@row_status and 	mdmi.vendor_number is not null and mdmi.vendor_number!=''
							AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','));

												
					 --Update the active flag and end-date for older version

					 PRINT 'Info: ProductPartyRole Table -> Closing off old Records if exists';

					 UPDATE ser.ProductPartyRole set SCDActiveFlag='N',SCDEndDate =DATEADD(second,-1,@SCDStartDate)
							 FROM ser.ProductPartyRole ppr 
								  JOIN 
								 (SELECT   ppr.productId,ppr.PartyRoleId,ppr.SCDactiveflag,pr.LOVRoleId,max(ppr.SCDVersion) SCDVersion,ppr.LovRecordSourceId from 
										  ser.ProductPartyRole ppr,ser.PartyRole pr
											Where ppr.SCDactiveflag='Y'
											and ppr.LovRecordSourceId=pr.LovRecordSourceId
											and ppr.PartyRoleId=pr.PartyRoleId
											group by ppr.productId,ppr.PartyRoleId,ppr.SCDactiveflag,pr.LOVRoleId,ppr.LovRecordSourceId)ppr2
									   ON  ppr.productID=ppr2.productId
									   AND ppr.LovRecordSourceId=ppr2.LovRecordSourceId									   
									   AND ppr.SCDactiveflag=ppr2.SCDactiveflag
									   AND ppr.SCDVersion!=ppr2.SCDVersion
							WHERE ppr.LovRecordSourceId=@mdm_record_sourceID aND
							ppr.SCDActiveFlag='Y' AND   ppr.SCDEndDate =convert (datetime,@SCDEndDate) 
							AND ppr.etlrunlogid not in (@serveETLRunLogID)					 
					
					PRINT 'Info: ProductPartyRole Table Loaded Successfully';  		
					
					/*Update the psa layer table with row_status as 'Loaded to Serve' once after Successful Migration*/
	
								UPDATE psa.rawuk_btc_mdm_item SET row_status=@row_status_final
								FROM psa.rawuk_btc_mdm_item mdmi 
											Inner Join
											ser.Product p 
												ON mdmi.item_code =p.sourcekey
												 AND  mdmi.record_source_id=p.LovRecordSourceID
												 AND mdmi.row_id=p.PSARowKey												
												WHERE mdmi.row_status=@row_status
													AND  mdmi.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ',')) 
													AND p.etlrunlogid in (@serveETLRunLogID) ;
	
					PRINT 'Info: updated Row_status in Source Table -> rawuk_btc_mdm_item';
					PRINT '********Info: MDM Product PSA to Serve Load Completed Successfully********';
	                SET  @flag =0;	
					COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH 
					  THROW;
			          SET  @flag =-1
					  ROLLBACK TRANSACTION ;						
			END CATCH
	--SELECT @flag as 'Status'
	END
GO
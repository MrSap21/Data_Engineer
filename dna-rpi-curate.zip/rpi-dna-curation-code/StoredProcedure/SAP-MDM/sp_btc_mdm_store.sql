/****** Object:  StoredProcedure [psa].[sp_btc_mdm_store]    Script Date: 02/07/2020 20:27:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('psa.sp_btc_mdm_store') IS NOT NULL
BEGIN
    DROP PROC psa.sp_btc_mdm_store 
    
END
/****** Object:  StoredProcedure [psa].[sp_btc_mdm_store]    Script Date: 08/07/2020 10:36:28 ******/
/****** Object:  StoredProcedure [psa].[sp_btc_mdm_store]    Script Date: 29/07/2020 15:01:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_btc_mdm_store]    Script Date: 30/07/2020 10:57:42 ******/
CREATE PROC [psa].[sp_btc_mdm_store] @psaETLRunLogID [varchar](MAX),@serveETLRunLogID [varchar](MAX),@tableName [varchar](200) AS
/*
************************************************************************************************************************************************************************
Procedure Name				: sp_btc_mdm_store
Purpose						: Load History data From MDM Store from psa layer(mdm store) into Serve Layer Table
Domain						: Store
ServeLayer Target Tables	: PostalAddress,Site,SiteRole,Party,Organisation,PartyRole,PartyRoleSiteRoleRelationship,SiteRoleContactMethod,SiteRoleTerritory,
                              SiteRoleGroup,SiteRoleIndicator,SiteRoleStatus,SiteRoleProperty ,SiteProperty(Total 15 Tables)
RecordSourceID for MDM      : 12008  , 12012(PostalAddress,Site)
*************************************************************************************************************************************************************************
SCD Columns and Concept (latest data is inserted with respect SCD)
************************************************************************************************************************************************************************
***HISTORY/HISTORY CATCH UP NEW RECORDS******
				SiteRoleId			: max(SiteRoleId)+1
				SCDStartDate        :  '1900-01-01 00:00:00'
				SCDEndDate          :  '9999-12-31 00:00:00'
				SCDActiveFlag       :  'Y'   
				SCDVersion          :   1 (Min version for new records) 
				SCDLOVRecordSourceId:  151 
				serveETLRunLogId    : RunlogID from api passing as a parameter
*******HISTORY CATCH UP Existing Records*******
				productId			: same productid as exisitng records
				SCDStartDate        :  (NO CHNAGE)
				SCDEndDate          :  SCDStartdate of new record minus 1 second with same productid
				SCDActiveFlag       :  'N'   
				SCDVersion          :  Increment exisitng version by 1 for that SiteRole id
				SCDLOVRecordSourceId:  151 
				serveETLRunLogId    : RunlogID from api passing asa parameter

*************************************************************************************************************************************************************************
Modification History
*************************************************************************************************************************************************************************
29-June-2020  : Incorporated v2.4 mapping changes    */ 
--drop temp table if exists
IF OBJECT_ID('ser.PostalAddress_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PostalAddress_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.PostalAddress_SiteProperty_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PostalAddress_SiteProperty_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleGrp_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleGrp_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.PartyRoleSiteRoleRelationship_STG') IS NOT NULL
BEGIN
DROP TABLE ser.PartyRoleSiteRoleRelationship_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleContactMethod_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleContactMethod_STG;
END

--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleTerritory_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleTerritory_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleStatus_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleStatus_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleProperty_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleProperty_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.SiteProperty_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteProperty_STG;
END
--drop temp table if exists
IF OBJECT_ID('ser.SiteRoleIndicator_STG') IS NOT NULL
BEGIN
DROP TABLE ser.SiteRoleIndicator_STG;
END
----------------------------------------------creating temp tables------------------------------------------------------
Print 'Info: Creating all necessary Temp Tables ';
CREATE TABLE [ser].[SiteRoleGrp_STG](
    [ExistsFlag]             int         NULL,
    [SiteRoleGroupId]        bigint      NULL,
    [SiteRoleId]             bigint      NOT NULL,
    [LOVSiteRoleGroupSetId]  int         NULL,
    [LOVGroupId]             int         NULL,
    [ParentSiteRoleGroupId]  bigint      NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          nchar(1)    NULL,
    [SCDVersion]             smallint    NULL,
    [SCDLOVRecordSourceId]   int         NULL,
    [ETLRunLogId]            int         NULL,
    [row_id]                 bigint      NULL 
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVSiteRoleGroupSetId],[LOVGroupId],[LOVRecordSourceId])
)

---Temp Table
CREATE TABLE ser.[PartyRoleSiteRoleRelationship_STG](
    [ExistsFlag] int null,
    [PartyRoleId]            bigint       NULL,
    [SiteRoleId]             bigint       NULL,
    [LOVRelationshipTypeId]  int          NULL,
    [EffectiveFrom]          datetime    NULL,
    [EffectiveTo]            datetime    NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          nchar(1)    NULL,
    [SCDVersion]             smallint    NULL,
    [SCDLOVRecordSourceId]   int         NULL,
    [ETLRunLogId]            int         NULL,
    [row_id]                 bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([PartyRoleId],[SiteRoleId],[LOVRelationshipTypeId],[LOVRecordSourceId])
)

--temp table
CREATE TABLE ser.[SiteRoleContactMethod_STG](
    [ExistsFlag] int null,
    [SiteRoleId]              bigint            NULL,
    [LOVContactMethodTypeId]  int               NULL,
    [LOVUsageTypeId]          int               NULL,
    [ContactDetail]           nvarchar(255)    NULL,
    [LOVRecordSourceId]       int              NULL,
    [SCDStartDate]            datetime         NULL,
    [SCDEndDate]              datetime         NULL,
    [SCDActiveFlag]           nchar(1)         NULL,
    [SCDVersion]              smallint         NULL,
    [SCDLOVRecordSourceId]    int              NULL,
    [ETLRunLogId]             int              NULL,
    [row_id]               bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVContactMethodTypeId],[LOVUsageTypeId],[LOVRecordSourceId])
)
--temp table 
CREATE TABLE ser.[SiteRoleTerritory_STG](
     [ExistsFlag] int null,
    [SiteRoleId]                 bigint       NULL,
    [LOVSiteRoleTerritorySetId]  int          NULL,
    [LOVTerritoryId]             int          NULL,
    [LOVRecordSourceId]          int          NULL,
    [SCDStartDate]               datetime    NULL,
    [SCDEndDate]                 datetime    NULL,
    [SCDActiveFlag]              nchar(1)    NULL,
    [SCDVersion]                 smallint    NULL,
    [SCDLOVRecordSourceId]       int         NULL,
    [ETLRunLogId]                int         NULL,
    [row_id]                  bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVTerritoryId],[LOVRecordSourceId])
)

--temp table
CREATE TABLE [ser].[SiteRoleStatus_STG](
    [ExistsFlag] int null,
    [SiteRoleId]              bigint       NULL,
    [LOVSiteRoleStatusSetId]  int          NULL,
    [LOVStatusId]             int          NULL,
    [EffectiveFrom]           datetime    NULL,
    [EffectiveTo]             datetime    NULL,
    [LOVRecordSourceId]       int         NOT NULL,
    [SCDStartDate]            datetime    NULL,
    [SCDEndDate]              datetime    NULL,
    [SCDActiveFlag]           nchar(1)    NULL,
    [SCDVersion]              smallint    NULL,
    [SCDLOVRecordSourceId]    int         NULL,
    [ETLRunLogId]             int         NULL,
    [row_id]               bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVStatusId],[LOVRecordSourceId])
)
--temp
CREATE TABLE [ser].[SiteRoleProperty_STG](
        [ExistsFlag] int null,
    [SiteRoleId]            bigint            NULL,
    [MeasureId]             int               NULL,
    [LOVUOMId]              int               NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  bigint           NULL,
    [ETLRunLogId]           int              NULL,
    [row_id]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVUOMId],[LOVRecordSourceId])
)
--temp table
CREATE TABLE [ser].[SiteProperty_STG](
	[ExistsFlag] int null,
    [SiteId]                bigint            NULL,
    [MeasureId]             int               NULL,
    [LOVUOMId]              int               NULL,
    [Value]                 nvarchar(255)    NULL,
    [LOVRecordSourceId]     int              NOT NULL,
    [SCDStartDate]          datetime         NULL,
    [SCDEndDate]            datetime         NULL,
    [SCDActiveFlag]         nchar(1)         NULL,
    [SCDVersion]            smallint         NULL,
    [SCDLOVRecordSourceId]  bigint           NULL,
    [ETLRunLogId]           int              NULL,
    [row_id]             bigint           NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteId],[LOVUOMId],[LOVRecordSourceId])
)
--temp table
 CREATE TABLE [ser].[SiteRoleIndicator_STG](
    [ExistsFlag] int null,		 
    [SiteRoleId]            bigint       NULL,
    [LOVIndicatorId]        int          NULL,
    [Value]                 nchar(1)    NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         nchar(1)    NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,
    [ETLRunLogId]           int         NULL,
    [row_id]             bigint      NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([SiteRoleId],[LOVRecordSourceId])
)
--temp table
CREATE TABLE [ser].[PostalAddress_STG](
    [SiteId]                bigint          NULL,
    [LocationName]          nvarchar(80)    NULL,
    [AddressLine1]          nvarchar(80)    NULL,
    [AddressLine2]          nvarchar(80)    NULL,
    [Town]                  nvarchar(80)    NULL,
    [County]                nvarchar(80)    NULL,
    [PostalCode]            nvarchar(10)    NULL,
	[z_grid_reference_northing]              nvarchar(255)    NULL,
	[z_grid_reference_easting]               nvarchar(255)    NULL,
	[z_grid_reference_latitude]              nvarchar(255)    NULL,
	[z_grid_reference_longitude]              nvarchar(255)   NULL
    )
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([SiteId])
)

--temp table
CREATE TABLE [ser].[PostalAddress_SiteProperty_STG](
    [SiteId]                bigint          NULL,
    [AddressLine1]          nvarchar(80)    NULL,
    [AddressLine2]          nvarchar(80)    NULL,
    [Town]                  nvarchar(80)    NULL,
    [County]                nvarchar(80)    NULL,
    [PostalCode]            nvarchar(10)    NULL,
	[z_grid_reference_northing]              nvarchar(255)    NULL,
	[z_grid_reference_easting]               nvarchar(255)    NULL,
	[z_grid_reference_latitude]              nvarchar(255)    NULL,
	[z_grid_reference_longitude]              nvarchar(255)   NULL,
	[LOVCountryId]              int Null,
	[EtlRunlogId]               int null,
	[PsaRowKey] bigint null
    )
WITH
(
    DISTRIBUTION = REPLICATE,
    CLUSTERED COLUMNSTORE INDEX ORDER ([SiteId])
)

Print 'Info: All necessary Temp Tables created Successfully';
/*-------DECLARE Variables-------*/
DECLARE @website_type_id int,
@physical_store_type_id int,
@role_id int,
--@party_type_id int ,
@record_source_id int,
@site_role_status_id int,
@party_relationship_type int,
@max_siteId int,
@max_partyId int,
@max_site_role_id int ,
@max_party_id int,
@max_party_role_id int,
@max_measure_id int,
@MAXSRGpID int,
@max_siterole_group_id int,
@PostalLOVRecordSourceId int,
@maxpostalsite_id int,
@row_status int =26001,
@serRowStatus int =26002,
--@SCDClosingEndDate datetime= current_timestamp ,
@SCDStartDate datetime= current_timestamp,
@SCDStartDate_new datetime=CONVERT(DATETIME,'19000101'),
@SCDEndDate datetime=CONVERT(DATETIME,'99991231'),
@SCDLOVRecordSourceId Varchar(100)= '151',
@PartyTypeId int,
@MAXPartyId int,
@role_id_partyrole_sorg int,
@role_id_partyrole int,
@role_id_partyrole_health int,
@MAXPartyRoleId int,
@party_relationship_type_of int,
@party_relationship_type_aw int,
@contact_method_type_id int,
@usage_type_id int,
@setid_area_number int ,
@setid_nhs_market int ,
@OpenStatus int, 
@LOVSiteRoleStatusSetId_status int,
@LOVSiteRoleStatusSetId_floor int,
@LOVSiteRoleStatusSetId_nonf_ifl int,
@LOVSiteRoleStatusSetId_pharmacy int,
@uom_idm2 int,
@uom_idunit int,
@uom_id_degree int,
@uom_id_m int,
@data_type_id int,
@data_type_double_id int,
@data_type_int_id int,
@measure_type_id int,
@measure_type_geocode_id int,
@easting_measureId int,
@northing_measureId int,
@latitude_measureId int,
@longitude_measureId int

BEGIN
BEGIN TRANSACTION;


SET @PostalLOVRecordSourceId=12012
SET @record_source_id =12008

/*-------Set the MAX value of surrogate Keys to particular Variables-------*/
SELECT @max_siteId= COALESCE((SELECT MAX(SiteId) FROM  ser.Site),0)

SELECT @maxpostalsite_id=COALESCE((SELECT MAX(SiteId) FROM  ser.PostalAddress),0)

SELECT @max_site_role_id=COALESCE((SELECT MAX(SiteRoleId) FROM  ser.SiteRole),0)

SELECT @max_siterole_group_id=COALESCE((SELECT MAX(SiteRoleGroupId) FROM  ser.SiteRoleGroup),0)

/*-------Derive the lookup table constant values and Set to Variables-------*/
SELECT @website_type_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='WEBSITE' and rls.LOVSetName='Site Type'

SELECT @physical_store_type_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='POSTAL ADDRESS' and rls.LOVSetName='Site Type'


SELECT @role_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='Store' and rls.LOVSetName='Role'

SELECT @data_type_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='STRING' and rls.LOVSetName='Data Type' 

SELECT @measure_type_geocode_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='GEOCODE' and rls.LOVSetName='Measure Type' 

SELECT @data_type_double_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='DOUBLE' and rls.LOVSetName='Data Type'

SELECT @data_type_int_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='INT' and rls.LOVSetName='Data Type' 
SELECT @measure_type_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='FLOOR_AREA' and rls.LOVSetName='Measure Type' 

SELECT @longitude_measureId= MeasureId from ser.Measure where MeasureName = 'z_grid_reference_longitude' AND LOVRecordSourceId = @record_source_id 
and LOVDatatypeId = @data_type_double_id and LovMeasureTypeId = @measure_type_geocode_id

SELECT  @latitude_measureId=MeasureId from ser.Measure where MeasureName = 'z_grid_reference_latitude' AND LOVRecordSourceId = @record_source_id 
and LOVDatatypeId = @data_type_double_id and LovMeasureTypeId = @measure_type_geocode_id


SELECT  @easting_measureId=MeasureId from ser.Measure where MeasureName = 'z_grid_reference_easting' AND LOVRecordSourceId = @record_source_id 
and LOVDatatypeId = @data_type_int_id and LovMeasureTypeId = @measure_type_geocode_id

SELECT  @northing_measureId=MeasureId from ser.Measure where MeasureName = 'z_grid_reference_northing' AND LOVRecordSourceId = @record_source_id 
and LOVDatatypeId = @data_type_int_id and LovMeasureTypeId = @measure_type_geocode_id

BEGIN TRY
---------------------------------------Table1-Postal Address----------------------------------------------------------------------------
Print 'Info: PostalAddress Table Load Started ';
--create and load postal address temp table for finding the distinct duplicate records
exec('INSERT INTO [ser].[PostalAddress_STG](SiteId,AddressLine1,AddressLine2, Town, County, PostalCode
,z_grid_reference_longitude ,z_grid_reference_latitude,z_grid_reference_easting,z_grid_reference_northing )
select Postal.SiteId,Postal.AddressLine1,Postal.AddressLine2, Postal.Town, Postal.County, Postal.PostalCode
,SP.z_grid_reference_longitude,SP.z_grid_reference_latitude,SP.z_grid_reference_easting,SP.z_grid_reference_northing
from ser.PostalAddress Postal 
left join 
(select [SiteId] as SiteId,['+@longitude_measureId+'] z_grid_reference_longitude ,['+@latitude_measureId+'] z_grid_reference_latitude,['+@easting_measureId+'] z_grid_reference_easting,['+@northing_measureId+'] z_grid_reference_northing
 FROM (select siteID,MeasureId,Value from ser.SiteProperty) SourceTable
PIVOT ( MAX(Value)
       FOR MeasureId in (['+@longitude_measureId+'],['+@latitude_measureId+'],['+@easting_measureId+'],['+@northing_measureId+'])) PivotTable) SP
on Postal.SiteId=SP.SiteId')

--create and load PostalAddressSitePropertyStaging Table
INSERT INTO ser.PostalAddress_SiteProperty_STG([SiteId],[AddressLine1],[AddressLine2],[Town],[County],[PostalCode],
[z_grid_reference_northing],[z_grid_reference_easting],[z_grid_reference_latitude],[z_grid_reference_longitude],
[LOVCountryId],[EtlRunlogId],[PsaRowKey] ) 
SELECT (COALESCE(@maxpostalsite_id,0) + ROW_NUMBER() OVER(ORDER BY  Ser.AddressLine1, Ser.AddressLine2, Ser.Town, Ser.County, Ser.PostalCode,Ser.z_grid_reference_northing,
Ser.z_grid_reference_easting,Ser.z_grid_reference_latitude,Ser.z_grid_reference_longitude ))SiteId  ,
Ser.AddressLine1, 
Ser.AddressLine2, 
Ser.Town, 
Ser.County, 
Ser.PostalCode,
Ser.z_grid_reference_northing,
Ser.z_grid_reference_easting
,Ser.z_grid_reference_latitude,
Ser.z_grid_reference_longitude,
Ser.LOVCountryId,
@serveETLRunLogID ETLRunLogId,
Ser.row_id
FROM 
(
SELECT Source.AddressLine1,Source.AddressLine2, Source.Town,Source.County, Source.PostalCode,
Source.z_grid_reference_northing,Source.z_grid_reference_easting
,Source.z_grid_reference_latitude,Source.z_grid_reference_longitude,
Source.LOVCountryId,Source.SCDStartDate,Source.ETLRunLogId,Source.row_id
,CASE WHEN  POSTAL.SiteId is NULL THEN  0 ELSE 1  END AS ExistsFlag
FROM ( 
SELECT AddressLine1, AddressLine2,Town,County,PostalCode,z_grid_reference_northing,z_grid_reference_easting
,z_grid_reference_latitude,z_grid_reference_longitude,ETLRunLogId,LOVCountryId,SCDStartDate,min(row_id) row_id FROM
(SELECT  Stage.store_address_line_1  AddressLine1,
Stage.store_address_line_2  AddressLine2,       
Stage.store_town  Town,
Stage.store_county  County,
Stage.postcode  PostalCode,
Stage.z_grid_reference_northing z_grid_reference_northing,
Stage.z_grid_reference_easting z_grid_reference_easting,
Stage.z_grid_reference_latitude z_grid_reference_latitude,
Stage.z_grid_reference_longitude z_grid_reference_longitude,
rl.LOVId LOVCountryId,
@SCDStartDate_new  as SCDStartDate,
Stage.etl_runlog_id ETLRunLogId,
row_id
FROM psa.rawuk_btc_mdm_store Stage 
join ser.RefLOV rl on Stage.country_code=rl.LOVKey 
				 join ser.RefLOVSet rls on rl.LOVSetId=rls.LOVSetId 
				 where rls.LovSetName='Country ISO 3166-2' and Stage.row_status=@row_status AND Stage.etl_runlog_id in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,',')) )P
group by AddressLine1, AddressLine2, Town,County, PostalCode,ETLRunLogId,LOVCountryId,SCDStartDate,
z_grid_reference_northing,z_grid_reference_easting,z_grid_reference_latitude,z_grid_reference_longitude
) Source
LEFT JOIN ser.PostalAddress_STG Postal
ON ISNULL(Source.AddressLine1,'')=ISNULL(POSTAL.AddressLine1,'') AND  
ISNULL(Source.AddressLine2,'') =ISNULL(POSTAL.AddressLine2,'') AND
ISNULL(Source.Town,'')=ISNULL(POSTAL.Town,'') AND
ISNULL(Source.County,'')=ISNULL(POSTAL.County,'') AND   
ISNULL(Source.PostalCode,'')=ISNULL(POSTAL.PostalCode ,'') AND
ISNULL(Source.z_grid_reference_northing,'')=ISNULL(POSTAL.z_grid_reference_northing ,'') AND
ISNULL(Source.z_grid_reference_easting,'')=ISNULL(POSTAL.z_grid_reference_easting ,'') AND
ISNULL(Source.z_grid_reference_latitude,'')=ISNULL(POSTAL.z_grid_reference_latitude ,'') AND
ISNULL(Source.z_grid_reference_longitude,'')=ISNULL(POSTAL.z_grid_reference_longitude ,'')
)Ser WHERE Ser.ExistsFlag=0

----siteId is the combination of store_numbeer and record_source_id
INSERT INTO ser.PostalAddress
		(SiteId, AddressLine1, AddressLine2, Town, County, PostalCode, LOVCountryId, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag,SCDVersion,
		SCDLOVRecordSourceId,ETLRunLogId,PsaRowkey )
		SELECT Ser.SiteId  ,Ser.AddressLine1, Ser.AddressLine2, Ser.Town, Ser.County, Ser.PostalCode, Ser.LOVCountryId,
@PostalLOVRecordSourceId,@SCDStartDate_new,@SCDEndDate,'Y', 1, @SCDLOVRecordSourceId,Ser.ETLRunLogId,Ser.PsaRowKey  from 
ser.PostalAddress_SiteProperty_STG Ser
Print 'Info: PostalAddress Table Loaded Successfully ';

------------------------------------------Table2-SITE--------------------------------------------------------------------		
Print 'Info: site Table Load Started ';
INSERT INTO ser.Site(SiteId,SourceKey,SiteName,LOVSiteTypeId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSArowKey)
SELECT SiteId,NULL SourceKey,NULL SiteName,@physical_store_type_id LOVSiteTypeId,@PostalLOVRecordSourceId,@SCDStartDate_new,
	@SCDEndDate,'Y',1,@SCDLOVRecordSourceId,ETLRunLogId,PsaRowKey  from 
ser.PostalAddress_SiteProperty_STG 
Print 'Info: site Table Loaded Successfully ';

------------------------------------------Table3-SITEPROPERTY--------------------------------------------------------------
PRINT 'Info: SITE PROPERTY Table Load Started '; 
--refernce value
SELECT @uom_id_degree = LovID from ser.RefLOV where LOVKey = '°' AND LovSetID = (SELECT LovSetID from ser.RefLOVSet where LOVSetName = 'Unit Of Measure' )
SELECT @uom_id_m =LovID from ser.RefLOV where LOVKey = 'm' AND LovSetID = (SELECT LovSetID from ser.RefLOVSet where LOVSetName = 'Unit Of Measure' )
Insert INTO [ser].[SiteProperty] (SiteId,          
  MeasureId,           
  LOVUOMId,            
  Value,
  LOVRecordSourceId,
  SCDStartDate,
  SCDEndDate,
  SCDActiveFlag,       
  SCDVersion,          
  SCDLOVRecordSourceId,
  ETLRunLogID,PsaRowKey)
 SELECT pvt.SiteId,pvt.MeasureId,pvt.LOVUOMId,pvt.Value,@record_source_id LOVRecordSourceId,@SCDStartDate_new,@SCDEndDate,'Y',1,@SCDLovRecordSourceId,EtlRunLogId,PsaRowKey FROM 
 (Select SiteID,
	(CASE WHEN (PICol='z_grid_reference_longitude') or (PICol='z_grid_reference_latitude') THEN @uom_id_degree ELSE @uom_id_m END ) LOVUOMId,
	(CASE WHEN (PICol='z_grid_reference_longitude') or (PICol='z_grid_reference_latitude') THEN (SELECT  MeasureId from ser.Measure where MeasureName = ''+PICol+'' AND LOVRecordSourceId = @record_source_id and LOVDatatypeId = @data_type_double_id and LovMeasureTypeId = @measure_type_geocode_id)
	ELSE (SELECT  MeasureId from ser.Measure where MeasureName = ''+PICol+'' AND LOVRecordSourceId = @record_source_id and LOVDatatypeId = @data_type_int_id and LovMeasureTypeId = @measure_type_geocode_id) END)	MeasureId,
	PIValue as Value,ETLRunLogId,PsaRowKey from 
(select SiteId ,AddressLine1, AddressLine2, Town, County, PostalCode,z_grid_reference_northing,
z_grid_reference_easting,z_grid_reference_latitude,z_grid_reference_longitude,ETLRunLogId,PsaRowKey from 
ser.PostalAddress_SiteProperty_STG)t
 UNPIVOT
(PIValue FOR PICol in         (t.z_grid_reference_longitude,
                                t.z_grid_reference_latitude,
                                t.z_grid_reference_easting,
                                t.z_grid_reference_northing
                                ))AS LOVGroupId  )pvt  where pvt.Value is not null AND pvt.Value!='' 
PRINT 'Info: SITE PROPERTY Table Loaded Successfully ';  
-------------------------------TABLE4-SITEROLE-------------------------------------------------------------------------------------
---truncating PostalAddress_STG table for getting the updated entry for postal address table with Site property columns
PRINT 'Info:Deleting entries in PostalAddress_STG table for getting refreshed data'
delete from ser.PostalAddress_STG
---Inserting PostalAddress_STG table for getting the updated entry for postal address table with Site property columns
PRINT 'Info:Inserting entries in PostalAddress_STG table for getting refreshed data'
--create and load postal address temp table for finding the distinct duplicate records
exec('INSERT INTO [ser].[PostalAddress_STG](SiteId,AddressLine1,AddressLine2, Town, County, PostalCode
,z_grid_reference_longitude ,z_grid_reference_latitude,z_grid_reference_easting,z_grid_reference_northing )
select Postal.SiteId,Postal.AddressLine1,Postal.AddressLine2, Postal.Town, Postal.County, Postal.PostalCode
,SP.z_grid_reference_longitude,SP.z_grid_reference_latitude,SP.z_grid_reference_easting,SP.z_grid_reference_northing
from ser.PostalAddress Postal 
left join 
(select [SiteId] as SiteId,['+@longitude_measureId+'] z_grid_reference_longitude ,['+@latitude_measureId+'] z_grid_reference_latitude,['+@easting_measureId+'] z_grid_reference_easting,['+@northing_measureId+'] z_grid_reference_northing
 FROM (select siteID,MeasureId,Value from ser.SiteProperty) SourceTable
PIVOT ( MAX(Value)
       FOR MeasureId in (['+@longitude_measureId+'],['+@latitude_measureId+'],['+@easting_measureId+'],['+@northing_measureId+'])) PivotTable) SP
on Postal.SiteId=SP.SiteId')

Print 'Info: siteRole Table Load Started '; 
SELECT @max_site_role_id= COALESCE((SELECT MAX(SiteRoleId) FROM  ser.SiteRole),0)

--updating the existing records in SiteRole table if exists
UPDATE ser.SiteRole   set SCDEndDate=DATEADD(second,-1,@SCDStartDate)
 FROM ser.SiteRole  sr
join psa.rawuk_btc_mdm_store mdms
ON mdms.record_source_id=LovRecordSourceId and
 sr.sourcekey = mdms.store_number
Where sr.SCDActiveFlag='Y' and mdms.row_status=@row_status
--insertion
INSERT INTO ser.SiteRole(SiteRoleId,SiteId,LOVRoleId,SourceKey,SiteRoleName,SiteRoleShortName,LOVRecordSourceId,SCDSTartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowkey)
SELECT   ISNULL(sr.SiteRoleId,row_num+@max_site_role_id) SiteRoleId,
                POSTAL.SiteId as SiteId,
				@role_id LOVSiteTypeId,
                mdms.store_number SourceKey,
                mdms.store_name SiteRoleName,
                mdms.store_short_name SiteRoleShortName ,   
                mdms.record_source_id LOVRecordSourceId,
                CASe When sr.scdstartdate is null then @SCDStartDate_new
                ELSE  @SCDStartDate END  SCDStartDate,                
                convert (datetime,'9999-12-31') SCDEndDate,
                LEAD('N', 1, 'Y') OVER(PARTITION BY mdms.store_number,mdms.record_source_id ORDER BY mdms.store_number ASC) SCDActiveFlag,                
                    (CASe When sr.SCDVersion is null then 1
                      ELSE 
                          sr.SCDVersion+1 
                END) SCDVersion,
                @SCDLOVRecordSourceId SCDLOVRecordSourceId,
                @serveETLRunLogID ETLRunLogId,
				mdms.row_id
    FROM psa.rawuk_btc_mdm_store  mdms
	join ser.PostalAddress_STG POSTAL on 
ISNULL(mdms.store_address_line_1,'')=ISNULL(POSTAL.AddressLine1,'') AND  
ISNULL(mdms.store_address_line_2,'') =ISNULL(POSTAL.AddressLine2,'') AND
ISNULL(mdms.store_town,'')=ISNULL(POSTAL.Town,'') AND
ISNULL(mdms.store_county,'')=ISNULL(POSTAL.County,'') AND   
ISNULL(mdms.postcode,'')=ISNULL(POSTAL.PostalCode ,'') AND
ISNULL(mdms.z_grid_reference_northing,'')=ISNULL(POSTAL.z_grid_reference_northing ,'') AND 
ISNULL(mdms.z_grid_reference_easting,'')=ISNULL(POSTAL.z_grid_reference_easting ,'') AND 
ISNULL(mdms.z_grid_reference_latitude,'')=ISNULL(POSTAL.z_grid_reference_latitude ,'') AND 
ISNULL(mdms.z_grid_reference_longitude,'')=ISNULL(POSTAL.z_grid_reference_longitude ,'')  
 join (SELECT mdms.store_number,
                 mdms.record_source_id,
                 ROW_NUMBER() OVER(ORDER BY mdms.store_number,mdms.record_source_id ASC) row_num
          FROM psa.rawuk_btc_mdm_store mdms  GROUP BY mdms.store_number,mdms.record_source_id) storeTemp
    ON mdms.store_number=storeTemp.store_number  
    LEFt join ser.SiteRole sr 
    on mdms.store_number =sr.sourcekey and mdms.record_source_id=sr.lovrecordSourceId
	WHERE mdms.Row_Status=@row_status AND mdms.etl_runlog_id in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,',')) and ISNULL(sr.SCDActiveFlag,'Y')='Y' 

 --updating the previous entries in SiteRole table column SCDActiveFlag='N'
 UPDATE ser.SiteRole   set SCDActiveFlag='N'
 FROM ser.SiteRole  sr
join psa.rawuk_btc_mdm_store mdms
ON mdms.record_source_id=LovRecordSourceId and
 sr.sourcekey = mdms.store_number
Where sr.SCDActiveFlag='Y' and mdms.Row_Status=@row_status and SCDEndDate !='9999-12-31 00:00:00.000'
Print 'Info: siteRole Table Loaded Successfully ';
--------------------------------------TABLE5-SITEROLEGROUP--------------------------------------------------------------
Print 'Info: SiteRoleGroup Table Load Started ';
 -- DECLARE @MAXSRGpID int;
SELECT @MAXSRGpID=COALESCE(max(siterolegroupid),0) from ser.siterolegroup;

Insert Into [ser].[SiteRoleGrp_STG](ExistsFlag,SiteRoleGroupId,SiteRoleId,LOVSiteRoleGroupSetId,LOVGroupId,ParentSiteRoleGroupId,LOVRecordSourceId,SCDStartDate
,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,row_id)
     
                SELECT CASE WHEN SRG.SiteRoleGroupId is  NULL AND SRG.LOVGroupId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag, 
				SRG.SiteRoleGroupId,
				pvt.SiteRoleId, 
				pvt.LOVSiteRoleGroupSetId,
				pvt.Lovid as LOVGroupId,
				NULL as ParentSiteRoleGroupId, 
				pvt.LOVRecordSourceId,
				CASE WHEN SRG.SiteRoleGroupId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
				LEAD(pvt.SCDStartDate,1,CONVERT(DATETIME,'99991231') )OVER(PARTITION BY pvt.SiteRoleId,pvt.Lovid,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC)	AS SCDEndDate,
                LEAD('N', 1,'Y') OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVSiteRoleGroupSetId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC) SCDActiveFlag,
				COALESCE(SRG.SCDVersion,0) SCDVersion,pvt.SCDLOVRecordSourceId,@serveETLRunLogID ETLRunLogId,pvt.row_id 
                 FROM
                 (
                    Select SiteRoleID,(SELECT LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = ''+PICol+'' and LOVSetRecordSourceId=@record_source_id) LOVSiteRoleGroupSetId,
       (SELECT LOVId FROM ser.RefLOV WHERE LOVKey = ''+PIValue+''AND 
       
      LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = ''+PICol+'' )) Lovid,null as ParentSiteRoleGroupId,
	  LOVRecordSourceId,SCDStartDate,SCDLOVRecordSourceId,@serveETLRunLogID ETLRunLogId,row_id
                 FROM
                (SELECT 
    mdms.distribution_channel,
    mdms.trading_format,
    mdms.type_of_store_description,
    mdms.sag,
    mdms.mini_sag,
    mdms.price_band_code,
    mdms.benchmark_group,
	sr.SiteRoleId as SiteRoleID,
	mdms.record_source_id as LOVRecordSourceId,
	CONVERT (date, GETDATE()) as SCDStartDate ,
    @SCDLOVRecordSourceId as SCDLOVRecordSourceId,
	 mdms.etl_runlog_id as ETLRunLogId,
	 mdms.row_id as row_id
  FROM psa.rawuk_btc_mdm_store mdms ,
     ser.SiteRole sr
     WHERE cast(mdms.store_number  as varchar)=sr.SourceKey
     and sr.LOVRecordSourceId=@record_source_id and sr.SCDActiveFlag='Y' and mdms.row_status=@row_status
	  AND mdms.etl_runlog_id in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,',')))t
	 UNPIVOT
(PIValue FOR PICol in         (t.distribution_channel,
                                t.trading_format,
                                t.type_of_store_description,
                                t.sag,
                                t.mini_sag,
                                t.price_band_code,
                                t.benchmark_group))AS LOVGroupIdSS  )pvt 
								LEFT JOIN ser.SiteRoleGroup SRG  on pvt.SiteRoleId=SRG.SiteRoleId AND
            pvt.LOVSiteRoleGroupSetId=SRG.LOVSiteRoleGroupSetId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId
            AND pvt.LovId is not null AND  pvt.LovId!='' AND SRG.SCDActiveFlag='Y' 
								
								
UPDATE ser.SiteRoleGroup SET SCDActiveFlag= 'N',  SCDEndDate=DATEADD(second,-1,INS.SCDStartDate )
FROM ser.SiteRoleGroup SRGrp JOIN 
(SELECT *         					
 FROM ser.SiteRoleGrp_STG STAGE  WHERE STAGE.SCDActiveFlag='Y' AND STAGE.existsFlag=1 )INS
ON 
SRGrp.SiteRoleId=INS.SiteRoleId AND SRGrp.LOVSiteRoleGroupSetId=INS.LOVSiteRoleGroupSetId
AND SRGrp.SCDActiveFlag='Y' AND SRGrp.lovRecordSourceId=INS.lovRecordSourceId

--Inserting to Siterolegroup
 INSERT  INTO  ser.SiteRoleGroup (SiteRoleGroupId,
                                    SiteRoleId     ,
                                    LOVSiteRoleGroupSetId            ,
                                    LOVGroupId  ,
                                    ParentSiteRoleGroupId  ,
                                    LOVRecordSourceId     ,
                                    SCDStartDate          , 
                                    SCDEndDate            ,									
                                    SCDActiveFlag         ,
                                    SCDVersion            ,
                                    SCDLOVRecordSourceId  ,
                                    ETLRunLogId,
									PSARowKey)
									SELECT CASE WHEN STAGE.existsFlag=1 THEN STAGE.SiteRoleGroupId
									ELSE ROW_NUMBER() OVER(ORDER BY STAGE.SiteRoleId,STAGE.LOVSiteRoleGroupSetId,STAGE.LOVRecordSourceId ASC)+0 END  SiteRoleGroupId,
									STAGE.[SiteRoleId] ,
									STAGE.[LOVSiteRoleGroupSetId] ,
                                    STAGE.[LOVGroupId],
                                    STAGE.[ParentSiteRoleGroupId],
									STAGE.[LOVRecordSourceId] ,
									STAGE.[SCDStartDate] , 
									STAGE.SCDEndDate,				 
 STAGE.[SCDActiveFlag] , STAGE.SCDVersion +1 ,@SCDLOVRecordSourceId SCDLOVRecordSourceId,
 @serveETLRunLogId  ETLRunLogId,STAGE.row_id FROM (
SELECT *  FROM ser.SiteRoleGrp_STG   STG WHERE STG.SCDActiveFlag='Y' and  STG.LOVGroupId is not null)STAGE
 		
  PRINT 'Info: SiteRoleGroup Table Loaded Successfully ';  
  
----------------------------------------TABLE6-PARTY--------------------------------------------------------------------
PRINT 'Info: Party Table Loading Started '; 

SELECT @MAXPartyId=max(PartyId) FROM ser.Party;
SELECT @PartyTypeId= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'ORG'  AND 
r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName ='Party Type'  )

INSERT INTO ser.Party(PartyId, LOVPartyTypeId, SourceKey, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,Psarowkey)
select COALESCE( @MAXPartyId,0) + ROW_NUMBER() OVER(ORDER BY  ser.SourceKey,ser.lovrecordsourceId) PartyId,ser.PartyTypeId,
ser.SourceKey,ser.lovrecordsourceId,ser.SCDStartDate,@SCDEndDate,'Y', 1, @SCDLOVRecordSourceId,ser.ETLRunLogId,ser.row_id from 
(SELECT CASE WHEN Party.PartyId IS NULL THEN 0 ELSE 1 END ExistsFlag,
Party.PartyId,
@PartyTypeId PartyTypeId,
store.SourceKey, 
store.lovrecordsourceId, 
@SCDStartDate_new  as SCDStartDate,
@serveETLRunLogID ETLRunLogId,
store.row_id 
FROM (
(select sales_organisation SourceKey,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id from psa.rawuk_btc_mdm_store
group by sales_organisation ,etl_runlog_id ,record_source_id ,row_status )
union
(select primary_care_organisation_description SourceKey,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id from psa.rawuk_btc_mdm_store 
group by primary_care_organisation_description ,etl_runlog_id ,record_source_id ,row_status)
union
(select name_of_health_authority SourceKey,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id from psa.rawuk_btc_mdm_store
group by name_of_health_authority ,etl_runlog_id ,record_source_id ,row_status))store
LEFT JOIN ser.Party Party
on store.lovrecordsourceId=Party.lovrecordsourceId AND Party.SourceKey=store.SourceKey AND PArty.SCDActiveFlag='Y' 
AND Party.LOVPartyTypeId=@PartyTypeId where store.Sourcekey is not null and store.Sourcekey!='' and store.row_status=@row_status AND store.ETLRunLogId in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,',')))ser
where ser.ExistsFlag=0

PRINT 'Info: Party Table Loaded Successfully ';  
---------------------------------------TABLE7-PARTYROLE------------------------------------
PRINT 'Info: PartyRole Table Load Started '; 
--referencevalue
SELECT @role_id_partyrole_sorg=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='Retailer' and rls.LOVSetName='Role' 
--referencevalue
SELECT @role_id_partyrole=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='Primary Care Trust' and rls.LOVSetName='Role'

--referencevalue
SELECT @role_id_partyrole_health=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='Health Authority' and rls.LOVSetName='Role' 
--referencevalue
SELECT @PartyTypeId= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'ORG'  AND 
r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName ='Party Type'  )
--maxvalue for partyRoleId
SELECT @MAXPartyRoleId=max(PartyRoleId) FROM ser.PartyRole;

--creating staging table for PartyRole
INSERT INTO ser.PartyRole([PartyRoleId],[LOVRoleId],[PartyId],[SourceKey],[PartyRoleName],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate]
          ,[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[PSARowKey])
SELECT COALESCE( @MAXPartyRoleId,0) + ROW_NUMBER() OVER(ORDER BY  ser.SourceKey,ser.LOVRoleId,ser.lovrecordsourceId)PartyRoleId, 
ser.LOVRoleId,ser.PartyId,ser.SourceKey,ser.PartyRoleName,LOVRecordSourceId,ser.SCDStartDate,@SCDEndDate,'Y', 1, @SCDLOVRecordSourceId, ser.ETLRunLogId,ser.row_id		   
from (
SELECT CASE WHEN PartyRole.PartyRoleId IS NULL THEN 0 ELSE 1 END ExistsFlag,
PartyRole.PartyRoleId,
CASE WHEN store.roletype='sales_organisation' THEN  @role_id_partyrole_sorg 
WHEN store.roletype='primary_care_organisation_description' THEN @role_id_partyrole  
ELSE @role_id_partyrole_health END  LOVRoleId,
p.PartyId,
store.SourceKey,
store.PartyRoleName,
store.lovrecordsourceId, 
store.SCDStartDate,
@serveETLRunLogID ETLRunLogId,store.row_id
FROM ( ( select sales_organisation SourceKey,company_name as PartyRoleName,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id,'sales_organisation' roletype from psa.rawuk_btc_mdm_store 
group by sales_organisation ,company_name,etl_runlog_id ,record_source_id ,row_status)
union
(select primary_care_organisation_description SourceKey,primary_care_organisation_description as PartyRoleName,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id,'primary_care_organisation_description' roletype from psa.rawuk_btc_mdm_store
where primary_care_organisation_description is not null and primary_care_organisation_description!='' group by primary_care_organisation_description,primary_care_organisation_description ,etl_runlog_id ,record_source_id ,row_status)
union
(select name_of_health_authority SourceKey,name_of_health_authority as PartyRoleName,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id,'name_of_health_authority' roletype from psa.rawuk_btc_mdm_store
where name_of_health_authority is not null and name_of_health_authority!='' group by name_of_health_authority ,name_of_health_authority,etl_runlog_id ,record_source_id ,row_status))store
LEFT JOIN ser.Party p
on store.SourceKey=p.SourceKey and store.lovrecordsourceId =p.LOVRecordSourceId
LEFT JOIN (SELECT  rl.LOVId as LOVId ,rls.LOVSetRecordSourceId from ser.RefLOV rl join ser.RefLOVSet rls
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='Primary Care Trust' and rls.LOVSetName='Role' and rls.LOVSetRecordSourceId = @record_source_id) rr
on store.lovrecordsourceId=rr.LOVSetRecordSourceId
LEFT JOIN ser.PartyRole PartyRole
on store.lovrecordsourceId=PartyRole.lovrecordsourceId AND PartyRole.SourceKey=store.SourceKey 
where p.SCDActiveFlag='Y' and store.row_status=@row_status
AND store.ETLRunLogId in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,',')))ser
where ser.ExistsFlag=0

PRINT 'Info: PartyRole Table Loaded Successfully ';  


--------------------------------------TABLE8-ORGANISATION---------------------------------------------------------
PRINT 'Info: Organisation Table Load Started ';  

INSERT INTO ser.Organisation(PartyId, SourceOrganisationKey,OrganisationName,ParentPartyID, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,Psarowkey)
SELECT PartyId, ser.SourceOrganisationKey,ser.OrganisationName,ser.ParentPartyID,ser.LOVRecordSourceId,
ser.SCDStartDate,@SCDEndDate,'Y', 1, @SCDLOVRecordSourceId, ser.ETLRunLogId,ser.row_id
FROM(
SELECT CASE WHEN Organisation.PartyId IS NULL THEN 0 ELSE 1 END ExistsFlag,
p.PartyId,
store.SourceOrganisationKey,
store.OrganisationName,
NULL as ParentPartyID,
store.lovrecordsourceId, 
store.SCDStartDate,
@serveETLRunLogID ETLRunLogId,store.row_id
FROM (
(select sales_organisation SourceOrganisationKey,company_name OrganisationName,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id from psa.rawuk_btc_mdm_store
group by sales_organisation ,company_name,etl_runlog_id ,record_source_id ,row_status )
union
(select primary_care_organisation_description SourceOrganisationKey,primary_care_organisation_description OrganisationName,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id from psa.rawuk_btc_mdm_store 
where primary_care_organisation_description is not null or primary_care_organisation_description!='' group by primary_care_organisation_description ,primary_care_organisation_description,etl_runlog_id ,record_source_id ,row_status)
union
(select name_of_health_authority SourceOrganisationKey,name_of_health_authority OrganisationName,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id from psa.rawuk_btc_mdm_store
where name_of_health_authority is not null or name_of_health_authority!='' group by name_of_health_authority ,name_of_health_authority,etl_runlog_id ,record_source_id ,row_status))store
LEFT JOIN ser.Party p on store.SourceOrganisationKey=p.SourceKey 
LEFT JOIN ser.Organisation Organisation
on store.lovrecordsourceId=Organisation.lovrecordsourceId AND Organisation.SourceOrganisationKey=store.SourceOrganisationKey AND Organisation.SCDActiveFlag='Y' 
where p.SCDActiveFlag='Y' and p.LOVRecordSourceId=store.lovrecordsourceId and store.row_status=@row_status
AND store.ETLRunLogId in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,',')))ser
where ser.ExistsFlag=0 

PRINT 'Info: Organisation Table Loaded Successfully ';  


-----------------------------------------------TABLE9-PARTROLESITEROLERELATIONSHIP-----------------------------------
PRINT 'Info: PartyRoleSiteRoleRelationship Table Load Started '; 
--refernce value
SELECT @party_relationship_type_of = rl.LOVId FROM ser.RefLOV rl JOIN ser.RefLOVSet rls ON rl.LOVSetId=rls.LOVSetId
AND rl.LOVKey='Operates From' AND rls.LOVSetName='Relationship Type' 

--reference value
SELECT @party_relationship_type_aw = rl.LOVId FROM ser.RefLOV rl JOIN ser.RefLOVSet rls ON rl.LOVSetId=rls.LOVSetId
AND rl.LOVKey='Associated With' AND rls.LOVSetName='Relationship Type' 

--create staging table
INSERT  INTO ser.[PartyRoleSiteRoleRelationship_STG](ExistsFlag,PartyRoleId,SiteRoleId,LOVRelationshipTypeId,LOVRecordSourceId,SCDStartDate,
SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,row_id)
SELECT CASE WHEN PartyRoleSiteRoleRelationship.PartyRoleId IS NULL THEN 0 ELSE 1 END ExistsFlag,
STG.PartyRoleId,
STG.SiteRoleId SiteRoleId,
CASE WHEN roleTypeId='sales_organisation' THEN @party_relationship_type_of ELSE @party_relationship_type_aw END LOVRelationshipTypeId,
STG.lovrecordsourceId, 
CASE WHEN PartyRoleSiteRoleRelationship.PartyRoleId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
LEAD(CONVERT(DateTime,STG.SCDStartDate),1,'99991231') OVER(PARTITION BY STG.sourceKey,STG.PartyRoleId,STG.SiteRoleId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDEndDate,
LEAD('N',1,'Y') OVER(PARTITION BY STG.sourceKey,STG.PartyRoleId,STG.SiteRoleId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDActiveFlag,
COALESCE(PartyRoleSiteRoleRelationship.SCDVersion,0) + 1 SCDVersion,@SCDLOVRecordSourceId SCDLOVRecordSourceId ,@serveETLRunLogID,STG.row_id
FROM (
select store.SourceKey,
p.PartyRoleId,
s.SiteRoleId,
store.roleTypeId,store.lovrecordsourceId,store.SCDStartDate,store.row_status,store.ETLRunLogId,store.row_id
from (--sales_organisation
(select sales_organisation sourceKey,store_number,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id,'sales_organisation' roleTypeId,@role_id_partyrole_sorg roleId  from psa.rawuk_btc_mdm_store
where record_source_id=@record_source_id group by sales_organisation ,store_number,etl_runlog_id ,record_source_id ,row_status )
union
--primary_care_organisation_description
(select primary_care_organisation_description sourceKey,store_number,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id,'primary_care_organisation_description' roleTypeId,@role_id_partyrole roleId from psa.rawuk_btc_mdm_store
where record_source_id=@record_source_id and primary_care_organisation_description is not null and primary_care_organisation_description!='' group by primary_care_organisation_description ,store_number,etl_runlog_id ,record_source_id ,row_status)
union
--name_of_health_authority
(select name_of_health_authority sourceKey,store_number,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate_new SCDStartDate,row_status,Min(row_id) row_id,'name_of_health_authority' roleTypeId,@role_id_partyrole_health  roleId from psa.rawuk_btc_mdm_store --@role_id_partyrole_health
where record_source_id=@record_source_id and name_of_health_authority is not null and name_of_health_authority!='' group by name_of_health_authority ,store_number,etl_runlog_id ,record_source_id ,row_status)

)store,
ser.PartyRole p,
ser.SiteRole s
  where 
  store.sourcekey=p.SourceKey and store.lovrecordSourceid=p.lovrecordsourceid
  and store.row_status=@row_status and store.roleId=p.LoVRoleId
   and s.sourcekey=store.store_number and 
	 store.lovrecordsourceId=s.LOVRecordSourceId 
	and  p.SCDActiveFlag='Y' and s.SCDActiveFlag='Y'  
	
	) STG    
LEFT JOIN ser.PartyRoleSiteRoleRelationship PartyRoleSiteRoleRelationship
on STG.lovrecordsourceId=PartyRoleSiteRoleRelationship.lovrecordsourceId  and STG.SiteRoleId=PartyRoleSiteRoleRelationship.SiteRoleId
and STG.PartyRoleId=PartyRoleSiteRoleRelationship.PartyRoleId AND  PartyRoleSiteRoleRelationship.SCDActiveFlag='Y' 
where  --STG.sourceKey is not null 
	 --and STG.sourceKey!='' 
	  STG.row_status=@row_status and STG.lovrecordsourceId=@record_source_id
	 AND STG.ETLRunLogId in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,',')) 
	 

--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.PartyRoleSiteRoleRelationship SET SCDEndDate=DATEADD(second,-1,UPD.SCDStartDate ) ,SCDActiveFlag='N' 
FROM ser.PartyRoleSiteRoleRelationship PartyRoleSiteRoleRelationship JOIN (
SELECT * FROM ser.PartyRoleSiteRoleRelationship_STG)UPD
ON PartyRoleSiteRoleRelationship.PartyRoleId=UPD.PartyRoleId AND PartyRoleSiteRoleRelationship.SiteRoleId=UPD.SiteRoleId
AND PartyRoleSiteRoleRelationship.LOVRelationshipTypeId=UPD.LOVRelationshipTypeId
AND PartyRoleSiteRoleRelationship.lovRecordSourceId=UPD.LOVRecordSourceId AND  
PartyRoleSiteRoleRelationship.SCDActiveFlag='Y' AND UPD.SCDActiveFlag='Y' AND UPD.ExistsFlag=1

--Inserting data to table with existing version increment by 1 and new record version as 1.
INSERT INTO ser.PartyRoleSiteRoleRelationship(PartyRoleId, SiteRoleId,LOVRelationshipTypeId,LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT PartyRoleId, SiteRoleId,LOVRelationshipTypeId,LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId,ETLRunLogId,row_id
FROM
(SELECT * FROM ser.PartyRoleSiteRoleRelationship_STG)Stage
WHERE Stage.SCDActiveFlag='Y'

--dropping staging table after process
PRINT 'Info: PartyRoleSiteRoleRelationship Table Loaded Successfully ';  


-----------------------------------------------TABLE10-SITEROLECONTACTMETHOD----------------------------------------------
PRINT 'Info: SITEROLE CONTACT METHOD Table Load Started ';  
--reference value
SELECT @contact_method_type_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='TEL' and rls.LOVSetName='Contact Method Type' 

--reference value
SELECT @usage_type_id=rl.LOVId from ser.RefLOV rl join ser.RefLOVSet rls 
on rl.LOVSetId=rls.LOVSetId  and rl.LOVKey='BUS' and rls.LOVSetName='Usage Type' 


--create staging table
INSERT INTO ser.SiteRoleContactMethod_STG(
[ExistsFlag],[SiteRoleId],[LOVContactMethodTypeId],[LOVUsageTypeId],[ContactDetail],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])


SELECT CASE WHEN SiteRoleContactMethod.SiteRoleId IS NULL THEN 0 ELSE 1 END ExistsFlag,
STG.SiteRoleId,
@contact_method_type_id as LOVContactMethodTypeId,
@usage_type_id as LovUsageTypeId,
STG.telephone_number as ContactDetail,
STG.lovrecordsourceId, 
CASE WHEN SiteRoleContactMethod.SiteRoleId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
LEAD(CONVERT(DateTime,STG.SCDStartDate),1,'99991231') OVER(PARTITION BY STG.SiteRoleId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDEndDate,
LEAD('N',1,'Y') OVER(PARTITION BY STG.SiteRoleId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDActiveFlag,
COALESCE(SiteRoleContactMethod.SCDVersion,0) + 1 SCDVersion,@SCDLOVRecordSourceId SCDLOVRecordSourceId , @serveETLRunLogID ETLRunLogId,STG.row_id
 FROM (
 
select s.SiteRoleId,store.telephone_number,store.ETLRunLogId,store.lovrecordsourceId,store.SCDStartDate,store.row_status,store.row_id from
(select store_number,telephone_number,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,Min(row_id) row_id  
from psa.rawuk_btc_mdm_store group by  store_number,telephone_number,etl_runlog_id,record_source_id,row_status)store,
ser.SiteRole s WHERE store.store_number=s.SourceKey and store.LOVRecordSourceId=s.LOVRecordSourceId and s.SCDActiveFlag='Y' 
)STG
LEFT JOIN ser.SiteRoleContactMethod SiteRoleContactMethod
on STG.lovrecordsourceId=SiteRoleContactMethod.lovrecordsourceId AND SiteRoleContactMethod.SCDActiveFlag='Y' 
AND STG.SiteRoleId=SiteRoleContactMethod.SiteRoleId
where STG.telephone_number is not null and STG.telephone_number!='' and STG.row_status=@row_status
AND STG.ETLRunLogId in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,','))

--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.SiteRoleContactMethod SET SCDEndDate=DATEADD(second,-1,UPD.SCDStartDate ) ,SCDActiveFlag='N' 
FROM ser.SiteRoleContactMethod SiteRoleContactMethod_mdm JOIN (
SELECT * FROM ser.SiteRoleContactMethod_STG)UPD
ON SiteRoleContactMethod_mdm.SiteRoleId=UPD.SiteRoleId AND SiteRoleContactMethod_mdm.lovRecordSourceId=UPD.LOVRecordSourceId AND  
SiteRoleContactMethod_mdm.SCDActiveFlag='Y' AND UPD.SCDActiveFlag='Y' AND UPD.ExistsFlag=1

--Inserting data to table with existing version increment by 1 and new record version as 1.
INSERT INTO ser.SiteRoleContactMethod([SiteRoleId]
           ,[LOVContactMethodTypeId]
           ,[LOVUsageTypeId]
           ,[ContactDetail]
		   ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId],
		   [Psarowkey])
SELECT SiteRoleId, LOVContactMethodTypeId,LOVUsageTypeId,ContactDetail,LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,row_id
FROM
(SELECT * FROM ser.SiteRoleContactMethod_STG)Stage
WHERE Stage.SCDActiveFlag='Y'

PRINT 'Info: SITEROLE CONTACT METHOD Table Loaded Successfully '; 

--------------------------------------------TABLE11-SITEROLETERRITORY--------------------------------------------------
PRINT 'Info: SITEROLE TERRITORY Table Load Started '; 
--reference value
SELECT @setid_area_number=LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = 'area_number' and LOVSetRecordSourceId=@record_source_id

--reference value
SELECT @setid_nhs_market=LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = 'nhs_market' and LOVSetRecordSourceId=@record_source_id

--create staging table

INSERT INTO ser.[SiteRoleTerritory_STG]([ExistsFlag],[SiteRoleId],[LOVSiteRoleTerritorySetId],[LOVTerritoryId],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])

SELECT CASE WHEN SiteRoleTerritory.SiteRoleId IS NULL THEN 0 ELSE 1 END ExistsFlag,
sr.SiteRoleId,
--case when typename='area_number' THEN @setid_area_number
    -- when typename='nhs_market' THEN @setid_nhs_market END as LOVSiteRoleTerritorySetId,
store.LOVSiteRoleTerritorySetId,
(SELECT LOVId FROM ser.RefLOV WHERE LOVKey = ''+territorysourceKey+''AND 
       
      LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = ''+typename+'' )) LovTerritoryId,	 
store.lovrecordsourceId, 
CASE WHEN SiteRoleTerritory.SiteRoleId IS NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
LEAD(CONVERT(DateTime,store.SCDStartDate),1,'99991231') OVER(PARTITION BY sr.SiteRoleId,store.LOVSiteRoleTerritorySetId,store.lovrecordsourceId ORDER BY store.SCDStartDate) SCDEndDate,
LEAD('N',1,'Y') OVER(PARTITION BY sr.SiteRoleId,store.LOVSiteRoleTerritorySetId,store.lovrecordsourceId ORDER BY store.SCDStartDate) SCDActiveFlag,
COALESCE(SiteRoleTerritory.SCDVersion,0) + 1 SCDVersion,@SCDLOVRecordSourceId SCDLOVRecordSourceId , @serveETLRunLogID ETLRunLogId,store.row_id
FROM (
(select store_number ,cast(area_number as varchar(50)) territorysourceKey,etl_runlog_id ETLRunLogId,@setid_area_number LOVSiteRoleTerritorySetId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,row_id,'area_number' as typename from psa.rawuk_btc_mdm_store where record_source_id=@record_source_id )
union
(select store_number ,cast(nhs_market as varchar(50)) territorysourceKey,etl_runlog_id ETLRunLogId,@setid_nhs_market LOVSiteRoleTerritorySetId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,row_id,'nhs_market' as typename from psa.rawuk_btc_mdm_store where record_source_id=@record_source_id)
)store
LEFT JOIN ser.SiteRole sr on store.store_number=sr.SourceKey and store.lovrecordsourceId=sr.lovrecordsourceId
LEFT JOIN ser.SiteRoleTerritory SiteRoleTerritory
on store.lovrecordsourceId=SiteRoleTerritory.lovrecordsourceId AND SiteRoleTerritory.SiteRoleId=sr.SiteRoleId AND SiteRoleTerritory.SCDActiveFlag='Y' and SiteRoleTerritory.LOVSiteRoleTerritorySetId=store.LOVSiteRoleTerritorySetId
where store.territorysourceKey is not null and store.territorysourceKey!='' and sr.SCDActiveFlag='Y' and sr.LOVRecordSourceId=store.lovrecordsourceId and store.row_status=@row_status
AND store.ETLRunLogId in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,','))


--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.SiteRoleTerritory SET SCDEndDate=DATEADD(second,-1,UPD.SCDStartDate )  ,SCDActiveFlag='N' 
FROM ser.SiteRoleTerritory SiteRoleTerritory JOIN (
SELECT * FROM ser.SiteRoleTerritory_STG)UPD
ON SiteRoleTerritory.SiteRoleId=UPD.SiteRoleId AND SiteRoleTerritory.lovRecordSourceId=UPD.LOVRecordSourceId AND  
SiteRoleTerritory.SCDActiveFlag='Y' AND UPD.SCDActiveFlag='Y' AND UPD.ExistsFlag=1

--Inserting data to table with existing version increment by 1 and new record version as 1.
INSERT INTO ser.SiteRoleTerritory(SiteRoleId, LOVSiteRoleTerritorySetId,LovTerritoryId,LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,Psarowkey)
SELECT SiteRoleId, LOVSiteRoleTerritorySetId,LovTerritoryId,LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,row_id
FROM
(SELECT * FROM ser.SiteRoleTerritory_STG)Stage
WHERE Stage.SCDActiveFlag='Y'

--select * from ser.SiteRoleTerritory_mdm
PRINT 'Info: SITEROLE TERRITORY Table Loaded Successfully '; 
----------------------------------------------TABLE12-SITEROLESTATUS---------------------------------------------------

PRINT 'Info: SiteRoleStatus Table Load Started ';
--reference value
SELECT @OpenStatus = ref.Lovid from ser.reflov ref JOIN ser.reflovset refs on ref.LovSetID = refs.LovSetID
WHERE ref.LOVKey =  'Open (for trading)'  and refs.LOVSETName = 'store_open_status' and ref.LoVRecordSourceId=@record_source_id

--reference value
SELECT @LOVSiteRoleStatusSetId_status = refs.LovSetid from ser.reflovset refs WHERE  refs.LOVSETName = 'store_open_status'

--reference value
SELECT @LOVSiteRoleStatusSetId_floor = ref.Lovid from ser.reflov ref JOIN ser.reflovset refs on ref.LovSetID = refs.LovSetID
WHERE ref.LOVKey =  'FLOOR_AREA'  and refs.LOVSETName = 'Measure Type'

--reference value
SELECT @LOVSiteRoleStatusSetId_nonf_ifl =refs.LovSetid from ser.reflovset refs WHERE  refs.LOVSETName = 'non_lfl_reason_code'

SELECT @LOVSiteRoleStatusSetId_pharmacy = refs.LovSetid from ser.reflovset refs WHERE  refs.LOVSETName = 'pharmacy_registration_status' and refs.LoVSetRecordSourceId=@record_source_id

--create staging table

INSERT INTO ser.SiteRoleStatus_STG( [ExistsFlag],[SiteRoleId],[LOVSiteRoleStatusSetId],[LOVStatusId],[EffectiveFrom],[EffectiveTo],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])
SELECT CASE WHEN SiteRoleStatus.SiteRoleId IS NULL THEN 0 ELSE 1 END ExistsFlag,
si.SiteRoleId,
STG.LOVSiteRoleStatusSetId LOVSiteRoleStatusSetId,
STG.statusId as LOVStatusId,
STG.EffectiveFrom as EffectiveFrom,
STG.EffectiveTo as EffectiveTo,
STG.lovrecordsourceId, 
CASE WHEN SiteRoleStatus.SiteRoleId IS NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
LEAD(CONVERT(DateTime,STG.SCDStartDate),1,'99991231') OVER(PARTITION BY si.SiteRoleId,STG.statusId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDEndDate,
LEAD('N',1,'Y') OVER(PARTITION BY si.SiteRoleId,STG.statusId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) SCDActiveFlag,
COALESCE(SiteRoleStatus.SCDVersion,0) + 1 SCDVersion,@SCDLOVRecordSourceId SCDLOVRecordSourceId , @serveETLRunLogID ETLRunLogId,STG.row_id
 FROM (
 (select  store_number,@OpenStatus statusId,store_opening_date EffectiveFrom, store_closure_date EffectiveTo,@LOVSiteRoleStatusSetId_status LOVSiteRoleStatusSetId,etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,row_id from psa.rawuk_btc_mdm_store
 where record_source_id=@record_source_id and store_open_status = 'Closed (ceased trading)' )
union
--2nd ---
(select  store_number,(select LovID from ser.RefLOV rl join ser.RefLovSet rls on rl.LovSetId=rls.LovSetId where LOVKey = store_open_status and  LOVSetName = 'store_open_status' and rl.LOVrecordSourceId=12008),
case when store_open_status='Open (for trading)' Then store_opening_date
when store_open_status='Closed (ceased trading)' Then store_closure_date ELSE null END as EffectiveFrom, 
null  EffectiveTo ,@LOVSiteRoleStatusSetId_status LOVSiteRoleStatusSetId ,
etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,row_id from psa.rawuk_btc_mdm_store where record_source_id=@record_source_id )

union
--3rd--
(select  store_number,(select LovID from ser.RefLOV rl join ser.RefLovSet rls on rl.LovSetId=rls.LovSetId where LOVKey = non_lfl_reason_code and  LOVSetName = 'non_lfl_reason_code' and rl.LOVrecordSourceId=@record_source_id),
intervention_start_date as EffectiveFrom, 
intervention_end_date EffectiveTo ,@LOVSiteRoleStatusSetId_nonf_ifl LOVSiteRoleStatusSetId,
etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,row_id from psa.rawuk_btc_mdm_store where record_source_id=@record_source_id )

union
--4th
(select  store_number,(select LovID from ser.RefLOV rl join ser.RefLovSet rls on rl.LovSetId=rls.LovSetId where LOVKey = pharmacy_registration_status and  LOVSetName = 'pharmacy_registration_status' and rl.LOVrecordSourceId=@record_source_id),
 null as EffectiveFrom, 
null  EffectiveTo ,@LOVSiteRoleStatusSetId_pharmacy LOVSiteRoleStatusSetId ,
etl_runlog_id ETLRunLogId,record_source_id lovrecordsourceId,@SCDStartDate SCDStartDate,row_status,row_id from psa.rawuk_btc_mdm_store where record_source_id=@record_source_id)
  )STG
  join ser.SiteRole si on si.SourceKey=STG.store_number and si.lovrecordsourceId=STG.lovrecordsourceId and si.SCDActiveFlag='Y'
LEFT JOIN ser.SiteRoleStatus SiteRoleStatus
on STG.lovrecordsourceId=SiteRoleStatus.lovrecordsourceId and SiteRoleStatus.SCDActiveFlag='Y' and Si.SiteRoleId=SiteRolestatus.SiteRoleId where
STG.statusId is not null and STG.statusId!='' and STG.row_status=@row_status and si.SCDActiveFlag='Y'
 AND STG.ETLRunLogId in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,','))


--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.SiteRoleStatus SET SCDEndDate=DATEADD(second,-1,UPD.SCDStartDate )  ,SCDActiveFlag='N' 
FROM ser.SiteRoleStatus SiteRoleStatus_mdm JOIN (
SELECT * FROM ser.SiteRoleStatus_STG)UPD
ON SiteRoleStatus_mdm.SiteRoleId=UPD.SiteRoleId AND SiteRoleStatus_mdm.lovRecordSourceId=UPD.LOVRecordSourceId AND  
SiteRoleStatus_mdm.SCDActiveFlag='Y' AND UPD.SCDActiveFlag='Y' AND UPD.ExistsFlag=1


INSERT INTO ser.SiteRoleStatus([SiteRoleId]
           ,[LOVSiteRoleStatusSetId]
           ,[LOVStatusId]
           ,[EffectiveFrom]
		   ,[EffectiveTo]
		   ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId],
		   [Psarowkey])
SELECT SiteRoleId, [LOVSiteRoleStatusSetId],[LOVStatusId],[EffectiveFrom],[EffectiveTo],LOVRecordSourceId,
SCDStartDate,SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,row_id
FROM
(SELECT * FROM ser.SiteRoleStatus_STG)Stage
WHERE Stage.SCDActiveFlag='Y'


PRINT 'Info: SITEROLE STATUS Table Loaded Successfully '; 
----------------------------------------------TABLE13-SITEROLEPROPERTY---------------------------------------------------

PRINT 'Info: SITEROLE PROPERTY Table Load Started '; 
--reference value
SELECT @uom_idm2 = LovID from ser.RefLOV where LOVKey = 'M2' AND LovSetID = (SELECT LovSetID from ser.RefLOVSet where LOVSetName = 'Unit Of Measure' )
--reference value
SELECT @uom_idunit = LovID from ser.RefLOV where LOVKey = 'unit' AND LovSetID = (SELECT LovSetID from ser.RefLOVSet where LOVSetName = 'Unit Of Measure')

--create staging table
INSERT INTO [ser].[SiteRoleProperty_STG] ([ExistsFlag],[SiteRoleId],[MeasureId],[LOVUOMId],[Value],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])
                SELECT CASE WHEN SRG.SiteRoleId is NULL THEN 0 ELSE 1 END ExistsFlag, 
				pvt.SiteRoleId, 
				pvt.MeasureId,
				pvt.LOVUOMId,
				pvt.Value,
				pvt.LOVRecordSourceId,
				CASE WHEN SRG.SiteRoleId IS NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
				LEAD(pvt.SCDStartDate,1,CONVERT(DATETIME,'99991231') )OVER(PARTITION BY pvt.SiteRoleId,pvt.MeasureId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC)	AS SCDEndDate,
                LEAD('N', 1,'Y') OVER(PARTITION BY pvt.SiteRoleId,pvt.MeasureId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC) SCDActiveFlag,
				COALESCE(SRG.SCDVersion,0) SCDVersion,pvt.SCDLOVRecordSourceId,pvt.ETLRunLogId ,pvt.row_id 
                 FROM
                 (
                    Select SiteRoleID,
					(CASE WHEN PICol='number_of_floors' THEN @uom_idunit ELSE @uom_idm2 END ) LOVUOMId,
				(SELECT  MeasureId from ser.Measure where MeasureName = ''+PICol+'' AND LOVRecordSourceId = @record_source_id and LOVDataTypeId=@data_type_id and LOVMeasureTypeId=@measure_type_id)	MeasureId,
				PIValue as Value,
	  LOVRecordSourceId,SCDStartDate,SCDLOVRecordSourceId,@serveETLRunLogID ETLRunLogId,row_status,row_id
                 FROM
                (SELECT 
    mdms.store_total_sales_area,
    mdms.number_of_floors,
    mdms.non_dispensing_sales_area,
    mdms.baby_changing_room_area,
    mdms.customer_toilets_area,
    mdms.health_clinic_area,
    mdms.opticans_off_sales_area,
	mdms.opticans_on_sales_area,
	mdms.pharmacy_consultation_area,
	mdms.photolab_off_sales_area,
	mdms.photolab_on_sales_area,
	sr.SiteRoleId as SiteRoleID,
	mdms.record_source_id as LOVRecordSourceId,
	CONVERT (date, GETDATE()) as SCDStartDate ,
    @record_source_id as SCDLOVRecordSourceId,
	mdms.etl_runlog_id as ETLRunLogId,
	mdms.row_status as row_status,
	mdms.row_id as row_id
  FROM psa.rawuk_btc_mdm_store mdms ,ser.SiteRole sr 
  WHERE cast(mdms.store_number  as varchar)=sr.SourceKey and sr.LOVRecordSourceId=@record_source_id and sr.SCDActiveFlag='Y' 
  and mdms.row_status=@row_status 
   AND mdms.etl_runlog_id in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,','))
)t
	 UNPIVOT
(PIValue FOR PICol in         (t.store_total_sales_area,
                                t.number_of_floors,
                                t.non_dispensing_sales_area,
                                t.baby_changing_room_area,
                                t.customer_toilets_area,
                                t.health_clinic_area,
                                t.opticans_off_sales_area,
								t.opticans_on_sales_area,
								t.pharmacy_consultation_area,
								t.photolab_off_sales_area,
								t.photolab_on_sales_area))AS LOVGroupId  )pvt 
								LEFT JOIN ser.SiteRoleProperty SRG  on pvt.SiteRoleId=SRG.SiteRoleId
								--AND 
			--pvt.MeasureId=SRG.MeasureId 
			AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId AND SRG.SCDActiveFlag='Y' 
			where pvt.Value is not NULL AND  pvt.Value!=''

--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.SiteRoleProperty SET SCDActiveFlag= 'N',  SCDEndDate=DATEADD(second,-1,INS.SCDStartDate )
FROM ser.SiteRoleProperty SRGrp JOIN 
(SELECT *         					
 FROM ser.SiteRoleProperty_STG STAGE  WHERE STAGE.SCDActiveFlag='Y' AND STAGE.existsFlag=1 )INS
ON 
SRGrp.SiteRoleId=INS.SiteRoleId AND SRGrp.MeasureId=INS.MeasureId
AND SRGrp.SCDActiveFlag='Y' AND SRGrp.lovRecordSourceId=INS.lovRecordSourceId

--Inserting data to table with existing version increment by 1 and new record version as 1.
Insert INTO [ser].[SiteRoleProperty] (SiteRoleId,          
  MeasureId,           
  LOVUOMId,            
  Value,
  LOVRecordSourceId,
  SCDStartDate,        
  SCDEndDate ,      
  SCDActiveFlag,       
  SCDVersion,          
  SCDLOVRecordSourceId,
  ETLRunLogID,PsaRowKey)
 SELECT STAGE.[SiteRoleId] ,
 STAGE.[MeasureId],STAGE.[LOVUOMId] ,
 STAGE.[Value],STAGE.[LOVRecordSourceId] ,STAGE.[SCDStartDate] , STAGE.SCDEndDate,				 
 STAGE.[SCDActiveFlag] , STAGE.SCDVersion +1 ,@SCDLOVRecordSourceId SCDLOVRecordSourceId,
 @serveETLRunLogId  ETLRunLogId,STAGE.row_id FROM (
SELECT *  FROM ser.SiteRoleProperty_STG    STG WHERE STG.SCDActiveFlag='Y' )STAGE
			
PRINT 'Info: SITEROLE PROPERTY Table Loaded Successfully '; 
-----------------------------------------TABLE14-SITEROLEINDICATOR---------------------------------------------------
PRINT 'Info: SITEROLE INDICATOR Table Load Started '; 

--create staging table
INSERT INTO [ser].[SiteRoleIndicator_STG]([ExistsFlag],[SiteRoleId],[LOVIndicatorId],[Value],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId],[ETLRunLogId],[row_id])
   
                SELECT CASE WHEN SRG.SiteRoleId is  NULL AND SRG.LOVIndicatorId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag, 
				pvt.SiteRoleId, 
				pvt.LOVIndicatorId,
				pvt.Value,
				pvt.LOVRecordSourceId,
				case when SRG.SiteRoleId is  NULL THEN @SCDStartDate_new ELSE @SCDStartDate END SCDStartDate,
				LEAD(pvt.SCDStartDate,1,CONVERT(DATETIME,'99991231') )OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVIndicatorId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC)	AS SCDEndDate,
                LEAD('N', 1,'Y') OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVIndicatorId,pvt.LOVRecordSourceId ORDER BY pvt.SCDStartDate ASC) SCDActiveFlag
                 ,COALESCE(SRG.SCDVersion,0) SCDVersion,pvt.SCDLOVRecordSourceId,@serveETLRunLogID ETLRunLogId ,pvt.row_id 
                 FROM
                 (
                    SELECT SiteRoleID,
       (SELECT LOVId FROM ser.RefLOV WHERE LOVKey = ''+PICol+'' AND 
       
      LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = 'Indicator - BUK MDM Site' )) LOVIndicatorId,
	  PIValue as value ,LOVRecordSourceId,SCDStartDate,
	       SCDLOVRecordSourceId,ETLRunLogId,row_id
							FROM
								(SELECT sr.SiteRoleId,
								cast(midnight_pharmacy as varchar(50)) midnight_pharmacy,
								cast(nhs_contract_flag as varchar(50)) nhs_contract_flag,
								cast(mds_room_flag as varchar(50)) mds_room_flag,
								cast(uk_ind as varchar(50)) uk_ind,
								cast(roi_ind as varchar(50)) roi_ind,
								cast(online_ind as varchar(50)) online_ind,
								cast(optician_ind as varchar(50)) optician_ind,
								mdms.record_source_Id LOVRecordSourceId,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								CONVERT (date, GETDATE()) as SCDStartDate ,
								null ETLRunLogId,
								mdms.row_id row_id
								FROM psa.rawuk_btc_mdm_store mdms,
									 ser.SiteRole sr
								WHERE CAST (mdms.store_number as VARCHAR)=sr.SourceKey
									AND mdms.row_status=@row_status
									AND sr.SCDActiveFlag='Y' AND mdms.record_source_id=sr.LovrecordSourceId
									AND  mdms.etl_runlog_id in  (SELECT value FROM STRING_SPLIT(@PSAETLRunLogID, ','))
									 ) t
								unpivot
(
  PIValue FOR PICol in    
    (uk_ind,roi_ind,online_ind,optician_ind,midnight_pharmacy,nhs_contract_flag,mds_room_flag)
) as unpiv  )pvt LEFT JOIN ser.SiteRoleIndicator SRG  on pvt.SiteRoleId=SRG.SiteRoleId AND
            pvt.LOVIndicatorId=SRG.LOVIndicatorId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId AND SRG.SCDActiveFlag='Y'   
			where pvt.Value is not NULL AND  pvt.Value!=''

--select * from #SiteRoleIndicator_STG
--updating existing records in table with SCDActiveFlag as 'N' and SCDEndDate as currentdate
UPDATE ser.SiteRoleIndicator SET SCDActiveFlag= 'N', SCDEndDate=DATEADD(second,-1,INS.SCDStartDate )
FROM ser.SiteRoleIndicator SRGrp JOIN 
(SELECT *         					
 FROM ser.SiteRoleIndicator_STG STAGE  WHERE STAGE.SCDActiveFlag='Y' AND STAGE.existsFlag=1 )INS
ON 
SRGrp.SiteRoleId=INS.SiteRoleId AND SRGrp.LOVIndicatorId=INS.LOVIndicatorId
AND SRGrp.SCDActiveFlag='Y' AND SRGrp.lovRecordSourceId=INS.lovRecordSourceId

--Inserting data to table with existing version increment by 1 and new record version as 1.
Insert INTO [ser].[SiteRoleIndicator] (SiteRoleId,          
  LOVIndicatorId,            
  Value,
  LOVRecordSourceId,
  SCDStartDate,
  SCDEndDate,  
  SCDActiveFlag,       
  SCDVersion,          
  SCDLOVRecordSourceId,
  ETLRunLogID,PsaRowKey)
  SELECT STAGE.[SiteRoleId] ,
 STAGE.[LOVIndicatorId],
 STAGE.[Value],STAGE.[LOVRecordSourceId] ,STAGE.[SCDStartDate] , STAGE.SCDEndDate,				 
 STAGE.[SCDActiveFlag] , STAGE.SCDVersion +1 ,@SCDLOVRecordSourceId SCDLOVRecordSourceId,
 @serveETLRunLogId  ETLRunLogId,STAGE.row_id FROM (
SELECT *  FROM ser.SiteRoleIndicator_STG    STG WHERE STG.SCDActiveFlag='Y' )STAGE
--drop staging table			
--drop table #SiteRoleIndicator_STG
				

PRINT 'Info: SiteRoleIndicator Table Loaded Successfully ';   

/********************************************************************************************************************************
	Update Source Table  :psa.rawuk_btc_mdm_store
	Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
**********************************************************************************************************************************/
PRINT '********************Updating Source Table accordingly -> psa.rawuk_btc_mdm_store****************';  



    UPDATE psa.rawuk_btc_mdm_store SET row_status=@serRowStatus
	FROM psa.rawuk_btc_mdm_store mdms 
	Inner Join ser.SiteRole sr ON  mdms.record_source_id=sr.LovRecordSourceID  and mdms.store_number=sr.SourceKey
	WHERE mdms.row_status=@row_status and mdms.row_id=sr.PSARowKey 
	--and sr.LovRecordSourceID =@record_source_id
		

		PRINT 'Info: Source Table Updated accordingly -> psa.rawuk_btc_mdm_store'; 
COMMIT TRANSACTION;
END TRY
BEGIN CATCH 
	 THROW ; 	       
	 ROLLBACK TRANSACTION ;
END CATCH 
--droping
drop table ser.PostalAddress_STG
drop table ser.PostalAddress_SiteProperty_STG
drop table ser.SiteRoleGrp_STG
drop table ser.PartyRoleSiteRoleRelationship_STG
drop table ser.SiteRoleContactMethod_STG
drop table ser.SiteRoleTerritory_STG
drop table ser.SiteRoleStatus_STG
drop table ser.SiteRoleProperty_STG
drop table ser.SiteProperty_STG
drop table ser.SiteRoleIndicator_STG


--PRINT 'Info: SiteRoleGroup Table Loaded Successfully ';  
END 
GO
/****** Object:  StoredProcedure [psa].[sp_transaction_convert_to_nullstring]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
************************************************************************************************************
Procedure Name							: sp_transaction_convert_to_nullstring
Purpose									: Delete from Serve table and update data in PSA table for encrypted 'NULL' value in customer_identifier, customer_number,other_customer_id
Domain									: Transaction
ServeLayer Target Tables	 			: LoyaltyAccount, TransactionLoyaltyAccount, international source table 
RecordSourceID  for  Transaction		: 12001,12004,12005,12010

**************************************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
*/

IF OBJECT_ID('psa.sp_transaction_convert_to_nullstring') IS NOT NULL
BEGIN
	DROP PROC psa.sp_transaction_convert_to_nullstring
END
GO

CREATE PROC [psa].[sp_transaction_convert_to_nullstring] @serveETLRunLogID VARCHAR(MAX), @tablename VARCHAR(MAX), @psaEntityId VARCHAR(MAX) AS

BEGIN

BEGIN TRY
BEGIN TRANSACTION

/*------  Delete for Serve tables ---------*/
DELETE FROM ser.TransactionLoyaltyAccount
WHERE LoyaltyAccountId IN (SELECT LoyaltyAccountId FROM ser.LoyaltyAccount 
WHERE sourcekey = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
AND LOVRecordSourceId IN (12001,12004,12005,12010))
AND LOVRecordSourceId IN (12001,12004,12005,12010) 
;

RAISERROR ('Completed deletion of TransactionLoyaltyAccount IN SERV', 0, 1) WITH NOWAIT

DELETE FROM ser.LoyaltyAccount
WHERE sourcekey = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g=='
AND LOVRecordSourceId IN (12001,12004,12005,12010) 
;

RAISERROR ('Completed deletion of LoyaltyAccount IN SERV', 0, 1) WITH NOWAIT

/*----  Updates for PSA tables  -----*/
UPDATE psa.no_crp_item_transaction 
SET customer_identifier = 'NULL'
WHERE customer_identifier = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;
UPDATE psa.no_crp_item_transaction 
SET customer_number = 'NULL'
WHERE customer_number = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;
UPDATE psa.no_crp_item_transaction 
SET other_customer_id = 'NULL'
WHERE other_customer_id = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;

RAISERROR ('Completed update of Norway psa table', 0, 1) WITH NOWAIT

UPDATE psa.cl_crp_item_transaction 
SET customer_identifier = 'NULL'
WHERE customer_identifier = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;
UPDATE psa.cl_crp_item_transaction 
SET customer_number = 'NULL'
WHERE customer_number = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;
UPDATE psa.cl_crp_item_transaction 
SET other_customer_id = 'NULL'
WHERE other_customer_id = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;

RAISERROR ('Completed update of Chile psa table', 0, 1) WITH NOWAIT

UPDATE psa.mx_crp_item_transaction 
SET customer_identifier = 'NULL'
WHERE customer_identifier = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;
UPDATE psa.mx_crp_item_transaction 
SET customer_number = 'NULL'
WHERE customer_number = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;
UPDATE psa.mx_crp_item_transaction 
SET other_customer_id = 'NULL'
WHERE other_customer_id = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;

RAISERROR ('Completed update of Mexico psa table', 0, 1) WITH NOWAIT

UPDATE psa.th_crp_item_transaction 
SET customer_identifier = 'NULL'
WHERE customer_identifier = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;
UPDATE psa.th_crp_item_transaction 
SET customer_number = 'NULL'
WHERE customer_number = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;
UPDATE psa.th_crp_item_transaction 
SET other_customer_id = 'NULL'
WHERE other_customer_id = 'MIGvBgkqhkiG9w0BBwaggaEwgZ4CAQAwgZgGCSqGSIb3DQEHATB5BgpghkgBhv0eBQEGMGsEAAxnQVBQX1JXX0FQUF9DRVAtUFJPRC1WT0xUQUdFX0NEUl9QSElEQVRBOjA3MDEwMTAwMDAwMFo6cHJvZC5nY3AuYm9vdHMuY29tIzE1NDg3ODc0Nzc6ZGF0YTpBRVMtRU1FUzoyNTY6OoAQZ99skeXOpru2P+O6F2EP4g==' 
;

RAISERROR ('Completed update of Thailand psa table', 0, 1) WITH NOWAIT

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
DECLARE @error_num VARCHAR(MAX),
		@error_msg VARCHAR(MAX),
		@error_sev VARCHAR(MAX)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

END;
GO
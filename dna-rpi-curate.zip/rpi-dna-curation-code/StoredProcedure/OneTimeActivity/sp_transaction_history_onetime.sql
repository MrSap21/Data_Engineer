/****** Object:  StoredProcedure [psa].[sp_transaction_history_onetime]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
************************************************************************************************************
Procedure Name							: sp_transaction_history_onetime
Purpose									: One time Load and update of history data into transaction Serve Layer Table
Domain									: Transaction
ServeLayer Target Tables	 			: TransactionGroup, TransactionLineItem, TransactionLineItemMeasure, LoyaltyAccount, TransactionLoyaltyAccount
RecordSourceID  for  Transaction		: 12001,12004,12005,12006,12010

**************************************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
*/

IF OBJECT_ID('psa.sp_transaction_history_onetime') IS NOT NULL
BEGIN
	DROP PROC psa.sp_transaction_history_onetime
END
GO

CREATE PROC [psa].[sp_transaction_history_onetime] @serveETLRunLogID VARCHAR(MAX), @tablename VARCHAR(MAX), @psaEntityId VARCHAR(MAX) AS

BEGIN

BEGIN TRY
BEGIN TRANSACTION

/*--- Update data into TransactionLineItem Table set lineitemtypeid to NULL in  History load -----*/
UPDATE ser.TransactionLineItem SET LOVLineItemTypeId = NULL WHERE LOVRecordSourceId IN (12001,12004,12005,12006,12010) AND SCDLOVRecordSourceId = 151;

RAISERROR ('Completed update of TransactionLineItem IN SERV', 0, 1) WITH NOWAIT

/*--- Update data into TransactionLineitemmeasure table for lovuomid field ---*/
DECLARE	@measureTypeID BIGINT;
DECLARE	@units_measureID BIGINT;
DECLARE	@tisp_measureID	BIGINT;
DECLARE	@tesp_measureID BIGINT;
DECLARE	@eposprofit_measureID BIGINT;
DECLARE	@discountappl_measureID BIGINT;
DECLARE @units_lovuomID BIGINT;
DECLARE @others_lovuomID BIGINT;
DECLARE @uklc_lovuomidgbp BIGINT;

SET @uklc_lovuomidgbp = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Currency ISO 4217' AND lovkey = 'GBP');
UPDATE ser.TransactionLineItemMeasure SET LOVUOMId = @uklc_lovuomidgbp WHERE LOVRecordSourceId = 12006 AND SCDLOVRecordSourceId = 151;

SET @measureTypeID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Measure Type' AND lovkey = 'RETAIL_TRANS_AGG');
SET @units_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'units' AND LOVRecordSourceId = 12004);
SET @tisp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tisp' AND LOVRecordSourceId = 12004);
SET @tesp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tesp' AND LOVRecordSourceId = 12004);
SET @eposprofit_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'epos_profit' AND LOVRecordSourceId = 12004);
SET @discountappl_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'discount_applied' AND LOVRecordSourceId = 12004);

SET @units_lovuomID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Unit Of Measure' AND lovkey = 'Unit');
UPDATE ser.TransactionLineItemMeasure 
SET LOVUOMId = @units_lovuomID 
WHERE MeasureId = @units_measureID 
AND LOVRecordSourceId IN (12004) 
AND SCDLOVRecordSourceId = 151;

SET @others_lovuomID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Currency ISO 4217' AND lovkey = 'MXN' AND LOVRecordSourceID = 12012);
UPDATE ser.TransactionLineItemMeasure 
SET LOVUOMId = @others_lovuomID 
WHERE MeasureId IN (@tisp_measureID,@tesp_measureID,@eposprofit_measureID,@discountappl_measureID) 
AND LOVRecordSourceId IN (12004) 
AND SCDLOVRecordSourceId = 151;

RAISERROR ('Completed update of TransactionLineItemMeasure for Mexico IN SERV', 0, 1) WITH NOWAIT

SET @units_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'units' AND LOVRecordSourceId = 12005);
SET @tisp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tisp' AND LOVRecordSourceId = 12005);
SET @tesp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tesp' AND LOVRecordSourceId = 12005);
SET @eposprofit_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'epos_profit' AND LOVRecordSourceId = 12005);
SET @discountappl_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'discount_applied' AND LOVRecordSourceId = 12005);

UPDATE ser.TransactionLineItemMeasure 
SET LOVUOMId = @units_lovuomID 
WHERE MeasureId = @units_measureID 
AND LOVRecordSourceId IN (12005) 
AND SCDLOVRecordSourceId = 151;

SET @others_lovuomID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Currency ISO 4217' AND lovkey = 'NOK' AND LOVRecordSourceID = 12012);
UPDATE ser.TransactionLineItemMeasure 
SET LOVUOMId = @others_lovuomID 
WHERE MeasureId IN (@tisp_measureID,@tesp_measureID,@eposprofit_measureID,@discountappl_measureID) 
AND LOVRecordSourceId IN (12005) 
AND SCDLOVRecordSourceId = 151;

RAISERROR ('Completed update of TransactionLineItemMeasure for Norway IN SERV', 0, 1) WITH NOWAIT

SET @units_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'units' AND LOVRecordSourceId = 12001);
SET @tisp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tisp' AND LOVRecordSourceId = 12001);
SET @tesp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tesp' AND LOVRecordSourceId = 12001);
SET @eposprofit_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'epos_profit' AND LOVRecordSourceId = 12001);
SET @discountappl_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'discount_applied' AND LOVRecordSourceId = 12001);

UPDATE ser.TransactionLineItemMeasure 
SET LOVUOMId = @units_lovuomID 
WHERE MeasureId = @units_measureID 
AND LOVRecordSourceId IN (12001) 
AND SCDLOVRecordSourceId = 151;

SET @others_lovuomID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Currency ISO 4217' AND lovkey = 'CLP' AND LOVRecordSourceID = 12012);
UPDATE ser.TransactionLineItemMeasure 
SET LOVUOMId = @others_lovuomID 
WHERE MeasureId IN (@tisp_measureID,@tesp_measureID,@eposprofit_measureID,@discountappl_measureID) 
AND LOVRecordSourceId IN (12001) 
AND SCDLOVRecordSourceId = 151;

RAISERROR ('Completed update of TransactionLineItemMeasure for Chile IN SERV', 0, 1) WITH NOWAIT

SET @units_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'units' AND LOVRecordSourceId = 12010);
SET @tisp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tisp' AND LOVRecordSourceId = 12010);
SET @tesp_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'tesp' AND LOVRecordSourceId = 12010);
SET @eposprofit_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'epos_profit' AND LOVRecordSourceId = 12010);
SET @discountappl_measureID = (SELECT measureID FROM ser.Measure measure WHERE lovmeasureTypeId = @measureTypeID AND MeasureName = 'discount_applied' AND LOVRecordSourceId = 12010);

UPDATE ser.TransactionLineItemMeasure 
SET LOVUOMId = @units_lovuomID 
WHERE MeasureId = @units_measureID 
AND LOVRecordSourceId IN (12010) 
AND SCDLOVRecordSourceId = 151;

SET @others_lovuomID = (SELECT lovid FROM ser.RefLovSetInfo WHERE lovsetname = 'Currency ISO 4217' AND lovkey = 'THB' AND LOVRecordSourceID = 12012);
UPDATE ser.TransactionLineItemMeasure 
SET LOVUOMId = @others_lovuomID 
WHERE MeasureId IN (@tisp_measureID,@tesp_measureID,@eposprofit_measureID,@discountappl_measureID) 
AND LOVRecordSourceId IN (12010) 
AND SCDLOVRecordSourceId = 151;

RAISERROR ('Completed update of TransactionLineItemMeasure for Thailand IN SERV', 0, 1) WITH NOWAIT
RAISERROR ('Completed update of TransactionLineItemMeasure and TransactionLineItem IN SERV', 0, 1) WITH NOWAIT

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
DECLARE @error_num VARCHAR(MAX),
		@error_msg VARCHAR(MAX),
		@error_sev VARCHAR(MAX)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

BEGIN TRY
BEGIN TRANSACTION

/*--- Insert data into TRANSACTIONGROUP table from INT tables ---*/
DECLARE	@max_transactionGroupID BIGINT;
DECLARE	@salestypeRefLOVSetID BIGINT;

/*--- Insert data into TRANSACTIONGROUP table from psa.rawno_crp_item_transaction ---*/

SELECT 	@max_transactionGroupID = COALESCE(MAX(TransactionGroupId),0) FROM ser.TransactionGroup;
SET @salestypeRefLOVSetID = (SELECT DISTINCT lovsetid FROM ser.RefLovSetInfo WHERE lovsetname = 'sales_type' AND LOVRecordSourceID = 12005);

INSERT INTO ser.TransactionGroup(
	TransactionGroupId		,
	TransactionId			,
	LOVTransactionGroupSetId,
	LOVGroupId				,
	ParentTransactionGroupId,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

SELECT 
@max_transactionGroupID+ROW_NUMBER() OVER(ORDER BY A.TransactionId) TransactionGroupId, 
A.TransactionId TransactionId,
@salestypeRefLOVSetID LOVTransactionGroupSetId, 
ro.LOVId LOVGroupId, 
NULL ParentTransactionGroupId, 
12005 LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
151 SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
row_id PSARowKey 
FROM
(SELECT sourcekey,TransactionId, LOVRecordSourceId, sales_type,transaction_date,transaction_time,transactiondatetime, date_added,row_id,record_source_id FROM ser.[Transaction] trans 
JOIN (SELECT ROW_NUMBER() OVER(PARTITION BY transaction_key, transaction_date, transaction_time ORDER BY transaction_key, sales_type) row_num, 
transaction_key, sales_type, ISNULL(date_added,'19000101') date_added,row_id, record_source_id,transaction_date,
CASE WHEN transaction_time LIKE '%[A-Za-z]%' OR transaction_time IS NULL OR TRIM(transaction_time) = '' THEN '000000' ELSE transaction_time END transaction_time
FROM psa.rawno_crp_item_transaction WHERE row_status = 26002 AND sales_type IS NOT NULL AND TRIM(sales_type) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)noitemtrans ON trans.sourcekey = noitemtrans.transaction_key AND trans.SCDActiveFlag = 'Y' AND noitemtrans.row_num = 1
AND CONVERT(datetime, CONCAT(SUBSTRING(noitemtrans.transaction_date,1,4),'-',SUBSTRING(noitemtrans.transaction_date,5,2),'-',SUBSTRING(noitemtrans.transaction_date,7,2),' ',SUBSTRING(noitemtrans.transaction_time,1,2),':',SUBSTRING(noitemtrans.transaction_time,3,2),':',SUBSTRING(noitemtrans.transaction_time,5,2)),120) = trans.transactiondatetime
WHERE trans.TransactionId IS NOT NULL AND trans.LOVRecordSourceId=12005) A
JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'sales_type'
AND ro.LOVKey=A.sales_type
AND A.LOVRecordSourceId = ro.LOVRecordSourceId
LEFT OUTER JOIN ser.TransactionGroup transgroup
ON A.transactionId = transgroup.transactionId
AND @salestypeRefLOVSetID = transgroup.LOVTransactionGroupSetId
AND A.record_source_id = transgroup.LOVRecordSourceID
WHERE transgroup.transactionId IS NULL
;

RAISERROR ('Completed insertion of TransactionGroup for Norway IN SERV', 0, 1) WITH NOWAIT

/*--- Insert data into TRANSACTIONGROUP table from psa.rawmx_crp_item_transaction ---*/

SELECT 	@max_transactionGroupID = COALESCE(MAX(TransactionGroupId),0) FROM ser.TransactionGroup;
SET @salestypeRefLOVSetID = (SELECT DISTINCT lovsetid FROM ser.RefLovSetInfo WHERE lovsetname = 'sales_type' AND LOVRecordSourceID = 12004);

INSERT INTO ser.TransactionGroup(
	TransactionGroupId		,
	TransactionId			,
	LOVTransactionGroupSetId,
	LOVGroupId				,
	ParentTransactionGroupId,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

SELECT 
@max_transactionGroupID+ROW_NUMBER() OVER(ORDER BY A.TransactionId) TransactionGroupId, 
A.TransactionId TransactionId,
@salestypeRefLOVSetID LOVTransactionGroupSetId, 
ro.LOVId LOVGroupId, 
NULL ParentTransactionGroupId, 
12004 LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
151 SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
row_id PSARowKey 
FROM
(SELECT sourcekey,TransactionId, LOVRecordSourceId, sales_type,transaction_date,transaction_time,transactiondatetime, date_added,row_id,record_source_id FROM ser.[Transaction] trans 
JOIN (SELECT ROW_NUMBER() OVER(PARTITION BY transaction_key, transaction_date, transaction_time ORDER BY transaction_key, sales_type) row_num, 
transaction_key, sales_type, ISNULL(date_added,'19000101') date_added,row_id, record_source_id,transaction_date,
CASE WHEN transaction_time LIKE '%[A-Za-z]%' OR transaction_time IS NULL OR TRIM(transaction_time) = '' THEN '00:00' ELSE transaction_time END transaction_time
FROM psa.rawmx_crp_item_transaction WHERE row_status = 26002 AND sales_type IS NOT NULL AND TRIM(sales_type) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans ON trans.sourcekey = mxitemtrans.transaction_key AND trans.SCDActiveFlag = 'Y' AND mxitemtrans.row_num = 1
AND CONVERT(datetime, CONCAT(SUBSTRING(mxitemtrans.transaction_date,1,4),'-',SUBSTRING(mxitemtrans.transaction_date,5,2),'-',SUBSTRING(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
WHERE trans.TransactionId IS NOT NULL AND trans.LOVRecordSourceId=12004) A
JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'sales_type'
AND ro.LOVKey=A.sales_type
AND A.LOVRecordSourceId = ro.LOVRecordSourceId
LEFT OUTER JOIN ser.TransactionGroup transgroup
ON A.transactionId = transgroup.transactionId
AND @salestypeRefLOVSetID = transgroup.LOVTransactionGroupSetId
AND A.record_source_id = transgroup.LOVRecordSourceID
WHERE transgroup.transactionId IS NULL
;

RAISERROR ('Completed insertion of TransactionGroup for Mexico IN SERV', 0, 1) WITH NOWAIT

/*--- Insert data into TRANSACTIONGROUP table from psa.rawcl_crp_item_transaction ---*/

SELECT 	@max_transactionGroupID = COALESCE(MAX(TransactionGroupId),0) FROM ser.TransactionGroup;
SET @salestypeRefLOVSetID = (SELECT DISTINCT lovsetid FROM ser.RefLovSetInfo WHERE lovsetname = 'sales_type' AND LOVRecordSourceID = 12001);

INSERT INTO ser.TransactionGroup(
	TransactionGroupId		,
	TransactionId			,
	LOVTransactionGroupSetId,
	LOVGroupId				,
	ParentTransactionGroupId,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

SELECT 
@max_transactionGroupID+ROW_NUMBER() OVER(ORDER BY A.TransactionId) TransactionGroupId, 
A.TransactionId TransactionId,
@salestypeRefLOVSetID LOVTransactionGroupSetId, 
ro.LOVId LOVGroupId, 
NULL ParentTransactionGroupId, 
12001 LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
151 SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
row_id PSARowKey 
FROM
(SELECT sourcekey,TransactionId, LOVRecordSourceId, sales_type,transaction_date,transaction_time,transactiondatetime, date_added,row_id,record_source_id FROM ser.[Transaction] trans 
JOIN (SELECT ROW_NUMBER() OVER(PARTITION BY transaction_key, transaction_date, transaction_time ORDER BY transaction_key, sales_type) row_num, 
transaction_key, sales_type, ISNULL(date_added,'19000101') date_added,row_id, record_source_id,transaction_date,
CASE WHEN transaction_time LIKE '%[A-Za-z]%' OR transaction_time IS NULL OR TRIM(transaction_time) = '' THEN '00:00:00' ELSE transaction_time END transaction_time
FROM psa.rawcl_crp_item_transaction WHERE row_status = 26002 AND sales_type IS NOT NULL AND TRIM(sales_type) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)clitemtrans ON trans.sourcekey = clitemtrans.transaction_key AND trans.SCDActiveFlag = 'Y' AND clitemtrans.row_num = 1
AND CAST(CONCAT(clitemtrans.transaction_date,' ',clitemtrans.transaction_time) as Datetime) = trans.TransactionDatetime
WHERE trans.TransactionId IS NOT NULL AND trans.LOVRecordSourceId=12001) A
JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'sales_type'
AND ro.LOVKey=A.sales_type
AND A.LOVRecordSourceId = ro.LOVRecordSourceId
LEFT OUTER JOIN ser.TransactionGroup transgroup
ON A.transactionId = transgroup.transactionId
AND @salestypeRefLOVSetID = transgroup.LOVTransactionGroupSetId
AND A.record_source_id = transgroup.LOVRecordSourceID
WHERE transgroup.transactionId IS NULL
;

RAISERROR ('Completed insertion of TransactionGroup for Chile IN SERV', 0, 1) WITH NOWAIT

/*--- Insert data into TRANSACTIONGROUP table from psa.rawth_crp_item_transaction ---*/
SELECT 	@max_transactionGroupID = COALESCE(MAX(TransactionGroupId),0) FROM ser.TransactionGroup;
SET @salestypeRefLOVSetID = (SELECT DISTINCT lovsetid FROM ser.RefLovSetInfo WHERE lovsetname = 'sales_type' AND LOVRecordSourceID = 12010);

INSERT INTO ser.TransactionGroup(
	TransactionGroupId		,
	TransactionId			,
	LOVTransactionGroupSetId,
	LOVGroupId				,
	ParentTransactionGroupId,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

SELECT 
@max_transactionGroupID+ROW_NUMBER() OVER(ORDER BY A.TransactionId) TransactionGroupId, 
A.TransactionId TransactionId,
@salestypeRefLOVSetID LOVTransactionGroupSetId, 
ro.LOVId LOVGroupId, 
NULL ParentTransactionGroupId, 
12010 LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
151 SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
row_id PSARowKey 
FROM
(SELECT sourcekey,TransactionId, LOVRecordSourceId, sales_type,transaction_date,transaction_time,transactiondatetime, date_added,row_id,record_source_id FROM ser.[Transaction] trans 
JOIN (SELECT ROW_NUMBER() OVER(PARTITION BY transaction_key, transaction_date, transaction_time ORDER BY transaction_key, sales_type) row_num, 
transaction_key, sales_type, ISNULL(date_added,'19000101') date_added,row_id, record_source_id,transaction_date,
CASE WHEN transaction_time LIKE '%[A-Za-z]%' OR transaction_time IS NULL OR TRIM(transaction_time) = '' THEN '00:00:00' ELSE transaction_time END transaction_time
FROM psa.rawth_crp_item_transaction WHERE row_status = 26002 AND sales_type IS NOT NULL AND TRIM(sales_type) != ''
--AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)thitemtrans ON trans.sourcekey = thitemtrans.transaction_key AND trans.SCDActiveFlag = 'Y' AND thitemtrans.row_num = 1
AND CAST(CONCAT(thitemtrans.transaction_date,' ',thitemtrans.transaction_time) as Datetime) = trans.TransactionDatetime
WHERE trans.TransactionId IS NOT NULL AND trans.LOVRecordSourceId=12010) A
JOIN ser.RefLOVSetInfo ro
ON ro.LOVSetName = 'sales_type'
AND ro.LOVKey=A.sales_type
AND A.LOVRecordSourceId = ro.LOVRecordSourceId
LEFT OUTER JOIN ser.TransactionGroup transgroup
ON A.transactionId = transgroup.transactionId
AND @salestypeRefLOVSetID = transgroup.LOVTransactionGroupSetId
AND A.record_source_id = transgroup.LOVRecordSourceID
WHERE transgroup.transactionId IS NULL
;

RAISERROR ('Completed insertion of TransactionGroup for Thailand IN SERV', 0, 1) WITH NOWAIT

/*--- Insert data into TRANSACTIONGROUP table from BUKROI tables ---*/

DECLARE	@uklc_lovRecordSourceID BIGINT;
DECLARE	@uklc_scdLovRecordSourceID BIGINT;
DECLARE	@psa_rowstatus BIGINT;
DECLARE	@max_trangroupid BIGINT;
DECLARE	@uk_trangroupsetid BIGINT;

SET @uklc_lovRecordSourceID = 12006; 
SET @uklc_scdLovRecordSourceID = 151; 
SET @psa_rowstatus = 26002; 

/*--- Insert data into TRANSACTIONGROUP table from psa.rawuk_btc_transaction_line_anon_p ---*/

SET @max_trangroupid = (SELECT COALESCE(MAX(TransactionGroupId),0) FROM  [ser].[TransactionGroup]);
SET @uk_trangroupsetid = (select distinct lovsetid from ser.reflovsetinfo where LOVsetname = 'till_transaction_type_code' and lovrecordsourceid = 12006); 

INSERT INTO [ser].[TransactionGroup] (TransactionGroupId, TransactionId, LOVTransactionGroupSetId, LOVGroupId, ParentTransactionGroupId, LOVRecordSourceId,  SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_trangroupid + ROW_NUMBER() OVER(ORDER BY A.TransactionId ASC) TransactionGroupId, 
        A.TransactionId TransactionId,
        @uk_trangroupsetid LOVTransactionGroupSetId, 
        A.lovid LOVGroupId, 
        null ParentTransactionGroupId, 
        12006 LOVRecordSourceId,
        '1900-01-01' SCDStartDate, 
        '9999-12-31' SCDEndDate, 
        'Y' SCDActiveFlag, 
        1 SCDVersion, 
        @uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
        @serveETLRunLogID ETLRunLogId,
        A.row_num PSARowKey from
(
SELECT T.TransactionId, src.row_num, R.lovid from 
(SELECT epos_transaction_key, store_number, till_transaction_number, till_transaction_date, till_transaction_time, record_source_id, till_transaction_type_code, till_number, MIN(row_id) row_num 
from psa.rawuk_btc_transaction_line_anon_p 
    where row_status = @psa_rowstatus 
    and till_transaction_type_code is not null and till_transaction_type_code != '' 
    group by epos_transaction_key, store_number, till_transaction_number, till_transaction_date, till_transaction_time, record_source_id, till_transaction_type_code,till_number
)src
JOIN [ser].[TRANSACTION] T on
    src.epos_transaction_key = T.sourcekey and
    T.LOVRecordSourceId = 12006 and 
    CAST (CONCAT(src.till_transaction_date,' ',src.till_transaction_time) as Datetime) = T.TransactionDatetime 
JOIN ser.reflovsetinfo R on
    R.lovkey = src.till_transaction_type_code and 
    R.lovsetid = @uk_trangroupsetid
LEFT OUTER JOIN [ser].[TransactionGroup] TG on 
    T.TransactionId = TG.TransactionId and 
    T.LOVRecordSourceId = TG.LOVRecordSourceId and
    @uk_trangroupsetid = TG.LOVTransactionGroupSetId
    where TG.TransactionId IS NULL
) A ;

RAISERROR ('Completed insertion of TransactionGroup for Transaction Line Anon IN SERV', 0, 1) WITH NOWAIT

/*--- Insert data into TRANSACTIONGROUP table from psa.rawuk_btc_transaction_line_card_p ---*/

SET @max_trangroupid = (SELECT COALESCE(MAX(TransactionGroupId),0) FROM  [ser].[TransactionGroup]);

INSERT INTO [ser].[TransactionGroup] (TransactionGroupId, TransactionId, LOVTransactionGroupSetId, LOVGroupId, ParentTransactionGroupId, LOVRecordSourceId,  SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_trangroupid + ROW_NUMBER() OVER(ORDER BY A.TransactionId ASC) TransactionGroupId, 
        A.TransactionId TransactionId,
        @uk_trangroupsetid LOVTransactionGroupSetId, 
        A.lovid LOVGroupId, 
        null ParentTransactionGroupId, 
        12006 LOVRecordSourceId,
        '1900-01-01' SCDStartDate, 
        '9999-12-31' SCDEndDate, 
        'Y' SCDActiveFlag, 
        1 SCDVersion, 
        @uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
        @serveETLRunLogID ETLRunLogId,
        A.row_num PSARowKey from
(
SELECT T.TransactionId, src.row_num, R.lovid from 
(SELECT epos_transaction_key, store_number, till_transaction_number, till_transaction_date, till_transaction_time, record_source_id, till_transaction_type_code, till_number, MIN(row_id) row_num 
from psa.rawuk_btc_transaction_line_card_p 
    where row_status = @psa_rowstatus 
    and till_transaction_type_code is not null and till_transaction_type_code != '' 
    group by epos_transaction_key, store_number, till_transaction_number, till_transaction_date, till_transaction_time, record_source_id, till_transaction_type_code,till_number
)src
JOIN [ser].[TRANSACTION] T on
    src.epos_transaction_key = T.sourcekey and
    T.LOVRecordSourceId = 12006 and 
    CAST (CONCAT(src.till_transaction_date,' ',src.till_transaction_time) as Datetime) = T.TransactionDatetime 
JOIN ser.reflovsetinfo R on
    R.lovkey = src.till_transaction_type_code and 
    R.lovsetid = @uk_trangroupsetid
LEFT OUTER JOIN [ser].[TransactionGroup] TG on 
    T.TransactionId = TG.TransactionId and 
    T.LOVRecordSourceId = TG.LOVRecordSourceId and
    @uk_trangroupsetid = TG.LOVTransactionGroupSetId
    where TG.TransactionId IS NULL
) A 
;

RAISERROR ('Completed insertion of TransactionGroup for Transaction Line Card IN SERV', 0, 1) WITH NOWAIT

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
DECLARE @error_num1 VARCHAR(MAX),
		@error_msg1 VARCHAR(MAX),
		@error_sev1 VARCHAR(MAX)
		;

SELECT  
        @error_num1=ERROR_NUMBER()
        ,@error_sev1=ERROR_SEVERITY()  
         ,@error_msg1=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num1,@error_msg1,@error_sev1)
END CATCH

END;
GO
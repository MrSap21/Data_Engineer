SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_THAILAND_HISTORY') IS NOT NULL
BEGIN
    DROP PROC psa.SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_THAILAND_HISTORY
END
GO

CREATE PROCEDURE [psa].[SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_THAILAND_HISTORY] @psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max) AS
/*
************************************************************************************************************
Procedure Name				: SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_THAILAND_HISTORY
Purpose						: Load History data From International Thailand Source(rawth_crp_planogram) into Serve Layer Table
Domain						: Merchandise
ServeLayer Target Tables	: Fact Instance, Fact Dimension Instance, Fact Measure Instance (Total 3 Tables)
RecordSourceID  for International Thailand : 12010
*****************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
 */ 


BEGIN


	/*--Declarations---*/
	DECLARE @max_FactInstanceId BIGINT;
	DECLARE @rowStatusPSACode BIGINT;	
	DECLARE	@rowStatusSERCode BIGINT;
	DECLARE @th_measuretypeid BIGINT;

	SET @rowStatusPSACode = 26001
	SET @rowStatusSERCode = 26002 

	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_FactInstanceId = COALESCE(MAX(FactInstanceId),0) FROM [ser].[FactInstance];
	

	
	
	
	/*-------------------------------Create temporary source table-------------------------------*/
	
	IF OBJECT_ID('tempdb..#rawth_crp_planogram_temp') is not null
		BEGIN
			DROP TABLE #rawth_crp_planogram_temp
		END
	
	SELECT
	@max_FactInstanceId + (ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS FactInstanceId
    ,*
	INTO #rawth_crp_planogram_temp
	FROM (SELECT * from [psa].[rawth_crp_planogram] where [row_status]=@rowStatusPSACode and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))) a
	;




	BEGIN TRANSACTION;
		BEGIN TRY

	/*--------------------------------Loading Fact Instance table---------------------------------*/
	INSERT INTO [ser].[FactInstance]
	(
	[FactInstanceId]
    ,[FactId]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[FactInstanceId]
		,[FactId]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_fact.FactId AS [FactId]
			,12010 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #rawth_crp_planogram_temp src
			LEFT OUTER JOIN
			(
				SELECT 
				rlrls.LOVId
				,rlrls.LOVKey
				,rlrls.LOVRecordSourceId
				,f.FactId 
				FROM  ser.fact f
				INNER JOIN 
				(
					SELECT 
					rl.LOVId
					,rl.LOVKey
					,rl.LOVRecordSourceId
					FROM ser.RefLOV rl 
					INNER JOIN ser.RefLOVSet rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Fact Type' and rls.Lovsetrecordsourceid = 12012
				) rlrls
				ON rlrls.LOVKey = 'TBC' AND f.LOVFactTypeId = rlrls.LOVId AND f.FactName = 'CRP Planogram' and f.LOVRecordSourceId=12010
			) lkp_fact
			ON  lkp_fact.LOVRecordSourceId = 12012
			
		)a;
		
		RAISERROR ('Completed insertion of International Thailand source data to FACT INSTANCE table', 0, 1) WITH NOWAIT	
	
	/*--------------------------------Loading Fact Dimension Instance table---------------------------------*/
	
	DECLARE @sourcekeytypeid bigint;
	SET @sourcekeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey =  'Thailand Planogram Id(pog_id)' and rlovset.LOVsetname = 'Source Key Type');
	
	INSERT INTO [ser].[FactDimensionInstance]
	([FactInstanceId]
    ,[DimensionId]
    ,[DimensionSurrogateKey]
    ,[DimensionSourceKey]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[FactInstanceId]
		,[DimensionId]
		,[DimensionSurrogateKey]
		,[DimensionSourceKey]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_dim.DimensionId AS [DimensionId]
			,lkp_plan.PlanogramId AS [DimensionSurrogateKey]
			,cast(src.pog_id as varchar(80)) AS [DimensionSourceKey]
			,12010 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM 
			#rawth_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[dimension] lkp_dim
			ON (lkp_dim.name =  'Planogram' AND  lkp_dim.LOVRecordSourceId = 12010)
			LEFT OUTER JOIN
			(select * from [ser].[planogram] where SCDActiveFlag='Y' and Lovrecordsourceid=12010 and lovsourcekeytypeid = @sourcekeytypeid) lkp_plan
			ON (ISNULL(lkp_plan.SourceKey,'DUMMY_POGID_FORNULL') = ISNULL(src.pog_id,'DUMMY_POGID_FORNULL') AND lkp_plan.LOVRecordSourceId = 12010)
			
			UNION
			
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_dim.DimensionId AS [DimensionId]
			,lkp_prod.ProductId AS [DimensionSurrogateKey]
			,cast(src.item_code as varchar(80)) AS [DimensionSourceKey]
			,12010 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM 
			#rawth_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[dimension] lkp_dim
			ON (lkp_dim.name =  'Product' AND  lkp_dim.LOVRecordSourceId = 12010)
			LEFT OUTER JOIN
			(select * from [ser].[product] where SCDActiveFlag = 'Y') lkp_prod
			ON (lkp_prod.SourceKey = cast(src.item_code as varchar(30)) AND lkp_prod.LOVRecordSourceId = 12010)
			
			UNION
			
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_dim.DimensionId AS [DimensionId]
			,lkp_refl.LOVId AS [DimensionSurrogateKey]
			,cast(src.week as varchar(80)) AS [DimensionSourceKey]
			,12010 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM 
			#rawth_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[dimension] lkp_dim
			ON (lkp_dim.name =  'Week' AND  lkp_dim.LOVRecordSourceId = 12010)
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='week' and rls.Lovsetrecordsourceid = 12010) lkp_refl
			ON CAST(src.week AS varchar(255)) = lkp_refl.LOVKey 
		)a
		;
		
		RAISERROR ('Completed insertion of International Thailand source data to FACT DIMENSION INSTANCE table', 0, 1) WITH NOWAIT	
	/*--------------------------------Loading Fact Measure Instance table---------------------------------*/
	SET @th_measuretypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 		'PLANOGRAM_AGGREGATION' and rlovset.LOVsetname = 'Measure Type');
	
	INSERT INTO [ser].[FactMeasureInstance]
	(
	 [FactInstanceId]
    ,[MeasureId]
    ,[Value]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[FactInstanceId]
		,[MeasureId]
		,[Value]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY [SCDStartDate] ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY [SCDStartDate] ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_meas.MeasureId AS [MeasureId]
			,src.facings AS [Value]
			,12010 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #rawth_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[measure] lkp_meas
			ON (lkp_meas.MeasureName = 'facings' AND lkp_meas.LOVRecordSourceId = 12010 and lkp_meas.LOVMeasureTypeId = @th_measuretypeid)
			WHERE src.facings IS NOT NULL AND src.facings <> ''
		)a
		;
		
		RAISERROR ('Completed insertion of International Thailand source data to FACT MEASURE INSTANCE table', 0, 1) WITH NOWAIT	
		
		
	UPDATE [psa].[rawth_crp_planogram] SET [row_status]=@rowStatusSERCode
	FROM [psa].[rawth_crp_planogram] th 
	INNER JOIN [ser].[FactInstance] p ON th.row_id=p.PSARowKey and th.record_source_id=p.LovRecordSourceID 
	WHERE th.row_status=@rowStatusPSACode  AND p.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))
		
	RAISERROR ('Updated Row Status to ''Loaded to Serve'' for psa.[rawth_crp_planogram] International Thailand  ', 0, 1) WITH NOWAIT
	
	
	COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH
				DECLARE @error_num varchar(max),
        				@error_msg varchar(max),
        				@error_sev varchar(max)
        		;
 
				SELECT  
        		@error_num=ERROR_NUMBER()
        		,@error_sev=ERROR_SEVERITY()  
         		,@error_msg=ERROR_MESSAGE() ;  
 
        		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
			END CATCH 
			drop table #rawth_crp_planogram_temp
			PRINT 'Info: Dropped Temp table for International Thailand-> psa.#rawth_crp_planogram_temp'
	END
GO
/****** Object:  StoredProcedure [psa].[sp_rawmx_crp_item_transaction]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
************************************************************************************************************
Procedure Name							: sp_rawmx_crp_item_transaction
Purpose									: Load History data from mexico transaction source table(rawmx.crp_item_transaction) into Serve Layer Table
Domain									: Transaction
ServeLayer Target Tables	 			: Till, SiteRole, Product, ProductIdentifier, Deal, Transaction, TransactionLineItem, TransactionLineItemIndicator, TransactionLineItemMeasure, 
										  Measure, LoyaltyAccount, TransactionLoyaltyAccount
RecordSourceID  for mexico Transaction	: 12004

**************************************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
*/

IF OBJECT_ID('psa.sp_rawmx_crp_item_transaction') IS NOT NULL
BEGIN
	DROP PROC psa.sp_rawmx_crp_item_transaction
END
GO

CREATE PROC [psa].[sp_rawmx_crp_item_transaction] @psaETLRunLogID varchar(max), @serveETLRunLogID BIGINT, @StartVal BIGINT, @EndVal BIGINT AS

	DECLARE	@mx_lovRecordSourceID		 BIGINT,
			@mx_lovPSAStatus    		 BIGINT,
			@mx_scdLovRecordSourceID	 BIGINT,
			@max_tillID				 	 BIGINT,
			@max_siteID 				 BIGINT,
			@max_siteRoleID				 BIGINT,
			@siteId 					 BIGINT,
			@mx_lovRoleId				 BIGINT,
			@max_transactionID			 BIGINT,
			@transactionTypeId 			 BIGINT,
			@mx_lovSourceKeyTypeId 		 BIGINT,
			@max_productID 				 BIGINT,
			@upc_identifierID 			 BIGINT,
			@max_dealID 				 BIGINT,
			@max_transactionLineItemID   BIGINT,
			@measureTypeID				 BIGINT,
			@integer_dataTypeID			 BIGINT,
			@decimal_dataTypeID			 BIGINT,
			@string_dataTypeID			 BIGINT,
			@max_measureID               BIGINT,
			@max_measureID1				 BIGINT,
			@max_measureID2				 BIGINT,
			@max_measureID3				 BIGINT,
			@max_measureID4				 BIGINT,
			@max_measureID5				 BIGINT,
			@units_measureID			 BIGINT,
			@tisp_measureID	    		 BIGINT,
			@tesp_measureID 			 BIGINT,
			@eposprofit_measureID 		 BIGINT,
			@discountappl_measureID 	 BIGINT,
			@max_transactionLineItemMeasureID 	BIGINT,
			@prescription_indicatorID	 BIGINT,
			@max_loyaltyAccountID   	 BIGINT;

BEGIN		

	SET		@mx_lovRecordSourceID	 = 12004;
	SET		@mx_scdLovRecordSourceID = 151;
	SET		@mx_lovPSAStatus    	 = 26001;
	
	BEGIN TRY
	BEGIN TRANSACTION;

	SELECT  @max_tillID = COALESCE(MAX(TillId),0) FROM ser.Till;
    SELECT  @max_siteID = COALESCE(MAX(SiteId),0) FROM ser.Site;
    SELECT  @max_siteRoleID = COALESCE(MAX(SiteRoleId),0) FROM ser.SiteRole;
    SELECT  @max_transactionID = COALESCE(MAX(TransactionId),0) FROM ser.[Transaction];
    SELECT  @max_productID = COALESCE(MAX(ProductId),0) FROM ser.Product;
    SELECT  @max_dealID = COALESCE(MAX(DealId),0) FROM ser.Deal;
    SELECT  @max_transactionLineItemID = COALESCE(MAX(TransactionLineItemId),0) FROM ser.TransactionLineItem;
    SELECT  @max_measureID = COALESCE(MAX(MeasureId),0) FROM ser.Measure;
    SELECT  @max_transactionLineItemMeasureID = COALESCE(MAX(TransactionLineItemMeasureId),0) FROM ser.TransactionLineItemMeasure;
    SELECT  @max_loyaltyAccountID = COALESCE(MAX(LoyaltyAccountId),0) FROM ser.LoyaltyAccount;


/* Table Name  :  Till */

INSERT INTO ser.Till(
	TillId				,
	SourceKey			,
	LOVRecordSourceId	,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId			,
	PSARowKey
)

select 
@max_tillID+ROW_NUMBER() OVER(order by till_id) TillId, 
till_id SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId,
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
from
(select till_id as till_id, min(concat(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid, record_source_id from psa.rawmx_crp_item_transaction mxitemtrans 
where till_id is not null and trim(till_id) != '' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
group by till_id,record_source_id) A
left outer join ser.Till till 
on A.till_id = till.sourceKey
and A.record_source_id = till.LOVRecordSourceID
where till.sourceKey is null
;

RAISERROR ('Completed insertion of MEXICO source data to TILL table', 0, 1) WITH NOWAIT


/* Table Name  :  Site */
/*
INSERT INTO ser.Site(
	SiteId				,
	SourceKey			,
	SiteName			,
	LOVSiteTypeId		,
	LOVRecordSourceId	,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId			,
	PSARowKey
)  

select 
@max_siteID+ROW_NUMBER() OVER(order by store_number) SiteId, 
store_number SourceKey, 
null SiteName, 
null LOVSiteTypeId, 
@mx_lovRecordSourceID LOVRecordSourceId,
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
null ETLRunLogId,
null PSARowKey 
from
(select store_number as store_number from psa.rawmx_crp_item_transaction mxitemtrans group by store_number) A;

RAISERROR ('Completed insertion of MEXICO source data to SITE table', 0, 1) WITH NOWAIT
*/

/* Table Name  :  SiteRole */

SET @mx_lovRoleId = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'Store' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Role'));

SET @siteId = (SELECT siteId siteId from ser.Site where sourceKey = 0 and LOVRecordSourceID = 12012 and 
lovSiteTypeId =(SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = '0' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Site Type')));


INSERT INTO ser.SiteRole(
	SiteRoleId			,
	SiteId				,
	LOVRoleId			,
	SourceKey			,
	SiteRoleName		,
	SiteRoleShortName	,
	LOVRecordSourceId	,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId			,
	PSARowKey
)  

select 
@max_siteRoleID+ROW_NUMBER() OVER(order by store_number) SiteRoleId, 
@siteId siteId,
@mx_lovRoleId LOVRoleId, 
store_number SourceKey, 
null SiteRoleName, 
null SiteRoleShortName, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
from
(select store_number as store_number, min(concat(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid,record_source_id from psa.rawmx_crp_item_transaction mxitemtrans 
where store_number is not null and trim(store_number) != '' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
group by store_number,record_source_id) A
left outer join ser.SiteRole siterole 
on A.store_number = siterole.sourceKey
and A.record_source_id = siterole.LOVRecordSourceID
where siterole.sourceKey is null
;

RAISERROR ('Completed insertion of MEXICO source data to SITEROLE table', 0, 1) WITH NOWAIT


/* Table Name  :  Transaction */

SET @transactionTypeId = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'RETAIL' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Transaction Type'));

INSERT INTO ser.[Transaction](
	TransactionId			,
	SourceKey				,
	LOVTransactionTypeId	,
	SiteRoleId				,
	TransactionDatetime		,
	TillId					,
	TillTransactionNumber	,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  
    
select 
@max_transactionID+ROW_NUMBER() OVER(order by transaction_key) TransactionId, 
transaction_key SourceKey, 
@transactionTypeId LOVTransactionTypeId, 
siterole.siteroleid SiteRoleId, 
convert(datetime, concat(substring(transaction_date,1,4),'-',substring(transaction_date,5,2),'-',substring(transaction_date,7,2),' ',transaction_time,':00'),120) TransactionDatetime,
till.tillId TillId, 
null TillTransactionNumber, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate,  
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
from
(select transaction_key as transaction_key, store_number as store_number, till_id as till_id, transaction_date as transaction_date, transaction_time as transaction_time,
min(concat(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid, record_source_id
from psa.rawmx_crp_item_transaction mxitemtrans where transaction_date is not null and transaction_date != '' and transaction_time is not null and transaction_time != '' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
group by transaction_key, store_number,till_id, transaction_date,transaction_time,record_source_id) A
left outer join (select * from ser.Till where SCDActiveFlag = 'Y' and LOVRecordSourceID = 12004) till
on till.sourcekey = A.till_id
and till.LOVRecordSourceId = @mx_lovRecordSourceID
join (select siteroleid, sourceKey, LOVRecordSourceID from ser.SiteRole where SCDActiveFlag = 'Y' and siteroleid is not null and LOVRecordSourceID = @mx_lovRecordSourceID)siterole
on siterole.sourcekey = A.store_number
and siterole.LOVRecordSourceID = @mx_lovRecordSourceID
left outer join ser.[Transaction] trans
on A.transaction_key = trans.sourceKey
and convert(datetime, concat(substring(A.transaction_date,1,4),'-',substring(A.transaction_date,5,2),'-',substring(A.transaction_date,7,2),' ',A.transaction_time,':00'),120) = trans.transactiondatetime
and A.record_source_id = trans.LOVRecordSourceID
where trans.sourceKey is null
;

RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION table', 0, 1) WITH NOWAIT



/* Table Name  :  Product */

SET @mx_lovSourceKeyTypeId = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'Mexico Item Code' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Source Key Type'));

INSERT INTO ser.Product(
	ProductId			,
	SourceKey			,
	LOVSourceKeyTypeId	,
	ProductName			,
	ProductDescription	,
	LOVBrandId 			,
	LOVSubBrandId 		,
--	LOVCostCentreId 	,
	LOVRecordSourceId	,
	ParentProductId		,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId			,
	PSARowKey
)  

select 
@max_productID+ROW_NUMBER() OVER(order by item_code) ProductId, 
item_code SourceKey,
@mx_lovSourceKeyTypeId LOVSourceKeyTypeId, 
null ProductName, 
null ProductDescription, 
null LOVBrandId,
null LOVSubBrandId,
--null LOVCostCentreId,
@mx_lovRecordSourceID LOVRecordSourceId, 
null ParentProductId,
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
from
(select item_code as item_code, min(concat(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid, record_source_id from psa.rawmx_crp_item_transaction mxitemtrans 
where item_code is not null and trim(item_code) != '' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) group by item_code,record_source_id)A
left outer join ser.Product product
on A.item_code = product.sourceKey
and A.record_source_id = product.LOVRecordSourceID
where product.sourceKey is null
;


RAISERROR ('Completed insertion of MEXICO source data to PRODUCT table', 0, 1) WITH NOWAIT


/* Table Name  :  Product Identifier */

SET @upc_identifierID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'UPC' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Identifier'));

INSERT INTO ser.ProductIdentifier(
	ProductId			,
	LOVIdentifierId		,
	Value				,
	LOVRecordSourceId	,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId 		,
	PSARowKey
)

select 
A.ProductId ProductId, 
@upc_identifierID LOVIdentifierId,
upc Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
from
(select sourcekey as sourcekey, ProductId ProductId, mxitemtrans.upc as upc, min(concat(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid, record_source_id from ser.Product product 
join psa.rawmx_crp_item_transaction mxitemtrans on product.sourcekey = mxitemtrans.item_code and product.LOVRecordSourceID = 12004
where product.LOVRecordSourceId=@mx_lovRecordSourceID and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
group by sourcekey, ProductId, upc,record_source_id) A
left outer join ser.ProductIdentifier prodidentifier
on A.productId = prodidentifier.productId
and coalesce(A.upc,'A000001') = coalesce(prodidentifier.value,'A000001')
and A.record_source_id = prodidentifier.LOVRecordSourceID
where prodidentifier.ProductId is null
;

		
RAISERROR ('Completed insertion of MEXICO source data to PRODUCT IDENTIFIER table', 0, 1) WITH NOWAIT



/* Table Name  :  Deal */

INSERT INTO ser.Deal(
	DealId				,
	SourceKey			,
	LOVRecordSourceId	,
	SCDStartDate		,
	SCDEndDate			,
	SCDActiveFlag		,
	SCDVersion			,
	SCDLOVRecordSourceId,
	ETLRunLogId			,
	PSARowKey
)

select 
@max_dealID+ROW_NUMBER() OVER(order by deal_id) DealId, 
deal_id SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId,
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey 
from
(select deal_id as deal_id, min(concat(ISNULL(date_added,'19000101'),'_',row_id)) date_added_rowid,record_source_id from psa.rawmx_crp_item_transaction mxitemtrans 
where deal_id is not null and trim(deal_id) != '' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) group by deal_id,record_source_id) A
left outer join ser.Deal deal
on A.deal_id = deal.sourceKey
and A.record_source_id = deal.LOVRecordSourceID
where deal.sourceKey is null
;


RAISERROR ('Completed insertion of MEXICO source data to DEAL table', 0, 1) WITH NOWAIT



/* Table Name  :  TransactionLineItem */

INSERT INTO ser.TransactionLineItem(
	TransactionLineItemId	,
	TransactionId			,
	ProductId				,
	LOVLineItemTypeId		,
	DealId					,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

select 
@max_transactionLineItemID+ROW_NUMBER() OVER(order by A.TransactionId) TransactionLineItemId, 
A.TransactionId TransactionId,
product.ProductId ProductId, 
ro.LOVId LOVLineItemTypeId, 
deal.dealid DealId, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(date_added,1,4),'-',substring(date_added,5,2),'-',substring(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
row_id PSARowKey 
from
(select sourcekey sourcekey,TransactionId TransactionId, LOVRecordSourceId LOVRecordSourceId, item_code, deal_id, sales_type,transaction_date,transaction_time,transactiondatetime, date_added,row_id,record_source_id from ser.[Transaction] trans 
join (select transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, ISNULL(date_added,'19000101') date_added,row_id row_id,record_source_id record_source_id,transaction_date,transaction_time 
from psa.rawmx_crp_item_transaction where row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans on trans.sourcekey = mxitemtrans.transaction_key 
and convert(datetime, concat(substring(mxitemtrans.transaction_date,1,4),'-',substring(mxitemtrans.transaction_date,5,2),'-',substring(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
where trans.TransactionId is not null and trans.LOVRecordSourceId=@mx_lovRecordSourceID) A
left outer join (select * from ser.Deal where SCDActiveFlag = 'Y' and LOVRecordSourceID = 12004) deal
on deal.sourcekey = A.deal_id
and deal.LOVRecordSourceId = @mx_lovRecordSourceID
join (select ProductId, sourcekey from ser.Product
where SCDActiveFlag = 'Y' and ProductId is not null and LOVRecordSourceId = @mx_lovRecordSourceID and lovsourceKeyTypeId = @mx_lovSourceKeyTypeId) product
on product.sourceKey = A.item_code
left outer join(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.reflov rl JOIN ser.reflovset rls 
ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='sales_type') ro
ON A.LOVRecordSourceId =ro.LOVRecordSourceId AND ro.LOVKey=A.sales_type
;


RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION LINE ITEM table', 0, 1) WITH NOWAIT



/* Table Name  :  Measure */

SET @measureTypeID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'RETAIL_TRANS_AGG' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Measure Type'));

SET @integer_dataTypeID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'INT' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Data Type'));

SET @decimal_dataTypeID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'DECIMAL' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Data Type'));

SET @string_dataTypeID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'STRING' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Data Type'));


SET @max_measureID1 = @max_measureID + 1;
SET @max_measureID2 = @max_measureID + 2;
SET @max_measureID3 = @max_measureID + 3;
SET @max_measureID4 = @max_measureID + 4;
SET @max_measureID5 = @max_measureID + 5;

INSERT INTO ser.Measure(
    MeasureId 			,
    LOVMeasureTypeId	,
    LOVDataTypeId		, 
    MeasureName			,        
    MeasureDescription	,
    Length				,
    Precision			,
    Scale				,
    StandardMeasureId	,
	LOVRecordSourceId 	,
    SCDStartDate		,
    SCDEndDate			,
    SCDActiveFlag		,
    SCDVersion 			,
	SCDLOVRecordSourceId,
    ETLRunLogId
) 

select TOP 1 
@max_measureID1 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@integer_dataTypeID LOVDataTypeId, 
'units' MeasureName,        
'The number of units of item sold in the transaction' MeasureDescription,
null Length,
null Precision,
null Scale,
null StandardMeasureId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'units'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @mx_lovRecordSourceID
where measure.MeasureId is null

UNION

select TOP 1
@max_measureID2 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'tisp' MeasureName,        
'Tax inclusive selling price (price paid by customer)' MeasureDescription,
null Length,
10 Precision,
2 Scale,
null StandardMeasureId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'tisp'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @mx_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID3 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'tesp' MeasureName,        
'Tax exclusive selling price' MeasureDescription,
null Length,
10 Precision,
2 Scale,
null StandardMeasureId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'tesp'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @mx_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID4 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'epos_profit' MeasureName,        
'This should be reflective of the true profitability of each product  (EPOS profit = TISP - Cost)' MeasureDescription,
null Length,
10 Precision,
2 Scale,
null StandardMeasureId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'epos_profit'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @mx_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID5 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@string_dataTypeID LOVDataTypeId, 
'discount_applied' MeasureName,        
'The total discount the customer received (through promotions, staff discount etc) on the items in the transaction.  I.e.. it is the difference between the shelf edge price and the amount the customer actually paid.' MeasureDescription,
null Length,
null Precision,
null Scale,
null StandardMeasureId,
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'discount_applied'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @mx_lovRecordSourceID
where measure.MeasureId is null
;

RAISERROR ('Completed insertion of MEXICO source data to MEASURE table', 0, 1) WITH NOWAIT


/* Table Name  :  TransactionLineItemMeasure */

SET @units_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'units' and LOVRecordSourceId = @mx_lovRecordSourceID);
SET @tisp_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'tisp' and LOVRecordSourceId = @mx_lovRecordSourceID);
SET @tesp_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'tesp' and LOVRecordSourceId = @mx_lovRecordSourceID);
SET @eposprofit_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'epos_profit' and LOVRecordSourceId = @mx_lovRecordSourceID);
SET @discountappl_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'discount_applied' and LOVRecordSourceId = @mx_lovRecordSourceID);


INSERT INTO ser.TransactionLineItemMeasure(
	TransactionLineItemMeasureId	,
	TransactionLineItemId 			,
	MeasureId  						,
	Value							,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

select @max_transactionLineItemMeasureID+DENSE_RANK() OVER(order by TransactionLineItemId, MeasureId) TransactionLineItemMeasureId, 
TransactionLineItemId, MeasureId, Value, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey
from

(
select 
translineitem.TransactionLineItemId TransactionLineItemId,
@units_measureID MeasureId, 
units Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(date_added,1,4),'-',substring(date_added,5,2),'-',substring(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @mx_lovRecordSourceID) translineitem
join (select transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, units units,ISNULL(date_added,'19000101') date_added,
row_id row_id,record_source_id record_source_id from psa.rawmx_crp_item_transaction where row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
on translineitem.PSARowKey = mxitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@tisp_measureID MeasureId, 
tisp Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(date_added,1,4),'-',substring(date_added,5,2),'-',substring(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @mx_lovRecordSourceID) translineitem
join (select transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, tisp tisp,ISNULL(date_added,'19000101') date_added,
row_id row_id,record_source_id record_source_id from psa.rawmx_crp_item_transaction where row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
on translineitem.PSARowKey = mxitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@tesp_measureID MeasureId, 
tesp Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(date_added,1,4),'-',substring(date_added,5,2),'-',substring(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @mx_lovRecordSourceID) translineitem
join (select transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, tesp tesp,ISNULL(date_added,'19000101') date_added,
row_id row_id,record_source_id record_source_id from psa.rawmx_crp_item_transaction where row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
on translineitem.PSARowKey = mxitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@eposprofit_measureID MeasureId, 
epos_profit Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(date_added,1,4),'-',substring(date_added,5,2),'-',substring(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @mx_lovRecordSourceID) translineitem
join (select transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, epos_profit epos_profit, ISNULL(date_added,'19000101') date_added,
row_id,record_source_id record_source_id from psa.rawmx_crp_item_transaction where row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
on translineitem.PSARowKey = mxitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@discountappl_measureID MeasureId, 
discount_applied Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(date_added,1,4),'-',substring(date_added,5,2),'-',substring(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @mx_lovRecordSourceID) translineitem
join (select transaction_key transaction_key, item_code item_code, sales_type sales_type, deal_id deal_id, discount_applied discount_applied,ISNULL(date_added,'19000101') date_added,
row_id row_id,record_source_id record_source_id from psa.rawmx_crp_item_transaction where row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans 
on translineitem.PSARowKey = mxitemtrans.row_id
)Z
;


RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION LINE ITEM MEASURE table', 0, 1) WITH NOWAIT



/* Table Name  :  TransactionLineItemIndicator */

SET @prescription_indicatorID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'prescription' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Indicator - MEXICO Transaction'));


INSERT INTO ser.TransactionLineItemIndicator(
	TransactionLineItemId 			,
	LOVIndicatorId					,
	Value							,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@prescription_indicatorID LOVIndicatorId, 
--prescription Value, 
case when (prescription = 'YES' OR prescription = 'Y' OR prescription = 'yes' OR prescription = 'y') then 'Y' 
	 when (prescription = 'NO' OR prescription = 'N' OR prescription = 'no' OR prescription = 'n') then 'N' 
	 end Value, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(date_added,1,4),'-',substring(date_added,5,2),'-',substring(date_added,7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @mx_lovRecordSourceID) translineitem
join (select transaction_key transaction_key, item_code item_code, prescription prescription,ISNULL(date_added,'19000101') date_added,row_id row_id,record_source_id record_source_id from psa.rawmx_crp_item_transaction
where prescription is not null and trim(prescription) != '' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
)mxitemtrans 
on translineitem.PSARowKey = mxitemtrans.row_id
;


RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION LINE ITEM INDICATOR table', 0, 1) WITH NOWAIT


/* Table Name  :  LoyaltyAccount */

INSERT INTO ser.LoyaltyAccount(
	LoyaltyAccountId 				,
	LOVLoyaltyProgramId				,
	SourceKey						,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

select @max_loyaltyAccountID+ROW_NUMBER() OVER(order by LOVLoyaltyProgramId, SourceKey) LoyaltyAccountId,
LOVLoyaltyProgramId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey
from
(
select 
LOVId LOVLoyaltyProgramId, 
customer_identifier SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
from
(select customer_identifier,ro.LOVId,record_source_id, min(date_added_rowid) date_added_rowid from
(select CASE WHEN customer_identifier_type is null OR trim(customer_identifier_type) = '' OR trim(customer_identifier_type) = 'NULL' THEN 'Unknown' ELSE customer_identifier_type END customer_identifier_type,
customer_identifier,concat(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id from psa.rawmx_crp_item_transaction 
where customer_identifier is not null and trim(customer_identifier) !='' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
) mxitemtrans
left outer join (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.reflov rl JOIN ser.reflovset rls 
ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='customer_identifier_type') ro
ON ro.LOVRecordSourceId=@mx_lovRecordSourceID 
AND ro.LOVKey=mxitemtrans.customer_identifier_type
left outer join ser.LoyaltyAccount loyaltyaccount
on customer_identifier = loyaltyaccount.sourceKey
and ro.LOVId = loyaltyaccount.LOVLoyaltyProgramId
and record_source_id = loyaltyaccount.LOVRecordSourceID
where loyaltyaccount.sourceKey is null
group by customer_identifier,LOVId,record_source_id
) X

UNION

select 
LOVId LOVLoyaltyProgramId, 
customer_number SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
from
(select customer_number,ro.LOVId,record_source_id, min(date_added_rowid) date_added_rowid from
(select CASE WHEN customer_number_type is null OR trim(customer_number_type) = '' OR trim(customer_number_type) = 'NULL' THEN 'Unknown' ELSE customer_number_type END customer_number_type, 
customer_number,concat(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id from psa.rawmx_crp_item_transaction 
where customer_number is not null and trim(customer_number) !='' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
) mxitemtrans
left outer join (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.reflov rl JOIN ser.reflovset rls 
ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='customer_number_type') ro
ON ro.LOVRecordSourceId=@mx_lovRecordSourceID 
AND ro.LOVKey=mxitemtrans.customer_number_type
left outer join ser.LoyaltyAccount loyaltyaccount
on customer_number = loyaltyaccount.sourceKey
and ro.LOVId = loyaltyaccount.LOVLoyaltyProgramId
and record_source_id = loyaltyaccount.LOVRecordSourceID
where loyaltyaccount.sourceKey is null
group by customer_number,LOVId,record_source_id
) X

UNION

select 
LOVId LOVLoyaltyProgramId, 
other_customer_id SourceKey, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
from
(select other_customer_id,ro.LOVId,record_source_id, min(date_added_rowid) date_added_rowid from
(select CASE WHEN other_customer_id_type is null OR trim(other_customer_id_type) = '' OR trim(other_customer_id_type) = 'NULL' THEN 'Unknown' ELSE other_customer_id_type END other_customer_id_type, 
other_customer_id,concat(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id from psa.rawmx_crp_item_transaction 
where other_customer_id is not null and trim(other_customer_id) !='' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
) mxitemtrans
left outer join (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.reflov rl JOIN ser.reflovset rls 
ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='other_customer_id_type') ro
ON ro.LOVRecordSourceId=@mx_lovRecordSourceID 
AND ro.LOVKey=mxitemtrans.other_customer_id_type
left outer join ser.LoyaltyAccount loyaltyaccount
on other_customer_id = loyaltyaccount.sourceKey
and ro.LOVId = loyaltyaccount.LOVLoyaltyProgramId
and record_source_id = loyaltyaccount.LOVRecordSourceID
where loyaltyaccount.sourceKey is null
group by other_customer_id,LOVId,record_source_id
) X

)Z
;

RAISERROR ('Completed insertion of MEXICO source data to LOYALTY ACCOUNT table', 0, 1) WITH NOWAIT


/* Table Name  :  TransactionLoyaltyAccount */

INSERT INTO ser.TransactionLoyaltyAccount(
	TransactionId			,
	LoyaltyAccountId		,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

select 
TransactionId TransactionId,
LoyaltyAccountId LoyaltyAccountId, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
from
(select A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id, min(date_added_rowid) date_added_rowid from
(select sourcekey sourcekey,TransactionId TransactionId, LOVRecordSourceId LOVRecordSourceId, transactiondatetime,transaction_date,transaction_time,
CASE WHEN customer_identifier_type is null OR trim(customer_identifier_type) = '' OR trim(customer_identifier_type) = 'NULL' THEN 'Unknown' ELSE customer_identifier_type END customer_identifier_type, customer_identifier customer_identifier,
date_added_rowid,record_source_id from ser.[Transaction] trans 
join (select transaction_key transaction_key, customer_identifier_type customer_identifier_type, customer_identifier customer_identifier,concat(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id,transaction_date,transaction_time 
from psa.rawmx_crp_item_transaction where customer_identifier is not null and trim(customer_identifier) !='' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans on trans.sourcekey = mxitemtrans.transaction_key 
and convert(datetime, concat(substring(mxitemtrans.transaction_date,1,4),'-',substring(mxitemtrans.transaction_date,5,2),'-',substring(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
where trans.LOVRecordSourceId=@mx_lovRecordSourceID) A
left outer join (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.reflov rl JOIN ser.reflovset rls 
ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='customer_identifier_type') ro
ON ro.LOVRecordSourceId=@mx_lovRecordSourceID
AND ro.LOVKey=A.customer_identifier_type
left outer join (select * from ser.LoyaltyAccount where SCDActiveFlag = 'Y' and LOVRecordSourceId = @mx_lovRecordSourceID) loyaltyacc
on loyaltyacc.sourcekey = A.customer_identifier
and loyaltyacc.LOVLoyaltyProgramId = ro.LOVId
left outer join ser.TransactionLoyaltyAccount transLoyaltyaccount
on A.TransactionId = transLoyaltyaccount.TransactionId
and loyaltyacc.LoyaltyAccountId = transLoyaltyaccount.LoyaltyAccountId
and A.record_source_id = transLoyaltyaccount.LOVRecordSourceID
where transLoyaltyaccount.LoyaltyAccountId is null
group by A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id
) X

UNION

select 
TransactionId TransactionId,
LoyaltyAccountId LoyaltyAccountId, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
from
(select A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id, min(date_added_rowid) date_added_rowid from
(select sourcekey sourcekey,TransactionId TransactionId, LOVRecordSourceId LOVRecordSourceId, transactiondatetime,transaction_date,transaction_time,
CASE WHEN customer_number_type is null OR trim(customer_number_type) = '' OR trim(customer_number_type) = 'NULL' THEN 'Unknown' ELSE customer_number_type END customer_number_type, customer_number customer_number,
date_added_rowid,record_source_id from ser.[Transaction] trans 
join (select transaction_key transaction_key, customer_number_type customer_number_type, customer_number customer_number, concat(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id,transaction_date,transaction_time 
from psa.rawmx_crp_item_transaction where customer_number is not null and trim(customer_number) !=''and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans on trans.sourcekey = mxitemtrans.transaction_key 
and convert(datetime, concat(substring(mxitemtrans.transaction_date,1,4),'-',substring(mxitemtrans.transaction_date,5,2),'-',substring(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
where trans.LOVRecordSourceId=@mx_lovRecordSourceID) A
left outer join (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.reflov rl JOIN ser.reflovset rls 
ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='customer_number_type') ro
ON ro.LOVRecordSourceId=@mx_lovRecordSourceID
AND ro.LOVKey=A.customer_number_type
left outer join (select * from ser.LoyaltyAccount where SCDActiveFlag = 'Y' and LOVRecordSourceId = @mx_lovRecordSourceID) loyaltyacc
on loyaltyacc.sourcekey = A.customer_number
and loyaltyacc.LOVLoyaltyProgramId = ro.LOVId
left outer join ser.TransactionLoyaltyAccount transLoyaltyaccount
on A.TransactionId = transLoyaltyaccount.TransactionId
and loyaltyacc.LoyaltyAccountId = transLoyaltyaccount.LoyaltyAccountId
and A.record_source_id = transLoyaltyaccount.LOVRecordSourceID
where transLoyaltyaccount.LoyaltyAccountId is null
group by A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id
) X

UNION

select 
TransactionId TransactionId,
LoyaltyAccountId LoyaltyAccountId, 
@mx_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
--concat(substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),1,4),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),5,2),'-',substring(LEFT(date_added_rowid,CHARINDEX('_',date_added_rowid)-1),7,2)) SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@mx_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
RIGHT(date_added_rowid,LEN(date_added_rowid)-CHARINDEX('_',date_added_rowid)) PSARowKey
from
(select A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id, min(date_added_rowid) date_added_rowid from
(select sourcekey sourcekey,TransactionId TransactionId, LOVRecordSourceId LOVRecordSourceId, transactiondatetime,transaction_date,transaction_time,
CASE WHEN other_customer_id_type is null OR trim(other_customer_id_type) = '' OR trim(other_customer_id_type) = 'NULL' THEN 'Unknown' ELSE other_customer_id_type END other_customer_id_type, other_customer_id other_customer_id,
date_added_rowid,record_source_id from ser.[Transaction] trans 
join (select transaction_key transaction_key, other_customer_id_type other_customer_id_type, other_customer_id other_customer_id,concat(ISNULL(date_added,'19000101'),'_',row_id) date_added_rowid,record_source_id,transaction_date,transaction_time 
from psa.rawmx_crp_item_transaction where other_customer_id is not null and trim(other_customer_id) !='' and row_status =@mx_lovPSAStatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)mxitemtrans on trans.sourcekey = mxitemtrans.transaction_key 
and convert(datetime, concat(substring(mxitemtrans.transaction_date,1,4),'-',substring(mxitemtrans.transaction_date,5,2),'-',substring(mxitemtrans.transaction_date,7,2),' ',mxitemtrans.transaction_time,':00'),120) = trans.transactiondatetime
where trans.LOVRecordSourceId=@mx_lovRecordSourceID) A
left outer join (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.reflov rl JOIN ser.reflovset rls 
ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='other_customer_id_type') ro
ON ro.LOVRecordSourceId=@mx_lovRecordSourceID
AND ro.LOVKey=A.other_customer_id_type
left outer join (select * from ser.LoyaltyAccount where SCDActiveFlag = 'Y' and LOVRecordSourceId = @mx_lovRecordSourceID) loyaltyacc
on loyaltyacc.sourcekey = A.other_customer_id
and loyaltyacc.LOVLoyaltyProgramId = ro.LOVId
left outer join ser.TransactionLoyaltyAccount transLoyaltyaccount
on A.TransactionId = transLoyaltyaccount.TransactionId
and loyaltyacc.LoyaltyAccountId = transLoyaltyaccount.LoyaltyAccountId
and A.record_source_id = transLoyaltyaccount.LOVRecordSourceID
where transLoyaltyaccount.LoyaltyAccountId is null
group by A.TransactionId, loyaltyacc.LoyaltyAccountId, record_source_id
) X
;

RAISERROR ('Completed insertion of MEXICO source data to TRANSACTION LOYALTY ACCOUNT table', 0, 1) WITH NOWAIT


update psa.rawmx_crp_item_transaction
set row_status = 26002
where row_status =@mx_lovPSAStatus
and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
;

RAISERROR ('Completed procedure of MEXICO updated row status to IN SERV', 0, 1) WITH NOWAIT

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
DECLARE @error_num varchar(max),
		@error_msg varchar(max),
		@error_sev varchar(max)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

END;
GO
/****** Object:  StoredProcedure [psa].[sp_rawcl_crp_product]    Script Date: 23/07/2020 14:13:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_rawcl_crp_product') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawcl_crp_product
END
GO

CREATE PROC [psa].[sp_rawcl_crp_product] @psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max) AS
/*
************************************************************************************************************
Procedure Name				: sp_rawcl_crp_product
Purpose						: Load History data From International CHILE Source(rawcl_crp_product) into Serve Layer Table
Domain						: Product
ServeLayer Target Tables	: Product,ProductGroup,ProductIndicator,ProductProperty,ProductStatus,
							  Party,Organization,PartyRole,ProductPartyRole    (Total 9 Tables)
RecordSourceID  for International Chile : 12001
*****************************************************************************************
Default values
************************************************************************************************************
				SCDStartDate for first version  : '1900-01-01'
				SCDEndDate for higest version   : '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
Modification History
09-June-2020  : Incorporated History Catchup logic
                a) Migrate only the records with RowStatus='PSA' and RunLogId=@psaETLRunLogID
				b) Surrogate key checking and version ,active flag
                c) Update psa table with RowStatus='Loaded to serve' if the data loaded successfully
14-July-2020  : Incorporated the exception handling
                a) Added the throw statement to get the exception in ADF pipeline
				b) Added the column names in the insert statements for ser.Product
21-July-2020  : Incorporated default SCDStartDate for first version
                a) SCDStartDate for first version is set as '1900-01-01'
				b) SCDStartDate and SCDEndDate made variables
                c) Fixed the productpartyrole issue
 */ 

 /*Declare  and initialize the Variables required for serve layer processing*/
 DECLARE @max_productID BIGINT				        , 
		 @max_productTempID BIGINT			        ,
		 @max_partyID BIGINT				        , 
		 @max_partyRoleID BIGINT			        , 
		 @max_productGroupID BIGINT			        , 
		 @uom_cmID BIGINT					        , 
		 @uom_unknownID BIGINT				        ,
		 @partyRoleID BIGINT				        ,
		 @chile_lovRecordSourceID BIGINT = 12001    ,
		 @chile_scdLovRecordSourceID BIGINT	= 151   ,
		 @itemCode_sourceKeyTypeID BIGINT	        ,
		 @upc_sourceKeyTypeID BIGINT		        ,
		 @rowStatusPSACode BIGINT = 26001           ,
		 @rowStatusSERCode BIGINT = 26002 	        ,
		 @party_typeID BIGINT				        ,
		 @supplier_LOVRoleId BIGINT			        ,
		 @retailer_LOVRoleId BIGINT			        ,
		 @measureTypeId BIGINT				        ,
		 @dataTypeId BIGINT					        ,
		 @scd_startDate VARCHAR(100) = '1900-01-01' ,
		 @scd_endDate VARCHAR(100) = '9999-12-31'

BEGIN
	/* Creating a intermediate physical table */
		IF OBJECT_ID('psa.rawcl_crp_product_temp') is not null
		BEGIN
			DROP TABLE psa.rawcl_crp_product_temp
		END			
			CREATE TABLE [psa].[rawcl_crp_product_temp]
				(
				[PSARowKey] [bigint] NOT NULL,
				[record_type] [nvarchar](100) NULL,
				[ProductID] [bigint] NULL,
				[ParentProductID] [bigint] NULL,
				[sourceKey] [nvarchar](500) NULL,
				[item_description] [nvarchar](500) NULL,
				[product_hierarchy1] [nvarchar](500) NULL,
				[product_hierarchy2] [nvarchar](500) NULL,
				[product_hierarchy3] [nvarchar](500) NULL,
				[product_hierarchy4] [nvarchar](500) NULL,
				[product_hierarchy5] [nvarchar](500) NULL,
				[product_hierarchy1_code] [nvarchar](500) NULL,
				[product_hierarchy2_code] [nvarchar](500) NULL,
				[product_hierarchy3_code] [nvarchar](500) NULL,
				[product_hierarchy4_code] [nvarchar](500) NULL,
				[product_hierarchy5_code] [nvarchar](500) NULL,
				[brand] [nvarchar](500) NULL,
				[subbrand] [nvarchar](500) NULL,
				[exclusive_flag] [nvarchar](500) NULL,
				[own_brand_flag] [nvarchar](500) NULL,
				[item_status] [nvarchar](500) NULL,
				[supplier_name] [nvarchar](500) NULL,
				[supplier_number] [nvarchar](500) NULL,
				[height] [nvarchar](500) NULL,
				[width] [nvarchar](500) NULL,
				[depth] [nvarchar](500) NULL,
				[size] [nvarchar](500) NULL,
				[date_added] [nvarchar](500) NULL,
				[etl_runlog_id] [int] NULL,
				[asset_id] [int] NULL,
				[LOVRecordSourceId] [int] NULL,
				[row_status] [int] NULL,
				[created_timestamp] [datetime] NULL
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			)
	/* Creating a intermediate physical table for Product Group*/
		IF OBJECT_ID('psa.rawcl_crp_product_groupTemp') is not null
		BEGIN
			DROP TABLE [psa].[rawcl_crp_product_groupTemp]
		END
			CREATE TABLE [psa].[rawcl_crp_product_groupTemp] 
				(
				[PSARowKey] [bigint] NOT NULL,
				[ProductID] [bigint] NULL,
				[SourceKey] [nvarchar](500) NULL,
				[LOVRecordSourceId] [bigint] NULL,
				[SCDLOVRecordSourceId] [bigint] NULL,
				[SCDStartDate] [nvarchar](500) NULL,
				[SCDEndDate] [nvarchar](500) NULL,
				[ETLRunLogId] [int] NULL,
				[product_hierarchy1_code] [bigint] NULL,
				[product_hierarchy1_name] [bigint] NULL,
				[product_hierarchy2_code] [bigint] NULL,
				[product_hierarchy2_name] [bigint] NULL,
				[product_hierarchy3_code] [bigint] NULL,
				[product_hierarchy3_name] [bigint] NULL,
				[product_hierarchy4_name] [bigint] NULL,
				[product_hierarchy4_code] [bigint] NULL,
				[product_hierarchy5_name] [bigint] NULL,
				[product_hierarchy5_code] [bigint] NULL
				)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			)
/*Setting the up the static values to the variable*/	
	BEGIN TRANSACTION;

		SELECT @max_productID = COALESCE(MAX(ProductID),0) FROM ser.PRODUCT
		SELECT @itemCode_sourceKeyTypeID = LOVId FROM ser.RefLOV WHERE LOVKey = 'Chile Item Code'  AND 
				LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = 'Source Key Type')
		SELECT @upc_sourceKeyTypeID = LOVId FROM ser.RefLOV WHERE LOVKey = 'UPC' AND 
				LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = 'Source Key Type')
		
		BEGIN TRY

		/* Loading a intermediate physical table with rows corresponding to distinct values of (item_code,date_added - parent) and 
		   (item_code,upc,date_added -child) and psa row_status as 'PSA' and ETLRunLogId in as @psaETLRunLogID*/
	
	PRINT 'Started insertion of International CHILE parent data to rawcl_crp_product_temp table' 
			
			INSERT INTO psa.rawcl_crp_product_temp
			SELECT PSARowKey,record_type,ProductID,ParentProductID,sourceKey,
			item_description,product_hierarchy1,product_hierarchy2,product_hierarchy3,product_hierarchy4,product_hierarchy5,
			product_hierarchy1_code,product_hierarchy2_code,product_hierarchy3_code,product_hierarchy4_code,product_hierarchy5_code,brand,subbrand,
			exclusive_flag,own_brand_flag,item_status,supplier_name,supplier_number,height,width,depth,size,date_added,
			etl_runlog_id,asset_id,LOVRecordSourceId,row_status,created_timestamp	
			FROM
				(SELECT 
				clprod.row_id PSARowKey,
				'parent' record_type,
				ISNULL(p.ProductID,prodIdTemp.ProductID) ProductID,
				NULL ParentProductID,
				clprod.item_code sourceKey,
				item_description,product_hierarchy1,product_hierarchy2,product_hierarchy3,product_hierarchy4,product_hierarchy5,
				product_hierarchy1_code,product_hierarchy2_code,product_hierarchy3_code,product_hierarchy4_code,product_hierarchy5_code,brand,subbrand,
				exclusive_flag,own_brand_flag,item_status,supplier_name,supplier_number,height,width,depth,size,date_added,
				CAST(@serveETLRunLogID AS INT) etl_runlog_id,
				asset_id,
				clprod.record_source_id LOVRecordSourceId,
				clprod.row_status,
				created_timestamp,
				LEAD('N', 1, 'Y') OVER(PARTITION BY clprod.item_code,clprod.record_source_id,clprod.date_added ORDER BY clprod.date_added ASC) SCDActiveFlag
				FROM psa.rawcl_crp_product clprod
				JOIN (SELECT clprod.item_code,clprod.record_source_id,
						(@max_productID+ROW_NUMBER() OVER(ORDER BY clprod.item_code,clprod.record_source_id ASC)) ProductID 
					  FROM psa.rawcl_crp_product clprod  GROUP BY clprod.item_code,clprod.record_source_id) prodIdTemp
				ON prodIdTemp.item_code=clprod.item_code AND prodIdTemp.record_source_id=clprod.record_source_id
				LEFT JOIN ser.product p 
				ON clprod.item_code =p.sourcekey  AND clprod.record_source_id = p.LOVRecordSourceId
				WHERE clprod.row_status = CAST(@rowStatusPSACode AS INT) AND ISNULL(p.SCDActiveFlag,'Y')='Y'
				AND p.LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
				AND clprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
			)t 
			WHERE t.SCDActiveFlag = 'Y'
			
			PRINT 'Completed insertion of International CHILE parent data to rawcl_crp_product_temp table'	
			
			PRINT 'Started insertion of International CHILE parent data to PRODUCT table'
			 
			 INSERT INTO ser.PRODUCT 
						 (ProductId,
						 SourceKey,
						 LOVSourceKeyTypeId,
						 ProductName,
						 ProductDescription,
						 LOVBrandId,
						 LOVSubBrandId,
						 LOVRecordSourceId,
						 ParentProductId,
						 SCDStartDate,
						 SCDEndDate,
						 SCDActiveFlag,
						 SCDVersion,
						 SCDLOVRecordSourceId,
						 ETLRunLogId,
						 PSARowKey)
				SELECT ProductId,SourceKey,LOVSourceKeyTypeId,ProductName,ProductDescription,LOVBrandId,LOVSubBrandId,
						LOVRecordSourceId,
						ParentProductId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId ORDER BY SCDStartDate ASC)) = 1) 
							 THEN @scd_startDate ELSE SCDStartDate 
						END SCDStartDate,
						@scd_endDate SCDEndDate,
						LEAD('N', 1, 'Y') OVER(PARTITION BY ProductId ORDER BY SCDStartDate ASC) SCDActiveFlag,				
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId ORDER BY SCDStartDate ASC) SCDVersion,						
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
				FROM
				 (SELECT 
						 clprod.PSARowKey,
						 clprod.ProductID,
						 clprod.SourceKey,
						 @itemCode_sourceKeyTypeID LOVSourceKeyTypeId,
						 clprod.item_description ProductName,
						 clprod.item_description ProductDescription ,    
						 b.lovid LOVBrandId,
						 sb.lovid LOVSubBrandId,          
						 clprod.ParentProductID,            
						 clprod.LOVRecordSourceId,        
						 clprod.date_added SCDStartDate,
						 @scd_endDate SCDEndDate,
						 @chile_scdLovRecordSourceID SCDLOVRecordSourceId,
						 p.SCDVersion SCDVersion,
						 clprod.etl_runlog_id ETLRunLogId
					FROM psa.rawcl_crp_product_temp clprod     
								LEFT JOIN ser.product p 
									ON clprod.ProductId = p.ProductId and clprod.LOVRecordSourceId = p.LOVRecordSourceId
								LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
											ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='brand') b
									ON clprod.LOVRecordSourceId =b.LOVRecordSourceId AND b.LOVKey=clprod.brand
								LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
											ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='subbrand') sb
									ON clprod.LOVRecordSourceId =sb.LOVRecordSourceId AND sb.LOVKey=clprod.subbrand
					WHERE ISNULL(p.SCDActiveFlag,'Y')='Y' AND clprod.record_type = 'parent')t
					
			PRINT 'Closing out old PRODUCT records if exists for Parent'		
			--Updating SCDEndDate with the date_added of next record having same ProductID
			UPDATE p SET SCDEndDate = t.SCDEndDate				
			FROM ser.Product p
			JOIN 
			(SELECT LOVRecordSourceId,ProductId,SCDStartDate,
			LEAD(SCDStartDate,1,@scd_endDate) OVER(PARTITION BY ProductId ORDER BY SCDVersion ASC) SCDEndDate 
			FROM
			ser.Product WHERE ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp))t 
			ON t.LOVRecordSourceId = p.LOVRecordSourceId AND t.ProductId = p.ProductId AND p.SCDStartDate = t.SCDStartDate
			WHERE LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID
			
			--Updating  active flag to N for  the closed records
			UPDATE ser.Product SET SCDActiveFlag='N'
			WHERE SCDActiveFlag='Y' AND ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp )
			AND SCDEndDate != @scd_endDate AND LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID

			PRINT 'Completed insertion of International CHILE parent data to PRODUCT table'
					
			PRINT 'Started insertion of International CHILE child data to rawcl_crp_product_temp table'	

			SELECT @max_productTempID = COALESCE(MAX(ProductID),0) FROM ser.PRODUCT
			INSERT INTO psa.rawcl_crp_product_temp
			  SELECT PSARowKey,record_type,ProductID,ParentProductID,sourceKey,
					item_description,product_hierarchy1,product_hierarchy2,product_hierarchy3,product_hierarchy4,product_hierarchy5,
					product_hierarchy1_code,product_hierarchy2_code,product_hierarchy3_code,product_hierarchy4_code,product_hierarchy5_code,brand,subbrand,
					exclusive_flag,own_brand_flag,item_status,supplier_name,supplier_number,height,width,depth,size,date_added,
					etl_runlog_id,asset_id,LOVRecordSourceId,row_status,created_timestamp	
			FROM 
				(SELECT 
						clprod.row_id PSARowKey,
						'child' record_type,
						ISNULL(p.ProductID,prodIdTemp.ProductID) ProductID,
						ISNULL(p.ParentProductID,productTemp.ProductID) ParentProductID,
						clprod.upc SourceKey,
						item_description,product_hierarchy1,product_hierarchy2,product_hierarchy3,product_hierarchy4,product_hierarchy5,
						product_hierarchy1_code,product_hierarchy2_code,product_hierarchy3_code,product_hierarchy4_code,product_hierarchy5_code,brand,subbrand,
						exclusive_flag,own_brand_flag,item_status,supplier_name,supplier_number,height,width,depth,size,date_added,
						CAST(@serveETLRunLogID AS INT) etl_runlog_id,
						asset_id,
						clprod.record_source_id LOVRecordSourceId,
						clprod.row_status,
						created_timestamp,
						LEAD('N', 1, 'Y') OVER(PARTITION BY clprod.item_code,clprod.upc,clprod.record_source_id,clprod.date_added ORDER BY clprod.date_added ASC) SCDActiveFlag
				FROM psa.rawcl_crp_product clprod
					JOIN (SELECT clprod.item_code,clprod.upc,clprod.record_source_id,(@max_productTempID+ROW_NUMBER() OVER(ORDER BY clprod.item_code,clprod.upc,clprod.record_source_id ASC)) ProductID
						 FROM psa.rawcl_crp_product clprod GROUP BY clprod.item_code,clprod.upc,clprod.record_source_id
						 ) prodIdTemp
					ON prodIdTemp.item_code=clprod.item_code AND prodIdTemp.upc=clprod.upc AND prodIdTemp.record_source_id=clprod.record_source_id
					JOIN (SELECT SourceKey,LOVRecordSourceId,ProductID FROM psa.rawcl_crp_product_temp GROUP BY SourceKey,LOVRecordSourceId,ProductID
					) productTemp
					ON productTemp.SourceKey = clprod.item_code AND productTemp.LOVRecordSourceId = clprod.record_source_id
					LEFT JOIN ser.product p 
					ON clprod.upc = p.sourcekey AND clprod.record_source_id = p.LOVRecordSourceId 
					AND p.ParentProductId  = 
					(Select ProductId from ser.Product WHERE SourceKey = clprod.item_code
					AND clprod.record_source_id = LOVRecordSourceId AND SCDActiveFlag = 'Y'
					AND ParentProductId IS NULL	AND LOVSourceKeyTypeId = @itemCode_sourceKeyTypeID)
				WHERE clprod.row_status = CAST(@rowStatusPSACode AS INT) AND ISNULL(p.SCDActiveFlag,'Y')='Y' 
				AND clprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
				)t
			 WHERE t.SCDActiveFlag = 'Y'
	
	PRINT 'Completed insertion of International CHILE child data to rawcl_crp_product_temp table'		 
/* 1.Table Name  :PRODUCT*/
	PRINT 'Started insertion of International CHILE child data to PRODUCT table'
			 
			 INSERT INTO ser.PRODUCT 
						 (ProductId,
						 SourceKey,
						 LOVSourceKeyTypeId,
						 ProductName,
						 ProductDescription,
						 LOVBrandId,
						 LOVSubBrandId,
						 LOVRecordSourceId,
						 ParentProductId,
						 SCDStartDate,
						 SCDEndDate,
						 SCDActiveFlag,
						 SCDVersion,
						 SCDLOVRecordSourceId,
						 ETLRunLogId,
						 PSARowKey)
				SELECT ProductId,SourceKey,LOVSourceKeyTypeId,ProductName,ProductDescription,LOVBrandId,LOVSubBrandId,
						LOVRecordSourceId,
						ParentProductId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId ORDER BY SCDStartDate ASC)) = 1) 
							 THEN @scd_startDate ELSE SCDStartDate 
						END SCDStartDate,
						@scd_endDate SCDEndDate,
						LEAD('N', 1, 'Y') OVER(PARTITION BY ProductId ORDER BY SCDStartDate ASC) SCDActiveFlag,				
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId ORDER BY SCDStartDate ASC) SCDVersion,						
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
				FROM
				 (SELECT   clprod.PSARowKey,
						 clprod.ProductID,
						 clprod.SourceKey,
						 @upc_sourceKeyTypeID LOVSourceKeyTypeId,
						 clprod.item_description ProductName,
						 clprod.item_description ProductDescription ,    
						 b.lovid LOVBrandId,
						 sb.lovid LOVSubBrandId,          
						 clprod.ParentProductID,            
						 clprod.LOVRecordSourceId,        
						 clprod.date_added SCDStartDate,
						 @scd_endDate SCDEndDate,
						 @chile_scdLovRecordSourceID SCDLOVRecordSourceId,
						 p.SCDVersion SCDVersion,
						 clprod.etl_runlog_id ETLRunLogId
					FROM psa.rawcl_crp_product_temp clprod     
					LEFT JOIN ser.product p 
						ON clprod.ProductId = p.ProductId and clprod.LOVRecordSourceId = p.LOVRecordSourceId
						AND p.ParentProductId  = clprod.ParentProductId						
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
									ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='brand') b
						 ON clprod.LOVRecordSourceId =b.LOVRecordSourceId AND b.LOVKey=clprod.brand
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
									ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='subbrand') sb
						 ON clprod.LOVRecordSourceId =sb.LOVRecordSourceId AND sb.LOVKey=clprod.subbrand
					WHERE ISNULL(p.SCDActiveFlag,'Y')='Y' AND clprod.record_type = 'child')t 
	 
	 PRINT 'Closing out old PRODUCT records if exists for child'		
			--Updating SCDEndDate with the date_added of next record having same ProductID
			UPDATE p SET SCDEndDate = t.SCDEndDate				
			FROM ser.Product p
			JOIN 
			(SELECT LOVRecordSourceId,ProductId,SCDStartDate,
			LEAD(SCDStartDate,1,@scd_endDate) OVER(PARTITION BY ProductId ORDER BY SCDVersion ASC) SCDEndDate 
			FROM
			ser.Product WHERE ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp))t
			ON t.LOVRecordSourceId = p.LOVRecordSourceId AND t.ProductId = p.ProductId AND p.SCDStartDate = t.SCDStartDate
			WHERE LOVSourceKeyTypeId = @upc_sourceKeyTypeID
			
			--Updating  active flag to N for  the closed records
			UPDATE ser.Product SET SCDActiveFlag='N'
			WHERE SCDActiveFlag='Y' AND ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp )
			AND SCDEndDate != @scd_endDate AND LOVSourceKeyTypeId = @upc_sourceKeyTypeID

	PRINT 'Completed insertion of International CHILE child data to PRODUCT table'
	

/* 2.Table Name  :PRODUCT PROPERTY*/
	PRINT 'Started insertion of International CHILE source data to PRODUCT PROPERTY table'
			
			SELECT @uom_cmID = LovId FROM ser.RefLOV WHERE LOVKey = 'cm' AND LOVSetId=
                      (SELECT LOVSetID FROM ser.RefLOVSet WHERE  LOVSetName = 'Unit of measure')

			SELECT @uom_unknownID = LovId FROM ser.RefLOV WHERE LOVKey = 'Unknown' AND LOVSetId=
                           (SELECT LOVSetID FROM ser.RefLOVSet WHERE  LOVSetName = 'Unit of measure')

			SET @measureTypeId = (SELECT rl.Lovid FROM ser.RefLov rl ,ser.RefLovset rls WHERE rl.LovSetID = rls.LovSetID AND rl.LOVKey = 'PROD_DIM' AND rls.LOVSetName = 'Measure Type')
			
			SET @dataTypeId	= (SELECT rl.Lovid FROM ser.RefLov rl,ser.RefLovset rls WHERE rl.LovSetID = rls.LovSetID AND rl.LOVKey = 'STRING' AND rls.LOVSetName = 'Data Type')
			
			INSERT INTO ser.ProductProperty
			(
			PSARowKey,
			ProductId,
			MeasureId,
			LOVUOMId,
			Value,
			LOVRecordSourceId,
			SCDStartDate,
			SCDEndDate,
			SCDActiveFlag,
			SCDVersion,
			SCDLOVRecordSourceId,
			ETLRunLogId			
			)
			SELECT temp.PSARowKey,
				   temp.ProductID,
				   measure.MeasureID,
				   @uom_cmID LOVUOMId,
				   temp.height value,
				   temp.LOVRecordSourceId,
				   CASE WHEN ((ISNULL(property.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC)) = 1) 
							 THEN @scd_startDate ELSE temp.date_added 
				   END SCDStartDate,
				   @scd_endDate SCDEndDate,
				   LEAD('N', 1, 'Y') OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC) SCDActiveFlag,
				   ISNULL(property.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC) SCDVersion,
				   @chile_scdLovRecordSourceID SCDLOVRecordSourceId,
				   temp.etl_runlog_id ETLRunLogId
				   FROM psa.rawcl_crp_product_temp temp				
				   JOIN ser.Measure measure 
				   ON measure.MeasureName = 'height' AND measure.LOVRecordSourceId = temp.LOVRecordSourceId
				   AND measure.LOVMeasureTypeId = @measureTypeId AND measure.LOVDataTypeId = @dataTypeId
				   AND temp.height != '' AND temp.height IS NOT NULL AND temp.record_type = 'child' 
				   LEFT JOIN ser.ProductProperty property
				   ON property.ProductID = temp.ProductID AND property.MeasureID = measure.MeasureID 
				   AND property.LOVRecordSourceId = temp.LOVRecordSourceId
				   AND property.SCDActiveFlag = 'Y'
			UNION
			SELECT temp.PSARowKey,
				   temp.ProductID,
				   measure.MeasureID,
				   @uom_cmID LOVUOMId,
				   temp.width value,
				   temp.LOVRecordSourceId,
				   CASE WHEN ((ISNULL(property.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC)) = 1) 
							 THEN @scd_startDate ELSE temp.date_added 
				   END SCDStartDate,
				   @scd_endDate SCDEndDate,
				   LEAD('N', 1, 'Y') OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC) SCDActiveFlag,
				   ISNULL(property.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC) SCDVersion,
				   @chile_scdLovRecordSourceID SCDLOVRecordSourceId,
				   temp.etl_runlog_id ETLRunLogId
				   FROM psa.rawcl_crp_product_temp temp				
				   JOIN ser.Measure measure 
				   ON measure.MeasureName = 'width' AND measure.LOVRecordSourceId = temp.LOVRecordSourceId
				   AND measure.LOVMeasureTypeId = @measureTypeId AND measure.LOVDataTypeId = @dataTypeId
				   AND temp.width != '' AND temp.width IS NOT NULL AND temp.record_type = 'child' 
				   LEFT JOIN ser.ProductProperty property
				   ON property.ProductID = temp.ProductID AND property.MeasureID = measure.MeasureID 
				   AND property.LOVRecordSourceId = temp.LOVRecordSourceId
				   AND property.SCDActiveFlag = 'Y'
			UNION
			SELECT temp.PSARowKey,
				   temp.ProductID,
				   measure.MeasureID,
				   @uom_cmID LOVUOMId,
				   temp.depth value,
				   temp.LOVRecordSourceId,
				   CASE WHEN ((ISNULL(property.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC)) = 1) 
							 THEN @scd_startDate ELSE temp.date_added 
				   END SCDStartDate,
				   @scd_endDate SCDEndDate,
				   LEAD('N', 1, 'Y') OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC) SCDActiveFlag,
				   ISNULL(property.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC) SCDVersion,
				   @chile_scdLovRecordSourceID SCDLOVRecordSourceId,
				   temp.etl_runlog_id ETLRunLogId
				   FROM psa.rawcl_crp_product_temp temp				
				   JOIN ser.Measure measure 
				   ON measure.MeasureName = 'depth' AND measure.LOVRecordSourceId = temp.LOVRecordSourceId
				   AND measure.LOVMeasureTypeId = @measureTypeId AND measure.LOVDataTypeId = @dataTypeId
				   AND temp.depth != '' AND temp.depth IS NOT NULL AND temp.record_type = 'child' 
				   LEFT JOIN ser.ProductProperty property
				   ON property.ProductID = temp.ProductID AND property.MeasureID = measure.MeasureID 
				   AND property.LOVRecordSourceId = temp.LOVRecordSourceId
				   AND property.SCDActiveFlag = 'Y'
			UNION
			SELECT temp.PSARowKey,
			       temp.ProductID,
				   measure.MeasureID,
				   @uom_unknownID LOVUOMId,
				   temp.size value,
				   temp.LOVRecordSourceId,
				   CASE WHEN ((ISNULL(property.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC)) = 1) 
							 THEN @scd_startDate ELSE temp.date_added 
				   END SCDStartDate,
				   @scd_endDate SCDEndDate,
				   LEAD('N', 1, 'Y') OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC) SCDActiveFlag,
				   ISNULL(property.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,measure.MeasureID ORDER BY temp.date_added ASC) SCDVersion,
				   @chile_scdLovRecordSourceID SCDLOVRecordSourceId,
				   temp.etl_runlog_id ETLRunLogId
				   FROM psa.rawcl_crp_product_temp temp				
				   JOIN ser.Measure measure 
				   ON measure.MeasureName = 'size' AND measure.LOVRecordSourceId = temp.LOVRecordSourceId
				   AND measure.LOVMeasureTypeId = @measureTypeId AND measure.LOVDataTypeId = @dataTypeId
				   AND temp.size != '' AND temp.size IS NOT NULL AND temp.record_type = 'child' 
				   LEFT JOIN ser.ProductProperty property
				   ON property.ProductID = temp.ProductID AND property.MeasureID = measure.MeasureID 
				   AND property.LOVRecordSourceId = temp.LOVRecordSourceId
				   AND property.SCDActiveFlag = 'Y'
	
	PRINT 'Closing out old PRODUCT PROPERTY records if exists'	
		   --Updating SCDEndDate with the date_added of next record having same ProductID and MeasureID
			UPDATE property SET SCDEndDate = t.SCDEndDate				
			FROM ser.ProductProperty property
			JOIN 
			(SELECT p.LOVRecordSourceId,p.ProductId,p.MeasureId,p.SCDStartDate,
			LEAD(p.SCDStartDate,1,@scd_endDate) OVER(PARTITION BY p.ProductID,p.MeasureID ORDER BY p.SCDStartDate ASC) SCDEndDate 
			FROM ser.ProductProperty p
			WHERE p.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp WHERE record_type = 'child')
			)t
			ON t.LOVRecordSourceId = property.LOVRecordSourceId AND t.ProductId = property.ProductId 
			AND t.MeasureId = property.MeasureId AND t.SCDStartDate = property.SCDStartDate

			--Updating  active flag to N for  the closed records
			UPDATE property SET property.SCDActiveFlag='N'
			FROM ser.ProductProperty  property
			WHERE property.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp WHERE record_type = 'child')
			AND property.SCDActiveFlag='Y'
			AND property.SCDEndDate != @scd_endDate
			
	PRINT 'Completed insertion of International CHILE source data to PRODUCT PROPERTY table'
			

/* 3.Table Name  :PRODUCT INDICATOR*/
	PRINT 'Started insertion of International CHILE source data to PRODUCT INDICATOR table'
			
			INSERT INTO ser.ProductIndicator
					(
					ProductId           ,					
					LOVIndicatorId      ,
					LOVRecordSourceId   ,
					Value               ,
					SCDStartDate        ,
					SCDEndDate          ,
					SCDActiveFlag       ,
					SCDVersion          ,
					SCDLOVRecordSourceId,
					ETLRunLogId			,
					PSARowKey
					)
			SELECT temp.ProductID,temp.LOVIndicatorId,temp.LOVRecordSourceId,temp.PIValue,
			CASE WHEN ((ISNULL(indicator.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,temp.LOVIndicatorId ORDER BY temp.SCDStartDate ASC)) = 1) 
							 THEN @scd_startDate ELSE temp.SCDStartDate 
			END SCDStartDate,
			temp.SCDEndDate,
			LEAD('N', 1, 'Y') OVER(PARTITION BY temp.ProductID,temp.LOVIndicatorId ORDER BY temp.SCDStartDate ASC) SCDActiveFlag,
			ISNULL(indicator.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID,temp.LOVIndicatorId ORDER BY temp.SCDStartDate ASC) SCDVersion,
			@chile_scdLovRecordSourceID SCDLOVRecordSourceId,
			temp.ETLRunLogId,temp.PSARowKey 
			FROM
				(SELECT 
						   ProductID ,  
						   LOVRecordSourceId,
						   (SELECT LOVId FROM ser.RefLOV WHERE LOVKey = ''+PICol+'' AND
						   LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = 'Indicator - Chile Product')) LOVIndicatorId,
						   PIValue,
						   SCDStartDate,
						   SCDEndDate,
						   ETLRunLogId,
						   PSARowKey
				FROM 
							(SELECT clprod.ProductID,
							clprod.LOVRecordSourceId,   
							clprod.exclusive_flag,
							clprod.own_brand_flag,
							clprod.date_added SCDStartDate,
							@scd_endDate SCDEndDate,				
							clprod.etl_runlog_id ETLRunLogId,
							clprod.PSARowKey
							FROM psa.rawcl_crp_product_temp clprod
							WHERE clprod.record_type = 'parent') t
							UNPIVOT
							(PIValue FOR PICol in (exclusive_flag,own_brand_flag)
							) AS ProductIndicator WHERE  PIValue!='' AND PIValue IS NOT NULL
							) temp
			LEFT JOIN ser.productIndicator indicator
			ON indicator.ProductId = temp.ProductId
			AND indicator.LOVIndicatorId = temp.LOVIndicatorId 
			AND indicator.LOVRecordSourceId = temp.LOVRecordSourceId
			AND indicator.SCDActiveFlag = 'Y'

	PRINT 'Closing out old PRODUCT INDICATOR records if exists'

			--Updating SCDEndDate with the date_added of next record having same ProductID and LOVIndicatorId
			UPDATE indicator SET SCDEndDate = t.SCDEndDate				
			FROM ser.ProductIndicator indicator
			JOIN 
			(SELECT i.LOVRecordSourceId,i.ProductId,i.LOVIndicatorId,i.SCDStartDate,
			LEAD(i.SCDStartDate,1,@scd_endDate) OVER(PARTITION BY i.ProductID,i.LOVIndicatorId ORDER BY i.SCDStartDate ASC) SCDEndDate 
			FROM ser.ProductIndicator i
			WHERE i.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp WHERE record_type = 'parent')
			)t
			ON t.LOVRecordSourceId = indicator.LOVRecordSourceId AND t.ProductId = indicator.ProductId 
			AND t.LOVIndicatorId = indicator.LOVIndicatorId AND t.SCDStartDate = indicator.SCDStartDate

			--Updating  active flag to N for  the closed records
			UPDATE indicator SET indicator.SCDActiveFlag='N'
			FROM ser.ProductIndicator indicator
			WHERE indicator.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp WHERE record_type = 'parent')
			AND indicator.SCDActiveFlag='Y'
			AND indicator.SCDEndDate != @scd_endDate
			
	PRINT 'Completed insertion of International CHILE source data to PRODUCT INDICATOR table'
			

/* 4.Table Name  :PRODUCT STATUS*/
	PRINT 'Started insertion of International CHILE source data to PRODUCT STATUS table'
			
			INSERT INTO ser.ProductStatus 
				(
				ProductId			,          
				LOVStatusId			,
				LOVProductStatusSetId,
				LOVRecordSourceId   , 
				EffectiveFrom		,       
				EffectiveTo			,         
				SCDStartDate		,        
				SCDEndDate			,          
				SCDActiveFlag		,       
				SCDVersion			,          
				SCDLOVRecordSourceId,
				ETLRunLogId			,
				PSARowKey
				)
			SELECT
				temp.ProductID,
				itmstat.LOVId LOVStatusId,
				itmstat.LOVSetId LOVProductStatusSetId,
				temp.LOVRecordSourceId,
				temp.date_added EffectiveFrom,
				NULL EffectiveTo,
				CASE WHEN ((ISNULL(pstatus.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID ORDER BY temp.date_added ASC)) = 1) 
							 THEN @scd_startDate ELSE temp.date_added 
				END SCDStartDate,
				@scd_endDate SCDEndDate,          
				LEAD('N', 1, 'Y') OVER(PARTITION BY temp.ProductID ORDER BY temp.date_added ASC) SCDActiveFlag,                
				ISNULL(pstatus.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY temp.ProductID ORDER BY temp.date_added ASC) SCDVersion,
				@chile_scdLovRecordSourceID SCDLOVRecordSourceId,
				temp.etl_runlog_id ETLRunLogId,
				temp.PSARowKey
				FROM psa.rawcl_crp_product_temp temp			
				JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId,rl.LOVSetId FROM  ser.RefLOV rl join ser.RefLOVSet rls
				ON rl.LOVSetID = rls.LOVSetID and rl.LOVRecordSourceId = rls.LovSetRecordSourceId and rls.LOVSetName='item_status') itmstat
				ON temp.LOVRecordSourceId =itmstat.LOVRecordSourceId and temp.item_status=itmstat.LOVKey
				AND temp.record_type = 'parent'
				AND temp.item_status!= '' AND temp.item_status IS NOT NULL
				LEFT JOIN ser.ProductStatus pstatus
				ON pstatus.ProductID = temp.ProductID
				AND pstatus.LOVRecordSourceId = temp.LOVRecordSourceId
				AND pstatus.SCDActiveFlag = 'Y'	

	PRINT 'Closing out old PRODUCT STATUS records if exists'
			--Updating SCDEndDate with the date_added of next record having same ProductID
			UPDATE pstatus SET SCDEndDate = t.SCDEndDate				
			FROM ser.ProductStatus pstatus
			JOIN 
			(SELECT pstat.LOVRecordSourceId,pstat.ProductId,pstat.SCDStartDate,
			LEAD(pstat.SCDStartDate,1,@scd_endDate) OVER(PARTITION BY pstat.ProductID ORDER BY pstat.SCDStartDate ASC) SCDEndDate 
			FROM ser.ProductStatus pstat
			WHERE pstat.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp WHERE record_type = 'parent')
			)t
			ON t.LOVRecordSourceId = pstatus.LOVRecordSourceId AND t.ProductId = pstatus.ProductId 
			AND t.SCDStartDate = pstatus.SCDStartDate
			
			--Updating  active flag to N for  the closed records
			UPDATE pstatus SET pstatus.SCDActiveFlag='N'
			FROM ser.ProductStatus pstatus
			WHERE pstatus.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp WHERE record_type = 'parent')
			AND pstatus.SCDActiveFlag='Y'
			AND pstatus.SCDEndDate != @scd_endDate

	PRINT 'Completed insertion of International CHILE source data to PRODUCT STATUS table'

/* 5.Table Name  :PRODUCT GROUP*/

/*********** Populating psa.rawcl_crp_product_groupTemp with join conditions for Product Group***********/
	PRINT 'Started insertion of International CHILE source data to rawcl_crp_product_groupTemp table'
	
	INSERT INTO psa.rawcl_crp_product_groupTemp
	SELECT
				clprod.PSARowKey,
				clprod.ProductID,
				clprod.SourceKey,            
				clprod.LOVRecordSourceId, 
				@chile_scdLovRecordSourceID SCDLOVRecordSourceId,
				clprod.date_added SCDStartDate,
				@scd_endDate SCDEndDate,
				clprod.etl_runlog_id ETLRunLogId,
				phc1.lovid product_hierarchy1_code,
				phn1.lovid product_hierarchy1_name,
				phc2.lovid product_hierarchy2_code,
				phn2.lovid product_hierarchy2_name,
				phc3.lovid product_hierarchy3_code,
				phn3.lovid product_hierarchy3_name,
				phc4.lovid product_hierarchy4_code,
				phn4.lovid product_hierarchy4_name,
				phc5.lovid product_hierarchy5_code,
				phn5.lovid product_hierarchy5_name 
				FROM psa.rawcl_crp_product_temp clprod
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceID = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy1_code') phc1
				ON clprod.LOVRecordSourceId =phc1.LOVRecordSourceId AND phc1.LOVKey=clprod.product_hierarchy1_code 
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceID = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy1_name') phn1
				ON clprod.LOVRecordSourceId =phn1.LOVRecordSourceId AND phn1.LOVKey=clprod.product_hierarchy1
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceID = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy2_code') phc2
				ON clprod.LOVRecordSourceId =phc2.LOVRecordSourceId AND phc2.LOVKey=clprod.product_hierarchy2_code
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy2_name') phn2
				ON clprod.LOVRecordSourceId =phn2.LOVRecordSourceId AND phn2.LOVKey=clprod.product_hierarchy2
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy3_code') phc3
				ON clprod.LOVRecordSourceId =phc3.LOVRecordSourceId AND phc3.LOVKey=clprod.product_hierarchy3_code
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy3_name') phn3
				ON clprod.LOVRecordSourceId =phn3.LOVRecordSourceId AND phn3.LOVKey=clprod.product_hierarchy3
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy4_code') phc4
				ON clprod.LOVRecordSourceId =phc4.LOVRecordSourceId AND phc4.LOVKey=clprod.product_hierarchy4_code
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy4_name') phn4
				ON clprod.LOVRecordSourceId =phn4.LOVRecordSourceId AND phn4.LOVKey=clprod.product_hierarchy4
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy5_code') phc5
				ON clprod.LOVRecordSourceId =phc5.LOVRecordSourceId AND phc5.LOVKey=clprod.product_hierarchy5_code
				LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
				ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='product_hierarchy5_name') phn5
				ON clprod.LOVRecordSourceId =phn5.LOVRecordSourceId AND phn5.LOVKey=clprod.product_hierarchy5
				WHERE clprod.record_type = 'parent'
	
	PRINT 'Completed insertion of International CHILE source data to rawcl_crp_product_groupTemp table'
	
	SELECT @max_productGroupID = COALESCE(MAX(ProductGroupId),0) FROM ser.ProductGroup

/*********** Inserting into ProductGroup by un pivoting the hierarchy columns ***********/
	PRINT 'Started insertion of International CHILE source data to PRODUCT GROUP table'
			
			INSERT  INTO  ser.ProductGroup
							(
							ProductGroupId		  ,
							ProductId			  ,
							LOVGroupId            ,
							LOVProductGroupSetId  ,
							ParentProductGroupId  ,
							LOVRecordSourceId     ,
							SCDStartDate          ,
							SCDEndDate            ,
							SCDActiveFlag         ,
							SCDVersion            ,
							SCDLOVRecordSourceId  ,
							ETLRunLogId			  ,
							PSARowKey
							)
			SELECT 
						ISNULL(pdtGroup.ProductGroupId,temp.ProductGroupId) ProductGroupId,
						pgTemp.ProductId,
						pgTemp.PGValue LOVGroupId,
						pgTemp.LOVProductGroupSetId,
						NULL ParentProductGroupId,
						pgTemp.LOVRecordSourceId,
						CASE WHEN ((ISNULL(pdtGroup.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgTemp.ProductId,pgTemp.LOVProductGroupSetId ORDER BY pgTemp.SCDStartDate ASC)) = 1) 
							 THEN @scd_startDate ELSE pgTemp.SCDStartDate 
						END SCDStartDate,
						pgTemp.SCDEndDate,
						LEAD('N', 1, 'Y') OVER(PARTITION BY pgTemp.ProductId,pgTemp.LOVProductGroupSetId ORDER BY pgTemp.SCDStartDate ASC) SCDActiveFlag,	
						ISNULL(pdtGroup.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pgTemp.ProductId,pgTemp.LOVProductGroupSetId ORDER BY pgTemp.SCDStartDate ASC) AS SCDVersion,						
						pgTemp.SCDLOVRecordSourceId,
						pgTemp.ETLRunLogId,
						pgTemp.PSARowKey
			FROM
						(SELECT ProductId,
								(SELECT LOVSetID FROM ser.RefLOV WHERE LOVId = PGValue) LOVProductGroupSetId,
								PGValue,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey 
						FROM
							(SELECT ProductId,product_hierarchy1_code,product_hierarchy1_name,
							product_hierarchy2_code,product_hierarchy2_name,product_hierarchy3_code,product_hierarchy3_name,product_hierarchy4_code,
							product_hierarchy4_name,product_hierarchy5_code,product_hierarchy5_name,SCDStartDate,SCDEndDate,
							SCDLOVRecordSourceId,LOVRecordSourceId,ETLRunLogId,PSARowKey
							FROM psa.rawcl_crp_product_groupTemp) t
				UNPIVOT  
							( PGValue FOR PGCol IN (product_hierarchy1_code,product_hierarchy1_name,product_hierarchy2_code,
													product_hierarchy2_name,product_hierarchy3_code,product_hierarchy3_name,
													product_hierarchy4_code,product_hierarchy4_name,product_hierarchy5_code,product_hierarchy5_name)
							)	AS LOVGroupId WHERE  PGValue!='' AND PGValue IS NOT NULL 
							) AS pgTemp
			JOIN 
						(SELECT ProductId,LOVProductGroupSetId,(@max_productGroupID+ROW_NUMBER() OVER(ORDER BY ProductId,LOVProductGroupSetId ASC)) ProductGroupId
						FROM 
							(SELECT ProductId,
									(SELECT LOVSetID FROM ser.RefLOV WHERE LOVId = PGValue) LOVProductGroupSetId 
							FROM
							(SELECT ProductId,				
							product_hierarchy1_code,product_hierarchy1_name,
							product_hierarchy2_code,product_hierarchy2_name,product_hierarchy3_code,product_hierarchy3_name,
							product_hierarchy4_code,product_hierarchy4_name,product_hierarchy5_code,product_hierarchy5_name					
							FROM psa.rawcl_crp_product_groupTemp) t
						UNPIVOT  
							( PGValue FOR PGCol IN (product_hierarchy1_code,product_hierarchy1_name,product_hierarchy2_code,
													product_hierarchy2_name,product_hierarchy3_code,product_hierarchy3_name,
													product_hierarchy4_code,product_hierarchy4_name,product_hierarchy5_code,
													product_hierarchy5_name)
							)	AS LOVGroupId WHERE  PGValue!='' AND PGValue IS NOT NULL 
							) a 
						GROUP BY ProductId,LOVProductGroupSetId) temp
			ON 	temp.ProductId = pgTemp.ProductId AND temp.LOVProductGroupSetId = pgTemp.LOVProductGroupSetId 
			LEFT JOIN ser.ProductGroup pdtGroup
			ON pdtGroup.ProductId = pgTemp.ProductId
			AND pdtGroup.LOVProductGroupSetId = pgTemp.LOVProductGroupSetId 
			AND pdtGroup.LOVRecordSourceId = pgTemp.LOVRecordSourceId
			AND pdtGroup.SCDActiveFlag = 'Y'
	
	PRINT 'Closing out old PRODUCT GROUP records if exists'

			UPDATE pdtGroup SET SCDEndDate = t.SCDEndDate				
			FROM ser.ProductGroup pdtGroup
			JOIN 
			(SELECT pg.LOVRecordSourceId,pg.ProductId,pg.LOVProductGroupSetId,pg.SCDStartDate,
			LEAD(pg.SCDStartDate,1,@scd_endDate) OVER(PARTITION BY pg.ProductId,pg.LOVProductGroupSetId ORDER BY pg.SCDStartDate ASC) SCDEndDate 
			FROM ser.ProductGroup pg
			WHERE pg.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp)
			)t
			ON t.LOVRecordSourceId = pdtGroup.LOVRecordSourceId AND t.ProductId = pdtGroup.ProductId 
			AND t.LOVProductGroupSetId = pdtGroup.LOVProductGroupSetId  AND t.SCDStartDate = pdtGroup.SCDStartDate

			UPDATE pdtGroup SET pdtGroup.SCDActiveFlag='N'
			FROM ser.ProductGroup pdtGroup
			WHERE pdtGroup.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp)
			AND pdtGroup.SCDActiveFlag='Y'
			AND pdtGroup.SCDEndDate != @scd_endDate

	PRINT 'Completed insertion of International CHILE source data to PRODUCT GROUP table'	

/* 6.Table Name  : PARTY*/
	PRINT 'Started insertion of International CHILE source data to PARTY table'		
			
			SET @max_partyID = (SELECT COALESCE(MAX(PartyId),0) FROM ser.Party)
			SET @party_typeID = (SELECT LovId FROM ser.RefLOV WHERE LOVKey = 'ORG' and LOVSetId=
							(SELECT LOVSetID FROM ser.RefLOVSet WHERE  LOVSetName = 'Party Type'  ))
			INSERT INTO ser.Party
					(                         
					PartyId                ,
					LOVPartyTypeId         ,
					SourceKey              ,
					LOVRecordSourceId      ,                
					SCDEndDate             ,
					SCDActiveFlag          ,
					SCDVersion             ,
					SCDLOVRecordSourceId   ,
					ETLRunLogId            ,				  
					SCDStartDate           ,
					PSARowKey
					)
			SELECT  @max_partyID+ROW_NUMBER() OVER(ORDER BY t.SourceKey,t.LOVRecordSourceId ASC) partyId,
					@party_typeID  LOVPartyTypeId,
					t.SourceKey,
					t.LOVRecordSourceId,
					@scd_endDate SCDEndDate,
					'Y' SCDActiveFlag,
					1 SCDVersion,
					@chile_scdLovRecordSourceID SCDLOVRecordSourceId,
					ETLRunLogId,
					@scd_startDate SCDStartDate ,
					PSARowKey
			FROM
			(SELECT supplier_number SourceKey,LOVRecordSourceId,etl_runlog_id ETLRunLogId,MIN(date_added) SCDStartDate,MIN(PSARowKey) PSARowKey
			FROM psa.rawcl_crp_product_temp temp 
			WHERE temp.supplier_number!='' AND temp.supplier_number IS NOT NULL
			GROUP BY supplier_number,LOVRecordSourceId,etl_runlog_id)t
			WHERE NOT EXISTS
			(SELECT sourcekey, LOVRecordSourceId FROM ser.Party party WHERE t.sourcekey=party.sourcekey and t.LOVRecordSourceId=party.LOVRecordSourceId )
	
	PRINT 'Completed insertion of International CHILE source data to PARTY table'
	
/* 7.Table Name  : ORGANISATION*/
	PRINT 'Started insertion of International CHILE source data to ORGANISATION table'			
			
			INSERT INTO ser.Organisation	
						(
						PartyId				 ,
						SourceOrganisationKey,
						OrganisationName	 ,
						LOVRecordSourceId    ,
						ParentPartyId		 ,
						SCDStartDate		 ,
						SCDEndDate			 ,
						SCDActiveFlag		 ,
						SCDVersion			 ,
						SCDLOVRecordSourceId ,
						ETLRunLogId			 ,
						PSARowKey			 
									 
						)	
			SELECT	party.PartyId  PartyId,
					t.SourceOrganisationKey,
					t.OrganisationName,
					t.LOVRecordSourceId,
					NULL ParentPartyId,
					CASE WHEN ((ISNULL(org.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC)) = 1) 
							 THEN @scd_startDate ELSE t.SCDStartDate 
					END SCDStartDate,
					@scd_endDate SCDEndDate,
					LEAD('N', 1, 'Y') OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC) SCDActiveFlag,
					ISNULL(org.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC) SCDVersion,
					@chile_scdLovRecordSourceID SCDLOVRecordSourceId,
					t.ETLRunLogId,
					t.PSARowKey
			FROM
						(SELECT supplier_number SourceOrganisationKey,supplier_name OrganisationName,LOVRecordSourceId,etl_runlog_id ETLRunLogId,
						MIN(date_added) SCDStartDate,MIN(PSARowKey) PSARowKey
						FROM psa.rawcl_crp_product_temp temp 
						WHERE temp.supplier_number!='' AND temp.supplier_number IS NOT NULL
						GROUP BY supplier_number,supplier_name,LOVRecordSourceId,etl_runlog_id)t
			JOIN ser.Party party
			ON t.SourceOrganisationKey = party.SourceKey and party.SCDActiveFlag='Y'
			AND t.LOVRecordSourceId=party.LOVRecordSourceId
			LEFT JOIN ser.Organisation org
			ON org.PartyId = party.PartyId
			AND org.LOVRecordSourceId = t.LOVRecordSourceId
			AND org.SCDActiveFlag = 'Y'	
			WHERE NOT EXISTS
			(SELECT SourceOrganisationKey,OrganisationName,LOVRecordSourceId FROM ser.Organisation org  
			WHERE t.SourceOrganisationKey=org.SourceOrganisationKey AND t.OrganisationName=org.OrganisationName 
			AND t.LOVRecordSourceId=org.LOVRecordSourceId )

	PRINT 'Closing out old ORGANISATION records if exists'

			--Updating SCDEndDate with the date_added of next record having same PartyId
			UPDATE org SET SCDEndDate = t.SCDEndDate				
			FROM ser.Organisation org
			JOIN 
			(SELECT orgTemp.LOVRecordSourceId,orgTemp.PartyId,orgTemp.SCDStartDate,
			LEAD(orgTemp.SCDStartDate,1,@scd_endDate) OVER(PARTITION BY orgTemp.PartyId ORDER BY orgTemp.SCDStartDate ASC) SCDEndDate 
			FROM ser.Organisation orgTemp
			WHERE orgTemp.SourceOrganisationKey IN (SELECT DISTINCT supplier_number FROM psa.rawcl_crp_product_temp)
			AND orgTemp.LOVRecordSourceId = @chile_lovRecordSourceID
			)t
			ON t.LOVRecordSourceId = org.LOVRecordSourceId AND t.PartyId = org.PartyId 
			AND t.SCDStartDate = org.SCDStartDate

			--Updating  active flag to N for  the closed records
			UPDATE org SET org.SCDActiveFlag='N'
			FROM ser.Organisation org
			WHERE org.SourceOrganisationKey IN (SELECT DISTINCT supplier_number FROM psa.rawcl_crp_product_temp)
			AND org.LOVRecordSourceId = @chile_lovRecordSourceID
			AND org.SCDActiveFlag='Y'
			AND org.SCDEndDate != @scd_endDate

	PRINT 'Completed insertion of International CHILE source data to ORGANISATION table'	

/* 8.Table Name  :PARTY ROLE*/
	PRINT 'Started insertion of International CHILE source data to PARTY ROLE table'			
			
			SET @max_partyRoleID=(SELECT COALESCE(MAX(PartyRoleId),0) FROM ser.PartyRole)
			SET @supplier_LOVRoleId = (SELECT LovId FROM ser.RefLOV WHERE LOVKey = 'Supplier' 
										AND LOVSetId=(SELECT LOVSetID FROM ser.RefLOVSet WHERE  LOVSetName = 'Role' )) 
			SET @retailer_LOVRoleId  = (SELECT LovId FROM ser.RefLOV WHERE LOVKey = 'Retailer' 
										AND LOVSetId=(SELECT LOVSetID FROM ser.RefLOVSet WHERE  LOVSetName = 'Role' ))
			INSERT INTO ser.PartyRole
					(
					PartyRoleId			,
					LOVRoleId			,
					PartyId				,
					SourceKey			,
					PartyRoleName		,
					LOVRecordSourceId   ,
					SCDStartDate	    ,
					SCDEndDate			,
					SCDActiveFlag       ,
					SCDVersiON          ,
					SCDLOVRecordSourceId,
					ETLRunLogId			,
					PSARowKey
					)
			SELECT	ISNULL(pRole.PartyRoleId,a.PartyRoleId) PartyRoleId,
					@supplier_LOVRoleId LOVRoleId,
					party.PartyId PartyId,
					t.SourceKey,
					t.PartyRoleName,
					t.LOVRecordSourceId,
					CASE WHEN ((ISNULL(pRole.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC)) = 1) 
							 THEN @scd_startDate ELSE t.SCDStartDate 
					END SCDStartDate,
					@scd_endDate SCDEndDate,
					LEAD('N', 1, 'Y') OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC) SCDActiveFlag,
					ISNULL(pRole.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC) SCDVersion,
					@chile_scdLovRecordSourceID SCDLOVRecordSourceId,
					t.ETLRunLogId,
					t.PSARowKey
			FROM
						(SELECT supplier_number SourceKey,supplier_name PartyRoleName,LOVRecordSourceId,etl_runlog_id ETLRunLogId,
						MIN(date_added) SCDStartDate,MIN(PSARowKey) PSARowKey
						FROM psa.rawcl_crp_product_temp temp 
						WHERE temp.supplier_number!='' AND temp.supplier_number IS NOT NULL
						GROUP BY supplier_number,supplier_name,LOVRecordSourceId,etl_runlog_id)t
			JOIN (SELECT supplier_number,@max_partyRoleID+ROW_NUMBER() OVER(ORDER BY supplier_number,LOVRecordSourceId ASC) PartyRoleId
			FROM psa.rawcl_crp_product_temp GROUP BY supplier_number,LOVRecordSourceId
			) a
			ON t.SourceKey = a.supplier_number
			JOIN ser.Party party
			ON t.SourceKey = party.SourceKey and party.SCDActiveFlag='Y'
			AND t.LOVRecordSourceId = party.LOVRecordSourceId
			LEFT JOIN ser.PartyRole pRole
			ON pRole.PartyId = party.PartyId
			AND pRole.LOVRecordSourceId = t.LOVRecordSourceId
			AND pRole.SCDActiveFlag = 'Y'	
			WHERE NOT EXISTS
			(SELECT SourceKey,PartyRoleName,LOVRecordSourceId FROM ser.PartyRole pr 
			WHERE t.SourceKey=pr.SourceKey AND t.PartyRoleName=pr.PartyRoleName 
			AND t.LOVRecordSourceId=pr.LOVRecordSourceId )

	PRINT 'Closing out old PARTY ROLE records if exists'
			--Updating SCDEndDate with the date_added of next record having same PartyId
			UPDATE pRole SET SCDEndDate = t.SCDEndDate				
			FROM ser.PartyRole pRole
			JOIN 
			(SELECT pr.LOVRecordSourceId,pr.PartyId,pr.SCDStartDate,
			LEAD(pr.SCDStartDate,1,@scd_endDate) OVER(PARTITION BY pr.PartyId ORDER BY pr.SCDStartDate ASC) SCDEndDate 
			FROM ser.PartyRole pr
			WHERE pr.SourceKey IN (SELECT DISTINCT supplier_number FROM psa.rawcl_crp_product_temp)
			AND pr.LOVRecordSourceId = @chile_lovRecordSourceID
			)t
			ON t.LOVRecordSourceId = pRole.LOVRecordSourceId AND t.PartyId = pRole.PartyId 
			AND t.SCDStartDate = pRole.SCDStartDate

			--Updating  active flag to N for  the closed records
			UPDATE pRole SET pRole.SCDActiveFlag='N'
			FROM ser.PartyRole pRole
			WHERE pRole.SourceKey IN (SELECT DISTINCT supplier_number FROM psa.rawcl_crp_product_temp)
			AND pRole.LOVRecordSourceId = @chile_lovRecordSourceID
			AND pRole.SCDActiveFlag='Y'
			AND pRole.SCDEndDate != @scd_endDate

	PRINT 'Completed insertion of International CHILE source data to PARTY ROLE table'
	
/* 9.Table Name  :PRODUCT PARTY ROLE*/
	PRINT 'Started insertion of International CHILE source data to PRODUCT PARTY ROLE table'
			
			SELECT @partyRoleID = [PartyRoleId] FROM ser.PartyRole WHERE SourceKey =  'WBA-CL-FA' 
			and LOVRecordSourceId= @chile_lovRecordSourceID
	
			INSERT INTO ser.ProductPartyRole
						(
						ProductId,
						PartyRoleId,  
						LOVRecordSourceId,
						SCDStartDate,
						SCDEndDate,      
						SCDActiveFlag,
						SCDVersion,  
						SCDLOVRecordSourceId,
						ETLRunLogId,
						PSARowKey
						)
			SELECT 
						proPtyRole.ProductId,proPtyRole.PartyRoleId,proPtyRole.LOVRecordSourceId,
						CASE WHEN ((ISNULL(t.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY proPtyRole.ProductId,proPtyRole.LOVRoleId ORDER BY proPtyRole.SCDStartDate ASC)) = 1) 
							 THEN @scd_startDate ELSE proPtyRole.SCDStartDate 
						END SCDStartDate,
						proPtyRole.SCDEndDate,
						LEAD('N', 1, 'Y') OVER(PARTITION BY proPtyRole.ProductId,proPtyRole.LOVRoleId ORDER BY proPtyRole.SCDStartDate ASC) SCDActiveFlag,
						ISNULL(t.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY proPtyRole.ProductId,proPtyRole.LOVRoleId ORDER BY proPtyRole.SCDStartDate ASC) SCDVersion,
						proPtyRole.SCDLOVRecordSourceId,
						proPtyRole.ETLRunLogId,
						proPtyRole.PSARowKey
			FROM
			(SELECT 
						@retailer_LOVRoleId LOVRoleId,
						ProductId,
						@partyRoleID PartyRoleId,
						LOVRecordSourceId,
						date_added SCDStartDate,
						@scd_endDate SCDEndDate,
						@chile_scdLovRecordSourceID SCDLOVRecordSourceId,
						etl_runlog_id ETLRunLogId,
						PSARowKey
						FROM psa.rawcl_crp_product_temp 
        				
			UNION      
			SELECT
						pr.LOVRoleId LOVRoleId,
						temp.ProductId,
						pr.PartyRoleId PartyRoleId,
						temp.LOVRecordSourceId,
						temp.date_added SCDStartDate,
						@scd_endDate SCDEndDate,
						@chile_scdLovRecordSourceID SCDLOVRecordSourceId,
						temp.etl_runlog_id ETLRunLogId,
						temp.PSARowKey
						FROM psa.rawcl_crp_product_temp temp                               
						JOIN ser.PartyRole pr ON temp.supplier_number = pr.SourceKey
						AND temp.record_type = 'child' AND temp.supplier_number!='' AND temp.supplier_number IS NOT NULL
						AND temp.LOVRecordSourceId = pr.LOVRecordSourceId AND pr.SCDActiveFlag='Y'
						) proPtyRole			
			LEFT JOIN (SELECT pPRole.ProductId,pPRole.LOVRecordSourceId,pPRole.SCDVersion,pRole.LOVRoleId FROM ser.ProductPartyRole pPRole 
						JOIN ser.PartyRole pRole
						ON pPRole.LOVRecordSourceId = pRole.LOVRecordSourceId
						AND pPRole.PartyRoleId = pRole.PartyRoleId
						AND pPRole.LOVRecordSourceId = @chile_lovRecordSourceID
						AND ISNULL(pPRole.SCDActiveFlag,'Y')='Y'
						AND pRole.SCDActiveFlag = 'Y')t
            ON t.ProductId = proPtyRole.ProductId
            AND t.LOVRoleId = proPtyRole.LOVRoleId
            AND t.LOVRecordSourceId = proPtyRole.LOVRecordSourceId

	PRINT 'Closing out old PRODUCT PARTY ROLE records if exists'

			--Updating SCDEndDate with the date_added of next record having same ProductId and PartyRoleId
			UPDATE proPtyRole SET SCDEndDate = t.SCDEndDate				
			FROM ser.ProductPartyRole proPtyRole
			JOIN 
			(SELECT prr.LOVRecordSourceId,prr.ProductId,prr.PartyRoleId,prr.SCDStartDate,prr.SCDVersion,
			LEAD(prr.SCDStartDate,1,@scd_endDate) OVER(PARTITION BY prr.ProductId,pr.LOVRoleId ORDER BY prr.SCDStartDate ASC) SCDEndDate 
			FROM ser.ProductPartyRole prr
			JOIN ser.PartyRole pr
			ON pr.PartyRoleId =prr.PartyRoleId AND pr.LOVRecordSourceId=prr.LOVRecordSourceId
			AND pr.SCDActiveFlag = 'Y'
			AND prr.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp)
			)t
			ON t.LOVRecordSourceId = proPtyRole.LOVRecordSourceId AND t.ProductId = proPtyRole.ProductId 
			AND t.PartyRoleId = proPtyRole.PartyRoleId  AND t.SCDStartDate = proPtyRole.SCDStartDate
			AND t.SCDVersion=proPtyRole.SCDVersion

			--Updating  active flag to N for  the closed records
			UPDATE proPtyRole SET proPtyRole.SCDActiveFlag='N'
			FROM ser.ProductPartyRole proPtyRole
			WHERE proPtyRole.ProductId IN (SELECT ProductId FROM psa.rawcl_crp_product_temp)
			AND proPtyRole.SCDActiveFlag='Y'
			AND proPtyRole.SCDEndDate != @scd_endDate

	PRINT 'Completed insertion of International CHILE source data to PRODUCT PARTY ROLE table'

	UPDATE psa.rawcl_crp_product SET row_status=@rowStatusSERCode
	FROM psa.rawcl_crp_product clprod 
	INNER JOIN ser.Product p ON clprod.row_id=p.PSARowKey and clprod.record_source_id=p.LovRecordSourceID 
	WHERE clprod.row_status=@rowStatusPSACode  AND p.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))
		
	PRINT 'Updated Row Status to ''Loaded to Serve'' for psa.rawcl_crp_product International CHILE  '
	
	COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH 
				THROW;					
				ROLLBACK TRANSACTION ;						
			END CATCH 
			drop table [psa].[rawcl_crp_product_temp]
			PRINT 'Dropped Temp table for International CHILE-> psa.rawcl_crp_product_temp'

			drop table [psa].[rawcl_crp_product_groupTemp]
			PRINT 'Dropped Temp table for International CHILE-> psa.rawcl_crp_product_groupTemp'

	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.SP_MERCHANDISING_CURATION_CRP_MERCHANDISING_THAILAND_HISTORY') IS NOT NULL
BEGIN
    DROP PROC psa.SP_MERCHANDISING_CURATION_CRP_MERCHANDISING_THAILAND_HISTORY
END
GO

CREATE PROCEDURE [psa].[SP_MERCHANDISING_CURATION_CRP_MERCHANDISING_THAILAND_HISTORY] @psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max) AS
/*
************************************************************************************************************
Procedure Name				: [SP_MERCHANDISING_CURATION_CRP_MERCHANDISING_THAILAND_HISTORY]
Purpose						: Load History data From International Thailand Source([RAWTH_CRP_MERCHANDISE]) into Serve Layer Table
Domain						: Merchandise
ServeLayer Target Tables	: Planogram, PlanogramGroup, PlanogramProperty, PlanogramIndicator (Total 4 Tables)
RecordSourceID  for International Thaiand : 12010
*****************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
 */ 

BEGIN

	/*--Declarations---*/
	DECLARE @max_PlanogramId BIGINT;
	DECLARE @max_PlanogramGroupId BIGINT;
	DECLARE @rowStatusPSACode BIGINT;	
	DECLARE	@rowStatusSERCode BIGINT;
	DECLARE @th_measuretypeid BIGINT;
	DECLARE @lovsourcekeytypeid BIGINT;
	
	SET @lovsourcekeytypeid = (SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
		ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Source Key Type' and 
		rl.LOVKey = 'Thailand Planogram dbkey');

	SET @rowStatusPSACode = 26001
	SET @rowStatusSERCode = 26002 

	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_PlanogramId = COALESCE(MAX(PlanogramId),0) FROM [ser].[Planogram];
	SELECT @max_PlanogramGroupId = COALESCE(MAX(PlanogramGroupId),0) FROM [ser].[planogramgroup];
	
	/*-------------------------------Create temporary source table-------------------------------*/
	
		IF OBJECT_ID('tempdb..#RAWTH_CRP_MERCHANDISE_temp') is not null
		BEGIN
			DROP TABLE #RAWTH_CRP_MERCHANDISE_temp
		END
	

	SELECT
	(DENSE_RANK() OVER(ORDER BY db_key,pog_id,planogram_start_date,planogram_end_date,date_added)) AS PlanogramId
    ,*
	INTO #RAWTH_CRP_MERCHANDISE_temp
	FROM (SELECT distinct * from [psa].[RAWTH_CRP_MERCHANDISE] where [row_status]=@rowStatusPSACode and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')))a;


	BEGIN TRANSACTION;
	BEGIN TRY	
	
	update ser.Planogram
	set scdstartdate = src.date_added
	from ser.planogram p
	join psa.rawth_crp_merchandise src
	on src.row_id = p.psarowkey
	and src.record_source_id = p.lovrecordsourceid
	where p.scdstartdate = '1900-01-01' and p.lovrecordsourceid = 12010 and p.lovsourcekeytypeid = @lovsourcekeytypeid
	
	
	/*-------------------------------Loading Parent records in Planogram table -------------------*/
	
	INSERT INTO [ser].[Planogram]
  (
	[PlanogramId]
	,[SourceKey]
	,[LOVSourceKeyTypeId]
	,[ParentPlanogramId]
	,[PlanogramStartDate]
	,[PlanogramEndDate]
	,[PlanogramName]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		@max_PlanogramId + (DENSE_RANK() OVER(ORDER BY B.pog_id)) AS PlanogramId
		,B.[SourceKey]
		,B.[LOVSourceKeyTypeId]
		,B.[ParentPlanogramId]
		,B.[PlanogramStartDate]
		,B.[PlanogramEndDate]
		,B.[PlanogramName]
		,B.[LOVRecordSourceId]
		,'1900-01-01 00:00:00' [SCDStartDate]
		,LEAD(B.SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY B.pog_id ORDER BY B.SCDStartDate,B.psarowkey ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY B.pog_id ORDER BY B.SCDStartDate,B.psarowkey ASC) AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY B.pog_id ORDER BY B.SCDStartDate,B.psarowkey ASC) AS [SCDVersion]
		,B.[SCDLOVRecordSourceId]
		,B.[ETLRunLogId]
		,B.[PSARowKey]
		FROM
			(select * from
			(
			SELECT
			src.pog_id as [pog_id]			 
			,src.pog_id AS [SourceKey]
			,lkp_refl.LOVId AS [LOVSourceKeyTypeId]
			,NULL AS [ParentPlanogramId]
			,NULL AS [PlanogramStartDate]
			,NULL AS [PlanogramEndDate]
			,CASE WHEN (src.pog_id IS NULL OR src.pog_id = '') then NULL ELSE src.pog_description END AS [PlanogramName]
			,12010 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			,ROW_NUMBER() OVER (partition by pog_id order by date_added desc) rno
			FROM [psa].[RAWTH_CRP_MERCHANDISE] src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Source Key Type' and rls.Lovsetrecordsourceid = 12012) lkp_refl
			ON lkp_refl.LOVKey =  'Thailand Planogram Id(pog_id)'
			where [row_status]=@rowStatusPSACode and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
			)a
		WHERE a.rno =1)B
		LEFT OUTER JOIN [ser].[Planogram] S on
		ISNULL(B.SourceKey,'DUMMY_SOURCEKEY_FORNULL') = ISNULL(S.SourceKey,'DUMMY_SOURCEKEY_FORNULL') 
		and B.LOVRecordSourceId = S.LOVRecordSourceId
		where S.SourceKey IS NULL and S.lovrecordsourceid IS NULL
		;

			RAISERROR ('Completed insertion of Parent Planogram source data Thailand to PLANOGRAM',0,1) WITH NOWAIT


					
	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_PlanogramId = COALESCE(MAX(PlanogramId),0) FROM [ser].[Planogram];	

	update #RAWTH_CRP_MERCHANDISE_temp
	set planogramid = planogramid + @max_PlanogramId;

	
		/*-------------------------------Loading child records in Planogram table--------------------------------------*/
	INSERT INTO [ser].[Planogram] 
	([PlanogramId]
	,[SourceKey]
	,[LOVSourceKeyTypeId]
	,[ParentPlanogramId]
	,[PlanogramStartDate]
	,[PlanogramEndDate]
	,[PlanogramName]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
	SELECT
	[PlanogramId]
	,[SourceKey]
	,[LOVSourceKeyTypeId]
	,[ParentPlanogramId]
	,CASE WHEN (PlanogramStartDate = '' or PlanogramStartDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramStartDate END AS [PlanogramStartDate]
	,CASE WHEN (PlanogramEndDate = '' or PlanogramEndDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramEndDate END AS [PlanogramEndDate]
	,[PlanogramName]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,LEAD([SCDStartDate],1,'9999-12-31 00:00:00') OVER (PARTITION BY [SourceKey],[pog_id],[PlanogramStartDate],[PlanogramEndDate],[SCDStartDate] ORDER BY [SCDStartDate],psarowkey ASC) AS [SCDEndDate]
	,LEAD('N',1,'Y') OVER (PARTITION BY [SourceKey],[pog_id],[PlanogramStartDate],[PlanogramEndDate],[SCDStartDate] ORDER BY [SCDStartDate],psarowkey ASC) AS [SCDActiveFlag]
	,ROW_NUMBER() OVER (PARTITION BY [SourceKey],[pog_id],[PlanogramStartDate],[PlanogramEndDate],[SCDStartDate] ORDER BY [SCDStartDate],psarowkey ASC) AS [SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	FROM
	(
		SELECT distinct
		case when (op.PlanogramId is null) then src.planogramid else op.planogramid end as planogramid
		,src.db_key AS [SourceKey]
		,lkp_refl.LOVId AS [LOVSourceKeyTypeId]
		,lkp_plan.PlanogramId AS [ParentPlanogramId]
		,src.planogram_start_date AS [PlanogramStartDate]
		,src.planogram_end_date AS [PlanogramEndDate]
		,src.pog_description AS [PlanogramName]
		,12010 AS [LOVRecordSourceId]
		,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID as [ETLRunLogId]
		,src.row_id as [PSARowKey]
		,src.pog_id AS [pog_id]
		FROM
		#RAWTH_CRP_MERCHANDISE_temp src
		LEFT OUTER JOIN
		(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
		ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Source Key Type' and rls.Lovsetrecordsourceid = 12012) lkp_refl
		ON lkp_refl.LOVKey =  'Thailand Planogram dbkey'
		LEFT OUTER JOIN
		[ser].[planogram] lkp_plan
		ON
		(
		ISNULL(lkp_plan.SourceKey,'DUMMY_POGID_FORNULL') = ISNULL(src.pog_id,'DUMMY_POGID_FORNULL')
		AND lkp_plan.LOVSourceKeyTypeId = 
			(SELECT rl.LOVId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Source Key Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey =  'Thailand Planogram Id(pog_id)'
			)
		AND lkp_plan.LOVRecordSourceId = 12010
		)
		left outer join (select distinct * from ser.planogram where lovrecordsourceid = 12010  
		and [LOVSourceKeyTypeId] = (SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
		ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Source Key Type' 
		and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'Thailand Planogram dbkey')) op
		on src.record_source_id = op.lovrecordsourceid
		and ISNULL(src.db_key,'DUMMY_DBKEY_FORNULL') = ISNULL(op.sourcekey,'DUMMY_DBKEY_FORNULL')
		and src.planogram_start_date= op.planogramstartdate
		and src.planogram_end_date= op.planogramenddate
		and src.date_added= op.scdstartdate
		and op.parentplanogramid = lkp_plan.planogramid
		and ISNULL(src.pog_id,'DUMMY_POGID_FORNULL') = ISNULL(lkp_plan.sourcekey,'DUMMY_POGID_FORNULL')
	)a
	;
	
	--update 1: This update statement updates the SCD Active Flag, SCD End date and SCD Version
	UPDATE [ser].[Planogram] 
	set scdactiveflag = F.scdactiveflag,
		SCDEndDate 	= F.SCDEndDate,
		SCDVersion = F.SCDVersion from  [ser].[Planogram] P join
	(select case
	when A.scdenddate = '9999-12-31 00:00:00.000' then 'Y' else 'N' end as scdactiveflag, A.SCDEndDate, A.[SCDVersion], A.psarowkey from
	(SELECT scdactiveflag,
    LEAD(i.SCDStartDate,1,'9999-12-31') OVER(PARTITION BY planogramid,[SourceKey],[PlanogramStartDate],[PlanogramEndDate],[SCDStartDate]
    ORDER BY i.SCDStartDate,i.psarowkey ASC) SCDEndDate ,
    ROW_NUMBER() OVER (PARTITION BY planogramid,[SourceKey],[PlanogramStartDate],[PlanogramEndDate],[SCDStartDate]
    ORDER BY [SCDStartDate],i.psarowkey ASC) AS [SCDVersion],
	psarowkey     FROM ser.planogram i
    where  LOVRecordSourceId =12010 and lovsourcekeytypeid = @lovsourcekeytypeid) A) F
	ON P.psarowkey = F.psarowkey
	where P.LOVRecordSourceId =12010 and P.lovsourcekeytypeid = @lovsourcekeytypeid
	;
	
	--update 2: This update statement updates the SCD Start Date
	UPDATE [ser].[Planogram]
	set SCDStartDate = '1900-01-01'
	where SCDVersion = 1 and LOVRecordSourceId =12010 and lovsourcekeytypeid = @lovsourcekeytypeid
	;

RAISERROR ('Completed insertion of child planogram THAILAND source data to PLANOGRAM table', 0, 1) WITH NOWAIT	

	/*--------------------------Loading Planogramgroup table---------------------------*/
	
	update #RAWTH_CRP_MERCHANDISE_temp
	set planogramid = p.planogramid
	from #RAWTH_CRP_MERCHANDISE_temp tmp
	join (select * from ser.planogram where lovrecordsourceid = 12010 and lovsourcekeytypeid = @lovsourcekeytypeid) p
	on p.psarowkey = tmp.row_id
	and p.lovrecordsourceid = 12010
	;
	
	INSERT INTO [ser].[planogramgroup]
	([PlanogramGroupId]
	,[PlanogramId]
	,[LOVPlanogramGroupSetId]
	,[LOVGroupId]
	,[ParentPlanogramGroupId]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		@max_PlanogramGroupId + (dense_rank() over (order by PlanogramId,LOVGroupId asc)) AS [PlanogramGroupId]
		,[PlanogramId]
		,[LOVPlanogramGroupSetId]
		,[LOVGroupId]
		,[ParentPlanogramGroupId]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY PlanogramId,LOVGroupId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY PlanogramId,LOVGroupId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY PlanogramId,LOVGroupId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12010 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #RAWTH_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='fitting_type' and rls.Lovsetrecordsourceid = 12010) lkp_refl
			ON src.fitting_type = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='fitting_type' AND lkp_refl_set.Lovsetrecordsourceid = 12010) 
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12010 and lovsourcekeytypeid = @lovsourcekeytypeid) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.fitting_type IS NOT NULL AND src.fitting_type <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12010 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #RAWTH_CRP_MERCHANDISE_temp src 
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='planner_family' and rls.Lovsetrecordsourceid = 12010) lkp_refl
			ON src.planner_family = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='planner_family' AND lkp_refl_set.Lovsetrecordsourceid = 12010)
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12010 and lovsourcekeytypeid = @lovsourcekeytypeid) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.planner_family IS NOT NULL AND src.planner_family <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12010 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #RAWTH_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='footprint' and rls.Lovsetrecordsourceid = 12010) lkp_refl
			ON src.footprint = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='footprint' AND lkp_refl_set.Lovsetrecordsourceid = 12010) 
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12010 and lovsourcekeytypeid = @lovsourcekeytypeid) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.footprint IS NOT NULL AND src.footprint <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12010 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #RAWTH_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='category' and rls.Lovsetrecordsourceid = 12010) lkp_refl
			ON src.category = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='category' AND lkp_refl_set.Lovsetrecordsourceid = 12010) 
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12010 and lovsourcekeytypeid = @lovsourcekeytypeid) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.category IS NOT NULL AND src.category <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12010 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #RAWTH_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='format' and rls.Lovsetrecordsourceid = 12010) lkp_refl
			ON src.format = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='format' AND lkp_refl_set.Lovsetrecordsourceid = 12010) 
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12010 and lovsourcekeytypeid = @lovsourcekeytypeid) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.format IS NOT NULL AND src.format <> ''
		)a
		;
		
	--update 1: This update statement updates the SCD Active Flag, SCD End date and SCD Version
	UPDATE [ser].[planogramgroup] 
	set scdactiveflag = F.scdactiveflag,
		SCDEndDate 	= F.SCDEndDate,
		SCDVersion = F.SCDVersion from  [ser].[planogramgroup] P join
	(select A.PlanogramId,A.LOVGroupId,case
	when A.scdenddate = '9999-12-31 00:00:00.000' then 'Y' else 'N' end as scdactiveflag, A.SCDEndDate, A.[SCDVersion], A.psarowkey from
	(SELECT PlanogramId,LOVGroupId,scdactiveflag,
    LEAD(i.SCDStartDate,1,'9999-12-31') OVER(PARTITION BY i.PlanogramId,i.LOVGroupId ORDER BY i.SCDStartDate,i.psarowkey ASC) SCDEndDate ,
    ROW_NUMBER() OVER (PARTITION BY i.PlanogramId,i.LOVGroupId ORDER BY [SCDStartDate],i.psarowkey ASC) AS [SCDVersion],
	psarowkey     
	FROM ser.planogramgroup i
    where  LOVRecordSourceId =12010 ) A) F
	ON P.psarowkey = F.psarowkey
	and P.PlanogramId = F.PlanogramId
	and P.LOVGroupId = F.LOVGroupId
	where P.LOVRecordSourceId =12010
	;
	
	--update 2: This update statement updates the SCD Start Date
	UPDATE [ser].[planogramgroup]
	set SCDStartDate = '1900-01-01'
	where SCDVersion = 1 and LOVRecordSourceId =12010
	;

RAISERROR ('Completed insertion of International Thailand source data to PLANOGRAMGROUP table', 0, 1) WITH NOWAIT	

/*---------------------------------Loading PlanogramIndicator table---------------------------------*/
	INSERT INTO [ser].[PlanogramIndicator]
	([PlanogramId]
	,[LovIndicatorId]
	,[Value]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
	SELECT
	[PlanogramId]
	,[LovIndicatorId]
	,[Value]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,LEAD([SCDStartDate],1,'9999-12-31 00:00:00') OVER (PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [SCDStartDate],PSARowKey ASC) AS [SCDEndDate]
	,LEAD('N',1,'Y') OVER (PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [SCDStartDate],PSARowKey ASC) AS [SCDActiveFlag]
	,ROW_NUMBER() OVER (PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [SCDStartDate],PSARowKey ASC) AS [SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	FROM
	(
		SELECT distinct
		src.PlanogramId AS [PlanogramId]
		,lkp_refl.LOVId AS [LovIndicatorId]
		,src.promotional_site AS [Value]
		,12010 AS [LOVRecordSourceId]																								  
		,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID as [ETLRunLogId]
		,src.row_id as [PSARowKey]
		FROM #RAWTH_CRP_MERCHANDISE_temp src
		LEFT OUTER JOIN
		(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
		ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Indicator - THAILAND Merchandise' and rls.Lovsetrecordsourceid = 12010 and rl.LOVKey = 'promotional_site') lkp_refl
		ON lkp_refl.LOVRecordSourceId = src.record_source_id
		JOIN
		(SELECT * from ser.planogram where Lovrecordsourceid=12010 and lovsourcekeytypeid = @lovsourcekeytypeid) PL
		on PL.PlanogramId = src.PlanogramId 
		and	PL.psarowkey = src.row_id
		WHERE src.promotional_site IS NOT NULL AND src.promotional_site <> ''
	)a
	;
	
	--update 1: This update statement updates the SCD Active Flag, SCD End date and SCD Version
	UPDATE [ser].[PlanogramIndicator] 
	set scdactiveflag = F.scdactiveflag,
		SCDEndDate 	= F.SCDEndDate,
		SCDVersion = F.SCDVersion from  [ser].[PlanogramIndicator] P join
	(select A.PlanogramId,A.LovIndicatorId,case
	when A.scdenddate = '9999-12-31 00:00:00.000' then 'Y' else 'N' end as scdactiveflag, A.SCDEndDate, A.[SCDVersion], A.psarowkey from
	(SELECT PlanogramId,LovIndicatorId,scdactiveflag,
    LEAD(i.SCDStartDate,1,'9999-12-31') OVER(PARTITION BY i.PlanogramId,i.LovIndicatorId ORDER BY i.SCDStartDate,i.psarowkey ASC) SCDEndDate ,
    ROW_NUMBER() OVER (PARTITION BY i.PlanogramId,i.LovIndicatorId ORDER BY [SCDStartDate],i.psarowkey ASC) AS [SCDVersion],
	psarowkey     
	FROM ser.PlanogramIndicator i
    where  LOVRecordSourceId =12010 ) A) F
	ON P.psarowkey = F.psarowkey
	and P.PlanogramId = F.PlanogramId
	and P.LovIndicatorId = F.LovIndicatorId
	where P.LOVRecordSourceId =12010 
	;
	
	--update 2: This update statement updates the SCD Start Date
	UPDATE [ser].[PlanogramIndicator]
	set SCDStartDate = '1900-01-01'
	where SCDVersion = 1 and LOVRecordSourceId =12010
	;

	RAISERROR ('Completed insertion of International Thaiand source data to PLANOGRAMIndicator table', 0, 1) WITH NOWAIT
		
	/*--------------------------------Loading Planogram Property table---------------------------------*/
	
	SET @th_measuretypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 		'PLANOGRAM_DIM' and rlovset.LOVsetname = 'Measure Type');
	
	INSERT INTO [ser].[PlanogramProperty]
	(
	[PlanogramId]
    ,[MeasureId]
    ,[LOVUOMId]
    ,[Value]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[PlanogramId]
		,[MeasureId]
		,[LOVUOMId]
		,[Value]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY PlanogramId,MeasureId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY PlanogramId,MeasureId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY PlanogramId,MeasureId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_meas.MeasureId AS [MeasureId]
			,lkp_refl.LOVId AS [LOVUOMId]
			,src.shelf_depth AS [Value]
			,12010 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #RAWTH_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Unit Of Measure' and rls.Lovsetrecordsourceid = 12012) lkp_refl
			ON lkp_refl.LOVKey =  'cm'
			LEFT OUTER JOIN
			[ser].[measure] lkp_meas
			ON (lkp_meas.MeasureName = 'shelf_depth' AND lkp_meas.LOVRecordSourceId = 12010 and lkp_meas.LOVMeasureTypeId = @th_measuretypeid)
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12010 and lovsourcekeytypeid = @lovsourcekeytypeid) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.shelf_depth IS NOT NULL AND src.shelf_depth <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_meas.MeasureId AS [MeasureId]
			,lkp_refl.LOVId AS [LOVUOMId]
			,src.height AS [Value]
			,12010 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #RAWTH_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Unit Of Measure' and rls.Lovsetrecordsourceid = 12012) lkp_refl
			ON lkp_refl.LOVKey =  'cm'
			LEFT OUTER JOIN
			[ser].[measure] lkp_meas
			ON (lkp_meas.MeasureName = 'height' AND lkp_meas.LOVRecordSourceId = 12010 and lkp_meas.LOVMeasureTypeId = @th_measuretypeid)
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12010 and lovsourcekeytypeid = @lovsourcekeytypeid) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.height IS NOT NULL AND src.height <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_meas.MeasureId AS [MeasureId]
			,lkp_refl.LOVId AS [LOVUOMId]
			,src.build_size AS [Value]
			,12010 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #RAWTH_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Unit Of Measure' and rls.Lovsetrecordsourceid = 12012) lkp_refl
			ON lkp_refl.LOVKey =  'Unknown'
			LEFT OUTER JOIN
			[ser].[measure] lkp_meas
			ON (lkp_meas.MeasureName = 'build_size' AND lkp_meas.LOVRecordSourceId = 12010 and lkp_meas.LOVMeasureTypeId = @th_measuretypeid)
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12010 and lovsourcekeytypeid = @lovsourcekeytypeid) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.build_size IS NOT NULL AND src.build_size <> ''
		)a
		;
		
		--update 1: This update statement updates the SCD Active Flag, SCD End date and SCD Version
		UPDATE [ser].[PlanogramProperty] 
		set scdactiveflag = F.scdactiveflag,
			SCDEndDate 	= F.SCDEndDate,
			SCDVersion = F.SCDVersion from  [ser].[PlanogramProperty] P join
		(select A.PlanogramId,A.MeasureId,case
		when A.scdenddate = '9999-12-31 00:00:00.000' then 'Y' else 'N' end as scdactiveflag, A.SCDEndDate, A.[SCDVersion], A.psarowkey from
		(SELECT PlanogramId,MeasureId,scdactiveflag,
		LEAD(i.SCDStartDate,1,'9999-12-31') OVER(PARTITION BY i.PlanogramId,i.MeasureId ORDER BY i.SCDStartDate,i.psarowkey ASC) SCDEndDate ,
		ROW_NUMBER() OVER (PARTITION BY i.PlanogramId,i.MeasureId ORDER BY i.SCDStartDate,i.psarowkey ASC) AS [SCDVersion],
		psarowkey     
		FROM ser.PlanogramProperty i
		where  LOVRecordSourceId =12010) A) F
		ON P.psarowkey = F.psarowkey
		and P.PlanogramId = F.PlanogramId
		and P.MeasureId = F.MeasureId
		where P.LOVRecordSourceId =12010
		;
		
		--update 2: This update statement updates the SCD Start Date
		UPDATE [ser].[PlanogramProperty]
		set SCDStartDate = '1900-01-01'
		where SCDVersion = 1 and LOVRecordSourceId =12010
		;

	RAISERROR ('Completed insertion of International Thailand source data to PLANOGRAMProperty table', 0, 1) WITH NOWAIT	
				
	UPDATE [psa].[RAWTH_CRP_MERCHANDISE] SET [row_status]=@rowStatusSERCode
	FROM [psa].[RAWTH_CRP_MERCHANDISE] th 
	INNER JOIN [ser].[Planogram] p ON th.row_id=p.PSARowKey and th.record_source_id=p.LovRecordSourceID 
	WHERE th.row_status=@rowStatusPSACode  AND p.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))
		
	RAISERROR ('Updated Row Status to ''Loaded to Serve'' for psa.[RAWTH_CRP_MERCHANDISE] International Thailand  ', 0, 1) WITH NOWAIT
	
		

	
	COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH
				DECLARE @error_num varchar(max),
        				@error_msg varchar(max),
        				@error_sev varchar(max)
        		;
 
				SELECT  
        		@error_num=ERROR_NUMBER()
        		,@error_sev=ERROR_SEVERITY()  
         		,@error_msg=ERROR_MESSAGE() ;  
 
        		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
			END CATCH 
			
	END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_CHILE_HISTORY') IS NOT NULL
BEGIN
    DROP PROC [psa].[SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_CHILE_HISTORY]
END
GO


CREATE PROCEDURE [psa].[SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_CHILE_HISTORY] @psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max)
AS 
/*
************************************************************************************************************
Procedure Name				: SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_CHILE_HISTORY
Purpose						: Load History data From International Chile 
Domain						: Merchandise
ServeLayer Target Tables	: Factinstance, Factdimensioninstance, FactmeasureInstance
RecordSourceID  for International Chile : 12001
*****************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
 */
BEGIN



	/*--Declarations---*/
	DECLARE @max_FactInstanceId BIGINT;
	DECLARE @cl_measuretypeid BIGINT;
	DECLARE @rowStatusPSACode BIGINT;	
	DECLARE @rowStatusSERCode BIGINT;

	SET @rowStatusPSACode = 26001
    SET @rowStatusSERCode = 26002 

	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_FactInstanceId = COALESCE(MAX(FactInstanceId),0) FROM [ser].[FactInstance];
	
	
	
	/*-------------------------------Create temporary source table-------------------------------*/

	IF OBJECT_ID('tempdb..#rawcl_crp_planogram_temp') IS NOT NULL
	BEGIN
		drop table tempdb..#rawcl_crp_planogram_temp;
	END

	
	SELECT
	@max_FactInstanceId + (ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS FactInstanceId
    ,*
	INTO #rawcl_crp_planogram_temp
	FROM (select * from [psa].[rawcl_crp_planogram] where [row_status]=@rowStatusPSACode and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')))a
	;
	
	RAISERROR ('Completed insertion of International Chile source data to #rawcl_crp_planogram_temp table', 0, 1) WITH NOWAIT	

	BEGIN TRANSACTION;
	BEGIN TRY


	/*--------------------------------Loading Fact Instance table---------------------------------*/
	INSERT INTO [ser].[FactInstance]
	(
	[FactInstanceId]
    ,[FactId]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[FactInstanceId]
		,[FactId]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_fact.FactId AS [FactId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #rawcl_crp_planogram_temp src
			LEFT OUTER JOIN
			(
				SELECT 
				rlrls.LOVId
				,rlrls.LOVKey
				,rlrls.LOVRecordSourceId
				,f.FactId 
				FROM  ser.fact f
				INNER JOIN 
				(
					SELECT 
					rl.LOVId
					,rl.LOVKey
					,rl.LOVRecordSourceId
					FROM ser.RefLOV rl 
					INNER JOIN ser.RefLOVSet rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Fact Type' and rls.Lovsetrecordsourceid = 12012
				) rlrls
				ON rlrls.LOVKey = 'TBC' AND f.LOVFactTypeId = rlrls.LOVId AND f.FactName = 'CRP Planogram' and f.LOVRecordSourceId = 12001
			) lkp_fact
			ON  lkp_fact.LOVRecordSourceId = 12012
			
		)a;
		
		RAISERROR ('Completed insertion of International Chile source data (planogram) to FactInstance table', 0, 1) WITH NOWAIT	
		
	
	/*--------------------------------Loading Fact Dimension Instance table---------------------------------*/
	
	DECLARE @sourcekeytypeid bigint;
	SET @sourcekeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey =  'Chile Planogram Id(pog_id)' and rlovset.LOVsetname = 'Source Key Type');
	
	INSERT INTO [ser].[FactDimensionInstance]
	([FactInstanceId]
    ,[DimensionId]
    ,[DimensionSurrogateKey]
    ,[DimensionSourceKey]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[FactInstanceId]
		,[DimensionId]
		,[DimensionSurrogateKey]
		,[DimensionSourceKey]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_dim.DimensionId AS [DimensionId]
			,lkp_plan.PlanogramId AS [DimensionSurrogateKey]
			,cast(src.pog_id as varchar(80)) AS [DimensionSourceKey]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM 
			#rawcl_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[dimension] lkp_dim
			ON (lkp_dim.name =  'Planogram' AND  lkp_dim.LOVRecordSourceId = 12001)
			LEFT OUTER JOIN
			(select * from [ser].[planogram] where SCDActiveFlag='Y' and Lovrecordsourceid=12001 and lovsourcekeytypeid = @sourcekeytypeid) lkp_plan
			ON (lkp_plan.SourceKey = src.pog_id AND lkp_plan.LOVRecordSourceId = 12001)
			
			UNION
			
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_dim.DimensionId AS [DimensionId]
			,lkp_prod.ProductId AS [DimensionSurrogateKey]
			,cast(src.item_code as varchar(80)) AS [DimensionSourceKey]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM 
			#rawcl_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[dimension] lkp_dim
			ON (lkp_dim.name =  'Product' AND  lkp_dim.LOVRecordSourceId = 12001)
			LEFT OUTER JOIN
			(select * from [ser].[product] where SCDActiveFlag = 'Y') lkp_prod
			ON (lkp_prod.SourceKey = cast(src.item_code as varchar(80)) AND lkp_prod.LOVRecordSourceId = 12001)
			
			UNION
			
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_dim.DimensionId AS [DimensionId]
			,lkp_refl.LOVId AS [DimensionSurrogateKey]
			,cast(src.week as varchar(80)) AS [DimensionSourceKey]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM 
			#rawcl_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[dimension] lkp_dim
			ON (lkp_dim.name =  'Week' AND  lkp_dim.LOVRecordSourceId = 12001)
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='week' and rls.Lovsetrecordsourceid = 12001) lkp_refl
			ON src.week = lkp_refl.LOVKey 
		)a
		;
		
		RAISERROR ('Completed insertion of International Chile source data (planogram) to FactDimensionInstance table', 0, 1) WITH NOWAIT	
		
		
	/*--------------------------------Loading Fact Measure Instance table---------------------------------*/
	
	SET @cl_measuretypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 		'PLANOGRAM_AGGREGATION' and rlovset.LOVsetname = 'Measure Type');
	
	INSERT INTO [ser].[FactMeasureInstance]
	(
	 [FactInstanceId]
    ,[MeasureId]
    ,[Value]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[FactInstanceId]
		,[MeasureId]
		,[Value]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY SCDStartDate ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY SCDStartDate ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_meas.MeasureId AS [MeasureId]
			,src.facings AS [Value]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #rawcl_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[measure] lkp_meas
			ON (lkp_meas.MeasureName = 'facings' AND lkp_meas.LOVRecordSourceId = 12001 and lkp_meas.LOVMeasureTypeId = @cl_measuretypeid)
			WHERE src.facings IS NOT NULL AND src.facings <> ''
		)a
		;
		
		RAISERROR ('Completed insertion of International Chile source data (planogram) to FactMeasureInstance table', 0, 1) WITH NOWAIT	
		
		UPDATE [psa].[rawcl_crp_planogram] SET [row_status]=@rowStatusSERCode
                FROM [psa].[rawcl_crp_planogram] cl 
                INNER JOIN [ser].[FactInstance] p ON cl.row_id=p.PSARowKey and cl.record_source_id=p.LovRecordSourceID 
                WHERE cl.row_status=@rowStatusPSACode  AND p.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))
		
		COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH
				DECLARE @error_num varchar(max),
        				@error_msg varchar(max),
        				@error_sev varchar(max)
        		;
 
				SELECT  
        		@error_num=ERROR_NUMBER()
        		,@error_sev=ERROR_SEVERITY()  
         		,@error_msg=ERROR_MESSAGE() ;  
 
        		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
			END CATCH 
END
GO
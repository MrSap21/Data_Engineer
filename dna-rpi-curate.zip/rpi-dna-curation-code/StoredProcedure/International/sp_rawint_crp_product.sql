/****** Object:  StoredProcedure [psa].[sp_rawint_crp_product]    Script Date: 23/07/2020 14:43:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_rawint_crp_product') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawint_crp_product
END
GO

CREATE PROC [psa].[sp_rawint_crp_product] @tableName [varchar](200),@psaETLRunLogID [varchar](200),@serveETLRunLogID [varchar](200) AS

/*
*******************************************************************************************************************************************************
Procedure Name									: sp_prod_int
Purpose											: Load History data From International NORWAY Source(rawno_crp_product),
												  International MEXICO Source(rawmx_crp_product) & International THAILAND Source(rawth_crp_product) 
												  into Serve Layer Table. The same script is re used for three sources by changing the input parameters.
Domain											: Product
ServeLayer Target Tables						: Product,ProductIdentifier,ProductGroup,ProductIndicator,ProductProperty,ProductStatus,
												  Party,Organization,PartyRole,ProductPartyRole    (Total 10 Tables)
RecordSourceID  for International Norway		: 12005
RecordSourceID  for International Mexico		: 12004
RecordSourceID  for International Thailand		: 12010
********************************************************************************************************************************************************
										 Default values
********************************************************************************************************************************************************
				SCDEndDate for highest version  :  '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				InpServeETLRunLogID				:  @serveETLRunLogID passed as argument
				InpTableName					:  @tableName  passed as argument

********************************************************************************************************************************************************
Modification History

July 14 : Added Error catch code, removed raise error statements and added print statements.
		  Added column names in insert queries.
		  Modified code for ETLRunLogID bugfix for Party,Organisation,PartyRole and ProductPartyRole.
		  
July 23 : Modified logic of SCDStartDate and modified code for ProductPartyRole table.



 */ 

		DECLARE	@inpTableName				VARCHAR (max),
				@inpPsaETLRunLogID			VARCHAR (max),
				@inpServeETLRunLogID		VARCHAR (max),
				@sourceKey                  VARCHAR (max),
				@lovKeyTemp					VARCHAR (max),
				@indicatorName				VARCHAR (max), 
				@organisationName 			VARCHAR (max),
				@uomCmId					BIGINT,
				@partyId                    BIGINT,
				@maxPartyId 				BIGINT,
				@partyRoleId 				BIGINT,
				@partyTypeId				BIGINT,
				@maxProductId				BIGINT,
				@uomUnknownId				BIGINT,
				@recordSourceId				BIGINT,
				@maxPartyRoleId				BIGINT,
				@upcIdentifierId			BIGINT,
				@lovRetailerRoleId 			BIGINT,
				@supplier_LOVRoleId			BIGINT,
				@maxProductGroupId			BIGINT,
				@scdLovRecordSourceId		BIGINT,
				@itemCodeSourceKeyTypeId	BIGINT,
				@rowStatusPSACode			BIGINT,
				@measureTypeId				BIGINT,
				@dataTypeId					BIGINT,
				@rowStatusSERCode			BIGINT,
				@scdDefaultStartDate		VARCHAR (100),
				@scdDefaultEndDate			VARCHAR (100);	
	
BEGIN	

		/* Creating a intermediate physical table for Product */

			IF OBJECT_ID('psa.rawint_crp_product_temp') is not null
	BEGIN
			DROP TABLE [psa].[rawint_crp_product_temp]
	END			
			CREATE TABLE [psa].[rawint_crp_product_temp]
			(
				[ProductId] [bigint] NOT NULL,
				[SourceKey] [nvarchar](80) NOT NULL,
				[LOVSourceKeyTypeId] [int] NOT NULL,
				[ProductName] [nvarchar](255) NULL,
				[ProductDescription] [nvarchar](255) NULL,
				[LOVBrandId] [int] NULL,
				[LOVSubBrandId] [int] NULL,
				[LOVRecordSourceId] [int] NOT NULL,
				[ParentProductId] [bigint] NULL,
				[SCDStartDate] [datetime] NULL,
				[SCDEndDate] [datetime] NULL,
				[SCDActiveFlag] [nchar](1) NULL,
				[SCDVersion] [smallint] NULL,
				[SCDLOVRecordSourceId] [int] NULL,
				[ETLRunLogId] [int] NULL,
				[PSARowKey] [bigint] NULL				
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			)
	

	/* Creating a intermediate physical table for Product Identifier */

		IF OBJECT_ID('psa.rawint_crp_product_identifier_temp') is not null
		BEGIN
			DROP TABLE [psa].[rawint_crp_product_identifier_temp]
		END			
			CREATE TABLE [psa].[rawint_crp_product_identifier_temp]
			(
				[ProductId] [bigint] NOT NULL,
				[LOVIdentifierId] [int] NOT NULL,
				[Value] [nvarchar](80) NULL,
				[LOVRecordSourceId] [int] NOT NULL,
				[SCDStartDate] [datetime] NULL,
				[SCDEndDate] [datetime] NULL,
				[SCDActiveFlag] [nchar](1) NULL,
				[SCDVersion] [smallint] NULL,
				[SCDLOVRecordSourceId] [int] NULL,
				[ETLRunLogId] [int] NULL,
				[PSARowKey] [bigint] NULL
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX ORDER ([LOVIdentifierId],[LOVRecordSourceId])
			)

	/* Creating a intermediate physical table for Product Status*/

		IF OBJECT_ID('psa.rawint_crp_product_status_temp') is not null
		BEGIN
			DROP TABLE [psa].[rawint_crp_product_status_temp]
		END			
			CREATE TABLE [psa].[rawint_crp_product_status_temp]
				(
					[ProductId] [bigint] NOT NULL,
					[LOVProductStatusSetId] [int] NOT NULL,
					[LOVStatusId] [int] NULL,
					[EffectiveFrom] [datetime] NULL,
					[EffectiveTo] [datetime] NULL,
					[LOVRecordSourceId] [int] NOT NULL,
					[SCDStartDate] [datetime] NULL,
					[SCDEndDate] [datetime] NULL,
					[SCDActiveFlag] [nchar](1) NULL,
					[SCDVersion] [smallint] NULL,
					[SCDLOVRecordSourceId] [int] NULL,
					[ETLRunLogId] [int] NULL,
					[PSARowKey] [bigint] NULL
				)
				WITH
				(
					DISTRIBUTION = REPLICATE,
					CLUSTERED COLUMNSTORE INDEX ORDER ([ProductId],[LOVRecordSourceId])
				)
				
	/* Creating a intermediate physical table for Product Property */

		IF OBJECT_ID('psa.rawint_crp_product_property_temp') is not null
		BEGIN
			DROP TABLE [psa].[rawint_crp_product_property_temp]
		END					

			CREATE TABLE [psa].[rawint_crp_product_property_temp]
			(
				[ProductId] [bigint] NOT NULL,
				[MeasureId] [int] NOT NULL,
				[LOVUOMId] [int] NOT NULL,
				[Value] [nvarchar](255) NULL,
				[LOVRecordSourceId] [int] NOT NULL,
				[SCDStartDate] [datetime] NULL,
				[SCDEndDate] [datetime] NULL,
				[SCDActiveFlag] [nchar](1) NULL,
				[SCDVersion] [smallint] NULL,
				[SCDLOVRecordSourceId] [int] NULL,
				[ETLRunLogId] [int] NULL,
				[PSARowKey] [bigint] NULL
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX ORDER ([MeasureId],[LOVUOMId],[LOVRecordSourceId])
			)

	/* Creating a intermediate physical table for Product Indicator */

			IF OBJECT_ID('psa.rawint_crp_product_indicator_temp') is not null
		BEGIN
			DROP TABLE [psa].[rawint_crp_product_indicator_temp]
		END					

			CREATE TABLE [psa].[rawint_crp_product_indicator_temp]
			(
				[ProductId] [bigint] NOT NULL,
				[LOVIndicatorId] [int] NOT NULL,
				[Value] [nvarchar](10) NULL,
				[LOVRecordSourceId] [int] NOT NULL,
				[SCDStartDate] [datetime] NULL,
				[SCDEndDate] [datetime] NULL,
				[SCDActiveFlag] [nchar](1) NULL,
				[SCDVersion] [smallint] NULL,
				[SCDLOVRecordSourceId] [int] NULL,
				[ETLRunLogId] [int] NULL,
				[PSARowKey] [bigint] NULL
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX ORDER ([LOVIndicatorId],[LOVRecordSourceId])
			)
	
	/* Creating a intermediate physical table for Product Group-1 */

			IF OBJECT_ID('psa.rawint_crp_product_group_temp') is not null
		BEGIN
			DROP TABLE [psa].[rawint_crp_product_group_temp]
		END
			CREATE TABLE [psa].[rawint_crp_product_group_temp] 
				(
				[PSARowKey] [int] NOT NULL,
				[ProductID] [bigint] NULL,
				[SourceKey] [nvarchar](500) NULL,
				[LOVRecordSourceId] [bigint] NULL,
				[SCDStartDate] [nvarchar](500) NULL,
				[SCDEndDate] [nvarchar](500) NULL,
				[SCDLOVRecordSourceId] [bigint] NULL,
				[ETLRunLogId] [int] NULL,
				[product_hierarchy1_code] [bigint] NULL,
				[product_hierarchy1_name] [bigint] NULL,
				[product_hierarchy2_code] [bigint] NULL,
				[product_hierarchy2_name] [bigint] NULL,
				[product_hierarchy3_code] [bigint] NULL,
				[product_hierarchy3_name] [bigint] NULL,
				[product_hierarchy4_code] [bigint] NULL,
				[product_hierarchy4_name] [bigint] NULL,
				[product_hierarchy5_code] [bigint] NULL,
				[product_hierarchy5_name] [bigint] NULL
				)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			)

/* Creating a intermediate physical table for Product Group-2 */

			IF OBJECT_ID('psa.rawint_crp_product_group_temp_thai') is not null
		BEGIN
			DROP TABLE [psa].[rawint_crp_product_group_temp_thai]
		END
			CREATE TABLE [psa].[rawint_crp_product_group_temp_thai] 
				(
				[PSARowKey] [int] NOT NULL,
				[ProductID] [bigint] NULL,
				[SourceKey] [nvarchar](500) NULL,
				[LOVRecordSourceId] [bigint] NULL,
				[SCDStartDate] [nvarchar](500) NULL,
				[SCDEndDate] [nvarchar](500) NULL,
				[SCDLOVRecordSourceId] [bigint] NULL,
				[ETLRunLogId] [int] NULL,
				[product_hierarchy1_code] [bigint] NULL,
				[product_hierarchy1_name] [bigint] NULL,
				[product_hierarchy2_code] [bigint] NULL,
				[product_hierarchy2_name] [bigint] NULL,
				[product_hierarchy3_code] [bigint] NULL,
				[product_hierarchy3_name] [bigint] NULL,
				[product_hierarchy4_code] [bigint] NULL,
				[product_hierarchy4_name] [bigint] NULL
				)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			)

	/* Creating a intermediate physical table for Product Group-3  */

	IF OBJECT_ID('psa.rawint_crp_product_group_out') is not null
		BEGIN
			DROP TABLE [psa].[rawint_crp_product_group_out]
		END
			CREATE TABLE [psa].[rawint_crp_product_group_out] 
			(
				[ProductGroupId] [bigint] NOT NULL,
				[ProductId] [bigint] NOT NULL,
				[LOVProductGroupSetId] [int] NOT NULL,
				[LOVGroupId] [int] NOT NULL,
				[ParentProductGroupId] [bigint] NULL,
				[LOVRecordSourceId] [int] NOT NULL,
				[SCDStartDate] [datetime] NULL,
				[SCDEndDate] [datetime] NULL,
				[SCDActiveFlag] [nchar](1) NULL,
				[SCDVersion] [smallint] NULL,
				[SCDLOVRecordSourceId] [int] NULL,
				[ETLRunLogId] [int] NULL,
				[PSARowKey] [bigint] NULL
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX ORDER ([ProductId],[LOVProductGroupSetId],[LOVRecordSourceId])
			)
	/* Creating a intermediate physical table for Product PartyRole */

			IF OBJECT_ID('psa.rawint_crp_product_party_role_temp') is not null
				BEGIN
					DROP TABLE [psa].[rawint_crp_product_party_role_temp]
				END					

			CREATE TABLE [psa].[rawint_crp_product_party_role_temp]
			(
				[ProductId] [bigint] NOT NULL,
				[PartyRoleId] [bigint] NOT NULL,
				[LOVRecordSourceId] [int] NOT NULL,
				[SCDStartDate] [datetime] NULL,
				[SCDEndDate] [datetime] NULL,
				[SCDActiveFlag] [char](1) NULL,
				[SCDVersion] [smallint] NULL,
				[SCDLOVRecordSourceId] [int] NULL,
				[ETLRunLogId] [int] NULL,
				[PSARowKey] [bigint] NULL
			)
			WITH
			(
			DISTRIBUTION = REPLICATE,
			CLUSTERED COLUMNSTORE INDEX ORDER ([PartyRoleId],[LOVRecordSourceId])
			)


	BEGIN TRANSACTION;
	

			SET		 @inpTableName		   = 'psa.'+@tableName
			SET		 @inpPsaETLRunLogID	   = @psaETLRunLogID 
			SET		 @inpServeETLRunLogID  = @serveETLRunLogID 
			SET		 @scdLovRecordSourceId = 151
			SET		 @rowStatusPSACode	   = 26001
			SET		 @rowStatusSERCode	   = 26002
			SET		 @scdDefaultStartDate  = '1900-01-01'
			SET		 @scdDefaultEndDate	   = '9999-12-31'

			--SET		 @recordSourceId	   = 12004	

			DECLARE @RecordSourceIdSQL nvarchar(max) = 'SELECT TOP 1 @recordSourceId = record_source_id FROM ' + @inpTableName
			exec sp_executesql @RecordSourceIdSQL, N'@recordSourceId int out', @recordSourceId out

			SET @lovKeyTemp =
	CASE
			WHEN @recordSourceId = 12010
			THEN 'Thailand Item Code'

			WHEN @recordSourceId = 12005
			THEN 'Norway Item Code'

			WHEN @recordSourceId = 12004
			THEN 'Mexico Item Code'
	END
			SET @indicatorName = 
	CASE
			WHEN @recordSourceId = 12010
			THEN 'Indicator - Thailand Product'

			WHEN @recordSourceId = 12005
			THEN 'Indicator - Norway Product'

			WHEN @recordSourceId = 12004
			THEN 'Indicator - Mexico Product'
	END
			SET @sourceKey=
    CASE
            WHEN @recordSourceId = 12010
            THEN 'WBA-TH-BT'

            WHEN @recordSourceId = 12005
            THEN 'WBA-NO-BN'

            WHEN @recordSourceId = 12004
            THEN 'WBA-MX-FB'
    END		
			SET @organisationName=
	CASE
			WHEN @recordSourceId = 12010
			THEN 'Boots Thailand'

			WHEN @recordSourceId = 12005
			THEN 'Boots Norway'

			WHEN @recordSourceId = 12004
			THEN 'Farmacias Benavides'
	END

												
		   SELECT @uomCmId				   = [LOVId] FROM [ser].[RefLov] WHERE LOVKey = 'cm'		AND 
												LOVSetId = (SELECT [LOVSetID] FROM [ser].[RefLovSet] WHERE LOVSetName = 'Unit of measure');
		   SELECT @partyTypeId		       = [LOVId] FROM [ser].[RefLOV] WHERE LOVKey = 'ORG'		AND
												LOVSetId = (SELECT [LOVSetID] FROM [ser].[RefLovSet] WHERE LOVSetName = 'Party Type' );
	       SELECT @uomUnknownId			   = [LOVId] FROM [ser].[RefLov] WHERE LOVKey = 'Unknown'	AND 
												LOVSetId = (SELECT [LOVSetID] FROM [ser].[RefLovSet] WHERE LOVSetName = 'Unit of measure');
		   SELECT @upcIdentifierId		   = [LOVId] FROM [ser].[RefLov] WHERE LOVKey = 'UPC'		AND
												LOVSetId = (SELECT [LOVSetID] FROM [ser].[RefLovSet] WHERE LOVSetName = 'Identifier');
		   SELECT @lovRetailerRoleId	   = [LOVId] FROM [ser].[RefLov] WHERE LOVKey = 'Retailer'  AND
												LOVSetId = (SELECT [LOVSetID] FROM [ser].[RefLovSet] WHERE LOVSetName = 'Role' );
		   SELECT @supplier_LOVRoleId	   = [LOVId] FROM [ser].[RefLov] WHERE LOVKey = 'Supplier'  AND 
												LOVSetId = (SELECT [LOVSetID] FROM [ser].[RefLovSet] WHERE LOVSetName = 'Role' );
		   SELECT @itemCodeSourceKeyTypeId = [LOVId] FROM [ser].[RefLov] WHERE LOVKey = @lovKeyTemp AND
												LOVSetId = (SELECT [LOVSetID] FROM [ser].[RefLovSet] WHERE LOVSetName = 'Source Key Type') ;
		   SELECT @partyRoleId = [PartyRoleId] FROM ser.partyRole WHERE SourceKey = @sourceKey and LOVRecordSourceId= @recordSourceId
		   
		   SET    @maxPartyId			   = (SELECT COALESCE(max(PartyId),0) FROM ser.party);
		   SET    @maxPartyRoleId		   = (SELECT COALESCE(max(PartyRoleId),0) FROM ser.partyRole);										
		   SELECT @maxProductId			   = COALESCE(MAX(ProductID),0) FROM ser.product; 
		   SELECT @maxProductGroupId	   = COALESCE(MAX(ProductGroupId),0) FROM ser.productGroup;  
		   SET    @measureTypeId		   = (SELECT rl.Lovid FROM ser.RefLov rl ,ser.RefLovset rls WHERE rl.LovSetID = rls.LovSetID AND rl.LOVKey = 'PROD_DIM' AND rls.LOVSetName = 'Measure Type');
		   SET    @dataTypeId			   = (SELECT rl.Lovid FROM ser.RefLov rl ,ser.RefLovset rls WHERE rl.LovSetID = rls.LovSetID AND rl.LOVKey = 'STRING' AND rls.LOVSetName = 'Data Type');

		   
	
	BEGIN TRY

  /* 1.Table Name  :  Product */	

 print 'Started EXEC command for Product';

exec('

		DECLARE  @productPsaETLRunLogID     VARCHAR(200)

		SET		 @productPsaETLRunLogID	   = '''+@psaETLRunLogID+'''

			INSERT INTO [psa].[rawint_crp_product_temp]
			SELECT      ProductID,SourceKey,LOVSourceKeyTypeId,ProductName,ProductDescription,LOVBrandId,LOVSubBrandId,
						LOVRecordSourceId,ParentProductId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID ORDER BY SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+'''
								 ELSE SCDStartDate
								 END SCDStartDate,
						SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY SourceKey,LOVRecordSourceId ORDER BY SCDStartDate ASC) SCDActiveFlag,
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID ORDER BY SCDStartDate ASC) SCDVersion,
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
			FROM
			(
			SELECT
						ISNULL(p.ProductID,prodIdTemp.ProductID) ProductID,
						intprod.item_code SourceKey,
						'+@itemCodeSourceKeyTypeId+' LOVSourceKeyTypeId,
						intprod.item_description ProductName,
						intprod.item_description ProductDescription ,   
						b.lovid LOVBrandId,
						sb.lovid LOVSubBrandId,           
						NULL ParentProductID,           
						intprod.record_source_id LOVRecordSourceId,       
						intprod.date_added SCDStartDate,
						'''+@scdDefaultEndDate+''' SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY intprod.item_code,intprod.item_description,intprod.brand,intprod.subbrand,
						intprod.record_source_id,intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+' intprod
						JOIN (SELECT intprod.item_code,intprod.record_source_id,('+@maxProductId+'+ROW_NUMBER() OVER(ORDER BY intprod.item_code,intprod.record_source_id ASC)) ProductID
						FROM '+@inpTableName+' intprod  GROUP BY intprod.item_code,intprod.record_source_id) prodIdTemp
							ON prodIdTemp.item_code=intprod.item_code AND prodIdTemp.record_source_id=intprod.record_source_id
						LEFT JOIN ser.product p
							ON intprod.item_code =p.sourcekey AND intprod.record_source_id = p.LOVRecordSourceId
							 AND p.SCDActiveFlag = ''Y''
						LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls
									ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''brand'') b
							ON intprod.record_source_id =b.LOVRecordSourceId AND b.LOVKey=intprod.brand
						LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls
									ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''subbrand'') sb
							ON intprod.record_source_id =sb.LOVRecordSourceId AND sb.LOVKey=intprod.subbrand
						WHERE intprod.row_status='+@rowStatusPSACode+' AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
						AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@productPsaETLRunLogID, '',''))
						)t
						where t.SCDActiveFlag=''Y'';
			
		print ''Inserted Data into Physical Temp Table'';


/* Inserting Data into Product table */

					INSERT INTO ser.product (
					ProductId,SourceKey,LOVSourceKeyTypeId,ProductName,ProductDescription,LOVBrandId,LOVSubBrandId,LOVRecordSourceId,
					ParentProductId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey )	
					SELECT * FROM [psa].[rawint_crp_product_temp] 

		print ''Inserted Data into Product Table'';

/* Updating the SCD End Date */

				UPDATE prdt SET SCDEndDate = temp.SCDEndDate               
						FROM ser.product prdt
						JOIN
						(SELECT q.LOVRecordSourceId,q.ProductId,q.SCDStartDate,q.SCDVersion,
						LEAD(q.SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY q.ProductId ORDER BY q.SCDVersion ASC) SCDEndDate
						FROM ser.product q 
						WHERE q.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_temp]))temp
						ON temp.LOVRecordSourceId = prdt.LOVRecordSourceId AND temp.ProductId = prdt.ProductId AND temp.SCDStartDate = prdt.SCDStartDate
						AND temp.SCDVersion=prdt.SCDVersion

		print ''Updated SCD End Date'';

/* Updating Active Flag */

				UPDATE prdt SET SCDActiveFlag=''N''
						FROM ser.product  prdt
						JOIN [psa].[rawint_crp_product_temp] temp
						ON temp.LovRecordSourceId = prdt.LovRecordSourceId AND prdt.SourceKey =temp.SourceKey
						WHERE prdt.SCDActiveFlag=''Y'' and prdt.SCDENDDate !='''+@scdDefaultEndDate+'''

		print ''Updated Active Flag'';

		')
		
print 'Completed EXEC Command for Product';	

/* 2.Table Name  :Product Identifier*/

print 'Started EXEC command for Product Identifier';

exec('

	DECLARE  @identifierPsaETLRunLogID     VARCHAR(200);

	SET		 @identifierPsaETLRunLogID	   = '''+@psaETLRunLogID+''';

			INSERT INTO psa.rawint_crp_product_identifier_temp
			SELECT
					ProductId,LOVIdentifierId,Value,LOVRecordSourceId,
					CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID ORDER BY SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+'''
								 ELSE SCDStartDate
								 END SCDStartDate,
					SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductId,value,LOVRecordSourceId ORDER BY SCDStartDate ASC) SCDActiveFlag,
					ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID ORDER BY SCDStartDate ASC) SCDVersion,
					SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
			FROM(
			SELECT
					product.ProductId ProductId,
					'+@upcIdentifierId+' LOVIdentifierId,
					intprod.upc Value,
					intprod.record_source_id LOVRecordSourceId,
					intprod.date_added SCDStartDate,
					'''+@scdDefaultEndDate+''' SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductId,intprod.upc,intprod.record_source_id,
										intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
					p.SCDVersion SCDVersion,
					'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
					'+@inpServeETLRunLogID+' ETLRunLogId,
					intprod.row_id PSARowKey
						FROM  '+@inpTableName+' intprod
						JOIN ser.product product
							ON product.SourceKey = intprod.item_code AND product.LOVRecordSourceID = intprod.record_source_id
							AND product.SCDActiveFlag = ''Y''
							AND intprod.upc !='''' AND intprod.upc is not null
					LEFT JOIN ser.productIdentifier p
							ON product.productId =p.ProductId AND product.LOVRecordSourceId = p.LOVRecordSourceId
							AND p.SCDActiveFlag = ''Y''
							WHERE intprod.row_status='+@rowStatusPSACode+'
							-- AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
						AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@identifierPsaETLRunLogID, '',''))
			) productIdentifier
			where productIdentifier.SCDActiveFlag=''Y'';

		print ''Inserted Data into Physical Temp Table'';

/* Inserting Data into Product Identifier table */

			INSERT INTO ser.productIdentifier(
			ProductId,LOVIdentifierId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,
			ETLRunLogId,PSARowKey )
			SELECT * FROM [psa].[rawint_crp_product_identifier_temp] 

		print ''Inserted Data into Product Identifier Table'';

/* Updating the SCD End Date */

		UPDATE pid SET SCDEndDate = temp.SCDEndDate               
			    FROM ser.productIdentifier pid
                JOIN
                 (SELECT q.LOVRecordSourceId,q.ProductId,q.SCDStartDate,q.SCDVersion,
                LEAD(SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY q.ProductId ORDER BY q.SCDVersion ASC) SCDEndDate
                FROM ser.productIdentifier q 
				WHERE q.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_identifier_temp]))temp
                ON temp.LOVRecordSourceId = pid.LOVRecordSourceId AND temp.ProductId = pid.ProductId AND temp.SCDStartDate = pid.SCDStartDate
				AND temp.SCDVersion=pid.SCDVersion

		print ''Updated SCD End Date'';

/* Updating Active Flag */

		UPDATE  pid SET SCDActiveFlag=''N''
				FROM ser.productIdentifier  pid
				JOIN [psa].[rawint_crp_product_identifier_temp] temp
				ON temp.LovRecordSourceId = pid.LovRecordSourceId AND pid.productId = temp.productId 
				WHERE pid.SCDActiveFlag=''Y'' and pid.SCDENDDate !='''+@scdDefaultEndDate+'''

		print ''Updated Active Flag'';

')

print 'Completed EXEC Command for Product Identifier';

/* 3.Table Name  :Product Status*/

print 'Started EXEC Command for Product Status';

exec('

	DECLARE  @statusPsaETLRunLogID     VARCHAR(200);

	SET		 @statusPsaETLRunLogID	   = '''+@psaETLRunLogID+''';

			INSERT INTO [psa].[rawint_crp_product_status_temp]
			SELECT
						ProductID,LOVProductStatusSetId,LOVStatusId,EffectiveFrom,EffectiveTo,LOVRecordSourceId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID ORDER BY SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+''' 
								 ELSE SCDStartDate
								 END SCDStartDate,
						SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductId,LOVStatusId,LOVRecordSourceId ORDER BY SCDStartDate ASC) SCDActiveFlag,
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID ORDER BY SCDStartDate ASC) SCDVersion,
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
			FROM (
			SELECT
						product.ProductID ProductID,
						itmstat.LOVSetId LOVProductStatusSetId,
						itmstat.LOVId LOVStatusId,
						intprod.date_added EffectiveFrom,
						NULL EffectiveTo,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added SCDStartDate,        
						'''+@scdDefaultEndDate+''' SCDEndDate,    
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductId,itmstat.LOVId,intprod.record_source_id,
										intprod.date_added ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+' intprod
						JOIN ser.product product				
						ON product.SourceKey = intprod.item_code AND product.LOVRecordSourceID = intprod.record_source_id
						AND product.SCDActiveFlag = ''Y''
						AND intprod.item_status!= '''' AND intprod.item_status IS NOT NULL
						LEFT JOIN ser.productStatus p
						ON p.productId =product.ProductID AND p.LOVRecordSourceId = product.LOVRecordSourceId
						AND p.SCDActiveFlag = ''Y''
						LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId,rl.LOVSetId FROM  ser.RefLOV rl join ser.reflovset rls
						ON rl.LOVSetID = rls.LOVSetID and rl.LOVRecordSourceId = rls.LovSetRecordSourceId and rls.LOVSetName=''item_status'') itmstat
						ON intprod.record_source_id =itmstat.LOVRecordSourceId and itmstat.LOVKey=intprod.item_status
						WHERE intprod.row_status='+@rowStatusPSACode+'
						--AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
						AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@statusPsaETLRunLogID, '',''))
						) ProductStatus
						where ProductStatus.SCDActiveFlag=''Y'';


/* Inserting Data into Product Status table */

			INSERT INTO ser.productStatus (
			ProductID,LOVProductStatusSetId,LOVStatusId,EffectiveFrom,EffectiveTo,LOVRecordSourceId,SCDStartDate,SCDEndDate,
			SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey )
			SELECT * FROM [psa].[rawint_crp_product_status_temp]

		print ''Inserted Data into Product Status Table'';

/* Updating the SCD End Date */

		UPDATE pst SET SCDEndDate = temp.SCDEndDate               
			    FROM ser.productStatus pst
                JOIN
                (SELECT q.ProductId,q.SCDStartDate,q.SCDVersion,q.LOVRecordSourceId,
                LEAD(q.SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY q.ProductId ORDER BY q.SCDVersion ASC) SCDEndDate
                FROM ser.productStatus q
				WHERE q.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_status_temp]))temp
                ON temp.LOVRecordSourceId = pst.LOVRecordSourceId AND temp.ProductId = pst.ProductId AND temp.SCDStartDate = pst.SCDStartDate
				AND temp.SCDVersion=pst.SCDVersion

		print ''Updated SCD End Date'';

/* Updating Active Flag */

		UPDATE pst SET SCDActiveFlag=''N''
				FROM ser.productStatus  pst
				JOIN [psa].[rawint_crp_product_status_temp] temp
				ON temp.LovRecordSourceId = pst.LovRecordSourceId AND pst.productId = temp.productId 
				WHERE pst.SCDActiveFlag=''Y'' and pst.SCDENDDate !='''+@scdDefaultEndDate+'''

		print ''Updated Active Flag'';

		')

print 'Completed EXEC Command for Product Status';

/* 2.Table Name  :Product Property*/

print 'Started EXEC Command for Product Property';

exec('
		DECLARE  @statusPsaETLRunLogID     VARCHAR(200);

		SET		 @statusPsaETLRunLogID	   = '''+@psaETLRunLogID+''';

		INSERT INTO  [psa].[rawint_crp_product_property_temp]
			SELECT 
						ProductID,MeasureID,LOVUOMId,value,LOVRecordSourceId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,MeasureID ORDER BY SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+'''  
								 ELSE SCDStartDate
								 END SCDStartDate,
						SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductId,MeasureID,LOVRecordSourceId ORDER BY SCDStartDate ASC) SCDActiveFlag,
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,MeasureID ORDER BY SCDStartDate ASC) SCDVersion,
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
			FROM 
			(
			
			SELECT 
						product.ProductID ProductID,
						measure.MeasureId MeasureID,
						'+@uomCmId+' LOVUOMId,
						intprod.height value,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added SCDStartDate,
						'''+@scdDefaultEndDate+''' SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductID,intprod.height,intprod.record_source_id,intprod.date_added,measure.MeasureId ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+'  intprod
						JOIN ser.product product
						ON product.SourceKey = intprod.item_code AND product.LOVRecordSourceID = intprod.record_source_id
						AND product.SCDActiveFlag = ''Y''
						AND intprod.height != '''' AND intprod.height IS NOT NULL
						join ser.Measure measure 
						ON measure.MeasureName = ''height'' AND measure.LOVRecordSourceId = intprod.record_source_id
						AND measure.LOVMeasureTypeId='+@measureTypeId+' AND measure.LOVDataTypeId ='+@dataTypeId+' 
						LEFT JOIN ser.productProperty p
						ON p.ProductID =product.ProductID AND p.LOVRecordSourceId = product.LOVRecordSourceId
						AND p.MeasureID = measure.MeasureID AND p.SCDActiveFlag = ''Y''
						WHERE intprod.row_status='+@rowStatusPSACode+'
						--AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
						AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@statusPsaETLRunLogID, '',''))
	
			UNION
			SELECT
						product.ProductID ProductID,
						measure.MeasureID MeasureID,
						'+@uomCmId+' LOVUOMId,
						intprod.width value,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added SCDStartDate,
						'''+@scdDefaultEndDate+''' SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductID,intprod.width,intprod.record_source_id,intprod.date_added,measure.MeasureId ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+' intprod
						JOIN ser.product product
						ON product.SourceKey =intprod.item_code AND product.LOVRecordSourceID = intprod.record_source_id
						AND product.SCDActiveFlag = ''Y''
						AND intprod.width != '''' AND intprod.width IS NOT NULL 
						JOIN ser.Measure measure 
						ON measure.MeasureName =''width'' AND measure.LOVRecordSourceId = intprod.record_source_id
						AND measure.LOVMeasureTypeId='+@measureTypeId+' AND measure.LOVDataTypeId ='+@dataTypeId+' 
						LEFT JOIN ser.productProperty p
						ON p.ProductID =product.ProductID AND p.LOVRecordSourceId = product.LOVRecordSourceId
						AND p.MeasureID = measure.MeasureID AND p.SCDActiveFlag = ''Y''
						WHERE intprod.row_status='+@rowStatusPSACode+' 
						--AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
						AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@statusPsaETLRunLogID, '',''))
				
			UNION
			SELECT
						product.ProductID ProductID,
						measure.MeasureID MeasureID,
						'+@uomCmId+' LOVUOMId,
						intprod.depth value,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added SCDStartDate,
						'''+@scdDefaultEndDate+''' SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductID,intprod.depth,intprod.record_source_id,intprod.date_added,measure.MeasureId ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM '+@inpTableName+' intprod
						JOIN ser.product product
						ON product.SourceKey =intprod.item_code AND product.LOVRecordSourceID = intprod.record_source_id
						AND product.SCDActiveFlag =''Y''
						AND intprod.depth != '''' AND intprod.depth IS NOT NULL 
						JOIN ser.Measure measure 
						ON measure.MeasureName = ''depth'' AND measure.LOVRecordSourceId = intprod.record_source_id
						AND measure.LOVMeasureTypeId='+@measureTypeId+' AND measure.LOVDataTypeId ='+@dataTypeId+' 
						LEFT JOIN ser.productProperty p
						ON p.ProductID =product.ProductID AND p.LOVRecordSourceId = product.LOVRecordSourceId
						AND p.MeasureID = measure.MeasureID AND p.SCDActiveFlag = ''Y''
						WHERE intprod.row_status='+@rowStatusPSACode+' 
						--AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
						AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@statusPsaETLRunLogID, '',''))
				
			UNION
			SELECT
						product.ProductID ProductID,
						measure.MeasureID MeasureID,
						'+@uomUnknownId+' LOVUOMId,
						intprod.size value,
						intprod.record_source_id LOVRecordSourceId,
						intprod.date_added SCDStartDate,
						'''+@scdDefaultEndDate+''' SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductID,intprod.size,intprod.record_source_id,intprod.date_added,measure.MeasureId ORDER BY intprod.date_added ASC) SCDActiveFlag,
						p.SCDVersion SCDVersion,
						'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
						'+@inpServeETLRunLogID+' ETLRunLogId,
						intprod.row_id PSARowKey
						FROM  '+@inpTableName+' intprod
						JOIN ser.product product
						ON product.SourceKey = intprod.item_code AND product.LOVRecordSourceID = intprod.record_source_id
						AND product.SCDActiveFlag = ''Y''
						AND intprod.size != '''' AND intprod.size IS NOT NULL 
						JOIN ser.Measure measure 
						ON measure.MeasureName = ''size'' AND measure.LOVRecordSourceId = intprod.record_source_id
						AND measure.LOVMeasureTypeId='+@measureTypeId+' AND measure.LOVDataTypeId ='+@dataTypeId+' 
						LEFT JOIN ser.productProperty p
						ON p.ProductID =product.ProductID AND p.LOVRecordSourceId = product.LOVRecordSourceId
						AND p.MeasureID = measure.MeasureID AND p.SCDActiveFlag = ''Y''
						WHERE intprod.row_status='+@rowStatusPSACode+'
						--AND ISNULL(p.SCDActiveFlag,''Y'')=''Y''
						AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@statusPsaETLRunLogID, '',''))
						) ProductProperty
						where ProductProperty.SCDActiveFlag=''Y'';
						
/* Inserting Data into Product Property table */

			INSERT INTO ser.productProperty ( 
			ProductID,MeasureID,LOVUOMId,value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,
			ETLRunLogId,PSARowKey )
			SELECT * FROM [psa].[rawint_crp_product_property_temp]

		print ''Inserted Data into Product Property Table'';

/* Updating the SCD End Date */

		UPDATE ppty SET SCDEndDate = temp.SCDEndDate               
				FROM ser.productProperty ppty
                JOIN
                (SELECT q.ProductId,q.SCDStartDate,q.MeasureId,q.SCDVersion,q.LOVRecordSourceId,
                LEAD(q.SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY q.ProductId,q.MeasureId ORDER BY q.SCDVersion ASC) SCDEndDate
                FROM ser.productProperty q
				WHERE q.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_property_temp]))temp
                ON temp.LOVRecordSourceId = ppty.LOVRecordSourceId AND temp.ProductId = ppty.ProductId AND temp.SCDStartDate = ppty.SCDStartDate
				AND temp.SCDVersion=ppty.SCDVersion AND temp.MeasureId=ppty.MeasureId
				
		print ''Updated SCD End Date'';

/* Updating Active Flag */

		UPDATE ppty SET SCDActiveFlag=''N''
				FROM ser.productProperty  ppty
				JOIN [psa].[rawint_crp_product_property_temp] temp
				ON temp.LovRecordSourceId = ppty.LovRecordSourceId AND ppty.productId = temp.productId 
				WHERE ppty.SCDActiveFlag=''Y'' and ppty.SCDENDDate !='''+@scdDefaultEndDate+'''

		print ''Updated Active Flag'';
			
		')

		print 'Completed EXEC Command for Product Property';

	/* 5.Table Name  :Product Indicator*/

		print 'Started EXEC Command for Product Indicator';

exec('
		DECLARE  @IndicatorPsaETLRunLogID     VARCHAR(200);

		SET		 @IndicatorPsaETLRunLogID	   = '''+@psaETLRunLogID+''';

		INSERT INTO  [psa].[rawint_crp_product_indicator_temp]

		
		SELECT		pindTemp.ProductID ProductID,pindTemp.LOVIndicatorId LOVIndicatorId,
					pindTemp.PIValue Value,
					pindTemp.LOVRecordSourceId LOVRecordSourceId,
					CASE WHEN ((ISNULL(pind.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId ORDER BY pindTemp.SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+'''  
								 ELSE pindTemp.SCDStartDate
								 END SCDStartDate,
					pindTemp.SCDEndDate SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId ORDER BY pindTemp.SCDStartDate ASC) SCDActiveFlag,
					ISNULL(pind.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY pindTemp.ProductID,pindTemp.LOVIndicatorId ORDER BY pindTemp.SCDStartDate ASC) SCDVersion,
					pindTemp.SCDLOVRecordSourceId SCDLOVRecordSourceId,pindTemp.ETLRunLogId ETLRunLogId,pindTemp.PSARowKey PSARowKey
		FROM
		(
		SELECT 
					ProductID,
				   (SELECT LOVId FROM ser.RefLOV WHERE LOVKey =  ''''+PICol+'''' AND
				   LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet WHERE LOVSetName = '''+@indicatorName+''' )) LOVIndicatorId,
				   PIValue,
				   LOVRecordSourceId,
				   SCDStartDate ,
				   SCDEndDate ,
				   LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductID,PICol,PIValue,SCDStartDate ORDER BY SCDStartDate ASC) SCDActiveFlag,						
				   SCDLOVRecordSourceId,ETLRunLogId,
				   PSARowKey   
		FROM
		(
		SELECT
					product.ProductID ProductID,   
					intprod.exclusive_flag,
					intprod.own_brand_flag,
					intprod.record_source_id LOVRecordSourceId,
					intprod.date_added SCDStartDate,
					'''+@scdDefaultEndDate+''' SCDEndDate,
					'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
					'+@inpServeETLRunLogID+' ETLRunLogId,
					intprod.row_id PSARowKey
					FROM  '+@inpTableName+' intprod
					join ser.product product
					on product.SourceKey = intprod.item_code AND product.LOVRecordSourceID = intprod.record_source_id
					AND product.SCDActiveFlag = ''Y''
					WHERE intprod.row_status='+@rowStatusPSACode+'
					AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@IndicatorPsaETLRunLogID, '',''))
		) t
					UNPIVOT
						(PIValue FOR PICol in (exclusive_flag,own_brand_flag)
						) AS ProductIndicator WHERE  PIValue!='''' AND PIValue IS NOT NULL
		)pindTemp
					LEFT JOIN ser.productIndicator pind
							ON pindTemp.productid=pind.productid
							AND pindTemp.LOVIndicatorId=pind.LOVIndicatorId
							AND pindTemp.LOVRecordSourceId=pind.LOVRecordSourceId
							WHERE pindTemp.PIValue is not null  
							 AND ISNULL (pind.SCDActiveFlag,''Y'') =''Y''
							AND pindTemp.SCDActiveFlag=''Y''
						

/* Inserting Data into Product Indicator table */
		
			INSERT INTO ser.productIndicator (
			ProductId,LOVIndicatorId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,
			SCDLOVRecordSourceId,ETLRunLogId,PSARowKey	)
			SELECT * FROM [psa].[rawint_crp_product_indicator_temp]
		
		print ''Inserted Data into Product Indicator Table'';
		
/* Updating the SCD End Date */
		
			UPDATE pinr SET SCDEndDate = temp.SCDEndDate 
					FROM ser.productIndicator pinr
					JOIN
					(SELECT q.ProductId,q.SCDStartDate,q.LOVIndicatorId,q.SCDVersion,q.LOVRecordSourceId,
					LEAD(q.SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY q.ProductId,q.LOVIndicatorId ORDER BY q.SCDVersion ASC) SCDEndDate
					FROM ser.productIndicator q
					WHERE q.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_indicator_temp]))temp
					ON temp.LOVRecordSourceId = pinr.LOVRecordSourceId AND temp.ProductId = pinr.ProductId AND temp.SCDStartDate = pinr.SCDStartDate
					AND temp.SCDVersion=pinr.SCDVersion AND temp.LOVIndicatorId=pinr.LOVIndicatorId
				
		print ''Updated SCD End Date'';
		
/* Updating Active Flag */
		
			UPDATE pinr SET SCDActiveFlag=''N''
					FROM ser.productIndicator  pinr
					JOIN [psa].[rawint_crp_product_indicator_temp] temp
					ON temp.LovRecordSourceId = pinr.LovRecordSourceId AND pinr.productId = temp.productId 
					WHERE pinr.SCDActiveFlag=''Y'' and pinr.SCDENDDate !='''+@scdDefaultEndDate+'''
		
		print ''Updated Active Flag'';
			
    ')

print 'Completed EXEC Command for Product Indicator';

/* 6.Table Name  :Product Group*/

print 'Started EXEC Command for Product Group';

IF (@recordSourceId =12005 OR @recordSourceId =12004)

	exec('			
	 DECLARE  @GroupPsaETLRunLogID     VARCHAR(200);

		SET		 @GroupPsaETLRunLogID	   = '''+@psaETLRunLogID+''';
		
	 insert into [psa].[rawint_crp_product_group_temp] 
		SELECT
					intprod.row_id PSARowKey,
					product.ProductID ProductID,
					intprod.item_code SourceKey,            
					intprod.record_source_id LOVRecordSourceId,        
					intprod.date_added SCDStartDate,
					'''+@scdDefaultEndDate+''' SCDEndDate,
					'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
					'+@inpServeETLRunLogID+' ETLRunLogId,
					phc1.lovid product_hierarchy1_code,
					phn1.lovid product_hierarchy1_name,
					phc2.lovid product_hierarchy2_code,
					phn2.lovid product_hierarchy2_name,
					phc3.lovid product_hierarchy3_code,
					phn3.lovid product_hierarchy3_name,
					phc4.lovid product_hierarchy4_code,
					phn4.lovid product_hierarchy4_name,
					phc5.lovid product_hierarchy5_code,
					phn5.lovid product_hierarchy5_name FROM '+@inpTableName+' intprod
					JOIN (SELECT DISTINCT SourceKey,LOVRecordSourceID,ProductID FROM ser.product) product 
					ON product.SourceKey = intprod.item_code AND product.LOVRecordSourceID = intprod.record_source_id 
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceID = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy1_code'') phc1
					ON intprod.record_source_id =phc1.LOVRecordSourceId AND phc1.LOVKey=intprod.product_hierarchy1_code 
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceID = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy1_name'') phn1
					ON intprod.record_source_id =phn1.LOVRecordSourceId AND phn1.LOVKey=intprod.product_hierarchy1
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceID = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy2_code'') phc2
					ON intprod.record_source_id =phc2.LOVRecordSourceId AND phc2.LOVKey=intprod.product_hierarchy2_code
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy2_name'') phn2
					ON intprod.record_source_id =phn2.LOVRecordSourceId AND phn2.LOVKey=intprod.product_hierarchy2
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy3_code'') phc3
					ON intprod.record_source_id =phc3.LOVRecordSourceId AND phc3.LOVKey=intprod.product_hierarchy3_code
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy3_name'') phn3
					ON intprod.record_source_id =phn3.LOVRecordSourceId AND phn3.LOVKey=intprod.product_hierarchy3
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy4_code'') phc4
					ON intprod.record_source_id =phc4.LOVRecordSourceId AND phc4.LOVKey=intprod.product_hierarchy4_code
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy4_name'') phn4
					ON intprod.record_source_id =phn4.LOVRecordSourceId AND phn4.LOVKey=intprod.product_hierarchy4
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy5_code'') phc5
					ON intprod.record_source_id =phc5.LOVRecordSourceId AND phc5.LOVKey=intprod.product_hierarchy5_code
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy5_name'') phn5
					ON intprod.record_source_id =phn5.LOVRecordSourceId AND phn5.LOVKey=intprod.product_hierarchy5
					
					WHERE intprod.row_status='+@rowStatusPSACode+'
					AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@GroupPsaETLRunLogID, '',''));

	
	insert into  [psa].[rawint_crp_product_group_out]
		
		(
				[ProductGroupId],
				[ProductId] ,
				[LOVGroupId] ,
				[LOVProductGroupSetId] ,
				[ParentProductGroupId] ,
				[LOVRecordSourceId] ,
				[SCDStartDate] ,
				[SCDEndDate] ,
				[SCDActiveFlag] ,
				[SCDVersion] ,
				[SCDLOVRecordSourceId],
				[ETLRunLogId],
				[PSARowKey]
			)

	select 
					ProductGroupId,ProductId,LOVGroupId,LOVProductGroupSetId,ParentProductGroupId,
					LOVRecordSourceId,
					CASE WHEN ((ISNULL(pgrpTemp.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId,LOVProductGroupSetId ORDER BY SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+''' 
								 ELSE SCDStartDate
								 END SCDStartDate,
					SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductID,LOVProductGroupSetId ORDER BY SCDStartDate ASC) SCDActiveFlag,
					ISNULL(pgrpTemp.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId,LOVProductGroupSetId ORDER BY SCDStartDate ASC) AS SCDVersion,
					SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
	
	from 
	(
		SELECT 
					ISNULL(pdtGroup.ProductGroupId,temp.ProductGroupId) ProductGroupId,
					pgTemp.ProductId,
					pgTemp.PGValue LOVGroupId,
					pgTemp.LOVProductGroupSetId,
					NULL ParentProductGroupId,
					pgTemp.LOVRecordSourceId,
					pgTemp.SCDStartDate,
					pgTemp.SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY pgTemp.ProductId,pgTemp.LOVProductGroupSetId,pgTemp.PGValue,pgTemp.SCDStartDate,pgTemp.LOVRecordSourceId  ORDER BY pgTemp.SCDStartDate ASC) SCDActiveFlag,
					pdtGroup.ScdVersion SCDVersion,
					pgTemp.SCDLOVRecordSourceId,
					pgTemp.ETLRunLogId,
					pgTemp.PSARowKey
		FROM
		(
		SELECT		
					ProductId,
					(SELECT LOVSetID FROM ser.RefLOV WHERE LOVId = PGValue) LOVProductGroupSetId,
					PGValue,LOVRecordSourceId,SCDStartDate,SCDEndDate,
					SCDLOVRecordSourceId,ETLRunLogId, PSARowKey
	
		FROM
		(
		SELECT 
					ProductId,
					product_hierarchy1_code,product_hierarchy1_name,
					product_hierarchy2_code,product_hierarchy2_name,
					product_hierarchy3_code,product_hierarchy3_name,
					product_hierarchy4_code,product_hierarchy4_name,
					product_hierarchy5_code,product_hierarchy5_name,
					SCDStartDate,SCDEndDate,
					SCDLOVRecordSourceId,LOVRecordSourceId,ETLRunLogId,
					PSARowKey
					FROM psa.rawint_crp_product_group_temp) t
	
		UNPIVOT  
					( PGValue FOR PGCol IN (product_hierarchy1_code,product_hierarchy1_name,
											product_hierarchy2_code,product_hierarchy2_name,
											product_hierarchy3_code,product_hierarchy3_name,
											product_hierarchy4_code,product_hierarchy4_name,
											product_hierarchy5_code,product_hierarchy5_name)
					)	AS LOVGroupId WHERE  PGValue!='''' AND PGValue IS NOT NULL 
					) AS pgTemp
		JOIN 
					(SELECT ProductId,LOVProductGroupSetId,('+@maxProductGroupId+'+ROW_NUMBER() OVER(ORDER BY ProductId,LOVProductGroupSetId ASC)) ProductGroupId
		FROM  
		(
		SELECT
					ProductId,
					(SELECT LOVSetID FROM ser.RefLOV WHERE LOVId = PGValue) LOVProductGroupSetId 
		FROM
		(
		SELECT		ProductId,				
					product_hierarchy1_code,product_hierarchy1_name,
					product_hierarchy2_code,product_hierarchy2_name,
					product_hierarchy3_code,product_hierarchy3_name,
					product_hierarchy4_code,product_hierarchy4_name,
					product_hierarchy5_code,product_hierarchy5_name
					--SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,LOVRecordSourceId,ETLRunLogId
					FROM psa.rawint_crp_product_group_temp) t

		UNPIVOT  
					( PGValue FOR PGCol IN (product_hierarchy1_code,product_hierarchy1_name,
											product_hierarchy2_code,product_hierarchy2_name,
											product_hierarchy3_code,product_hierarchy3_name,
											product_hierarchy4_code,product_hierarchy4_name,
											product_hierarchy5_code,product_hierarchy5_name)
					)	AS LOVGroupId WHERE  PGValue!='''' AND PGValue IS NOT NULL 
					) a 
					GROUP BY ProductId,LOVProductGroupSetId) temp
					ON 	temp.ProductId = pgTemp.ProductId AND temp.LOVProductGroupSetId = pgTemp.LOVProductGroupSetId
					LEFT JOIN ser.productGroup pdtGroup
					ON pdtGroup.ProductId = pgTemp.ProductId
					AND pdtGroup.LOVProductGroupSetId = pgTemp.LOVProductGroupSetId 
					AND pdtGroup.LOVRecordSourceId = pgTemp.LOVRecordSourceId
					AND pdtGroup.SCDActiveFlag = ''Y''
					) pgrpTemp
					where pgrpTemp.scdActiveFlag=''Y'';
				
	
/* Inserting Data into Product Group table */
		
			insert into ser.productGroup (
			ProductGroupId,ProductId,LOVProductGroupSetId,LOVGroupId,ParentProductGroupId,LOVRecordSourceId,
			SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey )
			select * from  [psa].[rawint_crp_product_group_out]
		
		print ''Inserted Data into Product Status Table'';

/* Updating the SCD End Date */

	UPDATE pdtGroup SET SCDEndDate = t.SCDEndDate				
			FROM ser.productGroup pdtGroup
			JOIN 
			(SELECT pg.LOVRecordSourceId,pg.ProductId,pg.LOVProductGroupSetId,pg.SCDStartDate,pg.ScdVersion,
			LEAD(pg.SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY pg.ProductId,pg.LOVProductGroupSetId ORDER BY pg.SCDStartDate ASC) SCDEndDate 
			FROM ser.productGroup pg
			WHERE pg.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_group_out])
			)t
			ON t.LOVRecordSourceId = pdtGroup.LOVRecordSourceId AND t.ProductId = pdtGroup.ProductId 
			AND t.LOVProductGroupSetId = pdtGroup.LOVProductGroupSetId  AND t.SCDStartDate = pdtGroup.SCDStartDate
			AND t.ScdVersion=pdtGroup.ScdVersion
			
			print ''Updated SCD End Date'';

/* Updating Active Flag */

			UPDATE pdtGroup SET pdtGroup.SCDActiveFlag=''N''
			FROM ser.productGroup pdtGroup
			WHERE pdtGroup.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_group_out])
			AND pdtGroup.SCDActiveFlag=''Y''
			AND pdtGroup.SCDEndDate != '''+@scdDefaultEndDate+'''
			
			print ''Updated Active Flag'';

	
')	


	IF (@recordSourceId =12010)
		
	exec('			
	 DECLARE  @GroupPsaETLRunLogID     VARCHAR(200);

		SET		 @GroupPsaETLRunLogID	   = '''+@psaETLRunLogID+''';
		
	 insert into [psa].[rawint_crp_product_group_temp_thai] 
		SELECT
					intprod.row_id PSARowKey,
					product.ProductID ProductID,
					intprod.item_code SourceKey,            
					intprod.record_source_id LOVRecordSourceId,        
					intprod.date_added SCDStartDate,
					'''+@scdDefaultEndDate+''' SCDEndDate,
					'+@scdLovRecordSourceId+' SCDLOVRecordSourceId,
					'+@inpServeETLRunLogID+' ETLRunLogId,
					phc1.lovid product_hierarchy1_code,
					phn1.lovid product_hierarchy1_name,
					phc2.lovid product_hierarchy2_code,
					phn2.lovid product_hierarchy2_name,
					phc3.lovid product_hierarchy3_code,
					phn3.lovid product_hierarchy3_name,
					phc4.lovid product_hierarchy4_code,
					phn4.lovid product_hierarchy4_name FROM '+@inpTableName+' intprod
					JOIN (SELECT DISTINCT SourceKey,LOVRecordSourceID,ProductID FROM ser.product) product 
					ON product.SourceKey = intprod.item_code AND product.LOVRecordSourceID = intprod.record_source_id 
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceID = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy1_code'') phc1
					ON intprod.record_source_id =phc1.LOVRecordSourceId AND phc1.LOVKey=intprod.product_hierarchy1_code 
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceID = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy1_name'') phn1
					ON intprod.record_source_id =phn1.LOVRecordSourceId AND phn1.LOVKey=intprod.product_hierarchy1
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceID = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy2_code'') phc2
					ON intprod.record_source_id =phc2.LOVRecordSourceId AND phc2.LOVKey=intprod.product_hierarchy2_code
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy2_name'') phn2
					ON intprod.record_source_id =phn2.LOVRecordSourceId AND phn2.LOVKey=intprod.product_hierarchy2
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy3_code'') phc3
					ON intprod.record_source_id =phc3.LOVRecordSourceId AND phc3.LOVKey=intprod.product_hierarchy3_code
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy3_name'') phn3
					ON intprod.record_source_id =phn3.LOVRecordSourceId AND phn3.LOVKey=intprod.product_hierarchy3
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy4_code'') phc4
					ON intprod.record_source_id =phc4.LOVRecordSourceId AND phc4.LOVKey=intprod.product_hierarchy4_code
					
					LEFT JOIN (SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.reflovset rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName=''product_hierarchy4_name'') phn4
					ON intprod.record_source_id =phn4.LOVRecordSourceId AND phn4.LOVKey=intprod.product_hierarchy4
					
					WHERE intprod.row_status='+@rowStatusPSACode+'
					AND intprod.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@GroupPsaETLRunLogID, '',''));

	
	insert into  [psa].[rawint_crp_product_group_out]
		
		(
				[ProductGroupId],
				[ProductId] ,
				[LOVGroupId] ,
				[LOVProductGroupSetId] ,
				[ParentProductGroupId] ,
				[LOVRecordSourceId] ,
				[SCDStartDate] ,
				[SCDEndDate] ,
				[SCDActiveFlag] ,
				[SCDVersion] ,
				[SCDLOVRecordSourceId],
				[ETLRunLogId],
				[PSARowKey]
			)

	select 
					ProductGroupId,ProductId,LOVGroupId,LOVProductGroupSetId,ParentProductGroupId,
					LOVRecordSourceId,
					CASE WHEN ((ISNULL(pgrpTemp.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId,LOVProductGroupSetId ORDER BY SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+'''
								 ELSE SCDStartDate
								 END SCDStartDate,
					SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductID,LOVProductGroupSetId ORDER BY SCDStartDate ASC) SCDActiveFlag,
					ISNULL(pgrpTemp.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductId,LOVProductGroupSetId ORDER BY SCDStartDate ASC) AS SCDVersion,
					SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
	
	from 
	(
		SELECT 
					ISNULL(pdtGroup.ProductGroupId,temp.ProductGroupId) ProductGroupId,
					pgTemp.ProductId,
					pgTemp.PGValue LOVGroupId,
					pgTemp.LOVProductGroupSetId,
					NULL ParentProductGroupId,
					pgTemp.LOVRecordSourceId,
					pgTemp.SCDStartDate,
					pgTemp.SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY pgTemp.ProductId,pgTemp.LOVProductGroupSetId,pgTemp.PGValue,pgTemp.SCDStartDate,pgTemp.LOVRecordSourceId  ORDER BY pgTemp.SCDStartDate ASC) SCDActiveFlag,
					pdtGroup.ScdVersion SCDVersion,	
					pgTemp.SCDLOVRecordSourceId,
					pgTemp.ETLRunLogId,
					pgTemp.PSARowKey
		FROM
		(
		SELECT		
					ProductId,
					(SELECT LOVSetID FROM ser.RefLOV WHERE LOVId = PGValue) LOVProductGroupSetId,
					PGValue,LOVRecordSourceId,SCDStartDate,SCDEndDate,
					SCDLOVRecordSourceId,ETLRunLogId, PSARowKey
	
		FROM
		(
		SELECT 
					ProductId,
					product_hierarchy1_code,product_hierarchy1_name,
					product_hierarchy2_code,product_hierarchy2_name,
					product_hierarchy3_code,product_hierarchy3_name,
					product_hierarchy4_code,product_hierarchy4_name,
					SCDStartDate,SCDEndDate,
					SCDLOVRecordSourceId,LOVRecordSourceId,ETLRunLogId,
					PSARowKey
					FROM psa.rawint_crp_product_group_temp_thai) t
	
		UNPIVOT  
					( PGValue FOR PGCol IN (product_hierarchy1_code,product_hierarchy1_name,
											product_hierarchy2_code,product_hierarchy2_name,
											product_hierarchy3_code,product_hierarchy3_name,
											product_hierarchy4_code,product_hierarchy4_name)
					)	AS LOVGroupId WHERE  PGValue!='''' AND PGValue IS NOT NULL 
					) AS pgTemp
		JOIN 
					(SELECT ProductId,LOVProductGroupSetId,('+@maxProductGroupId+'+ROW_NUMBER() OVER(ORDER BY ProductId,LOVProductGroupSetId ASC)) ProductGroupId
		FROM 
		(
		SELECT
					ProductId,
					(SELECT LOVSetID FROM ser.RefLOV WHERE LOVId = PGValue) LOVProductGroupSetId 
		FROM
		(
		SELECT		ProductId,				
					product_hierarchy1_code,product_hierarchy1_name,
					product_hierarchy2_code,product_hierarchy2_name,
					product_hierarchy3_code,product_hierarchy3_name,
					product_hierarchy4_code,product_hierarchy4_name
					--SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,LOVRecordSourceId,ETLRunLogId
					FROM psa.rawint_crp_product_group_temp_thai) t

		UNPIVOT  
					( PGValue FOR PGCol IN (product_hierarchy1_code,product_hierarchy1_name,
											product_hierarchy2_code,product_hierarchy2_name,
											product_hierarchy3_code,product_hierarchy3_name,
											product_hierarchy4_code,product_hierarchy4_name)
					)	AS LOVGroupId WHERE  PGValue!='''' AND PGValue IS NOT NULL 
					) a 
					GROUP BY ProductId,LOVProductGroupSetId) temp
					ON 	temp.ProductId = pgTemp.ProductId AND temp.LOVProductGroupSetId = pgTemp.LOVProductGroupSetId
					LEFT JOIN ser.productGroup pdtGroup
					ON pdtGroup.ProductId = pgTemp.ProductId
					AND pdtGroup.LOVProductGroupSetId = pgTemp.LOVProductGroupSetId 
					AND pdtGroup.LOVRecordSourceId = pgTemp.LOVRecordSourceId
					AND pdtGroup.SCDActiveFlag = ''Y''
					) pgrpTemp
					where pgrpTemp.scdActiveFlag=''Y''
	
	
/* Inserting Data into Product Group table */
		
		insert into ser.productGroup (
			ProductGroupId,ProductId,LOVProductGroupSetId,LOVGroupId,ParentProductGroupId,LOVRecordSourceId,
			SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey )
			select * from  [psa].[rawint_crp_product_group_out]
		
		print ''Inserted Data into Product Status Table'';

/* Updating the SCD End Date */

	UPDATE pdtGroup SET SCDEndDate = t.SCDEndDate				
			FROM ser.productGroup pdtGroup
			JOIN 
			(SELECT pg.LOVRecordSourceId,pg.ProductId,pg.LOVProductGroupSetId,pg.SCDStartDate,pg.ScdVersion,
			LEAD(pg.SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY pg.ProductId,pg.LOVProductGroupSetId ORDER BY pg.SCDStartDate ASC) SCDEndDate 
			FROM ser.productGroup pg
			WHERE pg.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_group_out])
			)t
			ON t.LOVRecordSourceId = pdtGroup.LOVRecordSourceId AND t.ProductId = pdtGroup.ProductId 
			AND t.LOVProductGroupSetId = pdtGroup.LOVProductGroupSetId  AND t.SCDStartDate = pdtGroup.SCDStartDate
			AND t.ScdVersion=pdtGroup.ScdVersion
			
			print ''Updated SCD End Date'';

/* Updating Active Flag */

			UPDATE pdtGroup SET pdtGroup.SCDActiveFlag=''N''
			FROM ser.productGroup pdtGroup
			WHERE pdtGroup.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_group_out])
			AND pdtGroup.SCDActiveFlag=''Y''
			AND pdtGroup.SCDEndDate != '''+@scdDefaultEndDate+'''
			
			print ''Updated Active Flag'';
	
')	


/* 7.Table Name  :Party*/

print 'Started EXEC Command for Party table';

exec('

DECLARE  @partyPsaETLRunLogID     VARCHAR(200)

SET      @partyPsaETLRunLogID       = '''+@psaETLRunLogID+'''
INSERT INTO ser.party
					(                         
					PartyId                ,
					LOVPartyTypeId         ,
					SourceKey              ,
					LOVRecordSourceId      ,                
					SCDEndDate             ,
					SCDActiveFlag          ,
					SCDVersion             ,
					SCDLOVRecordSourceId   ,
					ETLRunLogId            ,				  
					SCDStartDate           ,
					PSARowKey
					)
			SELECT  '+@maxpartyID+'+ROW_NUMBER() OVER(ORDER BY t.SourceKey,t.LOVRecordSourceId ASC) partyId,
					'+@partytypeID+'  LOVPartyTypeId,
					t.SourceKey,
					t.LOVRecordSourceId,
					'''+@scdDefaultEndDate+''' SCDEndDate,
					''Y'' SCDActiveFlag,
					1 SCDVersion,
					'+@scdLovRecordSourceID+' SCDLOVRecordSourceId, 
					'+@inpServeETLRunLogID+' ETLRunLogId,
					'''+@scdDefaultStartDate+''' SCDStartDate ,
					PSARowKey
			FROM
			(SELECT supplier_number SourceKey,record_source_id LOVRecordSourceId,etl_runlog_id ETLRunLogId,MIN(date_added) SCDStartDate,MIN(row_id) PSARowKey
			FROM '+@inpTableName+' temp 
			WHERE temp.supplier_number!='''' AND temp.supplier_number IS NOT NULL
			AND temp.row_status='+@rowStatusPSACode+'
			AND temp.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@partyPsaETLRunLogID, '',''))
			GROUP BY supplier_number,record_source_id,etl_runlog_id)t
			WHERE NOT EXISTS
			(SELECT sourcekey, LOVRecordSourceId FROM ser.party party WHERE t.sourcekey=party.sourcekey and t.LOVRecordSourceId=party.LOVRecordSourceId )
	

')
print 'Completed EXEC Command for Party table';

/* 8.Table Name  :Organisation*/

print 'Started EXEC Command for Organisation table';

exec('

DECLARE  @orgPsaETLRunLogID     VARCHAR(200)

SET      @orgPsaETLRunLogID       = '''+@psaETLRunLogID+'''
 INSERT INTO ser.organisation    
            (
            PartyId                 ,
            SourceOrganisationKey,
            OrganisationName     ,
            LOVRecordSourceId    ,
            ParentPartyId         ,
            SCDStartDate         ,
            SCDEndDate             ,
            SCDActiveFlag         , 
			SCDVersion,
            SCDLOVRecordSourceId ,
            ETLRunLogId             ,
            PSARowKey             
                         
            ) 
SELECT    party.PartyId  PartyId,
        t.SourceOrganisationKey,
        t.OrganisationName,
        t.LOVRecordSourceId,
        NULL ParentPartyId,
		CASE WHEN ((ISNULL(org.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+''' 
								 ELSE t.SCDStartDate
								 END SCDStartDate,
        '''+@scdDefaultEndDate+''' SCDEndDate,
        LEAD(''N'', 1, ''Y'') OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC) SCDActiveFlag,
        ISNULL(org.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY party.PartyId,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC) SCDVersion,
        '+@scdLovRecordSourceID+' SCDLOVRecordSourceId, 
		'+@inpServeETLRunLogID+' ETLRunLogId,
        t.PSARowKey
FROM
            (SELECT supplier_number SourceOrganisationKey,supplier_name OrganisationName,record_source_id LOVRecordSourceId,etl_runlog_id ETLRunLogId,
            MIN(date_added) SCDStartDate,MIN(row_id) PSARowKey
            FROM '+@inpTableName+' temp 
            WHERE temp.supplier_number!='''' AND temp.supplier_number IS NOT NULL
			AND temp.row_status='+@rowStatusPSACode+' 
			AND temp.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@orgPsaETLRunLogID, '',''))
            GROUP BY supplier_number,supplier_name,record_source_id,etl_runlog_id)t
			
JOIN ser.party party
ON t.SourceOrganisationKey = party.SourceKey and party.SCDActiveFlag=''Y''
AND t.LOVRecordSourceId = party.LOVRecordSourceId
LEFT JOIN ser.organisation org
ON org.PartyId = party.PartyId
AND org.LOVRecordSourceId = t.LOVRecordSourceId
AND org.SCDActiveFlag = ''Y''  

WHERE NOT EXISTS
(SELECT SourceOrganisationKey,OrganisationName,LOVRecordSourceId FROM ser.organisation org  
WHERE t.SourceOrganisationKey=org.SourceOrganisationKey AND t.OrganisationName=org.OrganisationName 
AND t.LOVRecordSourceId=org.LOVRecordSourceId )


/* Updating the SCD End Date */

UPDATE org SET SCDEndDate = t.SCDEndDate                
FROM ser.organisation org
JOIN 
(SELECT orgTemp.LOVRecordSourceId,orgTemp.PartyId,orgTemp.SCDStartDate,
LEAD(orgTemp.SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY orgTemp.PartyId ORDER BY orgTemp.SCDStartDate ASC) SCDEndDate 
FROM ser.organisation orgTemp
WHERE orgTemp.SourceOrganisationKey IN (SELECT DISTINCT supplier_number FROM '+@inpTableName+')
AND orgTemp.LOVRecordSourceId = '+@recordSourceId+'
)t
ON t.LOVRecordSourceId = org.LOVRecordSourceId AND t.PartyId = org.PartyId 
AND t.SCDStartDate = org.SCDStartDate


/* Updating Active Flag */


UPDATE org SET org.SCDActiveFlag=''N''
FROM ser.organisation org
WHERE org.SourceOrganisationKey IN (SELECT DISTINCT supplier_number FROM '+@inpTableName+')
AND org.LOVRecordSourceId = '+@recordSourceId+'
AND org.SCDActiveFlag=''Y''
AND org.SCDEndDate != '''+@scdDefaultEndDate+'''
')
print 'Completed EXEC Command for Organisation table';


/* 9.Table Name  :Party Role*/
print 'Started EXEC Command for Party Role table';

exec('


DECLARE  @prolePsaETLRunLogID     VARCHAR(200)

SET      @prolePsaETLRunLogID       = '''+@psaETLRunLogID+'''

		   INSERT INTO ser.partyRole
					(
					PartyRoleId			,
					LOVRoleId			,
					PartyId				,
					SourceKey			,
					PartyRoleName		,
					LOVRecordSourceId   ,
					SCDStartDate	    ,
					SCDEndDate			,
					SCDActiveFlag       ,
					SCDVersiON          ,
					SCDLOVRecordSourceId,
					ETLRunLogId			,
					PSARowKey
					)


SELECT	    isnull(pRole.partyroleid,a.PartyRoleId) PartyRoleId,
					'+@supplier_LOVRoleId+' LOVRoleId,
					party.PartyId PartyId,
					t.SourceKey,
					t.PartyRoleName,
					t.LOVRecordSourceId,
					CASE WHEN ((ISNULL(pRole.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+''' 
								 ELSE t.SCDStartDate
								 END SCDStartDate,	
					'''+@scdDefaultEndDate+''' SCDEndDate,
					LEAD(''N'', 1, ''Y'') OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC) SCDActiveFlag,
					ISNULL(pRole.SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY t.SourceKey,t.LOVRecordSourceId ORDER BY t.SCDStartDate ASC) SCDVersion,
					'+@scdLovRecordSourceID+' SCDLOVRecordSourceId, 
					'+@inpServeETLRunLogID+' ETLRunLogId,
					t.PSARowKey
			FROM
						(SELECT supplier_number SourceKey,supplier_name PartyRoleName,record_source_id LOVRecordSourceId,etl_runlog_id ETLRunLogId,
						MIN(date_added) SCDStartDate,MIN(row_id) PSARowKey
						FROM '+@inpTableName+' temp 
						WHERE temp.supplier_number!='''' AND temp.supplier_number IS NOT NULL
						AND temp.row_status='+@rowStatusPSACode+'
						AND temp.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@prolePsaETLRunLogID, '',''))
						GROUP BY supplier_number,supplier_name,record_source_id,etl_runlog_id)t						
						JOIN (SELECT supplier_number,'+@maxpartyRoleID+'+ROW_NUMBER() OVER(ORDER BY supplier_number,record_source_id ASC) PartyRoleId
            FROM '+@inpTableName+' GROUP BY supplier_number,record_source_id
            ) a
            ON t.SourceKey = a.supplier_number
			JOIN ser.party party
			ON t.SourceKey = party.SourceKey and party.SCDActiveFlag=''Y''
			AND t.LOVRecordSourceId = party.LOVRecordSourceId
			LEFT JOIN ser.partyRole pRole
			ON pRole.PartyId = party.PartyId
			AND pRole.LOVRecordSourceId = t.LOVRecordSourceId
			AND pRole.SCDActiveFlag = ''Y''			
			WHERE NOT EXISTS
			(SELECT SourceKey,PartyRoleName,LOVRecordSourceId FROM ser.partyRole pr 
			WHERE t.SourceKey=pr.SourceKey AND t.PartyRoleName=pr.PartyRoleName 
			AND t.LOVRecordSourceId=pr.LOVRecordSourceId )

			
			/* Updating the SCD End Date */


			
			UPDATE pRole SET SCDEndDate = t.SCDEndDate				
			FROM ser.partyRole pRole
			JOIN 
			(SELECT pr.LOVRecordSourceId,pr.PartyId,pr.SCDStartDate,
			LEAD(pr.SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY pr.PartyId ORDER BY pr.SCDStartDate ASC) SCDEndDate 
			FROM ser.partyRole pr
			WHERE pr.SourceKey IN (SELECT DISTINCT supplier_number FROM '+@inpTableName+' )
			AND pr.LOVRecordSourceId = '+@recordSourceId+'
			)t
			ON t.LOVRecordSourceId = pRole.LOVRecordSourceId AND t.PartyId = pRole.PartyId 
			AND t.SCDStartDate = pRole.SCDStartDate
			

/* Updating Active Flag */

			UPDATE pRole SET pRole.SCDActiveFlag=''N''
			FROM ser.partyRole pRole
			WHERE pRole.SourceKey IN (SELECT DISTINCT supplier_number FROM '+@inpTableName+')
			AND pRole.LOVRecordSourceId = '+@recordSourceId+'
			AND pRole.SCDActiveFlag=''Y''
			AND pRole.SCDEndDate != '''+@scdDefaultEndDate+'''
			
			
')
		print 'Completed EXEC Command for Party role';	
		

	/* 10.Table Name  :Product Party Role*/

print 'Started EXEC Command for Product Party Role table';
		
exec('

DECLARE  @pprPsaETLRunLogID     VARCHAR(200);

SET      @pprPsaETLRunLogID       = '''+@psaETLRunLogID+''' ;

INSERT INTO [psa].[rawint_crp_product_party_role_temp]

SELECT
						ProductID,PartyRoleId,LOVRecordSourceId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,LovRoleID ORDER BY SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+''' 
								 ELSE SCDStartDate
								 END SCDStartDate,	
						SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductId,LovRoleID,LOVRecordSourceId ORDER BY SCDStartDate ASC) SCDActiveFlag,
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,LovRoleID ORDER BY SCDStartDate ASC) SCDVersion,
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
			FROM (
	
SELECT
						product.ProductId ProductID,
						pr.lovRoleId LovRoleID, 
						pr.PartyRoleId PartyRoleId,
						temp.record_source_id LOVRecordSourceId,
						temp.date_added SCDStartDate,
						'''+@scdDefaultEndDate+''' SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductId,pr.LOVRoleId,temp.record_source_id,temp.date_added ORDER BY temp.date_added ASC) SCDActiveFlag,
						t.SCDVersion SCDVersion,
						'+@scdLovRecordSourceID+' SCDLOVRecordSourceId, 
						'+@inpServeETLRunLogID+' ETLRunLogId,
						temp.row_id PSARowKey
						FROM '+@inpTableName+' temp  
						JOIN ser.product product ON product.SourceKey = temp.item_code 
						AND product.LOVRecordSourceID = temp.record_source_id
						AND product.SCDActiveFlag = ''Y''
						
						JOIN ser.partyRole pr ON temp.supplier_number = pr.SourceKey
						AND temp.supplier_number!='''' AND temp.supplier_number IS NOT NULL
						AND temp.record_source_id = pr.LOVRecordSourceId AND pr.SCDActiveFlag=''Y''
						AND temp.row_status='+@rowStatusPSACode+' AND ISNULL(pr.SCDActiveFlag,''Y'')=''Y''
						AND temp.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@pprPsaETLRunLogID,'',''))

						LEFT JOIN (SELECT pRole.ProductId,pRole.LOVRecordSourceId,pRole.SCDVersion,prt.LOVRoleId FROM ser.ProductPartyRole pRole JOIN ser.PartyRole prt
					    ON 
					       pRole.LOVRecordSourceId = prt.LOVRecordSourceId
						   AND pRole.PartyRoleId = prt.PartyRoleId 
					       AND prt.LOVRoleId = '+@supplier_LOVRoleId+'
					       AND isnull(pRole.SCDActiveFlag,''Y'')=''Y'') t
						ON t.ProductId = product.ProductId
					       AND t.LOVRoleId = pr.LOVRoleId
					       AND t.LOVRecordSourceId = temp.record_source_id
					) proPtyRole
							where proPtyRole.SCDActiveFlag=''Y''

print ''Inserted First Set of data into temp table'';

INSERT INTO [psa].[rawint_crp_product_party_role_temp]

SELECT
						ProductID,PartyRoleId,LOVRecordSourceId,
						CASE WHEN ((ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,LovRoleID ORDER BY SCDStartDate ASC)) = 1)
								 THEN '''+@scdDefaultStartDate+''' 
								 ELSE SCDStartDate
								 END SCDStartDate,	
						SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY ProductId,LovRoleID,LOVRecordSourceId ORDER BY SCDStartDate ASC) SCDActiveFlag,
						ISNULL(SCDVersion,0)+ROW_NUMBER() OVER(PARTITION BY ProductID,LovRoleID ORDER BY SCDStartDate ASC) SCDVersion,
						SCDLOVRecordSourceId,ETLRunLogId,PSARowKey
			FROM (
	
SELECT
						product.ProductId ProductID,
						'+@lovRetailerRoleId+' LovRoleID,
						'+@partyRoleID+' PartyRoleId,
						temp.record_source_id LOVRecordSourceId,
						temp.date_added SCDStartDate,
						'''+@scdDefaultEndDate+''' SCDEndDate,
						LEAD(''N'', 1, ''Y'') OVER(PARTITION BY product.ProductId,'+@lovRetailerRoleId+',temp.record_source_id,temp.date_added ORDER BY temp.date_added ASC) SCDActiveFlag,
						t.SCDVersion SCDVersion,
						'+@scdLovRecordSourceID+' SCDLOVRecordSourceId, 
						'+@inpServeETLRunLogID+' ETLRunLogId,
						temp.row_id PSARowKey
						FROM '+@inpTableName+' temp  
						JOIN ser.product product ON product.SourceKey = temp.item_code
						AND product.LOVRecordSourceID = temp.record_source_id
						AND product.SCDActiveFlag = ''Y''
						AND temp.supplier_number!='''' AND temp.supplier_number IS NOT NULL
						AND temp.row_status='+@rowStatusPSACode+' 
						AND temp.etl_runlog_id IN (SELECT value FROM STRING_SPLIT(@pprPsaETLRunLogID,'',''))
				
						LEFT JOIN (SELECT pRole.ProductId,pRole.LOVRecordSourceId,pRole.SCDVersion,prt.LOVRoleId FROM ser.ProductPartyRole pRole JOIN ser.PartyRole prt
					    ON 
					       pRole.LOVRecordSourceId = prt.LOVRecordSourceId
						   AND pRole.PartyRoleId = prt.PartyRoleId 
					       AND prt.LOVRoleId = '+@lovRetailerRoleId+'
					       AND isnull(pRole.SCDActiveFlag,''Y'')=''Y'') t
						ON t.ProductId = product.ProductId
					       AND t.LOVRoleId ='+@lovRetailerRoleId+'
					       AND t.LOVRecordSourceId = temp.record_source_id

						) proPtyRole
						where proPtyRole.SCDActiveFlag=''Y''	

print ''Inserted Second Set of data into temp table'';

/* Inserting Data into Product Party Role table */		

		INSERT INTO ser.productPartyRole (
		ProductID,PartyRoleId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey )
		SELECT * FROM [psa].[rawint_crp_product_party_role_temp]
			
		print ''Inserted Data into Product Party Role Table'';
		
/* Updating the SCD End Date */			
UPDATE proPtyRole SET SCDEndDate = t.SCDEndDate				
from ser.productPartyRole proPtyRole
JOIN 
(SELECT prr.LOVRecordSourceId,prr.ProductId,prr.PartyRoleId,prr.SCDStartDate,prr.SCDVersion,
LEAD(prr.SCDStartDate,1,'''+@scdDefaultEndDate+''') OVER(PARTITION BY prr.ProductId ,pr.LOVRoleId ORDER BY prr.SCDStartDate ASC) SCDEndDate 
FROM ser.productPartyRole prr
JOIN ser.partyRole pr
ON pr.partyroleid =prr.partyroleid AND pr.LovRecordSourceId=prr.LovRecordSourceId
AND pr.SCDActiveFlag=''Y''
AND prr.ProductId IN (SELECT ProductId FROM [psa].[rawint_crp_product_party_role_temp])
)t
ON t.LOVRecordSourceId = proPtyRole.LOVRecordSourceId AND t.ProductId = proPtyRole.ProductId 
AND t.PartyRoleId = proPtyRole.PartyRoleId  AND t.SCDStartDate = proPtyRole.SCDStartDate
AND t.SCDVersion=proPtyRole.SCDVersion 

print ''Updated SCD End Date'';

/* Updating Active Flag */
UPDATE p SET SCDActiveFlag=''N''
FROM ser.productPartyRole  p
JOIN [psa].[rawint_crp_product_party_role_temp] temp
ON temp.LovRecordSourceId = p.LovRecordSourceId AND p.productId = temp.productId 
WHERE p.SCDActiveFlag=''Y'' and p.SCDENDDate !='''+@scdDefaultEndDate+'''

print ''Updated Active Flag'';

')
print 'Completed EXEC Command for Product Party Role table';


	exec('
				UPDATE '+@inpTableName+' SET row_status='+@rowStatusSERCode+'
				FROM '+@inpTableName+' intprod 
				INNER JOIN ser.product p ON intprod.item_code=p.sourceKey and intprod.record_source_id=p.LovRecordSourceID 
				WHERE intprod.row_status='+@rowStatusPSACode+'  AND p.ETLRunLogId in (CAST('+@inpServeETLRunLogID+' AS INT))
		
				print ''Updated Row Status to Loaded to Serve''
		')

print '************************* Completed updating row status to Loaded to Serve *********************************';

	COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH 
				THROW; 			
				ROLLBACK TRANSACTION ;						
			END CATCH 

			print 'Dropping Physical Temp Table for Product';
				DROP TABLE [psa].[rawint_crp_product_temp]
					print 'Successfully dropped Physical Temp Table for Product';
					
			print 'Dropping Physical Temp Table for Identifier';
				DROP TABLE [psa].[rawint_crp_product_identifier_temp]
					print 'Successfully dropped Physical Temp Table for Identifier';

			print 'Dropping Physical Temp Table for Status';
				DROP TABLE [psa].[rawint_crp_product_status_temp]
					print 'Successfully dropped Physical Temp Table for Status';

			print 'Dropping Physical Temp Table for Property';
				DROP TABLE [psa].[rawint_crp_product_property_temp]
						print 'Successfully dropped Physical Temp Table for Property';

			print 'Dropping Physical Temp Table for Product Indicator';
				DROP TABLE [psa].[rawint_crp_product_indicator_temp]
						print 'Successfully dropped Physical Temp Table for Product Indicator';	
			
			print 'Dropping Physical Temp Table for Product Group-1 ';
				DROP TABLE [psa].[rawint_crp_product_group_temp]
						print 'Successfully dropped Physical Temp Table for Product Group-1';
						
			print 'Dropping Physical Temp Table for Product Group-2';
				DROP TABLE [psa].[rawint_crp_product_group_temp_thai]
						print 'Successfully dropped Physical Temp Table for Product Group-2';

			print 'Dropping Physical Temp Table for Product Group-3';
				DROP TABLE [psa].[rawint_crp_product_group_out]
						print 'Successfully dropped Physical Temp Table for Product Group-3';
						
			print 'Dropping Physical Temp Table for Product Party Role ';
				DROP TABLE [psa].[rawint_crp_product_party_role_temp]
						print 'Successfully dropped Physical Temp Table for Product Party Role';	
						

	END
GO
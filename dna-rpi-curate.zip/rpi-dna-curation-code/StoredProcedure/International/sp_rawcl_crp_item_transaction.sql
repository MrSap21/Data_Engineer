IF OBJECT_ID('psa.sp_rawcl_crp_item_transaction') IS NOT NULL
BEGIN
	DROP PROC psa.sp_rawcl_crp_item_transaction;
END;

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
************************************************************************************************************
Procedure Name			: sp_rawcl_crp_item_transaction
Purpose					: Load History data from Chile transaction source table(rawcl.crp_item_transaction) into Serve Layer Table
Domain					: Transaction
RecordSourceID  for Chile Transaction	: 12001

**************************************************************************************************************
*/

CREATE PROC [psa].[sp_rawcl_crp_item_transaction] (@psaETLRunLogID varchar(max), @serveETLRunLogID bigint, @StartVal bigint, @EndVal bigint) AS
DECLARE @ch_lovRecordSourceID bigint; 
DECLARE @cl_scdLovRecordSourceID bigint; 
DECLARE @psa_rowstatus bigint; 
DECLARE @ser_rowstatus bigint;
DECLARE @max_tillid bigint;
DECLARE @max_siteroleid bigint; 
DECLARE @cl_Siteid bigint; 
DECLARE @cl_RoleId bigint;
DECLARE @max_transactionid bigint; 
DECLARE @cl_trantypeid bigint;
DECLARE @max_productid bigint; 
DECLARE @cl_srckeytypeid bigint;
DECLARE @max_upcproductid bigint; 
DECLARE @cl_upcsrckeytypeid bigint; 
DECLARE @max_dealid bigint;
DECLARE @max_tranlineitemid bigint; 
DECLARE @cl_lineitemtypeid bigint;
DECLARE @max_measureid bigint; 
DECLARE @cl_measuretypeid bigint; 
DECLARE @cl_measuretypeid_unit bigint; 
DECLARE @cl_measuretypeid_tisp bigint; 
DECLARE @cl_measuretypeid_tesp bigint; 
DECLARE @cl_measuretypeid_epos bigint; 
DECLARE @cl_measuretypeid_disc bigint;
DECLARE @cl_intdatatypeid bigint; 
DECLARE @cl_decdatatypeid bigint; 
DECLARE @cl_strdatatypeid bigint;
DECLARE @max_trnlineitemmeasureid bigint; 
DECLARE @cl_unitmeasureid bigint; 
DECLARE @cl_tispmeasureid bigint; 
DECLARE @cl_tespmeasureid bigint; 
DECLARE @cl_eposmeasureid bigint; 
DECLARE @cl_discmeasureid bigint;  
DECLARE @max_loyaltyacctid bigint;
DECLARE @catchup_row bigint;
--DECLARE @serveETLRunLogID bigint;
--DECLARE @StartVal bigint;
--DECLARE @EndVal bigint;

/**********   need to declare the schema    ******************/

BEGIN		

SET @ch_lovRecordSourceID = 12001; 
SET @cl_scdLovRecordSourceID = 151; 
SET @psa_rowstatus = 26001; 
SET @ser_rowstatus = 26002;
--SET @catchup_row = (SELECT COALESCE(MAX(PSARowKey),0) FROM [ser].[TRANSACTIONLINEITEM] where LOVRecordSourceId = @ch_lovRecordSourceID );
--SET @serveETLRunLogID = 12345;
--SET @StartVal = 7;
--SET @EndVal = 8;

BEGIN TRY
	BEGIN TRANSACTION
	
update [psa].[rawcl_crp_item_transaction]
set row_status = 26005
where REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') = '' OR REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0') = '';
	
/* 1.Table Name : Till */

SET @max_tillid = (SELECT COALESCE(MAX(TillId),0) FROM  [ser].[Till]);

INSERT INTO [ser].[Till] (TillId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_tillid + ROW_NUMBER() OVER(ORDER BY A.till_id ASC) TillId, 
		A.till_id SourceKey, 
		@ch_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate,
		--LEFT(A.date_row,CHARINDEX('_',A.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		RIGHT(A.date_row,LEN(A.date_row)-CHARINDEX('_',A.date_row)) PSARowKey
		from 
(SELECT src.till_id, src.date_row from 
(SELECT till_id, record_source_id, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row from [psa].[rawcl_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and till_id IS NOT NULL and till_id != '' GROUP BY till_id,record_source_id)src 
LEFT OUTER JOIN [ser].[Till] slf on src.till_id = slf.sourcekey and src.record_source_id = slf.LOVRecordSourceId 
where slf.sourcekey IS NULL )A ;

RAISERROR ('Completed insertion of CHILE source data to TILL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 2.Table Name : Site */
/*
DECLARE @max_siteid bigint; DECLARE @cl_SitetypeId bigint;
SET @max_siteid = (SELECT COALESCE(MAX(SiteId),0) FROM  [ser].[Site]);
SET @cl_SitetypeId = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = '0' and rlovset.LOVsetname = 'Site Type');

INSERT INTO [ser].[Site] (SiteId, SourceKey, SiteName, LOVSiteTypeId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId) 
SELECT	@max_siteid + ROW_NUMBER() OVER(ORDER BY store_number ASC) , 
		0 , 
		'UNKNOWN' , 
		ISNULL(@cl_SitetypeId,159000003) ,    
		12012 , 
		'1900-01-01' , 
		'9999-12-31' , 
		'Y' , 
		'1' ,  
		@cl_scdLovRecordSourceID , 
		@serveETLRunLogID  
		from [psa].[rawcl_crp_item_transaction] GROUP BY store_number ;

PRINT 'Info: Site Table Loaded Successfully';
*/
/*************************************************************************************************************************************************************/

/* 3.Table Name : Site_Role */

SET @max_siteroleid = (SELECT COALESCE(MAX(SiteRoleId),0) FROM  [ser].[SiteRole]);
SET @cl_SiteId = (SELECT siteid from [ser].[site] site where site.LOVRecordSourceId = '12012' and site.LOVSiteTypeId IN (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = '0' and rlovset.LOVsetname = 'Site Type'));
SET @cl_RoleId = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Store' and rlovset.LOVsetname = 'Role');


INSERT INTO [ser].[Siterole] (SiteRoleId, SiteId, LOVRoleId, SourceKey, SiteRoleName, SiteRoleShortName, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_siteroleid + ROW_NUMBER() OVER(ORDER BY A.sourcekey ASC) SiteRoleId, 
		@cl_SiteId SiteId,    /*temporary hard-coding the value as the desired lookup is not there*/
		@cl_RoleId LOVRoleId, 
		A.sourcekey SourceKey, 
		NULL SiteRoleName, 
		NULL SiteRoleShortName, 
		@ch_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate,
		--LEFT(A.date_row,CHARINDEX('_',A.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion,  
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		RIGHT(A.date_row,LEN(A.date_row)-CHARINDEX('_',A.date_row)) PSARowKey
		from 
(SELECT src.sourcekey, src.date_row from 
(SELECT REPLACE(LTRIM(REPLACE(store_number,'0',' ')),' ','0') sourcekey, record_source_id, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row 
from [psa].[rawcl_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and store_number IS NOT NULL and store_number != '' GROUP BY REPLACE(LTRIM(REPLACE(store_number,'0',' ')),' ','0'),record_source_id)src
LEFT OUTER JOIN [ser].[Siterole] slf on src.sourcekey = slf.sourcekey 
and src.record_source_id = slf.LOVRecordSourceId where slf.sourcekey IS NULL)A ;

RAISERROR ('Completed insertion of CHILE source data to SITEROLE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 4.Table Name : Transaction */

SET @max_transactionid = (SELECT COALESCE(MAX(TransactionId),0) FROM  [ser].[Transaction]);
SET @cl_trantypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Retail' and rlovset.LOVsetname = 'Transaction Type'); 


INSERT INTO [ser].[Transaction]
(TransactionId, SourceKey, LOVTransactionTypeId, SiteRoleId, TransactionDatetime, TillId, TillTransactionNumber, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_transactionid + ROW_NUMBER() OVER(ORDER BY trnx.transaction_key ASC) TransactionId, 
		trnx.transaction_key SourceKey, 
		@cl_trantypeid LOVTransactionTypeId, 
		trnx.SiteRoleId SiteRoleId, 
		CAST (CONCAT(trnx.transaction_date,' ',trnx.transaction_time) as Datetime) TransactionDatetime, 
		trnx.tillId TillId, 
		null TillTransactionNumber, 
		@ch_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate,
		--trnx.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		trnx.row_num PSARowKey from 
(SELECT P.transaction_key,P.siteroleid, P.transaction_date, P.transaction_time,P.tillid, P.record_source_id, P.startdate, P.row_num from
(SELECT src.transaction_key,B.siteroleid, src.transaction_date, src.transaction_time,till.tillid, src.record_source_id, LEFT(src.date_row,CHARINDEX('_',src.date_row)-1) startdate, RIGHT(src.date_row,LEN(src.date_row)-CHARINDEX('_',src.date_row)) row_num from 
(SELECT transaction_key, store_number, transaction_date, transaction_time, till_id,record_source_id, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row  from [psa].[rawcl_crp_item_transaction]  where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY transaction_key, store_number, till_id, transaction_date, transaction_time,record_source_id) src 
JOIN (SELECT SiteRoleId, sourcekey from [ser].[Siterole] where lovrecordsourceid = 12001 and SCDActiveFlag = 'Y')B on B.sourcekey = REPLACE(LTRIM(REPLACE(src.store_number,'0',' ')),' ','0')
JOIN (SELECT * from [ser].[Till] where lovrecordsourceid = 12001 and SCDActiveFlag = 'Y') till on src.till_id = till.sourcekey where till.lovrecordsourceid = 12001) P
LEFT OUTER JOIN [ser].[Transaction] T on P.transaction_key = T.sourcekey and CAST (CONCAT(P.transaction_date,' ',P.transaction_time) as Datetime) = T.TransactionDatetime and P.record_source_id = T.LOVRecordSourceId where T.sourcekey IS NULL )trnx ;


RAISERROR ('Completed insertion of CHILE source data to TRANSACTION table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 5.Table Name : Product(Parent) */

SET @max_productid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @cl_srckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Chile Item Code' and rlovset.LOVsetname = 'Source Key Type'); 

INSERT INTO [ser].[Product] (ProductId, SourceKey, LOVSourceKeyTypeId, ProductName, ProductDescription, LOVBrandId, LOVSubBrandId, LOVRecordSourceId, ParentProductId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_productid + ROW_NUMBER() OVER(ORDER BY A.SourceKey ASC) ProductId, 
		A.SourceKey SourceKey, 
		@cl_srckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		/*null LOVCostCentreId, */
		@ch_lovRecordSourceID LOVRecordSourceId,
		null ParentProductId,
		'1900-01-01' SCDStartDate,
		--LEFT(A.date_row,CHARINDEX('_',A.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		RIGHT(A.date_row,LEN(A.date_row)-CHARINDEX('_',A.date_row)) PSARowKey from
(SELECT src.sourcekey, src.date_row from 
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') SourceKey, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row, record_source_id from [psa].[rawcl_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), record_source_id) src 
LEFT OUTER JOIN [ser].[Product] P on src.sourcekey = P.sourcekey and src.record_source_id = P.LOVRecordSourceId and P.LOVSourceKeyTypeId = @cl_srckeytypeid
where P.sourcekey IS NULL and src.sourcekey IS NOT NULL and src.sourcekey != '') A
;


RAISERROR ('Completed insertion of CHILE source data to PRODUCT(parent) table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 6.Table Name : Product(Child) */

SET @max_upcproductid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @cl_upcsrckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'UPC' and 				rlovset.LOVsetname = 'Source Key Type'); 
SET @cl_srckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Chile Item Code' and rlovset.LOVsetname = 'Source Key Type');


INSERT INTO [ser].[Product] (ProductId, SourceKey, LOVSourceKeyTypeId, ProductName, ProductDescription, LOVBrandId, LOVSubBrandId, LOVRecordSourceId, ParentProductId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_upcproductid + ROW_NUMBER() OVER(ORDER BY prod.upc ASC) ProductId, 
		prod.upc SourceKey, 
		@cl_upcsrckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		/*null LOVCostCentreId, */
		@ch_lovRecordSourceID LOVRecordSourceId,
		prod.ProductId ParentProductId,
		'1900-01-01' SCDStartDate,
		--LEFT(prod.date_row,CHARINDEX('_',prod.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		RIGHT(prod.date_row,LEN(prod.date_row)-CHARINDEX('_',prod.date_row)) PSARowKey from
(SELECT T.upc, T.date_row, T.parent, T.ProductId from 
(
/* -- The first block of union is to accomodate those transaction records where both item_code and upc have meaningful values and upc is not null/blank -- */
SELECT par.upc ,par.date_row, par.record_source_id, par.item parent, cld.ProductId from
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') item, REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0') upc, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row , record_source_id from [psa].[rawcl_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0'), record_source_id) par
JOIN [ser].[product] cld on par.item = cld.sourcekey and cld.lovrecordsourceid = 12001 and cld.LOVSourceKeyTypeId = @cl_srckeytypeid and cld.SCDActiveFlag = 'Y'
--UNION
/* -- The second block of union is to accomodate those transaction records where upc has meaningful value and item_code is all zeroes -- */
/*SELECT par.upc ,par.date_row, par.record_source_id, par.item parent, null ProductId from
(SELECT REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') item, REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0') upc, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row , record_source_id from [psa].[rawcl_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and (REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') = '' OR item_code is null) and upc != '' and upc IS NOT NULL
GROUP BY REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0'), REPLACE(LTRIM(REPLACE(upc,'0',' ')),' ','0'), record_source_id) par
*/
) T
LEFT OUTER JOIN [ser].[product] P on T.upc = P.sourcekey and T.ProductId = P.ParentProductId and T.record_source_id = P.LOVRecordSourceId where P.sourcekey IS NULL and T.upc != '' and T.upc IS NOT NULL) prod;

RAISERROR ('Completed insertion of CHILE source data to PRODUCT(child) table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 7.Table Name : Deal */

SET @max_dealid = (SELECT COALESCE(MAX(DealId),0) FROM  [ser].[Deal]);

INSERT INTO [ser].[Deal] (DealId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_dealid + ROW_NUMBER() OVER(ORDER BY src.deal_id ASC) DealId,
		src.deal_id SourceKey,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--LEFT(src.date_row,CHARINDEX('_',src.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		RIGHT(src.date_row,LEN(src.date_row)-CHARINDEX('_',src.date_row)) PSARowKey from 
(SELECT T.deal_id, T.date_row from 
(SELECT deal_id, record_source_id, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row from [psa].[rawcl_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and deal_id != '' and deal_id IS NOT NULL GROUP BY deal_id, record_source_id)T 
LEFT OUTER JOIN [ser].[Deal] D on T.deal_id = D.sourcekey and T.record_source_id = D.LOVRecordSourceId where D.sourcekey IS NULL) src ;

RAISERROR ('Completed insertion of CHILE source data to DEAL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 8.Table Name : Transaction Line Item */

SET @max_tranlineitemid = (SELECT COALESCE(MAX(TransactionLineItemId),0) FROM  [ser].[TransactionLineItem]);
SET @cl_upcsrckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'UPC' and 	rlovset.LOVsetname = 'Source Key Type'); 
SET @cl_srckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Chile Item Code' and rlovset.LOVsetname = 'Source Key Type');


INSERT INTO [ser].[TransactionLineItem] (TransactionLineItemId, TransactionId, ProductId, LOVLineItemTypeId, DealId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_tranlineitemid + ROW_NUMBER() OVER(ORDER BY final.sourcekey ASC) TransactionLineItemId,
		final.transactionid TransactionId,
		final.productid ProductId,
		final.lovid LOVLineItemTypeId,    
		final.deal_id DealId,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--final.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(SELECT trnx.transactionid, trnx.sourcekey, A.productid ProductId, B.lovid, D.dealid deal_id, ISNULL(a.date_added,'1900-01-01') startdate, A.row_id row_num from [ser].[Transaction] trnx 
JOIN (
/* -- The first block of union is to accomodate those transaction records where both item_code and upc have meaningful values and upc is not null/blank -- */
SELECT ISNULL(src.date_added,'1900-01-01') date_added, src.upc item_upc, prd_ch.productId,src.transaction_key, src.sales_type, src.deal_id, src.row_id, CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) dt_tm from
(SELECT * from [psa].[rawcl_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src
JOIN [ser].[product] prd_ch on prd_ch.sourcekey = REPLACE(LTRIM(REPLACE(src.upc,'0',' ')),' ','0') and prd_ch.lovsourcekeytypeid = @cl_upcsrckeytypeid 
and prd_ch.ParentProductId in (select ProductId from ser.product where sourcekey = REPLACE(LTRIM(REPLACE(src.item_code,'0',' ')),' ','0') ) 
where src.upc IS NOT NULL and REPLACE(LTRIM(REPLACE(src.upc,'0',' ')),' ','0') != '' and prd_ch.SCDActiveFlag = 'Y'
--UNION 
/* -- The second block of union is to accomodate those transaction records where item_code has meaningful value and upc is null/blank -- */
/*SELECT ISNULL(src.date_added,'1900-01-01') date_added, src.item_code item_upc, prd_pa.productId,src.transaction_key, src.sales_type, src.deal_id,src.row_id, CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) dt_tm from
(SELECT * from [psa].[rawcl_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src
JOIN [ser].[product] prd_pa on prd_pa.sourcekey = REPLACE(LTRIM(REPLACE(src.item_code,'0',' ')),' ','0')  and prd_pa.lovsourcekeytypeid = @cl_srckeytypeid where (src.upc IS NULL or REPLACE(LTRIM(REPLACE(src.upc,'0',' ')),' ','0')='') and prd_pa.SCDActiveFlag = 'Y'
UNION */
/* -- The third block of union is to accomodate those transaction records where upc has meaningful value and item_code is all zeroes -- */
/*SELECT ISNULL(src.date_added,'1900-01-01') date_added, src.item_code item_upc, prd_00.productId,src.transaction_key, src.sales_type, src.deal_id,src.row_id, 
CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) dt_tm from
(SELECT * from [psa].[rawcl_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal 
and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
and (REPLACE(LTRIM(REPLACE(item_code,'0',' ')),' ','0') = '' OR item_code is null)) src
JOIN [ser].[product] prd_00 on prd_00.sourcekey = REPLACE(LTRIM(REPLACE(src.upc,'0',' ')),' ','0') and prd_00.ParentProductId is NULL and prd_00.lovsourcekeytypeid = @cl_upcsrckeytypeid
where src.upc IS NOT NULL and REPLACE(LTRIM(REPLACE(src.upc,'0',' ')),' ','0') != '' and 
prd_00.SCDActiveFlag = 'Y'
*/
)A on trnx.sourcekey = A.transaction_key and trnx.lovrecordsourceid = @ch_lovRecordSourceID and A.dt_tm = trnx.TransactionDatetime
LEFT OUTER JOIN (SELECT rlov.lovid, rlov.lovkey from [ser].[Reflov] rlov
JOIN [ser].[Reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.lovsetrecordsourceid = @ch_lovRecordSourceID and rlovset.lovsetname='sales_type')B on B.lovkey = A.sales_type
LEFT OUTER JOIN [ser].[Deal] D on D.sourcekey = A.deal_id and D.LOVRecordSourceId = @ch_lovRecordSourceID and D.SCDActiveFlag = 'Y'
) final;


RAISERROR ('Completed insertion of CHILE source data to TRANSACTIONLINEITEM table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 9.Table Name : Measure */

SET @max_measureid = (SELECT COALESCE(MAX(MeasureId),0) FROM  [ser].[Measure]);
SET @cl_measuretypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 			'RETAIL_TRANS_AGG' and rlovset.LOVsetname = 'Measure Type');
SET @cl_measuretypeid_unit = @max_measureid + 1; SET @cl_measuretypeid_tisp = @max_measureid + 2; SET @cl_measuretypeid_tesp = @max_measureid + 3;
SET @cl_measuretypeid_epos = @max_measureid + 4; SET @cl_measuretypeid_disc = @max_measureid + 5;

SET @cl_intdatatypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVName = 					'INTEGER' and rlovset.LOVsetname = 'Data Type');
SET @cl_decdatatypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 					'DECIMAL' and rlovset.LOVsetname = 'Data Type');
SET @cl_strdatatypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 					'STRING' and rlovset.LOVsetname = 'Data Type');

INSERT INTO [ser].[Measure] (MeasureId, LOVMeasureTypeId, LOVDataTypeId, MeasureName, MeasureDescription, [Length], [Precision], Scale, StandardMeasureId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId) 

SELECT  A.MeasureId MeasureId,
		A.LOVMeasureTypeId LOVMeasureTypeId,
		A.LOVDataTypeId LOVDataTypeId,
		A.MeasureName MeasureName,
		A.MeasureDescription MeasureDescription,
		A.[length] [Length],
		A.[Precision] [Precision],
		A.Scale Scale,
		A.StandardMeasureId StandardMeasureId,
		A.LOVRecordSourceId LOVRecordSourceId,
		A.SCDStartDate SCDStartDate,
		A.SCDEndDate SCDEndDate,
		A.SCDActiveFlag SCDActiveFlag,
		A.SCDVersion SCDVersion,
		A.SCDLOVRecordSourceId SCDLOVRecordSourceId,
		A.ETLRunLogId ETLRunLogId from 
(		
SELECT	TOP 1
		@cl_measuretypeid_unit MeasureId,
		@cl_measuretypeid LOVMeasureTypeId, 
		@cl_intdatatypeid LOVDataTypeId, 
		'units' MeasureName, 
		'The number of units of item sold in the transaction ' MeasureDescription,
		null [Length],
		null [Precision],
		null Scale,
		null StandardMeasureId ,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'units' = M.MeasureName and @cl_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @ch_lovRecordSourceID
	
UNION	
	 
SELECT	TOP 1
		@cl_measuretypeid_tisp MeasureId,
		@cl_measuretypeid LOVMeasureTypeId, 
		@cl_decdatatypeid LOVDataTypeId, 
		'tisp' MeasureName, 
		'Tax inclusive selling price (price paid by customer) ' MeasureDescription,
		null [Length],
		10 [Precision],
		2 Scale,
		null StandardMeasureId ,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'tisp' = M.MeasureName and @cl_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @ch_lovRecordSourceID
	
UNION
	
SELECT	TOP 1
		@cl_measuretypeid_tesp MeasureId,
		@cl_measuretypeid LOVMeasureTypeId, 
		@cl_decdatatypeid LOVDataTypeId, 
		'tesp' MeasureName, 
		'Tax exclusive selling price ' MeasureDescription,
		null [Length],
		10 [Precision],
		2 Scale,
		null StandardMeasureId ,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'tesp' = M.MeasureName and @cl_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @ch_lovRecordSourceID
	 
UNION

SELECT	TOP 1
		@cl_measuretypeid_epos MeasureId,
		@cl_measuretypeid LOVMeasureTypeId, 
		@cl_decdatatypeid LOVDataTypeId, 
		'epos_profit' MeasureName, 
		'This should be reflective of the true profitability of each product  (EPOS profit = TISP - Cost)' MeasureDescription,
		null [Length],
		10 [Precision],
		2 Scale,
		null StandardMeasureId ,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'epos_profit' = M.MeasureName and @cl_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @ch_lovRecordSourceID
	 
UNION

SELECT	TOP 1
		@cl_measuretypeid_disc MeasureId,
		@cl_measuretypeid LOVMeasureTypeId, 
		@cl_strdatatypeid LOVDataTypeId, 
		'discount_applied' MeasureName, 
		'The total discount the customer received (through promotions, staff discount etc) on the items in the transaction.  I.e.. it is the difference between the shelf edge price and the amount the customer actually paid.' MeasureDescription,
		null [Length],
		null [Precision],
		null Scale,
		null StandardMeasureId ,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'discount_applied' = M.MeasureName and @cl_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @ch_lovRecordSourceID

)A;
	 
RAISERROR ('Completed insertion of CHILE source data to MEASURE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 10.Table Name : Transaction Line Item Measure */

SET @max_trnlineitemmeasureid = (SELECT COALESCE(MAX(TransactionLineItemMeasureId),0) FROM  [ser].[TransactionLineItemMeasure]);
SET @cl_measuretypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 			'RETAIL_TRANS_AGG' and rlovset.LOVsetname = 'Measure Type');
SET @cl_unitmeasureid = (SELECT MAX(MeasureId) from [ser].[Measure] msr where msr.measurename = 'units' and msr.LOVMeasureTypeId = @cl_measuretypeid and msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @cl_tispmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'tisp' and msr.LOVMeasureTypeId = @cl_measuretypeid and msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @cl_tespmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'tesp' and msr.LOVMeasureTypeId = @cl_measuretypeid and msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @cl_eposmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'epos_profit' and msr.LOVMeasureTypeId = @cl_measuretypeid and 	msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @cl_discmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'discount_applied' and msr.LOVMeasureTypeId = @cl_measuretypeid and 	msr.LOVRecordSourceId = @ch_lovRecordSourceID GROUP BY LOVMeasureTypeId);

INSERT INTO [ser].[TransactionLineItemMeasure] (TransactionLineItemMeasureId, TransactionLineItemId, MeasureId, Value, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	@max_trnlineitemmeasureid + DENSE_RANK() OVER(ORDER BY final.TransactionLineItemId, final.MeasureId) TransactionLineItemMeasureId,
		final.TransactionLineItemId TransactionLineItemId,
		final.MeasureId MeasureId,
		final.Value Value,
		final.LOVRecordSourceId LOVRecordSourceId,
		final.SCDStartDate SCDStartDate,
		final.SCDEndDate SCDEndDate,
		final.SCDActiveFlag SCDActiveFlag,
		final.SCDVersion SCDVersion,
		final.SCDLOVRecordSourceId SCDLOVRecordSourceId,
		final.ETLRunLogId ETLRunLogId,
		final.PSARowKey PSARowKey from
(	
SELECT	A.TransactionLineItemId TransactionLineItemId,
		@cl_unitmeasureid MeasureId,
		A.units [Value],
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--A.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		A.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.units , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawcl_crp_item_transaction] src on trln.psarowkey = src.row_id and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) A

UNION

SELECT  B.TransactionLineItemId TransactionLineItemId,
		@cl_tispmeasureid MeasureId,
		B.tisp [Value],
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--B.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		B.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.tisp , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawcl_crp_item_transaction] src on trln.psarowkey = src.row_id and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))  ) B

UNION

SELECT  C.TransactionLineItemId TransactionLineItemId,
		@cl_tespmeasureid MeasureId,
		C.tesp Value,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--C.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		C.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.tesp , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawcl_crp_item_transaction] src on trln.psarowkey = src.row_id  and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))  ) C

UNION

SELECT  D.TransactionLineItemId TransactionLineItemId,
		@cl_eposmeasureid MeasureId,
		D.epos_profit Value,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--D.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		D.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.epos_profit , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawcl_crp_item_transaction] src on trln.psarowkey = src.row_id  and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))  ) D

UNION

SELECT  E.TransactionLineItemId TransactionLineItemId,
		@cl_discmeasureid MeasureId,
		E.discount_applied Value,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--E.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		E.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.discount_applied , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawcl_crp_item_transaction] src on trln.psarowkey = src.row_id  and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))  ) E

)final;

RAISERROR ('Completed insertion of CHILE source data to TRANSACTIONLINEITEMMEASURE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 11.Table Name : Loyalty Account */

SET @max_loyaltyacctid = (SELECT COALESCE(MAX(LoyaltyAccountId),0) FROM  [ser].[LoyaltyAccount]);

 INSERT INTO [ser].[LoyaltyAccount] (LoyaltyAccountId,LOVLoyaltyProgramId,SourceKey,LOVRecordSourceId,SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	@max_loyaltyacctid + ROW_NUMBER() OVER(ORDER BY final.lovid, final.SourceKey ASC) LoyaltyAccountId, 
		final.lovid LOVLoyaltyProgramId,
		final.SourceKey SourceKey,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--final.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
SELECT M.lovid, M.sourcekey, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from 
(SELECT rlov.lovid lovid, B.customer_identifier sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'customer_identifier_type' and LOVSetRecordSourceId = 12001
JOIN 
(SELECT (CASE WHEN (trim(A.customer_identifier_type) = '' OR A.customer_identifier_type IS NULL OR A.customer_identifier_type = 'NULL') THEN 'Unknown'
ELSE A.customer_identifier_type END) lovkey, A.customer_identifier, A.date_row, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_identifier_type, src.customer_identifier, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row,src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawcl_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12001 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.customer_identifier IS NOT NULL and TRIM(B.customer_identifier) != '' GROUP BY rlov.lovid, B.customer_identifier,B.record_source_id) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T on M.lovid=T.LOVLoyaltyProgramId and M.SourceKey=T.SourceKey and M.record_source_id=T.LOVRecordSourceId where LOVLoyaltyProgramId IS NULL

UNION

SELECT M.lovid, M.sourcekey, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from 
(SELECT rlov.lovid lovid, B.customer_number sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'customer_number_type' and LOVSetRecordSourceId = 12001
JOIN 
(SELECT (CASE WHEN (trim(A.customer_number_type) = '' OR A.customer_number_type IS NULL OR A.customer_number_type = 'NULL') THEN 'Unknown'
ELSE A.customer_number_type END) lovkey, A.customer_number, A.date_row, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_number_type, src.customer_number, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row,src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawcl_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12001 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.customer_number IS NOT NULL and TRIM(B.customer_number) != '' GROUP BY rlov.lovid, B.customer_number,B.record_source_id) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T on M.lovid=T.LOVLoyaltyProgramId and M.SourceKey=T.SourceKey and M.record_source_id=T.LOVRecordSourceId where LOVLoyaltyProgramId IS NULL

UNION

SELECT M.lovid, M.sourcekey, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from 
(SELECT rlov.lovid lovid, B.other_customer_id sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'other_customer_id_type' and LOVSetRecordSourceId = 12001
JOIN 
(SELECT (CASE WHEN (trim(A.other_customer_id_type) = '' OR A.other_customer_id_type IS NULL OR A.other_customer_id_type = 'NULL') THEN 'Unknown'
ELSE A.other_customer_id_type END) lovkey, A.other_customer_id, A.date_row, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.other_customer_id_type, src.other_customer_id, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row,src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawcl_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12001 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.other_customer_id IS NOT NULL and TRIM(B.other_customer_id) != '' GROUP BY rlov.lovid, B.other_customer_id,B.record_source_id) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T on M.lovid=T.LOVLoyaltyProgramId and M.SourceKey=T.SourceKey and M.record_source_id=T.LOVRecordSourceId where LOVLoyaltyProgramId IS NULL

) final;

RAISERROR ('Completed insertion of CHILE source data to LOYALTYACCOUNT table', 0, 1) WITH NOWAIT;


/*************************************************************************************************************************************************************/

/* 12.Table Name : TransactionLoyaltyAccount */

INSERT INTO [ser].[TransactionLoyaltyAccount] (TransactionId, LoyaltyAccountId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	final.TransactionId TransactionId, 
		final.loyaltyaccountid LoyaltyAccountId,
		@ch_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--final.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@cl_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.startdate, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from [ser].[LoyaltyAccount] LA 
JOIN (SELECT B.TransactionId, rlov.lovid lovid, B.customer_identifier sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'customer_identifier_type' and LOVSetRecordSourceId = 12001
JOIN 
(SELECT (CASE WHEN (trim(A.customer_identifier_type) = '' OR A.customer_identifier_type IS NULL OR A.customer_identifier_type = 'NULL') THEN 'Unknown'
ELSE A.customer_identifier_type END) lovkey, A.customer_identifier, A.date_row,A.TransactionId, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_identifier_type, src.customer_identifier, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row, src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawcl_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12001 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.customer_identifier IS NOT NULL and TRIM(B.customer_identifier) != '' GROUP BY B.TransactionId, rlov.lovid, B.customer_identifier,B.record_source_id)M 
on LA.LOVLoyaltyProgramId = M.lovid and LA.sourcekey = M.sourcekey and LA.SCDActiveFlag = 'Y') P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

UNION

SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.startdate, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from [ser].[LoyaltyAccount] LA 
JOIN (SELECT B.TransactionId, rlov.lovid lovid, B.customer_number sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'customer_number_type' and LOVSetRecordSourceId = 12001
JOIN 
(SELECT (CASE WHEN (trim(A.customer_number_type) = '' OR A.customer_number_type IS NULL OR A.customer_number_type = 'NULL') THEN 'Unknown'
ELSE A.customer_number_type END) lovkey, A.customer_number, A.date_row,A.TransactionId, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_number_type, src.customer_number, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row, src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawcl_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12001 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.customer_number IS NOT NULL and TRIM(B.customer_number) != '' GROUP BY B.TransactionId, rlov.lovid, B.customer_number,B.record_source_id)M 
on LA.LOVLoyaltyProgramId = M.lovid and LA.sourcekey = M.sourcekey and LA.SCDActiveFlag = 'Y') P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

UNION

SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.startdate, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from [ser].[LoyaltyAccount] LA 
JOIN (SELECT B.TransactionId, rlov.lovid lovid, B.other_customer_id sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'other_customer_id_type' and LOVSetRecordSourceId = 12001
JOIN 
(SELECT (CASE WHEN (trim(A.other_customer_id_type) = '' OR A.other_customer_id_type IS NULL OR A.other_customer_id_type = 'NULL')  THEN 'Unknown'
ELSE A.other_customer_id_type END) lovkey, A.other_customer_id, A.date_row,A.TransactionId, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.other_customer_id_type, src.other_customer_id, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row, src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawcl_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12001 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.other_customer_id IS NOT NULL and TRIM(B.other_customer_id) != '' GROUP BY B.TransactionId, rlov.lovid, B.other_customer_id,B.record_source_id)M 
on LA.LOVLoyaltyProgramId = M.lovid and LA.sourcekey = M.sourcekey and LA.SCDActiveFlag = 'Y') P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

)final;

RAISERROR ('Completed insertion of CHILE source data to TRANSACTIONLOYALTYACCOUNT table', 0, 1) WITH NOWAIT;


/*************************************************************************************************************************************************************/

/* 13.Table Name : psa.rawcl_crp_item_transaction */
/* Update the row_status in the psa.rawcl_crp_item_transaction from 26001(PSA) to 26002(SERVE) */

UPDATE [psa].[rawcl_crp_item_transaction]
SET row_status = @ser_rowstatus
where row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and row_status = @psa_rowstatus;

/*************************************************************************************************************************************************************/

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
DECLARE @error_num varchar(max),
		@error_msg varchar(max),
		@error_sev varchar(max)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

END;
GO
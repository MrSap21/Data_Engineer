SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.SP_MERCHANDISING_CURATION_FACT_DIM_MEASURE_CHILE_HISTORY') IS NOT NULL
BEGIN
    DROP PROC [psa].[SP_MERCHANDISING_CURATION_FACT_DIM_MEASURE_CHILE_HISTORY]
END
GO

CREATE PROCEDURE [psa].[SP_MERCHANDISING_CURATION_FACT_DIM_MEASURE_CHILE_HISTORY] 
AS 
/*
************************************************************************************************************
Procedure Name				: SP_MERCHANDISING_CURATION_FACT_DIM_MEASURE_CHILE_HISTORY
Purpose						: Load History data From International Chile 
Domain						: Merchandise
ServeLayer Target Tables	: Fact, Measure, Dimension, FactMeasure, FactDimension
RecordSourceID  for International Chile : 12001
*****************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
 */ 
BEGIN

BEGIN TRANSACTION;

	/*--Declarations---*/
	DECLARE @max_MeasureId BIGINT;
	DECLARE @max_FactId BIGINT;
	DECLARE @max_DimensionId BIGINT;
	DECLARE @serveETLRunLogID BIGINT;
	
	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_MeasureId = COALESCE(MAX(MeasureId),0) FROM [ser].[Measure];
	SELECT @max_FactId = COALESCE(MAX(FactId),0) FROM [ser].[Fact];
	SELECT @max_DimensionId = COALESCE(MAX(DimensionId),0) FROM [ser].[Dimension];
	SET @serveETLRunLogID = NULL;
	
	BEGIN TRY


	/*--------------------------------Loading Measure table---------------------------------*/
	
	DECLARE @cl_measuretypeid_agg BIGINT;
	DECLARE @cl_measuretypeid_dim BIGINT;
	
	SET @cl_measuretypeid_agg = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'PLANOGRAM_AGGREGATION' and rlovset.LOVsetname = 'Measure Type');
	SET @cl_measuretypeid_dim = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'PLANOGRAM_DIM' and rlovset.LOVsetname = 'Measure Type');
	
	
	INSERT INTO [ser].[measure]
	(
	[MeasureId]
	,[LOVMeasureTypeId]
	,[LOVDataTypeId]
	,[MeasureName]
	,[MeasureDescription]
	,[Length]
	,[Precision]
	,[Scale]
	,[StandardMeasureId]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	)
		SELECT
		@max_MeasureId + (dense_rank() over (order by MeasureName,LOVMeasureTypeId asc)) AS [MeasureId]
		,[LOVMeasureTypeId]
		,[LOVDataTypeId]
		,[MeasureName]
		,[MeasureDescription]
		,[Length]
		,[Precision]
		,[Scale]
		,[StandardMeasureId]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		FROM
		(
			SELECT TOP 1
			@cl_measuretypeid_dim AS [LOVMeasureTypeId]
			,
			(
				SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Data Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'DECIMAL'
			) AS [LOVDataTypeId]
			,'shelf_depth' AS [MeasureName]
			,'The standard shelf depth for the planogram  in cm' AS [MeasureDescription]
			,NULL AS [Length]
			,8 AS [Precision]
			,2 AS [Scale]
			,NULL AS [StandardMeasureId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'shelf_depth' = M.MeasureName and @cl_measuretypeid_dim = M.LOVMeasureTypeId and M.LOVRecordSourceId = 12001 where M.MeasureName IS NULL 
		
			UNION
		
			SELECT TOP 1
			@cl_measuretypeid_dim AS [LOVMeasureTypeId]
			,
			(
				SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Data Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'DECIMAL'
			) AS [LOVDataTypeId]
			,'height' AS [MeasureName]
			,'Shelf Height in cm' AS [MeasureDescription]
			,NULL AS [Length]
			,8 AS [Precision]
			,2 AS [Scale]
			,NULL AS [StandardMeasureId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'height' = M.MeasureName and @cl_measuretypeid_dim = M.LOVMeasureTypeId and M.LOVRecordSourceId = 12001 where M.MeasureName IS NULL 
			
			UNION
			
			SELECT TOP 1
			@cl_measuretypeid_dim AS [LOVMeasureTypeId]
			,
			(
				SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Data Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'STRING'
			) AS [LOVDataTypeId]
			,'build_size' AS [MeasureName]
			,'The shelving units in store are modular, so when they design a planogram, it will be made up of a number of shelving units. They refer to this as the build size.E.g. A 3 mod planogram will be 3 shelves wide.' AS [MeasureDescription]
			,NULL AS [Length]
			,NULL AS [Precision]
			,NULL AS [Scale]
			,NULL AS [StandardMeasureId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'build_size' = M.MeasureName and @cl_measuretypeid_dim = M.LOVMeasureTypeId and M.LOVRecordSourceId = 12001 where M.MeasureName IS NULL 
			
			UNION
			
			SELECT TOP 1
			@cl_measuretypeid_agg AS [LOVMeasureTypeId]
			,
			(
				SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Data Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'INT'
			) AS [LOVDataTypeId]
			,'facings' AS [MeasureName]
			,'Item facings for the planogram item' AS [MeasureDescription]
			,NULL AS [Length]
			,NULL AS [Precision]
			,NULL AS [Scale]
			,NULL AS [StandardMeasureId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'facings' = M.MeasureName and @cl_measuretypeid_agg = M.LOVMeasureTypeId and M.LOVRecordSourceId = 12001 where M.MeasureName IS NULL 
			
			UNION
			
			SELECT TOP 1
			@cl_measuretypeid_agg AS [LOVMeasureTypeId]
			,
			(
				SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Data Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'INT'
			) AS [LOVDataTypeId]
			,'units' AS [MeasureName]
			,'The number of units sold of  an item as part of  a transaction totalled for the planogram for that week' AS [MeasureDescription]
			,NULL AS [Length]
			,NULL AS [Precision]
			,NULL AS [Scale]
			,NULL AS [StandardMeasureId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'units' = M.MeasureName and @cl_measuretypeid_agg = M.LOVMeasureTypeId and M.LOVRecordSourceId = 12001 where M.MeasureName IS NULL 
			
			UNION
			
			SELECT TOP 1
			@cl_measuretypeid_agg AS [LOVMeasureTypeId]
			,
			(
				SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Data Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'DECIMAL'
			) AS [LOVDataTypeId]
			,'tesp' AS [MeasureName]
			,'Tax exclusive selling price total for all the items on the planogram for that week' AS [MeasureDescription]
			,NULL AS [Length]
			,10 AS [Precision]
			,2 AS [Scale]
			,NULL AS [StandardMeasureId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'tesp' = M.MeasureName and @cl_measuretypeid_agg = M.LOVMeasureTypeId and M.LOVRecordSourceId = 12001 where M.MeasureName IS NULL 
			
			UNION
			
			SELECT TOP 1
			@cl_measuretypeid_agg AS [LOVMeasureTypeId]
			,
			(
				SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Data Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'DECIMAL'
			) AS [LOVDataTypeId]
			,'tisp' AS [MeasureName]
			,'Tax inclusive selling price total for all the items on the planogram for that week (For viewer reporting)' AS [MeasureDescription]
			,NULL AS [Length]
			,10 AS [Precision]
			,2 AS [Scale]
			,NULL AS [StandardMeasureId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'tisp' = M.MeasureName and @cl_measuretypeid_agg = M.LOVMeasureTypeId and M.LOVRecordSourceId = 12001 where M.MeasureName IS NULL
			
			UNION
			
			SELECT TOP 1
			@cl_measuretypeid_agg AS [LOVMeasureTypeId]
			,
			(
				SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Data Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'DECIMAL'
			) AS [LOVDataTypeId]
			,'epos_profit' AS [MeasureName]
			,'EPOS profit For the planogram for that week in that store – cash not a % ' AS [MeasureDescription]
			,NULL AS [Length]
			,10 AS [Precision]
			,2 AS [Scale]
			,NULL AS [StandardMeasureId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'epos_profit' = M.MeasureName and @cl_measuretypeid_agg = M.LOVMeasureTypeId and M.LOVRecordSourceId = 12001 where M.MeasureName IS NULL
			
			UNION
			
			SELECT TOP 1
			@cl_measuretypeid_agg AS [LOVMeasureTypeId]
			,
			(
				SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Data Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'DECIMAL'
			) AS [LOVDataTypeId]
			,'modular_space' AS [MeasureName]
			,'size of the planogram in store.' AS [MeasureDescription]
			,NULL AS [Length]
			,10 AS [Precision]
			,2 AS [Scale]
			,NULL AS [StandardMeasureId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'modular_space' = M.MeasureName and @cl_measuretypeid_agg = M.LOVMeasureTypeId and M.LOVRecordSourceId = 12001 where M.MeasureName IS NULL
		)a
		;
		
		RAISERROR ('Completed insertion of International Chile source data to MEASURE table', 0, 1) WITH NOWAIT	
		
		
	/*--------------------------------Loading Fact table---------------------------------*/
	
	DECLARE @cl_facttypeid BIGINT;
	
	SET @cl_facttypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'TBC' and rlovset.LOVsetname = 'Fact Type');
	
	INSERT INTO [ser].[fact]
	(
	[FactId]
    ,[FactName]
    ,[LOVFactTypeId]
    ,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	)
		SELECT
		@max_FactId + (dense_rank() over (order by FactName,LOVFactTypeId asc)) AS [FactId]
		,[FactName]
		,[LOVFactTypeId]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		FROM
		(
			SELECT TOP 1
			'CRP Planogram' AS [FactName]
			,@cl_facttypeid AS [LOVFactTypeId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[fact] F on 'CRP Planogram' = F.FactName and @cl_facttypeid = F.LOVFactTypeId and F.LOVRecordSourceId = 12001 where F.FactName IS NULL
			
			UNION
			
			SELECT TOP 1
			'CRP Layout Performance' AS [FactName]
			,@cl_facttypeid AS [LOVFactTypeId]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[fact] F on 'CRP Layout Performance' = F.FactName and @cl_facttypeid = F.LOVFactTypeId and F.LOVRecordSourceId = 12001 where F.FactName IS NULL
		)a
		;
		
		RAISERROR ('Completed insertion of International Chile source data to FACT table', 0, 1) WITH NOWAIT
		
		
	/*--------------------------------Loading Dimension table---------------------------------*/
	INSERT INTO [ser].[Dimension]
	([DimensionId]
    ,[Name]
    ,[Description]
    ,[Schema]
    ,[Tablename]
    ,[SurrogateKeyColumn]
    ,[SourceKeyColumn]
    ,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	)
		SELECT
		@max_DimensionId + (dense_rank() over (order by [Name] asc)) AS [DimensionId]
		,[Name]
		,[Description]
		,[Schema]
		,[Tablename]
		,[SurrogateKeyColumn]
		,[SourceKeyColumn]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		FROM
			(SELECT TOP 1
			'Planogram' AS [Name]
			,NULL AS [Description]
			,NULL AS [Schema]
			,'Planogram' AS [Tablename]
			,'Planogram Id' AS [SurrogateKeyColumn]
			,'Source Key' AS [SourceKeyColumn]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[Dimension] D on 'Planogram' = D.Name and D.LOVRecordSourceId = 12001 where D.Name IS NULL
			
			UNION
			
			SELECT TOP 1
			'Product' AS [Name]
			,NULL AS [Description]
			,NULL AS [Schema]
			,'Product' AS [Tablename]
			,'Product Id' AS [SurrogateKeyColumn]
			,'Source Key' AS [SourceKeyColumn]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[Dimension] D on 'Product' = D.Name and D.LOVRecordSourceId = 12001 where D.Name IS NULL
		
			UNION
			
			SELECT TOP 1
			'Week' AS [Name]
			,NULL AS [Description]
			,NULL AS [Schema]
			,'RefLOV' AS [Tablename]
			,'LOVId' AS [SurrogateKeyColumn]
			,'LOVKey' AS [SourceKeyColumn]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS  [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[Dimension] D on 'Week' = D.Name and D.LOVRecordSourceId = 12001 where D.Name IS NULL
			
			UNION
			
			SELECT TOP 1
			'Store' AS [Name]
			,NULL AS [Description]
			,NULL AS [Schema]
			,'Site Role' AS [Tablename]
			,'Site Role Id' AS [SurrogateKeyColumn]
			,'Source Key' AS [SourceKeyColumn]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS  [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[Dimension] D on 'Store' = D.Name and D.LOVRecordSourceId = 12001 where D.Name IS NULL
			
			UNION
			
			SELECT TOP 1
			'Floor' AS [Name]
			,NULL AS [Description]
			,NULL AS [Schema]
			,'RefLOV' AS [Tablename]
			,'LOVId' AS [SurrogateKeyColumn]
			,'LOVKey' AS [SourceKeyColumn]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS  [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[Dimension] D on 'Floor' = D.Name and D.LOVRecordSourceId = 12001 where D.Name IS NULL
			
			UNION
			
			SELECT TOP 1
			'Week' AS [Name]
			,NULL AS [Description]
			,NULL AS [Schema]
			,'RefLOV' AS [Tablename]
			,'LOVId' AS [SurrogateKeyColumn]
			,'LOVKey' AS [SourceKeyColumn]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS  [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[Dimension] D on 'Week' = D.Name and D.LOVRecordSourceId = 12001 where D.Name IS NULL
			
			UNION
			
			SELECT TOP 1
			'Planogram' AS [Name]
			,NULL AS [Description]
			,NULL AS [Schema]
			,'Planogram' AS [Tablename]
			,'Planogram Id' AS [SurrogateKeyColumn]
			,'Source Key' AS [SourceKeyColumn]
			,12001 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS  [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			from [ser].[reflov] R LEFT OUTER JOIN [ser].[Dimension] D on 'Planogram' = D.Name and D.LOVRecordSourceId = 12001 where D.Name IS NULL
		)a;
		
		RAISERROR ('Completed insertion of International Chile source data to DIMENSION table', 0, 1) WITH NOWAIT
		
	
	/*--------------------------------Loading Fact Dimension table---------------------------------*/
	DECLARE @cl_factid BIGINT;
	DECLARE @cl_factid_lay BIGINT;
	DECLARE @dim_id_plano BIGINT;
	DECLARE @dim_id_prod BIGINT;
	DECLARE @dim_id_week BIGINT;
	DECLARE @dim_id_store BIGINT;
	DECLARE @dim_id_floor BIGINT;


	SET @dim_id_plano = (SELECT DimensionId from ser.Dimension where Name = 'Planogram' AND LOVRecordSourceId = 12001)
	SET @dim_id_prod = (SELECT DimensionId from ser.Dimension where Name = 'Product' AND LOVRecordSourceId = 12001)
	SET @dim_id_week = (SELECT DimensionId from ser.Dimension where Name = 'Week' AND LOVRecordSourceId = 12001)
	SET @dim_id_store = (SELECT DimensionId from ser.Dimension where Name = 'Store' AND LOVRecordSourceId = 12001)
	SET @dim_id_floor = (SELECT DimensionId from ser.Dimension where Name = 'Floor' AND LOVRecordSourceId = 12001)
	SET @cl_factid = (SELECT f.FactId FROM  ser.fact f INNER JOIN (	SELECT 	rl.LOVId, rl.LOVKey, rl.LOVRecordSourceId FROM ser.RefLOV rl 
						INNER JOIN ser.RefLOVSet rls ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVSETName='Fact Type' and rls.LovSETrecordsourceid = 12012) rlrls
					ON rlrls.LOVKey = 'TBC' AND f.LOVFactTypeId = rlrls.LOVId
					WHERE f.FactName = 'CRP Planogram' AND f.LOVRecordSourceId = 12001);
					
	SET @cl_factid_lay = (SELECT f.FactId FROM  ser.fact f INNER JOIN (	SELECT rl.LOVId, rl.LOVKey, rl.LOVRecordSourceId FROM ser.RefLOV rl 
							INNER JOIN ser.RefLOVSet rls ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVSETName='Fact Type' and rls.LovSETrecordsourceid = 12012) rlrls
							ON rlrls.LOVKey = 'TBC' AND f.LOVFactTypeId = rlrls.LOVId
							WHERE f.FactName = 'CRP Layout Performance' AND f.LOVRecordSourceId = 12001)
	
	
	INSERT INTO [ser].[FactDimension]
	([FactId]
    ,[DimensionId]
    ,[Sequence]
    ,[Mandatory]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	)
		(SELECT TOP 1
		@cl_factid AS [FactId]
		,@dim_id_plano AS [DimensionId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactDimension] FD on 
		@cl_factid = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.DimensionId = @dim_id_plano where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid AS [FactId]
		,@dim_id_prod AS [DimensionId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactDimension] FD on 
		@cl_factid = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.DimensionId = @dim_id_prod where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid AS [FactId]
		,@dim_id_week AS [DimensionId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactDimension] FD on 
		@cl_factid = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.DimensionId = @dim_id_week where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid_lay AS [FactId]
		,@dim_id_store AS [DimensionId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactDimension] FD on 
		@cl_factid_lay = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.DimensionId = @dim_id_store where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid_lay AS [FactId]
		,@dim_id_floor AS [DimensionId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactDimension] FD on 
		@cl_factid_lay = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.DimensionId = @dim_id_floor where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid_lay AS [FactId]
		,@dim_id_week AS [DimensionId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactDimension] FD on 
		@cl_factid_lay = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.DimensionId = @dim_id_week where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid_lay AS [FactId]
		,@dim_id_plano AS [DimensionId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactDimension] FD on 
		@cl_factid_lay = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.DimensionId = @dim_id_plano where FD.FactId IS NULL
		);
		
		RAISERROR ('Completed insertion of International Chile source data to FACTDIMENSION table', 0, 1) WITH NOWAIT
		
		
	
	/*--------------------------------Loading Fact Measure table---------------------------------*/
	
	DECLARE @msr_id_facing BIGINT;
	DECLARE @msr_id_unit BIGINT;
	DECLARE @msr_id_tesp BIGINT;
	DECLARE @msr_id_tisp BIGINT;
	DECLARE @msr_id_epos BIGINT;
	DECLARE @msr_id_modspace BIGINT;

	SET @msr_id_facing = (SELECT measureid from ser.measure WHERE MeasureName = 'facings' AND LOVRecordSourceId = 12001 and LOVMeasureTypeId = @cl_measuretypeid_agg)
	SET @msr_id_unit = (SELECT measureid from ser.measure WHERE MeasureName = 'units' AND LOVRecordSourceId = 12001 and LOVMeasureTypeId = @cl_measuretypeid_agg)
	SET @msr_id_tesp = (SELECT measureid from ser.measure WHERE MeasureName = 'tesp' AND LOVRecordSourceId = 12001 and LOVMeasureTypeId = @cl_measuretypeid_agg)
	SET @msr_id_tisp = (SELECT measureid from ser.measure WHERE MeasureName = 'tisp' AND LOVRecordSourceId = 12001 and LOVMeasureTypeId = @cl_measuretypeid_agg)
	SET @msr_id_epos = (SELECT measureid from ser.measure WHERE MeasureName =  'epos_profit' AND LOVRecordSourceId = 12001 and LOVMeasureTypeId = @cl_measuretypeid_agg)
	SET @msr_id_modspace = (SELECT measureid from ser.measure WHERE MeasureName =  'modular_space' AND LOVRecordSourceId = 12001 and LOVMeasureTypeId = @cl_measuretypeid_agg)

	INSERT INTO [ser].[FactMeasure]
	(
	[FactId]
    ,[MeasureId]
    ,[Sequence]
    ,[Mandatory]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	)
		(
		SELECT TOP 1
		@cl_factid AS [FactId]
		,@msr_id_facing AS [MeasureId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactMeasure] FD on 
		@cl_factid = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.MeasureId = @msr_id_facing where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid_lay AS [FactId]
		,@msr_id_unit AS [MeasureId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactMeasure] FD on 
		@cl_factid_lay = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.MeasureId = @msr_id_unit where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid_lay AS [FactId]
		,@msr_id_tesp AS [MeasureId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactMeasure] FD on 
		@cl_factid_lay = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.MeasureId = @msr_id_tesp where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid_lay AS [FactId]
		,@msr_id_tisp AS [MeasureId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactMeasure] FD on 
		@cl_factid_lay = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.MeasureId = @msr_id_tisp where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid_lay AS [FactId]
		,@msr_id_epos AS [MeasureId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactMeasure] FD on 
		@cl_factid_lay = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.MeasureId = @msr_id_epos where FD.FactId IS NULL
		
		UNION
		
		SELECT TOP 1
		@cl_factid_lay AS [FactId]
		,@msr_id_modspace AS [MeasureId]
		,NULL AS [Sequence]
		,NULL AS [Mandatory]
		,12001 AS [LOVRecordSourceId]
		,'1900-01-01 00:00:00' AS [SCDStartDate]
		,'9999-12-31 00:00:00' AS [SCDEndDate]
		,'Y' AS [SCDActiveFlag]
		,1 AS  [SCDVersion]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		from [ser].[reflov] R 
		LEFT OUTER JOIN [ser].[FactMeasure] FD on 
		@cl_factid_lay = FD.FactId and FD.LOVRecordSourceId = 12001 and FD.MeasureId = @msr_id_modspace where FD.FactId IS NULL
		);
		
		
		RAISERROR ('Completed insertion of International Chile source data to FACTMEASURE table', 0, 1) WITH NOWAIT
		
		COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH
				DECLARE @error_num varchar(max),
        				@error_msg varchar(max),
        				@error_sev varchar(max)
        		;
 
				SELECT  
        		@error_num=ERROR_NUMBER()
        		,@error_sev=ERROR_SEVERITY()  
         		,@error_msg=ERROR_MESSAGE() ;  
 
        		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
			END CATCH 
END
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.SP_MERCHANDISING_CURATION_CRP_MERCHANDISING_MEXICO_HISTORY') IS NOT NULL
BEGIN
    DROP PROC [psa].[SP_MERCHANDISING_CURATION_CRP_MERCHANDISING_MEXICO_HISTORY]
END
GO

CREATE PROCEDURE [psa].[SP_MERCHANDISING_CURATION_CRP_MERCHANDISING_MEXICO_HISTORY] @psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max)
AS 
/*
************************************************************************************************************
Procedure Name				: SP_MERCHANDISING_CURATION_CRP_MERCHANDISING_MEXICO_HISTORY
Purpose						: Load History data From International Mexico 
Domain						: Merchandise
ServeLayer Target Tables	: Planogram, Planogramgroup, Planogramindicator, Planogramproperty
RecordSourceID  for International Mexico : 12004
*****************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
 */ 
BEGIN



	/*--Declarations---*/
	DECLARE @max_PlanogramId BIGINT;
	DECLARE @max_PlanogramGroupId BIGINT;
	DECLARE @rowStatusPSACode BIGINT;
	DECLARE @rowStatusSERCode BIGINT;
	DECLARE @measureTypeIdPlanoDim BIGINT;
	
	
	SET @rowStatusPSACode = 26001
    SET @rowStatusSERCode = 26002 
	SET @measureTypeIdPlanoDim = (SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid 
	AND rls.LOVsetName='Measure Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'PLANOGRAM_DIM');


	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_PlanogramId = COALESCE(MAX(PlanogramId),0) FROM [ser].[Planogram];
	SELECT @max_PlanogramGroupId = COALESCE(MAX(PlanogramGroupId),0) FROM [ser].[planogramgroup];
	
	


	/*-------------------------------Create temporary source table-------------------------------*/
	
	IF OBJECT_ID('tempdb..#RAWMX_CRP_MERCHANDISE_temp') IS NOT NULL
	BEGIN
		drop table tempdb..#RAWMX_CRP_MERCHANDISE_temp;
	END
	
	
	SELECT
	@max_PlanogramId + (DENSE_RANK() OVER(ORDER BY pog_id)) AS PlanogramId
    ,*
	INTO #RAWMX_CRP_MERCHANDISE_temp
	FROM (SELECT distinct * from [psa].[RAWMX_CRP_MERCHANDISE] where [row_status]=@rowStatusPSACode and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')))a
	;
	
	RAISERROR ('Completed insertion of International Mexico source data to temporary table #RAWMX_CRP_MERCHANDISE_temp', 0, 1) WITH NOWAIT
	
	BEGIN TRANSACTION;
	BEGIN TRY
	
	/*-------------------------------Loading Planogram table--------------------------------------*/
	INSERT INTO [ser].[Planogram] 
	([PlanogramId]
	,[SourceKey]
	,[LOVSourceKeyTypeId]
	,[ParentPlanogramId]
	,[PlanogramStartDate]
	,[PlanogramEndDate]
	,[PlanogramName]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[PlanogramId]
		,[SourceKey]
		,[LOVSourceKeyTypeId]
		,[ParentPlanogramId]
		,CASE WHEN (PlanogramStartDate = '' or PlanogramStartDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramStartDate END AS [PlanogramStartDate]
		,CASE WHEN (PlanogramEndDate = '' or PlanogramEndDate = '1900-01-01 00:00:00.000') THEN NULL ELSE PlanogramEndDate END AS [PlanogramEndDate]
		,[PlanogramName]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD([SCDStartDate],1,'9999-12-31 00:00:00') OVER (PARTITION BY [PlanogramId] ORDER BY [SCDStartDate],psarowkey ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY [PlanogramId] ORDER BY [SCDStartDate],psarowkey ASC) AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY [PlanogramId] ORDER BY [SCDStartDate],psarowkey ASC) AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT distinct
			case when (op.PlanogramId is null) then src.planogramid else op.planogramid end as planogramid
			,src.pog_id AS [SourceKey]
			,lkp_refl.LOVId AS [LOVSourceKeyTypeId]
			,NULL AS [ParentPlanogramId]
			,src.planogram_start_date AS [PlanogramStartDate]
			,src.planogram_end_date AS [PlanogramEndDate]
			,src.pog_description AS [PlanogramName]
			,12004 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			--,'N' AS [SCDActiveFlag]
			--,NULL AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM
			#RAWMX_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Source Key Type' and rls.Lovsetrecordsourceid = 12012) lkp_refl
			ON lkp_refl.LOVKey =  'Mexico Planogram Id(pog_id)'
			left outer join (select distinct * from ser.planogram where lovrecordsourceid = 12004) op
			on src.record_source_id = op.lovrecordsourceid
			and ISNULL(src.pog_id,'DUMMY_POGID_FORNULL') = ISNULL(op.sourcekey,'DUMMY_POGID_FORNULL')
		)a
		;
		
		--update SCDVersion, SCDActiveFlag, SCDEndDate
		UPDATE [ser].[Planogram] 
		set scdactiveflag = F.scdactiveflag,
			SCDEndDate 	= F.SCDEndDate,
			SCDVersion = F.SCDVersion from  [ser].[Planogram] P join
		(select case
		when A.scdenddate = '9999-12-31 00:00:00.000' then 'Y' else 'N' end as scdactiveflag, A.SCDEndDate, A.[SCDVersion], A.psarowkey from
		(SELECT scdactiveflag,
		LEAD(i.SCDStartDate,1,'9999-12-31') OVER(PARTITION BY PlanogramId ORDER BY i.SCDStartDate,i.psarowkey ASC) SCDEndDate ,
		ROW_NUMBER() OVER (PARTITION BY PlanogramId ORDER BY [SCDStartDate],i.psarowkey ASC) AS [SCDVersion],
		psarowkey     FROM ser.planogram i
		where  LOVRecordSourceId =12004) A) F
		ON P.psarowkey = F.psarowkey
		where P.LOVRecordSourceId =12004
		;
	
		--update SCDStartDate to 1900 for SCDVersion=1
		UPDATE [ser].[Planogram]
		set SCDStartDate = '1900-01-01'
		where SCDVersion = 1 and LOVRecordSourceId =12004
		;
		
		RAISERROR ('Completed insertion of International Mexico source data to Planogram table', 0, 1) WITH NOWAIT


	/*--------------------------Loading Planogramgroup table---------------------------*/
	
	update #RAWMX_CRP_MERCHANDISE_temp
	set planogramid = p.planogramid
	from #RAWMX_CRP_MERCHANDISE_temp tmp
	join (select * from ser.planogram where lovrecordsourceid = 12004) p
	on p.psarowkey = tmp.row_id
	and p.lovrecordsourceid = 12004
	;
	
	INSERT INTO [ser].[planogramgroup]
	([PlanogramGroupId]
	,[PlanogramId]
	,[LOVPlanogramGroupSetId]
	,[LOVGroupId]
	,[ParentPlanogramGroupId]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		@max_PlanogramGroupId + (dense_rank() over (order by PlanogramId,LOVGroupId asc)) AS [PlanogramGroupId]
		,[PlanogramId]
		,[LOVPlanogramGroupSetId]
		,[LOVGroupId]
		,[ParentPlanogramGroupId]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY PlanogramId,LOVGroupId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY PlanogramId,LOVGroupId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY PlanogramId,LOVGroupId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12004 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #RAWMX_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='fitting_type' and rls.Lovsetrecordsourceid = 12004) lkp_refl
			ON src.fitting_type = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='fitting_type' AND lkp_refl_set.Lovsetrecordsourceid = 12004)
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12004) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.fitting_type IS NOT NULL AND src.fitting_type <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12004 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #RAWMX_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='planner_family' and rls.Lovsetrecordsourceid = 12004) lkp_refl
			ON src.planner_family = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='planner_family' AND lkp_refl_set.Lovsetrecordsourceid = 12004) 
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12004) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.planner_family IS NOT NULL AND src.planner_family <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12004 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #RAWMX_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='footprint' and rls.Lovsetrecordsourceid = 12004) lkp_refl
			ON src.footprint = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='footprint' AND lkp_refl_set.Lovsetrecordsourceid = 12004) 
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12004) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.footprint IS NOT NULL AND src.footprint <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12004 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #RAWMX_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='category' and rls.Lovsetrecordsourceid = 12004) lkp_refl
			ON src.category = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='category' AND lkp_refl_set.Lovsetrecordsourceid = 12004) 
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12004) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.category IS NOT NULL AND src.category <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_refl_set.LOVSetID AS [LOVPlanogramGroupSetId]
			,lkp_refl.LOVId AS [LOVGroupId]
			,NULL AS [ParentPlanogramGroupId]
			,12004 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #RAWMX_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='format' and rls.Lovsetrecordsourceid = 12004) lkp_refl
			ON src.format = lkp_refl.LOVKey 
			LEFT OUTER JOIN
			ser.RefLOVSet lkp_refl_set
			ON(lkp_refl_set.LOVsetName='format' AND lkp_refl_set.Lovsetrecordsourceid = 12004) 
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12004) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.format IS NOT NULL AND src.format <> ''
		)a
		;
		
		--update SCDVersion, SCDActiveFlag and SCDEndDate
		UPDATE [ser].[PlanogramGroup] 
		set scdactiveflag = F.scdactiveflag,
			SCDEndDate 	= F.SCDEndDate,
			SCDVersion = F.SCDVersion from  [ser].[PlanogramGroup] P join
		(select A.PlanogramId,A.LOVGroupId,case
		when A.scdenddate = '9999-12-31 00:00:00.000' then 'Y' else 'N' end as scdactiveflag, A.SCDEndDate, A.[SCDVersion], A.psarowkey from
		(SELECT PlanogramId,LOVGroupId,scdactiveflag,
		LEAD(i.SCDStartDate,1,'9999-12-31') OVER(PARTITION BY PlanogramId,LOVGroupId ORDER BY i.SCDStartDate,i.psarowkey ASC) SCDEndDate ,
		ROW_NUMBER() OVER (PARTITION BY PlanogramId,LOVGroupId ORDER BY [SCDStartDate],i.psarowkey ASC) AS [SCDVersion],
		psarowkey     FROM ser.PlanogramGroup i
		where  LOVRecordSourceId =12004) A) F
		ON P.psarowkey = F.psarowkey
		and P.PlanogramId = F.PlanogramId
		and P.LOVGroupId = F.LOVGroupId
		where P.LOVRecordSourceId =12004
		;
	
		--update SCDStartDate to 1900 where SCDVersion=1
		UPDATE [ser].[PlanogramGroup]
		set SCDStartDate = '1900-01-01'
		where SCDVersion = 1 and LOVRecordSourceId =12004
		;
		
		RAISERROR ('Completed insertion of International Mexico source data to Planogramgroup table', 0, 1) WITH NOWAIT



	/*---------------------------------Loading PlanogramIndicator table---------------------------------*/
	INSERT INTO [ser].[PlanogramIndicator]
	([PlanogramId]
	,[LovIndicatorId]
	,[Value]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,[SCDEndDate]
	,[SCDActiveFlag]
	,[SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	)
	SELECT
	[PlanogramId]
	,[LovIndicatorId]
	,[Value]
	,[LOVRecordSourceId]
	,[SCDStartDate]
	,LEAD([SCDStartDate],1,'9999-12-31 00:00:00') OVER (PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [SCDStartDate],PSARowKey ASC) AS [SCDEndDate]
	,LEAD('N',1,'Y') OVER (PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [SCDStartDate],PSARowKey ASC) AS [SCDActiveFlag]
	,ROW_NUMBER() OVER (PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [SCDStartDate],PSARowKey ASC) AS [SCDVersion]
	,[SCDLOVRecordSourceId]
	,[ETLRunLogId]
	,[PSARowKey]
	FROM
	(
		SELECT distinct
		src.PlanogramId AS [PlanogramId]
		,lkp_refl.LOVId AS [LovIndicatorId]
		,src.promotional_site AS [value]
		,12004 AS [LOVRecordSourceId]
		,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
		,151 AS [SCDLOVRecordSourceId]
		,@serveETLRunLogID AS [ETLRunLogId]
		,src.row_id AS [PSARowKey]
		FROM #RAWMX_CRP_MERCHANDISE_temp src
		LEFT OUTER JOIN
		(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
		ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Indicator - MEXICO Merchandise' and rls.Lovsetrecordsourceid = 12004 and rl.LOVKey = 'promotional_site') lkp_refl
		ON lkp_refl.LOVRecordSourceId = src.record_source_id 
		JOIN
		(SELECT * from ser.planogram where Lovrecordsourceid=12004) PL
		on PL.PlanogramId = src.PlanogramId 
		and	PL.psarowkey = src.row_id
		WHERE src.promotional_site IS NOT NULL AND src.promotional_site <> ''
	)a
	;
	
	--update SCDVersion, SCDActiveFlag and SCDEndDate
	UPDATE [ser].[PlanogramIndicator] 
	set scdactiveflag = F.scdactiveflag,
		SCDEndDate 	= F.SCDEndDate,
		SCDVersion = F.SCDVersion from  [ser].[PlanogramIndicator] P join
	(select A.PlanogramId,A.LovIndicatorId,case
	when A.scdenddate = '9999-12-31 00:00:00.000' then 'Y' else 'N' end as scdactiveflag, A.SCDEndDate, A.[SCDVersion], A.psarowkey from
	(SELECT PlanogramId,LovIndicatorId,scdactiveflag,
	LEAD(i.SCDStartDate,1,'9999-12-31') OVER(PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY i.SCDStartDate,i.psarowkey ASC) SCDEndDate ,
	ROW_NUMBER() OVER (PARTITION BY [PlanogramId],[LovIndicatorId] ORDER BY [SCDStartDate],i.psarowkey ASC) AS [SCDVersion],
	psarowkey     FROM ser.PlanogramIndicator i
	where  LOVRecordSourceId =12004) A) F
	ON P.psarowkey = F.psarowkey
	and P.PlanogramId = F.PlanogramId
	and P.LovIndicatorId = F.LovIndicatorId
	where P.LOVRecordSourceId =12004
	;
	
	--update SCDStartDate to 1900 where SCDVersion=1
	UPDATE [ser].[PlanogramIndicator]
	set SCDStartDate = '1900-01-01'
	where SCDVersion = 1 and LOVRecordSourceId =12004
	;
	
	RAISERROR ('Completed insertion of International Mexico source data to PlanogramIndicator table', 0, 1) WITH NOWAIT


		
	/*--------------------------------Loading Planogram Property table---------------------------------*/
	
	INSERT INTO [ser].[PlanogramProperty]
	(
	[PlanogramId]
    ,[MeasureId]
    ,[LOVUOMId]
    ,[Value]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[PlanogramId]
		,[MeasureId]
		,[LOVUOMId]
		,[Value]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY PlanogramId,MeasureId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY PlanogramId,MeasureId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY PlanogramId,MeasureId ORDER BY SCDStartDate,PSARowKey ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_meas.MeasureId AS [MeasureId]
			,lkp_refl.LOVId AS [LOVUOMId]
			,src.shelf_depth AS [Value]
			,12004 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #RAWMX_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Unit Of Measure' and rls.Lovsetrecordsourceid = 12012) lkp_refl
			ON lkp_refl.LOVKey =  'cm'
			LEFT OUTER JOIN
			[ser].[measure] lkp_meas
			ON (lkp_meas.MeasureName = 'shelf_depth' AND lkp_meas.LOVMeasureTypeId = @measureTypeIdPlanoDim AND lkp_meas.LOVRecordSourceId = 12004)
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12004) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.shelf_depth IS NOT NULL AND src.shelf_depth <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_meas.MeasureId AS [MeasureId]
			,lkp_refl.LOVId AS [LOVUOMId]
			,src.height AS [Value]
			,12004 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #RAWMX_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Unit Of Measure' and rls.Lovsetrecordsourceid = 12012) lkp_refl
			ON lkp_refl.LOVKey =  'cm'
			LEFT OUTER JOIN
			[ser].[measure] lkp_meas
			ON (lkp_meas.MeasureName = 'height' AND lkp_meas.LOVMeasureTypeId = @measureTypeIdPlanoDim AND lkp_meas.LOVRecordSourceId = 12004)
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12004) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.height IS NOT NULL AND src.height <> ''
			
			UNION
			
			SELECT
			src.PlanogramId AS [PlanogramId]
			,lkp_meas.MeasureId AS [MeasureId]
			,lkp_refl.LOVId AS [LOVUOMId]
			,src.build_size AS [Value]
			,12004 AS [LOVRecordSourceId]
			,ISNULL(src.date_added,'1900-01-01 00:00:00') AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID AS [ETLRunLogId]
			,src.row_id AS [PSARowKey]
			FROM #RAWMX_CRP_MERCHANDISE_temp src
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Unit Of Measure' and rls.Lovsetrecordsourceid = 12012) lkp_refl
			ON lkp_refl.LOVKey =  'Unknown'
			LEFT OUTER JOIN
			[ser].[measure] lkp_meas
			ON (lkp_meas.MeasureName = 'build_size' AND lkp_meas.LOVMeasureTypeId = @measureTypeIdPlanoDim AND lkp_meas.LOVRecordSourceId = 12004)
			JOIN
			(SELECT * from ser.planogram where Lovrecordsourceid=12004) PL
			on PL.PlanogramId = src.PlanogramId 
			and	PL.psarowkey = src.row_id
			WHERE src.build_size IS NOT NULL AND src.build_size <> ''
		)a
		;
		
		--update SCDVersion, SCDActiveFlag and SCDEndDate
		UPDATE [ser].[PlanogramProperty] 
		set scdactiveflag = F.scdactiveflag,
			SCDEndDate 	= F.SCDEndDate,
			SCDVersion = F.SCDVersion from  [ser].[PlanogramProperty] P join
		(select A.PlanogramId,A.MeasureId,case
		when A.scdenddate = '9999-12-31 00:00:00.000' then 'Y' else 'N' end as scdactiveflag, A.SCDEndDate, A.[SCDVersion], A.psarowkey from
		(SELECT PlanogramId,MeasureId,scdactiveflag,
		LEAD(i.SCDStartDate,1,'9999-12-31') OVER(PARTITION BY PlanogramId,MeasureId ORDER BY i.SCDStartDate,i.psarowkey ASC) SCDEndDate ,
		ROW_NUMBER() OVER (PARTITION BY PlanogramId,MeasureId ORDER BY [SCDStartDate],i.psarowkey ASC) AS [SCDVersion],
		psarowkey     FROM ser.PlanogramProperty i
		where  LOVRecordSourceId =12004) A) F
		ON P.psarowkey = F.psarowkey
		and P.PlanogramId = F.PlanogramId
		and P.MeasureId = F.MeasureId
		where P.LOVRecordSourceId =12004
		;
	
		--update SCDStartDate to 1900 where SCDVersion=1
		UPDATE [ser].[PlanogramProperty]
		set SCDStartDate = '1900-01-01'
		where SCDVersion = 1 and LOVRecordSourceId =12004
		;
		
		RAISERROR ('Completed insertion of International Mexico source data to PlanogramProperty table', 0, 1) WITH NOWAIT
		
		UPDATE [psa].[RAWMX_CRP_MERCHANDISE] SET [row_status]=@rowStatusSERCode
                FROM [psa].[RAWMX_CRP_MERCHANDISE] mx 
                INNER JOIN [ser].[Planogram] p ON mx.row_id=p.PSARowKey and mx.record_source_id=p.LovRecordSourceID 
                WHERE mx.row_status=@rowStatusPSACode  AND p.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))
		
		COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH
				DECLARE @error_num varchar(max),
        				@error_msg varchar(max),
        				@error_sev varchar(max)
        		;
 
				SELECT  
        		@error_num=ERROR_NUMBER()
        		,@error_sev=ERROR_SEVERITY()  
         		,@error_msg=ERROR_MESSAGE() ;  
 
        		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
			END CATCH 
END
GO
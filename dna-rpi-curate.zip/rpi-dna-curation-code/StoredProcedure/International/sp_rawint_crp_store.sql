/****** Object:  StoredProcedure [psa].[sp_rawint_crp_store]    Script Date: 04/07/2020 13:14:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('psa.sp_rawint_crp_store') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawint_crp_store
END
GO
/*
************************************************************************************************************
Procedure Name				: sp_rawint_crp_store
Purpose						: Load History data From International Store in psa layer(crp_store ) into Serve Layer Table
Domain						: Store
ServeLayer Target Tables	: SITE ,SITEROLE ,PARTY ,Organisation ,PartyRole ,PARTYROLESITEROLERELATIONSHIP ,POSTALADDRESS ,
							  SITEROLETERRITORY ,SiteRoleGroup ,SITEROLEINDICATOR ,SiteRoleStatus ,Measure(moved to DML ) ,SITEROLEPROPERTY 
								(Total 13 Tables)
RecordSourceID  for International Store : 12001,12004,12005,12010
**********************************************************************************************************************************************
SCD Columns and Concept (latest data is inserted from each input run). History load will have only version1, History catch up have version 2
**********************************************************************************************************************************************
				SCDStartDate        :  1900-01-01 00:00:00 (for version 1 ) else date_added
				SCDEndDate          :  31-12-9999 (for latest version) else SCDStartDate of next version
				SCDActiveFlag       :  'Y'   for latest version, 'N' for other versions
				SCDVersion          :  '1'   (1 for first version , Then put incrementally)
				SCDLOVRecordSourceId: 151 
				ETLRunLogId         : RunlogID from psa table

*************************************************************************************************************
History Catch Up: Take the latest among the catchup data and insert
*************************************************************************************************************
15-July-2020  : Incorporated v2.1 mapping changes                                                          */ 

 /*Declare  and initialize the Variables required for serve layer processing*/
CREATE PROC [psa].[sp_rawint_crp_store] @psaETLRunLogID [varchar](MAX),@serveETLRunLogID [varchar](MAX),@tableName [varchar](200) AS

DECLARE 
@recordSourceId int,
@scdLovRecordSourceID int,
@PostalLOVRecordSourceId  int,
@MAXID int,
@LOVCountryId int,
@LOVSiteTypeId int,
@CountryCode varchar(2),
@LOVWarehouseRoleId int, 
@lovIndicator varchar(200),
@MAXSiteId int,
@LOVRoleId int,
@maxSiteRoleId int,
@LOVIndicatorId int,
@PartyTypeId int,
@date_added varchar(max),
@heritage_company varchar(max),
@MAXSRGpID int,
@OpenStatus int,
@ClosedStatus int,
@MAXPartyId int,
@RetailerRoleId int,
@MAXPartyRoleId int,
@RoleId int,
@RelationshipTypeId1 int,
@RelationshipTypeId2 int,
@FetchRecordSourceId nvarchar(max),
@PSARowStatus int,
@ServeRowStatus int,
@LOVGeoCodeMeasureTypeId int,
@LOVFloorAreaMeasureTypeId int,
@LOVDataTypeId int,
@UOMID1 int,
@UOMID2 int,
@UOMID3 int,
@LOVSiteRoleStatusSetId int,
@open_date nvarchar(max),
@close_date nvarchar(max),
@store_format nvarchar(max),
@store_loc nvarchar(max),
@partyrole_const_srckey varchar(255),
@partyroleid_const int,
@db varchar(max);


	
BEGIN

IF OBJECT_ID('ser.TempIntStore_SiteRole_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRole_STG
END

IF OBJECT_ID('ser.TempIntStore_SiteRoleIndicator_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRoleIndicator_STG
END


IF OBJECT_ID('ser.TmpIntStore_SiteRoleProp_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TmpIntStore_SiteRoleProp_STG
END

IF OBJECT_ID('ser.TmpIntStore_SiteRoleTerritory_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TmpIntStore_SiteRoleTerritory_STG
END
IF OBJECT_ID('ser.TempIntStore_SiteRoleGroup_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRoleGroup_STG
END
IF OBJECT_ID('ser.TempIntStore_SiteRoleStatus_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_SiteRoleStatus_STG
END

IF OBJECT_ID('ser.TempIntStore_PartyRoleSiteRoleRelationship_STG') IS NOT NULL
BEGIN

DROP TABLE ser.TempIntStore_PartyRoleSiteRoleRelationship_STG
END

IF OBJECT_ID('ser.TempIntStore_PartyRoleSiteRoleRelationshipPartA_STG') IS NOT NULL
BEGIN

drop table ser.TempIntStore_PartyRoleSiteRoleRelationshipPartA_STG
END

CREATE TABLE  ser.TempIntStore_SiteRole_STG( 
    ExistsFlag              int            NULL,
	[SiteRoleId]            bigint         NULL,
    [SiteId]                bigint         NOT NULL,
    [LOVRoleId]             int            NOT NULL,
    [SourceKey]             varchar(80)    NULL,
    [SiteRoleName]          varchar(80)    NULL,
    [SiteRoleShortName]     varchar(20)    NULL,
    [LOVRecordSourceId]     int            NOT NULL,
    [SCDStartDate]          datetime       NULL,
    [SCDEndDate]            datetime       NULL,
    [SCDActiveFlag]         char(1)        NULL,
    [SCDVersion]            smallint       NULL,
    [SCDLOVRecordSourceId]  int            NULL,
    [ETLRunLogId]           int            NULL,
	PSARowKey bigint NULL)

CREATE TABLE ser.TempIntStore_SiteRoleIndicator_STG(
	ExistsFlag              int         NULL,
    [SiteRoleId]            bigint      NOT NULL,
    [LOVIndicatorId]        int         NOT NULL,
    [Value]                 char(1)     NULL,
    [LOVRecordSourceId]     int         NOT NULL,
    [SCDStartDate]          datetime    NULL,
    [SCDEndDate]            datetime    NULL,
    [SCDActiveFlag]         char(1)     NULL,
    [SCDVersion]            smallint    NULL,
    [SCDLOVRecordSourceId]  int         NULL,    
	[ETLRunLogId]          int         NULL,
	PSARowKey               bigint      NULL
)
	
CREATE TABLE ser.TmpIntStore_SiteRoleProp_STG(
    ExistsFlag              int             NOT NULL,
    [SiteRoleId]            bigint          NOT NULL,
	PGCol                   nvarchar(255)   NULL,   
    [MeasureId]             int             NOT NULL,
    [LOVUOMId]              int             NOT NULL,
    [Value]                 varchar(255)    NULL,
    [LOVRecordSourceId]     int             NOT NULL,
    [SCDStartDate]          datetime        NULL,   
	[SCDEndDate]            datetime        NULL,    
    [SCDActiveFlag]         char(1)         NULL,
	[SCDVersion]            smallint        NULL,    
	PSARowKey               bigint 			NULL 
)

CREATE TABLE ser.TmpIntStore_SiteRoleTerritory_STG(
    ExistsFlag                   int         NOT NULL,
    [SiteRoleId]                 bigint      NOT NULL,
	PGCol                        nvarchar(255) NOT NULL,
    [LOVSiteRoleTerritorySetId]  int         NOT NULL,
    [LOVTerritoryId]             int         NOT NULL,
    [LOVRecordSourceId]          int         NOT NULL,
    [SCDStartDate]               datetime    NULL,  
	[SCDEndDate]                 datetime    NULL,  
    [SCDActiveFlag]              char(1)     NULL, 
    [SCDVersion]                 smallint    NULL,  
	PSARowKey                    bigint      NULL
)

CREATE TABLE ser.TempIntStore_SiteRoleGroup_STG(
    ExistsFlag               int         NULL, 
    SiteRoleGroupId          bigint      NULL,
    [SiteRoleId]             bigint      NOT NULL,
	PGCol                    nvarchar(255) NULL,
    [LOVSiteRoleGroupSetId]  int         NOT NULL,
    [LOVGroupId]             int         NOT NULL,
    [ParentSiteRoleGroupId]  bigint      NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          char(1)     NULL,
    [SCDVersion]             smallint    NULL,    
    [PSARowKey]              bigint      NULL
)
CREATE TABLE ser.TempIntStore_SiteRoleStatus_STG(
    ExistsFlag                int         NOT NULL,
    [SiteRoleId]              bigint      NOT NULL,
    [LOVSiteRoleStatusSetId]  int         NOT NULL,
    [LOVStatusId]             int         NOT NULL,
    [EffectiveFrom]           datetime    NULL,
    [EffectiveTo]             datetime    NULL,
	openDate nvarchar(500) NULL,
	closeDate nvarchar(500) NULL,
    [LOVRecordSourceId]       int         NOT NULL,
    [SCDStartDate]            datetime    NULL,
    [SCDEndDate]              datetime    NULL,
    [SCDActiveFlag]           char(1)     NULL,
    [SCDVersion]              smallint    NULL,
    PSARowKey bigint NULL
)
CREATE TABLE ser.TempIntStore_PartyRoleSiteRoleRelationshipPartA_STG(
	 ExistsFlag              int         NOT NULL,
    [PartyRoleId]            bigint      NOT NULL,
    [SiteRoleId]             bigint      NOT NULL,
    [LOVRelationshipTypeId]  int         NOT NULL,
    [EffectiveFrom]          datetime    NULL,
    [EffectiveTo]            datetime    NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          char(1)     NULL,
    [SCDVersion]             smallint    NULL,    
    [PSARowKey]            bigint        NULL
	
)
CREATE TABLE ser.TempIntStore_PartyRoleSiteRoleRelationship_STG(
	 ExistsFlag              int         NOT NULL,
    [PartyRoleId]            bigint      NOT NULL,
    [SiteRoleId]             bigint      NOT NULL,
    [LOVRelationshipTypeId]  int         NOT NULL,
    [EffectiveFrom]          datetime    NULL,
    [EffectiveTo]            datetime    NULL,
    [LOVRecordSourceId]      int         NOT NULL,
    [SCDStartDate]           datetime    NULL,
    [SCDEndDate]             datetime    NULL,
    [SCDActiveFlag]          char(1)     NULL,
    [SCDVersion]             smallint    NULL,    
    [PSARowKey]            bigint        NULL
	
)
BEGIN TRANSACTION;

-- FETCH recordSourceId from data
--SET @FetchRecordSourceId = N'SELECT TOP 1 @recordSourceId =record_source_id FROM '+@tableName
--exec sp_executesql @FetchRecordSourceId, N'@recordSourceId int out', @recordSourceId out
SET @db='psa'
SET @scdLovRecordSourceID = 151
SET @PostalLOVRecordSourceId =12012
SET @PSARowStatus =26001
SET @ServeRowStatus= 26002
 

--set recordSourceId,Country code,lovIndicator ,date_added,heritage_company,open_date,close_date
if (@tableName='rawcl_crp_store')
BEGIN
SET @recordSourceId = 12001
SET @CountryCode='CL'
SET @lovIndicator='Indicator - CHILE Site'
SET @date_added='date_added'
SET @heritage_company='heritage_company'
SET @open_date= 'open_date'  
SET @close_date='close_date'
SET @store_format='store_format'
SET @store_loc='store_loc'
SET @partyrole_const_srckey='WBA-CL-FA'
END
ELSE if (@tableName='rawth_crp_store')
BEGIN
SET @recordSourceId = 12010
SET @CountryCode='TH'
SET @lovIndicator='Indicator - THAILAND Site'
SET @date_added='date_added'
SET @heritage_company='heritage_company' 
SET @open_date= 'open_date' 
SET @close_date='close_date'
SET @store_format='store_format'
SET @store_loc='store_loc'
SET @partyrole_const_srckey='WBA-TH-BT'
END
ELSE if (@tableName='rawmx_crp_store')
BEGIN
SET @recordSourceId = 12004
SET @CountryCode='MX'
SET @lovIndicator='Indicator - MEXICO Site' 
SET @date_added='date_added'
SET @heritage_company='heritage_company'  
SET @open_date= 'open_date'
SET @close_date='close_date'
SET @store_format='store_format'
SET @store_loc='store_loc'
SET @partyrole_const_srckey='WBA-MX-FB'
END
ELSE if (@tableName='rawno_crp_store')
BEGIN
SET @recordSourceId = 12005
SET @CountryCode='NO'
SET @lovIndicator='Indicator - Norway Site'
--set heritage_company,open_date Incase of Norway since columns are shifted, we map columns here
SET @date_added='heritage_company'
SET @heritage_company='heritage_flag' 
SET @open_date= 'store_loc' 
SET @close_date='open_date'
SET @store_format='store_size'
SET @store_loc='store_format'
SET @partyrole_const_srckey='WBA-NO-BN'
END

SELECT  @tablename= CONCAT(@db, '.',@tablename)
PRINT @tablename
PRINT @recordSourceId
PRINT  @CountryCode + ' '+ @lovIndicator + ' '+ @date_added + ' '+  @heritage_company + ' '+  @open_date + ' '+  @close_date
	

--used in PostalAddress
SELECT @LOVCountryId=r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = @CountryCode  AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = 'Country ISO 3166-2' );
SELECT @MAXSiteId=COALESCE(max(SiteId),0) FROM ser.PostalAddress;
--used in Site 
SELECT @LOVSiteTypeId=r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'POSTAL ADDRESS' AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = 'Site Type'); 
--used in SiteRole
SELECT @LOVRoleId= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'Store' AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = 'Role');   
SELECT @LOVWarehouseRoleId= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'Warehouse'  AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = 'Role');   
SELECT @maxSiteRoleId=COALESCE(max(siteroleId),0) from ser.SiteRole
PRINT @LOVRoleId
--used in SiteRoleIndicator
SELECT @LOVIndicatorId= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'heritage_flag'  AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName =@lovIndicator  );

--used in Party
SELECT @PartyTypeId= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'ORG'  AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName ='Party Type'  );
SELECT @MAXPartyId= COALESCE(max(PartyId),0) from ser.Party
--used in PartyRole
SELECT @MAXPartyRoleId= COALESCE(max(PartyRoleId),0) from ser.PartyRole
SELECT @RetailerRoleId= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'Retailer'  AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName ='Role'  );
--used in SiteRoleProperty

SELECT @LOVGeoCodeMeasureTypeId =  ref.Lovid from ser.reflov ref JOIN ser.reflovset refset
        on ref.LovSetID = refset.LovSetID WHERE ref.LOVKey = 'GEOCODE' and refset.LOVSETName = 'Measure Type' 
		
 
SELECT @LOVFloorAreaMeasureTypeId =  ref.Lovid from ser.reflov ref JOIN ser.reflovset refset
        on ref.LovSetID = refset.LovSetID WHERE ref.LOVKey = 'FLOOR_AREA' and refset.LOVSETName = 'Measure Type' 
        
SELECT @LOVDataTypeId = ref.Lovid from ser.reflov ref JOIN ser.reflovset refset
        on ref.LovSetID = refset.LovSetID WHERE ref.LOVKey = 'STRING' and refset.LOVSETName = 'Data Type' 

	 
SELECT @UOMID1= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey =  'Unknown'  AND 
r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName ='Unit Of Measure'  );

SELECT @UOMID2= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey =  'm2'  AND 
r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName ='Unit Of Measure'  );


SELECT @UOMID3= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey =  '°'  AND 
r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName ='Unit Of Measure'  );



--SiteRoleGroup
SELECT @MAXSRGpID=COALESCE(max(siterolegroupid),0) from ser.siterolegroup;
--siterolestatus
SELECT @OpenStatus = ref.Lovid from ser.reflov ref JOIN ser.reflovset refs on ref.LovSetID = refs.LovSetID WHERE ref.LOVKey =  'O'  and refs.LOVSETName = 'Status Type'
SELECT @ClosedStatus = ref.Lovid from ser.reflov ref JOIN ser.reflovset refs on ref.LovSetID = refs.LovSetID WHERE ref.LOVKey =  'C'  and refs.LOVSETName = 'Status Type'
SELECT @LOVSiteRoleStatusSetId= refs.LOVSetId FROM ser.reflovset refs WHERE refs.LOVSETName = 'Status Type'
--PartRoleSiteRelationship
SELECT @RelationshipTypeId1= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'Operates From'   
AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName ='Relationship Type'  );
SELECT @RelationshipTypeId2= r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = 'Previously Operated From'  
AND r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName ='Relationship Type'  );


BEGIN TRY

/********************************************************************************************************************************
1.	Table Name  :PostalAddress
**********************************************************************************************************************************/
PRINT 'Starting execution....'

PRINT '****************************** INFO: POSTAL ADDRESS LOADING*************************'


exec ( '
INSERT INTO ser.PostalAddress (SiteId, LocationName, AddressLine1, AddressLine2, Town, County, PostalCode, LOVCountryId, LOVRecordSourceId, SCDStartDate,SCDEndDate,
 SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey ) 

SELECT 
		CASE WHEN Ser.ExistsFlag=0 THEN '+@MAXSiteId+ ' + ROW_NUMBER() OVER(ORDER BY  Ser.LocationName,Ser.AddressLine1, Ser.AddressLine2, Ser.Town, Ser.County,Ser.PostalCode) END SiteId, 
		Ser.LOCATIONNAME,
		Ser.AddressLine1,
		Ser.AddressLine2, 
		Ser.Town, 
		Ser.County,
		Ser.PostalCode,
		'+@LOVCountryId+', 
		'+@PostalLOVRecordSourceId+',
		''1900-01-01 00:00:00'' SCDStartDate,
		''9999-12-31 00:00:00''  SCDEndDate, 
		''Y'', 
		1, 
		'+@scdLovRecordSourceID+ ', 
		'+@serveETLRunLogID+' ETLRunLogId,
		Ser.PSARowKey
		FROM 
			(SELECT 
				Source.LOCATIONNAME,
				Source.AddressLine1,
				Source.AddressLine2, 
				Source.Town,Source.County,
				Source.PostalCode,
				CONVERT(DATETIME,Source.SCDStartDate) SCDStartDate,
				Source.PSARowKey,
				CASE WHEN  POSTAL.SiteId is NULL THEN  0 ELSE 1  END AS ExistsFlag
				FROM 
					( SELECT 
						LOCATIONNAME,
						AddressLine1,
						AddressLine2,
						Town,
						County,
						PostalCode,
						max(SCDStartDate) SCDStartDate ,
						max(PSARowKey) PSARowKey
							FROM 
								(SELECT  
									NULL LOCATIONNAME,
									Case When Stage.address_line1 is NULL 
									OR Stage.address_line1 = ''NULL'' 
									OR len(Stage.address_line1)=0 
									OR Stage.address_line1=''-'' 
									then NULL 
									ELSE trim(Stage.address_line1) END  AddressLine1,
									Case When Stage.address_line2 is NULL
									OR Stage.address_line2 = ''NULL''
									OR len(Stage.address_line2)=0 
									OR Stage.address_line2=''-'' 
									then NULL ELSE trim(Stage.address_line2) END  AddressLine2,       
									Case When Stage.address_line3 is NULL 
									OR Stage.address_line3 = ''NULL'' 
									OR len(Stage.address_line3)=0 
									OR Stage.address_line3=''-'' 
									then NULL ELSE trim(Stage.address_line3) END  Town,
									Case When Stage.address_line4 is NULL 
									OR  Stage.address_line4 = ''NULL'' 
									OR  len(Stage.address_line4)=0 
									OR Stage.address_line4=''-'' 
									then NULL ELSE trim(Stage.address_line4) END  County,
									Case When Stage.postal_code is NULL 
									OR  Stage.postal_code = ''NULL'' 
									OR len(Stage.postal_code)=0 
									OR Stage.postal_code=''-'' 
									then NULL ELSE trim(Stage.postal_code) END  PostalCode,'  
									+@date_added+'  SCDStartDate, 
									Stage.row_id PSARowKey
									FROM '+ @tableName+ '  Stage Where Stage.Row_status='+@PSARowStatus+' AND etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','','')))P
							group by LOCATIONNAME,AddressLine1, AddressLine2, Town,County, PostalCode) Source
				LEFT JOIN ser.PostalAddress Postal 
					ON ISNULL(trim(Source.AddressLine1),'''')=ISNULL(trim(POSTAL.AddressLine1),'''') AND   
					ISNULL(trim(Source.AddressLine2),'''') =ISNULL(trim(POSTAL.AddressLine2),'''') AND 
					ISNULL(trim(Source.Town),'''')=ISNULL(trim(POSTAL.Town),'''') AND 
					ISNULL(trim(Source.County),'''')=ISNULL(trim(POSTAL.County),'''') AND	
					ISNULL(trim(Source.PostalCode),'''')=ISNULL(trim(POSTAL.PostalCode) ,''''))Ser WHERE Ser.ExistsFlag=0 
					') 


PRINT '****************************** INFO: POSTAL ADDRESS LOADED*************************';
/********************************************************************************************************************************
2.	Table Name  :SITE
**********************************************************************************************************************************/
PRINT '****************************** INFO: SITE LOADING*************************'
exec('
INSERT INTO ser.Site (SiteId,SourceKey,SiteName,LOVSiteTypeId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSArowKey)
	SELECT DISTINCT
		SiteId,
		SourceKey,
		SiteName,
		LOVSiteTypeId,
		LOVRecordSourceId,
		SCDStartDate,
		SCDEndDate,
		SCDActiveFlag,
		SCDVersion,
		SCDLOVRecordSourceId,
		'+@serveETLRunLogID+' ETLRunLogId ,
		PSARowKey
		FROM (
			select 
				Postal.SiteId,
				NULL SourceKey,
				NULL SiteName,				
				Stage.LOVSiteTypeId,
				Postal.LOVRecordSourceId,
				Postal.SCDStartDate,
				Postal.SCDEndDate,
				Postal.SCDActiveFlag,Postal.SCDVersion,'
				+@SCDLovRecordSourceId+' SCDLovRecordSourceId,
				Postal.PSARowKey,
				Case When Site.SiteId IS NULL THEN 0  ELSE 1 END ExistsFlag
				from  
					(select
						LOVSiteTypeId,											
						address_line1,
						address_line2,
						address_line3,
						address_line4,
						postal_code,
						max(date_added) SCDStartDate						
						from (select  
								Case When address_line1 is NULL 
									OR address_line1 = ''NULL'' 
									OR len(address_line1)=0 
									OR address_line1=''-'' 
									then NULL 
									ELSE trim(address_line1) END  address_line1,
									Case When address_line2 is NULL
									OR address_line2 = ''NULL''
									OR len(address_line2)=0 
									OR address_line2=''-'' 
									then NULL ELSE trim(address_line2) END  address_line2,       
									Case When address_line3 is NULL 
									OR address_line3 = ''NULL'' 
									OR len(address_line3)=0 
									OR address_line3=''-'' 
									then NULL ELSE trim(address_line3) END  address_line3,
									Case When address_line4 is NULL 
									OR  address_line4 = ''NULL'' 
									OR  len(address_line4)=0 
									OR address_line4=''-'' 
									then NULL ELSE trim(address_line4) END  address_line4,
									Case When postal_code is NULL 
									OR  postal_code = ''NULL'' 
									OR len(postal_code)=0 
									OR postal_code=''-'' 
									then NULL ELSE trim(postal_code) END  postal_code,  
								    '+@LOVSiteTypeId+'	   LOVSiteTypeId,
								    '+@date_added+'  date_added 
								
									from '+ @tableName+ ' Where Row_status='+@PSARowStatus+' AND etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','','')))P 
									group by  LOVSiteTypeId, address_line1,address_line2,address_line3,address_line4,postal_code)STage
				JOIN ser.PostalAddress Postal
						ON ISNULL(trim(Stage.address_line1),'''')=ISNULL(trim(POSTAL.AddressLine1),'''') AND   
							ISNULL(trim(Stage.address_line2),'''') =ISNULL(trim(POSTAL.AddressLine2),'''') AND 
							ISNULL(trim(Stage.address_line3),'''')=ISNULL(trim(POSTAL.Town),'''') AND 
							ISNULL(trim(Stage.address_line4),'''')=ISNULL(trim(POSTAL.County),'''') AND	
							ISNULL(trim(Stage.postal_code),'''')=ISNULL(trim(POSTAL.PostalCode) ,'''')
				LEFT JOIN ser.Site on Postal.SiteId=Site.SiteId AND Postal.lovrecordsourceId=Site.lovRecordSourceId AND
						Stage.LOVSiteTypeId=Site.LOVSiteTypeId )Ser 
		WHERE Ser.ExistsFlag=0')

PRINT '****************************** INFO: SITE LOADED*************************';

/********************************************************************************************************************************
3.	Table Name  :SITEROLE
**********************************************************************************************************************************/
PRINT '****************************** INFO: SITEROLE LOADING*************************'

exec('	 INSERT INTO ser.TempIntStore_SiteRole_STG
	SELECT
	CASE WHEN SR.SiteRoleId IS  NULL THEN 0 ELSE  1 END AS existsFlag,
	SR.SiteRoleId, 
	Source.SiteId,
	Source.lovroleId, 
	Source.SourceKey, 
	Source.Siterolename,
	Source.Siteroleshortname,
	Source.lovrecordsourceId,
	CONVERT(DATETIME,Source.SCDStartDate) SCDStartDate,
	LEAD(CONVERT(DATETIME,Source.SCDStartDate),1,CONVERT(DATETIME,''99991231'')) OVER(PARTITION BY Source.SourceKey,Source.LOVRecordSourceId ORDER BY Source.SCDStartDate) SCDEndDate,
	LEAD(''N'', 1,''Y'') OVER(PARTITION BY Source.SourceKey,Source.LOVRecordSourceId ORDER BY Source.SCDStartDate) SCDActiveFlag,
	SR.SCDVERSION SCDVERSION ,
	Source.SCDLOVRecordSourceId,
	Source.ETLRunLogId,
	Source.PSARowKey	

	FROM 
		(SELECT  POSTAL.SiteId,Stage.lovroleId,Stage.SourceKey,Stage.SiteRoleName,Stage.SiteRoleShortName,Stage.LOVRecordSourceId,Stage.SCDStartDate,
		Stage.SCDLOVRecordSourceId,Stage.ETLRunLogId,Stage.PSARowKey
		FROM
		(SELECT Case When address_line1 is NULL 
									OR address_line1 = ''NULL'' 
									OR len(address_line1)=0 
									OR address_line1=''-'' 
									then NULL 
									ELSE trim(address_line1) END  address_line1,
									Case When address_line2 is NULL
									OR address_line2 = ''NULL''
									OR len(address_line2)=0 
									OR address_line2=''-'' 
									then NULL ELSE trim(address_line2) END  address_line2,       
									Case When address_line3 is NULL 
									OR address_line3 = ''NULL'' 
									OR len(address_line3)=0 
									OR address_line3=''-'' 
									then NULL ELSE trim(address_line3) END  address_line3,
									Case When address_line4 is NULL 
									OR  address_line4 = ''NULL'' 
									OR  len(address_line4)=0 
									OR address_line4=''-'' 
									then NULL ELSE trim(address_line4) END  address_line4,
									Case When postal_code is NULL 
									OR  postal_code = ''NULL'' 
									OR len(postal_code)=0 
									OR postal_code=''-'' 
									then NULL ELSE trim(postal_code) END  postal_code,
									Case When ('''+@CountryCode+''' = ''TH'') and store_format in  (''Warehouse'') then '+@LOVWarehouseRoleId+'
									ELSE '+@LOVRoleId+ ' END lovroleId,
			store_number  SourceKey ,
			store_name	SiteRoleName,		
			NULL SiteRoleShortName,
			record_source_id LOVRecordSourceId,'
			+@date_added+'  SCDStartDate,'													
			+@SCDLOVRecordSourceId+ ' SCDLOVRecordSourceId,'
			+@serveETLRunLogID+'  ETLRunLogId, row_id PSARowKey 
			FROM '+ @tableName+ ' where Row_status='+@PSARowStatus+' AND etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','',''))) Stage 
		JOIN ser.PostalAddress POSTAL 
			on ISNULL(trim(Stage.address_line1),'''')=ISNULL(trim(POSTAL.AddressLine1),'''') AND   
			ISNULL(trim(Stage.address_line2),'''') =ISNULL(trim(POSTAL.AddressLine2),'''') AND 
			ISNULL(trim(Stage.address_line3),'''')=ISNULL(trim(POSTAL.Town),'''') AND 
			ISNULL(trim(Stage.address_line4),'''')=ISNULL(trim(POSTAL.County),'''') AND	
			ISNULL(trim(Stage.postal_code),'''')=ISNULL(trim(POSTAL.PostalCode) ,'''') AND 
			Postal.LovRecordSourceId='+@PostalLOVRecordSourceId+' AND 
			Postal.SCDActiveFlag=''Y''  
			
			)Source
		LEFT JOIN ser.SiteRole SR ON SR.SourceKey=Source.SourceKey AND SR.LovRecordSourceId=Source.LovRecordSourceId AND SR.SCDActiveFlag=''Y''')

--Close the existing records ie , update its status to 'N' and enddate to the new startdate-1
exec('UPDATE 
		ser.SiteRole SET SCDActiveFlag= ''N'' , 
		SCDEndDate= INS.SCDStartDate 
		FROM ser.SiteRole
			JOIN (SELECT * FROM ser.TempIntStore_SiteRole_STG STG  WHERE STG.SCDActiveFlag=''Y'' AND STG.existsFlag=1  )INS
			ON SiteRole.SiteRoleId=INS.SiteRoleId AND SiteRole.SCDActiveFlag=''Y''  ANd SiteRole.lovRecordSourceId=INS.lovRecordSourceId')

--Insert the records 
exec('INSERT INTO ser.SiteRole (SiteRoleId,SiteId,LOVRoleId,SourceKey,SiteRoleName,SiteRoleShortName,LOVRecordSourceId,SCDStartDate,
SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
		SELECT 
			CASE WHEN INS.existsFlag=1 THEN INS.SiteRoleId ELSE '+@maxSiteRoleId+' + ROW_NUMBER() OVER(ORDER BY  INS.SourceKey, INS.LOVRecordSourceId) END SiteRoleId , 
			INS.SiteId, 
			INS.LOVRoleId, 
			INS.SourceKey,
			INS.SiteRoleName,
			INS.SiteRoleShortName, 
			INS.LOVRecordSourceId, 
			CASE WHEN INS.SCDVERSION IS NULL THEN ''1900-01-01 00:00:00'' ELSE 	INS.SCDStartDate END SCDStartDate, 
			INS.SCDEndDate, 
			INS.SCDActiveFlag,
			COALESCE(INS.SCDVERSION,0) + 1 AS SCDVERSION ,
			INS.SCDLOVRecordSourceId,
			INS.ETLRunLogId,
			INS.PSARowKey
			FROM (SELECT * FROM ser.TempIntStore_SiteRole_STG STG  WHERE STG.SCDActiveFlag=''Y'' )INS')


PRINT 'Info: SiteRole Table Loaded Successfully '; 



/********************************************************************************************************************************
4.	Table Name  :SiteRoleIndicator
**********************************************************************************************************************************/
PRINT '****************************** INFO: SiteRoleIndicator LOADING*************************'
	   
exec('INSERT INTO  ser.TempIntStore_SiteRoleIndicator_STG SELECT 
		CASE WHEN SRInd.SiteRoleId IS NULL AND SRInd.LOVIndicatorId IS NULL AND SRInd.LOVRecordSourceId IS NULL  THEN 0 ELSE 1 END ExistsFlag,
		INDCTR.SiteRoleId SiteRoleId,
		INDCTR.LOVIndicatorId,
		INDCTR.Value,
		INDCTR.LOVRecordSourceId,
		INDCTR.SCDStartDate,
		LEAD(CONVERT(DATETIME,INDCTR.SCDStartDate),1,CONVERT(DATETIME,''99991231'')) OVER(PARTITION BY INDCTR.SiteRoleId,INDCTR.LOVIndicatorId,INDCTR.LOVRecordSourceId ORDER BY INDCTR.SCDStartDate ASC) SCDEndDate,
		LEAD(''N'', 1,''Y'') OVER(PARTITION BY INDCTR.SiteRoleId,INDCTR.LOVIndicatorId,INDCTR.LOVRecordSourceId ORDER BY INDCTR.SCDStartDate ASC) SCDActiveFlag,
		SRInd.SCDVERSION SCDVersion,
		INDCTR.SCDLOVRecordSourceId,
		INDCTR.ETLRunLogId,
		INDCTR.PSARowKey  FROM (SELECT STG.* FROM 
			(SELECT 
				SiteRole.SiteRoleId,'
				+@LOVIndicatorId+ ' AS LOVIndicatorId,
				Case WHEN '''+@CountryCode+''' IN (''NO'') THEN Latitude ELSE heritage_flag END Value,
				record_source_id LOVRecordSourceId,'
				+@date_added+' SCDStartDate,'   
				+@SCDLOVRecordSourceId+' SCDLOVRecordSourceId,'
				+@serveETLRunLogID+' as ETLRunLogId,
				row_id PSARowKey
					FROM '+ @tableName+ ' store 
					JOIN ser.SiteRole 
						on SiteRole.SourceKey=store.store_number AND SiteRole.LOVRecordSourceId=store.record_source_id 
						AND SiteRole.SCDActiveFlag=''Y''  AND store.Row_status='+@PSARowStatus+' AND 
						etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','','')))STG 
						WHERE STG.Value IS NOT NULL AND LEN(TRIM(STG.Value)) >0 AND STG.Value <> ''NULL'' )INDCTR 
					LEFT JOIN ser.SiteRoleIndicator SRInd ON SRInd.SiteRoleId=INDCTR.SiteRoleId AND SRInd.LOVIndicatorId=INDCTR.LOVIndicatorId 
							AND SRInd.LOVRecordSourceId=INDCTR.LOVRecordSourceId  AND SRInd.SCDActiveFlag=''Y''  
							')  

exec('
		UPDATE 
			ser.SiteRoleIndicator SET SCDActiveFlag= ''N'',  
			SCDEndDate=INS.SCDStartDate 
		FROM ser.SiteRoleIndicator SRInd 
		JOIN (SELECT * FROM ser.TempIntStore_SiteRoleIndicator_STG STG  WHERE STG.SCDActiveFlag=''Y'' AND STG.existsFlag=1 )INS
			ON SRInd.SiteRoleId=INS.SiteRoleId AND SRInd.LOVIndicatorId=INS.LOVIndicatorId
				AND SRInd.SCDActiveFlag=''Y'' AND SRInd.lovRecordSourceId=INS.lovRecordSourceId')

exec('
INSERT INTO ser.SiteRoleIndicator
(SiteRoleId,LOVIndicatorId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
	SELECT 
		SiteRoleId,
		LOVIndicatorId,
		Source.Value,
		LOVRecordSourceId,
		CASE WHEN Source.SCDVERSION IS NULL THEN ''1900-01-01 00:00:00'' ELSE 	Source.SCDStartDate END SCDStartDate,
		SCDEndDate,
		Source.SCDActiveFlag,
		COALESCE(Source.SCDVERSION,0) + 1 AS SCDVERSION,
		SCDLOVRecordSourceId, 
		ETLRunLogId,
		PSARowKey FROM 
		(SELECT * FROM ser.TempIntStore_SiteRoleIndicator_STG where SCDActiveFlag=''Y'')Source')

PRINT 'Info: SiteRoleIndicator Table Loaded Successfully'; 


/********************************************************************************************************************************
5.	Table Name  :Party
**********************************************************************************************************************************/

PRINT '****************************** INFO: Party LOADING*************************'
exec ('
INSERT INTO ser.Party (PartyId, LOVPartyTypeId, SourceKey, LOVRecordSourceId, SCDStartDate,SCDEndDate, SCDActiveFlag, 
SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
	SELECT 
		PartyId, 
		PartyTypeId, 
		SourceKey, 
		LOVRecordSourceId, 
		SCDStartDate,SCDEndDate, 
		SCDActiveFlag, 
		SCDVersion, 
		SCDLOVRecordSourceId, 
		ETLRunLogId,
		PSARowKey
		FROM 
			(SELECT 
				CASE WHEN Party.PartyId IS NULL THEN '+ @MAXPartyId+' + ROW_NUMBER() OVER(ORDER BY  store.SourceKey,store.lovrecordsourceId) END PartyId,
				CASE WHEN Party.PartyId IS NULL THEN 0 ELSE 1 END ExistsFlag,
				PartyTypeId,
				store.SourceKey,
				store.lovrecordsourceid,
				''1900-01-01 00:00:00'' SCDStartDate ,
				''9999-12-31 00:00:00'' SCDEndDate,
				''Y'' SCDActiveFlag,
				1 SCDVersion,'
				+@SCDLOVRecordSourceId+' SCDLOVRecordSourceId ,'
				+@serveETLRunLogId+' ETLRunLogId,
				store.row_id PSARowKey
				FROM 
					(select 
						'+@PartyTypeId+' PartyTypeId, 
						SourceKey,
						lovrecordsourceid,
						max(date_added) date_added, 
						max(row_id) row_id 
						FROM (
							select 
								'+ @heritage_company +' SourceKey , 
								record_source_id lovrecordsourceId,'
								+@date_added+ ' date_added,row_id
								FROM '+ @tableName+ ' WHERE Row_status='+@PSARowStatus+' AND 
						etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','','')))stage 
						group by SourceKey,lovrecordsourceId having SourceKey IS NOT NULL AND LEN(TRIM(SourceKey)) >0 AND SourceKey <> ''NULL'' )store
				LEFT JOIN ser.Party
						on store.lovrecordsourceId=Party.lovrecordsourceId 
							AND Party.SourceKey=store.SourceKey 
							AND Party.SCDActiveFlag=''Y'' 
							AND Party.LOVPartyTypeId=store.PartyTypeId)STG 
			where STG.ExistsFlag=0 ')


PRINT 'Info: Party Table Loaded Successfully'; 

/********************************************************************************************************************************
6.	Table Name  :PartyRole
**********************************************************************************************************************************/
PRINT '****************************** INFO: PARTYROLE LOADING*************************'
exec ('INSERT INTO [ser].[PartyRole]
           ([PartyRoleId]
           ,[LOVRoleId]
           ,[PartyId]
           ,[SourceKey]
           ,[PartyRoleName]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])
		   select 
			CASE WHEN PartyRole.PartyRoleId IS NULL THEN '+ @MAXPartyRoleId+' + ROW_NUMBER() OVER(ORDER BY  STG.PartyId,STG.LovRoleId,STG.lovrecordsourceId) END PartyRoleId,
			STG.LovRoleId, 
			STG.PartyId,
			STG.SourceKey,
			STG.SourceKey, 
			STG.lovrecordsourceid,
			''1900-01-01 00:00:00'' SCDStartDate ,
			''9999-12-31 00:00:00'' SCDEndDate,
			''Y'' SCDActiveFlag,
			1 SCDVersion,'
			+@SCDLOVRecordSourceId+' SCDLOVRecordSourceId ,'
			+@serveETLRunLogId+' ETLRunLogId,
			STG.row_id PSARowKey
			from 
				(select 
					Party.PartyId ,
					LovRoleId ,
					store.SourceKey,
					store.lovrecordsourceid,
					date_added,  
					row_id 
					from 
						(select 
							'+@RetailerRoleId+' LovRoleId, 
							SourceKey,
							lovrecordsourceid,
							max(date_added) date_added, 
							max(row_id) row_id 
							FROM (
								select 
									'+ @heritage_company +' SourceKey , 
									record_source_id lovrecordsourceId,'
									+@date_added+ ' date_added,
									row_id 
									FROM '+ @tableName+ ' WHERE Row_status='+@PSARowStatus+' AND 
						etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','','')) )stage 
							group by SourceKey,lovrecordsourceId  having SourceKey IS NOT NULL AND LEN(TRIM(SourceKey)) >0 AND SourceKey <> ''NULL'' )store 
						JOIN ser.Party ON Party.SourceKey=store.SourceKey 
							AND Party.lovrecordsourceId=store.lovrecordsourceId 
							AND PArty.SCDActiveFlag=''Y'')STG
			LEFT JOIN ser.PartyRole
				on STG.lovrecordsourceId=PartyRole.lovrecordsourceId 
				AND PartyRole.SourceKey=STG.SourceKey 
				AND PArtyRole.SCDActiveFlag=''Y'' 
				AND PartyRole.LOVRoleId=STG.LovRoleId 
				AND PartyRole.PartyId=STG.PartyId 
			WHERE PartyRole.PartyRoleId IS NULL
')

PRINT 'Info: PartyRole Table Loaded Successfully'; 

/********************************************************************************************************************************
7.	Table Name  :Organisation
**********************************************************************************************************************************/
PRINT '****************************** INFO: Organisation LOADING*************************'
	
exec ('INSERT INTO [ser].[Organisation]
           ([PartyId]
           ,[SourceOrganisationKey]
           ,[OrganisationName]
           ,[ParentPartyId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])
				select  
					Party.PartyId,
					store.SourceKey,
					store.SourceKey,
					NULL ParentPartyId,
					store.lovrecordsourceid,
					''1900-01-01 00:00:00'' SCDStartDate ,
				    ''9999-12-31 00:00:00'' SCDEndDate,
					''Y'' SCDActiveFlag,
					1 SCDVersion,'
					+@SCDLOVRecordSourceId+' SCDLOVRecordSourceId ,'
					+@serveETLRunLogId+'  ETLRunLogId,
					store.row_id PSARowKey 
					from 
						(select 
							SourceKey,
							lovrecordsourceid,
							max(date_added) date_added, 
							max(row_id) row_id 
								FROM (
									select 
										'+ @heritage_company +' SourceKey , 
										record_source_id lovrecordsourceId,'
										+@date_added+ ' date_added,
										row_id
										FROM '+ @tableName+ ' WHERE Row_status='+@PSARowStatus+' AND 
						etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','','')) )stage 
								group by SourceKey,lovrecordsourceId  having SourceKey IS NOT NULL AND LEN(TRIM(SourceKey)) >0 AND SourceKey <> ''NULL'')store 
				JOIN ser.Party ON Party.SourceKey=store.SourceKey 
						AND Party.lovrecordsourceId=store.lovrecordsourceId 
						AND PArty.SCDActiveFlag=''Y''
				LEFT JOIN ser.Organisation Org ON Org.PartyId=Party.PartyId 
						AND Org.lovrecordsourceId=store.lovrecordsourceId 
						AND Org.SCDActiveFlag=''Y''
				Where Org.PartyId IS NULL
')

PRINT 'Info: Organisation Table Loaded Successfully'; 


/********************************************************************************************************************************
8.	Table Name  :PartyRoleSiteRoleRelationship  PART I 
**********************************************************************************************************************************/
PRINT '****************************** INFO: PartyRoleSiteRoleRelationship  LOADING*************************'

select @partyroleid_const=partyroleId from  ser.partyrole where partyrole.SourceKey=@partyrole_const_srckey AND partyrole.SCDActiveFlag='Y'
AND partyrole.lovroleid=@RetailerRoleId

PRINT @RelationshipTypeId1
PRINT  @RetailerRoleId
PRINT '****************************** INFO: PartyRoleSiteRoleRelationship  LOADING*************************'
exec('INSERT INTO ser.TempIntStore_PartyRoleSiteRoleRelationshipPartA_STG
SELECT ExistsFlag,partyroleid,siteroleId,lovRelationshipTypeId,EffectiveFrom,EffectiveTo,lovrecordsourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,
PSARowKey  FROM (
SELECT 
CASE WHEN prsr.siteroleid is null AND prsr.partyroleId IS NULL AND prsr.lovRelationshipTypeId IS NULL 
AND prsr.lovrecordsourceid IS NULL THEN 0 ELSE 1 END ExistsFlag,
STG.partyroleid,
STG.siteroleId siteroleId, 
STG.RelationshipTypeId lovRelationshipTypeId, 
NULL EffectiveFrom,
NULL EffectiveTo, 
STG.lovrecordsourceId lovrecordsourceId,
CONVERT(DATETIME,STG.SCDStartDate) SCDStartDate,
LEAD(CONVERT(DATETIME,STG.SCDSTARTDate),1,CONVERT(DATETIME,''99991231'')) 
OVER(PARTITION BY STG.siteroleid,STG.partyroleId,STG.RelationshipTypeId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate ASC) SCDEndDate,
LEAD(''N'', 1,''Y'') 
OVER(PARTITION BY STG.siteroleid,STG.partyroleId,STG.RelationshipTypeId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) AS SCDActiveFlag,
prsr.SCDVersion SCDVersion, 
row_id PSARowKey 
FROM 
( 
SELECT '+@RelationshipTypeId1+' RelationshipTypeId, 
siterole.siteroleId, 
'+@partyroleid_const+' partyroleid,
store.date_added SCDStartDate,
store.record_source_id lovrecordsourceId,
store.row_id FROM 
(
SELECT 
store_number, 
record_source_id , 
'+@date_added+' date_added, 
row_id FROM '+ @tableName+ ' WHERE  Row_status='+@PSARowStatus+' AND 
etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','',''))
) store

join ser.siterole on siterole.SourceKey =store.store_number 
AND siterole.lovrecordsourceId=store.record_source_id AND siterole.SCDActiveFlag=''Y'')STG
LEFT JOIN ser.PartyRoleSiteRoleRelationship prsr 
ON   prsr.siteroleid=STG.siteroleid AND prsr.partyroleId='+@partyroleid_const+'
AND prsr.LOVRelationshipTypeId='''+@RelationshipTypeId1+'''
AND prsr.lovrecordsourceid=STG.lovrecordsourceId 
AND prsr.SCDActiveFlag=''Y'')Src where Src.SCDActiveFlag=''Y''')



exec('
UPDATE ser.PartyRoleSiteRoleRelationship 
	SET SCDActiveFlag= ''N'',  
	SCDEndDate=INS.SCDStartDate 
		FROM ser.PartyRoleSiteRoleRelationship SRInd 
			JOIN 
				(SELECT * FROM ser.TempIntStore_PartyRoleSiteRoleRelationshipPartA_STG STG  WHERE STG.existsFlag=1 )INS
					ON SRInd.SiteRoleId=INS.SiteRoleId 
					AND SRInd.partyroleId=INS.partyroleId
					AND SRInd.SCDActiveFlag=''Y'' 
					AND SRInd.lovRelationshipTypeId=INS.lovRelationshipTypeId 
					AND SRInd.lovRecordSourceId=INS.lovRecordSourceId')


exec('
INSERT INTO [ser].[PartyRoleSiteRoleRelationship]
           ([PartyRoleId]
           ,[SiteRoleId]
           ,[LOVRelationshipTypeId]
           ,[EffectiveFrom]
           ,[EffectiveTo]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])
	SELECT 
		PartyRoleId,
		SiteRoleId,
		LovRelationshipTypeId, 
		EffectiveFrom,
		EffectiveTo,
		LOVRecordSourceId,
		CASE WHEN Source.SCDVERSION IS NULL THEN ''1900-01-01 00:00:00'' ELSE 	Source.SCDStartDate END SCDStartDate, 
		SCDEndDate,
		SCDActiveFlag,
		COALESCE(SCDVERSION,0) + 1 AS SCDVERSION,'
		+@SCDLOVRecordSourceId+' SCDLOVRecordSourceId,'
		+@serveETLRunLogID+' ETLRunLogId,
		PSARowKey 
		FROM 
			(SELECT * FROM ser.TempIntStore_PartyRoleSiteRoleRelationshipPartA_STG  )Source') 
			
PRINT 'Info: PartyRoleSiteRoleRelationship Table For Part I Loaded Successfully'; 
/********************************************************************************************************************************
8.	Table Name  :PartyRoleSiteRoleRelationship  Part II
**********************************************************************************************************************************/
PRINT '****************************** INFO: PartyRoleSiteRoleRelationship  LOADING*************************'
exec('INSERT INTO ser.TempIntStore_PartyRoleSiteRoleRelationship_STG
SELECT 
		CASE WHEN prsr.siteroleid is null AND prsr.partyroleId IS NULL AND prsr.lovRelationshipTypeId IS NULL 
					AND prsr.lovrecordsourceid IS NULL THEN 0 ELSE 1 END ExistsFlag,
		STG.partyroleId,
		STG.siteroleId, 
		STG.RelationshipTypeId,				
		NULL,
		NULL,		
		STG.lovrecordsourceId ,
		CONVERT(DATETIME,STG.SCDStartDate) SCDStartDate,
		LEAD(CONVERT(DATETIME,STG.SCDSTARTDate),1,CONVERT(DATETIME,''99991231'')) 
		OVER(PARTITION BY STG.siteroleid,STG.partyroleId,STG.RelationshipTypeId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate ASC) SCDEndDate,
		LEAD(''N'', 1,''Y'') 
		OVER(PARTITION BY STG.siteroleid,STG.partyroleId,STG.RelationshipTypeId,STG.lovrecordsourceId ORDER BY STG.SCDStartDate) AS SCDActiveFlag,
		prsr.SCDVersion SCDVersion,		
		row_id 
			FROM 
			( 
					SELECT '+@RelationshipTypeId2+' RelationshipTypeId,
						store.SourceKey,
						partyrole.partyroleId,
						siterole.siteroleId, 						
						store.date_added SCDStartDate,
						store.record_source_id lovrecordsourceId,
						store.row_id FROM 
							(
							SELECT 
								store_number, 
								'+@heritage_company+' SourceKey,
								record_source_id ,
								
								'+@date_added+' date_added, 
								row_id FROM '+ @tableName+ ' WHERE  Row_status='+@PSARowStatus+' AND 
						etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','',''))
						) store
					join ser.partyrole on partyrole.SourceKey=store.SourceKey 
						AND partyrole.lovrecordsourceId=store.record_source_id AND partyrole.SCDActiveFlag=''Y''
						AND partyrole.lovroleid='+@RetailerRoleId+' AND store.SourceKey IS NOT NULL AND LEN(TRIM(store.SourceKey))>0 
					join ser.siterole on siterole.SourceKey =store.store_number 
						AND siterole.lovrecordsourceId=store.record_source_id AND siterole.SCDActiveFlag=''Y'')STG
		LEFT JOIN ser.PartyRoleSiteRoleRelationship prsr 
				ON   prsr.siteroleid=STG.siteroleid AND prsr.partyroleId=STG.partyroleId 
					AND prsr.LOVRelationshipTypeId='+@RelationshipTypeId2+' 
					AND prsr.lovrecordsourceid=STG.lovrecordsourceId 
					AND prsr.SCDActiveFlag=''Y''')



exec('
UPDATE ser.PartyRoleSiteRoleRelationship 
	SET SCDActiveFlag= ''N'',  
	SCDEndDate=INS.SCDStartDate 
		FROM ser.PartyRoleSiteRoleRelationship SRInd 
			JOIN 
				(SELECT * FROM ser.TempIntStore_PartyRoleSiteRoleRelationship_STG STG  WHERE STG.SCDActiveFlag=''Y'' AND STG.existsFlag=1 )INS
					ON SRInd.SiteRoleId=INS.SiteRoleId 
					AND SRInd.partyroleId=INS.partyroleId
					AND SRInd.SCDActiveFlag=''Y'' 
					AND SRInd.lovRelationshipTypeId=INS.lovRelationshipTypeId 
					AND SRInd.lovRecordSourceId=INS.lovRecordSourceId')


exec('
INSERT INTO [ser].[PartyRoleSiteRoleRelationship]
           ([PartyRoleId]
           ,[SiteRoleId]
           ,[LOVRelationshipTypeId]
           ,[EffectiveFrom]
           ,[EffectiveTo]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])
	SELECT 
		PartyRoleId,
		SiteRoleId,
		LovRelationshipTypeId, 
		EffectiveFrom,
		EffectiveTo,
		LOVRecordSourceId,
		CASE WHEN Source.SCDVERSION IS NULL THEN ''1900-01-01 00:00:00'' ELSE 	Source.SCDStartDate END SCDStartDate, 
		SCDEndDate,
		SCDActiveFlag,
		COALESCE(SCDVERSION,0) + 1 AS SCDVERSION,'
		+@SCDLOVRecordSourceId+' SCDLOVRecordSourceId,'
		+@serveETLRunLogID+' ETLRunLogId,
		PSARowKey 
		FROM 
			(SELECT * FROM ser.TempIntStore_PartyRoleSiteRoleRelationship_STG  where SCDActiveFlag=''Y'')Source') 
			
PRINT 'Info: PartyRoleSiteRoleRelationship Table for Part II Loaded Successfully'; 

/********************************************************************************************************************************
9.	Table Name  :SiteRoleProperty
**********************************************************************************************************************************/

PRINT '****************************** INFO: SiteRoleProperty  LOADING*************************'

exec(  'INSERT INTO  ser.TmpIntStore_SiteRoleProp_STG SELECT Src.ExistsFlag,Src.SiteRoleId,Src.PGCol,Src.MeasureId,Src.UOMID LOVUOMId,Src.Value,Src.LOVRecordSourceId,
Src.SCDStartDate,Src.SCDEndDate,Src.SCDActiveFlag,Src.SCDVersion,Src.PSARowKey 
   FROM (
	SELECT CASE WHEN SRG.SiteRoleId is  NULL AND SRG.MeasureId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag,
	pvt.SiteRoleId, pvt.PGCol,pvt.MeasureId,pvt.UOMID,  pvt.Value,pvt.LOVRecordSourceId, CONVERT(DATETIME,pvt.date_added )SCDStartDate,
	LEAD(pvt.date_added,1,CONVERT(DATETIME,''99991231'') )OVER(PARTITION BY pvt.SiteRoleId,pvt.MeasureId,pvt.LOVRecordSourceId ORDER BY pvt.date_added ASC)	AS SCDEndDate,
				 LEAD(''N'', 1,''Y'') OVER(PARTITION BY pvt.SiteRoleId,pvt.MeasureId,pvt.LOVRecordSourceId ORDER BY date_added ASC) SCDActiveFlag,
				 COALESCE(SRG.SCDVersion,0) SCDVersion
				 ,pvt.PSARowKey
				 FROM
(SELECT SiteRoleId,
							PGCol,
							Case When PGCol =''store_ndsa'' Then (SELECT Measure.MeasureId FROM ser.Measure WHERE MeasureName = ''store_ndsa''
							AND Measure.lovrecordsourceId = record_source_id 
							AND Measure.lovmeasuretypeid= '+@LOVFloorAreaMeasureTypeId+'  
							AND Measure.lovdatatypeid='+ @LOVDataTypeId+' )
							When PGCol =''store_size'' Then (SELECT Measure.MeasureId FROM ser.Measure WHERE MeasureName = ''store_size''
							AND Measure.lovrecordsourceId = record_source_id AND Measure.lovmeasuretypeid= '+@LOVFloorAreaMeasureTypeId+' 
		and Measure.lovdatatypeid='+ @LOVDataTypeId+')
							When PGCol =''latitude'' Then (SELECT Measure.MeasureId FROM ser.Measure WHERE MeasureName = ''latitude''
							AND Measure.lovrecordsourceId = record_source_id AND Measure.lovmeasuretypeid= '+@LOVGeoCodeMeasureTypeId+' 
		and Measure.lovdatatypeid='+ @LOVDataTypeId+')
							 When PGCol =''longitude'' Then (SELECT Measure.MeasureId FROM ser.Measure WHERE MeasureName = ''longitude''
							AND Measure.lovrecordsourceId = record_source_id AND Measure.lovmeasuretypeid= '+@LOVGeoCodeMeasureTypeId+' 
		and Measure.lovdatatypeid='+ @LOVDataTypeId+')
							  
							 END AS MeasureId,
							
							Case When PGCol =''store_ndsa'' 
							Then '+@UOMID2 +' When PGCol =''store_size'' 
							Then '+@UOMID1+' When PGCol =''latitude''
							Then '+@UOMID3+'  When	 PGCol =''longitude'' 
							Then '+@UOMID3+'  End AS  UOMID,
							
												
							PGValue  Value ,							
							record_source_id LOVRecordSourceId,
							date_added  ,	
							PSARowKey FROM (SELECT
						sr.SiteRoleID,	
						CASE WHEN '''+ @CountryCode +''' in (''NO'')  THEN (SELECT cast(replace(region_code ,'','',''.'') as nvarchar))												
						ELSE store_ndsa END store_ndsa,					
						
					
						CASE WHEN '''+ @CountryCode +''' in (''NO'') THEN (SELECT cast(replace(store_ndsa ,'','',''.'') as nvarchar))	
						ELSE store_size END store_size
						
						,CASE WHEN '''+ @CountryCode +''' in (''NO'') THEN cast(longitude as nvarchar) ELSE latitude END latitude
                        ,CASE WHEN '''+ @CountryCode +''' in (''NO'') THEN cast(close_date as nvarchar)  ELSE longitude END longitude						
						,store.record_source_id record_source_id
						,'+@date_added+'	date_added
						,store.row_id PSARowKey
				FROM '+ @tableName+ '  store
				INNER JOIN
				ser.SiteRole sr on sr.lovrecordsourceid = store.record_source_id and sr.SourceKey=store.store_number AND
				sr.SCDActiveFlag=''Y'' AND	store.Row_status='+@PSARowStatus+' AND 
						store.etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','','')) 
				) pg
								UNPIVOT  
							( PGValue FOR PGCol IN ( pg.store_ndsa
													,pg.store_size
													,pg.latitude
													,pg.longitude
													)
							)	AS LOVGroupId ) pvt  LEFT JOIN ser.SiteRoleProperty SRG  on pvt.SiteRoleId=SRG.SiteRoleId AND 
			pvt.MeasureId=SRG.MeasureId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId AND SRG.SCDActiveFlag=''Y'' )Src  
WHERE Src.Value is not NULL AND Src.Value <> ''NULL'' AND LEN(TRIM(Src.Value)) >0 AND Src.SCDActiveFlag=''Y''')
			
exec('
UPDATE ser.SiteRoleProperty SET SCDActiveFlag= ''N'',  SCDEndDate=INS.SCDStartDate 
FROM ser.SiteRoleProperty SRGrp JOIN 
(SELECT *         					
 FROM ser.TmpIntStore_SiteRoleProp_STG STAGE  WHERE STAGE.SCDActiveFlag=''Y'' AND STAGE.existsFlag=1 )INS
ON 
SRGrp.SiteRoleId=INS.SiteRoleId AND SRGrp.MeasureId=INS.MeasureId
AND SRGrp.SCDActiveFlag=''Y'' AND SRGrp.lovRecordSourceId=INS.lovRecordSourceId')

exec('INSERT INTO ser.SiteRoleProperty ([SiteRoleId] ,[MeasureId],[LOVUOMId] ,[Value],[LOVRecordSourceId] ,[SCDStartDate] , [SCDEndDate] ,
 [SCDActiveFlag] , [SCDVersion],[SCDLOVRecordSourceId] ,[ETLRunLogId] ,PSARowKey)
 
 SELECT STAGE.[SiteRoleId] ,
 STAGE.[MeasureId],STAGE.[LOVUOMId] ,
 STAGE.[Value],STAGE.[LOVRecordSourceId] ,CASE WHEN STAGE.SCDVERSION=0 THEN ''1900-01-01 00:00:00'' ELSE STAGE.SCDStartDate END SCDStartDate, STAGE.SCDEndDate,				 
 STAGE.[SCDActiveFlag] , STAGE.SCDVersion +1 ,'+@SCDLOVRecordSourceId+' SCDLOVRecordSourceId,'
 +@serveETLRunLogId+'  ETLRunLogId,STAGE.PSARowKey FROM (
SELECT *  FROM ser.TmpIntStore_SiteRoleProp_STG    STG WHERE STG.SCDActiveFlag=''Y'' )STAGE
')

PRINT 'Info: SiteRoleProperty Table Loaded Successfully ';  

/********************************************************************************************************************************
10.	Table Name  :SiteRoleTerritory
**********************************************************************************************************************************/

--For Norway , Region code is not added to table(Mapping sheet change 2.2), hence keeping NULL as region_code
PRINT '****************************** INFO: SiteRoleTerritory  LOADING*************************'
exec( ' INSERT INTO  ser.TmpIntStore_SiteRoleTerritory_STG 
SELECT ExistsFlag,SiteRoleId ,PGCol , LOVSiteRoleTerritorySetId,LOVTerritoryId , LOVRecordSourceId ,SCDStartDate 
,SCDEndDate ,SCDActiveFlag ,SCDVersion, PSARowKey FROM (
 
				SELECT 
				CASE WHEN SRG.SiteRoleId is  NULL AND SRG.LOVSiteRoleTerritorySetId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag,
				pvt.SiteRoleId, pvt.PGCol,pvt.Value, pvt.LOVSiteRoleTerritorySetId,pvt.LOVTerritoryId, pvt.LOVRecordSourceId, pvt.date_added SCDStartDate,
				LEAD(pvt.date_added,1,CONVERT(DATETIME,''99991231'') )OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVSiteRoleTerritorySetId,pvt.LOVRecordSourceId ORDER BY pvt.date_added ASC) SCDEndDate,
				 LEAD(''N'', 1,''Y'') OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVSiteRoleTerritorySetId,pvt.LOVRecordSourceId ORDER BY pvt.date_added ASC) SCDActiveFlag,
				 COALESCE(SRG.SCDVersion,0) SCDVersion,pvt.PSARowKey
				 FROM
				 (
                    SELECT 
							SiteRoleId,
							PGCol,
							Case When PGValue is not null Then (SELECT r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = PGValue AND 
												r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName =PGCol
												and rs.LOVSetRecordSourceID = record_source_id)) End AS  LOVTerritoryId,
											
							(SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = PGCol AND
										rs.LOVSetRecordSourceID = record_source_id) LOVSiteRoleTerritorySetId,
							PGValue  Value ,							
							record_source_id LOVRecordSourceId,
							date_added  ,	
							
							PSARowKey
				 FROM
				(SELECT
						 SiteRoleID		
						,area_code
						,district_code
						,CASE WHEN '''+ @CountryCode +''' in (''NO'') THEN NULL ELSE region_code END region_code	
						,store.record_source_id 
						,'+@date_added+'	date_added		
						,store.row_id PSARowKey
				FROM '+ @tableName+ '   store
				INNER JOIN
				ser.SiteRole sr on sr.lovrecordsourceid = store.record_source_id and sr.SourceKey=store.store_number
				and sr.SCDActiveFlag=''Y'' AND	store.Row_status='+@PSARowStatus+' AND 
						store.etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','',''))
				) pg
								UNPIVOT  
							( PGValue FOR PGCol IN ( pg.area_code
													,pg.district_code
													,pg.region_code
													)
							)	AS LOVGroupId  
							) pvt
							LEFT JOIN ser.SiteRoleTerritory SRG  on pvt.SiteRoleId=SRG.SiteRoleId AND 
			pvt.LOVSiteRoleTerritorySetId=SRG.LOVSiteRoleTerritorySetId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId AND SRG.SCDActiveFlag=''Y'' 
			)Src  
WHERE Src.Value is not NULL AND Src.Value <> ''NULL'' AND LEN(TRIM(Src.Value)) >0 AND Src.SCDActiveFlag=''Y''')

						
exec('
UPDATE ser.SiteRoleTerritory SET SCDActiveFlag= ''N'',  SCDEndDate=INS.SCDStartDate 
FROM ser.SiteRoleTerritory SRGrp JOIN 
(
SELECT * FROM ser.TmpIntStore_SiteRoleTerritory_STG  STAGE  WHERE STAGE.SCDActiveFlag=''Y'' AND STAGE.existsFlag=1 )INS
ON 
SRGrp.SiteRoleId=INS.SiteRoleId AND SRGrp.LOVSiteRoleTerritorySetId=INS.LOVSiteRoleTerritorySetId
AND SRGrp.SCDActiveFlag=''Y'' AND SRGrp.lovRecordSourceId=INS.lovRecordSourceId')



exec('INSERT INTO ser.SiteRoleTerritory ([SiteRoleId] ,[LOVSiteRoleTerritorySetId] ,[LOVTerritoryId]
           ,[LOVRecordSourceId] ,[SCDStartDate] ,[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId]
           ,[ETLRunLogId] ,[PSARowKey])
 
 SELECT STAGE.[SiteRoleId] ,
 STAGE.[LOVSiteRoleTerritorySetId],STAGE.[LOVTerritoryId] ,
 STAGE.[LOVRecordSourceId],CASE WHEN STAGE.SCDVERSION=0 THEN ''1900-01-01 00:00:00'' ELSE STAGE.SCDStartDate END SCDStartDate ,STAGE.[SCDEndDate] , STAGE.SCDActiveFlag,				 
 STAGE.SCDVersion +1 ,'+@SCDLOVRecordSourceId+' SCDLOVRecordSourceId,'
 +@serveETLRunLogId+'  ETLRunLogId,STAGE.PSARowKey FROM (
SELECT *  FROM ser.TmpIntStore_SiteRoleTerritory_STG    STG WHERE STG.SCDActiveFlag=''Y'' )STAGE
')

PRINT 'Info: SiteRoleTerritory Table Loaded Successfully';  


/********************************************************************************************************************************
11.	Table Name  :SiteRoleGroup
**********************************************************************************************************************************/
PRINT '****************************** INFO: SiteRoleGroup  LOADING*************************'
exec(  'INSERT INTO  ser.TempIntStore_SiteRoleGroup_STG  SELECT  ExistsFlag ,SiteRoleGroupId ,  [SiteRoleId] ,PGCol ,[LOVSiteRoleGroupSetId],[LOVGroupId] ,[ParentSiteRoleGroupId],[LOVRecordSourceId] 
, [SCDStartDate], [SCDEndDate] ,[SCDActiveFlag] ,[SCDVersion],[PSARowKey] FROM(
SELECT 
CASE WHEN SRG.SiteRoleId is  NULL AND SRG.LOVSiteRoleGroupSetId IS NULL AND SRG.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag,
SRG.SiteRoleGroupId,pvt.SiteRoleId, pvt.PGCol,pvt.PGValue,pvt.LOVSiteRoleGroupSetId,pvt.LOVGroupId,NULL as ParentSiteRoleGroupId, pvt.LOVRecordSourceId, CONVERT(DATETIME,pvt.date_added) SCDStartDate,
LEAD(CONVERT(DATETIME,pvt.date_added), 1,CONVERT(DATETIME,''99991231'')) 
OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVSiteRoleGroupSetId,pvt.LOVRecordSourceId ORDER BY pvt.date_added ASC) SCDEndDate,
LEAD(''N'', 1,''Y'') OVER(PARTITION BY pvt.SiteRoleId,pvt.LOVSiteRoleGroupSetId,pvt.LOVRecordSourceId ORDER BY pvt.date_added ASC) SCDActiveFlag,

COALESCE(SRG.SCDVERSION,0) SCDVERSION,row_id PSARowKey
FROM
(
SELECT 
SiteRoleId,
PGCol,
PGValue,
(CASE 
WHEN PGCol in (''store_format'')  THEN
(SELECT r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = PGValue AND 
r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = PGCol 
and rs.LOVSetRecordSourceID =record_source_id) )
WHEN PGCol in (''store_loc'') THEN
(SELECT r.LOVId FROM ser.RefLOV r WHERE r.LOVKey = PGValue AND 
r.LOVSetId = (SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = PGCol 
and rs.LOVSetRecordSourceID =record_source_id))

END ) LOVGroupId, 
(CASE 
WHEN PGCol in (''store_format'') THEN
(SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = PGCol AND
rs.LOVSetRecordSourceID = record_source_id) 
WHEN PGCol in (''store_loc'') THEN
(SELECT LOVSetId FROM ser.RefLOVSet rs WHERE  rs.LOVSetName = PGCol AND
rs.LOVSetRecordSourceID = record_source_id ) 

END ) LOVSiteRoleGroupSetId,
PGValue  value , 
record_source_id LOVRecordSourceId,
date_added  ,                            

row_id
FROM
(SELECT
SiteRoleID 
,'+@store_format+' store_format
,'+@store_loc+' store_loc 
,store.record_source_id 
,'+@date_added+' date_added
,store.row_id 
FROM '+ @tableName+ ' store 
INNER JOIN
ser.SiteRole sr on sr.lovrecordsourceid = store.record_source_id and sr.SourceKey=store.store_number AND sr.SCDActiveFlag=''Y''
AND store.Row_status='+@PSARowStatus+' AND store.etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','',''))) pg
UNPIVOT  
( PGValue FOR PGCol IN ( pg.store_format
,pg.store_loc
)
) AS LOVGroupId  ) pvt LEFT JOIN ser.SiteRoleGroup SRG  on pvt.SiteRoleId=SRG.SiteRoleId AND 
pvt.LOVSiteRoleGroupSetId=SRG.LOVSiteRoleGroupSetId AND pvt.LOVRecordSourceId=SRG.LOVRecordSourceId AND SRG.SCDActiveFlag=''Y'')Src  
WHERE Src.PGValue is not NULL AND Src.PGValue <> ''NULL'' AND LEN(TRIM(Src.PGValue)) >0 AND Src.SCDActiveFlag=''Y''')
			
			
exec('
UPDATE ser.SiteRoleGroup SET SCDActiveFlag= ''N'',  SCDEndDate=INS.SCDStartDate 
FROM ser.SiteRoleGroup SRGrp JOIN 
(SELECT * FROM ser.TempIntStore_SiteRoleGroup_STG STAGE WHERE STAGE.existsFlag=1 )INS
ON 
SRGrp.SiteRoleId=INS.SiteRoleId AND SRGrp.LOVSiteRoleGroupSetId=INS.LOVSiteRoleGroupSetId
AND SRGrp.SCDActiveFlag=''Y'' AND SRGrp.lovRecordSourceId=INS.lovRecordSourceId')
	

			exec('INSERT INTO [ser].[SiteRoleGroup]
           ([SiteRoleGroupId]
           ,[SiteRoleId]
           ,[LOVSiteRoleGroupSetId]
           ,[LOVGroupId]
           ,[ParentSiteRoleGroupId]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])
			SELECT  
			CASE WHEN INS.existsFlag=1 THEN INS.SiteRoleGroupId
			ELSE ROW_NUMBER() OVER(ORDER BY INS.SiteRoleId,LOVSiteRoleGroupSetId,LOVRecordSourceId ASC)+'+@MAXSRGpID+' END  SiteRoleGroupId,
			        INS.SiteRoleId,
					LOVSiteRoleGroupSetId,
					LOVGroupId,					
					ParentSiteRoleGroupId,
					LOVRecordSourceId,
					CASE WHEN INS.SCDVERSION=0 THEN ''1900-01-01 00:00:00'' ELSE INS.SCDStartDate END SCDStartDate,	
					SCDEndDate,					
					SCDActiveFlag         ,
				    INS.SCDVERSION + 1 AS SCDVERSION,'
					+@SCDLOVRecordSourceId+'   SCDLOVRecordSourceId,'
					+@serveETLRunLogId+'  ETLRunLogId,INS.PSARowKey
			FROM  
			(SELECT * FROM ser.TempIntStore_SiteRoleGroup_STG STG )INS
			
			')

		
			PRINT 'Info: SiteRoleGroup Table Loaded Successfully';  
			
/********************************************************************************************************************************
11.	Table Name  :SiteRoleStatus
**********************************************************************************************************************************/

PRINT 'Info: SiteRoleStatus Table Loaded Successfully*******************************';  
-- opendate and closedate are both null ignore that record
-- opendate alone is present , openstatus with eff from as opendate
-- closedate alone is present, closestatus with eff from as closedate
-- both are present, Openstatus and effFrom-opendate and effTo-closedate


exec(' INSERT INTO ser.TempIntStore_SiteRoleStatus_STG
SELECT ExistsFlag, siteroleid, LOVSiteRoleStatusSetId,StatusId,EffectiveFrom,EffectiveTo,open_date,close_date,record_source_id,SCDStartDate,SCDEndDate,
SCDActiveFlag,SCDVersion, PSARowkey   FROM (
SELECT CASE WHEN SRStatus.SiteRoleId IS NULL AND SRStatus.LOVSiteRoleStatusSetId IS NULL AND SRStatus.LOVRecordSourceId IS NULL THEN 0 ELSE 1 END ExistsFlag,
 sr.siteroleid, store.LOVSiteRoleStatusSetId, store.StatusId, store.EffectiveFrom, store.EffectiveTo,store.open_date,store.close_date,store.record_source_id,CONVERT(DATETIME,store.date_added) SCDStartDate,LEAD(CONVERT(DATETIME,store.date_added), 1,CONVERT(DATETIME,''99991231'')) 
OVER(PARTITION BY sr.siteroleid,store.LOVSiteRoleStatusSetId,store.record_source_id ORDER BY CONVERT(DATETIME,store.date_added) ASC) AS SCDEndDate,
LEAD(''N'', 1,''Y'') OVER(PARTITION BY sr.siteroleid,store.LOVSiteRoleStatusSetId,store.record_source_id ORDER BY CONVERT(DATETIME,store.date_added) ASC) AS SCDActiveFlag, 
SRStatus.scdversion,   store.row_id PSARowKey   FROM (
SELECT  store_number,
'+ @open_date+' open_date,
 '+@close_date+' close_date,'
+@LOVSiteRoleStatusSetId+' LOVSiteRoleStatusSetId,
CASE When (('+@open_date+' is NULL OR '+@open_date+'  = ''NULL'' OR LEN('+@open_date+') =0 )
AND ('+@close_date+' is NULL OR '+@close_date+'  = ''NULL'' OR LEN('+@close_date+') =0 )) Then NULL
When ('+@open_date+' is NOT NULL AND '+@open_date+'  <> ''NULL'') and
 LEN('+@open_date+') >0 and ('+@close_date+' is NOT NULL AND '+@close_date+'  <> ''NULL'') 
 and LEN('+@close_date+') >0 Then '+@OpenStatus+' When 
 ('+@open_date+' is NOT NULL AND '+@open_date+'  <> ''NULL'') and LEN('+@open_date+') >0  
and ('+@close_date+' is NULL OR '+@close_date+'  = ''NULL'' OR  LEN('+@close_date+') =0) Then '+@OpenStatus+' 
When ('+@open_date+' is NULL OR '+@open_date+'  = ''NULL'' OR LEN('+@open_date+') =0 ) 
and ('+@close_date+' is NOT NULL AND '+@close_date+'  <> ''NULL'') and LEN('+@close_date+') >0 Then '+@ClosedStatus+'

END AS StatusId,

CASE When (('+@open_date+' is NULL OR '+@open_date+'  = ''NULL'' OR LEN('+@open_date+') =0 )
AND ('+@close_date+' is NULL OR '+@close_date+'  = ''NULL'' OR LEN('+@close_date+') =0 )) Then NULL
When ('+@open_date+' is NOT NULL AND '+@open_date+'  <> ''NULL'') and
 LEN('+@open_date+') >0 and ('+@close_date+' is NOT NULL AND '+@close_date+'  <> ''NULL'') 
 and LEN('+@close_date+') >0 Then (CONVERT(DATETIME,'+@open_date+')) 
When ('+@open_date+' is NOT NULL AND '+@open_date+'  <> ''NULL'') and LEN('+@open_date+') >0  
and ('+@close_date+' is NULL OR '+@close_date+'  = ''NULL'' OR  LEN('+@close_date+') =0) Then (CONVERT(DATETIME,'+@open_date+')) 
When ('+@open_date+' is NULL OR '+@open_date+'  = ''NULL'' OR LEN('+@open_date+') =0 ) 
and ('+@close_date+' is NOT NULL AND '+@close_date+'  <> ''NULL'') and LEN('+@close_date+') >0 Then (CONVERT(DATETIME,'+@close_date+'))
END AS EffectiveFrom,

CASE 
When (('+@open_date+' is NULL OR '+@open_date+'  = ''NULL'' OR LEN('+@open_date+') =0 )
AND ('+@close_date+' is NULL OR '+@close_date+'  = ''NULL'' OR LEN('+@close_date+') =0 )) Then NULL
When ('+@open_date+' is NOT NULL AND '+@open_date+'  <> ''NULL'') and LEN('+@open_date+') >0
and ('+@close_date+' is NOT NULL AND '+@close_date+'  <> ''NULL'') and LEN('+@close_date+') >0 Then (CONVERT(DATETIME,'+@close_date+')) 
When ('+@open_date+' is NOT NULL AND '+@open_date+'  <> ''NULL'') and LEN('+@open_date+') >0  
and ('+@close_date+' is NULL OR '+@close_date+'  = ''NULL'' OR  LEN('+@close_date+') =0) Then NULL 
When ('+@open_date+' is NULL OR '+@open_date+'  = ''NULL'' OR LEN('+@open_date+') =0 ) and 
('+@close_date+' is NOT NULL AND '+@close_date+'  <> ''NULL'') and LEN('+@close_date+') >0 Then NULL
END AS EffectiveTo ,
record_source_id, row_id , '+@date_added+' date_added 
from '+ @tableName+ ' 
where ( Row_status='+@PSARowStatus+' 
AND etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','','')))

 )store
join ser.siterole sr on sr.sourcekey = store.store_number  and 
sr.lovrecordsourceid = store.record_source_id AND sr.SCDActiveFlag=''Y''
left join ser.siterolestatus SRStatus ON  SRStatus.SiteRoleId=sr.SiteRoleId AND SRStatus.LOVSiteRoleStatusSetId=store.LOVSiteRoleStatusSetId
AND SRStatus.LOVRecordSourceId=store.record_source_id AND SRStatus.SCDActiveFlag=''Y''
) staging where staging.SCDActiveFlag=''Y'' AND staging.StatusId IS NOT NULL
')

-- to insert an additional closed status for records for which both opendate and closedate is present
exec('INSERT INTO ser.TempIntStore_SiteRoleStatus_STG
SELECT ExistsFlag, siteroleid, LOVSiteRoleStatusSetId,
CASE When opendate is NOT NULL AND opendate  <> ''NULL'' and LEN(opendate) >0 and closedate is NOT NULL AND closedate  <> ''NULL'' 
and LEN(closedate) >0 Then '+@ClosedStatus+'  
END AS StatusId,

CASE 
When (opendate is NOT NULL AND opendate  <> ''NULL'') and LEN(opendate) >0
and (closedate is NOT NULL AND closedate  <> ''NULL'') and LEN(closedate) >0 Then closedate 
END AS EffectiveFrom ,

NULL AS  EffectiveTo, opendate,closedate,lovrecordsourceid, SCDStartDate,SCDEndDate, SCDActiveFlag,SCDVersion, PSARowkey 
from ser.TempIntStore_SiteRoleStatus_STG where (opendate is NOT NULL  AND opendate  <> ''NULL'' and LEN(opendate) >0 ) and 
(closedate is NOT NULL AND closedate  <> ''NULL'' and LEN(closedate) >0)

')	

exec('
UPDATE ser.SiteRoleStatus SET SCDActiveFlag= ''N'',  SCDEndDate=INS.SCDStartDate 
FROM ser.SiteRoleStatus SRGrp JOIN 
(SELECT * FROM ser.TempIntStore_SiteRoleStatus_STG STAGE WHERE STAGE.existsFlag=1 )INS
ON 
SRGrp.SiteRoleId=INS.SiteRoleId AND SRGrp.LOVSiteRoleStatusSetId=INS.LOVSiteRoleStatusSetId
AND SRGrp.SCDActiveFlag=''Y'' AND SRGrp.lovRecordSourceId=INS.lovRecordSourceId') 


exec('
INSERT INTO [ser].[SiteRoleStatus]
           ([SiteRoleId]
           ,[LOVSiteRoleStatusSetId]
           ,[LOVStatusId]
           ,[EffectiveFrom]
           ,[EffectiveTo]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
           ,[PSARowKey])
SELECT [SiteRoleId]
           ,[LOVSiteRoleStatusSetId]
           ,[LOVStatusId]
           ,[EffectiveFrom]
           ,[EffectiveTo]
           ,[LOVRecordSourceId]
           ,CASE WHEN STG.SCDVERSION IS NULL THEN ''1900-01-01 00:00:00'' ELSE STG.SCDStartDate END SCDStartDate
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,COALESCE(SCDVERSION,0) + 1 SCDVERSION
           ,'+@SCDLOVRecordSourceId+'   SCDLOVRecordSourceId
		   ,'+@serveETLRunLogId+'  ETLRunLogId
           ,[PSARowKey] FROM ser.TempIntStore_SiteRoleStatus_STG STG WHERE STG.SCDActiveFlag=''Y'' ') 

		   PRINT 'Info: SiteRoleStatus Table Loaded Successfully'; 
		   

/**********************************************************************************************************************************/
PRINT '********************Updating Source Table accordingly ****************';  

 

 

exec ('UPDATE '+ @tableName+ ' SET row_status='+@ServeRowStatus+'
    FROM '+ @tableName+ ' source 
    Inner Join ser.SiteRole sr ON  sr.Sourcekey=source.store_number and source.record_source_id=sr.LovRecordSourceID 
    WHERE source.row_status='+@PSARowStatus+' AND source.etl_runlog_id in (SELECT value FROM STRING_SPLIT('''+@psaETLRunLogID+''','','')) 
	AND sr.ETLRunLogId in (SELECT value FROM STRING_SPLIT('''+@serveETLRunLogID+''','',''))')
        
	 

        PRINT 'Info: Source Table Updated accordingly ';


COMMIT TRANSACTION; 
        END TRY    
        BEGIN CATCH
                    THROW;
                     ROLLBACK TRANSACTION ;
        END CATCH



IF OBJECT_ID('ser.TempIntStore_SiteRole_STG') IS NOT NULL
BEGIN
DROP TABLE ser.TempIntStore_SiteRole_STG
END

IF OBJECT_ID('ser.TempIntStore_SiteRoleIndicator_STG') IS NOT NULL
BEGIN
DROP TABLE ser.TempIntStore_SiteRoleIndicator_STG
END


IF OBJECT_ID('ser.TmpIntStore_SiteRoleProp_STG') IS NOT NULL
BEGIN
DROP TABLE ser.TmpIntStore_SiteRoleProp_STG
END

IF OBJECT_ID('ser.TmpIntStore_SiteRoleTerritory_STG') IS NOT NULL
BEGIN
DROP TABLE ser.TmpIntStore_SiteRoleTerritory_STG
END
IF OBJECT_ID('ser.TempIntStore_SiteRoleGroup_STG') IS NOT NULL
BEGIN
DROP TABLE ser.TempIntStore_SiteRoleGroup_STG
END
IF OBJECT_ID('ser.TempIntStore_SiteRoleStatus_STG') IS NOT NULL
BEGIN
DROP TABLE ser.TempIntStore_SiteRoleStatus_STG
END

IF OBJECT_ID('ser.TempIntStore_PartyRoleSiteRoleRelationship_STG') IS NOT NULL
BEGIN
DROP TABLE ser.TempIntStore_PartyRoleSiteRoleRelationship_STG
END

IF OBJECT_ID('ser.TempIntStore_PartyRoleSiteRoleRelationshipPartA_STG') IS NOT NULL
BEGIN
DROP TABLE ser.TempIntStore_PartyRoleSiteRoleRelationshipPartA_STG
END



END
GO
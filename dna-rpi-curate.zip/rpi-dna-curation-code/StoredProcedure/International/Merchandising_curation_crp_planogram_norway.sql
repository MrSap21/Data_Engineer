SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.[SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_NORWAY_HISTORY]') IS NOT NULL
BEGIN
    DROP PROC psa.[SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_NORWAY_HISTORY]
END
GO

CREATE PROCEDURE [psa].[SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_NORWAY_HISTORY] @psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max) AS
/*
************************************************************************************************************
Procedure Name				: [SP_MERCHANDISING_CURATION_CRP_PLANOGRAM_NORWAY_HISTORY]
Purpose						: Load History data From International Norway Source(rawno_crp_planogram) into Serve Layer Table
Domain						: Merchandise
ServeLayer Target Tables	: Fact Instance, Fact Dimension Instance, Fact Measure Instance (Total 3 Tables)
RecordSourceID  for International Norway : 12005
*****************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  151 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
 */ 

BEGIN

	/*--Declarations---*/
	DECLARE @max_FactInstanceId BIGINT;
	DECLARE @rowStatusPSACode BIGINT;	
	DECLARE	@rowStatusSERCode BIGINT;
	DECLARE @measureTypeIdPlanoAggr BIGINT;

	SET @rowStatusPSACode = 26001
	SET @rowStatusSERCode = 26002 
	SET @measureTypeIdPlanoAggr = (SELECT rl.LOVId FROM  ser.RefLOV rl INNER JOIN ser.RefLOVSet rls ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid 
	AND rls.LOVsetName='Measure Type' and rls.Lovsetrecordsourceid = 12012 AND rl.LOVKey = 'PLANOGRAM_AGGREGATION');
	/*--Identify maximum value of surrogate keys from existing tables--*/
	SELECT @max_FactInstanceId = COALESCE(MAX(FactInstanceId),0) FROM [ser].[FactInstance];

	
	
	/*-------------------------------Create temporary source table-------------------------------*/
	
		IF OBJECT_ID('tempdb..#rawno_crp_planogram_temp') is not null
		BEGIN
			DROP TABLE #rawno_crp_planogram_temp
		END

	SELECT
	@max_FactInstanceId + (ROW_NUMBER() OVER(ORDER BY (SELECT NULL))) AS FactInstanceId
    ,*
	INTO #rawno_crp_planogram_temp
	FROM (SELECT * from [psa].[rawno_crp_planogram] where [row_status]=@rowStatusPSACode and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')))a
	;


BEGIN TRANSACTION;
BEGIN TRY

	/*--------------------------------Loading Fact Instance table---------------------------------*/
	INSERT INTO [ser].[FactInstance]
	(
	[FactInstanceId]
    ,[FactId]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[FactInstanceId]
		,[FactId]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,[SCDEndDate]
		,[SCDActiveFlag]
		,[SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_fact.FactId AS [FactId]
			,12005 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,'9999-12-31 00:00:00' AS [SCDEndDate]
			,'Y' AS [SCDActiveFlag]
			,1 AS [SCDVersion]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #rawno_crp_planogram_temp src
			LEFT OUTER JOIN
			(
				SELECT 
				rlrls.LOVId
				,rlrls.LOVKey
				,rlrls.LOVRecordSourceId
				,f.FactId 
				FROM  ser.fact f
				INNER JOIN 
				(
					SELECT 
					rl.LOVId
					,rl.LOVKey
					,rl.LOVRecordSourceId
					FROM ser.RefLOV rl 
					INNER JOIN ser.RefLOVSet rls 
					ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='Fact Type' and rls.Lovsetrecordsourceid = 12012
				) rlrls
				ON rlrls.LOVKey = 'TBC' AND f.LOVFactTypeId = rlrls.LOVId AND f.FactName = 'CRP Planogram' and f.LOVRecordSourceId = 12005
			) lkp_fact
			ON  lkp_fact.LOVRecordSourceId = 12012
			
		)a;
		
		RAISERROR ('Completed insertion of International Norway source data to FACT INSTANCE table', 0, 1) WITH NOWAIT	
	
	/*--------------------------------Loading Fact Dimension Instance table---------------------------------*/
	
	DECLARE @sourcekeytypeid bigint;
	SET @sourcekeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey =  'Norway Planogram Id(pog_id)' and rlovset.LOVsetname = 'Source Key Type');
	
	INSERT INTO [ser].[FactDimensionInstance]
	([FactInstanceId]
    ,[DimensionId]
    ,[DimensionSurrogateKey]
    ,[DimensionSourceKey]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[FactInstanceId]
		,[DimensionId]
		,[DimensionSurrogateKey]
		,[DimensionSourceKey]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY FactInstanceId,DimensionId ORDER BY SCDStartDate ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_dim.DimensionId AS [DimensionId]
			,lkp_plan.PlanogramId AS [DimensionSurrogateKey]
			,cast(src.pog_id as varchar(80)) AS [DimensionSourceKey]
			,12005 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM 
			#rawno_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[dimension] lkp_dim
			ON (lkp_dim.name =  'Planogram' AND  lkp_dim.LOVRecordSourceId = 12005)
			LEFT OUTER JOIN
			(select * from [ser].[planogram] where SCDActiveFlag='Y' and Lovrecordsourceid=12005 and lovsourcekeytypeid = @sourcekeytypeid) lkp_plan
			ON (lkp_plan.SourceKey = src.pog_id AND lkp_plan.LOVRecordSourceId = 12005)
			
			UNION
			
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_dim.DimensionId AS [DimensionId]
			,lkp_prod.ProductId AS [DimensionSurrogateKey]
			,cast(src.item_code as varchar(80)) AS [DimensionSourceKey]
			,12005 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM 
			#rawno_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[dimension] lkp_dim
			ON (lkp_dim.name =  'Product' AND  lkp_dim.LOVRecordSourceId = 12005)
			LEFT OUTER JOIN
			(select * from [ser].[product] where SCDActiveFlag = 'Y') lkp_prod
			ON (lkp_prod.SourceKey = cast(src.item_code as varchar(30)) AND lkp_prod.LOVRecordSourceId = 12005)
			
			UNION
			
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_dim.DimensionId AS [DimensionId]
			,lkp_refl.LOVId AS [DimensionSurrogateKey]
			,cast(src.week as varchar(80)) AS [DimensionSourceKey]
			,12005 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM 
			#rawno_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[dimension] lkp_dim
			ON (lkp_dim.name =  'Week' AND  lkp_dim.LOVRecordSourceId = 12005)
			LEFT OUTER JOIN
			(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.RefLOV rl JOIN ser.RefLOVSet rls 
			ON rl.LOVSetID = rls.LOVSetID AND rl.Lovrecordsourceid = rls.Lovsetrecordsourceid AND rls.LOVsetName='week' and rls.Lovsetrecordsourceid = 12005) lkp_refl
			ON CAST(src.week AS varchar(255))  = lkp_refl.LOVKey 
		)a
		;
		
		RAISERROR ('Completed insertion of International Norway source data to FACT DIMENSION INSTANCE table', 0, 1) WITH NOWAIT
	/*--------------------------------Loading Fact Measure Instance table---------------------------------*/
	
	INSERT INTO [ser].[FactMeasureInstance]
	(
	 [FactInstanceId]
    ,[MeasureId]
    ,[Value]
	,[LOVRecordSourceId]
    ,[SCDStartDate]
    ,[SCDEndDate]
    ,[SCDActiveFlag]
    ,[SCDVersion]
    ,[SCDLOVRecordSourceId]
    ,[ETLRunLogId]
	,[PSARowKey]
	)
		SELECT
		[FactInstanceId]
		,[MeasureId]
		,[Value]
		,[LOVRecordSourceId]
		,[SCDStartDate]
		,LEAD(SCDStartDate,1,'9999-12-31 00:00:00') OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY SCDStartDate ASC) AS [SCDEndDate]
		,LEAD('N',1,'Y') OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY [SCDStartDate] ASC) AS [SCDActiveFlag]
		--,'N' AS [SCDActiveFlag]
		,ROW_NUMBER() OVER (PARTITION BY FactInstanceId,MeasureId ORDER BY [SCDStartDate] ASC) AS [SCDVersion]
		--,NULL AS [SCDVersion]
		,[SCDLOVRecordSourceId]
		,[ETLRunLogId]
		,[PSARowKey]
		FROM
		(
			SELECT
			src.FactInstanceId AS [FactInstanceId]
			,lkp_meas.MeasureId AS [MeasureId]
			,src.facings AS [Value]
			,12005 AS [LOVRecordSourceId]
			,'1900-01-01 00:00:00' AS [SCDStartDate]
			,NULL AS [SCDEndDate]
			,151 AS [SCDLOVRecordSourceId]
			,@serveETLRunLogID as [ETLRunLogId]
			,src.row_id as [PSARowKey]
			FROM #rawno_crp_planogram_temp src
			LEFT OUTER JOIN
			[ser].[measure] lkp_meas
			ON (lkp_meas.MeasureName = 'facings' AND lkp_meas.LOVMeasureTypeId = @measureTypeIdPlanoAggr AND lkp_meas.LOVRecordSourceId = 12005)
			WHERE src.facings IS NOT NULL AND src.facings <> ''
		)a
		;
		
		RAISERROR ('Completed insertion of International Norway source data to FACT MEASURE INSTANCE table', 0, 1) WITH NOWAIT

	UPDATE [psa].[rawno_crp_planogram] SET [row_status]=@rowStatusSERCode
	FROM [psa].[rawno_crp_planogram] nor 
	INNER JOIN [ser].[FactInstance] p ON nor.row_id=p.PSARowKey and nor.record_source_id=p.LovRecordSourceID 
	WHERE nor.row_status=@rowStatusPSACode  AND p.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))
		
	RAISERROR ('Updated Row Status to ''Loaded to Serve'' for psa.[rawno_crp_planogram] International Norway  ', 0, 1) WITH NOWAIT
	
	
	COMMIT TRANSACTION;					
			END TRY
			BEGIN CATCH
				DECLARE @error_num varchar(max),
        				@error_msg varchar(max),
        				@error_sev varchar(max)
        		;
 
				SELECT  
        		@error_num=ERROR_NUMBER()
        		,@error_sev=ERROR_SEVERITY()  
         		,@error_msg=ERROR_MESSAGE() ;  
 
        		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
			END CATCH 
			drop table #rawno_crp_planogram_temp
			PRINT 'Info: Dropped Temp table for International Norway-> psa.#rawno_crp_planogram_temp'
	END
GO
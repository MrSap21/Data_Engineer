IF OBJECT_ID('psa.sp_rawth_crp_item_transaction') IS NOT NULL
BEGIN
	DROP PROC psa.sp_rawth_crp_item_transaction;
END

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
************************************************************************************************************
Procedure Name			: sp_rawth_crp_item_transaction
Purpose					: Load History data from thailand transaction source table(rawth.crp_item_transaction) into Serve Layer Table
Domain					: Transaction
RecordSourceID  for thailand Transaction	: 12010

**************************************************************************************************************
*/

CREATE PROC [psa].[sp_rawth_crp_item_transaction] (@psaETLRunLogID varchar(max), @serveETLRunLogID bigint, @StartVal bigint, @EndVal bigint) AS
DECLARE @th_lovRecordSourceID 		bigint; 
DECLARE @th_scdLovRecordSourceID 	bigint; 
DECLARE @psa_rowstatus 				bigint; 
DECLARE @ser_rowstatus 				bigint;
DECLARE @max_tillid 				bigint;
DECLARE @max_siteroleid 			bigint; 
DECLARE @th_Siteid 					bigint; 
DECLARE @th_RoleId 					bigint;
DECLARE @max_transactionid 			bigint; 
DECLARE @th_trantypeid 				bigint;
DECLARE @max_productid 				bigint; 
DECLARE @th_srckeytypeid 			bigint;
DECLARE @max_upcproductid 			bigint; 
DECLARE @th_upcsrckeytypeid 		bigint; 
DECLARE @max_dealid 				bigint;
DECLARE @max_tranlineitemid 		bigint; 
DECLARE @th_lineitemtypeid 			bigint;
DECLARE @max_measureid 				bigint; 
DECLARE @th_measuretypeid			bigint; 
DECLARE @th_measuretypeid_unit 		bigint; 
DECLARE @th_measuretypeid_tisp 		bigint; 
DECLARE @th_measuretypeid_tesp 		bigint; 
DECLARE @th_measuretypeid_epos 		bigint; 
DECLARE @th_measuretypeid_disc 		bigint;
DECLARE @th_intdatatypeid 			bigint; 
DECLARE @th_decdatatypeid 			bigint; 
DECLARE @th_strdatatypeid 			bigint;
DECLARE @max_trnlineitemmeasureid 	bigint; 
DECLARE @th_unitmeasureid 			bigint; 
DECLARE @th_tispmeasureid 			bigint; 
DECLARE @th_tespmeasureid 			bigint; 
DECLARE @th_eposmeasureid 			bigint; 
DECLARE @th_discmeasureid 			bigint;  
DECLARE @max_loyaltyacctid 			bigint;
DECLARE @catchup_row 				bigint;
DECLARE @th_indicatorid 			bigint;
--DECLARE @serveETLRunLogID 		bigint;
--DECLARE @StartVal 				bigint;
--DECLARE @EndVal 					bigint;

/**********   need to declare the schema    ******************/

BEGIN		

SET @th_lovRecordSourceID = 12010; 
SET @th_scdLovRecordSourceID = 151; 
SET @psa_rowstatus = 26001; 
SET @ser_rowstatus = 26002;

BEGIN TRY
	BEGIN TRANSACTION


SET @catchup_row = (SELECT COALESCE(MAX(PSARowKey),0) FROM [ser].[TRANSACTIONLINEITEM] where LOVRecordSourceId = @th_lovRecordSourceID );
--SET @serveETLRunLogID = 54321;
--SET @StartVal = 7;
--SET @EndVal = 8;

/* 1.Table Name : Till */

SET @max_tillid = (SELECT COALESCE(MAX(TillId),0) FROM  [ser].[Till]);

INSERT INTO [ser].[Till] (TillId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_tillid + ROW_NUMBER() OVER(ORDER BY A.till_id ASC) TillId, 
		A.till_id SourceKey, 
		@th_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate,
		--LEFT(A.date_row,CHARINDEX('_',A.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		RIGHT(A.date_row,LEN(A.date_row)-CHARINDEX('_',A.date_row)) PSARowKey
		from 
(SELECT src.till_id, src.date_row from 
(SELECT till_id, record_source_id, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row from [psa].[rawth_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and till_id IS NOT NULL and till_id != '' GROUP BY till_id,record_source_id)src 
LEFT OUTER JOIN [ser].[Till] slf on src.till_id = slf.sourcekey and src.record_source_id = slf.LOVRecordSourceId 
where slf.sourcekey IS NULL )A ;

RAISERROR ('Completed insertion of thailand source data to TILL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 2.Table Name : Site */
/*
DECLARE @max_siteid int; DECLARE @th_SitetypeId int;
SET @max_siteid = (SELECT COALESCE(MAX(SiteId),0) FROM  [ser].[Site]);
SET @th_SitetypeId = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = '0' and rlovset.LOVsetname = 'Site Type');

INSERT INTO [ser].[Site] (SiteId, SourceKey, SiteName, LOVSiteTypeId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId) 
SELECT	@max_siteid + ROW_NUMBER() OVER(ORDER BY store_number ASC) , 
		0 , 
		'UNKNOWN' , 
		ISNULL(@th_SitetypeId,159000003) ,    
		12012 , 
		'1900-01-01' , 
		'9999-12-31' , 
		'Y' , 
		'1' ,  
		@th_scdLovRecordSourceID , 
		@serveETLRunLogID  
		from [psa].[rawth_crp_item_transaction] GROUP BY store_number ;

PRINT 'Info: Site Table Loaded Successfully';
*/
/*************************************************************************************************************************************************************/

/* 3.Table Name : Site_Role */

SET @max_siteroleid = (SELECT COALESCE(MAX(SiteRoleId),0) FROM  [ser].[SiteRole]);
SET @th_SiteId = (SELECT siteid from [ser].[site] site where site.LOVRecordSourceId = '12012' and site.LOVSiteTypeId IN (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = '0' and rlovset.LOVsetname = 'Site Type'));
SET @th_RoleId = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Store' and rlovset.LOVsetname = 'Role');


INSERT INTO [ser].[Siterole] (SiteRoleId, SiteId, LOVRoleId, SourceKey, SiteRoleName, SiteRoleShortName, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_siteroleid + ROW_NUMBER() OVER(ORDER BY A.sourcekey ASC) SiteRoleId, 
		@th_SiteId SiteId,    
		@th_RoleId LOVRoleId, 
		A.sourcekey SourceKey, 
		NULL SiteRoleName, 
		NULL SiteRoleShortName, 
		@th_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate,
		--LEFT(A.date_row,CHARINDEX('_',A.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion,  
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		RIGHT(A.date_row,LEN(A.date_row)-CHARINDEX('_',A.date_row)) PSARowKey
		from 
(SELECT src.sourcekey, src.date_row from 
(SELECT store_number sourcekey, record_source_id, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row 
from [psa].[rawth_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and store_number IS NOT NULL and store_number != '' GROUP BY store_number,record_source_id)src
LEFT OUTER JOIN [ser].[Siterole] slf on src.sourcekey = slf.sourcekey 
and src.record_source_id = slf.LOVRecordSourceId where slf.sourcekey IS NULL)A ;

RAISERROR ('Completed insertion of thailand source data to SITEROLE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 4.Table Name : Transaction */

SET @max_transactionid = (SELECT COALESCE(MAX(TransactionId),0) FROM  [ser].[Transaction]);
SET @th_trantypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Retail' and rlovset.LOVsetname = 'Transaction Type'); 


INSERT INTO [ser].[Transaction]
(TransactionId, SourceKey, LOVTransactionTypeId, SiteRoleId, TransactionDatetime, TillId, TillTransactionNumber, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_transactionid + ROW_NUMBER() OVER(ORDER BY trnx.transaction_key ASC) TransactionId, 
		trnx.transaction_key SourceKey, 
		@th_trantypeid LOVTransactionTypeId, 
		trnx.SiteRoleId SiteRoleId, 
		CAST (CONCAT(trnx.transaction_date,' ',trnx.transaction_time) as Datetime) TransactionDatetime, 
		trnx.tillId TillId, 
		null TillTransactionNumber, 
		@th_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate,
		--trnx.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		trnx.row_num PSARowKey from 
(SELECT P.transaction_key,P.siteroleid, P.transaction_date, P.transaction_time,P.tillid, P.record_source_id, P.startdate, P.row_num from
(SELECT src.transaction_key,B.siteroleid, src.transaction_date, src.transaction_time,till.tillid, src.record_source_id, LEFT(src.date_row,CHARINDEX('_',src.date_row)-1) startdate, RIGHT(src.date_row,LEN(src.date_row)-CHARINDEX('_',src.date_row)) row_num from 
(SELECT transaction_key, store_number, transaction_date, transaction_time, till_id,record_source_id, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row  from [psa].[rawth_crp_item_transaction]  where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY transaction_key, store_number, till_id, transaction_date, transaction_time,record_source_id) src 
JOIN (SELECT SiteRoleId, sourcekey from [ser].[Siterole] where lovrecordsourceid = 12010 and SCDActiveFlag = 'Y')B on B.sourcekey = src.store_number
JOIN (SELECT * from [ser].[Till] where lovrecordsourceid = 12010 and SCDActiveFlag = 'Y') till on src.till_id = till.sourcekey where till.lovrecordsourceid = 12010) P
LEFT OUTER JOIN [ser].[Transaction] T on P.transaction_key = T.sourcekey and CAST (CONCAT(P.transaction_date,' ',P.transaction_time) as Datetime) = T.TransactionDatetime and P.record_source_id = T.LOVRecordSourceId where T.sourcekey IS NULL )trnx ;


RAISERROR ('Completed insertion of thailand source data to TRANSACTION table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 5.Table Name : Product */

SET @max_productid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @th_srckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Thailand Item Code' and rlovset.LOVsetname = 'Source Key Type'); 

INSERT INTO [ser].[Product] (ProductId, SourceKey, LOVSourceKeyTypeId, ProductName, ProductDescription, LOVBrandId, LOVSubBrandId, LOVRecordSourceId, ParentProductId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_productid + ROW_NUMBER() OVER(ORDER BY A.SourceKey ASC) ProductId, 
		A.SourceKey SourceKey, 
		@th_srckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		@th_lovRecordSourceID LOVRecordSourceId,
		null ParentProductId,
		'1900-01-01' SCDStartDate,
		--LEFT(A.date_row,CHARINDEX('_',A.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		RIGHT(A.date_row,LEN(A.date_row)-CHARINDEX('_',A.date_row)) PSARowKey from
(SELECT src.sourcekey, src.date_row from 
(SELECT item_code SourceKey, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row, record_source_id from [psa].[rawth_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY item_code, record_source_id) src 
LEFT OUTER JOIN [ser].[Product] P on src.sourcekey = P.sourcekey and src.record_source_id = P.LOVRecordSourceId where P.sourcekey IS NULL and  src.sourcekey IS NOT NULL and src.sourcekey != '') A
;


RAISERROR ('Completed insertion of thailand source data to PRODUCT table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 6.Table Name : ProductIdentifier */

SET @max_upcproductid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @th_upcsrckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'UPC' and 				rlovset.LOVsetname = 'Identifier'); 
SET @th_srckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'thailand Item Code' and rlovset.LOVsetname = 'Source Key Type');


INSERT INTO [ser].[ProductIdentifier] (ProductId, LOVIdentifierId, [Value], LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  A.productId ProductId, 
		@th_upcsrckeytypeid LOVIdentifierId, 
		A.upc [Value], 
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--LEFT(A.date_row,CHARINDEX('_',A.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		RIGHT(A.date_row,LEN(A.date_row)-CHARINDEX('_',A.date_row)) PSARowKey from
(SELECT P.productId, src.upc, src.date_row from
(SELECT item_code, upc, record_source_id, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row from [psa].[rawth_crp_item_transaction] 
where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY item_code, upc, record_source_id) src
JOIN [ser].[PRODUCT] P on src.item_code = P.sourcekey and P.LOVRecordSourceId = @th_lovRecordSourceID and SCDActiveFlag = 'Y'
LEFT OUTER JOIN [ser].[ProductIdentifier] U on 
isnull(src.upc,'dummy_upc') = isnull(U.[Value],'dummy_upc') and src.record_source_id = U.LOVRecordSourceId and U.productId = P.productId where U.productId IS NULL) A;


RAISERROR ('Completed insertion of thailand source data to PRODUCTIDENTIFIER table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 7.Table Name : Deal */

SET @max_dealid = (SELECT COALESCE(MAX(DealId),0) FROM  [ser].[Deal]);

INSERT INTO [ser].[Deal] (DealId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_dealid + ROW_NUMBER() OVER(ORDER BY src.deal_id ASC) DealId,
		src.deal_id SourceKey,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--LEFT(src.date_row,CHARINDEX('_',src.date_row)-1) SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		RIGHT(src.date_row,LEN(src.date_row)-CHARINDEX('_',src.date_row)) PSARowKey from 
(SELECT T.deal_id, T.date_row from 
(SELECT deal_id, record_source_id, MIN(CONCAT(ISNULL(date_added,'1900-01-01'),'_',row_id)) date_row from [psa].[rawth_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY deal_id, record_source_id)T 
LEFT OUTER JOIN [ser].[Deal] D on T.deal_id = D.sourcekey and T.record_source_id = D.LOVRecordSourceId where D.sourcekey IS NULL and T.deal_id IS NOT NULL and T.deal_id != '') src ;

RAISERROR ('Completed insertion of thailand source data to DEAL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 8.Table Name : Transaction Line Item */

SET @max_tranlineitemid = (SELECT COALESCE(MAX(TransactionLineItemId),0) FROM  [ser].[TransactionLineItem]);
SET @th_upcsrckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'UPC' and 	rlovset.LOVsetname = 'Source Key Type'); 
SET @th_srckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Thailand Item Code' and rlovset.LOVsetname = 'Source Key Type');


INSERT INTO [ser].[TransactionLineItem] (TransactionLineItemId, TransactionId, ProductId, LOVLineItemTypeId, DealId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_tranlineitemid + ROW_NUMBER() OVER(ORDER BY final.sourcekey ASC) TransactionLineItemId,
		final.transactionid TransactionId,
		final.productid ProductId,
		final.lovid LOVLineItemTypeId,    
		final.deal_id DealId,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--final.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(SELECT trnx.transactionid, trnx.sourcekey, A.productid , B.lovid, D.dealid deal_id, ISNULL(A.date_added,'1900-01-01') startdate, A.row_id row_num from [ser].[Transaction] trnx 
JOIN (SELECT ISNULL(src.date_added,'1900-01-01') date_added, P.productId,src.transaction_key, src.sales_type, src.deal_id, src.row_id, CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) dt_tm from
(SELECT * from [psa].[rawth_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and item_code IS NOT NULL ) src
JOIN [ser].[product] P on P.sourcekey = src.item_code and P.lovsourcekeytypeid = @th_srckeytypeid and P.SCDActiveFlag = 'Y')A on trnx.sourcekey = A.transaction_key and trnx.lovrecordsourceid = @th_lovRecordSourceID and A.dt_tm = trnx.TransactionDatetime
LEFT OUTER JOIN (SELECT rlov.lovid, rlov.lovkey from [ser].[Reflov] rlov
JOIN [ser].[Reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.lovsetrecordsourceid = @th_lovRecordSourceID and rlovset.lovsetname='sales_type')B on B.lovkey = A.sales_type
LEFT OUTER JOIN [ser].[Deal] D on D.sourcekey = A.deal_id and D.LOVRecordSourceId = @th_lovRecordSourceID and D.SCDActiveFlag = 'Y'
) final;

RAISERROR ('Completed insertion of thailand source data to TRANSACTIONLINEITEM table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 9.Table Name : Measure */

SET @max_measureid = (SELECT COALESCE(MAX(MeasureId),0) FROM  [ser].[Measure]);
SET @th_measuretypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 			'RETAIL_TRANS_AGG' and rlovset.LOVsetname = 'Measure Type');
SET @th_measuretypeid_unit = @max_measureid + 1; SET @th_measuretypeid_tisp = @max_measureid + 2; SET @th_measuretypeid_tesp = @max_measureid + 3;
SET @th_measuretypeid_epos = @max_measureid + 4; SET @th_measuretypeid_disc = @max_measureid + 5;

SET @th_intdatatypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVName = 					'INTEGER' and rlovset.LOVsetname = 'Data Type');
SET @th_decdatatypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 					'DECIMAL' and rlovset.LOVsetname = 'Data Type');
SET @th_strdatatypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 					'STRING' and rlovset.LOVsetname = 'Data Type');

INSERT INTO [ser].[Measure] (MeasureId, LOVMeasureTypeId, LOVDataTypeId, MeasureName, MeasureDescription, [Length], [Precision], Scale, StandardMeasureId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId) 

SELECT  A.MeasureId MeasureId,
		A.LOVMeasureTypeId LOVMeasureTypeId,
		A.LOVDataTypeId LOVDataTypeId,
		A.MeasureName MeasureName,
		A.MeasureDescription MeasureDescription,
		A.[length] [Length],
		A.[Precision] [Precision],
		A.Scale Scale,
		A.StandardMeasureId StandardMeasureId,
		A.LOVRecordSourceId LOVRecordSourceId,
		A.SCDStartDate SCDStartDate,
		A.SCDEndDate SCDEndDate,
		A.SCDActiveFlag SCDActiveFlag,
		A.SCDVersion SCDVersion,
		A.SCDLOVRecordSourceId SCDLOVRecordSourceId,
		A.ETLRunLogId ETLRunLogId from 
(		
SELECT	TOP 1
		@th_measuretypeid_unit MeasureId,
		@th_measuretypeid LOVMeasureTypeId, 
		@th_intdatatypeid LOVDataTypeId, 
		'units' MeasureName, 
		'The number of units of item sold in the transaction ' MeasureDescription,
		null [Length],
		null [Precision],
		null Scale,
		null StandardMeasureId ,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'units' = M.MeasureName and @th_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @th_lovRecordSourceID
	
UNION	
	 
SELECT	TOP 1
		@th_measuretypeid_tisp MeasureId,
		@th_measuretypeid LOVMeasureTypeId, 
		@th_decdatatypeid LOVDataTypeId, 
		'tisp' MeasureName, 
		'Tax inclusive selling price (price paid by customer) ' MeasureDescription,
		null [Length],
		10 [Precision],
		2 Scale,
		null StandardMeasureId ,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'tisp' = M.MeasureName and @th_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @th_lovRecordSourceID
	
UNION
	
SELECT	TOP 1
		@th_measuretypeid_tesp MeasureId,
		@th_measuretypeid LOVMeasureTypeId, 
		@th_decdatatypeid LOVDataTypeId, 
		'tesp' MeasureName, 
		'Tax exclusive selling price ' MeasureDescription,
		null [Length],
		10 [Precision],
		2 Scale,
		null StandardMeasureId ,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'tesp' = M.MeasureName and @th_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @th_lovRecordSourceID
	 
UNION

SELECT	TOP 1
		@th_measuretypeid_epos MeasureId,
		@th_measuretypeid LOVMeasureTypeId, 
		@th_decdatatypeid LOVDataTypeId, 
		'epos_profit' MeasureName, 
		'This should be reflective of the true profitability of each product  (EPOS profit = TISP - Cost)' MeasureDescription,
		null [Length],
		10 [Precision],
		2 Scale,
		null StandardMeasureId ,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'epos_profit' = M.MeasureName and @th_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @th_lovRecordSourceID
	 
UNION

SELECT	TOP 1
		@th_measuretypeid_disc MeasureId,
		@th_measuretypeid LOVMeasureTypeId, 
		@th_strdatatypeid LOVDataTypeId, 
		'discount_applied' MeasureName, 
		'The total discount the customer received (through promotions, staff discount etc) on the items in the transaction.  I.e.. it is the difference between the shelf edge price and the amount the customer actually paid.' MeasureDescription,
		null [Length],
		null [Precision],
		null Scale,
		null StandardMeasureId ,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId from 
[ser].[reflov] R LEFT OUTER JOIN [ser].[MEASURE] M on 'discount_applied' = M.MeasureName and @th_measuretypeid = M.LOVMeasureTypeId and R.LOVRecordSourceId = M.LOVRecordSourceId where M.MeasureName IS NULL and R.LOVRecordSourceId = @th_lovRecordSourceID

)A;
	 
RAISERROR ('Completed insertion of thailand source data to MEASURE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 10.Table Name : Transaction Line Item Measure */

SET @max_trnlineitemmeasureid = (SELECT COALESCE(MAX(TransactionLineItemMeasureId),0) FROM  [ser].[TransactionLineItemMeasure]);
SET @th_measuretypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 			'RETAIL_TRANS_AGG' and rlovset.LOVsetname = 'Measure Type');
SET @th_unitmeasureid = (SELECT MAX(MeasureId) from [ser].[Measure] msr where msr.measurename = 'units' and msr.LOVMeasureTypeId = @th_measuretypeid and msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @th_tispmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'tisp' and msr.LOVMeasureTypeId = @th_measuretypeid and msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @th_tespmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'tesp' and msr.LOVMeasureTypeId = @th_measuretypeid and msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @th_eposmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'epos_profit' and msr.LOVMeasureTypeId = @th_measuretypeid and 	msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);
SET @th_discmeasureid = (SELECT MAX(MeasureId) MeasureId from [ser].[Measure] msr where msr.measurename = 'discount_applied' and msr.LOVMeasureTypeId = @th_measuretypeid and 	msr.LOVRecordSourceId = @th_lovRecordSourceID GROUP BY LOVMeasureTypeId);

INSERT INTO [ser].[TransactionLineItemMeasure] (TransactionLineItemMeasureId, TransactionLineItemId, MeasureId, Value, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	@max_trnlineitemmeasureid + DENSE_RANK() OVER(ORDER BY final.TransactionLineItemId, final.MeasureId) TransactionLineItemMeasureId,
		final.TransactionLineItemId TransactionLineItemId,
		final.MeasureId MeasureId,
		final.Value Value,
		final.LOVRecordSourceId LOVRecordSourceId,
		final.SCDStartDate SCDStartDate,
		final.SCDEndDate SCDEndDate,
		final.SCDActiveFlag SCDActiveFlag,
		final.SCDVersion SCDVersion,
		final.SCDLOVRecordSourceId SCDLOVRecordSourceId,
		final.ETLRunLogId ETLRunLogId,
		final.PSARowKey PSARowKey from
(	
SELECT	A.TransactionLineItemId TransactionLineItemId,
		@th_unitmeasureid MeasureId,
		A.units [Value],
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--A.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		A.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.units , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawth_crp_item_transaction] src on trln.psarowkey = src.row_id and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) A

UNION

SELECT  B.TransactionLineItemId TransactionLineItemId,
		@th_tispmeasureid MeasureId,
		B.tisp [Value],
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--B.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		B.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.tisp , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawth_crp_item_transaction] src on trln.psarowkey = src.row_id and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))  ) B

UNION

SELECT  C.TransactionLineItemId TransactionLineItemId,
		@th_tespmeasureid MeasureId,
		C.tesp Value,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--C.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		C.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.tesp , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawth_crp_item_transaction] src on trln.psarowkey = src.row_id  and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))  ) C

UNION

SELECT  D.TransactionLineItemId TransactionLineItemId,
		@th_eposmeasureid MeasureId,
		D.epos_profit Value,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--D.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		D.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.epos_profit , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawth_crp_item_transaction] src on trln.psarowkey = src.row_id  and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))  ) D

UNION

SELECT  E.TransactionLineItemId TransactionLineItemId,
		@th_discmeasureid MeasureId,
		E.discount_applied Value,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--E.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		E.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.discount_applied , src.row_id row_num, ISNULL(src.date_added,'1900-01-01') startdate from [ser].[TransactionLineItem] trln     
JOIN [psa].[rawth_crp_item_transaction] src on trln.psarowkey = src.row_id  and trln.LOVRecordSourceId = src.record_source_id where src.row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))  ) E
)final;

RAISERROR ('Completed insertion of thailand source data to TRANSACTIONLINEITEMMEASURE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 11.Table Name : TransactionLineItemIndicator */

SET @th_indicatorid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'prescription' and rlovset.LOVsetname = 'Indicator - Thailand Transaction');

INSERT INTO [ser].[TransactionLineItemIndicator] (TransactionLineItemId, LOVIndicatorId, [Value], LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT  A.TransactionLineItemId TransactionLineItemId,
		@th_indicatorid LOVIndicatorId,
		A.prescription [VALUE],
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--ISNULL(a.date_added,'1900-01-01') SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		A.row_num PSARowKey from
(SELECT trln.TransactionLineItemId, src.prescription, src.record_source_id, ISNULL(src.date_added,'1900-01-01') date_added, src.row_id row_num from 
(SELECT prescription, record_source_id, row_id, ISNULL(date_added,'1900-01-01') date_added from [psa].[rawth_crp_item_transaction] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and prescription IS NOT NULL and prescription != '') src
JOIN [ser].[TransactionLineItem] trln on trln.PSARowKey = src.row_id and trln.LOVRecordSourceId = @th_lovRecordSourceID  ) A;

RAISERROR ('Completed insertion of thailand source data to TransactionLineItemIndicator table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 12.Table Name : LoyaltyAccount */

SET @max_loyaltyacctid = (SELECT COALESCE(MAX(LoyaltyAccountId),0) FROM  [ser].[LoyaltyAccount]);

 INSERT INTO [ser].[LoyaltyAccount] (LoyaltyAccountId,LOVLoyaltyProgramId,SourceKey,LOVRecordSourceId,SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	@max_loyaltyacctid + ROW_NUMBER() OVER(ORDER BY final.lovid, final.SourceKey ASC) LoyaltyAccountId, 
		final.lovid LOVLoyaltyProgramId,
		final.SourceKey SourceKey,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--final.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
SELECT M.lovid, M.sourcekey, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from 
(SELECT rlov.lovid lovid, B.customer_identifier sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'customer_identifier_type' and LOVSetRecordSourceId = 12010
JOIN 
(SELECT (CASE WHEN (trim(A.customer_identifier_type) = '' OR A.customer_identifier_type IS NULL OR A.customer_identifier_type = 'NULL') THEN 'Unknown'
ELSE A.customer_identifier_type END) lovkey, A.customer_identifier, A.date_row, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_identifier_type, src.customer_identifier, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row,src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawth_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12010 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.customer_identifier IS NOT NULL and TRIM(B.customer_identifier) != '' GROUP BY rlov.lovid, B.customer_identifier,B.record_source_id) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T on M.lovid=T.LOVLoyaltyProgramId and M.SourceKey=T.SourceKey and M.record_source_id=T.LOVRecordSourceId where LOVLoyaltyProgramId IS NULL

UNION

SELECT M.lovid, M.sourcekey, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from 
(SELECT rlov.lovid lovid, B.customer_number sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'customer_number_type' and LOVSetRecordSourceId = 12010
JOIN 
(SELECT (CASE WHEN (trim(A.customer_number_type) = '' OR A.customer_number_type IS NULL OR A.customer_number_type = 'NULL') THEN 'Unknown'
ELSE A.customer_number_type END) lovkey, A.customer_number, A.date_row, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_number_type, src.customer_number, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row,src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawth_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12010 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.customer_number IS NOT NULL and TRIM(B.customer_number) != '' GROUP BY rlov.lovid, B.customer_number,B.record_source_id) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T on M.lovid=T.LOVLoyaltyProgramId and M.SourceKey=T.SourceKey and M.record_source_id=T.LOVRecordSourceId where LOVLoyaltyProgramId IS NULL

UNION

SELECT M.lovid, M.sourcekey, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from 
(SELECT rlov.lovid lovid, B.other_customer_id sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'other_customer_id_type' and LOVSetRecordSourceId = 12010
JOIN 
(SELECT (CASE WHEN (trim(A.other_customer_id_type) = '' OR A.other_customer_id_type IS NULL OR A.other_customer_id_type = 'NULL') THEN 'Unknown'
ELSE A.other_customer_id_type END) lovkey, A.other_customer_id, A.date_row, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.other_customer_id_type, src.other_customer_id, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row,src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawth_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12010 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.other_customer_id IS NOT NULL and TRIM(B.other_customer_id) != '' GROUP BY rlov.lovid, B.other_customer_id,B.record_source_id) M
LEFT OUTER JOIN [ser].[LoyaltyAccount] T on M.lovid=T.LOVLoyaltyProgramId and M.SourceKey=T.SourceKey and M.record_source_id=T.LOVRecordSourceId where LOVLoyaltyProgramId IS NULL

) final;

RAISERROR ('Completed insertion of thailand source data to LOYALTYACCOUNT table', 0, 1) WITH NOWAIT;


/*************************************************************************************************************************************************************/

/* 13.Table Name : TransactionLoyaltyAccount */

INSERT INTO [ser].[TransactionLoyaltyAccount] (TransactionId, LoyaltyAccountId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	final.TransactionId TransactionId, 
		final.loyaltyaccountid LoyaltyAccountId,
		@th_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01' SCDStartDate,
		--final.startdate SCDStartDate, 
		'9999-12-31 00:00:00' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@th_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.row_num PSARowKey from
(
SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.startdate, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from [ser].[LoyaltyAccount] LA 
JOIN (SELECT B.TransactionId, rlov.lovid lovid, B.customer_identifier sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'customer_identifier_type' and LOVSetRecordSourceId = 12010
JOIN 
(SELECT (CASE WHEN (trim(A.customer_identifier_type) = '' OR A.customer_identifier_type IS NULL OR A.customer_identifier_type = 'NULL') THEN 'Unknown'
ELSE A.customer_identifier_type END) lovkey, A.customer_identifier, A.date_row,A.TransactionId, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_identifier_type, src.customer_identifier, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row, src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawth_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12010 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.customer_identifier IS NOT NULL and TRIM(B.customer_identifier) != '' GROUP BY B.TransactionId, rlov.lovid, B.customer_identifier,B.record_source_id)M 
on LA.LOVLoyaltyProgramId = M.lovid and LA.sourcekey = M.sourcekey and LA.SCDActiveFlag = 'Y') P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

UNION

SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.startdate, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from [ser].[LoyaltyAccount] LA 
JOIN (SELECT B.TransactionId, rlov.lovid lovid, B.customer_number sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'customer_number_type' and LOVSetRecordSourceId = 12010
JOIN 
(SELECT (CASE WHEN (trim(A.customer_number_type) = '' OR A.customer_number_type IS NULL OR A.customer_number_type = 'NULL') THEN 'Unknown'
ELSE A.customer_number_type END) lovkey, A.customer_number, A.date_row,A.TransactionId, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.customer_number_type, src.customer_number, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row, src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawth_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12010 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.customer_number IS NOT NULL and TRIM(B.customer_number) != '' GROUP BY B.TransactionId, rlov.lovid, B.customer_number,B.record_source_id)M 
on LA.LOVLoyaltyProgramId = M.lovid and LA.sourcekey = M.sourcekey and LA.SCDActiveFlag = 'Y') P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

UNION

SELECT P.loyaltyaccountid,P.TransactionId, P.sourcekey, P.record_source_id, P.startdate, P.row_num from
(SELECT LA.loyaltyaccountid,M.TransactionId, M.sourcekey, M.record_source_id, LEFT(M.date_row,CHARINDEX('_',M.date_row)-1) startdate, RIGHT(M.date_row,LEN(M.date_row)-CHARINDEX('_',M.date_row)) row_num from [ser].[LoyaltyAccount] LA 
JOIN (SELECT B.TransactionId, rlov.lovid lovid, B.other_customer_id sourcekey, B.record_source_id, MIN(B.date_row) date_row from [ser].[reflov] rlov 
JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid and rlovset.LOVsetname = 'other_customer_id_type' and LOVSetRecordSourceId = 12010
JOIN 
(SELECT (CASE WHEN (trim(A.other_customer_id_type) = '' OR A.other_customer_id_type IS NULL OR A.other_customer_id_type = 'NULL')  THEN 'Unknown'
ELSE A.other_customer_id_type END) lovkey, A.other_customer_id, A.date_row,A.TransactionId, A.record_source_id from
(SELECT trnx.TransactionId, trnx.sourcekey, src.other_customer_id_type, src.other_customer_id, CONCAT(ISNULL(src.date_added,'1900-01-01'),'_',src.row_id) date_row, src.record_source_id from [ser].[Transaction] trnx
JOIN (select * from [psa].[rawth_crp_item_transaction] where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ) src on trnx.sourcekey = src.transaction_key and trnx.LOVRecordSourceId = 12010 and CAST (CONCAT(src.transaction_date,' ',src.transaction_time) as Datetime) = trnx.TransactionDatetime ) A) B on rlov.lovkey = B.lovkey
where B.other_customer_id IS NOT NULL and TRIM(B.other_customer_id) != '' GROUP BY B.TransactionId, rlov.lovid, B.other_customer_id,B.record_source_id)M 
on LA.LOVLoyaltyProgramId = M.lovid and LA.sourcekey = M.sourcekey and LA.SCDActiveFlag = 'Y') P
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] T on P.loyaltyaccountid=T.LoyaltyAccountId and P.TransactionId = T.TransactionId and P.record_source_id=T.LOVRecordSourceId where T.TransactionId IS NULL

)final;

RAISERROR ('Completed insertion of thailand source data to TRANSACTIONLOYALTYACCOUNT table', 0, 1) WITH NOWAIT;


/*************************************************************************************************************************************************************/

/* 14.Table Name : psa.rawth_crp_item_transaction */
/* Update the row_status in the psa.rawth_crp_item_transaction from 26001(PSA) to 26002(SERVE) */

UPDATE [psa].[rawth_crp_item_transaction]
SET row_status = @ser_rowstatus
where row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and row_status = @psa_rowstatus;

/*************************************************************************************************************************************************************/

	COMMIT TRANSACTION
END TRY

BEGIN CATCH
DECLARE @error_num varchar(max),
		@error_msg varchar(max),
		@error_sev varchar(max)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH

END;
GO
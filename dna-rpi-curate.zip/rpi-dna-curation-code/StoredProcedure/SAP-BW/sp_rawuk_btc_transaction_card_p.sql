/****** Object:  StoredProcedure [psa].[sp_rawuk_btc_transaction_card_p]    ******/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_rawuk_btc_transaction_card_p') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawuk_btc_transaction_card_p
END;
GO

CREATE PROC [psa].[sp_rawuk_btc_transaction_card_p] @psaETLRunLogID [varchar](20),@serveETLRunLogID [Varchar](20),@StartVal [varchar](20),@EndVal [varchar](20) AS

DECLARE
	@tETLRunLogId BigInt,
	@tLOVRecordSourceId BigInt,
	@tSCDLOVRecordSourceId BigInt,
	@tSAPCRMSourceId BigInt,
	@tSCDVersion Int,
	@tSCDActiveFlag NChar(1),
	@tNSCDActiveFlag Nchar(1),
	@tSCDEndDate datetime,
	@tSCDStartDate datetime,
	@tStatusStart Int,
	@tStatusEnd Int,
	@tStatusMissingP Int,
	@tStartVal BigInt,
	@tEndVal BigInt;
	/*@serveETLRunLogID bigint,
	@startval bigint,
	@endval bigint;

	

SET @serveETLRunLogID = 99999;
	SET @startval = 1;
	SET @endval =1;*/

BEGIN
	BEGIN TRY

	IF OBJECT_ID('tempdb..#tTransactionLoyaltyAccountCard') IS NOT NULL
		BEGIN
			DROP TABLE #tTransactionLoyaltyAccountCard;
		END;

	SET @tETLRunLogId=@serveETLRunLogID
	SET @tSAPCRMSourceId=12011
	SET @tLOVRecordSourceId=12006
	SET @tSCDLOVRecordSourceId=151
	SET @tSCDVersion=1
	SET @tSCDActiveFlag='Y'
	SET @tNSCDActiveFlag='N'
	SET @tSCDEndDate='9999-12-31 00:00:00'
	SET @tSCDStartDate='1900-01-01 00:00:00'
	SET @tStatusStart =26001
	SET @tStatusEnd=26002
	SET @tStatusMissingP = 26003
	SET @tStartVal=@StartVal
	SET @tEndVal=@EndVal
	
	
	RAISERROR ('Set the variable done', 0, 1) WITH NOWAIT
	-- CHECK IF PSA Has Null for store or product number

	RAISERROR ( ' row status %d, start val %d, end val %d',0,1,@tStatusStart, @tStartVal, @tEndVal)

	
	CREATE TABLE #tTransactionLoyaltyAccountCard WITH (DISTRIBUTION = HASH([TransactionId])) AS
	(
	SELECT 
	tt.TransactionId AS [TransactionId],
	ISNULL(lc.LoyaltyAccountCardId,12345) [LoyaltyAccountCardId],
	@tLOVRecordSourceId AS [LOVRecordSourceId],
	@tSCDStartDate AS [SCDStartDate],
	@tSCDEndDate AS [SCDEndDate] ,
	@tSCDActiveFlag AS [SCDActiveFlag],
	@tSCDVersion AS [SCDVersion],
	@tSCDLOVRecordSourceId AS [SCDLOVRecordSourceId],
	@tETLRunLogId AS [ETLRunLogId],
	row_id AS [PSARowKey],
	CASE WHEN tc.TransactionId is NOT NULL  THEN 0 ELSE 1 END AS tcvalid,
	CASE WHEN tt.TransactionId IS NULL OR lc.LoyaltyAccountId IS NULL THEN 0 ELSE 1 END AS valid
	FROM (SELECT epos_transaction_key, customer_card_number, max(record_source_id) as record_source_id,  max(row_id) AS row_id 
			FROM [psa].[rawuk_btc_transaction_card_p] where row_status=@tStatusStart 
			AND (customer_card_number IS NOT NULL AND customer_card_number <> '') 
			AND [row_id] Between @tStartVal and @tEndVal 
			AND [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
			group by epos_transaction_key, customer_card_number) t
	LEFT JOIN ser.[Transaction] tt
	ON t.epos_transaction_key=tt.SourceKey
	AND tt.LOVRecordSourceId=@tLOVRecordSourceId
	AND tt.[SCDActiveFlag]=@tSCDActiveFlag
	AND t.record_source_id=tt.LOVRecordSourceId
	LEFT JOIN ser.LoyaltyAccountCard lc
	ON lc.SourceKey=t.customer_card_number
	AND lc.LOVRecordSourceId=@tSAPCRMSourceId
	LEFT JOIN ser.TransactionLoyaltyAccountCard tc
	ON tt.TransactionId = tc.TransactionId
	AND lc.LoyaltyAccountCardId = tc.LoyaltyAccountCardId
	AND tc.LOVRecordSourceId=@tLOVRecordSourceId
	)
	
BEGIN TRANSACTION;

-- Insert into target when valid and tcvalid is 1

	INSERT INTO [ser].[TransactionLoyaltyAccountCard] (TransactionId, LoyaltyAccountCardId, LOVRecordSourceId, SCDStartDate, 
	SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
	SELECT TransactionId, LoyaltyAccountCardId, LOVRecordSourceId, SCDStartDate, 
	SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey from #tTransactionLoyaltyAccountCard 
	where tcvalid = 1 and valid = 1;
	
-- update psa for loaded recs to 26002 when valid and tcvalid is 1
	
	UPDATE [psa].[rawuk_btc_transaction_card_p]
	SET row_status = 26002
	FROM [psa].[rawuk_btc_transaction_card_p] tc
	JOIN 
	(select trans.sourcekey from ser.TransactionLoyaltyAccountCard tmp 
	JOIN (select * from ser.[TRANSACTION] where lovrecordsourceid = 12006) trans
		on tmp.transactionid = trans.transactionid
	)M
	ON M.sourcekey = tc.epos_transaction_key
	WHERE tc.row_status = 26001;
	
-- update psa table with row_status = 26003 when the business key is missing 
		
	UPDATE [psa].[rawuk_btc_transaction_card_p]
	SET row_status = 26003
	WHERE row_status = 26001
	AND row_id Between @tStartVal and @tEndVal;
		
	COMMIT TRANSACTION;
END TRY

BEGIN CATCH 
			ROLLBACK TRANSACTION ;
				SELECT  
						ERROR_NUMBER() AS ErrorNumber     
						,ERROR_PROCEDURE() AS ErrorProcedure	       
						,ERROR_MESSAGE() AS ErrorMessage; 						
												
END CATCH

END;
GO
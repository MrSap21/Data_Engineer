/****** Object:  StoredProcedure [psa].[sp_rawuk_base_plan_product]    Script Date: 07/08/2020 16:51:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
**********************************************************************************************************************
This Procedure is for populating the records From RAWUK_BASE_PLAN_PRODUCT in psa layer(SAP_BW) into Serve Layer Tables
Source Table: psa.RAWUK_BASE_PLAN_PRODUCT
Target Tables : [ser].[FactInstnace],[ser].[FactDimensionInstance]
***********************************************************************************************************************
*/
IF OBJECT_ID('[psa].[sp_rawuk_base_plan_product]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_rawuk_base_plan_product] 
END
GO

CREATE PROC [psa].[sp_rawuk_base_plan_product] @psaETLRunLogID [varchar](MAX),@serveETLRunLogID [varchar](MAX),@tableName [varchar](200) AS

----drop temp table if exists
IF OBJECT_ID('ser.TmpBasePlanProduct') IS NOT NULL
BEGIN
DROP TABLE ser.TmpBasePlanProduct;
END

-----create temp table
CREATE TABLE [ser].[TmpBasePlanProduct]
(
[row_num] [bigint] NOT NULL,
planogramid [bigint]  NULL,
productid [bigint]  NULL,
calender_id [bigint]  NULL,
fiscal_id [bigint]  NULL,
row_id [bigint] NOT NULL,
pogid [nvarchar](200)  NULL,
article_id [nvarchar](200)  NULL,
calendar_week [nvarchar](200)  NULL,
fiscal_week [nvarchar](200)  NULL,
record_source_id [int] NOT NULL,
row_status [bigint] NULL,
etl_runlog_id [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([row_num],[record_source_id])
)
BEGIN
BEGIN TRANSACTION;

--Declare Variables
DECLARE 
			@max_FactInstanceID bigint,
			@psaRowStatus int, 
			@serRowStatus int,
			@planogram_type_id int,
			@fact_type_id int,
			@max_FactID int,
			@max_DimensionId int,
			@SCDStartDate datetime=(SELECT CONVERT(datetime2,'1900-01-01 00:00:00')),
			@SCDEndDate datetime= (SELECT CONVERT(datetime2,'9999-12-31 00:00:00')),
			@SCDActiveFlag char='Y',
			@SCDVersion smallint=1,
			@LOVRecordSourceId int =12006,
			@PlnLOVRecordSourceId int =12002,
			@SCDLOVRecordSourceId int =151,
			@calender_week_max int,
			@dimension_id_calenderWeek int;

--Set Maximum factInstnace id from the table  ser.FactInstance and Rowstatus values for both PSA and SERVE Layer
SET @max_FactInstanceId=(SELECT COALESCE(MAX(FactInstanceId),0)  from ser.FactInstance);
SET @psaRowStatus=26001;
SET @serRowStatus=26002;

/*-------Derive the lookup table constant values and Set to Variables-------*/
SELECT @planogram_type_id=rl.LovId from ser.RefLov rl where rl.LOVKey = 'Intactix Planogram Id(value50)' AND rl.LOVSetId = (SELECT rls.LOVSetId from ser.RefLovSet rls where rls.LOVSetName = 'Source Key Type')
SET @fact_type_id = (SELECT rl.LovId from ser.RefLov rl where rl.LOVKey = 'TBC' AND rl.LOVSetId = (SELECT rls.LOVSetId from ser.RefLovSet rls where rls.LOVSetName = 'Fact Type'));
SET @dimension_id_calenderWeek = (SELECT DimensionId from ser.Dimension where Name='calendar_week' AND LOVRecordSourceID = @LOVRecordSourceId);
SET @calender_week_max=(SELECT COALESCE(MAX(DimensionSourceKey),0)  from ser.FactDimensionInstance fdi
						LEFT join ser.FactInstance fi
						on fi.FactInstanceId = fdi.FactInstanceId
						LEFT join ser.Fact f
						on f.factId = fi.factId 
						WHERE f.LOVRecordSourceId = @LOVRecordSourceId AND 
						fdi.DimensionId = @dimension_id_calenderWeek AND f.FactName = 'BASE PLAN PRODUCT');

BEGIN TRY
---INSERT TO TEMP TABLE
INSERT INTO  ser.TmpBasePlanProduct

select ROW_NUMBER() OVER (ORDER BY row_id) + @max_FactInstanceId row_num,
(case when 
(SELECT COUNT(PlanogramId) FROM (select PlanogramId,LOVSourceKeyTypeId,LOVRecordSourceId,SCDActiveFlag from ser.planogram pl where pl.sourcekey = bp.pogid 
AND pl.LOVSourceKeyTypeId = @planogram_type_id and pl.LOVRecordSourceId=@PlnLOVRecordSourceId AND pl.SCDActiveFlag = 'Y'
group by LOVSourceKeyTypeId,LOVRecordSourceId,PlanogramId,SCDActiveFlag) SS)=1 THEN (select  PlanogramId from ser.planogram pl where pl.sourcekey = bp.pogid
AND pl.LOVSourceKeyTypeId = @planogram_type_id and pl.LOVRecordSourceId=@PlnLOVRecordSourceId AND pl.SCDActiveFlag = 'Y') ELSE NULL END)planogramid,
pp.ProductId as productid,
cw.LOVId as calender_id,
fw.LOVId as fiscal_id,
row_id,
pogid,
article_id,
calendar_week,
fiscal_week,
record_source_id,
row_status,
CAST(@serveETLRunLogID AS INT) etl_runlog_id
from psa.rawuk_base_plan_product bp 
--AND bp.etl_runlog_id in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,','));
left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
                            ser.RefLov rl
                            join ser.RefLovSet rls
                            on rl.LOVSETId=rls.LOVSetID                
                            where rls.LOVSetName = 'calendar_week' )cw
                             on bp.record_source_id=cw.LOVRecordSourceId and  cw.LOVKey = bp.calendar_week

left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
                            ser.RefLov rl
                            join ser.RefLovSet rls
                            on rl.LOVSETId=rls.LOVSetID                
                            where rls.LOVSetName = 'fiscal_week' )fw
                             on bp.record_source_id=fw.LOVRecordSourceId and  fw.LOVKey = bp.fiscal_week
left join ser.Product pp ON  pp.SourceKey=bp.article_id AND pp.LOVRecordSourceId = @PlnLOVRecordSourceId AND pp.SCDActiveFlag = 'Y'

where bp.row_status =@psaRowStatus AND bp.etl_runlog_id in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,',')) AND (cast(bp.calendar_week as INT) >@calender_week_max  OR (bp.calendar_week is null));



--select * from #tempTable_BPP
 
/********************************************************************************************************************************
1.	Table Name  :FactInstance 
	
**********************************************************************************************************************************/
WITH FactInstanceCTE AS 
(select temp.row_num factInstanceId,temp.record_source_id,temp.row_id,f.factId,fd.DimensionId from ser.TmpBasePlanProduct temp join ser.FactDimension fd 
on temp.record_source_id = fd.LovRecordSourceId 
join ser.Fact f on 
fd.factId=f.factId where f.factName='BASE PLAN PRODUCT' and f.LOVFactTypeId = @fact_type_id
and  f.LOVrecordSourceId=@LOVRecordSourceId)

INSERT INTO ser.FactInstance(FactInstanceId,FactId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)		
						SELECT
						distinct(fi.factInstanceId) FactInstanceId,
							   fi.factId Factid,
							   fi.record_source_id LOVRecordSourceID,
								@SCDStartDate SCDStartDate,
								@SCDEndDate SCDEndDate,
								@SCDActiveFlag SCDActiveFlag,
								@SCDVersion SCDVersion,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								@serveETLRunLogID ETLRunLogId,
								fi.row_id PSARowKey
									FROM FactInstanceCTE fi							   
			   
						PRINT ' Info : FactInstance  Table Loaded Successfully' ;
/********************************************************************************************************************************
2.	Table Name  :FactDimensionInstance 
	
**********************************************************************************************************************************/

WITH FactDimesionInstanceCTE AS 
(select temp.row_num factInstanceId,temp.article_id,temp.pogid,temp.calendar_week,temp.fiscal_week,temp.calender_id,temp.fiscal_id,temp.planogramid,temp.ProductId,temp.record_source_id,temp.row_id,f.factId,fd.DimensionId from ser.TmpBasePlanProduct temp join ser.FactDimension fd 
on temp.record_source_id = fd.LovRecordSourceId 
join ser.Fact f on 
fd.factId=f.factId where f.factName='BASE PLAN PRODUCT' and f.LOVFactTypeId = @fact_type_id
and  f.LOVrecordSourceId=@LOVRecordSourceId)


--select * from ser.FactDimensionInstance where LOVRecordSourceId = 12006
INSERT INTO ser.FactDimensionInstance(
				[FactInstanceId],[DimensionId], [DimensionSurrogateKey],[DimensionSourceKey],[LOVRecordSourceId],[SCDStartDate],[SCDEndDate],[SCDActiveFlag],[SCDVersion],[SCDLOVRecordSourceId] ,[ETLRunLogId], [PSARowKey] )	
SELECT 
									fdi.factInstanceId FactInstanceId,
									fdi.DimensionId DimensionId,
									fdi.planogramId	DimensionSurrogateKey,   
									fdi.pogid	[DimensionSourceKey],   
									fdi.record_source_id	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
									fdi.row_id PSARowKey									
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='planogram' and d.LOVRecordSourceId = @PlnLOVRecordSourceId
UNION ALL								

SELECT 
									fdi.factInstanceId FactInstanceId,
									fdi.DimensionId DimensionId,
									fdi.ProductId	DimensionSurrogateKey,   
									fdi.article_id	[DimensionSourceKey],   
									fdi.record_source_id	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
									fdi.row_id PSARowKey
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='product' and d.LOVRecordSourceId = @PlnLOVRecordSourceId
UNION ALL

SELECT 
									fdi.factInstanceId FactInstanceId,
									fdi.DimensionId DimensionId,
									fdi.calender_id	DimensionSurrogateKey,   
									fdi.calendar_week	[DimensionSourceKey],   
									fdi.record_source_id	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
									fdi.row_id PSARowKey
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='calendar_week' and d.LOVRecordSourceId = @LOVRecordSourceId
UNION ALL

SELECT 
									fdi.factInstanceId FactInstanceId,
									fdi.DimensionId DimensionId,
									fdi.fiscal_id	DimensionSurrogateKey,   
									fdi.fiscal_week	[DimensionSourceKey],   
									fdi.record_source_id	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
									fdi.row_id PSARowKey
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='fiscal_week' and d.LOVRecordSourceId = @LOVRecordSourceId;
								
								PRINT ' Info : FactDimesnionInstance  Table Loaded Successfully';
/********************************************************************************************************************************
3.	Update Source Table  :psa.rawuk_base_plan_product 
	Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
**********************************************************************************************************************************/
PRINT '********************Updating Source Table accordingly -> psa.rawuk_base_plan_product****************';  



UPDATE psa.rawuk_base_plan_product SET row_status=@serRowStatus
	FROM psa.rawuk_base_plan_product bp
	Inner Join ser.TmpBasePlanProduct temp ON  bp.row_status=temp.row_status and bp.record_source_id=temp.record_source_id 
	WHERE bp.row_status=@psaRowStatus  AND temp.etl_runlog_id in (CAST(@serveETLRunLogID AS INT)) 
	AND (cast(bp.calendar_week as INT) >@calender_week_max  OR (bp.calendar_week is null));
PRINT 'Info: Source Table Updated accordingly -> psa.rawuk_base_plan_product'; 		
COMMIT TRANSACTION;
END TRY
BEGIN CATCH 
	THROW;
	   ROLLBACK TRANSACTION ;
END CATCH 
drop table [ser].[TmpBasePlanProduct]
PRINT 'Info: Dropped Temp table -> ser.TmpBasePlanProduct';
END
GO
IF OBJECT_ID('psa.sp_rawuk_btc_transaction_line_anon_p') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawuk_btc_transaction_line_anon_p
END;


/****** Object:  StoredProcedure [psa].[sp_rawuk_btc_transaction_line_anon_p]    Script Date: 9/6/2020 9:22:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [psa].[sp_rawuk_btc_transaction_line_anon_p] @psaETLRunLogID [varchar](20),@serveETLRunLogID [Varchar](20),@StartVal [varchar](20),@EndVal [varchar](20) AS

DECLARE
	@tETLRunLogId BigInt,
	@tMaxTillId BigInt,
	@tMaxSiteId Bigint,
	@tMaxSiteRoleId Bigint,
	@tMaxProductId Bigint,
	@tMaxMeasureId BigInt,
	@tMaxTransactionId BigInt,
	@tMaxTransactionLineItemId BigInt,
	@tMaxTransactionLineItemMeasureId BigInt,
	@tLOVRecordSourceId BigInt,
	@tSCDLOVRecordSourceId BigInt,
	@tSCDVersion Int,
	@tSCDActiveFlag NChar(1),
	@tNSCDActiveFlag Nchar(1),
	@tSCDEndDate datetime,
	@tSCDStartDate datetime,
	@tsqlqry Nvarchar(max),
	@tSiteSource int,
	@tDandASourceId Int ,
	@tSAPMDMSourceId Int,
	@tStatusStart Int,
	@tStatusEnd Int,
	@tStatusMissingP Int,
	@tStatusMissingRef Int,
	@tProcCondition Nvarchar(max),
	@tStartVal BigInt,
	@tEndVal BigInt,
	@xact_state smallint;

BEGIN
		
		IF OBJECT_ID('tempdb..#tProductdata') IS NOT NULL
		BEGIN
			DROP TABLE #tProductdata;
		END
		
		IF OBJECT_ID('tempdb..#tMeasureDecimaldata') IS NOT NULL
		BEGIN
			DROP TABLE #tMeasureDecimaldata;
		END
		
		IF OBJECT_ID('tempdb..#tTransactiondata') IS NOT NULL
		BEGIN
			DROP TABLE #tTransactiondata;
		END

			IF OBJECT_ID('tempdb..#tTransactionLinedata') IS NOT NULL
		BEGIN
			DROP TABLE #tTransactionLinedata;
		END

			IF OBJECT_ID('tempdb..#tTransactionIndicator') IS NOT NULL
		BEGIN
			DROP TABLE #tTransactionIndicator;
		END
		
		IF OBJECT_ID('tempdb..#tTransactionLinetgtdata') IS NOT NULL
		BEGIN
			DROP TABLE #tTransactionLinetgtdata;
		END
		

		IF OBJECT_ID('tempdb..#tTransactiontgtdata') IS NOT NULL
		BEGIN
			DROP TABLE #tTransactiontgtdata;
		END
		
		
		CREATE TABLE #tProductdata 
		(
		ProductId BigInt NULL,
		item_code Varchar(100) NULL,
		LOVSourceKeyTypeId BigInt NULL,
		PartyRoleId BigInt NULL,
		row_id BigInt NULL,
		LOVRecordSourceId BigInt NULL
		)
		WITH (DISTRIBUTION = HASH(item_code));

		CREATE TABLE #tMeasureDecimaldata 
    	(
		LOVDataTypeId BigInt NULL,
		LOVMeasureTypeId Bigint NULL
		)
		WITH (DISTRIBUTION = HASH([LOVMeasureTypeId]));

		CREATE TABLE #tTransactiondata 
		(
		epos_transaction_key varchar(100) NULL,
		store_number varchar(20) NULL,
		till_transaction_date varchar(20) NULL,
		till_transaction_time varchar(20) NULL,
		till_number varchar(20) NULL,
		till_transaction_number varchar(100) NULL,
		row_id Bigint NULL,
		record_source_id Bigint NULL
		)
		WITH (DISTRIBUTION = HASH ([epos_transaction_key]))


		CREATE TABLE #tTransactiontgtdata 
		(
		TransactionId BigInt NULL,
		SourceKey varchar(100) NULL,
		LOVTransactionTypeId BigInt NULL,
		SiteRoleId BigInt NULL,
		TransactionDatetime datetime NULL,
		TillId BigInt NULL,
		TillTransactionNumber nVarchar(80) NULL,
		LOVRecordSourceId BigInt NULL,
		SCDStartDate datetime NULL,
		SCDEndDate datetime NULL,
		SCDActiveFlag nchar(1) NULL,
		SCDVersion smallint NULL,
		SCDLOVRecordSourceId int NULL,
		ETLRunLogId int NULL,
		PSARowKey BigInt NULL,
		Valid Int NULL
		)
		WITH (DISTRIBUTION=HASH([SourceKey]));

		CREATE TABLE #tTransactionIndicator
		(
		TransactionId BigInt NULL,
		SourceKey varchar(80) NULL,
		LOVIndicatorId BigInt NULL,
		Value nvarchar(1) NULL,
		LOVRecordSourceId Bigint NULL,
		row_id BigInt NULL,
		Valid Int NULL
		)
		WITH (DISTRIBUTION =HASH([TransactionId]))
		;

		 CREATE TABLE #tTransactionLinedata 
		(
		[epos_transaction_key] nvarchar(100) NULL,
		[item_code] nvarchar(100) NULL,
		[till_transaction_type_code] nvarchar(30) NULL, 
		[sales_units] nvarchar(30) NULL,
		[sales_at_tisp] nvarchar(30) NULL,
		[sales_at_tesp] nvarchar(30) NULL,
		[sales_epos_profit] nvarchar(30) NULL,
		[sap_sales_at_tisp] nvarchar(30) NULL,
		[epos_profit_adjusted] nvarchar(30) NULL,
		[sale_item_discount_percentage] nvarchar(30) NULL,
		[takings] nvarchar(30) NULL,
		[revenue] nvarchar(30) NULL ,
		[item_points_quantity] nvarchar(30) NULL,
		[item_points_value] nvarchar(30) NULL,
		[mapp] nvarchar(30) NULL,
		[refund_flag] nvarchar(30) NULL,
		[item_discount_overridden_flag] nvarchar(30) NULL,
		[price_overridden_item_flag] nvarchar(30) NULL,
		[row_id] Bigint NULL,
        [record_source_id] Int NULL
		)
		WITH (DISTRIBUTION = HASH ([epos_transaction_key]));

		CREATE TABLE #tTransactionLinetgtdata 
		(
		[epos_transaction_key] nvarchar(80) NULL,
		[item_code] nvarchar(30) NULL,
		[till_transaction_type_code] nvarchar(10) NULL, 
	    TransactionLineItemId BigInt NULL,
		TransactionId BigInt NULL,        
		ProductId BigInt NULL,            
		LOVLineItemTypeId BigInt NULL,
		DealId nvarchar(30) NULL,               
		sales_units nvarchar(30) NULL,
		sales_MeasureId BigInt NULL,
		sales_at_tisp nvarchar(30) NULL,
		stisp_MeasureId BigInt NULL,
		sales_at_tesp nvarchar(30) NULL,
		stesp_MeasureId BigInt NULL,
		sales_epos_profit nvarchar(30) NULL,
		eposp_MeasureId BigInt NULL,
		sap_sales_at_tisp nvarchar(30) NULL,
		saptisp_MeasureId Bigint NULL,
		epos_profit_adjusted nvarchar(30) NULL,
		epospa_MeasureId BigInt NULL,
		sale_item_discount_percentage nvarchar(30) NULL,
		disper_MeasureId BigInt NULL,
		takings nvarchar(30) NULL,
		tak_MeasureId BigInt NULL,
		revenue nvarchar(30) NULL,
		rev_MeasureId BigInt NULL,
		item_points_quantity nvarchar(30) NULL,
		item_MeasureId BigInt NULL,
		item_points_value nvarchar(30) NULL,
		itemv_MeasureId BigInt NULL,
		mapp nvarchar(30) NULL,
		map_MeasureId BigInt NULL,
		refund_flag nvarchar(30) NULL,
		refund_LOVIndicatorId BigInt NULL,
		item_discount_overridden_flag nvarchar(30) NULL,
		item_discount_LOVIndicatorId BigInt NULL,
		price_overridden_item_flag nvarchar(30) NULL,
		price_LOVIndicatorId BigInt NULL,
		row_id BigInt NULL,
        record_source_id BigInt NULL,
	    Valid nvarchar(10) NULL
		)
		WITH (DISTRIBUTION = HASH ([epos_transaction_key]));

	SET @tETLRunLogId=@serveETLRunLogID
	SET @tDandASourceId=12012
	SET @tSAPMDMSourceId=12008
	SET @tLOVRecordSourceId=12006
	SET @tSCDLOVRecordSourceId=151
	SET @tSCDVersion=1
	SET @tSCDActiveFlag='Y'
	SET @tNSCDActiveFlag='N'
	SET @tSCDEndDate='9999-12-31 00:00:00'
	SET @tSCDStartDate='1900-01-01 00:00:00'
	SET @tStatusStart =26001
	SET @tStatusEnd=26002
	SET @tStatusMissingP = 26003
	SET @tStatusMissingRef=26004 
	SET @tStartVal=@StartVal
	SET @tEndVal=@EndVal
	SET @xact_state=0
	
		SELECT @tMaxTillId=COALESCE(max(TillId),0) FROM ser.Till ;
		SELECT @tMaxSiteId=COALESCE(max(SiteId),0) FROM ser.Site;
		SELECT @tMaxSiteRoleId=COALESCE(max(SiteRoleId),0) FROM ser.SiteRole;
		SELECT @tMaxProductId=COALESCE(max(ProductId),0) FROM ser.Product;
		SELECT @tMaxMeasureId=COALESCE(max(MeasureId),0) FROM ser.Measure;
		SELECT @tMaxTransactionId=COALESCE(max(TransactionId),0) FROM ser.[transaction];
		SELECT @tMaxTransactionLineItemId=COALESCE(max([TransactionLineItemId]),0) FROM [ser].[TransactionLineItem];
		SELECT @tMaxTransactionLineItemMeasureId=COALESCE(max([TransactionLineItemMeasureId]),0) FROM [ser].[TransactionLineItemMeasure];

		RAISERROR ('Set the variable done', 0, 1) WITH NOWAIT
		-- CHECK IF PSA Has Null for store or product number
BEGIN TRANSACTION;
	BEGIN TRY
		Update psa.rawuk_btc_transaction_line_anon_p SET row_status=@tStatusMissingP Where ([store_number] is NULL OR TRIM([store_number])='')  AND row_status=@tStatusStart AND [row_id] Between @tStartVal and @tEndVal;
			 
		Update psa.rawuk_btc_transaction_line_anon_p SET row_status=@tStatusMissingP Where ([item_code] is NULL OR TRIM([item_code])='') AND row_status=@tStatusStart AND [row_id] Between @tStartVal and @tEndVal;
		
		RAISERROR ('Product id and site check completed', 0, 1) WITH NOWAIT
		-- LOAD Till

	 --delete from ser.Till

		INSERT INTO ser.Till
		SELECT
		    ROW_NUMBER() OVER(ORDER BY tlap.Till_number ) + @tMaxTillId as [TillId],
			tlap.till_number as [SourceKey],
			@tLOVRecordSourceId as [LOVRecordSourceId],
			@tSCDStartDate as [SCDStartDate],
			@tSCDEndDate as [SCDEndDate],
			@tSCDActiveFlag as [SCDActiveFlag],
			@tSCDVersion as [SCDVersion],
			@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
			@tETLRunLogId as [ETLRunLogId],
			tlap.row_id as [PSARowKey]
		FROM (SELECT till_number, max(row_id) as row_id, max(record_source_id) as record_source_id FROM 
		psa.rawuk_btc_transaction_line_anon_p WHERE record_source_id=@tLOVRecordSourceId AND row_status=@tStatusStart AND [row_id] Between @tStartVal and @tEndVal group by till_number) tlap
		WHERE NOT EXISTS   
		(SELECT * FROM ser.Till t WHERE 
		t.[SourceKey] = tlap.till_number
		AND t.[LOVRecordSourceId]=tlap.record_source_id
		AND t.SCDActiveFlag=@tSCDActiveFlag
		)
		;
		--@tSCDLOVRecordSourceId @tStatusStart
		RAISERROR ('Insert into Till table has completed', 0, 1) WITH NOWAIT

--		--Load Site Role


        INSERT INTO ser.SiteRole
		SELECT
		    ROW_NUMBER() OVER(ORDER BY st.store_number ) + @tMaxSiteRoleId as SiteRoleId,
			si.SiteId,
			rf.[LOVId] as LOVRoleId,
			st.store_number as [SourceKey],
			NULL as SiteRoleName,
			NULL as SiteRoleShortName,
			@tSAPMDMSourceId as [LOVRecordSourceId],
			@tSCDStartDate as [SCDStartDate],
			@tSCDEndDate as [SCDEndDate],
			@tSCDActiveFlag as [SCDActiveFlag],
			@tSCDVersion as [SCDVersion],
			@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
			@tETLRunLogId as [ETLRunLogId],
			st.row_id as [PSARowKey]
		FROM 
		(SELECT tlap.store_number, tlap.row_id, tlap.record_source_id FROM
		(SELECT store_number, max(row_id) as row_id, max(record_source_id) as record_source_id FROM 
		psa.rawuk_btc_transaction_line_anon_p WHERE record_source_id=@tLOVRecordSourceId AND row_status=@tStatusStart AND [row_id] Between @tStartVal and @tEndVal group by store_number) tlap
		WHERE NOT EXISTS   
		(SELECT * FROM ser.SiteRole s WHERE 
		s.SourceKey = tlap.store_number
		AND s.SCDActiveFlag=@tSCDActiveFlag
		AND s.LOVRecordSourceId=@tSAPMDMSourceId
		)) st
		INNER JOIN ser.Site si
		ON si.SourceKey='0'
		AND si.[LOVRecordSourceId]=@tDandASourceId
		AND si.SCDActiveFlag=@tSCDActiveFlag
		INNER JOIN ser.[RefLOVSetInfo] rf
		ON rf.LOVKey = 'Store' 
		AND rf.LOVSetName = 'Role'
		;
	

	RAISERROR ('Insert into SiteRole table completed', 0, 1) WITH NOWAIT

----		--Load product records

        INSERT INTO #tProductdata
		--CREATE TABLE #tProductdata WITH (DISTRIBUTION = HASH(Item_Code)) AS
		--(
		SELECT 
		ROW_NUMBER() OVER(ORDER BY pt.item_code ) + @tMaxProductId as [ProductId],
		pt.item_code, rf.LOVId as [LOVSourceKeyTypeId], 
		(SELECT DISTINCT pyr.PartyRoleId FROM
		(SELECT PartyId,LOVRecordSourceId FROM ser.Party
			WHERE SourceKey='WBA-UK-BTC' and SCDActiveFlag='Y' and [LOVRecordSourceId]= 12008)  p
				INNER JOIN ser.PartyRole pyr 
		ON pyr.PartyId=p.PartyId
		AND pyr.LOVRecordSourceId=p.LOVRecordSourceId
		AND pyr.[LOVRecordSourceId]= 12008
		AND pyr.PartyId=p.PartyId		
		INNER JOIN ser.[RefLOVSetInfo] rf2
		ON rf2.LOVKey = 'Retailer' 
		AND rf2.LOVSetName = 'Role'
		AND rf2.[LOVRecordSourceId]=12012
		AND pyr.[LOVRecordSourceId]= 12008
		AND pyr.LovRoleId=rf2.LOVId ) AS
		PartyRoleId		
		, pt.row_id, @tSAPMDMSourceId as LOVRecordSourceId 
		FROM
		(
		SELECT item_code, row_id,record_source_id FROM
		(SELECT item_code, max(row_id) as row_id, max(record_source_id) as record_source_id FROM 
		psa.rawuk_btc_transaction_line_anon_p 
		WHERE record_source_id=@tLOVRecordSourceId AND row_status=@tStatusStart AND [row_id] Between @tStartVal and @tEndVal group by item_code) tlap
		WHERE NOT EXISTS   
		(SELECT * FROM ser.product p WHERE 
		p.[SourceKey] = tlap.item_code
		AND p.[LOVRecordSourceId]=@tSAPMDMSourceId
		AND p.SCDActiveFlag=@tSCDActiveFlag
		)
		) pt
		INNER JOIN ser.[RefLOVSetInfo] rf
		ON rf.LOVKey = 'SAP Article Number' 
		AND rf.LOVSetName = 'Source Key Type'
		--)
		;
	
	RAISERROR ('Tempory product data has been created', 0, 1) WITH NOWAIT

------ Load Product
        INSERT INTO ser.product
		SELECT 
		pt.[ProductId] as [ProductId],
		pt.item_code as [SourceKey],
		pt.[LOVSourceKeyTypeId] as [LOVSourceKeyTypeId],
		NULL as [ProductName],
		NULL as [ProductDescription],
		NULL as [LOVBrandId],
		NULL as [LOVSubBrandId],
		@tSAPMDMSourceId as [LOVRecordSourceId],
		NULL as [ParentProductId],
		@tSCDStartDate as [SCDStartDate],
		@tSCDEndDate as [SCDEndDate],
		@tSCDActiveFlag as [SCDActiveFlag],
		@tSCDVersion as [SCDVersion],
		@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
		@tETLRunLogId as [ETLRunLogId],
		pt.row_id as [PSARowKey]
		FROM psa.#tProductdata pt;

RAISERROR ('Insert into Product table completed', 0, 1) WITH NOWAIT

----		--LOAD Product party Role
		INSERT INTO ser.ProductPartyRole
		SELECT 
		pt.[ProductId] as ProductId,
		pt.[PartyRoleId] as [PartyRoleId],
		pt.[LOVRecordSourceId] as [LOVRecordSourceId],
		@tSCDStartDate as [SCDStartDate],
		@tSCDEndDate as [SCDEndDate],
		@tSCDActiveFlag as [SCDActiveFlag],
		@tSCDVersion as [SCDVersion],
		@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
		@tETLRunLogId as [ETLRunLogId],
		pt.row_id as [PSARowKey]
		FROM psa.#tProductdata pt;


	
--		--Load Measure
--		--> Rference lookup cheks
		


		--CREATE TABLE #tMeasureDecimaldata WITH (DISTRIBUTION = HASH([LOVMeasureTypeId])) AS
    	--(
		INSERT INTO #tMeasureDecimaldata
		SELECT max([LOVDataTypeId]) as [LOVDataTypeId] , max([LOVMeasureTypeId]) as [LOVMeasureTypeId] FROM
		(
		SELECT LOVId as [LOVDataTypeId] , NULL as [LOVMeasureTypeId] FROM ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Data Type' and LOVKey='DECIMAL'  AND [LOVRecordSourceId]=@tDandASourceId
		UNION
		SELECT NULL as [LOVDataTypeId], LOVId as [LOVMeasureTypeId] FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVKey]='RETAIL_TRANS_AGG' and LOVSetKey='Measure Type'  AND [LOVRecordSourceId]=@tDandASourceId
		)rd 
		--)
		;

		RAISERROR ('Created temp Measure data completed', 0, 1) WITH NOWAIT
	
		INSERT INTO ser.Measure
		SELECT 
		ROW_NUMBER() OVER(ORDER BY MeasureName ) + @tMaxMeasureId as [MeasureId],
		[LOVMeasureTypeId],
		[LOVDataTypeId],
		[MeasureName],
		[MeasureDescription],
		[Length],
		[Precision],
		[Scale],
		[StandardMeasureId],
		[LOVRecordSourceId],
		@tSCDStartDate as [SCDStartDate],
		@tSCDEndDate as [SCDEndDate],
		@tSCDActiveFlag as [SCDActiveFlag],
		@tSCDVersion as [SCDVersion],
		@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
		@tETLRunLogId as [ETLRunLogId]
		FROM
		(
		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'sales_units' as  [MeasureName],
		'Quantity of items sold' as [MeasureDescription],
		NULL as [Length],
		NULL as [Precision],
		NULL as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM 
		(
		SELECT max([LOVDataTypeId]) as [LOVDataTypeId] , max([LOVMeasureTypeId]) as [LOVMeasureTypeId] FROM
		(
		SELECT LOVId as [LOVDataTypeId] , NULL as [LOVMeasureTypeId]  FROM ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Data Type' AND LOVName='Integer' AND [LOVRecordSourceId]=@tDandASourceId
		UNION
		SELECT NULL as [LOVDataTypeId], LOVId as [LOVMeasureTypeId] FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId
		) rd ) rf	
		
		UNION

	   SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'sales_at_tisp' as  [MeasureName],
		'TISP - Tax inclusive sales amount' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'sales_at_tesp' as  [MeasureName],
		'TESP (Tax excluding sales amount)' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'sales_epos_profit' as  [MeasureName],
		'sales_epos_profit' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'sap_sales_at_tisp' as  [MeasureName],
		'sap_sales_at_tisp' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'epos_profit_adjusted' as  [MeasureName],
		'epos_profit_adjusted' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'sale_item_discount_percentage' as  [MeasureName],
		'Percent Discount applied to the transaction' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'takings' as  [MeasureName],
		'takings' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'item_points_quantity' as  [MeasureName],
		'AdCard Points Qnty' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'item_points_value' as  [MeasureName],
		'AdCard Points Value in money' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'mapp' as  [MeasureName],
		'Cost of Goods Sold' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf

		UNION

		SELECT 
		rf.[LOVMeasureTypeId],
		rf.[LOVDataTypeId],
		'revenue' as  [MeasureName],
		'revenue' as [MeasureDescription],
		NULL as [Length],
		18 as [Precision],
		6 as [Scale],
		NULL as [StandardMeasureId],
		@tLOVRecordSourceId as [LOVRecordSourceId] FROM #tMeasureDecimaldata rf
		) mea
		WHERE NOT EXISTS 
		(SELECT * FROM ser.Measure tgt
		WHERE mea.[MeasureName]=tgt.[MeasureName]
		AND mea.[LOVMeasureTypeId]=tgt.[LOVMeasureTypeId]
		AND mea.[LOVDataTypeId]=tgt.[LOVDataTypeId]
		AND tgt.[LOVRecordSourceId]=mea.[LOVRecordSourceId]
		AND tgt.SCDActiveFlag=@tSCDActiveFlag
		)
		;
		RAISERROR ('Insert into Measure table completed', 0, 1) WITH NOWAIT
		
			
		----Load Transaction
		--CREATE TABLE #tTransactiondata WITH (DISTRIBUTION = HASH ([epos_transaction_key])) AS
		--(
		INSERT INTO #tTransactiondata
		SELECT 
        [epos_transaction_key] as [epos_transaction_key],
		max([store_number]) as [store_number],
        max([till_transaction_date]) AS [till_transaction_date],
        max([till_transaction_time]) as [till_transaction_time],
        max([till_number]) as [till_number],
		max([till_transaction_number]) as [till_transaction_number],
		max(row_id) as row_id,
        max([record_source_id]) as [record_source_id]
		FROM psa.rawuk_btc_transaction_line_anon_p ts WHERE ts.row_status=@tStatusStart AND [row_id] Between @tStartVal and @tEndVal 
		AND NOT EXISTS  
		(
		select * from ser.[Transaction] t where ts.[epos_transaction_key]=t.SourceKey
		AND t.[SCDActiveFlag]=@tSCDActiveFlag
		)
		group by [epos_transaction_key]
		--)
		;


		RAISERROR ('Insert into transaction temp completed', 0, 1) WITH NOWAIT
	
	-- CREATE THE TRANSACTION TARGET DATA


	 --  CREATE TABLE #tTransactiontgtdata WITH (DISTRIBUTION=HASH([SourceKey])) AS 
		--(
		INSERT INTO #tTransactiontgtdata
		SELECT 
		ROW_NUMBER() OVER(ORDER BY tt.[epos_transaction_key]) + @tMaxTransactionId AS TransactionId,
		tt.[epos_transaction_key] as SourceKey,
		rf.LOVId as [LOVTransactionTypeId],
		sr.SiteRoleId as [SiteRoleId],
		CAST(CONCAT([till_transaction_date],' ',[till_transaction_time]) as datetime) AS [TransactionDatetime],
		ti.[TillId] AS [TillId],
		tt.[till_transaction_number] AS [TillTransactionNumber],
		@tLOVRecordSourceId as [LOVRecordSourceId],
		@tSCDStartDate as [SCDStartDate],
		@tSCDEndDate as [SCDEndDate],
		@tSCDActiveFlag as [SCDActiveFlag],
		@tSCDVersion as [SCDVersion],
		@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
		@tETLRunLogId as [ETLRunLogId],
		tt.row_id as [PSARowKey],
		CASE WHEN rf.LOVId IS NULL OR sr.SiteRoleId IS NULL OR ti.TillId IS NULL THEN 1 ELSE 0 END AS Valid
		FROM #tTransactiondata tt 
		LEFT JOIN ser.[RefLOVSetInfo] rf
		ON rf.LOVSetName='Transaction Type'
		AND rf.LOVKey='RETAIL'
		AND rf.[LOVRecordSourceId]=@tDandASourceId
		LEFT JOIN ser.SiteRole sr
		ON sr.SourceKey=tt.Store_Number
		AND sr.[LOVRecordSourceId]=@tSAPMDMSourceId
		AND sr.SCDActiveFlag=@tSCDActiveFlag
		LEFT JOIN ser.Till ti
		ON ti.[SourceKey]=tt.[Till_number]
		AND ti.[LOVRecordSourceId]=tt.[record_source_id]
		AND ti.[LOVRecordSourceId]=@tLOVRecordSourceId
		AND ti.SCDActiveFlag=@tSCDActiveFlag
		--)
		;

		RAISERROR ('Insert into transaction tgt temp format completed', 0, 1) WITH NOWAIT

	----CLOSE OUT THE EXISITNG RECORD
	--	UPDATE ser.[Transaction] SET SCDActiveFlag=@tNSCDActiveFlag, SCDEndDate=current_timestamp -1 
	--	FROM ser.[Transaction] tgt
	--	INNER JOIN #tTransactiontgtdata tt
	--	ON tgt.[SourceKey]=tt.SourceKey
	--	AND tgt.LOVRecordSourceId=tt.[LOVRecordSourceId]
	--	AND tgt.SCDActiveFlag=@tSCDActiveFlag
	--	AND tt.Valid=0;
	--	;

		RAISERROR ('Update the transaction record completed ', 0, 1) WITH NOWAIT

   --INSERT NEW RECORDS
		INSERT INTO ser.[transaction]
		SELECT 
		[TransactionId],
		[SourceKey],
		[LOVTransactionTypeId],
		[SiteRoleId],
		[TransactionDatetime],
		[TillId],
		[TillTransactionNumber],
		[LOVRecordSourceId],
		[SCDStartDate],
		[SCDEndDate],
		[SCDActiveFlag],
		[SCDVersion],
		[SCDLOVRecordSourceId],
		[ETLRunLogId],
		[PSARowKey]
		FROM #tTransactiontgtdata tt WHERE tt.Valid=0
	    ;

		RAISERROR ('Insert into transaction table completed', 0, 1) WITH NOWAIT

--		-- UPDATE ERROR RECORDS 

		Update psa.rawuk_btc_transaction_line_anon_p SET row_status=@tStatusMissingP FROM psa.rawuk_btc_transaction_line_anon_p tgt 
		INNER JOIN #tTransactiontgtdata t
		ON  tgt.[epos_transaction_key]=t.SourceKey
		AND t.Valid=1 AND tgt.row_status=@tStatusStart
		AND tgt.[row_id] Between @tStartVal and @tEndVal;

		RAISERROR ('Update the PSA status based on transaction', 0, 1) WITH NOWAIT
--	--LOAD into Transaction Indicator

		--CREATE TABLE #tTransactionIndicator WITH (DISTRIBUTION =HASH([TransactionId])) AS
		--(
		INSERT INTO #tTransactionIndicator
		SELECT 
		t.[TransactionId] as [TransactionId],
		t.SourceKey as SourceKey,
		rf.LOVId AS [LOVIndicatorId],
		'N' AS [Value],
		@tLOVRecordSourceId AS [LOVRecordSourceId],
		td.row_id as row_id,
		CASE WHEN t.TransactionId is NULL THEN 1 ELSE 0 END AS Valid
		FROM #tTransactiondata td 
		LEFT JOIN ser.[transaction] t
		ON t.[SourceKey]=td.[epos_transaction_key]
		AND t.LOVRecordSourceId=td.[record_source_id]
		AND t.SCDActiveFlag=@tSCDActiveFlag
		INNER JOIN ser.[RefLOVSetInfo] rf
		ON rf.LOVSetName='Indicator - BUK SAP BW Transaction'
		AND rf.LOVKey='card_flag'
		--)
		;
		RAISERROR ('Create temporay transaction indicator table', 0, 1) WITH NOWAIT

--		-- UPDATE transaction indicator missing parent record

		Update psa.rawuk_btc_transaction_line_anon_p SET row_status=@tStatusMissingP FROM psa.rawuk_btc_transaction_line_anon_p tgt 
		INNER JOIN #tTransactionIndicator t
		ON  tgt.[epos_transaction_key]=t.SourceKey
		AND t.Valid=1 AND tgt.row_status=@tStatusStart
		AND tgt.[row_id] Between @tStartVal and @tEndVal;

		RAISERROR ('Update the failed status falied Indicator records completed', 0, 1) WITH NOWAIT

--		-- Update transaction indicator

		--UPDATE ser.[TransactionIndicator] SET SCDActiveFlag=@tNSCDActiveFlag, SCDEndDate=current_timestamp -1 
		--FROM ser.[TransactionIndicator] tgt
		--INNER JOIN #tTransactionIndicator t
		--ON tgt.[TransactionId]=t.[TransactionId]
		--AND tgt.[LOVRecordSourceId]=t.[LOVRecordSourceId]
		--AND t.Valid=0
		--  	;
		--RAISERROR ('Update the Transaction indicator table', 0, 1) WITH NOWAIT

		

----		-- Insert into transaction Inidcator
		INSERT INTO ser.[TransactionIndicator]
		SELECT 
		tt.[TransactionId] AS [TransactionId],
		tt.[LOVIndicatorId] AS [LOVIndicatorId],
		tt.[Value] AS [Value],
		@tLOVRecordSourceId as [LOVRecordSourceId],
		@tSCDStartDate as [SCDStartDate],
		@tSCDEndDate as [SCDEndDate],
		@tSCDActiveFlag as [SCDActiveFlag],
		@tSCDVersion as [SCDVersion],
		@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
		@tETLRunLogId as [ETLRunLogId],
		tt.row_id as [PSARowKey]
		FROM #tTransactionIndicator tt WHERE Valid=0
		AND NOT EXISTS  
		(
		select * from ser.[TransactionIndicator] t where tt.[TransactionId]=t.[TransactionId]
		AND tt.[LOVIndicatorId]=t.[LOVIndicatorId]
		AND t.[SCDActiveFlag]=@tSCDActiveFlag
		)
		;

		RAISERROR ('Insert into Transaction indicator completed', 0, 1) WITH NOWAIT

----	-- Create line item table Line

	 --  CREATE TABLE #tTransactionLinedata WITH (DISTRIBUTION = HASH ([epos_transaction_key])) AS
		--(
		INSERT INTO #tTransactionLinedata
		SELECT 
        [epos_transaction_key],
		[item_code],
		[till_transaction_type_code],
		[sales_units],
		[sales_at_tisp],
		[sales_at_tesp],
		[sales_epos_profit],
		[sap_sales_at_tisp],
		[epos_profit_adjusted],
		[sale_item_discount_percentage],
		[takings],
		[revenue],
		[item_points_quantity],
		[item_points_value],
		[mapp],
		[refund_flag],
		[item_discount_overridden_flag],
		[price_overridden_item_flag],
		[row_id],
        [record_source_id]
		FROM psa.rawuk_btc_transaction_line_anon_p ts WHERE ts.row_status=@tStatusStart AND [row_id] Between @tStartVal and @tEndVal
		--)
		;

		RAISERROR ('Create temp transaction line data completed', 0, 1) WITH NOWAIT
				
		--CREATE TABLE #tTransactionLinetgtdata WITH (DISTRIBUTION = HASH ([epos_transaction_key])) AS
		--(
		INSERT INTO #tTransactionLinetgtdata
		SELECT 
        [epos_transaction_key],
		[item_code],
		[till_transaction_type_code],
	    ROW_NUMBER() OVER(ORDER BY [epos_transaction_key]) + @tMaxTransactionLineItemId AS [TransactionLineItemId],
		t.[TransactionId] AS [TransactionId],        
		p.ProductId AS [ProductId],            
		trf.LOVId AS [LOVLineItemTypeId],
		NULL AS [DealId],               
		[sales_units],
		sales.[MeasureId] as [sales_MeasureId],
		[sales_at_tisp],
		stisp.[MeasureId] as [stisp_MeasureId],
		[sales_at_tesp],
		stesp.[MeasureId] as [stesp_MeasureId],
		[sales_epos_profit],
		eposp.[MeasureId] as [eposp_MeasureId],
		[sap_sales_at_tisp],
		saptisp.[MeasureId] as [saptisp_MeasureId],
		[epos_profit_adjusted],
		epospa.[MeasureId] as [epospa_MeasureId],
		[sale_item_discount_percentage],
		disper.[MeasureId] as [disper_MeasureId],
		[takings],
		tak.[MeasureId] as [tak_MeasureId],
		[revenue],
		rev.[MeasureId] as [rev_MeasureId],
		[item_points_quantity],
		item.[MeasureId] as [item_MeasureId],
		[item_points_value],
		itemv.[MeasureId] as [itemv_MeasureId],
		[mapp],
		map.[MeasureId] as [map_MeasureId],
		[refund_flag],
		refund.LOVId as refund_LOVIndicatorId,
		[item_discount_overridden_flag],
		item_discount.LOVId as item_discount_LOVIndicatorId,
		[price_overridden_item_flag],
		price.LOVId as price_LOVIndicatorId,
		[row_id],
        [record_source_id],
	    CASE WHEN t.TransactionId IS NULL OR p.ProductId IS NULL THEN 1 ELSE 0 END AS Valid
		FROM #tTransactionLinedata tt
		LEFT JOIN (SELECT [TransactionId], [SourceKey], [LOVRecordSourceId] FROM ser.[transaction] tgt WHERE SCDActiveFlag=@tSCDActiveFlag AND tgt.[LOVRecordSourceId]=@tLOVRecordSourceId ) t
		ON t.[SourceKey]=tt.[epos_transaction_key]
		AND t.[LOVRecordSourceId]=tt.[record_source_id]
		LEFT JOIN ser.Product p
		ON tt.[item_code]=p.SourceKey
		AND p.SCDActiveFlag=@tSCDActiveFlag
		AND p.[LOVRecordSourceId]=@tSAPMDMSourceId
		AND p.[LOVSourceKeyTypeId]=(SELECT LOVId FROM ser.[RefLOVSetInfo] prf WHERE prf.LOVKey = 'SAP Article Number' AND prf.LOVSetName = 'Source Key Type' AND prf.LOVRecordSourceId=@tDandASourceId)
		LEFT JOIN ser.[RefLOVSetInfo] trf
		ON trf.LOVKey =tt.till_transaction_type_code
        AND trf.LOVSetName='till_transaction_type_code'
		AND trf.LOVRecordSourceId = @tLOVRecordSourceId
		LEFT JOIN ser.[RefLOVSetInfo] refund
		ON refund.LOVKey ='refund_flag'
        AND refund.LOVSetName='Indicator - BUK SAP BW Transaction'
		AND refund.LOVRecordSourceId = @tLOVRecordSourceId
		LEFT JOIN ser.[RefLOVSetInfo] item_discount
		ON item_discount.LOVKey ='item_discount_overridden_flag'
        AND item_discount.LOVSetName='Indicator - BUK SAP BW Transaction'
		AND item_discount.LOVRecordSourceId = @tLOVRecordSourceId
		LEFT JOIN ser.[RefLOVSetInfo] price
		ON price.LOVKey ='price_overridden_item_flag'
		AND price.LOVRecordSourceId = @tLOVRecordSourceId
        AND price.LOVSetName='Indicator - BUK SAP BW Transaction'
		AND price.LOVRecordSourceId = @tLOVRecordSourceId
		LEFT JOIN ser.Measure sales
		ON sales.MeasureName='sales_units'
		AND sales.LOVRecordSourceId = @tLOVRecordSourceId
		AND sales.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure stisp
		ON stisp.MeasureName='sales_at_tisp'
		AND stisp.LOVRecordSourceId = @tLOVRecordSourceId
		AND stisp.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure stesp
		ON stesp.MeasureName='sales_at_tesp'
		AND stesp.LOVRecordSourceId = @tLOVRecordSourceId
		AND stesp.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure eposp
		ON eposp.MeasureName='sales_epos_profit'
		AND eposp.LOVRecordSourceId = @tLOVRecordSourceId
		AND eposp.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure saptisp
		ON saptisp.MeasureName='sap_sales_at_tisp'
		AND saptisp.LOVRecordSourceId = @tLOVRecordSourceId
		AND saptisp.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure epospa
		ON epospa.MeasureName='epos_profit_adjusted'
		AND epospa.LOVRecordSourceId = @tLOVRecordSourceId
		AND epospa.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure disper
		ON disper.MeasureName='sale_item_discount_percentage'
		AND disper.LOVRecordSourceId = @tLOVRecordSourceId
		AND disper.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure tak
		ON tak.MeasureName='takings'
		AND tak.LOVRecordSourceId = @tLOVRecordSourceId
		AND tak.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure rev
		ON rev.MeasureName='revenue'
		AND rev.LOVRecordSourceId = @tLOVRecordSourceId
		AND rev.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure item
		ON item.MeasureName='item_points_quantity'
		AND item.LOVRecordSourceId = @tLOVRecordSourceId
		AND item.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		LEFT JOIN ser.Measure itemv
		ON itemv.MeasureName='item_points_value'
		AND itemv.LOVRecordSourceId = @tLOVRecordSourceId
		AND itemv.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		--select * from ser.Measure where LOVRecordSourceId=12006
		LEFT JOIN ser.Measure map
		ON map.MeasureName='mapp'
		AND map.LOVRecordSourceId = @tLOVRecordSourceId
		AND map.LOVMeasureTypeId=(SELECT LOVId FROM  ser.[RefLOVSetInfo] rf
		WHERE rf.[LOVSetKey]='Measure Type' AND LOVKey='RETAIL_TRANS_AGG' AND [LOVRecordSourceId]=@tDandASourceId)
		--)
		;
		
		RAISERROR ('Create temp tgt transaction line table data, completed', 0, 1) WITH NOWAIT

--		-- UPDATE ERRORS 
		Update psa.rawuk_btc_transaction_line_anon_p SET row_status=@tStatusMissingP FROM psa.rawuk_btc_transaction_line_anon_p tgt 
		INNER JOIN #tTransactionLinetgtdata t
		ON  tgt.[epos_transaction_key]=t.[epos_transaction_key]
		AND t.Valid=1 AND tgt.row_status=@tStatusStart
		AND tgt.[row_id] Between @tStartVal and @tEndVal;

		RAISERROR ('Update the PSA status based on transaction Line', 0, 1) WITH NOWAIT

		INSERT INTO ser.TransactionLineItem
		SELECT 
		[TransactionLineItemId],
		[TransactionId],        
		[ProductId],            
		[LOVLineItemTypeId],
		NULL AS [DealId],               
		@tLOVRecordSourceId as [LOVRecordSourceId],
		@tSCDStartDate as [SCDStartDate],
		@tSCDEndDate as [SCDEndDate],
		@tSCDActiveFlag as [SCDActiveFlag],
		@tSCDVersion as [SCDVersion],
		@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
		@tETLRunLogId as [ETLRunLogId],
		tt.row_id as [PSARowKey]
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0
		;

		RAISERROR ('Insert into transaction line item table completed', 0, 1) WITH NOWAIT

		
	   INSERT INTO [ser].[TransactionLineItemMeasure]
	   SELECT 
	   ROW_NUMBER() OVER( ORDER BY [TransactionLineItemId],[MeasureId] ) + @tMaxTransactionLineItemMeasureId AS [TransactionLineItemMeasureId],
		tt.[TransactionLineItemId],
		tt.[MeasureId],
		tt.[Value],
		@tLOVRecordSourceId as [LOVRecordSourceId],
		@tSCDStartDate as [SCDStartDate],
		@tSCDEndDate as [SCDEndDate],
		@tSCDActiveFlag as [SCDActiveFlag],
		@tSCDVersion as [SCDVersion],
		@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
		@tETLRunLogId as [ETLRunLogId],
		tt.row_id as [PSARowKey]
	 FROM 
	 (
	 	SELECT 
		tt.[TransactionLineItemId],
		tt.[sales_MeasureId] AS [MeasureId],
		tt.[sales_units] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[stesp_MeasureId] AS [MeasureId],
		tt.[sales_at_tesp] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[stisp_MeasureId] AS [MeasureId],
		tt.[sales_at_tisp] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[eposp_MeasureId] AS [MeasureId],
		tt.[sales_epos_profit] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

        UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[saptisp_MeasureId] AS [MeasureId],
		tt.[sap_sales_at_tisp] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[epospa_MeasureId] AS [MeasureId],
		tt.[epos_profit_adjusted] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[disper_MeasureId] AS [MeasureId],
		tt.[sale_item_discount_percentage] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0


		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[tak_MeasureId] AS [MeasureId],
		tt.[takings] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[rev_MeasureId] AS [MeasureId],
		tt.[revenue] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[item_MeasureId] AS [MeasureId],
		tt.[item_points_quantity] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0


		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[itemv_MeasureId] AS [MeasureId],
		tt.[item_points_value] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.[map_MeasureId] AS [MeasureId],
		tt.[mapp] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0
	 ) tt
 ;

 RAISERROR ('Insert into Transaction line measure table completed', 0, 1) WITH NOWAIT
 
 
	 INSERT INTO [ser].[TransactionLineItemIndicator]
	 SELECT 
	    tt.[TransactionLineItemId],
        tt.[LOVIndicatorId],
        tt.[Value],
		@tLOVRecordSourceId as [LOVRecordSourceId],
		@tSCDStartDate as [SCDStartDate],
		@tSCDEndDate as [SCDEndDate],
		@tSCDActiveFlag as [SCDActiveFlag],
		@tSCDVersion as [SCDVersion],
		@tSCDLOVRecordSourceId as [SCDLOVRecordSourceId],
		@tETLRunLogId as [ETLRunLogId],
		tt.row_id as [PSARowKey]
	  FROM (
		SELECT 
		tt.[TransactionLineItemId],
		tt.refund_LOVIndicatorId AS [LOVIndicatorId],
		tt.[refund_flag] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.item_discount_LOVIndicatorId AS [LOVIndicatorId],
		tt.[item_discount_overridden_flag] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0

		UNION ALL

		SELECT 
		tt.[TransactionLineItemId],
		tt.price_LOVIndicatorId AS [LOVIndicatorId],
		tt.[price_overridden_item_flag] AS [Value],
		tt.row_id 
		FROM #tTransactionLinetgtdata tt WHERE tt.Valid=0
	      )tt
		  ;

		  RAISERROR ('Insert into Transaction line indicator table completed', 0, 1) WITH NOWAIT

		 -- UPDATE SUCCESS
		Update psa.rawuk_btc_transaction_line_anon_p SET row_status=@tStatusEnd FROM psa.rawuk_btc_transaction_line_anon_p tgt 
		INNER JOIN #tTransactionLinetgtdata t
		ON  tgt.[epos_transaction_key]=t.[epos_transaction_key]
		AND t.Valid=0 AND tgt.row_status=@tStatusStart
		AND tgt.[row_id] Between @tStartVal and @tEndVal;

		RAISERROR ('Update PSA record status to Serve completed ', 0, 1) WITH NOWAIT

END TRY

BEGIN CATCH
DECLARE @error_num varchar(max),
		@error_msg varchar(max),
		@error_sev varchar(max)
		;
		ROLLBACK TRANSACTION;
SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',18,1,@error_num,@error_msg,@error_sev) WITH NOWAIT
	
END CATCH
 COMMIT TRANSACTION;

END
GO
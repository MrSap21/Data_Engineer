IF OBJECT_ID('psa.sp_rawuk_btc_transaction_line_card_p') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawuk_btc_transaction_line_card_p
END;


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*
************************************************************************************************************
Procedure Name			: sp_rawuk_btc_transaction_line_card_p
Purpose					: Load History data from sapbw transaction source table(rawuk.btc_transaction_line_card_p) into Serve Layer Table
Domain					: Transaction
RecordSourceID  for sapbw Transaction	: 12006

**************************************************************************************************************
*/

CREATE PROC [psa].[sp_rawuk_btc_transaction_line_card_p] (@psaETLRunLogID varchar(max), @serveETLRunLogID bigint, @StartVal bigint, @EndVal bigint) AS
DECLARE @uklc_lovRecordSourceID 		BIGINT; 
DECLARE @uklc_scdLovRecordSourceID 		BIGINT; 
DECLARE @psa_rowstatus 					BIGINT; 
DECLARE @ser_rowstatus 					BIGINT;
DECLARE @max_tillid 					BIGINT;
DECLARE @max_siteroleid 				BIGINT; 
DECLARE @uklc_Siteid 					BIGINT; 
DECLARE @uklc_RoleId 					BIGINT;
DECLARE @max_transactionid 				BIGINT; 
DECLARE @uklc_trantypeid 				BIGINT;
DECLARE @max_productid 					BIGINT; 
DECLARE @uklc_srckeytypeid 				BIGINT;
DECLARE @max_loyaltyacctid 				BIGINT;
DECLARE @uklc_indicatorid 				BIGINT;
DECLARE @uklc_partyroleid				BIGINT;
DECLARE @uklc_loyaltypgmid				BIGINT;


DECLARE		@mdm_lovRecordSourceID  	 BIGINT,
			@sapbw_lovSourceKeyTypeId 	 BIGINT,
			@max_transactionLineItemID   BIGINT,
			@max_transactionLineItemMeasureID	 BIGINT,
			@measureTypeID				 BIGINT,
			@integer_dataTypeID			 BIGINT,
			@decimal_dataTypeID			 BIGINT,
			@max_measureID               BIGINT,
			@max_measureID1				 BIGINT,
			@max_measureID2				 BIGINT,
			@max_measureID3				 BIGINT,
			@max_measureID4				 BIGINT,
			@max_measureID5				 BIGINT,
			@max_measureID6				 BIGINT,			
			@max_measureID7				 BIGINT,
			@max_measureID8				 BIGINT,
			@max_measureID9				 BIGINT,
			@max_measureID10			 BIGINT,
			@max_measureID11			 BIGINT,
			@max_measureID12			 BIGINT,
			@salesunits_measureID		 BIGINT,
			@salesattisp_measureID 		 BIGINT,
			@salesattesp_measureID		 BIGINT,
			@saleseposprofit_measureID	 BIGINT,
			@sapsalesattisp_measureID 	 BIGINT,
			@eposprofitadjusted_measureID	 	 BIGINT,
			@saleitemdispercent_measureID	 	 BIGINT,
			@takings_measureID		 	 BIGINT,
			@revenue_measureID		 	 BIGINT,
			@itempointsqty_measureID 	 BIGINT,
			@itempointsval_measureID 	 BIGINT,
			@mapp_measureID			     BIGINT,
			@refundflag_indicatorID		 BIGINT,
			@itemdisoverriddenflag_indicatorID	 BIGINT,
			@priceoverriddenitemflag_indicatorID BIGINT;


/**********   need to declare the schema    ******************/

BEGIN		

SET @uklc_lovRecordSourceID = 12006; 
SET @uklc_scdLovRecordSourceID = 151; 
SET @psa_rowstatus = 26001; 
SET @ser_rowstatus = 26002;
--SET @serveETLRunLogID = 12345;
SET	@mdm_lovRecordSourceID = 12008;

BEGIN TRY
	BEGIN TRANSACTION

/* 1.Table Name : Till */

SET @max_tillid = (SELECT COALESCE(MAX(TillId),0) FROM  [ser].[Till]);

INSERT INTO [ser].[Till] (TillId, SourceKey, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_tillid + ROW_NUMBER() OVER(ORDER BY A.till_number ASC) TillId, 
		A.till_number SourceKey, 
		@uklc_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(SELECT src.till_number, src.date_row from 
(SELECT till_number, record_source_id, MIN(row_id) date_row from [psa].[rawuk_btc_transaction_line_card_p] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and till_number IS NOT NULL and till_number != '' GROUP BY till_number,record_source_id)src 
LEFT OUTER JOIN [ser].[Till] slf on src.till_number = slf.sourcekey and src.record_source_id = slf.LOVRecordSourceId 
where slf.sourcekey IS NULL )A ;

RAISERROR ('Completed insertion of SAPBW source data to TILL table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 2.Table Name : Site */
/*
DECLARE @max_siteid int; DECLARE @uklc_SitetypeId int;
SET @max_siteid = (SELECT COALESCE(MAX(SiteId),0) FROM  [ser].[Site]);
SET @uklc_SitetypeId = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = '0' and rlovset.LOVsetname = 'Site Type');

INSERT INTO [ser].[Site] (SiteId, SourceKey, SiteName, LOVSiteTypeId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId) 
SELECT	@max_siteid + ROW_NUMBER() OVER(ORDER BY store_number ASC) , 
		0 , 
		'UNKNOWN' , 
		ISNULL(@uklc_SitetypeId,159000003) ,    
		12012 , 
		'1900-01-01' , 
		'9999-12-31' , 
		'Y' , 
		'1' ,  
		@uklc_scdLovRecordSourceID , 
		@serveETLRunLogID  
		from [psa].[rawuk_btc_transaction_line_card_p] GROUP BY store_number ;

PRINT 'Info: Site Table Loaded Successfully';
*/
/*************************************************************************************************************************************************************/

/* 3.Table Name : Site_Role */

SET @max_siteroleid = (SELECT COALESCE(MAX(SiteRoleId),0) FROM  [ser].[SiteRole]);
SET @uklc_SiteId = (SELECT siteid from [ser].[site] site where site.LOVRecordSourceId = '12012' and site.LOVSiteTypeId IN (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = '0' and rlovset.LOVsetname = 'Site Type'));
SET @uklc_RoleId = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Store' and rlovset.LOVsetname = 'Role');


INSERT INTO [ser].[Siterole] (SiteRoleId, SiteId, LOVRoleId, SourceKey, SiteRoleName, SiteRoleShortName, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  @max_siteroleid + ROW_NUMBER() OVER(ORDER BY A.sourcekey ASC) SiteRoleId, 
		@uklc_SiteId SiteId,   
		@uklc_RoleId LOVRoleId, 
		A.sourcekey SourceKey, 
		NULL SiteRoleName, 
		NULL SiteRoleShortName, 
		12008 LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion,  
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey
		from 
(SELECT src.sourcekey, src.date_row from 
(SELECT store_number sourcekey, record_source_id, MIN(row_id) date_row 
from [psa].[rawuk_btc_transaction_line_card_p] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and store_number IS NOT NULL and store_number != '' GROUP BY store_number,record_source_id)src
LEFT OUTER JOIN [ser].[Siterole] slf on src.sourcekey = slf.sourcekey 
and slf.LOVRecordSourceId = 12008 where slf.sourcekey IS NULL)A ;

RAISERROR ('Completed insertion of SAPBW source data to SITEROLE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 4.Table Name : Transaction */

SET @max_transactionid = (SELECT COALESCE(MAX(TransactionId),0) FROM  [ser].[Transaction]);
SET @uklc_trantypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'RETAIL' and rlovset.LOVsetname = 'Transaction Type'); 


INSERT INTO [ser].[Transaction]
(TransactionId, SourceKey, LOVTransactionTypeId, SiteRoleId, TransactionDatetime, TillId, TillTransactionNumber, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT 	@max_transactionid + ROW_NUMBER() OVER(ORDER BY trnx.epos_transaction_key ASC) TransactionId, 
		trnx.epos_transaction_key SourceKey, 
		@uklc_trantypeid LOVTransactionTypeId, 
		trnx.SiteRoleId SiteRoleId, 
		CAST (CONCAT(trnx.till_transaction_date,' ',trnx.till_transaction_time) as Datetime) TransactionDatetime, 
		trnx.tillId TillId, 
		trnx.till_transaction_number TillTransactionNumber, 
		@uklc_lovRecordSourceID LOVRecordSourceId, 
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		trnx.row_num PSARowKey from 
(SELECT P.epos_transaction_key,P.siteroleid, P.till_transaction_date, P.till_transaction_time,P.tillid, P.record_source_id, P.startdate, P.row_num, P.till_transaction_number from
(SELECT src.epos_transaction_key,B.siteroleid, src.till_transaction_date, src.till_transaction_time,till.tillid, src.record_source_id, src.till_transaction_number, LEFT(src.date_row,CHARINDEX('_',src.date_row)-1) startdate, RIGHT(src.date_row,LEN(src.date_row)-CHARINDEX('_',src.date_row)) row_num from 
(SELECT epos_transaction_key, store_number, till_transaction_date, till_transaction_time, till_number,till_transaction_number, record_source_id, MIN(CONCAT(till_transaction_date,'_',row_id)) date_row  from [psa].[rawuk_btc_transaction_line_card_p]  where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY epos_transaction_key, store_number, till_transaction_date, till_transaction_time, till_number,till_transaction_number, record_source_id) src 
JOIN (SELECT SiteRoleId, sourcekey from [ser].[Siterole] where lovrecordsourceid = 12008 and SCDActiveFlag = 'Y')B on B.sourcekey = src.store_number
JOIN (SELECT * from [ser].[Till] where LOVRecordSourceID = 12006 and SCDActiveFlag = 'Y') till on src.till_number = till.sourcekey where till.lovrecordsourceid = 12006) P
LEFT OUTER JOIN [ser].[Transaction] T on P.epos_transaction_key = T.sourcekey and CAST (CONCAT(P.till_transaction_date,' ',P.till_transaction_time) as Datetime) = T.TransactionDatetime and P.record_source_id = T.LOVRecordSourceId where T.sourcekey IS NULL )trnx ;


RAISERROR ('Completed insertion of SAPBW source data to TRANSACTION table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 5.Table Name : Product */

SET @max_productid = (SELECT COALESCE(MAX(ProductId),0) FROM  [ser].[Product]);
SET @uklc_srckeytypeid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'SAP Article Number' and rlovset.LOVsetname = 'Source Key Type'); 

INSERT INTO [ser].[Product] (ProductId, SourceKey, LOVSourceKeyTypeId, ProductName, ProductDescription, LOVBrandId, LOVSubBrandId, LOVRecordSourceId, ParentProductId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  @max_productid + ROW_NUMBER() OVER(ORDER BY A.SourceKey ASC) ProductId, 
		A.SourceKey SourceKey, 
		@uklc_srckeytypeid LOVSourceKeyTypeId, 
		null ProductName, 
		null ProductDescription, 
		null LOVBrandId, 
		null LOVSubBrandId, 
		/*null LOVCostCentreId, */
		12008 LOVRecordSourceId,
		null ParentProductId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey from
(SELECT src.sourcekey, src.date_row from 
(SELECT item_code SourceKey, MIN(row_id) date_row, record_source_id from [psa].[rawuk_btc_transaction_line_card_p] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY item_code, record_source_id) src 
LEFT OUTER JOIN [ser].[Product] P on src.sourcekey = P.sourcekey and P.LOVRecordSourceId = 12008 where P.sourcekey IS NULL and  src.sourcekey IS NOT NULL and src.sourcekey != '') A
;


RAISERROR ('Completed insertion of SAPBW source data to PRODUCT table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 6.Table Name : ProductPartyRole */

SET @uklc_roleid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'Retailer' and rlovset.LOVsetname = 'Role'); 
SET @uklc_partyroleid = (SELECT PR.PartyRoleId from ser.PartyRole PR JOIN [ser].[Party] P on P.partyid = PR.partyid where P.sourcekey = 'WBA-UK-BTC' and P.LOVRecordSourceId = 12008 and PR.LOVRoleId = @uklc_roleid);


INSERT INTO [ser].[ProductPartyRole] (ProductId, PartyRoleId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId,PSARowKey)
SELECT  A.productId ProductId, 
		@uklc_partyroleid PartyRoleId, 
		12008 LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId,
		A.date_row PSARowKey from
(SELECT P.productId, src.date_row from
(SELECT item_code,record_source_id, MIN(row_id) date_row from [psa].[rawuk_btc_transaction_line_card_p] 
where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and item_code IS NOT NULL and item_code != '' GROUP BY item_code, record_source_id) src
JOIN [ser].[PRODUCT] P on src.item_code = P.sourcekey and P.LOVRecordSourceId = 12008 and P.SCDActiveFlag = 'Y'
LEFT OUTER JOIN [ser].[ProductPartyRole]PPR on P.productId = PPR.productId and PPR.LOVRecordSourceId = 12008 where PPR.productId IS NULL) A;


RAISERROR ('Completed insertion of SAPBW source data to PRODUCTPARTYROLE table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

/* 7.Table Name : TransactionIndicator */

SET @uklc_indicatorid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'card_flag' and rlovset.LOVsetname = 'Indicator - BUK SAP BW Transaction');

INSERT INTO [ser].[TransactionIndicator] (TransactionId, LOVIndicatorId, [Value], LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)
SELECT  A.TransactionId TransactionId,
		@uklc_indicatorid LOVIndicatorId,
		'Y' [Value],
		12006 LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		A.date_row PSARowKey from 
(SELECT T.TransactionId, src.epos_transaction_key, src.date_row from 
(SELECT epos_transaction_key, record_source_id, MIN(row_id) date_row from [psa].[rawuk_btc_transaction_line_card_p] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) GROUP BY epos_transaction_key, record_source_id) src
JOIN [ser].[TRANSACTION] T on src.epos_transaction_key = T.sourcekey and T.LOVRecordSourceId = 12006 
LEFT OUTER JOIN [ser].[TransactionIndicator] TI on T.TransactionId = TI.TransactionId and T.LOVRecordSourceId = TI.LOVRecordSourceId where TI.TransactionId IS NULL) A ;

RAISERROR ('Completed insertion of SAPBW source data to TRANSACTIONINDICATOR table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

SELECT  @max_transactionLineItemID = COALESCE(MAX(TransactionLineItemId),0) FROM ser.TransactionLineItem
SELECT  @max_measureID = COALESCE(MAX(MeasureId),0) FROM ser.Measure
SELECT  @max_transactionLineItemMeasureID = COALESCE(MAX(TransactionLineItemMeasureId),0) FROM ser.TransactionLineItemMeasure
	

SET @sapbw_lovSourceKeyTypeId = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'SAP Article Number' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Source Key Type'));


/* 8.Table Name  :  TransactionLineItem */

INSERT INTO ser.TransactionLineItem(
	TransactionLineItemId	,
	TransactionId			,
	ProductId				,
	LOVLineItemTypeId		,
	DealId					,
	LOVRecordSourceId		,
	SCDStartDate			,
	SCDEndDate				,
	SCDActiveFlag			,
	SCDVersion				,
	SCDLOVRecordSourceId 	,
	ETLRunLogId				,
	PSARowKey
)  

select 
@max_transactionLineItemID+ROW_NUMBER() OVER(order by A.TransactionId) TransactionLineItemId, 
A.TransactionId TransactionId,
product.ProductId ProductId, 
ro.LOVId LOVLineItemTypeId, 
null DealId, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
row_id PSARowKey 
from
(select sourcekey sourcekey,TransactionId TransactionId, LOVRecordSourceId LOVRecordSourceId, item_code item_code, till_transaction_type_code till_transaction_type_code,row_id,record_source_id from ser.[Transaction] trans 
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code,row_id row_id,record_source_id record_source_id, till_transaction_date, till_transaction_time
from psa.rawuk_btc_transaction_line_card_p where row_status=@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans on trans.sourcekey = sapitemtrans.epos_transaction_key 
and CAST (CONCAT(sapitemtrans.till_transaction_date,' ',sapitemtrans.till_transaction_time) as Datetime) = trans.TransactionDatetime
where trans.LOVRecordSourceId=@uklc_lovRecordSourceID) A
join (select ProductId, sourcekey from ser.Product
where SCDActiveFlag = 'Y' and LOVRecordSourceId = @mdm_lovRecordSourceID and lovsourceKeyTypeId = @sapbw_lovSourceKeyTypeId) product
on product.sourceKey = A.item_code
left outer join(SELECT rl.LOVId,rl.LOVKey,rl.LOVRecordSourceId FROM  ser.reflov rl JOIN ser.reflovset rls 
ON rl.LOVSetID = rls.LOVSetID AND rl.LOVRecordSourceId = rls.LovSetRecordSourceId AND rls.LOVSetName='till_transaction_type_code') ro
ON A.LOVRecordSourceId =ro.LOVRecordSourceId AND ro.LOVKey=A.till_transaction_type_code
;


RAISERROR ('Completed insertion of SAPBW source data to TRANSACTION LINE ITEM table', 0, 1) WITH NOWAIT

/*************************************************************************************************************************************************************/

/* 9.Table Name  :  Measure */

SET @measureTypeID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'RETAIL_TRANS_AGG' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Measure Type'));

SET @integer_dataTypeID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'INT' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Data Type'));

SET @decimal_dataTypeID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'DECIMAL' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Data Type'));


SET @max_measureID1 = @max_measureID + 1;
SET @max_measureID2 = @max_measureID + 2;
SET @max_measureID3 = @max_measureID + 3;
SET @max_measureID4 = @max_measureID + 4;
SET @max_measureID5 = @max_measureID + 5;
SET @max_measureID6 = @max_measureID + 6;
SET @max_measureID7 = @max_measureID + 7;
SET @max_measureID8 = @max_measureID + 8;
SET @max_measureID9 = @max_measureID + 9;
SET @max_measureID10 = @max_measureID + 10;
SET @max_measureID11 = @max_measureID + 11;
SET @max_measureID12 = @max_measureID + 12;

INSERT INTO ser.Measure(
    MeasureId 			,
    LOVMeasureTypeId	,
    LOVDataTypeId		, 
    MeasureName			,        
    MeasureDescription	,
    Length				,
    Precision			,
    Scale				,
    StandardMeasureId	,
	LOVRecordSourceId 	,
    SCDStartDate		,
    SCDEndDate			,
    SCDActiveFlag		,
    SCDVersion 			,
	SCDLOVRecordSourceId,
    ETLRunLogId
) 

select TOP 1 
@max_measureID1 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@integer_dataTypeID LOVDataTypeId, 
'sales_units' MeasureName,        
'Quantity of items sold' MeasureDescription,
null Length,
null Precision,
null Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'sales_units'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select TOP 1
@max_measureID2 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'sales_at_tisp' MeasureName,        
'TISP - Tax inclusive sales amount' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'sales_at_tisp'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID3 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'sales_at_tesp' MeasureName,        
'TESP (Tax excluding sales amount)' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'sales_at_tesp'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID4 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'sales_epos_profit' MeasureName,        
'sales_epos_profit' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'sales_epos_profit'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID5 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'sap_sales_at_tisp' MeasureName,        
'sap_sales_at_tisp' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'sap_sales_at_tisp'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID6 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'epos_profit_adjusted' MeasureName,        
'epos_profit_adjusted' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'epos_profit_adjusted'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID7 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'sale_item_discount_percentage' MeasureName,        
'Percent Discount applied to the transaction' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'sale_item_discount_percentage'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID8 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'takings' MeasureName,        
'takings' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'takings'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID9 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'revenue' MeasureName,        
'revenue' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'revenue'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID10 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'item_points_quantity' MeasureName,        
'AdCard Points Qnty' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'item_points_quantity'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID11 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'item_points_value' MeasureName,        
'AdCard Points Value in money' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'item_points_value'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null

UNION

select top 1
@max_measureID12 MeasureId, 
@measureTypeID LOVMeasureTypeId,
@decimal_dataTypeID LOVDataTypeId, 
'mapp' MeasureName,        
'Cost of Goods Sold' MeasureDescription,
null Length,
18 Precision,
6 Scale,
null StandardMeasureId,
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId
from ser.reflov
left outer join ser.Measure measure
on measure.MeasureName = 'mapp'
and measure.LOVMeasureTypeId = @measureTypeID
and measure.LOVRecordSourceID = @uklc_lovRecordSourceID
where measure.MeasureId is null
;

RAISERROR ('Completed insertion of SAPBW source data to MEASURE table', 0, 1) WITH NOWAIT

/*************************************************************************************************************************************************************/

/* 10.Table Name  :  TransactionLineItemMeasure */

SET @salesunits_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'sales_units' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @salesattisp_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'sales_at_tisp' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @salesattesp_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'sales_at_tesp' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @saleseposprofit_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'sales_epos_profit' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @sapsalesattisp_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'sap_sales_at_tisp' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @eposprofitadjusted_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'epos_profit_adjusted' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @saleitemdispercent_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'sale_item_discount_percentage' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @takings_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'takings' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @revenue_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'revenue' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @itempointsqty_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'item_points_quantity' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @itempointsval_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'item_points_value' and LOVRecordSourceId = @uklc_lovRecordSourceID);
SET @mapp_measureID = (SELECT measureID from ser.Measure measure where lovmeasureTypeId = @measureTypeID and MeasureName = 'mapp' and LOVRecordSourceId = @uklc_lovRecordSourceID);



INSERT INTO ser.TransactionLineItemMeasure(
	TransactionLineItemMeasureId	,
	TransactionLineItemId 			,
	MeasureId  						,
	Value							,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

select @max_transactionLineItemMeasureID+DENSE_RANK() OVER(order by TransactionLineItemId, MeasureId) TransactionLineItemMeasureId, 
TransactionLineItemId, MeasureId, Value, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey
from

(
select 
translineitem.TransactionLineItemId TransactionLineItemId,
@salesunits_measureID MeasureId, 
sales_units Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, sales_units sales_units,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@salesattisp_measureID MeasureId, 
sales_at_tisp Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, sales_at_tisp sales_at_tisp,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@salesattesp_measureID MeasureId, 
sales_at_tesp Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, sales_at_tesp sales_at_tesp,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@saleseposprofit_measureID MeasureId, 
sales_epos_profit Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, sales_epos_profit sales_epos_profit,
row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@sapsalesattisp_measureID MeasureId, 
sap_sales_at_tisp Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, sap_sales_at_tisp sap_sales_at_tisp,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@eposprofitadjusted_measureID MeasureId, 
epos_profit_adjusted Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, epos_profit_adjusted epos_profit_adjusted,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@saleitemdispercent_measureID MeasureId, 
sale_item_discount_percentage Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, sale_item_discount_percentage sale_item_discount_percentage,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@takings_measureID MeasureId, 
takings Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, takings takings,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@revenue_measureID MeasureId, 
revenue Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, revenue revenue,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@itempointsqty_measureID MeasureId, 
item_points_quantity Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, item_points_quantity item_points_quantity,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@itempointsval_measureID MeasureId, 
item_points_value Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, item_points_value item_points_value,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@mapp_measureID MeasureId, 
mapp Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, mapp mapp,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id
)Z
;


RAISERROR ('Completed insertion of SAPBW source data to TRANSACTION LINE ITEM MEASURE table', 0, 1) WITH NOWAIT

/*************************************************************************************************************************************************************/

/* 11.Table Name  :  TransactionLineItemIndicator */

SET @refundflag_indicatorID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'refund_flag' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Indicator - BUK SAP BW Transaction'));

SET @itemdisoverriddenflag_indicatorID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'item_discount_overridden_flag' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Indicator - BUK SAP BW Transaction'));

SET @priceoverriddenitemflag_indicatorID = (SELECT rlov.lovid from ser.reflov rlov where rlov.LOVKey = 'price_overridden_item_flag' 
and rlov.LOVSetId = (select LOVSetId from ser.reflovset where LOVSetName = 'Indicator - BUK SAP BW Transaction'));


INSERT INTO ser.TransactionLineItemIndicator(
	TransactionLineItemId 			,
	LOVIndicatorId					,
	Value							,
	LOVRecordSourceId				,
	SCDStartDate					,
	SCDEndDate						,
	SCDActiveFlag					,
	SCDVersion						,
	SCDLOVRecordSourceId 			,
	ETLRunLogId						,
	PSARowKey
)  

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@refundflag_indicatorID LOVIndicatorId, 
refund_flag Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, refund_flag refund_flag,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@itemdisoverriddenflag_indicatorID LOVIndicatorId, 
item_discount_overridden_flag Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, item_discount_overridden_flag item_discount_overridden_flag,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id

UNION

select 
translineitem.TransactionLineItemId TransactionLineItemId,
@priceoverriddenitemflag_indicatorID LOVIndicatorId, 
price_overridden_item_flag Value, 
@uklc_lovRecordSourceID LOVRecordSourceId, 
'1900-01-01' SCDStartDate, 
'9999-12-31' SCDEndDate, 
'Y' SCDActiveFlag, 
1 SCDVersion, 
@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
@serveETLRunLogID ETLRunLogId,
translineitem.PSARowKey PSARowKey 
from
(select * from ser.TransactionLineItem where LOVRecordSourceId =  @uklc_lovRecordSourceID AND ETLRunLogId = @serveETLRunLogID) translineitem
join (select epos_transaction_key epos_transaction_key, item_code item_code, till_transaction_type_code till_transaction_type_code, price_overridden_item_flag price_overridden_item_flag,
row_id row_id,record_source_id record_source_id from psa.rawuk_btc_transaction_line_card_p where row_status =@psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
)sapitemtrans 
on translineitem.PSARowKey = sapitemtrans.row_id
;


RAISERROR ('Completed insertion of SAPBW source data to TRANSACTION LINE ITEM INDICATOR table', 0, 1) WITH NOWAIT


/************************************************************************************************************************************************************/

/* 12.Table Name : LoyaltyAccount */

SET @max_loyaltyacctid = (SELECT COALESCE(MAX(LoyaltyAccountId),0) FROM  [ser].[LoyaltyAccount]);
SET @uklc_loyaltypgmid = (SELECT rlov.lovid from [ser].[reflov] rlov JOIN [ser].[reflovset] rlovset on rlov.lovsetid = rlovset.lovsetid where rlov.LOVKey = 'ADCARD' and rlovset.LOVsetname = 'loyalty_program' and rlov.LOVRecordSourceId = 12011);

 INSERT INTO [ser].[LoyaltyAccount] (LoyaltyAccountId,LOVLoyaltyProgramId,SourceKey,LOVRecordSourceId,SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	@max_loyaltyacctid + ROW_NUMBER() OVER(ORDER BY final.acct_nbr ASC) LoyaltyAccountId, 
		@uklc_loyaltypgmid LOVLoyaltyProgramId,
		final.acct_nbr SourceKey,
		12011 LOVRecordSourceId,
		'1900-01-01' SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.date_row PSARowKey from
(SELECT src.account_number acct_nbr, src.date_row from 
(SELECT account_number, record_source_id, MIN(row_id) date_row from [psa].[rawuk_btc_transaction_line_card_p] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and account_number is not null and trim(account_number) != '' GROUP BY account_number, record_source_id)src
LEFT OUTER JOIN [ser].[LoyaltyAccount] LA on src.account_number = LA.sourcekey and LA.LOVRecordSourceId = 12011 where LA.sourcekey IS NULL 
) final ;

RAISERROR ('Completed insertion of UK-SAPBW source data to LOYALTYACCOUNT table', 0, 1) WITH NOWAIT;


/*************************************************************************************************************************************************************/

/* 13.Table Name : TransactionLoyaltyAccount */

INSERT INTO [ser].[TransactionLoyaltyAccount] (TransactionId, LoyaltyAccountId, LOVRecordSourceId, SCDStartDate, SCDEndDate, SCDActiveFlag, SCDVersion, SCDLOVRecordSourceId, ETLRunLogId, PSARowKey)

SELECT 	final.TransactionId TransactionId, 
		final.loyaltyaccountid LoyaltyAccountId,
		@uklc_lovRecordSourceID LOVRecordSourceId,
		'1900-01-01'  SCDStartDate, 
		'9999-12-31' SCDEndDate, 
		'Y' SCDActiveFlag, 
		1 SCDVersion, 
		@uklc_scdLovRecordSourceID SCDLOVRecordSourceId, 
		@serveETLRunLogID ETLRunLogId, 
		final.date_row PSARowKey from
(SELECT T.TransactionId, LA.LoyaltyAccountId, src.date_row from
(SELECT account_number, epos_transaction_key, record_source_id, till_transaction_date, till_transaction_time, MIN(row_id) date_row from [psa].[rawuk_btc_transaction_line_card_p] where row_status = @psa_rowstatus and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and account_number is not null and trim(account_number) != '' GROUP BY account_number, epos_transaction_key, record_source_id,till_transaction_date, till_transaction_time)src
JOIN [ser].[TRANSACTION] T on src.epos_transaction_key = T.sourcekey and CAST (CONCAT(src.till_transaction_date,' ',src.till_transaction_time) as Datetime) = T.TransactionDatetime and src.record_source_id = T.LOVRecordSourceId
JOIN [ser].[LoyaltyAccount] LA on src.account_number = LA.sourcekey and LA.LOVRecordSourceId = 12011 and LOVLoyaltyProgramId = @uklc_loyaltypgmid and LA.SCDActiveFlag = 'Y'
LEFT OUTER JOIN [ser].[TransactionLoyaltyAccount] TLA on T.TransactionId = TLA.TransactionId and TLA.LOVRecordSourceId = 12006 where TLA.TransactionId IS NULL
)final;

RAISERROR ('Completed insertion of UK-SAPBW source data to TRANSACTIONLOYALTYACCOUNT table', 0, 1) WITH NOWAIT;

/*************************************************************************************************************************************************************/

update psa.rawuk_btc_transaction_line_card_p
set row_status = 26002
where row_status = 26001
and row_id >= @StartVal and row_id <= @EndVal and [etl_runlog_id] IN (SELECT value FROM STRING_SPLIT(@psaETLRunLogID, ','))
;

RAISERROR ('Completed procedure of UK-SAPBW updated row status to IN SERV', 0, 1) WITH NOWAIT

/*************************************************************************************************************************************************************/

COMMIT TRANSACTION
END TRY

BEGIN CATCH
DECLARE @error_num varchar(max),
		@error_msg varchar(max),
		@error_sev varchar(max)
		;

SELECT  
        @error_num=ERROR_NUMBER()
        ,@error_sev=ERROR_SEVERITY()  
         ,@error_msg=ERROR_MESSAGE() ;  

		RAISERROR ( 'ERROR number:%s,Error message:%s,Error sev:%s',16,1,@error_num,@error_msg,@error_sev)
END CATCH



END;
GO
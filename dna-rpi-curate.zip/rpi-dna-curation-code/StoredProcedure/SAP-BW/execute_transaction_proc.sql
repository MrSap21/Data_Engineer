IF OBJECT_ID('psa.execute_transaction_proc') IS NOT NULL
BEGIN
DROP PROC psa.execute_transaction_proc
END;
GO

CREATE PROC [psa].[execute_transaction_proc] @tableName [varchar](max),@psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max) AS

DECLARE
@tpsaETLRunLogID varchar(1000),
@tserveETLRunLogID varchar(1000),
@tTableName varchar(100),
@tProcName varchar(200),
@tStartVal bigint,
@tEndVal Bigint,
@tIncVal bigInt,
@tStopVal bigInt,
@tProcexec varchar(500),
@returnVal int

BEGIN

SET @tpsaETLRunLogID=@psaETLRunLogID
SET @tserveETLRunLogID=@serveETLRunLogID
SET @tTableName=@tableName

WHILE (SELECT StopVal FROM psa.TransactionExecuteMeta where TableName=@tTableName) > (SELECT StartVal FROM psa.TransactionExecuteMeta where TableName=@tTableName)
	BEGIN
	SELECT @tProcName=procName , @tStartVal=StartVal, @tIncVal=IncVal, @tEndVal= StartVal +  IncVal - 1  
	FROM  psa.TransactionExecuteMeta WHERE TableName=@tTableName;

	RAISERROR ( @tProcName  , 0, 1) WITH NOWAIT
	RAISERROR ( '%d' , 0, 1, @tStartVal) WITH NOWAIT
	RAISERROR ( '%d', 0, 1,@tEndVal) WITH NOWAIT
	RAISERROR ( @tpsaETLRunLogID  , 0, 1) WITH NOWAIT
	RAISERROR ( @tserveETLRunLogID  , 0, 1) WITH NOWAIT
	RAISERROR ( @tTableName  , 0, 1) WITH NOWAIT



	EXEC ('EXEC ' + @tProcName + ' @psaETLRunLogID = ''' + @tpsaETLRunLogID +''',@serveETLRunLogID = ' + @tserveETLRunLogID + ',@StartVal = ' + @tStartVal + ',@EndVal = ' + @tEndVal);

			UPDATE psa.TransactionExecuteMeta SET StartVal=@tEndVal + 1  where TableName=@tTableName; 
			
		
		
	END
END
GO
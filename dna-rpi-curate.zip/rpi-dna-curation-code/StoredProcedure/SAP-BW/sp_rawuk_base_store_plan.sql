/****** Object:  StoredProcedure [psa].[sp_rawuk_base_store_plan]    Script Date: 07/08/2020 18:05:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*****************************************************************************************************************
-- This Procedure is for populating the records in serve layer tables from the source table RAWUK_BASE_STORE_PLAN
-- Source Table: psa.RAWUK_BASE_STORE_PLAN
-- Target Tables : [ser].[FactInstance],[ser].[FactDimensionInstance],[ser].[FactMeasureInstance]
*****************************************************************************************************************/

IF OBJECT_ID('[psa].[sp_rawuk_base_store_plan]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_rawuk_base_store_plan] 
END
GO

CREATE PROC [psa].[sp_rawuk_base_store_plan] @psaETLRunLogID [varchar](MAX),@serveETLRunLogID [varchar](MAX),@tableName [varchar](200) AS


--drop temp table if exists

IF OBJECT_ID('ser.TempBaseStorePlan') IS NOT NULL
BEGIN
DROP TABLE ser.TempBaseStorePlan;
END

--create temp table


CREATE TABLE [ser].[TempBaseStorePlan]
(
	[row_num] [int] NOT NULL,
	[site_role_id] [bigint] NULL,
	[floor_plan_id] [int] NULL,
	[calender_week_id] [int] NULL,
	[fiscal_week_id] [int] NULL,
	[planogram_id] [bigint] NULL,
	[sales_quantity_measure_id] [int] NULL,
	[sales_tesp_measure_id] [int] NULL,
	[sales_tisp_measure_id] [int] NULL,
	[sales_epgp_measure_id] [int] NULL,
	[modular_build_measure_id] [int] NULL,
    [build_size_measure_id] [int] NULL,
	[instances_measure_id] [int] NULL,
	[row_id] [bigint] NOT NULL,
	[store] [nvarchar](500) NULL,
	[floor_plan] [nvarchar](500) NULL,
	[calendar_week] [nvarchar](500) NULL,
	[fiscal_week] [nvarchar](500) NULL,
	[pog_id] [nvarchar](500) NULL,
	[sales_qty] [nvarchar](500) NULL,
	[sales_tesp] [nvarchar](500) NULL,
	[sales_tisp] [nvarchar](500) NULL,
	[sales_epgp] [nvarchar](500) NULL,
	[modular_build] [nvarchar](500) NULL,
    [build_size] [nvarchar](500) NULL,
	[instances] [nvarchar](500) NULL,
	[record_source_id] [int] NULL,
	[row_status] [bigint] NULL,
	[etl_runlog_id] [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([row_num],[record_source_id])
)

BEGIN
BEGIN TRANSACTION;

--declare variables

DECLARE 	@max_FactInstanceID bigint,
            @psaRowStatus int, 
            @serRowStatus int,
            @planogram_type_id int,
			@fact_type_id int,
			@max_FactID int,
		    @max_DimensionId int,
			@SCDStartDate datetime =(SELECT CONVERT(datetime2,'1900-01-01 00:00:00')),
			@SCDEndDate datetime =(SELECT CONVERT(datetime2,'9999-12-31 00:00:00')),
			@SCDActiveFlag char ='Y',
			@SCDVersion smallint ='1',
			@LOVRecordSourceId int =12006,
			@PlLOVRecordSourceId int = 12002,
			@SrLOVRecordSourceId int = 12008,
			@SCDLOVRecordSourceId int =151,
			@max_calendarweek int,
			@dimensionid_calendarweek int;
			
			
--Set Maximum factInstnace id from the table  ser.FactInstance and Rowstatus values for both PSA and SERVE Layer
SET @max_FactInstanceId=(SELECT COALESCE(MAX(FactInstanceId),0)  from ser.FactInstance);
SET @psaRowStatus=26001;
SET @serRowStatus=26002;

/*-------Derive the lookup table constant values and Set to Variables-------*/
SELECT @planogram_type_id=rl.LovId from ser.Reflov rl where rl.LOVKey = 'Intactix Planogram Id(value50)' AND rl.LOVSetId = (SELECT rls.LOVSetId from ser.Reflovset rls where rls.LOVSetName = 'Source Key Type');
SET @fact_type_id = (SELECT rl.LovId from ser.RefLov rl where rl.LOVKey = 'TBC' AND rl.LOVSetId = (SELECT rls.LOVSetId from ser.RefLovSet rls where rls.LOVSetName = 'Fact Type'));
SET @dimensionid_calendarweek = (SELECT DimensionId from ser.Dimension where Name = 'calendar_week' and LOVRecordSourceId = @LOVRecordSourceId);
SET @max_calendarweek =(SELECT COALESCE(MAX(DimensionSourceKey),0)  from ser.FactDimensionInstance fdi
                        LEFT join ser.FactInstance fi
                        on fi.FactInstanceId = fdi.FactInstanceId
                        LEFT join ser.Fact f
                        on f.factId = fi.factId
                        WHERE f.LOVRecordSourceId = @LOVRecordSourceId AND
                        fdi.DimensionId = @dimensionid_calendarweek AND f.FactName = 'BASE STORE PLAN');

BEGIN TRY
---INSERT TO TEMP TABLE	      

INSERT INTO [ser].[TempBaseStorePlan]

select ROW_NUMBER() OVER (ORDER BY row_id) + @max_FactInstanceID row_num,
srd.SiteRoleId as site_role_id,
fp.LOVId as floor_plan_id,
cw.LOVId as calender_week_id,
fw.LOVId as fiscal_week_id,
(case when 
(SELECT COUNT(planogramid) FROM (select planogramid,LOVSourceKeyTypeId,LOVRecordSourceId,SCDActiveFlag from ser.planogram pl
where pl.sourcekey = bsp.pog_id AND pl.LOVSourceKeyTypeId = @planogram_type_id and pl.LOVRecordSourceId=@PlLOVRecordSourceId 
and pl.SCDActiveFlag = 'Y'
group by LOVSourceKeyTypeId,LOVRecordSourceId,planogramid,SCDActiveFlag) SS)=1 
THEN (select  planogramid from ser.planogram pl where pl.sourcekey = bsp.pog_id
AND pl.LOVSourceKeyTypeId = @planogram_type_id and pl.LOVRecordSourceId=@PlLOVRecordSourceId and pl.SCDActiveFlag = 'Y') ELSE NULL END)planogram_id,
(SELECT MeasureId from ser.Measure m where m.MeasureName = 'sales_qty' AND m.LOVRecordSourceId = @LOVRecordSourceId) as sales_quantity_measure_id,
(SELECT MeasureId from ser.Measure m where m.MeasureName = 'sales_tesp' AND m.LOVRecordSourceId = @LOVRecordSourceId) as sales_tesp_measure_id,
(SELECT MeasureId from ser.Measure m where m.MeasureName = 'sales_tisp' AND m.LOVRecordSourceId = @LOVRecordSourceId) as sales_tisp_measure_id,
(SELECT MeasureId from ser.Measure m where m.MeasureName = 'sales_epgp' AND m.LOVRecordSourceId = @LOVRecordSourceId) as sales_epgp_measure_id,
(SELECT MeasureId from ser.Measure m where m.MeasureName = 'modular_build' AND m.LOVRecordSourceId = @LOVRecordSourceId) as modular_build_measure_id,
(SELECT MeasureId from ser.Measure m where m.MeasureName = 'build_size' AND m.LOVRecordSourceId = @LOVRecordSourceId) as build_size_measure_id,
(SELECT MeasureId from ser.Measure m where m.MeasureName = 'instances' AND m.LOVRecordSourceId = @LOVRecordSourceId) as instances_measure_id,
row_id,
store,
floor_plan,
calendar_week,
fiscal_week,
pog_id,
sales_qty,
sales_tesp,
sales_tisp,
sales_epgp,
modular_build,
build_size,
instances,
record_source_id,
row_status,
CAST(@serveETLRunLogID as INT) etl_runlog_id
from psa.rawuk_base_store_plan bsp 

left join (select sr.SiteRoleId,sr.SourceKey,sr.LOVRecordSourceId,sr.SCDActiveFlag from ser.SiteRole sr 
                    join ser.RefLov rl
                    on sr.LOVRoleId = rl.LOVId
                            join ser.RefLovSet rls
                            on rl.LOVSETId=rls.LOVSetID                
                            where rls.LOVSetName = 'Role' AND rl.lovkey ='Store' )srd
                            on  srd.SourceKey = bsp.store AND srd.LOVRecordSourceId = @SrLOVRecordSourceId
							AND srd.SCDActiveFlag = 'Y'
left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
                            ser.RefLov rl
                            join ser.RefLovSet rls
                            on rl.LOVSETId=rls.LOVSetID                
                            where rls.LOVSetName = 'floor_plan' )fp
                            on bsp.record_source_id=fp.LOVRecordSourceId and  fp.LOVKey = bsp.floor_plan
left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
                            ser.RefLov rl
                            join ser.RefLovSet rls
                            on rl.LOVSETId=rls.LOVSetID                
                            where rls.LOVSetName = 'calendar_week' )cw
                            on bsp.record_source_id=cw.LOVRecordSourceId and  cw.LOVKey = bsp.calendar_week

left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
                            ser.RefLov rl
                            join ser.RefLovSet rls
                            on rl.LOVSETId=rls.LOVSetID                
                            where rls.LOVSetName = 'fiscal_week' )fw
                            on bsp.record_source_id=fw.LOVRecordSourceId and  fw.LOVKey = bsp.fiscal_week

where bsp.row_status =@psaRowStatus AND bsp.etl_runlog_id in (SELECT value FROM STRING_SPLIT(@psaETLRunLogID,',')) and (CAST(bsp.calendar_week as INT) > @max_calendarweek or (bsp.calendar_week IS NULL));
 

/********************************************************************************************************************************
1.	Table Name  :FactInstance 
	
**********************************************************************************************************************************/

WITH FactInstanceCTE AS 
(select temp.row_num factInstanceId,temp.record_source_id,temp.row_id,f.factId,fd.DimensionId from ser.TempBaseStorePlan temp join ser.FactDimension fd 
on temp.record_source_id = fd.LovRecordSourceId 
join ser.Fact f 
on fd.factId=f.factId where f.factName='BASE STORE PLAN' and f.LOVFactTypeId = @fact_type_id
and  f.LOVrecordSourceId=@LOVRecordSourceId)


INSERT INTO ser.FactInstance(
											FactInstanceId       ,
											FactId               ,
											LOVRecordSourceId    ,
											SCDStartDate         ,
											SCDEndDate           ,
											SCDActiveFlag        ,
											SCDVersion           ,
											SCDLOVRecordSourceId ,
											ETLRunLogId,
                                            PSARowKey )		
						SELECT
						distinct(fi.factInstanceId) FactInstanceId,
							    fi.factId Factid,
							    fi.record_source_id LOVRecordSourceID,
								@SCDStartDate SCDStartDate,
								@SCDEndDate SCDEndDate,
								@SCDActiveFlag SCDActiveFlag,
								@SCDVersion SCDVersion,
								@SCDLOVRecordSourceId SCDLOVRecordSourceId,
								@serveETLRunLogID ETLRunLogId,
                                fi.row_id  PSARowKey								
												FROM FactInstanceCTE fi
												
												PRINT 'Info : FactInstance  Table Loaded Successfully';
											
/********************************************************************************************************************************
2.	Table Name  :FactDimensionInstance 
	
**********************************************************************************************************************************/

WITH FactDimesionInstanceCTE AS 
(select temp.row_num factInstanceId,temp.floor_plan_id,temp.site_role_id,temp.pog_id,temp.calendar_week,temp.fiscal_week,temp.floor_plan,
temp.calender_week_id,temp.fiscal_week_id,temp.planogram_id,temp.store,temp.record_source_id,temp.row_id,f.factId,fd.DimensionId 
from ser.TempBaseStorePlan temp join ser.FactDimension fd 
on temp.record_source_id = fd.LovRecordSourceId 
join ser.Fact f on 
fd.factId=f.factId where f.factName='BASE STORE PLAN' and f.LOVFactTypeId = @fact_type_id
and  f.LOVrecordSourceId=@LOVRecordSourceId)

--select * from ser.FactDimensionInstance where LOVRecordSourceId = 12006

INSERT INTO ser.FactDimensionInstance(
					[FactInstanceId],
					[DimensionId], 
					[DimensionSurrogateKey],
					[DimensionSourceKey],
					[LOVRecordSourceId],
					[SCDStartDate],
					[SCDEndDate],
					[SCDActiveFlag],
					[SCDVersion],
					[SCDLOVRecordSourceId] ,
					[ETLRunLogId],
					[PSARowKey] )	

								
SELECT 
							fdi.factInstanceId FactInstanceId,
							fdi.DimensionId DimensionId,
									fdi.site_role_id DimensionSurrogateKey,   
									fdi.store [DimensionSourceKey],   
									fdi.record_source_id	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
                                    fdi.row_id  PSARowKey
									
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='Store' and d.LOVRecordSourceId = @SrLOVRecordSourceId

					
UNION ALL

							
SELECT 
							fdi.factInstanceId FactInstanceId,
							fdi.DimensionId DimensionId,
									fdi.floor_plan_id	DimensionSurrogateKey,   
									fdi.floor_plan	[DimensionSourceKey],   
									fdi.record_source_id	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
                                    fdi.row_id  PSARowKey			   
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='floor_plan' and d.LOVRecordSourceId = @LOVRecordSourceId


UNION ALL								

								
SELECT 
							fdi.factInstanceId FactInstanceId,
							fdi.DimensionId DimensionId,
									fdi.calender_week_id	DimensionSurrogateKey,   
									fdi.calendar_week [DimensionSourceKey],   
									fdi.record_source_id	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
                                    fdi.row_id  PSARowKey			   
						        FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='calendar_week'  and d.LOVRecordSourceId = @LOVRecordSourceId

								
UNION ALL
								
SELECT 
							fdi.factInstanceId FactInstanceId,
							fdi.DimensionId DimensionId,
									fdi.fiscal_week_id	DimensionSurrogateKey,   
									fdi.fiscal_week 	[DimensionSourceKey],   
									fdi.record_source_id	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
                                    fdi.row_id  PSARowKey			   
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='fiscal_week' and d.LOVRecordSourceId = @LOVRecordSourceId	

UNION ALL

								
SELECT 
							fdi.factInstanceId FactInstanceId,
							fdi.DimensionId DimensionId,
									fdi.planogram_id	DimensionSurrogateKey,   
									fdi.pog_id 	[DimensionSourceKey],   
									fdi.record_source_id	[LOVRecordSourceId],
								    @SCDStartDate SCDStartDate,
								    @SCDEndDate SCDEndDate,
								    @SCDActiveFlag SCDActiveFlag,
								    @SCDVersion SCDVersion,
								    @SCDLOVRecordSourceId SCDLOVRecordSourceId,
								    @serveETLRunLogID ETLRunLogId,
                                    fdi.row_id  PSARowKey			   
								FROM FactDimesionInstanceCTE fdi
								join ser.Dimension d on fdi.DimensionId=d.DimensionId where d.Name='planogram' and d.LOVRecordSourceId = @PlLOVRecordSourceId;	
								
									PRINT ' Info : FactDimesnionInstance  Table Loaded Successfully';
									
/********************************************************************************************************************************
3.	Table Name  :FactMeasureInstance 
	
**********************************************************************************************************************************/									



WITH FactMeasureInstanceCTE AS(												
select temp.row_num,temp.planogram_id,temp.site_role_id,temp.floor_plan_id,temp.calender_week_id,temp.fiscal_week_id,temp.sales_tesp_measure_id,
temp.sales_epgp_measure_id,temp.modular_build_measure_id,temp.build_size_measure_id,temp.instances_measure_id,temp.sales_tisp_measure_id,
temp.sales_quantity_measure_id,temp.pog_id,temp.store,temp.floor_plan,temp.calendar_week,temp.fiscal_week,temp.record_source_id,temp.row_id,temp.sales_qty,
temp.sales_tisp,temp.instances,temp.build_size,temp.modular_build,temp.sales_tesp,temp.sales_epgp,f.factId,fm.MeasureId 
from ser.TempBaseStorePlan temp join ser.FactMeasure fm
on temp.record_source_id = fm.LovRecordSourceId 
join ser.Fact f on 
fm.factId=f.factId
where f.factName='BASE STORE PLAN'
and  fm.LOVrecordSourceId=@LOVRecordSourceId)

INSERT INTO [ser].[FactMeasureInstance]     ([FactInstanceId]
           ,[MeasureId]
           ,[Value]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
		   ,[PSARowKey])
		   
		   SELECT
		   fmi.row_num FactInstanceId,
		   fmi.sales_quantity_measure_id MeasureId,
		   fmi.sales_qty  [Value],
		   fmi.record_source_id [LOVRecordSourceId],
		   @SCDStartDate SCDStartDate,
			@SCDEndDate SCDEndDate,
			@SCDActiveFlag SCDActiveFlag,
			@SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			@serveETLRunLogID ETLRunLogId,
            fmi.row_id  PSARowKey				   
								FROM FactMeasureInstanceCTE fmi
								join ser.Measure m on fmi.MeasureId=m.MeasureId where m.MeasureName='sales_qty' and m.LOVRecordSourceId = @LOVRecordSourceId
								and fmi.Sales_Qty is not null and fmi.Sales_Qty !=''
								

UNION ALL
		   
		   SELECT
		   fmi.row_num FactInstanceId,
		   fmi.sales_tesp_measure_id MeasureId,
		   fmi.sales_tesp  [Value],
		   fmi.record_source_id [LOVRecordSourceId],
		   @SCDStartDate SCDStartDate,
			@SCDEndDate SCDEndDate,
			@SCDActiveFlag SCDActiveFlag,
			@SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			@serveETLRunLogID ETLRunLogId,
            fmi.row_id  PSARowKey				   
								FROM FactMeasureInstanceCTE fmi
								join ser.Measure m on fmi.MeasureId=m.MeasureId where m.MeasureName='sales_tesp' and m.LOVRecordSourceId = @LOVRecordSourceId
								and fmi.sales_tesp is not null and fmi.sales_tesp !=''
							
UNION ALL

		   SELECT
		   fmi.row_num FactInstanceId,
		   fmi.sales_tisp_measure_id MeasureId,
		   fmi.sales_tisp  [Value],
		   fmi.record_source_id [LOVRecordSourceId],
		   @SCDStartDate SCDStartDate,
			@SCDEndDate SCDEndDate,
			@SCDActiveFlag SCDActiveFlag,
			@SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			@serveETLRunLogID ETLRunLogId,
            fmi.row_id  PSARowKey				   
								FROM FactMeasureInstanceCTE fmi
								join ser.Measure m on fmi.MeasureId=m.MeasureId where m.MeasureName='sales_tisp' and m.LOVRecordSourceId = @LOVRecordSourceId
								and fmi.sales_tisp is not null and fmi.sales_tisp !=''
								
UNION ALL
		   
		   SELECT
		   fmi.row_num FactInstanceId,
		   fmi.sales_epgp_measure_id MeasureId,
		   fmi.sales_epgp [Value],
		   fmi.record_source_id [LOVRecordSourceId],
		   @SCDStartDate SCDStartDate,
			@SCDEndDate SCDEndDate,
			@SCDActiveFlag SCDActiveFlag,
			@SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			@serveETLRunLogID ETLRunLogId,
            fmi.row_id  PSARowKey				   
								FROM FactMeasureInstanceCTE fmi
								join ser.Measure m on fmi.MeasureId=m.MeasureId where m.MeasureName='sales_epgp' and m.LOVRecordSourceId = @LOVRecordSourceId
								and fmi.sales_epgp is not null and fmi.sales_epgp !=''

								
UNION ALL
		   
		   SELECT
		   fmi.row_num FactInstanceId,
		   fmi.modular_build_measure_id MeasureId,
		   fmi.modular_build  [Value],
		   fmi.record_source_id [LOVRecordSourceId],
		   @SCDStartDate SCDStartDate,
			@SCDEndDate SCDEndDate,
			@SCDActiveFlag SCDActiveFlag,
			@SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			@serveETLRunLogID ETLRunLogId,
            fmi.row_id  PSARowKey				   
								FROM FactMeasureInstanceCTE fmi
								join ser.Measure m on fmi.MeasureId=m.MeasureId where m.MeasureName='modular_build' and m.LOVRecordSourceId = @LOVRecordSourceId
								and fmi.modular_build is not null and fmi.modular_build !=''
UNION ALL
		   
		   SELECT
		   fmi.row_num FactInstanceId,
		   fmi.build_size_measure_id MeasureId,
		   fmi.build_size  [Value],
		   fmi.record_source_id [LOVRecordSourceId],
		   @SCDStartDate SCDStartDate,
			@SCDEndDate SCDEndDate,
			@SCDActiveFlag SCDActiveFlag,
			@SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			@serveETLRunLogID ETLRunLogId,
            fmi.row_id  PSARowKey				   
								FROM FactMeasureInstanceCTE fmi
								join ser.Measure m on fmi.MeasureId=m.MeasureId where m.MeasureName='build_size' and m.LOVRecordSourceId = @LOVRecordSourceId
								and fmi.build_size is not null and fmi.build_size !=''
								
UNION ALL
		   
		   SELECT
		   fmi.row_num FactInstanceId,
		   fmi.instances_measure_id MeasureId,
		   fmi.instances  [Value],
		   fmi.record_source_id [LOVRecordSourceId],
		   @SCDStartDate SCDStartDate,
		    @SCDEndDate SCDEndDate,
		    @SCDActiveFlag SCDActiveFlag,
			@SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			@serveETLRunLogID ETLRunLogId,
            fmi.row_id  PSARowKey				   
								FROM FactMeasureInstanceCTE fmi
								join ser.Measure m on fmi.MeasureId=m.MeasureId where m.MeasureName='instances' and m.LOVRecordSourceId = @LOVRecordSourceId
								and fmi.instances is not null and fmi.instances !='';

								PRINT ' Info : FactMeasureInstance  Table Loaded Successfully';


/********************************************************************************************************************************
4.	Update Source Table  :psa.rawuk_base_store_plan 
	Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
**********************************************************************************************************************************/
PRINT '********************Updating Source Table accordingly -> psa.rawuk_base_store_plan****************';  



UPDATE psa.rawuk_base_store_plan SET row_status=@serRowStatus
	FROM psa.rawuk_base_store_plan bsp
	Inner Join ser.TempBaseStorePlan temp ON  bsp.row_status=temp.row_status and bsp.record_source_id=temp.record_source_id 
	WHERE bsp.row_status=@psaRowStatus  AND temp.etl_runlog_id in (CAST(@serveETLRunLogID as int)) AND (CAST(bsp.calendar_week as INT) > @max_calendarweek or (bsp.calendar_week IS NULL));
	PRINT 'Info: Source Table Updated accordingly -> psa.rawuk_base_store_plan'; 		
COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    THROW;
ROLLBACK TRANSACTION;
END CATCH
drop table [ser].[TempBaseStorePlan]
PRINT 'Info: Dropped Temp table -> ser.TempBaseStorePlan';
END
GO
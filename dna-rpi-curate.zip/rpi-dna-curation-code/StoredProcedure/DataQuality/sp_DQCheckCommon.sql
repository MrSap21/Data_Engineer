SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('psa.sp_DQCheckCommon') IS NOT NULL
BEGIN
    DROP PROC psa.sp_DQCheckCommon
END
GO
CREATE PROC [psa].[sp_DQCheckCommon] @RuleType [varchar](500) AS
/*
Procedure : sp_DQCheckCommon
Purpose   : This Procedure will check for the RefLOV values which do not have
            any dependency with source data(irrespective of sourceColumn)
*/
DECLARE 
	@cnt int,
	@RuleKey varchar(4000),
	@sql varchar(4000),
	@COUNTER int,
	@MAXID int,
	@RuleSetName varchar(500),
	@SourceColumn varchar(500),
	@SourceTable varchar(500),
	@RecordSourceID int,
	@Status [int]
BEGIN	
       IF OBJECT_ID('tempdb..#TempDQRules') IS NOT NULL
				BEGIN
					DROP TABLE #TempDQRules
				END
	   	SELECT  ROW_NUMBER() OVER(ORDER BY RuleSetName) rowid,RuleSetName,RuleKey,TableName,RecordSourceID 
			INTO #TempDQRules
		FROM psa.[DQRules] WHERE ActiveFlag ='Y' and RuleKey is not null  and TableName ='ALL' and RuleType=''+@RuleType+'';
	    SET @COUNTER = 1
		SET @Status=0
        SELECT @MAXID = COUNT(*) FROM #TempDQRules;
		WHILE (@COUNTER < = @MAXID)
           BEGIN  
		  	 SELECT @RuleSetName=p.RuleSetName ,  @RuleKey=p.RuleKey, @RecordSourceID=RecordSourceID
		  		from #TempDQRules as p WHERE rowid=@COUNTER;
          IF @RecordSourceID is null
		      BEGIN
		  		SELECT  @cnt = Count(*) FROM
		  				ser.reflov rl
		  				 join ser.reflovset rls
		  				on rl.LOVSETId=rls.LOVSetID                 
		  				where rls.LOVSetName = trim(''+@RuleSetName+'') and 
		  				rl.LOVKey = trim(''+@RuleKey+'');
                END
		  ELSE 
		      BEGIN
		  		SELECT  @cnt = Count(*) FROM
		  				ser.reflov rl
		  				 join ser.reflovset rls
		  				on rl.LOVSETId=rls.LOVSetID 
						and rl.LOVRecordSourceId=rls.LOVSetRecordSourceId
		  				where rls.LOVSetName = trim(''+@RuleSetName+'') and 
		  				rl.LOVKey = trim(''+@RuleKey+'')
						and rls.LOVSetRecordSourceId =@RecordSourceID;
                END
		     
		  --PRINT 'Count :' + cast (@Cnt as varchar )
		  		IF @Cnt >0 and @Cnt !=1
				BEGIN
		  		  PRINT ' Info: Multiple Entry available in RefLOV for LOVSetName :'+@RuleSetName+' and LOVKey :'+@RuleKey
		  		  SET @Status=-1
				END 
				 ELSE IF @Cnt=0
				 BEGIN
		  			PRINT ' Info :Entry Missing in RefLOV for LOVSetName :'+@RuleSetName+' and LOVKey :'+@RuleKey
		         SET @Status=-1
                END
			SET @COUNTER = @COUNTER + 1
		   END
		   SELECT @Status as 'ProcedureStatus'
   END
GO
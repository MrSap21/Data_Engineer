SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_DQNullCheck') IS NOT NULL
BEGIN
    DROP PROC psa.sp_DQNullCheck
END
GO

CREATE PROC [psa].[sp_DQNullCheck] @RecordSourceId [varchar](500),@TableName [varchar](500),@RuleType [varchar](500) AS
/*
ProcedureName : [sp_NullCheck]
Purpose       : This Procedure Does the Quality Check for Null for Mandatory Columns
                 and update the psa table row_status with the errorCode -26005(Null Value for Mandatory Field) 
*/
DECLARE 
@sql varchar(8000),
@COUNTER int,
@MAXID int,
@RuleSetName varchar(500),
@ColumnName varchar(500),
@RefLovTab  varchar(4000)='reflov',
@RefLovSetTab  varchar(4000)='reflovset',
@RuleTypeCode varchar(4000) =26005,
@row_status varchar(4000) =26001
SET @COUNTER = 1	
	BEGIN	
	   IF OBJECT_ID('tempdb..#TempDQRulesCheck') IS NOT NULL
				BEGIN
					DROP TABLE #TempDQRulesCheck
				END
		SELECT  ROW_NUMBER() OVER(ORDER BY RecordSourceID) rowid,RuleSetName,ColumnName,RecordSourceID,TableName 
			INTO #TempDQRulesCheck
			FROM psa.[DQRules] WHERE ActiveFlag ='Y' and RecordSourceId =@RecordSourceId and lower(RuleType)=lower(''+@RuleType+'') and lower(TableName)=lower(''+@TableName+'');
		SELECT @MAXID = COUNT(*) FROM #TempDQRulesCheck;
		WHILE (@COUNTER <= @MAXID)
		BEGIN
			SELECT @RuleSetName=dq.RuleSetName ,@ColumnName=dq.ColumnName,@RecordSourceID=dq.RecordSourceID, @TableName=dq.TableName
			from #TempDQRulesCheck as dq WHERE rowid=@COUNTER;
			Print 'Column  '+@ColumnName
			SET @sql ='UPDATE psa.'+@TableName+'
				SET row_status = '+@RuleTypeCode+'
				FROM psa.'+@TableName+' mdmi WHERE (mdmi.'+@ColumnName+' is null  or mdmi.'+@ColumnName+'= '''') AND 
						mdmi.row_status = '+@row_status
						--PRINT @sql		
		 EXEC (@sql );
			 SET @COUNTER = @COUNTER + 1
		 END
 END 
GO
/****** Object:  StoredProcedure [psa].[sp_DQAnomaliesCheck]    Script Date: 16/07/2020 11:37:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_DQAnomaliesCheck') IS NOT NULL
BEGIN
    DROP PROC psa.sp_DQAnomaliesCheck
END
GO

CREATE PROC [psa].[sp_DQAnomaliesCheck] @table_Name [nvarchar](max) AS
/*Purpose : The procedure will identify and log the Anomalies in Data Quality
 TableName(logs) : psa.[DQAnomalies]
 */
DECLARE 
@sql varchar(8000),
@COUNTER int,
@Cnt int,
@MAXID int,
@RuleSetName varchar(500),
@ColumnName varchar(500),
@RecordSourceId [varchar](500),
@TableName [varchar](500),
@DataType [varchar](500),
@RuleType [varchar](500),
@RuleKey [varchar](500),
@row_status [varchar] (20)=26001;
SET @COUNTER = 1
IF  OBJECT_ID('tempdb..#TempDQAnomaliesCheck') IS NOT NULL
BEGIN
    DROP TABLE #TempDQAnomaliesCheck
END
IF trim(upper(@table_Name))=trim(upper('ALLSOURCES'))
BEGIN
	SET @table_Name=  (SELECT STRING_AGG(tablename, ',')  
                     FROM (select distinct tablename FROM psa.DQRules) t); 						 
END
    PRINT 'TableName : ' +@table_Name
	BEGIN	     
		SELECT  ROW_NUMBER() OVER(ORDER BY RecordSourceID) rowid,
		        RuleType,RuleSetName,RuleKey,ColumnName,
				RecordSourceID,TableName,Datatype 
		INTO #TempDQAnomaliesCheck
		FROM psa.[DQRules] WHERE ActiveFlag ='Y' and tableName in  (SELECT value FROM STRING_SPLIT(@table_Name, ',')) ;
		SELECT @MAXID = COUNT(*) FROM #TempDQAnomaliesCheck;		
		WHILE (@COUNTER <= @MAXID)
		BEGIN
			BEGIN TRY 		   
				SELECT @RuleSetName=dq.RuleSetName ,@ColumnName=dq.ColumnName,@RecordSourceID=dq.RecordSourceID, @TableName=dq.TableName,@RuleType=dq.RuleType,@DataType=dq.DataType,@RuleKey=dq.RuleKey
				from #TempDQAnomaliesCheck as dq WHERE rowid=@COUNTER ;			
				IF @RuleType='MissingLookupKeys' 
						BEGIN
							--PRINT  'Rowid:' +cast (@COUNTER  as varchar)+'RuleType:'+@RuleType+';TableName:'+@TableName+';Column :'+@ColumnName+';RuleSetName:'+@RuleSetName+';RecordSourceID :'+@RecordSourceID;
							SET @sql ='INSERT INTO psa.[DQAnomalies](RuleType,tableName,ColumnName,KeyValue,row_id,RecordSourceId,created_timestamp)
										SELECT DISTINCT  '''+@RuleType+''' as RuleType, '''+@TableName+''' as tableName,'''+@RuleSetName+''' LOVSetName, 
											tab.'+@ColumnName+' as LOVKEY,tab.row_id,'+@RecordSourceID+',current_timestamp
										FROM [psa].['+@TableName+'] tab
												left join (select  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
												ser.RefLOV rl
												 join ser.RefLOVSet rls
												on rl.LOVSETId=rls.LOVSetID
												and rl.LOVRecordSourceId=rls.LOVSetRecordSourceId                 
												where rls.LOVSetName = trim('''+@RuleSetName+''' ) )rf
											 on rf.LOVRecordSourceId='+@RecordSourceID+' and  
												rf.LOVKey =tab.'+@ColumnName+' 
											   WHERE  (tab.'+@ColumnName+' is not null  and tab.'+@ColumnName+'!= '''') and
												(tab.Row_Status = '+@row_status+' ) and 
											 rf.LOVRecordSourceId is null' ;
							--PRINT (@sql )
							EXEC (@sql )	
						END	
				ELSE IF  @RuleType='NullForMandatoryField'
						BEGIN
							--PRINT  'Rowid:' +cast (@COUNTER  as varchar)+'RuleType:'+@RuleType+';TableName:'+@TableName+';Column :'+@ColumnName+';RecordSourceID :'+@RecordSourceID;
							 SET @sql ='INSERT INTO psa.[DQAnomalies](RuleType,tableName,ColumnName,KeyValue,row_id,RecordSourceID,created_timestamp)
											SELECT DISTINCT  '''+@RuleType+''' as RuleType, '''+@TableName+''' as tableName,'''+@ColumnName+''' ColumnName, 
												tab.'+@ColumnName+' as LOVKEY,tab.row_id,'+@RecordSourceID+',current_timestamp
							 FROM psa.'+@TableName+' tab WHERE (tab.'+@ColumnName+' is null  or tab.'+@ColumnName+'= '''') AND 
								tab.row_status = '+@row_status;
							--PRINT (@sql )
							EXEC (@sql );
						END
				ELSE IF  @RuleType='IncompatibleDataType'
						BEGIN
							--PRINT  'Rowid:' +cast (@COUNTER  as varchar)+'RuleType:'+@RuleType+';TableName:'+@TableName+';Column :'+@ColumnName+';RuleSetName:'+@RuleSetName+';RecordSourceID :'+@RecordSourceID+';RuleKey:'+@RuleKey+';DataType :'+@DataType
							 SET @sql ='INSERT INTO psa.[DQAnomalies](RuleType,tableName,ColumnName,KeyValue,row_id,RecordSourceID,created_timestamp)
											SELECT DISTINCT '''+@RuleType+''' as RuleType, '''+@TableName+''' as tableName,'''+@ColumnName+''' ColumnName, 
												tab.'+@ColumnName+' as LOVKEY,tab.row_id,'+@RecordSourceID+',current_timestamp
							 FROM psa.'+@TableName+' tab WHERE (tab.'+@ColumnName+' is not null  AND  tab.'+@ColumnName+'!= '''') AND 
								 TRY_CAST('+@ColumnName+ ' AS '+@DataType+') IS NULL and tab.row_status = '+@row_status					
							-- PRINT (@sql )
						    EXEC (@sql )
						END
				ELSE IF  @RuleType='ReferenceValueExists'
						BEGIN					
							IF @RecordSourceID is null
								  BEGIN
								  --PRINT  'Rowid:' +cast (@COUNTER  as varchar)+'RuleType:'+@RuleType+';TableName:'+@TableName+';RuleSetName:'+@RuleSetName+';RuleKey:'+@RuleKey;
									SELECT  @cnt = Count(*) FROM
											ser.reflov rl
											 join ser.reflovset rls
											on rl.LOVSETId=rls.LOVSetID                 
											where rls.LOVSetName = trim(''+@RuleSetName+'') and 
											rl.LOVKey = trim(''+@RuleKey+'');
									END
							ELSE 
								  BEGIN
								  PRINT  'Rowid:' +cast (@COUNTER  as varchar)+'RuleType:'+@RuleType+';TableName:'+@TableName+';Column :'+@ColumnName+';RuleSetName:'+@RuleSetName+';RecordSourceID :'+@RecordSourceID
									SELECT  @cnt = Count(*) FROM
											ser.reflov rl
											 join ser.reflovset rls
											on rl.LOVSETId=rls.LOVSetID 
											and rl.LOVRecordSourceId=rls.LOVSetRecordSourceId
											where rls.LOVSetName = trim(''+@RuleSetName+'') and 
											rl.LOVKey = trim(''+@RuleKey+'')
											and rls.LOVSetRecordSourceId =@RecordSourceID;
									END
							Declare @currentdate datetime =current_timestamp;
							IF @Cnt >0 and @Cnt !=1
								BEGIN				    
									INSERT INTO psa.[DQAnomalies](RuleType,tableName,ColumnName,KeyValue,row_id,RecordSourceID,created_timestamp) VALUES
									(@ruleType,'ALL',@RuleSetName,@RuleKey,null,@RecordSourceID,@currentdate)
									  PRINT 'RuleType:'+@RuleType+';TableName:'+@TableName
									  PRINT 'WARNING: Multiple Entry available in RefLOV for LOVSetName :'+@RuleSetName+' and LOVKey :'+@RuleKey
								 END 
							ELSE IF @Cnt=0
								 BEGIN							 
									  INSERT INTO psa.[DQAnomalies](RuleType,tableName,ColumnName,KeyValue,row_id,RecordSourceID,created_timestamp) VALUES
										(@ruleType,'ALL',@RuleSetName,@RuleKey,null,@RecordSourceID,@currentdate)
									  PRINT 'RuleType:'+@RuleType+';TableName:'+@TableName
									  PRINT 'WARNING :Entry Missing in RefLOV for LOVSetName :'+@RuleSetName+' and LOVKey :'+@RuleKey
								 END			   
						END			
			END TRY
			BEGIN CATCH
				PRINT '!!ERROR: RuleType : '+@RuleType+'; TableName :'+@TableName+' ; Rowid:'+cast (@COUNTER  as varchar);
				PRINT 'ErrorNumber : '+ cast (ERROR_NUMBER()  as varchar)+ ', ErrorMessage : ' +ERROR_MESSAGE() ;    
				THROW	       
			END CATCH 
			SET @COUNTER = @COUNTER + 1;
	    END
END
GO
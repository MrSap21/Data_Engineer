/****** Object:  StoredProcedure [psa].[sp_DQDatatypeCheck]    Script Date: 02/07/2020 12:03:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_DQDatatypeCheck') IS NOT NULL
BEGIN
    DROP PROC psa.sp_DQDatatypeCheck
END
GO

CREATE PROC [psa].[sp_DQDatatypeCheck] @TableName [varchar](max),@RuleType [varchar](max) AS
/*
ProcedureName : [sp_DQDatatypeCheck]
Purpose       : This Procedure Does the Quality Check for incompatible Data types in psa 
                 and update the psa table row_status with the errorCode -26004(Incompatible Data Type) 
*/
DECLARE 
@sql varchar(8000),
@COUNTER int,
@MAXID int,
@RuleSetName varchar(500),
@ColumnName varchar(500),
@RuleTypeCode varchar(4000) =26004,
@row_status varchar(4000) =26001,
@DataType varchar(500)
SET @COUNTER = 1	
	BEGIN	
	   IF OBJECT_ID('tempdb..#TempDataTypeDQRules') IS NOT NULL
				BEGIN
					DROP TABLE #TempDataTypeDQRules
				END
		SELECT  ROW_NUMBER() OVER(ORDER BY TableName,ColumnName) as rowid,ColumnName,TableName,DataType
			INTO #TempDataTypeDQRules
			FROM psa.DQRules WHERE ActiveFlag ='Y' and lower(RuleType)=lower(''+@RuleType+'') and lower(TableName)=lower(''+@TableName+'');
		SELECT @MAXID = COUNT(*) FROM #TempDataTypeDQRules;
		WHILE (@COUNTER <= @MAXID)
		BEGIN
			SELECT   @ColumnName=dq.ColumnName, @TableName=dq.TableName,@DataType=dq.DataType
			from #TempDataTypeDQRules as dq WHERE rowid=@COUNTER;
			Print 'Column  '+@ColumnName
			SET @sql ='UPDATE psa.'+@TableName+'
				SET row_status = '+@RuleTypeCode+'
				FROM psa.'+@TableName+' tab WHERE (tab.'+@ColumnName+' is not null  AND  tab.'+@ColumnName+'!= '''') AND 
						 TRY_CAST('+@ColumnName+ ' AS '+@DataType+') IS NULL and tab.row_status = '+@row_status
					--PRINT @sql		
					EXEC (@sql );
			 SET @COUNTER = @COUNTER + 1
		 END
 END 
GO
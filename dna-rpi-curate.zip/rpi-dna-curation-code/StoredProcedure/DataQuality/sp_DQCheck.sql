SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('psa.sp_DQCheck') IS NOT NULL
BEGIN
    DROP PROC psa.sp_DQCheck
END
GO
CREATE PROC [psa].[sp_DQCheck] @TableName [varchar](500),@RuleType [varchar](500) AS
/*
ProcedureName : [sp_DQCheck]
Purpose       : This Procedure Does the Quality Check against the refLOV and ReflovSet table values
                 and update the psa table row_status with the error code 26006(Missing Lookup Reference)
*/
DECLARE 
@sql varchar(8000),
@COUNTER int,
@MAXID int,
@RuleSetName varchar(500),
@ColumnName varchar(500),
@RefLovTab  varchar(4000)='reflov',
@RefLovSetTab  varchar(4000)='reflovset',
@RuleTypeCode varchar(40) =26006,
@row_status varchar(40) =26001,
@flag int =0,
@RecordSourceID  varchar(40)
SET @COUNTER = 1	
	BEGIN	
	   IF OBJECT_ID('tempdb..#TempDQRulesCheck') IS NOT NULL
				BEGIN
					DROP TABLE #TempDQRulesCheck
				END
		SELECT  ROW_NUMBER() OVER(ORDER BY RecordSourceID,ColumnName) rowid,RuleSetName,ColumnName,RecordSourceID,TableName 
			INTO #TempDQRulesCheck
			FROM psa.[DQRules] WHERE ActiveFlag ='Y' and RuleKey is null and lower(RuleType)=lower(''+@RuleType+'') and lower(TableName)=lower(''+@TableName+'');
		SELECT @MAXID = COUNT(*) FROM #TempDQRulesCheck;
		WHILE (@COUNTER <= @MAXID)	
			BEGIN 
					SELECT @RuleSetName=dq.RuleSetName ,@ColumnName=dq.ColumnName,@RecordSourceID=dq.RecordSourceID, @TableName=dq.TableName
					from #TempDQRulesCheck as dq WHERE rowid=@COUNTER;
					Print 'Column  '+@ColumnName
					IF (@RecordSourceID !='' and @RecordSourceID is not null)
						  BEGIN
							SET @sql ='UPDATE [psa].['+@TableName+']
							SET row_status = CAST ('+@RuleTypeCode+' as int)
							FROM [psa].['+@TableName+'] mdmi
							left join (select  rl.LOVId,rls.LOVSetRecordSourceId,rl.lovkey FROM
											ser.'+@RefLovTab+' rl
											 join ser.'+@RefLovSetTab+' rls
											on rl.LOVSETId=rls.LOVSetID 
											and rl.LOVRecordSourceId=rls.LOVSetRecordSourceId                
											where rls.LOVSetName = trim('''+@RuleSetName+''') )rf
								on rf.LOVSetRecordSourceId = '+@RecordSourceID+'and 
									rf.LOVKey = mdmi.'+@ColumnName+
									' WHERE (mdmi.'+@ColumnName+' is not null  and mdmi.'+@ColumnName+'!= '''') AND 
									mdmi.row_status = '+@row_status+' AND 
									rf.LOVSetRecordSourceId is null'
						 END
					ELSE 
						BEGIN
								   SET @sql ='UPDATE [psa].['+@TableName+']
											SET row_status = CAST ('+@RuleTypeCode+' as int)
											FROM [psa].['+@TableName+'] mdmi
										left join (select  rl.LOVId,rls.LOVSetRecordSourceId,rl.lovkey FROM
										ser.'+@RefLovTab+' rl
										 join ser.'+@RefLovSetTab+' rls
										on rl.LOVSETId=rls.LOVSetID
										and rl.LOVRecordSourceId=rls.LOVSetRecordSourceId                 
										where rls.LOVSetName = trim('''+@RuleSetName+''' ) )rf
									 on rf.LOVKey =mdmi.'+@ColumnName+' and  (mdmi.'+@ColumnName+' is not null  and mdmi.'+@ColumnName+'!= '''')
									   WHERE	  mdmi.row_status = '+@row_status+' AND 
									 rf.LOVSetRecordSourceId is null'
						END									
				    EXEC (@sql );
					SET @COUNTER = @COUNTER + 1			
	         
	         END 	 
			-- SELECT @flag as 'Status'
 END 
GO
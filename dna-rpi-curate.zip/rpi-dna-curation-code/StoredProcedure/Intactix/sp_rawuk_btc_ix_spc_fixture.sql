/****** Object:  StoredProcedure [psa].[sp_rawuk_btc_ix_spc_fixture]    Script Date: 29/07/2020 16:08:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID('psa.sp_rawuk_btc_ix_spc_fixture') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawuk_btc_ix_spc_fixture
END
GO

CREATE  PROC [psa].[sp_rawuk_btc_ix_spc_fixture] @psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max) AS



/*************************************************************************************************************************************************************************
Procedure Name				: sp_rawuk_btc_ix_spc_fixture
Purpose						: Load History data From International Intactix Planogram in psa layer(Intactix) into Serve Layer Table
Domain						: Merchandise
ServeLayer Target Tables	: PlanogramFixture,Measure,PlanogramFixtureProperty(Total 3 Tables)
RecordSourceID  for INTACTIX : 12002
***********************************************************************************
SCD Columns and Concept (latest data is inserted with respect SCD)
************************************************************************************************************
				SCDStartDate        :  DBDateEffectiveFrom 
				SCDEndDate          :  9999-12-31
				SCDActiveFlag       :  'Y'   
				SCDVersion          :  '1' 
				SCDLOVRecordSourceId: 151 
				ETLRunLogId         : RunlogID from psa table
************************************************************************************************************			
Modification History
*************************************************************************************************************************************************************************
08-June-2020  : Incorporated v1.4 mapping changes 
15-June-2020  : Incorporated v1.5 mapping changes                                                             */


IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_fixture_temp') is not null
		BEGIN
			DROP TABLE psa.rawuk_btc_ix_spc_planogram_fixture_temp
		END			
			CREATE TABLE [psa].[rawuk_btc_ix_spc_planogram_fixture_temp]
			(
				dbkey [nvarchar](500) NULL
							
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			);
			
		
	
			
			IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_fixture_property_temp') is not null
		BEGIN
			DROP TABLE psa.rawuk_btc_ix_spc_planogram_fixture_property_temp
		END			
			CREATE TABLE [psa].[rawuk_btc_ix_spc_planogram_fixture_property_temp]
			(
				PlanogramFixtureId bigint NULL
							
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			);
			

			
/*-------DECLARE Variables-------*/
DECLARE @LOVRecordSourceId int,@SCDStartDate datetime,@SCDEndDate datetime,@SCDActiveFlag char,@SCDVersion smallint,@SCDLOVRecordSourceId int, @max_PlanogramFixtureId int, @LOVId int, @LOVUOMId int, @MeasureId int, @psaRowStatus int, @serRowStatus int

BEGIN
BEGIN TRANSACTION;


/*-------Set the MAX value of surrogate Keys to particular Variables-------*/
SET @max_PlanogramFixtureId=(SELECT COALESCE(MAX(PlanogramFixtureId),0) FROM  ser.PlanogramFixture)


/*-------Set the Constant Values to Variables-------*/


SET @SCDEndDate=(SELECT CONVERT(datetime2,'9999-12-31 00:00:00'))
SET @SCDActiveFlag='Y'
SET @SCDVersion=1
SET @SCDLOVRecordSourceId=151
SET @LOVRecordSourceId = 12002
SET @psaRowStatus=26001
SET @serRowStatus=26002


/*-------Derive the lookup table constant values and Set to Variables-------*/
SELECT @LOVId = rl.LOVId FROM ser.RefLov rl
									JOIN ser.RefLovset rls
									on rl.LOVSetId=rls.LOVSetID
									WHERE rl.LOVKey = 'Intactix Planogram dbkey' AND rls.LOVSetName = 'Source Key Type'
SELECT @MeasureId = MeasureId from ser.Measure m where m.MeasureName = 'shelf_number' AND m.LOVRecordSourceId = @LOVRecordSourceId
SELECT @LOVUOMId = rl.LovID from ser.RefLOV rl  
									 JOIN ser.RefLOVSet rls
									 on rl.LovSetID = rls.LovSetID 
									 where rl.LOVKey = 'Unknown' and rls.LOVSetName = 'Unit Of Measure'
									 
									 

 BEGIN TRY

/********************************************************************************************************************************
1.	Table Name  :PlanogramFixture
Condition : Entry for all data in Source table against surrogate key 
**********************************************************************************************************************************/
PRINT 'Info: Loading psa.rawuk_btc_ix_spc_planogram_fixture_temp Table';

 
INSERT INTO [psa].[rawuk_btc_ix_spc_planogram_fixture_temp]
SELECT  sf.dbkey  FROM psa.rawuk_btc_ix_spc_fixture sf  where row_status=@psaRowStatus
					and   sf.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))                      
                       and  sf.dbkey not in  (SELECT  sourcekey FROM ser.PlanogramFixture pf
                        JOIN psa.rawuk_btc_ix_spc_fixture fix on pf.sourcekey = fix.dbkey  where pf.LOVRecordSourceId = @LOVRecordSourceId)


PRINT 'Info: psa.rawuk_btc_ix_spc_planogram_fixture_temp Table Loaded Successfully';


PRINT 'Info: Loading PlanogramFixture Table';	

---INSERT TO PLANOGRAMFIXTURE
INSERT INTO ser.PlanogramFixture (
	PlanogramFixtureId         ,
	PlanogramId					,
	SourceKey					,
    LOVRecordSourceId        	,
    SCDStartDate         		,
    SCDEndDate         			,
    SCDActiveFlag         		,
    SCDVersion         			,
    SCDLOVRecordSourceId        ,
    ETLRunLogId					,
	PSARowKey)	
	
SELECT (@max_PlanogramFixtureId+ ROW_NUMBER() OVER(ORDER BY sf.dbkey ASC)) PlanogramFixtureId, 
	pl.PlanogramId PlanogramId,
    sf.dbkey AS SourceKey,
    sf.record_source_id AS LOVRecordSourceId,
	pl.SCDStartDate  AS SCDStartDate ,
    @SCDEndDate AS SCDEndDate,
    @SCDActiveFlag SCDActiveFlag,  
    @SCDVersion SCDVersion,
	@SCDLOVRecordSourceId AS SCDLOVRecordSourceId,
	CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	sf.row_id as PSARowKey
FROM [psa].[rawuk_btc_ix_spc_fixture] sf         
    JOIN ser.Planogram pl on sf.DBParentPlanogramKey = pl.SourceKey and pl.LOVSourceKeyTypeId= @LOVId and pl.LOVRecordSourceId= @LOVRecordSourceId 	
    LEFT JOIN  ser.PlanogramFixture pf on sf.dbkey =pf.SourceKey 
	JOIN psa.rawuk_btc_ix_spc_planogram_fixture_temp sft on sf.dbkey = sft.dbkey
    WHERE pl.ParentPlanogramId is not null and sf.record_source_id = @LOVRecordSourceId AND sf.row_status= @psaRowStatus
	AND sf.etl_runlog_id in (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) ;
	
	
		
PRINT 'Info: PlanogramFixture Table Loaded Successfully';  	

/********************************************************************************************************************************
 2. Table Name  :PlanogramFixtureProperty
--********************************************************************************************************************************/
PRINT 'Info: Loading psa.rawuk_btc_ix_spc_planogram_fixture_property_temp Table';

INSERT INTO [psa].[rawuk_btc_ix_spc_planogram_fixture_property_temp]
SELECT   pf.PlanogramFixtureId FROM ser.PlanogramFixture pf  where                    
     pf.PlanogramFixtureId  not in  (select pfp.PlanogramFixtureId from  ser.PlanogramFixtureProperty pfp 
	 	join ser.PlanogramFixture pf
		on pfp.PlanogramFixtureId = pf.PlanogramFixtureId where pf.LOVRecordSourceId = @LOVRecordSourceId )
				
PRINT 'Info: psa.rawuk_btc_ix_spc_planogram_fixture_property_temp Table Loaded Successfully'	;


PRINT 'Info: Loading PlanogramFixtureProperty Table';				 
						
--Insert to PlanogramFixtureProperty
insert into ser.PlanogramFixtureProperty (
	PlanogramFixtureId         ,
    MeasureId         		    ,
    LOVUOMId         			,
    Value       			    ,
    LOVRecordSourceId        	,
    SCDStartDate         		,
    SCDEndDate         			,
    SCDActiveFlag         		,
    SCDVersion         			,
    SCDLOVRecordSourceId        ,
    ETLRunLogId,
    PSARowKey	) 
	
SELECT  
	pf.PlanogramFixtureId PlanogramFixtureId,
    @MeasureId MeasureId,
    @LOVUOMId LOVUOMId,
    sf.value1  Value ,
    sf.record_source_id LOVRecordSourceId,
    pf.SCDStartDate AS SCDStartDate ,
    @SCDEndDate  AS SCDEndDate,
    @SCDActiveFlag SCDActiveFlag,  
    @SCDVersion SCDVersion,
    @SCDLOVRecordSourceId  SCDLOVRecordSourceId,
    CAST(@serveETLRunLogID AS INT) ETLRunLogId,
    sf.row_id as PSARowKey 
FROM [psa].[rawuk_btc_ix_spc_fixture] sf
    join ser.PlanogramFixture pf on pf.SourceKey = sf.DBKey and sf.row_status= @psaRowStatus  AND sf.etl_runlog_id in (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
	join  [psa].[rawuk_btc_ix_spc_planogram_fixture_property_temp] fpt ON fpt.PlanogramFixtureId = pf.PlanogramFixtureId 
    left join ser.PlanogramFixtureProperty pfp on pfp.PlanogramFixtureId = pf.PlanogramFixtureId  
    where pf.LOVRecordSourceId = @LOVRecordSourceId  and  sf.value1 is not null and sf.value1!='' ;


	
PRINT 'Info: PlanogramFixtureProperty Table Loaded Successfully';	

/********************************************************************************************************************************
3.	Update Source Table  :psa.rawuk_btc_ix_spc_fixture
	Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
**********************************************************************************************************************************/
PRINT '********************Updating Source Table accordingly -> psa.rawuk_btc_ix_spc_fixture****************';  
	
	UPDATE psa.rawuk_btc_ix_spc_fixture SET row_status=@serRowStatus
	FROM psa.rawuk_btc_ix_spc_fixture sf
	Inner Join ser.PlanogramFixture pf ON  sf.row_id=pf.PSARowKey and sf.record_source_id=pf.LOVRecordSourceId 
	WHERE sf.row_status=@psaRowStatus  AND pf.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))
		

PRINT 'Info: Source Table Updated accordingly -> psa.rawuk_btc_ix_spc_fixture'; 


		
COMMIT TRANSACTION;
END TRY


BEGIN CATCH 
			THROW;        
	        ROLLBACK TRANSACTION ;
END CATCH 
		IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_fixture_temp') is not null
		BEGIN
			DROP TABLE psa.rawuk_btc_ix_spc_planogram_fixture_temp
			PRINT 'Info: Dropped Temp table -> [psa].[rawuk_btc_ix_spc_planogram_fixture_temp]';
		END	

		IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_fixture_property_temp') is not null
		BEGIN
			drop table psa.rawuk_btc_ix_spc_planogram_fixture_property_temp
			PRINT 'Info: Dropped Temp table -> psa.rawuk_btc_ix_spc_planogram_fixture_property_temp';
		END	

		
END
GO
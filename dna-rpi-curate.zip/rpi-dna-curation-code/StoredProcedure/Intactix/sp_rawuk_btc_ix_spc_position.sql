/****** Object:  StoredProcedure [psa].[sp_rawuk_btc_ix_spc_position]    Script Date: 30-July-2020 12:35:30 ******/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_rawuk_btc_ix_spc_position') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawuk_btc_ix_spc_position
END 
GO
CREATE PROC [psa].[sp_rawuk_btc_ix_spc_position] @psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max) AS

/*
************************************************************************************************************
Procedure Name				: sp_rawuk_btc_ix_spc_position
Purpose						: Load History dataetl_runlog_id From International Intactix PlanogramPosition in psa layer(Intactix ) into Serve Layer Table
							: This Procedure for populating the records from serve layer tables from the source table RAWUK_BTC_IX_SPC_POSITION
Domain						: Merchandise
ServeLayer Target Tables	: [ser].[PlanogramPosition],[ser].[PlanogramPositionProperty]
RecordSourceID  for INTACTIX : 12002
*****************************************************************************************
SCD Columns and Concept (latest data is inserted with respect SCD)
************************************************************************************************************
***HISTORY/HISTORY CATCH UP NEW RECORDS******
				SCDStartDate        :  PlanogramStartDate
				SCDEndDate          :  9999-12-31
				SCDActiveFlag       :  'Y'   
				SCDVersion          :  '1' 
				SCDLOVRecordSourceId: 151 
				serveETLRunLogId    : RunlogID from api passing asa parameter
*******HISTORY CATCH UP Existing Records*******
				PlanogramID			:  We are not expecting any duplicate records in history catch up also. Duplicate records will exclude.
				SCDStartDate        :  PlanogramStartDate
				SCDEndDate          :  SCDStartdate of the corresponding PlanogramId
				SCDActiveFlag       :  'Y'   
				SCDVersion          :  1
				SCDLOVRecordSourceId: 151 
				serveETLRunLogId    : RunlogID from api passing asa parameter

*************************************************************************************************************
Modification History
*************************************************************************************************************
10-June-2020  : Incorporated v1.4 mapping changes 
16-June-2020  : Incorporated v1.5 mapping changes  
28-July-2020  : Incorporated the SCD changes
30-July-2020  : Temp table added instead of not in sub query
*/

IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_position_temp') is not null
		BEGIN
			DROP TABLE psa.rawuk_btc_ix_spc_planogram_position_temp
		END			
			CREATE TABLE [psa].[rawuk_btc_ix_spc_planogram_position_temp]
			(
				dbkey [nvarchar](500) NULL
							
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			);
			
			IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_position_property_temp') is not null
		BEGIN
			DROP TABLE psa.rawuk_btc_ix_spc_planogram_position_property_temp
		END			
			CREATE TABLE [psa].[rawuk_btc_ix_spc_planogram_position_property_temp]
			(
				PlanogramPositionId bigint NULL
							
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			);
			
			
--Variables
DECLARE @max_planogram_position_id   int,@record_source_id   int, @lov_uom_id int, @scd_lov_record_source_id int, @psaRowStatus int, @serRowStatus int,@SCDEndDate datetime,@SCDActiveFlag char,@SCDVersion smallint;
IF OBJECT_ID('ser.PlanogramPositionPropertyTemp') IS NOT NULL
BEGIN
DROP TABLE ser.PlanogramPositionPropertyTemp;
END 
--Creating a intermediate physical table
 CREATE TABLE ser.PlanogramPositionPropertyTemp
(
	PlanogramPositionId bigint,
	MeasureId int,
	LOVUOMId int,
	PIValue varchar(10),
	LOVRecordSourceId int,
	SCDStartDate date,
	SCDEndDate date,
	SCDActiveFlag char(1),
	SCDVersion int,
	SCDLOVRecordSourceId int,
	ETLRunLogId int,
	PSARowKey int
	)WITH
				(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
				);	  
PRINT 'Info: Intermediate table ser.PlanogramPositionPropertyTemp is created'; 
BEGIN 
BEGIN TRANSACTION;
--Record Source Id for Intactix
SET @record_source_id = 12002;
--SCD Lov Records Source Id , Hadoop source
SET @scd_lov_record_source_id = 151
SET @psaRowStatus=26001
SET @serRowStatus=26002
SET @SCDEndDate=(SELECT CONVERT(datetime2,'9999-12-31 00:00:00'))
SET @SCDActiveFlag='Y'
SET @SCDVersion = 1
-- Taking the max planogram postion id for surroage key generation.
SELECT @max_planogram_position_id = COALESCE((SELECT MAX(PlanogramPositionId) FROM [ser].[PlanogramPosition]),0) 
SELECT @lov_uom_id=(Select LovID from ser.RefLOV rl inner join ser.RefLOVSet rls on rl.LovSetID = rls.LovSetID where LOVSetName = 'Unit Of Measure' and  LOVKey  = 'Unknown')
BEGIN TRY


INSERT INTO [psa].[rawuk_btc_ix_spc_planogram_position_temp]
SELECT  sp.dbkey  FROM psa.rawuk_btc_ix_spc_position sp  where row_status=@psaRowStatus
					and   sp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))                      
                       and  sp.dbkey not in  (SELECT  sourcekey FROM ser.PlanogramPosition pp
                        JOIN psa.rawuk_btc_ix_spc_position pos on pp.sourcekey = pos.dbkey)

/********************************************************************************************************************************
1.	Table Name  :PlanogramPosition
	Condition : Entry for all data in Source table against surrogate key (SourceID & record_source_id)
**********************************************************************************************************************************/
INSERT INTO [ser].[PlanogramPosition]
           ([PlanogramPositionId]
           ,[ProductId]
           ,[PlanogramId]
           ,[PlanogramFixtureId]
           ,[SourceKey]
           ,[LOVRecordSourceId]
           ,[SCDStartDate]
           ,[SCDEndDate]
           ,[SCDActiveFlag]
           ,[SCDVersion]
           ,[SCDLOVRecordSourceId]
           ,[ETLRunLogId]
		   ,[PSARowKey])
		   
SELECT 
 (@max_planogram_position_id + ROW_NUMBER() OVER(ORDER BY pps.dbkey ASC)   ) PlanogramPositionId,  
pr.ProductId, 
pl.PlanogramId,
pf.PlanogramFixtureId,
pps.dbkey AS SourceKey,
pps.record_source_id AS LOVRecordSourceId,
pl.PlanogramStartDate as SCDStartDate,
@SCDEndDate AS SCDEndDate,
@SCDActiveFlag  AS SCDActiveFlag,
@SCDVersion AS SCDVersion,
@scd_lov_record_source_id AS SCDLOVRecordSourceId,
CAST(@serveETLRunLogID AS INT) ETLRunLogId,
pps.row_id as PSARowKey
FROM psa.RAWUK_BTC_IX_SPC_POSITION pps 
JOIN psa.RAWUK_BTC_IX_SPC_PRODUCT ixpr ON ixpr.dbkey =  pps.dbparentproductkey
JOIN ser.Product pr ON  ixpr.id  =   pr.SourceKey
JOIN ser.Planogram pl ON pps.DBParentPlanogramKey = pl.SourceKey
JOIN ser.PlanogramFixture pf ON pps.DBParentFixtureKey = pf.SourceKey
JOIN psa.rawuk_btc_ix_spc_planogram_position_temp spt on pps.dbkey = spt.dbkey
LEFT JOIN ser.PlanogramPosition pp ON pp.sourcekey = pps.dbkey
WHERE pps.record_source_id = @record_source_id  AND pr.LOVRecordSourceId = @record_source_id AND pl.LOVRecordSourceId = @record_source_id AND pf.LOVRecordSourceId = @record_source_id 
AND pl.parentplanogramid is not null
AND pps.row_status= @psaRowStatus 
AND pf.SCDActiveFlag = 'Y' AND pl.SCDActiveFlag = 'Y' AND pr.SCDActiveFlag = 'Y'
AND ISNULL(pp.SCDActiveFlag,'Y')='Y' AND pps.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 

PRINT 'Info: Insert [ser].[PlanogramPosition] is done'; 


INSERT INTO [psa].[rawuk_btc_ix_spc_planogram_position_property_temp]
SELECT   pp.PlanogramPositionId FROM ser.PlanogramPosition pp  where                    
     pp.PlanogramPositionId  not in  (select pfp.PlanogramPositionId from  ser.PlanogramPositionProperty pfp 
	 	join ser.PlanogramPosition pf
		on pfp.PlanogramPositionId = pf.PlanogramPositionId where pf.LOVRecordSourceId = 12002 )

/* Perform the Pivot and Insert into a intermediate table */

INSERT INTO ser.PlanogramPositionPropertyTemp
 SELECT  PlanogramPositionId AS PlanogramPositionId ,	
        (SELECT MeasureId FROM ser.Measure me WHERE me.MeasureName = ''+PICol+'' AND  me.LOVRecordSourceId =12002) MeasureId,
        @lov_uom_id AS LOVUOMId, -- @lov_uom_id	    
		 PIValue 		AS Value ,		
		@record_source_id  AS LOVRecordSourceId,
		SCDStartDate as SCDStartDate,
		SCDEndDate,
		SCDActiveFlag,
		SCDVersion,
	    @scd_lov_record_source_id   AS SCDLOVRecordSourceId,    
	    ETLRunLogId AS ETLRunLogId,
		PSARowKey AS PSARowKey
FROM  
(
  SELECT  
  pp.PlanogramPositionId AS PlanogramPositionId,
	locationid   AS product_location,
	hfacings   AS product_facing,
	segment   AS  item_segment,   
	pl.PlanogramStartDate as SCDStartDate,
	@SCDEndDate AS SCDEndDate,
	@SCDActiveFlag  AS SCDActiveFlag,
    @SCDVersion AS SCDVersion,
 	 CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	 pps.dbkey AS dbkey,
	 pp.SourceKey AS SourceKey,
	 pps.row_id as PSARowKey
  FROM psa.RAWUK_BTC_IX_SPC_POSITION pps 
JOIN psa.RAWUK_BTC_IX_SPC_PRODUCT ixpr ON ixpr.dbkey =  pps.dbparentproductkey
JOIN ser.Product pr ON  ixpr.id  =   pr.SourceKey
JOIN ser.Planogram pl ON pps.DBParentPlanogramKey = pl.SourceKey
JOIN ser.PlanogramFixture pf ON pps.DBParentFixtureKey = pf.SourceKey
JOIN ser.PlanogramPosition pp ON pp.sourcekey = pps.dbkey
JOIN  [psa].[rawuk_btc_ix_spc_planogram_position_property_temp] pft ON pft.PlanogramPositionId = pp.PlanogramPositionId  
WHERE pps.record_source_id = @record_source_id  AND pr.LOVRecordSourceId = @record_source_id AND pl.LOVRecordSourceId = @record_source_id AND pf.LOVRecordSourceId = @record_source_id 
AND pl.parentplanogramid is not null
AND pps.row_status= @psaRowStatus 
AND pf.SCDActiveFlag = 'Y' AND pl.SCDActiveFlag = 'Y' AND pr.SCDActiveFlag = 'Y'
AND ISNULL(pp.SCDActiveFlag,'Y')='Y'  AND pps.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 

) d
UNPIVOT
(
  PIValue FOR PICol IN    
    (product_location,product_facing,item_segment)
) AS unpiv

PRINT 'Info: INSERT INTO ser.PlanogramPositionPropertyTemp  is done';


/********************************************************************************************************************************
2.	Table Name  :PlanogramPositionProperty
	Condition : Entry for all data in Source table against surrogate key (SourceID & record_source_id)
**********************************************************************************************************************************/
INSERT INTO  ser.PlanogramPositionProperty
SELECT 
ppt.PlanogramPositionId,
ppt.MeasureId,
ppt.LOVUOMId,
ppt.PIValue AS Value,
ppt.LOVRecordSourceId,
ppt.SCDStartDate,
ppt.SCDEndDate,
ppt.SCDActiveFlag,  
@SCDVersion AS SCDVersion,
@scd_lov_record_source_id AS SCDLOVRecordSourceId,
ppt.etlrunlogid AS ETLRunLogId,
ppt.PSARowKey
from  ser.PlanogramPositionPropertyTemp ppt  
LEFT JOIN ser.PlanogramPositionProperty ppp ON ppt.PlanogramPositionId = ppp.PlanogramPositionId
AND ppt.MeasureId = ppp.MeasureId AND ppt.SCDActiveFlag = ppp.SCDActiveFlag where ppt.PIValue is not null  AND ppt.PIValue != ''
 
 PRINT 'Info: INSERT INTO  ser.PlanogramPositionProperty  is done';

/********************************************************************************************************************************
 	Update Source Table  :psa.rawuk_btc_ix_spc_position 
	Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
**********************************************************************************************************************************/
UPDATE psa.rawuk_btc_ix_spc_position SET row_status=@serRowStatus
FROM psa.RAWUK_BTC_IX_SPC_POSITION pps 
JOIN psa.RAWUK_BTC_IX_SPC_PRODUCT ixpr ON ixpr.dbkey =  pps.dbparentproductkey
JOIN ser.Product pr ON  ixpr.id  =   pr.SourceKey
JOIN ser.Planogram pl ON pps.DBParentPlanogramKey = pl.SourceKey
JOIN ser.PlanogramFixture pf ON pps.DBParentFixtureKey = pf.SourceKey
JOIN ser.PlanogramPosition pp ON pp.sourcekey = pps.dbkey
WHERE pps.record_source_id = @record_source_id  AND pr.LOVRecordSourceId = @record_source_id AND pl.LOVRecordSourceId = @record_source_id AND pf.LOVRecordSourceId = @record_source_id 
AND pl.parentplanogramid is not null
AND pf.SCDActiveFlag = 'Y' AND pl.SCDActiveFlag = 'Y' AND pr.SCDActiveFlag = 'Y'
AND pps.row_status=@psaRowStatus AND pp.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))

PRINT 'Info:  Source table UPDATE psa.rawuk_btc_ix_spc_position is done '; 

COMMIT TRANSACTION;
END TRY
BEGIN CATCH
                THROW;                   
                ROLLBACK TRANSACTION ;                       
END CATCH
IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_position_temp') is not null
		BEGIN
			DROP TABLE psa.rawuk_btc_ix_spc_planogram_position_temp
			PRINT 'Info: Dropped Temp table -> [psa].[rawuk_btc_ix_spc_planogram_position_temp]';
		END	

		IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_position_property_temp') is not null
		BEGIN
			drop table psa.rawuk_btc_ix_spc_planogram_position_property_temp
			PRINT 'Info: Dropped Temp table -> psa.rawuk_btc_ix_spc_planogram_position_property_temp';
		END	
		
	   IF OBJECT_ID('ser.PlanogramPositionPropertyTemp') is not null
		BEGIN
			drop table ser.PlanogramPositionPropertyTemp
			PRINT 'Info: Dropped Temp table -> ser.PlanogramPositionPropertyTemp';
		END	
		
		END
GO
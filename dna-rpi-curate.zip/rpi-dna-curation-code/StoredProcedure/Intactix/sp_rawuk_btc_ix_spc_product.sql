/****** Object:  StoredProcedure [psa].[sp_rawuk_btc_ix_spc_product]    Script Date: 26/06/2020 15:50:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_rawuk_btc_ix_spc_product') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawuk_btc_ix_spc_product
END
GO

CREATE PROC [psa].[sp_rawuk_btc_ix_spc_product] @psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max) AS
/*
************************************************************************************************************************************************************************
Procedure Name				: sp_rawuk_btc_ix_spc_product
Purpose						: Load History data From International Intactix Product in psa layer(Intactix) into Serve Layer Table
Domain						: Product
ServeLayer Target Tables	: Total 9 tables
							Through SP		   -> Product,ProductStatus,ProductIdentifier,ProductProperty,ProductPartyRole
							DML One Off Insert -> Measure,Party,Organization,PartyRole
RecordSourceID  for INTACTIX : 12002
RecordSourceID for INTACTIX-ProductPartyRole : 12012
*************************************************************************************************************************************************************************
SCD Columns and Concept (latest data is inserted with respect SCD)
************************************************************************************************************************************************************************
***HISTORY/HISTORY CATCH UP NEW RECORDS******
				productId			: max(productid)+1
				SCDStartDate        :  '1900-01-01 00:00:00'
				SCDEndDate          :  '9999-12-31 00:00:00'
				SCDActiveFlag       :  'Y'   
				SCDVersion          :   1 (Min version for new records) 
				SCDLOVRecordSourceId: 151 
				serveETLRunLogId    : RunlogID from API passing as a parameter
*******HISTORY CATCH UP Existing Records*******
				productId			: same productid as exisitng records
				SCDStartDate        :  PROCESSING DATE
				SCDEndDate          :  PROCESSING DATE-1sec
				SCDActiveFlag       :  'N'   
				SCDVersion          :  Increment exisitng version by 1 for that product id
				SCDLOVRecordSourceId: 151 
				serveETLRunLogId    : RunlogID from API passing as a parameter

*************************************************************************************************************************************************************************
Modification History
*************************************************************************************************************************************************************************
24-June-2020  : Incorporated v1.7 mapping changes 
06-July-2020  : Throw Function added
20-July-2020  : New SCD Change for SCDStartDate (History -> '1900-01-01 00:00:00',HistoryCatchUp->PROCESSING DATE) and SCDEndDate-PROCESSING DATE-1sec

*************************************************************************************************************************************************************************
*/ 

--drop temp table if exists

IF OBJECT_ID('ser.TmpProductIxp') IS NOT NULL
BEGIN
DROP TABLE ser.TmpProductIxp;
END

--create temp table
CREATE TABLE [ser].[TmpProductIxp]
(
	[ProductId] [bigint] NOT NULL,
	[SourceKey] [nvarchar](80) NOT NULL,
	[LOVSourceKeyTypeId] [int] NOT NULL,
	[ProductName] [nvarchar](100) NULL,
	[ProductDescription] [nvarchar](255) NULL,
	[LOVBrandId] [int] NULL,
	[LOVSubBrandId] [int] NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[ParentProductId] [bigint] NULL,
	[SCDStartDate] [datetime] NULL,
	[SCDEndDate] [datetime] NULL,
	[SCDActiveFlag] [nchar](1) NULL,
	[SCDVersion] [smallint] NULL,
	[SCDLOVRecordSourceId] [int] NULL,
	[ETLRunLogId] [int] NULL,
	[PSARowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX ORDER ([LOVSourceKeyTypeId],[LOVRecordSourceId])
)

/*-------DECLARE Variables-------*/

DECLARE @max_productID int,@LOVMeasureTypeId int,@LOVDataTypeId int,@max_measureID int, @UOMId int,@max_PartyId int,@max_PartyRoleId int,@SCDStartDate datetime2,
		@SCDEndDate datetime2,@SCDActiveFlag char,@SCDVersion smallint,@SCDLOVRecordSourceId int,@LOVRecordSourceId int,@Sourcekey nvarchar(30),@PtyLOVRecordSourceId int,
		@SourceOrganisationKey nvarchar(30),@OrganisationName nvarchar(30),@PartyRoleName nvarchar(30),@Partyid int, @LOVPartyTypeId INT,@LOVRoleId int,@PdctPartyRoleId int,
		@LOVSourceKeyTypeId int,@LOVIdentifierId int,@LOVProductStatusSetId int,@psaRowStatus int,@serRowStatus int,@SCDCurrentStartDate datetime2,@SCDCurrentEndDate datetime2;


BEGIN
BEGIN TRANSACTION;

/*-------Set the MAX value of surrogate Keys to particular Variables-------*/

SET @max_productID=(SELECT COALESCE(MAX(ProductID),0) FROM  ser.PRODUCT)
/*-------Set the Constant Values to Variables-------*/

SET @SCDStartDate=(SELECT CONVERT(datetime2,'1900-01-01 00:00:00'))
SET @SCDEndDate=(SELECT CONVERT(datetime2,'9999-12-31 00:00:00'))
SET @SCDCurrentStartDate=CURRENT_TIMESTAMP
SET @SCDCurrentEndDate= (SELECT DATEADD(SECOND,-1, @SCDCurrentStartDate ))
SET @SCDActiveFlag='Y'
SET @SCDVersion=1
SET @SCDLOVRecordSourceId=151
SET @LOVRecordSourceId = 12002
SET @PtyLOVRecordSourceId = 12012
SET @psaRowStatus=26001
SEt @serRowStatus=26002



/*-------Derive the lookup table constant values and Set to Variables-------*/

SELECT @LOVSourceKeyTypeId = rl.LOVId FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LOVSETId=rls.LOVSetID WHERE rl.LOVKey = 'SAP Article Number' AND rls.LOVSetName = 'Source Key Type'
SELECT @LOVMeasureTypeId = rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PROD_DIM' AND rls.LOVSetName = 'Measure Type'
SELECT @LOVDataTypeId = rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'FLOAT' AND rls.LOVSetName = 'Data Type'
SELECT @UOMId = rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'Unknown' AND rls.LOVSetName = 'Unit Of Measure'
SELECT @LOVIdentifierId	= rl.LOVId FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LOVSETId=rls.LOVSetID WHERE rl.LOVKey = 'UPC' AND rls.LOVSetName = 'Identifier'	
SELECT @LOVPartyTypeId = rl.LOVId FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LOVSetId=rls.LOVSetID WHERE rl.LOVKey = 'ORG' AND rls.LOVSetName = 'Party Type'
SELECT @LOVRoleId=rl.LOVId FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LOVSETId=rls.LOVSetID WHERE rl.LOVKey = 'Retailer' AND rls.LOVSetName = 'Role'
SELECT @LOVProductStatusSetId= rls.LovSetID FROM ser.RefLovset rls WHERE LOVSetName = 'Status' AND rls.LOVSetRecordSourceId = @LOVRecordSourceId


  BEGIN TRY

  		
/********************************************************************************************************************************
1.	Table Name  :Product
	Condition : Entry for all data in Source table against surrogate key (SourceID & record_source_id)
**********************************************************************************************************************************/
PRINT '****************Loading Product Table*********************';

PRINT '*****************Update SCDEndDate for closed records in Product Table*************';  
 --closing the active record
UPDATE ser.Product   
set SCDEndDate = @SCDCurrentEndDate
	FROM ser.Product  p 
	JOIN psa.[rawuk_btc_ix_spc_product] ixp ON ixp.record_source_id=p.LovRecordSourceId and	 p.sourcekey = ixp.id
	WHERE p.SCDActiveFlag='Y' and ixp.row_status= @psaRowStatus  AND ixp.etl_runlog_id in (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','));

---INSERT TO PRODUCT
PRINT '*****************Insert into Temp Table*************';  
INSERT INTO  ser.TmpProductIxp

	SELECT  
			ISNULL(p.ProductID,row_num+@max_productID) ProductID,
            ixp.id  SourceKey,
			@LOVSourceKeyTypeId  LOVSourceKeyTypeId,
			ixp.name  ProductName,
			NULL  ProductDescription,
			c.LOVId  LOVBrANDId,
			NULL  LOVSubBRANDId,
			ixp.record_source_id  LOVRecordSourceId,
			NULL  ParentProductId,                
			(CASE When p.SCDStartDate is null then @SCDStartDate ELSE @SCDCurrentStartDate END) SCDStartDate,
            @SCDEndDate SCDEndDate,
            LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id ASC) SCDActiveFlag,                
            (CASE When p.SCDVersion is null then 1 ELSE p.SCDVersion+1 END) SCDVersion,
            @SCDLOVRecordSourceId SCDLOVRecordSourceId,
            CAST(@serveETLRunLogID AS INT) ETLRunLogId,
			ixp.row_id as PSARowKey
    FROM psa.rawuk_btc_ix_spc_product ixp
    join (SELECT ixp.id,ixp.record_source_id,ROW_NUMBER() OVER(ORDER BY ixp.id,ixp.record_source_id ASC) row_num
			FROM psa.rawuk_btc_ix_spc_product ixp  WHERE ixp.row_status=@psaRowStatus AND ixp.etl_runlog_id in (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))
			GROUP BY ixp.id,ixp.record_source_id) productTemp ON ixp.id=productTemp.id    
    LEFT JOIN ser.product p on ixp.id =p.sourcekey and ixp.record_source_id=p.LOVRecordSourceId
    LEFT JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
					ser.RefLov rl
					 JOIN ser.RefLovset rls
					on rl.LOVSETId=rls.LOVSetID AND rls.LOVsetRecordSourceId = @LOVRecordSourceId                
					WHERE rls.LOVSetName = 'Brand')c
		on ixp.record_source_id=c.LOVRecordSourceId AND  c.LOVKey = ixp.BRAND
		WHERE ixp.row_status=@psaRowStatus  AND ixp.etl_runlog_id in (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) AND	ISNULL(p.SCDActiveFlag,'Y')='Y';

PRINT '*****************Insert into PRODCT table from Temp Table*************';  
INSERT INTO 
		[ser].[PRODUCT] (ProductId,SourceKey,LOVSourceKeyTypeId,ProductName,ProductDescription,LOVBrANDId,LOVSubBrANDId,
		LOVRecordSourceId,ParentProductId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
Select * from ser.TmpProductIxp;

--Updating  active flag to N for  the closed date
PRINT '*****************Update SCDActiveFlag for closed records in Product table*************';  

UPDATE ser.Product   set SCDActiveFlag='N'
	FROM ser.Product  p
	join psa.[rawuk_btc_ix_spc_product] ixp
	ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id 
	Where p.SCDActiveFlag='Y' and ixp.row_status=@psaRowStatus and p.SCDENDDate !='9999-12-31 00:00:00.000' 
	AND ixp.etl_runlog_id in (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))
		

		PRINT 'Info: Product Table Loaded Successfully';  


/********************************************************************************************************************************
 2. Table Name  :ProductStatus 
	Condition: Source Status Column Value Not Null or Blank
--********************************************************************************************************************************/
PRINT '****************Loading ProductStatus Table*********************';

PRINT 'Update SCDEndDate for closed records into ProductStatus Table';  

--closing the active record
UPDATE ser.Productstatus   
set SCDEndDate=@SCDCurrentEndDate
from ser.productstatus ps
	WHERE ps.productid in (select productid FROM ser.TmpProductIxp  p
	join psa.rawuk_btc_ix_spc_product ixp ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id
	WHERE   ixp.status!=''  AND ixp.status is not null  AND ixp.row_status=@psaRowStatus  AND  
		ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')))
		and ps.SCDActiveFlag='Y';

--Insert to ProductStatus
PRINT 'Insert New and Updated records into ProductStatus Table';  

INSERT INTO 
	[ser].[ProductStatus](ProductId,LOVProductStatusSetId,LOVStatusId,EffectiveFROM,EffectiveTo,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
SELECT
			pdct.ProductId   ProductId,
			@LOVProductStatusSetId  LOVProductStatusSetId,
			c.LovID  LOVStatusId,
			null  EffectiveFROM,
			null EffectiveTo,
			ixp.record_source_id  LOVRecordSourceId,              
			(CASE When ps.SCDStartDate is null then @SCDStartDate ELSE @SCDCurrentStartDate END) SCDStartDate,
			@SCDEndDate SCDEndDate,       
			LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id ASC) SCDActiveFlag,  
            (CASE When ps.SCDVersion is null then 1 ELSE ps.SCDVersion+1 END) SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
			ixp.row_id as PSARowKey
		FROM ser.TmpProductIxp pdct
		LEFT JOIN ser.productstatus ps on ps.productid=pdct.productid and ps.LOVRecordSourceId=pdct.LOVRecordSourceId
		JOIN psa.rawuk_btc_ix_spc_product ixp on pdct.SourceKey = ixp.ID AND Pdct.LOVRecordSourceId = ixp.record_source_id
		INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
					ser.RefLov rl JOIN ser.RefLovset rls On rl.LOVSETId=rls.LOVSetID
					WHERE rls.LOVSetName = 'Status' AND rls.LOVsetRecordSourceId = @LOVRecordSourceId)c
					on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.Status
		WHERE ixp.row_status=@psaRowStatus  and ixp.status!='' AND ixp.status is not null  AND ISNULL(ps.SCDActiveFlag,'Y')='Y' 
			AND ixp.etl_runlog_id  IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','));
		

--Updating  active flag to N for  the closed date
PRINT 'Update SCDActiveFlag for closed records in ProductStatus Table';  

UPDATE ser.Productstatus   
set SCDActiveFlag='N'
	FROM ser.Productstatus  ps
	where ps.productid in (select productid FROM ser.TmpProductIxp  p
							join psa.rawuk_btc_ix_spc_product ixp
							ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id 
							Where   ixp.row_status=@psaRowStatus AND ixp.status!='' AND ixp.status is not null  
							AND ixp.etl_runlog_id  IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))) 
	and ps.SCDENDDate !='9999-12-31 00:00:00.000' and ps.SCDActiveFlag='Y';

PRINT 'Info: ProductStatus Table Loaded Successfully';


/********************************************************************************************************************************
3.	Table Name  :ProductIdentifier 
	Condition: Source UPC Column Value Not Null or Blank
**********************************************************************************************************************************/
PRINT '****************Loading ProductIdentifier Table*********************';
--closing the active record
PRINT 'Update SCDEndDate for closed records in ProductIdentifier Table';  
UPDATE ser.[ProductIdentifier]   
	SET SCDEndDate=@SCDCurrentEndDate
	from ser.ProductIdentifier   pid
	WHERE pid.productid in 
		(SELECT productid FROM ser.TmpProductIxp  p
		join psa.rawuk_btc_ix_spc_product ixp
		ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id
		WHERE   ixp.row_status=@psaRowStatus AND ixp.upc!='' AND ixp.upc is not null  
		AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')))
		and pid.SCDActiveFlag='Y';

PRINT 'Insert New and Active records into ProductIdentifier Table';  

INSERT INTO [ser].[ProductIdentifier] 
	(ProductId,LOVIdentifierId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
SELECT
		pdct.ProductId  ProductId,
		@LOVIdentifierId  LOVIdentifierId,
		ixp.UPC  Value,
		ixp.record_source_id  LOVRecordSourceId,             
		(CASE When pid.SCDStartDate is null then @SCDStartDate ELSE @SCDCurrentStartDate END) SCDStartDate,
		@SCDEndDate SCDEndDate,       
		LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id ASC) SCDActiveFlag,  
        (CASE When pid.SCDVersion is null then 1 ELSE pid.SCDVersion+1 END) SCDVersion,
		@SCDLOVRecordSourceId SCDLOVRecordSourceId,
		CAST(@serveETLRunLogID AS INT)  ETLRunLogId ,
		ixp.row_id as PSARowKey  
		FROM ser.TmpProductIxp pdct
		LEFT JOIN ser.productidentifier pid on pid.productid=pdct.productid and pid.LOVRecordSourceId=pdct.LOVRecordSourceId
		JOIN psa.rawuk_btc_ix_spc_product ixp
			on pdct.SourceKey = ixp.ID AND Pdct.LOVRecordSourceId = ixp.record_source_id
		WHERE ixp.upc is not null AND ixp.upc!=''  AND ixp.row_status=@psaRowStatus AND	ISNULL(pid.SCDActiveFlag,'Y')='Y'
			AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','));

--Updating  active flag to N for  the closed date
PRINT 'Update SCDActiveFlag for closed records in ProductIdentifier Table';  

UPDATE ser.Productidentifier  
set SCDActiveFlag='N'
	FROM ser.Productidentifier  pid
	where pid.productid in (select productid FROM ser.TmpProductIxp  p
							join psa.rawuk_btc_ix_spc_product ixp
							ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id 
							Where   ixp.upc!='' AND ixp.upc is not null AND ixp.row_status=@psaRowStatus
							AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))) 
	and pid.SCDENDDate !='9999-12-31 00:00:00.000' AND  pid.SCDActiveFlag='Y' ;

		PRINT 'Info: ProductIdentifier Table Loaded Successfully';  

/********************************************************************************************************************************
4.	Table Name  :ProductProperty 
	Condition: Create/modify an entry for Height,Width,Depth againset each row of the Product Data,if Height,Width,Depth resp is not
				null or not blank.
**********************************************************************************************************************************/
PRINT '*****************Loading ProductProperty Table*************';  

--closing the active record
PRINT 'Update SCDEndDate for closed records in ProductProperty Table';  

UPDATE ser.ProductProperty   
	SET SCDEndDate=@SCDCurrentEndDate
	from ser.ProductProperty ppty
	WHERE ppty.productid in 
		(SELECT productid FROM ser.TmpProductIxp  p
		join psa.rawuk_btc_ix_spc_product ixp
		ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id
		WHERE ixp.Height!='' AND ixp.Height is not null AND  ixp.row_status=@psaRowStatus 
		AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')))
		and ppty.SCDActiveFlag='Y' 
		and ppty.measureid in (select measureid from ser.measure where measurename='Height' and lovrecordsourceid=12002 and lovmeasuretypeid=@LOVMeasureTypeId and lovdatatypeid=@LOVDataTypeId) ; 

UPDATE ser.ProductProperty   
	SET SCDEndDate=@SCDCurrentEndDate
	from ser.ProductProperty ppty
	WHERE ppty.productid in 
		(SELECT productid FROM ser.TmpProductIxp  p
		join psa.rawuk_btc_ix_spc_product ixp
		ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id
		WHERE  ixp.Width!='' AND ixp.Width is not null AND  ixp.row_status=@psaRowStatus 
		AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')))
	and ppty.SCDActiveFlag='Y' 
	and ppty.measureid in (select measureid from ser.measure where measurename='Width' and lovrecordsourceid=12002 and lovmeasuretypeid=@LOVMeasureTypeId and lovdatatypeid=@LOVDataTypeId) ; 

UPDATE ser.ProductProperty   
	SET SCDEndDate=@SCDCurrentEndDate
	from ser.ProductProperty ppty
	WHERE ppty.productid in 
		(SELECT productid FROM ser.TmpProductIxp  p
		join psa.rawuk_btc_ix_spc_product ixp
		ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id
		WHERE  ixp.Depth!='' AND ixp.Depth is not null AND  ixp.row_status=@psaRowStatus 
		AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')))
		and ppty.SCDActiveFlag='Y'
		and ppty.measureid in (select measureid from ser.measure where measurename='Depth' and lovrecordsourceid=12002 and lovmeasuretypeid=@LOVMeasureTypeId and lovdatatypeid=@LOVDataTypeId) ;  

PRINT 'INSERT new and updated records into ProductProperty Table';  

INSERT INTO ser.ProductProperty
(ProductId,MeasureId,LOVUOMId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey) 
	
SELECT 
	p.productid ProductId,
	m.MeasureId MeasureId,
	@UOMId LOVUOMId,
	ixp.Height Value,
	ixp.record_source_id LOVRecordSourceId,                
	(CASE When ppty.SCDStartDate is null then @SCDStartDate ELSE @SCDCurrentStartDate END) SCDStartDate,
    @SCDEndDate SCDEndDate,
    LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id ASC) SCDActiveFlag,                
    (CASE When ppty.SCDVersion is null then 1 ELSE ppty.SCDVersion+1 END) SCDVersion,
	@SCDLOVRecordSourceId SCDLOVRecordSourceId,
	CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	max(ixp.row_id) as PSARowKey
		FROM ser.TmpProductIxp p 
		LEFT JOIN ser.productproperty ppty
		on ppty.productid=p.productid and ppty.LOVRecordSourceId=p.LOVRecordSourceId 
		JOIN psa.rawuk_btc_ix_spc_product  ixp on p.SourceKey = ixp.ID AND p.LOVRecordSourceID = ixp.record_source_id 
		INNER JOIN ser.Measure m on p.LOVRecordSourceId = m.LOVRecordSourceId 
			WHERE   ixp.row_status=@psaRowStatus AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
			AND m.MeasureName = 'Height' and m.lovmeasuretypeid=@LOVMeasureTypeId and m.lovdatatypeid=@LOVDataTypeId and ixp.Height != '' AND ixp.Height is not null AND 	ISNULL(ppty.SCDActiveFlag,'Y')='Y'
			GROUP BY p.productid,m.MeasureId,ixp.Height,ppty.SCDStartDate,ppty.SCDVersion,ixp.id,ixp.record_source_id

UNION ALL

SELECT 
	p.productid ProductId,
	m.MeasureId MeasureId,
	@UOMId LOVUOMId,
	ixp.Width Value,
	ixp.record_source_id LOVRecordSourceId,
	(CASE When ppty.SCDStartDate is null then @SCDStartDate ELSE @SCDCurrentStartDate END) SCDStartDate,
    @SCDEndDate SCDEndDate,
    LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id ASC) SCDActiveFlag,                
    (CASE When ppty.SCDVersion is null then 1 ELSE ppty.SCDVersion+1 END) SCDVersion,
	@SCDLOVRecordSourceId SCDLOVRecordSourceId,
	CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	max(ixp.row_id) as PSARowKey
		FROM ser.TmpProductIxp p 
		LEFT JOIN ser.productproperty ppty
		on ppty.productid=p.productid and ppty.LOVRecordSourceId=p.LOVRecordSourceId 
		JOIN psa.rawuk_btc_ix_spc_product  ixp on p.SourceKey = ixp.ID AND p.LOVRecordSourceID = ixp.record_source_id 
		INNER JOIN ser.Measure m on p.LOVRecordSourceId = m.LOVRecordSourceId 
			WHERE ixp.row_status=@psaRowStatus AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
			AND m.MeasureName = 'Width' and m.lovmeasuretypeid=@LOVMeasureTypeId and m.lovdatatypeid=@LOVDataTypeId and ixp.Width != '' AND ixp.Width is not null  AND ISNULL(ppty.SCDActiveFlag,'Y')='Y'
			GROUP BY p.productid,m.MeasureId,ixp.Width,ppty.SCDStartDate,ppty.SCDVersion,ixp.id,ixp.record_source_id
UNION ALL

SELECT 
	p.productid ProductId,
	m.MeasureId MeasureId,
	@UOMId LOVUOMId,
	ixp.Depth Value,
	ixp.record_source_id LOVRecordSourceId,                
	(CASE When ppty.SCDStartDate is null then @SCDStartDate ELSE @SCDCurrentStartDate END) SCDStartDate,
    @SCDEndDate SCDEndDate,
    LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id ASC) SCDActiveFlag,              
    (CASE When ppty.SCDVersion is null then 1 ELSE ppty.SCDVersion+1 END) SCDVersion,
	@SCDLOVRecordSourceId SCDLOVRecordSourceId,
	CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	max(ixp.row_id) as PSARowKey
		FROM ser.TmpProductIxp p 
		LEFT JOIN ser.productproperty ppty
		on ppty.productid=p.productid and ppty.LOVRecordSourceId=p.LOVRecordSourceId 
		JOIN psa.rawuk_btc_ix_spc_product  ixp on p.SourceKey = ixp.ID AND p.LOVRecordSourceID = ixp.record_source_id 
		INNER JOIN ser.Measure m on p.LOVRecordSourceId = m.LOVRecordSourceId 
			WHERE ixp.row_status=@psaRowStatus AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
			AND  m.MeasureName = 'Depth' and m.lovmeasuretypeid=@LOVMeasureTypeId and m.lovdatatypeid=@LOVDataTypeId and ixp.Depth != '' AND ixp.Depth is not null AND ISNULL(ppty.SCDActiveFlag,'Y')='Y'
			GROUP BY p.productid,m.MeasureId,ixp.Depth,ppty.SCDStartDate,ppty.SCDVersion,ixp.id,ixp.record_source_id;



--Updating  active flag to N for  the closed date
PRINT 'Update SCDActiveFlag for closed records in ProductProperty Table';  
UPDATE ser.Productproperty  
set SCDActiveFlag='N'
	FROM ser.productproperty  ppty
	where ppty.productid in (select productid FROM ser.TmpProductIxp  p
							join psa.rawuk_btc_ix_spc_product ixp
							ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id 
							WHERE ixp.row_status=@psaRowStatus AND ixp.Height!='' AND ixp.Height is not null  
							AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')))
	and ppty.SCDENDDate !='9999-12-31 00:00:00.000' and  ppty.SCDActiveFlag='Y' 
	and ppty.measureid in (select measureid from ser.measure where measurename='Height' and lovrecordsourceid=12002 and lovmeasuretypeid=@LOVMeasureTypeId and lovdatatypeid=@LOVDataTypeId) ; 

	

UPDATE ser.Productproperty  
set SCDActiveFlag='N'
	FROM ser.productproperty  ppty
	where ppty.productid in (select productid FROM ser.TmpProductIxp  p
							join psa.rawuk_btc_ix_spc_product ixp
							ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id 
							WHERE  ixp.row_status=@psaRowStatus AND ixp.Width!='' AND ixp.Width is not null  
							AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))) 
	AND ppty.SCDENDDate !='9999-12-31 00:00:00.000' and  ppty.SCDActiveFlag='Y'
	and ppty.measureid in (select measureid from ser.measure where measurename='Width' and lovrecordsourceid=12002 and lovmeasuretypeid=@LOVMeasureTypeId and lovdatatypeid=@LOVDataTypeId) ; 

UPDATE ser.Productproperty  
set SCDActiveFlag='N'
	FROM ser.productproperty  ppty
	where ppty.productid in (select productid FROM ser.TmpProductIxp  p
							join psa.rawuk_btc_ix_spc_product ixp
							ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id 
							WHERE  ixp.row_status=@psaRowStatus AND ixp.Depth!='' AND ixp.Depth is not null  AND 
							ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))) 
	and ppty.SCDENDDate !='9999-12-31 00:00:00.000' and  ppty.SCDActiveFlag='Y'
	and ppty.measureid in (select measureid from ser.measure where measurename='Depth' and lovrecordsourceid=12002 and lovmeasuretypeid=@LOVMeasureTypeId and lovdatatypeid=@LOVDataTypeId) ; 



PRINT 'Info: ProductProperty Table Loaded Successfully';   
 

/********************************************************************************************************************************
5.	Table Name  :ProductPArtyRole 
	Condition: Link Retailer Party with Product.(PSASourceTable ID and Recordsourceid matches with that of product table)
**********************************************************************************************************************************/
PRINT '*****************Loading ProductPartyRole Table*************';  

--closing the active record

PRINT 'Update SCDEndDate for closed records in productpartyrole Table';  
UPDATE ser.Productpartyrole   
	SET SCDEndDate=@SCDCurrentEndDate
	from ser.Productpartyrole ppr
	WHERE ppr.productid in 
		(SELECT productid FROM ser.TmpProductIxp  p
		join psa.rawuk_btc_ix_spc_product ixp
		ON ixp.record_source_id=p.LovRecordSourceId and p.sourcekey = ixp.id 
		AND ixp.row_status=@psaRowStatus AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))
		)
		and ppr.SCDActiveFlag='Y'; 


		
PRINT 'Insert New and Updated records into Productpartyrole Table';  

select @PdctPartyRoleId = ptr.PartyRoleId from ser.PartyRole ptr join ser.party pty on ptr.partyid = pty.partyid where ptr.lovrecordsourceid=12012 and ptr.LOVRoleId = @LOVRoleId

INSERT INTO [ser].[ProductPartyRole](ProductId,PartyRoleId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)

SELECT 
	pdct.ProductId	ProductId,
	@PdctPartyRoleId  PartyRoleId,
	@PtyLOVRecordSourceId  LOVRecordSourceId,                
	(CASE When ppr.SCDStartDate is null then @SCDStartDate ELSE @SCDCurrentStartDate END) SCDStartDate,
    @SCDEndDate SCDEndDate,
    LEAD('N', 1, 'Y') OVER(PARTITION BY ixp.id,ixp.record_source_id ORDER BY ixp.id ASC) SCDActiveFlag,                
    (CASE When ppr.SCDVersion is null then 1 ELSE ppr.SCDVersion+1 END) SCDVersion,
	@SCDLOVRecordSourceId  SCDLOVRecordSourceId,
	CAST(@serveETLRunLogID AS INT) ETLRunLogId,
	ixp.row_id as PSARowKey
	FROM ser.TmpProductIxp pdct  
	LEFT JOIN ser.productpartyrole ppr
		on ppr.productid=pdct.productid 
	join psa.rawuk_btc_ix_spc_product ixp
		on pdct.SourceKey = ixp.ID AND pdct.lovrecordsourceid = ixp.record_source_id 
		WHERE ixp.row_status=@psaRowStatus and ISNULL(ppr.SCDActiveFlag,'Y')='Y'
		AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','));

--Updating  active flag to N for  the closed date

PRINT 'Update SCDActiveFlag for closed records in productpartyrole Table';  

UPDATE ser.Productpartyrole  
set SCDActiveFlag='N'
	FROM ser.productpartyrole  ppr
	where ppr.productid in (select productid FROM ser.TmpProductIxp  p
							join psa.rawuk_btc_ix_spc_product ixp
							ON ixp.record_source_id=p.LovRecordSourceId AND p.sourcekey = ixp.id 
							AND ixp.row_status=@psaRowStatus AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))) 
	and ppr.SCDENDDate !='9999-12-31 00:00:00.000' and  ppr.SCDActiveFlag='Y';	
			
			

			PRINT 'Info: ProductPartyRole Table Loaded Successfully'; 


/********************************************************************************************************************************
6.	Update Source Table  :psa.rawuk_btc_ix_spc_product 
	Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
**********************************************************************************************************************************/
PRINT '********************Updating Source Table accordingly -> psa.rawuk_btc_ix_spc_product****************';  



UPDATE psa.rawuk_btc_ix_spc_product SET row_status=@serRowStatus
	FROM psa.rawuk_btc_ix_spc_product ixp 
	Inner Join ser.Product p ON  ixp.row_id=p.PSARowKey and ixp.record_source_id=p.LovRecordSourceID 
	WHERE ixp.row_status=@psaRowStatus  AND p.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))
		

		PRINT 'Info: Source Table Updated accordingly -> psa.rawuk_btc_ix_spc_product'; 
		

COMMIT TRANSACTION;
END TRY
BEGIN CATCH 
	THROW;
	ROLLBACK TRANSACTION ;
END CATCH 

drop table [ser].[TmpProductIxp]
PRINT 'Info: Dropped Temp table -> ser.TmpProductIxp';


		END

GO
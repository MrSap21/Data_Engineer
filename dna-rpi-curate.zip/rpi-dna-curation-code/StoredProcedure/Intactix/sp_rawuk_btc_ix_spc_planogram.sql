/****** Object:  StoredProcedure [psa].[sp_rawuk_btc_ix_spc_planogram]    Script Date: 29/07/2020 12:35:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_rawuk_btc_ix_spc_planogram') IS NOT NULL
BEGIN
    DROP PROC psa.sp_rawuk_btc_ix_spc_planogram 
END
GO
CREATE PROC [psa].[sp_rawuk_btc_ix_spc_planogram]
@psaETLRunLogID [varchar](max),@serveETLRunLogID [varchar](max),@tableName [varchar](max) 
AS

/*
************************************************************************************************************
Procedure Name				: sp_rawuk_btc_ix_spc_planogram
Purpose						: Load History dataetl_runlog_id From International Intactix Planogram in psa layer(Intactix ) into Serve Layer Table
Domain						: Merchandise
ServeLayer Target Tables	: Planogram,PlanogramStatus,PlanogramGroup,PlanogramProperty(Total 4 Tables)
RecordSourceID  for INTACTIX : 12002
*****************************************************************************************
SCD Columns and Concept (latest data is inserted with respect SCD)
************************************************************************************************************
***HISTORY/HISTORY CATCH UP NEW RECORDS******
				SCDStartDate        :  DbDateEffectiveFrom(If NULL then '1900-01-01'
				SCDEndDate          :  9999-12-31
				SCDActiveFlag       :  'Y'   
				SCDVersion          :  '1' 
				SCDLOVRecordSourceId: 151 
				serveETLRunLogId    : RunlogID from api passing asa parameter
*******HISTORY CATCH UP Existing Records*******
No Records are inserted
***********************

*************************************************************************************************************
Modification History
*************************************************************************************************************
10-June-2020  : Incorporated v1.4 mapping changes 
16-June-2020  : Incorporated v1.5 mapping changes 
20-June-2020  : Incorporated v1.6 mapping changes
23-June-2020  : Incorporated v1.7 mapping changes
29-June-2020  : Incorporated v1.8 mapping changes
*/

/* Creating a intermediate physical table for child and parent values */
		IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_temp') is not null
		BEGIN
			DROP TABLE psa.rawuk_btc_ix_spc_planogram_temp
		END			
			CREATE TABLE [psa].[rawuk_btc_ix_spc_planogram_temp]
			(
				[PSARowKey] [bigint] NOT NULL,
				[record_type] [nvarchar](100) NULL,
				PlanogramId bigint NULL,
				SourceKey [nvarchar](80) NULL,
				LOVSourceKeyTypeId int NULL,
				ParentPlanogramId bigint NULL,
				LOVRecordSourceId int NULL,
				dbkey [nvarchar](500) NULL,
				value50 [nvarchar](500) NULL,
				name nvarchar(100) NULL,
                etl_runlog_id int null,
                DBDateEffectiveFrom [nvarchar](500) NULL,
                DBDateEffectiveTo [nvarchar](500) NULL,
                livedate [nvarchar](500) null,
                desc1 [nvarchar](500) NULL,
                desc2 [nvarchar](500) NULL,
				desc3 [nvarchar](500) NULL,
				desc4 [nvarchar](500) NULL,
				desc5 [nvarchar](500) NULL,
				desc28 [nvarchar](500) NULL,
				desc29 [nvarchar](500) NULL,
                Category [nvarchar](500) NULL,
                width [nvarchar](500) NULL,
                record_source_id INT NULL,
                asset_id int NULL,
                row_status int NULL ,
                created_timestamp datetime NULL,
				PlanogramStartDate datetime NULL,
				PlanogramEndDate datetime NULL,
				SCDStartDate datetime NULL,
				SCDEndDate datetime NULL,
				SCDVersion int null,
				SCDLOVRecordSourceId int null,
				SCDActiveFlag char(1) null						
			)
			WITH
			(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
			);
--Table for grouping values based on the value50 
IF OBJECT_ID('ser.PLANOGRAM_TEMP') IS NOT NULL
BEGIN
DROP TABLE ser.PLANOGRAM_TEMP;
END
				CREATE TABLE ser.PLANOGRAM_TEMP
				(dbkey [nvarchar](500) ,
				value50 [nvarchar](500))
				WITH
				(
				DISTRIBUTION = REPLICATE,
				CLUSTERED COLUMNSTORE INDEX
				);

/*-------DECLARE Variables-------*/
DECLARE @max_PlanogramId int,@LOVRecordSourceId int,@SCDStartDate datetime,@SCDEndDate datetime,@SCDActiveFlag char,@SCDVersion smallint,@SCDLOVRecordSourceId int,
@LOVSetId_planogramgroup_desc5 int,@LOVSetId_planogramgroup_desc2 int,@LOVSetId_planogramgroup_desc1 int,@LOVStatusId int,@max_PlanogramGroupId int,
@LOVSetId_planogramgroup_desc3 int,@LOVSetId_planogramgroup_Category int,@LOVMeasureTypeId int,@LOVDataTypeId_string int,@LOVDataTypeId_float int,@LOVDataTypeId_int int,@UOMId int,
@LOVSetId_planogram int,@max_measureID int,@Sourcekeytypeid_parent int,@Sourcekeytypeid_child int,@CurrentScdVersion int,@firstquery VARCHAR(8000),@nextquery VARCHAR(8000),@psaRowStatus int,@serRowStatus int,@SCDStartDate_initial datetime;

BEGIN
BEGIN TRANSACTION;
/*-------Set the MAX value of surrogate Keys to particular Variables-------*/
SET @max_PlanogramId=(SELECT COALESCE(MAX(PlanogramId),0) FROM  ser.Planogram)
SET @max_PlanogramGroupId=(SELECT COALESCE(MAX(PlanogramGroupId),0) FROM  ser.PlanogramGroup)
SET @max_measureID=(SELECT COALESCE(MAX(MeasureId),0) FROM  ser.Measure)


/*-------Set the Constant Values to Variables-------*/
SET @LOVRecordSourceId = 12002
SET @SCDStartDate=current_timestamp
SET @SCDStartDate_initial=(SELECT CONVERT(datetime2,'1900-01-01 00:00:00'))
SET @SCDEndDate=(SELECT CONVERT(datetime2,'9999-12-31 00:00:00'))
SET @SCDActiveFlag='Y'
SET @SCDVersion=1
SET @SCDLOVRecordSourceId=151
SET @psaRowStatus=26001
SEt @serRowStatus=26002

/*-------Derive the lookup table constant values and Set to Variables-------*/
SELECT @LOVMeasureTypeId = rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'PLANOGRAM_DIM' AND rls.LOVSetName = 'Measure Type'
SELECT @LOVDataTypeId_string = rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'STRING' AND rls.LOVSetName = 'Data Type'
SELECT @LOVDataTypeId_float = rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'FLOAT' AND rls.LOVSetName = 'Data Type'
SELECT @LOVDataTypeId_int = rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'INT' AND rls.LOVSetName = 'Data Type' 
SELECT @UOMId = rl.Lovid FROM ser.RefLov rl JOIN ser.RefLovset rls ON rl.LovSetID = rls.LovSetID WHERE rl.LOVKey = 'Unknown' AND rls.LOVSetName = 'Unit Of Measure' 

select  @LOVStatusId = rl.LOVId FROM ser.RefLov rl
									JOIN ser.RefLovset rls
										on rl.LOVSetId=rls.LOVSetID
										WHERE rl.LOVKey = 'livedate' AND rls.LOVSetName = 'Status Type'

select @Sourcekeytypeid_parent = rl.LOVId FROM ser.RefLov rl
									JOIN ser.RefLovset rls
										on rl.LOVSetId=rls.LOVSetID
										WHERE rl.LOVKey = 'Intactix Planogram Id(value50)' AND rls.LOVSetName = 'Source Key Type'
									
select @Sourcekeytypeid_child = rl.LOVId FROM ser.RefLov rl
									JOIN ser.RefLovset rls
										on rl.LOVSetId=rls.LOVSetID
										WHERE rl.LOVKey = 'Intactix Planogram dbkey' AND rls.LOVSetName = 'Source Key Type'


set @LOVSetId_planogram=(select LOVSetId from ser.RefLovset rls
							where rls.LOVSetName = 'Status Type'
							and rls.LOVSetRecordSourceID = 12012)
set @LOVSetId_planogramgroup_desc5=(select LOVSetId from ser.RefLovset rls
							where rls.LOVSetName = 'fitting_type'
							and rls.LOVSetRecordSourceID = 12002)
set @LOVSetId_planogramgroup_desc2=(select LOVSetId from ser.RefLovset rls
							where rls.LOVSetName = 'planner_family'
							and rls.LOVSetRecordSourceID = 12002)
set @LOVSetId_planogramgroup_desc1=(select LOVSetId from ser.RefLovset rls
							where rls.LOVSetName = 'footprint'
							and rls.LOVSetRecordSourceID = 12002)
set @LOVSetId_planogramgroup_desc3=(select LOVSetId from ser.RefLovset rls
							where rls.LOVSetName = 'format'
							and rls.LOVSetRecordSourceID = 12002)
set @LOVSetId_planogramgroup_Category=(select LOVSetId from ser.RefLovset rls
							where rls.LOVSetName = 'category'
							and rls.LOVSetRecordSourceID = 12002)



  BEGIN TRY
--Insert into the temp table group by value50 for generating parent records
PRINT '****************Loading Planogram_Temp Started for parent case*********************'
				insert into ser.PLANOGRAM_TEMP
				SELECT
					 MAX(DBKEY),cast(convert(float,value50)as nvarchar) FROM psa.rawuk_btc_ix_spc_planogram spl     
					where row_status=@psaRowStatus  AND spl.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ','))                          
					 group by cast(convert(float,value50)as nvarchar) having  cast(convert(float,value50)as nvarchar) not in 
					 (SELECT cast(convert(float,value50)as nvarchar) FROM ser.Planogram pl
						JOIN psa.rawuk_btc_ix_spc_planogram spl on pl.sourcekey = cast(convert(float,spl.value50)as nvarchar) and pl.lovrecordsourceid=@LOVRecordSourceId
						group by cast(convert(float,value50)as nvarchar) )
PRINT '****************Loading of Planogram_Temp Completed for parent case*********************'
/*-------Set the MAX value of surrogate Keys to particular Variables-------*/
DECLARE @max_planogramTempID BIGINT	;
SELECT @max_planogramTempID = COALESCE(MAX(PlanogramId),0) FROM psa.rawuk_btc_ix_spc_planogram_temp;

-- Loading a intermediate physical table with values corresponding to distinct values of  parent 
PRINT '****************Loading psa.rawuk_btc_ix_spc_planogram_temp for parent case*********************'
		INSERT INTO psa.rawuk_btc_ix_spc_planogram_temp
			SELECT 
				PSARowKey,record_type,PlanogramId,SourceKey,LOVSourceKeyTypeId,ParentPlanogramId,LOVRecordSourceId,dbkey,value50,name,
				etl_runlog_id,DBDateEffectiveFrom,DBDateEffectiveTo,livedate,desc1,desc2,desc3,desc4,desc5,desc28,desc29,
				Category,width,record_source_id,asset_id,row_status,created_timestamp,
				PlanogramStartDate ,
				PlanogramEndDate ,
				SCDStartDate,
				SCDEndDate ,
				SCDVersion ,
				SCDLOVRecordSourceId,
				SCDActiveFlag				
			FROM
			(SELECT
			  cast(ixp.row_id as bigint) AS PSARowKey,
			 'parent' as record_type,
			  cast(ROW_NUMBER() OVER(ORDER BY convert(float,ixp.value50),ixp.record_source_id ASC)+ @max_planogramTempID as bigint) as PlanogramId,
			  cast(convert(float,ixp.value50)as nvarchar) as SourceKey,
			  cast(@Sourcekeytypeid_parent as int)   as LOVSourceKeyTypeId, 
			  NULL as ParentPlanogramId,
			  @LOVRecordSourceId as LOVRecordSourceId,
			  ixp.dbkey as dbkey,
			  cast(convert(float,ixp.value50)as nvarchar) as value50,
			  ixp.name as name,
              CAST(@serveETLRunLogID AS INT) as etl_runlog_id,
              ixp.DBDateEffectiveFrom as DBDateEffectiveFrom,
              ixp.DBDateEffectiveTo as DBDateEffectiveTo,
              ixp.livedate as livedate,
              ixp.desc1 as desc1,
              ixp.desc2 as desc2,
              ixp.desc3 as desc3,
              ixp.desc4 as desc4,
              ixp.desc5 as desc5,
              ixp.desc28 as desc28,
              ixp.desc29 as desc29,
              ixp.Category as Category,
              ixp.width as width,
			  ixp.record_source_id as record_source_id,
              ixp.asset_id as asset_id,
              ixp.row_status as row_status,
              ixp.created_timestamp as created_timestamp,
			  NULL PlanogramStartDate ,
				NULL PlanogramEndDate ,
				NULL SCDStartDate,
				NULL SCDEndDate ,
				NULL SCDVersion ,
				NULL SCDLOVRecordSourceId,
				NULL SCDActiveFlag
			  from psa.rawuk_btc_ix_spc_planogram ixp
				inner join ser.PLANOGRAM_TEMP temp
				on temp.dbkey=ixp.dbkey
				and ixp.row_status=@psaRowStatus AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 
				where ixp.value50 is not NULL OR cast(convert(float,ixp.value50)as nvarchar)!=0
				)t ;
PRINT '****************Loading of psa.rawuk_btc_ix_spc_planogram_temp for parent case Completed*********************'				
PRINT '****************Loading Planogram Table for Parent*********************'				
		--Insert parent to ser.Planogram		
			Insert into ser.Planogram	
			SELECT PlanogramId,
					SourceKey,
					LOVSourceKeyTypeId,
					PlanogramStartDate,
					PlanogramEndDate,
					PlanogramName,
					ParentPlanogramId,
					LOVRecordSourceId,
					SCDStartDate ,
					@SCDEndDate SCDEndDate,
					@SCDActiveFlag  SCDActiveFlag,
					@SCDVersion SCDVersion,
					@SCDLOVRecordSourceId SCDLOVRecordSourceId,
					ETLRunLogId,
					PSARowKey
				from
				(select  
					cast((@max_PlanogramId + PlanogramId) as bigint) as PlanogramId,
					SourceKey as SourceKey,
					cast(LOVSourceKeyTypeId as int) as LOVSourceKeyTypeId,
					NULL as PlanogramStartDate,
					NULL as PlanogramEndDate,
					name  as PlanogramName,
					ParentPlanogramId  as ParentPlanogramId,
					@LOVRecordSourceId as LOVRecordSourceId,
					case when (ixp.DBDateEffectiveFrom is null or ixp.DBDateEffectiveFrom='')
						then @SCDStartDate_initial
						else convert(datetime2,ixp.DBDateEffectiveFrom)
					end as SCDStartDate,
					CAST(@serveETLRunLogID AS INT) ETLRunLogId,
					cast(PSARowkey as bigint) as PSARowkey
					from psa.rawuk_btc_ix_spc_planogram_temp ixp
					where record_type='parent' )t	
PRINT '****************Completed Planogram Table for Parent*********************'			
-- Loading a intermediate physical table with values corresponding to distinct values of  child
PRINT '****************Deletion of  Planogram_temp Started********************'		
		delete 	from ser.PLANOGRAM_TEMP;
PRINT '****************Deletion of  Planogram_temp Completed********************'

PRINT '****************Loading Planogram_Temp Started for child case*********************'
				insert into ser.PLANOGRAM_TEMP
				SELECT	dbkey,cast(convert(float,value50)as nvarchar) FROM psa.rawuk_btc_ix_spc_planogram spl     
					where row_status=@psaRowStatus  AND spl.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) and                         
						dbkey not in  (SELECT  dbkey FROM ser.Planogram pl
						JOIN psa.rawuk_btc_ix_spc_planogram spl on pl.sourcekey = spl.dbkey and pl.lovrecordsourceid=@LOVRecordSourceId
						and pl.parentplanogramid is not null)
PRINT '****************Loading Planogram_Temp Completed for child case*********************'
		SELECT @max_planogramTempID = COALESCE(MAX(PlanogramId),0) FROM ser.Planogram;
PRINT '****************Loading psa.rawuk_btc_ix_spc_planogram_temp for child case*********************'
			INSERT INTO psa.rawuk_btc_ix_spc_planogram_temp
			SELECT 
			PSARowKey,record_type,
			PlanogramId,
			SourceKey,
			LOVSourceKeyTypeId,
			ParentPlanogramId,
			LOVRecordSourceId,
			dbkey,
			value50,
			name,
			etl_runlog_id,
			DBDateEffectiveFrom,
			DBDateEffectiveTo,
			livedate,desc1,desc2,desc3,desc4,desc5,desc28,desc29,
			Category,width,record_source_id,asset_id,row_status,created_timestamp,
			PlanogramStartDate ,
				PlanogramEndDate ,
				SCDStartDate,
				SCDEndDate ,
				SCDVersion ,
				SCDLOVRecordSourceId,
				SCDActiveFlag
			FROM
			(SELECT  
			 cast(ixp.row_id as bigint) AS PSARowKey,
			 'child' as record_type,
			  @max_planogramTempID+ROW_NUMBER() OVER(ORDER BY convert(float,ixp.value50),ixp.dbkey ASC)  as PlanogramId,
			  ixp.dbkey as SourceKey,
			  @Sourcekeytypeid_child  as LOVSourceKeyTypeId,
			  cast(PlanogramIdTemp.PlanogramId as bigint) as ParentPlanogramId,
			  @LOVRecordSourceId as LOVRecordSourceId,
			  ixp.dbkey as dbkey,
			  cast(convert(float,ixp.value50)as nvarchar) as value50,
			  ixp.name as name,
              CAST(@serveETLRunLogID AS INT) as etl_runlog_id,
              ixp.DBDateEffectiveFrom as DBDateEffectiveFrom,
              ixp.DBDateEffectiveTo as DBDateEffectiveTo,
              ixp.livedate as livedate,
              ixp.desc1 as desc1,
              ixp.desc2 as desc2,
              ixp.desc3 as desc3,
              ixp.desc4 as desc4,
              ixp.desc5 as desc5,
              ixp.desc28 as desc28,
              ixp.desc29 as desc29,
              ixp.Category as Category,
              ixp.width as width,
			  ixp.record_source_id as record_source_id,
              ixp.asset_id as asset_id,
              ixp.row_status as row_status,
              ixp.created_timestamp as created_timestamp,
			  convert(datetime2,ixp.DBDateEffectiveFrom) as PlanogramStartDate,
			  convert(datetime2,ixp.DBDateEffectiveTo) as PlanogramEndDate,
					case when (ixp.DBDateEffectiveFrom is null or ixp.DBDateEffectiveFrom='')
						then @SCDStartDate_initial
						else convert(datetime2,ixp.DBDateEffectiveFrom)
					end as SCDStartDate,
				@SCDEndDate SCDEndDate,
				@SCDVersion as SCDVersion,
				@SCDLOVRecordSourceId as SCDLOVRecordSourceId, 			 
				@SCDActiveFlag SCDActiveFlag	
				from psa.rawuk_btc_ix_spc_planogram ixp
				inner join ser.PLANOGRAM_TEMP temp
				on temp.dbkey=ixp.dbkey
				and ixp.row_status=@psaRowStatus AND ixp.etl_runlog_id IN (SELECT  value FROM STRING_SPLIT(@psaETLRunLogID, ',')) 

				LEFT JOIN ser.Planogram plgm 
					ON ixp.dbkey  = plgm.sourcekey 
					AND ixp.record_source_id = plgm.LOVRecordSourceId 
					AND plgm.SCDActiveFlag = 'Y'	
	
				LEFT JOIN (SELECT SourceKey,LOVRecordSourceId,PlanogramId FROM ser.Planogram GROUP BY SourceKey,LOVRecordSourceId,PlanogramId) PlanogramIdTemp
					ON PlanogramIdTemp.SourceKey = cast(convert(float,ixp.value50)as nvarchar) AND PlanogramIdTemp.LOVRecordSourceId = ixp.record_source_id
				where  ixp.dbkey is not NULL OR ixp.dbkey!=0
				and plgm.LOVRecordSourceId=@LOVRecordSourceId and ISNULL(plgm.SCDActiveFlag,'Y')='Y' AND plgm.LOVSourceKeyTypeId = @Sourcekeytypeid_parent and plgm.ParentPlanogramId is not null 
				)t ;
PRINT '****************Loading psa.rawuk_btc_ix_spc_planogram_temp for child case completed*********************'


/********************************************************************************************************************************
1.	Table Name  :Planogram
	Condition : Entry for all data in Source table against surrogate key (SourceID & record_source_id)
**********************************************************************************************************************************/
--closing the active record for child if exists 


PRINT '****************Loading Planogram Table for child*********************'
SET @max_PlanogramId=(SELECT COALESCE(MAX(PlanogramId),0) FROM  ser.Planogram)
set @CurrentScdVersion=(select COALESCE(max(scdversion),0) from ser.Planogram WHERE LOVRecordSourceId=12002)

--Child insert into planogram

INSERT INTO ser.Planogram 
SELECT 
			PlanogramId,
			SourceKey,
			LOVSourceKeyTypeId,
			PlanogramStartDate,
			PlanogramEndDate,
			PlanogramName,
			ParentPlanogramId,
			LOVRecordSourceId,
	   		SCDStartDate,
			SCDEndDate,
			@SCDActiveFlag SCDActiveFlag,	
			SCDVersion,
			SCDLOVRecordSourceId,
			ETLRunLogId,
			PSARowKey
			from 
				(				
					 SELECT 
					  PlanogramId,
					temp.SourceKey as SourceKey,
					cast(temp.LOVSourceKeyTypeId as int) as LOVSourceKeyTypeId,
					CASE When (temp.DBDateEffectiveFrom is null or temp.DBDateEffectiveFrom='')  
						then NULL
						ELSE convert(datetime2,temp.DBDateEffectiveFrom) END  as PlanogramStartDate,
					CASE When (temp.DBDateEffectiveTo is null or temp.DBDateEffectiveTo='')  
						then NULL 
						ELSE convert(datetime2,temp.DBDateEffectiveTo) END as PlanogramEndDate,
					temp.ParentPlanogramId as ParentPlanogramId,
					temp.name  as PlanogramName,
					@LOVRecordSourceId as LOVRecordSourceId,
					temp.SCDStartDate as SCDStartDate ,
					temp.SCDEndDate as SCDEndDate,
					temp.SCDVersion as SCDVersion,
					@SCDLOVRecordSourceId SCDLOVRecordSourceId,
					CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
					temp.PSARowkey as PSARowkey
					from psa.rawuk_btc_ix_spc_planogram_temp temp
					where 
					ISNULL(temp.SCDActiveFlag,'Y')='Y'   and record_type='child' and temp.row_status=@psaRowStatus  )t; 
					 
	 
PRINT '****************Insertion of  Planogram Table Completed*********************'




/********************************************************************************************************************************
 2. Table Name  :PlanogramStatus 
	Condition: Source livedate Column Value Not Null or Blank
--********************************************************************************************************************************/


PRINT '****************Loading PlanogramStatus Table*********************'
		INSERT INTO ser.PlanogramStatus
		(PlanogramId,LOVPlanogramStatusSetId,LOVStatusId,EffectiveFrom,EffectiveTo,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
			select distinct
			plgm.PlanogramId as PlanogramId,
			@LOVSetId_planogram as LOVPlanogramStatusSetId,
			@LOVStatusId as LOVStatusId,
			convert(datetime2,ixp.livedate) as EffectiveFrom,
			NULL as EffectiveTo,
			@LOVRecordSourceId LOVRecordSourceId,
			plgm.SCDStartDate SCDStartDate ,
			plgm.SCDEndDate SCDEndDate,
			plgm.SCDActiveFlag  SCDActiveFlag,
			plgm.SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
			plgm.PSARowKey PSARowKey
			from psa.rawuk_btc_ix_spc_planogram_temp ixp
			inner join ser.Planogram plgm
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
			and plgm.SCDActiveFlag='Y'		
			where ixp.livedate is not null and ixp.livedate!=''
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child' and ixp.row_status=@psaRowStatus ;
PRINT '****************Insertion of  PlanogramStatus Table Completed*********************'


/********************************************************************************************************************************
3.	Table Name  :PlanogramGroup 
	Condition: Source column such as desc5,desc2,desc1,Category,desc3 should be not null or not blank
**********************************************************************************************************************************/
SET @max_PlanogramGroupId=(SELECT COALESCE(MAX(PlanogramGroupId),0) FROM  ser.PlanogramGroup)
--1.
--********************************************************************************************************************************/


PRINT '****************Loading PlanogramGroup Table*********************'
		INSERT INTO ser.PlanogramGroup
        (PlanogramGroupId,PlanogramId,LOVPlanogramGroupSetId,LOVGroupId,ParentPlanogramGroupId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
		   select 
		    ROW_NUMBER() OVER(ORDER BY t.LOVGroupId,t.PlanogramId ASC)+@max_PlanogramGroupId PlanogramGroupId,*
			from
			(select distinct 
		    plgm.PlanogramId PlanogramId,
		    @LOVSetId_planogramgroup_desc5 LOVPlanogramGroupSetId,
		    c.LovId LOVGroupId,
		    NULL ParentPlanogramGroupId,
		    @LOVRecordSourceId LOVRecordSourceId,
			plgm.SCDStartDate SCDStartDate ,
			plgm.SCDEndDate SCDEndDate,
			plgm.SCDActiveFlag  SCDActiveFlag,
			plgm.SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
			plgm.PSARowKey PSARowKey
			from psa.rawuk_btc_ix_spc_planogram_temp ixp
			inner join ser.Planogram plgm
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
			and plgm.SCDActiveFlag='Y'
			and ixp.row_status=@psaRowStatus 
			INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
					ser.RefLov rl
					JOIN ser.Reflovset rls
					on rl.LOVSETId=rls.LOVSetID
					WHERE rls.LOVSetName = 'fitting_type'
					 AND rls.LOVsetRecordSourceId = @LOVRecordSourceId)c
			on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.desc5
			where ixp.desc5 is not null and ixp.desc5!=''
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child'
			 )t;

 PRINT 'Inserted 1st case with source column as desc5'
SET @max_PlanogramGroupId=(SELECT COALESCE(MAX(PlanogramGroupId),0) FROM  ser.PlanogramGroup)
--2.
		INSERT INTO ser.PlanogramGroup
        (PlanogramGroupId,PlanogramId,LOVPlanogramGroupSetId,LOVGroupId,ParentPlanogramGroupId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
		   select 
		    ROW_NUMBER() OVER(ORDER BY t.LOVGroupId,t.PlanogramId ASC)+@max_PlanogramGroupId PlanogramGroupId,*
			from
			(select distinct 
		    plgm.PlanogramId PlanogramId,
		    @LOVSetId_planogramgroup_desc2 LOVPlanogramGroupSetId,
		    c.LovId LOVGroupId,
		    NULL ParentPlanogramGroupId,
		    @LOVRecordSourceId LOVRecordSourceId,
			plgm.SCDStartDate SCDStartDate ,
			plgm.SCDEndDate SCDEndDate,
			plgm.SCDActiveFlag  SCDActiveFlag,
			plgm.SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
			plgm.PSARowKey PSARowKey
			from psa.rawuk_btc_ix_spc_planogram_temp ixp
			inner join ser.Planogram plgm
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
			and plgm.SCDActiveFlag='Y'
			and ixp.row_status=@psaRowStatus 
			INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
					ser.RefLov rl
					JOIN ser.Reflovset rls
					on rl.LOVSETId=rls.LOVSetID
					WHERE rls.LOVSetName = 'planner_family'
					 AND rls.LOVsetRecordSourceId = @LOVRecordSourceId)c
			on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.desc2
			where ixp.desc2 is not null and ixp.desc2!=''
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child'
			 )t;


 PRINT 'Inserted 2nd case with source column as desc2'
SET @max_PlanogramGroupId=(SELECT COALESCE(MAX(PlanogramGroupId),0) FROM  ser.PlanogramGroup)
--3.
		INSERT INTO ser.PlanogramGroup
        (PlanogramGroupId,PlanogramId,LOVPlanogramGroupSetId,LOVGroupId,ParentPlanogramGroupId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
		   select 
		    ROW_NUMBER() OVER(ORDER BY t.LOVGroupId,t.PlanogramId ASC)+@max_PlanogramGroupId PlanogramGroupId,*
			from
			(select distinct 
		    plgm.PlanogramId PlanogramId,
		    @LOVSetId_planogramgroup_desc1 LOVPlanogramGroupSetId,
		    c.LovId LOVGroupId,
		    NULL ParentPlanogramGroupId,
		    @LOVRecordSourceId LOVRecordSourceId,
			plgm.SCDStartDate SCDStartDate ,
			plgm.SCDEndDate SCDEndDate,
			plgm.SCDActiveFlag  SCDActiveFlag,
			plgm.SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
			plgm.PSARowKey PSARowKey
			from psa.rawuk_btc_ix_spc_planogram_temp ixp
			inner join ser.Planogram plgm
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
			and plgm.SCDActiveFlag='Y'
			and ixp.row_status=@psaRowStatus 
			INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
					ser.RefLov rl
					JOIN ser.Reflovset rls
					on rl.LOVSETId=rls.LOVSetID
					WHERE rls.LOVSetName = 'footprint'
					 AND rls.LOVsetRecordSourceId = @LOVRecordSourceId)c
			on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.desc1
			where ixp.desc1 is not null and ixp.desc1!=''
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child'
			 )t;
 PRINT 'Inserted 3rd case with source column as desc1'
SET @max_PlanogramGroupId=(SELECT COALESCE(MAX(PlanogramGroupId),0) FROM  ser.PlanogramGroup)
--4.
		INSERT INTO ser.PlanogramGroup
        (PlanogramGroupId,PlanogramId,LOVPlanogramGroupSetId,LOVGroupId,ParentPlanogramGroupId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
		   select 
		    ROW_NUMBER() OVER(ORDER BY t.LOVGroupId,t.PlanogramId ASC)+@max_PlanogramGroupId PlanogramGroupId,*
			from
			(select distinct 
		    plgm.PlanogramId PlanogramId,
		    @LOVSetId_planogramgroup_Category LOVPlanogramGroupSetId,
		    c.LovId LOVGroupId,
		    NULL ParentPlanogramGroupId,
		    @LOVRecordSourceId LOVRecordSourceId,
			plgm.SCDStartDate SCDStartDate ,
			plgm.SCDEndDate SCDEndDate,
			plgm.SCDActiveFlag  SCDActiveFlag,
			plgm.SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
			plgm.PSARowKey PSARowKey
			from psa.rawuk_btc_ix_spc_planogram_temp ixp
			inner join ser.Planogram plgm
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
			and plgm.SCDActiveFlag='Y'
			and ixp.row_status=@psaRowStatus 
			INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
					ser.RefLov rl
					JOIN ser.Reflovset rls
					on rl.LOVSETId=rls.LOVSetID
					WHERE rls.LOVSetName = 'category'
					 AND rls.LOVsetRecordSourceId = @LOVRecordSourceId)c
			on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.Category
			where ixp.Category is not null and ixp.Category!=''
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child'
			 )t;

 PRINT 'Inserted 4th case with source column as category'
SET @max_PlanogramGroupId=(SELECT COALESCE(MAX(PlanogramGroupId),0) FROM  ser.PlanogramGroup)
--5.
		INSERT INTO ser.PlanogramGroup
       (PlanogramGroupId,PlanogramId,LOVPlanogramGroupSetId,LOVGroupId,ParentPlanogramGroupId,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowKey)
		   select 
		    ROW_NUMBER() OVER(ORDER BY t.LOVGroupId,t.PlanogramId ASC)+@max_PlanogramGroupId PlanogramGroupId,*
			from
			(select distinct 
		    plgm.PlanogramId PlanogramId,
		    @LOVSetId_planogramgroup_desc3 LOVPlanogramGroupSetId,
		    c.LovId LOVGroupId,
		    NULL ParentPlanogramGroupId,
		    @LOVRecordSourceId LOVRecordSourceId,
			plgm.SCDStartDate SCDStartDate ,
			plgm.SCDEndDate SCDEndDate,
			plgm.SCDActiveFlag  SCDActiveFlag,
			plgm.SCDVersion SCDVersion,
			@SCDLOVRecordSourceId SCDLOVRecordSourceId,
			CAST(@serveETLRunLogID AS INT)  ETLRunLogId,
			plgm.PSARowKey PSARowKey
			from psa.rawuk_btc_ix_spc_planogram_temp ixp
			inner join ser.Planogram plgm
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
			and plgm.SCDActiveFlag='Y'
			and ixp.row_status=@psaRowStatus 
			INNER JOIN (SELECT  rl.LOVId,rl.LOVRecordSourceId,rl.lovkey FROM
					ser.RefLov rl
					JOIN ser.Reflovset rls
					on rl.LOVSETId=rls.LOVSetID
					WHERE rls.LOVSetName = 'format'
					 AND rls.LOVsetRecordSourceId = @LOVRecordSourceId)c
			on ixp.record_source_id=c.LOVRecordSourceId AND c.LOVKey = ixp.desc3
			where ixp.desc3 is not null and ixp.desc3!=''
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child'
			)t;

 PRINT 'Inserted 5th case with source column as desc3'
 PRINT '****************Insertion of  PlanogramGroup Table Completed*********************'
 


 /********************************************************************************************************************************
4.	Table Name  :PlanogramProperty 
	Condition: Create/modify an entry for Height,Width,Depth,build_size against each row of the Planogram Data,if Height,Width,Depth,build_size resp is not
				null or not blank.
**********************************************************************************************************************************/

PRINT '****************Loading of  PlanogramProperty Table *********************'
      INSERT INTO ser.PlanogramProperty
		 (PlanogramId,MeasureId,LOVUOMId,Value,LOVRecordSourceId,SCDStartDate,SCDEndDate,SCDActiveFlag,SCDVersion,SCDLOVRecordSourceId,ETLRunLogId,PSARowkey)
        SELECT 
        plgm.PlanogramId PlanogramId,
        m.MeasureId MeasureId,
        @UOMId LOVUOMId,
        ixp.desc29 Value,
        @LOVRecordSourceId LOVRecordSourceId,
		plgm.SCDStartDate SCDStartDate ,
		@SCDEndDate SCDEndDate,
		plgm.SCDActiveFlag  SCDActiveFlag,
		plgm.SCDVersion SCDVersion,
        @SCDLOVRecordSourceId SCDLOVRecordSourceId,
        CAST(@serveETLRunLogID AS INT) ETLRunLogId,
		plgm.PSARowkey PSARowkey
        FROM ser.Planogram plgm
            JOIN psa.rawuk_btc_ix_spc_planogram_temp  ixp   			
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child 
			and plgm.SCDActiveFlag='Y'		
            INNER JOIN ser.Measure m on plgm.LOVRecordSourceId = m.LOVRecordSourceId 
            WHERE  m.MeasureName = 'shelf_depth' AND ixp.desc29 != '' AND ixp.desc29 is not null
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child'
			and ixp.row_status=@psaRowStatus 
        	group by plgm.PlanogramId,m.MeasureId,ixp.desc29,plgm.SCDStartDate,plgm.SCDActiveFlag,plgm.SCDVersion,plgm.PSARowkey
        UNION
        SELECT 
        plgm.PlanogramId PlanogramId,
        m.MeasureId MeasureId,
        @UOMId LOVUOMId,
        ixp.desc28 Value,
        @LOVRecordSourceId LOVRecordSourceId,
		plgm.SCDStartDate SCDStartDate ,
		@SCDEndDate SCDEndDate,
		plgm.SCDActiveFlag  SCDActiveFlag,
		plgm.SCDVersion SCDVersion,
        @SCDLOVRecordSourceId SCDLOVRecordSourceId,
        CAST(@serveETLRunLogID AS INT) ETLRunLogId,
		plgm.PSARowkey PSARowkey
        FROM ser.Planogram plgm
            JOIN psa.rawuk_btc_ix_spc_planogram_temp  ixp    
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child 
			and plgm.SCDActiveFlag='Y'
            INNER JOIN ser.Measure m on plgm.LOVRecordSourceId = m.LOVRecordSourceId 
            WHERE m.MeasureName = 'shelf_height' AND ixp.desc28 != '' AND ixp.desc28 is not null
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child'
			and ixp.row_status=@psaRowStatus 
        	group by plgm.PlanogramId,m.MeasureId,ixp.desc28,plgm.SCDStartDate,plgm.SCDActiveFlag,plgm.SCDVersion,plgm.PSARowkey
        UNION
        SELECT 
        plgm.PlanogramId PlanogramId,
        m.MeasureId MeasureId,
        @UOMId LOVUOMId,
        cast(ixp.width as nvarchar(80)) Value,
        @LOVRecordSourceId LOVRecordSourceId,
			plgm.SCDStartDate SCDStartDate ,
			@SCDEndDate SCDEndDate,
			plgm.SCDActiveFlag  SCDActiveFlag,
			plgm.SCDVersion SCDVersion,
        @SCDLOVRecordSourceId SCDLOVRecordSourceId,
        CAST(@serveETLRunLogID AS INT) ETLRunLogId,
		plgm.PSARowkey PSARowkey
        FROM ser.Planogram plgm
            JOIN psa.rawuk_btc_ix_spc_planogram_temp  ixp 
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
			and plgm.SCDActiveFlag='Y'
            INNER JOIN ser.Measure m on plgm.LOVRecordSourceId = m.LOVRecordSourceId 
            WHERE  m.MeasureName = 'shelf_width' AND ixp.width != '' AND ixp.width is not null
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child'
			and ixp.row_status=@psaRowStatus 
        	group by plgm.PlanogramId,m.MeasureId,ixp.width,plgm.SCDStartDate,plgm.SCDActiveFlag,plgm.SCDVersion,plgm.PSARowkey
        UNION
        SELECT 
        plgm.PlanogramId PlanogramId,
        m.MeasureId MeasureId,
        @UOMId LOVUOMId,
        ixp.desc4 Value,
        @LOVRecordSourceId LOVRecordSourceId,
			plgm.SCDStartDate SCDStartDate ,
			@SCDEndDate SCDEndDate,
			plgm.SCDActiveFlag  SCDActiveFlag,
			plgm.SCDVersion SCDVersion,
        @SCDLOVRecordSourceId SCDLOVRecordSourceId,
        CAST(@serveETLRunLogID AS INT) ETLRunLogId,
		plgm.PSARowkey PSARowkey
        FROM ser.Planogram plgm
            JOIN psa.rawuk_btc_ix_spc_planogram_temp  ixp 
			on plgm.Sourcekey=ixp.dbkey
			and plgm.LOVSourceKeyTypeId=@Sourcekeytypeid_child
			and plgm.SCDActiveFlag='Y'
            INNER JOIN ser.Measure m on plgm.LOVRecordSourceId = m.LOVRecordSourceId 
            WHERE  m.MeasureName = 'build_size' AND ixp.desc4 != '' AND ixp.desc4 is not null
			and plgm.LOVRecordSourceId=@LOVRecordSourceId
			and plgm.ParentPlanogramId is not null
			and ixp.record_type='child'
			and ixp.row_status=@psaRowStatus 
        	group by plgm.PlanogramId,m.MeasureId,ixp.desc4,plgm.SCDStartDate,plgm.SCDActiveFlag,plgm.SCDVersion,plgm.PSARowkey
PRINT '****************Insertion of  PlanogramProperty Table Completed*********************'


/********************************************************************************************************************************
5.	Update Source Table  :psa.rawuk_btc_ix_spc_planogram 
	Condition: Update psa table rowstatus to 'Loaded to Serve' Once all parent and Child tables load completed
**********************************************************************************************************************************/

PRINT '********************Updating Source Table accordingly -> rawuk_btc_ix_spc_planogram****************';  



UPDATE psa.rawuk_btc_ix_spc_planogram SET row_status=@serRowStatus
	FROM psa.rawuk_btc_ix_spc_planogram ixp 
	Inner Join ser.Planogram p ON  ixp.row_id=p.PSARowKey and ixp.record_source_id=p.LovRecordSourceID 
	WHERE ixp.row_status=@psaRowStatus  AND p.ETLRunLogId in (CAST(@serveETLRunLogID AS INT))
		

		PRINT 'Info: Source Table Updated accordingly -> rawuk_btc_ix_spc_planogram'; 
		

COMMIT TRANSACTION;
END TRY
			BEGIN CATCH 
				THROW;					
				ROLLBACK TRANSACTION ;						
			END CATCH 

		IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_temp') is not null
		BEGIN
			DROP TABLE psa.rawuk_btc_ix_spc_planogram_temp
			PRINT 'Info: Dropped Temp table -> [psa].[rawuk_btc_ix_spc_planogram_temp]';
		END	

		IF OBJECT_ID('psa.rawuk_btc_ix_spc_planogram_temp') is not null
		BEGIN
			drop table ser.PLANOGRAM_TEMP
			PRINT 'Info: Dropped Temp table -> ser.PLANOGRAM_TEMP';
		END	


		END

GO
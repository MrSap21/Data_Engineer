/****** Object:  StoredProcedure [psaTemp].[sp_update_status_FW]    Script Date: 26/06/2020 10:36:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID('dbo.sp_update_status') IS NOT NULL
BEGIN
	DROP PROC [dbo].[sp_update_status]
END
GO
CREATE PROC [dbo].[sp_update_status] @tableName [varchar](max) AS		
/*
************************************************************************************************************
Procedure Name				: sp_update_status
Purpose						: Resets the 'SPStatus' column in the 'serve_sp_mapping' metadata table with 
							  the value 'Y' 
*************************************************************************************************************
Modification History
*************************************************************************************************************
*/ 

BEGIN
	SET NOCOUNT ON;
	
	IF OBJECT_ID('dbo.serve_sp_mapping') IS NULL
		BEGIN
			SELECT -1 AS 'ProcedureStatus';
		END
	ELSE
		BEGIN
			UPDATE dbo.serve_sp_mapping SET SPStatus='Y' where TableName=@tableName;
			IF @@ERROR = 0
				BEGIN
					SELECT 1 AS 'ProcedureStatus';
				END
			ELSE
				BEGIN
					SELECT -1 AS 'ProcedureStatus';
				END
		END
END
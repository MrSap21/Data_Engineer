--TODO : row_id column addition not tested
--DDL for psa tables 

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_data
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[TITLE] [nvarchar](500) NULL,
	[FIRST_NAME] [nvarchar](500) NULL,
	[MIDDLE_NAME] [nvarchar](500) NULL,
	[LAST_NAME] [nvarchar](500) NULL,
	[CHOSEN_FIRST_NAME] [nvarchar](500) NULL,
	[BIRTH_LAST_NAME] [nvarchar](500) NULL,
	[GENDER] [nvarchar](500) NULL,
	[DATE_OF_BIRTH] [nvarchar](500) NULL,
	[DATE_OF_DEATH] [nvarchar](500) NULL,
	[SOURCE_DECEASED_INFO] [nvarchar](500) NULL,
	[DEATH_NOTIFICATION_DATE] [nvarchar](500) NULL,
	[THIRD_PARTY_PROVIDED_FLG] [nvarchar](10) NULL,
	[NO_DATA_SHARE_FLG] [nvarchar](10) NULL,
	[NO_DUTY_OF_CARE_FLG] [nvarchar](10) NULL,
	[SPECIAL_FLG3] [nvarchar](10) NULL,
	[SPECIAL_FLG4] [nvarchar](10) NULL,
	[SPECIAL_FLG5] [nvarchar](10) NULL,
	[SPECIAL_FLG6] [nvarchar](10) NULL,
	[SPECIAL_FLG7] [nvarchar](10) NULL,
	[SPECIAL_FLG8] [nvarchar](10) NULL,
	[SPECIAL_FLG9] [nvarchar](10) NULL,
	[SPECIAL_FLG10] [nvarchar](10) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[CONSENT_SOURCE_CODE] [nvarchar](12) NULL,
	[CONSENT_SOURCE_GUID] [nvarchar](40) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[CONSENT_TYPE_ID] [nvarchar](10) NULL,
	[CONSENT_OPT_IN_VALUE] [nvarchar](10) NULL,
	[CONSENT_UPDATE_TIME] [nvarchar](20) NULL,
	[CONSENT_SOURCE_CODE] [nvarchar](12) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_address
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[ADDRESS_TYPE] [nvarchar](500) NULL,
	[HOUSE_NUMBER] [nvarchar](500) NULL,
	[HOUSE_UNIT] [nvarchar](500) NULL,
	[BUILDING_NAME] [nvarchar](500) NULL,
	[STREET] [nvarchar](500) NULL,
	[LOCALITY] [nvarchar](500) NULL,
	[TOWN] [nvarchar](500) NULL,
	[COUNTY] [nvarchar](500) NULL,
	[POST_CODE] [nvarchar](500) NULL,
	[COUNTRY_CODE] [nvarchar](500) NULL,
	[NO_FIXED_ABODE_FLG] [nvarchar](10) NULL,
	[ADDRESS_VALID_FLG] [nvarchar](10) NULL,
	[GONE_AWAY_FLG] [nvarchar](10) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[SOCIAL_MEDIA_TYPE] [nvarchar](30) NULL,
	[SOCIAL_MEDIA_ID] [nvarchar](500) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_phone
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[PHONE_TYPE] [nvarchar](20) NULL,
	[PHONE_NUMBER] [nvarchar](500) NULL,
	[MOBILE_VALID_FLG] [nvarchar](10) NULL,
	[PHONE_VALID_FLG] [nvarchar](10) NULL,
	[PHONE_CERTAINTY_FLG] [nvarchar](10) NULL,
	[PHONE_EXTRA_INFO_FLG] [nvarchar](10) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[STAFF_DISCOUNT_CARD] [nvarchar](500) NULL,
	[NHS_NUMBER] [nvarchar](500) NULL,
	[CHI_NUMBER] [nvarchar](500) NULL,
	[HSCN_NUMBER] [nvarchar](500) NULL,
	[ADCARD_NUMBER] [nvarchar](500) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[SOURCE_CODE] [nvarchar](12) NULL,
	[SOURCE_GUID] [nvarchar](40) NULL,
	[MEMBER_UPDATE_TIME] [nvarchar](20) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_email
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[EMAIL_TYPE] [nvarchar](10) NULL,
	[EMAIL_ADDRESS] [nvarchar](500) NULL,
	[EMAIL_VALID_FLG] [nvarchar](10) NULL,
	[EMAIL_CERTAINTY_FLG] [nvarchar](10) NULL,
	[EMAIL_EXTRA_INFO_FLG] [nvarchar](10) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;

CREATE TABLE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete
(
	row_id bigint NOT NULL,
	[ENTITY_ID] [nvarchar](500) NULL,
	[DELETE_FLG] [nvarchar](10) NULL,
	[PROCESS_FLG] [nvarchar](10) NULL,
	[PROCESS_DATE] [nvarchar](20) NULL,
	[INSERT_DATE] [nvarchar](20) NULL,
	[UPDATE_DATE] [nvarchar](20) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;
CREATE TABLE [psa].[BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_type]
(
	row_id bigint NOT NULL,
	[CONSENT_TYPE_ID] [nvarchar](20) NULL,
	[CONSENT_TYPE_DESC] [nvarchar](100) NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL, 
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
) ;
GO
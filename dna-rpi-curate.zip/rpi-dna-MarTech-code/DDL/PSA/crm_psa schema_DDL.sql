CREATE TABLE psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_child					
(					
row_id bigint NOT NULL
,RECORD_TYPE			nvarchar(10)	
,CUSTOMER_NUMBER     nvarchar(500)         
,CHILD_NUMBER       nvarchar(500)         
,DATE_TYPE          nvarchar(20)         
,CHILD_DOB          nvarchar(500) 
,CHILD_FORENAME     nvarchar(500)
,CHILD_GENDER       nvarchar(500)
,IUD_FLAG           nvarchar(10)
,CREATE_USER        nvarchar(500)
,CHANGE_USER        nvarchar(500)
,CREATED_BY_CHANNEL nvarchar(20)         
,UPDATED_BY_CHANNEL  nvarchar(20)
,etl_runlog_id int NULL
,asset_id int NULL
,record_source_id int NULL
,row_status int NULL
,created_timestamp datetime NULL
,active_flag char(1) NULL                 
	)
WITH	
(   
    DISTRIBUTION = REPLICATE,  
    HEAP
  ) ;  	
					
CREATE TABLE psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_clubs					
(					
row_id bigint NOT NULL
,RECORD_TYPE		nvarchar(10)	
,CUSTOMER_NUMBER     nvarchar(500)           	
,CLUB_TYPE          nvarchar(10)  			
,CLUB_NAME          nvarchar(10)  			
,CLUB_STATUS        nvarchar(20)           
,CLUB_NUMBER        nvarchar(20)           
,CLUB_JOIN_SOURCE   nvarchar(10)  		
,DATE_JOINED_CLUB   nvarchar(10)   		
,DATE_RESIGNED_CLUB nvarchar(10)   		
,DATE_ACTIVATED     nvarchar(10)   		
,DATE_EXPIRED       nvarchar(10)   		
,CLUB_RESIGN_SOURCE nvarchar(10)  		
,CLUB_TOPIC         nvarchar(20)           
,CREATE_USER        nvarchar(500)  			
,CHANGE_USER        nvarchar(500)  			
,CREATED_BY_CHANNEL nvarchar(20)           
,UPDATED_BY_CHANNEL nvarchar(20)  
,etl_runlog_id int NULL
,asset_id int NULL
,record_source_id int NULL
,row_status int NULL
,created_timestamp datetime NULL
,active_flag char(1) NULL             
)
WITH	
(   
    DISTRIBUTION = REPLICATE,  
    HEAP
  ) ;  	
							
					
CREATE TABLE psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers					
(					
row_id bigint NOT NULL
,RECORD_TYPE			nvarchar(10)		
,BUSINESS_PARTNER_ID    nvarchar(500)  					
,TITLE                  nvarchar(500)          	
,BUSINESS_PARTNER_ROLE  nvarchar(500) 				
,USERID                 nvarchar(500) 				
,INIT                   nvarchar(500) 				
,FORENAME               nvarchar(500) 				
,SURNAME                nvarchar(500) 				
,GENDER                 nvarchar(500) 			
,DATE_OF_BIRTH          nvarchar(500)  			
,DATE_OF_DEATH          nvarchar(500)  			
,NO_IN_HOUSEHOLD        nvarchar(500)          	
,DONOR_FLAG             nvarchar(500)          	
,APPL_SOURCE_CODE       nvarchar(10) 			
,TRAFFIC_LIGHT          nvarchar(10) 				
,DO_NOT_MAIL            nvarchar(10) 			
,GONE_AWAY_DATE         nvarchar(20)          	
,HOUSE_NUMBER           nvarchar(500) 				
,STREET                 nvarchar(500)				
,UNIT_NAME              nvarchar(500) 				
,BUILDING_NAME          nvarchar(500) 				
,TOWN                   nvarchar(500) 				
,DISTRICT               nvarchar(500) 				
,COUNTY                 nvarchar(500) 				
,POST_CODE              nvarchar(500) 				
,ADDRESS_TYPE           nvarchar(500) 			
,COUNTRY_CODE           nvarchar(500) 			
,PHONE_NUMBER           nvarchar(500) 				
,MOBILE_NUMBER          nvarchar(500) 				
,FAX_NUMBER             nvarchar(500) 				
,EMAIL_ADDRESS          nvarchar(500) 				
,CORRECTIVE_EYEWEAR     nvarchar(20)          	
,CONTACT_PREFERENCE     nvarchar(10) 			
,CREATE_USER            nvarchar(500) 				
,CHANGE_USER            nvarchar(500) 				
,CREATED_BY_CHANNEL     nvarchar(20)          	
,UPDATED_BY_CHANNEL     nvarchar(20) 
,etl_runlog_id int NULL
,asset_id int NULL
,record_source_id int NULL
,row_status int NULL
,created_timestamp datetime NULL
,active_flag char(1) NULL            	
)
WITH	
(   
    DISTRIBUTION = REPLICATE,  
    HEAP
  ) ;  	
							
					
CREATE TABLE psa.BUKIT_ABACUS_BUK_SAPCRM_Advantage_Card_membership_card_Abacus					
(					
row_id bigint NOT NULL
,RECORD_TYPE			nvarchar(10)						
,CARD_NUMBER            nvarchar(500)      			
,CARD_CHECK_DIGIT      nvarchar(20)         	
,CARD_STATUS_CODE      nvarchar(10)			
,CUSTOMER_NUMBER       nvarchar(500)         		
,DESP_TO_CUST_DATE     nvarchar(14)			
,CFA_ID                nvarchar(10)			
,ACCOUNT_NUMBER        nvarchar(500)         		
,PROD_BATCH_NUMBER     nvarchar(20)         		
,GEOGRAPHY_CODE        nvarchar(10)			
,ADVCD_TMNTD_TMSTMP    nvarchar(14)			
,CARD_TYPE_CODE        nvarchar(10)  			
,CARD_ACTIVATION_DATE  nvarchar(10) 			
,CARD_EXPIRY_DATE      nvarchar(10) 			
,CHANGE_USER           nvarchar(500)				
,CREATED_BY_CHANNEL    nvarchar(20)         	
,UPDATED_BY_CHANNEL    nvarchar(20) 
,etl_runlog_id int NULL
,asset_id int NULL
,record_source_id int NULL
,row_status int NULL
,created_timestamp datetime NULL
,active_flag char(1) NULL            	
	)
WITH	
(   
    DISTRIBUTION = REPLICATE,  
    HEAP
  ) ;  	
						
					
CREATE TABLE psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_points					
(					
row_id bigint NOT NULL
,RECORD_TYPE			nvarchar(10) 			
,ACCOUNT_NUMBER          nvarchar(500)          		
,CUSTOMER_NUMBER         nvarchar(500)          		
,MEMBERSHIP_TYPE_CODE    nvarchar(10) 			
,POINTS_BALANCE          nvarchar(15) 				
,POINTS_EARNED           nvarchar(15) 				
,ACCOUNT_TERMINATED_DATE nvarchar(10)  			
,ACCOUNT_ENROLLED_DATE   nvarchar(10)  			
,POINTS_REDEEMED         nvarchar(15) 				
,POINTS_EXPIRED          nvarchar(15) 				
,MEMBERSHIP_STATUS       nvarchar(32) 				
,POINT_ACCOUNT_ID        nvarchar(500) 				
,GEOGRAPHY_CODE          nvarchar(10) 			
,LATEST_TXN_DATE         nvarchar(10)  			
,CHANGED_BY              nvarchar(500) 				
,CREATED_BY_CHANNEL      nvarchar(20)          	
,UPDATED_BY_CHANNEL      nvarchar(20)   
,etl_runlog_id int NULL
,asset_id int NULL
,record_source_id int NULL
,row_status int NULL
,created_timestamp datetime NULL
,active_flag char(1) NULL           	
	)
WITH	
(   
    DISTRIBUTION = REPLICATE,  
    HEAP
  ) ;  	
						
					
CREATE TABLE psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_activity					
(					
row_id bigint NOT NULL
,RECORD_TYPE			nvarchar(10) 							
,ACCOUNT_NUMBER                      nvarchar(500)         	
,MEMBER_ACTIVITY_ID                  nvarchar(20)         	
,POINT_TRANSACTION_DATE              nvarchar(10) 		
,POINT_TRANSACTION_TIME              nvarchar(14)			
,CUSTOMER_NUMBER                     nvarchar(500)         	
,POINTS_REQUESTED                    nvarchar(15)			
,POINTS_BALANCE                      nvarchar(15)			
,QUALIFIYING_SPEND                   nvarchar(18)			
,TOTAL_SPEND                         nvarchar(18)			
,POINT_ACCOUNT_ID                    nvarchar(500)			
,CURRENCY_CODE                       nvarchar(10)		
,EXTERNAL_REF_NO                     nvarchar(20)			
,THIRD_PARTY_ID                      nvarchar(12)			
,TILL_TXN_TIMESTAMP                  nvarchar(14)			
,STORE_NUMBER                        nvarchar(20)         
,TERMINAL_ID                         nvarchar(20)         
,CHANNEL_ID                          nvarchar(20)         
,ACTIVITY_TYPE                       nvarchar(10)		
,CATEGORY                            nvarchar(10)		
,OPERATOR_ID                         nvarchar(500)         	
,MANUAL_FLAG                         nvarchar(10)			
,CARD_NUMBER                         nvarchar(500)      		
,RECEIPT_NUMBER                      nvarchar(34)			
,COUNTRY_CODE                        nvarchar(500)		
,ADCARD_PRESENTATION_METHOD          nvarchar(20)         
,CHANGED_BY                          nvarchar(500)			
,OFFLINE_FLAG                        nvarchar(10)		
,MEMBER_ACTIVITY_STATUS              nvarchar(10)
,etl_runlog_id int NULL
,asset_id int NULL
,record_source_id int NULL
,row_status int NULL
,created_timestamp datetime NULL
,active_flag char(1) NULL   	
	)
WITH	
(   
    DISTRIBUTION = REPLICATE,  
    HEAP
  ) ;  	
						
					
CREATE TABLE psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions					
(					
 row_id bigint NOT NULL
,RECORD_TYPE			nvarchar(10) 					
,CUSTOMER_NUMBER      nvarchar(500)          		
,ACCOUNT_NUMBER       nvarchar(500)          		
,MEMBER_ACTIVITY_ID   nvarchar(20)          		
,CARD_NUMBER          nvarchar(500)       			
,TRANSACTION_TYPE     nvarchar(10)   			
,POINTS_MOVEMENT      nvarchar(15) 				
,CREATION_TIMESTAMP   nvarchar(14) 				
,POINTS_EXPIRY_DATE   nvarchar(10)  			
,POINT_ACCOUNT_ID     nvarchar(500) 				
,POINT_TYPE           nvarchar(20) 				
,CHANGE_USER          nvarchar(500) 				
,REWARD_RULE_ID       nvarchar(10) 
,etl_runlog_id int NULL
,asset_id int NULL
,record_source_id int NULL
,row_status int NULL
,created_timestamp datetime NULL
,active_flag char(1) NULL    				
)
WITH	
(   
    DISTRIBUTION = REPLICATE,  
    HEAP
  ) ;  	
CREATE TABLE psa.SAPCOE_SAPCRM_BUK_SAPCRM_Customer_Anonymisation
(
 row_id bigint NOT NULL
,RECORD_TYPE			nvarchar(10) 	
,SAP_IDENTIFIER	nvarchar(20) 
,CUSTOMER_NUMBER	nvarchar(20)  
,etl_runlog_id int NULL
,asset_id int NULL
,record_source_id int NULL
,row_status int NULL
,created_timestamp datetime NULL
,active_flag char(1) NULL 
)
WITH	
(   
    DISTRIBUTION = ROUND_ROBIN,  
    HEAP 
) ;  	
		


CREATE TABLE psa.SAPCOE_SAPCRM_BUK_SAPCRM_Customer_Status_Change
(
 row_id bigint NOT NULL
,RECORD_TYPE			nvarchar(10) 	
,CUSTOMER_NUMBER	nvarchar(20)  
,ABACUS_ACCOUNT_STATUS	nvarchar(20) 
,EXTRACT_DATE	nvarchar(20) 
,CRM_NEW_STATUS	nvarchar(20) 
,etl_runlog_id int NULL
,asset_id int NULL
,record_source_id int NULL
,row_status int NULL
,created_timestamp datetime NULL
,active_flag char(1) NULL   
)
WITH	
(   
    DISTRIBUTION = ROUND_ROBIN,  
    HEAP 
  ) ;  
GO  
--TODO : PSA and LOAD Tablename change and sp rename not tested
--     : row_id need to be included
--     : ErrorLog tableName to be corrected (DNA)
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_consent]', N'P') IS NOT NULL
    DROP PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_consent]
GO
CREATE PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_consent]
AS
-------------------------------------------------------------------------------------------------------------
--Procedure Name				: sp_merge_bukit_btcsvoc_buk_svoc_customer_consent
--Purpose						: To UPSERT data from lod to psa svoc central consents tables in azure
--Domain						: SVoC
--psa Layer Target Tables		: psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent
--	
--Logic							: This procedure will UPSERT the data from lod to psa bukit_btcsvoc_buk_svoc_customer_consent table. 
--								 For updated records only Update_date column will be set to current timestamp. 
--								 For inserted records both update_date and insert_date columns will be set to current timestamp.
--Last Modified					: 01 March 2021
--Last Modified by				: Abhilaksh Agnihotri
--Modification					: Modified to have lod to psa tranformations
-------------------------------------------------------------------------------------------------------------

BEGIN


DECLARE @CurrDate nvarchar(20);	
SET @CurrDate= Convert(nvarchar(20),CONVERT(DATETIMEOFFSET(0),CURRENT_TIMESTAMP),127);


IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_TEMP
END	

CREATE TABLE tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_TEMP
(
[ENTITY_ID]               	[nvarchar](10) NULL,
[PARTY_ID]                	[nvarchar](10) NULL,
[CONSENT_TYPE_ID]             [nvarchar](10) NULL,
[CONSENT_OPT_IN_VALUE]        [nvarchar](10) NULL,
[CONSENT_UPDATE_TIME]         [nvarchar](10) NULL,
[CONSENT_SOURCE_CODE]         [nvarchar](12) NULL,
[ENTITY_CREATE_TIME]          [nvarchar](20) NULL,
[ENTITY_LAST_UPDATE_TIME]     [nvarchar](20) NULL

)

--Modified : 11-May - The consent change will not be updating the ENTITY_LAST_UPDATE_TIME date instead it updates the CONSENT_UPDATE_TIME.
--(ENTITY_LAST_UPDATE_TIME will be updated for Entity PII such as demographics,entity link,phone,address,social information,email,identifier only and no Consents)

BEGIN TRANSACTION;
BEGIN TRY
--create temp table with source data avoiding duplicates
PRINT 'inserting sourcedata to the temp table started';	
INSERT INTO tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_TEMP
SELECT						ENTITY_ID, 
							PARTY_ID, 
							CONSENT_TYPE_ID, 
							CONSENT_OPT_IN_VALUE, 
							CONSENT_UPDATE_TIME, 
							CONSENT_SOURCE_CODE,  
							ENTITY_CREATE_TIME, 
							ENTITY_LAST_UPDATE_TIME
			FROM  (SELECT 
							ENTITY_ID, 
							PARTY_ID, 
							CONSENT_TYPE_ID, 
							CONSENT_OPT_IN_VALUE, 
							CONSENT_UPDATE_TIME, 
							CONSENT_SOURCE_CODE,  
							ENTITY_CREATE_TIME, 
							ENTITY_LAST_UPDATE_TIME,
             ROW_NUMBER() OVER (PARTITION BY ENTITY_ID, PARTY_ID, CONSENT_TYPE_ID ORDER BY ENTITY_LAST_UPDATE_TIME DESC, ENTITY_CREATE_TIME DESC) AS RNUM 
			 FROM lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_Incr) src
			 WHERE RNUM=1
			 
	PRINT 'inserting sourcedata to the temp table completed';						

UPDATE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent	
SET 
			ENTITY_ID = srcConsent.ENTITY_ID, 
			PARTY_ID = srcConsent.PARTY_ID, 
			CONSENT_TYPE_ID = srcConsent.CONSENT_TYPE_ID, 
			CONSENT_OPT_IN_VALUE = srcConsent.CONSENT_OPT_IN_VALUE, 
			CONSENT_UPDATE_TIME = srcConsent.CONSENT_UPDATE_TIME, 
			CONSENT_SOURCE_CODE = srcConsent.CONSENT_SOURCE_CODE,  
            ENTITY_CREATE_TIME = srcConsent.ENTITY_CREATE_TIME, 
			ENTITY_LAST_UPDATE_TIME = srcConsent.ENTITY_LAST_UPDATE_TIME, 
			UPDATE_DATE = @CurrDate
FROM	 psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent tgtConsent 
			INNER JOIN #BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_TEMP srcConsent					 
			 
ON (tgtConsent.ENTITY_ID = srcConsent.ENTITY_ID
	AND tgtConsent.PARTY_ID = srcConsent.PARTY_ID
	AND tgtConsent.CONSENT_TYPE_ID = srcConsent.CONSENT_TYPE_ID)
	WHERE srcConsent.ENTITY_LAST_UPDATE_TIME > tgtConsent.ENTITY_LAST_UPDATE_TIME 


INSERT INTO psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent
				SELECT  srcConsent.ENTITY_ID,
						srcConsent.PARTY_ID,
						srcConsent.CONSENT_TYPE_ID,
						srcConsent.CONSENT_OPT_IN_VALUE,
						srcConsent.CONSENT_UPDATE_TIME,
						srcConsent.CONSENT_SOURCE_CODE,
						srcConsent.ENTITY_CREATE_TIME,
						srcConsent.ENTITY_LAST_UPDATE_TIME,
						@CurrDate,	
						@CurrDate	
						FROM #BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_TEMP srcConsent
						LEFT JOIN psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent tgtConsent
						ON (tgtConsent.ENTITY_ID = srcConsent.ENTITY_ID
						AND tgtConsent.PARTY_ID = srcConsent.PARTY_ID
						AND tgtConsent.CONSENT_TYPE_ID = srcConsent.CONSENT_TYPE_ID)
						WHERE tgtConsent.ENTITY_ID IS NULL;
END TRY

BEGIN CATCH

IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION;
DECLARE @UserName VARCHAR(100),
		@ErrorNumber INT,
		@ErrorState INT,
		@ErrorSeverity INT,
		@ErrorProcedure VARCHAR(MAX),
		@ErrorMessage VARCHAR(MAX),
		@ErrorDateTime  DATETIME;

SELECT	@UserName=SUSER_SNAME(),
		@ErrorNumber=ERROR_NUMBER(),
		@ErrorState=ERROR_STATE(),
		@ErrorSeverity=ERROR_SEVERITY(),
		@ErrorProcedure='sp_merge_bukit_btcsvoc_buk_svoc_customer_consent',
		@ErrorMessage=ERROR_MESSAGE(),
		@ErrorDateTime=GETDATE();

INSERT INTO [psa].[UK_SVOCC_DB_Errors_Log]
    VALUES	(@UserName, @ErrorNumber, @ErrorState, @ErrorSeverity, @ErrorProcedure, @ErrorMessage, @ErrorDateTime);

THROW;

END CATCH

IF @@TRANCOUNT>0
COMMIT TRANSACTION;

IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_TEMP
END	

END
GO
--TODO : PSA and LOAD tablename change and sp rename change are not tested
--     : row_id need to be included
--     : ErrorLog tableName to be corrected (DNA)
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_social_media]', N'P') IS NOT NULL
    DROP PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_social_media]
GO
CREATE PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_social_media] AS
-------------------------------------------------------------------------------------------------------------
--Procedure Name				: sp_merge_bukit_btcsvoc_buk_svoc_customer_social_media
--Purpose						: To UPSERT data from lod to psa svoc central consents tables in azure
--Domain						: SVoC
--psa Layer Target Tables		: psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media
--	
--Logic							: This procedure will UPSERT the data from lod to psa bukit_btcsvoc_buk_svoc_customer_social_media table. 
--								 For updated records only Update_date column will be set to current timestamp. 
--								 For inserted records both update_date and insert_date columns will be set to current timestamp.
--Last Modified					: 01 March 2021
--Last Modified by				: Abhilaksh Agnihotri
--Modification					: Modified to have lod to psa tranformations
-------------------------------------------------------------------------------------------------------------

BEGIN


DECLARE @CurrDate nvarchar(20);
SET @CurrDate= Convert(nvarchar(20),CONVERT(DATETIMEOFFSET(0),CURRENT_TIMESTAMP),127);

IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media_TEMP
END	
CREATE TABLE tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media_TEMP
(
[ENTITY_ID]					[nvarchar](10) NULL,
[PARTY_ID]                	[nvarchar](10) NULL,
[SOCIAL_MEDIA_TYPE]         [nvarchar](30) NULL,
[SOCIAL_MEDIA_ID]           [nvarchar](40) NULL,
[ENTITY_CREATE_TIME]        [nvarchar](20) NULL,
[ENTITY_LAST_UPDATE_TIME]   [nvarchar](20) NULL
)


BEGIN TRANSACTION;
BEGIN TRY
PRINT 'inserting sourcedata to the temp table started';	
INSERT INTO tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media_TEMP
SELECT			ENTITY_ID, 
				PARTY_ID, 
				SOCIAL_MEDIA_TYPE, 
				SOCIAL_MEDIA_ID, 
				ENTITY_CREATE_TIME, 
				ENTITY_LAST_UPDATE_TIME
		 FROM  (SELECT 
				ENTITY_ID, 
				PARTY_ID, 
				SOCIAL_MEDIA_TYPE, 
				SOCIAL_MEDIA_ID, 
				ENTITY_CREATE_TIME, 
				ENTITY_LAST_UPDATE_TIME,
			 ROW_NUMBER() OVER (PARTITION BY ENTITY_ID, PARTY_ID, SOCIAL_MEDIA_TYPE ORDER BY ENTITY_LAST_UPDATE_TIME DESC, ENTITY_CREATE_TIME DESC) AS RNUM 
			 FROM lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media_Incr) src
			 WHERE RNUM=1

	PRINT 'inserting sourcedata to the temp table completed';

UPDATE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media	
SET

		ENTITY_ID = srcSocialMedia.ENTITY_ID,
		PARTY_ID = srcSocialMedia.PARTY_ID, 
		SOCIAL_MEDIA_TYPE = srcSocialMedia.SOCIAL_MEDIA_TYPE, 
		SOCIAL_MEDIA_ID = srcSocialMedia.SOCIAL_MEDIA_ID, 
		ENTITY_CREATE_TIME = srcSocialMedia.ENTITY_CREATE_TIME, 
		ENTITY_LAST_UPDATE_TIME = srcSocialMedia.ENTITY_LAST_UPDATE_TIME,
		UPDATE_DATE = @CurrDate
       FROM  psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media tgtSocialMedia 
				INNER JOIN #BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media_TEMP srcSocialMedia
ON(tgtSocialMedia.ENTITY_ID = srcSocialMedia.ENTITY_ID
	AND tgtSocialMedia.PARTY_ID = srcSocialMedia.PARTY_ID
	AND tgtSocialMedia.SOCIAL_MEDIA_TYPE = srcSocialMedia.SOCIAL_MEDIA_TYPE)
	WHERE srcSocialMedia.ENTITY_LAST_UPDATE_TIME > tgtSocialMedia.ENTITY_LAST_UPDATE_TIME 
	                                                            

INSERT INTO psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media
				SELECT srcSocialMedia.ENTITY_ID,
					   srcSocialMedia.PARTY_ID,
					   srcSocialMedia.SOCIAL_MEDIA_TYPE,
					   srcSocialMedia.SOCIAL_MEDIA_ID,
					   srcSocialMedia.ENTITY_CREATE_TIME,
					   srcSocialMedia.ENTITY_LAST_UPDATE_TIME,
					   @CurrDate,
					   @CurrDate
FROM #BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media_TEMP srcSocialMedia
						LEFT JOIN psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media tgtSocialMedia
						ON (tgtSocialMedia.ENTITY_ID = srcSocialMedia.ENTITY_ID
						AND tgtSocialMedia.PARTY_ID = srcSocialMedia.PARTY_ID
						AND tgtSocialMedia.SOCIAL_MEDIA_TYPE = srcSocialMedia.SOCIAL_MEDIA_TYPE)
						WHERE tgtSocialMedia.ENTITY_ID IS NULL;
END TRY

BEGIN CATCH

IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION;
DECLARE @UserName VARCHAR(100),
		@ErrorNumber INT,
		@ErrorState INT,
		@ErrorSeverity INT,
		@ErrorProcedure VARCHAR(MAX),
		@ErrorMessage VARCHAR(MAX),
		@ErrorDateTime  DATETIME;

SELECT	@UserName=SUSER_SNAME(),
		@ErrorNumber=ERROR_NUMBER(),
		@ErrorState=ERROR_STATE(),
		@ErrorSeverity=ERROR_SEVERITY(),
		@ErrorProcedure='sp_merge_bukit_btcsvoc_buk_svoc_customer_social_media',
		@ErrorMessage=ERROR_MESSAGE(),
		@ErrorDateTime=GETDATE();

INSERT INTO [psa].[UK_SVOCC_DB_Errors_Log]
    VALUES	(@UserName, @ErrorNumber, @ErrorState, @ErrorSeverity, @ErrorProcedure, @ErrorMessage, @ErrorDateTime);

THROW;

END CATCH

IF @@TRANCOUNT>0
COMMIT TRANSACTION;


IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media_TEMP
END	

END
GO
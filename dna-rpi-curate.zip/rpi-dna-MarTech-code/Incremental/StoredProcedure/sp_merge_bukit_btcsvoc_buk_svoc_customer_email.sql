--TODO : PSA and LOAD Tablename change and sp rename not tested
--     : row_id need to be included
--     : ErrorLog tableName to be corrected (DNA)
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'[psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_email]', N'P') IS NOT NULL
    DROP PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_email]
GO


CREATE PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_email] AS

-------------------------------------------------------------------------------------------------------------
--Procedure Name				: sp_merge_bukit_btcsvoc_buk_svoc_customer_email
--Purpose						: To UPSERT data from lod to psa svoc central consents tables in azure
--Domain						: SVoC
--psa Layer Target Tables		: psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_email
--	
--Logic							: This procedure will UPSERT the data from lod to psa bukit_btcsvoc_buk_svoc_customer_email table. 
--								 For updated records only Update_date column will be set to current timestamp. 
--								 For inserted records both update_date and insert_date columns will be set to current timestamp.
--Last Modified					: 01 March 2021
--Last Modified by				: Krishna Divya
--Modification					: Modified to have lod to psa tranformations
-------------------------------------------------------------------------------------------------------------




BEGIN

DECLARE @CurrDate nvarchar(20);	
SET @CurrDate= Convert(nvarchar(20),CONVERT(DATETIMEOFFSET(0),CURRENT_TIMESTAMP),127);


IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_email_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_email_TEMP
END	
CREATE TABLE tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_email_TEMP
(
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[EMAIL_TYPE] [nvarchar](10) NULL,
	[EMAIL_ADDRESS] [nvarchar](500) NULL,
	[EMAIL_VALID_FLG] [nvarchar](10) NULL,
	[EMAIL_CERTAINTY_FLG] [nvarchar](10) NULL,
	[EMAIL_EXTRA_INFO_FLG] [nvarchar](10) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL
)


BEGIN TRANSACTION;
BEGIN TRY
--create temp table with source data avoiding duplicates
PRINT 'inserting sourcedata to the temp table started';	
INSERT INTO tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_email_TEMP 
	SELECT	    ENTITY_ID, 
				PARTY_ID, 
				EMAIL_TYPE, 
				EMAIL_ADDRESS, 
				EMAIL_VALID_FLG, 
				EMAIL_CERTAINTY_FLG, 
				EMAIL_EXTRA_INFO_FLG, 
				ENTITY_CREATE_TIME, 
				ENTITY_LAST_UPDATE_TIME
          FROM  (SELECT 
					ENTITY_ID, 
					PARTY_ID, 
					EMAIL_TYPE, 
					EMAIL_ADDRESS, 
					EMAIL_VALID_FLG, 
					EMAIL_CERTAINTY_FLG, 
					EMAIL_EXTRA_INFO_FLG, 
					ENTITY_CREATE_TIME, 
					ENTITY_LAST_UPDATE_TIME,
             ROW_NUMBER() OVER (PARTITION BY ENTITY_ID, PARTY_ID, EMAIL_TYPE ORDER BY ENTITY_LAST_UPDATE_TIME DESC, ENTITY_CREATE_TIME DESC) AS RNUM 
			 FROM lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_email_Incr) src
			 WHERE RNUM=1

	PRINT 'inserting sourcedata to the temp table completed';

UPDATE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_email	
SET 
			  ENTITY_ID = srcEmail.ENTITY_ID, 
			  PARTY_ID = srcEmail.PARTY_ID, 
			  EMAIL_TYPE = srcEmail.EMAIL_TYPE, 
			  EMAIL_ADDRESS = srcEmail.EMAIL_ADDRESS, 
			  EMAIL_VALID_FLG = srcEmail.EMAIL_VALID_FLG, 
			  EMAIL_CERTAINTY_FLG = srcEmail.EMAIL_CERTAINTY_FLG, 
			  EMAIL_EXTRA_INFO_FLG = srcEmail.EMAIL_EXTRA_INFO_FLG, 
              ENTITY_CREATE_TIME = srcEmail.ENTITY_CREATE_TIME, 
			  ENTITY_LAST_UPDATE_TIME = srcEmail.ENTITY_LAST_UPDATE_TIME, 
			  UPDATE_DATE = @CurrDate
FROM	 psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_email tgtEmail 
				INNER JOIN #BUKIT_BTCSVOC_BUK_SVOC_Customer_email_TEMP srcEmail
			 
ON (tgtEmail.ENTITY_ID = srcEmail.ENTITY_ID
	AND tgtEmail.PARTY_ID = srcEmail.PARTY_ID
	AND tgtEmail.EMAIL_TYPE = srcEmail.EMAIL_TYPE)
	WHERE srcEmail.ENTITY_LAST_UPDATE_TIME > tgtEmail.ENTITY_LAST_UPDATE_TIME 

INSERT INTO psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_email
SELECT  srcEmail.ENTITY_ID,
		srcEmail.PARTY_ID,
		srcEmail.EMAIL_TYPE,
		srcEmail.EMAIL_ADDRESS,
		srcEmail.EMAIL_VALID_FLG,
		srcEmail.EMAIL_CERTAINTY_FLG,
		srcEmail.EMAIL_EXTRA_INFO_FLG,
		srcEmail.ENTITY_CREATE_TIME,
		srcEmail.ENTITY_LAST_UPDATE_TIME,
		@CurrDate,	
		@CurrDate
		FROM  #BUKIT_BTCSVOC_BUK_SVOC_Customer_email_TEMP srcEmail 
						LEFT JOIN psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_email tgtEmail
						ON (tgtEmail.ENTITY_ID = srcEmail.ENTITY_ID
						AND tgtEmail.PARTY_ID = srcEmail.PARTY_ID
						AND tgtEmail.EMAIL_TYPE = srcEmail.EMAIL_TYPE)
						WHERE tgtEmail.ENTITY_ID IS NULL;
END TRY

BEGIN CATCH

IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION;
	
DECLARE @UserName VARCHAR(100),
		@ErrorNumber INT,
		@ErrorState INT,
		@ErrorSeverity INT,
		@ErrorProcedure VARCHAR(MAX),
		@ErrorMessage VARCHAR(MAX),
		@ErrorDateTime  DATETIME;

SELECT	@UserName=SUSER_SNAME(),
		@ErrorNumber=ERROR_NUMBER(),
		@ErrorState=ERROR_STATE(),
		@ErrorSeverity=ERROR_SEVERITY(),
		@ErrorProcedure='sp_merge_bukit_btcsvoc_buk_svoc_customer_email',--ERROR_PROCEDURE(),
		@ErrorMessage=ERROR_MESSAGE(),
		@ErrorDateTime=GETDATE();

INSERT INTO [psa].[UK_SVOCC_DB_Errors_Log]
    VALUES	(@UserName, @ErrorNumber, @ErrorState, @ErrorSeverity, @ErrorProcedure, @ErrorMessage, @ErrorDateTime);

THROW;
	
END CATCH

IF @@TRANCOUNT>0
COMMIT TRANSACTION;

IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_email_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_email_TEMP
END

END
GO
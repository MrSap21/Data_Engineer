--TODO : PSA and LOAD Tablename change and sp rename not tested
--     : row_id need to be included
--     : ErrorLog tableName to be corrected (DNA)
/****** Object:  StoredProcedure [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_delete]    Script Date: 4/22/2021 6:19:58 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'[psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_delete]', N'P') IS NOT NULL
    DROP PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_delete]
GO
CREATE PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_delete] AS


-------------------------------------------------------------------------------------------------------------
--Procedure Name				: sp_merge_bukit_btcsvoc_buk_svoc_customer_delete
--Purpose						: To UPSERT data from lod to psa svoc central consents tables in azure ( To perform the deletion of Customer entities 
--									from the target tables based on the delete flag in the incoming file)
--Domain						: SVoC
--psa Layer Target Tables		: psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete
--Logic						: This procedure will UPSERT the data from lod to psa bukit_btcsvoc_buk_svoc_customer_delete table in azure. 
--							  For updated records only Update_date column will be set to current timestamp. 
--							  For inserted records both update_date and insert_date columns will be set to current timestamp. 
--							  This procedure will Delete records from all target tables whose Delete_flag=1  and process flag ='N',not processed in azure
--Last Modified				: 01 March 2021
--Last Modified by			: Deepa Madhavu
--Modification				: Modified to have lod to psa tranformations
-------------------------------------------------------------------------------------------------------------


--#LANGUAGE TSQL
BEGIN

--#DECLARE v_currdate timestamp;
--#SELECT CURRENT TIMESTAMP INTO v_currdate FROM SYSIBM.SYSDUMMY1;

--DECLARE v_currdate DATETIME;
--SET @v_currdate=CURRENT_TIMESTAMP;
SET NOCOUNT ON;
DECLARE @CurrDate nvarchar(20);	--updated
SET @CurrDate= Convert(nvarchar(20),CONVERT(DATETIMEOFFSET(0),CURRENT_TIMESTAMP),127);--updated

BEGIN TRANSACTION;
BEGIN TRY


UPDATE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete SET
PROCESS_FLG = 'N',
UPDATE_DATE = @CurrDate 
FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete  tgtDel
JOIN lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete_Incr srcDel
ON
srcDel.ENTITY_ID = tgtDel.ENTITY_ID
AND srcDel.DELETE_FLG = tgtDel.DELETE_FLG 
;

INSERT INTO psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete 
	SELECT DISTINCT 
		srcDel.ENTITY_ID ENTITY_ID,
		srcDel.DELETE_FLG DELETE_FLG,
		'N'  AS PROCESS_FLG,
		null AS PROCESS_DATE,
		@CurrDate AS INSERT_DATE,
		@CurrDate AS UPSERT_DATE	
		FROM lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete_Incr srcDel
		WHERE NOT EXISTS (SELECT 1 FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete tgtDel
							WHERE srcDel.ENTITY_ID = tgtDel.ENTITY_ID
							AND srcDel.DELETE_FLG = tgtDel.DELETE_FLG);


--Delete records from all target tables whose Delete_flag=1  and process flag ='N',not processed
DELETE FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_data  WHERE ENTITY_ID IN 
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N');
DELETE FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link WHERE ENTITY_ID IN 
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete  WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N');
DELETE FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_address  WHERE ENTITY_ID IN 
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete  WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N');
DELETE FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_phone  WHERE ENTITY_ID IN 
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N');
DELETE FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_email  WHERE ENTITY_ID IN 
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N');
DELETE FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media  WHERE ENTITY_ID IN 
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N');
DELETE FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier  WHERE ENTITY_ID IN 
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete  WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N');
DELETE FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent   WHERE ENTITY_ID IN
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete  WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N');
DELETE FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link  WHERE ENTITY_ID IN 
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete  WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N');

UPDATE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete
SET  PROCESS_FLG = 'Y',PROCESS_DATE=@CurrDate
FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete
WHERE ENTITY_ID IN (
(SELECT ENTITY_ID FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_delete  WHERE DELETE_FLG = 1 AND PROCESS_FLG = 'N'))

END TRY

BEGIN CATCH

	IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION;
	
DECLARE @UserName VARCHAR(100),
		@ErrorNumber INT,
		@ErrorState INT,
		@ErrorSeverity INT,
		@ErrorProcedure VARCHAR(MAX),
		@ErrorMessage VARCHAR(MAX),
		@ErrorDateTime  DATETIME;

SELECT	@UserName=SUSER_SNAME(),
		@ErrorNumber=ERROR_NUMBER(),
		@ErrorState=ERROR_STATE(),
		@ErrorSeverity=ERROR_SEVERITY(),
		@ErrorProcedure='sp_merge_bukit_btcsvoc_buk_svoc_customer_delete',
		@ErrorMessage=ERROR_MESSAGE(),
		@ErrorDateTime=GETDATE();

INSERT INTO [psa].[UK_SVOCC_DB_Errors_Log]
    VALUES	(@UserName, @ErrorNumber, @ErrorState, @ErrorSeverity, @ErrorProcedure, @ErrorMessage, @ErrorDateTime);

THROW;
	
END CATCH

IF @@TRANCOUNT>0
COMMIT TRANSACTION;
	 END
GO
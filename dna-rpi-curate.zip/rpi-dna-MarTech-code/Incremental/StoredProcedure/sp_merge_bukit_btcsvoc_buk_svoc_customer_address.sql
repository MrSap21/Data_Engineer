--TODO : PSA and LOAD Tablename change and sp rename change are not tested
--     : row_id need to be included
--     : ErroLog tableName to be corrected (DNA)
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'[psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_address]', N'P') IS NOT NULL
    DROP PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_address]
GO

CREATE PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_address] AS	

-------------------------------------------------------------------------------------------------------------
--Procedure Name				: sp_merge_bukit_btcsvoc_buk_svoc_customer_address
--Purpose						: To UPSERT data from lod to psa svoc central consents tables in azure
--Domain						: SVoC
--psa Layer Target Tables		: psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_address to psa bukit_btcsvoc_buk_svoc_customer_address table. 
--								 For updated records only Update_date column will be set to current timestamp. 
--								 For inserted records both update_date and insert_date columns will be set to current timestamp.
--Last Modified					: 01 March 2021
--Last Modified by				: Krishna Divya
--Modification					: Modified to have lod to psa tranformations
-------------------------------------------------------------------------------------------------------------


BEGIN



DECLARE @CurrDate nvarchar(20);	
SET @CurrDate= Convert(nvarchar(20),CONVERT(DATETIMEOFFSET(0),CURRENT_TIMESTAMP),127);

IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_address_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_address_TEMP
END	
CREATE TABLE tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_address_TEMP
(
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[ADDRESS_TYPE] [nvarchar](20) NULL,
	[HOUSE_NUMBER] [nvarchar](500) NULL,
	[HOUSE_UNIT] [nvarchar](500) NULL,
	[BUILDING_NAME] [nvarchar](500) NULL,
	[STREET] [nvarchar](500) NULL,
	[LOCALITY] [nvarchar](500) NULL,
	[TOWN] [nvarchar](500) NULL,
	[COUNTY] [nvarchar](500) NULL,
	[POST_CODE] [nvarchar](500) NULL,
	[COUNTRY_CODE] [nvarchar](500) NULL,
	[NO_FIXED_ABODE_FLG] [nvarchar](10) NULL,
	[ADDRESS_VALID_FLG] [nvarchar](10) NULL,
	[GONE_AWAY_FLG] [nvarchar](10) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL
	
)

BEGIN TRANSACTION;
BEGIN TRY
--create temp table with source data avoiding duplicates
PRINT 'inserting sourcedata to the temp table started';	
INSERT INTO tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_address_TEMP 
		SELECT	    ENTITY_ID, 
					PARTY_ID, 
					ADDRESS_TYPE, 
					HOUSE_NUMBER, 
					HOUSE_UNIT, 
					BUILDING_NAME, 
					STREET, 
					LOCALITY, 
					TOWN, 
					COUNTY, 
					POST_CODE, 
					COUNTRY_CODE,
	                NO_FIXED_ABODE_FLG, 
					ADDRESS_VALID_FLG, 
				    GONE_AWAY_FLG, 
					ENTITY_CREATE_TIME, 
					ENTITY_LAST_UPDATE_TIME
          FROM  (SELECT     ENTITY_ID, 
							PARTY_ID, 
							ADDRESS_TYPE, 
							HOUSE_NUMBER, 
							HOUSE_UNIT, 
							BUILDING_NAME, 
							STREET, 
							LOCALITY, 
							TOWN, 
							COUNTY, 
							POST_CODE, 
							COUNTRY_CODE,
							NO_FIXED_ABODE_FLG, 
							ADDRESS_VALID_FLG, 
							GONE_AWAY_FLG, 
							ENTITY_CREATE_TIME, 
							ENTITY_LAST_UPDATE_TIME,
             ROW_NUMBER() OVER (PARTITION BY ENTITY_ID, PARTY_ID, ADDRESS_TYPE ORDER BY ENTITY_LAST_UPDATE_TIME DESC, ENTITY_CREATE_TIME DESC) AS RNUM 
			 FROM lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_address_Incr) srcAddress
			 WHERE RNUM=1

	PRINT 'inserting sourcedata to the temp table completed';

UPDATE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_address	
SET
			  ENTITY_ID = srcAddress.ENTITY_ID, 
			  PARTY_ID = srcAddress.PARTY_ID, 
			  ADDRESS_TYPE = srcAddress.ADDRESS_TYPE, 
			  HOUSE_NUMBER = srcAddress.HOUSE_NUMBER, 
			  HOUSE_UNIT = srcAddress.HOUSE_UNIT, 
			  BUILDING_NAME = srcAddress.BUILDING_NAME, 
			  STREET = srcAddress.STREET, 
			  LOCALITY = srcAddress.LOCALITY, 
			  TOWN = srcAddress.TOWN, 
			  COUNTY = srcAddress.COUNTY, 
			  POST_CODE = srcAddress.POST_CODE, 
			  COUNTRY_CODE = srcAddress.COUNTRY_CODE,
  	          NO_FIXED_ABODE_FLG = srcAddress.NO_FIXED_ABODE_FLG, 
			  ADDRESS_VALID_FLG = srcAddress.ADDRESS_VALID_FLG, 
			  GONE_AWAY_FLG = srcAddress.GONE_AWAY_FLG, 
			  ENTITY_CREATE_TIME = srcAddress.ENTITY_CREATE_TIME, 
			  ENTITY_LAST_UPDATE_TIME = srcAddress.ENTITY_LAST_UPDATE_TIME, 
			  UPDATE_DATE = @CurrDate
FROM	 psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_address tgtAddress 
				INNER JOIN #BUKIT_BTCSVOC_BUK_SVOC_Customer_address_TEMP srcAddress
			 
ON (tgtAddress.ENTITY_ID = srcAddress.ENTITY_ID
	AND tgtAddress.PARTY_ID = srcAddress.PARTY_ID
	AND tgtAddress.ADDRESS_TYPE = srcAddress.ADDRESS_TYPE)
	WHERE srcAddress.ENTITY_LAST_UPDATE_TIME > tgtAddress.ENTITY_LAST_UPDATE_TIME


INSERT INTO psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_address
				SELECT  srcAddress.ENTITY_ID,
						srcAddress.PARTY_ID,
						srcAddress.ADDRESS_TYPE,
						srcAddress.HOUSE_NUMBER,
						srcAddress.HOUSE_UNIT,
						srcAddress.BUILDING_NAME,
						srcAddress.STREET,
						srcAddress.LOCALITY,
						srcAddress.TOWN,
						srcAddress.COUNTY,
						srcAddress.POST_CODE,
						srcAddress.COUNTRY_CODE,
						srcAddress.NO_FIXED_ABODE_FLG,
						srcAddress.ADDRESS_VALID_FLG,
						srcAddress.GONE_AWAY_FLG,
						srcAddress.ENTITY_CREATE_TIME,
						srcAddress.ENTITY_LAST_UPDATE_TIME,
						@CurrDate,	
						@CurrDate
						FROM  #BUKIT_BTCSVOC_BUK_SVOC_Customer_address_TEMP srcAddress 
						LEFT JOIN psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_address tgtAddress
						ON (tgtAddress.ENTITY_ID = srcAddress.ENTITY_ID
						AND tgtAddress.PARTY_ID = srcAddress.PARTY_ID
						AND tgtAddress.ADDRESS_TYPE = srcAddress.ADDRESS_TYPE)
						WHERE tgtAddress.ENTITY_ID IS NULL;
END TRY

BEGIN CATCH

IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION;
	
DECLARE @UserName VARCHAR(100),
		@ErrorNumber INT,
		@ErrorState INT,
		@ErrorSeverity INT,
		@ErrorProcedure VARCHAR(MAX),
		@ErrorMessage VARCHAR(MAX),
		@ErrorDateTime  DATETIME;

SELECT	@UserName=SUSER_SNAME(),
		@ErrorNumber=ERROR_NUMBER(),
		@ErrorState=ERROR_STATE(),
		@ErrorSeverity=ERROR_SEVERITY(),
		@ErrorProcedure='sp_merge_bukit_btcsvoc_buk_svoc_customer_address',--ERROR_PROCEDURE(),
		@ErrorMessage=ERROR_MESSAGE(),
		@ErrorDateTime=GETDATE();

INSERT INTO [psa].[UK_SVOCC_DB_Errors_Log]
    VALUES	(@UserName, @ErrorNumber, @ErrorState, @ErrorSeverity, @ErrorProcedure, @ErrorMessage, @ErrorDateTime);

THROW;
	
END CATCH

IF @@TRANCOUNT>0
COMMIT TRANSACTION;
IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_address_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_address_TEMP
END


END
GO
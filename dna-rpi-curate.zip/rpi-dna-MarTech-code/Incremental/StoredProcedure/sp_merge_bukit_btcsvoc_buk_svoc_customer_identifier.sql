--TODO : PSA and LOAD Tablename change and sp rename change are not tested
--     : row_id need to be included
--     : ErrorLog tableName to be corrected (DNA)
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_identifier]', N'P') IS NOT NULL
    DROP PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_identifier]
GO
CREATE PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_identifier] AS
-------------------------------------------------------------------------------------------------------------
--Procedure Name				: sp_merge_bukit_btcsvoc_buk_svoc_customer_identifier
--Purpose						: To UPSERT data from lod to psa svoc central consents tables in azure
--Domain						: SVoC
--psa Layer Target Tables		: psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier
--	
--Logic							: This procedure will UPSERT the data from lod to psa bukit_btcsvoc_buk_svoc_customer_identifier table. 
--								 For updated records only Update_date column will be set to current timestamp. 
--								 For inserted records both update_date and insert_date columns will be set to current timestamp.
--Last Modified					: 01 March 2021
--Last Modified by				: Abhilaksh Agnihotri
--Modification					: Modified to have lod to psa tranformations
-------------------------------------------------------------------------------------------------------------

BEGIN


DECLARE @CurrDate nvarchar(20);
SET @CurrDate= Convert(nvarchar(20),CONVERT(DATETIMEOFFSET(0),CURRENT_TIMESTAMP),127);

IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier_TEMP
END

CREATE TABLE tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier_TEMP
(
[ENTITY_ID]               [nvarchar](10) NULL,
[PARTY_ID]               [nvarchar](10) NULL,
[STAFF_DISCOUNT_CARD]     [nvarchar](20) NULL,
[NHS_NUMBER]              [nvarchar](20) NULL,
[CHI_NUMBER]             [nvarchar](20) NULL,
[HSCN_NUMBER]             [nvarchar](20) NULL,
[ADCARD_NUMBER]           [nvarchar](20) NULL,
[ENTITY_CREATE_TIME]      [nvarchar](20) NULL,
[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL

)


BEGIN TRANSACTION;
BEGIN TRY
--create temp table with source data avoiding duplicates
PRINT 'inserting sourcedata to the temp table started';
INSERT INTO tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier_TEMP 
SELECT					ENTITY_ID, 
						PARTY_ID, 
						STAFF_DISCOUNT_CARD, 
						NHS_NUMBER, 
						CHI_NUMBER, 
						HSCN_NUMBER, 
						ADCARD_NUMBER, 
						ENTITY_CREATE_TIME, 
						ENTITY_LAST_UPDATE_TIME
			FROM(SELECT 
						ENTITY_ID, 
						PARTY_ID, 
						STAFF_DISCOUNT_CARD, 
						NHS_NUMBER, 
						CHI_NUMBER, 
						HSCN_NUMBER, 
						ADCARD_NUMBER, 
						ENTITY_CREATE_TIME, 
						ENTITY_LAST_UPDATE_TIME,
			 ROW_NUMBER() OVER (PARTITION BY ENTITY_ID, PARTY_ID ORDER BY ENTITY_LAST_UPDATE_TIME DESC, ENTITY_CREATE_TIME DESC) AS RNUM 
			 FROM lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier_Incr) src
			 WHERE RNUM=1
			 
	PRINT 'inserting sourcedata to the temp table completed';

UPDATE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier	
SET 
			ENTITY_ID = srcIdentifier.ENTITY_ID,
			PARTY_ID = srcIdentifier.PARTY_ID, 
			STAFF_DISCOUNT_CARD = srcIdentifier.STAFF_DISCOUNT_CARD, 
			NHS_NUMBER = srcIdentifier.NHS_NUMBER, 
			CHI_NUMBER = srcIdentifier.CHI_NUMBER, 
			HSCN_NUMBER = srcIdentifier.HSCN_NUMBER, 
			ADCARD_NUMBER = srcIdentifier.ADCARD_NUMBER, 
			ENTITY_CREATE_TIME = srcIdentifier.ENTITY_CREATE_TIME, 
			ENTITY_LAST_UPDATE_TIME = srcIdentifier.ENTITY_LAST_UPDATE_TIME, 
			UPDATE_DATE = @CurrDate
FROM	 psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier tgtIdentifier 
				INNER JOIN #BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier_TEMP srcIdentifier
			 
ON (tgtIdentifier.ENTITY_ID = srcIdentifier.ENTITY_ID
	AND tgtIdentifier.PARTY_ID = srcIdentifier.PARTY_ID)
	WHERE srcIdentifier.ENTITY_LAST_UPDATE_TIME > tgtIdentifier.ENTITY_LAST_UPDATE_TIME 



INSERT INTO psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier
				SELECT	srcIdentifier.ENTITY_ID,
						srcIdentifier.PARTY_ID,
						srcIdentifier.STAFF_DISCOUNT_CARD,
						srcIdentifier.NHS_NUMBER,
						srcIdentifier.CHI_NUMBER,
						srcIdentifier.HSCN_NUMBER,
						srcIdentifier.ADCARD_NUMBER,
						srcIdentifier.ENTITY_CREATE_TIME,
						srcIdentifier.ENTITY_LAST_UPDATE_TIME,
						@CurrDate,	
						@CurrDate	
						FROM #BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier_TEMP srcIdentifier
						LEFT JOIN psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier tgtIdentifier
						ON (tgtIdentifier.ENTITY_ID = srcIdentifier.ENTITY_ID
						AND tgtIdentifier.PARTY_ID = srcIdentifier.PARTY_ID)
						WHERE tgtIdentifier.ENTITY_ID IS NULL;
END TRY

BEGIN CATCH

IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION;
DECLARE @UserName VARCHAR(100),
		@ErrorNumber INT,
		@ErrorState INT,
		@ErrorSeverity INT,
		@ErrorProcedure VARCHAR(MAX),
		@ErrorMessage VARCHAR(MAX),
		@ErrorDateTime  DATETIME;

SELECT	@UserName=SUSER_SNAME(),
		@ErrorNumber=ERROR_NUMBER(),
		@ErrorState=ERROR_STATE(),
		@ErrorSeverity=ERROR_SEVERITY(),
		@ErrorProcedure='sp_merge_bukit_btcsvoc_buk_svoc_customer_identifier',
		@ErrorMessage=ERROR_MESSAGE(),
		@ErrorDateTime=GETDATE();

INSERT INTO [psa].[UK_SVOCC_DB_Errors_Log]
    VALUES	(@UserName, @ErrorNumber, @ErrorState, @ErrorSeverity, @ErrorProcedure, @ErrorMessage, @ErrorDateTime);

THROW;
	
END CATCH

IF @@TRANCOUNT>0
COMMIT TRANSACTION;

IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier_TEMP
END	

END
GO
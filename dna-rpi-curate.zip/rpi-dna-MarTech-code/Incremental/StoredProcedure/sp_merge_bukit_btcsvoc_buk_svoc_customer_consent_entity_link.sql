--TODO : PSA and LOAD Tablename change and sp rename change are not tested
--     : row_id need to be included
--     : ErrorLog tableName to be corrected (DNA)
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID(N'[psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_consent_entity_link]', N'P') IS NOT NULL
    DROP PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_consent_entity_link]
GO

CREATE PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_consent_entity_link]


-------------------------------------------------------------------------------------------------------------
--Procedure Name				: sp_merge_bukit_btcsvoc_buk_svoc_customer_consent_entity_link
--Purpose						: To UPSERT data from lod to psa svoc central consents tables in azure
--Domain						: SVoC
--psa Layer Target Tables		: psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link
--Logic						: This procedure will UPSERT the data from lod to psa bukit_btcsvoc_buk_svoc_customer_consent_entity_link table in azure. 
--							  The duplicate records selected from lod table are grouped on the key columns [as in the target table] 
--								and then sorted by datetime fields and topmost record is selected for merge to target. 
--							  For updated records only Update_date column will be set to current timestamp. 
--							  For inserted records both update_date and insert_date columns will be set to current timestamp. 
-------------------------------------------------------------------------------------------------------------
--***********************************************************************************************************************
--***********************************************************************************************************************
--Modification History
--***********************************************************************************************************************
-- Modified by		Date				:        Description
--=======================================================================================================================
--Suruchi Bhanot	31 March 2021  :    Initial Version to have lod to psa tranformations for SVOCC 
--Suruchi Bhanot	12 April 2021  :	Naming convention for sp name
--***********************************************************************************************************************/

AS

--LANGUAGE TSQL
BEGIN


DECLARE @CurrDate nvarchar(20);	
SET @CurrDate= Convert(nvarchar(20),CONVERT(DATETIMEOFFSET(0),CURRENT_TIMESTAMP),127);


BEGIN TRANSACTION;
BEGIN TRY
--Added : Transfer entity ETL insert timestamp info from DW table into Staging 
--before deleting old relationship from DW so that the same ETL insert timestamp info can
--be put back in DW while loading to keep track of when this entity first came into database

UPDATE lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link_Incr
SET INSERT_DATE = TGT_CUST_CONST_ENTITY_LNK.INSERT_DATE
FROM lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link_Incr SRC_CUST_CONST_ENTITY_LNK
INNER JOIN psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link TGT_CUST_CONST_ENTITY_LNK
ON SRC_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_GUID=TGT_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_GUID
and SRC_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_CODE=TGT_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_CODE
WHERE SRC_CUST_CONST_ENTITY_LNK.ENTITY_LAST_UPDATE_TIME >= TGT_CUST_CONST_ENTITY_LNK.ENTITY_LAST_UPDATE_TIME;

--ADDED: Changed the delete clause to cater for duplicates
--in the composite key combination in the sub select query.

--Added :  The entity-member in the daily file is completely refreshed 
--by delete and reload current relation ship state such that it woks also for the 
--member delete scenario
DELETE TGT_CUST_CONST_ENTITY_LNK 
FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link TGT_CUST_CONST_ENTITY_LNK
INNER JOIN lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link_Incr SRC_CUST_CONST_ENTITY_LNK
ON SRC_CUST_CONST_ENTITY_LNK.ENTITY_ID=TGT_CUST_CONST_ENTITY_LNK.ENTITY_ID
AND SRC_CUST_CONST_ENTITY_LNK.PARTY_ID=TGT_CUST_CONST_ENTITY_LNK.PARTY_ID; 




--Replaced old Merge Script : 

INSERT INTO psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link                                                                     
SELECT 
SRC_CUST_CONST_ENTITY_LNK.ENTITY_ID,
SRC_CUST_CONST_ENTITY_LNK.PARTY_ID,
SRC_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_CODE,
SRC_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_GUID,
SRC_CUST_CONST_ENTITY_LNK.ENTITY_CREATE_TIME,
SRC_CUST_CONST_ENTITY_LNK.ENTITY_LAST_UPDATE_TIME,
COALESCE (SRC_CUST_CONST_ENTITY_LNK.INSERT_DATE,@CurrDate),
@CurrDate
FROM (SELECT	ENTITY_ID, 
				PARTY_ID,
				CONSENT_SOURCE_CODE, 
				CONSENT_SOURCE_GUID,
				ENTITY_CREATE_TIME, 
				ENTITY_LAST_UPDATE_TIME, 
				INSERT_DATE,
				ROW_NUMBER() OVER (PARTITION BY CONSENT_SOURCE_CODE ,CONSENT_SOURCE_GUID ORDER BY ENTITY_LAST_UPDATE_TIME DESC) AS RNUM 
		FROM lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link_Incr) SRC_CUST_CONST_ENTITY_LNK
LEFT JOIN 	psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link TGT_CUST_CONST_ENTITY_LNK 
ON (TGT_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_CODE = SRC_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_CODE
AND TGT_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_GUID= SRC_CUST_CONST_ENTITY_LNK.CONSENT_SOURCE_GUID)
WHERE	SRC_CUST_CONST_ENTITY_LNK.RNUM = 1
AND		TGT_CUST_CONST_ENTITY_LNK.ENTITY_ID IS NULL;


END TRY

BEGIN CATCH

IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION;

DECLARE @UserName VARCHAR(100),
		@ErrorNumber INT,
		@ErrorState INT,
		@ErrorSeverity INT,
		@ErrorProcedure VARCHAR(MAX),
		@ErrorMessage VARCHAR(MAX),
		@ErrorDateTime  DATETIME;

SELECT	@UserName=SUSER_SNAME(),
		@ErrorNumber=ERROR_NUMBER(),
		@ErrorState=ERROR_STATE(),
		@ErrorSeverity=ERROR_SEVERITY(),
		@ErrorProcedure= 'sp_merge_bukit_btcsvoc_buk_svoc_customer_consent_entity_link',--ERROR_PROCEDURE(),
		@ErrorMessage=ERROR_MESSAGE(),
		@ErrorDateTime=GETDATE();

INSERT INTO [psa].[UK_SVOCC_DB_Errors_Log]
    VALUES	(@UserName, @ErrorNumber, @ErrorState, @ErrorSeverity, @ErrorProcedure, @ErrorMessage, @ErrorDateTime);

THROW;

END CATCH

IF @@TRANCOUNT>0
COMMIT TRANSACTION;

END
GO
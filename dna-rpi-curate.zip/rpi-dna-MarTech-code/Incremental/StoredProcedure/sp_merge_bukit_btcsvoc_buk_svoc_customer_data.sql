--TODO : PSA and LOAD Tablename change and sp rename change are not tested
--     : row_id need to be included
--     : ErrorLog tableName to be corrected (DNA)
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'[psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_data]', N'P') IS NOT NULL
    DROP PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_data]
GO

CREATE PROC [psa].[sp_merge_bukit_btcsvoc_buk_svoc_customer_data]

-------------------------------------------------------------------------------------------------------------
--Procedure Name				: sp_merge_bukit_btcsvoc_buk_svoc_customer_data
--Purpose						: To UPSERT data from lod to psa svoc central consents tables in azure
--Domain						: SVoC
--psa Layer Target Tables		: psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_data
--	
--Logic							: This procedure will UPSERT the data from lod to psa bukit_btcsvoc_buk_svoc_customer_data table. 
--								 For updated records only Update_date column will be set to current timestamp. 
--								 For inserted records both update_date and insert_date columns will be set to current timestamp.
-------------------------------------------------------------------------------------------------------------
--***********************************************************************************************************************
--***********************************************************************************************************************
--Modification History
--***********************************************************************************************************************
-- Modified by		Date				:        Description
--=======================================================================================================================
--Suruchi Bhanot	26 March 2021  :    Initial Version to have lod to psa tranformations for SVOCC 
--Suruchi Bhanot	30 March 2021  :    Incorporating review comments-Drop and create, naming conversion,
--										Remove blank space at the end and Error handling mechanism
--Suruchi Bhanot	12 April 2021  :	Adding Temp Table and Naming convention for sp name
--***********************************************************************************************************************/

AS	

--#LANGUAGE TSQL
BEGIN

DECLARE @CurrDate nvarchar(20);	
SET @CurrDate= Convert(nvarchar(20),CONVERT(DATETIMEOFFSET(0),CURRENT_TIMESTAMP),127);


--create temp table with source data avoiding duplicates
IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_data_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_data_TEMP
END	

CREATE TABLE tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_data_TEMP
(
 [ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[TITLE] [nvarchar](500) NULL,
	[FIRST_NAME] [nvarchar](500) NULL,
	[MIDDLE_NAME] [nvarchar](500) NULL,
	[LAST_NAME] [nvarchar](500) NULL,
	[CHOSEN_FIRST_NAME] [nvarchar](500) NULL,
	[BIRTH_LAST_NAME] [nvarchar](500) NULL,
	[GENDER] [nvarchar](500) NULL,
	[DATE_OF_BIRTH] [nvarchar](500) NULL,
	[DATE_OF_DEATH] [nvarchar](500) NULL,
	[SOURCE_DECEASED_INFO] [nvarchar](500) NULL,
	[DEATH_NOTIFICATION_DATE] [nvarchar](500) NULL,
	[THIRD_PARTY_PROVIDED_FLG] [nvarchar](10) NULL,
	[NO_DATA_SHARE_FLG] [nvarchar](10) NULL,
	[NO_DUTY_OF_CARE_FLG] [nvarchar](10) NULL,
	[SPECIAL_FLG3] [nvarchar](10) NULL,
	[SPECIAL_FLG4] [nvarchar](10) NULL,
	[SPECIAL_FLG5] [nvarchar](10) NULL,
	[SPECIAL_FLG6] [nvarchar](10) NULL,
	[SPECIAL_FLG7] [nvarchar](10) NULL,
	[SPECIAL_FLG8] [nvarchar](10) NULL,
	[SPECIAL_FLG9] [nvarchar](10) NULL,
	[SPECIAL_FLG10] [nvarchar](10) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](20) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](20) NULL
)


BEGIN TRANSACTION;
BEGIN TRY

--create temp table with source data avoiding duplicates
PRINT 'inserting sourcedata to the temp table started';	
INSERT INTO tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_data_TEMP 
SELECT			ENTITY_ID, 
				PARTY_ID, 
				TITLE, 
				FIRST_NAME, 
				MIDDLE_NAME, 
				LAST_NAME, 
				CHOSEN_FIRST_NAME, 
				BIRTH_LAST_NAME, 
				GENDER, 
				DATE_OF_BIRTH, 
				DATE_OF_DEATH,
				SOURCE_DECEASED_INFO, 
				DEATH_NOTIFICATION_DATE, 
				THIRD_PARTY_PROVIDED_FLG, 
				NO_DATA_SHARE_FLG, 
				NO_DUTY_OF_CARE_FLG, 
				SPECIAL_FLG3, 
				SPECIAL_FLG4, 
				SPECIAL_FLG5, 
				SPECIAL_FLG6, 
				SPECIAL_FLG7, 
				SPECIAL_FLG8, 
				SPECIAL_FLG9, 
				SPECIAL_FLG10,  
				ENTITY_CREATE_TIME, 
				ENTITY_LAST_UPDATE_TIME
          FROM  (SELECT 
					    ENTITY_ID, 
						PARTY_ID, 
						TITLE, 
						FIRST_NAME, 
						MIDDLE_NAME, 
						LAST_NAME, 
						CHOSEN_FIRST_NAME, 
						BIRTH_LAST_NAME, 
						GENDER, 
						DATE_OF_BIRTH, 
						DATE_OF_DEATH,
						SOURCE_DECEASED_INFO, 
						DEATH_NOTIFICATION_DATE, 
						THIRD_PARTY_PROVIDED_FLG, 
						NO_DATA_SHARE_FLG, 
						NO_DUTY_OF_CARE_FLG, 
						SPECIAL_FLG3, 
						SPECIAL_FLG4, 
						SPECIAL_FLG5, 
						SPECIAL_FLG6, 
						SPECIAL_FLG7, 
						SPECIAL_FLG8, 
						SPECIAL_FLG9, 
						SPECIAL_FLG10,  
						ENTITY_CREATE_TIME, 
						ENTITY_LAST_UPDATE_TIME,
             ROW_NUMBER() OVER (PARTITION BY ENTITY_ID, PARTY_ID ORDER BY ENTITY_LAST_UPDATE_TIME DESC,ENTITY_CREATE_TIME DESC) AS RNUM  
			 FROM lod.BUKIT_BTCSVOC_BUK_SVOC_Customer_data_Incr) src
			 WHERE RNUM=1



UPDATE psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_data	
SET

		ENTITY_ID = SRC_CUST_MST.ENTITY_ID,
		PARTY_ID = SRC_CUST_MST.PARTY_ID,
		TITLE = SRC_CUST_MST.TITLE,
		FIRST_NAME = SRC_CUST_MST.FIRST_NAME,
		MIDDLE_NAME = SRC_CUST_MST.MIDDLE_NAME,
		LAST_NAME = SRC_CUST_MST.LAST_NAME,
		CHOSEN_FIRST_NAME = SRC_CUST_MST.CHOSEN_FIRST_NAME,
		BIRTH_LAST_NAME = SRC_CUST_MST.BIRTH_LAST_NAME,
		GENDER = SRC_CUST_MST.GENDER,
		DATE_OF_BIRTH = SRC_CUST_MST.DATE_OF_BIRTH,
		DATE_OF_DEATH = SRC_CUST_MST.DATE_OF_DEATH,
		SOURCE_DECEASED_INFO = SRC_CUST_MST.SOURCE_DECEASED_INFO,
		DEATH_NOTIFICATION_DATE = SRC_CUST_MST.DEATH_NOTIFICATION_DATE,
		THIRD_PARTY_PROVIDED_FLG = SRC_CUST_MST.THIRD_PARTY_PROVIDED_FLG,
		NO_DATA_SHARE_FLG = SRC_CUST_MST.NO_DATA_SHARE_FLG,
		NO_DUTY_OF_CARE_FLG = SRC_CUST_MST.NO_DUTY_OF_CARE_FLG,
		SPECIAL_FLG3 = SRC_CUST_MST.SPECIAL_FLG3,
		SPECIAL_FLG4 = SRC_CUST_MST.SPECIAL_FLG4,
		SPECIAL_FLG5 = SRC_CUST_MST.SPECIAL_FLG5,
		SPECIAL_FLG6 = SRC_CUST_MST.SPECIAL_FLG6,
		SPECIAL_FLG7 = SRC_CUST_MST.SPECIAL_FLG7,
		SPECIAL_FLG8 = SRC_CUST_MST.SPECIAL_FLG8,
		SPECIAL_FLG9 = SRC_CUST_MST.SPECIAL_FLG9,
		SPECIAL_FLG10 = SRC_CUST_MST.SPECIAL_FLG10,
		ENTITY_CREATE_TIME = SRC_CUST_MST.ENTITY_CREATE_TIME,
		ENTITY_LAST_UPDATE_TIME = SRC_CUST_MST.ENTITY_LAST_UPDATE_TIME,
		UPDATE_DATE = @CurrDate
FROM	 psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_data TGT_CUST_MST 
				INNER JOIN #BUKIT_BTCSVOC_BUK_SVOC_Customer_data_TEMP SRC_CUST_MST

ON (TGT_CUST_MST.ENTITY_ID = SRC_CUST_MST.ENTITY_ID
	AND TGT_CUST_MST.PARTY_ID = SRC_CUST_MST.PARTY_ID)
	WHERE SRC_CUST_MST.ENTITY_LAST_UPDATE_TIME > TGT_CUST_MST.ENTITY_LAST_UPDATE_TIME 
	


INSERT INTO psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_data
				SELECT  SRC_CUST_MST.ENTITY_ID, 
						SRC_CUST_MST.PARTY_ID, 
						SRC_CUST_MST.TITLE, 
						SRC_CUST_MST.FIRST_NAME, 
						SRC_CUST_MST.MIDDLE_NAME, 
						SRC_CUST_MST.LAST_NAME, 
						SRC_CUST_MST.CHOSEN_FIRST_NAME, 
						SRC_CUST_MST.BIRTH_LAST_NAME, 
						SRC_CUST_MST.GENDER, 
						SRC_CUST_MST.DATE_OF_BIRTH, 
						SRC_CUST_MST.DATE_OF_DEATH,
						SRC_CUST_MST.SOURCE_DECEASED_INFO, 
						SRC_CUST_MST.DEATH_NOTIFICATION_DATE, 
						SRC_CUST_MST.THIRD_PARTY_PROVIDED_FLG, 
						SRC_CUST_MST.NO_DATA_SHARE_FLG, 
						SRC_CUST_MST.NO_DUTY_OF_CARE_FLG, 
						SRC_CUST_MST.SPECIAL_FLG3, 
						SRC_CUST_MST.SPECIAL_FLG4, 
						SRC_CUST_MST.SPECIAL_FLG5, 
						SRC_CUST_MST.SPECIAL_FLG6, 
						SRC_CUST_MST.SPECIAL_FLG7, 
						SRC_CUST_MST.SPECIAL_FLG8, 
						SRC_CUST_MST.SPECIAL_FLG9, 
						SRC_CUST_MST.SPECIAL_FLG10,  
						SRC_CUST_MST.ENTITY_CREATE_TIME, 
						SRC_CUST_MST.ENTITY_LAST_UPDATE_TIME,
						@CurrDate,	
						@CurrDate	
						FROM #BUKIT_BTCSVOC_BUK_SVOC_Customer_data_TEMP SRC_CUST_MST 
						LEFT JOIN psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_data TGT_CUST_MST
						ON (TGT_CUST_MST.ENTITY_ID = SRC_CUST_MST.ENTITY_ID
						AND TGT_CUST_MST.PARTY_ID = SRC_CUST_MST.PARTY_ID)
						WHERE	TGT_CUST_MST.ENTITY_ID IS NULL;

END TRY

BEGIN CATCH

IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION;

DECLARE @UserName VARCHAR(100),
		@ErrorNumber INT,
		@ErrorState INT,
		@ErrorSeverity INT,
		@ErrorProcedure VARCHAR(MAX),
		@ErrorMessage VARCHAR(MAX),
		@ErrorDateTime  DATETIME;

SELECT	@UserName=SUSER_SNAME(),
		@ErrorNumber=ERROR_NUMBER(),
		@ErrorState=ERROR_STATE(),
		@ErrorSeverity=ERROR_SEVERITY(),
		@ErrorProcedure='sp_merge_bukit_btcsvoc_buk_svoc_customer_data',--ERROR_PROCEDURE(),
		@ErrorMessage=ERROR_MESSAGE(),
		@ErrorDateTime=GETDATE();

INSERT INTO [psa].[UK_SVOCC_DB_Errors_Log]
    VALUES	(@UserName, @ErrorNumber, @ErrorState, @ErrorSeverity, @ErrorProcedure, @ErrorMessage, @ErrorDateTime);

THROW;

END CATCH

IF @@TRANCOUNT>0
COMMIT TRANSACTION;

IF OBJECT_ID('tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_data_TEMP') IS NOT NULL
BEGIN
	DROP table tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_data_TEMP
END	

END
GO
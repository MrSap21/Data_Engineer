--This SP COvers only the Anonymisation process not SAP delete Customer PSA Load 
--TO DO: ErroLog tableName to be corrected (DNA)
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[psa].[sp_merge_sapcoe_sapcrm_buk_sapcrm_customer_anonymisation]', N'P') IS NOT NULL
    DROP PROC [psa].[sp_merge_sapcoe_sapcrm_buk_sapcrm_customer_anonymisation]
GO

CREATE PROCEDURE psa.sp_merge_sapcoe_sapcrm_buk_sapcrm_customer_anonymisation
-------------------------------------------------------------------------------------------------------------
--Procedure Name				: sp_merge_sapcoe_sapcrm_buk_sapcrm_customer_anonymisation
--Purpose						: To Anonymize data from lod to psa SAPCRM tables in azure
--Domain						: SAPCRM
--psa Layer Target Tables		: psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers
--	
--Logic							: This procedure will Anonymize the data from lod to psa SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers table. 

-------------------------------------------------------------------------------------------------------------
--***********************************************************************************************************************
--***********************************************************************************************************************
--Modification History
--***********************************************************************************************************************
-- Modified by				Date				:        Description
--=======================================================================================================================
--Gauri Nair, Ann Jose 		30 March 2021  		:    Initial Version to have lod to psa tranformations for SAPCRM 

--***********************************************************************************************************************/
AS

BEGIN

BEGIN TRANSACTION;
BEGIN TRY

		UPDATE psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers 
		SET
		
			--AW.CRM_CUSTOMER: Update All anonimisable fields in the AW.CRM_CUSTOMER table
										TITLE = '0',
                                        FORENAME = '0',
                                        SURNAME = '0',
                                        GENDER = CASE WHEN (UPPER(GENDER) NOT IN ('1','2','3') AND (GENDER IS NOT NULL)) THEN '' ELSE GENDER END,
                                        DATE_OF_BIRTH = CASE CAST(coalesce(DATE_OF_BIRTH, '0') AS INT) WHEN 0 THEN DATE_OF_BIRTH ELSE CONCAT(SUBSTRING(DATE_OF_BIRTH, 1, 4),'0101') END ,
                                        DO_NOT_MAIL = 'N',
				--Update All anonimisable fields in the AW.CRM_CUSTOMER_ADDRESS table
										UNIT_NAME = '0',
                                        BUILDING_NAME = '0',
                                        STREET = '0',
                                        POST_CODE = CASE WHEN ((COUNTRY_CODE = 'GB') AND (CHARINDEX(TRIM(POST_CODE), ' ') IN (3, 4, 5))) THEN SUBSTRING(TRIM(POST_CODE), 1, CHARINDEX(TRIM(POST_CODE), ' ') - 1) WHEN (LEN(TRIM(POST_CODE)) > 4) THEN SUBSTRING(TRIM(POST_CODE), 1, 4) ELSE TRIM(POST_CODE) END,
                                        HOUSE_NUMBER = '0',
                                        ADDRESS_TYPE = '0',
				--Update All anonimisable fields in the AW.CRM_ELECTRONIC_ADDRESS table (where E_COMMUNICATIONS_CODE IN (1,3,5))
										PHONE_NUMBER='', --1
										MOBILE_NUMBER='', --3
							 			EMAIL_ADDRESS='' --5
										
		WHERE CAST(BUSINESS_PARTNER_ID AS INT) IN 
		(SELECT CUSTOMER_NUMBER FROM lod.SAPCOE_SAPCRM_BUK_SAPCRM_Customer_Anonymisation)



END TRY

BEGIN CATCH

	IF @@TRANCOUNT>0
	ROLLBACK TRANSACTION;
	
DECLARE @UserName VARCHAR(100),
		@ErrorNumber INT,
		@ErrorState INT,
		@ErrorSeverity INT,
		@ErrorProcedure VARCHAR(MAX),
		@ErrorMessage VARCHAR(MAX),
		@ErrorDateTime  DATETIME;

SELECT	@UserName=SUSER_SNAME(),
		@ErrorNumber=ERROR_NUMBER(),
		@ErrorState=ERROR_STATE(),
		@ErrorSeverity=ERROR_SEVERITY(),
		@ErrorProcedure='sp_merge_sapcoe_sapcrm_buk_sapcrm_customer_anonymisation',
		@ErrorMessage=ERROR_MESSAGE(),
		@ErrorDateTime=GETDATE();

INSERT INTO [psa].[UK_SVOCC_DB_Errors_Log]
    VALUES	(@UserName, @ErrorNumber, @ErrorState, @ErrorSeverity, @ErrorProcedure, @ErrorMessage, @ErrorDateTime);

THROW;
	
END CATCH

IF @@TRANCOUNT>0
COMMIT TRANSACTION;
	 END
GO

PRINT 'Merge statement for [idfwba].[Feed]'


GO
BEGIN TRANSACTION

SET NOCOUNT ON

DECLARE @mergeOutput TABLE ( [DMLAction] VARCHAR(6) );
MERGE INTO [idfwba].[Feed] AS [Target]
USING (VALUES
(CURRENT_TIMESTAMP,'pf_product_lookup_pcc_dat','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "pf_product_lookup_pcc%.dat%%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "pf_product_lookup_pcc_dat"}','27003','1',403,142,'1','0','1800042546','6','0','pf_product_lookup_pcc%.dat%','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','retail/photo/pcplus/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]'),
(CURRENT_TIMESTAMP,'PHEXT010_dat','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "%PHEXT010%.dat%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "PHEXT010_dat"}','27003','1',403,142,'1','0','1800042546','6','0','%PHEXT010%.dat','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','retail/retail_codes/ecom/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' ),
(CURRENT_TIMESTAMP,'SSEXT009_dat','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "%SSEXT009%.dat%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "SSEXT009_dat"}','27003','1',403,142,'1','0','1800042546','6','0','%SSEXT009%.dat','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','digital/ecom/ecom/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' ),
(CURRENT_TIMESTAMP,'EPS_MBR_INFO_dat','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "EPS_MBR_INFO_%.dat%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "EPS_MBR_INFO_dat"}','27003','1',403,142,'1','0','1800042546','6','0','EPS_MBR_INFO_%.dat','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','marketing/loyalty/epsilon/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' ),
(CURRENT_TIMESTAMP,'RXEXT002_dat','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "%RXEXT002%.dat%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "RXEXT002_dat"}','27003','1',403,142,'1','0','1800042546','6','0','%RXEXT002%.dat','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','digital/ecom/ecom/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' ),
(CURRENT_TIMESTAMP,'PHOTO_COMBINED','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "PHOTO_COMBINED%.%%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "PHOTO_COMBINED"}','27003','1',403,142,'1','0','1800042546','6','0','PHOTO_COMBINED%.%','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','retail/retail_sales/photo/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' ),
(CURRENT_TIMESTAMP,'RXEXT014_dat','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "%RXEXT014%.dat%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "RXEXT014_dat"}','27003','1',403,142,'1','0','1800042546','6','0','%RXEXT014%.dat','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','digital/ecom/ecom/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' ),
(CURRENT_TIMESTAMP,'pf_commercial_account_rep','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "pf_commercial_account_rep%.dat%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "pf_commercial_account_rep"}','27003','1',403,142,'1','0','1800042546','6','0','pf_commercial_account_rep%.dat','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','retail/photo/pcplus/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' ),
(CURRENT_TIMESTAMP,'dim_product_dat  ','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "dim_product_[0-9]%.dat%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "dim_product_dat  "}','27003','1',403,142,'1','0','1800042546','6','0','dim_product_[0-9]%.dat','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','master_data/product/scm/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' ),
(CURRENT_TIMESTAMP,'INVENTORY_OUTPUT_TXT','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "INVENTORY_OUTPUT_TXT%%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "INVENTORY_OUTPUT_TXT"}','27003','1',403,142,'1','0','1800042546','6','0','INVENTORY_OUTPUT_TXT%','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','supply_chain/inventory_replenishment/scm/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' ),
(CURRENT_TIMESTAMP,'PO_FYTD_OUTPUT_TXT','Admin','{"properties": {"folder_pattern": "%rpu_incremental_landing%", "file_pattern": "PO_FYTD_OUTPUT_TXT%%"}, "type": "feed", "id": "https://walgreens-mvc.com/schemas/file_feed/schema", "title": "PO_FYTD_OUTPUT_TXT"}','27003','1',403,142,'1','0','1800042546','6','0','PO_FYTD_OUTPUT_TXT%','Ç','0','rpu_incremental_landing','1800042547','17000','1800042545','18000','8001','supply_chain/purchasing/scm/YYYY/MM/DD','0','0','[{"columnName":"","columnType":"","isKey":"","dataClasification":"","encryptionMask":"","encryptionIdentity":"","businessGlosarry":"","description":""}]' )


) AS [Source] ([DTCreated],[FeedName],[UserCreated],[assetJSON],[PlatformVersionID],[DQCheck],[SourceRangeID],[FeedFrequencyID],[HeaderInfo],[InformationClassificationID],[SourceSystemID],[AssetTypeID],[PromotedFromID],[FeedNamePattern],[Delimiter],[RestrictionsForUse],[SourcePathName],[SourceSubsystemID],[CountryID],[SupplierID],[LanguageID],[ProjectID],[DestinationPathName],[EntityDescription],[AuthorisationLink],[DataProperties])
ON ([Target].[feedName] = [Source].[feedName])
WHEN MATCHED AND (
              NULLIF([Source].[FeedName], [Target].[FeedName]) IS NOT NULL) THEN
UPDATE SET
  [Target].[DTCreated] = [Source].[DTCreated],
  [Target].[FeedName] = [Source].[FeedName],
  [Target].[UserCreated] = [Source].[UserCreated],
  [Target].[assetJSON] = [Source].[assetJSON],
  [Target].[PlatformVersionID] = [Source].[PlatformVersionID],
  [Target].[DQCheck] = [Source].[DQCheck],
  [Target].[SourceRangeID] = [Source].[SourceRangeID],
  [Target].[FeedFrequencyID] = [Source].[FeedFrequencyID],
  [Target].[HeaderInfo] = [Source].[HeaderInfo],
  [Target].[InformationClassificationID] = [Source].[InformationClassificationID],
  [Target].[SourceSystemID] = [Source].[SourceSystemID],
  [Target].[AssetTypeID] = [Source].[AssetTypeID],
  [Target].[PromotedFromID] = [Source].[PromotedFromID],
  [Target].[FeedNamePattern] = [Source].[FeedNamePattern],
  [Target].[Delimiter] = [Source].[Delimiter],
  [Target].[RestrictionsForUse] = [Source].[RestrictionsForUse],
  [Target].[SourcePathName] = [Source].[SourcePathName],
  [Target].[SourceSubsystemID] = [Source].[SourceSubsystemID],
  [Target].[CountryID] = [Source].[CountryID],
  [Target].[SupplierID] = [Source].[SupplierID],
  [Target].[LanguageID] = [Source].[LanguageID],
  [Target].[ProjectID] = [Source].[ProjectID],
  [Target].[DestinationPathName] = [Source].[DestinationPathName],
  [Target].[EntityDescription] = [Source].[EntityDescription],
  [Target].[AuthorisationLink] = [Source].[AuthorisationLink],
  [Target].[DataProperties] = [Source].[DataProperties]
WHEN NOT MATCHED BY TARGET THEN
INSERT([DTCreated],[FeedName],[UserCreated],[assetJSON],[PlatformVersionID],[DQCheck],[SourceRangeID],[FeedFrequencyID],[HeaderInfo],[InformationClassificationID],[SourceSystemID],[AssetTypeID],[PromotedFromID],[FeedNamePattern],[Delimiter],[RestrictionsForUse],[SourcePathName],[SourceSubsystemID],[CountryID],[SupplierID],[LanguageID],[ProjectID],[DestinationPathName],[EntityDescription],[AuthorisationLink],[DataProperties])
VALUES([Source].[DTCreated],[Source].[FeedName],[Source].[UserCreated],[Source].[assetJSON],[Source].[PlatformVersionID],[Source].[DQCheck],[Source].[SourceRangeID],[Source].[FeedFrequencyID],[Source].[HeaderInfo],[Source].[InformationClassificationID],[Source].[SourceSystemID],[Source].[AssetTypeID],[Source].[PromotedFromID],[Source].[FeedNamePattern],[Source].[Delimiter],[Source].[RestrictionsForUse],[Source].[SourcePathName],[Source].[SourceSubsystemID],[Source].[CountryID],[Source].[SupplierID],[Source].[LanguageID],[Source].[ProjectID],[Source].[DestinationPathName],[Source].[EntityDescription],[Source].[AuthorisationLink],[Source].[DataProperties])
OUTPUT $action INTO @mergeOutput;

DECLARE @mergeError int
, @mergeCount int, @mergeCountIns int, @mergeCountUpd int, @mergeCountDel int
SELECT @mergeError = @@ERROR
SELECT @mergeCount = COUNT(1), @mergeCountIns = SUM(IIF([DMLAction] = 'INSERT', 1, 0)), @mergeCountUpd = SUM(IIF([DMLAction] = 'UPDATE', 1, 0)), @mergeCountDel = SUM (IIF([DMLAction] = 'DELETE', 1, 0)) FROM @mergeOutput
IF @mergeError != 0
BEGIN
PRINT 'ERROR OCCURRED IN MERGE FOR [idfwba].[DAP_Feed_Registration]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected
END
ELSE
BEGIN
PRINT '[idfwba].[DAP_Feed_Registration rows affected by MERGE: ' + CAST(COALESCE(@mergeCount,0) AS VARCHAR(100)) + ' (Inserted: ' + CAST(COALESCE(@mergeCountIns,0) AS VARCHAR(100)) + '; Updated: ' + CAST(COALESCE(@mergeCountUpd,0) AS VARCHAR(100)) + '; Deleted: ' + CAST(COALESCE(@mergeCountDel,0) AS VARCHAR(100)) + ')' ;
END
GO


SET NOCOUNT OFF
GO

COMMIT TRANSACTION
GO

PRINT 'DAP_Job_Cluster_Mapping_Insert';

DELETE FROM [dbo].[DAP_Job_Cluster_Mapping] WHERE [esp_id] IN ('DAP65398', 'DAP65375', 'DAP65386', 'DAP65387', 'DAP65397', 'DAP65372', 'DAP65384', 'DAP65385', 'DAP65392', 'DAP65393', 'DAP65394', 'DAP65395','DAP65333','DAP65416','DAP65417','DAP65450','DAP65400','DAP65401','DAP65482','DAP65481','DAP65497','DAP65547','DAP65548','DAP65577','DAP65572','DAP65583','DAP65584','DAP65594','DAP65592','DAP65615','DAP65613','DAP65614','DAP65620','DAP65666','DAP65640','DAP65642','DAP65936','DAP65685','DAP65647','DAP65648','DAP65665','DAP65673','DAP65700','DAP65689', 'DAP65666', 'DAP65667', 'DAP65668', 'DAP65691','DAP65701','DAP65588','DAP65643','DAP65632','DAP65712','DAP65711', 'DAP65692','DAP65715','DAP65933','DAP65687','DAP65605','DAP65686','DAP65705','DAP65565');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65398');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65375');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65386');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65387');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65397');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65372');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65384');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65385');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65392');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65393');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65394');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65395');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65333');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65416');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65417');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65450');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65400');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65401');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65482');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65481');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65497');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65547');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65548');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65577');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65572');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65583');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus03', N'DAP65584');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65594');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65592');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65613');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65614');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65615');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65620');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus03', N'DAP65936');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus05', N'DAP65640');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus03', N'DAP65642');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus03', N'DAP65685');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65647');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65648');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65665');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus03', N'DAP65673');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65700');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65689');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65666');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65667');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus05', N'DAP65668');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus05', N'DAP65691');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65701');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65588');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus03', N'DAP65643');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65632');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65712');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65711');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus05', N'DAP65692');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65715');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus04', N'DAP65933');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus03', N'DAP65687');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65605');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus03', N'DAP65686');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus03', N'DAP65705');

INSERT [dbo].[DAP_Job_Cluster_Mapping] ([cluster_id], [esp_id]) VALUES (N'Clus02', N'DAP65565');

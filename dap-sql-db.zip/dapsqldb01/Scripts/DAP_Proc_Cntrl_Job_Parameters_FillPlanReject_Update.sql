PRINT 'Updating pTeraPrefixParam PARAMS dbo.DAP_Proc_Cntrl_Job_Parameters'

GO

update dbo.DAP_Proc_Cntrl_Job_Parameters set PARM_VAL='patient_services.FL_FillPlanReject_STG'
where JOB_NAME in ('Rx_seq_load_PrescriptionFillPlanReject','Rx_seq_xform_PrescriptionFillPlanReject')
and PARM_NAME='pTeraPrefixParam'

COMMIT TRANSACTION
GO
﻿PRINT 'Merge statement for DataStage ETL pipelines parameters R6'


GO
BEGIN TRANSACTION

SET NOCOUNT ON

DECLARE @mergeOutput TABLE ( [DMLAction] VARCHAR(6) );
MERGE INTO [dbo].[DAP_Proc_Cntrl_Job_Parameters] AS [Target]
USING (VALUES
/**********************************************************************BEGIN R6**********************************************************************/

--BEGIN POD 1
  (N'EDW_photo_prd', N'Cust_Seq_Xform', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'/usr/local/edw/photo/prd/common/apt/config1x1_photo.apt', N'Configuration file')
--END POD 1
--BEGIN POD 2
 
--END POD 2
--BEGIN POD 3
 ,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'$pErrPostThreshold', N'0', N'Enter the post load reject threshold in records.')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblTLPrescriptionReturnCallList', N'PATIENT_SERVICES.TL_Prescription_return_call_list', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblLocationStoreRelocation', N'LOCATION.LOCATION_STORE_RELOCATION', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblTlEtlProcDupRxRetSktCallList', N'PATIENT_SERVICES.TL_etl_proc_dup_rx_ret_stk_call_list_stg', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblTlEtlTbf0RetToStkCallList', N'PATIENT_SERVICES.TL_etl_tbf0_ret_to_stk_call_list_stg', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblTlEtlProcDupRx', N'PATIENT_SERVICES.tl_etl_proc_dup_rx_stg', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblTlEtlProcDupRxRetStkCallList', N'PATIENT_SERVICES.TL_ETL_PROC_DUP_RX_RET_STK_CALL_LIST_STG', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblTlEtlProcDupRxTran', N'PATIENT_SERVICES.tl_etl_proc_dup_rx_tran_stg', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblTlEtlProcDupFill', N'PATIENT_SERVICES.tl_etl_proc_dup_fill_STG', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblTlRxCreateDttmChange', N'PATIENT_SERVICES.tl_rx_create_dttm_change_STG', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'SfTblTlFillSoldDttmChange', N'PATIENT_SERVICES.tl_fill_sold_dttm_change_stg', N'Snowflake Table Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'$pErrPreThreshold', N'0', N'Enter the pre load reject threshold in records.')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'pEdwBatchId', N'999', N'Enter the batch ID for the current cycle')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'pTeraPrefix', N'TL_prescription_return_call_list', N'Enter a short hand notation of the target table for work/log/error table names.')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'pDSJobInvocation', N'NOINVID', N'Enter the first job Invocation ID')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'pTDEDWTargetTable', N'TL_prescription_return_call_list', N'Enter the Target Table Name.')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'$APT_CONFIG_FILE', N'/usr/local/edw/pharmacy/prod/common/apt/edw_phrm_config_4x4.apt', N'Configuration file')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'pLogFile', N'/usr/local/edw/pharmacy/prod/audit/TL_presprntseq.txt', N'Log file')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'pDSJobName', N'TL_rx_De_Dup_PrescripRetToStkCallList', N'Enter the first jobname to be executed')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'pTDETLStageView', N'TL_etl_tbf0_ret_to_stk_call_list', N'Enter the ETL Stage View Name')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'$pScriptPostLoadProc', N'edw_phrm_bteq_postload.sh', N'Enter the name of the Post Load Processing Script.')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'edw_pharmacy_prd', N'TL_rx_seq_De_Dup_PrescripRetToStkCallList', N'NOINVID', N'prod', N'$pScriptPreLoadProc', N'edw_phrm_bteq_preload.sh', N'Enter the name of the Pre Load Processing Script.')
--END POD 3
--BEGIN POD 4
 
--END POD 4
--BEGIN POD 5
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pDSJobName8', N'ecomphoto_load_TbCodeType_Ins_02', N'Datastage job name 8')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pDSJobName4', N'ecomphoto_load_TbCodeType_Ins_01', N'Datastage job name 4')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pDSJobName1', N'ecomphoto_xform_TbCodeType_01', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pDSJobName2', N'ecomphoto_xform_TbCodeType_02', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pDSJobName6', N'ecomphoto_xform_TbCodeType_04', N'Datastage job name 6')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pDSJobName5', N'ecomphoto_xform_TbCodeType_03', N'Datastage job name 5')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pDSJobName7', N'ecomphoto_load_TbCodeType_Upd_02', N'Datastage job name 7')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pDSJobName', N'ecomphoto_xform_TbCodeType', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pDSJobName3', N'ecomphoto_load_TbCodeType_Upd_01', N'Datastage job name 3')
,(N'EDW_ecommerce_prd', N'seq_ecomphoto_TbCodeType', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/seq_ecomphoto_TbCodeType_Log.txt', N'Log file')
--END POD 5
--BEGIN POD 6
 
--END POD 6

--BEGIN_MADE_QUEUE
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'pTeraPrefix', N'PATIENT_SERVICES.TL_PRESCRIPTION_MADR_QUEUE', N'Enter prefix.')
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'pDSJobName1', N'Madr_queue_create_loadfiles', N'Enter Job Name1.')
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'pDSJobName2', N'Madr_queue_update', N'Enter Job Name2.')
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'pDSJobName3', N'Madr_queue_insert', N'Enter Job Name3.')
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'pSFTargetTable', N'PATIENT_SERVICES.TL_PRESCRIPTION_MADR_QUEUE', N'Enter Target table.')
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'pLogFile', N'/dev/null', N'Enter log file.')
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'$pErrPostThreshold', N'0', N'Enter the post load reject threshold in records')
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'$APT_CONFIG_FILE', N'/usr/local/edw/pharmacy/prod/common/apt/edw_phrm_config_4x4.apt', N'Configuration file')
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_pharmacy_prd', N'Madr_queue_Seq', N'NOINVID', N'prod', N'pEdwBatchId', N'9999', N'Enter the batch ID for the current cycle')
--END_MADR_QUEUE

--BEGIN POD 7
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'pDSJobName1', N'cust_load_TbPrsRfilRmd_Upd', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'pDSJobName', N'cust_xform_TbPrsRfillRmd', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'pTDTable', N'ecom_prescription_refill_rmdr', N'pTDTable')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'pDSJobName2', N'cust_load_TbPrsRfilRmd_Ins', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/SeqLog.txt', N'Log file')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'$APT_NO_PART_INSERTION', N'True', N'Disable automatic partitioning')
,(N'EDW_ecommerce_prd', N'seq_TbPrsRfilRmd', N'NOINVID', N'prd', N'$APT_NO_SORT_INSERTION', N'True', N'Disable sort insertion') 
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'pDSJobName1', N'ord_xform_TbOrdRet_refchk', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'pDSJobName3', N'ord_load_TbOrdRet_Upd', N'pDSJobName3')
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'pDSJobName2', N'ord_xform_TbOrdRet', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'pDSJobName4', N'ord_load_TbOrdRet_Ins', N'pDSJobName4')
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/Seq_TbOrdRetLog.txt', N'Log file')
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbOrdRtn', N'NOINVID', N'prd', N'pDSJobName', N'ord_xform_TbOrdRet_stg', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pDSJobName2', N'ord_xform_TbOrder_part1', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'pDSJobName1', N'ord_xform_TbLenOrdVer_refchk', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/SeqLog_TbOrder.txt', N'Log file')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pDSJobName1', N'ord_stg_TbOrder', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'pDSJobName3', N'ord_load_TbLenOrdVer_Upd', N'pDSJobName3')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/Seq_TbLenOrdVerLog.txt', N'Log file')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pDSJobName3', N'ord_xform_TbOrder_part2', N'pDSJobName3')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'pDSJobName2', N'ord_xform_TbLenOrdVer', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pDSJobName4', N'ord_load_TbOrder_Upd', N'pDSJobName4')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pDSJobName5', N'ord_load_TbOrder_Ins', N'pDSJobName5')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'pDSJobName4', N'ord_load_TbLenOrdVer_Ins', N'pDSJobName4')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pDSJobName', N'ord_stg_TbOrderRx', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_TbOrder', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbLenOrdVer', N'NOINVID', N'prd', N'pDSJobName', N'ord_xform_TbLenOrdVer_stg', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'$APT_NO_SORT_INSERTION', N'False', N'Disable sort insertion')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'pDSJobName', N'cust_xform_TbPrescriptionTransferFm', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'pDSJobName2', N'cust_stage_TbPrescriptionTransferFm', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'pDSJobName1', N'cust_xform_TbPresTransFm_refchk', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/TbPrescriptionTransfer.txt', N'Log file')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'pDSJobName3', N'cust_load_TbPrescriptionTransferFm_Ins', N'Datastage job name 3')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbPrescriptionTransferFm', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'invocation id')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pDSJobName2', N'Nonregcust_load_TbCustEmlOpt_Ins', N'insert final table job name')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pDSJobName', N'Nonregcust_xform_TbCustEmlOpt_stg', N'staging table job name')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pTeraStgPrefix', N'ecom.Nonregstgcustemail', N'terastageprefix table')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pDsStgJobName', N'Nonregcust_xform_TbCustEmlOpt_stg', N'staging table job name')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/NonregCustEmlOptSeqLog.txt', N'Root directory for process controlparameterfiles')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pTDStgTable', N'Nonstg_ecom_cust_email_options', N'staging table')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pTDStgTable1', N'ecom.ecom_noncust_email_opt_stg', N'staging table')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pTDTable', N'ecom.ecom_non_cust_email_options', N'final table')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'batchid for sequence')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pLogFile', N'/usr/local/EDW/ecomm/prd/audit/Nonreg_seq_TbCustEmlOpt_Log.txt', N'root directory for log files')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'auditbypass value')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'configuration file')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pDSJobName1', N'Nonregcust_load_TbCustEmlOpt_Upd', N'update final table job name')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pTeraPrefix', N'ecom.Nonregcustemail', N'teraprefix table')
,(N'EDW_ecommerce_prd', N'Nonreg_seq_TbCustEmlOpt', N'NOINVID', N'prd', N'pDSJobName3', N'Nonregcust_TbCustEmlOpt_stg', N'staging table populating job for hist compare') 
,(N'EDW_ecommerce_prd', N'seq_Reprocessing_TbCustomer', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_Reprocessing_TbCustomer', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/Seq_TBCustReproLog.txt', N'Log file')
,(N'EDW_ecommerce_prd', N'seq_Reprocessing_TbCustomer', N'NOINVID', N'prd', N'pDSJobName', N'cust_Reprocessing_TbCustomer', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_Reprocessing_TbCustomer', N'NOINVID', N'prd', N'pTeraPrefix', N'ecom.TbCustRepro', N'pTeraPrefix')
,(N'EDW_ecommerce_prd', N'seq_Reprocessing_TbCustomer', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_Reprocessing_TbCustomer', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_Reprocessing_TbCustomer', N'NOINVID', N'prd', N'pTDTable', N'ecom.ecom_customer', N'pTDTable')
,(N'EDW_ecommerce_prd', N'seq_Reprocessing_TbCustomer', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'pDSJobName1', N'vend_load_TbSsVendor_Upd', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'pTDTable', N'ecom_ss_vendor', N'pTDTable')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'pDSJobName2', N'vend_load_TbSsVendor_Ins', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'pDSJobName', N'vend_xform_TbSsVendor', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'pTeraPrefix', N'ssvedor', N'pTeraPrefix')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'pEdwBatchId', N'9999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_TbSsVendor', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/TbSsVendorSeqLog.txt', N'Log file')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pDSJobName1', N'prod_xform_TbProdCategory', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pDSJobName2', N'prod_load_TbProdCategory_Ins', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pTDStgTable', N'stg_ecom_product_category', N'Stage Table Name')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pEdwBatchId', N'9999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pDSJobName', N'prod_stg_TbProdCategory', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pTDTable', N'ecom_product_category', N'pTDTable')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/Seq_TbProdCat_Log.txt', N'Log file')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pTDTable1', N'ecom_product', N'pTDTable1')
,(N'EDW_ecommerce_prd', N'seq_TbProdCategory', N'NOINVID', N'prd', N'pTDTable2', N'ecom_category', N'pTDTable2')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pDSJobName6', N'ord_xform_TbOrderItem_CostPric_Upd', N'pDSJobName6')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/SeqLog_TbOrder.txt', N'Log file')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pDSJobName2', N'ord_xform_TbOrderItem', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pDSJobName5', N'ord_stg_TbOrderItem_stg', N'pDSJobName5')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pDSJobName1', N'ord_xform_TbOrderItem_Refcheck', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pDSJobName7', N'ord_stg_TbOrderItem_PHRX', N'pDSJobName7')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'$APT_NO_SORT_INSERTION', N'True', N'Disable sort insertion')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pDSJobName', N'ord_stg_TbOrderItem', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pDSJobName3', N'ord_load_TbOrderItem_Upd', N'pDSJobName3')
,(N'EDW_ecommerce_prd', N'seq_TbOrderItem', N'NOINVID', N'prd', N'pDSJobName4', N'ord_load_TbOrderItem_Ins', N'pDSJobName4')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'$APT_CONFIG_FILE',N'$PROJDEF',N'Configuration file')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pAuditBypass',N'0',N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName',N'pymnt_xform_TbBillAddSS_stg',N'Datastage job name')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName2',N'pymnt_load_TbBillAddSS_Upd',N'Datastage job name 2')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName6',N'pymnt_load_TbBillAddPH_Upd',N'pDSJobName6')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName4',N'pymnt_xform_TbBillAddPH_stg',N'pDSJobName4')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName1',N'pymnt_xform_TbBillAddSS',N'Datastage job name 1')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName5',N'pymnt_xform_TbBillAddPH',N'pDSJobName5')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pLogFile',N'$pDirAudit/Seq_TbBillAdd_Log.txt',N'Log file')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pEdwBatchId',N'20220422203131',N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName11',N'pymnt_load_TbBillAddRX_Upd',N'pDSJobName11')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName8',N'pymnt_stage_TbBillAddRX',N'pDSJobName8')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName12',N'pymnt_load_TbBillAddRX_Ins',N'pDSJobName12')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName7',N'pymnt_load_TbBillAddPH_Ins',N'pDSJobName7')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pSeq_InvocationId',N'NOINVID',N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName10',N'pymnt_xform_TbBillAddRX',N'pDSJobName10')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName3',N'pymnt_load_TbBillAddSS_Ins',N'pDSJobName3')
,(N'EDW_ecommerce_prd',N'seq_TbBillAdd',N'NOINVID',N'prd',N'pDSJobName9',N'pymnt_xform_TbBillAddRX_stg',N'pDSJobName9')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pAuditBypass',N'0',N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pEdwBatchId',N'9999',N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pLogFile',N'$pDirAudit/Seq_TbSkuIndDimLog.txt',N'Log file')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pDSJobName4',N'ord_load_TbOrdItmRet_Upd',N'pDSJobName4')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'$APT_CONFIG_FILE',N'$PROJDEF',N'Configuration file')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pSeq_InvocationId',N'NOINVID',N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pDSJobName',N'ord_xform_TbOrdItemRet_stg',N'Datastage job name')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pDSJobName2',N'ord_xform_TbOrdItmRet_RefChk_OrdRet',N'Datastage job name 2')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pDSJobName5',N'ord_load_TbOrdItmRet_Ins',N'pDSJobName5')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pDSJobName3',N'ord_xform_TbOrdItmRet',N'pDSJobName3')
,(N'EDW_ecommerce_prd',N'ord_TbOrdItmRet',N'NOINVID',N'prd',N'pDSJobName1',N'ord_xform_TbOrdItmRet_RefChk_Ord',N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pDSJobName4', N'promo_load_TbPromo_PhUpd', N'pDSJobName4')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pDSJobName', N'promo_xform_TbPromo', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pDSJobName2', N'promo_load_TbPromo_Ins', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pDSJobName3', N'promo_xform_TbPromo_SS', N'pDSJobName3')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pEdwBatchId', N'9999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pDSJobName5', N'promo_xform_TbPromo1', N'Datastage job name 5')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pDSJobName1', N'promo_load_TbPromo_Upd', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbPromo', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/seq_TbPromo_Log.txt', N'Log file')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pEdwBatchId',N'20220422203131',N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName9',N'ord_load_TbOrdPaySSPH_Ins',N'pDSJobName9')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pSeq_InvocationId',N'NOINVID',N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pAuditBypass',N'0',N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName12',N'ord_load_TbOrdPayRX_Ins',N'pDSJobName12')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName14',N'ord_xform_TbOrdPay_PH',N'pDSJobName14')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName10',N'ord_xform_TbOrdPay_stg_RX',N'pDSJobName10')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName1',N'ord_xform_TbOrdPay_refchk',N'Datastage job name 1')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName3',N'ord_load_TbOrdPay_Upd',N'pDSJobName3')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName7',N'ord_xform_TbOrdPay_SSPH',N'pDSJobName7')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName8',N'ord_load_TbOrdPaySSPH_Upd',N'pDSJobName8')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName15',N'ord_load_TbOrdPayPH_Ins',N'pDSJobName15')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'$APT_CONFIG_FILE',N'$PROJDEF',N'Configuration file')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'$APT_NO_SORT_INSERTION',N'True',N'Disable sort insertion')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName6',N'ord_xform_TbOrdPaySSPH_refchk',N'pDSJobName6')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName',N'ord_xform_TbOrdPay_stg_SS',N'Datastage job name')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName2',N'ord_xform_TbOrdPay_SS',N'Datastage job name 2')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pLogFile',N'$pDirAudit/Seq_TbOrdPay_Log.txt',N'Log file')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName11',N'ord_xform_TbOrdPay_RX',N'pDSJobName11')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName13',N'ord_xform_TbOrdPay_stg_PH',N'pDSJobName13')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName4',N'ord_load_TbOrdPay_Ins',N'pDSJobName4')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobName5',N'ord_xform_TbOrdPay_stg_SSPH',N'pDSJobName5')
,(N'EDW_ecommerce_prd',N'seq_TbOrdPay',N'NOINVID',N'prd',N'pDSJobNamePH',N'ord_load_TbOrdPaySTG_PH_Ins',N'pDSJobNamePH')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'pDSJobName', N'ord_xform_TbSubOrdItem_stg', N'Datastage job name \')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'pDSJobName3', N'ord_load_TbSubOrdItem_Upd', N'Datastage job name 3 \')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'pDSJobName4', N'ord_load_TbSubOrdItem_Ins', N'Datastage job name 4 \')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'pDSJobName2', N'ord_xform_TbSubOrdItem', N'Datastage job name 2 \')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/seq_TbSubOrderItem.txt', N'Log file \')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file \')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass) \')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'pDSJobName1', N'ord_xform_TbSubOrdItem_refcheck', N'Datastage job name 1 \')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId \')
,(N'EDW_ecommerce_prd', N'seq_TbSubOrderItem', N'NOINVID', N'prd', N'pEdwBatchId', N'9999', N'Enter the batch ID for the current cycle \')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pDSJob1_InvocationId', N'NOINVID', N'pDSJob1_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pEdwBatchId', N'999', N'EdwBatchId')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing?')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pTeraPrefix', N'Ecoms2s', N'TeraPrefix')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'TDTable1', N'ecom_ship_to_store_product', N'TDTable1')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pDSJob2_InvocationId', N'NOINVID', N'pDSJob2_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pDSJob_InvocationId', N'NOINVID', N'pDSJob_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pDSJobName', N'ord_xform_Tbecom_s2s_product', N'First Datastage jobname to be executed')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pDSJob1', N'ord_load_Tbecoms2sproduct_Ins', N'Second datastage job to execute')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pDSJob2', N'ord_load_Tbecoms2sproduct_Upd', N'thrid Datastage job to execute')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pSchemaFile1', N'PHEXT023', N'pSchemaFile1')
,(N'EDW_ecommerce_prd', N'seq_TbS2SProduct', N'NOINVID', N'prd', N'pLogFile', N'/usr/local/edw/ecomm/prd/audit/S2SEcom_product.txt', N'LogFile')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'$APT_CONFIG_FILE',N'$PROJDEF',N'Configuration file')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pSchemaFile',N'PHEXT022',N'Schema file name ')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pTDTable',N'ECOM.ECOM_ORDER_TOKEN',N'Teradata table name')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pEdwBatchId',N'999',N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pLogFile',N'$pDirAudit/seq_TbOrderToken.txt',N'Log file')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pAuditBypass',N'0',N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pSchemaFile1',N'PHEXT003',N'Schema file name 1')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pDSJobName1',N'ord_load_TbOrdTkn_Ins',N'Datastage job name 2')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pDSJobName',N'ord_xform_TbOrdTkn_stg',N'Datastage job name')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pSeq_InvocationId',N'NOINVID',N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd',N'seq_TbOrderToken',N'NOINVID',N'prd',N'pDSJobName2',N'ord_load_TbOrdTkn_Upd',N'Datastage job name 3')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'pDSJobName4', N'ord_load_TbOrdPromo_Ins', N'pDSJobName4')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'pSeq_InvocationId', N'NOINVID', N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'pDSJobName', N'ord_xform_TbOrdPromo_stg', N'Datastage job name')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'pAuditBypass', N'0', N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'pDSJobName2', N'ord_xform_TbOrdPromo', N'Datastage job name 2')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'pDSJobName3', N'ord_load_TbOrdPromo_Upd', N'Datastage job name 3')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'$APT_CONFIG_FILE', N'$PROJDEF', N'Configuration file')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'pEdwBatchId', N'9999', N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'$APT_NO_SORT_INSERTION', N'True', N'Disable sort insertion')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'pDSJobName1', N'ord_xform_TbOrdPromo_Refcheck', N'Datastage job name 1')
,(N'EDW_ecommerce_prd', N'seq_TbOrderPromo', N'NOINVID', N'prd', N'pLogFile', N'$pDirAudit/seq_TbPromo_Log.txt', N'Log file')
,(N'EDW_ecommerce_prd',N'seq_TbPymntTndr',N'NOINVID',N'prd',N'pDSJobName1',N'pymnt_xform_TbPymntTndr',N'Datastage job name 1')
,(N'EDW_ecommerce_prd',N'seq_TbPymntTndr',N'NOINVID',N'prd',N'pEdwBatchId',N'999',N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd',N'seq_TbPymntTndr',N'NOINVID',N'prd',N'$APT_CONFIG_FILE',N'$PROJDEF',N'Configuration file')
,(N'EDW_ecommerce_prd',N'seq_TbPymntTndr',N'NOINVID',N'prd',N'pAuditBypass',N'0',N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd',N'seq_TbPymntTndr',N'NOINVID',N'prd',N'pDSJobName',N'pymnt_stg_TbPymntTndr',N'Datastage job name')
,(N'EDW_ecommerce_prd',N'seq_TbPymntTndr',N'NOINVID',N'prd',N'pDSJobName2',N'pymnt_load_TbPymntTndr_Upd',N'Datastage job name 2')
,(N'EDW_ecommerce_prd',N'seq_TbPymntTndr',N'NOINVID',N'prd',N'pDSJobName3',N'pymnt_load_TbPymntTndr_Ins',N'pDSJobName3')
,(N'EDW_ecommerce_prd',N'seq_TbPymntTndr',N'NOINVID',N'prd',N'pLogFile',N'$pDirAudit/Seq_TbPymntTndr_Log.txt',N'Log file')
,(N'EDW_ecommerce_prd',N'seq_TbPymntTndr',N'NOINVID',N'prd',N'pSeq_InvocationId',N'NOINVID',N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd',N'seq_Tbpymttender_2nd_pass',N'NOINVID',N'prd',N'pDSJobName1',N'pymnt_xform_TbPymntTndr_02',N'Datastage job name 1')
,(N'EDW_ecommerce_prd',N'seq_Tbpymttender_2nd_pass',N'NOINVID',N'prd',N'pSeq_InvocationId',N'NOINVID',N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd',N'seq_Tbpymttender_2nd_pass',N'NOINVID',N'prd',N'pLogFile',N'$pDirAudit/seq_Tbpymttender_2nd_pass_Log.txt',N'Log file')
,(N'EDW_ecommerce_prd',N'seq_Tbpymttender_2nd_pass',N'NOINVID',N'prd',N'$APT_CONFIG_FILE',N'$PROJDEF',N'Configuration file')
,(N'EDW_ecommerce_prd',N'seq_Tbpymttender_2nd_pass',N'NOINVID',N'prd',N'pDSJobName',N'pymnt_xform_TbPymntTndr_01',N'Datastage job name')
,(N'EDW_ecommerce_prd',N'seq_Tbpymttender_2nd_pass',N'NOINVID',N'prd',N'pDSJobName2',N'pymnt_load_TbPymntTndr_03',N'Datastage job name 2')
,(N'EDW_ecommerce_prd',N'seq_Tbpymttender_2nd_pass',N'NOINVID',N'prd',N'pEdwBatchId',N'999',N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd',N'seq_Tbpymttender_2nd_pass',N'NOINVID',N'prd',N'pAuditBypass',N'0',N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName13',N'ship_xform_TbOrdShip_seqgen',N'pDSJobName13')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName',N'ship_stage_TbOrdShp',N'pDSJobName')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName2',N'ship_stg_TbOrdShip_refchk',N'Datastage job name 2')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName4',N'ship_load_TbOrdShipSS_Upd',N'pDSJobName4')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName6',N'ship_load_TbOrdShip_Ins',N'pDSJobName6')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName3',N'ship_xform_TbOrdShip',N'Datastage job name 3')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName5',N'ship_load_TbOrdShip_Upd',N'pDSJobName5')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pSeq_InvocationId',N'NOINVID',N'pSeq_InvocationId')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'$APT_CONFIG_FILE',N'$PROJDEF',N'Configuration file')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName8',N'ship_xform_SSPH_Tracking',N'pDSJobName8')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pLogFile',N'$pDirAudit/Seq_TbOrdShip_Log.txt',N'Log file')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName7',N'ship_stage_SSEXT003',N'pDSJobName7')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pEdwBatchId',N'999',N'Enter the batch ID for the current cycle')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName11',N'ship_xform_SSEXT015_upd',N'pDSJobName11')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName14',N'ship_load_SSPH_Tracking_Upd',N'pDSJobName14')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName10',N'ship_stage_SSEXT015',N'pDSJobName10')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pAuditBypass',N'0',N'Bypass Process Control Auditing? (1=bypass)')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName15',N'ship_load_SSPH_Tracking_Ins',N'pDSJobName15')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName12',N'ship_load_TbOrdShipSS15_Upd',N'pDSJobName12')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName9',N'ship_xform_SSPH_Tracking_InsUpd',N'pDSJobName9')
,(N'EDW_ecommerce_prd',N'seq_TbOrdShip',N'NOINVID',N'prd',N'pDSJobName1',N'ship_xform_TbOrdShip_stg',N'Datastage job name 1')

--END POD 7
--BEGIN POD 8
 
--END POD 8
--BEGIN POD 9
 
--END POD 9
--BEGIN POD 10
 
--END POD 10
/************************************************************************END R5*************************************************************************/
) AS [Source] ([PROJ_NAME],[JOB_NAME],[JOB_INVOCATION_ID],[ENVRT],[PARM_NAME],[PARM_VAL],[PARM_DESC])
ON (([Target].[PROJ_NAME] = [Source].[PROJ_NAME]) AND ([Target].[JOB_NAME] = [Source].[JOB_NAME]) AND ([Target].[PARM_NAME] = [Source].[PARM_NAME] OR ([Target].[PARM_NAME] IS NULL AND [Source].[PARM_NAME] IS NULL)))
WHEN MATCHED AND (
	NULLIF([Source].[PROJ_NAME], [Target].[PROJ_NAME]) IS NOT NULL OR NULLIF([Target].[PROJ_NAME], [Source].[PROJ_NAME]) IS NOT NULL OR 
	NULLIF([Source].[JOB_NAME], [Target].[JOB_NAME]) IS NOT NULL OR NULLIF([Target].[JOB_NAME], [Source].[JOB_NAME]) IS NOT NULL OR 
	NULLIF([Source].[JOB_INVOCATION_ID], [Target].[JOB_INVOCATION_ID]) IS NOT NULL OR NULLIF([Target].[JOB_INVOCATION_ID], [Source].[JOB_INVOCATION_ID]) IS NOT NULL OR 
	NULLIF([Source].[ENVRT], [Target].[ENVRT]) IS NOT NULL OR NULLIF([Target].[ENVRT], [Source].[ENVRT]) IS NOT NULL OR 
	NULLIF([Source].[PARM_NAME], [Target].[PARM_NAME]) IS NOT NULL OR NULLIF([Target].[PARM_NAME], [Source].[PARM_NAME]) IS NOT NULL OR 
	NULLIF([Source].[PARM_VAL], [Target].[PARM_VAL]) IS NOT NULL OR NULLIF([Target].[PARM_VAL], [Source].[PARM_VAL]) IS NOT NULL OR 
	NULLIF([Source].[PARM_DESC], [Target].[PARM_DESC]) IS NOT NULL OR NULLIF([Target].[PARM_DESC], [Source].[PARM_DESC]) IS NOT NULL) THEN
 UPDATE SET
  [Target].[PROJ_NAME] = [Source].[PROJ_NAME], 
  [Target].[JOB_NAME] = [Source].[JOB_NAME], 
  [Target].[JOB_INVOCATION_ID] = [Source].[JOB_INVOCATION_ID], 
  [Target].[ENVRT] = [Source].[ENVRT], 
  [Target].[PARM_NAME] = [Source].[PARM_NAME], 
  [Target].[PARM_VAL] = [Source].[PARM_VAL], 
  [Target].[PARM_DESC] = [Source].[PARM_DESC]
WHEN NOT MATCHED BY TARGET THEN
 INSERT([PROJ_NAME],[JOB_NAME],[JOB_INVOCATION_ID],[ENVRT],[PARM_NAME],[PARM_VAL],[PARM_DESC])
 VALUES([Source].[PROJ_NAME],[Source].[JOB_NAME],[Source].[JOB_INVOCATION_ID],[Source].[ENVRT],[Source].[PARM_NAME],[Source].[PARM_VAL],[Source].[PARM_DESC])
OUTPUT $action INTO @mergeOutput;

DECLARE @mergeError int
 , @mergeCount int, @mergeCountIns int, @mergeCountUpd int, @mergeCountDel int
SELECT @mergeError = @@ERROR
SELECT @mergeCount = COUNT(1), @mergeCountIns = SUM(IIF([DMLAction] = 'INSERT', 1, 0)), @mergeCountUpd = SUM(IIF([DMLAction] = 'UPDATE', 1, 0)), @mergeCountDel = SUM (IIF([DMLAction] = 'DELETE', 1, 0)) FROM @mergeOutput
IF @mergeError != 0
 BEGIN
 PRINT 'ERROR OCCURRED IN MERGE FOR [dbo].[DAP_Proc_Cntrl_Job_Parameters]. Rows affected: ' + CAST(@mergeCount AS VARCHAR(100)); -- SQL should always return zero rows affected
 END
ELSE
 BEGIN
 PRINT '[dbo].[DAP_Proc_Cntrl_Job_Parameters] rows affected by MERGE: ' + CAST(COALESCE(@mergeCount,0) AS VARCHAR(100)) + ' (Inserted: ' + CAST(COALESCE(@mergeCountIns,0) AS VARCHAR(100)) + '; Updated: ' + CAST(COALESCE(@mergeCountUpd,0) AS VARCHAR(100)) + '; Deleted: ' + CAST(COALESCE(@mergeCountDel,0) AS VARCHAR(100)) + ')' ;
 END
GO


SET NOCOUNT OFF
GO

COMMIT TRANSACTION
GO
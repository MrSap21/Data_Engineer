-- Create new index on column RunID
drop index if exists [idfwba].[runlog].[NCI_RunID]
GO
create nonclustered index [NCI_RunID] on [idfwba].[runlog]([RunID]) include ([runlogid])
GO

-- Improve views for missed assets reporting

-- create new index on column feed.FeedFrequencyID
drop index if exists [idfwba].[Feed].[NCI_FeedFrequencyID]
GO
create nonclustered index [NCI_FeedFrequencyID] on [idfwba].[Feed]([FeedFrequencyID]) include ([Feedname])
GO

-- Improve sproc AssetFetchProperties performance

-- create new index on column feed.feednamepattern and 
drop index if exists [idfwba].[Feed].[NCI_FeedNamePattern]
GO
create nonclustered index [NCI_FeedNamePattern] on [idfwba].[Feed]([FeedNamePattern] desc, [SourcePathName] desc)
GO

-- Improve FeedTaskGet and AssetInZipFile sproc

-- create new index on column feed.
drop index if exists [idfwba].[FeedTask].[NCI_FeedTask];
GO
create nonclustered index NCI_FeedTask on [idfwba].[FeedTask]([FeedID]) include ([TaskID])
GO

-- Improve CountAsset

drop index if exists [idfwba].asset.assetSearch
GO
create index assetSearch on [idfwba].[asset] ([AssetName],[AssetCurrentLocation]) include ([assetDefinition])
GO

/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/


:r .\Script.DAP_Proc_Cntrl_Job_Parameters_Merge.sql
:r .\Script.DAP_Dynamic_Cluster_Config_Merge.sql
:r .\Script.DAP_Parameter_Tbl_Insert.sql
:r .\Script.DAP_Data_Load_Config_Params_Insert.sql
:r .\Script.DAP_Data_Load_snowflake_db_meta_data_Merge.sql
:r .\Script.DAP_Job_Cluster_Mapping_Insert.sql
:r .\Script.DAP_Data_Load_Config_Params_SVOC_Insert.sql
:r .\Script.DAP_Data_Load_snowflake_db_meta_data_SVOC_Insert.sql
:r .\Script.DAP_Parameter_Tbl_SVOC_Insert.sql
:r .\Script.DAP_Proc_Cntrl_Job_Parameters_Merge_R7.sql
:r .\Script.DAP_Proc_Cntrl_Exec_Parameter_Tbl_Merge_R10.sql   
:r .\Script.EGRESS_DAP_Proc_Cntrl_Exec_Parameter_Tbl_Merge_R7.sql
:r .\Script.EGRESS_DAP_Proc_Cntrl_Exec_Parameter_Tbl_Merge_R9.sql
:r .\Script.Feed_Zip_Strategy_Parameters.sql
:r .\Script.New_indexes_US981057_MetaData_DB_optimization.sql
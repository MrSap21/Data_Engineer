PRINT 'Inserting dbo.DAP_Proc_Cntrl_Exec_Parameter_Tbl'

GO
MERGE INTO [dbo].[DAP_Proc_Cntrl_Exec_Parameter_Tbl] AS tgt

USING (VALUES ('B1AA6001-510D-456F-9D95-8F2C12F0D719','Retail','','PL_WCARD_CREATE_ITEM_LOAD_READY_FILES','','',0,'PAR_PL_ADR4_EFF_DT','','Antonio','Apr 30 2021 12:19PM','','Apr 30 2021 12:19PM',

               '','Y','',,'')) as src

                        ([RowId],[Business_Domain],[Sub_Domain],[PipelineName],[JobID],[JobName],[PAR_ORDER],[PAR_KEY],[PAR_VALUE],[Createdby],[Createdon],[Modifiedby],[Modifiedon],[Remarks],[Softflag],

                         [Esp_Job_Name],[PsetOrder],[ParentChildFlag]) 

ON tgt.RowId = src.RowId

 

WHEN MATCHED THEN

 

UPDATE SET [Business_Domain] = 'Retail',

           [Sub_Domain] = '',

                 [PipelineName] = 'PL_WCARD_CREATE_ITEM_LOAD_READY_FILES',

                 [JobID] = '',

                 [JobName] = '',

                 [PAR_ORDER] = 0,

                 [PAR_VALUE] = '',

                 [Createdby] = 'Antonio',

                 [Createdon] = 'Apr 30 2021 12:19PM',

                 [Modifiedby] = '',

                 [Modifiedon] = 'Apr 30 2021 12:19PM',

                 [Remarks] = '',

                 [Softflag] = 'Y',

                 [Esp_Job_Name] = '',

                 [PsetOrder] = ,

                 [ParentChildFlag] = ''

                

WHEN NOT MATCHED BY TARGET THEN

 

INSERT ([RowId],[Business_Domain],[Sub_Domain],[PipelineName],[JobID],[JobName],[PAR_ORDER],[PAR_KEY],[PAR_VALUE],[Createdby],[Createdon],[Modifiedby],[Modifiedon],[Remarks],[Softflag],[Esp_Job_Name],

        [PsetOrder],[ParentChildFlag])

              VALUES

              ('B1AA6001-510D-456F-9D95-8F2C12F0D719','Retail','','PL_WCARD_CREATE_ITEM_LOAD_READY_FILES','','',0,'PAR_PL_ADR4_EFF_DT','','Antonio','Apr 30 2021 12:19PM','','Apr 30 2021 12:19PM','','Y','',,'');

GO
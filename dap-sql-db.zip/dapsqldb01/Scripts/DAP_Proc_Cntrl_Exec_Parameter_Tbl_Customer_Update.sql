PRINT 'Updating PC, IC Customer delimiter PARAMS dbo.DAP_Proc_Cntrl_Exec_Parameter_Tbl'

GO

BEGIN TRANSACTION
update DAP_Proc_Cntrl_Exec_Parameter_Tbl
set PAR_VALUE='\x01'
where jobid='C84B0FF0-50E1-42EE-AB67-44249E1CBDC3'
and PsetOrder=1 and PAR_KEY='PAR_PL_IN_FILE_DELIM'


update DAP_Proc_Cntrl_Exec_Parameter_Tbl
set PAR_VALUE='\x01'
where jobid='B480FD05-ED7C-41BF-AF29-53D404084109'
and PsetOrder=1 and PAR_KEY='PAR_PL_IN_FILE_DELIM'

COMMIT TRANSACTION
GO
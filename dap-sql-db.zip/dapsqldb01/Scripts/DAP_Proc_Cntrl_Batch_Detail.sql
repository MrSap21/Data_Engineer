SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DAP_Proc_Cntrl_Batch_Detail](
	[Proj_name] [varchar](250) NOT NULL,
	[Src_stream_name] [varchar](250) NOT NULL,
	[Edw_batch_id] [decimal](18,0) NOT NULL,
	[Batch_status_cd] [smallint] NOT NULL
) ON [PRIMARY]
GO
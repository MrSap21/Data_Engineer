PRINT 'Updating IC_PATIENT_PRISON PARAMS dbo.DAP_Proc_Cntrl_Exec_Parameter_Tbl'

GO

BEGIN TRANSACTION

update Dap_Proc_Cntrl_Exec_Parameter_Tbl
set PAR_VALUE ='edw_idl_customer_cdi_prison_ind_extr'
where JobID='2A33E446-9D0C-48FF-BD40-725B099F6F1D'
and PsetOrder=0
and PAR_KEY='PAR_READAPI_VALUE'
and rowid='EF7A127F-0E81-4683-BAA6-87A1F9CA44CC'

update Dap_Proc_Cntrl_Exec_Parameter_Tbl
set PAR_VALUE = '$pTD_DB_CIF=CUSTOMER;pSTG_TABLE_NAME=SRC_IC_PATIENT_PRISON_STG'
where JobID='2A33E446-9D0C-48FF-BD40-725B099F6F1D'
and PsetOrder=2
and PAR_KEY='PAR_PL_PARAMETERS_LIST'

COMMIT TRANSACTION
GO
DECLARE @signalFeed INT;
SET @signalFeed = (SELECT FeedId FROM idfwba.feed  WHERE FeedName = 'wagpos_detail_list');

UPDATE idfwba.feed SET [Zip_ProcFlg] = 1,  [Sig_FeedID] = @signalFeed WHERE FeedName = 'wagpos_POSLOG'
UPDATE idfwba.feed SET [Zip_ProcFlg] = 2 WHERE FeedName = 'DAILY_POS_PROMOMVT'
﻿CREATE PROC [dbo].[upd_rec_mult_key] @prm_sp_file_prefix [nvarchar](500),@prm_sp_file_prefix_curr [nvarchar](500),@prm_sp_scd_type [nvarchar](500),@prm_sp_tab_name [nvarchar](500),@prm_sp_nat_col [nvarchar](500),@prm_sp_col_cnt [nvarchar](500),@prm_sp_pipeline_name [nvarchar](200),@prm_sp_trigger_name [nvarchar](200),@prm_sp_batch_date [nvarchar](10),@prm_sp_src_id [nvarchar](5),@prm_sp_total_rec_cnt [bigint],@prm_sp_scenario [nvarchar](40),@prm_sp_expected_period_key [nvarchar](10) AS 
BEGIN

Declare @type2_date_col varchar(50)

BEGIN TRY

Declare @stg_table_cnt bigint
Declare @stg_table_attr_key int
DECLARE @ErrorMessage NVarchar(4000),  @ErrorSeverity int, @Errorstate int

Declare @idx nvarchar(2)
select @idx=rn from (select value,row_number() over(order by (select 1)) as rn 
from string_split(@prm_sp_file_prefix,'|') ) gh where value=@prm_sp_file_prefix_curr
print(@idx)

select @prm_sp_tab_name=value from (select value,row_number() over(order by (select 1)) as rn 
from string_split(@prm_sp_tab_name,'|') ) gh where rn=@idx
print(@prm_sp_tab_name)

select @prm_sp_scd_type=value from (select value,row_number() over(order by (select 1)) as rn 
from string_split(@prm_sp_scd_type,'|') ) gh where rn=@idx
print(@prm_sp_scd_type)

select @prm_sp_nat_col=value from (select value,row_number() over(order by (select 1)) as rn 
from string_split(@prm_sp_nat_col,'|') ) gh where rn=@idx
print(@prm_sp_nat_col)

select @prm_sp_col_cnt=value from (select value,row_number() over(order by (select 1)) as rn 
from string_split(@prm_sp_col_cnt,'|') ) gh where rn=@idx
print(@prm_sp_col_cnt)

select @prm_sp_scenario=value from (select value,row_number() over(order by (select 1)) as rn 
from string_split(@prm_sp_scenario,'|') ) gh where rn=@idx
print(@prm_sp_scenario)

DECLARE @scd_join_query varchar(1000) 
select @scd_join_query=string_AGG(concat('latest.',value,'=previous.',value),' AND ')
from string_split(@prm_sp_nat_col,',')

Declare @table_name varchar(50)
Declare @schema_name varchar(50)
select @table_name=substring(value,charindex('.',value)+1,len(value)),@schema_name=substring(value,0,charindex('.',value)) from string_split(@prm_sp_tab_name,'-')

Declare @all_columns_list nvarchar(MAX)
select @all_columns_list=string_AGG(cast (column_name as nvarchar(max)),',')
from information_schema.columns where table_name=replace(replace(@table_name,'[',''),']','')
and table_schema=replace(replace(@schema_name,'[',''),']','')
and ORDINAL_POSITION<>1
print(@all_columns_list)

DECLARE @prm_sp_stg_tab_name nvarchar(500)
set @prm_sp_stg_tab_name=replace(replace(concat(replace(@prm_sp_tab_name,'.','_stg.'),'_STG'),'[',''),']','')
print(@prm_sp_scd_type)

IF @prm_sp_scd_type='Type-2'
BEGIN

Declare @serrogate_key_scd2 varchar(50)
select @serrogate_key_scd2=column_name from information_schema.columns where table_name=replace(replace(@table_name,'[',''),']','') and ORDINAL_POSITION=1

exec(N'select count(*) as cnt into #stg_tab_cnt_view from '+@prm_sp_stg_tab_name + ' where SRC_ID='+@prm_sp_src_id)
select @stg_table_cnt=cnt from #stg_tab_cnt_view
drop table #stg_tab_cnt_view

IF  @prm_sp_scd_type='Append'
BEGIN
print('Append')
Declare @txn_all_columns Nvarchar(1000)
select @txn_all_columns=string_AGG( cast(column_name as nvarchar(max)),',') from information_schema.columns where table_name =replace(replace(@table_name,'[',''),']','') and table_schema=replace(replace(@schema_name,'[',''),']','') and column_name not in 
(select name from sys.identity_columns where object_name(object_id)=replace(replace(@table_name,'[',''),']',''))

Declare @append_query as NVARCHAR(4000) = N' insert into  '+@prm_sp_tab_name+' (' + @txn_all_columns +' ) select ' + @txn_all_columns + 'from '+ @prm_sp_stg_tab_name
print(@append_query)
exec(@append_query)
END

ELse if @stg_table_cnt=@prm_sp_total_rec_cnt 
BEGIN
DECLARE @scd2_query AS NVARCHAR(MAX) = N'select latest.*,req_natural_col, LOAD_TS as req_ts, 
LOAD_USERID as req_userid into #tt from '+@prm_sp_stg_tab_name+' latest left join  (select '+ @serrogate_key_scd2+' as req_natural_col, LOAD_TS as req_ts, 
LOAD_USERID as req_userid,'+@prm_sp_nat_col+'  from '+@prm_sp_tab_name+ ' where SNAPSHOT_END_DT IS NULL AND CURR_IND=''1'' )  previous on ('+  @scd_join_query +')
where latest.SRC_ID='+cast(@prm_sp_src_id as NVARCHAR(4))+' 

update '+ @prm_sp_tab_name+'
set SNAPSHOT_END_DT=DATEADD(DAY, -1, cast(getdate() as date)),CURR_IND=''0'',UPD_TS=req_ts,UPD_USERID=req_userid
from #tt S where '+@prm_sp_tab_name+'.'+ @serrogate_key_scd2+'=req_natural_col and req_natural_col is not null

insert into '+@prm_sp_tab_name+' ('+@all_columns_list+')
select '+@all_columns_list+' from #tt 

delete from '+@prm_sp_stg_tab_name+' where SRC_ID='+cast(@prm_sp_src_id as NVARCHAR(4))+'
  
 drop table #tt ; '
print(@scd2_query)

BEGIN TRY

exec(@scd2_query)

END TRY
BEGIN CATCH
select  @ErrorMessage=Error_Message(),  @ErrorSeverity =Error_Severity(), @Errorstate =Error_STATE()
RAISERROR(@ErrorMessage,@ErrorSeverity,@Errorstate)

END CATCH
END
else 
BEGIN
              THROW 51000, 'Stage table count doesnt match with spark Dataframe count.',1;
END
END
END TRY
BEGIN CATCH
print('In catch')
END CATCH
END
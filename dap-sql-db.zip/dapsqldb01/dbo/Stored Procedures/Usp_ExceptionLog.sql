﻿CREATE PROCEDURE [dbo].[Usp_ExceptionLog]
(@DataFactoryName varchar(100), @PipelineName varchar(100), @runid varchar(100),@ErrorMessage varchar(1000))
AS
BEGIN
INSERT INTO
ExceptionLogs
(
[DataFactoryName],
[PipelineName],
[RunId],
[ErrorMessage]
)
VALUES
(
@DataFactoryName,
@PipelineName,
@runid,
@ErrorMessage
)
END
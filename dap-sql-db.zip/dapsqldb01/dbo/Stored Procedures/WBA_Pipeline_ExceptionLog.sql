﻿CREATE PROCEDURE [dbo].[WBA_Pipeline_ExceptionLog]
(@runid nvarchar(255), @BatchID nvarchar(255), @DataFactoryName nvarchar(255), @PipelineName nvarchar(255), @ErrorMessage nvarchar(4000))
AS
BEGIN

INSERT INTO
dbo.[WBA_ExceptionLogs]
(
[RunId],
[BatchID],
[DataFactoryName],
[PipelineName],
[ErrorMessage],
[CreatedOn]
)
VALUES
(
@runid,
@BatchID,
@DataFactoryName,
@PipelineName,
@ErrorMessage,
GETUTCDATE()
)
END
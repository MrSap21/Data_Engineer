﻿CREATE PROC [dbo].[usp_GetPipelineParameters] @JobID [VARCHAR](1000)  AS
BEGIN
--------
--------Stored procedure to reture the Parameters  as table format
--------exec dbo.usp_GetPipelineParameters '53A2B951-A980-4CCD-9DF0-F055A4A69852' 
--------
	DECLARE @cols AS NVARCHAR(MAX), @query AS NVARCHAR(MAX)	
	Begin 
	SELECT @cols = STRING_AGG('P'+cast(PSETORDER as nvarchar(MAX))+'_'+PAR_KEY,',') FROM dbo.DAP_Proc_Cntrl_Exec_Parameter_Tbl WHERE JobID = @JobID 
	set @query = concat('SELECT  ' + @cols + ' from 
				(
					select ''P''+cast(PSETORDER as nvarchar(10))+''_''+PAR_KEY as PAR,PAR_VALUE
					from dbo.DAP_Proc_Cntrl_Exec_Parameter_Tbl
					where JobID = ''',@JobID,''' 
			   ) x
				pivot 
				(
					max(PAR_VALUE)
					for PAR in (' + @cols + ')
				) p ')
	End 
	execute(@query)
END
CREATE PROCEDURE [dbo].[usp_GetNotebookParameters] @BusinessDomain [VARCHAR](1000), @SubDomain [VARCHAR](1000), @EspID [VARCHAR](1000), @RestartFlag [VARCHAR](2) AS
BEGIN
--------
--------Stored procedure to return the inputs required to run Orchestration Framework 
--------exec dbo.usp_GetNotebookParameters_ls 'Supply_Chain','Purchasing', 'DAP65342', 1
--------select * from DAP_Parameter_Tbl
--------select * from DAP_Audit_log where esp_id = 'DAP65304' order by exec_start_time desc
	DECLARE @query AS NVARCHAR(MAX), @BatchID AS NVARCHAR(80)
	DECLARE @seq_no AS NVARCHAR(4), @exec_no AS NVARCHAR(255), @run_no AS NVARCHAR(4)
	DECLARE @max_run_no INTEGER, @asset_id NVARCHAR(80)
	DECLARE @node_type NVARCHAR(100), @no_of_nodes NVARCHAR(100),@cluster_version NVARCHAR(150)
	
	/* Generating execution_no */
	SET @exec_no = newid();

	/*Deriving currect active Batch ID */
	SET @BatchID = (SELECT MAX(edw_batch_id)
	FROM  dbo.DAP_Proc_Cntrl_batch_detail 
	WHERE proj_name= @BusinessDomain
	AND src_stream_name=@SubDomain
	 AND batch_status_cd=1 )

	 IF(@EspID LIKE 'R%_DDL')
	 BEGIN
		SET @BatchID = '12345'
	 END
	 

	/* Fetching sequence no based on restart_flag 
	SET @restart_flag = (SELECT restart_flag
	FROM dbo.DAP_Parameter_Tbl
	WHERE business_domain = @BusinessDomain
	AND sub_domain = @SubDomain
	AND esp_id = @EspID) */

	/*Fetching run no */
	SET @max_run_no = (SELECT max(exec_run_no)
		FROM dbo.DAP_Audit_Log
		WHERE business_domain = @BusinessDomain
		AND sub_domain = @SubDomain
		AND esp_id = @EspID
		AND batch_id = @BatchID
		AND	master_flag = 'Y')

	SET @run_no = isnull(@max_run_no+1,0)

	/*
	SET @node_type = isnull((Select cc.node_type from   dbo.DAP_Cluster_Config cc inner join dbo.DAP_Job_Cluster_Mapping  cm on cc.cluster_id = cm.cluster_id where cm.esp_id = @EspID),(Select cc.node_type from   dbo.DAP_Cluster_Config cc inner join dbo.DAP_Job_Cluster_Mapping  cm on cc.cluster_id = cm.cluster_id where cc.cluster_type = 'default'))
	
	SET @no_of_nodes = isnull((Select cc.no_of_nodes from   dbo.DAP_Cluster_Config cc inner join dbo.DAP_Job_Cluster_Mapping  cm on cc.cluster_id = cm.cluster_id where cm.esp_id = @EspID),(Select cc.no_of_nodes from   dbo.DAP_Cluster_Config cc inner join dbo.DAP_Job_Cluster_Mapping  cm on cc.cluster_id = cm.cluster_id where cc.cluster_type = 'default'))
	
	SET @cluster_version = isnull((Select cc.cluster_version from   dbo.DAP_Cluster_Config cc inner join dbo.DAP_Job_Cluster_Mapping  cm on cc.cluster_id = cm.cluster_id where cm.esp_id = @EspID),(Select cc.cluster_version from   dbo.DAP_Cluster_Config cc inner join dbo.DAP_Job_Cluster_Mapping  cm on cc.cluster_id = cm.cluster_id where cc.cluster_type = 'default'))
	*/
	if exists( select '1' from dbo.DAP_Job_Cluster_Mapping where esp_id = @EspID)
	begin
		SELECT @node_type = cc.node_type, @no_of_nodes=cc.no_of_nodes, @cluster_version = cc.cluster_version
		from   dbo.DAP_Dynamic_Cluster_Config cc 
		inner join dbo.DAP_Job_Cluster_Mapping  cm 
		on cc.cluster_id = cm.cluster_id 
		where cm.esp_id = @EspID
	end
	else
	begin
		SELECT @node_type = cc.node_type, @no_of_nodes=cc.no_of_nodes, @cluster_version = cc.cluster_version
		from   dbo.DAP_Dynamic_Cluster_Config cc 
		where cc.cluster_type = 'default'
	end

	IF(@RestartFlag=1) AND EXISTS(
		SELECT '1' FROM dbo.DAP_Audit_Log
		WHERE business_domain = @BusinessDomain
		AND sub_domain = @SubDomain
		AND esp_id = @EspID
		AND batch_id = @BatchID
		AND	master_flag = 'Y'
		AND status_cd = '-1'
		AND exec_run_no = @max_run_no)
	Begin
		SET @seq_no = (SELECT top 1 sequence_no 
		FROM dbo.DAP_Audit_Log
		WHERE business_domain = @BusinessDomain
		AND sub_domain = @SubDomain
		AND esp_id = @EspID
		AND batch_id = @BatchID
		AND	master_flag = 'Y'
		ORDER BY exec_start_time desc)

		SET @asset_id = (SELECT top 1 assetId
		FROM dbo.DAP_Audit_Log
		WHERE business_domain = @BusinessDomain
		AND sub_domain = @SubDomain
		AND esp_id = @EspID
		AND batch_id = @BatchID
		AND	master_flag = 'Y'
		ORDER BY exec_start_time desc)
	End
	ELSE
	Begin
		SET @seq_no =  1
		SET @asset_id = -1
	End


	
	/* Generating query for execution */
	Begin 
	set @query = concat('SELECT  main.input_json as ''input_json'', main.notebook_path as ''notebook_path'', const.input_json as ''constant_params'' , '''
					+ @BatchID +''' as ''batch_id'', ''' +@seq_no+''' as ''sequence_no'', ''' 
					+ @exec_no + ''' as ''execution_no'', ''' + @run_no + ''' as ''run_no'', ''' + @asset_id + ''' as ''asset_id'','''
					+ @node_type + ''' as ''node_type'', ''' + @no_of_nodes + ''' as ''no_of_nodes'', ''' + @cluster_version + ''' as ''cluster_version''
					from dbo.DAP_Parameter_Tbl main
					left join  dbo.DAP_Parameter_Tbl const
					ON	main.const_param_id = const.business_domain
					where main.business_domain = ''',@BusinessDomain,'''
					and main.sub_domain = ''',@SubDomain,''' 
					and main.esp_id = ''',@EspID,''' 
	'		   ) 
	End

	execute(@query) 
END

GO

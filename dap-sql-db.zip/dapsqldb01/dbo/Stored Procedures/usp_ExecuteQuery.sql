CREATE PROC [dbo].[usp_ExecuteQuery] @query [VARCHAR](MAX)  AS
BEGIN
	execute(@query)
END
GO
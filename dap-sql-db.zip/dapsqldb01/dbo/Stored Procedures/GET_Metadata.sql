﻿CREATE PROCEDURE [dbo].[GET_Metadata]
(@Element_ID uniqueidentifier)
AS
BEGIN

IF @Element_ID = '00000000-0000-0000-0000-000000000000' 

Begin 

		;WITH  getMetadataCTE
		AS
		(
			SELECT  [Element_ID], [Element_name], [Keyid] , [KeyValue] ,[Parent_Element_id],1 AS [Level], 
						 CAST(([Element_name]) AS VARCHAR(MAX)) AS Hierarchy
			FROM    dbo.Metadata AS Main
			WHERE   [Parent_Element_id] IS NULL

			UNION ALL
				--recursive member
			SELECT  Member.[Element_ID], Member.[Element_name], Member.[Keyid], Member.[KeyValue], Member.[Parent_Element_id],Main.[Level] + 1 AS [Level],
						 CAST((Main.Hierarchy + '->' + Member.[Element_name]) AS VARCHAR(MAX)) AS Hierarchy
			FROM    dbo.Metadata AS Member
					JOIN getMetadataCTE AS Main ON Member.[Parent_Element_id] = Main.[Element_ID]   
		)

		SELECT * FROM getMetadataCTE

End 

Else 
Begin 
		;WITH  getMetadataCTE
		AS
		(
			SELECT  [Element_ID], [Element_name], [Keyid] , [KeyValue] ,[Parent_Element_id],1 AS [Level], 
						 CAST(([Element_name]) AS VARCHAR(MAX)) AS Hierarchy
			FROM    dbo.Metadata AS Main
			WHERE   [Element_id] = @Element_ID and [Parent_Element_id] IS NULL

			UNION ALL
				--recursive member
			SELECT  Member.[Element_ID], Member.[Element_name], Member.[Keyid], Member.[KeyValue], Member.[Parent_Element_id],Main.[Level] + 1 AS [Level],
						 CAST((Main.Hierarchy + '->' + Member.[Element_name]) AS VARCHAR(MAX)) AS Hierarchy
			FROM    dbo.Metadata AS Member
					JOIN getMetadataCTE AS Main ON Member.[Parent_Element_id] = Main.[Element_ID]   
					And Main.[Element_ID] =@Element_ID
		)

		SELECT * FROM getMetadataCTE --where [Parent_Element_id] = @Element_ID or [Element_ID]=@Element_ID
end 

END
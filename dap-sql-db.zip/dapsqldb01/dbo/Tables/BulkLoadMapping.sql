﻿CREATE TABLE [dbo].[BulkLoadMapping] (
    [BulkLoadMappingId]        BIGINT         IDENTITY (1, 1) NOT NULL,
    [PipelineName]             NVARCHAR (250) NOT NULL,
    [InputFileName]            NVARCHAR (500) NOT NULL,
    [InputFileOrdinalPosition] BIGINT         NOT NULL,
    [OutputSchemaName]         NVARCHAR (250) NOT NULL,
    [OutputTableName]          NVARCHAR (250) NOT NULL,
    [OutputTableColumnName]    NVARCHAR (250) NOT NULL,
    [IsActive]                 BIT            DEFAULT ((1)) NULL,
    [DefaultValue]             NVARCHAR (20)  NULL
);


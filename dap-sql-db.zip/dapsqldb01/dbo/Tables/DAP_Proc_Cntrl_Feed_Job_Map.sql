CREATE TABLE [dbo].[DAP_Proc_Cntrl_Feed_Job_Map](
	[feed_job_id] [int] NOT NULL FOREIGN KEY([job_id])
REFERENCES [dbo].[DAP_Proc_Cntrl_ETL_Jobs],
	[feed_name] [varchar](250) NOT NULL,
	[job_id] [int] NOT NULL,
	[file_trigger_enabled] [char](1) NULL
PRIMARY KEY CLUSTERED 
(
	[feed_job_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
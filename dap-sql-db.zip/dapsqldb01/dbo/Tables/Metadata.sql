﻿CREATE TABLE [dbo].[Metadata] (
    [Element_ID]        UNIQUEIDENTIFIER NOT NULL,
    [Element_name]      NVARCHAR (255)   NOT NULL,
    [Keyid]             NVARCHAR (255)   NOT NULL,
    [KeyValue]          NVARCHAR (1000)  NULL,
    [KeyDescription]    NVARCHAR (255)   NULL,
    [Parent_Element_id] UNIQUEIDENTIFIER NULL,
    [Createdby]         NVARCHAR (255)   NULL,
    [Createdon]         DATETIME         NOT NULL,
    [IsActive]          BIT              DEFAULT ((1)) NOT NULL
);


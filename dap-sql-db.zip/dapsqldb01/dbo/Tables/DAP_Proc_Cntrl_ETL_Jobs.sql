CREATE TABLE [dbo].[DAP_Proc_Cntrl_ETL_Jobs](
	[job_id] [int] NOT NULL,
	[job_name] [varchar](250) NOT NULL,
	[domain] [varchar](250) NOT NULL,
	[platform] [varchar](250) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[job_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


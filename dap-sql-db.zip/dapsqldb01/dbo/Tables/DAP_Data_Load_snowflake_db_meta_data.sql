CREATE TABLE [dbo].[DAP_Data_Load_snowflake_db_meta_data](
	[dbname] [varchar](100) NULL,
	[schemaname] [varchar](100) NULL,
	[tablename] [varchar](512) NULL,
	[outputcolumnlist] [varchar](max) NULL,
	[skeycolumn] [varchar](1000) NULL,
	[lastloadedbatchid] [varchar](50) NULL,
	[sql_stmt_template] [varchar](max) NULL,
	[dmloutputfilepath] [varchar](512) NULL,
	[stagname] [varchar](200) NULL,
	[outputfolderpath] [varchar](1000) NULL,
	[sql_merge_stmt] [varchar](max) NULL,
    [part_key] [varchar](1000) NULL,
	[full_data_load] [varchar](10) NULL,
	[multi_key_flag] [varchar](10) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


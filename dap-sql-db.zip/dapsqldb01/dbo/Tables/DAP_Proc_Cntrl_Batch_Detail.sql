CREATE TABLE [dbo].[DAP_Proc_Cntrl_Batch_Detail](
	[PROJ_NAME] [varchar](250) NOT NULL,
	[SRC_STREAM_NAME] [varchar](250) NOT NULL,
	[EDW_BATCH_ID] [decimal](18,0) NOT NULL,
	[BATCH_STATUS_CD] [smallint] NOT NULL
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[DAP_Dynamic_Cluster_Config](
	[cluster_id] [nvarchar](255) NOT NULL,
	[node_type] [nvarchar](100) NULL,
	[no_of_nodes] [nvarchar](100) NULL,
	[cluster_version] [nvarchar](150) NULL,
	[cluster_type] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[cluster_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
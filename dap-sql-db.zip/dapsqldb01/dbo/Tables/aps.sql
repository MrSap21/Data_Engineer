﻿CREATE TABLE [dbo].[aps] (
    [seq_nmb] BIGINT NULL
);


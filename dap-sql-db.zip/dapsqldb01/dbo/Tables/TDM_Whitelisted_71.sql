﻿CREATE TABLE [dbo].[TDM_Whitelisted_71] (
    [Database] VARCHAR (50)    NOT NULL,
    [Table]    VARCHAR (50)    NOT NULL,
    [GB]       DECIMAL (18, 8) NOT NULL,
    [Columns]  INT             NOT NULL
);


﻿CREATE TABLE [dbo].[check1] (
    [schema name] NVARCHAR (128) NULL
);


CREATE TABLE [dbo].[WBA_Parameter_Tbl] (
    [RowId]           UNIQUEIDENTIFIER DEFAULT (newid()) NULL,
    [Business_Domain] VARCHAR (100)    NULL,
    [Sub_Domain]      VARCHAR (100)    NULL,
    [PipelineName]    VARCHAR (255)    NULL,
    [JobID]           UNIQUEIDENTIFIER NULL,
    [JobName]         NVARCHAR (1000)  NOT NULL,
    [PAR_ORDER]       INT              NOT NULL,
    [PAR_KEY]         NVARCHAR (1000)  NOT NULL,
    [PAR_VALUE]       VARCHAR (4000)   NULL,
    [Createdby]       VARCHAR (255)    NULL,
    [Createdon]       DATETIME         DEFAULT (getutcdate()) NULL,
    [Modifiedby]      VARCHAR (255)    NULL,
    [Modifiedon]      DATETIME         DEFAULT (getutcdate()) NULL,
    [Remarks]         VARCHAR (1000)   NULL,
    [Softflag]        VARCHAR (1)      DEFAULT ('Y') NULL,
    [Esp_Job_Name]    VARCHAR (100)    NULL,
    [PsetOrder]       INT              NULL,
    [ParentChildFlag] VARCHAR (1)      NULL
);


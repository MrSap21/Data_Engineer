﻿CREATE TABLE [dbo].[WBA_ExceptionLogs] (
    [RunId]           NVARCHAR (255)  NULL,
    [BatchID]         NVARCHAR (255)  NULL,
    [DataFactoryName] NVARCHAR (255)  NULL,
    [PipelineName]    NVARCHAR (255)  NULL,
    [ErrorMessage]    NVARCHAR (4000) NULL,
    [CreatedOn]       DATETIME        NULL
);


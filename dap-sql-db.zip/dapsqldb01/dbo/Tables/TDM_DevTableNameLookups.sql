﻿CREATE TABLE [dbo].[TDM_DevTableNameLookups] (
    [DevTableName]     VARCHAR (256) NULL,
    [DevDatabaseName]  VARCHAR (256) NULL,
    [ProdDatabaseName] VARCHAR (256) NULL,
    [DevColumns]       INT           NULL,
    [ProdColumns]      INT           NULL
);


﻿CREATE TABLE [dbo].[sam] (
    [seq_nmb] BIGINT NULL
);


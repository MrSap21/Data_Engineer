CREATE TABLE [dbo].[DAP_Data_Load_Config_Params](
	[job_id] [nvarchar](255) NULL,
	[src_env] [nvarchar](255) NULL,
	[src_db_Name] [nvarchar](255) NULL,
	[src_object_ref] [nvarchar](255) NULL,
	[src_object_name] [nvarchar](255) NULL,
	[src_col_flag] [nvarchar](2) NULL,
	[delimiter] [nvarchar](max) NULL,
	[tgt_env] [nvarchar](255) NULL,
	[tgt_db_Name] [nvarchar](255) NULL,
	[tgt_object_ref] [nvarchar](255) NULL,
	[tgt_object_name] [nvarchar](255) NULL,
	[DataWarehouseName] [nvarchar](255) NULL,
	[DBPool] [nvarchar](255) NULL,
	[active_flag] [nvarchar](2) NULL,
	[created_date] [datetime] NULL,
	[end_date] [datetime] NULL,
	[modified_date] [datetime] NULL,
	[src_save_mode] [nvarchar](40) NULL,
	[trg_save_mode] [nvarchar](40) NULL,
	[src_filter] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]




﻿CREATE TABLE [dbo].[adfresultaudit] (
    [ResourcegroupName]    VARCHAR (255)  NULL,
    [DatafactoryName]      VARCHAR (255)  NULL,
    [Pipelinename]         VARCHAR (255)  NULL,
    [RunID]                NVARCHAR (255) NULL,
    [RunGroupID]           NVARCHAR (255) NULL,
    [RunStatus]            VARCHAR (255)  NULL,
    [pipelinerunstarttime] NVARCHAR (255) NULL,
    [pipelinerunendtime]   NVARCHAR (255) NULL,
    [durationinMs]         NVARCHAR (255) NULL,
    [pipelinerunmessage]   NVARCHAR (MAX) NULL
);


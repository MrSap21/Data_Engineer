CREATE TABLE [dbo].[DAP_Audit_log](
[execution_id]	[nvarchar](255) NOT NULL,
[exec_run_no]	[int] NOT NULL,
[master_flag]	[nvarchar](2) NOT NULL,
[business_domain]	[nvarchar](80) NOT NULL,
[sub_domain]	[nvarchar](80) NOT NULL,
[esp_id]	[nvarchar](80) NOT NULL,
[batch_id]	[nvarchar](80) NOT NULL,
[sequence_no]	[int],
[notebook]	[nvarchar](1000),
[status_cd]	[nvarchar](2),
[exec_start_time]	[datetime],
[exec_end_time]	[datetime],
[error_log]	[nvarchar](max),
[assetId] [nvarchar](2000),
[exec_url] [nvarchar](2000),
[notebook_output] [nvarchar](max)
)

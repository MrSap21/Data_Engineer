﻿CREATE TABLE [dbo].[DAP_FILE_TO_TABLE] (
    [Element_Id]      INT             NULL,
    [Rule_id]         INT             NULL,
    [Rule_Name]       NVARCHAR (255)  NULL,
    [Business_Domain] NVARCHAR (255)  NULL,
    [Input_file_Name] NVARCHAR (1000) NULL,
    [File_path]       NVARCHAR (1000) NULL,
    [DB_Server]       NVARCHAR (1000) NULL,
    [DB_SCHEMA]       NVARCHAR (255)  NULL,
    [DB_Table]        NVARCHAR (1000) NULL,
    [DB_Columns]      NVARCHAR (4000) NULL,
    [File_Delimiter]  NVARCHAR (100)  NULL,
    [File_extension]  NVARCHAR (100)  NULL
);


﻿CREATE TABLE [dbo].[ExceptionLogs] (
    [DataFactoryName] VARCHAR (100)  NULL,
    [PipelineName]    VARCHAR (100)  NULL,
    [RunId]           VARCHAR (100)  NULL,
    [ErrorMessage]    VARCHAR (1000) NULL,
    [CreatedOn]       DATETIME       CONSTRAINT [DF_CreatedOn] DEFAULT (getdate()) NULL
);


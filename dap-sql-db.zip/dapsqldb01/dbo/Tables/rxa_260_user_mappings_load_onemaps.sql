﻿CREATE TABLE [dbo].[rxa_260_user_mappings_load_onemaps] (
    [yr_nbr]                VARCHAR (15) NULL,
    [mnth_nbr]              VARCHAR (15) NULL,
    [third_party_plan_id]   VARCHAR (20) NULL,
    [plan_group_nbr]        VARCHAR (20) NULL,
    [clnt_name]             VARCHAR (20) NULL,
    [contract_name]         VARCHAR (20) NULL,
    [fill_reqst_channel_cd] VARCHAR (25) NULL,
    [payr_type_name]        VARCHAR (30) NULL,
    [edw_batch_id]          VARCHAR (40) NULL,
    [create_dttm]           VARCHAR (50) NULL
);


CREATE TABLE [dbo].[DAP_Proc_Cntrl_Job_Parameters](
	[PROJ_NAME] [varchar](250) NOT NULL,
	[JOB_NAME] [varchar](50) NOT NULL,
	[JOB_INVOCATION_ID] [varchar](50) NOT NULL,
	[ENVRT] [varchar](4) NOT NULL,
	[PARM_NAME] [varchar](50) NULL,
	[PARM_VAL] [varchar](100) NULL,
	[PARM_DESC] [varchar](250) NULL
) ON [PRIMARY]
GO
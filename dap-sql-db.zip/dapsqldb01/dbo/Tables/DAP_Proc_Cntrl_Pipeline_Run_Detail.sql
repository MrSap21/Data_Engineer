CREATE TABLE [dbo].[DAP_Proc_Cntrl_Pipeline_Run_Detail](
	[PROJ_NAME] [varchar](250) NOT NULL,
	[SRC_STREAM_NAME] [varchar](250) NOT NULL,
	[EDW_BATCH_ID] [decimal](18,0) NOT NULL,
	[PIPELINE_NAME] [varchar](250) NOT NULL,
	[RUN_SEQ_NBR] [decimal](18,0) NOT NULL,
	[START_DTTM] [datetime] NOT NULL,
	[FINISH_DTTM] [datetime] NOT NULL,
	[STATUS_CD] [decimal](18,0) NOT NULL,
	[JOB_INVOCATION_ID] [varchar](50) NULL
) ON [PRIMARY]
GO
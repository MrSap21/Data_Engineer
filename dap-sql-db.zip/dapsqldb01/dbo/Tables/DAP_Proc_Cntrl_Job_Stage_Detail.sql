CREATE TABLE [dbo].[DAP_Proc_Cntrl_Job_Stage_Detail](
	[PROJ_NAME] [varchar](250) NOT NULL,
	[EDW_BATCH_ID] [decimal](18,0) NOT NULL,
	[JOB_NAME] [varchar](50) NOT NULL,
    [JOB_INVOCATION_ID] [varchar](50) NOT NULL,
	[STG_NAME] [varchar](100) NOT NULL,
	[STG_TYPE] [varchar](30) NULL,
	[STG_IN_ROW_CNT] [decimal](18,0) NULL
) ON [PRIMARY]
GO
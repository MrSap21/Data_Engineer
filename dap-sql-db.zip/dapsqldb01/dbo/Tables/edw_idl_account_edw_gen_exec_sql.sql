﻿CREATE TABLE [dbo].[edw_idl_account_edw_gen_exec_sql] (
    [PSETS]              NVARCHAR (500) NULL,
    [SQL]                NVARCHAR (500) NULL,
    [pEDW_BATCH_ID]      NVARCHAR (500) NULL,
    [pPROJ_NAME]         NVARCHAR (500) NULL,
    [pSQL_PARM_1]        NVARCHAR (500) NULL,
    [pSQL_PARM_2]        NVARCHAR (500) NULL,
    [pSQL_PARM_3]        NVARCHAR (500) NULL,
    [pSQL_PARM_4]        NVARCHAR (500) NULL,
    [pSRC_STREAM_NAME]   NVARCHAR (500) NULL,
    [pSRC_SYS_CD]        NVARCHAR (500) NULL,
    [pTABLE_NAME_1]      NVARCHAR (500) NULL,
    [pTD_DB_CIF]         NVARCHAR (500) NULL,
    [pTD_DB_IDL]         NVARCHAR (500) NULL,
    [pTD_DB_META]        NVARCHAR (500) NULL,
    [pTD_EDW_BATCH_DATE] NVARCHAR (500) NULL,
    [pTD_EDW_END_DATE]   NVARCHAR (500) NULL,
    [pTD_EDW_LOW_DATE]   NVARCHAR (500) NULL,
    [pTD_VIEW_DB_IDL]    NVARCHAR (500) NULL
);


﻿CREATE TABLE [dbo].[DAP_Proc_Cntrl_Exec_Parameter_Tbl](
	[RowId] [uniqueidentifier] NULL,
	[Business_Domain] [varchar](100) NULL,
	[Sub_Domain] [varchar](100) NULL,
	[PipelineName] [varchar](255) NULL,
	[JobID] [uniqueidentifier] NULL,
	[JobName] [nvarchar](1000) NOT NULL,
	[PAR_ORDER] [int] NOT NULL,
	[PAR_KEY] [nvarchar](1000) NOT NULL,
	[PAR_VALUE] [varchar](4000) NULL,
	[Createdby] [varchar](255) NULL,
	[Createdon] [datetime] NULL,
	[Modifiedby] [varchar](255) NULL,
	[Modifiedon] [datetime] NULL,
	[Remarks] [varchar](1000) NULL,
	[Softflag] [varchar](1) NULL,
	[Esp_Job_Name] [varchar](100) NULL,
	[PsetOrder] [int] NULL,
	[ParentChildFlag] [varchar](1) NULL
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[DAP_Proc_Cntrl_Exec_Parameter_Tbl] ADD  DEFAULT (newid()) FOR [RowId]
GO

ALTER TABLE [dbo].[DAP_Proc_Cntrl_Exec_Parameter_Tbl] ADD  DEFAULT (getutcdate()) FOR [Createdon]
GO

ALTER TABLE [dbo].[DAP_Proc_Cntrl_Exec_Parameter_Tbl] ADD  DEFAULT (getutcdate()) FOR [Modifiedon]
GO

ALTER TABLE [dbo].[DAP_Proc_Cntrl_Exec_Parameter_Tbl] ADD  DEFAULT ('Y') FOR [Softflag]
GO
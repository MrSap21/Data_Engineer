﻿CREATE TABLE [dbo].[keshav_test] (
    [schema name] NVARCHAR (128) NULL
);


﻿CREATE TABLE [dbo].[drug_specialty_catg_reference_update] (
    [catg_cd]       VARCHAR (50) NULL,
    [catg_desc]     VARCHAR (50) NULL,
    [catg_desc_tbl] VARCHAR (50) NULL,
    [update_ind]    VARCHAR (50) NULL
);


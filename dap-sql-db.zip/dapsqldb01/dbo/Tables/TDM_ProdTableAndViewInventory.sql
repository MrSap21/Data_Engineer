﻿CREATE TABLE [dbo].[TDM_ProdTableAndViewInventory] (
    [DatabaseName] VARCHAR (256) NULL,
    [TableName]    VARCHAR (256) NULL,
    [Columns]      INT           NULL
);


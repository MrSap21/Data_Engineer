﻿CREATE TABLE [dbo].[DQ_RunLog_v1] (
    [_corrupt_record] NVARCHAR (MAX) NULL
);


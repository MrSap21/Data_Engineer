CREATE TABLE [dbo].[DAP_Parameter_Tbl](
[business_domain]	[nvarchar](80) NOT NULL,
[sub_domain]	[nvarchar](80) NOT NULL,
[esp_id]	[nvarchar](80),
[table_name] [nvarchar](255),
[input_json]	[nvarchar](max) NOT NULL,
[notebook_path]	[nvarchar](80),
[const_param_id]	[nvarchar](max),
[restart_flag]	[nvarchar](2),
[Createdby]	[nvarchar](80),
[Createdon]	[datetime],
[Modifiedby]	[nvarchar](80),
[Modifiedon]	[datetime],
[Remarks]	[nvarchar](255),
CONSTRAINT PK_DAP_Parameter_Tbl PRIMARY KEY CLUSTERED (business_domain, sub_domain, esp_id )
)
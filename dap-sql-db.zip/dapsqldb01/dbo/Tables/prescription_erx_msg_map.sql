﻿CREATE TABLE [dbo].[prescription_erx_msg_map] (
    [epbr_erx_msg_id] VARCHAR (50) NULL,
    [rx_create_dt]    DATETIME     NULL,
    [rx_nbr]          VARCHAR (50) NULL,
    [str_nbr]         VARCHAR (50) NULL
);


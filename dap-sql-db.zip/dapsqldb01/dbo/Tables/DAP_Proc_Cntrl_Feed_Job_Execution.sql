CREATE TABLE [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution](
	[job_execution_id] [int] IDENTITY(1,1) NOT NULL,
	[feed_job_id] [int] NOT NULL FOREIGN KEY([feed_job_id])
REFERENCES [dbo].[DAP_Proc_Cntrl_Feed_Job_Map],
	[asset_id] [int] NOT NULL,
	[edw_batch_id] [decimal](18, 0) NOT NULL,
	[read_dttm] [datetime] NOT NULL,
	[close_job_dttm] [datetime] NULL,
	[close_asset_dttm] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[job_execution_id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
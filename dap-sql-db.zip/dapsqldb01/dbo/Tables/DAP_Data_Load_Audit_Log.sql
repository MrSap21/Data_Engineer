CREATE TABLE [dbo].[DAP_Data_Load_Audit_Log](
[job_id]	[nvarchar](80),
[batch_id]	[nvarchar](80),
[env]	[nvarchar](80),
[db_Name]	[nvarchar](80),
[object_ref_name]	[nvarchar](80),
[object_name]	[nvarchar](80),
[rec_count]	[bigint],
[created_date]	[datetime],
[row_id]	[nvarchar](80),
[function_name] [nvarchar](80),
[status_cd]	[nvarchar](2),
[message]	[nvarchar](max)
)
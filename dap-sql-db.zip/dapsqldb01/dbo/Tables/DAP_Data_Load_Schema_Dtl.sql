CREATE TABLE [dbo].[DAP_Data_Load_Schema_Dtl](
[env]	[nvarchar](80),
[db_Name]	[nvarchar](80),
[schema_name]	[nvarchar](80),
[table_name]	[nvarchar](80),
[col_name]	[nvarchar](80),
[data_type]	[nvarchar](80),
[precision_value]	[int],
[job_id]	[nvarchar](80),
[column_index]	[int]
)

﻿CREATE TABLE [dbo].[sure_scripts_key_rx] (
    [rx_create_dt] DATETIME     NULL,
    [rx_nbr]       VARCHAR (50) NULL,
    [str_nbr]      VARCHAR (50) NULL
);


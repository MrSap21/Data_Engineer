﻿CREATE TABLE [dbo].[TDM_DevTablesAndViews] (
    [TableKind]    CHAR (1)      NULL,
    [DatabaseName] VARCHAR (256) NULL,
    [TableName]    VARCHAR (256) NULL
);


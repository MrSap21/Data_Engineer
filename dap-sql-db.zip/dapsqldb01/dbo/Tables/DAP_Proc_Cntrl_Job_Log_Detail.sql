CREATE TABLE [dbo].[DAP_Proc_Cntrl_Job_Log_Detail](
	[PROJ_NAME] [varchar](250) NOT NULL,
	[EDW_BATCH_ID] [decimal](18,0) NOT NULL,
	[JOB_NAME] [varchar](50) NOT NULL,
    [JOB_INVOCATION_ID] [varchar](50) NOT NULL,
	[EVT_MSG] [varchar](2000) NOT NULL,
	[EVT_USER] [varchar](30) NULL,
	[EVT_TYPE_CD] [varchar](1) NULL,
	[EVT_DTTM] [datetime] NULL
) ON [PRIMARY]
GO
﻿CREATE TABLE [dbo].[uijsoninput] (
    [ID]            NVARCHAR (100) NOT NULL,
    [Username]      NVARCHAR (100) NULL,
    [Owner]         NVARCHAR (100) NULL,
    [jsonValue]     NVARCHAR (MAX) NULL,
    [Status]        NVARCHAR (100) NULL,
    [Created_time]  DATETIME2 (7)  NULL,
    [Modified_time] DATETIME2 (7)  NULL,
    [IsActive]      BIT            NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);


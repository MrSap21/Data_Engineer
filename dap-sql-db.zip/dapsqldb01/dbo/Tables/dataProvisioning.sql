﻿CREATE TABLE [dbo].[dataProvisioning] (
    [ID]            VARCHAR (100) NULL,
    [Username]      VARCHAR (100) NULL,
    [Owner]         VARCHAR (100) NULL,
    [jsonValue]     VARCHAR (MAX) NULL,
    [Status]        VARCHAR (100) NULL,
    [Created_time]  DATETIME      NULL,
    [Modified_time] DATETIME      NULL,
    [IsActive]      VARCHAR (100) NULL
);


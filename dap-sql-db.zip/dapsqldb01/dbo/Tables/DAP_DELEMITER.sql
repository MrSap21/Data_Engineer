﻿CREATE TABLE [dbo].[DAP_DELEMITER] (
    [File_Delimiter] NVARCHAR (100) NULL
);


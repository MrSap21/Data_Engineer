﻿CREATE TABLE [dbo].[cicdpltest]
(
	[Id] INT NOT NULL PRIMARY KEY
)

﻿CREATE SCHEMA [hist_migration_abc];







GO
--GRANT EXECUTE
    --ON SCHEMA::[hist_migration_abc] TO [dapdevadf01];


﻿CREATE SCHEMA [idfwba_stg]
    AUTHORIZATION [dbo];




-- GO
-- GRANT EXECUTE
--     ON SCHEMA::[idfwba_stg] TO [dapdevadf01];


-- GO
-- GRANT EXECUTE
--     ON SCHEMA::[idfwba_stg] TO [Azure-DNA-DevRole-DataEng];


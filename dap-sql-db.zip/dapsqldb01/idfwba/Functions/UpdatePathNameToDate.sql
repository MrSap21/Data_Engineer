﻿

CREATE FUNCTION idfwba.[UpdatePathNameToDate]
(
@Path varchar(max)
)
RETURNS varchar(max)
AS
BEGIN


declare @PathDateFormat varchar(max)
set @PathDateFormat = 'YYYYMMDD'


declare @DestinationPathName varchar(max)
set @DestinationPathName = @Path


declare @DestinationPathNameDatePart varchar(max)
set @DestinationPathNameDatePart = right(@DestinationPathName,8)


declare @NewDestinationPathName varchar(max)


if(@DestinationPathName like '%' + 'YYYYMMDD' )
begin
set @NewDestinationPathName = replace(@DestinationPathName,'YYYYMMDD',convert(varchar,getdate(),112))
end
else if(@DestinationPathName like '%' + 'YYYY/MM/DD' )
begin
set @NewDestinationPathName = replace(@DestinationPathName,'YYYY/MM/DD',convert(varchar,getdate(),111))
end
else if(right(@DestinationPathName,10) = 'MM/DD/YYYY')
begin
set @NewDestinationPathName = replace(@DestinationPathName,'MM/DD/YYYY',convert(varchar,getdate(),101))
end
else if(right(@DestinationPathName,14) = 'YYYYMMDDHH0000')
begin
set @NewDestinationPathName = replace(@DestinationPathName,'YYYYMMDDHH0000',convert(varchar, FORMAT(getdate(), 'yyyyMMddhh') + '0000'))
end
else
begin
set @NewDestinationPathName = @DestinationPathName
end


return @NewDestinationPathName
END
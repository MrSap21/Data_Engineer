﻿--IF OBJECT_ID ( 'idfwba.FeedTemplateReplace', 'FN' ) IS NOT NULL
--    DROP FUNCTION idfwba.FeedTemplateReplace;
--GO

CREATE FUNCTION idfwba.FeedTemplateReplace
(
    @pFeedId             AS NVARCHAR(20),
    @pTemplate           AS NVARCHAR(MAX),
    @pValueWrapper       AS NVARCHAR(MAX)
)
RETURNS nvarchar(MAX)
AS
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================
--
-- FileName    : FeedTemplateReplace.sql
-- Description : Replace the template values enclosed in pValueWrapper with values from either "System Configuration" LOVSet or Property sub-model
-- =============================================================================
--
-- Change History
-- Name              Date            Description
-- Victor            11-DEC-2019     First Version
-- Victor            22-MAY-2020     Replace REF_LOV and REF_LOV_SET WITH RefLOV and RefLOVSet and LOVDescripiton with LOVSetName
-- Daniel Santamaria 16-NOV-2020     3371-Renamed, normalized and modified to support multiple storage accounts
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN
   --output data
    DECLARE @vTextOutput      NVARCHAR(MAX) = @pTemplate;
    DECLARE @vTextPending     NVARCHAR(MAX) = @pTemplate;
    DECLARE @vStringStart     INT;
    DECLARE @vStringEnd       INT;
    DECLARE @vValueKey        NVARCHAR(MAX);
    DECLARE @vValueName       NVARCHAR(MAX) = '';

    /*Convert empty strings into Null*/
    SET @pFeedID              = NULLIF(@pFeedID, '');

    --Get ProjectID from Feed, if FeedID is null then set ProjectID=0 (dummy)
    DECLARE @vProjectID       INT = 0; 
    SELECT @vProjectID = ProjectID FROM idfwba.Feed WHERE FeedID = @pFeedID;

    --Use a table variable in order to only run the query once, and not in each iteration
    --We can't take advantage of temp tables (SELECT * INTO #temp...) inside a Function
    DECLARE @tParam AS TABLE (
        ParamSource          NVARCHAR(128),
        LOVKey               NVARCHAR(128),
        LOVName              NVARCHAR(128)
    );
    INSERT INTO @tParam SELECT * FROM (
        SELECT 'RefLOV' AS Source, LOVKey, LOVName
        FROM idfwba.RefLOV rl
        JOIN idfwba.RefLOVSet rls ON (rl.LOVSetID = rls.LOVSetID AND rls.LOVSetID = 6 AND rls.ActiveFlag = 1)
        WHERE rl.ActiveFlag = 1
        UNION
        SELECT 'Property' AS Source
            , CONCAT(rll.LOVKey, '.', p.PropertyName) AS LOVKey
            , COALESCE(plp.PropertyValue, rl.LOVKey)  AS LOVName
        FROM idfwba.ProjectLayerProperty plp 
        JOIN idfwba.RefLOV               rll ON (plp.LayerID = rll.LOVID       AND rll.ActiveFlag = 1)
        JOIN idfwba.Property               p ON (p.PropertyID = plp.PropertyID AND p.ActiveFlag = 1)
        LEFT JOIN idfwba.RefLOV           rl ON (rl.LOVID = plp.PropertyLOVID  AND rl.ActiveFlag = 1)
        WHERE plp.ActiveFlag = 1
        AND plp.ProjectID  = @vProjectID
    ) sq

    --Iterate through the Template and replace each Value Key with its corresponding Value Name
    WHILE CHARINDEX(@pValueWrapper, @vTextPending) <> 0
    BEGIN
        SET @vStringStart = CHARINDEX(@pValueWrapper, @vTextPending) + 1
        SET @vStringEnd   = CHARINDEX(@pValueWrapper, @vTextPending, @vStringStart + 1)
        SET @vValueKey    = SUBSTRING(@vTextPending, @vStringStart + 1, @vStringEnd - @vStringStart - 1)
        SET @vTextPending = SUBSTRING(@vTextPending, @vStringEnd + 2, LEN(@vTextPending))
        SET @vValueName   = '' --Reset in each iteration so that it doesn't keep previous iteration value in case next select returns nothing

        SELECT @vValueName = LOVName 
        FROM @tParam
        WHERE LOVKey = @vValueKey

        IF @vValueName <> ''
        BEGIN
            SET @vTextOutput = REPLACE(@vTextOutput, @pValueWrapper + @vValueKey + @pValueWrapper, @vValueName)
        END
    END

    -- Return the result of the function
    RETURN @vTextOutput
END
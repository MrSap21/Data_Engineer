﻿--IF OBJECT_ID ( 'idfwba.AddNewAssetHistory', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.AddNewAssetHistory;
--GO

CREATE PROCEDURE idfwba.AddNewAssetHistory
(
    @pAssetID       AS NVARCHAR(30), -- ID of the Asset -- 12
    @pDTCreated     AS NVARCHAR(21), -- 20200109 16:58:47.170
    @pDescription   AS NVARCHAR(MAX) -- 'Moved from ... to ...'
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
 -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : AddNewAssetHistory.sql                                                                                                           
-- Description : This procedure insert a new row into idfwba.ASSETHISTORY                                                        
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                       
-- Name              Date            Description                                                                                                         
-- Andrés Gracia     29-NOV-2019     Created                                                                                                             
-- Daniel Santamaria 11-FEB-2020     Normalized, added new params AssetID and DTCreated, added return
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN TRY
	
	DECLARE @vDTCreated	        DATETIME;
	DECLARE @vAssetHistoryID    NVARCHAR(10);
	
    /*AGO 20200117 - Avoid errors on Start Date*/
    IF (@pDTCreated = '') OR (@pDTCreated IS NULL)
        BEGIN
            SET @vDTCreated = SYSDATETIME();
        END
    ELSE
        BEGIN
            SET @vDTCreated = CONVERT(datetime, @pDTCreated, 113);
        END
    ;

	INSERT INTO idfwba.ASSETHISTORY(AssetID, DTCreated, Description) 
        VALUES (@pAssetID, @vDTCreated, @pDescription)
    ;

    SELECT @vAssetHistoryID  = SCOPE_IDENTITY();

    /*AGO 20200117 - Return*/
    SELECT @pAssetID AS AssetID, @vAssetHistoryID AS AssetHistoryID, @pDescription AS Description;

END TRY

BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
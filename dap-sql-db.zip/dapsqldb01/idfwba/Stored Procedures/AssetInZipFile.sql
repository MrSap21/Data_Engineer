﻿
CREATE PROCEDURE [idfwba].[AssetInZipFile]
(
@pListAssetName as varchar(max),
@pAssetName as varchar(max),
@CurrentFeedJobTask as varchar(max),
@pMD5 as varchar(max),
@pSize as int ,
@pNrRecords as int,
@pAssetID as int,
@pAssetPath as varchar(max), 
@pAssetDefinition as varchar(max) 
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON

BEGIN
    BEGIN TRY
        DECLARE @tTransaction VARCHAR(20) = 'tTransactionZip';
        BEGIN TRAN @tTransaction;

		  /*Generic output variables*/
		  DECLARE @vProcedureMessage               AS NVARCHAR(MAX) = 'OK';
		  DECLARE @vProcedureStatus                AS NVARCHAR(20)  = '0';

		  declare @vAssetIDref						AS INT
		  declare @vProcedureMessageref				AS NVARCHAR(MAX)
		  declare @vProcedureStatusref				AS NVARCHAR(20)
	
		  DECLARE @vFeedId                        AS NVARCHAR(255)
		  DECLARE @vFeedTasks			          AS NVARCHAR(MAX)
		  DECLARE @vAssetCurrentLocation		  AS NVARCHAR(MAX)
		  DECLARE @vUserCreated                   AS NVARCHAR(100)
		  DECLARE @vDTCreated                     AS NVARCHAR(21) 
		  DECLARE @vStatusIDDefault               AS NVARCHAR(20)
		  DECLARE @vStatusID					  AS NVARCHAR(20)
		  DECLARE @vKeepValueFlag                 AS NCHAR(1)
		  DECLARE @vcASSET_NAME					  AS VARCHAR(max)


		  DECLARE @tBulkImportData TABLE(
				  ASSET_NAME		VARCHAR(max)
				  )
      
		  INSERT INTO @tBulkImportData
		  SELECT AssetJson.*
		  FROM OPENJSON(@pListAssetName, '$.value')
		  WITH(
				ASSET_NAME   VARCHAR(max) '$.name'
			   ) AssetJson

	 
		  DECLARE @tCurrentFeedJobTask TABLE (
				  FeedID				INT,
				  JobID				INT,
				  TaskID				INT,
				  ExecutionOrder		INT,
				  FeedTaskDescription	VARCHAR(MAX),
				  FeedTaskComponent	VARCHAR(MAX)
			)
	  
		  INSERT INTO @tCurrentFeedJobTask
		  SELECT FeedTaskJson.*
		  FROM OPENJSON(@CurrentFeedJobTask,'$.value')
		  WITH (
				FeedID				INT '$.FeedID',
				JobID				INT '$.JobID',
				TaskID				INT '$.TaskID',
				ExecutionOrder		INT '$.ExecutionOrder',
				FeedTaskDescription	VARCHAR(MAX) '$.FeedTaskDescription',
				FeedTaskComponent	VARCHAR(MAX) '$.FeedTaskComponent'
				) FeedTaskJson
	 
		 --Populate parameters defined af Feed level, ie. common for all unzipped assets		 
	
		 SELECT @vFeedID = FeedID from @tCurrentFeedJobTask
	 
		 SELECT @vFeedTasks= FeedTaskJSON from (
											SELECT ft.FeedID  AS FeedIDa,
											idfwba.FeedTemplateReplace(ft.FeedID, ft.FeedTaskJSON, '$$') AS FeedTaskJSON
											FROM idfwba.FeedTask ft
											JOIN idfwba.Task      t ON (t.TaskID = ft.TaskID) and TaskDescription ='Move from Raw to Cleansed'
											WHERE ft.FeedId = @vFeedID) b
	
		SELECT @vAssetCurrentLocation =  FeedTaskJsonAsset.AssetCurrentLocation
													FROM OPENJSON(@vFeedTasks,'$.properties')
													WITH (
														   AssetCurrentLocation    VARCHAR(MAX) '$.FolderPath_DestinationStore'
													) FeedTaskJsonAsset

		DECLARE @vCounter INT 
		SET @vCounter = 0
		
		DECLARE cAssetNamesList CURSOR LOCAL FOR   
		SELECT ASSET_NAME 
		FROM @tBulkImportData
		
	
		OPEN cAssetNamesList  
		
		FETCH NEXT FROM cAssetNamesList  INTO @vcASSET_NAME
	
		WHILE @@FETCH_STATUS = 0  
			BEGIN 
 				SET @vDTCreated                             = ISNULL(@vDTCreated        ,GETDATE());   --Default current date
				SET @vUserCreated                           = ISNULL(@vUserCreated      ,SYSTEM_USER); --Default user
				SET @vKeepValueFlag                         = ISNULL(@vKeepValueFlag    ,'1'    );
				SET @vStatusIDDefault                       = ISNULL(@vStatusIDDefault  ,'24001'); --Default 'Active'
				SET @vStatusID = 24014 
			
				EXEC [idfwba].[AssetAddOrUpdateZip]       
				@pAssetID = null,               
				@pAssetName = @vcASSET_NAME,                  
				@pAssetDefinition = @pAssetDefinition,     
				@pAssetTypeID = null,                
				@pAssetSubTypeID =null,           
				@pAssetMD5 = null,                    
				@pParentAssetID = @pAssetID,               
				@pAssetCurrentLocation = @vAssetCurrentLocation,        
				@pFeedId = @vFeedID,                      
				@pInformationClassificationID = null,
				@pEntityDescription = null,           
				@pAttributeDescription = null,      
				@pAttributeEntityDescription = null,  
				@pNumberOfRecords = @pNrRecords,            
				@pNumberOfBytes = @pSize,              
				@pDTCreated = @vDTCreated,              
				@pUserCreated  = @vUserCreated,               
				@pStatusID = @vStatusIDDefault,
				@pKeepValueFlag = @vKeepValueFlag,
				@preturnAssetID  = @vAssetIDref   OUTPUT,
				@preturnProcedureStatus  = @vProcedureStatusref    OUTPUT ,  
				@preturnProcedureMessage  = @vProcedureMessageref   OUTPUT
	
				----tracing UPDATE STATUS
				/*insert into idfwba.assetLogging(operation, impacted_table, query_text) 
				select 'FirstUpdate3','AssetStatus', 'UPDATE idfwba.AssetStatus (SET DTEffectiveTo = ' + CONVERT(VARCHAR(30), GETDATE(), 109) + ' WHERE AssetID  = ' + cast(isnull(@vAssetIDref, 'NULL') as varchar(20)) + ' AND DTEffectiveTo IS NULL)' query_text*/
				----UPDATE STATUS
				UPDATE idfwba.AssetStatus WITH (TABLOCKX)
							   SET DTEffectiveTo     = GETDATE()
							   WHERE AssetID  = @vAssetIDref AND DTEffectiveTo IS NULL
				
				----tracing INSERT WRANGLED STATUS
				/*insert into idfwba.assetLogging(operation, impacted_table, query_text)
				select 'SecondInsert4','AssetStatus', 'INSERT INTO idfwba.AssetStatus (AssetID,StatusID,DTEffectiveFrom,DTEffectiveTo,DTCreated,UserCreated) VALUES (''' + cast(isnull(@vAssetIDref, 'NULL') as varchar(20)) + ''', ''' + @vStatusID + ''', ''' + CONVERT(VARCHAR(30), GETDATE(), 109) + ''', NULL, ''' + CONVERT(VARCHAR(30), GETDATE(), 109) + ''', ''' + @vUserCreated + ''') ' query_text*/
                    /*Insert AssetStatus*/
				----INSERT WRANGLED STATUS
				INSERT INTO idfwba.AssetStatus WITH (TABLOCKX) (AssetID, StatusID, DTEffectiveFrom, DTEffectiveTo, DTCreated, UserCreated)
				VALUES (@vAssetIDref, @vStatusID, GETDATE(), NULL, GETDATE(), @vUserCreated)
				
				DECLARE @Description varchar(max)
				SELECT @Description = CONCAT('AssetID=',cast(@vAssetIDref as varchar(max)),'; AssetName=',@vcASSET_NAME,'. Moved from ',@pAssetPath,' to ',@vAssetCurrentLocation)
				
				----tracing INSERT ASSET HISTORY
				/*insert into idfwba.assetLogging(operation, impacted_table, query_text)
				select 'FirstInsert5','AssetHistory', 'INSERT INTO idfwba.ASSETHISTORY (AssetID, DTCreated, Description) VALUES (''' + cast(isnull(@vAssetIDref, 'NULL') as varchar(20)) + ''', ''' + CONVERT(VARCHAR(30), GETDATE(), 109) + ''', ''' + ISNULL(@Description, 'NULL') + ''') ' query_text*/
				----INSERT ASSET HISTORY
				INSERT INTO idfwba.ASSETHISTORY WITH (TABLOCKX) (AssetID, DTCreated, Description)  
				VALUES (@vAssetIDref, GETDATE(), @Description)

				SET @vCounter  = @vCounter  + 1

				FETCH NEXT FROM cAssetNamesList  INTO @vcASSET_NAME

			 END
		
		CLOSE cAssetNamesList 
		DEALLOCATE cAssetNamesList


SELECT CONCAT(cast (@vCounter as varchar(max)), ' Assets') as NumberOfAssets

COMMIT TRAN;
    END TRY

    BEGIN CATCH
        ROLLBACK TRAN @tTransaction;
        SELECT @pAssetID AS AssetID
             , '-1' AS ProcedureStatus
             , CONCAT( 'Error number: ',   ERROR_NUMBER(),    '; ', CHAR(13)
                      ,'Error message: ',  ERROR_MESSAGE(),   '; ', CHAR(13)
                      ,'Severity: ',       ERROR_SEVERITY(),  '; ', CHAR(13)
                      ,'State: ',          ERROR_STATE(),     '; ', CHAR(13)
                      ,'Procedure name: ', ERROR_PROCEDURE(), '; ', CHAR(13)
                      ,'Procedure line: ', ERROR_LINE(),      '; ', CHAR(13)
                     ) AS ProcedureMessage
        ;
    END CATCH;
END;



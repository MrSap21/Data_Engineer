﻿--IF OBJECT_ID ( 'idfwba.RunResult', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.RunResult;
--GO

CREATE PROCEDURE idfwba.RunResult
(
    @pRunLogID              AS NVARCHAR(20),   --25
    @pStatus                AS NVARCHAR(10),   -- Finish
    @pResultName            AS NVARCHAR(50),  -- {"result_name":"Test","result_value":"10"}
    @pResultValue           AS NVARCHAR(MAX),  -- {"result_name":"Test","result_value":"10"}
    @pRunID                 AS NVARCHAR(100)   -- RunID of the Pipeline - 56465464
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : RunResult.sql                                                                                                           
-- Description : This procedure updates the result of the running entity
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                       
-- Name              Date            Description                                                                                                         
-- Andrés Gracia     15-JAN-2020     Created                     
-- Andrés Gracia     31-JAN-2020     Changed comments & parameters due to Task 1678                                    
-- Daniel Santamaria 04-FEB-2020     Moved comments before BEGIN, removed TABs, added Added RunId logic
-- Daniel Santamaria 05-FEB-2020     Replaced pResult with pResultName and pResultValue
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN TRY
    DECLARE @vProcedureStatus         AS NVARCHAR(1)   = '0';
    DECLARE @vProcedureMessage        AS NVARCHAR(100) = 'OK';
    DECLARE @vNumRowsChanged          AS NVARCHAR(10);
    DECLARE @vResult                  AS NVARCHAR(MAX);

    /*DS  202000204 - Null values*/
    SET @pRunLogID        = NULLIF(@pRunLogID,'');
    SET @pRunID           = NULLIF(@pRunID,'');
    SET @pStatus          = NULLIF(@pStatus,'');
    SET @pResultName      = NULLIF(@pResultName,'');
    --SET @pResultValue     = NULLIF(@pResultValue,''); --This one can be ''

    /*DS  20200204 - Added RunId logic*/
    IF @pRunLogID IS NULL 
        SELECT @pRunLogID = RunLogID 
        FROM idfwba.RUNLOG 
        WHERE JSON_VALUE(RunLogDefinitionJSON, '$.RunID') = @pRunId
    ;

    /*AGO 20200117 - Update Status, without making an append*/
    IF @pStatus IS NOT NULL
        UPDATE idfwba.RUNLOG SET 
            RunLogOutputJSON = JSON_MODIFY(RunLogOutputJSON,'$.status',@pStatus)
        WHERE  RunLogID = @pRunLogID
    ;

    /*DS 20200205 - Build the JSON structure with pResultName and pResultValue*/
    SET @vResult = CONCAT('{"result_name":"', @pResultName, '","result_value":"', @pResultValue, '"}');

    /*AGO 20200117 - Update Results, always making an append*/
    IF @vResult IS NOT NULL
        UPDATE idfwba.RUNLOG SET 
            RunLogOutputJSON = JSON_MODIFY(RunLogOutputJSON,'append $.output',JSON_QUERY(@vResult))
        WHERE RunLogID = @pRunLogID
    ;
    SET @vNumRowsChanged = @@ROWCOUNT;

    /*AGO 20200117 - Return values*/
    SELECT @pRunLogID AS RunLogID, @vNumRowsChanged AS Updated_Rows, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;
END TRY

BEGIN CATCH
    DECLARE @msg nvarchar(2048) = error_message()  
      RAISERROR (@msg, 16, 1)
END CATCH
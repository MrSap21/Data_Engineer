﻿--IF OBJECT_ID ( 'idfwba.RunMessage', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.RunMessage;
--GO

CREATE PROCEDURE idfwba.RunMessage
(
    @pRunLogID              AS NVARCHAR(20),   -- 5
    @pDate                  AS NVARCHAR(21),   -- 20200109 16:58:47.170
    @pMessage               AS NVARCHAR(MAX), -- Free Text
    @pRunID                 AS NVARCHAR(100)   -- RunID of the Pipeline - 56465464
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : RunMessage.sql                                                                                                           
-- Description : This procedure writes messages into RunLogMessageJSON
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                       
-- Name              Date            Description                                                                                                         
-- Andrés Gracia     16-JAN-2020     Created   
-- Andrés Gracia     31-JAN-2020     Changed comments & parameters due to Task 1678                                    
-- Daniel Santamaria 04-FEB-2020     Moved comments before BEGIN, removed TABs, added Added RunId logic
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN TRY
    DECLARE @vCurrentMessage          AS NVARCHAR(MAX);
    DECLARE @vJson                    AS NVARCHAR(MAX);
    DECLARE @vProcedureStatus         AS NVARCHAR(1)   = '0';
    DECLARE @vProcedureMessage        AS NVARCHAR(100) = 'OK';
    DECLARE @vNumRowsChanged          AS NVARCHAR(10);

    /*DS  202000204 - Null values*/
    SET @pRunLogID        = NULLIF(@pRunLogID,'');
    SET @pRunID           = NULLIF(@pRunID,'');

    /*DS  20200204 - Added RunId logic*/
    IF @pRunLogID IS NULL 
        SELECT @pRunLogID = RunLogID 
        FROM idfwba.RUNLOG 
        WHERE JSON_VALUE(RunLogDefinitionJSON, '$.RunID') = @pRunId
    ;

    /*AGO 20200117 - Set current Message*/
    SELECT @vCurrentMessage = JSON_QUERY(RunLogMessageJSON,'$')
    FROM idfwba.RUNLOG
    WHERE RunLogID = @pRunLogID
    ;

    /*AGO 20200117 - Check if there is any message to perform an append or not*/
    IF @vCurrentMessage ='{}'
        BEGIN
            SET @vJson = (SELECT @pDate AS date, @pMessage AS message FOR JSON PATH);
            UPDATE idfwba.RUNLOG SET RunLogMessageJSON = @vJson WHERE RunLogID = @pRunLogID;
        END
    ELSE
        BEGIN
            SET @vJson = (SELECT @pDate AS date, @pMessage AS message FOR JSON PATH,WITHOUT_ARRAY_WRAPPER);
            UPDATE idfwba.RUNLOG SET RunLogMessageJSON = JSON_MODIFY(RunLogMessageJSON,'append $',JSON_QUERY(@vJson)) WHERE RunLogID = @pRunLogID;
        END
    ;
    SET @vNumRowsChanged = @@ROWCOUNT;
    
    /*AGO 20200117 - Return values*/
    SELECT @pRunLogID AS RunLogID, @vNumRowsChanged AS Updated_Rows, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;
END TRY

BEGIN CATCH
    DECLARE @msg nvarchar(2048) = error_message();
    RAISERROR (@msg, 16, 1);
END CATCH
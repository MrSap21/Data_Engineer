﻿CREATE PROCEDURE [idfwba].[AssetAddOrUpdateZip]
(
    @pAssetID                       AS NVARCHAR(20),  --If Null or a non existing AssetID, a new Asset is inserted
    @pAssetName                     AS NVARCHAR(255),
    @pAssetDefinition               AS NVARCHAR(255),
	@pAssetTypeID                   AS NVARCHAR(20),  --LOVID from RefLOV where LOVSetID=
    @pAssetSubTypeID                AS NVARCHAR(20),  --LOVID from RefLOV where LOVSetID=
    @pAssetMD5                      AS NVARCHAR(255),
    @pParentAssetID                 AS NVARCHAR(20),
	@pAssetCurrentLocation          AS NVARCHAR(255),
	@pFeedId                        AS NVARCHAR(255), --FK to Feed.FeedID
    @pInformationClassificationID   AS NVARCHAR(255), --LOVID from RefLOV where LOVSetID=. Inherited from Feed.
    @pEntityDescription             AS NVARCHAR(255),
    @pAttributeDescription          AS NVARCHAR(255),
    @pAttributeEntityDescription    AS NVARCHAR(255),
    @pNumberOfRecords               AS NVARCHAR(20),
    @pNumberOfBytes                 AS NVARCHAR(20),
    @pDTCreated                     AS NVARCHAR(21), --Format: 20200430 16:58:47. If not informed, default GETDATE() if not informed
    @pUserCreated                   AS NVARCHAR(100),--Default SYSTEM_USER (login user) if not informed
    @pStatusID                      AS NVARCHAR(20), --Initial status of the Asset to insert in AssetStatus.
                                                       --Possible values are LOVID from RefLOV where LOVSetID=24
                                                       --If the status of a existing Asset needs to be updated, use idfwba.AssetStatusChange SP instead
    @pKeepValueFlag                 AS NCHAR(1),      --Update behaviour when a parameter comes empty: 
                                                       --'1', the attribute keeps its value.
                                                       --'0', the attribute is set to NULL. If the target column is set as NOT NULL, an error will be returned
	@preturnAssetID					AS  VARCHAR(20) output,
	@preturnProcedureStatus			AS  VARCHAR(20) output,
	@preturnProcedureMessage		AS  VARCHAR(MAX) output
) 
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================
--
-- FileName    : AssetAddOrUpdateZip.sql
-- Description : Insert or update a new row in Asset and AssetStatus when AssetAddOrUpdate is called from another sp
--
-- =============================================================================
--
-- Change History
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN
    BEGIN TRY
        
            /*Generic output variables*/
            DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
            DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';
			
            /*Specific variables*/

            /*Convert empty strings into Null*/
            SET @pAssetID                               = NULLIF(@pAssetID                     ,'');
            SET @pAssetName                             = NULLIF(@pAssetName                   ,'');
            SET @pAssetDefinition                       = NULLIF(@pAssetDefinition             ,'');
            SET @pAssetTypeID                           = NULLIF(@pAssetTypeID                 ,'');
            SET @pAssetSubTypeID                        = NULLIF(@pAssetSubTypeID              ,'');
            SET @pAssetMD5                              = NULLIF(@pAssetMD5                    ,'');
            SET @pParentAssetID                         = NULLIF(@pParentAssetID               ,'');
            SET @pAssetCurrentLocation                  = NULLIF(@pAssetCurrentLocation        ,'');
            SET @pFeedId                                = NULLIF(@pFeedId                      ,'');
            SET @pInformationClassificationID           = NULLIF(@pInformationClassificationID ,'');
            SET @pEntityDescription                     = NULLIF(@pEntityDescription           ,'');
            SET @pAttributeDescription                  = NULLIF(@pAttributeDescription        ,'');
            SET @pAttributeEntityDescription            = NULLIF(@pAttributeEntityDescription  ,'');
            SET @pNumberOfRecords                       = NULLIF(@pNumberOfRecords             ,'');
            SET @pNumberOfBytes                         = NULLIF(@pNumberOfBytes               ,'');
            SET @pDTCreated                             = NULLIF(@pDTCreated                   ,'');
            SET @pUserCreated                           = NULLIF(@pUserCreated                 ,'');
            SET @pStatusID                              = NULLIF(@pStatusID                    ,'');
            SET @pKeepValueFlag                         = NULLIF(@pKeepValueFlag               ,'');

            /*Set default values*/
            SET @pDTCreated                             = ISNULL(@pDTCreated        ,GETDATE());   --Default current date
            SET @pUserCreated                           = ISNULL(@pUserCreated      ,SYSTEM_USER); --Default user
            SET @pStatusID                              = ISNULL(@pStatusID         ,'24001'); --Default 'Active'
            SET @pKeepValueFlag                         = ISNULL(@pKeepValueFlag    ,'1'    ); --Default keep attribute value if parameter comes empty

       
            IF (NOT @pFeedId IS NULL) AND (@pInformationClassificationID IS NULL OR  @pEntityDescription IS NULL OR @pAssetTypeID IS NULL OR @pAssetSubTypeID IS NULL)
            BEGIN
                SELECT @pInformationClassificationID = ISNULL(@pInformationClassificationID,InformationClassificationID),
                        @pEntityDescription           = ISNULL(@pEntityDescription,EntityDescription),
                        @pAssetTypeID                 = ISNULL(@pAssetTypeID,AssetTypeID),
                        @pAssetSubTypeID              = ISNULL(@pAssetSubTypeID,AssetTypeID)
                FROM idfwba.FEED
                WHERE FeedId = @pFeedId;
            END;

			/*Try UPDATE Asset, if no rows updated then then insert. This is the best performance approach*/
            --Note: AssetStatus is not updated in this SP. If the status of a existing Asset needs to be updated, use idfwba.AssetStatusChange instead
            
			UPDATE idfwba.Asset WITH (TABLOCKX)
               SET AssetName                   = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pAssetName                  , AssetName                  ) ELSE @pAssetName                   END
                 , AssetDefinition             = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pAssetDefinition            , AssetDefinition            ) ELSE @pAssetDefinition             END
                 , AssetTypeID                 = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pAssetTypeID                , AssetTypeID                ) ELSE @pAssetTypeID                 END
                 , AssetSubTypeID              = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pAssetSubTypeID             , AssetSubTypeID             ) ELSE @pAssetSubTypeID              END
                 , AssetMD5                    = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pAssetMD5                   , AssetMD5                   ) ELSE @pAssetMD5                    END
                 , ParentAssetID               = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pParentAssetID              , ParentAssetID              ) ELSE @pParentAssetID               END
                 , AssetCurrentLocation        = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pAssetCurrentLocation       , AssetCurrentLocation       ) ELSE @pAssetCurrentLocation        END
                 , FeedId                      = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pFeedId                     , FeedId                     ) ELSE @pFeedId                      END
                 , InformationClassificationID = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pInformationClassificationID, InformationClassificationID) ELSE @pInformationClassificationID END
                 , EntityDescription           = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pEntityDescription          , EntityDescription          ) ELSE @pEntityDescription           END
                 , AttributeDescription        = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pAttributeDescription       , AttributeDescription       ) ELSE @pAttributeDescription        END
                 , AttributeEntityDescription  = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pAttributeEntityDescription , AttributeEntityDescription ) ELSE @pAttributeEntityDescription  END
                 , NumberOfRecords             = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pNumberOfRecords            , NumberOfRecords            ) ELSE @pNumberOfRecords             END
                 , NumberOfBytes               = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pNumberOfBytes              , NumberOfBytes              ) ELSE @pNumberOfBytes               END
                 , DTCreated                   = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pDTCreated                  , DTCreated                  ) ELSE @pDTCreated                   END
                 , UserCreated                 = CASE @pKeepValueFlag WHEN '1' THEN ISNULL(@pUserCreated                , UserCreated                ) ELSE @pUserCreated                 END
             WHERE AssetID = @pAssetID;
			
			

            IF @@ROWCOUNT = 0
                BEGIN
					/*insert into idfwba.assetLogging(operation, impacted_table, query_text)
					select 'FirstInsert1','Asset', 'INSERT INTO idfwba.Asset (AssetName, AssetDefinition, AssetTypeID, AssetSubTypeID, AssetMD5, ParentAssetID, AssetCurrentLocation, FeedId, InformationClassificationID, EntityDescription, AttributeDescription, AttributeEntityDescription, NumberOfRecords, NumberOfBytes, DTCreated, UserCreated) VALUES ( ''' + ISNULL(@pAssetName,'NULL') + ''', ''' + ISNULL(@pAssetDefinition,'NULL') + ''', ''' + ISNULL(@pAssetTypeID,'NULL') + ''', ''' + ISNULL(@pAssetSubTypeID,'NULL') + ''', ''' + ISNULL(@pAssetMD5,'NULL') + ''', ''' + ISNULL(@pParentAssetID,'NULL') + ''', ''' + ISNULL(@pAssetCurrentLocation,'NULL') + ''', ''' + ISNULL(@pFeedId,'NULL') + ''', ''' + ISNULL(@pInformationClassificationID,'NULL') + ''', ''' + ISNULL(@pEntityDescription,'NULL') + ''', ''' + ISNULL(@pAttributeDescription,'NULL') + ''', ''' + ISNULL(@pAttributeEntityDescription,'NULL') + ''', ''' + ISNULL(@pNumberOfRecords,'NULL') + ''', ''' + ISNULL(@pNumberOfBytes,'NULL') + ''', ''' + ISNULL(@pDTCreated,'NULL') + ''', ''' + ISNULL(@pUserCreated,'NULL') + ''') ' query_text*/
                  
				  /*Insert Asset and get AssetId for later cascade inserts*/
                    INSERT INTO idfwba.Asset WITH (TABLOCKX) (  AssetName, AssetDefinition, AssetTypeID, AssetSubTypeID, AssetMD5, ParentAssetID, AssetCurrentLocation, FeedId
                                                   , InformationClassificationID, EntityDescription, AttributeDescription, AttributeEntityDescription
                                                   , NumberOfRecords, NumberOfBytes, DTCreated, UserCreated) 
                                  VALUES (  @pAssetName, @pAssetDefinition, @pAssetTypeID, @pAssetSubTypeID, @pAssetMD5, @pParentAssetID, @pAssetCurrentLocation, @pFeedId
                                          , @pInformationClassificationID, @pEntityDescription, @pAttributeDescription, @pAttributeEntityDescription
                                          , @pNumberOfRecords, @pNumberOfBytes, @pDTCreated, @pUserCreated);
                    SET @pAssetID = SCOPE_IDENTITY();


					/*insert into idfwba.assetLogging(operation, impacted_table, query_text)
					select 'FirstInsert2','AssetStatus', 'INSERT INTO idfwba.AssetStatus (AssetID,StatusID,DTEffectiveFrom,DTEffectiveTo,DTCreated,UserCreated) VALUES (''' + @pAssetID + ''', ''' + @pStatusID + ''', ''' + @pDTCreated + ''', NULL, ''' + @pDTCreated + ''', ''' + @pUserCreated + ''') ' query_text*/
                    /*Insert AssetStatus*/
                    INSERT INTO idfwba.AssetStatus WITH (TABLOCKX) (  AssetID,   StatusID,   DTEffectiveFrom,   DTEffectiveTo,   DTCreated,   UserCreated)
                                      VALUES (  @pAssetID, @pStatusID,       @pDTCreated,            NULL, @pDTCreated, @pUserCreated)
                    ;

                    SET @vProcedureMessage  = 'Inserted new row';
                END
            ELSE
                SET @vProcedureMessage  = 'Table updated';

            /*Return*/
            SELECT @preturnAssetID=	@pAssetID, @preturnProcedureStatus=@vProcedureStatus, @preturnProcedureMessage=@vProcedureMessage;

    END TRY

    BEGIN CATCH
        
        SELECT @pAssetID AS AssetID
             , '-1' AS ProcedureStatus
             , CONCAT( 'Error number: ',   ERROR_NUMBER(),    '; ', CHAR(13)
                      ,'Error message: ',  ERROR_MESSAGE(),   '; ', CHAR(13)
                      ,'Severity: ',       ERROR_SEVERITY(),  '; ', CHAR(13)
                      ,'State: ',          ERROR_STATE(),     '; ', CHAR(13)
                      ,'Procedure name: ', ERROR_PROCEDURE(), '; ', CHAR(13)
                      ,'Procedure line: ', ERROR_LINE(),      '; ', CHAR(13)
                     ) AS ProcedureMessage
        ;
    END CATCH;
END;

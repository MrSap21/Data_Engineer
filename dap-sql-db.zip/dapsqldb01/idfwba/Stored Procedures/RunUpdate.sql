﻿--IF OBJECT_ID ( 'idfwba.RunUpdate', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.RunUpdate;
--GO

CREATE PROCEDURE idfwba.RunUpdate
(
    @pRunLogID              AS NVARCHAR(20),  -- 5
    @pRunningStatus         AS NVARCHAR(10),  -- Free text
    @pNrRecords             AS NVARCHAR(20),  -- 45
    @pDataSizeMB            AS NVARCHAR(20),  -- 1.000.000.000.000
    @pFeedID                AS NVARCHAR(30),  -- ID of the Feed itself -- 23
    @pJobID                 AS NVARCHAR(10),  -- ID of the Feed Job -- 12
    @pTaskID                AS NVARCHAR(10),  -- Task ID in Feed -- 10
    @pPipelineName          AS NVARCHAR(50),  -- If it's a Pipeline -Test
    @pRunID                 AS NVARCHAR(100), -- RunID of the Pipeline - 56465464
    @pAssetID               AS NVARCHAR(10)   -- AssetID
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================
--
-- FileName    : RunUpdate.sql
-- Description : This procedure updates an entity Run Row in idfwba.RUNLOG Table
--
-- =============================================================================
--
-- Change History
-- Name              Date            Description
-- Andrés Gracia     14-JAN-2020     Created
-- Andrés Gracia     31-JAN-2020     Changed comments & parameters due to Task 1678
-- Daniel Santamaria 04-FEB-2020     Moved comments before BEGIN, removed TABs, added Added RunId logic
-- Sergio Pérez      19-FEB-2020     Added Asset ID logic
-- Daniel Santamaria 11-MAR-2020     Fix. DataSizeMB/NrRecords datatype increased to cope with huge file sizes
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN TRY
    DECLARE @vCurrentRunningStatus    AS NVARCHAR(10);
    DECLARE @vCurrentDataSizeMB       AS NVARCHAR(20);
    DECLARE @vCurrentNrRecords        AS NVARCHAR(20);
    DECLARE @vCurrentFeedID           AS NVARCHAR(30);
    DECLARE @vCurrentJobID            AS NVARCHAR(30);
    DECLARE @vCurrentTaskID           AS NVARCHAR(30);
    DECLARE @vCurrentPipelineName     AS NVARCHAR(30);
    DECLARE @vCurrentRunID            AS NVARCHAR(30);
    DECLARE @vCurrentAssetID          AS NVARCHAR(30);
    DECLARE @vProcedureStatus         AS NVARCHAR(1)   = '0';
    DECLARE @vProcedureMessage        AS NVARCHAR(100) = 'OK';
    DECLARE @vNumRowsChanged          AS NVARCHAR(10);

    /*AGO 20200117 - Null values*/
    SET @pRunLogID        = NULLIF(@pRunLogID,'');
    SET @pRunningStatus   = NULLIF(@pRunningStatus,'');
    SET @pNrRecords       = NULLIF(@pNrRecords,'');
    SET @pDataSizeMB      = NULLIF(@pDataSizeMB,'');
    SET @pFeedID          = NULLIF(@pFeedID,'');
    SET @pJobID           = NULLIF(@pJobID,'');
    SET @pTaskID          = NULLIF(@pTaskID,'');
    SET @pPipelineName    = NULLIF(@pPipelineName,'');
    SET @pRunID           = NULLIF(@pRunID,'');
    SET @pAssetID         = NULLIF(@pAssetID,'');

    /*DS  20200204 - Added RunId logic*/
    IF @pRunLogID IS NULL
        SELECT @pRunLogID = RunLogID
        FROM idfwba.RUNLOG
        WHERE JSON_VALUE(RunLogDefinitionJSON, '$.RunID') = @pRunId
    ;

    /*AGO 20200117 - Select current values*/
    SELECT @vCurrentNrRecords       = NrRecords,
           @vCurrentDataSizeMB      = DataSizeMB,
           @vCurrentRunningStatus   = RunLogStatus,
           @vCurrentFeedID          = JSON_VALUE(RunLogDefinitionJSON,'$.FeedID'),
           @vCurrentJobID           = JSON_VALUE(RunLogDefinitionJSON,'$.JobID'),
           @vCurrentTaskID          = JSON_VALUE(RunLogDefinitionJSON,'$.TaskID'),
           @vCurrentPipelineName    = JSON_VALUE(RunLogDefinitionJSON,'$.PipelineName'),
           @vCurrentRunID           = JSON_VALUE(RunLogDefinitionJSON,'$.RunID'),
           @vCurrentAssetID         = JSON_VALUE(RunLogDefinitionJSON,'$.AssetID')
    FROM idfwba.RUNLOG
    WHERE RunLogID = @pRunLogID
    ;

    /*AGO 20200117 - Update clause*/
    UPDATE idfwba.RUNLOG SET
        NrRecords               = COALESCE(@pNrRecords,@vCurrentNrRecords),
        DataSizeMB              = COALESCE(@pDataSizeMB,@vCurrentDataSizeMB),
        RunLogStatus            = COALESCE(@pRunningStatus,@vCurrentRunningStatus),
        RunLogDefinitionJSON    = JSON_MODIFY(JSON_MODIFY(JSON_MODIFY(JSON_MODIFY(JSON_MODIFY(JSON_MODIFY(RunLogDefinitionJSON
                                                                                              ,'$.JobID',COALESCE(@pJobID,@vCurrentJobID))
                                                                                  ,'$.TaskID',COALESCE(@pTaskID,@vCurrentTaskID))
                                                                      ,'$.FeedID',COALESCE(@pFeedID,@vCurrentFeedID))
                                                          ,'$.PipelineName',COALESCE(@pPipelineName,@vCurrentPipelineName))
                                              ,'$.RunID',COALESCE(@pRunID,@vCurrentRunID))
                                              ,'$.AssetID',COALESCE(@pAssetID,@vCurrentAssetID))
    WHERE RunLogID = @pRunLogID
    ;
    SET @vNumRowsChanged = @@ROWCOUNT;

    /*AGO 20200117 - Return values*/
    SELECT @pRunLogID AS RunLogID, @vNumRowsChanged AS Updated_Rows, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;
END TRY

BEGIN CATCH
    DECLARE @msg NVARCHAR(2048) = error_message();
    RAISERROR (@msg, 16, 1);
END CATCH
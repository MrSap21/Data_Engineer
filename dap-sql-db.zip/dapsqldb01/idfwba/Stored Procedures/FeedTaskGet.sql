﻿--IF OBJECT_ID ( 'idfwba.FeedTaskGet', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.FeedTaskGet;
--GO

CREATE PROCEDURE idfwba.FeedTaskGet
(
    @pFeedId             AS NVARCHAR(20)
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================
--
-- FileName    : FeedTaskGet.sql
-- Description : Lists tasks with replaced template values for a given FeedId
--
-- =============================================================================
--
-- Change History
-- Name             Date            Description
-- Victor           10-DEC-2019     First Version
-- Victor           09-JAN-2020     Changed DUMMY_FEEDTASK to FEEDTASK
-- DSantamaria      15-JAN-2020     Adapted to new TASK -> FEEDTASK structure
-- Victor Salesa    11-FEB-2020     Added RemplaceTemplatevalues to get datalake configuration from REF_LOV
-- DSantamaria      11-FEB-2020     Changed ORDER BY to get tasks in the right order
-- DSantamaria      16-NOV-2020     3371-Renamed, normalized and modified to support multiple storage accounts
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN TRY
    -- Select the only row for the valid pattern
    SELECT ft.FeedID         AS FeedID
         , ft.JobID          AS JobID
         , ft.TaskID         AS TaskID
         , ft.ExecutionOrder AS ExecutionOrder
         , t.TaskDescription AS FeedTaskDescription
         , t.TaskComponent   AS FeedTaskComponent
         , idfwba.FeedTemplateReplace(ft.FeedID, ft.FeedTaskJSON, '$$') AS FeedTaskJSON
    FROM idfwba.FeedTask ft
    JOIN idfwba.Task      t ON (t.TaskID = ft.TaskID)
    WHERE ft.FeedId = @pFeedId
    ORDER BY ft.ExecutionOrder ASC
    ;

END TRY

BEGIN CATCH
    DECLARE @msg nvarchar(2048) = error_message()
    RAISERROR (@msg, 16, 1)
END CATCH
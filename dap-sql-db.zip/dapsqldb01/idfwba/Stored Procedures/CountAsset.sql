﻿--IF OBJECT_ID ( 'idfwba.CountAsset', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.CountAsset;
--GO

CREATE PROCEDURE idfwba.CountAsset
(
    @pAssetName	 		AS NVARCHAR(255),	-- BUKITData_20200210.csv
    @pMD5 				AS NVARCHAR(255) 	-- cSXb1GZ2vHd9hfZaMUTPhg==        
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT OFF

BEGIN TRY
	DECLARE @vAssetCount        AS NVARCHAR(2);
	DECLARE	@vProcedureStatus	AS NVARCHAR(1);
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : CountAsset.sql                                                                                                           
-- Description : This procedure checks if an asset exists or not                                                        
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                       
-- Name              Date            Description                                                                                                         
-- Andrés Gracia      10-FEB-2020     Created                  
-- Daniel Santamaria  12-FEB-2020     AssetMD5 changed from NVARCHAR(40) to NVARCHAR(255)
-- Daniel Santamaria  02-MAR-2020     Added 'quarantine' and 'unpacked' exclusion in query
-- Victor Salesa Sanz 23-OCT-2020     hotfix/1.10.4 As AssetName is Renamed for some custom Assets 
--									  we need to check also the AssetDefinition that corresponds with the original FileName
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID ( 'idfwba.CountAsset', 'P' ) IS NOT NULL
	/*AGO 20200210 - Prevent null Asset Name or Asset MD5*/
	IF (@pAssetName IS NULL)
		BEGIN
	   		SET @pAssetName = ''
	  	END
	IF (@pMD5 IS NULL)
		BEGIN
	   		SET @pMD5 = ''
	  	END
	
	/*AGO 20200210 - Select clause*/
	SELECT @vAssetCount  =  count(1)
      FROM idfwba.ASSET
     WHERE (TRIM(AssetName) = TRIM(@pAssetName) or TRIM(AssetDefinition) = TRIM(@pAssetName))
       AND TRIM(AssetMD5)  = TRIM(@pMD5)
       AND UPPER(AssetCurrentLocation) NOT LIKE ('%QUARANTINE%')
       AND UPPER(AssetCurrentLocation) NOT LIKE ('%UNPACKED%')
    ;

	SET @vProcedureStatus	='0';
	/*AGO 20200117 - Return values*/
    SELECT @vAssetCount AS AssetCount,  @vProcedureStatus	AS Procedure_Status;
END TRY

BEGIN CATCH
	DECLARE @msg nvarchar(2048) = error_message()  
  	RAISERROR (@msg, 16, 1)
	SET @vProcedureStatus	='-1';
END CATCH
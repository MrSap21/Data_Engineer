﻿

CREATE PROCEDURE [idfwba].[RenameFileAccordingToPattern]
(
    @pAssetName          AS VARCHAR(255),
    @pFeedID             AS INT
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
BEGIN TRY
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : RenameFileAccordingToPattern.sql                                                                                                                 
-- Description : This procedure will return the file renamed if it should be renamed according to a Pattern                                                                         
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                       
-- Name              Date            Description                                                                                                                                                                                         
-- Victor            19-MAR-2020     First Version        
-- Victor            20-MAR-2020     Created SubstringFromPattern function to avoid DateLength parameter and removed DateLength                            
-- Victor Salesa     20-MAY-2020     Renamed REF_LOV to RefLOV , REF_LOV_SET to REFLOVSet and changed LOVDescription to use new LOVName from now on.  
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
    DECLARE @vTransformEnabled            VARCHAR(200);
	DECLARE @vDate_Pattern                VARCHAR(200);
	/*DECLARE @vDate_Length			      INT;*/
	DECLARE @vDate                        VARCHAR(50);
	DECLARE @vNameWithoutDate             VARCHAR(200);
	DECLARE @vNameWithoutDateAndExtension VARCHAR(200);
	DECLARE @vExtension					  VARCHAR(200);
    DECLARE @vSourceSystem                VARCHAR(50) = 'NA';
    DECLARE @vSupplier                    VARCHAR(50) = 'NA';
    DECLARE @vProcedureStatus AS NVARCHAR(3)  ='1';
    DECLARE @vProcedureMessage AS NVARCHAR(3) ='OK';

    SET @pAssetName     = NULLIF(@pAssetName,'');
    SET @vTransformEnabled   = 'NO'
	SET @vDate               = ''

	/**********************************************  TO BE REPLACED BY JSON PARAMETERS IN FEED **********************************************************************/
    DECLARE @tRenamingFilePatterns TABLE(
        FilePattern NVARCHAR(200),
		DatePattern NVARCHAR(200),
		--DateLength  INT,
        TransformEnabled NVARCHAR(200)
    )

    INSERT INTO @tRenamingFilePatterns VALUES 
        --('20[0-9][0-9][0-1][0-9][0-3][0-9]-[0-2][0-9][0-5][0-9][0-5][0-9]_%_FILE.csv','%20[0-9][0-9][0-1][0-9][0-3][0-9]-[0-2][0-9][0-5][0-9][0-5][0-9]%',/*15,*/'YES'),
        ('20[0-9][0-9][0-1][0-9][0-3][0-9]-[0-2][0-9][0-5][0-9][0-5][0-9]%.%','%20[0-9][0-9][0-1][0-9][0-3][0-9]-[0-2][0-9][0-5][0-9][0-5][0-9]%',/*15,*/'YES'),
		('%20[0-9][0-9][0-1][0-9][0-3][0-9]-[0-2][0-9][0-5][0-9][0-5][0-9]%.%','%20[0-9][0-9][0-1][0-9][0-3][0-9]-[0-2][0-9][0-5][0-9][0-5][0-9]%',/*15,*/'YES')

    -- Select the only row for the valid pattern
    SELECT @vTransformEnabled = TransformEnabled,@vDate_Pattern = DatePattern/*,@vDate_Length = DateLength*/
    FROM @tRenamingFilePatterns WHERE @pAssetName LIKE FilePattern

	/******************************************************************************************************************************************************************/

    IF @vTransformEnabled = 'YES'
	 BEGIN
		IF PATINDEX(@vDate_Pattern,@pAssetName) <> 0
			--SET	@vDate = SUBSTRING(@pAssetName,PATINDEX(@vDate_Pattern,@pAssetName),@vDate_Length);
            SET @vDate = idfwba.SubstringFromPattern(@vDate_Pattern,@pAssetName)
		SET @vNameWithoutDate = REPLACE(@pAssetName,@vDate,'');
		SET @vNameWithoutDateAndExtension = SUBSTRING(@vNameWithoutDate,1,CHARINDEX('.',@vNameWithoutDate,-1)-1) 
		SET @vExtension = SUBSTRING(@vNameWithoutDate,CHARINDEX('.',@vNameWithoutDate,-1),LEN(@vNameWithoutDate))
		SELECT @vSourceSystem = rlsourcesystem.LOVKey, @vSupplier = rlsupplierid.LOVKey 
		FROM idfwba.FEED f 
		LEFT JOIN (
			SELECT LOVID,LOVKey FROM RefLOV WHERE LOVSetID IN
			(SELECT LOVSetID FROM RefLOVSet 
				WHERE LOVSetName LIKE '%Data Sources%')
		) rlsourcesystem
		ON f.SourceSystemID = rlsourcesystem.LOVID
		LEFT JOIN (
			SELECT LOVID,LOVKey FROM RefLOV WHERE LOVSetID IN
			(SELECT LOVSetID FROM RefLOVSet 
				WHERE LOVSetName LIKE '%Data Suppliers%')
		) rlsupplierid
		ON f.SupplierID = rlsupplierid.LOVID
		WHERE FeedID=@pFeedID

		SELECT @vDate = REPLACE(REPLACE(@vDate,'-','_'),'/','_')

		IF NOT(@vNameWithoutDateAndExtension LIKE '\_%' ESCAPE '\')
			SET @vNameWithoutDateAndExtension = '_' + @vNameWithoutDateAndExtension

		SELECT @vSupplier + '_' + @vSourceSystem + @vNameWithoutDateAndExtension +'_'+@vDate+@vExtension AS RenamedAsset, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;
    END
   ELSE
        SELECT @pAssetName AS RenamedAsset, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;
END TRY

BEGIN CATCH
    DECLARE @msg nvarchar(MAX) = error_message();
    RAISERROR (@msg, 16, 1);
    SELECT @pAssetName AS RenamedAsset, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;
END CATCH
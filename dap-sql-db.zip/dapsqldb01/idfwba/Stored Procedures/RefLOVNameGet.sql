﻿--IF OBJECT_ID ( 'idfwba.RefLOVNameGet', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.RefLOVNameGet;
--GO

CREATE PROCEDURE idfwba.RefLOVNameGet
(
    @pRefLOVSetName         AS NVARCHAR(128),
    @pRefLOVKey             AS NVARCHAR(128)
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT OFF
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : RefLOVNameGet.sql                                                                                                           
-- Description : This procedure returns a value from the Reference Tables                                                      
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                       
-- Name              Date            Description                                                                                                         
-- Víctor Salesa     10-FEB-2020     Created  
-- Victor Salesa     20-MAY-2020     Renamed REF_LOV to RefLOV , REF_LOV_SET to REFLOVSet and changed LOVDescription to use new LOVName from now on.                
-- Daniel Santamaria 16-NOV-2020     3371-Renamed and normalized
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN TRY
    /*Generic output variables*/
    DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
    DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';

    /*Specific variables*/
    DECLARE @vLOVName                           AS NVARCHAR(128) = NULL;

    SELECT @vLOVName = LOVName
    FROM idfwba.RefLOV    rl
    JOIN idfwba.RefLOVSet rls ON (rl.LOVSetID = rls.LOVSetID AND rls.ActiveFlag = 1)
    WHERE rls.LOVSetName = @pRefLOVSetName
      AND rl.LOVKey      = @pRefLOVKey
      AND rl.ActiveFlag  = 1
    ;

    /*Return*/
    IF @vLOVName IS NULL  
        BEGIN
            SET @vProcedureStatus = '-1'
            SET @vProcedureMessage = 'Value not found'
        END

    SELECT @vLOVName as Value, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage

END TRY

BEGIN CATCH
    SELECT NULL AS Value
            , '-1' AS ProcedureStatus
            , CONCAT( 'Error number: ',   ERROR_NUMBER(),    '; ', CHAR(13)
                    ,'Error message: ',  ERROR_MESSAGE(),   '; ', CHAR(13)
                    ,'Severity: ',       ERROR_SEVERITY(),  '; ', CHAR(13)
                    ,'State: ',          ERROR_STATE(),     '; ', CHAR(13)
                    ,'Procedure name: ', ERROR_PROCEDURE(), '; ', CHAR(13)
                    ,'Procedure line: ', ERROR_LINE(),      '; ', CHAR(13)
                    ) AS ProcedureMessage
    ;
END CATCH
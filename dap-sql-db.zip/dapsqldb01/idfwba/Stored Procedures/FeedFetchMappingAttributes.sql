﻿--IF OBJECT_ID ( 'idfwba.FeedFetchMappingAttributes', 'P' ) IS NOT NULL
--    DROP PROCEDURE idfwba.FeedFetchMappingAttributes;
--GO

CREATE PROCEDURE idfwba.FeedFetchMappingAttributes
(
    @pFeedId                        AS NVARCHAR(20)
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================
--
-- FileName    : FeedFetchMappingAttributes.sql
-- Description : Creates a Mapping JSON based on FeedId for the linked Entity Attributes
--
-- =============================================================================
--
-- Change History
-- Name               Date            Description
-- Victor Salesa Sanz 14-JUL-2020     Created
-- Victor Salesa Sanz 14-JUL-2020     Renamed by the name provider as FeedFetchMappingAttributes
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN
    BEGIN TRY
        DECLARE @tTransaction VARCHAR(20) = 'tTransaction';
        BEGIN TRAN @tTransaction;

            /*Generic output variables*/
            DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
            DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';
            DECLARE @vProcedureJSON                     AS NVARCHAR(MAX) = '{}'
            DECLARE @jsonResult					        as NVARCHAR(MAX) = '';
            DECLARE @jsonNoMapping                      as NVARCHAR(MAX) = '{"type":"TabularTranslator","typeConversion":true,"typeConversionSettings":{"allowDataTruncation":true,"treatBooleanAsNumber":false}}'

            SELECT @vProcedureJSON  = 
            (
                SELECT 'TabularTranslator' AS [type],
                    JSON_QUERY((
                        SELECT 
                            'String'					   AS [source.type],
                            'String'					   AS [source.physicalType],
                            a.Position					   AS [source.ordinal],
                            a.AttributeName				   AS [sink.name],
                            'String'					   AS [sink.type]
                        FROM Attribute a 
                        JOIN FeedEntity fe 
                            ON fe.EntityID = a.EntityID
                        WHERE fe.FeedID=@pFeedId
                        FOR JSON PATH
                    )) as mappings,
                    CAST(1 AS BIT) AS [typeConversion],
                    JSON_QUERY((
                    SELECT 
                        CAST(1 AS BIT) AS allowDataTruncation,
                        CAST(0 AS BIT) AS treatBooleanAsNumber
                    FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
                    )) as typeConversionSettings
                FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
            )

            /*Return*/
            IF (@vProcedureJSON <> @jsonNoMapping)
                SELECT @vProcedureJSON AS ProcedureJSON , @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;
            ELSE
                SELECT @vProcedureJSON AS ProcedureJSON, '-1' AS ProcedureStatus, 'No Mapping Data Found' AS ProcedureMessage;

        COMMIT TRAN;
    END TRY
    
    BEGIN CATCH
        ROLLBACK TRAN @tTransaction;
        SELECT @vProcedureJSON AS ProcedureJSON
             , '-1' AS ProcedureStatus
             , CONCAT( 'Error number: ',   ERROR_NUMBER(),    '; ', CHAR(13)
                      ,'Error message: ',  ERROR_MESSAGE(),   '; ', CHAR(13)
                      ,'Severity: ',       ERROR_SEVERITY(),  '; ', CHAR(13)
                      ,'State: ',          ERROR_STATE(),     '; ', CHAR(13)
                      ,'Procedure name: ', ERROR_PROCEDURE(), '; ', CHAR(13)
                      ,'Procedure line: ', ERROR_LINE(),      '; ', CHAR(13)
                     ) AS ProcedureMessage
        ;
    END CATCH;
END;
﻿CREATE PROCEDURE [idfwba].[AssetFetchProperties]
(
    @pAssetID                       AS NVARCHAR(20),  --If Null or a non existing AssetID, a matching Feed is searched
                                                      --If existing, some additional properties are returned (Status)
    @pOnlyActiveFeedsFlag           AS NCHAR(1),      --Show Feeds Behaviour: 
                                                       --'1', the query returns the assets whose Feed is active
                                                       --'0', the query returns all assets
    @pAssetName                     AS NVARCHAR(255), --Used to find a matching Feed file_pattern
	@pAssetPath                     AS NVARCHAR(255)  --Used to find a matching Feed folder_pattern
)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET NOCOUNT ON
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================
--
-- FileName    : AssetFetchProperties.sql
-- Description : Search for a valid Feed and return Feed properties, and Asset properties if Asset exists
--
-- =============================================================================
--
-- Change History
-- Name                Date            Description
-- Daniel Santamaria   11-JUN-2020     Created
-- Victor Salesa Sanz  15-JUN-2020     Added @pOnlyActiveFeedsFlag logic to return just active Feeds
-- Daniel Santamaria   18-JUN-2020     Moved pOnlyActiveFeedsFlag default value to the righ section for keeping consistence along SPs
-- Victor Salesa       22-JUN-2020     Added AssetCurrentLocation and AssetCurrentName to the output to get this values when retrieving the AssetName and AssetCurrentLocation in UnpacktoRaw
-- Daniel Santamaria   13-JUL-2020     Added new filter PlatformVersionID. Fixed generic variables data length, code cleansed and normalized to standards
-- Daniel Santamaria   21-JUL-2020     Fixed bug vAssetCurrentName defined with length 50
-- Gaetano D'Errico    12-DEC-2022     US 981057 - MetaData DB optimization
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN
    BEGIN TRY
       
           /*Generic output variables*/
            DECLARE @vProcedureMessage                  NVARCHAR(MAX) = 'OK';
            DECLARE @vProcedureStatus                   NVARCHAR(20)  = '0';

            /*Specific variables*/
            DECLARE @vFeedID                            NVARCHAR(20); --should be int
            DECLARE @vFeedStatusID                      NVARCHAR(20); --should be int
            DECLARE @vAssetJSON                         NVARCHAR(MAX);
            DECLARE @vAssetStatusID                     NVARCHAR(20); --should be int
            DECLARE @vAssetCurrentLocation              NVARCHAR(255);
            DECLARE @vAssetCurrentName                  NVARCHAR(255);
            DECLARE @vNumMatchingFeeds                  int = 0;

            /*Convert empty strings into Null*/
            SET @pAssetID                               = NULLIF(@pAssetID                     ,'');
            SET @pAssetName                             = NULLIF(@pAssetName                   ,'');
            SET @pAssetPath                             = NULLIF(@pAssetPath                   ,'');
            SET @pOnlyActiveFeedsFlag                   = NULLIF(@pOnlyActiveFeedsFlag         ,'');      

            /*Set default values*/
            SET @pOnlyActiveFeedsFlag                   = ISNULL(@pOnlyActiveFeedsFlag         ,'0'); --Default 

            /*Get properties*/
            /*PENDING
               - Split in two queries? For performance, if AssetID is informed we can simplify the query with no LIKE and JOINs to Feed
            */
            SELECT @vFeedId        = f.FeedID
                 , @vFeedStatusID  = fs.StatusID
                 , @vAssetJSON     = JSON_QUERY(f.AssetJSON,'$.properties')
                 , @vAssetStatusID = ast.StatusID
                 , @vAssetCurrentLocation = a.AssetCurrentLocation
                 , @vAssetCurrentName     = a.AssetName
            FROM idfwba.Feed f with (nolock) 
            join idfwba.FeedStatus fs with (nolock) ON 
				f.FeedID = fs.FeedID 
                and fs.DTEffectiveTo IS NULL
				and IIF(@pOnlyActiveFeedsFlag = '1', IIF(fs.StatusID=23001, 1, 0), 1) = 1
            left join idfwba.Asset         a with (nolock) ON (a.AssetID = @pAssetID)
            left join idfwba.AssetStatus ast with (nolock) ON (ast.AssetID = a.AssetID AND ast.DTEffectiveTo IS NULL)
            WHERE @pAssetName LIKE f.FeedNamePattern + '%' escape '\'
              AND @pAssetPath LIKE '%' + f.SourcePathName + '%' escape '\' 
              AND f.PlatformVersionID = 27003 --Gather the ones whose Platform Version is 'V3 Ingestion Framework'

            SET @vNumMatchingFeeds = @@ROWCOUNT;

            --If we have more than one matching feeds, then we can't return a single specific Feed's info, so we set Feed attributes to null 
            --In this case the previous query, even returning several rows, assigns the first fetched one to @vFeedId, @vFeedStatusID andf @vAssetJSON, so the result could be misleading
            IF @vNumMatchingFeeds > 1
                BEGIN
                    SET @vFeedId = NULL;
                    SET @vFeedStatusID = NULL;
                    SET @vAssetJSON = NULL;
                    SET @vAssetCurrentLocation = NULL;
                    SET @vAssetCurrentName = NULL;
                    SET @vProcedureStatus  = '-1' 
                    SET @vProcedureMessage = 'Found several matching feeds. Only one matching feed is allowed.'
                END

            /*Return*/
            SELECT @vNumMatchingFeeds AS NumMatchingFeeds, @vFeedId AS FeedId, @vFeedStatusID AS FeedStatusID, @vAssetJSON AS AssetJSON, @pAssetID AS AssetID, @vAssetStatusID AS AssetStatusID
                 , @vAssetCurrentLocation AS AssetCurrentLocation, @vAssetCurrentName AS AssetCurrentName
                 , @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

       
    END TRY

    BEGIN CATCH
       
        SELECT @vNumMatchingFeeds AS NumMatchingFeeds, @vFeedId AS FeedId, @vFeedStatusID AS FeedStatusID, @vAssetJSON AS AssetJSON, @pAssetID AS AssetID, @vAssetStatusID AS AssetStatusID
             , @vAssetCurrentLocation AS AssetCurrentLocation, @vAssetCurrentName AS AssetCurrentName
             , '-1' AS ProcedureStatus
             , CONCAT( 'Error number: ',   ERROR_NUMBER(),    '; ', CHAR(13)
                      ,'Error message: ',  ERROR_MESSAGE(),   '; ', CHAR(13)
                      ,'Severity: ',       ERROR_SEVERITY(),  '; ', CHAR(13)
                      ,'State: ',          ERROR_STATE(),     '; ', CHAR(13)
                      ,'Procedure name: ', ERROR_PROCEDURE(), '; ', CHAR(13)
                      ,'Procedure line: ', ERROR_LINE(),      '; ', CHAR(13)
                     ) AS ProcedureMessage
        ;
    END CATCH;
END;
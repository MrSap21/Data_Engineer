﻿/*************************** Monthly ********************************/

create   view [idfwba].[vAssetByMonth]
AS
WITH calculate_months (Month_ref) AS (
    select 1 Month_ref
    union all
    SELECT Month_ref + 1
    FROM calculate_months
    WHERE Month_ref < 12
),
assetPerYear (years) AS (
    select distinct YEAR(dtcreated)
    from idfwba.asset with(nolock)
),
feeds (feedid, feedname, dtcreated, month_ref,years) AS (
    select a.feedid, a.feedname, a.dtcreated , b.month_ref, years
    from idfwba.feed a with(nolock)
    cross join calculate_months b
    cross join assetPerYear c
    where FeedFrequencyID = 144
),
assets (num_asset, feedid, mese, anno) AS (
    select count(*) num_asset, a.feedid, month(a.dtcreated) mese, year(a.dtcreated) anno
    from idfwba.asset a with(nolock)
    group by a.feedid, month(a.dtcreated),year(a.dtcreated)
)
select a.feedid, a.feedname, a.dtcreated, a.month_ref [months], IIF(b.num_asset is NULL,0,b.num_asset) num_asset, a.years
			,case 
				when (convert(datetime,cast(a.years as CHAR)+'-'+ cast(a.month_ref as CHAR)+'-1') < format(a.dtcreated,'yyyy-MM-01')) and b.num_asset is null 
					then 'Before feed creation' 
				when (convert(datetime,cast(a.years as CHAR)+'-'+ cast(a.month_ref as CHAR)+'-1') >= format(a.dtcreated,'yyyy-MM-01')) and b.num_asset is null 
					then 'No asset ingested'
				else 'ok'
			 end [check]
from feeds a
left join assets b on
    a.month_ref = b.mese and a.feedid = b.feedid and b.anno = a.years


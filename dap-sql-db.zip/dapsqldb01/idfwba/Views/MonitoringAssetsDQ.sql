﻿CREATE VIEW  [idfwba].[MonitoringAssetsDQ]  AS (
--Create view for ingestion monitoring PBI report daily report in Direct Query
SELECT 
		CASE WHEN AssetCurrentLocation like '/wrangled%' THEN 'Wrangled' 
			 WHEN AssetCurrentLocation like 'quarantine/%' THEN 'Quarantine'
			 when (Zip_ProcFlg = 1  or  assetname  like '%.zip' ) and AssetCurrentLocation like 'unpacked in /raw/%'  THEN 'Unpacked'
			 WHEN datediff(mi, a.DTCreated, GETDATE()) <= 30 THEN 'Processing' 
			 WHEN datediff(mi, a.DTCreated, GETDATE()) > 30 then 'Blocked' 
			 ELSE 'NA' END AS AssetFlagZip, 
		AssetID, AssetName, AssetDefinition, ParentAssetID, AssetCurrentLocation, a.FeedID, NumberOfRecords, NumberOfBytes, a.DTCreated,
		replace(convert(varchar,dateadd(hour, datediff(hour, 0, a.dtcreated),0), 24), ':','') as StartOfHour 
	 FROM idfwba.Asset  a
	 left join idfwba.Feed f ON a.feedid=f.feedid
	 WHERE CAST(a.DTCreated AS DATE) = CAST(GETDATE() AS DATE)
	 )
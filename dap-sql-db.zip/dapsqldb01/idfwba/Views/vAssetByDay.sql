﻿CREATE   VIEW [idfwba].[vAssetByDay]
AS
WITH calculate_days_not_leap (day_ref) AS (
    select 1 day_ref
    union all
    SELECT day_ref + 1
    FROM calculate_days_not_leap
    WHERE day_ref < 365
),
assetPerYear_not_leap (years) AS (
	select distinct YEAR(dtcreated)
	from idfwba.asset with(nolock)
	where ( (YEAR(dtcreated) % 4 != 0) and (YEAR(dtcreated) % 100 = 0) or (YEAR(dtcreated) % 400 != 0) )
),
calculate_days_leap (day_ref) AS (
    select 1 day_ref
    union all
    SELECT day_ref + 1
    FROM calculate_days_leap
    WHERE day_ref < 366
),
assetPerYear_leap (years) AS (
	select distinct YEAR(dtcreated)
	from idfwba.asset with(nolock)
	where ( (YEAR(dtcreated) % 4 = 0) and (YEAR(dtcreated) % 100 != 0) or (YEAR(dtcreated) % 400 = 0) )
),
feeds (feedid, feedname, dtcreated, day_ref, years) AS (
	select a.feedid, a.feedname, a.dtcreated, b.day_ref, c.years
	from idfwba.feed a with(nolock)
	cross join calculate_days_leap b
	cross join assetPerYear_leap c
	where FeedFrequencyID = 142
	UNION
	select a.feedid, a.feedname, a.dtcreated, b.day_ref, c.years
	from idfwba.feed a with(nolock)
	cross join calculate_days_not_leap b
	cross join assetPerYear_not_leap c
	where FeedFrequencyID = 142
),
assets (num_asset, feedid, giorno, settimana, mese, anno) AS (
	select count(*) num_asset, a.feedid, datepart(dayofyear,a.DTCreated) giorno,  datepart(week,a.DTCreated) settimana, month(a.dtcreated) mese, year(a.dtcreated) anno
	from idfwba.asset a with(nolock)
	group by a.feedid, datepart(dayofyear,a.DTCreated), datepart(week,a.DTCreated), month(a.dtcreated),year(a.dtcreated)
)
select a.feedid,a.feedname, a.dtcreated, a.day_ref [days], IIF(b.num_asset is NULL,0,b.num_asset) num_asset , MONTH(dateadd(DAYOFYEAR,a.day_ref,cast(a.years as char) + '/01/01') -1) [months], a.years
,case 
				when (convert(datetime,cast(a.years as CHAR)+'-'+ cast(MONTH(dateadd(DAYOFYEAR,a.day_ref,cast(a.years as char) + '/01/01') -1) as CHAR)  +  '-1') < format(a.dtcreated,'yyyy-MM-01')) and b.num_asset is null 
					then 'Before feed creation' 
				when (convert(datetime,cast(a.years as CHAR)+'-'+ cast(MONTH(dateadd(DAYOFYEAR,a.day_ref,cast(a.years as char) + '/01/01') -1) as char) +  '-1') >= format(a.dtcreated,'yyyy-MM-01')) and b.num_asset is null 
					then 'No asset ingested'
				else 'ok'
			 end [check] 

from feeds a
left join assets b on
	a.day_ref = b.giorno and a.feedid = b.feedid and b.anno = a.years and MONTH(dateadd(DAYOFYEAR,a.day_ref,cast(a.years as char) + '/01/01') -1) = b.mese




﻿/*************************** Weekly ********************************/

create   view [idfwba].[vAssetByWeek]
AS
WITH calculate_weeks (week_ref) AS (
    select 1 week_ref
    union all
    SELECT week_ref + 1
    FROM calculate_weeks
    WHERE week_ref < 52
), 
assetPerYear (years) AS (
	select distinct YEAR(dtcreated)
	from idfwba.asset with(nolock)
),
feeds (feedid, feedname, dtcreated, week_ref, years) AS (
	select a.feedid, a.feedname, a.dtcreated, b.week_ref, c.years
	from idfwba.feed a with (nolock)
	cross join calculate_weeks b
	cross join assetPerYear c
	where FeedFrequencyID = 143 
),
assets (num_asset, feedid, settimana, mese, anno) AS (
	select count(*) num_asset, a.feedid, datepart(week,a.DTCreated) settimana, month(a.dtcreated) mese, year(a.dtcreated) anno
	from idfwba.asset a with (nolock)
	group by a.feedid, datepart(week,a.DTCreated), month(a.dtcreated),year(a.dtcreated)
)
select a.feedid, a.feedname, a.dtcreated, a.week_ref [weeks], IIF(b.num_asset is NULL,0,b.num_asset) num_asset , a.years, DATEpart(month, DATEADD(month, month(dateadd(wk, a.week_ref -1, cast(a.years as CHAR) + '/01/01')), -1)) [months]
		,case 
				when (convert(datetime,cast(a.years as CHAR)+'-'+ cast(DATEpart(month, DATEADD(month, month(dateadd(wk, a.week_ref -1, cast(a.years as CHAR) + '/01/01')), -1 )) AS char)  +  '-1') < format(a.dtcreated,'yyyy-MM-01')) and b.num_asset is null 
					then 'Before feed creation' 
				when (convert(datetime,cast(a.years as CHAR)+'-'+ cast(DATEpart(month, DATEADD(month, month(dateadd(wk, a.week_ref -1, cast(a.years as CHAR) + '/01/01')), -1 )) AS char)  +  '-1') >= format(a.dtcreated,'yyyy-MM-01')) and b.num_asset is null 
					then 'No asset ingested'
				else 'ok'
			 end [check] 
from feeds a
left join assets b on
	a.week_ref = b.settimana and a.feedid = b.feedid and b.anno = a.years



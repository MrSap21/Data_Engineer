﻿CREATE TABLE [idfwba].[RefLOVSetExport] (
    [LOVSetID]      INT            NOT NULL,
    [TargetLayerID] INT            NOT NULL,
    [DTCreated]     SMALLDATETIME  NULL,
    [UserCreated]   NVARCHAR (128) NULL,
    CONSTRAINT [PK_RefLOVSetExport] PRIMARY KEY CLUSTERED ([LOVSetID] ASC, [TargetLayerID] ASC)
);


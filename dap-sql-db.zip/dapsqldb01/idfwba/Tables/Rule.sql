﻿CREATE TABLE [idfwba].[Rule] (
    [RuleID]          INT             NOT NULL,
    [RuleCode]        NVARCHAR (20)   NOT NULL,
    [RuleName]        NVARCHAR (128)  NOT NULL,
    [RuleDescription] NVARCHAR (1024) NULL,
    [Logic]           NVARCHAR (MAX)  NULL,
    [ScopeID]         INT             NOT NULL,
    [GroupID]         INT             NOT NULL,
    [ActiveFlag]      SMALLINT        NOT NULL,
    [DTCreated]       SMALLDATETIME   NULL,
    [UserCreated]     NCHAR (100)     NULL,
    CONSTRAINT [PK_Rule] PRIMARY KEY CLUSTERED ([RuleID] ASC)
);


﻿CREATE TABLE [idfwba].[FEEDSOURCE] (
    [FeedID]                     INT            NOT NULL,
    [DataOwnerID]                INT            NOT NULL,
    [SystemOfRecordID]           INT            NOT NULL,
    [StrategicDataSourceFlag]    SMALLINT       NOT NULL,
    [DataScope]                  NVARCHAR (500) NOT NULL,
    [Granularity]                NVARCHAR (50)  NOT NULL,
    [History]                    NVARCHAR (250) NULL,
    [ExternalFlag]               SMALLINT       NOT NULL,
    [OrganisationFunctionID]     INT            NOT NULL,
    [ContactEmail]               NVARCHAR (320) NULL,
    [SystemOfRecordOwnerID]      INT            NOT NULL,
    [SystemOfRecordExternalFlag] SMALLINT       NOT NULL,
    [SystemOfRecordFunctionID]   INT            NOT NULL,
    CONSTRAINT [PK_FEEDSOURCE] PRIMARY KEY CLUSTERED ([FeedID] ASC)
);


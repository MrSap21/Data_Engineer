﻿CREATE TABLE [idfwba].[abinitio_test] (
    [product_key]     INT            IDENTITY (1, 1) NOT NULL,
    [column1]         VARCHAR (1000) NULL,
    [column2]         VARCHAR (1000) NULL,
    [column3]         VARCHAR (1000) NULL,
    [column4]         VARCHAR (1000) NULL,
    [LOAD_TS]         DATETIME       NULL,
    [LOAD_USERID]     VARCHAR (1000) NULL,
    [UPD_TS]          DATETIME       NULL,
    [UPD_USERID]      VARCHAR (20)   NULL,
    [SRC_ID]          INT            NULL,
    [BATCH_ID]        VARCHAR (40)   NULL,
    [curr_ind]        CHAR (1)       NULL,
    [SNAPSHOT_BEG_DT] DATE           NULL,
    [SNAPSHOT_END_DT] DATE           NULL,
    [FEEDID]          INT            NULL
);


﻿CREATE TABLE [idfwba].[RefLOVHierarchy] (
    [LOVHierarchySetID] INT            NOT NULL,
    [ParentLOVID]       INT            NOT NULL,
    [ChildLOVID]        INT            NOT NULL,
    [ActiveFlag]        SMALLINT       NOT NULL,
    [DTCreated]         SMALLDATETIME  NULL,
    [UserCreated]       NVARCHAR (128) NULL,
    CONSTRAINT [PK_RefLOVHierarchy] PRIMARY KEY CLUSTERED ([LOVHierarchySetID] ASC, [ParentLOVID] ASC, [ChildLOVID] ASC)
);


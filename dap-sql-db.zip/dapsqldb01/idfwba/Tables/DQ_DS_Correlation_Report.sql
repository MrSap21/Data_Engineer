﻿CREATE TABLE [idfwba].[DQ_DS_Correlation_Report] (
    [Data_Quality_Check_Files] NVARCHAR (100) NOT NULL,
    [Emp_ID]                   DECIMAL (5, 2) NOT NULL,
    [Age_in_Yrs]               DECIMAL (5, 2) NOT NULL,
    [Weight_in_Kgs]            DECIMAL (5, 2) NOT NULL,
    [Year_of_Joining]          DECIMAL (5, 2) NOT NULL,
    [Month_of_Joining]         DECIMAL (5, 2) NOT NULL,
    [Day_of_Joining]           DECIMAL (5, 2) NOT NULL,
    [Age_in_Company]           DECIMAL (5, 2) NOT NULL,
    [Salary]                   DECIMAL (5, 2) NOT NULL,
    [Zip]                      DECIMAL (5, 2) NOT NULL
);


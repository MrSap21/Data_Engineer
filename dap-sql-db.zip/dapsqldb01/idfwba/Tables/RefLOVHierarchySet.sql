﻿CREATE TABLE [idfwba].[RefLOVHierarchySet] (
    [LOVHierarchySetID]   INT            NOT NULL,
    [ParentLOVSetID]      INT            NOT NULL,
    [ChildLOVSetID]       INT            NOT NULL,
    [LOVHierarchySetDesc] NVARCHAR (255) NOT NULL,
    [ActiveFlag]          SMALLINT       NOT NULL,
    [DTCreated]           SMALLDATETIME  NULL,
    [UserCreated]         NVARCHAR (128) NULL,
    CONSTRAINT [PK_RefLOVHierarchySet] PRIMARY KEY CLUSTERED ([LOVHierarchySetID] ASC)
);


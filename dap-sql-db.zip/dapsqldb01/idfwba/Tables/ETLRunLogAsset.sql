﻿CREATE TABLE [idfwba].[ETLRunLogAsset] (
    [ETLRunLogID] INT            NOT NULL,
    [AssetID]     INT            NOT NULL,
    [DTCreated]   SMALLDATETIME  NULL,
    [UserCreated] NVARCHAR (128) NULL,
    CONSTRAINT [PK_ETLRunLogAsset] PRIMARY KEY CLUSTERED ([ETLRunLogID] ASC, [AssetID] ASC)
);


﻿CREATE TABLE [idfwba].[RUNLOG] (
    [RunLogId]             INT            IDENTITY (1, 1) NOT NULL,
    [RunLogTypeId]         NCHAR (10)     NOT NULL,
    [ParentRunLogId]       INT            NULL,
    [RunLogDefinitionJSON] VARCHAR (2000) NULL,
    [DTStart]              DATETIME2 (7)  NULL,
    [DTEnd]                DATETIME2 (7)  NULL,
    [NrRecords]            BIGINT         NULL,
    [DataSizeMB]           BIGINT         NULL,
    [RunLogStatus]         NCHAR (10)     NOT NULL,
    [RunLogOutputJSON]     VARCHAR (MAX)  NULL,
    [RunLogMessageJSON]    VARCHAR (MAX)  NULL,
	[RunID]				   as ( JSON_VALUE(RunLogDefinitionJSON,'$.RunID') )
    CONSTRAINT [PK_RUNLOG] PRIMARY KEY CLUSTERED ([RunLogId] ASC)
);


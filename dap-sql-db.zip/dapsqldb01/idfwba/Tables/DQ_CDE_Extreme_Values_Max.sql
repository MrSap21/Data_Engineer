﻿CREATE TABLE [idfwba].[DQ_CDE_Extreme_Values_Max] (
    [Data_Quality_Check_Files] NVARCHAR (38)  NOT NULL,
    [Value]                    NVARCHAR (38)  NOT NULL,
    [Count]                    INT            NOT NULL,
    [Frequency]                DECIMAL (5, 2) NOT NULL
);


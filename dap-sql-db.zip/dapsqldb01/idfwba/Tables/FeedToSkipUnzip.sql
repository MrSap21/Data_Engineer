CREATE TABLE [idfwba].[FeedToSkipUnzip] (
    [FeedID]        INT     NOT NULL,
    [Should_skip]   BIT     NULL,
    PRIMARY KEY (FeedID),
    FOREIGN KEY ([FeedID]) REFERENCES [idfwba].[Feed](FeedID)
)



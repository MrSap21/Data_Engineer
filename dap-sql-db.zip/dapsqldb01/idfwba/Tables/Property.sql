﻿CREATE TABLE [idfwba].[Property] (
    [PropertyID]   INT             IDENTITY (1, 1) NOT NULL,
    [PropertyName] NVARCHAR (128)  NOT NULL,
    [PropertyDesc] NVARCHAR (1024) NULL,
    [LOVSetFlag]   SMALLINT        NOT NULL,
    [LOVSetID]     INT             NOT NULL,
    [Sequence]     SMALLINT        NULL,
    [ActiveFlag]   SMALLINT        NOT NULL,
    [DTCreated]    SMALLDATETIME   NULL,
    [UserCreated]  NVARCHAR (128)  NULL,
    CONSTRAINT [PK_Property] PRIMARY KEY CLUSTERED ([PropertyID] ASC)
);


﻿CREATE TABLE [idfwba].[TEAM] (
    [TeamID]           INT            IDENTITY (1, 1) NOT NULL,
    [TeamName]         NVARCHAR (255) NOT NULL,
    [FeedApproverFlag] SMALLINT       NOT NULL,
    CONSTRAINT [PK_TEAM] PRIMARY KEY CLUSTERED ([TeamID] ASC)
);


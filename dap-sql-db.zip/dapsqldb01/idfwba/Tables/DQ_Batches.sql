﻿CREATE TABLE [idfwba].[DQ_Batches] (
    [Batch_Id]      NVARCHAR (100) NOT NULL,
    [Feed_Id]       INT            NOT NULL,
    [Asset_Id]      INT            NOT NULL,
    [Owner]         NVARCHAR (100) NOT NULL,
    [Status]        NVARCHAR (100) NOT NULL,
    [Created_Time]  DATETIME       NOT NULL,
    [Modified_Time] DATETIME       NOT NULL
);


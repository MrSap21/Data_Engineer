﻿CREATE TABLE [idfwba].[ASSETHISTORY] (
    [AssetID]        INT             NOT NULL,
    [AssetHistoryID] INT             IDENTITY (1, 1) NOT NULL,
    [DTCreated]      SMALLDATETIME   NULL,
    [Description]    NVARCHAR (4000) NULL,
    CONSTRAINT [PK_ASSETHISTORY] PRIMARY KEY CLUSTERED ([AssetID] ASC, [AssetHistoryID] ASC)
);


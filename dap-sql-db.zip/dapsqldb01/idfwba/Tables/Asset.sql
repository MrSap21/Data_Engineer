﻿CREATE TABLE [idfwba].[Asset] (
    [AssetID]                     INT            IDENTITY (1, 1) NOT NULL,
    [AssetName]                   VARCHAR (255)  NULL,
    [AssetDefinition]             VARCHAR (255)  NULL,
    [AssetTypeID]                 VARCHAR (255)  NULL,
    [AssetSubTypeID]              INT            NULL,
    [AssetMD5]                    VARCHAR (255)  NULL,
    [ParentAssetID]               INT            NULL,
    [AssetCurrentLocation]        VARCHAR (255)  NULL,
    [FeedID]                      INT            NULL,
    [InformationClassificationID] INT            NULL,
    [EntityDescription]           VARCHAR (255)  NULL,
    [AttributeDescription]        VARCHAR (255)  NULL,
    [AttributeEntityDescription]  VARCHAR (255)  NULL,
    [NumberOfRecords]             BIGINT         NULL,
    [NumberOfBytes]               BIGINT         NULL,
    [DTCreated]                   SMALLDATETIME  NULL,
    [UserCreated]                 NVARCHAR (128) NULL,
    CONSTRAINT [PK_ASSET] PRIMARY KEY CLUSTERED ([AssetID] ASC)
);


GO
-- ==============================================
-- Create dml trigger template Azure SQL Database 
-- ==============================================
-- Drop the dml trigger if it already exists

CREATE TRIGGER [idfwba].[CreateFeedTasks] 
   ON   [idfwba].[Asset]
   AFTER  INSERT
AS 
BEGIN
	

delete from [idfwba].[FeedTask] where FeedID = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))

insert into [idfwba].[FeedTask] 
(FeedID,JobID, TaskID,[FeedTaskJSON],ExecutionOrder,DTCreated,UserCreated)
values 
((select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset)), '1', '1',(select '{
   "id":"https://walgreens-dna.com/schemas/Move_File_From_Landing_To_ADLS2.schema.json",
   "title":"Move File between Azure Storage Configuration",
   "type":"task",
   "properties":{
      "source_environment":"landing",
      "FolderPath_SourceStore":"/$$Landing.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))) +'/",
      "FolderPath_DestinationStore":"/$$Rawhopper.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))) +'/",
      "FolderPath_QuarantineStore":"/$$Quarantine.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))) +'/",
      "FolderPath_ArchiveStore":"/$$Archive.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))) +'/",
      "SourceStorageAccountServiceEndPoint":"$$Landing.StorageAccount$$",
      "TargetStorageAccountServiceEndPoint":"$$Rawhopper.StorageAccount$$",
      "QuarantineStorageAccountServiceEndPoint":"$$Quarantine.StorageAccount$$",
      "ArchiveStorageAccountServiceEndPoint":"$$Archive.StorageAccount$$",
      "SourceStorageAccountType":"$$Landing.StorageAccountType$$",
      "TargetStorageAccountType":"$$Rawhopper.StorageAccountType$$",
      "QuarantineStorageAccountType":"$$Quarantine.StorageAccountType$$",
      "ArchiveStorageAccountType":"$$Archive.StorageAccountType$$"
   }
}'), '1', getdate(), 'UIF')
,
((select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset)), '1', '2',(select '{
   "id":"https://walgreens-dna.com/schemas/Move_File_From_ADLS2_To_ADLS2.schema.json",
   "title":"Move File between Azure Storage Configuration",
   "type":"task",
   "properties":{
      "source_environment":"raw",
      "FolderPath_SourceStore":"/$$Raw.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid =  (select max(assetid) from idfwba.Asset))) +'/",
      "FolderPath_DestinationStore":"/$$Cleansed.Container$$/' + (select idfwba.UpdatePathNameToDate(DestinationPathName) from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))) +'/",
	  "FolderPath_DQDestinationStore":"' +(select idfwba.UpdatePathNameToDate(DestinationPathName) from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))) +'/",
      "FolderPath_QuarantineStore":"/$$Quarantine.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))) +'/",
      "SourceStorageAccountServiceEndPoint":"$$Raw.StorageAccount$$",
      "TargetStorageAccountServiceEndPoint":"$$Cleansed.StorageAccount$$",
      "QuarantineStorageAccountServiceEndPoint":"$$Quarantine.StorageAccount$$",
      "SourceStorageAccountType":"$$Raw.StorageAccountType$$",
      "TargetStorageAccountType":"$$Cleansed.StorageAccountType$$",
      "QuarantineStorageAccountType":"$$Quarantine.StorageAccountType$$"
   }
}
'), '3', getdate(), 'UIF')
,
(
(select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset)), '1', '3',(select '{
  "id": "https://walgreens-dna.com/schemas/Unpack_File.schema.json",
  "title": "Unpack File to RAW",
  "type": "task",
  "properties": {
    "source_environment": "rawhopper",
    "FolderPath_SourceStore": "/$$Rawhopper.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))) +'/",
    "FolderPath_DestinationStore": "/$$Raw.Container$$/' + (select SourcePathName from idfwba.Feed where feedId = (select feedid from idfwba.asset where assetid = (select max(assetid) from idfwba.Asset))) +'/",
    "SourceStorageAccountServiceEndPoint": "$$Rawhopper.StorageAccount$$",
    "TargetStorageAccountServiceEndPoint": "$$Raw.StorageAccount$$",
    "SourceStorageAccountType": "$$Rawhopper.StorageAccountType$$",
    "TargetStorageAccountType": "$$Raw.StorageAccountType$$",
    "KeyvaultUrl": "$$KEYVAULT_URL$$",
    "FeedPrivateKeySecretName": "IngestionFramework",
    "FeedPassphraseSecretName": "IngestionFramework"
  }
}'), '2', getdate(), 'UIF'
)

END

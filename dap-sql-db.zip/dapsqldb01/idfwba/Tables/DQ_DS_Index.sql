﻿CREATE TABLE [idfwba].[DQ_DS_Index] (
    [Data_Quality_Check_Files] NVARCHAR (100)   NOT NULL,
    [Completedness]            DECIMAL (38, 14) NOT NULL,
    [Consistency]              DECIMAL (38, 14) NOT NULL,
    [Accuracy]                 DECIMAL (38, 14) NOT NULL,
    [Timeliness]               DECIMAL (38, 14) NOT NULL
);


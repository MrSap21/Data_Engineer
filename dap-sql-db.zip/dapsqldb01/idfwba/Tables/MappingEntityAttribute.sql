﻿CREATE TABLE [idfwba].[MappingEntityAttribute] (
    [MappingID]         INT            NOT NULL,
    [SourceEntityID]    INT            NOT NULL,
    [TargetEntityID]    INT            NOT NULL,
    [SourceAttributeID] INT            NOT NULL,
    [TargetAttributeID] INT            NOT NULL,
    [MappingSequence]   SMALLINT       NULL,
    [MappingJSON]       NVARCHAR (MAX) NULL,
    [DTCreated]         SMALLDATETIME  NULL,
    [UserCreated]       NVARCHAR (128) NULL,
    CONSTRAINT [PK_MappingEntityAttribute] PRIMARY KEY CLUSTERED ([MappingID] ASC, [SourceEntityID] ASC, [TargetEntityID] ASC, [SourceAttributeID] ASC, [TargetAttributeID] ASC)
);


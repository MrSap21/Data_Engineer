﻿CREATE TABLE [idfwba].[Entity] (
    [EntityID]          INT             IDENTITY (1, 1) NOT NULL,
    [EntityCode]        NVARCHAR (32)   NOT NULL,
    [EntityName]        NVARCHAR (128)  NOT NULL,
    [EntityDescription] NVARCHAR (1024) NOT NULL,
    [LayerID]           INT             NOT NULL,
    [DomainID]          INT             NOT NULL,
    [SchemaName]        NVARCHAR (128)  NOT NULL,
    [TableName]         NVARCHAR (128)  NOT NULL,
    [ActiveFlag]        SMALLINT        NOT NULL,
    [DTCreated]         SMALLDATETIME   NULL,
    [UserCreated]       NVARCHAR (128)  NULL,
    CONSTRAINT [PK_Entity] PRIMARY KEY CLUSTERED ([EntityID] ASC)
);


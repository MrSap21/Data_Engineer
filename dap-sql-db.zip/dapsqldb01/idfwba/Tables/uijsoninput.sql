﻿CREATE TABLE [idfwba].[uijsoninput] (
    [ID]            NVARCHAR (100) NOT NULL,
    [FeedId]        INT            NULL,
    [Username]      NVARCHAR (100) NULL,
    [Owner]         NVARCHAR (100) NULL,
    [jsonValue]     NVARCHAR (MAX) NULL,
    [Status]        NVARCHAR (100) NULL,
    [Created_time]  DATETIME2 (7)  NULL,
    [Modified_time] DATETIME2 (7)  NULL,
    [IsActive]      BIT            NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);


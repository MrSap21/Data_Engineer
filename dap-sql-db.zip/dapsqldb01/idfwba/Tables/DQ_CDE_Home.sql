﻿CREATE TABLE [idfwba].[DQ_CDE_Home] (
    [Data_Quality_Check_Files] NVARCHAR (100)  NOT NULL,
    [Distinct_Count]           INT             NOT NULL,
    [Unique]                   DECIMAL (38, 2) NOT NULL,
    [Missing]                  DECIMAL (38, 2) NOT NULL,
    [Missing_Values]           INT             NOT NULL,
    [Infinite]                 DECIMAL (38, 2) NOT NULL,
    [Infinite_n]               INT             NOT NULL,
    [Mean]                     DECIMAL (38, 2) NOT NULL,
    [Minimum]                  INT             NOT NULL,
    [Maximum]                  INT             NOT NULL,
    [Zeros]                    INT             NOT NULL
);


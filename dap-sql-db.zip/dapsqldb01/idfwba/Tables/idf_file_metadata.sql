﻿CREATE TABLE [idfwba].[idf_file_metadata] (
    [Idf_file_registration_id] VARCHAR (MAX) NULL,
    [Idf_file_metadata_id]     VARCHAR (MAX) NULL,
    [column_name]              VARCHAR (MAX) NULL,
    [data_type]                VARCHAR (MAX) NULL,
    [is_nullable]              VARCHAR (MAX) NULL
);


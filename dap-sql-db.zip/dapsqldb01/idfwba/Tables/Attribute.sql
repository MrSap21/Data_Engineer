﻿CREATE TABLE [idfwba].[Attribute] (
    [AttributeId]          INT             IDENTITY (1, 1) NOT NULL,
    [EntityId]             INT             NOT NULL,
    [AttributeName]        NVARCHAR (128)  NOT NULL,
    [AttributeDescription] NVARCHAR (1024) NULL,
    [Position]             SMALLINT        NOT NULL,
    [DataTypeId]           INT             NOT NULL,
    [DataWidth]            INT             NULL,
    [DataLength]           INT             NULL,
    [DataScale]            INT             NULL,
    [DataPrecision]        INT             NULL,
    [ActiveFlag]           SMALLINT        NOT NULL,
    [DTCreated]            SMALLDATETIME   NULL,
    [UserCreated]          NVARCHAR (128)  NULL,
    CONSTRAINT [PK_Attribute] PRIMARY KEY CLUSTERED ([AttributeId] ASC)
);


﻿CREATE TABLE [idfwba].[DQ_RunLog_v2] (
    [assetid]  NVARCHAR (MAX) NULL,
    [feedid]   NVARCHAR (MAX) NULL,
    [corr_log] NVARCHAR (MAX) NULL
);


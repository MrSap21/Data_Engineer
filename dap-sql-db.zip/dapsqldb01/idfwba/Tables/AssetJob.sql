﻿CREATE TABLE [idfwba].[AssetJob](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[AssetID] [int] NOT NULL,
	[JobID] [int] NOT NULL,
	[Status] [varchar](50) NOT NULL,
	[OperationDateTime] [smalldatetime] NOT NULL
) ON [PRIMARY];
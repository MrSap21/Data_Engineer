﻿CREATE TABLE [idfwba].[Mapping] (
    [MappingID]         INT             IDENTITY (1, 1) NOT NULL,
    [MappingName]       NVARCHAR (100)  NOT NULL,
    [MappingDefinition] NVARCHAR (255)  NULL,
    [DocumentName]      NVARCHAR (255)  NULL,
    [DocumentVersion]   NVARCHAR (100)  NULL,
    [DocumentLink]      NVARCHAR (2048) NULL,
    [ETLProcessName]    NVARCHAR (255)  NULL,
    [ActiveFlag]        SMALLINT        NOT NULL,
    [DTCreated]         SMALLDATETIME   NULL,
    [UserCreated]       NVARCHAR (128)  NULL,
    CONSTRAINT [PK_Mapping] PRIMARY KEY CLUSTERED ([MappingID] ASC)
);


﻿CREATE TABLE [TDM].[Wants_Space_Planning_28] (
    [Want] VARCHAR (256) NULL,
    [Type] VARCHAR (32)  NULL
);


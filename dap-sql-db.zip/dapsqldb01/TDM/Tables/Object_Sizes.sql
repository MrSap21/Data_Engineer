﻿CREATE TABLE [TDM].[Object_Sizes] (
    [DataBaseName] VARCHAR (256)   NULL,
    [TableName]    VARCHAR (256)   NULL,
    [UsedSpaceGB]  DECIMAL (18, 8) NULL,
    [NumColumns]   INT             NULL
);


﻿CREATE TABLE [TDM].[Migration_Status] (
    [DataBaseName] VARCHAR (256) NULL,
    [TableName]    VARCHAR (256) NULL,
    [AliasPrefix]  VARCHAR (256) NULL,
    [AliasName]    VARCHAR (256) NULL,
    [Status]       VARCHAR (256) NULL
);


﻿CREATE TABLE [TDM].[Migrated_List] (
    [ObjectName]   VARCHAR (513) NULL,
    [DatabaseName] VARCHAR (256) NULL,
    [TableName]    VARCHAR (256) NULL
);


﻿CREATE TABLE [TDM].[WhiteListed_71] (
    [DataBaseName] VARCHAR (256)   NULL,
    [TableName]    VARCHAR (256)   NULL,
    [UsedSpaceGB]  DECIMAL (18, 8) NULL,
    [NumColumns]   INT             NULL
);


﻿CREATE TABLE [TDM].[Business_Impact_Assessment] (
    [Blank]                      INT            NULL,
    [Name]                       VARCHAR (32)   NULL,
    [Organization]               VARCHAR (64)   NULL,
    [Migration_Group_Number]     VARCHAR (32)   NULL,
    [Migration_Group_Allocation] VARCHAR (64)   NULL,
    [Domain_Alignment]           VARCHAR (32)   NULL,
    [Use_Cases]                  VARCHAR (512)  NULL,
    [Priority]                   VARCHAR (128)  NULL,
    [PHI_Involved]               VARCHAR (32)   NULL,
    [PHI_Drill_Down_Needed]      VARCHAR (256)  NULL,
    [Want]                       VARCHAR (2048) NULL,
    [Wanted_Type]                VARCHAR (64)   NULL,
    [Data_Extracted]             VARCHAR (MAX)  NULL,
    [Extract_Tool]               VARCHAR (4096) NULL,
    [Query_Name]                 VARCHAR (64)   NULL,
    [Query_Logic]                VARCHAR (MAX)  NULL,
    [Extract_Usage]              VARCHAR (MAX)  NULL,
    [Extract_Frequency]          VARCHAR (512)  NULL
);


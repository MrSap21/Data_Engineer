﻿CREATE TABLE [TDM].[Foundational_900] (
    [DataBaseName] VARCHAR (256)   NULL,
    [TableName]    VARCHAR (256)   NULL,
    [UsedSpaceGB]  DECIMAL (18, 8) NULL,
    [NumColumns]   INT             NULL
);


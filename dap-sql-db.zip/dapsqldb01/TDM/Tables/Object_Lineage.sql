﻿CREATE TABLE [TDM].[Object_Lineage] (
    [Wanted_DB]              VARCHAR (256)  NULL,
    [Wanted_Object]          VARCHAR (256)  NULL,
    [Depends_On_DB]          VARCHAR (256)  NULL,
    [Depends_On_Object]      VARCHAR (256)  NULL,
    [Depends_On_Object_Type] VARCHAR (256)  NULL,
    [Depth]                  INT            NULL,
    [Object_Path]            VARCHAR (8000) NULL
);


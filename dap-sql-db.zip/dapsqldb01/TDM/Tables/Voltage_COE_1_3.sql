﻿CREATE TABLE [TDM].[Voltage_COE_1_3] (
    [database_name]        VARCHAR (256)  NULL,
    [table_name]           VARCHAR (256)  NULL,
    [column_name]          VARCHAR (256)  NULL,
    [datatype]             VARCHAR (256)  NULL,
    [business_description] VARCHAR (8000) NULL,
    [source_application]   VARCHAR (256)  NULL,
    [exceptions]           VARCHAR (256)  NULL,
    [comments]             VARCHAR (2048) NULL,
    [sensitive_flag]       VARCHAR (32)   NULL,
    [encrypt_flag]         VARCHAR (32)   NULL,
    [voltage_key]          VARCHAR (64)   NULL,
    [voltage_format_name]  VARCHAR (64)   NULL,
    [project_name]         VARCHAR (256)  NULL,
    [voltage_alias]        VARCHAR (64)   NULL,
    [comments2]            VARCHAR (1024) NULL,
    [comments3]            VARCHAR (1024) NULL
);


﻿CREATE TABLE [TDM].[Migration_Table_Status] (
    [TableName]           VARCHAR (256)   NULL,
    [DatabaseName]        VARCHAR (256)   NULL,
    [SearchableTableName] VARCHAR (256)   NULL,
    [UsedSpaceGB]         DECIMAL (18, 8) NULL,
    [NumColumns]          INT             NULL,
    [AlreadyMigrated]     VARCHAR (256)   NULL,
    [Status]              VARCHAR (256)   NULL
);


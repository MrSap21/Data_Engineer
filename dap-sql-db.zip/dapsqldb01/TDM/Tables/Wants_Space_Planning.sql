﻿CREATE TABLE [TDM].[Wants_Space_Planning] (
    [Want] VARCHAR (256) NULL,
    [Type] VARCHAR (32)  NULL
);


﻿CREATE TABLE [TDM].[Object_Existence] (
    [TableOrView]         CHAR (1)      NULL,
    [DataBaseName]        VARCHAR (256) NULL,
    [TableName]           VARCHAR (256) NULL,
    [Tier]                VARCHAR (256) NULL,
    [SME]                 VARCHAR (256) NULL,
    [CreateTimeStamp]     VARCHAR (32)  NULL,
    [LastAlterName]       VARCHAR (256) NULL,
    [LastAlterTimeStamp]  VARCHAR (32)  NULL,
    [LastAccessTimeStamp] VARCHAR (32)  NULL,
    [AccessCount]         INT           NULL,
    [DaysSinceLastAccess] INT           NULL,
    [LastAccessedDate]    VARCHAR (32)  NULL,
    [NumObjects]          INT           NULL,
    [NumUnused]           INT           NULL,
    [LT_FY2019]           INT           NULL,
    [LT_FY2019_COUNT]     INT           NULL,
    [LT_FY2020]           INT           NULL,
    [LT_FY2020_COUNT]     INT           NULL,
    [LT_FY2021]           INT           NULL,
    [LT_FY2021_COUNT]     INT           NULL
);


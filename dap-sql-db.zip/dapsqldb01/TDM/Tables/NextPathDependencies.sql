﻿CREATE TABLE [TDM].[NextPathDependencies] (
    [Target_Object_Type]            VARCHAR (256) NULL,
    [target_DB]                     VARCHAR (256) NULL,
    [target_object]                 VARCHAR (256) NULL,
    [Fully_Qualified_target_object] VARCHAR (256) NULL,
    [Source_Object_Type]            VARCHAR (256) NULL,
    [Source_DB]                     VARCHAR (256) NULL,
    [Source_Object]                 VARCHAR (256) NULL,
    [Fully_Qualified_Source_Object] VARCHAR (256) NULL,
    [Comment]                       VARCHAR (512) NULL
);


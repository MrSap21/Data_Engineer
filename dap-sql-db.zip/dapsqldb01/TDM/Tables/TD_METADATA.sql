﻿CREATE TABLE [TDM].[TD_METADATA] (
    [DatabaseName]            VARCHAR (256) NULL,
    [TableName]               VARCHAR (256) NULL,
    [ColumnName]              VARCHAR (256) NULL,
    [ColumnId]                INT           NULL,
    [ColumnType]              VARCHAR (16)  NULL,
    [ColumnTypeString]        VARCHAR (256) NULL,
    [ColumnUDTName]           VARCHAR (256) NULL,
    [ColumnLength]            INT           NULL,
    [Nullable]                CHAR (1)      NULL,
    [IdColType]               VARCHAR (32)  NULL,
    [IdColumnTypeString]      VARCHAR (256) NULL,
    [DecimalTotalDigits]      INT           NULL,
    [DecimalFractionalDigits] INT           NULL,
    [PartitioningColumn]      VARCHAR (256) NULL,
    [ColumnPartitionNumber]   INT           NULL
);


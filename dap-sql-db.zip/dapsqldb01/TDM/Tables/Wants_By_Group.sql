﻿CREATE TABLE [TDM].[Wants_By_Group] (
    [Group] VARCHAR (256) NULL,
    [Want]  VARCHAR (256) NULL
);


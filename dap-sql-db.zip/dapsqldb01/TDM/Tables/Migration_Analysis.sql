﻿CREATE TABLE [TDM].[Migration_Analysis] (
    [ID]           INT           NULL,
    [TableName]    VARCHAR (256) NULL,
    [DatabaseName] VARCHAR (256) NULL,
    [Group]        VARCHAR (256) NULL
);


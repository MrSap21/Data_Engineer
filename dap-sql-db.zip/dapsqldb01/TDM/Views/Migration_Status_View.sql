﻿
CREATE   VIEW [TDM].[Migration_Status_View] 
AS 
SELECT 
	LOWER(TRIM([DatabaseName])) + '.' + LOWER(TRIM([TableName])) AS ObjectName,
	LOWER(TRIM([DatabaseName])) AS DatabaseName,
	LOWER(TRIM([TableName])) AS TableName,
	'prdedwdb.' + LOWER(TRIM([TableName])) AS EdwObjectName,
	'prdidldb.' + LOWER(TRIM([TableName])) AS IdlObjectName,
	LOWER(TRIM([AliasPrefix])) AS AliasPrefix,
	LOWER(TRIM([AliasName])) AS AliasName,
	LOWER(TRIM([AliasPrefix])) + '.' + LOWER(TRIM([AliasName])) AS AliasObjectName,
	[Status] AS Status
FROM
	[TDM].[Migration_Status];
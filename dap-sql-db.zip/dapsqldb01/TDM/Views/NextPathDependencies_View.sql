﻿
CREATE   VIEW [TDM].[NextPathDependencies_View]
AS 
SELECT
	LOWER(TRIM([Target_DB])) + '.' + LOWER(TRIM([Target_Object])) AS TargetObjectName,
	LOWER(TRIM([Source_DB])) + '.' + LOWER(TRIM([Source_Object])) AS SourceObjectName,
	* 
	FROM [TDM].[NextPathDependencies];
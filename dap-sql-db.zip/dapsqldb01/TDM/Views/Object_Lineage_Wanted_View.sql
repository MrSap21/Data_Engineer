﻿
CREATE   VIEW [TDM].[Object_Lineage_Wanted_View]
AS
SELECT 
	LOWER(TRIM([Wanted_DB])) + '.' + LOWER(TRIM([Wanted_Object])) AS Wanted_Name,
	LOWER(TRIM([Wanted_DB])) AS Wanted_DB,
	LOWER(TRIM([Wanted_Object])) AS Wanted_Object,
	COUNT([Depth]) AS Consumers
FROM
	[TDM].Object_Lineage
GROUP BY
	Wanted_DB,
	Wanted_Object;
﻿CREATE   VIEW [TDM].[Foundational_900_View] 
AS 
SELECT 
	LOWER(TRIM([DatabaseName])) + '.' + LOWER(TRIM([TableName])) AS ObjectName,
	* 
FROM
	[TDM].[Foundational_900];
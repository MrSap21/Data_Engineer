﻿
CREATE   VIEW [TDM].[WhiteListed_71_View] 
AS 
SELECT 
	LOWER(TRIM([DatabaseName])) + '.' + LOWER(TRIM([TableName])) AS ObjectName,
	* 
FROM
	[TDM].[WhiteListed_71];
﻿CREATE VIEW [TDM].[Object_Lineage_Summary_View]
AS
SELECT 
	[Wanted_DB] + '.' + [Wanted_Object] AS Wanted_Object,
	[Depends_On_DB] + '.' + [Depends_On_Object] AS Depends_On_Object,
	[Depends_On_Object_Type],
	[Depth],
	[Object_Path] 
FROM
	[TDM].Object_Lineage;
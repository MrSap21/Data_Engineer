﻿
CREATE   VIEW [TDM].[Wants_By_Group_BIA_View] 
AS 
SELECT
	COUNT([Organization]) AS Organizations,
	LOWER(TRIM([Want])) as Want,
	CASE WHEN CHARINDEX('.', LOWER(TRIM([Want]))) > 0
		THEN LEFT(LOWER(TRIM([Want])), CHARINDEX('.', LOWER(TRIM([Want]))) - 1) 
	END AS WantDatabaseName,
	CASE WHEN CHARINDEX('.', LOWER(TRIM([Want]))) > 0
		THEN RIGHT(LOWER(TRIM([Want])), CHARINDEX('.', REVERSE(LOWER(TRIM([Want])))) - 1) 
	END AS WantTableName
FROM
	[TDM].[Business_Impact_Assessment]
WHERE TRIM([Want]) <> ''
GROUP BY [Want];
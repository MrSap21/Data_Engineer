﻿
CREATE   VIEW [TDM].[Object_Existence_View] 
AS 
SELECT 
	LOWER(TRIM([DatabaseName])) + '.' + LOWER(TRIM([TableName])) AS ObjectName,
	LOWER(TRIM([DatabaseName])) AS DatabaseName,
	LOWER(TRIM([TableName])) AS TableName,
	[TableOrView],
	[Tier],
	[SME],
	[CreateTimeStamp],
	[LastAlterName],
	[LastAlterTimeStamp],
	[LastAccessTimeStamp],
	[AccessCount],
	[DaysSinceLastAccess],
	[LastAccessedDate],
	[NumObjects],
	[NumUnused],
	[LT_FY2019],
	[LT_FY2019_COUNT],
	[LT_FY2020],
	[LT_FY2020_COUNT],
	[LT_FY2021],
	[LT_FY2021_COUNT]
FROM
	[TDM].[Object_Existence];
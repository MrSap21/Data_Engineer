﻿
CREATE   VIEW [TDM].[Wants_By_Group_View] 
AS 
SELECT
	[Group],
	LOWER(TRIM([Want])) AS Want,
	CASE WHEN CHARINDEX('.', LOWER(TRIM([Want]))) > 0
		THEN LEFT(LOWER(TRIM([Want])), CHARINDEX('.', LOWER(TRIM([Want]))) - 1) 
	END AS WantDatabaseName,
	CASE WHEN CHARINDEX('.', [Want]) > 0
		THEN RIGHT(LOWER(TRIM([Want])), CHARINDEX('.', REVERSE(LOWER(TRIM([Want])))) - 1) 
	END AS WantTableName
FROM
	[TDM].[Wants_By_Group];
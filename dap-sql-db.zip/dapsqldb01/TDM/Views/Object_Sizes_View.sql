﻿
CREATE   VIEW [TDM].[Object_Sizes_View] 
AS 
SELECT 
	LOWER(TRIM([DatabaseName])) + '.' + LOWER(TRIM([TableName])) AS ObjectName,
	* 
FROM
	[TDM].[Object_Sizes];
﻿
CREATE   VIEW [TDM].[Migration_Table_Status_View] 
AS 
SELECT 
	LOWER(TRIM([DatabaseName])) + '.' + LOWER(TRIM([TableName])) AS ObjectName,
	LOWER(TRIM([DatabaseName])) AS DatabaseName,
	LOWER(TRIM([TableName])) AS TableName,
	LOWER(TRIM([SearchableTableName])) AS SearchableTableName,
	[UsedSpaceGB],
	[NumColumns],
	[AlreadyMigrated] AS AlreadyMigrated
FROM
	[TDM].[Migration_Table_Status];
﻿
CREATE   VIEW [TDM].[Wants_To_Needs_View]
AS
SELECT DISTINCT
	OL.Wanted_Name,
	OL.Depends_On_Name,
	OL.Depends_On_Object_Type,
	Ex.[ObjectName],
	Ex.[DataBaseName],
	Ex.[TableName],
	OS.UsedSpaceGB,
	OS.NumColumns,
	Ex.[AccessCount],
	Ex.[DaysSinceLastAccess],
	MA.ObjectName AS MigratedName,
	WL.ObjectName AS WhiteListedName,
	OL.Depth,
	OL.Object_Path
FROM
	TDM.Wants_By_Group_View BU
	LEFT OUTER JOIN
	TDM.[Object_Lineage_View] OL 
	ON BU.[Want] = OL.[Wanted_Name] 
	LEFT OUTER JOIN
	TDM.[Object_Existence_View] Ex 
	ON OL.[Depends_On_Name] = Ex.[ObjectName] 	
	LEFT OUTER JOIN
	TDM.Object_Sizes_View OS
	ON OL.[Depends_On_Name] = OS.[ObjectName] 
	LEFT OUTER JOIN
	TDM.Migration_Analysis_View MA
	ON EX.[ObjectName] = MA.[ObjectName] 
	LEFT OUTER JOIN
	TDM.WhiteListed_71_View WL
	ON EX.[ObjectName] = WL.[ObjectName]
WHERE
	OL.Wanted_Name IS NOT NULL;
--	OL.Depends_On_Object_Type <> 'View';
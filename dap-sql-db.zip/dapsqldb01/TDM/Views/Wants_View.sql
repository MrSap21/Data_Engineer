﻿
CREATE   VIEW [TDM].[Wants_View]
AS
SELECT DISTINCT
	OL.Wanted_Name,
	Ex.[ObjectName] AS [Want],
	Ex.[DataBaseName],
	Ex.[TableName],
	CASE 
		WHEN Ex.[TableOrView] = 'T' THEN 'Table'
		WHEN Ex.[TableOrView] = 'V' THEN 'View'
	END AS TypeFound,
	OS.UsedSpaceGB,
	OS.NumColumns,
	Ex.[AccessCount],
	Ex.[DaysSinceLastAccess],
	OL.Depends_On_Name,
	OL.Depends_On_Object_Type,
	OL.Depth,
	OL.Object_Path
FROM
	TDM.[Object_Lineage_View] OL 
	LEFT OUTER JOIN
	TDM.[Object_Existence_View] Ex 
	ON OL.[Wanted_Name] = Ex.[ObjectName]
	LEFT OUTER JOIN
	TDM.Object_Sizes_View OS
	ON Ex.[ObjectName] = OS.[ObjectName];
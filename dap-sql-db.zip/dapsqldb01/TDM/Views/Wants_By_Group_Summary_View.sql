﻿
CREATE   VIEW [TDM].[Wants_By_Group_Summary_View] 
AS 
SELECT
	COUNT([Group]) AS Groups,
	LOWER(TRIM([Want])) as Want,
	CASE WHEN CHARINDEX('.', LOWER(TRIM([Want]))) > 0
		THEN LEFT(LOWER(TRIM([Want])), CHARINDEX('.', LOWER(TRIM([Want]))) - 1) 
	END AS WantDatabaseName,
	CASE WHEN CHARINDEX('.', LOWER(TRIM([Want]))) > 0
		THEN RIGHT(LOWER(TRIM([Want])), CHARINDEX('.', REVERSE(LOWER(TRIM([Want])))) - 1) 
	END AS WantTableName
FROM
	[TDM].[Wants_By_Group]
WHERE TRIM([Want]) <> ''
GROUP BY [Want];
﻿
CREATE   VIEW [TDM].[Object_Lineage_View]
AS
SELECT 
	LOWER(TRIM([Wanted_DB])) + '.' + LOWER(TRIM([Wanted_Object])) AS Wanted_Name,
	LOWER(TRIM([Wanted_DB])) AS Wanted_DB,
	LOWER(TRIM([Wanted_Object])) AS Wanted_Object,
	LOWER(TRIM([Depends_On_DB])) + '.' + LOWER(TRIM([Depends_On_Object])) AS Depends_On_Name,
	LOWER(TRIM([Depends_On_DB])) AS Depends_On_DB,
	LOWER(TRIM([Depends_On_Object])) AS Depends_On_Object,
	TRIM(Depends_On_Object_Type) AS [Depends_On_Object_Type],
	[Depth],
	[Object_Path]
FROM
	[TDM].Object_Lineage;
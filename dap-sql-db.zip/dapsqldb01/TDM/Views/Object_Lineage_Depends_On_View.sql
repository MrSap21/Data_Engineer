﻿
CREATE   VIEW [TDM].[Object_Lineage_Depends_On_View]
AS
SELECT 
	LOWER(TRIM([Depends_On_DB])) + '.' + LOWER(TRIM([Depends_On_Object])) AS Depends_On_Name,
	LOWER(TRIM([Depends_On_DB])) AS Depends_On_DB,
	LOWER(TRIM([Depends_On_Object])) AS Depends_On_Object,
	TRIM([Depends_On_Object_Type]) AS Depends_On_Object_Type,
	COUNT([Depth]) AS Producers
FROM
	[TDM].Object_Lineage
GROUP BY
	Depends_On_DB,
	Depends_On_Object,
	Depends_On_Object_Type;
﻿CREATE   VIEW [TDM].[Migration_Analysis_View] 
AS 
SELECT 
	LOWER(TRIM([DatabaseName])) + '.' + LOWER(TRIM([TableName])) AS ObjectName,
	LOWER(TRIM([DatabaseName])) AS DatabaseName,
	LOWER(TRIM([TableName])) AS TableName
FROM
	[TDM].[Migrated_List];
﻿CREATE VIEW [idfwbadev].[Unprocessed_Asset_table]
AS
SELECT        a.AssetID, a.AssetName, st.LOVName AS [Asset Status], a.AssetCurrentLocation, a.ParentAssetID, a.FeedID, fd.FeedName
FROM            idfwbadev.Asset AS a INNER JOIN
                         idfwbadev.AssetStatus AS b ON a.AssetID = b.AssetID LEFT OUTER JOIN
                             (SELECT        a.LOVID, a.LOVName
                               FROM            idfwbadev.RefLOV AS a INNER JOIN
                                                         idfwbadev.RefLOVSet AS b ON a.LOVSetID = b.LOVSetID
                               WHERE        (b.LOVSetName = 'Asset Status')) AS st ON st.LOVID = b.StatusID LEFT OUTER JOIN
                         idfwbadev.Feed AS fd ON a.FeedID = fd.FeedID
WHERE        (b.StatusID = '24014') AND (b.DTEffectiveTo IS NULL)
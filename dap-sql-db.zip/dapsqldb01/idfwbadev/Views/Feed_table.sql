﻿CREATE VIEW [idfwbadev].[Feed_table]
AS
SELECT        fd.FeedID, fd.FeedName, ss.LOVName AS [Source System], pr.LOVName AS [Project Name], ct.LOVName AS Country, lg.LOVName AS Language, fd.UserCreated, fd.DTCreated
FROM            idfwbadev.Feed AS fd LEFT OUTER JOIN
                         idfwbadev.RefLOV AS pr ON fd.ProjectID = pr.LOVID LEFT OUTER JOIN
                         idfwbadev.RefLOV AS lg ON fd.LanguageID = lg.LOVID LEFT OUTER JOIN
                         idfwbadev.RefLOV AS ct ON fd.CountryID = ct.LOVID LEFT OUTER JOIN
                         idfwbadev.RefLOV AS ss ON fd.SourceSystemID = ss.LOVID
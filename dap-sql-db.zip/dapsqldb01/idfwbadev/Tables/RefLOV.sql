﻿CREATE TABLE [idfwbadev].[RefLOV] (
    [LOVID]          INT             NOT NULL,
    [LOVSetID]       INT             NOT NULL,
    [LOVKey]         NVARCHAR (128)  NOT NULL,
    [LOVName]        NVARCHAR (128)  NOT NULL,
    [LOVDescription] NVARCHAR (1024) NULL,
    [LOVSequence]    INT             NULL,
    [ActiveFlag]     SMALLINT        NOT NULL,
    [DTCreated]      SMALLDATETIME   NULL,
    [UserCreated]    NVARCHAR (128)  NULL,
    CONSTRAINT [PK_RefLOV] PRIMARY KEY CLUSTERED ([LOVID] ASC)
);


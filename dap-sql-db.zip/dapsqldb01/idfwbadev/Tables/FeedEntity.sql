﻿CREATE TABLE [idfwbadev].[FeedEntity] (
    [FeedID]         INT            NOT NULL,
    [EntityID]       INT            NOT NULL,
    [FeedEntityJSON] NVARCHAR (MAX) NULL,
    [DTCreated]      SMALLDATETIME  NULL,
    [UserCreated]    NVARCHAR (128) NULL,
    CONSTRAINT [PK_FeedEntity] PRIMARY KEY CLUSTERED ([FeedID] ASC, [EntityID] ASC)
);


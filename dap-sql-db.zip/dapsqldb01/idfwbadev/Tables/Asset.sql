﻿CREATE TABLE [idfwbadev].[Asset] (
    [AssetID]                     INT            IDENTITY (1, 1) NOT NULL,
    [AssetName]                   VARCHAR (255)  NULL,
    [AssetDefinition]             VARCHAR (255)  NULL,
    [AssetTypeID]                 VARCHAR (255)  NULL,
    [AssetSubTypeID]              INT            NULL,
    [AssetMD5]                    VARCHAR (255)  NULL,
    [ParentAssetID]               INT            NULL,
    [AssetCurrentLocation]        VARCHAR (255)  NULL,
    [FeedID]                      INT            NULL,
    [InformationClassificationID] INT            NULL,
    [EntityDescription]           VARCHAR (255)  NULL,
    [AttributeDescription]        VARCHAR (255)  NULL,
    [AttributeEntityDescription]  VARCHAR (255)  NULL,
    [NumberOfRecords]             BIGINT         NULL,
    [NumberOfBytes]               BIGINT         NULL,
    [DTCreated]                   SMALLDATETIME  NULL,
    [UserCreated]                 NVARCHAR (128) NULL,
    CONSTRAINT [PK_ASSET] PRIMARY KEY CLUSTERED ([AssetID] ASC)
);


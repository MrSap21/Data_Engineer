﻿CREATE TABLE [idfwbadev].[FeedTask] (
    [FeedID]         INT            NOT NULL,
    [JobID]          SMALLINT       NOT NULL,
    [TaskID]         SMALLINT       NOT NULL,
    [FeedTaskJSON]   VARCHAR (2000) NULL,
    [ExecutionOrder] SMALLINT       NOT NULL,
    [DTCreated]      SMALLDATETIME  NULL,
    [UserCreated]    NVARCHAR (128) NULL,
    CONSTRAINT [PK_FEEDTASK] PRIMARY KEY CLUSTERED ([FeedID] ASC, [JobID] ASC, [TaskID] ASC)
);


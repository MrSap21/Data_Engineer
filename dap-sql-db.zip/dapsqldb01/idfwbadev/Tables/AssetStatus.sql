﻿CREATE TABLE [idfwbadev].[AssetStatus] (
    [AssetID]         INT            NOT NULL,
    [StatusID]        INT            NOT NULL,
    [DTEffectiveFrom] DATETIME       NOT NULL,
    [DTEffectiveTo]   DATETIME       NULL,
    [DTCreated]       SMALLDATETIME  NULL,
    [UserCreated]     NVARCHAR (128) NULL,
    [UIFProcessed]    INT            NULL,
    CONSTRAINT [PK_AssetStatus] PRIMARY KEY CLUSTERED ([AssetID] ASC, [StatusID] ASC, [DTEffectiveFrom] ASC)
);


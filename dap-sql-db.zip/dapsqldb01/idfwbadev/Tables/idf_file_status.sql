﻿CREATE TABLE [idfwbadev].[idf_file_status] (
    [Idf_file_registration_id] NVARCHAR (MAX) NULL,
    [Current_file_status]      NVARCHAR (MAX) NULL,
    [Last_update_time]         NVARCHAR (MAX) NULL,
    [current_status]           NVARCHAR (MAX) NULL,
    [current_location]         NVARCHAR (MAX) NULL,
    [file_size]                NVARCHAR (MAX) NULL
);


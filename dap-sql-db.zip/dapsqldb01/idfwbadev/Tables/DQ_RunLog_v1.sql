﻿CREATE TABLE [idfwbadev].[DQ_RunLog_v1] (
    [assetid] NVARCHAR (MAX) NULL,
    [feedid]  NVARCHAR (MAX) NULL,
    [log]     NVARCHAR (MAX) NULL
);


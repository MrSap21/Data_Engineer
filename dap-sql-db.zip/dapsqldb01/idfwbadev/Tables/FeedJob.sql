﻿CREATE TABLE [idfwbadev].[FeedJob] (
    [FeedID]      INT            NOT NULL,
    [JobID]       SMALLINT       NOT NULL,
    [DTCreated]   SMALLDATETIME  NULL,
    [UserCreated] NVARCHAR (128) NULL,
    CONSTRAINT [PK_FEEDJOB] PRIMARY KEY CLUSTERED ([FeedID] ASC, [JobID] ASC)
);


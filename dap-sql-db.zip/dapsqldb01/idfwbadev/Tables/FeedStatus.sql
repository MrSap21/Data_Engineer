﻿CREATE TABLE [idfwbadev].[FeedStatus] (
    [FeedID]          INT            NOT NULL,
    [StatusID]        INT            NOT NULL,
    [DTEffectiveFrom] DATETIME       NOT NULL,
    [DTEffectiveTo]   DATETIME       NULL,
    [DTCreated]       SMALLDATETIME  NULL,
    [UserCreated]     NVARCHAR (128) NULL,
    CONSTRAINT [PK_FeedStatus] PRIMARY KEY CLUSTERED ([FeedID] ASC, [StatusID] ASC, [DTEffectiveFrom] ASC)
);


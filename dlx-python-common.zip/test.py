import dap_logger.custom_handler as chand
import dap_logger.custom_logger as clog
import os
import time

blob_url = "DefaultEndpointsProtocol=https;AccountName=dnapocdevops;AccountKey=/PyJXOiwdXD4V9/Ubj5zEccRD8LnasuRXLkCQxUa1bPnqzgu9S8N0sHdUH9JdDqbfQria+xRrAMI0b3CEraMTg==;EndpointSuffix=core.windows.net"
os.environ["blob_account_url"] = blob_url

test = clog.get_logger("test", blob_log_file="log.txt", time_interval=1)
test2 = clog.get_logger("test2", blob_log_file="log2.txt", time_interval=1)
test3 = clog.get_logger("test4", blob_log_file="log3.txt", time_interval=1)
for i in range(1, 10):
    test.error("test")
    test2.error("test2")
    test3.error("test3")
    time.sleep(61)

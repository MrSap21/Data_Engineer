import logging
import logging.config
import os
import json

DEFAULT_CONFIG = {
    "version": 1,
    "root": {
        "level": "DEBUG",
        "handlers": ["console"],
        "propagate": False
    },
    "formatters": {
        "standard": {
            "format": "%(asctime)s - [%(levelname)s] - %(name)s  - %(message)s"
        }
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "formatter": "standard",
            "stream": "ext://sys.stdout",
            "level": "DEBUG"
        }
    },
    "loggers": {

    }
}


def get_logger(name, blob_container="logging", console_log_level="DEBUG", azure_monitor_log_level="ERROR", azure_blob_log_level="DEBUG", blob_log_file="example.log", time_interval=60):
    """
    Get Logger from custom library.

    Set InstrumentationKey env key for Azure Log Insights key.
    Set blob_account_url for Azure Blob account Url
    """
    instrumentation_key = os.getenv("InstrumentationKey")
    blob_account_url = os.getenv("blob_account_url")

    DEFAULT_CONFIG["handlers"]["console"]["level"] = console_log_level
    new_handler = {
        "level": "DEBUG",
        "handlers": ["console"],
        "propagate": False
        }
    # Check for instrumentation key in envrironment.
    if instrumentation_key is None:
        print("Instrumentation key not found in environment variables.")
    else:
        DEFAULT_CONFIG["handlers"][f"{name}_azure_monitor"] = {
            "class": "opencensus.ext.azure.log_exporter.AzureLogHandler",
            "formatter": "standard",
            "level": azure_monitor_log_level,
            "connection_string": f"InstrumentationKey={instrumentation_key}"
        }
        new_handler["handlers"].append(f"{name}_azure_monitor")

    # Check for blob account_url in envrironment.
    if blob_account_url is None:
        print("Blob account not found in environment variables.")
    else:
        DEFAULT_CONFIG["handlers"][f"{name}_blob"] = {
            'account_url': blob_account_url,
            'container': blob_container,
            'level': azure_blob_log_level,
            'class': 'dap_logger.custom_handler.BlobStorageTimedRotatingFileHandler',
            'formatter': 'standard',
            'filename': blob_log_file,
            'when': 'M',
            'interval': time_interval,
        }
        new_handler["handlers"].append(f"{name}_blob")

    if name not in DEFAULT_CONFIG['loggers']:
        DEFAULT_CONFIG['loggers'][name] = {}

    DEFAULT_CONFIG['loggers'][name]["handlers"] = new_handler["handlers"]
    DEFAULT_CONFIG['loggers'][name]["level"] = new_handler["level"]
    DEFAULT_CONFIG['loggers'][name]["propagate"] = False

    logging.config.dictConfig(DEFAULT_CONFIG)

    return logging.getLogger(name)

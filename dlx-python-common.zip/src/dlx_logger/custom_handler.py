import logging
import logging.config

import os
import string
import sys

from logging.handlers import TimedRotatingFileHandler
from socket import gethostname

from azure.storage.blob import BlobServiceClient

_PY3 = sys.version_info[0] == 3


_blob_file_storage_logger = logging.getLogger("_BlobStorageFileHandler")


def _formatName(name, params):
    if _PY3:
        # try all possible formattings
        name = string.Template(name).substitute(**params)
        name = name.format(**params)
    return name % params


class _BlobStorageFileHandler(object):
    """
    Blob Storage File handler
    """

    def __init__(self,
                 account_url,
                 container='logging'):
        self.container = container
        self.service = BlobServiceClient.from_connection_string(account_url)
        self.container_created = False

    def put_file_into_storage(self, dirName, fileName):
        """
        Ship the outdated log file to the specified blob container.
        """
        filtered_container = self.service.list_containers(self.container)
        for container_searched in filtered_container:
            if container_searched['name'] == self.container:
                self.container_created = True
                break

        if not self.container_created:
            _blob_file_storage_logger.debug(
                f"creating container {self.container}")
            self.service.create_container(self.container)
            self.container_created = True
        else:
            _blob_file_storage_logger.debug(
                f"Container {self.container} already exists.")
            self.container_created = True
        try:
            file_path = os.path.join(dirName, fileName)
            _blob_file_storage_logger.debug(
                f"Upload {fileName} to {self.container} with {file_path}")
            blob_client = self.service.get_blob_client(
                container=self.container, blob=fileName)
            with open(file_path, "rb") as data:
                blob_client.upload_blob(data)
        except:
            _blob_file_storage_logger.error(
                "Unable to upload file to azure blob storage.")


class BlobStorageTimedRotatingFileHandler(TimedRotatingFileHandler,
                                          _BlobStorageFileHandler):
    """
    Handler for logging to a file, rotating the log file at certain timed
    intervals.

    The outdated log file is shipped to the specified Azure Storage
    blob container and removed from the local file system immediately.
    """

    def __init__(self,
                 account_url,
                 container,
                 filename,
                 when,
                 interval,
                 encoding=None,
                 delay=False,
                 utc=False,
                 ):
        self.meta = {'hostname': gethostname(), 'process': os.getpid()}
        TimedRotatingFileHandler.__init__(self,filename,
                         when=when,
                         interval=interval,
                         backupCount=1,
                         encoding=encoding,
                         delay=delay,
                         utc=utc)
        _BlobStorageFileHandler.__init__(self,
            account_url=account_url,
            container=container
        )

    def emit(self, record):
        """
        Emit a record.

        Output the record to the file, catering for rollover as described
        in doRollover().
        """
        record.hostname = self.meta['hostname']
        super(BlobStorageTimedRotatingFileHandler, self).emit(record)

    def getFilesToDelete(self):
        """
        Determine the files to delete when rolling over.
        """
        dirName, baseName = os.path.split(self.baseFilename)
        fileNames = os.listdir(dirName)
        result = []
        prefix = baseName + "."
        plen = len(prefix)
        for fileName in fileNames:
            if fileName[:plen] == prefix:
                suffix = fileName[plen:]
                if self.extMatch.match(suffix):
                    self.put_file_into_storage(dirName, fileName)
                    result.append(os.path.join(dirName, fileName))
        # delete the stored log file from the local file system immediately
        return result

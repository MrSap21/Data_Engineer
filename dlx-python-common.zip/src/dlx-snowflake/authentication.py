import msal
# Add logging
# hard code tennat id

def __get_access_token__(tennat_id, client_id, client_secret, scope):
    # Populate these values with the values obtained during OAuth setup.
    
    # add details for key valult

    auth_url = f"https://login.microsoftonline.com/{tennat_id}"

    # Prepare the payload for the msal request to obtain JWT authorization token.
    app = msal.ConfidentialClientApplication(
        client_id=client_id,
        client_credential=client_secret,
        authority=auth_url
    )
    response = app.acquire_token_for_client(scopes=scope)

    if not response['error']:
        access_token = response['access_token']
    else:
        error = response['error']
        error_description = response['error_description']
        raise Exception(
            f"Unable to get access_token due to error :{error} and decrition :{error_description}")
    return access_token
    
 def get_access_token( key_prefix_from_key_valut,scope,tennat_id=""):
    pass
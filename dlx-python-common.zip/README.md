# Python Logging Framework

## Overview
Python logging framework is a library to ease logging to azure monitor and azure blob. It send loggings to azure monitor and uploads time rotated(specified by parameter time_intermval) archive file to adls.

## Usage Guidelines
 - Create a Notebook in the Databricks
 - pass the blob URL Conection String and App insights Instrumentation Key as environment Variables "blob_account_url" and "InstrumentationKey"
 - Import get_logger from dap_logger and pass the Time Interval for logs deployment and the name of the Log File as  parameter to the get_logger function.
 - call the loger.handlers
 - Add logger commands.
 - Run the Notebook.

### Available options for logger configuration
- blob_container - Specify logging container name in adls, default value : logging
- console_log_level - Specify logging level for console output, default value : DEBUG
- azure_monitor_log_level - Specify logging level for azure monitor output, default value : ERROR
- azure_blob_log_level - Specify logging level for console output, default value : DEBUG
- blob_log_file - Specify logging file name for adls output, default value : application.log
- time_interval - Specify time interval(in minutes) file rotation and upload to adls, default value : 60


## Code Development steps and guidelines

### Setup System for developments

- Update pip to latest version
```
python -m pip install --upgrade pip
```
- Installed Required Packages
  * Install wheel and check-wheel-contents
  ``` 
  pip install wheel check-wheel-contents 
  ```
 
### Building wheel file
Naviagate to working directory where setup.py exists. Run command to create wheel file.
```
python setup.py bdist_wheel
```

### Verify Wheel file
We can navigate to the dist/ directory in working directory.

### Check wheel package
Navigate to dist directory in working directory. Run command to check wheel package
``` 
check-wheel-contents 
```
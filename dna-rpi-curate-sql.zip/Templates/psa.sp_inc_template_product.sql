﻿CREATE PROC [psa].[sp_inc_XXXX_product] @tableName [varchar](max),@serveETLRunLogID [varchar](max),@psaEntityId [varchar](max) AS

/*************************************************************************************************************************
Procedure Name					: sp_XX_product
Purpose							: Load Incremental data From XXXX into Serve Layer Table
Domain							: Product
ServeLayer Target Tables		: Product				-- 
								  Product Group			-- 
								  Product Status		-- 
								  Measure				-- 
								  Product Property		-- 
								  Product Identifier	-- 
								  Product Party Role	-- 
								  Product Indicator		-- 

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

04-09-2020   :  SB				  Inital Version

**************************************************************************************************************************/

DECLARE			@rowStatusSERCode			BIGINT,
				@rowStatusPSACode			BIGINT,
				@LovRecordSourceID			BIGINT,
				@SCDLOVRecordSourceId		BIGINT,
				@tablecolumns				VARCHAR(500),
				@exec_sql					VARCHAR(1000),
				@inpServeETLRunLogId		VARCHAR (20);
				
BEGIN


--	BEGIN TRANSACTION;
	
 /* Change the items below to correspond to your project */

 SET		@LovRecordSourceID = 12025		   
 SET		@SCDLOVRecordSourceId = 123
 SET		@inpServeETLRunLogId = @serveETLRunLogID

/********************************************************************************************************************************

 1. Table Name  :	Product 

--********************************************************************************************************************************/

	SET @tablecolumns =		'[ProductId]'+
							',[SourceKey]'+
							',[LOVSourceKeyTypeId]'+
							',[ProductName]'+
							',[ProductDescription]'+
							',[LOVBrandId]'+
							',[LOVSubBrandId]'+
							',[LOVRecordSourceId]'+
							',[ParentProductId]'+
							',[SCDStartDate]'+
							',[SCDEndDate]'+
							',[SCDActiveFlag]'+
							',[SCDVersion]'+
							',[SCDLOVRecordSourceId]'+
							',[ETLRunLogId]'+
							',[PSARowKey]'

	PRINT 'Info: Product Table Serve Loading Started';

	PRINT 'Info: Inserting the new version of record if there is a change in the attribute';


	/* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */

	--IF OBJECT_ID('tempdb..#temp_gb_product') IS NOT NULL
	--	DROP TABLE #temp_gb_product;

	--SET @exec_sql = ' SELECT TOP 0 '+@tablecolumns+' INTO #temp_gb_product FROM [sm_ser].[Product]'
	--EXEC(@exec_sql)

	--INSERT INTO		#temp_gb_product
	--SELECT			0							as ProductID,
	--				p.[matnr]					as SourceKey, 
	--				ISNULL(SourceKey.LovID,0)	as LOVSourceKeyTypeId,  -- REMOVE WHEN LOV IS THERE
	--				t.[maktx]					as ProductName,
	--				null						as ProductDescription,
	--				0							as LOVBrandId,
	--				0							as LOVSubBrandId,
	--				@LovRecordSourceID as LovRecordSourceID,
	--				null as [ParentProductId],
	--				null as [SCDStartDate],
	--				null as [SCDEndDate],
	--				null as [SCDActiveFlag],
	--				null as [SCDVersion],
	--				@SCDLOVRecordSourceId as [SCDLOVRecordSourceId],
	--				@inpServeETLRunLogId as ETLRunLogId,
	--				p.[row_id] as PsaRowID
	--FROM			[psa].[uk_sap_mara] p
	--LEFT OUTER JOIN [psa].[uk_sap_makt] t ON (p.[matnr] = t.[matnr] AND t.[spras] = 'E')
	--LEFT OUTER JOIN	(select LovID,LOVKey from [ser].[RefLOV] RefLOV INNER JOIN (select lovsetid from [ser].[RefLOVSet] where lovsetname = 'Source Key Type' and recordsourceid = '12012') lovset on (lovset.lovsetid = reflov.lovsetid) where RefLOV.recordsourceid = '12012') SourceKey ON (SourceKey.LOVKey = 'SAP Material Number')

	/* Perform SCD and Load into Target Table */

	SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	/* 
	
	Change Following Parameters
	
	1.  @l_source_table = N'XXXX' : Needs to be either the Temp table name or the existing table name which contains the records.
	2.  @l_drop_target = 0	: If you don't need to know the PK's which have been created you can drop this.

	*/

	EXEC	[psa].[sp_inc_perform_scd]
		@l_source_table = N'#temp_buk_product',
		@l_target_schema = N'sm_ser',
		@l_target_table = N'Product',
		@l_table_bus_pk = N'SourceKey,LovRecordSourceID',
		@l_table_pk = N'ProductID',
		@l_table_columns = @tablecolumns,
		@l_drop_source = 1, 
		@l_drop_target = 0

	PRINT 'Info: Product Table -> Closing off old Records if exists';

	PRINT 'Info: Product Table Loaded Successfully'; 


/********************************************************************************************************************************

 2. Table Name  :	Product Identifier

--********************************************************************************************************************************/

	SET @tablecolumns =		'[ProductId]'+
							',[LOVIdentifierId]'+
							',[Value]'+
							',[LOVRecordSourceId]'+
							',[SCDStartDate]'+
							',[SCDEndDate]'+
							',[SCDActiveFlag]'+
							',[SCDVersion]'+
							',[SCDLOVRecordSourceId]'+
							',[ETLRunLogId]'+
							',[PSARowKey]'

	PRINT 'Info: Product Identifier Table Serve Loading Started';

	PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

	/* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */

	--IF OBJECT_ID('tempdb..#temp_gb_product_identifier') IS NOT NULL
	--	DROP TABLE #temp_gb_product_identifier;

	--SET @exec_sql = ' SELECT TOP 0 '+@tablecolumns+' INTO #temp_gb_product_identifier FROM [sm_ser].[ProductIdentifier]'
	--EXEC(@exec_sql)

	--INSERT INTO		#temp_gb_product_identifier
	--SELECT
	--	t.ProductId as ProductID,
	--	a.LovID as [LOVIdentifierId],
	--	[ean11] as [Value],
	--	@LovRecordSourceID as LovRecordSourceID,
	--	null as [SCDStartDate],
	--	null as [SCDEndDate],
	--	null as [SCDActiveFlag],
	--	null as [SCDVersion],
	--	@SCDLOVRecordSourceId as [SCDLOVRecordSourceId],
	--	@inpServeETLRunLogId as ETLRunLogId,
	--	p.[row_id] as PsaRowID		
	--FROM [psa].[uk_sap_mara] p
	--INNER JOIN #CRUD_temp_gb_product t ON (p.[matnr] = t.SourceKey)
	--LEFT OUTER JOIN (
	--	select TOP 1 LOVID from [ref].[RefLOV]
	--	where [LOVKey] = 'EAN' and LOVSetID IN (
	--		select LOVSETID from [ref].[RefLOVSet]
	--		where [LOVSetName] = 'Identifier' and ActiveFlag = 1 and RecordSourceID = 12012 )
	--	and ActiveFlag = 1 and RecordSourceID = 12012
	--) a ON (1=1)


	/* Perform SCD and Load into Target Table */

	SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	/* 
	
	Change Following Parameters
	
	1.  @l_source_table = N'XXXX' : Needs to be either the Temp table name or the existing table name which contains the records.

	*/

	EXEC	[psa].[sp_inc_perform_scd]
		@l_source_table = N'#temp_product_identifier',
		@l_target_schema = N'sm_ser',
		@l_target_table = N'ProductIdentifier',
		@l_table_bus_pk = N'ProductID,LOVIdentifierId,LovRecordSourceID',
		@l_table_pk = N'',
		@l_table_columns = @tablecolumns,
		@l_drop_source = 1, 
		@l_drop_target = 1

	PRINT 'Info: ProductIdentifier Table -> Closing off old Records if exists';

	PRINT 'Info: Product Identifier Table Loaded Successfully'; 


/********************************************************************************************************************************

 3. Table Name  :	Product Status

--********************************************************************************************************************************/

	SET @tablecolumns =		'[ProductId]'+
							',[LOVProductStatusSetId]'+
							',[LOVStatusId]'+
							',[EffectiveFrom]'+
							',[EffectiveTo]'+
							',[LOVRecordSourceId]'+
							',[SCDStartDate]'+
							',[SCDEndDate]'+
							',[SCDActiveFlag]'+
							',[SCDVersion]'+
							',[SCDLOVRecordSourceId]'+
							',[ETLRunLogId]'+
							',[PSARowKey]'

	PRINT 'Info: Product Status Table Serve Loading Started';

	PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

	/* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */

	--IF OBJECT_ID('tempdb..#temp_gb_product_status') IS NOT NULL
	--	DROP TABLE #temp_gb_product_status;

	--SET @exec_sql = ' SELECT TOP 0 '+@tablecolumns+' INTO #temp_gb_product_status FROM [sm_ser].[ProductStatus]'
	--EXEC(@exec_sql)

	--INSERT INTO		#temp_gb_product_status
	--SELECT
	--	t.ProductID,
	--	ISNULL(lovset.lovsetid,0) as LOVProductStatusSetId,  -- REMOVE WHEN LOV IS THERE
	--	Status.LovID as LOVStatusId,
	--	NULL as EffectiveFrom,
	--	NULL as EffectiveTo,
	--	@LovRecordSourceID as LovRecordSourceID,
	--	null as [SCDStartDate],
	--	null as [SCDEndDate],
	--	null as [SCDActiveFlag],
	--	null as [SCDVersion],
	--	@SCDLOVRecordSourceId as [SCDLOVRecordSourceId],
	--	@inpServeETLRunLogId as ETLRunLogId,
	--	p.[row_id] as PsaRowID	
	--FROM [psa].[uk_sap_mara] p
	--INNER JOIN #CRUD_temp_gb_product t ON (p.[matnr] = t.SourceKey)
	--LEFT OUTER JOIN	(select  top 1 lovsetid from [ser].[RefLOVSet] where lovsetname = 'material_stage' and recordsourceid = '12025' and activeflag = 1) lovset ON (1=1)
	---- Currently Missing
	--LEFT OUTER JOIN	(select LovID,LOVKey from [ser].[RefLOV] INNER JOIN (select lovsetid from [ser].[RefLOVSet] where lovsetname = 'material_stage' and recordsourceid = '12025') lovset on (lovset.lovsetid = reflov.lovsetid)) Status ON (Status.LOVKey = p.[formt])

	/* Perform SCD and Load into Target Table */

	SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	/* 
	
	Change Following Parameters
	
	1.  @l_source_table = N'XXXX' : Needs to be either the Temp table name or the existing table name which contains the records.

	*/

	EXEC	[psa].[sp_inc_perform_scd]
		@l_source_table = N'#temp_product_status',
		@l_target_schema = N'sm_ser',
		@l_target_table = N'ProductStatus',
		@l_table_bus_pk = N'ProductID,LOVProductStatusSetId,LovRecordSourceID',
		@l_table_pk = N'',
		@l_table_columns = @tablecolumns,
		@l_drop_source = 1, 
		@l_drop_target = 1

	PRINT 'Info: ProductStatus Table -> Closing off old Records if exists';

	PRINT 'Info: Product Status Table Loaded Successfully'; 


/********************************************************************************************************************************

 4. Table Name  :	Product Indicator

--********************************************************************************************************************************/

	SET @tablecolumns =		'[ProductId]'+
							',[LOVIndicatorId]'+
							',[Value]'+
							',[LOVRecordSourceId]'+
							',[SCDStartDate]'+
							',[SCDEndDate]'+
							',[SCDActiveFlag]'+
							',[SCDVersion]'+
							',[SCDLOVRecordSourceId]'+
							',[ETLRunLogId]'+
							',[PSARowKey]'

	PRINT 'Info: Product Indicator Table Serve Loading Started';

	PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

	/* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */

	--IF OBJECT_ID('tempdb..#temp_gb_Product_Indicator') IS NOT NULL
	--	DROP TABLE #temp_gb_Product_Indicator;

	--SET @exec_sql = ' SELECT TOP 0 '+@tablecolumns+' INTO #temp_gb_Product_Indicator FROM [ser].[ProductIndicator]'
	--EXEC(@exec_sql)

	---- GBMR GB SAP Records
	--INSERT INTO		#temp_gb_Product_Indicator
	---- Planning Material IND
	--SELECT		
	--	t.ProductID as ProductID,
	--	ISNULL(Product_Ind.LovID,0) as LOVIndicatorId,  -- MISSING LOV
	--	CASE WHEN p.[formt] = 'B' THEN 'Y' ELSE 'N' END as Value,
	--	@LovRecordSourceID as LovRecordSourceID,
	--	null as [SCDStartDate],
	--	null as [SCDEndDate],
	--	null as [SCDActiveFlag],
	--	null as [SCDVersion],
	--	@SCDLOVRecordSourceId as [SCDLOVRecordSourceId],
	--	@inpServeETLRunLogId as ETLRunLogId,
	--	p.[row_id] as PsaRowID		
	--FROM [psa].[uk_sap_mara] p
	--INNER JOIN #CRUD_temp_gb_product t ON (p.[matnr] = t.SourceKey)
	--LEFT OUTER JOIN	(select top 1 LovID from [ser].[RefLOV] INNER JOIN (select lovsetid from [ser].[RefLOVSet] where lovsetname = 'Indicator - GBMR Product' and recordsourceid = '12034' and activeflag = 1) lovset on (lovset.lovsetid = reflov.lovsetid) where LOVKey = 'planning_material_ind' and activeflag = 1 and recordsourceid = '12014') Product_Ind ON (1=1)

	/* Perform SCD and Load into Target Table */

	SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	/* 
	
	Change Following Parameters
	
	1.  @l_source_table = N'XXXX' : Needs to be either the Temp table name or the existing table name which contains the records.

	*/

	EXEC	[psa].[sp_inc_perform_scd]
		@l_source_table = N'#temp_Product_Indicator',
		@l_target_schema = N'sm_ser',
		@l_target_table = N'ProductIndicator',
		@l_table_bus_pk = N'ProductID,LOVIndicatorId,LovRecordSourceID',
		@l_table_pk = N'',
		@l_table_columns = @tablecolumns,
		@l_drop_source = 1, 
		@l_drop_target = 1

	PRINT 'Info: ProductIndicator Table -> Closing off old Records if exists';
	
	PRINT 'Info: Product Indicator Table Loaded Successfully'; 




/********************************************************************************************************************************

 5. Table Name  :	Product Property

--********************************************************************************************************************************/

	PRINT 'Info: Product Property Table Serve Loading Started';

	PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

	-- GB SAP Records 

	-- Removed from Mappings

	PRINT 'Info: ProductProperty Table -> Closing off old Records if exists';
			
	PRINT 'Info: Product Property Table Loaded Successfully'; 


/********************************************************************************************************************************

 6. Table Name  :	Product Group

--********************************************************************************************************************************/

	PRINT 'Info: Product Group Table Serve Loading Started';

	SET @tablecolumns =		'[ProductGroupId]'+
							',[ProductId]'+
							',[LOVProductGroupSetId]'+
							',[LOVGroupId]'+
							',[ParentProductGroupId]'+
							',[LOVRecordSourceId]'+
							',[SCDStartDate]'+
							',[SCDEndDate]'+
							',[SCDActiveFlag]'+
							',[SCDVersion]'+
							',[SCDLOVRecordSourceId]'+
							',[ETLRunLogId]'+
							',[PSARowKey]'

	-- GB SAP Product Group

	--IF OBJECT_ID('tempdb..#temp_gb_Product_Group') IS NOT NULL
	--	DROP TABLE #temp_gb_Product_Group;

	--SELECT TOP 0 * INTO #temp_gb_Product_Group FROM [ser].[ProductGroup]

	--INSERT INTO		#temp_gb_Product_Group
	---- Material Group
	---- Removed as no LOVs
	--SELECT  
	--	0 as ProductGroupId,
	--	t.ProductId,
	--	-- Check one below as missing from mapping
	--	lovset.lovsetid as LOVProductGroupSetId,
	--	ProductGroup.LOVKey as LOVGroupId,
	--	NULL as ParentProductGroupId,
	--	@LovRecordSourceID as LovRecordSourceID,
	--	null as [SCDStartDate],
	--	null as [SCDEndDate],
	--	null as [SCDActiveFlag],
	--	null as [SCDVersion],
	--	null as [SCDLOVRecordSourceId],
	--	@inpServeETLRunLogId as ETLRunLogId,
	--	p.[row_id] as PsaRowID	
	--FROM [psa].[uk_sap_mara] p
	--INNER JOIN #temp_gb_product t ON (p.[matnr] = t.SourceKey) 
	--	LEFT OUTER JOIN	(select LovID,LOVKey from [ser].[RefLOV] INNER JOIN (select lovsetid from [sm_ser].[RefLOVSet] where lovsetname = 'material_group' and recordsourceid = '12025' and activeflag = 1) lovset on (lovset.lovsetid = reflov.lovsetid) where recordsourceid = '12025' and activeflag = 1) ProductGroup ON (ProductGroup.LOVKey = p.[matkl])
	--	LEFT OUTER JOIN	(select TOP 1 lovsetid from [ser].[RefLOVSet] where lovsetname = 'material_group' and recordsourceid = '12025' and activeflag = 1) lovset ON (1=1)

	/* Perform SCD and Load into Target Table */

	SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	EXEC	[psa].[sp_inc_perform_scd]
		@l_source_table = N'#temp_product_group',
		@l_target_schema = N'sm_ser',
		@l_target_table = N'ProductGroup',
		@l_table_bus_pk = N'ProductID,LOVProductGroupSetId,LovRecordSourceID',
		@l_table_pk = N'ProductGroupId',
		@l_table_columns = @tablecolumns,
		@l_drop_source = 1, 
		@l_drop_target = 1

	PRINT 'Info: ProductGroup Table -> Closing off old Records if exists';

	PRINT 'Info: Product Group Table Loaded Successfully'; 

/********************************************************************************************************************************

 7 . Table Name  :	Product Party Role

--********************************************************************************************************************************/	

	PRINT 'Info: Product Party Role Table Serve Loading Started';

	PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

	SET @tablecolumns =		'[ProductId]'+
							',[PartyRoleId]'+
							',[LOVRecordSourceId]'+
							',[SCDStartDate]'+
							',[SCDEndDate]'+
							',[SCDActiveFlag]'+
							',[SCDVersion]'+
							',[SCDLOVRecordSourceId]'+
							',[ETLRunLogId]'+
							',[PSARowKey]'

	IF OBJECT_ID('tempdb..#temp_Product_Party_Role') IS NOT NULL
		DROP TABLE #temp_Product_Party_Role;

	SET @exec_sql = ' SELECT TOP 0 '+@tablecolumns+' INTO #temp_Product_Party_Role FROM [ser].[ProductPartyRole]'
	EXEC(@exec_sql)

	/*
	INSERT INTO	#temp_Product_Party_Role
	SELECT
		t.ProductId ProductId,
		PartyRole.[PartyRoleId] as PartyRoleId ,
		@LovRecordSourceID as LovRecordSourceID,
		null as [SCDStartDate],
		null as [SCDEndDate],
		null as [SCDActiveFlag],
		null as [SCDVersion],
		@SCDLovRecordSourceID as [SCDLOVRecordSourceId],
		@inpServeETLRunLogId as ETLRunLogId,
		p.[row_id] as PsaRowID	
	FROM [psa].[SAPCOE_BUKSAP_BUKSAPArticle] p
	INNER JOIN		#CRUD_temp_buk_product t ON (p.[row_id] = t.PSARowKey)
	INNER JOIN (
						SELECT top 1 [PartyRoleId]
							FROM [ser].[PartyRole]
							where SourceKey = 'WBA-UK-BTC'
							and SCDActiveFlag = 'Y'
							and LOVRecordSourceID = 12012
							and LOVRoleID IN (select top 1 LovID from ref.reflov 
											where LOVKey = 'Retailer'
											and ActiveFlag = 1
											and RecordSourceID = 12012
											and LOVSetID IN (Select top 1 LovSetID from ref.reflovset where lovsetname = 'Role' and ActiveFlag = 1 and RecordSourceID = '12012'))
					) PartyRole ON (1=1)
	*/

	/* Perform SCD and Load into Target Table */

	SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	EXEC	[psa].[sp_inc_perform_scd]
		@l_source_table = N'#temp_Product_Party_Role',
		@l_target_schema = N'sm_ser',
		@l_target_table = N'ProductPartyRole',
		@l_table_bus_pk = N'ProductID,PartyRoleId,LovRecordSourceID',
		@l_table_pk = N'',
		@l_table_columns = @tablecolumns,
		@l_drop_source = 1, 
		@l_drop_target = 1

	PRINT 'Info: ProductPartyRole Table -> Closing off old Records if exists';

	PRINT 'Info: ProductPartyRole Table Incremental Load Completed Successfully'; 

/********************************************************************************************************************************

 8 . Table Name  :	Product Characteristic

--********************************************************************************************************************************/	

	PRINT 'Info: Product Characteristic Table Serve Loading Started';

	PRINT 'Info: Inserting the new version of record if there is achange in the attribute';

	SET @tablecolumns =		'[ProductId]'+
							',[LOVCharacteristicId]'+
							',[Value]'+
							',[LOVRecordSourceId]'+
							',[SCDStartDate]'+
							',[SCDEndDate]'+
							',[SCDActiveFlag]'+
							',[SCDVersion]'+
							',[SCDLOVRecordSourceId]'+
							',[ETLRunLogId]'+
							',[PSARowKey]'

	-- GB SAP Product Characteristic

	--IF OBJECT_ID('tempdb..#temp_gb_Product_Characteristic') IS NOT NULL
	--	DROP TABLE #temp_gb_Product_Characteristic;

	--SELECT TOP 0 * INTO #temp_gb_Product_Characteristic FROM [ser].[ProductCharacteristic]

	--INSERT INTO		#temp_gb_Product_Characteristic
	---- Size and Dimensions
	--SELECT
	--	t.ProductId ProductId,
	--	ISNULL(ProductGroup.LovID,0) as [LOVCharacteristicId],  -- REMOVE WHEN LOVS AVAILBLE
	--	[groes] as Value,
	--	@LovRecordSourceID as LovRecordSourceID,
	--	null as [SCDStartDate],
	--	null as [SCDEndDate],
	--	null as [SCDActiveFlag],
	--	null as [SCDVersion],
	--	null as [SCDLOVRecordSourceId],
	--	@inpServeETLRunLogId as ETLRunLogId,
	--	p.[row_id] as PsaRowID	
	--FROM [psa].[uk_sap_mara] p
	--INNER JOIN #temp_gb_product t ON (p.[matnr] = t.SourceKey)
	--LEFT OUTER JOIN	(select LovID,LOVKey from [ser].[RefLOV] INNER JOIN (select lovsetid from [ser].[RefLOVSet] where lovsetname = 'GB_SAP_Product_Characteristics' and recordsourceid = '12025') lovset on (lovset.lovsetid = reflov.lovsetid)) ProductGroup ON (ProductGroup.LOVKey = 'Size and Dimensions')

	/* Perform SCD and Load into Target Table */

	SET @tablecolumns = REPLACE(REPLACE(@tablecolumns,'[',''''),']','''')

	EXEC [psa].[sp_inc_perform_scd]
		@l_source_table = N'#temp_Product_Characteristic',
		@l_target_schema = N'sm_ser',
		@l_target_table = N'ProductCharacteristic',
		@l_table_bus_pk = N'ProductID,LOVCharacteristicId,LovRecordSourceID',
		@l_table_pk = N'',
		@l_table_columns = @tablecolumns,
		@l_drop_source = 1, 
		@l_drop_target = 1	

	PRINT 'Info: ProductCharacteristic Table -> Closing off old Records if exists';

	PRINT 'Info: ProductCharacteristic Table Incremental Load Completed Successfully'; 

/********************************************************************************************************************************

 10 . End of Procedure, Close of processed records.

--********************************************************************************************************************************/	

--	UPDATE [psa].[SAPCOE_BUKSAP_BUKSAPArticle]
--	SET [row_status] = 26002
--	WHERE row_id IN (Select DISTINCT PSARowKey FROM #CRUD_temp_buk_product)

--	DROP TABLE #CRUD_temp_buk_product
--	DROP TABLE #temp_buk_product_gbmr



END
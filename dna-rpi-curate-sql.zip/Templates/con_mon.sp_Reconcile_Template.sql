﻿CREATE PROCEDURE con_mon.sp_Reconcile_Template 
	@assetid BIGINT ,
	@reconcile_type NVARCHAR(200)
AS

BEGIN

	DECLARE @source_total DECIMAL(12,2),
			@target_total DECIMAL(12,2),
			@monitorid BIGINT,
			@Projectid BIGINT,
			@Feedid BIGINT,
			@AssetName nvarchar(500),
			@success_ind BIT,
			@final_message NVARCHAR(4000)

	/* Source Count */

	-- Below is a example of a SQL Query to populate the source_total figure.  It should count/sum the relevant field of the asset which has been loaded
	
	--select @source_total = sum(cast( replace(replace([SALES $],'$',''),',','') as decimal(10,2)) )
	--from psa.[TGT_TGTWP_TargetSales]
	--where asset_id = @assetid

	/* Target Count */

	-- Below is a example of a SQL Query to populate the target_total figure.  It sum count/sum the transactionmeasure value field of any transactions created by the asset above.

	--select @target_total = sum(CAST(Value as Decimal(10,2)))
	--from ser.transactionlineitemmeasure tm
	--inner join ser.transactionlineitem tli ON (tm.[TransactionLineItemId] = tli.[TransactionLineItemId])
	--inner join ser.measure m ON (tm.measureid = m.measureid AND m.lovrecordsourceid = 134 and measurename = 'SALES $')
	--where tli.transactionid IN (
	--	select distinct transactionid 
	--	from ser.[transaction]
	--	where sourcekey in (
	--	select concat(CONVERT( nvarchar, convert(Datetime,[Date],20) ,120),[LOCATION NUMBER],[channel - originated]) as SourceKey 
	--	from psa.[TGT_TGTWP_TargetSales]
	--	where asset_id = @assetid
	--	group by  [DATE], [LOCATION NUMBER],[channel - originated]
	--	)
	--	and lovrecordsourceid = 134
	--)


	/*

	Write Into Results table  

	Below SQL should be left alone

	*/

	SELECT	@monitorid = MAX(Monitor_ID),
			@Projectid = MAX([Project_ID]),
			@Feedid = MAX([Feed_ID]),
			@AssetName = MAX([AssetName])
	FROM [con_mon].[Feed_Assets]
	WHERE [AssetID] = @assetid

	IF @source_total IS NULL OR @target_total IS NULL 
	BEGIN
		SET @success_ind = 0
		SET @final_message = 'Reconciliation Failed : Asset No : '+CAST(@assetid AS VARCHAR(200))+' : One of the Totals could not be calculated'
	END
	ELSE IF @source_total <> @target_total 
	BEGIN
		SET @success_ind = 0
		SET @final_message = 'Reconciliation Failed : Asset No : '+CAST(@assetid AS VARCHAR(200))+' : Total out by '+CAST((@source_total-@target_total) AS VARCHAR(200))
	END
	ELSE 
	BEGIN
		SET @success_ind = 1
		SET @final_message = 'Reconciliation Passed : Asset No : '+CAST(@assetid AS VARCHAR(200))+' : Total = '+CAST((@source_total) AS VARCHAR(200))
	END

	INSERT INTO [con_mon].[reconcile_results]
	([Monitor_ID],
	 [Project_ID],
	 [Feed_ID],
	 [Asset_ID],
	 [Asset_Name],
	 [Reconcile_Type],
	 [Pass_Ind],
	 [Result])
	 VALUES
	 (
	 @monitorid,
	 @Projectid,
	 @Feedid,
	 @assetid,
	 @AssetName,
	 @reconcile_type,
	 @success_ind,
	 @final_message
	 )

END
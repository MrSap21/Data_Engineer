﻿CREATE TABLE [extract].[DynamicSAPExtracts]
(
	[SAPTableID] [int] IDENTITY(1,1) NOT NULL,
	[SAPTableName] [varchar](50) NOT NULL,
	[SAPParamsJSON] [varchar](4000) NOT NULL,
	[active] [bit] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE PROC [extract].[uspSAPExtractParams] @p_table_name [VARCHAR](100) AS 

-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : [uspGBAEnvironmentalVars].sql
-- Description : Returns enviromental parameters to ADF Pipelines
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                      
-- Name         Date           Description
-- S Blakemore  05-June-2020   Created

-- -----------------------------------------------------------------------------------------------------------------------------------------------------

BEGIN

	SET NOCOUNT ON
	SET ANSI_NULLS ON
	SET QUOTED_IDENTIFIER ON

	DECLARE @columns NVARCHAR(MAX), @sql NVARCHAR(MAX), @cols NVARCHAR(MAX);
	DECLARE @l_temp VARCHAR(max)

	SELECT @l_temp = SAPParamsJSON 
	from extract.DynamicSAPExtracts
	where SAPTableName = @p_table_name

	IF OBJECT_ID('tempdb..#temp_parameters') IS NOT NULL
	  DROP TABLE #temp_parameters

	SELECT 
	[key],
	CAST(Value as VARCHAR(4000)) as [Value],
	[type]
	INTO #temp_parameters
	FROM OPENJSON(@l_temp) s

	SELECT @columns = STRING_AGG([Key],',') from #temp_parameters

	SET @sql = N'
	SELECT [TYPE], '+STUFF(@columns, 1, 0, '')+' FROM (
	SELECT * 
		FROM #temp_parameters) AS j PIVOT (max(Value) FOR [Key] in 
		   ('+STUFF(REPLACE(@columns, ', p.[', ',['), 1, 0, '')+')) AS p;';

	EXEC sp_executesql @sql

SET NOCOUNT OFF
END
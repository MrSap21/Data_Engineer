﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : Dermstore
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidDC BIGINT,
		@ruleidNN BIGINT,
		@attributeidENDDATE  BIGINT,
		@attributeidPRODUCTSKU BIGINT,		
		@entityid_Dermstore BIGINT,
		@entityid_PSA_Dermstore BIGINT,
		@entityid_His_Dermstore BIGINT,
		@entityid_His_PSA_Dermstore BIGINT;
		

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   Dermstore
 */

SET @entityid_Dermstore = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Dermstore sales data%');
SET @entityid_PSA_Dermstore = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TGTDS_TGTDSEXCEL_DermstoreRetailSales');



SET @entityid_His_Dermstore = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%DermstoreRetailSales Ingestion%');
SET @entityid_His_PSA_Dermstore = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_DermstoreRetailSales');

-- Update Business Key fields in Attribute table   

UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_Dermstore AND attributeName IN 
('ENDDATE','PRODUCTSKU') AND activeflag=1;
UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_Dermstore AND attributeName IN 
('ENDDATE','PRODUCTSKU') AND activeflag=1;


--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_Dermstore,@entityid_His_PSA_Dermstore);




-- Find the attributeId
SET @attributeidENDDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ENDDATE' AND 
entityid = @entityid_Dermstore);
SET @attributeidPRODUCTSKU = (SELECT attributeid FROM psa.attribute WHERE attributename = 'PRODUCTSKU' AND
entityid = @entityid_Dermstore);


PRINT @attributeidENDDATE
PRINT @attributeidPRODUCTSKU


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Dermstore,@attributeidENDDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Dermstore,@attributeidPRODUCTSKU,28004,'28001',NULL,1,@insert_date,@insert_user);


--Insert to RuleEntity for ENDDATE

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_Dermstore,@attributeidENDDATE,28004,'28001',
'{"DateFormatSQLServer":"121"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId

SET @attributeidENDDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ENDDATE' AND 
entityid = @entityid_His_Dermstore);
SET @attributeidPRODUCTSKU = (SELECT attributeid FROM psa.attribute WHERE attributename = 'PRODUCTSKU' AND
entityid = @entityid_His_Dermstore);

PRINT @attributeidENDDATE
PRINT @attributeidPRODUCTSKU


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Dermstore,@attributeidENDDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Dermstore,@attributeidPRODUCTSKU,28004,'28001',NULL,1,@insert_date,@insert_user);


--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_His_PSA_Dermstore,@attributeidENDDATE,28004,'28001',
'{"DateFormatSQLServer":"121"}',1,@insert_date,@insert_user);
END
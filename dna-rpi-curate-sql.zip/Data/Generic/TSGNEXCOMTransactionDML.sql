﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : TSGNEXCOM
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidDC BIGINT,
		@ruleidNN BIGINT,
		@attributeidFILEDATE BIGINT,		
		@attributeidSTYLENUMBER BIGINT,
		@entityid_TSGNEXCOM BIGINT,
		@entityid_PSA_TSGNEXCOM BIGINT,
		@entityid_His_TSGNEXCOM BIGINT,
		@entityid_His_PSA_TSGNEXCOM BIGINT;

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   TSGNEXCOM
 */

 
SET @entityid_TSGNEXCOM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of The Singer Group (Navy) data%');
SET @entityid_PSA_TSGNEXCOM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TSG_TSGEXCEL_TSGNEXCOM');

SET @entityid_His_TSGNEXCOM = (SELECT entityId FROM psa.entity WHERE  schemaname LIKE '%feed%' AND
entityname like '%TSGNEXCOM Ingestion%');
SET @entityid_His_PSA_TSGNEXCOM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_TSGNEXCOM');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_TSGNEXCOM AND attributeName IN 
--('FILEDATE','STYLENUMBER') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_TSGNEXCOM AND attributeName IN 
--('FILEDATE','STYLENUMBER') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_TSGNEXCOM,@entityid_His_PSA_TSGNEXCOM);




-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_TSGNEXCOM);
SET @attributeidSTYLENUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STYLENUMBER' AND 
entityid = @entityid_TSGNEXCOM);

PRINT @attributeidFILEDATE
PRINT @attributeidSTYLENUMBER

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGNEXCOM,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGNEXCOM,@attributeidSTYLENUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_TSGNEXCOM,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"21"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_His_TSGNEXCOM);
SET @attributeidSTYLENUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STYLENUMBER' AND
entityid = @entityid_His_TSGNEXCOM);

PRINT @attributeidFILEDATE
PRINT @attributeidSTYLENUMBER

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGNEXCOM,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGNEXCOM,@attributeidSTYLENUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_His_PSA_TSGNEXCOM,@attributeidDATE,28004,'28001',
'{"DateFormatSQLServer":"21"}',1,@insert_date,@insert_user);
END
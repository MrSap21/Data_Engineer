﻿
IF OBJECT_ID('tempdb..#cf_stored_proc') IS NOT NULL
  DROP TABLE #cf_stored_proc
  

CREATE TABLE #cf_stored_proc
(
	[sp_id] [int] NOT NULL,
	[sp_name] [nvarchar](150) NULL,
	[active_flag] [smallint] NOT NULL,
	[dt_created] [smalldatetime] NULL,
	[user_created] [nchar](100) NULL
)


/*

Enter Your FEED_CONFIGURATION below.  If it doens't exist it'll insert it into the table.

*/

/* Pre Prod Configuration						*/

INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_buk',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_GBFIN_GBFINEXCEL_GBFINRetailerCalendar',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_buk_sap_product',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_gb_sap_product',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_gb_sap_transaction',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_measures',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_organisation',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_party',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_party_role',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_gb_sap_transaction_master',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_le_product',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_sap_mdm_product',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_gbmr_golden_product',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_HistoryDataCapture',1,@insert_date,@insert_user)

-- SAP Customer
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_gb_customer_master',1,@insert_date,@insert_user)


-- Dermstore

INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_DermstoreRetailSales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_TGTDS_TGTDSEXCEL_DermstoreRetailSales',1,@insert_date,@insert_user)


--Skinstore
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_SKINSTORE_No7_WeeklyRetailSales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_SKINSTORE_SG_WeeklyRetailSales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_SKNST_SKNSTEXCEL_SKINSTORE_No7_WeeklyRetailSales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_SKNST_SKNSTEXCEL_SKINSTORE_SG_WeeklyRetailSales',1,@insert_date,@insert_user)

--SDM
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_SDMSGStoreSales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_SDMSGESales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_SDMNo7StoreSales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_SDMNo7ESales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_SDM_SDMEXCEL_SDMNo7ESales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_SDM_SDMEXCEL_SDMNo7StoreSales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_SDM_SDMEXCEL_SDMSGESales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_SDM_SDMEXCEL_SDMSGStoreSales',1,@insert_date,@insert_user)

--TSG
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_TSGAAFES',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_TSGMCXNo7',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_TSGNEXCOM',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_TSG_TSGEXCEL_TSGAAFES',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_TSG_TSGEXCEL_TSGMCXNo7',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_TSG_TSGEXCEL_TSGNEXCOM',1,@insert_date,@insert_user)


--Target
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_TargetSales',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_TGT_TGTWP_TargetSales',1,@insert_date,@insert_user)


--ULTA
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_UltaEDI',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_Ulta_ULTAEXCEL_UltaEDI',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_UltaWeb',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_Ulta_ULTAEXCEL_UltaWeb',1,@insert_date,@insert_user)

--WAG product
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensProduct',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WAGIT_WAGEDW_WalgreensProduct',1,@insert_date,@insert_user)

--WAG store
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensStore',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WAGIT_WAGEDW_WalgreensStore',1,@insert_date,@insert_user)

--Walgreens
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensBasket',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WAGIT_WAGEDW_WalgreensBasket',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensEBasket',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WAGIT_WAGEDW_WalgreensEBasket',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensTransaction',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WAGIT_WAGEDW_WalgreensTransaction',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensETransaction',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WAGIT_WAGEDW_WalgreensETransaction',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensTransactionCost',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WAGIT_WAGEDW_WalgreensTransactionCost',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensETransactionCost',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WAGIT_WAGEDW_WalgreensETransactionCost',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_DATALYNX_WAGX_GB_Daily_Walgreens_Sales_from_RSI_WAGX',1,@insert_date,@insert_user)

--Indonesia
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL',1,@insert_date,@insert_user)


--Currency Conversion
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_GFSD_GFSDEXCEL_GlobalBrandsCurrencyConversionRates',1,@insert_date,@insert_user)

--Baozun Combo
--TODO Changes for wrapper
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunSalesHistory',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunSalesIncremental',1,@insert_date,@insert_user)
-- Removed, No such procedures exist
--INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunComboHistory',1,@insert_date,@insert_user)
--INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunComboIncremental',1,@insert_date,@insert_user)


--GBFINRetailer
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_GBFIN_GBFINEXCEL_GBFINRetailer_party',1,@insert_date,@insert_user)

--GBFINStoreMaster
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_GBFIN_GBFINEXCEL_GBFINStoreMaster',1,@insert_date,@insert_user)

--DA Invoice 
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_gb_da_inv_transaction_master',1,@insert_date,@insert_user)

--GB SAP Customer

INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_party_role_group',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_party_role_relationship',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_finance_account',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_gb_customer_master',1,@insert_date,@insert_user)

--GB SAP Finance GL
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_GBSAP_SAP_BKPF',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_GBSAP_SAP_BSEG',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_GBSAP_SAP_SKAT',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_GBSAP_SAP_CEPT',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_GBSAP_SAP_CE41000_ACCT',1,@insert_date,@insert_user)

--LE Store
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_LEIT_LEXDH_LEIT_LEX_SALES_Store',1,@insert_date,@insert_user)

--GBSAP GL Manual Adjustment
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_GBFIN_GBSAP_SAP_Invoice_manual_adjustment',1,@insert_date,@insert_user)

--DA COGS
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_gb_da_cogs_document',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_gb_da_cogs_transaction_master',1,@insert_date,@insert_user)

-- GB FIN Calendar
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_calendar_master',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_GBFIN_GBFINEXCEL_GB_Calendar_information_GBFINEXCEL_incr',1,@insert_date,@insert_user)

--LE Sales
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_liz_earle_transaction_master',1,@insert_date,@insert_user)

-- SM CDC Proc
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_SM',1,@insert_date,@insert_user)

--GB S&OP Alshaya Weekly sales inc
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_MHAC_MHACX_Alshaya_Weekly_sales_inc',1,@insert_date,@insert_user)

--GB S&OP APH Weekly sales inc
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_APH_APHX_APH_Weekly_sales_inc',1,@insert_date,@insert_user)


-- Opticians CDC Proc
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_optician',1,@insert_date,@insert_user)

-- Custom SP For WAG Transaction History load
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_SM_WAG',1,@insert_date,@insert_user)

-- Custom SP For WAG Transaction Incremental load
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_buk_WAG',1,@insert_date,@insert_user)

--GB S&OP Kohls
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_KOHLS_KSSWP_KOHLS_WEEKLY_SALES',1,@insert_date,@insert_user)

--TeamCenter Product
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_BUKIT_GBTC_Teamcenter',1,@insert_date,@insert_user)

--GB S&OP Walmart Retail Sales 
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WALMART_WMTWP_WALMART_RETAIL_SALES',1,@insert_date,@insert_user)

--GB S&OP Walmart Online Sales 
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_WALMART_WMTWP_WALMART_ONLINE_SALES',1,@insert_date,@insert_user)

--Mecca Sales
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_mecca_transaction_master',1,@insert_date,@insert_user)

--Liz Earle Migration
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_LE',1,@insert_date,@insert_user)

-- GBMR UI
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_RPIDNA_DNAUIGBMRPRD_GB_GBMR_Product_Updates_GBMRUI',1,@insert_date,@insert_user)

--BUK TransactionLineAnon and TransactionLineCard OneTimeUpdateActivity
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_BUKIT_ABACUS_BUK_Transaction_line_anon_Abacus_hist',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_BUKIT_ABACUS_BUK_Transaction_line_card_Abacus_hist',1,@insert_date,@insert_user)

-- Budget and Forecast Weekly
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_budgetforecast_weekly_main',1,@insert_date,@insert_user)

-- Budget and Forecast Monthly
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_budgetforecast_monthly_main',1,@insert_date,@insert_user)

-- Martech wave2
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_HistoryDataCapture_Martech',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_Svoc',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_SvocEntityLink',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_Martech',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_CRMTrans',1,@insert_date,@insert_user)

-- DPI
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_dpi',1,@insert_date,@insert_user)

--Asia MI
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_truncate_load_AsiaMI',1,@insert_date,@insert_user)

--TPM
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_Product_Master',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_Coggs',1,@insert_date,@insert_user)

-- STEP
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_step',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_step_product',1,@insert_date,@insert_user)

--RPRS
--RPRS Loss
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_LossRPRS',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_loss',1,@insert_date,@insert_user)


--RPRS Customer

INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_customerRPRS',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_customeraffluencelink',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_customeraffluencedetail',1,@insert_date,@insert_user)


--RPRS MERCH

INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_IncrementalDataCapture_rprs',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_uk_btc_by_spc_fixture',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_uk_btc_by_sp_ProductMerch',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_uk_btc_by_spc_planogram',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_uk_btc_by_spc_Merch_store',1,@insert_date,@insert_user)
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_perform_scd_Merch',1,@insert_date,@insert_user)

--Product Exclusion
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_inc_step_product_exclusion',1,@insert_date,@insert_user)

--Retailer to STEP mapping
INSERT INTO #cf_stored_proc VALUES (0,'psa.sp_insertretailertostep_productrelationship',1,@insert_date,@insert_user)


/* End of Configuration							*/

INSERT INTO [psa].[cf_stored_proc] 
select 
	max_spid + row_number() OVER (ORDER BY sp_name) as [sp_id],
	[sp_name],
	[active_flag],
	[dt_created],
	[user_created]
from #cf_stored_proc
inner join (select max(sp_id) max_spid from [psa].[cf_stored_proc]) max_pk ON (1=1)
WHERE sp_name NOT IN (select distinct [sp_name] from [psa].[cf_stored_proc])
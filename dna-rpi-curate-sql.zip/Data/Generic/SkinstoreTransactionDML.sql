﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : Skinstore
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidDC BIGINT,
		@ruleidNN BIGINT,
		@attributeidDATESPLIT BIGINT,
		@attributeidUPC BIGINT,		
		@entityid_SKNSNO7 BIGINT,
		@entityid_PSA_SKNSNO7 BIGINT,
		@entityid_His_SKNSNO7 BIGINT,
		@entityid_His_PSA_SKNSNO7 BIGINT,
		@entityid_SKNSSG BIGINT,
		@entityid_PSA_SKNSSG BIGINT,
		@entityid_His_SKNSSG BIGINT,
		@entityid_His_PSA_SKNSSG BIGINT;

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   Skinstore NO7
 */

SET @entityid_SKNSNO7 = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Skinstore sales data%');
SET @entityid_PSA_SKNSNO7 = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'SKNST_SKNSTEXCEL_SKINSTORE_No7_WeeklyRetailSales');

SET @entityid_His_SKNSNO7 = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%SKINSTORE_No7_WeeklyRetailSales Ingestion%');
SET @entityid_His_PSA_SKNSNO7 = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_SKINSTORE_No7_WeeklyRetailSales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SKNSNO7 AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SKNSNO7 AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_SKNSNO7,@entityid_His_PSA_SKNSNO7);


-- Find the attributeId
SET @attributeidDATESPLIT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATESPLIT' AND 
entityid = @entityid_SKNSNO7);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_SKNSNO7);


PRINT @attributeidDATESPLIT
PRINT @attributeidUPC


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SKNSNO7,@attributeidDATESPLIT,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SKNSNO7,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);



--History Skinstore NO7
-- Find the attributeId

SET @attributeidDATESPLIT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATESPLIT' AND 
entityid = @entityid_His_SKNSNO7);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_His_SKNSNO7);


PRINT @attributeidDATESPLIT
PRINT @attributeidUPC


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SKNSNO7,@attributeidDATESPLIT,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SKNSNO7,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);



/* 
 *   Skinstore SG
 */
 SET @entityid_SKNSSG = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Skinstore weekly sales data%');
SET @entityid_PSA_SKNSSG = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'SKNST_SKNSTEXCEL_SKINSTORE_SG_WeeklyRetailSales');

SET @entityid_His_SKNSSG = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%SKINSTORE_SG_WeeklyRetailSales Ingestion%');
SET @entityid_His_PSA_SKNSSG = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_SKINSTORE_SG_WeeklyRetailSales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SKNSSG AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SKNSSG AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_His_PSA_SKNSSG,@entityid_PSA_SKNSSG);




-- Find the attributeId
SET @attributeidDATESPLIT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATESPLIT' AND 
entityid = @entityid_SKNSSG);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_SKNSSG);


PRINT @attributeidDATESPLIT
PRINT @attributeidUPC


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SKNSSG,@attributeidDATESPLIT,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SKNSSG,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);



--History Skinstore SG


-- Find the attributeId
SET @attributeidDATESPLIT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATESPLIT' AND 
entityid = @entityid_His_SKNSSG);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_His_SKNSSG);


PRINT @attributeidDATESPLIT
PRINT @attributeidUPC


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SKNSSG,@attributeidDATESPLIT,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SKNSSG,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);



END
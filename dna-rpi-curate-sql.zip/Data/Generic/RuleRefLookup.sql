﻿
IF OBJECT_ID('tempdb..#temp_RuleRefLookup') IS NOT NULL
  DROP TABLE #temp_RuleRefLookup

CREATE TABLE #temp_RuleRefLookup
(
	[RuleType] [varchar](200) NULL,
	[TableName] [nvarchar](500) NULL,
	[ColumnName] [nvarchar](500) NULL,
	[FnToApply] [nvarchar](500) NULL,
	[RuleSetName] [nvarchar](500) NULL,
	[RuleKey] [nvarchar](500) NULL,
	[RecordSourceID] [bigint] NULL,
	[ActiveFlag] [char](1) NULL
)

DELETE FROM [psa].[RuleRefLookup] WHERE [TableName] = 'SAPCOE_BUKSAP_BUKSAPArticle'

-- BUK Product
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','SAPCOE_BUKSAP_BUKSAPArticle','Brand',null,'brand_code',null,'12008','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','SAPCOE_BUKSAP_BUKSAPArticle','SubBrand',null,'sub_brand_code',null,'12008','Y')
-- Product Statuses
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','SAPCOE_BUKSAP_BUKSAPArticle','XSiteArticleStatus',null,'retail_status_code',null,'12008','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','SAPCOE_BUKSAP_BUKSAPArticle','XDistributionChainStatus',null,'distribution_chain_status_code',null,'12008','Y')
-- Product Group 
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','SAPCOE_BUKSAP_BUKSAPArticle','MerchandiseCategory',null,'merchandise_category_code',null,'12008','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','SAPCOE_BUKSAP_BUKSAPArticle','ArticleType',null,'item_type',null,'12008','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','SAPCOE_BUKSAP_BUKSAPArticle','BaseUnitofMeasure',null,'base_unit_of_measure',null,'12012','Y')


-- LE PRODUCT
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','LEIT_LEDATAHUB_SalesProduct','[productgroupcode]',null,'product_group',null,'129','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','LEIT_LEDATAHUB_SalesProduct','[productfamilycode]',null,'product_family',null,'126','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','LEIT_LEDATAHUB_SalesProduct','[productfamilycategorycode]',null,'product_family_category',null,'126','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','LEIT_LEDATAHUB_SalesProduct','[saleclassificationcode]',null,'sales_classification',null,'126','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','LEIT_LEDATAHUB_SalesProduct','[bayno]',null,'bay_number',null,'126','Y')

-- GB Product
-- Product Statuses
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_MARA','formt',null,'material_stage',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_MARC','mmsta',null,'material_status',null,'12025','Y')
-- Product Group 
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_MARA','matkl',null,'material_group',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_MARA','magrv',null,'monograph_group',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_MARA','mtart',null,'item_type',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_MARA','meins',null,'base_unit_of_measure',null,'12012','Y')

-- GB SAP Invoice Sales
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_VBRK','FKART',null,'billing_types',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_VBRK','WAERK',null,'Currency ISO 4217',null,'12012','Y')

-- SAP Product Master
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','BrandGroup',null,'brandgroup',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','ReportingBrand' ,null,'ReportingBrand',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','RetailCategoryGroup' ,null,'RetailCategoryGroup',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','RetailCategory' ,null,'RetailCategory',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','RetailSubCategory' ,null,'RetailSubCategory',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','ProductType' ,null,'ProductType',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','IndustrySectorGS1Segment' ,null,'IndustrySectorGS1Segment',null,'12036','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','ShadeVariety' ,null,'ShadeVariety',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','Fragrance' ,null,'Fragrance',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','SkincareCategory' ,null,'SkincareCategory',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','GS1BrickCode' ,null,'GS1BrickCode',null,'12036','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','RangeName' ,null,'RangeName',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_GBFINEXCEL_GBMDTProduct','SubBrand' ,null,'SubBrand',null,'12023','Y')

-- STEP Product
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','materialgroupid',null,'material_group',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','monographordinflagid',null,'monograph_group',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','materialtypeid',null,'item_type',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','workflowstatusflagid',null,'material_stage',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','plantspecificstatusid',null,'material_status',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','brandgroupname',null,'brandgroup',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','ReportingBrand' ,null,'ReportingBrand',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','RetailCategory' ,null,'RetailCategory',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','subcategoryname' ,null,'RetailSubCategory',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','producttypename' ,null,'ProductType',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','ShadeVariety' ,null,'ShadeVariety',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','Fragrance' ,null,'Fragrance',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','SkincareCategory' ,null,'SkincareCategory',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','GS1BrickCode' ,null,'GS1BrickCode',null,'12036','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','GBMDT_STEP_GB_Product_Master_STEP','subbrandname' ,null,'SubBrand',null,'12023','Y')


--DA Invoice 
INSERT INTO #temp_RuleRefLookup VALUES 
('MissingLookupKeys','BUKIT_GBEDISTG_DAInvoiceDetails','CURRENCY',null,'Currency ISO 4217',null,'12012','Y')

-- SAP Customer
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_ADRC','SORT1' ,null,'Search Term 1',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_ADRC','SORT2' ,null,'Search Term 2',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_KNA1','KTOKD' ,null,'Account Group',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_KNA1','LAND1' ,null,'Country ISO 3166-2',null,'12012','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_KNVV','KDGRP' ,null,'Customer Group',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_KNVV','KVGR1' ,null,'Customer Group 1',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_KNVV','KVGR2' ,null,'Customer Group 2',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_KNVV','KVGR3' ,null,'Customer Group 3',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_KNVV','WAERS' ,null,'Currency ISO 4217',null,'12012','Y')

--GB SAP Finance GL
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_BKPF','BLART',null,'finance_document_types',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_BKPF','HWAER',null,'Currency ISO 4217',null,'12012','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_BKPF','WAERS',null,'Currency ISO 4217',null,'12012','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_BKPF','MONAT',null,'Posting_period',null,'12025','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','RPIDNA_GBSAP_SAP_BSEG','BSCHL',null,'Posting key',null,'12025','Y')

--LE Store
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','LEIT_LEXDH_LEIT_LEX_SALES_Store','SalesForecastingLevelCode',null,'Sales Forecasting Level',null,'129','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','LEIT_LEXDH_LEIT_LEX_SALES_Store','Region',null,'Region',null,'129','Y')
INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','LEIT_LEXDH_LEIT_LEX_SALES_Store','Channel',null,'Channel',null,'129','Y')

--DA COGS
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','RPIDNA_GBSAP_SAP_MSEG','LocalCurrency',null,'Currency ISO 4217',null,'12012','Y')

--LE Sales
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','LEIT_LEXDH_LIZ_EARLE_RETAIL_AND_INVOICE_SALES','Currency',null,'Currency ISO 4217',null,'12012','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','LEIT_LEXDH_LIZ_EARLE_RETAIL_AND_INVOICE_SALES','Source',null,'Transaction Source',null,'129','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','LEIT_LEXDH_LIZ_EARLE_RETAIL_AND_INVOICE_SALES','PaymentType',null,'Transaction Payment Type',null,'129','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','LEIT_LEXDH_LIZ_EARLE_RETAIL_AND_INVOICE_SALES','OrderStatus',null,'LE Line Item Type',null,'129','Y')

-- Budget and Forecast Weekly
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','Version',null,'Budget_forecast_version',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','Metric',null,'Budget_forecast_metric',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','Entity',null,'Budget_forecast_entity',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','Market',null,'Budget_forecast_market',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','Customer',null,'Budget_forecast_customer',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','Brand_Cat',null,'Budget_forecast_brand_cat',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','Brand',null,'Budget_forecast_Brand',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','Category',null,'Budget_forecast_Category',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','MICustomer','CASE WHEN TRY_CAST($Column AS int) IS NULL THEN $Column ELSE CAST(FORMAT(CAST($Column as int),''0000000000'') as varchar) END','MICustomer',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','MICountry',null,'Country ISO 3166-2',null,'12012','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','Channel',null,'Budget_forecast_Channel',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr','LocalCurrency',null,'Currency ISO 4217',null,'12012','Y')

-- Budget and Forecast Monthly
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','Version',null,'Budget_forecast_version',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','Metric',null,'Budget_forecast_metric',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','Entity',null,'Budget_forecast_entity',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','Market',null,'Budget_forecast_market',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','Customer',null,'Budget_forecast_customer',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','Brand_Cat',null,'Budget_forecast_brand_cat',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','Brand',null,'Budget_forecast_Brand',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','Category',null,'Budget_forecast_Category',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','MICustomer','CASE WHEN TRY_CAST($Column AS int) IS NULL THEN $Column ELSE CAST(FORMAT(CAST($Column as int),''0000000000'') as varchar) END','MICustomer',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','MICountry',null,'Country ISO 3166-2',null,'12012','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','Channel',null,'Budget_forecast_Channel',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr','LocalCurrency',null,'Currency ISO 4217',null,'12012','Y')

--Indonesia
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL','BRAND',null,'BRAND',null,'1800096205','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL','CATEGORY',null,'CATEGORY',null,'1800096205','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL','BootsBrand',null,'BootsBrand',null,'1800096205','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL','BootsBrandRange',null,'BootsBrandRange',null,'1800096205','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL','LocalSubCategory',null,'LocalSubCategory',null,'1800096205','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL','cat',null,'cat',null,'1800096205','Y')

---Exclusion
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel','Brand_Group',null,'brandgroup',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel','Category',null,'RetailCategory',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel','Brand',null,'ReportingBrand',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel','Sub_Category',null,'RetailSubCategory',null,'12023','Y')
INSERT INTO #temp_RuleRefLookup VALUES ('MissingLookupKeys','GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel','Sub_Brand',null,'SubBrand',null,'12023','Y')

--RPRS

--RPRS Merch

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDBStatus',null,'POGStatus',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDBKey1',null,'Company',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDBKey2',null,'POG Type',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDBKey3',null,'Department',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDBKey4',null,'Footprint',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDBKey5',null,'Planner Family',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDBKey6',null,'Store Format',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGCategory',null,'POGCategory',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc5',null,'Fitting Type',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc7',null,'MAP Family name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc8',null,'Space Planner Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc12',null,'Sales Plan Period No',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc16',null,'pogHead Layout Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc19',null,'SM Codes_1',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc27',null,'Sub-Format',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc30',null,'Furniture Type',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc37',null,'SM Codes_2',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc39',null,'SM Codes_3',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGDesc40',null,'SM Codes_4',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGValue7',null,'SP Period No',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGValue26',null,'Ad-Hoc avg Service Level',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGValue41',null,'Part module number',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr','POGValue48',null,'Version Number',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue5',null,'Display Aid Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixDesc7',null,'Cradle/Bracket Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixDesc9',null,'Shelf Insert Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue10',null,'Divider Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue11',null,'Riser Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue12',null,'Sharkstooth Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue13',null,'Nav/Seg Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue14',null,'Illumination Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue15',null,'Hanging Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue16',null,'Hook Name',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue26',null,'Notch Offset GF',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue27',null,'Notch Offset GL',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixValue28',null,'Notch Offset GLF',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixType',null,'Fixture Type',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr','POGFixDesc30',null,'Furniture',null,'1800052563','Y')

INSERT INTO #temp_RuleRefLookup values ('MissingLookupKeys','BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr','FPDBStatus',null,'FPStatus',null,'1800052563','Y')

--Insert into the target table
INSERT INTO [psa].[RuleRefLookup]
select * from #temp_RuleRefLookup t
WHERE NOT EXISTS (SELECT 1 FROM [psa].[RuleRefLookup] r
				   WHERE t.[TableName] = r.[TableName]
				     AND t.[ColumnName] = r.[ColumnName]
					 AND t.[RuleSetName] = r.[RuleSetName])


﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : All
Domain  : All 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidDC BIGINT,
		@ruleidNN BIGINT,
		@attributeidDATESPLIT BIGINT,
		@attributeidUPC BIGINT,		
		@entityid_SKNSNO7 BIGINT,
		@entityid_PSA_SKNSNO7 BIGINT,
		@entityid_His_SKNSNO7 BIGINT,
		@entityid_His_PSA_SKNSNO7 BIGINT,
		@entityid_SKNSSG BIGINT,
		@entityid_PSA_SKNSSG BIGINT,
		@entityid_His_SKNSSG BIGINT,
		@entityid_His_PSA_SKNSSG BIGINT,
		@attributeidENDDATE  BIGINT,
		@attributeidPRODUCTSKU BIGINT,		
		@entityid_Dermstore BIGINT,
		@entityid_PSA_Dermstore BIGINT,
		@entityid_His_Dermstore BIGINT,
		@entityid_His_PSA_Dermstore BIGINT,
		@attributeidStore BIGINT,
		@entityid_StoreMaster BIGINT,
		@entityid_PSA_StoreMaster BIGINT,
		@attributeidFILEDATE BIGINT,
		@attributeidFAC7DIGITNUMBER BIGINT,
		@entityid_TSGAAFES BIGINT,
		@entityid_PSA_TSGAAFES BIGINT,
		@entityid_His_TSGAAFES BIGINT,
		@entityid_His_PSA_TSGAAFES BIGINT,
		@attributeidSITE BIGINT,
		@attributeidSTYLENO BIGINT,
		@entityid_TSGMCXNo7 BIGINT,
		@entityid_PSA_TSGMCXNo7 BIGINT,
		@entityid_His_TSGMCXNo7 BIGINT,
		@entityid_His_PSA_TSGMCXNo7 BIGINT,
		@attributeidSTYLENUMBER BIGINT,
		@entityid_TSGNEXCOM BIGINT,
		@entityid_PSA_TSGNEXCOM BIGINT,
		@entityid_His_TSGNEXCOM BIGINT,
		@entityid_His_PSA_TSGNEXCOM BIGINT,
		@attributeidDATE BIGINT,
		@attributeidLOCNUMBER BIGINT,
		@attributeidMFGSTYLE BIGINT,
		@entityid_Target BIGINT,
		@entityid_PSA_Target BIGINT,
		@entityid_His_Target BIGINT,
		@entityid_His_PSA_Target BIGINT,
		@attributeidUPC_CODE BIGINT,
		@entityid_WAGPRD BIGINT,
		@entityid_PSA_WAGPRD BIGINT,
		@entityid_His_WAGPRD BIGINT,
		@entityid_His_PSA_WAGPRD BIGINT,
		@entityid_SAP_BKPF BIGINT,
		@entityid_PSA_SAP_BKPF BIGINT,
		@attributeidBELNR BIGINT,
		@attributeidBUKRS BIGINT,
		@attributeidGJAHR BIGINT,
		@attributeidBLDAT BIGINT,
		@attributeidBUDAT BIGINT,
		@entityid_SAP_BSEG BIGINT,
		@entityid_PSA_SAP_BSEG BIGINT,
		@attributeidBUZEI BIGINT,
		@entityid_SAP_SKAT BIGINT,
		@entityid_PSA_SAP_SKAT BIGINT,
		@attributeidSAKNR BIGINT,
		@entityid_SAP_CEPT BIGINT,
		@entityid_PSA_SAP_CEPT BIGINT,
		@attributeidPRCTR BIGINT,
		@entityid_LEStore BIGINT,
		@entityid_PSA_LEStore BIGINT,
		@attributeidOrderCentreId BIGINT,
		@attributeidFINYEAR BIGINT,		
		@attributeidWEEKNUMBER BIGINT,	
		@entityid_SDM BIGINT,
		@entityid_PSA_SDM BIGINT,
		@entityid_His_SDM BIGINT,
		@entityid_His_PSA_SDM BIGINT,
		@attributeidSTORE_NUM BIGINT,
		@attributeidTODATE  BIGINT,
		@attributeidSTORECODE BIGINT,
		@attributeidPRODUCTCODE BIGINT,
		@entityid_UltaEDI BIGINT,
		@entityid_PSA_UltaEDI BIGINT,
		@entityid_BAO BIGINT,
		@entityid_PSA_BAO BIGINT,
		@entityid_His_BAO BIGINT,
		@entityid_His_PSA_BAO BIGINT,
		@attributeidStoreId BIGINT,
		@attributeidBarcode BIGINT,
		@entityid_wag BIGINT,
		@entityid_PSA_wag BIGINT,
		@entityid_His_wag BIGINT,
		@entityid_His_PSA_wag BIGINT,
		@attributeidCITY  BIGINT,
		@attributeidSTATE BIGINT,
		@attributeidZIP   BIGINT,
		@attributeidWalgreensFiscalDate  BIGINT,
		@entityid_walgreensRSI   BIGINT,
		@entityid_PSA_walgreensRSI BIGINT,
		@entityid_NorwayTransaction  BIGINT,
        @entityid_PSA_NorwayTransaction BIGINT,
        @attributeidunits BIGINT,
        @attributeidtisp  BIGINT,
        @attributeidtesp  BIGINT,
		@entityid_Indonesia BIGINT,
        @entityid_PSA_Indonesia BIGINT,
        @attributeidPLU BIGINT,
		@attributeidTransactionnumber BIGINT,
		@entityid_ewag  BIGINT,
		@entityid_PSA_ewag   BIGINT,
		@entityid_His_ewag  BIGINT,
		@entityid_His_PSA_ewag BIGINT,
		@attributeidETransactionnumber BIGINT,
		@attributeidretailId BIGINT,
		@entityid_SAP_ManualAdj BIGINT,
		@entityid_PSA_SAP_ManualAdj BIGINT,
		@attributeidDocumentNumber BIGINT,
		@attributeidCompanyCode BIGINT,
		@attributeidFiscalYear BIGINT,
		@attributeidLineItemNumber BIGINT,
		@entityid_GBSnOP_Kohls BIGINT,
		@entityid_PSA_GBSnOP_Kohls_storemaster BIGINT,
		@entityid_PSA_GBSnOP_Kohls BIGINT,
		@attributeidSKU BIGINT,
		@entityid_TeamCenterProduct BIGINT,
		@entityid_PSA_TeamCenterProduct BIGINT,
		@attributeidItemId BIGINT,
		@entityid_GBSnOP_WalmartRS BIGINT,
		@entityid_PSA_GBSnOP_WalmartRS BIGINT,
		@attributeidStrNbr BIGINT,
		@attributeidItemNbr  BIGINT,
        @attributeidDaily BIGINT,
		@attributeidlastweekdate BIGINT,
        @attributeidretailer BIGINT,
		@entityid_Exclusion   BIGINT,
		@entityid_PSA_Exclusion BIGINT,
		@attributeidRetailerItemCode BIGINT,
		@entityid_GBFIN_storemaster BIGINT,
		@entityid_PSA_GBFIN_storemaster BIGINT,
		@attributeidpoporderreturnid BIGINT,
		@attributeiddocumentno BIGINT,
		@entityid_poporderreturn BIGINT,
		@entityid_PSA_poporderreturn BIGINT,
		@attributeidpoporderreturnlineid BIGINT,
		@entityid_poporderreturnline BIGINT,
		@entityid_PSA_poporderreturnline BIGINT,
		@entityid_nlnominalaccount BIGINT,
		@entityid_PSA_nlnominalaccount BIGINT,
		@attributeidnlnominalaccounid BIGINT,
		@attributeidaccountnumber BIGINT,
		@entityid_plpostedsuppliertran BIGINT,
		@entityid_PSA_plpostedsuppliertran BIGINT,
		@attributeidtransactionreference BIGINT,
		@attributeidplpostedsuppliertranid BIGINT,
		@attributeidtransactiondate BIGINT,
		@entityid_popinvoicecreditline BIGINT,
		@entityid_PSA_popinvoicecreditline BIGINT,
		@attributeidpopinvoicecreditlineid BIGINT,
		@entityid_productgroup BIGINT,
		@entityid_PSA_productgroup BIGINT,
		@attributeidproductgroupid BIGINT,
        @entityid_stockitem BIGINT,
		@entityid_PSA_stockitem BIGINT,
		@attributeidCode BIGINT,
		@entityid_GBSnOP_Alshaya BIGINT,
		@entityid_PSA_GBSnOP_Alshaya BIGINT,
		@entityid_GBSnOP_APHS BIGINT,
		@entityid_PSA_GBSnOP_APHS BIGINT,
		@attributeidPrimBar BIGINT,
		@attributeidCountryCode BIGINT,
		@attributeidWEDate BIGINT,
		@attributeiditemcode BIGINT;


--SKINSTORE RuleENtity Inserts
BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   Skinstore NO7
 */

SET @entityid_SKNSNO7 = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Skinstore sales data%');
SET @entityid_PSA_SKNSNO7 = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'SKNST_SKNSTEXCEL_SKINSTORE_No7_WeeklyRetailSales');

SET @entityid_His_SKNSNO7 = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%SKINSTORE_No7_WeeklyRetailSales Ingestion%');
SET @entityid_His_PSA_SKNSNO7 = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_SKINSTORE_No7_WeeklyRetailSales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SKNSNO7 AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SKNSNO7 AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_SKNSNO7,@entityid_His_PSA_SKNSNO7);


-- Find the attributeId
SET @attributeidDATESPLIT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATESPLIT' AND 
entityid = @entityid_SKNSNO7);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_SKNSNO7);


PRINT @attributeidDATESPLIT
PRINT @attributeidUPC


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SKNSNO7,@attributeidDATESPLIT,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SKNSNO7,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);



--History Skinstore NO7
-- Find the attributeId

SET @attributeidDATESPLIT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATESPLIT' AND 
entityid = @entityid_His_SKNSNO7);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_His_SKNSNO7);


PRINT @attributeidDATESPLIT
PRINT @attributeidUPC


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SKNSNO7,@attributeidDATESPLIT,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SKNSNO7,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);



/* 
 *   Skinstore SG
 */
 SET @entityid_SKNSSG = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Skinstore weekly sales data%');
SET @entityid_PSA_SKNSSG = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'SKNST_SKNSTEXCEL_SKINSTORE_SG_WeeklyRetailSales');

SET @entityid_His_SKNSSG = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%SKINSTORE_SG_WeeklyRetailSales Ingestion%');
SET @entityid_His_PSA_SKNSSG = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_SKINSTORE_SG_WeeklyRetailSales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SKNSSG AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SKNSSG AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_His_PSA_SKNSSG,@entityid_PSA_SKNSSG);




-- Find the attributeId
SET @attributeidDATESPLIT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATESPLIT' AND 
entityid = @entityid_SKNSSG);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_SKNSSG);


PRINT @attributeidDATESPLIT
PRINT @attributeidUPC


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SKNSSG,@attributeidDATESPLIT,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SKNSSG,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);



--History Skinstore SG


-- Find the attributeId
SET @attributeidDATESPLIT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATESPLIT' AND 
entityid = @entityid_His_SKNSSG);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_His_SKNSSG);


PRINT @attributeidDATESPLIT
PRINT @attributeidUPC


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SKNSSG,@attributeidDATESPLIT,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SKNSSG,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);



END
		
		
--DERMSTORE RuleENtity Inserts

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   Dermstore
 */

SET @entityid_Dermstore = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Dermstore sales data%');
SET @entityid_PSA_Dermstore = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TGTDS_TGTDSEXCEL_DermstoreRetailSales');



SET @entityid_His_Dermstore = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%DermstoreRetailSales Ingestion%');
SET @entityid_His_PSA_Dermstore = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_DermstoreRetailSales');

-- Update Business Key fields in Attribute table   

UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_Dermstore AND attributeName IN 
('ENDDATE','PRODUCTSKU') AND activeflag=1;
UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_Dermstore AND attributeName IN 
('ENDDATE','PRODUCTSKU') AND activeflag=1;


--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_Dermstore,@entityid_His_PSA_Dermstore);




-- Find the attributeId
SET @attributeidENDDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ENDDATE' AND 
entityid = @entityid_Dermstore);
SET @attributeidPRODUCTSKU = (SELECT attributeid FROM psa.attribute WHERE attributename = 'PRODUCTSKU' AND
entityid = @entityid_Dermstore);


PRINT @attributeidENDDATE
PRINT @attributeidPRODUCTSKU


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Dermstore,@attributeidENDDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Dermstore,@attributeidPRODUCTSKU,28004,'28001',NULL,1,@insert_date,@insert_user);


--Insert to RuleEntity for ENDDATE

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_Dermstore,@attributeidENDDATE,28004,'28001',
'{"DateFormatSQLServer":"121"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId

SET @attributeidENDDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ENDDATE' AND 
entityid = @entityid_His_Dermstore);
SET @attributeidPRODUCTSKU = (SELECT attributeid FROM psa.attribute WHERE attributename = 'PRODUCTSKU' AND
entityid = @entityid_His_Dermstore);

PRINT @attributeidENDDATE
PRINT @attributeidPRODUCTSKU


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Dermstore,@attributeidENDDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Dermstore,@attributeidPRODUCTSKU,28004,'28001',NULL,1,@insert_date,@insert_user);


--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_His_PSA_Dermstore,@attributeidENDDATE,28004,'28001',
'{"DateFormatSQLServer":"121"}',1,@insert_date,@insert_user);
END

--GBFINStoreMaster RuleEntity inserts
/*
BEGIN

SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

SET @entityid_StoreMaster = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%GBA retailer data upload%');
SET @entityid_PSA_StoreMaster = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'GBFIN_GBFINEXCEL_GBFINRetailer');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_StoreMaster);

-- Find the attributeId
SET @attributeidStore = (SELECT attributeid FROM psa.attribute WHERE attributename = 'Store' AND entityid = @entityid_StoreMaster);

PRINT @attributeidStore

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_StoreMaster,@attributeidStore,28004,'28001',NULL,1,@insert_date,@insert_user);

END
*/

---TSG AFEES

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   TSGAAFES
 */

 
SET @entityid_TSGAAFES = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of The Singer Group (Army) data%' );
SET @entityid_PSA_TSGAAFES = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TSG_TSGEXCEL_TSGAAFES');

SET @entityid_His_TSGAAFES = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%TSGAAFES Ingestion%');
SET @entityid_His_PSA_TSGAAFES = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_TSGAAFES');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_TSGAAFES AND attributeName IN 
--('FILEDATE','FAC7DIGITNUMBER','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_TSGAAFES AND attributeName IN 
--('FILEDATE','FAC7DIGITNUMBER','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_TSGAAFES,@entityid_His_PSA_TSGAAFES);




-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_TSGAAFES);
SET @attributeidFAC7DIGITNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FAC7DIGITNUMBER' AND
entityid = @entityid_TSGAAFES);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND entityid = @entityid_TSGAAFES);

PRINT @attributeidFILEDATE
PRINT @attributeidFAC7DIGITNUMBER
PRINT @attributeidUPC

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGAAFES,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGAAFES,@attributeidFAC7DIGITNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGAAFES,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_TSGAAFES,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"23"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_His_TSGAAFES);
SET @attributeidFAC7DIGITNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FAC7DIGITNUMBER' AND
entityid = @entityid_His_TSGAAFES);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND entityid = @entityid_His_TSGAAFES);

PRINT @attributeidFILEDATE
PRINT @attributeidFAC7DIGITNUMBER
PRINT @attributeidUPC

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGAAFES,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGAAFES,@attributeidFAC7DIGITNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGAAFES,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_His_PSA_TSGAAFES,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"23"}',1,@insert_date,@insert_user);
END


--TSG MCX

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   TSGMCXNo7
 */

 
SET @entityid_TSGMCXNo7 = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of The Singer Group (Marines) data%' );
SET @entityid_PSA_TSGMCXNo7 = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TSG_TSGEXCEL_TSGMCXNo7');

SET @entityid_His_TSGMCXNo7 = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%TSGMCXNo7 Ingestion%');
SET @entityid_His_PSA_TSGMCXNo7 = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_TSGMCXNo7');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_TSGMCXNo7 AND attributeName IN 
--('FILEDATE','SITE','STYLENO') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_TSGMCXNo7 AND attributeName IN 
--('FILEDATE','SITE','STYLENO') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_TSGMCXNo7,@entityid_His_PSA_TSGMCXNo7);




-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_TSGMCXNo7);
SET @attributeidSITE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'SITE' AND
entityid = @entityid_TSGMCXNo7);
SET @attributeidSTYLENO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STYLENO' AND 
entityid = @entityid_TSGMCXNo7);

PRINT @attributeidFILEDATE
PRINT @attributeidSITE
PRINT @attributeidSTYLENO

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGMCXNo7,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGMCXNo7,@attributeidSITE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGMCXNo7,@attributeidSTYLENO,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_TSGMCXNo7,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"23"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_His_TSGMCXNo7);
SET @attributeidSITE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'SITE' AND
entityid = @entityid_His_TSGMCXNo7);
SET @attributeidSTYLENO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STYLENO' AND
entityid = @entityid_His_TSGMCXNo7);

PRINT @attributeidFILEDATE
PRINT @attributeidSITE
PRINT @attributeidSTYLENO

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGMCXNo7,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGMCXNo7,@attributeidSITE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGMCXNo7,@attributeidSTYLENO,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_His_PSA_TSGMCXNo7,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"23"}',1,@insert_date,@insert_user);
END

--TSG Nexcom

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   TSGNEXCOM
 */

 
SET @entityid_TSGNEXCOM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of The Singer Group (Navy) data%');
SET @entityid_PSA_TSGNEXCOM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TSG_TSGEXCEL_TSGNEXCOM');

SET @entityid_His_TSGNEXCOM = (SELECT entityId FROM psa.entity WHERE  schemaname LIKE '%feed%' AND
entityname like '%TSGNEXCOM Ingestion%');
SET @entityid_His_PSA_TSGNEXCOM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_TSGNEXCOM');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_TSGNEXCOM AND attributeName IN 
--('FILEDATE','STYLENUMBER') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_TSGNEXCOM AND attributeName IN 
--('FILEDATE','STYLENUMBER') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_TSGNEXCOM,@entityid_His_PSA_TSGNEXCOM);




-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_TSGNEXCOM);
SET @attributeidSTYLENUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STYLENUMBER' AND 
entityid = @entityid_TSGNEXCOM);

PRINT @attributeidFILEDATE
PRINT @attributeidSTYLENUMBER

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGNEXCOM,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGNEXCOM,@attributeidSTYLENUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_TSGNEXCOM,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"23"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_His_TSGNEXCOM);
SET @attributeidSTYLENUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STYLENUMBER' AND
entityid = @entityid_His_TSGNEXCOM);

PRINT @attributeidFILEDATE
PRINT @attributeidSTYLENUMBER

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGNEXCOM,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGNEXCOM,@attributeidSTYLENUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_His_PSA_TSGNEXCOM,@attributeidDATE,28004,'28001',
'{"DateFormatSQLServer":"23"}',1,@insert_date,@insert_user);
END


--Target

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   Target
 */

SET @entityid_Target = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Target sales data%');
SET @entityid_PSA_Target = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TGT_TGTWP_TargetSales');

SET @entityid_His_Target = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%TargetSales history Ingestion%');
SET @entityid_His_PSA_Target = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_TargetSales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_Target AND attributeName IN 
--('Date','LOCATION NUMBER','DPCI') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_Target AND attributeName IN 
--('Date','LOCATION NUMBER','DPCI') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_Target,@entityid_His_PSA_Target);




-- Find the attributeId
SET @attributeidDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATE' AND 
entityid = @entityid_Target);
SET @attributeidLOCNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'LOCATION NUMBER' AND
entityid = @entityid_Target);
SET @attributeidMFGSTYLE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'MFG STYLE' AND entityid = @entityid_Target);

PRINT @attributeidDATE
PRINT @attributeidLOCNUMBER
PRINT @attributeidMFGSTYLE

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Target,@attributeidDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Target,@attributeidLOCNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Target,@attributeidMFGSTYLE,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_Target,@attributeidDATE,28004,'28001',
'{"DateFormatSQLServer":"23"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId
SET @attributeidDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATE' AND 
entityid = @entityid_His_Target);
SET @attributeidLOCNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'LOCATION NUMBER' AND
entityid = @entityid_His_Target);
SET @attributeidMFGSTYLE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'MFG STYLE' AND entityid = @entityid_His_Target);

PRINT @attributeidDATE
PRINT @attributeidLOCNUMBER
PRINT @attributeidMFGSTYLE

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Target,@attributeidDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Target,@attributeidLOCNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Target,@attributeidMFGSTYLE,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 
--Dateformat check is not configured as it comes from history old gdh expected to be correct format

END

--walgreens RSI

BEGIN

SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

SET @entityid_walgreensRSI = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Daily Walgreens sales information%');
SET @entityid_PSA_walgreensRSI = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'DATALYNX_WAGX_GB_Daily_Walgreens_Sales_from_RSI_WAGX');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN(@entityid_PSA_walgreensRSI);

-- Find the attributeId
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_walgreensRSI);
SET @attributeidSTORE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE' AND 
entityid = @entityid_walgreensRSI);
SET @attributeidCITY = (SELECT attributeid FROM psa.attribute WHERE attributename = 'CITY' AND 
entityid = @entityid_walgreensRSI);
SET @attributeidSTATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STATE' AND 
entityid = @entityid_walgreensRSI);
SET @attributeidZIP = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ZIP' AND 
entityid = @entityid_walgreensRSI);
SET @attributeidWalgreensFiscalDate = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WalgreensFiscalDate' AND 
entityid = @entityid_walgreensRSI);

PRINT @attributeidUPC
PRINT @attributeidSTORE
PRINT @attributeidCITY
PRINT @attributeidSTATE
PRINT @attributeidZIP
PRINT @attributeidWalgreensFiscalDate

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_walgreensRSI,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_walgreensRSI,@attributeidSTORE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_walgreensRSI,@attributeidCITY,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_walgreensRSI,@attributeidSTATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_walgreensRSI,@attributeidZIP,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_walgreensRSI,@attributeidWalgreensFiscalDate,28004,'28001',NULL,1,@insert_date,@insert_user);

END


--Norway Transaction
/*
BEGIN

SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

SET @entityid_NorwayTransaction = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Norway_crp_item_transaction_Incremental_Load_txt%');
SET @entityid_PSA_NorwayTransaction= (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'no_crp_item_transaction');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN(@entityid_PSA_NorwayTransaction);


-- Find the attributeId
SET @attributeiditemcode = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ITEM_CODE' AND 
entityid = @entityid_NorwayTransaction);
SET @attributeidunits = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UNITS' AND 
entityid = @entityid_NorwayTransaction);
SET @attributeidtisp = (SELECT attributeid FROM psa.attribute WHERE attributename = 'TISP' AND 
entityid = @entityid_NorwayTransaction);
SET @attributeidtesp = (SELECT attributeid FROM psa.attribute WHERE attributename = 'TESP' AND 
entityid = @entityid_NorwayTransaction);

PRINT @attributeiditemcode
PRINT @attributeidunits
PRINT @attributeidtisp
PRINT @attributeidtesp


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_NorwayTransaction,@attributeiditemcode,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_NorwayTransaction,@attributeidunits,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_NorwayTransaction,@attributeidtisp,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_NorwayTransaction,@attributeidtesp,28004,'28001',NULL,1,@insert_date,@insert_user);



END
*/
--Indonesia Transaction

BEGIN

SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

SET @entityid_Indonesia = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Indonesia weekly sales transaction%');
SET @entityid_PSA_Indonesia = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN(@entityid_PSA_Indonesia);


-- Find the attributeId
SET @attributeidPLU= (SELECT attributeid FROM psa.attribute WHERE attributename = 'PLU' AND 
entityid = @entityid_Indonesia);
SET @attributeidSTORE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE' AND 
entityid = @entityid_Indonesia);
SET @attributeidDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATE' AND 
entityid = @entityid_Indonesia);


PRINT @attributeidPLU
PRINT @attributeidSTORE
PRINT @attributeidDATE


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Indonesia,@attributeidPLU,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Indonesia,@attributeidSTORE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Indonesia,@attributeidDATE,28004,'28001',NULL,1,@insert_date,@insert_user);



END

--Exclusion Table

	
BEGIN

SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

SET @entityid_Exclusion = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%This feed contains the props products with the heirarchy information%');
SET @entityid_PSA_Exclusion = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN(@entityid_PSA_Exclusion);

-- Find the attributeId
SET @attributeidretailer = (SELECT attributeid FROM psa.attribute WHERE attributename = 'Retailer' AND 
entityid = @entityid_Exclusion);
SET @attributeidRetailerItemCode = (SELECT attributeid FROM psa.attribute WHERE attributename = 'Retailer Item Code' AND 
entityid = @entityid_Exclusion);


PRINT @attributeidretailer
PRINT @attributeidRetailerItemCode


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Exclusion,@attributeidretailer,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Exclusion,@attributeidRetailerItemCode,28004,'28001',NULL,1,@insert_date,@insert_user);

END

--WAG PRODUCT

BEGIN



SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   WAG product
 */

SET @entityid_WAGPRD = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Walgreens product data%');
SET @entityid_PSA_WAGPRD = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'WAGIT_WAGEDW_WalgreensProduct');

SET @entityid_His_WAGPRD = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%WalgreensProduct Ingestion%');
SET @entityid_His_PSA_WAGPRD = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_WalgreensProduct');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SKNSNO7 AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SKNSNO7 AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_WAGPRD,@entityid_His_PSA_WAGPRD);

--Incremental
-- Find the attributeId
SET @attributeidUPC_CODE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC_CODE' AND
entityid = @entityid_WAGPRD);


PRINT @attributeidUPC_CODE


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_WAGPRD,@attributeidUPC_CODE,28004,'28001',NULL,1,@insert_date,@insert_user);


--History
-- Find the attributeId

SET @attributeidUPC_CODE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC_CODE' AND
entityid = @entityid_His_WAGPRD);


PRINT @attributeidUPC_CODE


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_WAGPRD,@attributeidUPC_CODE,28004,'28001',NULL,1,@insert_date,@insert_user);



END

/*--------------------- GB SAP Finance GL ----------------------*/

--SAP_BKPF RuleEntity inserts
BEGIN

SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');
SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');

SET @entityid_SAP_BKPF = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%BKPF%');
SET @entityid_PSA_SAP_BKPF = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'RPIDNA_GBSAP_SAP_BKPF');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_SAP_BKPF);

-- Find the attributeId
SET @attributeidBELNR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'BELNR' AND entityid = @entityid_SAP_BKPF);
SET @attributeidBUKRS = (SELECT attributeid FROM psa.attribute WHERE attributename = 'BUKRS' AND entityid = @entityid_SAP_BKPF);
SET @attributeidGJAHR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'GJAHR' AND entityid = @entityid_SAP_BKPF);
SET @attributeidBLDAT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'BLDAT' AND entityid = @entityid_SAP_BKPF);
SET @attributeidBUDAT = (SELECT attributeid FROM psa.attribute WHERE attributename = 'BUDAT' AND entityid = @entityid_SAP_BKPF);

PRINT @attributeidBELNR
PRINT @attributeidBUKRS
PRINT @attributeidGJAHR
PRINT @attributeidBLDAT
PRINT @attributeidBUDAT

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_BKPF,@attributeidBELNR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_BKPF,@attributeidBUKRS,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_BKPF,@attributeidGJAHR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_SAP_BKPF,@attributeidBLDAT,28004,'28001','{"DateFormatSQLServer":"112"}',1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_SAP_BKPF,@attributeidBUDAT,28004,'28001','{"DateFormatSQLServer":"112"}',1,@insert_date,@insert_user);

END

--SAP_BSEG RuleEntity inserts
BEGIN

SET @entityid_SAP_BSEG = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%BSEG%');
SET @entityid_PSA_SAP_BSEG = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'RPIDNA_GBSAP_SAP_BSEG');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_SAP_BSEG);

-- Find the attributeId
SET @attributeidBELNR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'BELNR' AND entityid = @entityid_SAP_BSEG);
SET @attributeidBUKRS = (SELECT attributeid FROM psa.attribute WHERE attributename = 'BUKRS' AND entityid = @entityid_SAP_BSEG);
SET @attributeidGJAHR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'GJAHR' AND entityid = @entityid_SAP_BSEG);
SET @attributeidBUZEI = (SELECT attributeid FROM psa.attribute WHERE attributename = 'BUZEI' AND entityid = @entityid_SAP_BSEG);

PRINT @attributeidBELNR
PRINT @attributeidBUKRS
PRINT @attributeidGJAHR
PRINT @attributeidBUZEI

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_BSEG,@attributeidBELNR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_BSEG,@attributeidBUKRS,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_BSEG,@attributeidGJAHR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_BSEG,@attributeidBUZEI,28004,'28001',NULL,1,@insert_date,@insert_user);

END

--SAP_SKAT RuleEntity inserts
BEGIN

SET @entityid_SAP_SKAT = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%SKAT%');
SET @entityid_PSA_SAP_SKAT = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'RPIDNA_GBSAP_SAP_SKAT');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_SAP_SKAT);

-- Find the attributeId
SET @attributeidSAKNR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'SAKNR' AND entityid = @entityid_SAP_SKAT);

PRINT @attributeidSAKNR

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_SKAT,@attributeidSAKNR,28004,'28001',NULL,1,@insert_date,@insert_user);

END

--SAP_CEPT RuleEntity inserts
BEGIN

SET @entityid_SAP_CEPT = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%SAP_CEPT%');
SET @entityid_PSA_SAP_CEPT = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'RPIDNA_GBSAP_SAP_CEPT');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_SAP_CEPT);

-- Find the attributeId
SET @attributeidPRCTR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'PRCTR' AND entityid = @entityid_SAP_CEPT);

PRINT @attributeidPRCTR

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_CEPT,@attributeidPRCTR,28004,'28001',NULL,1,@insert_date,@insert_user);

END

--LE Store RuleEntity inserts
BEGIN

SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

SET @entityid_LEStore = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%LE BTB-Customer and Store data%');
SET @entityid_PSA_LEStore = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LEIT_LEX_SALES_Store');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_LEStore);

-- Find the attributeId
SET @attributeidOrderCentreId = (SELECT attributeid FROM psa.attribute WHERE attributename = 'OrderCentreId' AND entityid = @entityid_LEStore);

PRINT @attributeidOrderCentreId

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_LEStore,@attributeidOrderCentreId,28004,'28001',NULL,1,@insert_date,@insert_user);

END

--SDMNo7Esales

BEGIN


SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   SDMNo7ESales
 */

 
SET @entityid_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Shoppers Drug Mart store data%');
SET @entityid_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'SDM_SDMEXCEL_SDMNo7ESales');

SET @entityid_His_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%SDMNo7ESales Ingestion%');
SET @entityid_His_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_SDMNo7ESales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_SDM,@entityid_His_PSA_SDM);




-- Find the attributeId
SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidUPC

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);





--History
-- Find the attributeId

SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_His_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_His_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_His_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidSTORE_NUM
PRINT @attributeidUPC
--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);


END

--SDMNo7StoreSales

BEGIN


SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   SDMNo7StoreSales
 */

 
SET @entityid_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Shoppers Drug Mart store data%');
SET @entityid_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'SDM_SDMEXCEL_SDMNo7StoreSales');

SET @entityid_His_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%SDMNo7StoreSales Ingestion%');
SET @entityid_His_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_SDMNo7StoreSales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','STORE_NUM','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','STORE_NUM','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_SDM,@entityid_His_PSA_SDM);




-- Find the attributeId
SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_SDM);
SET @attributeidSTORE_NUM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE_NUM' AND 
entityid = @entityid_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidSTORE_NUM
PRINT @attributeidUPC
--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidSTORE_NUM,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);





--History
-- Find the attributeId

-- Find the attributeId
SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_His_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_His_SDM);
SET @attributeidSTORE_NUM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE_NUM' AND 
entityid = @entityid_His_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_His_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidSTORE_NUM
PRINT @attributeidUPC
--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidSTORE_NUM,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);


END

--SDMSGESales

BEGIN


SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   SDMSGESales
 */

 
SET @entityid_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Shoppers Drug Mart store data%');
SET @entityid_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'SDM_SDMEXCEL_SDMSGESales');

SET @entityid_His_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%SDMSGESales Ingestion%');
SET @entityid_His_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_SDMSGESales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_SDM,@entityid_His_PSA_SDM);




-- Find the attributeId
SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidUPC

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);





--History
-- Find the attributeId

SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_His_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_His_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_His_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidSTORE_NUM
PRINT @attributeidUPC
--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);


END

--SDMSGStoreSales

BEGIN


SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   SDMSGStoreSales
 */

 
SET @entityid_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Shoppers Drug Mart store sales data%');
SET @entityid_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'SDM_SDMEXCEL_SDMSGStoreSales');

SET @entityid_His_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%SDMSGStoreSales Ingestion%');
SET @entityid_His_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_SDMSGStoreSales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','STORE_NUM','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','STORE_NUM','UPC') AND activeflag=1;


--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_SDM,@entityid_His_PSA_SDM);




-- Find the attributeId
SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_SDM);
SET @attributeidSTORE_NUM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE_NUM' AND 
entityid = @entityid_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidSTORE_NUM
PRINT @attributeidUPC
--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidSTORE_NUM,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);





--History
-- Find the attributeId

-- Find the attributeId
SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_His_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_His_SDM);
SET @attributeidSTORE_NUM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE_NUM' AND 
entityid = @entityid_His_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_His_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidSTORE_NUM
PRINT @attributeidUPC
--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidSTORE_NUM,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);


END

--ULTAEDI

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   UltaEDI
 */

SET @entityid_UltaEDI = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Ulta EDI data%');
SET @entityid_PSA_UltaEDI = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'Ulta_ULTAEXCEL_UltaEDI');



-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_UltaEDI AND attributeName IN 
--('TO_DATE','STORE_CODE','PRODUCT_CODE') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_UltaEDI);




-- Find the attributeId
SET @attributeidTODATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'TO_DATE' AND 
entityid = @entityid_UltaEDI);
SET @attributeidSTORECODE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE_CODE' AND
entityid = @entityid_UltaEDI);
SET @attributeidPRODUCTCODE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'PRODUCT_CODE' AND
entityid = @entityid_UltaEDI);


PRINT @attributeidTODATE
PRINT @attributeidSTORECODE
PRINT @attributeidPRODUCTCODE


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_UltaEDI,@attributeidTODATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_UltaEDI,@attributeidSTORECODE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_UltaEDI,@attributeidPRODUCTCODE,28004,'28001',NULL,1,@insert_date,@insert_user);


/* 
 *   Baozun 
 */

SET @entityid_BAO = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental Weekly sales transaction for Baozun(TMALL and KAOLA)%');
SET @entityid_PSA_BAO = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'WBAHK_BZUNEXCEL_BaozunSalesIncremental');

SET @entityid_His_BAO = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like 'Weekly sales transaction for Baozun(TMALL and KAOLA)%');
SET @entityid_His_PSA_BAO = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'WBAHK_BZUNEXCEL_BaozunSalesHistory');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_BAO,@entityid_His_PSA_BAO);


-- Find the attributeId
SET @attributeidStoreId = (SELECT attributeid FROM psa.attribute WHERE attributename = 'StoreId' AND 
entityid = @entityid_BAO);
SET @attributeidBarcode = (SELECT attributeid FROM psa.attribute WHERE attributename = 'Barcode' AND
entityid = @entityid_BAO);


PRINT @attributeidStoreId
PRINT @attributeidBarcode


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_BAO,@attributeidStoreId,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_BAO,@attributeidBarcode,28004,'28001',NULL,1,@insert_date,@insert_user);



--History Baozun 
-- Find the attributeId

SET @attributeidStoreId = (SELECT attributeid FROM psa.attribute WHERE attributename = 'StoreId' AND 
entityid = @entityid_His_BAO);
SET @attributeidBarcode = (SELECT attributeid FROM psa.attribute WHERE attributename = 'Barcode' AND
entityid = @entityid_His_BAO);


PRINT @attributeidStoreId
PRINT @attributeidBarcode


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_His_PSA_BAO,@attributeidStoreId,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_His_PSA_BAO,@attributeidBarcode,28004,'28001',NULL,1,@insert_date,@insert_user);


/* 
 *   Walgreens Transaction 
 */

SET @entityid_wag = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Walgreens transaction data%');
SET @entityid_PSA_wag = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'WAGIT_WAGEDW_WalgreensTransaction');

SET @entityid_His_wag = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%WalgreensTransaction Ingestion%');
SET @entityid_His_PSA_wag = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_WalgreensTransaction');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_wag,@entityid_His_PSA_wag);


-- Find the attributeId
SET @attributeidTransactionnumber= (SELECT attributeid FROM psa.attribute WHERE attributename = 'TRANSACTION_NUMBER' AND 
entityid = @entityid_wag);
SET @attributeidupc = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_wag);


PRINT @attributeidTransactionnumber
PRINT @attributeidupc


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_wag,@attributeidTransactionnumber,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_wag,@attributeidupc,28004,'28001',NULL,1,@insert_date,@insert_user);



--History wag 
-- Find the attributeId

SET @attributeidTransactionnumber = (SELECT attributeid FROM psa.attribute WHERE attributename = 'TRANSACTION_NUMBER' AND 
entityid = @entityid_His_wag);
SET @attributeidupc = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND
entityid = @entityid_His_wag);


PRINT @attributeidTransactionnumber
PRINT @attributeidupc


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_wag,@attributeidTransactionnumber,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_wag,@attributeidupc,28004,'28001',NULL,1,@insert_date,@insert_user);


/* 
 *   Walgreens ETransaction 
 */

SET @entityid_ewag = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Walgreens etransaction data%');
SET @entityid_PSA_ewag = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'WAGIT_WAGEDW_WalgreensETransaction');

SET @entityid_His_ewag = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%WalgreensETransaction Ingestion%');
SET @entityid_His_PSA_ewag = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_WalgreensETransaction');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_ewag,@entityid_His_PSA_ewag);


-- Find the attributeId
SET @attributeidETransactionnumber= (SELECT attributeid FROM psa.attribute WHERE attributename = 'TRANSACTION_NUMBER' AND 
entityid = @entityid_ewag);
SET @attributeidretailId = (SELECT attributeid FROM psa.attribute WHERE attributename = 'retailer_product_identifier' AND
entityid = @entityid_ewag);


PRINT @attributeidETransactionnumber
PRINT @attributeidretailId


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_ewag,@attributeidETransactionnumber,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_ewag,@attributeidretailId,28004,'28001',NULL,1,@insert_date,@insert_user);



--History ewagzun 
-- Find the attributeId

SET @attributeidETransactionnumber = (SELECT attributeid FROM psa.attribute WHERE attributename = 'TRANSACTION_NUMBER' AND 
entityid = @entityid_His_ewag);
SET @attributeidretailId = (SELECT attributeid FROM psa.attribute WHERE attributename = 'retailer_product_identifier' AND
entityid = @entityid_His_ewag);


PRINT @attributeidETransactionnumber
PRINT @attributeidretailId


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_ewag,@attributeidETransactionnumber,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_ewag,@attributeidretailId,28004,'28001',NULL,1,@insert_date,@insert_user);
END

/*
--GBSAP GL Manual Adjustment RuleEntity inserts
BEGIN

SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

SET @entityid_SAP_ManualAdj = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%SAP Invoice Manual Adjustment%');
SET @entityid_PSA_SAP_ManualAdj = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'GBFIN_GBSAP_SAP_Invoice_manual_adjustment');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_SAP_ManualAdj);

-- Find the attributeId
SET @attributeidDocumentNumber = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DocumentNumber' AND entityid = @entityid_SAP_ManualAdj);
SET @attributeidCompanyCode = (SELECT attributeid FROM psa.attribute WHERE attributename = 'CompanyCode' AND entityid = @entityid_SAP_ManualAdj);
SET @attributeidFiscalYear = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FiscalYear' AND entityid = @entityid_SAP_ManualAdj);
SET @attributeidLineItemNumber = (SELECT attributeid FROM psa.attribute WHERE attributename = 'LineItemNumber' AND entityid = @entityid_SAP_ManualAdj);

PRINT @attributeidDocumentNumber
PRINT @attributeidCompanyCode
PRINT @attributeidFiscalYear
PRINT @attributeidLineItemNumber

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_ManualAdj,@attributeidDocumentNumber,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_ManualAdj,@attributeidCompanyCode,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_ManualAdj,@attributeidFiscalYear,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_SAP_ManualAdj,@attributeidLineItemNumber,28004,'28001',NULL,1,@insert_date,@insert_user);

END
*/

--TeamCenter Product RuleEntity inserts
BEGIN

SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

SET @entityid_TeamCenterProduct = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Teamcenter Product%');
SET @entityid_PSA_TeamCenterProduct = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'BUKIT_GBTC_Teamcenter');

--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_TeamCenterProduct);

-- Find the attributeId
SET @attributeidItemId = (SELECT attributeid FROM psa.attribute WHERE attributename = 'Item_ID' AND entityid = @entityid_TeamCenterProduct);

PRINT @attributeidItemId

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_TeamCenterProduct,@attributeidItemId,28004,'28001',NULL,1,@insert_date,@insert_user);

END

--
--GBS&OP Kohls RuleEntity inserts
BEGIN

	SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

	SET @entityid_GBSnOP_Kohls = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Online and retail sales for each product in a week%');
	SET @entityid_PSA_GBSnOP_Kohls = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'Kohls_KSSWP_Kohls_weekly_sales');

	--Delete already existing entries for the entityPSA id
	DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_GBSnOP_Kohls);

	-- Find the attributeId
	SET @attributeidSKU = (SELECT attributeid FROM psa.attribute WHERE attributename = 'SKU' AND entityid = @entityid_GBSnOP_Kohls);
	SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND entityid = @entityid_GBSnOP_Kohls);


	PRINT @attributeidSKU
	PRINT @attributeidFILEDATE

	--Insert to RuleEntity for NotNull checks for BK 
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_Kohls,@attributeidSKU,28004,'28001',NULL,1,@insert_date,@insert_user);
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_Kohls,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);


END
--GBS&OP Walmart Retail Sales  RuleEntity inserts
BEGIN

	SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

	SET @entityid_GBSnOP_WalmartRS = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname ='Walmart store retail sales');
	SET @entityid_PSA_GBSnOP_WalmartRS = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'Walmart_WMTWP_Walmart_retail_sales');

	--Delete already existing entries for the entityPSA id
	DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_GBSnOP_WalmartRS);

	-- Find the attributeId
	SET @attributeidStrNbr = (SELECT attributeid FROM psa.attribute WHERE attributename = 'StoreNbr' AND entityid = @entityid_GBSnOP_WalmartRS);
	SET @attributeidItemNbr = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ItemNbr' AND entityid = @entityid_GBSnOP_WalmartRS);
	SET @attributeidDaily = (SELECT attributeid FROM psa.attribute WHERE attributename = 'Daily' AND entityid = @entityid_GBSnOP_WalmartRS);

	PRINT @attributeidStrNbr
	PRINT @attributeidItemNbr
	PRINT @attributeidDaily


	--Insert to RuleEntity for NotNull checks for BK 
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_WalmartRS,@attributeidStrNbr,28004,'28001',NULL,1,@insert_date,@insert_user);
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_WalmartRS,@attributeidItemNbr,28004,'28001',NULL,1,@insert_date,@insert_user);
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_WalmartRS,@attributeidDaily,28004,'28001',NULL,1,@insert_date,@insert_user);

END
--GBS&OP Walmart Online Sales  RuleEntity inserts
BEGIN

	SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

	SET @entityid_GBSnOP_WalmartRS = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname ='Walmart online retail sales');
	SET @entityid_PSA_GBSnOP_WalmartRS = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'Walmart_WMTWP_Walmart_online_sales');

	--Delete already existing entries for the entityPSA id
	DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_GBSnOP_WalmartRS);

	-- Find the attributeId
	SET @attributeidStrNbr = (SELECT attributeid FROM psa.attribute WHERE attributename = 'StoreNbr' AND entityid = @entityid_GBSnOP_WalmartRS);
	SET @attributeidItemNbr = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ItemNbr' AND entityid = @entityid_GBSnOP_WalmartRS);
	SET @attributeidDaily = (SELECT attributeid FROM psa.attribute WHERE attributename = 'Daily' AND entityid = @entityid_GBSnOP_WalmartRS);

	PRINT @attributeidStrNbr
	PRINT @attributeidItemNbr
	PRINT @attributeidDaily


	--Insert to RuleEntity for NotNull checks for BK 
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_WalmartRS,@attributeidStrNbr,28004,'28001',NULL,1,@insert_date,@insert_user);
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_WalmartRS,@attributeidItemNbr,28004,'28001',NULL,1,@insert_date,@insert_user);
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_WalmartRS,@attributeidDaily,28004,'28001',NULL,1,@insert_date,@insert_user);

END


--GBS&OP Alshaya  RuleEntity inserts
BEGIN

	SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

	SET @entityid_GBSnOP_Alshaya = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname ='Alshaya-Weekly-sales-inc');
	SET @entityid_PSA_GBSnOP_Alshaya = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'MHAC_MHACX_Alshaya_Weekly_sales_inc');

	--Delete already existing entries for the entityPSA id
	DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_GBSnOP_Alshaya);

	-- Find the attributeId
	SET @attributeidPrimBar = (SELECT attributeid FROM psa.attribute WHERE attributename = 'PrimaryBarcode' AND entityid = @entityid_GBSnOP_Alshaya);
	SET @attributeidCountryCode = (SELECT attributeid FROM psa.attribute WHERE attributename = 'CountryCode' AND entityid = @entityid_GBSnOP_Alshaya);
	SET @attributeidWEDate = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WeekendingDate' AND entityid = @entityid_GBSnOP_Alshaya);

	PRINT @attributeidPrimBar
	PRINT @attributeidCountryCode
	PRINT @attributeidWEDate


	--Insert to RuleEntity for NotNull checks for BK 
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_Alshaya,@attributeidPrimBar,28004,'28001',NULL,1,@insert_date,@insert_user);
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_Alshaya,@attributeidCountryCode,28004,'28001',NULL,1,@insert_date,@insert_user);
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_Alshaya,@attributeidWEDate,28004,'28001',NULL,1,@insert_date,@insert_user);

END

--GBS&OP APH Sales  RuleEntity inserts
BEGIN

	SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

	SET @entityid_GBSnOP_APHS = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname ='APH-Weekly-sales-inc');
	SET @entityid_PSA_GBSnOP_APHS = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'APH_APHX_APH_Weekly_sales_inc');

	--Delete already existing entries for the entityPSA id
	DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_GBSnOP_APHS);

	-- Find the attributeId
	
	SET @attributeidItemNbr = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ItemNumber' AND entityid = @entityid_GBSnOP_APHS);
	SET @attributeidlastweekdate = (SELECT attributeid FROM psa.attribute WHERE attributename = 'LastWeekDate' AND entityid = @entityid_GBSnOP_APHS);

	
	PRINT @attributeidItemNbr
	PRINT @attributeidlastweekdate


	--Insert to RuleEntity for NotNull checks for BK 
	
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_APHS,@attributeidItemNbr,28004,'28001',NULL,1,@insert_date,@insert_user);
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBSnOP_APHS,@attributeidlastweekdate,28004,'28001',NULL,1,@insert_date,@insert_user);

END

--GBFIN-store RuleEntity inserts
BEGIN

	SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

	SET @entityid_GBFIN_storemaster = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%GBA store data upload%');
	SET @entityid_PSA_GBFIN_storemaster = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'GBFIN_GBFINEXCEL_GBFINStoreMaster');

	--Delete already existing entries for the entityPSA id
	DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_GBFIN_storemaster);
	-- Find the attributeId
	SET @attributeidretailer = (SELECT attributeid FROM psa.attribute WHERE attributename = 'retailer' AND entityid = @entityid_GBFIN_storemaster);


	PRINT @attributeidretailer

	--Insert to RuleEntity for NotNull checks for BK 
	INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_GBFIN_storemaster,@attributeidretailer,28004,'28001',NULL,1,@insert_date,@insert_user);


END

/*
	-- LE - POP Order Return  RuleEntity inserts
	BEGIN

		SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

		SET @entityid_poporderreturn = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Purchase Order Processing Order Return Details%');
		SET @entityid_PSA_poporderreturn = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_POP_Order_Return_LEXDH_Incr');

		--Delete already existing entries for the entityPSA id
		DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_poporderreturn);
		
		-- Find the attributeId
		SET @attributeidpoporderreturnid = (SELECT attributeid FROM psa.attribute WHERE attributename = 'POPOrderReturnID' AND entityid = @entityid_poporderreturn);
		SET @attributeiddocumentno = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DocumentNo' AND entityid = @entityid_poporderreturn);

		PRINT @attributeidpoporderreturnid
		PRINT @attributeiddocumentno

		--Insert to RuleEntity for NotNull checks for BK 
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_poporderreturn,@attributeidpoporderreturnid,28004,'28002',NULL,1,@insert_date,@insert_user);
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_poporderreturn,@attributeiddocumentno,28004,'28002',NULL,1,@insert_date,@insert_user);


	END

	-- LE - POP Order Return Line RuleEntity inserts
	BEGIN

		SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

		SET @entityid_poporderreturnline = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Purchase Order Processing Order Return Line Details%');
		SET @entityid_PSA_poporderreturnline = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_POP_Order_Return_Line_LEXDH_Incr');

		--Delete already existing entries for the entityPSA id
		DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_poporderreturnline);
		
		-- Find the attributeId
		SET @attributeidpoporderreturnlineid = (SELECT attributeid FROM psa.attribute WHERE attributename = 'POPOrderReturnLineID' AND entityid = @entityid_poporderreturnline);
		SET @attributeiditemcode = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ItemCode' AND entityid = @entityid_poporderreturnline);

		PRINT @attributeidpoporderreturnlineid
		PRINT @attributeiditemcode

		--Insert to RuleEntity for NotNull checks for BK 
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_poporderreturnline,@attributeiditemcode,28004,'28002',NULL,1,@insert_date,@insert_user);

		--Insert to RuleEntity for NotNull checks for BK 
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_poporderreturnline,@attributeidpoporderreturnlineid,28004,'28002',NULL,1,@insert_date,@insert_user);


	END
	
	--LE - NL Nominal Account RuleEntity inserts
	BEGIN 
	
		SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1'); 

		SET @entityid_nlnominalaccount = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Nominal Ledger Nominal Account%');
		SET @entityid_PSA_nlnominalaccount = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_NL_Nominal_Account_LEXDH_Incr');

		--Delete already existing entries for the entityPSA id
		DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_nlnominalaccount);
			
		-- Find the attributeId
		SET @attributeidnlnominalaccounid = (SELECT attributeid FROM psa.attribute WHERE attributename = 'NLNominalAccountID' AND entityid = @entityid_nlnominalaccount);
		SET @attributeidaccountnumber = (SELECT attributeid FROM psa.attribute WHERE attributename = 'AccountNumber' AND entityid = @entityid_nlnominalaccount);

		PRINT @attributeidnlnominalaccounid
		PRINT @attributeidaccountnumber

		--Insert to RuleEntity for NotNull checks for BK 
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_nlnominalaccount,@attributeidnlnominalaccounid,28004,'28001',NULL,1,@insert_date,@insert_user);
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_nlnominalaccount,@attributeidaccountnumber,28004,'28001',NULL,1,@insert_date,@insert_user);
		
		
	END
	
	--LE - PL Posted Supplier Transaction RuleEntity inserts
	BEGIN

		SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1'); 

		SET @entityid_plpostedsuppliertran = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Purchase Ledger Posted Supplier Transaction Details%');
		SET @entityid_PSA_plpostedsuppliertran = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_PL_Posted_Supplier_Transaction_LEXDH_Incr');

		--Delete already existing entries for the entityPSA id
		DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_plpostedsuppliertran);
			
		-- Find the attributeId
		SET @attributeidtransactionreference = (SELECT attributeid FROM psa.attribute WHERE attributename = 'TransactionReference' AND entityid = @entityid_plpostedsuppliertran);
		SET @attributeidplpostedsuppliertranid = (SELECT attributeid FROM psa.attribute WHERE attributename = 'PLPostedSupplierTranID' AND entityid = @entityid_plpostedsuppliertran);
		SET @attributeidtransactiondate = (SELECT attributeid FROM psa.attribute WHERE attributename = 'TransactionDate' AND entityid = @entityid_plpostedsuppliertran);

		PRINT @attributeidtransactionreference
		PRINT @attributeidplpostedsuppliertranid
		PRINT @attributeidtransactiondate

		--Insert to RuleEntity for NotNull checks for BK 
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_plpostedsuppliertran,@attributeidtransactionreference,28004,'28001',NULL,1,@insert_date,@insert_user);
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_plpostedsuppliertran,@attributeidplpostedsuppliertranid,28004,'28001',NULL,1,@insert_date,@insert_user);
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_plpostedsuppliertran,@attributeidtransactiondate,28004,'28001',NULL,1,@insert_date,@insert_user);


	END

	--LE - POP Invoice Credit Line RuleEntity inserts
	BEGIN

		SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1'); 

		SET @entityid_popinvoicecreditline = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Purchase Order Processing Invoice Credit Line Details%');
		SET @entityid_PSA_popinvoicecreditline = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_POP_Invoice_Credit_Line_LEXDH_Incr');

		--Delete already existing entries for the entityPSA id
		DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_popinvoicecreditline);
			
		-- Find the attributeId
		SET @attributeidpopinvoicecreditlineid = (SELECT attributeid FROM psa.attribute WHERE attributename = 'POPInvoiceCreditLineID' AND entityid = @entityid_popinvoicecreditline);

		PRINT @attributeidpopinvoicecreditlineid

		--Insert to RuleEntity for NotNull checks for BK 
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_popinvoicecreditline,@attributeidpopinvoicecreditlineid,28004,'28001',NULL,1,@insert_date,@insert_user);


	END
	
	--LE - Product Group Details RuleEntity inserts
	BEGIN	
		SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

		SET @entityid_productgroup = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Product Group Details%');
		SET @entityid_PSA_productgroup = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_Product_Group_LEXDH_Incr');

		--Delete already existing entries for the entityPSA id
		DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_productgroup);
		
		-- Find the attributeId
		SET @attributeidproductgroupid = (SELECT attributeid FROM psa.attribute WHERE attributename = 'ProductGroupID' AND entityid = @entityid_productgroup);

		PRINT @attributeidproductgroupid

		--Insert to RuleEntity for NotNull checks for BK 
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_productgroup,@attributeidproductgroupid ,28004,'28001',NULL,1,@insert_date,@insert_user);
	END
	
	--LE - Stock Item RuleEntity inserts
	BEGIN	
		SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');

		SET @entityid_stockitem = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Stock Item Details%');
		SET @entityid_PSA_stockitem = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_Stock_Item_LEXDH_Incr');

		--Delete already existing entries for the entityPSA id
		DELETE FROM [psa].[RuleEntity] WHERE EntityID IN (@entityid_PSA_stockitem);
		
		-- Find the attributeId
		SET @attributeidCode = (SELECT attributeid FROM psa.attribute WHERE attributename = 'Code' AND entityid = @entityid_stockitem);

		PRINT @attributeidCode

		--Insert to RuleEntity for NotNull checks for BK 
		INSERT INTO psa.ruleentity VALUES (@ruleidNN,@entityid_PSA_stockitem,@attributeidCode ,28004,'28002',NULL,1,@insert_date,@insert_user);
	END

*/
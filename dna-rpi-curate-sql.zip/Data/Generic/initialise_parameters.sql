﻿DECLARE @insert_date datetime,
		@insert_user varchar(20) = 'DevOps_ADO';
SET @insert_date = GETDATE()

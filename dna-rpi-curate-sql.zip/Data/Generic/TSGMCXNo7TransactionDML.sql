﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : TSGMCXNo7
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidDC BIGINT,
		@ruleidNN BIGINT,
		@attributeidFILEDATE BIGINT,
		@attributeidSITE BIGINT,
		@attributeidSTYLENO BIGINT,
		@entityid_TSGMCXNo7 BIGINT,
		@entityid_PSA_TSGMCXNo7 BIGINT,
		@entityid_His_TSGMCXNo7 BIGINT,
		@entityid_His_PSA_TSGMCXNo7 BIGINT;

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   TSGMCXNo7
 */

 
SET @entityid_TSGMCXNo7 = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of The Singer Group (Marines) data%' );
SET @entityid_PSA_TSGMCXNo7 = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TSG_TSGEXCEL_TSGMCXNo7');

SET @entityid_His_TSGMCXNo7 = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%TSGMCXNo7 Ingestion%');
SET @entityid_His_PSA_TSGMCXNo7 = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_TSGMCXNo7');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_TSGMCXNo7 AND attributeName IN 
--('FILEDATE','SITE','STYLENO') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_TSGMCXNo7 AND attributeName IN 
--('FILEDATE','SITE','STYLENO') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_TSGMCXNo7,@entityid_His_PSA_TSGMCXNo7);




-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_TSGMCXNo7);
SET @attributeidSITE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'SITE' AND
entityid = @entityid_TSGMCXNo7);
SET @attributeidSTYLENO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STYLENO' AND 
entityid = @entityid_TSGMCXNo7);

PRINT @attributeidFILEDATE
PRINT @attributeidSITE
PRINT @attributeidSTYLENO

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGMCXNo7,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGMCXNo7,@attributeidSITE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGMCXNo7,@attributeidSTYLENO,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_TSGMCXNo7,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"21"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_His_TSGMCXNo7);
SET @attributeidSITE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'SITE' AND
entityid = @entityid_His_TSGMCXNo7);
SET @attributeidSTYLENO = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STYLENO' AND
entityid = @entityid_His_TSGMCXNo7);

PRINT @attributeidFILEDATE
PRINT @attributeidSITE
PRINT @attributeidSTYLENO

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGMCXNo7,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGMCXNo7,@attributeidSITE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGMCXNo7,@attributeidSTYLENO,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_His_PSA_TSGMCXNo7,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"21"}',1,@insert_date,@insert_user);
END
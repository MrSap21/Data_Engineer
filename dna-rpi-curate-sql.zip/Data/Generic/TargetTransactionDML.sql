﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : Target
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidDC BIGINT,
		@ruleidNN BIGINT,
		@attributeidDATE BIGINT,
		@attributeidLOCNUMBER BIGINT,
		@attributeidDPCI BIGINT,
		@entityid_Target BIGINT,
		@entityid_PSA_Target BIGINT,
		@entityid_His_Target BIGINT,
		@entityid_His_PSA_Target BIGINT;

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   Target
 */

SET @entityid_Target = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Target sales data%');
SET @entityid_PSA_Target = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TGT_TGTWP_TargetSales');

SET @entityid_His_Target = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%TargetSales history Ingestion%');
SET @entityid_His_PSA_Target = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_TargetSales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_Target AND attributeName IN 
--('Date','LOCATION NUMBER','DPCI') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_Target AND attributeName IN 
--('Date','LOCATION NUMBER','DPCI') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_Target,@entityid_His_PSA_Target);




-- Find the attributeId
SET @attributeidDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATE' AND 
entityid = @entityid_Target);
SET @attributeidLOCNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'LOCATION NUMBER' AND
entityid = @entityid_Target);
SET @attributeidDPCI = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DPCI' AND entityid = @entityid_Target);

PRINT @attributeidDATE
PRINT @attributeidLOCNUMBER
PRINT @attributeidDPCI

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Target,@attributeidDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Target,@attributeidLOCNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_Target,@attributeidDPCI,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_Target,@attributeidDATE,28004,'28001',
'{"DateFormatSQLServer":"103"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId
SET @attributeidDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DATE' AND 
entityid = @entityid_His_Target);
SET @attributeidLOCNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'LOCATION NUMBER' AND
entityid = @entityid_His_Target);
SET @attributeidDPCI = (SELECT attributeid FROM psa.attribute WHERE attributename = 'DPCI' AND entityid = @entityid_His_Target);

PRINT @attributeidDATE
PRINT @attributeidLOCNUMBER
PRINT @attributeidDPCI

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Target,@attributeidDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Target,@attributeidLOCNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_Target,@attributeidDPCI,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 
--Dateformat check is not configured as it comes from history old gdh expected to be correct format

END
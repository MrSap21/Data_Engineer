﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : Ulta
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidDC BIGINT,
		@ruleidNN BIGINT,
		@attributeidTODATE  BIGINT,
		@attributeidSTORECODE BIGINT,
		@attributeidPRODUCTCODE BIGINT,
		@entityid_UltaEDI BIGINT,
		@entityid_PSA_UltaEDI BIGINT;
		
		

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   UltaEDI
 */

SET @entityid_UltaEDI = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Ulta EDI data%');
SET @entityid_PSA_UltaEDI = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'Ulta_ULTAEXCEL_UltaEDI');



-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_UltaEDI AND attributeName IN 
--('TO_DATE','STORE_CODE','PRODUCT_CODE') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_UltaEDI);




-- Find the attributeId
SET @attributeidTODATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'TO_DATE' AND 
entityid = @entityid_UltaEDI);
SET @attributeidSTORECODE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE_CODE' AND
entityid = @entityid_UltaEDI);
SET @attributeidPRODUCTCODE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'PRODUCT_CODE' AND
entityid = @entityid_UltaEDI);


PRINT @attributeidTODATE
PRINT @attributeidSTORECODE
PRINT @attributeidPRODUCTCODE


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_UltaEDI,@attributeidTODATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_UltaEDI,@attributeidSTORECODE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_UltaEDI,@attributeidPRODUCTCODE,28004,'28001',NULL,1,@insert_date,@insert_user);


END
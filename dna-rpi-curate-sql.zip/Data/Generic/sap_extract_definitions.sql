﻿
CREATE TABLE #temp_DynamicSAPExtracts
(
SAPTableName varchar(50) NOT NULL,
SAPParamsJSON varchar(4000) NOT NULL,
Active BIT
)


-- Main Tables
INSERT INTO #temp_DynamicSAPExtracts Values ('MARA','{"TableName":"MARA","FileName":"GB_SAP_MARA_YYYYMMDD.csv","FieldNames":"MATNR,ERSDA,LAEDA,LVORM,MTART,MATKL,MEINS,GROES,BRGEW,NTGEW,GEWEI,VOLUM,VOLEH,RAUBE,TEMPB,EAN11,LAENG,BREIT,HOEHE,MEABM,PRDHA,MHDRZ,MHDHB,KZUMW,MFRPN,MFRNR,PROFL,FORMT,MSTAV,BISMT,LABOR,MAGRV ","WhereClause":"","EscapeChar":"","Quote":"","Delim":","}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('MARC','{"TableName":"MARC","FileName":"GB_SAP_MARC_YYYYMMDD.csv","FieldNames":"MATNR,WERKS,MMSTA,HERKL,PRCTR","WhereClause":"","EscapeChar":"","Quote":"","Delim":","}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('VBRP','{"TableName":"VBRP","FileName":"GB_SAP_VBRP_YYYYMMDD.csv","FieldNames":"VBELN,POSNR,FKLMG,NETWR,MATNR,WAVWR,MWSBP","WhereClause":"ERDAT GT ''20180731''","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('VBRK','{"TableName":"VBRK","FileName":"GB_SAP_VBRK_YYYYMMDD.csv","FieldNames":"VBELN,FKART,WAERK,VKORG,FKDAT,KURRF,BUKRS,ERDAT,AEDAT,KUNRG,KUNAG,XBLNR","WhereClause":"FKDAT GT ''20180731''","EscapeChar":"","Quote":"","Delim":"|"}',1)

-- Reference Tables
INSERT INTO #temp_DynamicSAPExtracts Values ('MAKT','{"TableName":"MAKT","FileName":"GB_SAP_MAKT_YYYYMMDD.csv","FieldNames":"MANDT,MATNR,SPRAS,MAKTX,MAKTG","WhereClause":"","EscapeChar":"\\","Quote":"''","Delim":","}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('T023T','{"TableName":"T023T","FileName":"GB_SAP_T023T_YYYYMMDD.csv","FieldNames":"MANDT,SPRAS,MATKL,WGBEZ,WGBEZ60","WhereClause":"","EscapeChar":"","Quote":"","Delim":","}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('T179T','{"TableName":"T179T","FileName":"GB_SAP_T179T_YYYYMMDD.csv","FieldNames":"MANDT,SPRAS,PRODH,VTEXT","WhereClause":"","EscapeChar":"","Quote":"","Delim":","}',1)

-- SAP Customer Tables

INSERT INTO #temp_DynamicSAPExtracts Values ('T001','{"TableName":"T001","FileName":"GB_SAP_T001_YYYYMMDD.csv","FieldNames":"BUKRS,BUTXT","WhereClause":"BUKRS NE ''0001''","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('TVKOT','{"TableName":"TVKOT","FileName":"GB_SAP_TVKOT_YYYYMMDD.csv","FieldNames":"MANDT,SPRAS,VKORG,VTEXT","WhereClause":"VKORG NE ''0001''","EscapeChar":"","Quote":"","Delim":","}',1)
--INSERT INTO #temp_DynamicSAPExtracts Values ('KNA1','{"TableName":"KNA1","FileName":"GB_SAP_KNA1_YYYYMMDD.csv","FieldNames":"KUNNR,LAND1,NAME1,ADRNR,ERDAT,KTOKD,KUKLA,RPMKR,VBUND,LOEVM","WhereClause":"","EscapeChar":"\\","Quote":"''","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('KNA1','{"TableName":"KNA1","FileName":"GB_SAP_KNA1_YYYYMMDD.csv","FieldNames":"KUNNR,LAND1,NAME1,ADRNR,ERDAT,KTOKD,KUKLA,RPMKR,VBUND,LOEVM","WhereClause":"","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('TVKO','{"TableName":"TVKO","FileName":"GB_SAP_TVKO_YYYYMMDD.csv","FieldNames":"VKORG,BUKRS","WhereClause":"VKORG NE ''0001''","EscapeChar":"","Quote":"","Delim":","}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('KNB1','{"TableName":"KNB1","FileName":"GB_SAP_KNB1_YYYYMMDD.csv","FieldNames":"MANDT,KUNNR,BUKRS,AKONT,ALTKN","WhereClause":"","EscapeChar":"","Quote":"","Delim":","}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('ADRC','{"TableName":"ADRC","FileName":"GB_SAP_ADRC_YYYYMMDD.csv","FieldNames":"ADDRNUMBER,NAME1,SORT1,SORT2","WhereClause":"","EscapeChar":"","Quote":"","Delim":"|"}',1)
---INSERT INTO #temp_DynamicSAPExtracts Values ('KNVV','{"TableName":"KNVV","FileName":"GB_SAP_KNVV_YYYYMMDD.csv","FieldNames":"KUNNR,VKORG,ERDAT,KDGRP,WAERS,KVGR1,KVGR2,KVGR3","WhereClause":"","EscapeChar":"","Quote":"","Delim":","}',1)

INSERT INTO #temp_DynamicSAPExtracts Values ('TVV1T','{"TableName":"TVV1T","FileName":"GB_SAP_TVV1T_YYYYMMDD.csv","FieldNames":"KVGR1,BEZEI","WhereClause":"SPRAS EQ ''EN''","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('TVV2T','{"TableName":"TVV2T","FileName":"GB_SAP_TVV2T_YYYYMMDD.csv","FieldNames":"KVGR2,BEZEI","WhereClause":"SPRAS EQ ''EN''","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('TVV3T','{"TableName":"TVV3T","FileName":"GB_SAP_TVV3T_YYYYMMDD.csv","FieldNames":"KVGR3,BEZEI","WhereClause":"SPRAS EQ ''EN''","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('T151T','{"TableName":"T151T","FileName":"GB_SAP_T151T_YYYYMMDD.csv","FieldNames":"KDGRP,KTEXT","WhereClause":"SPRAS EQ ''EN''","EscapeChar":"","Quote":"","Delim":"|"}',1)

-- DA Cogs (Incremental)
INSERT INTO #temp_DynamicSAPExtracts Values ('MSEG','{"TableName":"MSEG","FileName":"GB_SAP_MSEG_YYYYMMDD.csv","FieldNames":"MBLNR,LINE_ID,MATNR,MJAHR,BUKRS,DMBTR,SHKZG,MENGE,WAERS,XBLNR_MKPF","WhereClause":"GJAHR GT 2022","EscapeChar":"","Quote":"","Delim":","}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('MKPF','{"TableName":"MKPF","FileName":"GB_SAP_MKPF_YYYYMMDD.csv","FieldNames":"MBLNR,BLDAT,MJAHR","WhereClause":"BLDAT GT YYYYMMDD","EscapeChar":"","Quote":"","Delim":","}',1)
--INSERT INTO #temp_DynamicSAPExtracts Values ('MKPF','{"TableName":"MKPF","FileName":"GB_SAP_MKPF_YYYYMMDD.csv","FieldNames":"MBLNR,BLDAT,MJAHR","WhereClause":"","EscapeChar":"","Quote":"","Delim":","}',1)

-- Incremental
INSERT INTO #temp_DynamicSAPExtracts Values ('CE41000_ACCT','{"TableName":"CE41000_ACCT","FileName":"GB_SAP_CE41000_ACCT_YYYYMMDD.csv","FieldNames":"PAOBJNR,ARTNR,KNDNR,ACCT_BUDAT","WhereClause":"ACCT_BUDAT GT YYYYMMDD","EscapeChar":"","Quote":"","Delim":","}',1)
--INSERT INTO #temp_DynamicSAPExtracts Values ('BKPF','{"TableName":"BKPF","FileName":"GB_SAP_BKPF_YYYYMMDD.csv","FieldNames":"BELNR,BLART,BUDAT,BUKRS,GJAHR,HWAE2,HWAER,MONAT,WAERS,XBLNR,BLDAT","WhereClause":"BLDAT GT YYYYMMDD","EscapeChar":"","Quote":"","Delim":"|"}',1)
--INSERT INTO #temp_DynamicSAPExtracts Values ('BSEG','{"TableName":"BSEG","FileName":"GB_SAP_BSEG_YYYYMMDD.csv","FieldNames":"AUFNR,BELNR,BUKRS,GJAHR,BUZEI,BSCHL,DMBE2,DMBTR,HKONT,KOSTL,PRCTR,SHKZG,WRBTR,PAOBJNR,MENGE","WhereClause":"GJAHR GT 2020","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts values ('BKPF','{"TableName":"BKPF","FileName":"GB_SAP_BKPF_YYYYMMDD.csv","FieldNames":"BELNR,BLART,BUDAT,BUKRS,GJAHR,HWAE2,HWAER,MONAT,WAERS,XBLNR,BLDAT,BKTXT","WhereClause":"GJAHR GT 2020","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts values ('BSEG','{"TableName":"BSEG","FileName":"GB_SAP_BSEG_YYYYMMDD.csv","FieldNames":"AUFNR,BELNR,BUKRS,GJAHR,BUZEI,BSCHL,DMBE2,DMBTR,HKONT,KOSTL,PRCTR,SHKZG,WRBTR,PAOBJNR,MENGE,ZUONR,SGTXT,KUNNR","WhereClause":"GJAHR GT 2022","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('CEPCT','{"TableName":"CEPCT","FileName":"GB_SAP_CEPT_YYYYMMDD.csv","FieldNames":"PRCTR,LTEXT","WhereClause":"","EscapeChar":"SPRAS=''EN''","Quote":"","Delim":","}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('SKAT','{"TableName":"SKAT","FileName":"GB_SAP_SKAT_YYYYMMDD.csv","FieldNames":"SAKNR, SPRAS, KTOPL, TXT50","WhereClause":"","EscapeChar":"\\","Quote":"''","Delim":"|"}',1)

---TPM
INSERT INTO #temp_DynamicSAPExtracts Values ('TVV4T','{"TableName":"TVV4T","FileName":"GB_SAP_TVV4T_YYYYMMDD.csv","FieldNames":"KVGR4,SPRAS,BEZEI","WhereClause":"SPRAS EQ ''EN''","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('TVV5T','{"TableName":"TVV5T","FileName":"GB_SAP_TVV5T_YYYYMMDD.csv","FieldNames":"KVGR5,SPRAS,BEZEI","WhereClause":"SPRAS EQ ''EN''","EscapeChar":"","Quote":"","Delim":"|"}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('KNVV','{"TableName":"KNVV","FileName":"GB_SAP_KNVV_YYYYMMDD.csv","FieldNames":"KUNNR,VKORG,ERDAT,KDGRP,WAERS,KVGR1,KVGR2,KVGR3,KVGR4,KVGR5","WhereClause":"","EscapeChar":"","Quote":"","Delim":","}',1)
INSERT INTO #temp_DynamicSAPExtracts Values ('MBEW','{"TableName":"MBEW","FileName":"GB_SAP_MBEW_YYYYMMDD.csv","FieldNames":"MANDT,MATNR,BWKEY,VPRSV,VERPR,STPRS,PEINH","WhereClause":"","EscapeChar":"","Quote":"","Delim":","}',1)


DELETE FROM extract.DynamicSAPExtracts

INSERT INTO extract.DynamicSAPExtracts
SELECT * FROM #temp_DynamicSAPExtracts
WHERE SAPTableName NOT IN (SELECT DISTINCT SAPTableName FROM extract.DynamicSAPExtracts)


﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : Walgreens Product
Domain  : Product 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidNN BIGINT,
		@attributeidUPC_CODE BIGINT,
		@attributeidMFR_NBR BIGINT,
		@entityid_WAGPRD BIGINT,
		@entityid_PSA_WAGPRD BIGINT,
		@entityid_His_WAGPRD BIGINT,
		@entityid_His_PSA_WAGPRD BIGINT;


BEGIN



SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   WAG product
 */

SET @entityid_WAGPRD = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Walgreens product data%');
SET @entityid_PSA_WAGPRD = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'WAGIT_WAGEDW_WalgreensProduct');

SET @entityid_His_WAGPRD = (SELECT entityid FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%WalgreensProduct Ingestion%');
SET @entityid_His_PSA_WAGPRD = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_WalgreensProduct');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SKNSNO7 AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SKNSNO7 AND attributeName IN 
--('DateSplit','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_WAGPRD,@entityid_His_PSA_WAGPRD);

--Incremental
-- Find the attributeId
SET @attributeidUPC_CODE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC_CODE' AND
entityid = @entityid_WAGPRD);


PRINT @attributeidUPC_CODE


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_WAGPRD,@attributeidUPC_CODE,28004,'28001',NULL,1,@insert_date,@insert_user);

-- Find the attributeId
SET @attributeidMFR_NBR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'MFR_NBR' AND
entityid = @entityid_WAGPRD);


PRINT @attributeidMFR_NBR


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_WAGPRD,@attributeidMFR_NBR,28004,'28001',NULL,1,@insert_date,@insert_user);

--History
-- Find the attributeId

SET @attributeidUPC_CODE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC_CODE' AND
entityid = @entityid_His_WAGPRD);


PRINT @attributeidUPC_CODE


--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_WAGPRD,@attributeidUPC_CODE,28004,'28001',NULL,1,@insert_date,@insert_user);



END
﻿IF OBJECT_ID('tempdb..#dq_Rule') IS NOT NULL
    DROP TABLE #dq_Rule

CREATE TABLE #dq_Rule
(
	[RuleID] [int] NOT NULL,
	[RuleCode] [nvarchar](20) NOT NULL,
	[RuleName] [nvarchar](128) NOT NULL,
	[RuleDescription] [nvarchar](1024) NULL,
	[Logic] [nvarchar](4000) NULL,
	[ScopeID] [int] NOT NULL,
	[GroupID] [int] NOT NULL,
	[ActiveFlag] [smallint] NOT NULL,
	[DTCreated] [smalldatetime] NULL,
	[UserCreated] [nchar](100) NULL
)
  

INSERT INTO #dq_Rule ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES 
(0,'0Or-1','0Or-1','0Or-1','Check in code',21002,22005,1,@insert_date,@insert_user)
INSERT INTO #dq_Rule ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES 
(0,'FDC','FutureDatesCheck','FutureDatesCheck','Check in code',21002,22005,1,@insert_date,@insert_user)
INSERT INTO #dq_Rule ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES 
(0,'QBWQ','QueryBasedWQ','QueryBasedWQ','Check in code',21002,22005,1,@insert_date,@insert_user)
INSERT INTO #dq_Rule ([RuleID],[RuleCode],[RuleName],[RuleDescription],[Logic],[ScopeID],[GroupID],[ActiveFlag],[DTCreated],[UserCreated]) VALUES 
(0,'blank check','blank check','blank check','Check in code',21002,22005,1,@insert_date,@insert_user)





INSERT INTO psa.[Rule]
select 
	max_RuleID + row_number() OVER (ORDER BY RuleName) as [RuleID],
	[RuleCode],
	[RuleName],
	[RuleDescription],
	[Logic],
	[ScopeID],
	[GroupID],
	[ActiveFlag],
	[DTCreated],
	[UserCreated]
from #dq_Rule
inner join (select max(RuleID) max_RuleID from [psa].[Rule]) max_pk ON (1=1)
WHERE RuleName NOT IN (select distinct [RuleName] from [psa].[Rule])
﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : TSGAAFES
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidDC BIGINT,
		@ruleidNN BIGINT,
		@attributeidFILEDATE BIGINT,
		@attributeidFAC7DIGITNUMBER BIGINT,
		@attributeidUPC BIGINT,
		@entityid_TSGAAFES BIGINT,
		@entityid_PSA_TSGAAFES BIGINT,
		@entityid_His_TSGAAFES BIGINT,
		@entityid_His_PSA_TSGAAFES BIGINT;

BEGIN


SET @ruleidDC = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'DC' AND rulename = 'Date Check' AND activeflag = '1');
SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   TSGAAFES
 */

 
SET @entityid_TSGAAFES = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of The Singer Group (Army) data%' );
SET @entityid_PSA_TSGAAFES = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'TSG_TSGEXCEL_TSGAAFES');

SET @entityid_His_TSGAAFES = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%TSGAAFES Ingestion%');
SET @entityid_His_PSA_TSGAAFES = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_TSGAAFES');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_TSGAAFES AND attributeName IN 
--('FILEDATE','FAC7DIGITNUMBER','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_TSGAAFES AND attributeName IN 
--('FILEDATE','FAC7DIGITNUMBER','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_TSGAAFES,@entityid_His_PSA_TSGAAFES);




-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_TSGAAFES);
SET @attributeidFAC7DIGITNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FAC7DIGITNUMBER' AND
entityid = @entityid_TSGAAFES);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND entityid = @entityid_TSGAAFES);

PRINT @attributeidFILEDATE
PRINT @attributeidFAC7DIGITNUMBER
PRINT @attributeidUPC

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGAAFES,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGAAFES,@attributeidFAC7DIGITNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_TSGAAFES,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_PSA_TSGAAFES,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"21"}',1,@insert_date,@insert_user);




--History
-- Find the attributeId
SET @attributeidFILEDATE = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FILEDATE' AND 
entityid = @entityid_His_TSGAAFES);
SET @attributeidFAC7DIGITNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FAC7DIGITNUMBER' AND
entityid = @entityid_His_TSGAAFES);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND entityid = @entityid_His_TSGAAFES);

PRINT @attributeidFILEDATE
PRINT @attributeidFAC7DIGITNUMBER
PRINT @attributeidUPC

--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGAAFES,@attributeidFILEDATE,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGAAFES,@attributeidFAC7DIGITNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_TSGAAFES,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);

--Insert to RuleEntity for DateCheck checks for transactiondatetime 

INSERT INTO psa.ruleentity VALUES (@ruleidDC,@entityid_His_PSA_TSGAAFES,@attributeidFILEDATE,28004,'28001',
'{"DateFormatSQLServer":"21"}',1,@insert_date,@insert_user);
END
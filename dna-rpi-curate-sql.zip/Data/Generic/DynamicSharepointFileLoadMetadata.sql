﻿IF OBJECT_ID('tempdb..#DynamicSharepointFileLoadMetadata') IS NOT NULL
    DROP TABLE #DynamicSharepointFileLoadMetadata

CREATE TABLE #DynamicSharepointFileLoadMetadata(
	[ActionID] [int] NOT NULL,
	[ActionName] [varchar](255) NULL,
	[ServerName] [varchar](255) NULL,
	[DatabaseName] [varchar](255) NULL,
	[DBSchema] [char](15) NOT NULL,
	[TableName] [varchar](100) NULL,
	[StoredProcedure] [varchar](255) NULL,
	[LastUpdate] [datetime2](7) NOT NULL,
	[IsActive] [bit] NULL,
	[LogicAppName] [varchar](255) NULL
)


INSERT INTO #DynamicSharepointFileLoadMetadata ([ActionID],[ActionName],[ServerName],[DatabaseName],[DBSchema],[TableName],[StoredProcedure],[LastUpdate],[IsActive],[LogicAppName]) VALUES (0,'Check File Last Updated','prod-dna-northeurope-prod-ssrv01.database.windows.net','prod-data-northeurope-prod-dwh-01','dc_metadata    ','DynamicSharepointFileLoad','uspCheckSharepointFileLastUpdated','2020-03-06 14:58:00.0000000',1,'laGDHDynamicSharepointFileLoad')
INSERT INTO #DynamicSharepointFileLoadMetadata ([ActionID],[ActionName],[ServerName],[DatabaseName],[DBSchema],[TableName],[StoredProcedure],[LastUpdate],[IsActive],[LogicAppName]) VALUES (0,'Check valid Sharepoint Folder Name in DDBB','prod-dna-northeurope-prod-ssrv01.database.windows.net','prod-data-northeurope-prod-dwh-01','dc_metadata    ','DynamicSharepointFileLoad','uspValidateSharepointFolder','2020-03-06 14:58:00.0000000',1,'laGDHDynamicSharepointFileLoad')
INSERT INTO #DynamicSharepointFileLoadMetadata ([ActionID],[ActionName],[ServerName],[DatabaseName],[DBSchema],[TableName],[StoredProcedure],[LastUpdate],[IsActive],[LogicAppName]) VALUES (0,'Get Sharepoint Roots from DDBB','prod-dna-northeurope-prod-ssrv01.database.windows.net','prod-data-northeurope-prod-dwh-01','dc_metadata    ','DynamicSharepointFileLoad','uspGetSharepointRoots','2020-03-06 14:58:00.0000000',1,'laGDHDynamicSharepointFileLoad')
INSERT INTO #DynamicSharepointFileLoadMetadata ([ActionID],[ActionName],[ServerName],[DatabaseName],[DBSchema],[TableName],[StoredProcedure],[LastUpdate],[IsActive],[LogicAppName]) VALUES (0,'Check valid Filename in DDBB','prod-dna-northeurope-prod-ssrv01.database.windows.net','prod-data-northeurope-prod-dwh-01','dc_metadata    ','DynamicSharepointFileLoad','uspValidateSharepointFileName','2020-03-06 14:58:00.0000000',1,'laGDHDynamicSharepointFileLoad')
INSERT INTO #DynamicSharepointFileLoadMetadata ([ActionID],[ActionName],[ServerName],[DatabaseName],[DBSchema],[TableName],[StoredProcedure],[LastUpdate],[IsActive],[LogicAppName]) VALUES (0,'Log File Movement to GBA Audit','prod-dna-northeurope-prod-ssrv01.database.windows.net','prod-data-northeurope-prod-dwh-01','dc_metadata    ','DynamicSharepointFileLoadAudit','uspInsertRowIntoSharepointAudit','2020-03-06 14:58:00.0000000',1,'laGDHDynamicSharepointFileLoad')
INSERT INTO #DynamicSharepointFileLoadMetadata ([ActionID],[ActionName],[ServerName],[DatabaseName],[DBSchema],[TableName],[StoredProcedure],[LastUpdate],[IsActive],[LogicAppName]) VALUES (0,'Update Last Modified Date in Files Table','prod-dna-northeurope-prod-ssrv01.database.windows.net','prod-data-northeurope-prod-dwh-01','dc_metadata    ','DynamicSharepointFileLoad','uspUpdateFileLastUpdatedField','2020-03-06 14:58:00.0000000',1,'laGDHDynamicSharepointFileLoad')


INSERT INTO dc_metadata.[DynamicSharepointFileLoadMetadata]
SELECT 
	COALESCE(max_ActionID,0) + row_number() OVER (ORDER BY tmp.[ActionName]) as [ActionID],
	tmp.[ActionName],
	tmp.[ServerName],
	tmp.[DatabaseName],
	tmp.[DBSchema],
	tmp.[TableName],
	tmp.[StoredProcedure],
	tmp.[LastUpdate],
	tmp.[IsActive],
	tmp.[LogicAppName]
FROM #DynamicSharepointFileLoadMetadata tmp
JOIN (SELECT MAX(ActionID) max_ActionID FROM dc_metadata.[DynamicSharepointFileLoadMetadata]) max_pk ON (1=1)
LEFT OUTER JOIN (SELECT DISTINCT [ActionName] FROM dc_metadata.[DynamicSharepointFileLoadMetadata]) src
ON src.ActionName = tmp.ActionName
WHERE src.ActionName IS NULL
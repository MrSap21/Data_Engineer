﻿IF OBJECT_ID('tempdb..#GDHDynamicADFParams') IS NOT NULL
    DROP TABLE #GDHDynamicADFParams

CREATE TABLE #GDHDynamicADFParams(
	[Project_Name] [nvarchar](200) NOT NULL,
	[Job_name] [nvarchar](200) NULL,
	[Environment] [char](5) NULL,
    [Process_Name] [nvarchar](200) NOT NULL,
	[Param_key] [nvarchar](200) NOT NULL,
	[Param_value] [nvarchar](4000) NULL
)


insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','TableName','BUKIT_EDI_UltaEDIStoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','GDHServeFilePath','serve/GBA/ULTAEDI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','IFLandingFilePath','ULTA/ULTAEXCEL/UltaEDI/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','FilePrefix','ulta');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','GDHArchiveFilePath','archive/GBA/ULTAEDI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','GDHRawFilePath','raw/GBA/ULTAEDI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaEDI_prod','Delimiter',',');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','TableName','WAGIT_WAGEDW_Store');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','GDHServeFilePath','serve/GBA/WalgreensStore');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','IFLandingFilePath','WAGIT/WAGEDW/WalgreensStore/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','FilePrefix','WAGUS_WAGEDW_store');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','GDHArchiveFilePath','archive/GBA/WalgreensStore');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensStore_prod','GDHRawFilePath','raw/GBA/WalgreensStore');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','TableName','TSG_MCX_No7_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','GDHServeFilePath','serve/GBA/TSGMCXNo7');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','IFLandingFilePath','TSG/TSG_UNKNOWN/TSGMCXNo7/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','FilePrefix','MCX');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','GDHArchiveFilePath','archive/GBA/TSGMCXNo7');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','Retailer','TSGMV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGMCXNo7_prod','GDHRawFilePath','raw/GBA/TSGMCXNo7');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','TableName','GBFIN_ConversionRate');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','GDHServeFilePath','serve/GBA/GBFINConversionRate');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','IFLandingFilePath','GBFIN/MSEXCEL/GBFINConversionRate/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','FilePrefix','Budget FX Rates');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','GDHArchiveFilePath','archive/GBA/GBFINConversionRate');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINConversionRate_prod','GDHRawFilePath','raw/GBA/GBFINConversionRate');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','TableName','WAGIT_WAGEDW_Product');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','GDHServeFilePath','serve/GBA/WalgreensProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','IFLandingFilePath','WAGIT/WAGIDH/WalgreensProduct/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','FilePrefix','WAGUS_WAGEDW_products');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','GDHArchiveFilePath','archive/GBA/WalgreensProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','Retailer','WagProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','DecryptionRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','DecryptionFolder','serve/GBA_Decrypt/WalgreensProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','DecryptionKeyVault','aznednakvprod01');----GDH-Prod-KeyVault-Servic
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','DecryptionSecretName','gpg-prod-passphrase');----Global-Data-Hub-Passphrase-GPG
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','DecryptionWebhookURL','https://s9events.azure-automation.net/webhooks?token=6GW2Ejf%2fMZIgZq1JIxTyILGE78RCvqosv9L4%2bUCM1m8%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensProduct_prod','GDHRawFilePath','raw/GBA/WalgreensProduct');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','TableName','WAGIT_WAGEDW_Transaction_Cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','GDHServeFilePath','serve/GBA/WalgreensTransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','IFLandingFilePath','WAGIT/WAGEDW/WalgreensTransactionCost/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','FilePrefix','WAGUS_WAGEDW_transactions_cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','GDHArchiveFilePath','archive/GBA/WalgreensTransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransactionCost_prod','GDHRawFilePath','raw/GBA/WalgreensTransactionCost');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','TableName','WAGIT_WAGEDW_ETransaction_Cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','GDHServeFilePath','serve/GBA/WalgreensETransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','IFLandingFilePath','WAGIT/WAGEDW/WalgreensETransactionCost/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','FilePrefix','WAGUS_WAGEDW_etransactions_cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','GDHArchiveFilePath','archive/GBA/WalgreensETransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransactionCost_prod','GDHRawFilePath','raw/GBA/WalgreensETransactionCost');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','TableName','WAGIT_WAGEDW_Basket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','GDHServeFilePath','serve/GBA/WalgreensBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','IFLandingFilePath','WAGIT/WAGIDH/WalgreensBasket/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','FilePrefix','WAGUS_WAGIDH_baskets');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','GDHArchiveFilePath','archive/GBA/WalgreensBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensBasket_prod','GDHRawFilePath','raw/GBA/WalgreensBasket');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','TableName','ULTA_WEBP_UltaSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','GDHServeFilePath','serve/GBA/UltaWeb');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','IFLandingFilePath','ULTA/ULTAEXCEL/UltaWeb/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','FilePrefix','Sales-Inv-');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','GDHArchiveFilePath','archive/GBA/UltaWeb');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','Retailer','ULTA');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWeb_prod','GDHRawFilePath','raw/GBA/UltaWeb');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','TableName','WAGIT_WAGEDW_Etransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','GDHServeFilePath','serve/GBA/WalgreensETransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','IFLandingFilePath','WAGIT/WAGIDH/WalgreensETransaction/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','FilePrefix','WAGUS_WAGIDH_etransactions');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','GDHArchiveFilePath','archive/GBA/WalgreensETransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensETransaction_prod','GDHRawFilePath','raw/GBA/WalgreensETransaction');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','TableName','SKINSTORE_No7_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','GDHServeFilePath','serve/GBA/SKINSTORE_No7_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','IFLandingFilePath','SKINSTORE/SKINSTORE_UNKNOWN/SKINSTORE_No7_WeeklyRetailSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','FilePrefix','no7 wk');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','GDHArchiveFilePath','archive/GBA/SKINSTORE_No7_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','Retailer','SKINNO7');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_No7_WeeklyRetailSales_prod','GDHRawFilePath','raw/GBA/SKINSTORE_No7_WeeklyRetailSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','TableName','GBMDT_Sap_Material_Sales_Reporting_Master_Data');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','GDHServeFilePath','serve/GBA/GBMDTProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','IFLandingFilePath','GBMDT/MSEXCEL/GBMDTProduct/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','FilePrefix','SAP Material Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','GDHArchiveFilePath','archive/GBA/GBMDTProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','Retailer','SAPMasterFilesNew');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBMDTProduct_prod','GDHRawFilePath','raw/GBA/GBMDTProduct');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','TableName','GBFIN_StoreMaster');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','GDHServeFilePath','serve/GBA/GBFINStoreMaster');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','IFLandingFilePath','GBFIN/MSEXCEL/GBFINStoreMaster/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','FilePrefix','BRUSA Store List');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','GDHArchiveFilePath','archive/GBA/GBFINStoreMaster');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','Retailer','StoreV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINStoreMaster_prod','GDHRawFilePath','raw/GBA/GBFINStoreMaster');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','TableName','SKINSTORE_SG_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','GDHServeFilePath','serve/GBA/SKINSTORE_SG_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','IFLandingFilePath','SKINSTORE/SKINSTORE_UNKNOWN/SKINSTORE_SG_WeeklyRetailSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','FilePrefix','SG sales wk');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','GDHArchiveFilePath','archive/GBA/SKINSTORE_SG_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','Retailer','SKINSG');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSKINSTORE_SG_WeeklyRetailSales_prod','GDHRawFilePath','raw/GBA/SKINSTORE_SG_WeeklyRetailSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','TableName','GBFIN_Retailer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','GDHServeFilePath','serve/GBA/GBFINRetailer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','IFLandingFilePath','GBFIN/MSEXCEL/GBFINRetailer/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','FilePrefix','BRUSA Qlik CUSTOMER');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','GDHArchiveFilePath','archive/GBA/GBFINRetailer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','Retailer','BrusaCustomer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailer_prod','GDHRawFilePath','raw/GBA/GBFINRetailer');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','TableName','GBFIN_RetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','GDHServeFilePath','serve/GBA/GBFINRetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','IFLandingFilePath','GBFIN/MSEXCEL/GBFINRetailerCalendar/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','FilePrefix','BRUSA Qlik Date by Week Retailers');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','GDHArchiveFilePath','archive/GBA/GBFINRetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','Retailer','BrusaRetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINRetailerCalendar_prod','GDHRawFilePath','raw/GBA/GBFINRetailer');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','TableName','GBFIN_Calendar_Incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','GDHServeFilePath','serve/GBA/GBFINCalendarIncr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','IFLandingFilePath','GBFIN/GBFINEXCEL/GB_Calendar_information_GBFINEXCEL_incr/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','FilePrefix','GB_calendar_information_');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','GDHArchiveFilePath','archive/GBA/GBFINCalendarIncr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','Retailer','GBFINCalendarIncr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINCalendarIncr_prod','GDHRawFilePath','raw/GBA/GBFINCalendarIncr');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','TableName','Walgreens_RSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','GDHServeFilePath','serve/GBA/WalgreensRSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','IFLandingFilePath','DATALYNX/WAGX/GB_Daily_Walgreens_Sales_from_RSI_WAGX/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','FilePrefix','Alliance Boots_Walgreens_ADHOC_');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','GDHArchiveFilePath','archive/GBA/WalgreensRSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','Retailer','WalgreensRSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensRSI_prod','GDHRawFilePath','raw/GBA/WalgreensRSI');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','TableName','WAGIT_WAGEDW_Transaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','GDHServeFilePath','serve/GBA/WalgreensTransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','IFLandingFilePath','WAGIT/WAGIDH/WalgreensTransaction/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','FilePrefix','WAGUS_WAGIDH_transactions');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','GDHArchiveFilePath','archive/GBA/WalgreensTransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensTransaction_prod','GDHRawFilePath','raw/GBA/WalgreensTransaction');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','TableName','WAGIT_WAGEDW_Ebasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','GDHServeFilePath','serve/GBA/WalgreensEBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','IFLandingFilePath','WAGIT/WAGIDH/WalgreensEBasket/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','FilePrefix','WAGUS_WAGIDH_ebaskets');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','GDHArchiveFilePath','archive/GBA/WalgreensEBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalgreensEBasket_prod','GDHRawFilePath','raw/GBA/WalgreensEBasket');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','TableName','SDM_SG_BB_Weekly_Esales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','GDHServeFilePath','serve/GBA/SDMSGESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMSGESales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','FilePrefix','S&G Beauty');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','GDHArchiveFilePath','archive/GBA/SDMSGESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','Retailer','SDMSGE');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGESales_prod','GDHRawFilePath','raw/GBA/SDMSGESales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','TableName','TSG_AAFES_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','GDHServeFilePath','serve/GBA/TSGAAFES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','IFLandingFilePath','TSG/TSG_UNKNOWN/TSGAAFES/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','FilePrefix','AAFES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','GDHArchiveFilePath','archive/GBA/TSGAAFES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','Retailer','TSGAV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGAAFES_prod','GDHRawFilePath','raw/GBA/TSGAAFES');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','TableName','SDM_No7_Store_Weekly_Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','GDHServeFilePath','serve/GBA/SDMNo7StoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMNo7StoreSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','FilePrefix','No_7 Sales By Store');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','GDHArchiveFilePath','archive/GBA/SDMNo7StoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','Retailer','SDMNO7BM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7StoreSales_prod','GDHRawFilePath','raw/GBA/SDMNo7StoreSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','TableName','DERMSTORE_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','GDHServeFilePath','serve/GBA/DermstoreRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','IFLandingFilePath','DERMSTORE/DERMSTORE_UNKNOWN/DermstoreRetailSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','FilePrefix','No7_505424');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','GDHArchiveFilePath','archive/GBA/DermstoreRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDermstoreRetailSales_prod','GDHRawFilePath','raw/GBA/DermstoreRetailSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','TableName','SDM_No7_BB_Weekly_Esales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','GDHServeFilePath','serve/GBA/SDMNo7ESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMNo7ESales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','FilePrefix','No_7 Beauty');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','GDHArchiveFilePath','archive/GBA/SDMNo7ESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','Retailer','SDMNO7E');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMNo7ESales_prod','GDHRawFilePath','raw/GBA/SDMNo7ESales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','TableName','SDM_SG_Store_Weekly_Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','GDHServeFilePath','serve/GBA/SDMSGStoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMSGStoreSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','FilePrefix','S&G Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','GDHArchiveFilePath','archive/GBA/SDMSGStoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','Retailer','SDMSGBM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadSDMSGStoreSales_prod','GDHRawFilePath','raw/GBA/SDMSGStoreSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','TableName','TSG_NEXCOM_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','GDHServeFilePath','serve/GBA/TSGNEXCOM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','IFLandingFilePath','TSG/TSG_UNKNOWN/TSGNEXCOM/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','FilePrefix','Nexcom');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','GDHArchiveFilePath','archive/GBA/TSGNEXCOM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','Retailer','TSGNV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTSGNEXCOM_prod','GDHRawFilePath','raw/GBA/TSGNEXCOM');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','TableName','DNA_CountryISO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','GDHServeFilePath','serve/GBA/DNACountryISO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','IFLandingFilePath','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','FilePrefix','countryiso');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','GDHArchiveFilePath','archive/GBA/DNACountryISO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadDNACountryISO_prod','GDHRawFilePath','raw/GBA/DNACountryISO');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','TableName','TARGET_Transactions');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','GDHServeFilePath','serve/GBA/TargetSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','IFLandingFilePath','TGT-IT/TGT-WP/TargetSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','FilePrefix','GDH Daily Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','GDHArchiveFilePath','archive/GBA/TargetSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','Retailer','TARGET');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadTargetSales_prod','GDHRawFilePath','raw/GBA/TargetSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','TableName','GBFIN_BusinessChannel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','GDHServeFilePath','serve/GBA/GBFINBusinessChannel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','IFLandingFilePath','WAGIT/DNARDM/GBFINBusinessChannel/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','FilePrefix','Business Channel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','GDHArchiveFilePath','archive/GBA/GBFINBusinessChannel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGBFINBusinessChannel_prod','GDHRawFilePath','raw/GBA/GBFINBusinessChannel');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','TableName','ULTA_WEBP_UltaSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','GDHServeFilePath','serve/GBA/UltaWebHist');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','IFLandingFilePath','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','FilePrefix','Ulta Raw Data');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','GDHArchiveFilePath','archive/GBA/UltaWebHist');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadUltaWebHist_prod','GDHRawFilePath','raw/GBA/UltaWebHist');



insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','TableName','BUKIT_EDI_UltaEDIStoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','GDHServeFilePath','serve/GBA/ULTAEDI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','IFLandingFilePath','ULTA/ULTAEXCEL/UltaEDI/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','FilePrefix','ulta');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','GDHArchiveFilePath','archive/GBA/ULTAEDI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','GDHRawFilePath','raw/GBA/ULTAEDI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaEDI_pp','Delimiter',',');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','TableName','WAGIT_WAGEDW_Store');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','GDHServeFilePath','serve/GBA/WalgreensStore');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','IFLandingFilePath','WAGIT/WAGEDW/WalgreensStore/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','FilePrefix','WAGUS_WAGEDW_store');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','GDHArchiveFilePath','archive/GBA/WalgreensStore');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensStore_pp','GDHRawFilePath','raw/GBA/WalgreensStore');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','TableName','TSG_MCX_No7_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','GDHServeFilePath','serve/GBA/TSGMCXNo7');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','IFLandingFilePath','TSG/TSG_UNKNOWN/TSGMCXNo7/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','FilePrefix','MCX');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','GDHArchiveFilePath','archive/GBA/TSGMCXNo7');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','Retailer','TSGMV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGMCXNo7_pp','GDHRawFilePath','raw/GBA/TSGMCXNo7');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','TableName','GBFIN_ConversionRate');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','GDHServeFilePath','serve/GBA/GBFINConversionRate');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','IFLandingFilePath','GBFIN/MSEXCEL/GBFINConversionRate/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','FilePrefix','Budget FX Rates');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','GDHArchiveFilePath','archive/GBA/GBFINConversionRate');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINConversionRate_pp','GDHRawFilePath','raw/GBA/GBFINConversionRate');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','TableName','WAGIT_WAGEDW_Product');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','GDHServeFilePath','serve/GBA/WalgreensProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','IFLandingFilePath','WAGIT/WAGIDH/WalgreensProduct/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','FilePrefix','WAGUS_WAGEDW_products');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','GDHArchiveFilePath','archive/GBA/WalgreensProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','Retailer','WagProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','DecryptionRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','DecryptionFolder','serve/GBA_Decrypt/WalgreensProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','DecryptionKeyVault','aznegbitkvdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','DecryptionSecretName','Global-Data-Hub-Passphrase-GPG');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','DecryptionWebhookURL','https://s9events.azure-automation.net/webhooks?token=0s%2f5%2bkCdgrq2glpgOjcKHeHKbaNe%2bGl%2fqrUrKbeFIzQ%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensProduct_pp','GDHRawFilePath','raw/GBA/WalgreensProduct');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','TableName','WAGIT_WAGEDW_Transaction_Cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','GDHServeFilePath','serve/GBA/WalgreensTransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','IFLandingFilePath','WAGIT/WAGEDW/WalgreensTransactionCost/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','FilePrefix','WAGUS_WAGEDW_transactions_cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','GDHArchiveFilePath','archive/GBA/WalgreensTransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransactionCost_pp','GDHRawFilePath','raw/GBA/WalgreensTransactionCost');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','TableName','WAGIT_WAGEDW_ETransaction_Cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','GDHServeFilePath','serve/GBA/WalgreensETransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','IFLandingFilePath','WAGIT/WAGEDW/WalgreensETransactionCost/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','FilePrefix','WAGUS_WAGEDW_etransactions_cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','GDHArchiveFilePath','archive/GBA/WalgreensETransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransactionCost_pp','GDHRawFilePath','raw/GBA/WalgreensETransactionCost');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','TableName','WAGIT_WAGEDW_Basket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','GDHServeFilePath','serve/GBA/WalgreensBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','IFLandingFilePath','WAGIT/WAGIDH/WalgreensBasket/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','FilePrefix','WAGUS_WAGIDH_baskets');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','GDHArchiveFilePath','archive/GBA/WalgreensBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensBasket_pp','GDHRawFilePath','raw/GBA/WalgreensBasket');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','TableName','ULTA_WEBP_UltaSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','GDHServeFilePath','serve/GBA/UltaWeb');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','IFLandingFilePath','ULTA/ULTAEXCEL/UltaWeb/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','FilePrefix','Sales-Inv-');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','GDHArchiveFilePath','archive/GBA/UltaWeb');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','Retailer','ULTA');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWeb_pp','GDHRawFilePath','raw/GBA/UltaWeb');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','TableName','WAGIT_WAGEDW_Etransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','GDHServeFilePath','serve/GBA/WalgreensETransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','IFLandingFilePath','WAGIT/WAGIDH/WalgreensETransaction/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','FilePrefix','WAGUS_WAGIDH_etransactions');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','GDHArchiveFilePath','archive/GBA/WalgreensETransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensETransaction_pp','GDHRawFilePath','raw/GBA/WalgreensETransaction');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','TableName','SKINSTORE_No7_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','GDHServeFilePath','serve/GBA/SKINSTORE_No7_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','IFLandingFilePath','SKINSTORE/SKINSTORE_UNKNOWN/SKINSTORE_No7_WeeklyRetailSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','FilePrefix','no7 wk');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','GDHArchiveFilePath','archive/GBA/SKINSTORE_No7_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','Retailer','SKINNO7');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_No7_WeeklyRetailSales_pp','GDHRawFilePath','raw/GBA/SKINSTORE_No7_WeeklyRetailSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','TableName','GBMDT_Sap_Material_Sales_Reporting_Master_Data');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','GDHServeFilePath','serve/GBA/GBMDTProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','IFLandingFilePath','GBMDT/MSEXCEL/GBMDTProduct/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','FilePrefix','SAP Material Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','GDHArchiveFilePath','archive/GBA/GBMDTProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','Retailer','SAPMasterFilesNew');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBMDTProduct_pp','GDHRawFilePath','raw/GBA/GBMDTProduct');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','TableName','GBFIN_StoreMaster');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','GDHServeFilePath','serve/GBA/GBFINStoreMaster');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','IFLandingFilePath','GBFIN/MSEXCEL/GBFINStoreMaster/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','FilePrefix','BRUSA Store List');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','GDHArchiveFilePath','archive/GBA/GBFINStoreMaster');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','Retailer','StoreV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINStoreMaster_pp','GDHRawFilePath','raw/GBA/GBFINStoreMaster');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','TableName','SKINSTORE_SG_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','GDHServeFilePath','serve/GBA/SKINSTORE_SG_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','IFLandingFilePath','SKINSTORE/SKINSTORE_UNKNOWN/SKINSTORE_SG_WeeklyRetailSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','FilePrefix','SG sales wk');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','GDHArchiveFilePath','archive/GBA/SKINSTORE_SG_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','Retailer','SKINSG');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSKINSTORE_SG_WeeklyRetailSales_pp','GDHRawFilePath','raw/GBA/SKINSTORE_SG_WeeklyRetailSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','TableName','GBFIN_Retailer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','GDHServeFilePath','serve/GBA/GBFINRetailer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','IFLandingFilePath','GBFIN/MSEXCEL/GBFINRetailer/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','FilePrefix','BRUSA Qlik CUSTOMER');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','GDHArchiveFilePath','archive/GBA/GBFINRetailer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','Retailer','BrusaCustomer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailer_pp','GDHRawFilePath','raw/GBA/GBFINRetailer');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','TableName','GBFIN_RetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','GDHServeFilePath','serve/GBA/GBFINRetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','IFLandingFilePath','GBFIN/MSEXCEL/GBFINRetailerCalendar/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','FilePrefix','BRUSA Qlik Date by Week Retailers');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','GDHArchiveFilePath','archive/GBA/GBFINRetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','Retailer','BrusaRetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINRetailerCalendar_pp','GDHRawFilePath','raw/GBA/GBFINRetailer');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','TableName','GBFIN_Calendar_Incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','GDHServeFilePath','serve/GBA/GBFINCalendarIncr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','IFLandingFilePath','GBFIN/GBFINEXCEL/GB_Calendar_information_GBFINEXCEL_incr/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','FilePrefix','GB_calendar_information_');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','GDHArchiveFilePath','archive/GBA/GBFINCalendarIncr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','Retailer','GBFINCalendarIncr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINCalendarIncr_pp','GDHRawFilePath','raw/GBA/GBFINCalendarIncr');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','TableName','Walgreens_RSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','GDHServeFilePath','serve/GBA/WalgreensRSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','IFLandingFilePath','DATALYNX/WAGX/GB_Daily_Walgreens_Sales_from_RSI_WAGX/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','FilePrefix','Alliance Boots_Walgreens_ADHOC_');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','GDHArchiveFilePath','archive/GBA/WalgreensRSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','Retailer','WalgreensRSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensRSI_pp','GDHRawFilePath','raw/GBA/WalgreensRSI');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','TableName','WAGIT_WAGEDW_Transaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','GDHServeFilePath','serve/GBA/WalgreensTransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','IFLandingFilePath','WAGIT/WAGIDH/WalgreensTransaction/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','FilePrefix','WAGUS_WAGIDH_transactions');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','GDHArchiveFilePath','archive/GBA/WalgreensTransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensTransaction_pp','GDHRawFilePath','raw/GBA/WalgreensTransaction');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','TableName','WAGIT_WAGEDW_Ebasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','GDHServeFilePath','serve/GBA/WalgreensEBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','IFLandingFilePath','WAGIT/WAGIDH/WalgreensEBasket/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','FilePrefix','WAGUS_WAGIDH_ebaskets');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','GDHArchiveFilePath','archive/GBA/WalgreensEBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalgreensEBasket_pp','GDHRawFilePath','raw/GBA/WalgreensEBasket');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','TableName','SDM_SG_BB_Weekly_Esales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','GDHServeFilePath','serve/GBA/SDMSGESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMSGESales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','FilePrefix','S&G Beauty');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','GDHArchiveFilePath','archive/GBA/SDMSGESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','Retailer','SDMSGE');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGESales_pp','GDHRawFilePath','raw/GBA/SDMSGESales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','TableName','TSG_AAFES_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','GDHServeFilePath','serve/GBA/TSGAAFES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','IFLandingFilePath','TSG/TSG_UNKNOWN/TSGAAFES/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','FilePrefix','AAFES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','GDHArchiveFilePath','archive/GBA/TSGAAFES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','Retailer','TSGAV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGAAFES_pp','GDHRawFilePath','raw/GBA/TSGAAFES');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','TableName','SDM_No7_Store_Weekly_Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','GDHServeFilePath','serve/GBA/SDMNo7StoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMNo7StoreSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','FilePrefix','No_7 Sales By Store');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','GDHArchiveFilePath','archive/GBA/SDMNo7StoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','Retailer','SDMNO7BM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7StoreSales_pp','GDHRawFilePath','raw/GBA/SDMNo7StoreSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','TableName','DERMSTORE_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','GDHServeFilePath','serve/GBA/DermstoreRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','IFLandingFilePath','DERMSTORE/DERMSTORE_UNKNOWN/DermstoreRetailSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','FilePrefix','No7_505424');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','GDHArchiveFilePath','archive/GBA/DermstoreRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDermstoreRetailSales_pp','GDHRawFilePath','raw/GBA/DermstoreRetailSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','TableName','SDM_No7_BB_Weekly_Esales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','GDHServeFilePath','serve/GBA/SDMNo7ESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMNo7ESales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','FilePrefix','No_7 Beauty');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','GDHArchiveFilePath','archive/GBA/SDMNo7ESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','Retailer','SDMNO7E');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMNo7ESales_pp','GDHRawFilePath','raw/GBA/SDMNo7ESales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','TableName','SDM_SG_Store_Weekly_Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','GDHServeFilePath','serve/GBA/SDMSGStoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMSGStoreSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','FilePrefix','S&G Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','GDHArchiveFilePath','archive/GBA/SDMSGStoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','Retailer','SDMSGBM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadSDMSGStoreSales_pp','GDHRawFilePath','raw/GBA/SDMSGStoreSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','TableName','TSG_NEXCOM_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','GDHServeFilePath','serve/GBA/TSGNEXCOM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','IFLandingFilePath','TSG/TSG_UNKNOWN/TSGNEXCOM/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','FilePrefix','Nexcom');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','GDHArchiveFilePath','archive/GBA/TSGNEXCOM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','Retailer','TSGNV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTSGNEXCOM_pp','GDHRawFilePath','raw/GBA/TSGNEXCOM');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','TableName','DNA_CountryISO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','GDHServeFilePath','serve/GBA/DNACountryISO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','IFLandingFilePath','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','FilePrefix','countryiso');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','GDHArchiveFilePath','archive/GBA/DNACountryISO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadDNACountryISO_pp','GDHRawFilePath','raw/GBA/DNACountryISO');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','TableName','TARGET_Transactions');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','GDHServeFilePath','serve/GBA/TargetSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','IFLandingFilePath','TGT-IT/TGT-WP/TargetSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','FilePrefix','GDH Daily Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','GDHArchiveFilePath','archive/GBA/TargetSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','Retailer','TARGET');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadTargetSales_pp','GDHRawFilePath','raw/GBA/TargetSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','TableName','GBFIN_BusinessChannel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','GDHServeFilePath','serve/GBA/GBFINBusinessChannel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','IFLandingFilePath','WAGIT/DNARDM/GBFINBusinessChannel/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','FilePrefix','Business Channel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','GDHArchiveFilePath','archive/GBA/GBFINBusinessChannel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGBFINBusinessChannel_pp','GDHRawFilePath','raw/GBA/GBFINBusinessChannel');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','TableName','ULTA_WEBP_UltaSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','GDHServeFilePath','serve/GBA/UltaWebHist');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','IFLandingFilePath','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','FilePrefix','Ulta Raw Data');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','GDHArchiveFilePath','archive/GBA/UltaWebHist');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadUltaWebHist_pp','GDHRawFilePath','raw/GBA/UltaWebHist');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','GDHServeFilePath','serve/GBA/BAOZUNSALES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','IFLandingFilePath','WBAHK/BZUN-EXCEL/BaozunSalesIncremental/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','FilePrefix','salesbreakdownatproductlevelBaozun');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','GDHArchiveFilePath','archive/GBA/BAOZUNSALES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','Retailer','BaozunSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunSales_prod','GDHRawFilePath','raw/GBA/BAOZUNSALES');														 

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','GDHServeFilePath','serve/GBA/BAOZUNCOMBO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','IFLandingFilePath','WBAHK/BZUN-EXCEL/BaozunComboIncremental/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','FilePrefix','Baozun');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','GDHArchiveFilePath','archive/GBA/BAOZUNCOMBO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','Retailer','BaozunCombo');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadBaozunCombo_prod','GDHRawFilePath','raw/GBA/BAOZUNCOMBO');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','GDHServeFilePath','serve/GBA/MECCA');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','IFLandingFilePath','Mecca/MECCAIT/Mecca_Monthly_sales_inc/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','FilePrefix','By Store By Item - SOAP');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','GDHArchiveFilePath','archive/GBA/MECCA');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','Retailer','GBSOPMecca');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadMeccaSales_prod','GDHRawFilePath','raw/GBA/MECCA');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','GDHServeFilePath','serve/GBA/Kohls');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','IFLandingFilePath','Kohls/KSSWP/Kohls_weekly_sales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','FilePrefix','Kohls weekly sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','GDHArchiveFilePath','archive/GBA/Kohls');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','Retailer','GBSOPKohls');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadKohlsSales_prod','GDHRawFilePath','raw/GBA/Kohls');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','GDHServeFilePath','serve/GBA/WalmartRetail');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','IFLandingFilePath','Walmart/WMTWP/Walmart_retail_sales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','FilePrefix','Walmart_retail_sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','GDHArchiveFilePath','archive/GBA/WalmartRetail');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','Retailer','WalmartRetail');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartRetail_prod','GDHRawFilePath','raw/GBA/WalmartRetail');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','GDHServeFilePath','serve/GBA/WalmartOnline');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','IFLandingFilePath','Walmart/WMTWP/Walmart_online_sales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','FilePrefix','Walmart_online_sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','GDHArchiveFilePath','archive/GBA/WalmartOnline');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','Retailer','WalmartOnline');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadWalmartOnline_prod','GDHRawFilePath','raw/GBA/WalmartOnline');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','GDHServeFilePath','serve/GBA/CurrencyConversion');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','IFLandingFilePath','GFSD/GFSDEXCEL/GlobalBrandsCurrencyConversionRates/Default');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','FilePrefix','Global Brands currency conversion rates');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','GDHArchiveFilePath','archive/GBA/CurrencyConversion');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadCurrencyConversion_prod','GDHRawFilePath','raw/GBA/CurrencyConversion');


------------------------------------------Missing New Entries for PreProd-----------------------------------------------------------
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','GDHServeFilePath','serve/GBA/BAOZUNSALES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','IFLandingFilePath','WBAHK/BZUN-EXCEL/BaozunSalesIncremental/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','FilePrefix','salesbreakdownatproductlevelBaozun');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','GDHArchiveFilePath','archive/GBA/BAOZUNSALES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','Retailer','BaozunSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunSales_pp','GDHRawFilePath','raw/GBA/BAOZUNSALES');														 

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','GDHServeFilePath','serve/GBA/BAOZUNCOMBO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','IFLandingFilePath','WBAHK/BZUN-EXCEL/BaozunComboIncremental/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','FilePrefix','Baozun');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','GDHArchiveFilePath','archive/GBA/BAOZUNCOMBO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','Retailer','BaozunCombo');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadBaozunCombo_pp','GDHRawFilePath','raw/GBA/BAOZUNCOMBO');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','GDHServeFilePath','serve/GBA/MECCA');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','IFLandingFilePath','Mecca/MECCAIT/Mecca_Monthly_sales_inc/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','FilePrefix','By Store By Item - SOAP');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','GDHArchiveFilePath','archive/GBA/MECCA');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','Retailer','GBSOPMecca');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadMeccaSales_pp','GDHRawFilePath','raw/GBA/MECCA');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','GDHServeFilePath','serve/GBA/Kohls');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','IFLandingFilePath','Kohls/KSSWP/Kohls_weekly_sales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','FilePrefix','Kohls weekly sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','GDHArchiveFilePath','archive/GBA/Kohls');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','Retailer','GBSOPKohls');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadKohlsSales_pp','GDHRawFilePath','raw/GBA/Kohls');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','GDHServeFilePath','serve/GBA/WalmartRetail');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','IFLandingFilePath','Walmart/WMTWP/Walmart_retail_sales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','FilePrefix','Walmart_retail_sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','GDHArchiveFilePath','archive/GBA/WalmartRetail');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','Retailer','WalmartRetail');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartRetail_pp','GDHRawFilePath','raw/GBA/WalmartRetail');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','GDHServeFilePath','serve/GBA/WalmartOnline');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','IFLandingFilePath','Walmart/WMTWP/Walmart_online_sales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','FilePrefix','Walmart_online_sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','GDHArchiveFilePath','archive/GBA/WalmartOnline');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','Retailer','WalmartOnline');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadWalmartOnline_pp','GDHRawFilePath','raw/GBA/WalmartOnline');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','GDHServeFilePath','serve/GBA/CurrencyConversion');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','IFLandingFilePath','GFSD/GFSDEXCEL/GlobalBrandsCurrencyConversionRates/Default');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','FilePrefix','Global Brands currency conversion rates');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','GDHArchiveFilePath','archive/GBA/CurrencyConversion');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadCurrencyConversion_pp','GDHRawFilePath','raw/GBA/CurrencyConversion');


------------------------------------------Missing New Entries for QA-----------------------------------------------------------
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','TableName','BUKIT_EDI_UltaEDIStoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','GDHServeFilePath','serve/GBA/ULTAEDI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','IFLandingFilePath','ULTA/ULTAEXCEL/UltaEDI/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','FilePrefix','ulta');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','GDHArchiveFilePath','archive/GBA/ULTAEDI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','GDHRawFilePath','raw/GBA/ULTAEDI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaEDI_qa','Delimiter',',');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','TableName','WAGIT_WAGEDW_Store');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','GDHServeFilePath','serve/GBA/WalgreensStore');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','IFLandingFilePath','WAGIT/WAGEDW/WalgreensStore/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','FilePrefix','WAGUS_WAGEDW_store');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','GDHArchiveFilePath','archive/GBA/WalgreensStore');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensStore_qa','GDHRawFilePath','raw/GBA/WalgreensStore');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','TableName','TSG_MCX_No7_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','GDHServeFilePath','serve/GBA/TSGMCXNo7');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','IFLandingFilePath','TSG/TSG_UNKNOWN/TSGMCXNo7/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','FilePrefix','MCX');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','GDHArchiveFilePath','archive/GBA/TSGMCXNo7');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','Retailer','TSGMV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGMCXNo7_qa','GDHRawFilePath','raw/GBA/TSGMCXNo7');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','TableName','GBFIN_ConversionRate');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','GDHServeFilePath','serve/GBA/GBFINConversionRate');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','IFLandingFilePath','GBFIN/MSEXCEL/GBFINConversionRate/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','FilePrefix','Budget FX Rates');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','GDHArchiveFilePath','archive/GBA/GBFINConversionRate');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINConversionRate_qa','GDHRawFilePath','raw/GBA/GBFINConversionRate');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','TableName','WAGIT_WAGEDW_Product');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','GDHServeFilePath','serve/GBA/WalgreensProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','IFLandingFilePath','WAGIT/WAGIDH/WalgreensProduct/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','FilePrefix','WAGUS_WAGEDW_products');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','GDHArchiveFilePath','archive/GBA/WalgreensProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','Retailer','WagProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','DecryptionRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','DecryptionFolder','serve/GBA_Decrypt/WalgreensProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','DecryptionKeyVault','aznegbitkvdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','DecryptionSecretName','Global-Data-Hub-Passphrase-GPG');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','DecryptionWebhookURL','https://s9events.azure-automation.net/webhooks?token=0s%2f5%2bkCdgrq2glpgOjcKHeHKbaNe%2bGl%2fqrUrKbeFIzQ%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensProduct_qa','GDHRawFilePath','raw/GBA/WalgreensProduct');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','TableName','WAGIT_WAGEDW_Transaction_Cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','GDHServeFilePath','serve/GBA/WalgreensTransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','IFLandingFilePath','WAGIT/WAGEDW/WalgreensTransactionCost/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','FilePrefix','WAGUS_WAGEDW_transactions_cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','GDHArchiveFilePath','archive/GBA/WalgreensTransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransactionCost_qa','GDHRawFilePath','raw/GBA/WalgreensTransactionCost');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','TableName','WAGIT_WAGEDW_ETransaction_Cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','GDHServeFilePath','serve/GBA/WalgreensETransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','IFLandingFilePath','WAGIT/WAGEDW/WalgreensETransactionCost/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','FilePrefix','WAGUS_WAGEDW_etransactions_cost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','GDHArchiveFilePath','archive/GBA/WalgreensETransactionCost');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransactionCost_qa','GDHRawFilePath','raw/GBA/WalgreensETransactionCost');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','TableName','WAGIT_WAGEDW_Basket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','GDHServeFilePath','serve/GBA/WalgreensBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','IFLandingFilePath','WAGIT/WAGIDH/WalgreensBasket/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','FilePrefix','WAGUS_WAGIDH_baskets');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','GDHArchiveFilePath','archive/GBA/WalgreensBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensBasket_qa','GDHRawFilePath','raw/GBA/WalgreensBasket');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','TableName','ULTA_WEBP_UltaSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','GDHServeFilePath','serve/GBA/UltaWeb');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','IFLandingFilePath','ULTA/ULTAEXCEL/UltaWeb/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','FilePrefix','Sales-Inv-');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','GDHArchiveFilePath','archive/GBA/UltaWeb');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','Retailer','ULTA');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWeb_qa','GDHRawFilePath','raw/GBA/UltaWeb');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','TableName','WAGIT_WAGEDW_Etransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','GDHServeFilePath','serve/GBA/WalgreensETransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','IFLandingFilePath','WAGIT/WAGIDH/WalgreensETransaction/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','FilePrefix','WAGUS_WAGIDH_etransactions');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','GDHArchiveFilePath','archive/GBA/WalgreensETransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensETransaction_qa','GDHRawFilePath','raw/GBA/WalgreensETransaction');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','TableName','SKINSTORE_No7_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','GDHServeFilePath','serve/GBA/SKINSTORE_No7_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','IFLandingFilePath','SKINSTORE/SKINSTORE_UNKNOWN/SKINSTORE_No7_WeeklyRetailSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','FilePrefix','no7 wk');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','GDHArchiveFilePath','archive/GBA/SKINSTORE_No7_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','Retailer','SKINNO7');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_No7_WeeklyRetailSales_qa','GDHRawFilePath','raw/GBA/SKINSTORE_No7_WeeklyRetailSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','TableName','GBMDT_Sap_Material_Sales_Reporting_Master_Data');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','GDHServeFilePath','serve/GBA/GBMDTProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','IFLandingFilePath','GBMDT/MSEXCEL/GBMDTProduct/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','FilePrefix','SAP Material Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','GDHArchiveFilePath','archive/GBA/GBMDTProduct');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','Retailer','SAPMasterFilesNew');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBMDTProduct_qa','GDHRawFilePath','raw/GBA/GBMDTProduct');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','TableName','GBFIN_StoreMaster');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','GDHServeFilePath','serve/GBA/GBFINStoreMaster');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','IFLandingFilePath','GBFIN/MSEXCEL/GBFINStoreMaster/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','FilePrefix','BRUSA Store List');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','GDHArchiveFilePath','archive/GBA/GBFINStoreMaster');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','Retailer','StoreV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINStoreMaster_qa','GDHRawFilePath','raw/GBA/GBFINStoreMaster');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','TableName','SKINSTORE_SG_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','GDHServeFilePath','serve/GBA/SKINSTORE_SG_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','IFLandingFilePath','SKINSTORE/SKINSTORE_UNKNOWN/SKINSTORE_SG_WeeklyRetailSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','FilePrefix','SG sales wk');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','GDHArchiveFilePath','archive/GBA/SKINSTORE_SG_WeeklyRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','Retailer','SKINSG');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSKINSTORE_SG_WeeklyRetailSales_qa','GDHRawFilePath','raw/GBA/SKINSTORE_SG_WeeklyRetailSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','TableName','GBFIN_Retailer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','GDHServeFilePath','serve/GBA/GBFINRetailer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','IFLandingFilePath','GBFIN/MSEXCEL/GBFINRetailer/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','FilePrefix','BRUSA Qlik CUSTOMER');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','GDHArchiveFilePath','archive/GBA/GBFINRetailer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','Retailer','BrusaCustomer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailer_qa','GDHRawFilePath','raw/GBA/GBFINRetailer');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','TableName','GBFIN_RetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','GDHServeFilePath','serve/GBA/GBFINRetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','IFLandingFilePath','GBFIN/MSEXCEL/GBFINRetailerCalendar/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','FilePrefix','BRUSA Qlik Date by Week Retailers');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','GDHArchiveFilePath','archive/GBA/GBFINRetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','Retailer','BrusaRetailerCalendar');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINRetailerCalendar_qa','GDHRawFilePath','raw/GBA/GBFINRetailer');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','TableName','GBFIN_Calendar_Incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','GDHServeFilePath','serve/GBA/GBFINCalendarIncr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','IFLandingFilePath','GBFIN/GBFINEXCEL/GB_Calendar_information_GBFINEXCEL_incr/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','FilePrefix','GB_calendar_information_');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','GDHArchiveFilePath','archive/GBA/GBFINCalendarIncr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','Retailer','GBFINCalendarIncr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINCalendarIncr_qa','GDHRawFilePath','raw/GBA/GBFINCalendarIncr');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','TableName','Walgreens_RSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','GDHServeFilePath','serve/GBA/WalgreensRSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','IFLandingFilePath','DATALYNX/WAGX/GB_Daily_Walgreens_Sales_from_RSI_WAGX/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','FilePrefix','Alliance Boots_Walgreens_ADHOC_');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','GDHArchiveFilePath','archive/GBA/WalgreensRSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','Retailer','WalgreensRSI');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensRSI_qa','GDHRawFilePath','raw/GBA/WalgreensRSI');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','TableName','WAGIT_WAGEDW_Transaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','GDHServeFilePath','serve/GBA/WalgreensTransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','IFLandingFilePath','WAGIT/WAGIDH/WalgreensTransaction/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','FilePrefix','WAGUS_WAGIDH_transactions');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','GDHArchiveFilePath','archive/GBA/WalgreensTransaction');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensTransaction_qa','GDHRawFilePath','raw/GBA/WalgreensTransaction');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','TableName','WAGIT_WAGEDW_Ebasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','GDHServeFilePath','serve/GBA/WalgreensEBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','IFLandingFilePath','WAGIT/WAGIDH/WalgreensEBasket/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','FilePrefix','WAGUS_WAGIDH_ebaskets');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','GDHArchiveFilePath','archive/GBA/WalgreensEBasket');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalgreensEBasket_qa','GDHRawFilePath','raw/GBA/WalgreensEBasket');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','TableName','SDM_SG_BB_Weekly_Esales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','GDHServeFilePath','serve/GBA/SDMSGESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMSGESales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','FilePrefix','S&G Beauty');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','GDHArchiveFilePath','archive/GBA/SDMSGESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','Retailer','SDMSGE');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGESales_qa','GDHRawFilePath','raw/GBA/SDMSGESales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','TableName','TSG_AAFES_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','GDHServeFilePath','serve/GBA/TSGAAFES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','IFLandingFilePath','TSG/TSG_UNKNOWN/TSGAAFES/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','FilePrefix','AAFES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','GDHArchiveFilePath','archive/GBA/TSGAAFES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','Retailer','TSGAV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGAAFES_qa','GDHRawFilePath','raw/GBA/TSGAAFES');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','TableName','SDM_No7_Store_Weekly_Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','GDHServeFilePath','serve/GBA/SDMNo7StoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMNo7StoreSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','FilePrefix','No_7 Sales By Store');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','GDHArchiveFilePath','archive/GBA/SDMNo7StoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','Retailer','SDMNO7BM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7StoreSales_qa','GDHRawFilePath','raw/GBA/SDMNo7StoreSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','TableName','DERMSTORE_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','GDHServeFilePath','serve/GBA/DermstoreRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','IFLandingFilePath','DERMSTORE/DERMSTORE_UNKNOWN/DermstoreRetailSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','FilePrefix','No7_505424');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','GDHArchiveFilePath','archive/GBA/DermstoreRetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDermstoreRetailSales_qa','GDHRawFilePath','raw/GBA/DermstoreRetailSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','TableName','SDM_No7_BB_Weekly_Esales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','GDHServeFilePath','serve/GBA/SDMNo7ESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMNo7ESales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','FilePrefix','No_7 Beauty');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','GDHArchiveFilePath','archive/GBA/SDMNo7ESales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','Retailer','SDMNO7E');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMNo7ESales_qa','GDHRawFilePath','raw/GBA/SDMNo7ESales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','TableName','SDM_SG_Store_Weekly_Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','GDHServeFilePath','serve/GBA/SDMSGStoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','IFLandingFilePath','SDM/SDM_UNKNOWN/SDMSGStoreSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','FilePrefix','S&G Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','GDHArchiveFilePath','archive/GBA/SDMSGStoreSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','Retailer','SDMSGBM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadSDMSGStoreSales_qa','GDHRawFilePath','raw/GBA/SDMSGStoreSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','TableName','TSG_NEXCOM_RetailSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','GDHServeFilePath','serve/GBA/TSGNEXCOM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','IFLandingFilePath','TSG/TSG_UNKNOWN/TSGNEXCOM/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','FilePrefix','Nexcom');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','GDHArchiveFilePath','archive/GBA/TSGNEXCOM');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','Retailer','TSGNV2');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTSGNEXCOM_qa','GDHRawFilePath','raw/GBA/TSGNEXCOM');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','TableName','DNA_CountryISO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','GDHServeFilePath','serve/GBA/DNACountryISO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','IFLandingFilePath','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','FilePrefix','countryiso');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','GDHArchiveFilePath','archive/GBA/DNACountryISO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadDNACountryISO_qa','GDHRawFilePath','raw/GBA/DNACountryISO');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','TableName','TARGET_Transactions');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','GDHServeFilePath','serve/GBA/TargetSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','IFLandingFilePath','TGT-IT/TGT-WP/TargetSales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','FilePrefix','GDH Daily Sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','GDHArchiveFilePath','archive/GBA/TargetSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','Retailer','TARGET');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadTargetSales_qa','GDHRawFilePath','raw/GBA/TargetSales');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','TableName','GBFIN_BusinessChannel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','GDHServeFilePath','serve/GBA/GBFINBusinessChannel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','IFLandingFilePath','WAGIT/DNARDM/GBFINBusinessChannel/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','FilePrefix','Business Channel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','GDHArchiveFilePath','archive/GBA/GBFINBusinessChannel');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGBFINBusinessChannel_qa','GDHRawFilePath','raw/GBA/GBFINBusinessChannel');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','TableName','ULTA_WEBP_UltaSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','GDHServeFilePath','serve/GBA/UltaWebHist');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','IFLandingFilePath','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','FilePrefix','Ulta Raw Data');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','GDHArchiveFilePath','archive/GBA/UltaWebHist');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadUltaWebHist_qa','GDHRawFilePath','raw/GBA/UltaWebHist');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','GDHServeFilePath','serve/GBA/BAOZUNSALES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','IFLandingFilePath','WBAHK/BZUN-EXCEL/BaozunSalesIncremental/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','FilePrefix','salesbreakdownatproductlevelBaozun');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','GDHArchiveFilePath','archive/GBA/BAOZUNSALES');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','Retailer','BaozunSales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunSales_qa','GDHRawFilePath','raw/GBA/BAOZUNSALES');														 

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','GDHServeFilePath','serve/GBA/BAOZUNCOMBO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','IFLandingFilePath','WBAHK/BZUN-EXCEL/BaozunComboIncremental/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','FilePrefix','Baozun');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','GDHArchiveFilePath','archive/GBA/BAOZUNCOMBO');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','Retailer','BaozunCombo');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadBaozunCombo_qa','GDHRawFilePath','raw/GBA/BAOZUNCOMBO');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','GDHServeFilePath','serve/GBA/MECCA');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','IFLandingFilePath','Mecca/MECCAIT/Mecca_Monthly_sales_inc/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','FilePrefix','By Store By Item - SOAP');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','GDHArchiveFilePath','archive/GBA/MECCA');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','Retailer','GBSOPMecca');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadMeccaSales_qa','GDHRawFilePath','raw/GBA/MECCA');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','GDHServeFilePath','serve/GBA/Kohls');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','IFLandingFilePath','Kohls/KSSWP/Kohls_weekly_sales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','FilePrefix','Kohls weekly sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','GDHArchiveFilePath','archive/GBA/Kohls');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','Retailer','GBSOPKohls');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadKohlsSales_qa','GDHRawFilePath','raw/GBA/Kohls');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','GDHServeFilePath','serve/GBA/WalmartRetail');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','IFLandingFilePath','Walmart/WMTWP/Walmart_retail_sales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','FilePrefix','Walmart_retail_sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','GDHArchiveFilePath','archive/GBA/WalmartRetail');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','Retailer','WalmartRetail');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartRetail_qa','GDHRawFilePath','raw/GBA/WalmartRetail');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','GDHServeFilePath','serve/GBA/WalmartOnline');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','IFLandingFilePath','Walmart/WMTWP/Walmart_online_sales/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','FilePrefix','Walmart_online_sales');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','GDHArchiveFilePath','archive/GBA/WalmartOnline');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','Retailer','WalmartOnline');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadWalmartOnline_qa','GDHRawFilePath','raw/GBA/WalmartOnline');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','GDHServeFilePath','serve/GBA/CurrencyConversion');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','IFLandingFilePath','GFSD/GFSDEXCEL/GlobalBrandsCurrencyConversionRates/Default');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','FilePrefix','Global Brands currency conversion rates');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','PythonRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','GDHArchiveFilePath','archive/GBA/CurrencyConversion');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','Retailer','');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadCurrencyConversion_qa','GDHRawFilePath','raw/GBA/CurrencyConversion');

---Budget & Forecast Weekly and Monthly parameters
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','TableName','BudgetForecastWeekly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHServeFilePath','serve/GBA/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','IFLandingFilePath','GBFIN/GFSDEXCEL/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','FilePrefix','Budget_and_Forecast_Weekly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHArchiveFilePath','archive/GBA/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','Retailer','BudgetForecastWeekly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHRawFilePath','raw/GBA/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','TableName','BudgetForecastWeekly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHServeFilePath','serve/GBA/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','IFLandingFilePath','GBFIN/GFSDEXCEL/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','FilePrefix','Budget_and_Forecast_Weekly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHArchiveFilePath','archive/GBA/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','Retailer','BudgetForecastWeekly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHRawFilePath','raw/GBA/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','TableName','BudgetForecastWeekly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHServeFilePath','serve/GBA/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','IFLandingFilePath','GBFIN/GFSDEXCEL/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','FilePrefix','Budget_and_Forecast_Weekly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHArchiveFilePath','archive/GBA/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','Retailer','BudgetForecastWeekly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHRawFilePath','raw/GBA/GB_Weekly_Budget_and_Forecast_GBFINEXCEL_incr');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','TableName','BudgetForecastMonthly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHStorageAccSerEndpoint','https://azsagbitproddatalake01.dfs.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHServeFilePath','serve/GBA/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','IFLandingStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','IFLandingFilePath','GBFIN/GFSDEXCEL/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','FilePrefix','Budget_and_Forecast_Monthly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','Webhook Python','https://s9events.azure-automation.net/webhooks?token=HbmzveoBtlx4YZK2%2bR5%2f2qY4jrbkm4FjFXNuLV6wQNk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHStorageAccName','azsagbitproddatalake01');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHArchiveFilePath','archive/GBA/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','Retailer','BudgetForecastMonthly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','prod','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_prod','GDHRawFilePath','raw/GBA/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','TableName','BudgetForecastMonthly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHServeFilePath','serve/GBA/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','IFLandingFilePath','GBFIN/GFSDEXCEL/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','FilePrefix','Budget_and_Forecast_Monthly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHArchiveFilePath','archive/GBA/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','Retailer','BudgetForecastMonthly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','pp','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_pp','GDHRawFilePath','raw/GBA/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr');

insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','TableName','BudgetForecastMonthly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHStorageAccSerEndpoint','https://azsanegdhdev1.dfs.core.windows.net');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHContainerName','gdhdatalake');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHTransferFilePath','transfer');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHServeFilePath','serve/GBA/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','IFLandingStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net/');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','IFLandingContainerName','landing');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','IFLandingFilePath','GBFIN/GFSDEXCEL/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr/Incremental');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','FilePrefix','Budget_and_Forecast_Monthly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=kr11X990TbRZtmzTxitVPFLnFjHERFyhlBvZDb80zkk%3d');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','PythonRequired','1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHStorageAccName','azsanegdhdev1');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHArchiveFilePath','archive/GBA/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','Retailer','BudgetForecastMonthly');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','DecryptionRequired','0');
insert into #GDHDynamicADFParams values ('GBA','GBA_incremental_load','qa','LoadGB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr_qa','GDHRawFilePath','raw/GBA/GB_Monthly_Budget_and_Forecast_GBFINEXCEL_incr');

--DPI parameters
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','InputFilePath','raw/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','InputFilename','in.avro')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','StorageContainerName','landing')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','EventhubStorageContainerName','eventhub-capture')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Digital_Pharmacy_Order_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Webhook Python','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=2YkZpkUg%2bAJ8pBHJjbYo7l8TWrH2wooKIF%2b2oa2%2bNvM%3d')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Digital_Pharmacy_Order_Items_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Items_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Digital_Pharmacy_Order_Edits_Removal_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Edits_Removal_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Digital_Pharmacy_Customer_Relationship_%.csv','SAPCOE/BTCSAPCDC/BootsUK_Pharmacy_Customer_Relationship_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Digital_Pharmacy_Order_TaxedPrice_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_TaxedPrice_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Digital_Pharmacy_Customer_Info_%.csv','SAPCOE/BTCSAPCDC/BootsUK_Pharmacy_Customer_Info_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','StorageAccountName','proddatneqasa04')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Retailer','DPI')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Digital_Pharmacy_Order_Consent_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Consent_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','StorageAccountServiceEndPoint',' https://proddatneqasa04.blob.core.windows.net/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','ArchivePath','archive/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','DeleteSourceFile','1')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','OutputFilePath','serve/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','RejectPath','rejected/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Digital_Pharmacy_Order_Transition_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Transition_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','EventHubStorageAccountName','proddatneqasa04')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','FilePattern','prod-dat-ne-qa-ehns-01/prod-dat-ne-qa-ehub-01')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','OutputFilename','out.avro')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','qa','Avro_to_csv','Webhook FetchFilelist','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=iNRncrL7pRe5k3VGDS98tWj3QdHZJCb0el%2fPS6C%2fr%2fM%3d')


INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','InputFilePath','raw/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','InputFilename','in.avro')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','StorageContainerName','landing')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','EventhubStorageContainerName','eventhub')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Digital_Pharmacy_Order_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Webhook Python','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=3g6l2%2buKAaQYUoglqWbZUfth1VSZAD5wjh3fcvRSItY%3d')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Digital_Pharmacy_Order_Items_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Items_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Digital_Pharmacy_Order_Edits_Removal_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Edits_Removal_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Digital_Pharmacy_Customer_Relationship_%.csv','SAPCOE/BTCSAPCDC/BootsUK_Pharmacy_Customer_Relationship_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Digital_Pharmacy_Order_TaxedPrice_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_TaxedPrice_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Digital_Pharmacy_Customer_Info_%.csv','SAPCOE/BTCSAPCDC/BootsUK_Pharmacy_Customer_Info_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','StorageAccountName','proddatneprsa04')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Retailer','DPI')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Digital_Pharmacy_Order_Consent_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Consent_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','StorageAccountServiceEndPoint','https://proddatneprsa04.blob.core.windows.net/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','ArchivePath','archive/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','DeleteSourceFile','1')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','OutputFilePath','serve/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','RejectPath','rejected/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Digital_Pharmacy_Order_Transition_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Transition_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','EventHubStorageAccountName','proddatneprsa04')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','FilePattern','prod-dat-ne-pr-ehns-01/prod-dat-ne-pr-ehub-01')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','OutputFilename','out.avro')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','prod','Avro_to_csv','Webhook FetchFilelist','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=iNRncrL7pRe5k3VGDS98tWj3QdHZJCb0el%2fPS6C%2fr%2fM%3d')


INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','InputFilePath','raw/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','InputFilename','in.avro')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','StorageContainerName','landing')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','EventhubStorageContainerName','eventhub-capture')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Digital_Pharmacy_Order_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Webhook Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=m3k8Xu5JiTsUk0PSdBDiYWmN1Zrb87U9nbF8t9C6meU%3d')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Digital_Pharmacy_Order_Items_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Items_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Digital_Pharmacy_Order_Edits_Removal_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Edits_Removal_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Digital_Pharmacy_Customer_Relationship_%.csv','SAPCOE/BTCSAPCDC/BootsUK_Pharmacy_Customer_Relationship_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Digital_Pharmacy_Order_TaxedPrice_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_TaxedPrice_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Digital_Pharmacy_Customer_Info_%.csv','SAPCOE/BTCSAPCDC/BootsUK_Pharmacy_Customer_Info_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','StorageAccountName','nprodatneppsa01')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Retailer','DPI')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Digital_Pharmacy_Order_Consent_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Consent_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','StorageAccountServiceEndPoint',' https://nprodatneppsa01.blob.core.windows.net/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','ArchivePath','archive/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','DeleteSourceFile','1')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','OutputFilePath','serve/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','RejectPath','rejected/CEP/DPI/')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Digital_Pharmacy_Order_Transition_%.csv','BUKIT/CEP/BootsUK_Pharmacy_Order_Transition_CEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','EventHubStorageAccountName','nprodatneppsa01')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','FilePattern','prod-dat-ne-pp-ehns-01/prod-dat-ne-pp-ehub-01')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','OutputFilename','out.avro')
INSERT INTO #GDHDynamicADFParams values('DPI','DPI_csv_load','pp','Avro_to_csv','Webhook FetchFilelist','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=%2b2RF5KUawsygASr8MvO%2bUD5F6NiSQQGBdBbafPPI9FQ%3d')

--Asia MI preprocessor values non PII

insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'pp','StorageDetails','GDHStorageAccName','aznednapresa01')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'pp','StorageDetails','GDHContainerName','hkasiamilanding')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'pp','StorageDetails','GDHStorageAccSerEndpoint','https://aznednapresa01.blob.core.windows.net')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'qa','StorageDetails','GDHStorageAccName','aznednaqasa01')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'qa','StorageDetails','GDHContainerName','hkasiamilanding')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'qa','StorageDetails','GDHStorageAccSerEndpoint','https://aznednaqasa01.blob.core.windows.net/')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','StorageDetails','GDHStorageAccName','aznednaprodsa01')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','StorageDetails','GDHContainerName','hkasiamilanding')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','StorageDetails','GDHStorageAccSerEndpoint','https://aznednaprodsa01.blob.core.windows.net/')


insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_CNTRYGRP','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_CNTRYGRP_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_BIZ','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_BIZ_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_CUSTOMER','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_CUSTOMER_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_DATE','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_DATE_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_ForecastGroup','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_ForecastGroup_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_HSCODE','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_Walgreens_HS_Code_List_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_METRIC','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_METRIC_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_METRIC_GRP','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_METRIC_GRP_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_Opstudy','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_Opstudy_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_PORTToCNTRY','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_PORTToCNTRY_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_SAFETYRATE','IFLandingFilePath','WBAHK/BamRose/WBAHK_DIM_SAFETYRATE_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_SEGToCustCode','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_SEGToCustCode_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_TEAM','IFLandingFilePath','WBAHK/ADR7WAG/WBAHK_DIM_TEAM_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR_GROUP','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR_GROUP_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR_INSPECTIONRATE_ROLLING','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR_INSPECTIONRATE_ROLLING_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR_MOQOAT_UK','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR_MOQOAT_UK_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR_SERVICELVL','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR_SERVICELVL_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR_SSIS','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR_SSIS_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR9BOXSUMMARY','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR9BOXSUMMARY_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOROPS','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOROPS_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','EthicalDetail_ETL','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_EthicalDetail_ETL_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','FactManualData','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_Dashboard_Metric_Grouping_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','FactManualData_target','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_Dashboard_Metric_KPI_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','FactManualDataFY','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_Dashboard_Metric_Parameter_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','temp_fte','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_temp_fte_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','V_BRS_PARTY_INFOCARD','IFLandingFilePath','WBAHK/BamRose/WBAHK_V_BRS_PARTY_INFOCARD_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_ADR7_PAYTERMS','IFLandingFilePath','WBAHK/ADR7WAG/WBAHK_DIM_ADR7_PAYTERMS_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_COLOR','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_COLOR_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_HR_Datatype','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_HR_Datatype_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_HR_TEAM','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_HR_TEAM_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_MARGIN_BREAKDOWN','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_MARGIN_BREAKDOWN_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR_1506','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR_1506_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR_DEALS','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR_DEALS_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR_MOQOAT','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_VENDOR_MOQOAT_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDOR9BOX','IFLandingFilePath','WBAHK/BamRose/WBAHK_DIM_VENDOR9BOX_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','Fact_HR','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_Fact_HR_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','PARTY_REL_TIER','IFLandingFilePath','WBAHK/BamRose/WBAHK_PARTY_REL_TIER_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','TEMP_9BOXSummary','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_TEMP_9BOXSummary_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','TEMP_BRANDMAP','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_TEMP_BRANDMAP_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','TEMP_EthicalSummary','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_TEMP_EthicalSummary_HKSQLDB/Incremental')


--Asia MI PII

insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','ADR7OPEN','IFLandingFilePath','WAGIT/ADR7WAG/WBAHK_Walgreens_Open_Purchase_Order_Detail_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_ForecastGroup_v2','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_ForecastGroup_v2_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_ITEM ','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_DIM_ITEM_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','FactMIDATA_LIMA_OPEN ','IFLandingFilePath','LIMAIT/Lima/WBAHK_FactMIDATA_LIMA_OPEN_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','FactMIDATA_OPEN','IFLandingFilePath','WAGIT/ADR7WAG/WBAHK_FactMIDATA_OPEN_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','V_BRS_PARTY','IFLandingFilePath','WBAHK/BamRose/WBAHK_V_BRS_PARTY_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','V_WBAPARTY_FTY','IFLandingFilePath','WBAHK/BamRose/WBAHK_V_WBAPARTY_FTY_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','ADR7_VENDORFACTORY_4FLAGS','IFLandingFilePath','WBAHK/ADR7WAG/WBAHK_ADR7_VENDORFACTORY_4FLAGS_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','DIM_VENDORINFO','IFLandingFilePath','WBAHK/BamRose/WBAHK_DIM_VENDORINFO_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','FACT_WBAQUOTE_GSO','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_FACT_WBAQUOTE_GSO_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','FactMIDATA_GSOOPEN','IFLandingFilePath','WBAHK/ADR7WAG/WBAHK_FactMIDATA_GSOOPEN_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','TEMP_FINANCECHECK_UK','IFLandingFilePath','WBAHK/BamRose/WBAHK_TEMP_FINANCECHECK_UK_HKSQLDB/Incremental')
insert into #GDHDynamicADFParams values ('AsiaMI','AsiaMI_preprocessor' , 'prod','FactMIDATA','IFLandingFilePath','WBAHK/WBAHKBUS/WBAHK_FactMIDATA_HKSQLDB/Incremental')


--MarTech History Egress
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','514','crm-membership_card-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','525','crm-point_transaction-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','526','crm-membership_points-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','527','crm-member_activity-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','528','crm-cust_child-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','529','crm-cust_clubs-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','530','crm-cust_info-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','554','svoccc-customer_mst-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','555','svoccc-customer_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','558','svoccc-customer_phone-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','559','svoccc-customer_address-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','563','svoccc-customer_email-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','566','svoccc-customer_identifier-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','567','svoccc-customer_social_media-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','570','svoccc-consent_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','572','svoccc-customer_consent-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','BatchDecryptUtil','603','NA');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','514','DF17');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','525','DF05');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','526','DF04');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','527','DF03');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','528','DF02');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','529','DF06');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','530','DF01');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','554','DF08');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','555','DF09');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','558','DF11');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','559','DF10');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','563','DF12');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','566','DF14');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','567','DF13');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','570','DF16');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','572','DF15');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','pp','DataFeedLookup','603','DF58');

insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','371','crm-cust_child-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','373','crm-cust_clubs-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','375','crm-cust_info-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','377','crm-member_activity-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','379','crm-membership_points-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','381','crm-point_transaction-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','396','crm-membership_card-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','388','svoccc-customer_phone-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','421','svoccc-customer_mst-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','422','svoccc-customer_address-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','423','svoccc-customer_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','424','svoccc-customer_email-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','425','svoccc-customer_social_media-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','426','svoccc-customer_identifier-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','427','svoccc-customer_consent-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','428','svoccc-consent_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','BatchDecryptUtil','419','NA');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','371','DF02');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','373','DF06');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','375','DF01');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','377','DF03');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','379','DF04');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','381','DF05');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','396','DF17');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','388','DF11');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','421','DF08');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','422','DF10');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','423','DF09');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','424','DF12');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','425','DF13');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','426','DF14');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','427','DF15');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','428','DF16');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','qa','DataFeedLookup','419','DF58');

insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','521','crm-cust_child-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','525','crm-cust_clubs-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','529','crm-cust_info-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','533','crm-member_activity-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','537','crm-membership_points-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','541','crm-point_transaction-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','547','crm-membership_card-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','511','svoccc-customer_phone-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','508','svoccc-customer_mst-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','510','svoccc-customer_address-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','509','svoccc-customer_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','512','svoccc-customer_email-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','513','svoccc-customer_social_media-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','514','svoccc-customer_identifier-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','515','svoccc-customer_consent-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','516','svoccc-consent_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','507','NA');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','521','DF02');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','525','DF06');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','529','DF01');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','533','DF03');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','537','DF04');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','541','DF05');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','547','DF17');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','511','DF11');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','508','DF08');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','510','DF10');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','509','DF09');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','512','DF12');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','513','DF13');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','514','DF14');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','515','DF15');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','516','DF16');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','507','DF58');

--MarTech Egress Common Params
insert into #GDHDynamicADFParams values ('MarTech','MarTech_Egress','pp','BatchDecryptUtil','SAEndpoints','{ "wrangled_endpoint":"https://aznednapredl01.dfs.core.windows.net","collection_endpoint":"https://dnappcollectionsa02.dfs.core.windows.net" }');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_Egress','pp','BatchDecryptUtil','UtilParam','{ "mi_client_id":"7fae697d-ea8f-4033-9507-3585184b384b","gpg_pubkey_secret":"dna-pzdb-gpg-pre-pub-key","gpg_email":"esp.sit@boots.co.uk","voltage_secret":"NA","skip_decrypt_file":"lov_skip_decryption.txt" }');

insert into #GDHDynamicADFParams values ('MarTech','MarTech_Egress','qa','BatchDecryptUtil','SAEndpoints','{ "wrangled_endpoint":"https://aznednaqadl01.dfs.core.windows.net","collection_endpoint":"https://dnaqacollectionsa02.dfs.core.windows.net" }');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_Egress','qa','BatchDecryptUtil','UtilParam','{ "mi_client_id":"4f5f3c00-afd7-422d-8faa-5717e9f37db6","gpg_pubkey_secret":"dna-pzdb-gpg-qa-pub-key","gpg_email":"esp.sit@boots.co.uk","voltage_secret":"dna-voltage-qa-key","skip_decrypt_file":"lov_skip_decryption.txt" }');

insert into #GDHDynamicADFParams values ('MarTech','MarTech_Egress','prod','BatchDecryptUtil','SAEndpoints','{ "wrangled_endpoint":"https://aznednaprodl01.dfs.core.windows.net","collection_endpoint":"https://dnaprcollectionsa02.dfs.core.windows.net" }');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_Egress','prod','BatchDecryptUtil','UtilParam','{ "mi_client_id":"8d1662ac-bd39-4810-b33b-fc94cdc517cb","gpg_pubkey_secret":"dna-pzdb-gpg-prod-pub-key","gpg_email":"adobe_campaign_reputational@boots.co.uk","voltage_secret":"dna-voltage-prod-key","skip_decrypt_file":"lov_skip_decryption.txt" }');

--MarTech Delta Egress
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','201','crm-membership_points-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','202','crm-point_transaction-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','203','crm-cust_info-config-anon.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','204','crm-cust_clubs-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','205','crm-cust_child-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','206','crm-member_activity-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','207','crm-customer_status_change-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','208','svoccc-customer_mst-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','209','svoccc-customer_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','210','svoccc-customer_address-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','211','svoccc-customer_phone-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','212','svoccc-customer_email-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','213','svoccc-customer_social_media-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','214','svoccc-customer_identifier-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','215','svoccc-customer_consent-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','216','svoccc-consent_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','BatchDecryptUtil','217','crm-membership_card_inc-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','WrapperPipeline','WrapperParam',
'{ "ef_generatefacts_url":"https://management.azure.com/subscriptions/ef96be94-eb8b-4cb0-950d-151cda7e92ed/resourceGroups/npro-dna-pre-northeurope-main01/providers/Microsoft.DataFactory/factories/npro-dna-pre-adf-01/pipelines/DataGenerateFacts/createRun?api-version=2018-06-01","run_status_url":"https://management.azure.com/subscriptions/ef96be94-eb8b-4cb0-950d-151cda7e92ed/resourceGroups/npro-dna-pre-northeurope-main01/providers/Microsoft.DataFactory/factories/npro-dna-pre-adf-01/pipelineruns/","ef_egressexecute_url":"https://management.azure.com/subscriptions/ef96be94-eb8b-4cb0-950d-151cda7e92ed/resourceGroups/npro-dna-pre-northeurope-main01/providers/Microsoft.DataFactory/factories/npro-dna-pre-adf-01/pipelines/DataEgressExecute/createRun?api-version=2018-06-01" }');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','201','DF04');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','202','DF05');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','203','DF01');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','204','DF06');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','205','DF02');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','206','DF03');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','207','DF07');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','208','DF08');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','209','DF09');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','210','DF10');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','211','DF11');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','212','DF12');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','213','DF13');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','214','DF14');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','215','DF15');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','216','DF16');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','pp','DataFeedLookup','217','DF17');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','pp','EgressRerun','PipelineUrl','https://management.azure.com/subscriptions/ef96be94-eb8b-4cb0-950d-151cda7e92ed/resourceGroups/npro-data-ppma-northeurope-01/providers/Microsoft.DataFactory/factories/nprodataneppadf02/pipelines/MT_EgressMain/createRun?api-version=2018-06-01')

insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','561','crm-membership_points-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','562','crm-point_transaction-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','563','crm-cust_info-config-anon.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','564','crm-cust_clubs-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','565','crm-cust_child-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','566','crm-member_activity-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','567','crm-customer_status_change-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','568','svoccc-customer_mst-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','569','svoccc-customer_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','570','svoccc-customer_address-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','571','svoccc-customer_phone-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','572','svoccc-customer_email-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','573','svoccc-customer_social_media-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','574','svoccc-customer_identifier-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','575','svoccc-customer_consent-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','576','svoccc-consent_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','BatchDecryptUtil','577','crm-membership_card_inc-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','WrapperPipeline','WrapperParam',
'{ "ef_generatefacts_url":"https://management.azure.com/subscriptions/61dcae01-f261-48b1-ad36-9f3218969f72/resourceGroups/prod-dna-qa-northeurope-main01/providers/Microsoft.DataFactory/factories/prod-dna-qa-adf-01/pipelines/DataGenerateFacts/createRun?api-version=2018-06-01","run_status_url":"https://management.azure.com/subscriptions/61dcae01-f261-48b1-ad36-9f3218969f72/resourceGroups/prod-dna-qa-northeurope-main01/providers/Microsoft.DataFactory/factories/prod-dna-qa-adf-01/pipelineruns/","ef_egressexecute_url":"https://management.azure.com/subscriptions/61dcae01-f261-48b1-ad36-9f3218969f72/resourceGroups/prod-dna-qa-northeurope-main01/providers/Microsoft.DataFactory/factories/prod-dna-qa-adf-01/pipelines/DataEgressExecute/createRun?api-version=2018-06-01" }');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','561','DF04');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','562','DF05');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','563','DF01');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','564','DF06');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','565','DF02');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','566','DF03');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','567','DF07');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','568','DF08');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','569','DF09');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','570','DF10');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','571','DF11');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','572','DF12');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','573','DF13');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','574','DF14');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','575','DF15');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','576','DF16');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','qa','DataFeedLookup','577','DF17');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','qa','EgressRerun','PipelineUrl','https://management.azure.com/subscriptions/61dcae01-f261-48b1-ad36-9f3218969f72/resourceGroups/prod-data-qama-northeurope-01/providers/Microsoft.DataFactory/factories/proddataneqaadf02/pipelines/MT_EgressMain/createRun?api-version=2018-06-01')

insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','688','crm-membership_points-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','689','crm-point_transaction-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','690','crm-cust_info-config-anon.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','691','crm-cust_clubs-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','692','crm-cust_child-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','693','crm-member_activity-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','694','crm-customer_status_change-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','695','svoccc-customer_mst-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','696','svoccc-customer_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','697','svoccc-customer_address-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','698','svoccc-customer_phone-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','699','svoccc-customer_email-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','700','svoccc-customer_social_media-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','701','svoccc-customer_identifier-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','702','svoccc-customer_consent-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','703','svoccc-consent_entity_lnk-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','BatchDecryptUtil','704','crm-membership_card_inc-config.xml');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','WrapperPipeline','WrapperParam',
'{ "ef_generatefacts_url":"https://management.azure.com/subscriptions/61dcae01-f261-48b1-ad36-9f3218969f72/resourceGroups/prod-dna-prod-northeurope-main01/providers/Microsoft.DataFactory/factories/prod-dna-adf-01/pipelines/DataGenerateFacts_Generic/createRun?api-version=2018-06-01","run_status_url":"https://management.azure.com/subscriptions/61dcae01-f261-48b1-ad36-9f3218969f72/resourceGroups/prod-dna-prod-northeurope-main01/providers/Microsoft.DataFactory/factories/prod-dna-adf-01/pipelineruns/","ef_egressexecute_url":"https://management.azure.com/subscriptions/61dcae01-f261-48b1-ad36-9f3218969f72/resourceGroups/prod-dna-prod-northeurope-main01/providers/Microsoft.DataFactory/factories/prod-dna-adf-01/pipelines/DataEgressExecute_Generic/createRun?api-version=2018-06-01" }');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','688','DF04');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','689','DF05');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','690','DF01');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','691','DF06');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','692','DF02');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','693','DF03');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','694','DF07');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','695','DF08');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','696','DF09');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','697','DF10');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','698','DF11');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','699','DF12');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','700','DF13');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','701','DF14');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','702','DF15');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','703','DF16');
insert into #GDHDynamicADFParams values('MarTech','MarTech_DeltaEgress','prod','DataFeedLookup','704','DF17');
insert into #GDHDynamicADFParams values ('MarTech','MarTech_DeltaEgress','prod','EgressRerun','PipelineUrl','https://management.azure.com/subscriptions/61dcae01-f261-48b1-ad36-9f3218969f72/resourceGroups/prod-data-prma-northeurope-01/providers/Microsoft.DataFactory/factories/proddatanepradf02/pipelines/MT_EgressMain/createRun?api-version=2018-06-01')

--Martech wave 3 History Egress
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','85','rawuk-btc_deal_qualified_card-config.xml')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','88','NA')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','64','rawuk-btc_transaction_line_card-config.xml')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','60','rawuk-btc_transaction_card-config.xml')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','144','NA')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','130','rawuk-btc_deal_qualified_card-config.xml')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','128','uk-abacus_deals-config.xml')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','122','rawuk-btc_transaction_line_card-config.xml')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','BatchDecryptUtil','120','rawuk-btc_transaction_card-config.xml')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','PSAToPSAHopperCopy','130','EXEC [psa].[sp_uk_abacus_promotions_Egress_Extract] ''$pCreatedTimestamp''')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','PSAToPSAHopperCopy','128','EXEC [psa].[sp_uk_abacus_deals_Egress_Extract] ''$pCreatedTimestamp''')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','PSAToPSAHopperCopy','122','EXEC [psa].[sp_uk_abacus_item_Egress_Extract] ''$pCreatedTimestamp''')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','PSAToPSAHopperCopy','120','EXEC [psa].[sp_uk_abacus_header_Egress_Extract] ''$pCreatedTimestamp''')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','PSAToPSAHopperCopy','85','EXEC [psa].[sp_rawuk_btc_deal_qualified_card_Egress_Extract] ''$pCreatedTimestamp''')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','PSAToPSAHopperCopy','88','EXEC [psa].[sp_rawuk_btc_promotion_deal_Egress_Extract] ''$pCreatedTimestamp''')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','PSAToPSAHopperCopy','144','EXEC [psa].[sp_uk_btc_promotion_deal_Egress_Extract] ''$pCreatedTimestamp''')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','PSAToPSAHopperCopy','64','EXEC [psa].[sp_rawuk_btc_transaction_line_card_p_Egress_Extract] ''$pCreatedTimestamp''')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','PSAToPSAHopperCopy','60','EXEC [psa].[sp_rawuk_btc_transaction_card_p_Egress_Extract] ''$pCreatedTimestamp''')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','85','DF29')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','88','DF34')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','64','DF25')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','60','DF24')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','144','DF34')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','130','DF29')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','128','DF28')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','122','DF25')
insert into #GDHDynamicADFParams values('MarTech','MarTech_HistoryEgress','prod','DataFeedLookup','120','DF24')

--Google Analytics
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','ADLS_connect','Storage_account','aznednaqadl01');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','ADLS_connect','input_container','cleansed');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','ADLS_connect','output_container','gadispatch');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','GA_Notebook_execution','NoteBook_sourceFile','/Shared/ga/scripts/0_GA_first_table');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','Notebook_execution','Notebook1','/Shared/ga/scripts/1_6_GA_Transformation');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','Notebook_execution','Notebook2','/Shared/ga/scripts/7_11_GA_Transformation');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','GA_Notebook_execution','zipping_transformed_csv','/Shared/ga/scripts/zipping_transformed_csv');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','GA_Notebook_execution','CleanUp','/Shared/ga/scripts/CleanUp');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','GA_Notebook_execution','mount_adls_storage','/Shared/ga/config/mount_adls_storage');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','key_vault_var','ClientID','sp-GA-databricks-qa-ClientId');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','key_vault_var','TenantID','sp-GA-databricks-qa-TenantId');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','key_vault_var','ClientSecret','sp-GA-databricks-qa-secret');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_ROI_Daily_GA/Incremental','BUKIT/GA/GDH_cm_transformed_ROI_GA_incr/Incremental');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_ROI_Intraday_GA/Incremental','BUKIT/GA/GDH_cm_transformed_intraday_ROI_GA_incr/Incremental');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_UK_Daily_GA/Incremental','BUKIT/GA/GDH_cm_transformed_UK_GA_incr/Incremental');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_UK_Intraday_GA/Incremental','BUKIT/GA/GDH_cm_transformed_intraday_UK_GA_incr/Incremental');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_ROI_Daily_GA/Historical','BUKIT/GA/GDH_cm_transformed_ROI_GA_incr/Historical');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_UK_Daily_GA/Historical','BUKIT/GA/GDH_cm_transformed_UK_GA_incr/Historical');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','databrick_instance','https://adb-4658016460302550.10.azuredatabricks.net');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','prelandingcont','galanding');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','dispatchbatching','predisptachcont','gadispatch');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','count','10');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','dispatchbatching','copycount','10');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','concurrency','40');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','ROI_Daily_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','ROI_Intraday_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','ROI_History_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','UK_Daily_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','UK_Intraday_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','UK_History_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','ROI_Daily_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','ROI_Intraday_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','ROI_History_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','UK_Daily_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','UK_Intraday_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','qa','microbatching','UK_History_landingflag','OFF');

INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','ADLS_connect','Storage_account','aznednaprodl01');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','ADLS_connect','input_container','cleansed');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','ADLS_connect','output_container','gadispatch');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','GA_Notebook_execution','NoteBook_sourceFile','/Shared/ga/scripts/0_GA_first_table');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','Notebook_execution','Notebook1','/Shared/ga/scripts/1_6_GA_Transformation');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','Notebook_execution','Notebook2','/Shared/ga/scripts/7_11_GA_Transformation');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','GA_Notebook_execution','zipping_transformed_csv','/Shared/ga/scripts/zipping_transformed_csv');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','GA_Notebook_execution','CleanUp','/Shared/ga/scripts/CleanUp');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','GA_Notebook_execution','mount_adls_storage','/Shared/ga/config/mount_adls_storage');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','key_vault_var','ClientID','sp-GA-databricks-prod-ClientId');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','key_vault_var','TenantID','sp-GA-databricks-prod-TenantId');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','key_vault_var','ClientSecret','sp-GA-databricks-prod-secret');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_ROI_Daily_GA/Incremental','BUKIT/GA/GDH_cm_transformed_ROI_GA_incr/Incremental');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_ROI_Intraday_GA/Incremental','BUKIT/GA/GDH_cm_transformed_intraday_ROI_GA_incr/Incremental');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_UK_Daily_GA/Incremental','BUKIT/GA/GDH_cm_transformed_UK_GA_incr/Incremental');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_UK_Intraday_GA/Incremental','BUKIT/GA/GDH_cm_transformed_intraday_UK_GA_incr/Incremental');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_ROI_Daily_GA/Historical','BUKIT/GA/GDH_cm_transformed_ROI_GA_incr/Historical');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','output_path','BUKIT/GA/BootsUK_Core_Metrics_Clickstream_Data_UK_Daily_GA/Historical','BUKIT/GA/GDH_cm_transformed_UK_GA_incr/Historical');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','databrick_instance','https://adb-5352336141854054.14.azuredatabricks.net');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','prelandingcont','galanding');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','dispatchbatching','predisptachcont','gadispatch');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','count','8');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','dispatchbatching','copycount','8');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','concurrency','11');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','ROI_Daily_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','ROI_Intraday_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','ROI_History_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','UK_Daily_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','UK_Intraday_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','UK_History_dispatchflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','ROI_Daily_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','ROI_Intraday_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','ROI_History_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','UK_Daily_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','UK_Intraday_landingflag','OFF');
INSERT INTO #GDHDynamicADFParams VALUES ('GA','GA_avro_tsv','prod','microbatching','UK_History_landingflag','OFF');

-- Adcard Gamification Lite

INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','StorageContainerName','eventhub-capture')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','Webhook_Python','https://5c0bc823-bb52-4378-8575-116a389faa49.webhook.ne.azure-automation.net/webhooks?token=pleqGfQgAJHKPdJx0GlRtm9RcXA%2f9AgBfCo29ms3GeY%3d')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','StorageAccountName','aznednapresa01')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','Retailer','Gamification')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','StorageAccountServiceEndPoint',' https://aznednapresa01.blob.core.windows.net/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','ArchivePath','Gamification/archive/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','DeleteSourceFile','0')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','OutputFilePath','Gamification/csv/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','RejectPath','Gamification/rejected/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','TargetFilePattern','CEP_*.csv')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','RejectFilePattern','GAMIFICATIONAVROTOCSVREJ*.dat')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','SourceFilePattern','npro_dat_ne_pp_ehns_01_npro_dna_preprod_gamificationopportunities_ingest_ne_eh01_*.avro')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','CEP_GameOpportunities_%.csv','BUKIT/CEP/BootsUK_GameOpportunities_Boots_CEP_Incr/Incremental')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','CEP_EligibleCustomerOpportunities_%.csv','BUKIT/CEP/BootsUK_EligibleCustomerOpportunities_Boots_CEP_Incr/Incremental')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','TargetRejectPath','BUKIT/CEP/Gamification/rejected')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','OutputStorageContainerName','landing')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','srcPrefix','npro-dat-ne-pp-ehns-01/npro-dna-preprod-gamificationopportunities-ingest-ne-eh01')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','pp','Avro_to_csv','OutputFilePattern','CEP_GameOpportunities_*.csv')


INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','StorageContainerName','eventhub-capture')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','Webhook_Python','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=neFnuOagYXI2pb8wagFLmjSEtkdW73kZ8m6HLH15IqI%3d')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','StorageAccountName','aznednaqasa01')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','Retailer','Gamification')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','StorageAccountServiceEndPoint',' https://aznednaqasa01.blob.core.windows.net/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','ArchivePath','Gamification/archive/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','DeleteSourceFile','0')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','OutputFilePath','Gamification/csv/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','RejectPath','Gamification/rejected/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','TargetFilePattern','CEP_*.csv')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','RejectFilePattern','GAMIFICATIONAVROTOCSVREJ*.dat')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','SourceFilePattern','prod_dat_ne_qa_ehns_01_prod_dna_qa_gamificationopportunities_ingest_ne_eh01_*.avro')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','CEP_GameOpportunities_%.csv','BUKIT/CEP/BootsUK_GameOpportunities_Boots_CEP_Incr/Incremental')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','CEP_EligibleCustomerOpportunities_%.csv','BUKIT/CEP/BootsUK_EligibleCustomerOpportunities_Boots_CEP_Incr/Incremental')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','TargetRejectPath','BUKIT/CEP/Gamification/rejected')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','OutputStorageContainerName','landing')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','srcPrefix','prod-dat-ne-qa-ehns-01/prod-dna-qa-gamificationopportunities-ingest-ne-eh01')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','qa','Avro_to_csv','OutputFilePattern','CEP_GameOpportunities_*.csv')


INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','StorageContainerName','eventhub-capture')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','Webhook_Python','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=neFnuOagYXI2pb8wagFLmjSEtkdW73kZ8m6HLH15IqI%3d')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','StorageAccountName','aznednaprodsa01')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','Retailer','Gamification')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','StorageAccountServiceEndPoint',' https://aznednaprodsa01.blob.core.windows.net/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','ArchivePath','Gamification/archive/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','DeleteSourceFile','0')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','OutputFilePath','Gamification/csv/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','RejectPath','Gamification/rejected/')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','TargetFilePattern','CEP_*.csv')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','RejectFilePattern','GAMIFICATIONAVROTOCSVREJ*.dat')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','SourceFilePattern','prod_dat_ne_pr_ehns_01_prod_dna_prod_gamificationopportunities_ingest_ne_eh01_*.avro')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','CEP_GameOpportunities_%.csv','BUKIT/CEP/BootsUK_GameOpportunities_Boots_CEP_Incr/Incremental')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','CEP_EligibleCustomerOpportunities_%.csv','BUKIT/CEP/BootsUK_EligibleCustomerOpportunities_Boots_CEP_Incr/Incremental')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','TargetRejectPath','BUKIT/CEP/Gamification/rejected')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','OutputStorageContainerName','landing')
INSERT INTO #GDHDynamicADFParams values('Gamification','Gamification_csv_load','prod','Avro_to_csv','srcPrefix','prod-dat-ne-pr-ehns-01/prod-dna-prod-gamificationopportunities-ingest-ne-eh01')

--STEP
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','SourceFilePattern','MDM_ProductDetails_*.xml')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','StorageContainerName','pdhlanding')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','DecryptionRequired','1')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','TargetFilePattern','GB_Product_Master_STEP_*.csv')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','RejectPath','rejected/STEP/')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','StorageAccountName','aznednaprodsa01')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','DecryptionWebhookURL','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=jPOyKrJruIKko6y00K%2fFPJcQWtV8mW29N%2fCzBVP00Cs%3d')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','GB_Product_Master_STEP_%.csv','GBMDT/STEP/GB_Product_Master_STEP/Incremental')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','Retailer','STEP')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','TargetRejectPath','GBMDT/STEP/rejected')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','DeleteSourceFile','1')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','InputFilePath','STEP/xml/')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','Webhook Python','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=G4FonfDXkgDV50h6LQYQyfsvAQ2lw%2fZB8JvXLp7JKGo%3d')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','StorageAccountServiceEndPoint',' https://aznednaprodsa01.blob.core.windows.net/')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','DecryptionKeyVault','aznednakvprod01')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','ArchivePath','archive/STEP/')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','RejectFilePattern','STEPXMLTOCSVREJ*.dat')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','OutputFilePath','STEP/csv/')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','DecryptionSecretName','gpg-prod-passphrase')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','OutputStorageContainerName','landing')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','TempPath','STEP/temp/')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','count','500')
INSERT INTO #GDHDynamicADFParams values('STEP','STEP_csv_load','prod','xml_to_csv','WebhookURL','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=nxuijJWhiPmeBPvfev94PO3J85ufFv%2bxC7EGxI8bkdc%3d')



INSERT INTO dc_metadata.[GDHDynamicADFParams]
SELECT 
	tmp.[Project_Name],
	tmp.[Job_name],
	tmp.[Environment],
	tmp.[Process_Name],
	tmp.[Param_key],
	tmp.[Param_value]
FROM #GDHDynamicADFParams tmp
LEFT OUTER JOIN (SELECT DISTINCT [Project_Name],[Job_name],[Environment],[Process_Name],[Param_key],[Param_value] FROM dc_metadata.[GDHDynamicADFParams]) src
ON src.Project_Name = tmp.Project_Name
AND src.Job_name = tmp.Job_name
AND src.Environment = tmp.Environment
AND src.Process_Name = tmp.Process_Name
AND src.Param_key = tmp.Param_key
AND src.Param_value = tmp.Param_value
WHERE src.Project_Name IS NULL
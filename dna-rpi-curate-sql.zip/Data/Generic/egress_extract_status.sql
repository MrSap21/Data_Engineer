﻿IF OBJECT_ID('tempdb..#egress_extract_status') IS NOT NULL
DROP TABLE #egress_extract_status
 
CREATE TABLE #egress_extract_status
(
[table_name] nvarchar(500) NULL,
[extract_date] nvarchar(30) NULL
)

INSERT INTO #egress_extract_status
SELECT 'rawuk_btc_deal_qualified_card','2020-04-01' UNION
SELECT 'rawuk_btc_transaction_card_p','2020-04-01' UNION
SELECT 'rawuk_btc_transaction_line_card_p','2020-04-01' UNION
SELECT 'uk_abacus_header','2020-10-20' UNION
SELECT 'uk_abacus_item','2020-10-20' UNION
SELECT 'uk_abacus_deals','2020-10-01' UNION
SELECT 'uk_abacus_payment','2020-10-01' UNION
SELECT 'uk_abacus_promotions','2020-10-01';

--Insert into the target table
INSERT INTO [psa].[egress_extract_status]
select * from #egress_extract_status t
WHERE NOT EXISTS (SELECT 1 FROM [psa].[egress_extract_status] r
				   WHERE t.[table_name] = r.[table_name]
				 )
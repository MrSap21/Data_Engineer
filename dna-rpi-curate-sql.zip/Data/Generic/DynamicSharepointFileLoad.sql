﻿IF OBJECT_ID('tempdb..#DynamicSharepointFileLoad') IS NOT NULL
    DROP TABLE #DynamicSharepointFileLoad

CREATE TABLE #DynamicSharepointFileLoad(
	[FilePatternId] [int] NOT NULL,
	[SourceFileNamePattern] [varchar](100) NULL,
	[SharepointFolder] [varchar](255) NULL,
	[BlobPath] [varchar](255) NOT NULL,
	[Retailer] [varchar](50) NOT NULL,
	[ModifiedBy] [varchar](50) NULL,
	[Active] [char](1) NOT NULL,
	[LastUpdated] [datetime2](7) NOT NULL,
	[SharepointSite] [varchar](255) NULL,
	[SharepointRootFolder] [varchar](255) NULL,
	[LastFileUpdate] [datetime2](7) NULL
)


INSERT INTO #DynamicSharepointFileLoad ([FilePatternId],[SourceFileNamePattern],[SharepointFolder],[BlobPath],[Retailer],[ModifiedBy],[Active],[LastUpdated],[SharepointSite],[SharepointRootFolder],[LastFileUpdate]) VALUES (0,'SAP Material Sales Reporting Master Data.xlsx','','gdh-logicapp-blobs','REFERENCEDATA',NULL,'1','2020-03-11 09:53:33.2600000','https://onewba.sharepoint.com/teams/BootsI/DataManagement','/Qlikview Resources/Root/Boots Int/Prod/Master Files/SAP Material Sales Reporting Master Data.xlsx','2021-06-27 23:00:42.1248528')
INSERT INTO #DynamicSharepointFileLoad ([FilePatternId],[SourceFileNamePattern],[SharepointFolder],[BlobPath],[Retailer],[ModifiedBy],[Active],[LastUpdated],[SharepointSite],[SharepointRootFolder],[LastFileUpdate]) VALUES (0,'BRUSA Store List Upload.xlsx',NULL,'gdh-logicapp-blobs','REFERENCEDATA',NULL,'1','2020-04-20 20:26:25.0466667','https://onewba.sharepoint.com/teams/BootsI/DataManagement','/Qlikview Resources/Root/BRUSA/Prod/BRUSA/User/MasterData/BRUSA Store List Upload.xlsx','2021-06-27 23:00:40.8772629')


INSERT INTO dc_metadata.[DynamicSharepointFileLoad]
SELECT 
	COALESCE(max_FilePatternId,0) + row_number() OVER (ORDER BY tmp.[SourceFileNamePattern],tmp.[BlobPath],tmp.[Retailer],tmp.[SharepointRootFolder]) as [FilePatternId],
	tmp.[SourceFileNamePattern],
	tmp.[SharepointFolder],
	tmp.[BlobPath],
	tmp.[Retailer],
	tmp.[ModifiedBy],
	tmp.[Active],
	tmp.[LastUpdated],
	tmp.[SharepointSite],
	tmp.[SharepointRootFolder],
	tmp.[LastFileUpdate]
FROM #DynamicSharepointFileLoad tmp
JOIN (SELECT MAX(FilePatternId) max_FilePatternId FROM dc_metadata.[DynamicSharepointFileLoad]) max_pk ON (1=1)
LEFT OUTER JOIN (SELECT DISTINCT [SourceFileNamePattern],[BlobPath],[Retailer],[SharepointRootFolder] FROM dc_metadata.[DynamicSharepointFileLoad]) src
ON src.SourceFileNamePattern = tmp.SourceFileNamePattern
AND src.BlobPath = tmp.BlobPath
AND src.Retailer = tmp.Retailer
AND src.SharepointRootFolder = tmp.SharepointRootFolder
WHERE src.SourceFileNamePattern IS NULL
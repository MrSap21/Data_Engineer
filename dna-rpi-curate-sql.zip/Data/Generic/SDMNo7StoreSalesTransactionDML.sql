﻿/* ***********************************************************
Purpose	: DQ Meta data Configuration
Source  : SDMNo7StoreSales
Domain  : Transaction 
===============================================================
Modification History 
===============================================================
Date              Description
---------------------------------------------------------------
09-09-2020        Initial Configuration v1.0
09-09-2020        v1.1
**************************************************************/

DECLARE @ruleidDC BIGINT,
		@ruleidNN BIGINT,
		@attributeidUPC BIGINT,
		@attributeidSTORE_NUM BIGINT,		
		@attributeidFINYEAR BIGINT,		
		@attributeidWEEKNUMBER BIGINT,	
		@entityid_SDM BIGINT,
		@entityid_PSA_SDM BIGINT,
		@entityid_His_SDM BIGINT,
		@entityid_His_PSA_SDM BIGINT;

BEGIN


SET @ruleidNN = (SELECT ruleid FROM psa.[rule] WHERE rulecode = 'NN' AND rulename = 'Not Null Check' AND activeflag = '1');


/* 
 *   SDMNo7StoreSales
 */

 
SET @entityid_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%Incremental upload of Shoppers Drug Mart store data%');
SET @entityid_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'SDM_SDMEXCEL_SDMNo7StoreSales');

SET @entityid_His_SDM = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND
entityname like '%SDMNo7StoreSales Ingestion%');
SET @entityid_His_PSA_SDM = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND
entityname = 'RPIDNA_DNAPSAV1_SDMNo7StoreSales');

-- Update Business Key fields in Attribute table 

--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','STORE_NUM','UPC') AND activeflag=1;
--UPDATE psa.attribute SET attributeType=40001 WHERE entityID=@entityid_His_SDM AND attributeName IN 
--('FINYEAR','WEEKNUMBER','STORE_NUM','UPC') AND activeflag=1;



--Delete already existing entries for the entityPSA id
DELETE FROM [psa].[RuleEntity] WHERE EntityID IN 
(@entityid_PSA_SDM,@entityid_His_PSA_SDM);




-- Find the attributeId
SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_SDM);
SET @attributeidSTORE_NUM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE_NUM' AND 
entityid = @entityid_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidSTORE_NUM
PRINT @attributeidUPC
--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidSTORE_NUM,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);





--History
-- Find the attributeId

-- Find the attributeId
SET @attributeidFINYEAR = (SELECT attributeid FROM psa.attribute WHERE attributename = 'FINYEAR' AND 
entityid = @entityid_His_SDM);
SET @attributeidWEEKNUMBER = (SELECT attributeid FROM psa.attribute WHERE attributename = 'WEEKNUMBER' AND 
entityid = @entityid_His_SDM);
SET @attributeidSTORE_NUM = (SELECT attributeid FROM psa.attribute WHERE attributename = 'STORE_NUM' AND 
entityid = @entityid_His_SDM);
SET @attributeidUPC = (SELECT attributeid FROM psa.attribute WHERE attributename = 'UPC' AND 
entityid = @entityid_His_SDM);

PRINT @attributeidFINYEAR
PRINT @attributeidWEEKNUMBER
PRINT @attributeidSTORE_NUM
PRINT @attributeidUPC
--Insert to RuleEntity for NotNull checks for BK 
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidFINYEAR,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidWEEKNUMBER,28004,'28001',NULL,1,@insert_date,@insert_user);

INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidSTORE_NUM,28004,'28001',NULL,1,@insert_date,@insert_user);
INSERT INTO psa.ruleentity VALUES 
(@ruleidNN,@entityid_His_PSA_SDM,@attributeidUPC,28004,'28001',NULL,1,@insert_date,@insert_user);


END
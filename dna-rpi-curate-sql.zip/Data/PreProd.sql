﻿-- Run DML Scripts Specifically to Pre-Prod Feeds
-- Base Path for all files should be : D:\a\r1\a\_dna-rpi-curate-sql\SQLDML\Specific\PreProd\
--
-- Files in Order of Data insertion (i.e. cf_feed_configuration needs values from cf_stored_prod)
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\initialise_parameters.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\cf_stored_proc.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\sap_extract_definitions.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\RuleRefLookup.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Specific\PreProd\cf_feed_configuration.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Specific\PreProd\cf_batch.sql
--
--:r D:\a\r1\a\_dna-rpi-curate-sql\SQLDML\Generic\RuleLookup.sql
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\RuleLookup.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\iso_units_of_measure.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Specific\PreProd\LEIT_LEXDH_LE_Config.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\DynamicEmailFileLoad.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\DynamicSharepointFileLoad.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\DynamicSharepointFileLoadMetadata.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Generic\GDHDynamicADFParams.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Specific\PreProd\monitor_reconcile_metadata.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Specific\PreProd\cf_program_batch.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Specific\PreProd\historymdref.sql
--
:r $(pathname)\_dna-rpi-curate-sql\SQLDML\Specific\PreProd\mt_bucket_iterate.sql
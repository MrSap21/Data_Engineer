﻿
IF OBJECT_ID('tempdb..#cf_feed_configuration') IS NOT NULL
  DROP TABLE #cf_feed_configuration

CREATE TABLE #cf_feed_configuration
(
	[feed_id] [int] NOT NULL,
	[psa_table_name] [nchar](80) NULL,
	[delta_capture_sp] [int] NOT NULL,
	[curation_sp] [int] NOT NULL,
	[record_filter_id] [int] NULL,
	[depends_on] [nchar](25) NULL,
	[null_conv_char] [nchar](5) NULL,
	[active_flag] [smallint] NOT NULL,
	[dt_created] [smalldatetime] NULL,
	[user_created] [nchar](100) NULL
)

/*

Enter Your FEED_CONFIGURATION below.  If it doens't exist it'll insert it into the table.

*/

DELETE FROM psa.cf_feed_configuration where feed_id IN (297,298);

/* Pre Prod Configuration */                

INSERT INTO #cf_feed_configuration SELECT 294,'RPIDNA_GBSAP_MARA',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 295,'RPIDNA_GBSAP_MAKT',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 296,'RPIDNA_GBSAP_T023T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
--INSERT INTO #cf_feed_configuration SELECT 297,'RPIDNA_GBSAP_T179T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 297,'RPIDNA_GBSAP_T179T',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_sap_product' 
INSERT INTO #cf_feed_configuration SELECT 298,'RPIDNA_GBSAP_MARC',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gbmr_golden_product' 

INSERT INTO #cf_feed_configuration SELECT 299,'RPIDNA_GBSAP_VBRK',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 300,'RPIDNA_GBSAP_VBRP',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_sap_transaction' 
INSERT INTO #cf_feed_configuration SELECT 301,'SAPCOE_BUKSAP_BUKSAPArticle',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_buk_sap_product' 
INSERT INTO #cf_feed_configuration SELECT 399,'GBFIN_GBFINEXCEL_GBFINRetailerCalendar',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_calendar_master' 
INSERT INTO #cf_feed_configuration SELECT 2469,'GBFIN_GBFINEXCEL_GB_Calendar_information_GBFINEXCEL_incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBFINEXCEL_GB_Calendar_information_GBFINEXCEL_incr' 
INSERT INTO #cf_feed_configuration SELECT 303,'LEIT_LEDATAHUB_SalesProduct'  ,a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_le_product'
INSERT INTO #cf_feed_configuration SELECT 377,'WAGIT_WAGEDW_WalgreensProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensProduct' 
INSERT INTO #cf_feed_configuration SELECT 392,'GBMDT_GBFINEXCEL_GBMDTProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_sap_mdm_product' 

-- SAP Customer
INSERT INTO #cf_feed_configuration SELECT 454,'RPIDNA_GBSAP_SAP_T001',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 455,'RPIDNA_GBSAP_SAP_TVKOT',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 456,'RPIDNA_GBSAP_SAP_KNA1',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 458,'RPIDNA_GBSAP_SAP_KNB1',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 459,'RPIDNA_GBSAP_SAP_TVKO',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 478,'RPIDNA_GBSAP_SAP_ADRC',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_sap_customer_master' 
INSERT INTO #cf_feed_configuration SELECT 479,'RPIDNA_GBSAP_SAP_KNVV',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'

--Opticians
INSERT INTO #cf_feed_configuration SELECT 670,'SAPCOE_BTCSAPECC_BUK_Opticians_Product_Master_Data_SAP_ECC',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_optician'
INSERT INTO #cf_feed_configuration SELECT 672,'BOPSAPPMAN_BUKOPTMI_BUK_Opticians_Transaction_Sales_Price_Data_Opticians_MI_Incr',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_optician'


--Dermstore
INSERT INTO #cf_feed_configuration SELECT 361,'RPIDNA_DNAPSAV1_DermstoreRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_DermstoreRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 384,'TGTDS_TGTDSEXCEL_DermstoreRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TGTDS_TGTDSEXCEL_DermstoreRetailSales' 


--Skinstore
INSERT INTO #cf_feed_configuration SELECT 359,'RPIDNA_DNAPSAV1_SKINSTORE_No7_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SKINSTORE_No7_WeeklyRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 381,'SKNST_SKNSTEXCEL_SKINSTORE_No7_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SKNST_SKNSTEXCEL_SKINSTORE_No7_WeeklyRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 358,'RPIDNA_DNAPSAV1_SKINSTORE_SG_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SKINSTORE_SG_WeeklyRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 382,'SKNST_SKNSTEXCEL_SKINSTORE_SG_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SKNST_SKNSTEXCEL_SKINSTORE_SG_WeeklyRetailSales' 


--SDM
INSERT INTO #cf_feed_configuration SELECT 357,'RPIDNA_DNAPSAV1_SDMSGESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMSGESales' 
INSERT INTO #cf_feed_configuration SELECT 354,'RPIDNA_DNAPSAV1_SDMSGStoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMSGStoreSales'     
INSERT INTO #cf_feed_configuration SELECT 356,'RPIDNA_DNAPSAV1_SDMNo7StoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMNo7StoreSales' 
INSERT INTO #cf_feed_configuration SELECT 355,'RPIDNA_DNAPSAV1_SDMNo7ESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMNo7ESales' 
INSERT INTO #cf_feed_configuration SELECT 374,'SDM_SDMEXCEL_SDMNo7ESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMNo7ESales' 
INSERT INTO #cf_feed_configuration SELECT 379,'SDM_SDMEXCEL_SDMSGStoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMSGStoreSales'     
INSERT INTO #cf_feed_configuration SELECT 378,'SDM_SDMEXCEL_SDMNo7StoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMNo7StoreSales' 
INSERT INTO #cf_feed_configuration SELECT 380,'SDM_SDMEXCEL_SDMSGESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMSGESales' 

--TSG
INSERT INTO #cf_feed_configuration SELECT 364,'RPIDNA_DNAPSAV1_TSGAAFES',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TSGAAFES' 
INSERT INTO #cf_feed_configuration SELECT 363,'RPIDNA_DNAPSAV1_TSGMCXNo7',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TSGMCXNo7' 
INSERT INTO #cf_feed_configuration SELECT 362,'RPIDNA_DNAPSAV1_TSGNEXCOM',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TSGNEXCOM' 
INSERT INTO #cf_feed_configuration SELECT 385,'TSG_TSGEXCEL_TSGAAFES',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TSG_TSGEXCEL_TSGAAFES' 
INSERT INTO #cf_feed_configuration SELECT 386,'TSG_TSGEXCEL_TSGMCXNo7',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TSG_TSGEXCEL_TSGMCXNo7' 
INSERT INTO #cf_feed_configuration SELECT 387,'TSG_TSGEXCEL_TSGNEXCOM',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TSG_TSGEXCEL_TSGNEXCOM' 

--Target
INSERT INTO #cf_feed_configuration SELECT 360,'RPIDNA_DNAPSAV1_TargetSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TargetSales' 
INSERT INTO #cf_feed_configuration SELECT 383,'TGT_TGTWP_TargetSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_TGT_TGTWP_TargetSales' 


--ULTA
INSERT INTO #cf_feed_configuration SELECT 389,'Ulta_ULTAEXCEL_UltaEDI',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_Ulta_ULTAEXCEL_UltaEDI' 
INSERT INTO #cf_feed_configuration SELECT 366,'RPIDNA_DNAPSAV1_UltaWeb',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_UltaWeb' 
INSERT INTO #cf_feed_configuration SELECT 388,'Ulta_ULTAEXCEL_UltaWeb',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_Ulta_ULTAEXCEL_UltaWeb' 

--WAG product
INSERT INTO #cf_feed_configuration SELECT 398,'RPIDNA_DNAPSAV1_WalgreensProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensProduct' 
INSERT INTO #cf_feed_configuration SELECT 377,'WAGIT_WAGEDW_WalgreensProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensProduct' 
INSERT INTO #cf_feed_configuration SELECT 2470,'DATALYNX_WAGX_GB_Daily_Walgreens_Sales_from_RSI_WAGX',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_DATALYNX_WAGX_GB_Daily_Walgreens_Sales_from_RSI_WAGX' 

 --Indonesia
INSERT INTO #cf_feed_configuration SELECT 2675,'IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL' 

--WAG Transaction
INSERT INTO #cf_feed_configuration SELECT 395,'RPIDNA_DNAPSAV1_WalgreensTransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensTransaction' 
INSERT INTO #cf_feed_configuration SELECT 414,'WAGIT_WAGEDW_WalgreensTransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensTransaction' 

INSERT INTO #cf_feed_configuration SELECT 396,'RPIDNA_DNAPSAV1_WalgreensETransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensETransaction' 
INSERT INTO #cf_feed_configuration SELECT 413,'WAGIT_WAGEDW_WalgreensETransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensETransaction' 

INSERT INTO #cf_feed_configuration SELECT 368,'RPIDNA_DNAPSAV1_WalgreensTransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensTransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 410,'WAGIT_WAGEDW_WalgreensTransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensTransactionCost' 

INSERT INTO #cf_feed_configuration SELECT 397,'RPIDNA_DNAPSAV1_WalgreensETransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensETransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 391,'WAGIT_WAGEDW_WalgreensETransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensETransactionCost' 

--CurrenCy Conversion
INSERT INTO #cf_feed_configuration SELECT 462,'GFSD_GFSDEXCEL_GlobalBrandsCurrencyConversionRates',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GFSD_GFSDEXCEL_GlobalBrandsCurrencyConversionRates' 

--Baozun Combo
INSERT INTO #cf_feed_configuration SELECT 452,'WBAHK_BZUNEXCEL_BaozunComboSalesHistory',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunComboHistory' 
INSERT INTO #cf_feed_configuration SELECT 453,'WBAHK_BZUNEXCEL_BaozunComboIncremental',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunComboIncremental' 
--Baozun Sales
INSERT INTO #cf_feed_configuration SELECT 375,'WBAHK_BZUNEXCEL_BaozunSalesHistory',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunSalesHistory' 
INSERT INTO #cf_feed_configuration SELECT 376,'WBAHK_BZUNEXCEL_BaozunSalesIncremental',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunSalesIncremental' 

--GBFINRetailer
INSERT INTO #cf_feed_configuration SELECT 403,'GBFIN_GBFINEXCEL_GBFINRetailer',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBFINEXCEL_GBFINRetailer_party' 

--GBFINStoreMaster
INSERT INTO #cf_feed_configuration SELECT 402,'GBFIN_GBFINEXCEL_GBFINStoreMaster',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBFINEXCEL_GBFINStoreMaster' 

--DA Invoice 
INSERT INTO #cf_feed_configuration SELECT 481,'BUKIT_GBEDISTG_DAInvoiceDetails',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_gb_da_inv_transaction_master'

--GB SAP Finance GL
INSERT INTO #cf_feed_configuration SELECT 492,'RPIDNA_GBSAP_SAP_BKPF',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_BKPF'
INSERT INTO #cf_feed_configuration SELECT 493,'RPIDNA_GBSAP_SAP_BSEG',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_BSEG'
INSERT INTO #cf_feed_configuration SELECT 494,'RPIDNA_GBSAP_SAP_SKAT',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_SKAT'
INSERT INTO #cf_feed_configuration SELECT 495,'RPIDNA_GBSAP_SAP_CEPT',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_CEPT'
INSERT INTO #cf_feed_configuration SELECT 496,'RPIDNA_GBSAP_SAP_CE41000_ACCT',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_CE41000_ACCT'

--LE Store
INSERT INTO #cf_feed_configuration SELECT 499,'LEIT_LEXDH_LEIT_LEX_SALES_Store',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_LEIT_LEXDH_LEIT_LEX_SALES_Store'

--GBSAP GL Manual Adjustment
INSERT INTO #cf_feed_configuration SELECT 502,'GBFIN_GBSAP_SAP_Invoice_manual_adjustment',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBSAP_SAP_Invoice_manual_adjustment'

--DA COGS
INSERT INTO #cf_feed_configuration SELECT 497,'RPIDNA_GBSAP_SAP_MKPF',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_da_cogs_document' 
INSERT INTO #cf_feed_configuration SELECT 498,'RPIDNA_GBSAP_SAP_MSEG',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_da_cogs_transaction_master' 

--LE Sales
INSERT INTO #cf_feed_configuration SELECT 500,'LEIT_LEXDH_LIZ_EARLE_RETAIL_AND_INVOICE_SALES',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_liz_earle_sales_master'

-- SAP Customer Lookup Tables
INSERT INTO #cf_feed_configuration SELECT 505,'RPIDNA_GBSAP_SAP_T151T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 506,'RPIDNA_GBSAP_SAP_TVV1T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 507,'RPIDNA_GBSAP_SAP_TVV2T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 508,'RPIDNA_GBSAP_SAP_TVV3T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'

--GB S&OP Kohls
INSERT INTO #cf_feed_configuration SELECT 503,'Kohls_KSSWP_Kohls_weekly_sales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_KOHLS_KSSWP_KOHLS_WEEKLY_SALES' 

--TeamCenter Product
INSERT INTO #cf_feed_configuration SELECT 501,'BUKIT_GBTC_Teamcenter',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_BUKIT_GBTC_Teamcenter'

--GB S&OP Walmart Retail Sales 
INSERT INTO #cf_feed_configuration SELECT 509,'Walmart_WMTWP_Walmart_retail_sales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_WALMART_WMTWP_WALMART_RETAIL_SALES' 

--GB S&OP Walmart Online Sales 
INSERT INTO #cf_feed_configuration SELECT 510,'Walmart_WMTWP_Walmart_online_sales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_WALMART_WMTWP_WALMART_ONLINE_SALES' 

--GB S&OP Alshaya Weekly sales inc
INSERT INTO #cf_feed_configuration SELECT 659,'MHAC_MHACX_Alshaya_Weekly_sales_inc',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_MHAC_MHACX_Alshaya_Weekly_sales_inc' 

--GB S&OP APH Weekly sales inc
INSERT INTO #cf_feed_configuration SELECT 687,'APH_APHX_APH_Weekly_sales_inc',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_APH_APHX_APH_Weekly_sales_inc' 


--International Retail Sales
INSERT INTO #cf_feed_configuration SELECT 440,'RPIDNA_DNAPSAV1_FAITFAPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 423,'FAIT_BIRFAEXCEL_FAITFAPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 409,'FAIT_BIRFAEXCEL_FAITFAPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 439,'RPIDNA_DNAPSAV1_FAITFAPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 441,'BTHIT_BIRTHEXCEL_BIRTHITTPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 442,'BTHIT_BIRTHEXCEL_BIRTHITTPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 444,'RPIDNA_DNAPSAV1_BIRTHITTPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 445,'RPIDNA_DNAPSAV1_BIRTHITTPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 447,'BNEIT_BIRNLEXCEL_BIRNEITNEPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 449,'BNEIT_BIRNLEXCEL_BIRNEITNEPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 450,'RPIDNA_DNAPSAV1_BIRNEITNEPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 451,'RPIDNA_DNAPSAV1_BIRNEITNEPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 425,'FBIT_BIRFBEXCEL_BIRMEXITMEXPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 427,'FBIT_BIRFBEXCEL_BIRMEXITMEXPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 434,'RPIDNA_DNAPSAV1_BIRMEXITMEXPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 435,'RPIDNA_DNAPSAV1_BIRMEXITMEXPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 429,'BNIT_BIRNOEXCEL_BIRNITBIRNPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 431,'BNIT_BIRNOEXCEL_BIRNITBIRNPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 433,'BNIT_BIRNOEXCEL_BIRNITBIRNWSWholesaleDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 436,'RPIDNA_DNAPSAV1_BIRNITBIRNPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 437,'RPIDNA_DNAPSAV1_BIRNITBIRNPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 438,'RPIDNA_DNAPSAV1_BIRNITBIRNWSWholesaleDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'

--Mecca Sales
INSERT INTO #cf_feed_configuration SELECT 511,'Mecca_MECCAIT_Mecca_Monthly_sales_inc',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_mecca_transaction_master' 

-- Liz Earle Migration
INSERT INTO #cf_feed_configuration SELECT 604,'LEIT_LEXDH_LE_Bin_Item_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 605,'LEIT_LEXDH_LE_Bom_Item_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 606,'LEIT_LEXDH_LE_CB_Account_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 607,'LEIT_LEXDH_LE_CB_Account_Contact_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 608,'LEIT_LEXDH_LE_Document_Print_Status_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 609,'LEIT_LEXDH_LE_Document_Status_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 610,'LEIT_LEXDH_LE_Landed_Costs_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 611,'LEIT_LEXDH_LE_NL_Posted_Nominal_Transaction_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 612,'LEIT_LEXDH_LE_PL_Posted_Supplier_Transaction_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 613,'LEIT_LEXDH_LE_PL_Supplier_Account_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 614,'LEIT_LEXDH_LE_PL_Supplier_Contact_Value_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 615,'LEIT_LEXDH_LE_PL_Supplier_Contact_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 616,'LEIT_LEXDH_LE_PL_Supplier_Location_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 617,'LEIT_LEXDH_LE_NL_Account_Number_Cost_Centre_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 618,'LEIT_LEXDH_LE_NL_Account_Number_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 619,'LEIT_LEXDH_LE_NL_Account_Report_Category_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 620,'LEIT_LEXDH_LE_NL_Account_Report_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 621,'LEIT_LEXDH_LE_NL_Account_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 622,'LEIT_LEXDH_LE_NL_Cost_Centre_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 623,'LEIT_LEXDH_LE_NL_Department_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 624,'LEIT_LEXDH_LE_NL_Nominal_Account_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 625,'LEIT_LEXDH_LE_NL_Nominal_Tran_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 626,'LEIT_LEXDH_LE_Order_Return_Line_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 627,'LEIT_LEXDH_LE_PL_Payment_Group_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 628,'LEIT_LEXDH_LE_PL_Supplier_Contact_Role_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 629,'LEIT_LEXDH_LE_POP_Invoice_Credit_Line_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 630,'LEIT_LEXDH_LE_POP_Invoice_Credit_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 631,'LEIT_LEXDH_LE_POP_Order_Return_Line_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 632,'LEIT_LEXDH_LE_POP_Order_Return_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 633,'LEIT_LEXDH_LE_POP_Order_Return_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 634,'LEIT_LEXDH_LE_POP_Receipt_Return_Line_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 635,'LEIT_LEXDH_LE_POP_Receipt_Return_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 636,'LEIT_LEXDH_LE_POP_Receipt_Return_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 637,'LEIT_LEXDH_LE_Product_Group_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 638,'LEIT_LEXDH_LE_Salutation_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 639,'LEIT_LEXDH_LE_Source_Area_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 640,'LEIT_LEXDH_LE_Stock_Item_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 641,'LEIT_LEXDH_LE_Stock_Item_Status_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 642,'LEIT_LEXDH_LE_Stock_Item_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 643,'LEIT_LEXDH_LE_SYS_Account_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 644,'LEIT_LEXDH_LE_Sys_Contact_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 645,'LEIT_LEXDH_LE_SYS_Country_Code_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 646,'LEIT_LEXDH_LE_SYS_Credit_Bureau_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 647,'LEIT_LEXDH_LE_SYS_Credit_Position_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 648,'LEIT_LEXDH_LE_SYS_Currency_ISO_Code_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 649,'LEIT_LEXDH_LE_SYS_Currency_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 650,'LEIT_LEXDH_LE_SYS_Exchange_Rate_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 651,'LEIT_LEXDH_LE_SYS_Module_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 652,'LEIT_LEXDH_LE_SYS_Payment_Terms_Basis_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 653,'LEIT_LEXDH_LE_Sys_Tax_EC_Term_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 654,'LEIT_LEXDH_LE_Sys_Tax_Rate_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 655,'LEIT_LEXDH_LE_SYS_Trader_Contact_Role_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 656,'LEIT_LEXDH_LE_SYS_Trader_Tran_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 657,'LEIT_LEXDH_LE_Traceable_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 658,'LEIT_LEXDH_LE_Warehouse_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'

-- GBMR UI
INSERT INTO #cf_feed_configuration SELECT 661,'RPIDNA_DNAUIGBMRPRD_GB_GBMR_Product_Updates_GBMRUI_inc',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAUIGBMRPRD_GB_GBMR_Product_Updates_GBMRUI'

--BUK TransactionLineAnon and TransactionLineCard OneTimeUpdateActivity
INSERT INTO #cf_feed_configuration SELECT 665,'BUKIT_ABACUS_BUK_Transaction_line_anon_Abacus_hist',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_BUKIT_ABACUS_BUK_Transaction_line_anon_Abacus_hist'
INSERT INTO #cf_feed_configuration SELECT 668,'BUKIT_ABACUS_BUK_Transaction_line_card_Abacus_hist',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_BUKIT_ABACUS_BUK_Transaction_line_card_Abacus_hist'

--Budget and Forecast Weekly
INSERT INTO #cf_feed_configuration SELECT 677,'GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_budgetforecast_weekly_main'

--Budget and Forecast Monthly
INSERT INTO #cf_feed_configuration SELECT 676,'GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_budgetforecast_Monthly_main'

--Martech Wave 2  CRM History 
INSERT INTO #cf_feed_configuration SELECT 528,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_child',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 529,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_clubs',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 530,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 527,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_activity',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 514,'BUKIT_ABACUS_BUK_SAPCRM_Advantage_Card_membership_card',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 526,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_points',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 525,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'


--Martech Wave 2  SVOC History 
INSERT INTO #cf_feed_configuration SELECT 559,'BUKIT_BTCSVOC_BUK_SVOC_Customer_address',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 572,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 570,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 554,'BUKIT_BTCSVOC_BUK_SVOC_Customer_data',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 563,'BUKIT_BTCSVOC_BUK_SVOC_Customer_email',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 555,'BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 566,'BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 558,'BUKIT_BTCSVOC_BUK_SVOC_Customer_phone',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 567,'BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 603,'BUKIT_ABACUS_BUK_SVOC_Customer_consent_type',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'

--Martech Wave 2 CRM Incremental  
INSERT INTO #cf_feed_configuration SELECT 522,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_child',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 523,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_clubs',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 524,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 520,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_points',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 521,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_activity',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_CRMTrans'
INSERT INTO #cf_feed_configuration SELECT 519,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_CRMTrans'
INSERT INTO #cf_feed_configuration SELECT 516,'SAPCOE_SAPCRM_BUK_SAPCRM_Customer_Anonymisation',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 515,'SAPCOE_SAPCRM_BUK_SAPCRM_Customer_Status_Change',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'


--Martech Wave 2 SVOC Incremental   
INSERT INTO #cf_feed_configuration SELECT 544,'BUKIT_BTCSVOC_BUK_SVOC_Customer_address',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 549,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 550,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_SvocEntityLink'
INSERT INTO #cf_feed_configuration SELECT 542,'BUKIT_BTCSVOC_BUK_SVOC_Customer_data',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 552,'BUKIT_BTCSVOC_BUK_SVOC_Customer_delete',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 546,'BUKIT_BTCSVOC_BUK_SVOC_Customer_email',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 543,'BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_SvocEntityLink'
INSERT INTO #cf_feed_configuration SELECT 548,'BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 545,'BUKIT_BTCSVOC_BUK_SVOC_Customer_phone',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 547,'BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'

-- DPI
INSERT INTO #cf_feed_configuration SELECT 689,'BootsUK_Pharmacy_Customer_Info_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 690,'BootsUK_Pharmacy_Order_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 691,'BootsUK_Pharmacy_Customer_Relationship_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 692,'BootsUK_Pharmacy_Order_Items_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 693,'BootsUK_Pharmacy_Order_Transition_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 694,'BootsUK_Pharmacy_Order_Edits_Removal_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 695,'BootsUK_Pharmacy_Order_Consent_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 696,'BootsUK_Pharmacy_Order_TaxedPrice_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'

--Product Exclusion
INSERT INTO #cf_feed_configuration SELECT 2681,'GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_step_product_exclusion' 

--Retailer to STEP mapping
INSERT INTO #cf_feed_configuration SELECT -2,'',0,sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_insertretailertostep_productrelationship'

/* End of Configuration */

INSERT INTO [psa].[cf_feed_configuration] 
select 
	[feed_id],
	[psa_table_name],
	[delta_capture_sp],
	[curation_sp],
	[record_filter_id],
	[depends_on],
	[null_conv_char],
	[active_flag],
	[dt_created],
	[user_created]
from #cf_feed_configuration
WHERE [feed_id] NOT IN (select distinct [feed_id] from [psa].[cf_feed_configuration])

UPDATE [psa].[cf_feed_configuration] 
SET	[psa_table_name]		= cf.[psa_table_name]		,
	[delta_capture_sp]		= cf.[delta_capture_sp]	,
	[curation_sp]			= cf.[curation_sp]			,
	[record_filter_id]		= cf.[record_filter_id]	,
	[depends_on]			= cf.[depends_on]			,
	[null_conv_char]		= cf.[null_conv_char]		,
	[active_flag]			= cf.[active_flag]		
FROM #cf_feed_configuration cf
WHERE 
[cf_feed_configuration].feed_id = cf.feed_id
AND
(
	cf.[psa_table_name]		<> [cf_feed_configuration].[psa_table_name]		OR
	cf.[delta_capture_sp]	<> [cf_feed_configuration].[delta_capture_sp]	OR
	cf.[curation_sp]		<> [cf_feed_configuration].[curation_sp]		OR
	cf.[record_filter_id]	<> [cf_feed_configuration].[record_filter_id]	OR
	cf.[depends_on]			<> [cf_feed_configuration].[depends_on]			OR
	cf.[null_conv_char]		<> [cf_feed_configuration].[null_conv_char]		OR
	cf.[active_flag]		<> [cf_feed_configuration].[active_flag]			
)

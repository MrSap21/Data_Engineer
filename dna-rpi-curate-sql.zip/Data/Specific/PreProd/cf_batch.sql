﻿IF OBJECT_ID('tempdb..#cf_batch') IS NOT NULL
  DROP TABLE #cf_batch

CREATE TABLE #cf_batch
(
	[batch_id] [int] NOT NULL,
	[batch_name] [nchar](100) NULL,
	[feed_id] [int] NOT NULL,
	[order_of_execution] [int] NOT NULL,
	[active_flag] [smallint] NOT NULL,
	[dt_created] [smalldatetime] NULL,
	[user_created] [nchar](100) NULL
)


--DELETE FROM psa.cf_batch where feed_id IN (354,357,356,355,379,380,378,374,359,381,358,382);

INSERT INTO #cf_batch VALUES(0,'GB SAP',294,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',295,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',296,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',297,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',298,5,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP TRANSACTION',299,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP TRANSACTION',300,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'LIZ EARLE',303,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BUK SAP',301,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAP PRODUCT MASTER',392,1,1,@insert_date,@insert_user)

--Calendar
INSERT INTO #cf_batch VALUES(0,'Calendar',399,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GBFIN_Calendar_incr',2469,1,1,@insert_date,@insert_user);

--Walgreens
INSERT INTO #cf_batch VALUES(0,'WAGProduct',377,1,1,@insert_date,@insert_user)

--Dermstore
INSERT INTO #cf_batch VALUES(0,'Dermstore history',361,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Dermstore incremental',384,1,1,@insert_date,@insert_user)

--Skinstore
INSERT INTO #cf_batch VALUES(0,'Skinstore No7 history',359,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Skinstore No7 incremental',381,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Skinstore SG history',358,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Skinstore SG incremental',382,1,1,@insert_date,@insert_user)

--SDM
INSERT INTO #cf_batch VALUES(0,'SDMSGStoreSales History',354,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMSGESales History',357,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7StoreSales History',356,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7ESales History',355,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMSGStoreSales Incremental',379,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMSGESales Incremental',380,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7StoreSales Incremental',378,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7ESales Incremental',374,1,1,@insert_date,@insert_user)

--TSG
INSERT INTO #cf_batch VALUES(0,'TSGAAFES History',364,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGMCXNo7 History',363,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGNEXCOM History',362,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGAAFES Incremental',385,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGMCXNo7 Incremental',386,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGNEXCOM Incremental',387,1,1,@insert_date,@insert_user)


--Target
INSERT INTO #cf_batch VALUES(0,'Target History',360,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Target Incremental',383,1,1,@insert_date,@insert_user)


--ULTA
INSERT INTO #cf_batch VALUES(0,'ULTAEDI Incremental',389,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'ULTAWEB History',366,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'ULTAWEB Incremental',388,1,1,@insert_date,@insert_user)

-- WAG product
INSERT INTO #cf_batch VALUES(0,'WAG product History',398,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG product Incremental',377,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'walgreens RSI daily sales',2470,1,1,@insert_date,@insert_user)

--Indonesia
INSERT INTO #cf_batch VALUES(0,'Indonesia weekly sales transaction',2675,1,1,@insert_date,@insert_user)

--WAG Transaction
INSERT INTO #cf_batch VALUES(0,'WAG Transaction History',395,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG Transaction Incremental',414,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG ETransaction History',396,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG ETransaction Incremental',413,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transactioncost History',368,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transactioncost Incremental',410,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransactioncost History',397,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransactioncost Incremental',391,1,1,@insert_date,@insert_user)

--Currency Conversion 
INSERT INTO #cf_batch VALUES(0,'GlobalBrandsCurrencyConversionRates Incremental',462,1,1,@insert_date,@insert_user)

--Baozun Combo history 
INSERT INTO #cf_batch VALUES(0,'BaozunComboHistory',452,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BaozunComboIncremental',453,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BaozunSalesHistory',375,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BaozunSalesIncremental',376,1,1,@insert_date,@insert_user)

--GBFINRetailer
INSERT INTO #cf_batch VALUES(0,'GBFINRetailerIncremental',403,1,1,@insert_date,@insert_user)

--GBFINStoreMaster
INSERT INTO #cf_batch VALUES(0,'GBFINStoreMasterIncremental',402,1,1,@insert_date,@insert_user)

--DA Invoice
INSERT INTO #cf_batch VALUES(0,'GB MI DA_Invoice Transaction',481,1,1,@insert_date,@insert_user)

--GB SAP Customer
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',456,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',458,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',479,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',454,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',459,5,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',455,6,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',478,7,1,@insert_date,@insert_user)

--GB SAP Finance GL
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL BKPF',492,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL BSEG',493,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL SKAT',494,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL CEPT',495,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL CE41000_ACCT',496,1,1,@insert_date,@insert_user)

--LE Store
INSERT INTO #cf_batch VALUES(0,'LizEarleStore',499,1,1,@insert_date,@insert_user)

--GBSAP GL Manual Adjustment
INSERT INTO #cf_batch VALUES(0,'GBSAP GL ManualAdjustment',502,1,1,@insert_date,@insert_user)

--DA COGS
INSERT INTO #cf_batch VALUES(0,'DA COGS Material Document Invoice',497,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'DA COGS Material Document Invoice',498,2,1,@insert_date,@insert_user)

--LE Sales
INSERT INTO #cf_batch VALUES(0,'LIZ EARLE Sales',500,1,1,@insert_date,@insert_user)

--GB S&OP Kohls
INSERT INTO #cf_batch VALUES(0,'GB S&OP Kohls weekly sales',503,1,1,@insert_date,@insert_user)

--TeamCenter Product
INSERT INTO #cf_batch VALUES(0,'TeamCenterProduct',501,1,1,@insert_date,@insert_user)

--GB S&OP Walmart Retail Sales 
INSERT INTO #cf_batch VALUES(0,'GB S&OP Walmart store retail sales',509,1,1,@insert_date,@insert_user)

--GB S&OP Walmart Online Sales 
INSERT INTO #cf_batch VALUES(0,'GB S&OP Walmart online retail sales',510,1,1,@insert_date,@insert_user)

--GB S&OP Alshaya Weekly sales inc 
INSERT INTO #cf_batch VALUES(0,'GB S&OP Alshaya Weekly sales inc',659,1,1,@insert_date,@insert_user)

--GB S&OP APH Weekly sales inc 
INSERT INTO #cf_batch VALUES(0,'GB S&OP APH Weekly sales inc',687,1,1,@insert_date,@insert_user)


--Mecca Sales
INSERT INTO #cf_batch VALUES(0,'Mecca Sales',511,1,1,@insert_date,@insert_user)


--GBMR UI
INSERT INTO #cf_batch VALUES(0,'GBMR UI',661,1,1,@insert_date,@insert_user)

--BUK TransactionLineAnon and TransactionLineCard OneTimeUpdateActivity
INSERT INTO #cf_batch VALUES(0,'BUK TransactionLineAnon Onetime',665,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BUK TransactionLineCard Onetime',668,1,1,@insert_date,@insert_user)

-- Budget and Forecast Weekly
INSERT INTO #cf_batch VALUES(0,'Budget and Forecast Weekly',677,1,1,@insert_date,@insert_user)

-- Budget and Forecast Monthly
INSERT INTO #cf_batch VALUES(0,'Budget and Forecast Monthly',676,1,1,@insert_date,@insert_user)


-- New Set of Batches for Global Brands

-- GBA

INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',413,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',414,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',391,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',410,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',390,5,1,@insert_date,@insert_user)

-- S&M

INSERT INTO #cf_batch VALUES(0,'GB SM',479,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',478,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',459,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',455,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',454,5,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',456,6,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',458,7,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',505,8,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',506,9,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',507,10,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',508,11,1,@insert_date,@insert_user)

INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',494,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',495,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',496,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',492,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',493,5,1,@insert_date,@insert_user)


-- Golden Record

INSERT INTO #cf_batch VALUES(0,'GB GOLDEN RECORD',298,8,1,@insert_date,@insert_user)

--Product Exclusion
INSERT INTO #cf_batch VALUES(0,'Exclusion Weekly Transaction',2681,1,1,@insert_date,@insert_user)

--Retailer to STEP mapping
INSERT INTO #cf_batch VALUES(0,'GB RETAILER_STEP_MAPPING',-2,1,1,@insert_date,@insert_user)

INSERT INTO [psa].[cf_batch] 
select 
	max_batch_id + distinct_match.new_row_id as [batch_id],
	s.[batch_name],
	s.[feed_id],
	s.[order_of_execution],
	s.[active_flag],
	s.[dt_created],
	s.[user_created]
from #cf_batch s
inner join (select max([batch_id]) max_batch_id from [psa].[cf_batch]) qry ON (1=1)
inner join (select [batch_name], row_number() OVER (ORDER BY batch_name) as new_row_id from #cf_batch
			where [batch_name] NOT IN (select distinct [batch_name] from [psa].[cf_batch])
			 group by [batch_name]) distinct_match ON (distinct_match.[batch_name] = s.[batch_name])
WHERE NOT EXISTS (select [batch_name],[order_of_execution] from [psa].[cf_batch] t
					WHERE s.[batch_name] = t.[batch_name]
					AND s.[order_of_execution] = t.[order_of_execution])


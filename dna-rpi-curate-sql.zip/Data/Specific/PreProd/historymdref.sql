﻿IF OBJECT_ID('tempdb..#historymdref') IS NOT NULL
    DROP TABLE #historymdref

CREATE TABLE #historymdref
(
	[assetid] [int] NOT NULL,
	[assetname] [nvarchar](100) NULL,
	[assettypeid] [int] NOT NULL,
	[feedid] [int] NOT NULL,
	[feeddescription] [nvarchar](200) NULL,
	[sourcesystemid] [int] NOT NULL,
	[lovkey] [nvarchar](50) NULL,
	[LOVName] [nvarchar](50) NULL,
	[bucket_id] [int] NULL
)

GO

insert into #historymdref VALUES(8541,'SVOCCC_CONSENT_TYPE_MST_03.csv',6,603,'SVoC Customer consent type - One Off initial Load',30,'ABACUS','Abacus',1)
insert into #historymdref VALUES(10451,'SVOCCC_CUSTOMER_MST_99.csv',6,554,'SVoC Customer data - One Off initial Load',30,'ABACUS','Abacus',2)
insert into #historymdref VALUES(10452,'SVOCCC_CUSTOMER_ENTITY_LNK_99.csv',6,555,'SVoC Customer entity link - One Off initial Load',30,'ABACUS','Abacus',3)
insert into #historymdref VALUES(12716,'SVOCCC_CUSTOMER_ADDRESS_9912.csv',6,559,'SVoC Customer address - One Off initial Load',30,'ABACUS','Abacus',4)
insert into #historymdref VALUES(10453,'SVOCCC_CUSTOMER_PHONE_99.csv',6,558,'SVoC Customer phone - One Off initial Load',30,'ABACUS','Abacus',5)
insert into #historymdref VALUES(8512,'SVOCCC_CUSTOMER_EMAIL_0.csv',6,563,'SVoC customer email - One Off initial Load',30,'ABACUS','Abacus',6)
insert into #historymdref VALUES(10455,'SVOCCC_CUSTOMER_SOCIAL_MEDIA_99.csv',6,567,'SVoC Customer social media - One Off initial Load',30,'ABACUS','Abacus',7)
insert into #historymdref VALUES(10454,'SVOCCC_CUSTOMER_IDENTIFIER_99.csv',6,566,'SVoC Customer identifier - One Off initial Load',30,'ABACUS','Abacus',8)
insert into #historymdref VALUES(10457,'SVOCCC_CUSTOMER_CONSENT_99.csv',6,572,'SVoC Customer consent - One Off initial Load',30,'ABACUS','Abacus',9)
insert into #historymdref VALUES(10456,'SVOCCC_CUSTOMER_CONSENT_ENTITY_LNK_99.csv',6,570,'SVoC Customer consent entity link - One Off initial Load',30,'ABACUS','Abacus',10)
insert into #historymdref VALUES(10435,'AW_CUST_CHILD_99.csv',6,528,'Boots UK Advantage Card customer child  - history - One Off initial Load',30,'ABACUS','Abacus',11)
insert into #historymdref VALUES(10440,'AW_CUST_CLUBS_99.csv',6,529,'Boots UK Advantage Card customer clubs - history- One Off initial Load',30,'ABACUS','Abacus',12)
insert into #historymdref VALUES(5397,'AW_CUST_INFO_01.csv',6,530,'Boots UK Advantage Card customers - history - One Off initial Load',30,'ABACUS','Abacus',13)
insert into #historymdref VALUES(8472,'AW_CUST_INFO_02.csv',6,530,'Boots UK Advantage Card customers - history - One Off initial Load',30,'ABACUS','Abacus',13)
insert into #historymdref VALUES(10460,'AW_MEMBER_ACTIVITY_111.csv',6,527,'Boots UK Advantage Card membership activity - history - One Off initial Load',30,'ABACUS','Abacus',14)
insert into #historymdref VALUES(10442,'AW_MEMBERSHIP_POINTS_99.csv',6,526,'Boots UK Advantage Card membership points - history - One Off initial Load',30,'ABACUS','Abacus',15)
insert into #historymdref VALUES(10441,'AW_POINT_TRANSACTION_99.csv',6,525,'Boots UK Advantage Card transactions - history - One Off initial Load',30,'ABACUS','Abacus',16)
insert into #historymdref VALUES(13298,'AW_POINT_TRANSACTION_004.csv',6,525,'Boots UK Advantage Card transactions - history - One Off initial Load',30,'ABACUS','Abacus',16)
insert into #historymdref VALUES(10458,'AW_MEMBERSHIP_CARD_99.csv',6,514,'Boots UK Advantage Card membership card - history - One Off initial Load',30,'ABACUS','Abacus',17)

INSERT INTO psa.historymdref
SELECT  * FROM #historymdref
WHERE assetid NOT IN (SELECT DISTINCT assetid FROM psa.historymdref)
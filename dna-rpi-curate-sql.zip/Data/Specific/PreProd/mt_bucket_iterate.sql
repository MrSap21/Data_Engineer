﻿IF OBJECT_ID('tempdb..#mt_bucket_iterate') IS NOT NULL
    DROP TABLE #mt_bucket_iterate
	
	CREATE TABLE #mt_bucket_iterate
(
	[bucket_id] [int] NOT NULL,
	[seq_num] [int] NOT NULL,
	[egress_flag] [char](1) NULL
)
insert into #mt_bucket_iterate VALUES(2,1,'N')
insert into #mt_bucket_iterate VALUES(4,2,'N')
insert into #mt_bucket_iterate VALUES(5,3,'N')
insert into #mt_bucket_iterate VALUES(7,4,'N')
insert into #mt_bucket_iterate VALUES(6,5,'N')
insert into #mt_bucket_iterate VALUES(3,6,'N')
insert into #mt_bucket_iterate VALUES(9,7,'N')
insert into #mt_bucket_iterate VALUES(10,8,'N')
insert into #mt_bucket_iterate VALUES(1,9,'N')
insert into #mt_bucket_iterate VALUES(13,10,'N')
insert into #mt_bucket_iterate VALUES(12,11,'N')
insert into #mt_bucket_iterate VALUES(17,12,'N')
insert into #mt_bucket_iterate VALUES(15,13,'N')
insert into #mt_bucket_iterate VALUES(14,14,'N')
insert into #mt_bucket_iterate VALUES(16,15,'N')

INSERT INTO psa.mt_bucket_iterate
SELECT  * FROM #mt_bucket_iterate
WHERE bucket_id NOT IN (SELECT DISTINCT bucket_id FROM psa.mt_bucket_iterate)
﻿IF OBJECT_ID('tempdb..#LEIT_LEXDH_LE_Config') IS NOT NULL
    DROP TABLE #LEIT_LEXDH_LE_Config

CREATE TABLE #LEIT_LEXDH_LE_Config
(
  [param_name] [nvarchar](100) NULL,
	[param_value] [nvarchar](500) NULL,
	[param_type] [nvarchar](20) NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO

INSERT INTO #LEIT_LEXDH_LE_Config
select 'LEIT_LEX_SAGE_BinItem','LEIT/LEXDH/LE_Bin_Item_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_BomItemType','LEIT/LEXDH/LE_Bom_Item_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_CBAccount','LEIT/LEXDH/LE_CB_Account_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_CBAccountContact','LEIT/LEXDH/LE_CB_Account_Contact_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_DocumentPrintStatus','LEIT/LEXDH/LE_Document_Print_Status_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_DocumentStatus','LEIT/LEXDH/LE_Document_Status_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_LandedCostsType','LEIT/LEXDH/LE_Landed_Costs_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_mod_NLPostedNominalTran','LEIT/LEXDH/LE_NL_Posted_Nominal_Transaction_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_mod_PLPostedSupplierTran','LEIT/LEXDH/LE_PL_Posted_Supplier_Transaction_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_mod_PLSupplierAccount','LEIT/LEXDH/LE_PL_Supplier_Account_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_mod_PLSupplierContactValue','LEIT/LEXDH/LE_PL_Supplier_Contact_Value_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_mod_PLSupplierContact','LEIT/LEXDH/LE_PL_Supplier_Contact_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_mod_PLSupplierLocation','LEIT/LEXDH/LE_PL_Supplier_Location_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_NLAccountNumberCostCentre','LEIT/LEXDH/LE_NL_Account_Number_Cost_Centre_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_NLAccountNumber','LEIT/LEXDH/LE_NL_Account_Number_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_NLAccountReportCategory','LEIT/LEXDH/LE_NL_Account_Report_Category_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_NLAccountReportType','LEIT/LEXDH/LE_NL_Account_Report_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_NLAccountType','LEIT/LEXDH/LE_NL_Account_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_NLCostCentre','LEIT/LEXDH/LE_NL_Cost_Centre_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_NLDepartment','LEIT/LEXDH/LE_NL_Department_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_NLNominalAccount','LEIT/LEXDH/LE_NL_Nominal_Account_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_NLNominalTranType','LEIT/LEXDH/LE_NL_Nominal_Tran_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_OrderReturnLineType','LEIT/LEXDH/LE_Order_Return_Line_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_PLPaymentGroup','LEIT/LEXDH/LE_PL_Payment_Group_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_PLSupplierContactRole','LEIT/LEXDH/LE_PL_Supplier_Contact_Role_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_POPInvoiceCreditLine','LEIT/LEXDH/LE_POP_Invoice_Credit_Line_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_POPInvoiceCreditType','LEIT/LEXDH/LE_POP_Invoice_Credit_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_POPOrderReturnLine','LEIT/LEXDH/LE_POP_Order_Return_Line_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_POPOrderReturnType','LEIT/LEXDH/LE_POP_Order_Return_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_POPOrderReturn','LEIT/LEXDH/LE_POP_Order_Return_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_POPReceiptReturnLine','LEIT/LEXDH/LE_POP_Receipt_Return_Line_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_POPReceiptReturnType','LEIT/LEXDH/LE_POP_Receipt_Return_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_POPReceiptReturn','LEIT/LEXDH/LE_POP_Receipt_Return_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_ProductGroup','LEIT/LEXDH/LE_Product_Group_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_Salutation','LEIT/LEXDH/LE_Salutation_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SourceAreaType','LEIT/LEXDH/LE_Source_Area_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_StockItem','LEIT/LEXDH/LE_Stock_Item_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_StockItemStatus','LEIT/LEXDH/LE_Stock_Item_Status_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_StockItemType','LEIT/LEXDH/LE_Stock_Item_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSAccountType','LEIT/LEXDH/LE_SYS_Account_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SysContactType','LEIT/LEXDH/LE_Sys_Contact_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSCountryCode','LEIT/LEXDH/LE_SYS_Country_Code_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSCreditBureau','LEIT/LEXDH/LE_SYS_Credit_Bureau_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSCreditPosition','LEIT/LEXDH/LE_SYS_Credit_Position_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSCurrencyISOCode','LEIT/LEXDH/LE_SYS_Currency_ISO_Code_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSCurrency','LEIT/LEXDH/LE_SYS_Currency_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSExchangeRateType','LEIT/LEXDH/LE_SYS_Exchange_Rate_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSModule','LEIT/LEXDH/LE_SYS_Module_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSPaymentTermsBasis','LEIT/LEXDH/LE_SYS_Payment_Terms_Basis_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SysTaxECTerm','LEIT/LEXDH/LE_Sys_Tax_EC_Term_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SysTaxRate','LEIT/LEXDH/LE_Sys_Tax_Rate_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSTraderContactRole','LEIT/LEXDH/LE_SYS_Trader_Contact_Role_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_SYSTraderTranType','LEIT/LEXDH/LE_SYS_Trader_Tran_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_TraceableType','LEIT/LEXDH/LE_Traceable_Type_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'LEIT_LEX_SAGE_Warehouse','LEIT/LEXDH/LE_Warehouse_LEXDH_Incr/Incremental/','Feed',CURRENT_TIMESTAMP,'Y' union
select 'UTF8RequiredFeeds','LEIT_LEX_SAGE_CBAccount|LEIT_LEX_SAGE_mod_PLSupplierAccount|LEIT_LEX_SAGE_NLNominalAccount|LEIT_LEX_SAGE_POPOrderReturnLine|LEIT_LEX_SAGE_Warehouse','Feed',CURRENT_TIMESTAMP,'Y' union
select 'InputFilePath','LEIT/zip/','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'Retailer','LizEarleUnZip','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'InputStorageContainerName','lelanding','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'FeedPropertyFileName','lizearle_feed_prop.txt','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'ArchiveFilePath','archive/zip/','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'WebHookPython','https://06b2ab06-8fa5-4e2a-8939-f7ae10eed2c2.webhook.ne.azure-automation.net/webhooks?token=NLfjYEnMGYxOlIZ7rX8yJiSP9bZlfA5p0qrF4uYZnd8%3d','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'IsUTF8ConversionRequired','1','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'StorageAccountName','aznednaqasa01','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'OutputStorageContainerName','landing','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'EgressPipelineSubscriptions','61dcae01-f261-48b1-ad36-9f3218969f72','EgressADFParams',CURRENT_TIMESTAMP,'Y' union
select 'EgressResourceGroups','prod-dna-qa-northeurope-main01','EgressADFParams',CURRENT_TIMESTAMP,'Y' union
select 'EgressFactoryName','prod-dna-qa-adf-01','EgressADFParams',CURRENT_TIMESTAMP,'Y' union
select 'EgressGenerateFactsPipelineName','DataGenerateFacts','EgressADFParams',CURRENT_TIMESTAMP,'Y' union
select 'EgressDataEgressExecutePipelineName','DataEgressExecute','EgressADFParams',CURRENT_TIMESTAMP,'Y' union
select 'EgressPipelineResourceUrl','https://management.azure.com/','EgressADFParams',CURRENT_TIMESTAMP,'Y' union
select 'EgressBodyPdtExtractStart','liz_earle','EgressADFParams',CURRENT_TIMESTAMP,'Y' union
select 'EgressBodyPprojectId','8007','EgressADFParams',CURRENT_TIMESTAMP,'Y' union 
select 'EgressBodyPoverallQueryTimeout','480','EgressADFParams',CURRENT_TIMESTAMP,'Y' union 
select 'EgressBodyPAssetStatusId','24032','EgressADFParams',CURRENT_TIMESTAMP,'Y'   union
select 'EgressWaitingTimeInSeconds','10','EgressADFParams',CURRENT_TIMESTAMP,'Y' union
select 'CollectionArchiveFilePath','ARIBA/archive','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'CollectionStorageAccountName','dnaqacollectionsa01','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'CollectionFilePath','ARIBA/ARIBA/PurchaseDetails','ADFParams',CURRENT_TIMESTAMP,'Y' union
select 'CollectionContainerName','collection','ADFParams',CURRENT_TIMESTAMP,'Y'


INSERT INTO psa.LEIT_LEXDH_LE_Config
SELECT  * FROM #LEIT_LEXDH_LE_Config
WHERE param_name NOT IN (SELECT DISTINCT param_name FROM psa.LEIT_LEXDH_LE_Config)
﻿IF OBJECT_ID('tempdb..#mt_bucket_iterate') IS NOT NULL
    DROP TABLE #mt_bucket_iterate
	
	CREATE TABLE #mt_bucket_iterate
(
	[bucket_id] [int] NOT NULL,
	[seq_num] [int] NOT NULL,
	[egress_flag] [char](1) NULL
)
insert into #mt_bucket_iterate VALUES(43,1,'N')
insert into #mt_bucket_iterate VALUES(45,2,'N')
insert into #mt_bucket_iterate VALUES(39,3,'N')
insert into #mt_bucket_iterate VALUES(33,4,'N')
insert into #mt_bucket_iterate VALUES(35,5,'N')
insert into #mt_bucket_iterate VALUES(32,6,'N')
insert into #mt_bucket_iterate VALUES(42,7,'N')
insert into #mt_bucket_iterate VALUES(34,8,'N')
insert into #mt_bucket_iterate VALUES(40,9,'N')
insert into #mt_bucket_iterate VALUES(41,10,'N')
insert into #mt_bucket_iterate VALUES(44,11,'N')
insert into #mt_bucket_iterate VALUES(23,12,'N')
insert into #mt_bucket_iterate VALUES(22,13,'N')
insert into #mt_bucket_iterate VALUES(28,14,'N')
insert into #mt_bucket_iterate VALUES(25,15,'N')
insert into #mt_bucket_iterate VALUES(24,16,'N')
insert into #mt_bucket_iterate VALUES(26,17,'N')
insert into #mt_bucket_iterate VALUES(27,18,'N')

INSERT INTO psa.mt_bucket_iterate
SELECT  * FROM #mt_bucket_iterate
WHERE bucket_id NOT IN (SELECT DISTINCT bucket_id FROM psa.mt_bucket_iterate)

IF OBJECT_ID('tempdb..#cf_feed_configuration') IS NOT NULL
  DROP TABLE #cf_feed_configuration

CREATE TABLE #cf_feed_configuration
(
	[feed_id] [int] NOT NULL,
	[psa_table_name] [nchar](80) NULL,
	[delta_capture_sp] [int] NOT NULL,
	[curation_sp] [int] NOT NULL,
	[record_filter_id] [int] NULL,
	[depends_on] [nchar](25) NULL,
	[null_conv_char] [nchar](5) NULL,
	[active_flag] [smallint] NOT NULL,
	[dt_created] [smalldatetime] NULL,
	[user_created] [nchar](100) NULL
)

/*

Enter Your FEED_CONFIGURATION below.  If it doens't exist it'll insert it into the table.

*/

/* QA Configuration */                

DELETE FROM [psa].[cf_feed_configuration] WHERE [feed_id] IN (190,191)

/* QA Configuration */                

INSERT INTO #cf_feed_configuration SELECT 187,'RPIDNA_GBSAP_MARA',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 188,'RPIDNA_GBSAP_MAKT',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 189,'RPIDNA_GBSAP_T023T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
--INSERT INTO #cf_feed_configuration SELECT 190,'RPIDNA_GBSAP_T179T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 190,'RPIDNA_GBSAP_T179T',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_sap_product' 
INSERT INTO #cf_feed_configuration SELECT 191,'RPIDNA_GBSAP_MARC',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gbmr_golden_product' 

INSERT INTO #cf_feed_configuration SELECT 192,'RPIDNA_GBSAP_VBRK',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 193,'RPIDNA_GBSAP_VBRP',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_sap_transaction' 
INSERT INTO #cf_feed_configuration SELECT 185,'SAPCOE_BUKSAP_BUKSAPArticle',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_buk_sap_product' 
INSERT INTO #cf_feed_configuration SELECT 200,'LEIT_LEDATAHUB_SalesProduct'  ,a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_le_product'
INSERT INTO #cf_feed_configuration SELECT 197,'GBMDT_GBFINEXCEL_GBMDTProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_sap_mdm_product' 


INSERT INTO #cf_feed_configuration SELECT 196,'GBFIN_GBFINEXCEL_GBFINRetailerCalendar',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_calendar_master' 
INSERT INTO #cf_feed_configuration SELECT 2256,'GBFIN_GBFINEXCEL_GB_Calendar_information_GBFINEXCEL_incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBFINEXCEL_GB_Calendar_information_GBFINEXCEL_incr' 

--WAG product
INSERT INTO #cf_feed_configuration SELECT 204,'RPIDNA_DNAPSAV1_WalgreensProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensProduct' 
INSERT INTO #cf_feed_configuration SELECT 201,'WAGIT_WAGEDW_WalgreensProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensProduct' 

--WAG store
INSERT INTO #cf_feed_configuration SELECT 218,'RPIDNA_DNAPSAV1_WalgreensStore',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensStore' 
INSERT INTO #cf_feed_configuration SELECT 199,'WAGIT_WAGEDW_WalgreensStore',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensStore' 

--Walgreens
INSERT INTO #cf_feed_configuration SELECT 236,'RPIDNA_DNAPSAV1_WalgreensBasket',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensBasket' 
INSERT INTO #cf_feed_configuration SELECT 247,'WAGIT_WAGEDW_WalgreensBasket',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensBasket' 
INSERT INTO #cf_feed_configuration SELECT 235,'RPIDNA_DNAPSAV1_WalgreensEBasket',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensEBasket' 
INSERT INTO #cf_feed_configuration SELECT 248,'WAGIT_WAGEDW_WalgreensEBasket',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensEBasket' 
INSERT INTO #cf_feed_configuration SELECT 237,'RPIDNA_DNAPSAV1_WalgreensTransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensTransaction' 
INSERT INTO #cf_feed_configuration SELECT 250,'WAGIT_WAGEDW_WalgreensTransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensTransaction' 
INSERT INTO #cf_feed_configuration SELECT 238,'RPIDNA_DNAPSAV1_WalgreensETransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensETransaction' 
INSERT INTO #cf_feed_configuration SELECT 249,'WAGIT_WAGEDW_WalgreensETransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensETransaction' 
INSERT INTO #cf_feed_configuration SELECT 219,'RPIDNA_DNAPSAV1_WalgreensTransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensTransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 246,'WAGIT_WAGEDW_WalgreensTransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensTransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 239,'RPIDNA_DNAPSAV1_WalgreensETransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensETransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 234,'WAGIT_WAGEDW_WalgreensETransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensETransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 2257,'DATALYNX_WAGX_GB_Daily_Walgreens_Sales_from_RSI_WAGX',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_DATALYNX_WAGX_GB_Daily_Walgreens_Sales_from_RSI_WAGX' 

--Indonesia
INSERT INTO #cf_feed_configuration SELECT 2275,'IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL' 

--Opticians
INSERT INTO #cf_feed_configuration SELECT 495,'SAPCOE_BTCSAPECC_BUK_Opticians_Product_Master_Data_SAP_ECC',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_optician'
INSERT INTO #cf_feed_configuration SELECT 494,'BOPSAPPMAN_BUKOPTMI_BUK_Opticians_Transaction_Sales_Price_Data_Opticians_MI_Incr',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_optician'

--Dermstore
INSERT INTO #cf_feed_configuration SELECT 212,'RPIDNA_DNAPSAV1_DermstoreRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_DermstoreRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 228,'TGTDS_TGTDSEXCEL_DermstoreRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TGTDS_TGTDSEXCEL_DermstoreRetailSales' 

--Skinstore
INSERT INTO #cf_feed_configuration SELECT 210,'RPIDNA_DNAPSAV1_SKINSTORE_No7_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SKINSTORE_No7_WeeklyRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 226,'SKNST_SKNSTEXCEL_SKINSTORE_No7_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SKNST_SKNSTEXCEL_SKINSTORE_No7_WeeklyRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 209,'RPIDNA_DNAPSAV1_SKINSTORE_SG_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SKINSTORE_SG_WeeklyRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 227,'SKNST_SKNSTEXCEL_SKINSTORE_SG_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SKNST_SKNSTEXCEL_SKINSTORE_SG_WeeklyRetailSales' 

--SDM
INSERT INTO #cf_feed_configuration SELECT 208,'RPIDNA_DNAPSAV1_SDMSGESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMSGESales' 
INSERT INTO #cf_feed_configuration SELECT 205,'RPIDNA_DNAPSAV1_SDMSGStoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMSGStoreSales'     
INSERT INTO #cf_feed_configuration SELECT 207,'RPIDNA_DNAPSAV1_SDMNo7StoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMNo7StoreSales' 
INSERT INTO #cf_feed_configuration SELECT 206,'RPIDNA_DNAPSAV1_SDMNo7ESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMNo7ESales' 
INSERT INTO #cf_feed_configuration SELECT 220,'SDM_SDMEXCEL_SDMNo7ESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMNo7ESales' 
INSERT INTO #cf_feed_configuration SELECT 225,'SDM_SDMEXCEL_SDMSGStoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMSGStoreSales'     
INSERT INTO #cf_feed_configuration SELECT 223,'SDM_SDMEXCEL_SDMNo7StoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMNo7StoreSales' 
INSERT INTO #cf_feed_configuration SELECT 224,'SDM_SDMEXCEL_SDMSGESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMSGESales' 

--TSG
INSERT INTO #cf_feed_configuration SELECT 215,'RPIDNA_DNAPSAV1_TSGAAFES',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TSGAAFES' 
INSERT INTO #cf_feed_configuration SELECT 214,'RPIDNA_DNAPSAV1_TSGMCXNo7',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TSGMCXNo7' 
INSERT INTO #cf_feed_configuration SELECT 213,'RPIDNA_DNAPSAV1_TSGNEXCOM',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TSGNEXCOM' 
INSERT INTO #cf_feed_configuration SELECT 229,'TSG_TSGEXCEL_TSGAAFES',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TSG_TSGEXCEL_TSGAAFES' 
INSERT INTO #cf_feed_configuration SELECT 230,'TSG_TSGEXCEL_TSGMCXNo7',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TSG_TSGEXCEL_TSGMCXNo7' 
INSERT INTO #cf_feed_configuration SELECT 231,'TSG_TSGEXCEL_TSGNEXCOM',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TSG_TSGEXCEL_TSGNEXCOM' 

--Target
INSERT INTO #cf_feed_configuration SELECT 211,'RPIDNA_DNAPSAV1_TargetSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TargetSales' 
INSERT INTO #cf_feed_configuration SELECT 203,'TGT_TGTWP_TargetSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_TGT_TGTWP_TargetSales' 

--ULTA
INSERT INTO #cf_feed_configuration SELECT 216,'RPIDNA_DNAPSAV1_UltaEDI',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_UltaEDI' 
INSERT INTO #cf_feed_configuration SELECT 233,'Ulta_ULTAEXCEL_UltaEDI',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_Ulta_ULTAEXCEL_UltaEDI' 
INSERT INTO #cf_feed_configuration SELECT 217,'RPIDNA_DNAPSAV1_UltaWeb',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_UltaWeb' 
INSERT INTO #cf_feed_configuration SELECT 232,'Ulta_ULTAEXCEL_UltaWeb',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_Ulta_ULTAEXCEL_UltaWeb' 

--CurrenCy Conversion
INSERT INTO #cf_feed_configuration SELECT 251,'GFSD_GFSDEXCEL_GlobalBrandsCurrencyConversionRates',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GFSD_GFSDEXCEL_GlobalBrandsCurrencyConversionRates' 

--GBFINRetailer
INSERT INTO #cf_feed_configuration SELECT 242,'GBFIN_GBFINEXCEL_GBFINRetailer',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBFINEXCEL_GBFINRetailer_party' 

--GBFINStoreMaster
INSERT INTO #cf_feed_configuration SELECT 198,'GBFIN_GBFINEXCEL_GBFINStoreMaster',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBFINEXCEL_GBFINStoreMaster' 

--DA Invoice
INSERT INTO #cf_feed_configuration SELECT 284,'BUKIT_GBEDISTG_DAInvoiceDetails',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_gb_da_inv_transaction_master'

/* SAP Customer Feeds */                

INSERT INTO #cf_feed_configuration SELECT 285,'RPIDNA_GBSAP_SAP_KNB1',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 286,'RPIDNA_GBSAP_SAP_KNA1',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 287,'RPIDNA_GBSAP_SAP_T001',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 288,'RPIDNA_GBSAP_SAP_KNVV',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 289,'RPIDNA_GBSAP_SAP_ADRC',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_customer_master' 
INSERT INTO #cf_feed_configuration SELECT 290,'RPIDNA_GBSAP_SAP_TVKO',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 291,'RPIDNA_GBSAP_SAP_TVKOT',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'

--GB SAP Finance GL
INSERT INTO #cf_feed_configuration SELECT 295,'RPIDNA_GBSAP_SAP_BKPF',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_BKPF'
INSERT INTO #cf_feed_configuration SELECT 296,'RPIDNA_GBSAP_SAP_BSEG',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_BSEG'
INSERT INTO #cf_feed_configuration SELECT 297,'RPIDNA_GBSAP_SAP_SKAT',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_SKAT'
INSERT INTO #cf_feed_configuration SELECT 298,'RPIDNA_GBSAP_SAP_CEPT',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_CEPT'
INSERT INTO #cf_feed_configuration SELECT 299,'RPIDNA_GBSAP_SAP_CE41000_ACCT',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_CE41000_ACCT'

--LE Store
INSERT INTO #cf_feed_configuration SELECT 300,'LEIT_LEXDH_LEIT_LEX_SALES_Store',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_LEIT_LEXDH_LEIT_LEX_SALES_Store'

--GBSAP GL Manual Adjustment
INSERT INTO #cf_feed_configuration SELECT 303,'GBFIN_GBSAP_SAP_Invoice_manual_adjustment',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBSAP_SAP_Invoice_manual_adjustment'

--DA COGS
INSERT INTO #cf_feed_configuration SELECT 301,'RPIDNA_GBSAP_SAP_MKPF',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_da_cogs_document' 
INSERT INTO #cf_feed_configuration SELECT 302,'RPIDNA_GBSAP_SAP_MSEG',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_da_cogs_transaction_master' 

--Baozun Combo
INSERT INTO #cf_feed_configuration SELECT 309,'WBAHK_BZUNEXCEL_BaozunComboSalesHistory',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 352,'WBAHK_BZUNEXCEL_BaozunComboSalesIncremental',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'

--Baozun Sales
INSERT INTO #cf_feed_configuration SELECT 221,'WBAHK_BZUNEXCEL_BaozunSalesHistory',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunSalesHistory' 
INSERT INTO #cf_feed_configuration SELECT 222,'WBAHK_BZUNEXCEL_BaozunSalesIncremental',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunSalesIncremental' 

--LE Sales
INSERT INTO #cf_feed_configuration SELECT 304,'LEIT_LEXDH_LIZ_EARLE_RETAIL_AND_INVOICE_SALES',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_liz_earle_sales_master' 

-- SAP Customer Lookup Tables
INSERT INTO #cf_feed_configuration SELECT 305,'RPIDNA_GBSAP_SAP_T151T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 306,'RPIDNA_GBSAP_SAP_TVV1T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 307,'RPIDNA_GBSAP_SAP_TVV2T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 308,'RPIDNA_GBSAP_SAP_TVV3T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'

--TeamCenter Product
INSERT INTO #cf_feed_configuration SELECT 312,'BUKIT_GBTC_Teamcenter',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_BUKIT_GBTC_Teamcenter'

--GB S&OP Kohls
INSERT INTO #cf_feed_configuration SELECT 311,'Kohls_KSSWP_Kohls_weekly_sales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_KOHLS_KSSWP_KOHLS_WEEKLY_SALES' 

--GB S&OP Walmart Retail Sales 
INSERT INTO #cf_feed_configuration SELECT 316,'Walmart_WMTWP_Walmart_retail_sales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_WALMART_WMTWP_WALMART_RETAIL_SALES' 

--GB S&OP Walmart Online Sales 
INSERT INTO #cf_feed_configuration SELECT 317,'Walmart_WMTWP_Walmart_online_sales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_WALMART_WMTWP_WALMART_ONLINE_SALES' 

--GB S&OP Alshaya Weekly sales inc
INSERT INTO #cf_feed_configuration SELECT 507,'MHAC_MHACX_Alshaya_Weekly_sales_inc',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_MHAC_MHACX_Alshaya_Weekly_sales_inc' 

--GB S&OP APH Weekly sales inc
INSERT INTO #cf_feed_configuration SELECT 509,'APH_APHX_APH_Weekly_sales_inc',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_APH_APHX_APH_Weekly_sales_inc' 


--International Retail Sales
INSERT INTO #cf_feed_configuration SELECT 324,'RPIDNA_DNAPSAV1_FAITFAPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 322,'FAIT_BIRFAEXCEL_FAITFAPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 319,'FAIT_BIRFAEXCEL_FAITFAPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 323,'RPIDNA_DNAPSAV1_FAITFAPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 325,'BTHIT_BIRTHEXCEL_BIRTHITTPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 327,'BTHIT_BIRTHEXCEL_BIRTHITTPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 328,'RPIDNA_DNAPSAV1_BIRTHITTPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 329,'RPIDNA_DNAPSAV1_BIRTHITTPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 331,'BNEIT_BIRNLEXCEL_BIRNEITNEPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 333,'BNEIT_BIRNLEXCEL_BIRNEITNEPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 334,'RPIDNA_DNAPSAV1_BIRNEITNEPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 335,'RPIDNA_DNAPSAV1_BIRNEITNEPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 337,'FBIT_BIRFBEXCEL_BIRMEXITMEXPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 339,'FBIT_BIRFBEXCEL_BIRMEXITMEXPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 340,'RPIDNA_DNAPSAV1_BIRMEXITMEXPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 341,'RPIDNA_DNAPSAV1_BIRMEXITMEXPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 343,'BNIT_BIRNOEXCEL_BIRNITBIRNPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 345,'BNIT_BIRNOEXCEL_BIRNITBIRNPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 347,'BNIT_BIRNOEXCEL_BIRNITBIRNWSWholesaleDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 348,'RPIDNA_DNAPSAV1_BIRNITBIRNPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 349,'RPIDNA_DNAPSAV1_BIRNITBIRNPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 350,'RPIDNA_DNAPSAV1_BIRNITBIRNWSWholesaleDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'

--Mecca Sales
INSERT INTO #cf_feed_configuration SELECT 351,'Mecca_MECCAIT_Mecca_Monthly_sales_inc',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_mecca_transaction_master' 

-- Liz Earle Migration
INSERT INTO #cf_feed_configuration SELECT 430,'LEIT_LEXDH_LE_Bin_Item_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 431,'LEIT_LEXDH_LE_Bom_Item_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 432,'LEIT_LEXDH_LE_CB_Account_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 433,'LEIT_LEXDH_LE_CB_Account_Contact_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 434,'LEIT_LEXDH_LE_Document_Print_Status_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 435,'LEIT_LEXDH_LE_Document_Status_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 436,'LEIT_LEXDH_LE_Landed_Costs_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 437,'LEIT_LEXDH_LE_NL_Posted_Nominal_Transaction_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 438,'LEIT_LEXDH_LE_PL_Posted_Supplier_Transaction_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 439,'LEIT_LEXDH_LE_PL_Supplier_Account_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 440,'LEIT_LEXDH_LE_PL_Supplier_Contact_Value_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 441,'LEIT_LEXDH_LE_PL_Supplier_Contact_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 442,'LEIT_LEXDH_LE_PL_Supplier_Location_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 443,'LEIT_LEXDH_LE_NL_Account_Number_Cost_Centre_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 444,'LEIT_LEXDH_LE_NL_Account_Number_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 445,'LEIT_LEXDH_LE_NL_Account_Report_Category_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 446,'LEIT_LEXDH_LE_NL_Account_Report_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 447,'LEIT_LEXDH_LE_NL_Account_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 448,'LEIT_LEXDH_LE_NL_Cost_Centre_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 449,'LEIT_LEXDH_LE_NL_Department_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 450,'LEIT_LEXDH_LE_NL_Nominal_Account_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 451,'LEIT_LEXDH_LE_NL_Nominal_Tran_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 452,'LEIT_LEXDH_LE_Order_Return_Line_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 453,'LEIT_LEXDH_LE_PL_Payment_Group_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 454,'LEIT_LEXDH_LE_PL_Supplier_Contact_Role_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 455,'LEIT_LEXDH_LE_POP_Invoice_Credit_Line_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 456,'LEIT_LEXDH_LE_POP_Invoice_Credit_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 457,'LEIT_LEXDH_LE_POP_Order_Return_Line_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 458,'LEIT_LEXDH_LE_POP_Order_Return_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 472,'LEIT_LEXDH_LE_POP_Order_Return_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 473,'LEIT_LEXDH_LE_POP_Receipt_Return_Line_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 474,'LEIT_LEXDH_LE_POP_Receipt_Return_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 476,'LEIT_LEXDH_LE_POP_Receipt_Return_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 475,'LEIT_LEXDH_LE_Product_Group_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 477,'LEIT_LEXDH_LE_Salutation_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 478,'LEIT_LEXDH_LE_Source_Area_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 479,'LEIT_LEXDH_LE_Stock_Item_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 480,'LEIT_LEXDH_LE_Stock_Item_Status_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 459,'LEIT_LEXDH_LE_SYS_Credit_Bureau_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 460,'LEIT_LEXDH_LE_SYS_Credit_Position_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 461,'LEIT_LEXDH_LE_SYS_Currency_ISO_Code_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 462,'LEIT_LEXDH_LE_SYS_Currency_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 463,'LEIT_LEXDH_LE_SYS_Exchange_Rate_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 464,'LEIT_LEXDH_LE_SYS_Module_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 465,'LEIT_LEXDH_LE_SYS_Payment_Terms_Basis_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 466,'LEIT_LEXDH_LE_Sys_Tax_EC_Term_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 467,'LEIT_LEXDH_LE_Sys_Tax_Rate_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 468,'LEIT_LEXDH_LE_SYS_Trader_Contact_Role_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 469,'LEIT_LEXDH_LE_SYS_Trader_Tran_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 470,'LEIT_LEXDH_LE_Traceable_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 471,'LEIT_LEXDH_LE_Warehouse_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 481,'LEIT_LEXDH_LE_Stock_Item_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 482,'LEIT_LEXDH_LE_SYS_Account_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 483,'LEIT_LEXDH_LE_Sys_Contact_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 484,'LEIT_LEXDH_LE_SYS_Country_Code_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'

-- GBMR UI
INSERT INTO #cf_feed_configuration SELECT 485,'RPIDNA_DNAUIGBMRPRD_GB_GBMR_Product_Updates_GBMRUI_inc',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAUIGBMRPRD_GB_GBMR_Product_Updates_GBMRUI'

--BUK TransactionLineAnon and TransactionLineCard OneTimeUpdateActivity
INSERT INTO #cf_feed_configuration SELECT 488,'BUKIT_ABACUS_BUK_Transaction_line_anon_Abacus_hist',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_BUKIT_ABACUS_BUK_Transaction_line_anon_Abacus_hist'
INSERT INTO #cf_feed_configuration SELECT 491,'BUKIT_ABACUS_BUK_Transaction_line_card_Abacus_hist',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_BUKIT_ABACUS_BUK_Transaction_line_card_Abacus_hist'

--Budget and Forecast Weekly
INSERT INTO #cf_feed_configuration SELECT 498,'GBFIN_GFSDEXCEL_GB_Weekly_Budget_and_Forecast_GBFINEXCEL_Incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_budgetforecast_weekly_main'

--Budget and Forecast Monthly
INSERT INTO #cf_feed_configuration SELECT 508,'GBFIN_GFSDEXCEL_GB_Monthly_Budget_and_Forecast_GBFINEXCEL_Incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_budgetforecast_Monthly_main'

--Martech Wave 2  CRM History 
INSERT INTO #cf_feed_configuration SELECT 371,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_child',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 373,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_clubs',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 375,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 377,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_activity',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 396,'BUKIT_ABACUS_BUK_SAPCRM_Advantage_Card_membership_card',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 379,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_points',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 381,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'


--Martech Wave 2  SVOC History 
INSERT INTO #cf_feed_configuration SELECT 422,'BUKIT_BTCSVOC_BUK_SVOC_Customer_address',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 427,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 428,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 421,'BUKIT_BTCSVOC_BUK_SVOC_Customer_data',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 424,'BUKIT_BTCSVOC_BUK_SVOC_Customer_email',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 423,'BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 426,'BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 388,'BUKIT_BTCSVOC_BUK_SVOC_Customer_phone',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 425,'BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 419,'BUKIT_ABACUS_BUK_SVOC_Customer_consent_type',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'


--Martech Wave 2 CRM Incremental  
INSERT INTO #cf_feed_configuration SELECT 359,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_child',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 357,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_clubs',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 355,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 363,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_points',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 361,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_activity',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_CRMTrans'
INSERT INTO #cf_feed_configuration SELECT 365,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_CRMTrans'
INSERT INTO #cf_feed_configuration SELECT 367,'SAPCOE_SAPCRM_BUK_SAPCRM_Customer_Anonymisation',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 369,'SAPCOE_SAPCRM_BUK_SAPCRM_Customer_Status_Change',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'


--Martech Wave 2 SVOC Incremental   
INSERT INTO #cf_feed_configuration SELECT 384,'BUKIT_BTCSVOC_BUK_SVOC_Customer_address',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 411,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 414,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_SvocEntityLink'
INSERT INTO #cf_feed_configuration SELECT 399,'BUKIT_BTCSVOC_BUK_SVOC_Customer_data',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 417,'BUKIT_BTCSVOC_BUK_SVOC_Customer_delete',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 392,'BUKIT_BTCSVOC_BUK_SVOC_Customer_email',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 402,'BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_SvocEntityLink'
INSERT INTO #cf_feed_configuration SELECT 408,'BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 395,'BUKIT_BTCSVOC_BUK_SVOC_Customer_phone',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 405,'BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'

-- DPI
INSERT INTO #cf_feed_configuration SELECT 510,'BootsUK_Pharmacy_Customer_Info_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 511,'BootsUK_Pharmacy_Order_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 512,'BootsUK_Pharmacy_Customer_Relationship_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 513,'BootsUK_Pharmacy_Order_Items_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 514,'BootsUK_Pharmacy_Order_Transition_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 515,'BootsUK_Pharmacy_Order_Edits_Removal_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 516,'BootsUK_Pharmacy_Order_Consent_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 517,'BootsUK_Pharmacy_Order_TaxedPrice_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'

--Asia MI non PII feeds
INSERT INTO #cf_feed_configuration SELECT 581,'WBAHK_DIM_BIZ_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 684,'WBAHK_DIM_CNTRYGRP_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 584,'WBAHK_DIM_CUSTOMER_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 587,'WBAHK_DIM_DATE_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 590,'WBAHK_DIM_ForecastGroup_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 593,'WBAHK_Walgreens_HS_Code_List_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 605,'WBAHK_DIM_METRIC_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 619,'WBAHK_DIM_METRIC_GRP_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 624,'WBAHK_DIM_Opstudy_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 627,'WBAHK_DIM_PORTToCNTRY_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 632,'WBAHK_DIM_SAFETYRATE_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 636,'WBAHK_DIM_SEGToCustCode_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 640,'WBAHK_DIM_TEAM_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 642,'WBAHK_DIM_VENDOR_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 644,'WBAHK_DIM_VENDOR_GROUP_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 657,'WBAHK_DIM_VENDOR_INSPECTIONRATE_ROLLING_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 671,'WBAHK_DIM_VENDOR_MOQOAT_UK_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 666,'WBAHK_DIM_VENDOR_SERVICELVL_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 661,'WBAHK_DIM_VENDOR_SSIS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 656,'WBAHK_DIM_VENDOR9BOXSUMMARY_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 652,'WBAHK_DIM_VENDOROPS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 601,'WBAHK_EthicalDetail_ETL_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 609,'WBAHK_Dashboard_Metric_Grouping_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 613,'WBAHK_Dashboard_Metric_KPI_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 620,'WBAHK_Dashboard_Metric_Parameter_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 623,'WBAHK_temp_fte_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 629,'WBAHK_V_BRS_PARTY_INFOCARD_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 635,'WBAHK_DIM_ADR7_PAYTERMS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 639,'WBAHK_DIM_COLOR_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 647,'WBAHK_DIM_HR_Datatype_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 651,'WBAHK_DIM_HR_TEAM_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 654,'WBAHK_DIM_MARGIN_BREAKDOWN_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 662,'WBAHK_DIM_VENDOR_1506_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 665,'WBAHK_DIM_VENDOR_DEALS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 668,'WBAHK_DIM_VENDOR_MOQOAT_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 670,'WBAHK_DIM_VENDOR9BOX_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 674,'WBAHK_Fact_HR_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 677,'WBAHK_PARTY_REL_TIER_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 679,'WBAHK_TEMP_9BOXSummary_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 681,'WBAHK_TEMP_BRANDMAP_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 683,'WBAHK_TEMP_EthicalSummary_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'

--Asia MI PII Feeds

INSERT INTO #cf_feed_configuration SELECT 599,'WBAHK_ADR7_VENDORFACTORY_4FLAGS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 580,'WBAHK_DIM_ForecastGroup_v2_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 648,'WBAHK_DIM_ITEM_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 604,'WBAHK_DIM_VENDORINFO_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 607,'WBAHK_FACT_WBAQUOTE_GSO_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 591,'WBAHK_FactMIDATA_OPEN_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 626,'WBAHK_FactMIDATA_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 585,'WBAHK_FactMIDATA_LIMA_OPEN_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 611,'WBAHK_FactMIDATA_GSOOPEN_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 615,'WBAHK_TEMP_FINANCECHECK_UK_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 595,'WBAHK_V_BRS_PARTY_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 597,'WBAHK_V_WBAPARTY_FTY_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 579,'WBAHK_Walgreens_Open_Purchase_Order_Detail_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'

--Product Exclusion
INSERT INTO #cf_feed_configuration SELECT 2300,'GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_step_product_exclusion' 

--Retailer to STEP mapping
INSERT INTO #cf_feed_configuration SELECT -2,'',0,sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_insertretailertostep_productrelationship'

/* End of Configuration */


INSERT INTO [psa].[cf_feed_configuration] 
select 
	[feed_id],
	[psa_table_name],
	[delta_capture_sp],
	[curation_sp],
	[record_filter_id],
	[depends_on],
	[null_conv_char],
	[active_flag],
	[dt_created],
	[user_created]
from #cf_feed_configuration
WHERE [feed_id] NOT IN (select distinct [feed_id] from [psa].[cf_feed_configuration])

UPDATE [psa].[cf_feed_configuration] 
SET	[psa_table_name]		= cf.[psa_table_name]		,
	[delta_capture_sp]		= cf.[delta_capture_sp]	,
	[curation_sp]			= cf.[curation_sp]			,
	[record_filter_id]		= cf.[record_filter_id]	,
	[depends_on]			= cf.[depends_on]			,
	[null_conv_char]		= cf.[null_conv_char]		,
	[active_flag]			= cf.[active_flag]		
FROM #cf_feed_configuration cf
WHERE 
[cf_feed_configuration].feed_id = cf.feed_id
AND
(
	cf.[psa_table_name]		<> [cf_feed_configuration].[psa_table_name]		OR
	cf.[delta_capture_sp]	<> [cf_feed_configuration].[delta_capture_sp]	OR
	cf.[curation_sp]		<> [cf_feed_configuration].[curation_sp]		OR
	cf.[record_filter_id]	<> [cf_feed_configuration].[record_filter_id]	OR
	cf.[depends_on]			<> [cf_feed_configuration].[depends_on]			OR
	cf.[null_conv_char]		<> [cf_feed_configuration].[null_conv_char]		OR
	cf.[active_flag]		<> [cf_feed_configuration].[active_flag]			
)



﻿IF OBJECT_ID('tempdb..#historymdref') IS NOT NULL
    DROP TABLE #historymdref

CREATE TABLE #historymdref
(
	[assetid] [int] NOT NULL,
	[assetname] [nvarchar](100) NULL,
	[assettypeid] [int] NOT NULL,
	[feedid] [int] NOT NULL,
	[feeddescription] [nvarchar](200) NULL,
	[sourcesystemid] [int] NOT NULL,
	[lovkey] [nvarchar](50) NULL,
	[LOVName] [nvarchar](50) NULL,
	[bucket_id] [int] NULL
)

GO

insert into #historymdref VALUES (3463, 'AW_CUST_CHILD_1.csv',6,371, 'Boots UK Advantage Card customer child  - history - One Off initial Load',30, 'ABACUS', 'Abacus',21)
insert into #historymdref VALUES (4865, 'AW_CUST_CHILD_6.csv',6,371, 'Boots UK Advantage Card customer child  - history - One Off initial Load',30, 'ABACUS', 'Abacus',21)
insert into #historymdref VALUES (5210, 'AW_CUST_CHILD_2.csv',6,371, 'Boots UK Advantage Card customer child  - history - One Off initial Load',30, 'ABACUS', 'Abacus',21)
insert into #historymdref VALUES (3462, 'AW_CUST_CLUBS_01.csv',6,373, 'Boots UK Advantage Card customer clubs - history- One Off initial Load',30, 'ABACUS', 'Abacus',22)
insert into #historymdref VALUES (3747, 'AW_CUST_INFO_00.csv',6,375, 'Boots UK Advantage Card customers - history - One Off initial Load',30, 'ABACUS', 'Abacus',23)
insert into #historymdref VALUES (3461, 'AW_MEMBER_ACTIVITY_0001.csv',6,377, 'Boots UK Advantage Card membership activity - history - One Off initial Load',30, 'ABACUS', 'Abacus',24)
insert into #historymdref VALUES (3742, 'AW_MEMBERSHIP_POINTS_00.csv',6,379, 'Boots UK Advantage Card membership points - history - One Off initial Load',30, 'ABACUS', 'Abacus',25)
insert into #historymdref VALUES (3746, 'AW_POINT_TRANSACTION_00.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',26)
insert into #historymdref VALUES (5564, 'AW_POINT_TRANSACTION_010.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',26)
insert into #historymdref VALUES (5565, 'AW_POINT_TRANSACTION_016.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',26)
insert into #historymdref VALUES (5566, 'AW_POINT_TRANSACTION_008.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',26)
insert into #historymdref VALUES (5573, 'AW_POINT_TRANSACTION_004.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',26)
insert into #historymdref VALUES (5574, 'AW_POINT_TRANSACTION_006.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',26)
insert into #historymdref VALUES (5575, 'AW_POINT_TRANSACTION_002.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',27)
insert into #historymdref VALUES (5576, 'AW_POINT_TRANSACTION_003.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',27)
insert into #historymdref VALUES (5577, 'AW_POINT_TRANSACTION_007.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',27)
insert into #historymdref VALUES (5578, 'AW_POINT_TRANSACTION_005.csv',6,381, 'Boots UK Advantage Card transactions - history - One Off initial Load',30, 'ABACUS', 'Abacus',27)
insert into #historymdref VALUES (3743, 'AW_MEMBERSHIP_CARD_00.csv',6,396, 'Boots UK Advantage Card membership card - history - One Off initial Load',30, 'ABACUS', 'Abacus',28)
insert into #historymdref VALUES (5644, 'SVOCCC_CUSTOMER_PHONE_3.csv',6,388, 'SVoC Customer phone - One Off initial Load',30, 'ABACUS', 'Abacus',33)
insert into #historymdref VALUES (3782, 'SVOCCC_CONSENT_TYPE_MST_12.csv',6,419, 'SVoC Customer consent type - One Off initial Load',30, 'ABACUS', 'Abacus',44)
insert into #historymdref VALUES (4717, 'SVOCCC_CUSTOMER_MST_0.csv',6,421, 'SVoC Customer data - One Off initial Load',30, 'ABACUS', 'Abacus',45)
insert into #historymdref VALUES (5647, 'SVOCCC_CUSTOMER_MST_3.csv',6,421, 'SVoC Customer data - One Off initial Load',30, 'ABACUS', 'Abacus',43)
insert into #historymdref VALUES (4815, 'SVOCCC_CUSTOMER_ADDRESS_3.csv',6,422, 'SVoC Customer address - One Off initial Load',30, 'ABACUS', 'Abacus',39)
insert into #historymdref VALUES (5648, 'SVOCCC_CUSTOMER_ENTITY_LNK_4.csv',6,423, 'SVoC Customer entity link - One Off initial Load',30, 'ABACUS', 'Abacus',42)
insert into #historymdref VALUES (4712, 'SVOCCC_CUSTOMER_EMAIL_0.csv',6,424, 'SVoC customer email - One Off initial Load',30, 'ABACUS', 'Abacus',32)
insert into #historymdref VALUES (4720, 'SVOCCC_CUSTOMER_SOCIAL_MEDIA_0.csv',6,425, 'SVoC Customer social media - One Off initial Load',30, 'ABACUS', 'Abacus',35)
insert into #historymdref VALUES (5102, 'SVOCCC_CUSTOMER_IDENTIFIER_0.csv',6,426, 'SVoC Customer identifier - One Off initial Load',30, 'ABACUS', 'Abacus',36)
insert into #historymdref VALUES (5103, 'SVOCCC_CUSTOMER_IDENTIFIER_00.csv',6,426, 'SVoC Customer identifier - One Off initial Load',30, 'ABACUS', 'Abacus',36)
insert into #historymdref VALUES (5104, 'SVOCCC_CUSTOMER_IDENTIFIER_2.csv',6,426, 'SVoC Customer identifier - One Off initial Load',30, 'ABACUS', 'Abacus',38)
insert into #historymdref VALUES (4684, 'SVOCCC_CUSTOMER_CONSENT_0.csv',6,427, 'SVoC Customer consent - One Off initial Load',30, 'ABACUS', 'Abacus',34)
insert into #historymdref VALUES (5652, 'SVOCCC_CUSTOMER_CONSENT_ENTITY_LNK_3.csv',6,428, 'SVoC Customer consent entity link - One Off initial Load',30, 'ABACUS', 'Abacus',40)
insert into #historymdref VALUES (5653, 'SVOCCC_CUSTOMER_CONSENT_ENTITY_LNK_1.csv',6,428, 'SVoC Customer consent entity link - One Off initial Load',30, 'ABACUS', 'Abacus',41)
insert into #historymdref VALUES (5654, 'SVOCCC_CUSTOMER_CONSENT_ENTITY_LNK_2.csv',6,428, 'SVoC Customer consent entity link - One Off initial Load',30, 'ABACUS', 'Abacus',41)

INSERT INTO psa.historymdref
SELECT  * FROM #historymdref
WHERE assetid NOT IN (SELECT DISTINCT assetid FROM psa.historymdref)
IF OBJECT_ID('tempdb..#cf_batch') IS NOT NULL
  DROP TABLE #cf_batch

CREATE TABLE #cf_batch
(
	[batch_id] [int] NOT NULL,
	[batch_name] [nchar](100) NULL,
	[feed_id] [int] NOT NULL,
	[order_of_execution] [int] NOT NULL,
	[active_flag] [smallint] NOT NULL,
	[dt_created] [smalldatetime] NULL,
	[user_created] [nchar](100) NULL
)


--DELETE FROM [psa].[cf_batch] WHERE batch_name = 'Calendar'

INSERT INTO #cf_batch VALUES(0,'GB SAP',187,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',188,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',189,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',190,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',191,5,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP TRANSACTION',192,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP TRANSACTION',193,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'LIZ EARLE',200,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BUK SAP',185,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAP PRODUCT MASTER',197,1,1,@insert_date,@insert_user)

--Calendar
INSERT INTO #cf_batch VALUES(0,'Calendar',196,1,1,@insert_date,@insert_user);
INSERT INTO #cf_batch VALUES(0,'GBFIN_Calendar_incr',2256,1,1,@insert_date,@insert_user);

--WAG product
INSERT INTO #cf_batch VALUES(0,'WAG product History',204,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG product Incremental',201,1,1,@insert_date,@insert_user)

--WAG store
--INSERT INTO #cf_batch VALUES(0,'WAG store History',218,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG store Incremental',199,1,1,@insert_date,@insert_user)

--WAG 
INSERT INTO #cf_batch VALUES(0,'WAG basket History',236,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG basket Incremental',247,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG ebasket History',235,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG ebasket Incremental',248,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transaction History',237,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transaction Incremental',250,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransaction History',238,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransaction Incremental',249,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transactioncost History',219,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transactioncost Incremental',246,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransactioncost History',239,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransactioncost Incremental',234,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'walgreens RSI daily sales',2257,1,1,@insert_date,@insert_user)

 --Indonesia
INSERT INTO #cf_batch VALUES(0,'Indonesia weekly sales transaction',2275,1,1,@insert_date,@insert_user)

--Dermstore
INSERT INTO #cf_batch VALUES(0,'Dermstore history',212,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Dermstore incremental',228,1,1,@insert_date,@insert_user)

--Skinstore
INSERT INTO #cf_batch VALUES(0,'Skinstore No7 history',210,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Skinstore No7 incremental',226,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Skinstore SG history',209,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Skinstore SG incremental',227,1,1,@insert_date,@insert_user)

--SDM
INSERT INTO #cf_batch VALUES(0,'SDMSGStoreSales History',205,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMSGESales History',208,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7StoreSales History',207,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7ESales History',206,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMSGStoreSales Incremental',225,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMSGESales Incremental',224,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7StoreSales Incremental',223,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7ESales Incremental',220,1,1,@insert_date,@insert_user)

--TSG
INSERT INTO #cf_batch VALUES(0,'TSGAAFES History',215,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGMCXNo7 History',214,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGNEXCOM History',213,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGAAFES Incremental',229,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGMCXNo7 Incremental',230,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGNEXCOM Incremental',231,1,1,@insert_date,@insert_user)

--Target
INSERT INTO #cf_batch VALUES(0,'Target History',211,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Target Incremental',203,1,1,@insert_date,@insert_user)

--ULTA
INSERT INTO #cf_batch VALUES(0,'ULTAEDI History',216,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'ULTAEDI Incremental',233,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'ULTAWEB History',217,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'ULTAWEB Incremental',232,1,1,@insert_date,@insert_user)

--Currency Conversion 
INSERT INTO #cf_batch VALUES(0,'GlobalBrandsCurrencyConversionRates Incremental',251,1,1,@insert_date,@insert_user)

--Baozun 
INSERT INTO #cf_batch VALUES(0,'BaozunSalesHistory',221,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BaozunSalesIncremental',222,1,1,@insert_date,@insert_user)

--GBFINRetailer
INSERT INTO #cf_batch VALUES(0,'GBFINRetailerIncremental',242,1,1,@insert_date,@insert_user)

--GBFINStoreMaster
INSERT INTO #cf_batch VALUES(0,'GBFINStoreMasterIncremental',198,1,1,@insert_date,@insert_user)

--DA Invoice
INSERT INTO #cf_batch VALUES(0,'GB MI DA_Invoice Transaction',284,1,1,@insert_date,@insert_user)

--GB SAP Customer
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',285,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',286,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',287,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',288,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',290,5,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',291,6,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',289,7,1,@insert_date,@insert_user)

--GB SAP Finance GL
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL BKPF',295,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL BSEG',296,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL SKAT',297,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL CEPT',298,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL CE41000_ACCT',299,1,1,@insert_date,@insert_user)

--LE Store
INSERT INTO #cf_batch VALUES(0,'LizEarleStore',300,1,1,@insert_date,@insert_user)

--GBSAP GL Manual Adjustment
INSERT INTO #cf_batch VALUES(0,'GBSAP GL ManualAdjustment',303,1,1,@insert_date,@insert_user)

--DA COGS
INSERT INTO #cf_batch VALUES(0,'DA COGS Material Document Invoice',301,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'DA COGS Material Document Invoice',302,2,1,@insert_date,@insert_user)

--LE Sales
INSERT INTO #cf_batch VALUES(0,'LIZ EARLE Sales',304,1,1,@insert_date,@insert_user)

--TeamCenter Product
INSERT INTO #cf_batch VALUES(0,'TeamCenterProduct',312,1,1,@insert_date,@insert_user)

--GB S&OP Kohls
INSERT INTO #cf_batch VALUES(0,'GB S&OP Kohls weekly sales',311,1,1,@insert_date,@insert_user)

--GB S&OP Walmart Retail Sales 
INSERT INTO #cf_batch VALUES(0,'GB S&OP Walmart store retail sales',316,1,1,@insert_date,@insert_user)

--GB S&OP Walmart Online Sales 
INSERT INTO #cf_batch VALUES(0,'GB S&OP Walmart online retail sales',317,1,1,@insert_date,@insert_user)

--GB S&OP Alshaya Weekly sales inc 
INSERT INTO #cf_batch VALUES(0,'GB S&OP Alshaya Weekly sales inc',507,1,1,@insert_date,@insert_user)

--GB S&OP APH Weekly sales inc 
INSERT INTO #cf_batch VALUES(0,'GB S&OP APH Weekly sales inc',509,1,1,@insert_date,@insert_user)

--Mecca Sales
INSERT INTO #cf_batch VALUES(0,'Mecca Sales',351,1,1,@insert_date,@insert_user)

--GBMR UI
INSERT INTO #cf_batch VALUES(0,'GBMR UI',485,1,1,@insert_date,@insert_user)

--BUK TransactionLineAnon and TransactionLineCard OneTimeUpdateActivity
INSERT INTO #cf_batch VALUES(0,'BUK TransactionLineAnon Onetime',488,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BUK TransactionLineCard Onetime',491,1,1,@insert_date,@insert_user)

-- Budget and Forecast Weekly
INSERT INTO #cf_batch VALUES(0,'Budget and Forecast Weekly',498,1,1,@insert_date,@insert_user)

-- Budget and Forecast Monthly
INSERT INTO #cf_batch VALUES(0,'Budget and Forecast Monthly',508,1,1,@insert_date,@insert_user)


-- New Set of Batches for Global Brands

-- GBA

INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',249,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',250,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',234,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',246,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',199,5,1,@insert_date,@insert_user)

-- S&M

INSERT INTO #cf_batch VALUES(0,'GB SM',288,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',289,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',290,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',291,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',287,5,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',286,6,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',285,7,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',305,8,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',306,9,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',307,10,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',308,11,1,@insert_date,@insert_user)

INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',297,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',298,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',299,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',295,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',296,5,1,@insert_date,@insert_user)


-- Golden Record

INSERT INTO #cf_batch VALUES(0,'GB GOLDEN RECORD',191,8,1,@insert_date,@insert_user)

--Product Exclusion
INSERT INTO #cf_batch VALUES(0,'Exclusion Weekly Transaction',2300,1,1,@insert_date,@insert_user)

--Retailer to STEP mapping
INSERT INTO #cf_batch VALUES(0,'GB RETAILER_STEP_MAPPING',-2,1,1,@insert_date,@insert_user)


INSERT INTO [psa].[cf_batch] 
select 
	max_batch_id + distinct_match.new_row_id as [batch_id],
	s.[batch_name],
	s.[feed_id],
	s.[order_of_execution],
	s.[active_flag],
	s.[dt_created],
	s.[user_created]
from #cf_batch s
inner join (select max([batch_id]) max_batch_id from [psa].[cf_batch]) qry ON (1=1)
inner join (select [batch_name], row_number() OVER (ORDER BY batch_name) as new_row_id from #cf_batch
			where [batch_name] NOT IN (select distinct [batch_name] from [psa].[cf_batch])
			 group by [batch_name]) distinct_match ON (distinct_match.[batch_name] = s.[batch_name])
WHERE NOT EXISTS (select [batch_name],[order_of_execution] from [psa].[cf_batch] t
					WHERE s.[batch_name] = t.[batch_name]
					AND s.[order_of_execution] = t.[order_of_execution])

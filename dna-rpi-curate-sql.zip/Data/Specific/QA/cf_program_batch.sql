﻿

IF OBJECT_ID('tempdb..#temp_cf_program_batch') IS NOT NULL
  DROP TABLE #temp_cf_program_batch

CREATE TABLE #temp_cf_program_batch
(
	[Program_ID] [int] NOT NULL,
	[Program_Name] [nvarchar](100) NOT NULL,
	[Program_Step_ID] [int] NOT NULL,
	[Program_Step_Name] [nvarchar](100) NOT NULL,
	[Program_Seq_or_Parra] [nvarchar](20) NOT NULL,
	[Program_JSON] [nvarchar](4000) NULL
)

--DELETE FROM [psa].[cf_program_batch]

INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',1,'Reference Data','Parra','')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',2,'Product Data','Parra','')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',3,'GBA Sales Data','Parra','')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',4,'S&M Sales Data','Parra','')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',5,'S&OP Sales Data','Parra','')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',6,'GBMR UI Data','Seq','')
--INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',7,'Golden Record','Seq','')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',7,'Golden Record','Parra','{"Program_ID": "1","Steps": [{"Step_ID": "7","Step_Name": "Golden Record","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "Golden Record","Parra_Step_Batch": "101","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"},{"Parra_Step_ID": "2","Parra_Step_Name": "Retailer STEP mapping","Parra_Step_Batch": "115","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"}]}]}')



INSERT INTO [psa].[cf_program_batch] 
select 
	[Program_ID],
	[Program_Name],
	[Program_Step_ID],
	[Program_Step_Name],
	[Program_Seq_or_Parra],
	[Program_JSON]
from #temp_cf_program_batch s
WHERE NOT EXISTS (select [Program_ID],[Program_Step_ID] from [psa].[cf_program_batch] t
					WHERE s.[Program_ID] = t.[Program_ID]
					AND s.[Program_Step_ID] = t.[Program_Step_ID])


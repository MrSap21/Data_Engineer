﻿
create table #temp_monitor_reconcile_metadata
(
Project_ID						BIGINT NOT NULL,
Feed_ID							BIGINT NOT NULL,
Reconcile_Type					NVARCHAR(200) NOT NULL,
ProcSchema						NVARCHAR(100) NOT NULL,
ProcName						NVARCHAR(200) NOT NULL
)


INSERT INTO #temp_monitor_reconcile_metadata VALUES (66,203,'Sales Values','con_mon','sp_Reconcile_TGT_TGTWP_TargetSales')

DELETE from con_mon.monitor_reconcile_metadata

INSERT INTO con_mon.monitor_reconcile_metadata
select 
	s.Project_ID,
	s.Feed_ID,
	s.Reconcile_Type,
	s.ProcSchema,
	s.ProcName
from #temp_monitor_reconcile_metadata s
WHERE NOT EXISTS (select *
					from con_mon.monitor_reconcile_metadata t
					WHERE s.Project_ID = t.Project_ID
					AND s.Feed_ID = t.Feed_ID)




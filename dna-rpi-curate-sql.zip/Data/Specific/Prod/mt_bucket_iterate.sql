﻿IF OBJECT_ID('tempdb..#mt_bucket_iterate') IS NOT NULL
    DROP TABLE #mt_bucket_iterate
	
	CREATE TABLE #mt_bucket_iterate
(
	[bucket_id] [int] NOT NULL,
	[seq_num] [int] NOT NULL,
	[egress_flag] [char](1) NULL
)
--DF09 SVOCCC_CUSTOMER_ENTITY_LNK
insert into #mt_bucket_iterate VALUES(431,1,'Y')
insert into #mt_bucket_iterate VALUES(432,2,'Y')
insert into #mt_bucket_iterate VALUES(433,3,'Y')
insert into #mt_bucket_iterate VALUES(443,4,'Y')
insert into #mt_bucket_iterate VALUES(451,5,'Y')
insert into #mt_bucket_iterate VALUES(452,6,'Y')
insert into #mt_bucket_iterate VALUES(453,7,'Y')
insert into #mt_bucket_iterate VALUES(461,8,'Y')
insert into #mt_bucket_iterate VALUES(462,9,'Y')
insert into #mt_bucket_iterate VALUES(463,10,'Y')
insert into #mt_bucket_iterate VALUES(4341,11,'Y')
insert into #mt_bucket_iterate VALUES(4342,12,'Y')
insert into #mt_bucket_iterate VALUES(441,13,'Y')
insert into #mt_bucket_iterate VALUES(442,14,'Y')

--DF03 AW_MEMBER_ACTIVITY
insert into #mt_bucket_iterate VALUES(6012,15,'Y')
insert into #mt_bucket_iterate VALUES(60212,16,'Y')
insert into #mt_bucket_iterate VALUES(602121,17,'Y')
insert into #mt_bucket_iterate VALUES(601122,18,'Y')
insert into #mt_bucket_iterate VALUES(601111,19,'Y')
insert into #mt_bucket_iterate VALUES(821,20,'Y')
insert into #mt_bucket_iterate VALUES(6031,21,'Y')
insert into #mt_bucket_iterate VALUES(831,22,'Y')
insert into #mt_bucket_iterate VALUES(822,23,'Y')
-- automation starts below
insert into #mt_bucket_iterate VALUES(811,24,'N')
insert into #mt_bucket_iterate VALUES(812,25,'N')
insert into #mt_bucket_iterate VALUES(832,26,'N')
insert into #mt_bucket_iterate VALUES(6032,27,'N')
insert into #mt_bucket_iterate VALUES(601112,28,'N')
insert into #mt_bucket_iterate VALUES(601121,29,'N')
insert into #mt_bucket_iterate VALUES(601211,30,'N')
insert into #mt_bucket_iterate VALUES(601212,31,'N')
insert into #mt_bucket_iterate VALUES(601221,32,'N')
insert into #mt_bucket_iterate VALUES(601222,33,'N')
insert into #mt_bucket_iterate VALUES(602111,34,'N')
insert into #mt_bucket_iterate VALUES(602112,35,'N')
insert into #mt_bucket_iterate VALUES(602122,36,'N')
insert into #mt_bucket_iterate VALUES(602211,37,'N')
insert into #mt_bucket_iterate VALUES(602212,38,'N')
insert into #mt_bucket_iterate VALUES(602221,39,'N')
insert into #mt_bucket_iterate VALUES(602222,40,'N')

--DF04 AW_MEMBERSHIP_POINTS
insert into #mt_bucket_iterate VALUES(911,41,'N')
insert into #mt_bucket_iterate VALUES(912,42,'N')
insert into #mt_bucket_iterate VALUES(921,43,'N')
insert into #mt_bucket_iterate VALUES(922,44,'N')
insert into #mt_bucket_iterate VALUES(923,45,'N')
insert into #mt_bucket_iterate VALUES(913,46,'N')

--DF05 AW_POINT_TRANSACTION
insert into #mt_bucket_iterate VALUES(96,47,'N')
insert into #mt_bucket_iterate VALUES(97,48,'N')
insert into #mt_bucket_iterate VALUES(95,49,'N')
insert into #mt_bucket_iterate VALUES(94,50,'N')
insert into #mt_bucket_iterate VALUES(99,51,'N')
insert into #mt_bucket_iterate VALUES(72111,52,'N')
insert into #mt_bucket_iterate VALUES(72112,53,'N')
insert into #mt_bucket_iterate VALUES(72121,54,'N')
insert into #mt_bucket_iterate VALUES(72211,55,'N')
insert into #mt_bucket_iterate VALUES(72212,56,'N')
insert into #mt_bucket_iterate VALUES(72221,57,'N')
insert into #mt_bucket_iterate VALUES(72222,58,'N')
insert into #mt_bucket_iterate VALUES(72122,59,'N')
insert into #mt_bucket_iterate VALUES(71111,60,'N')
insert into #mt_bucket_iterate VALUES(71112,61,'N')
insert into #mt_bucket_iterate VALUES(71121,62,'N')
insert into #mt_bucket_iterate VALUES(71122,63,'N')
insert into #mt_bucket_iterate VALUES(71211,64,'N')
insert into #mt_bucket_iterate VALUES(71212,65,'N')
insert into #mt_bucket_iterate VALUES(71221,66,'N')
insert into #mt_bucket_iterate VALUES(71222,67,'N')
insert into #mt_bucket_iterate VALUES(981,68,'N')
insert into #mt_bucket_iterate VALUES(982,69,'N')

--DF06 AW_CUST_CLUBS
insert into #mt_bucket_iterate VALUES(523,70,'N')
insert into #mt_bucket_iterate VALUES(511,71,'N')
insert into #mt_bucket_iterate VALUES(512,72,'N')
insert into #mt_bucket_iterate VALUES(513,73,'N')
insert into #mt_bucket_iterate VALUES(514,74,'N')
insert into #mt_bucket_iterate VALUES(521,75,'N')
insert into #mt_bucket_iterate VALUES(522,76,'N')
insert into #mt_bucket_iterate VALUES(524,77,'N')

--DF15 SVOCCC_CUSTOMER_CONSENT
insert into #mt_bucket_iterate VALUES(411,78,'N')
insert into #mt_bucket_iterate VALUES(42,79,'N')
insert into #mt_bucket_iterate VALUES(415,80,'N')
insert into #mt_bucket_iterate VALUES(417,81,'N')
insert into #mt_bucket_iterate VALUES(419,82,'N')

--DF16 SVOCCC_CUSTOMER_CONSENT_ENTITY_LNK
insert into #mt_bucket_iterate VALUES(322,83,'N')
insert into #mt_bucket_iterate VALUES(331,84,'N')
insert into #mt_bucket_iterate VALUES(3111,85,'N')
insert into #mt_bucket_iterate VALUES(3112,86,'N')
insert into #mt_bucket_iterate VALUES(3121,87,'N')
insert into #mt_bucket_iterate VALUES(3122,88,'N')
insert into #mt_bucket_iterate VALUES(3211,89,'N')
insert into #mt_bucket_iterate VALUES(3212,90,'N')
insert into #mt_bucket_iterate VALUES(3321,91,'N')
insert into #mt_bucket_iterate VALUES(3322,92,'N')

--DF58 SVOCCC_CONSENT_TYPE_MST
insert into #mt_bucket_iterate VALUES(602223,93,'N')

--DF17 AW_MEMBERSHIP_CARD
insert into #mt_bucket_iterate VALUES(62,94,'N')
insert into #mt_bucket_iterate VALUES(64,95,'N')
insert into #mt_bucket_iterate VALUES(63,96,'N')
insert into #mt_bucket_iterate VALUES(61,97,'N')
insert into #mt_bucket_iterate VALUES(60,98,'N')
insert into #mt_bucket_iterate VALUES(58,99,'N')
insert into #mt_bucket_iterate VALUES(59,100,'N')
insert into #mt_bucket_iterate VALUES(65,101,'N')
insert into #mt_bucket_iterate VALUES(591,102,'N')

--DF01 AW_CUST_INFO
insert into #mt_bucket_iterate VALUES(53,103,'N')
insert into #mt_bucket_iterate VALUES(54,104,'N')
insert into #mt_bucket_iterate VALUES(55,105,'N')
insert into #mt_bucket_iterate VALUES(56,106,'N')
insert into #mt_bucket_iterate VALUES(57,107,'N')

--DF08 SVOCCC_CUSTOMER_MST
insert into #mt_bucket_iterate VALUES(251,108,'N')
insert into #mt_bucket_iterate VALUES(252,109,'N')
insert into #mt_bucket_iterate VALUES(271,110,'N')
insert into #mt_bucket_iterate VALUES(272,111,'N')
insert into #mt_bucket_iterate VALUES(261,112,'N')
insert into #mt_bucket_iterate VALUES(262,113,'N')
insert into #mt_bucket_iterate VALUES(281,114,'N')
insert into #mt_bucket_iterate VALUES(282,115,'N')

--DF10 SVOCCC_CUSTOMER_ADDRESS
insert into #mt_bucket_iterate VALUES(212,116,'N')
insert into #mt_bucket_iterate VALUES(222,117,'N')
insert into #mt_bucket_iterate VALUES(232,118,'N')
insert into #mt_bucket_iterate VALUES(24,119,'N')
insert into #mt_bucket_iterate VALUES(2111,120,'N')
insert into #mt_bucket_iterate VALUES(2112,121,'N')
insert into #mt_bucket_iterate VALUES(2211,122,'N')
insert into #mt_bucket_iterate VALUES(2212,123,'N')
insert into #mt_bucket_iterate VALUES(2311,124,'N')
insert into #mt_bucket_iterate VALUES(2312,125,'N')

---DF11 SVOCCC_CUSTOMER_PHONE
insert into #mt_bucket_iterate VALUES(38,126,'N')
insert into #mt_bucket_iterate VALUES(361,127,'N')
insert into #mt_bucket_iterate VALUES(362,128,'N')
insert into #mt_bucket_iterate VALUES(363,129,'N')
insert into #mt_bucket_iterate VALUES(371,130,'N')
insert into #mt_bucket_iterate VALUES(372,131,'N')
insert into #mt_bucket_iterate VALUES(373,132,'N')
insert into #mt_bucket_iterate VALUES(364,133,'N')

--DF13 SVOCCC_CUSTOMER_SOCIAL_MEDIA
insert into #mt_bucket_iterate VALUES(1,134,'N')
insert into #mt_bucket_iterate VALUES(11,135,'N')
insert into #mt_bucket_iterate VALUES(12,136,'N')
insert into #mt_bucket_iterate VALUES(13,137,'N')
insert into #mt_bucket_iterate VALUES(14,138,'N')
insert into #mt_bucket_iterate VALUES(15,139,'N')
insert into #mt_bucket_iterate VALUES(161,140,'N')
insert into #mt_bucket_iterate VALUES(162,141,'N')

--DF12 SVOCCC_CUSTOMER_EMAIL
insert into #mt_bucket_iterate VALUES(35,142,'N')
insert into #mt_bucket_iterate VALUES(341,143,'N')
insert into #mt_bucket_iterate VALUES(342,144,'N')
insert into #mt_bucket_iterate VALUES(343,145,'N')
insert into #mt_bucket_iterate VALUES(344,146,'N')
insert into #mt_bucket_iterate VALUES(345,147,'N')

--DF02 CUST_CHILD
insert into #mt_bucket_iterate VALUES(51,1,'N')

--DF14 CUSTOMER IDENTIFIER
insert into #mt_bucket_iterate VALUES(602225,2,'N')
insert into #mt_bucket_iterate VALUES(602226,3,'N')
insert into #mt_bucket_iterate VALUES(602227,4,'N')
insert into #mt_bucket_iterate VALUES(602228,5,'N')
insert into #mt_bucket_iterate VALUES(602229,6,'N')
insert into #mt_bucket_iterate VALUES(602230,7,'N')
insert into #mt_bucket_iterate VALUES(602231,8,'N')
insert into #mt_bucket_iterate VALUES(602232,9,'N')
insert into #mt_bucket_iterate VALUES(602233,10,'N')
insert into #mt_bucket_iterate VALUES(602234,11,'N')
insert into #mt_bucket_iterate VALUES(602235,12,'N')

--DF24
insert into #mt_bucket_iterate VALUES(1000001,1,'N')

--DF25
insert into #mt_bucket_iterate VALUES(1000002,2,'N')

--DF29
insert into #mt_bucket_iterate VALUES(1000003,3,'N')

--DF34
insert into #mt_bucket_iterate VALUES(1000004,4,'N')

--WAVE 3 CATCH UP
--DF24
insert into #mt_bucket_iterate VALUES(1000005,1,'N')

--DF25
insert into #mt_bucket_iterate VALUES(1000006,2,'N')

--DF29
insert into #mt_bucket_iterate VALUES(1000007,3,'N')

--DF28
insert into #mt_bucket_iterate VALUES(1000008,4,'N')

--DF34
insert into #mt_bucket_iterate VALUES(1000009,5,'N')

INSERT INTO psa.mt_bucket_iterate
SELECT  * FROM #mt_bucket_iterate
WHERE bucket_id NOT IN (SELECT DISTINCT bucket_id FROM psa.mt_bucket_iterate)
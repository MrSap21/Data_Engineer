﻿
IF OBJECT_ID('tempdb..#cf_feed_configuration') IS NOT NULL
  DROP TABLE #cf_feed_configuration

CREATE TABLE #cf_feed_configuration
(
	[feed_id] [int] NOT NULL,
	[psa_table_name] [nchar](100) NULL,
	[delta_capture_sp] [int] NOT NULL,
	[curation_sp] [int] NOT NULL,
	[record_filter_id] [int] NULL,
	[depends_on] [nchar](25) NULL,
	[null_conv_char] [nchar](5) NULL,
	[active_flag] [smallint] NOT NULL,
	[dt_created] [smalldatetime] NULL,
	[user_created] [nchar](100) NULL
)

/*

Enter Your FEED_CONFIGURATION below.  If it doens't exist it'll insert it into the table.

*/

--DELETE FROM [psa].[cf_feed_configuration] WHERE [feed_id] IN (294,295,296,297,298,299,300,301,377,399)
--DELETE FROM [psa].[cf_feed_configuration] WHERE [feed_id] IN (392)

DELETE FROM psa.cf_feed_configuration where feed_id IN (396,397);

/* Prod Configuration */                

INSERT INTO #cf_feed_configuration SELECT 393,'RPIDNA_GBSAP_MARA',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 394,'RPIDNA_GBSAP_MAKT',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 395,'RPIDNA_GBSAP_T023T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 396,'RPIDNA_GBSAP_T179T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
--INSERT INTO #cf_feed_configuration SELECT 396,'RPIDNA_GBSAP_T179T',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_sap_product' 
--INSERT INTO #cf_feed_configuration SELECT 397,'RPIDNA_GBSAP_MARC',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gbmr_golden_product' 
INSERT INTO #cf_feed_configuration SELECT 397,'RPIDNA_GBSAP_MARC',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_Product_Master' 

INSERT INTO #cf_feed_configuration SELECT 391,'RPIDNA_GBSAP_VBRK',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 392,'RPIDNA_GBSAP_VBRP',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_sap_transaction_master' 
INSERT INTO #cf_feed_configuration SELECT 253,'SAPCOE_BUKSAP_BUKSAPArticle',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_buk_sap_product' 
INSERT INTO #cf_feed_configuration SELECT 390,'LEIT_LEDATAHUB_SalesProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_le_product' 
INSERT INTO #cf_feed_configuration SELECT 301,'GBMDT_GBFINEXCEL_GBMDTProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_sap_mdm_product' 

-- SAP Customer
INSERT INTO #cf_feed_configuration SELECT 406,'RPIDNA_GBSAP_SAP_T001',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 409,'RPIDNA_GBSAP_SAP_TVKOT',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 403,'RPIDNA_GBSAP_SAP_KNA1',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 404,'RPIDNA_GBSAP_SAP_KNB1',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 408,'RPIDNA_GBSAP_SAP_TVKO',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 405,'RPIDNA_GBSAP_SAP_ADRC',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_gb_customer_master' 
INSERT INTO #cf_feed_configuration SELECT 407,'RPIDNA_GBSAP_SAP_KNVV',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'



-- GBA Spreadsheet Feeds
INSERT INTO #cf_feed_configuration SELECT 401,'GFSD_GFSDEXCEL_GlobalBrandsCurrencyConversionRates',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GFSD_GFSDEXCEL_GlobalBrandsCurrencyConversionRates' 
INSERT INTO #cf_feed_configuration SELECT 254,'GBFIN_GBFINEXCEL_GBFINRetailerCalendar',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_calendar_master' 
INSERT INTO #cf_feed_configuration SELECT 2449,'GBFIN_GBFINEXCEL_GB_Calendar_information_GBFINEXCEL_incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBFINEXCEL_GB_Calendar_information_GBFINEXCEL_incr' 


--DA Invoice Sales
INSERT INTO #cf_feed_configuration SELECT 402,'BUKIT_GBEDISTG_DAInvoiceDetails',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_gb_da_inv_transaction_master'

--LE Store
INSERT INTO #cf_feed_configuration SELECT 412,'LEIT_LEXDH_LEIT_LEX_SALES_Store',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_LEIT_LEXDH_LEIT_LEX_SALES_Store'

--GB SAP Finance GL
INSERT INTO #cf_feed_configuration SELECT 419,'RPIDNA_GBSAP_SAP_BKPF',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_BKPF'
INSERT INTO #cf_feed_configuration SELECT 420,'RPIDNA_GBSAP_SAP_BSEG',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_BSEG'
INSERT INTO #cf_feed_configuration SELECT 421,'RPIDNA_GBSAP_SAP_SKAT',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_SKAT'
INSERT INTO #cf_feed_configuration SELECT 422,'RPIDNA_GBSAP_SAP_CEPT',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_CEPT'
INSERT INTO #cf_feed_configuration SELECT 423,'RPIDNA_GBSAP_SAP_CE41000_ACCT',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_GBSAP_SAP_CE41000_ACCT'

-- SAP Customer Lookup Tables
INSERT INTO #cf_feed_configuration SELECT 411,'RPIDNA_GBSAP_SAP_T151T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 413,'RPIDNA_GBSAP_SAP_TVV1T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 414,'RPIDNA_GBSAP_SAP_TVV2T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 415,'RPIDNA_GBSAP_SAP_TVV3T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'

--DA COGS
INSERT INTO #cf_feed_configuration SELECT 416,'RPIDNA_GBSAP_SAP_MKPF',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_gb_da_cogs_document' 
INSERT INTO #cf_feed_configuration SELECT 417,'RPIDNA_GBSAP_SAP_MSEG',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_gb_da_cogs_transaction_master' 

--LE SALES
INSERT INTO #cf_feed_configuration SELECT 418,'LEIT_LEXDH_LIZ_EARLE_RETAIL_AND_INVOICE_SALES',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_liz_earle_transaction_master' 

--International Retail Sales
INSERT INTO #cf_feed_configuration SELECT 430,'RPIDNA_DNAPSAV1_FAITFAPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 428,'FAIT_BIRFAEXCEL_FAITFAPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 426,'FAIT_BIRFAEXCEL_FAITFAPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 429,'RPIDNA_DNAPSAV1_FAITFAPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 432,'BTHIT_BIRTHEXCEL_BIRTHITTPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 434,'BTHIT_BIRTHEXCEL_BIRTHITTPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 435,'RPIDNA_DNAPSAV1_BIRTHITTPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 436,'RPIDNA_DNAPSAV1_BIRTHITTPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 438,'BNEIT_BIRNLEXCEL_BIRNEITNEPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 440,'BNEIT_BIRNLEXCEL_BIRNEITNEPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 441,'RPIDNA_DNAPSAV1_BIRNEITNEPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 442,'RPIDNA_DNAPSAV1_BIRNEITNEPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 444,'FBIT_BIRFBEXCEL_BIRMEXITMEXPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 446,'FBIT_BIRFBEXCEL_BIRMEXITMEXPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 447,'RPIDNA_DNAPSAV1_BIRMEXITMEXPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 448,'RPIDNA_DNAPSAV1_BIRMEXITMEXPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 450,'BNIT_BIRNOEXCEL_BIRNITBIRNPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 452,'BNIT_BIRNOEXCEL_BIRNITBIRNPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 454,'BNIT_BIRNOEXCEL_BIRNITBIRNWSWholesaleDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture'
INSERT INTO #cf_feed_configuration SELECT 455,'RPIDNA_DNAPSAV1_BIRNITBIRNPOSDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 456,'RPIDNA_DNAPSAV1_BIRNITBIRNPOSDailySalesProfit',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'
INSERT INTO #cf_feed_configuration SELECT 457,'RPIDNA_DNAPSAV1_BIRNITBIRNWSWholesaleDailySales',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture'


--GBFINRetailer
INSERT INTO #cf_feed_configuration SELECT 257,'GBFIN_GBFINEXCEL_GBFINRetailer',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBFINEXCEL_GBFINRetailer_party' 

--GBFINStoreMaster
INSERT INTO #cf_feed_configuration SELECT 300,'GBFIN_GBFINEXCEL_GBFINStoreMaster',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_GBFIN_GBFINEXCEL_GBFINStoreMaster' 

--WAG product
INSERT INTO #cf_feed_configuration SELECT 98,'RPIDNA_DNAPSAV1_WalgreensProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensProduct' 
INSERT INTO #cf_feed_configuration SELECT 275,'WAGIT_WAGEDW_WalgreensProduct',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensProduct' 

--WAG store
INSERT INTO #cf_feed_configuration SELECT 95,'RPIDNA_DNAPSAV1_WalgreensStore',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensStore' 
INSERT INTO #cf_feed_configuration SELECT 289,'WAGIT_WAGEDW_WalgreensStore',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensStore' 

--Walgreens
INSERT INTO #cf_feed_configuration SELECT 101,'RPIDNA_DNAPSAV1_WalgreensBasket',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensBasket' 
INSERT INTO #cf_feed_configuration SELECT 287,'WAGIT_WAGEDW_WalgreensBasket',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensBasket' 
INSERT INTO #cf_feed_configuration SELECT 111,'RPIDNA_DNAPSAV1_WalgreensEBasket',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensEBasket' 
INSERT INTO #cf_feed_configuration SELECT 285,'WAGIT_WAGEDW_WalgreensEBasket',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensEBasket' 
INSERT INTO #cf_feed_configuration SELECT 110,'RPIDNA_DNAPSAV1_WalgreensTransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM_WAG' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensTransaction' 
INSERT INTO #cf_feed_configuration SELECT 295,'WAGIT_WAGEDW_WalgreensTransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensTransaction' 
INSERT INTO #cf_feed_configuration SELECT 103,'RPIDNA_DNAPSAV1_WalgreensETransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensETransaction' 
INSERT INTO #cf_feed_configuration SELECT 283,'WAGIT_WAGEDW_WalgreensETransaction',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensETransaction' 
INSERT INTO #cf_feed_configuration SELECT 99,'RPIDNA_DNAPSAV1_WalgreensTransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensTransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 293,'WAGIT_WAGEDW_WalgreensTransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensTransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 100,'RPIDNA_DNAPSAV1_WalgreensETransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_WalgreensETransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 290,'WAGIT_WAGEDW_WalgreensETransactionCost',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk_WAG' and b.[sp_name] = 'psa.sp_inc_WAGIT_WAGEDW_WalgreensETransactionCost' 
INSERT INTO #cf_feed_configuration SELECT 2450,'DATALYNX_WAGX_GB_Daily_Walgreens_Sales_from_RSI_WAGX',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_DATALYNX_WAGX_GB_Daily_Walgreens_Sales_from_RSI_WAGX' 

--Indonesia
INSERT INTO #cf_feed_configuration SELECT 2478,'IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_IDNBUS_IDNEXCEL_GB_Indonesia_Transaction_IDNEXCEL' 


--Opticians
INSERT INTO #cf_feed_configuration SELECT 670,'SAPCOE_BTCSAPECC_BUK_Opticians_Product_Master_Data_SAP_ECC',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_optician'
INSERT INTO #cf_feed_configuration SELECT 673,'BOPSAPPMAN_BUKOPTMI_BUK_Opticians_Transaction_Sales_Price_Data_Opticians_MI_Incr',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_optician'

--Dermstore
INSERT INTO #cf_feed_configuration SELECT 114,'RPIDNA_DNAPSAV1_DermstoreRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_DermstoreRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 256,'TGTDS_TGTDSEXCEL_DermstoreRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TGTDS_TGTDSEXCEL_DermstoreRetailSales' 

--Skinstore
INSERT INTO #cf_feed_configuration SELECT 104,'RPIDNA_DNAPSAV1_SKINSTORE_No7_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SKINSTORE_No7_WeeklyRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 264,'SKNST_SKNSTEXCEL_SKINSTORE_No7_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SKNST_SKNSTEXCEL_SKINSTORE_No7_WeeklyRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 107,'RPIDNA_DNAPSAV1_SKINSTORE_SG_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SKINSTORE_SG_WeeklyRetailSales' 
INSERT INTO #cf_feed_configuration SELECT 263,'SKNST_SKNSTEXCEL_SKINSTORE_SG_WeeklyRetailSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SKNST_SKNSTEXCEL_SKINSTORE_SG_WeeklyRetailSales' 

--SDM
INSERT INTO #cf_feed_configuration SELECT 112,'RPIDNA_DNAPSAV1_SDMSGESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMSGESales' 
INSERT INTO #cf_feed_configuration SELECT 116,'RPIDNA_DNAPSAV1_SDMSGStoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMSGStoreSales'     
INSERT INTO #cf_feed_configuration SELECT 113,'RPIDNA_DNAPSAV1_SDMNo7StoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMNo7StoreSales' 
INSERT INTO #cf_feed_configuration SELECT 115,'RPIDNA_DNAPSAV1_SDMNo7ESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_SDMNo7ESales' 
INSERT INTO #cf_feed_configuration SELECT 262,'SDM_SDMEXCEL_SDMNo7ESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMNo7ESales' 
INSERT INTO #cf_feed_configuration SELECT 259,'SDM_SDMEXCEL_SDMSGStoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMSGStoreSales'     
INSERT INTO #cf_feed_configuration SELECT 261,'SDM_SDMEXCEL_SDMNo7StoreSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMNo7StoreSales' 
INSERT INTO #cf_feed_configuration SELECT 260,'SDM_SDMEXCEL_SDMSGESales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_SDM_SDMEXCEL_SDMSGESales' 

--TSG
INSERT INTO #cf_feed_configuration SELECT 94,'RPIDNA_DNAPSAV1_TSGAAFES',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TSGAAFES' 
INSERT INTO #cf_feed_configuration SELECT 96,'RPIDNA_DNAPSAV1_TSGMCXNo7',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TSGMCXNo7' 
INSERT INTO #cf_feed_configuration SELECT 117,'RPIDNA_DNAPSAV1_TSGNEXCOM',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TSGNEXCOM' 
INSERT INTO #cf_feed_configuration SELECT 298,'TSG_TSGEXCEL_TSGAAFES',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TSG_TSGEXCEL_TSGAAFES' 
INSERT INTO #cf_feed_configuration SELECT 266,'TSG_TSGEXCEL_TSGMCXNo7',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TSG_TSGEXCEL_TSGMCXNo7' 
INSERT INTO #cf_feed_configuration SELECT 265,'TSG_TSGEXCEL_TSGNEXCOM',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture' and b.[sp_name] = 'psa.sp_inc_TSG_TSGEXCEL_TSGNEXCOM' 

--Target
INSERT INTO #cf_feed_configuration SELECT 247,'RPIDNA_DNAPSAV1_TargetSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_TargetSales' 
INSERT INTO #cf_feed_configuration SELECT 297,'TGT_TGTWP_TargetSales',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_TGT_TGTWP_TargetSales' 

--ULTA
INSERT INTO #cf_feed_configuration SELECT 118,'RPIDNA_DNAPSAV1_UltaEDI',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_UltaEDI' 
INSERT INTO #cf_feed_configuration SELECT 299,'Ulta_ULTAEXCEL_UltaEDI',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_Ulta_ULTAEXCEL_UltaEDI' 
INSERT INTO #cf_feed_configuration SELECT 102,'RPIDNA_DNAPSAV1_UltaWeb',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_HistoryDataCapture' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAPSAV1_UltaWeb' 
INSERT INTO #cf_feed_configuration SELECT 267,'Ulta_ULTAEXCEL_UltaWeb',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_Ulta_ULTAEXCEL_UltaWeb' 

--Baozun Combo
INSERT INTO #cf_feed_configuration SELECT 277,'WBAHK_BZUNEXCEL_BaozunComboSalesHistory',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 276,'WBAHK_BZUNEXCEL_BaozunComboSalesIncremental',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'

--Baozun Sales
INSERT INTO #cf_feed_configuration SELECT 279,'WBAHK_BZUNEXCEL_BaozunSalesHistory',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunSalesHistory' 
--INSERT INTO #cf_feed_configuration SELECT 279,'WBAHK_BZUNEXCEL_BaozunSalesHistory',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 278,'WBAHK_BZUNEXCEL_BaozunSalesIncremental',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_WBAHK_BZUNEXCEL_BaozunSalesIncremental' 

--BUK TransactionLineAnon and TransactionLineCard OneTimeUpdateActivity
INSERT INTO #cf_feed_configuration SELECT 553,'BUKIT_ABACUS_BUK_Transaction_line_anon_Abacus_hist',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_BUKIT_ABACUS_BUK_Transaction_line_anon_Abacus_hist'
INSERT INTO #cf_feed_configuration SELECT 556,'BUKIT_ABACUS_BUK_Transaction_line_card_Abacus_hist',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_BUKIT_ABACUS_BUK_Transaction_line_card_Abacus_hist'

-- GBMR UI
INSERT INTO #cf_feed_configuration SELECT 557,'RPIDNA_DNAUIGBMRPRD_GB_GBMR_Product_Updates_GBMRUI_inc',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_RPIDNA_DNAUIGBMRPRD_GB_GBMR_Product_Updates_GBMRUI'

--TeamCenter Product
INSERT INTO #cf_feed_configuration SELECT 458,'BUKIT_GBTC_Teamcenter',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_BUKIT_GBTC_Teamcenter'

-- Liz Earle Migration
INSERT INTO #cf_feed_configuration SELECT 587,'LEIT_LEXDH_LE_Bin_Item_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 588,'LEIT_LEXDH_LE_Bom_Item_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 589,'LEIT_LEXDH_LE_CB_Account_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 590,'LEIT_LEXDH_LE_CB_Account_Contact_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 591,'LEIT_LEXDH_LE_Document_Print_Status_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 592,'LEIT_LEXDH_LE_Document_Status_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 593,'LEIT_LEXDH_LE_Landed_Costs_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 594,'LEIT_LEXDH_LE_NL_Posted_Nominal_Transaction_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 595,'LEIT_LEXDH_LE_PL_Posted_Supplier_Transaction_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 596,'LEIT_LEXDH_LE_PL_Supplier_Account_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 597,'LEIT_LEXDH_LE_PL_Supplier_Contact_Value_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 598,'LEIT_LEXDH_LE_PL_Supplier_Contact_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 599,'LEIT_LEXDH_LE_PL_Supplier_Location_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 600,'LEIT_LEXDH_LE_NL_Account_Number_Cost_Centre_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 601,'LEIT_LEXDH_LE_NL_Account_Number_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 602,'LEIT_LEXDH_LE_NL_Account_Report_Category_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 603,'LEIT_LEXDH_LE_NL_Account_Report_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 604,'LEIT_LEXDH_LE_NL_Account_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 605,'LEIT_LEXDH_LE_NL_Cost_Centre_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 606,'LEIT_LEXDH_LE_NL_Department_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 607,'LEIT_LEXDH_LE_NL_Nominal_Account_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 608,'LEIT_LEXDH_LE_NL_Nominal_Tran_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 609,'LEIT_LEXDH_LE_Order_Return_Line_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 610,'LEIT_LEXDH_LE_PL_Payment_Group_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 611,'LEIT_LEXDH_LE_PL_Supplier_Contact_Role_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 612,'LEIT_LEXDH_LE_POP_Invoice_Credit_Line_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 613,'LEIT_LEXDH_LE_POP_Invoice_Credit_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 614,'LEIT_LEXDH_LE_POP_Order_Return_Line_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 615,'LEIT_LEXDH_LE_POP_Order_Return_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 616,'LEIT_LEXDH_LE_POP_Order_Return_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 617,'LEIT_LEXDH_LE_POP_Receipt_Return_Line_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 618,'LEIT_LEXDH_LE_POP_Receipt_Return_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 619,'LEIT_LEXDH_LE_POP_Receipt_Return_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 620,'LEIT_LEXDH_LE_Product_Group_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 621,'LEIT_LEXDH_LE_Salutation_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 622,'LEIT_LEXDH_LE_Source_Area_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 623,'LEIT_LEXDH_LE_Stock_Item_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 624,'LEIT_LEXDH_LE_Stock_Item_Status_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 625,'LEIT_LEXDH_LE_Stock_Item_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 626,'LEIT_LEXDH_LE_SYS_Account_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 627,'LEIT_LEXDH_LE_Sys_Contact_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 628,'LEIT_LEXDH_LE_SYS_Country_Code_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 629,'LEIT_LEXDH_LE_SYS_Credit_Bureau_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 630,'LEIT_LEXDH_LE_SYS_Credit_Position_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 631,'LEIT_LEXDH_LE_SYS_Currency_ISO_Code_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 632,'LEIT_LEXDH_LE_SYS_Currency_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 633,'LEIT_LEXDH_LE_SYS_Exchange_Rate_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 634,'LEIT_LEXDH_LE_SYS_Module_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 635,'LEIT_LEXDH_LE_SYS_Payment_Terms_Basis_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 636,'LEIT_LEXDH_LE_Sys_Tax_EC_Term_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 637,'LEIT_LEXDH_LE_Sys_Tax_Rate_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 638,'LEIT_LEXDH_LE_SYS_Trader_Contact_Role_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 639,'LEIT_LEXDH_LE_SYS_Trader_Tran_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 640,'LEIT_LEXDH_LE_Traceable_Type_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'
INSERT INTO #cf_feed_configuration SELECT 641,'LEIT_LEXDH_LE_Warehouse_LEXDH_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LE'

--Martech Wave 2  SVOC History 
INSERT INTO #cf_feed_configuration SELECT 510,'BUKIT_BTCSVOC_BUK_SVOC_Customer_address',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 515,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 516,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 508,'BUKIT_BTCSVOC_BUK_SVOC_Customer_data',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 512,'BUKIT_BTCSVOC_BUK_SVOC_Customer_email',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 509,'BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 514,'BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 511,'BUKIT_BTCSVOC_BUK_SVOC_Customer_phone',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 513,'BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 507,'BUKIT_ABACUS_BUK_SVOC_Customer_consent_type',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'

-- DPI
INSERT INTO #cf_feed_configuration SELECT 662,'BootsUK_Pharmacy_Customer_Info_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 663,'BootsUK_Pharmacy_Order_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 664,'BootsUK_Pharmacy_Customer_Relationship_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 665,'BootsUK_Pharmacy_Order_Items_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 666,'BootsUK_Pharmacy_Order_Transition_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 667,'BootsUK_Pharmacy_Order_Edits_Removal_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 668,'BootsUK_Pharmacy_Order_Consent_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'
INSERT INTO #cf_feed_configuration SELECT 669,'BootsUK_Pharmacy_Order_TaxedPrice_CEP',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_dpi'

--Asia MI non PII feeds
INSERT INTO #cf_feed_configuration SELECT 2522,'WBAHK_DIM_BIZ_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2622,'WBAHK_DIM_CNTRYGRP_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2524,'WBAHK_DIM_CUSTOMER_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2528,'WBAHK_DIM_DATE_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2530,'WBAHK_DIM_ForecastGroup_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2534,'WBAHK_Walgreens_HS_Code_List_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2546,'WBAHK_DIM_METRIC_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2560,'WBAHK_DIM_METRIC_GRP_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2564,'WBAHK_DIM_Opstudy_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2568,'WBAHK_DIM_PORTToCNTRY_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2572,'WBAHK_DIM_SAFETYRATE_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2576,'WBAHK_DIM_SEGToCustCode_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2580,'WBAHK_DIM_TEAM_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2582,'WBAHK_DIM_VENDOR_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2584,'WBAHK_DIM_VENDOR_GROUP_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2597,'WBAHK_DIM_VENDOR_INSPECTIONRATE_ROLLING_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2611,'WBAHK_DIM_VENDOR_MOQOAT_UK_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2613,'WBAHK_DIM_VENDOR_SERVICELVL_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2601,'WBAHK_DIM_VENDOR_SSIS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2595,'WBAHK_DIM_VENDOR9BOXSUMMARY_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 1332,'WBAHK_DIM_VENDOROPS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2542,'WBAHK_EthicalDetail_ETL_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2550,'WBAHK_Dashboard_Metric_Grouping_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2554,'WBAHK_Dashboard_Metric_KPI_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2558,'WBAHK_Dashboard_Metric_Parameter_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2562,'WBAHK_temp_fte_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2570,'WBAHK_V_BRS_PARTY_INFOCARD_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2574,'WBAHK_DIM_ADR7_PAYTERMS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2578,'WBAHK_DIM_COLOR_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2586,'WBAHK_DIM_HR_Datatype_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2590,'WBAHK_DIM_HR_TEAM_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2593,'WBAHK_DIM_MARGIN_BREAKDOWN_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2599,'WBAHK_DIM_VENDOR_1506_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2603,'WBAHK_DIM_VENDOR_DEALS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2605,'WBAHK_DIM_VENDOR_MOQOAT_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2607,'WBAHK_DIM_VENDOR9BOX_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2610,'WBAHK_Fact_HR_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2615,'WBAHK_PARTY_REL_TIER_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2617,'WBAHK_TEMP_9BOXSummary_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2619,'WBAHK_TEMP_BRANDMAP_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2621,'WBAHK_TEMP_EthicalSummary_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'

--Asia MI PII Feeds

INSERT INTO #cf_feed_configuration SELECT 2540,'WBAHK_ADR7_VENDORFACTORY_4FLAGS_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2517,'WBAHK_DIM_ForecastGroup_v2_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2588,'WBAHK_DIM_ITEM_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2544,'WBAHK_DIM_VENDORINFO_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2548,'WBAHK_FACT_WBAQUOTE_GSO_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2532,'WBAHK_FactMIDATA_OPEN_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2566,'WBAHK_FactMIDATA_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2526,'WBAHK_FactMIDATA_LIMA_OPEN_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2552,'WBAHK_FactMIDATA_GSOOPEN_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2556,'WBAHK_TEMP_FINANCECHECK_UK_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2536,'WBAHK_V_BRS_PARTY_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2538,'WBAHK_V_WBAPARTY_FTY_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'
INSERT INTO #cf_feed_configuration SELECT 2519,'WBAHK_Walgreens_Open_Purchase_Order_Detail_HKSQLDB',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_truncate_load_AsiaMI'


--Martech Wave 2  CRM History 
INSERT INTO #cf_feed_configuration SELECT 521,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_child',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 525,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_clubs',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 529,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 533,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_activity',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 547,'BUKIT_ABACUS_BUK_SAPCRM_Advantage_Card_membership_card',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 537,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_points',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 541,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions',a.sp_id,0,0,'','',0,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_HistoryDataCapture_Martech'

--Martech Wave 2 CRM Incremental  
INSERT INTO #cf_feed_configuration SELECT 519,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_child',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 523,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customer_clubs',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 527,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_customers',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 535,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_points',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 531,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_membership_activity',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_CRMTrans'
INSERT INTO #cf_feed_configuration SELECT 539,'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_CRMTrans'
INSERT INTO #cf_feed_configuration SELECT 543,'SAPCOE_SAPCRM_BUK_SAPCRM_Customer_Anonymisation',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 545,'SAPCOE_SAPCRM_BUK_SAPCRM_Customer_Status_Change',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'


--Martech Wave 2 SVOC Incremental   
INSERT INTO #cf_feed_configuration SELECT 483,'BUKIT_BTCSVOC_BUK_SVOC_Customer_address',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 498,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 501,'BUKIT_BTCSVOC_BUK_SVOC_Customer_consent_entity_link',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_SvocEntityLink'
INSERT INTO #cf_feed_configuration SELECT 477,'BUKIT_BTCSVOC_BUK_SVOC_Customer_data',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 504,'BUKIT_BTCSVOC_BUK_SVOC_Customer_delete',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Martech'
INSERT INTO #cf_feed_configuration SELECT 489,'BUKIT_BTCSVOC_BUK_SVOC_Customer_email',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 480,'BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_SvocEntityLink'
INSERT INTO #cf_feed_configuration SELECT 495,'BUKIT_BTCSVOC_BUK_SVOC_Customer_identifier',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 486,'BUKIT_BTCSVOC_BUK_SVOC_Customer_phone',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'
INSERT INTO #cf_feed_configuration SELECT 492,'BUKIT_BTCSVOC_BUK_SVOC_Customer_social_media',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_Svoc'

---TPM
INSERT INTO #cf_feed_configuration SELECT 2226,'RPIDNA_GBSAP_SAP_TVV4T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 2227,'RPIDNA_GBSAP_SAP_TVV5T',sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_IncrementalDataCapture_SM'
INSERT INTO #cf_feed_configuration SELECT 2228,'RPIDNA_GBSAP_SAP_MBEW',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_SM' and b.[sp_name] = 'psa.sp_inc_Coggs' 

-- STEP
INSERT INTO #cf_feed_configuration SELECT 2397,'GBMDT_STEP_GB_Product_Master_STEP',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_step' and b.[sp_name] = 'psa.sp_inc_step_product'

--Golden Record
INSERT INTO #cf_feed_configuration SELECT -1,'',0,sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_inc_gbmr_golden_product'

--RPRS
--RPRS Loss
INSERT INTO #cf_feed_configuration SELECT 2469,'SAPCOE_SAPBW_BootsUK_Loss_SAP_STOCK_ZPA_SAPBW_Incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_LossRPRS' and b.[sp_name] ='psa.sp_inc_loss'

--RPRS CUSTOMER

INSERT INTO #cf_feed_configuration SELECT 2625,'EXPRN_EXPRNMSC_BootsUK_Customer_Boots_Advantage_Card_Link_Key_Append_EXPRNMSC_incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_customerRPRS' and b.[sp_name] ='psa.sp_inc_customeraffluencelink'
INSERT INTO #cf_feed_configuration SELECT 2624,'EXPRN_EXPRNMSC_BootsUK_Customer_Boots_CV_Feed_EXPRNMSC_incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_customerRPRS' and b.[sp_name] ='psa.sp_inc_customeraffluencedetail'


--RPRS Merch

INSERT INTO #cf_feed_configuration SELECT 2476,'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Hierarchy_Data_BTCBY_Incr',a.sp_id,0,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_rprs'
INSERT INTO #cf_feed_configuration SELECT 2477,'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Fixtures_Data_BTCBY_Incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_rprs'and b.[sp_name]='psa.sp_inc_uk_btc_by_spc_fixture'
INSERT INTO #cf_feed_configuration SELECT 2473,'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Product_Data_BTCBY_Incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_rprs' and b.[sp_name]='psa.sp_inc_uk_btc_by_sp_ProductMerch'
INSERT INTO #cf_feed_configuration SELECT 2474,'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Header_Data_BTCBY_Incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_rprs' and b.[sp_name]='psa.sp_inc_uk_btc_by_spc_planogram'
INSERT INTO #cf_feed_configuration SELECT 2475,'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name]='psa.sp_IncrementalDataCapture_rprs' and b.[sp_name]='psa.sp_inc_uk_btc_by_spc_Merch_store'


--Product Exclusion
INSERT INTO #cf_feed_configuration SELECT 2637,'GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel',a.sp_id,b.sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] a JOIN  [psa].[cf_stored_proc] b ON (1=1) WHERE a.[sp_name] = 'psa.sp_IncrementalDataCapture_buk' and b.[sp_name] = 'psa.sp_inc_step_product_exclusion' 

--Retailer to STEP mapping
INSERT INTO #cf_feed_configuration SELECT -2,'',0,sp_id,0,'','',1,@insert_date,@insert_user FROM [psa].[cf_stored_proc] WHERE [sp_name] = 'psa.sp_insertretailertostep_productrelationship'

/* End of Configuration */

INSERT INTO [psa].[cf_feed_configuration] 
select 
	[feed_id],
	[psa_table_name],
	[delta_capture_sp],
	[curation_sp],
	[record_filter_id],
	[depends_on],
	[null_conv_char],
	[active_flag],
	[dt_created],
	[user_created]
from #cf_feed_configuration
WHERE [feed_id] NOT IN (select distinct [feed_id] from [psa].[cf_feed_configuration])

UPDATE [psa].[cf_feed_configuration] 
SET	[psa_table_name]		= cf.[psa_table_name]		,
	[delta_capture_sp]		= cf.[delta_capture_sp]	,
	[curation_sp]			= cf.[curation_sp]			,
	[record_filter_id]		= cf.[record_filter_id]	,
	[depends_on]			= cf.[depends_on]			,
	[null_conv_char]		= cf.[null_conv_char]		,
	[active_flag]			= cf.[active_flag]		
FROM #cf_feed_configuration cf
WHERE 
[cf_feed_configuration].feed_id = cf.feed_id
AND
(
	cf.[psa_table_name]		<> [cf_feed_configuration].[psa_table_name]		OR
	cf.[delta_capture_sp]	<> [cf_feed_configuration].[delta_capture_sp]	OR
	cf.[curation_sp]		<> [cf_feed_configuration].[curation_sp]		OR
	cf.[record_filter_id]	<> [cf_feed_configuration].[record_filter_id]	OR
	cf.[depends_on]			<> [cf_feed_configuration].[depends_on]			OR
	cf.[null_conv_char]		<> [cf_feed_configuration].[null_conv_char]		OR
	cf.[active_flag]		<> [cf_feed_configuration].[active_flag]			
)

﻿/**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

2021         :  Steve Blakemore	  Inital Version
01-11-2021   :  Gourik Nandy      Modified Version (code changes mentioned below and labeled as **LegacyDaily(01-Nov-2021)**)
                                  Purpose : Till date Legacy Migration Daily jobs were running under separate batches. This change will include that batch run 	under programId 2. This will help to bring all batch run under a single umbrella. The Legacy weekly jobs will still be runnning separate. However they will be taken under a different programId in future			
11-11-2021   :  Gourik Nandy      Include batch Id for Walmart curation (Tag: WalmartBatchAdd)	Batch ID - 78	
09-02-2023   :  Shivangi Arora    Modified Version: (Tag: 'UpdateJSON_CRQ69339')
								  Purpose: Correct Program Seq and JSON for Program Step 'GBMR UI Data'
29-06-2023   :  Shivangi Arora    Modified Version: (Tag: 'UpdateJSON_CRQ80908')
								  Purpose: Added details for Retailer to STEP mapping in step 'Golden Record'
**************************************************************************************************************************/

IF OBJECT_ID('tempdb..#temp_cf_program_batch') IS NOT NULL
  DROP TABLE #temp_cf_program_batch

CREATE TABLE #temp_cf_program_batch
(
	[Program_ID] [int] NOT NULL,
	[Program_Name] [nvarchar](100) NOT NULL,
	[Program_Step_ID] [int] NOT NULL,
	[Program_Step_Name] [nvarchar](100) NOT NULL,
	[Program_Seq_or_Parra] [nvarchar](20) NOT NULL,
	[Program_JSON] [nvarchar](4000) NULL
)

DELETE FROM [psa].[cf_program_batch]

INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',1,'Reference Data','Parra','{"Program_ID": "1","Steps": [{"Step_ID": "1","Step_Name": "Reference Data","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "Currency","Parra_Step_Batch": "17","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "2","Parra_Step_Name": "SAP Retailer","Parra_Step_Batch": "28","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "3","Parra_Step_Name": "Calendar","Parra_Step_Batch": "27","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "4","Parra_Step_Name": "Store","Parra_Step_Batch": "29","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "5","Parra_Step_Name": "SAP Product","Parra_Step_Batch": "93","Parra_Step_Project_ID": "1800051725","Parra_Time_Delay": "1"}]}]}')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',2,'Product Data','Parra','{"Program_ID": "1","Steps": [{"Step_ID": "2","Step_Name": "Product Data","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "GB_SAP_Product","Parra_Step_Batch": "12","Parra_Step_Project_ID": "67","Parra_Time_Delay": "1"},{"Parra_Step_ID": "2","Parra_Step_Name": "BUK_SAP_Product","Parra_Step_Batch": "11","Parra_Step_Project_ID": "67","Parra_Time_Delay": "120"},{"Parra_Step_ID": "3","Parra_Step_Name": "LIZ_Earle_Product","Parra_Step_Batch": "14","Parra_Step_Project_ID": "67","Parra_Time_Delay": "240"},{"Parra_Step_ID": "4","Parra_Step_Name": "Team Centre","Parra_Step_Batch": "82","Parra_Step_Project_ID": "67","Parra_Time_Delay": "1"},{"Parra_Step_ID": "5","Parra_Step_Name": "Wag Product","Parra_Step_Batch": "65","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "6","Parra_Step_Name": "TPM MBEW","Parra_Step_Batch": "92","Parra_Step_Project_ID": "1800051174","Parra_Time_Delay": "1"},{"Parra_Step_ID": "7","Parra_Step_Name": "Exclusion","Parra_Step_Batch": "99","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"}]}]}')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',3,'GBA Sales Data','Parra','{"Program_ID": "1","Steps": [{"Step_ID": "3","Step_Name": "GBA Sales Data","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "Walgreens","Parra_Step_Batch": "86","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "2","Parra_Step_Name": "SDM No7 E","Parra_Step_Batch": "33","Parra_Step_Project_ID": "66","Parra_Time_Delay": "600"},{"Parra_Step_ID": "3","Parra_Step_Name": "SDM No 7 Stores","Parra_Step_Batch": "35","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1200"},{"Parra_Step_ID": "4","Parra_Step_Name": "SDM SG E","Parra_Step_Batch": "37","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "5","Parra_Step_Name": "SDM SG Stores","Parra_Step_Batch": "39","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "6","Parra_Step_Name": "SkinStore No 7","Parra_Step_Batch": "41","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "7","Parra_Step_Name": "SkinStore SG","Parra_Step_Batch": "43","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "8","Parra_Step_Name": "TSG Army","Parra_Step_Batch": "47","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "9","Parra_Step_Name": "TSG Marines","Parra_Step_Batch": "49","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "10","Parra_Step_Name": "TSG Navy","Parra_Step_Batch": "51","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "11","Parra_Step_Name": "Target","Parra_Step_Batch": "45","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "12","Parra_Step_Name": "Ulta EDI","Parra_Step_Batch": "53","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "13","Parra_Step_Name": "Ulta Web","Parra_Step_Batch": "55","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "14","Parra_Step_Name": "Baozun Combo","Parra_Step_Batch": "72","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "15","Parra_Step_Name": "Baozun Sales","Parra_Step_Batch": "141","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "16","Parra_Step_Name": "DermStore","Parra_Step_Batch": "31","Parra_Step_Project_ID": "66","Parra_Time_Delay": "1"},{"Parra_Step_ID": "17","Parra_Step_Name": "SAP Customer","Parra_Step_Batch": "89","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"},{"Parra_Step_ID": "18","Parra_Step_Name": "DA COGS","Parra_Step_Batch": "19","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"}]}]}')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',4,'S&M Sales Data','Parra','{"Program_ID": "1","Steps": [{"Step_ID": "4","Step_Name": "S&M Sales Data","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "GB SAP Invoice","Parra_Step_Batch": "88","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"},{"Parra_Step_ID": "2","Parra_Step_Name": "Liz Earle Store","Parra_Step_Batch": "21","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "240"},{"Parra_Step_ID": "3","Parra_Step_Name": "Liz Earle Sales","Parra_Step_Batch": "20","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "480"},{"Parra_Step_ID": "4","Parra_Step_Name": "DA Invoice","Parra_Step_Batch": "16","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"},{"Parra_Step_ID": "5","Parra_Step_Name": "Budget Weekly","Parra_Step_Batch": "84","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"},{"Parra_Step_ID": "6","Parra_Step_Name": "Budget Monthly","Parra_Step_Batch": "83","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"},{"Parra_Step_ID": "7","Parra_Step_Name": "Walgreens RSI","Parra_Step_Batch": "95","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"},{"Parra_Step_ID": "8","Parra_Step_Name": "Indonesia","Parra_Step_Batch": "97","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"}]}]}')
--WalmartBatchAdd
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',5,'S&OP Sales Data','Parra','{"Program_ID": "1","Steps": [{"Step_ID": "5","Step_Name": "S&OP Sales Data","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "S&M Manual Adjustments","Parra_Step_Batch": "0","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"},{"Parra_Step_ID": "2","Parra_Step_Name": "GB SAP Transactions","Parra_Step_Batch": "13","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "240"},{"Parra_Step_ID": "3","Parra_Step_Name": "Walmart","Parra_Step_Batch": "77","Parra_Step_Project_ID": "1800041583","Parra_Time_Delay": "480"},{"Parra_Step_ID": "4","Parra_Step_Name": "Mecca","Parra_Step_Batch": "79","Parra_Step_Project_ID": "1800041583","Parra_Time_Delay": "1"},{"Parra_Step_ID": "5","Parra_Step_Name": "Alshaya","Parra_Step_Batch": "81","Parra_Step_Project_ID": "1800041583","Parra_Time_Delay": "1"},{"Parra_Step_ID": "6","Parra_Step_Name": "Alshaya 2","Parra_Step_Batch": "85","Parra_Step_Project_ID": "1800041583","Parra_Time_Delay": "1"},{"Parra_Step_ID": "7","Parra_Step_Name": "Kohls","Parra_Step_Batch": "76","Parra_Step_Project_ID": "1800041583","Parra_Time_Delay": "1"},{"Parra_Step_ID": "8","Parra_Step_Name": "Walmart","Parra_Step_Batch": "78","Parra_Step_Project_ID": "1800041583","Parra_Time_Delay": "1"}]}]}')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',6,'GBMR UI Data','Parra','{"Program_ID": "1","Steps": [{"Step_ID": "6","Step_Name": "GBMR UI Data","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "GBMR UI Data","Parra_Step_Batch": "75","Parra_Step_Project_ID": "67","Parra_Time_Delay": "1"}]}]}') --UpdateJSON_CRQ69339
--INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',7,'Golden Record','Seq','{"Program_ID": "1","Steps": [{"Step_ID": "7","Step_Name": "Golden Record Data","Seq_or_Parra": "Seq","Batch_List": "87"}]}')
--INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',7,'Golden Record','Parra','{"Program_ID": "1","Steps": [{"Step_ID": "7","Step_Name": "Golden Record","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "Golden Record","Parra_Step_Batch": "87","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"}]}]}')
INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',7,'Golden Record','Parra','{"Program_ID": "1","Steps": [{"Step_ID": "7","Step_Name": "Golden Record","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "Golden Record","Parra_Step_Batch": "87","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"},{"Parra_Step_ID": "2","Parra_Step_Name": "Retailer STEP mapping","Parra_Step_Batch": "101","Parra_Step_Project_ID": "8002","Parra_Time_Delay": "1"}]}]}')

--**LegacyDaily(01-Nov-2021)**
--INSERT INTO #temp_cf_program_batch VALUES (2,'Legacy_Migration',1,'Legacy Migration Daily','Seq','{"Program_ID": "2","Steps": [{"Step_ID": "1","Step_Name": "Legacy Migration Daily","Seq_or_Parra": "Seq","Batch_List": "10"}]}')
INSERT INTO #temp_cf_program_batch VALUES (2,'Legacy_Migration',1,'Legacy Migration Daily','Parra','{"Program_ID": "2","Steps": [{"Step_ID": "1","Step_Name": "Legacy Migration Daily","Seq_or_Parra": "Parra","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "Legacy Migration Daily","Parra_Step_Batch": "10","Parra_Step_Project_ID": "69","Parra_Time_Delay": "1"}]}]}')
INSERT INTO #temp_cf_program_batch VALUES (2,'Legacy_Migration',2,'Legacy Promotion Daily','Seq','{"Program_ID": "2","Steps": [{"Step_ID": "2","Step_Name": "Legacy Promotion Daily","Seq_or_Parra": "Seq","Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "Legacy Promotion Daily","Parra_Step_Batch": "91","Parra_Step_Project_ID": "69","Parra_Time_Delay": "1"}]}]}')

--RPRS LOSS
--INSERT INTO #temp_cf_program_batch VALUES (1,'Global Brands',8,'RPRS','Seq','{"Program_ID": "1","Steps": [{"Step_ID": "8","Step_Name": "RPRS","Seq_or_Parra": "Parra","Parra_Details":[{"Parra_Step_ID": "1","Parra_Step_Name": "RPRS LOSS","Parra_Step_Batch": "96","Parra_Step_Project_ID": "1800052452","Parra_Time_Delay": "1"}]}]}')
insert into psa.cf_program_batch values ('3','RPRS','1','RPRS_Loss','Parra','{"Program_ID": "3","Steps": [{"Step_ID": "1","Step_Name": "RPRS_Loss","Seq_or_Parra": "Parra",
"Parra_Details": [{"Parra_Step_ID": "1","Parra_Step_Name": "Legacy Migration Daily",
"Parra_Step_Batch": "96","Parra_Step_Project_ID": "1800052452","Parra_Time_Delay": "1"}]}]}')

--RPRS MERCH

insert into psa.cf_program_batch values ('3','RPRS','2','RPRS_Merch','Parra','{"Program_ID": "3","Steps": [{"Step_ID": "2","Step_Name": "RPRS_Merch","Seq_or_Parra": "Parra",
"Parra_Details": [{"Parra_Step_ID": "2","Parra_Step_Name": " RPRS_Merch ",
"Parra_Step_Batch": "100","Parra_Step_Project_ID": "1800052452","Parra_Time_Delay": "1"}]}]}')

INSERT INTO [psa].[cf_program_batch] 
select 
	[Program_ID],
	[Program_Name],
	[Program_Step_ID],
	[Program_Step_Name],
	[Program_Seq_or_Parra],
	[Program_JSON]
from #temp_cf_program_batch s
WHERE NOT EXISTS (select [Program_ID],[Program_Step_ID] from [psa].[cf_program_batch] t
					WHERE s.[Program_ID] = t.[Program_ID]
					AND s.[Program_Step_ID] = t.[Program_Step_ID])


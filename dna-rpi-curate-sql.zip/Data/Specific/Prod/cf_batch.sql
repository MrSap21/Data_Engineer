﻿/**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

2021         :  Steve Blakemore	  Inital Version
01-11-2021   :  Gourik Nandy      Modified Version (code changes mentioned below and labeled as **Intactix(01-Nov-2021)**)
                                  Purpose : Intactix jobs will be removed from Batch id 10 and will be created as a separate batch								  
29-06-2023   :  Shivangi Arora    Modified Version (code changes mentioned below and labeled as **Retailer to STEP mapping**)
                                  Purpose : Created a new batch for Retailer to STEP mapping stored procedure
**************************************************************************************************************************/

IF OBJECT_ID('tempdb..#cf_batch') IS NOT NULL
  DROP TABLE #cf_batch

CREATE TABLE #cf_batch
(
	[batch_id] [int] NOT NULL,
	[batch_name] [nchar](100) NULL,
	[feed_id] [int] NOT NULL,
	[order_of_execution] [int] NOT NULL,
	[active_flag] [smallint] NOT NULL,
	[dt_created] [smalldatetime] NULL,
	[user_created] [nchar](100) NULL
)

INSERT INTO #cf_batch VALUES(0,'GB SAP',393,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',394,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',395,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',396,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP',397,5,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP TRANSACTION',391,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP TRANSACTION',392,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'LIZ EARLE',390,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BUK SAP',253,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAP PRODUCT MASTER',301,1,1,@insert_date,@insert_user)

--GB SAP Customer
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',403,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',404,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',406,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',407,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',408,5,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',409,6,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Customer',405,7,1,@insert_date,@insert_user)

--Currency conversion
INSERT INTO #cf_batch VALUES(0,'GlobalBrandsCurrencyConversionRates Incremental',401,1,1,@insert_date,@insert_user)

--DA Invoice Sales
INSERT INTO #cf_batch VALUES(0,'GB MI DA_Invoice Transaction',402,1,1,@insert_date,@insert_user)

--LE Store
INSERT INTO #cf_batch VALUES(0,'LizEarleStore',412,1,1,@insert_date,@insert_user)

--GB SAP Finance GL
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL BKPF',419,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL BSEG',420,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL SKAT',421,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL CEPT',422,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SAPFinanceGL CE41000_ACCT',423,1,1,@insert_date,@insert_user)

--DA COGS
INSERT INTO #cf_batch VALUES(0,'DA COGS Material Document Invoice',416,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'DA COGS Material Document Invoice',417,2,1,@insert_date,@insert_user)

--LE SALES
INSERT INTO #cf_batch VALUES(0,'LIZ EARLE Sales',418,1,1,@insert_date,@insert_user)

--Calendar
INSERT INTO #cf_batch VALUES(0,'Calendar',254,1,1,@insert_date,@insert_user);
INSERT INTO #cf_batch VALUES(0,'GBFIN_Calendar_incr',2449,1,1,@insert_date,@insert_user);

--WAG product
INSERT INTO #cf_batch VALUES(0,'WAG product History',98,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG product Incremental',275,1,1,@insert_date,@insert_user)

--WAG store
--INSERT INTO #cf_batch VALUES(0,'WAG store History',95,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG store Incremental',289,1,1,@insert_date,@insert_user)

--WAG 
INSERT INTO #cf_batch VALUES(0,'WAG basket History',101,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG basket Incremental',287,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG ebasket History',111,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG ebasket Incremental',285,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transaction History',110,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transaction Incremental',295,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransaction History',103,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransaction Incremental',283,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transactioncost History',99,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG transactioncost Incremental',293,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransactioncost History',100,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'WAG etransactioncost Incremental',290,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'walgreens RSI daily sales',2450,1,1,@insert_date,@insert_user)

--Indonesia
INSERT INTO #cf_batch VALUES(0,'Indonesia weekly sales transaction',2478,1,1,@insert_date,@insert_user)

--GBFINRetailer
INSERT INTO #cf_batch VALUES(0,'GBFINRetailerIncremental',257,1,1,@insert_date,@insert_user)

--GBFINStoreMaster
INSERT INTO #cf_batch VALUES(0,'GBFINStoreMasterIncremental',300,1,1,@insert_date,@insert_user)

--Dermstore
INSERT INTO #cf_batch VALUES(0,'Dermstore history',114,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Dermstore incremental',256,1,1,@insert_date,@insert_user)

--Skinstore
INSERT INTO #cf_batch VALUES(0,'Skinstore No7 history',104,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Skinstore No7 incremental',264,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Skinstore SG history',107,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Skinstore SG incremental',263,1,1,@insert_date,@insert_user)

--SDM
INSERT INTO #cf_batch VALUES(0,'SDMSGStoreSales History',116,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMSGESales History',112,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7StoreSales History',113,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7ESales History',115,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMSGStoreSales Incremental',259,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMSGESales Incremental',260,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7StoreSales Incremental',261,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'SDMNo7ESales Incremental',262,1,1,@insert_date,@insert_user)

--TSG
INSERT INTO #cf_batch VALUES(0,'TSGAAFES History',94,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGMCXNo7 History',96,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGNEXCOM History',117,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGAAFES Incremental',298,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGMCXNo7 Incremental',266,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'TSGNEXCOM Incremental',265,1,1,@insert_date,@insert_user)

--Target
INSERT INTO #cf_batch VALUES(0,'Target History',247,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'Target Incremental',297,1,1,@insert_date,@insert_user)

--ULTA
INSERT INTO #cf_batch VALUES(0,'ULTAEDI History',118,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'ULTAEDI Incremental',299,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'ULTAWEB History',102,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'ULTAWEB Incremental',267,1,1,@insert_date,@insert_user)

--Baozun 
INSERT INTO #cf_batch VALUES(0,'BaozunSalesHistory',279,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BaozunSalesIncremental',278,1,1,@insert_date,@insert_user)

--BUK TransactionLineAnon and TransactionLineCard OneTimeUpdateActivity
INSERT INTO #cf_batch VALUES(0,'BUK TransactionLineAnon Onetime',553,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'BUK TransactionLineCard Onetime',556,1,1,@insert_date,@insert_user)

--GBMR UI
INSERT INTO #cf_batch VALUES(0,'GBMR UI',557,1,1,@insert_date,@insert_user)

--TeamCenter Product
INSERT INTO #cf_batch VALUES(0,'TeamCenterProduct',458,1,1,@insert_date,@insert_user)

-- New Set of Batches for Global Brands

-- GBA

INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',283,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',295,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',290,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',293,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GBA Walgreens',289,5,1,@insert_date,@insert_user)

-- S&M

INSERT INTO #cf_batch VALUES(0,'GB SM',407,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',405,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',408,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',409,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',406,5,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',403,6,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',404,7,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',411,8,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',413,9,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',414,10,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SM',415,11,1,@insert_date,@insert_user)

INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',421,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',422,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',423,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',419,4,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB SAP Invoice',420,5,1,@insert_date,@insert_user)


-- Golden Record

--INSERT INTO #cf_batch VALUES(0,'GB GOLDEN RECORD',397,8,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'GB GOLDEN RECORD',-1,1,1,@insert_date,@insert_user)
--**Intactix(01-Nov-2021)**
INSERT into #cf_batch VALUES(0,'Intactix',201,1,1,@insert_date,'@insert_user')
INSERT into #cf_batch VALUES(0,'Intactix',199,2,1,@insert_date,'@insert_user')
INSERT into #cf_batch VALUES(0,'Intactix',198,3,1,@insert_date,'@insert_user')
INSERT into #cf_batch VALUES(0,'Intactix',200,4,1,@insert_date,'@insert_user')

--TPM
INSERT INTO #cf_batch VALUES(0,'TPM MBEW',2228,1,1,@insert_date,@insert_user)

--STEP
INSERT INTO #cf_batch VALUES(0,'STEP',2397,1,1,@insert_date,@insert_user)


--RPRS
--RPRS LOSS
INSERT INTO #cf_batch VALUES(0,'RPRS LOSS',2469,1,1,@insert_date,@insert_user)

--RPRS CUSTOMER
INSERT INTO #cf_batch VALUES(0,'RPRS Customer',2624,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'RPRS Customer',2625,1,1,@insert_date,@insert_user)

--RPRS MERCH

INSERT INTO #cf_batch VALUES(0,'RPRS_Merch',2474,1,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'RPRS_Merch',2473,3,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'RPRS_Merch',2477,2,1,@insert_date,@insert_user)
INSERT INTO #cf_batch VALUES(0,'RPRS_Merch',2475,4,1,@insert_date,@insert_user)

--Product Exclusion
INSERT INTO #cf_batch VALUES(0,'Exclusion Weekly Transaction',2637,1,1,@insert_date,@insert_user)

--Retailer to STEP mapping
INSERT INTO #cf_batch VALUES(0,'GB RETAILER_STEP_MAPPING',-2,1,1,@insert_date,@insert_user)

INSERT INTO [psa].[cf_batch] 
select 
	max_batch_id + distinct_match.new_row_id as [batch_id],
	s.[batch_name],
	s.[feed_id],
	s.[order_of_execution],
	s.[active_flag],
	s.[dt_created],
	s.[user_created]
from #cf_batch s
inner join (select max([batch_id]) max_batch_id from [psa].[cf_batch]) qry ON (1=1)
inner join (select [batch_name], row_number() OVER (ORDER BY batch_name) as new_row_id from #cf_batch
			where [batch_name] NOT IN (select distinct [batch_name] from [psa].[cf_batch])
			 group by [batch_name]) distinct_match ON (distinct_match.[batch_name] = s.[batch_name])
WHERE NOT EXISTS (select [batch_name],[order_of_execution] from [psa].[cf_batch] t
					WHERE s.[batch_name] = t.[batch_name]
					AND s.[order_of_execution] = t.[order_of_execution])
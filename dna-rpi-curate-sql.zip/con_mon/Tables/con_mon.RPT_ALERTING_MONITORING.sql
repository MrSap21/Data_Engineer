﻿/****** Object:  Table [con_mon].[RPT_ALERTING_MONITORING]    Script Date: 5/25/2023 7:24:30 AM ******/

CREATE TABLE [con_mon].[RPT_ALERTING_MONITORING]
(
	[Table_Name] [varchar](200) NULL,
	[Stored_Procedure_Name] [varchar](200) NULL,
	[Query_Description] [nvarchar](2000) NULL,
	[Query_Run_Date] [datetime2](7) NULL,
	[Returned_Row_Count] [bigint] NULL,
	[Row_Count_Expected] [char](1) NULL,
	[Alert_Flag] [int] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
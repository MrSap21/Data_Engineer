﻿create table con_mon.process_etl_messages
(
RuleEntityInstanceID	BIGINT,
Monitor_ID				BIGINT,
Project_ID				BIGINT,
Feed_ID					BIGINT,
Entity_Code				NVARCHAR(32),
Attribute_Name			NVARCHAR(128),
Attribute_Description	NVARCHAR(1024),
Rule_Name				NVARCHAR(128),
Rule_Detail				NVARCHAR(4000),
Time_Created			DATETIME,
ETLRunLogID				BIGINT,
PSARowKey				BIGINT
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

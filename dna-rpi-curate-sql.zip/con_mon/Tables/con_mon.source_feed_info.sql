﻿CREATE TABLE [con_mon].[source_feed_info](
	[ProjectID] [bigint] NOT NULL,
	[FeedID] [bigint] NOT NULL,
	[FeedDescription] [varchar](2000) NULL,
	[EntityID] [bigint] NOT NULL,
	[EntityCode] [varchar](2000) NULL,
	[TargetMapping1] [bigint] NULL,
	[TargetMapping2] [bigint] NULL,
	[TargetMapping3] [bigint] NULL,
	[TargetMapping4] [bigint] NULL,
	[TargetMapping5] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

﻿CREATE TABLE [con_mon].[Asset_History](
	[Project_ID] [bigint] NOT NULL,
	[Feed_ID] [bigint] NOT NULL,
	[AssetID] [bigint] NOT NULL,
	[AssetName] [nvarchar](500) NOT NULL,
	[FileIngestedDateTime] [datetime] NULL,
	[LastStage] [nvarchar](100) NULL,
	[LastStageTime] [datetime] NULL,
	[FileTrafficLight] [nvarchar](100) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

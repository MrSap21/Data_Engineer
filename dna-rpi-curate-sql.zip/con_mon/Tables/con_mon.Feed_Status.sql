﻿CREATE TABLE con_mon.Feed_Status
(
Monitor_ID			BIGINT,
Feed_ID				BIGINT,
Feed_Frequency			VARCHAR(30),
Feed_Status_TrafficLight	VARCHAR(20),
Last_File_Asset_No		BIGINT,
Last_File_Name			VARCHAR(500),
Last_File_Arrived_Date_Time	DATETIME,
Current_Stage			VARCHAR(30),
Current_Stage_Time		DATETIME,
Feed_Status_Description		VARCHAR(500),
Feed_Up_To_Date			BIT,
Feed_Active			BIT,
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
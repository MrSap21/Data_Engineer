﻿create table con_mon.reconcile_results
(
Monitor_ID		BIGINT,
Project_ID		BIGINT,
Feed_ID			BIGINT,
Asset_ID		BIGINT,
Asset_Name		NVARCHAR(500),
Reconcile_Type	NVARCHAR(100),
Pass_Ind		BIT,
Result			NVARCHAR(4000)
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

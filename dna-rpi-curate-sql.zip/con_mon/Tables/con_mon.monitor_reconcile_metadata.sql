﻿create table con_mon.monitor_reconcile_metadata
(
monitor_reconcile_metadata_ID	BIGINT IDENTITY(1,1),
Project_ID						BIGINT NOT NULL,
Feed_ID							BIGINT NOT NULL,
Reconcile_Type					NVARCHAR(200) NOT NULL,
ProcSchema						NVARCHAR(100) NULL,
ProcName						NVARCHAR(200) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)

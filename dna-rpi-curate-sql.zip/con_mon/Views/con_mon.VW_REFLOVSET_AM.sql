﻿/****** Object:  View [con_mon].[VW_REFLOVSET_AM]    Script Date: 5/25/2023 8:57:08 AM ******/

CREATE VIEW [con_mon].[VW_REFLOVSET_AM]
AS (
	SELECT
		COUNT(*) OVER (PARTITION BY LOVSetId) AS DUPES
		,RecordSourceId
		,DTCreated
		,LOVSetId
		,LOVSetName
		,LOVSetDescription
		,LOVSetSequence
		,ActiveFlag
		,UserCreated
		,ETLRunLogId
	FROM
		ser.RefLOVSet
	WHERE
		ActiveFlag = 1
);
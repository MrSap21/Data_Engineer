﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_POSITION_DISTINCT_AM]    Script Date: 5/25/2023 7:20:21 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_POSITION_DISTINCT_AM]
AS (
SELECT DISTINCT
		PlanogramId
		,PlanogramFixtureId
		,ProductId
		,PlanogramPositionId
		,SourceKey
	FROM
		con_mon.VW_PLANOGRAM_POSITION_AM
);
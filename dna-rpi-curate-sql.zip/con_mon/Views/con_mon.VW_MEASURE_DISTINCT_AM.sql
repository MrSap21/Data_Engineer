﻿/****** Object:  View [con_mon].[VW_MEASURE_DISTINCT_AM]    Script Date: 5/26/2023 2:10:28 PM ******/

CREATE VIEW [con_mon].[VW_MEASURE_DISTINCT_AM]
AS (
	SELECT DISTINCT
		RECORD_SOURCE_KEY
		,MEASURE_TYPE_KEY
		,MeasureName
		,MeasureId
	FROM
		con_mon.VW_MEASURE_AM
	 
);
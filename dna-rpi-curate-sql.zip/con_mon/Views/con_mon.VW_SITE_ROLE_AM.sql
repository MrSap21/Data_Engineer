﻿/****** Object:  View [con_mon].[VW_SITE_ROLE_AM]    Script Date: 5/25/2023 7:23:01 AM ******/

CREATE VIEW [con_mon].[VW_SITE_ROLE_AM]
AS (
SELECT

	SR.LOVRecordSourceId
	,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
	,LOV_RS.LOVName AS RECORD_SOURCE_NAME

	,SR.LOVRoleId
	,LOV_ROLE.LOVKey AS ROLE_KEY
	,LOV_ROLE.LOVName AS ROLE_NAME

	,SR.SourceKey
	,SR.SiteRoleId

	,SR.SiteId
	,SR.SiteRoleName
	,SR.SiteRoleShortName

	,SR.LOVSourceKeyTypeId
	,LOV_SK_TYPE.LOVKey AS SK_TYPE_KEY
	,LOV_SK_TYPE.LOVName AS SK_TYPE_NAME

	,SR.SCDStartDate
	,SR.SCDEndDate
	,SR.SCDActiveFlag
	,SR.SCDVersion
	,SR.SCDLOVRecordSourceId
	,SR.ETLRunLogId
	,SR.PSARowKey

FROM
	ser.SiteRole AS SR

	LEFT JOIN ser.RefLOV AS LOV_RS
	ON SR.LOVRecordSourceId = LOV_RS.LOVId
	AND LOV_RS.ActiveFlag = 1

	LEFT JOIN ser.RefLOV AS LOV_SK_TYPE
	ON SR.LOVSourceKeyTypeId = LOV_SK_TYPE.LOVId
	AND LOV_SK_TYPE.ActiveFlag = 1

	LEFT JOIN ser.RefLOV AS LOV_ROLE
	ON SR.LOVRoleId = LOV_ROLE.LOVId
	AND LOV_ROLE.ActiveFlag = 1
);
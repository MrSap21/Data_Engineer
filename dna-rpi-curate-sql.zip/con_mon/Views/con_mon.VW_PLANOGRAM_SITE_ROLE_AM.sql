﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_SITE_ROLE_AM]    Script Date: 5/25/2023 7:21:58 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_SITE_ROLE_AM]
AS (
SELECT
		--COUNT(*) OVER (PARTITION BY P2SR.PlanogramSiteRoleId) AS ROW_COUNT

		P2SR.LOVRecordSourceId
		,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
		,LOV_RS.LOVName AS RECORD_SOURCE_NAME

		,P2SR.PlanogramSiteRoleId
		,P2SR.PlanogramId
		,P2SR.SiteRoleId

		,P2SR.SCDStartDate
		,P2SR.SCDEndDate
		,P2SR.SCDActiveFlag
		,P2SR.SCDVersion
		,P2SR.SCDLOVRecordSourceId
		,P2SR.ETLRunLogId
		,P2SR.PSARowKey

	FROM
		ser.PlanogramSiteRole AS P2SR

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON P2SR.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

	--WHERE
	--	LOV_RS.LOVKey = N''BTCBY''
);
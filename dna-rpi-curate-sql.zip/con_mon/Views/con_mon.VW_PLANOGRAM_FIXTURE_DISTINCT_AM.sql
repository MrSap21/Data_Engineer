﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_FIXTURE_DISTINCT_AM]    Script Date: 5/25/2023 11:19:19 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_FIXTURE_DISTINCT_AM]
AS (
	SELECT DISTINCT
		PlanogramFixtureId
		,PlanogramId
		,SourceKey
	FROM
		[con_mon].[VW_PLANOGRAM_FIXTURE_AM] as VW_FIX
	
);
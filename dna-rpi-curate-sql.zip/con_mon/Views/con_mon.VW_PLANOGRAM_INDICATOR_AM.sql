﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_INDICATOR_AM]    Script Date: 5/25/2023 8:55:23 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_INDICATOR_AM]
AS (
	SELECT
		COUNT(*) OVER (PARTITION BY P_IND.PlanogramId, P_IND.LOVIndicatorId) AS ROW_COUNT

		,P_IND.LOVRecordSourceId
		,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
		,LOV_RS.LOVName AS RECORD_SOURCE_NAME

		,P_IND.PlanogramId

		,P_IND.LOVIndicatorId
		,LOV_IND.LOVKey AS IND_KEY
		,LOV_IND.LOVName AS IND_NAME

		,P_IND.Value

		,P_IND.SCDStartDate
		,P_IND.SCDEndDate
		,P_IND.SCDActiveFlag
		,P_IND.SCDVersion
		,P_IND.SCDLOVRecordSourceId
		,P_IND.ETLRunLogId
		,P_IND.PSARowKey

	FROM
		ser.PlanogramIndicator AS P_IND

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON P_IND.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

		LEFT JOIN ser.RefLOV AS LOV_IND
		ON P_IND.LOVIndicatorId = LOV_IND.LOVId
		AND LOV_IND.ActiveFlag = 1
);
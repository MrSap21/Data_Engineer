﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM]    Script Date: 5/25/2023 8:54:14 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM]
AS (
	SELECT
		 
		FP_SECT.LOVRecordSourceId
		,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
		,LOV_RS.LOVName AS RECORD_SOURCE_NAME

		,FP_SECT.LOVSourceKeyTypeId
		,LOV_SK_TYPE.LOVKey AS SK_TYPE_KEY
		,LOV_SK_TYPE.LOVName AS SK_TYPE_NAME

		,FP_SECT.PlanogramFloorPlanSectionId
		,FP_SECT.PlanogramFloorPlanId
		,FP_SECT.SourceKey

		,FP_SECT.SegmentStart
		,FP_SECT.HostPlanogram

		,FP_SECT.SCDStartDate
		,FP_SECT.SCDEndDate
		,FP_SECT.SCDActiveFlag
		,FP_SECT.SCDVersion
		,FP_SECT.SCDLOVRecordSourceId
		,FP_SECT.ETLRunLogId
		,FP_SECT.PSARowKey

	FROM
		ser.PlanogramFloorPlanSection AS FP_SECT

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON FP_SECT.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

		LEFT JOIN ser.RefLOV AS LOV_SK_TYPE
		ON FP_SECT.LOVSourceKeyTypeId = LOV_SK_TYPE.LOVId
		AND LOV_SK_TYPE.ActiveFlag = 1

	WHERE
		LOV_RS.LOVKey = N'BTCBY'
);
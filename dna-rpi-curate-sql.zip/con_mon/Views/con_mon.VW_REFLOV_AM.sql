﻿/****** Object:  View [con_mon].[VW_REFLOV_AM]    Script Date: 5/25/2023 9:05:50 AM ******/

CREATE VIEW [con_mon].[VW_REFLOV_AM]
AS (
	SELECT
		COUNT(*) OVER (PARTITION BY LOVId) AS DUPES
		,RecordSourceId
		,DTCreated
		,LOVId
		,LOVSetId
		,LOVKey
		,LOVName
		,LOVDescription
		,LOVSequence
		,ETLRunLogId
		,ActiveFlag
		,UserCreated
	FROM
		ser.RefLOV
	WHERE
		ActiveFlag = 1
);
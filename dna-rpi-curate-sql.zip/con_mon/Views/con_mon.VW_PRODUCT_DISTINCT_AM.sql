﻿/****** Object:  View [con_mon].[VW_PRODUCT_DISTINCT_AM]    Script Date: 5/25/2023 9:04:59 AM ******/

CREATE VIEW [con_mon].[VW_PRODUCT_DISTINCT_AM]
AS (
	SELECT DISTINCT
		RECORD_SOURCE_KEY
		,SK_TYPE_KEY
		,SourceKey
		,ProductId
	FROM
		con_mon.VW_Product_AM
);
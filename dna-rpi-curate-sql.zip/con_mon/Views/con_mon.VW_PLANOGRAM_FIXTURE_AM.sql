﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_FIXTURE_AM]    Script Date: 5/25/2023 11:18:45 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_FIXTURE_AM]
AS (
	SELECT
		FIX.LOVRecordSourceId
		,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
		,LOV_RS.LOVName AS RECORD_SOURCE_NAME

		,FIX.PlanogramFixtureId
		,FIX.PlanogramId
		,FIX.SourceKey

		,FIX.SCDStartDate
		,FIX.SCDEndDate
		,FIX.SCDActiveFlag
		,FIX.SCDVersion
		,FIX.SCDLOVRecordSourceId
		,FIX.ETLRunLogId
		,FIX.PSARowKey

	FROM
		ser.PlanogramFixture AS FIX

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON FIX.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

	--WHERE
		--LOV_RS.LOVKey = N''BTCBY''
);
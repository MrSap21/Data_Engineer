﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_AM]    Script Date: 5/25/2023 11:16:51 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_AM]
AS (
SELECT
		POG.LOVRecordSourceId
		,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
		,LOV_RS.LOVName AS RECORD_SOURCE_NAME

		,POG.LOVSourceKeyTypeId
		,LOV_SK_TYPE.LOVKey AS SK_TYPE_KEY
		,LOV_SK_TYPE.LOVName AS SK_TYPE_NAME

		,POG.PlanogramId
		,POG.SourceKey
		,POG.PlanogramName

		,POG.PlanogramStartDate
		,POG.PlanogramEndDate

		,POG.ParentPlanogramId

		,POG.SCDStartDate
		,POG.SCDEndDate
		,POG.SCDActiveFlag
		,POG.SCDVersion
		,POG.SCDLOVRecordSourceId
		,POG.ETLRunLogId
		,POG.PSARowKey

	FROM
		ser.Planogram AS POG

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON POG.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

		LEFT JOIN ser.RefLOV AS LOV_SK_TYPE
		ON POG.LOVSourceKeyTypeId = LOV_SK_TYPE.LOVId
		AND LOV_SK_TYPE.ActiveFlag = 1

	--WHERE
	--	LOV_RS.LOVKey = N''BTCBY''
);
﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_DISTINCT_AM]    Script Date: 5/25/2023 11:18:21 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_DISTINCT_AM]
AS (
	SELECT DISTINCT

		RECORD_SOURCE_KEY
		,SK_TYPE_KEY
		,SourceKey
		,PlanogramId
	FROM
		con_mon.[VW_PLANOGRAM_AM]
);
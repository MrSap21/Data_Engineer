﻿/****** Object:  View [con_mon].[VW_PRODUCT_AM]    Script Date: 5/25/2023 9:03:34 AM ******/

CREATE VIEW [con_mon].[VW_PRODUCT_AM]
AS (
	SELECT

		PROD.LOVRecordSourceId
		,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
		,LOV_RS.LOVName AS RECORD_SOURCE_NAME

		,PROD.LOVSourceKeyTypeId
		,LOV_SK_TYPE.LOVKey AS SK_TYPE_KEY
		,LOV_SK_TYPE.LOVName AS SK_TYPE_NAME

		,PROD.SourceKey
		,PROD.ProductId

		,PROD.ProductName
		,PROD.ProductDescription
		,PROD.LOVBrandId
		,PROD.LOVSubBrandId
		,PROD.ParentProductId

		,PROD.SCDStartDate
		,PROD.SCDEndDate
		,PROD.SCDActiveFlag
		,PROD.SCDVersion
		,PROD.SCDLOVRecordSourceId
		,PROD.ETLRunLogId
		,PROD.PSARowKey

	FROM
		ser.Product AS PROD

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON PROD.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

		LEFT JOIN ser.RefLOV AS LOV_SK_TYPE
		ON PROD.LOVSourceKeyTypeId = LOV_SK_TYPE.LOVId
		AND LOV_SK_TYPE.ActiveFlag = 1
);
﻿/****** Object:  View [con_mon].[VW_SITE_ROLE_DISTINCT_AM]    Script Date: 5/25/2023 7:23:32 AM ******/

CREATE VIEW [con_mon].[VW_SITE_ROLE_DISTINCT_AM]
AS (
SELECT DISTINCT
	RECORD_SOURCE_KEY
	,ROLE_KEY
	,SourceKey
	,SiteRoleId
FROM
	con_mon.VW_SITE_ROLE_AM
);
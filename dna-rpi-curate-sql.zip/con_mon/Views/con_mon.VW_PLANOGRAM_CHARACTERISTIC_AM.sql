﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM]    Script Date: 5/25/2023 11:17:44 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM]
AS (
	SELECT

		 P_CHAR.LOVRecordSourceId
		,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
		,LOV_RS.LOVName AS RECORD_SOURCE_NAME

		,P_CHAR.PlanogramId

		,P_CHAR.LOVCharacteristicId
		,LOV_CHAR.LOVKey AS CHAR_KEY
		,LOV_CHAR.LOVName AS CHAR_NAME

		,P_CHAR.Value

		,P_CHAR.SCDStartDate
		,P_CHAR.SCDEndDate
		,P_CHAR.SCDActiveFlag
		,P_CHAR.SCDVersion
		,P_CHAR.SCDLOVRecordSourceId
		,P_CHAR.ETLRunLogId
		,P_CHAR.PSARowKey

	FROM
		ser.PlanogramCharacteristic AS P_CHAR

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON P_CHAR.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

		LEFT JOIN ser.RefLOV AS LOV_CHAR
		ON P_CHAR.LOVCharacteristicId = LOV_CHAR.LOVId
		AND LOV_CHAR.ActiveFlag = 1
);
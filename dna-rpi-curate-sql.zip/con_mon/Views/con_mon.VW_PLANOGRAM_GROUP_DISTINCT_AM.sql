﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_GROUP_DISTINCT_AM]    Script Date: 5/25/2023 8:57:00 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_GROUP_DISTINCT_AM]
AS (
	SELECT DISTINCT
		RECORD_SOURCE_KEY
		,PlanogramId
		,GROUP_SET_NAME
		,PlanogramGroupId
	FROM
		con_mon.VW_PLANOGRAM_GROUP_AM
	
);
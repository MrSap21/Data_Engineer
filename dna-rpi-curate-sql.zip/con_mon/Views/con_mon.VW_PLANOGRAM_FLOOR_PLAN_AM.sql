﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM]    Script Date: 5/25/2023 11:19:47 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM]
AS (
	SELECT
		FP.LOVRecordSourceId
		,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
		,LOV_RS.LOVName AS RECORD_SOURCE_NAME

		,FP.LOVSourceKeyTypeId
		,LOV_SK_TYPE.LOVKey AS SK_TYPE_KEY
		,LOV_SK_TYPE.LOVName AS SK_TYPE_NAME

		,FP.PlanogramFloorPlanId
		,FP.SourceKey
		,FP.ParentPlanogramId

		,FP.PlanogramSiteRoleId
		,FP.FloorLevel
		,FP.FloorPlanName
		,FP.FloorPlanStartDate
		,FP.FloorPlanEndDate
		,FP.ParentPlanogramFloorPlanId

		,FP.SCDStartDate
		,FP.SCDEndDate
		,FP.SCDActiveFlag
		,FP.SCDVersion
		,FP.SCDLOVRecordSourceId
		,FP.ETLRunLogId
		,FP.PSARowKey

	FROM
		ser.PlanogramFloorPlan AS FP

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON FP.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

		LEFT JOIN ser.RefLOV AS LOV_SK_TYPE
		ON FP.LOVSourceKeyTypeId = LOV_SK_TYPE.LOVId
		AND LOV_SK_TYPE.ActiveFlag = 1
);
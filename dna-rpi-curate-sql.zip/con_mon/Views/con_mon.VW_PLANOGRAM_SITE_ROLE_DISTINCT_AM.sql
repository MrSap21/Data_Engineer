﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_SITE_ROLE_DISTINCT_AM]    Script Date: 5/25/2023 7:22:26 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_SITE_ROLE_DISTINCT_AM]
AS (
SELECT DISTINCT
		PlanogramSiteRoleId
		,PlanogramId
		,SiteRoleId
	FROM
		con_mon.VW_PLANOGRAM_SITE_ROLE_AM
);
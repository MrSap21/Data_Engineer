﻿/****** Object:  View [con_mon].[VW_PLANOGRAM_POSITION_AM]    Script Date: 5/25/2023 7:19:48 AM ******/

CREATE VIEW [con_mon].[VW_PLANOGRAM_POSITION_AM]
AS (
SELECT
		POS.LOVRecordSourceId
		,LOV_RS.LOVKey AS RECORD_SOURCE_KEY
		,LOV_RS.LOVName AS RECORD_SOURCE_NAME

		,POS.PlanogramPositionId
		,POS.PlanogramId
		,POS.PlanogramFixtureId
		,POS.ProductId
		,POS.SourceKey
		,POS.SCDStartDate
		,POS.SCDEndDate
		,POS.SCDActiveFlag
		,POS.SCDVersion
		,POS.SCDLOVRecordSourceId
		,POS.ETLRunLogId
		,POS.PSARowKey

	FROM
		ser.PlanogramPosition AS POS

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON POS.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1
);
﻿/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_STATUS_AM]    Script Date: 5/25/2023 8:13:02 AM ******/

CREATE PROC [con_mon].[USP_PLANOGRAM_STATUS_AM] @P_RUN_DATE [DATETIME] AS
/*************************************************************************************************************************
Procedure Name					: USP_PLANOGRAM_STATUS_AM
Purpose							: UAT Automation Testing for ser.PlanogramStatus table		

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

25-05-2023   :  Rohit Shaw	          :Initial Version	
 
**************************************************************************************************************************/
 
BEGIN

DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_STATUS_AM';
DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.PlanogramStatus';
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;

 

---------------------------------------------------------------------------------------------------------
---- Check for how many delta changes have taken place in the table
---- Where STATUS_SET_NAME = 'POGStatus'

-----

SET @V_DELTA_COUNT_1 =
(
SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_STATUS_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
	AND STATUS_SET_NAME = N'POGStatus'
)
--SELECT @V_DELTA_COUNT_1 AS [@V_DELTA_COUNT_1]

SET @V_DELTA_COUNT_2 =
(
SELECT
	COUNT(*) AS DISTINCT_P_STATUSES
FROM
	(
		SELECT DISTINCT
			PlanogramId
			,LOVPlanogramStatusSetId
		FROM
			con_mon.VW_PLANOGRAM_STATUS_AM
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
			AND STATUS_SET_NAME = N'POGStatus'
	) AS DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

--SELECT @V_ROW_COUNT AS [@V_ROW_COUNT]

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for how many delta changes have taken place in the table Where STATUS_SET_NAME = ''POGStatus''', @P_RUN_DATE,@V_ROW_COUNT,'Y',@V_ALERT_FLAG);


------------------------------------------------------------------------------------------------------------------------------
---- Check for how many delta changes have taken place in the table
---- Where STATUS_SET_NAME = 'Planogram Status Type' and STATUS_KEY = 'Planogram Pending Date'

SET @V_DELTA_COUNT_1 =
(
SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_STATUS_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
	AND STATUS_SET_NAME = N'Planogram Status Type'
	AND STATUS_KEY = N'Planogram Pending Date'
)

SET @V_DELTA_COUNT_2 =
(

SELECT
	COUNT(*) AS DISTINCT_P_STATUSES
FROM
	(
		SELECT DISTINCT
			PlanogramId
			,LOVPlanogramStatusSetId
		FROM
			con_mon.VW_PLANOGRAM_STATUS_AM
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
			AND STATUS_SET_NAME = N'Planogram Status Type'
			AND STATUS_KEY = N'Planogram Pending Date'
	) AS DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]

VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for how many delta changes have taken place in the table Where STATUS_SET_NAME = ''Planogram Status Type''', @P_RUN_DATE,@V_ROW_COUNT,'Y',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------------------------

-- Test: Check for duplicate record sources
-- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'POGStatus'

 
SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	PlanogramId
	,LOVPlanogramStatusSetId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_STATUS_AM
WHERE
	STATUS_SET_NAME = N'POGStatus'
GROUP BY
	PlanogramId
	,LOVPlanogramStatusSetId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
 
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for duplicate record sources Where STATUS_SET_NAME = ''POGStatus''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

--------------------------------------------------------------------------------------------------------------------

-- Test: Check for duplicate record sources
-- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'Planogram Status Type' and STATUS_KEY = 'Planogram Pending Date'
SELECT @V_ROW_COUNT = COUNT(*) FROM
(

SELECT  
	PlanogramId
	,LOVPlanogramStatusSetId
	,LOVStatusId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_STATUS_AM
WHERE
	STATUS_SET_NAME = N'Planogram Status Type'
	AND STATUS_KEY = N'Planogram Pending Date'
GROUP BY
	PlanogramId
	,LOVPlanogramStatusSetId
	,LOVStatusId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
 )a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for duplicate record sources Where STATUS_SET_NAME = ''Planogram Status Type''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-----------------------------------------------------------------------------------------------------------------------------------
---- Test: Check for NULL start or end datetimes or active flags
---- Expected result: No rows returned
SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	*
FROM
	con_mon.VW_PLANOGRAM_STATUS_AM
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	AND RECORD_SOURCE_KEY = N'BTCBY'
 
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for NULL start or end datetimes or active flags', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for back-to-front start and end datetimes
---- Expected result: No rows returned
SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	*
FROM
	con_mon.VW_PLANOGRAM_STATUS_AM
WHERE
	-- In Curate each record is active from and including SCDStartDate up to but not including SCDEndDate + 1 second
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'
 
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for back-to-front start and end datetimes', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);


---------------------------------------------------------------------------------

---- Test: Check for rows with identical start and end datetimes
---- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'POGStatus'

-------
SELECT @V_ROW_COUNT = COUNT(*) FROM
(

SELECT  
	COUNT(*) AS DUPLICATES
	,PlanogramId
	,LOVPlanogramStatusSetId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_STATUS_AM
WHERE
	STATUS_SET_NAME = N'POGStatus'
GROUP BY
	PlanogramId
	,LOVPlanogramStatusSetId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1
 )a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for NULL start or end datetimes or active flags Where STATUS_SET_NAME = ''POGStatus''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for rows with identical start and end datetimes
---- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'Planogram Status Type' and STATUS_KEY = 'Planogram Pending Date'

 SELECT @V_ROW_COUNT = COUNT(*) FROM
(

SELECT  
	COUNT(*) AS DUPLICATES
	,PlanogramId
	,LOVPlanogramStatusSetId
	,LOVStatusId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_STATUS_AM
WHERE
	STATUS_SET_NAME = N'Planogram Status Type'
	AND STATUS_KEY = N'Planogram Pending Date'
GROUP BY
	PlanogramId
	,LOVPlanogramStatusSetId
	,LOVStatusId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1
 
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for NULL start or end datetimes or active flags Where STATUS_SET_NAME = ''Planogram Status Type''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for overlapping or underlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'POGStatus'
-- Check for SCD overlaps

 
SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT  
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*
			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
					,LOVPlanogramStatusSetId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_STATUS_AM

		WHERE
			STATUS_SET_NAME = N'POGStatus'

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate

	 
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for overlapping start-end periods Where STATUS_SET_NAME = ''POGStatus''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-- Check for SCD underlaps (i.e. gaps)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
					,LOVPlanogramStatusSetId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_STATUS_AM

		WHERE
			STATUS_SET_NAME = N'POGStatus'

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	
	---- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate
 
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for underlapping start-end periods Where STATUS_SET_NAME = ''POGStatus''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-----------------------------------------------------------------------------------------------------------------------------------
---- Test: Check for overlapping or underlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'Planogram Status Type' and STATUS_KEY = 'Planogram Pending Date'
-- Check for SCD overlaps
 
SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT  
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
					,LOVPlanogramStatusSetId
					,LOVStatusId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_STATUS_AM

		WHERE
			STATUS_SET_NAME = N'Planogram Status Type'
			AND STATUS_KEY = N'Planogram Pending Date'

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate

	 
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for overlapping start-end periods Where STATUS_SET_NAME = ''Planogram Status Type''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);


-- Check for SCD underlaps (i.e. gaps)

SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT TOP 1000
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
					,LOVPlanogramStatusSetId
					,LOVStatusId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_STATUS_AM

		WHERE
			STATUS_SET_NAME = N'Planogram Status Type'
			AND STATUS_KEY = N'Planogram Pending Date'

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	 

	---- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for underlapping start-end periods Where STATUS_SET_NAME = ''Planogram Status Type''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-------------------------------------------------------------------------------------------------------------------------------------
---- Test: Check for entities whose lives do not start on 1900-01-01
---- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'POGStatus'

 

WITH CTE_LATE_STARTS AS
(
	SELECT  
		PlanogramId
		,LOVPlanogramStatusSetId

	FROM
		con_mon.VW_PLANOGRAM_STATUS_AM

	WHERE
		STATUS_SET_NAME = N'POGStatus'

	GROUP BY
		PlanogramId
		,LOVPlanogramStatusSetId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
		 
)
SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_STATUS.*

FROM
	con_mon.VW_PLANOGRAM_STATUS_AM AS VW_STATUS

	INNER JOIN CTE_LATE_STARTS
	ON VW_STATUS.PlanogramId = CTE_LATE_STARTS.PlanogramId
	AND VW_STATUS.LOVPlanogramStatusSetId = CTE_LATE_STARTS.LOVPlanogramStatusSetId

 
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not start on 1900-01-01 Where STATUS_SET_NAME = ''POGStatus''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-------------------------------------------------------------------------------------------------------------------------------------
---- Test: Check for entities whose lives do not start on 1900-01-01
---- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'Planogram Status Type' and STATUS_KEY = 'Planogram Pending Date'
WITH CTE_LATE_STARTS AS
(
	SELECT  
		PlanogramId
		,LOVPlanogramStatusSetId
		,LOVStatusId

	FROM
		con_mon.VW_PLANOGRAM_STATUS_AM

	WHERE
		STATUS_SET_NAME = N'Planogram Status Type'
		AND STATUS_KEY = N'Planogram Pending Date'

	GROUP BY
		PlanogramId
		,LOVPlanogramStatusSetId
		,LOVStatusId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
		 
)
SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_STATUS.*

FROM
	con_mon.VW_PLANOGRAM_STATUS_AM AS VW_STATUS


	INNER JOIN CTE_LATE_STARTS
	ON VW_STATUS.PlanogramId = CTE_LATE_STARTS.PlanogramId
	AND VW_STATUS.LOVPlanogramStatusSetId = CTE_LATE_STARTS.LOVPlanogramStatusSetId
	AND VW_STATUS.LOVStatusId = CTE_LATE_STARTS.LOVStatusId

 )a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not start on 1900-01-01 Where STATUS_SET_NAME = ''Planogram Status Type''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not end on 9999-12-31
---- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'POGStatus'


WITH CTE_EARLY_ENDS AS
(
	SELECT  
		PlanogramId
		,LOVPlanogramStatusSetId

	FROM
		con_mon.VW_PLANOGRAM_STATUS_AM

	WHERE
		STATUS_SET_NAME = N'POGStatus'

	GROUP BY
		PlanogramId
		,LOVPlanogramStatusSetId

	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
		 
)
SELECT @V_ROW_COUNT = COUNT(*) FROM
(

SELECT
	VW_STATUS.*

FROM
	con_mon.VW_PLANOGRAM_STATUS_AM AS VW_STATUS

	INNER JOIN CTE_EARLY_ENDS
	ON VW_STATUS.PlanogramId = CTE_EARLY_ENDS.PlanogramId
	AND VW_STATUS.LOVPlanogramStatusSetId = CTE_EARLY_ENDS.LOVPlanogramStatusSetId
)a
SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not end on 9999-12-31 Where STATUS_SET_NAME = ''POGStatus''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not end on 9999-12-31
---- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'Planogram Status Type' and STATUS_KEY = 'Planogram Pending Date'

WITH CTE_EARLY_ENDS AS
(
	SELECT
		PlanogramId
		,LOVPlanogramStatusSetId
		,LOVStatusId

	FROM
		con_mon.VW_PLANOGRAM_STATUS_AM

	WHERE
		STATUS_SET_NAME = N'Planogram Status Type'
		AND STATUS_KEY = N'Planogram Pending Date'

	GROUP BY
		PlanogramId
		,LOVPlanogramStatusSetId
		,LOVStatusId

	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
		 
)
SELECT @V_ROW_COUNT = COUNT(*) FROM
(

SELECT
	VW_STATUS.*

FROM
	con_mon.VW_PLANOGRAM_STATUS_AM AS VW_STATUS

	INNER JOIN CTE_EARLY_ENDS
	ON VW_STATUS.PlanogramId = CTE_EARLY_ENDS.PlanogramId
	AND VW_STATUS.LOVPlanogramStatusSetId = CTE_EARLY_ENDS.LOVPlanogramStatusSetId
	AND VW_STATUS.LOVStatusId = CTE_EARLY_ENDS.LOVStatusId
)a
SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not end on 9999-12-31 Where STATUS_SET_NAME = ''Planogram Status Type''', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);


---------------------------------------------------------------------------------

-- Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
-- Expected result: No rows returned
SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	*

FROM
	con_mon.VW_PLANOGRAM_STATUS_AM

WHERE
	(
		(SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
		OR
		(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y')
	)

	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

END
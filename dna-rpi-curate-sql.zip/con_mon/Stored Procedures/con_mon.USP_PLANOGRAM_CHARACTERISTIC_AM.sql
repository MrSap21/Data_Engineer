﻿/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_CHARACTERISTIC_AM]    Script Date: 5/25/2023 11:10:24 AM ******/

CREATE PROC [con_mon].[USP_PLANOGRAM_CHARACTERISTIC_AM] @P_RUN_DATE [DATETIME] AS

/*************************************************************************************************************************
Procedure Name					: [USP_PLANOGRAM_CHARACTERISTIC_AM]
Purpose							: UAT Automation Testing for ser.PlanogramCharacteristic table		

**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

12-05-2023   : Nancy Khandelwal		   Inital Version

*************************************************************************************************************************/

BEGIN 

DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';

DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.PlanogramCharacteristic';
DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_CHARACTERISTIC_AM';
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;
DECLARE @V_TOTAL_CHAR_KEY BIGINT;

---------------------------------------------------------------------------------
-- Check for how many delta changes have taken place in the table

SET @V_DELTA_COUNT_1 =
(SELECT
	COUNT(*) AS THE_ROWS
FROM
	[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR
)

SET @V_DELTA_COUNT_2 = 
(SELECT
	COUNT(*) AS DISTINCT_P_CHARS
FROM
	(
		SELECT DISTINCT
			PlanogramId
			,LOVCharacteristicId
		FROM
			[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR
	) AS DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for how many delta changes have taken place in the table',@P_RUN_DATE,@V_ROW_COUNT,'Y',@V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for duplicate record sources
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	PlanogramId
	,LOVCharacteristicId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR
GROUP BY
	PlanogramId
	,LOVCharacteristicId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for duplicate record sources', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-------------------------------------------------------------------------------
-- Test: Check for NULL start or end datetimes or active flags
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	*
FROM
	[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	AND RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for NULL start or end datetimes or active flags', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-------------------------------------------------------------------------------
-- Test: Check for back-to-front start and end datetimes
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	*
FROM
	[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR
WHERE
	-- In Curate each record is active from and including SCDStartDate up to but not including SCDEndDate + 1 second
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for back-to-front start and end datetimes', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-------------------------------------------------------------------------------
-- Test: Check for rows with identical start and end datetimes
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	COUNT(*) AS DUPLICATES
	,PlanogramId
	,LOVCharacteristicId
	,SCDStartDate
	,SCDEndDate
FROM
	[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR
GROUP BY
	PlanogramId
	,LOVCharacteristicId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for rows with identical start and end datetimes', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-------------------------------------------------------------------------------
-- Test: Check for overlapping start-end periods
-- Prerequisites: Above tests must have passed
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	QRY_NEXT_START.*
FROM
	(
		SELECT
			*
			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
					,LOVCharacteristicId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for overlapping start-end periods', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-------------------------------------------------------------------------------
-- Test: Check for underlapping start-end periods
-- Prerequisites: Above tests must have passed
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	QRY_NEXT_START.*
FROM
	(
		SELECT
			*
			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
					,LOVCharacteristicId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for underlapping start-end periods', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-------------------------------------------------------------------------------
-- Test: Check for entities whose lives do not start on 1900-01-01
-- Expected result: No rows returned

WITH CTE_LATE_STARTS AS
(
	SELECT
		PlanogramId
		,LOVCharacteristicId

	FROM
		[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR

	GROUP BY
		PlanogramId
		,LOVCharacteristicId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	VW_CHAR.LOVRecordSourceId
	,VW_CHAR.RECORD_SOURCE_KEY

	,VW_CHAR.PlanogramId

	,VW_CHAR.LOVCharacteristicId
	,VW_CHAR.CHAR_NAME

	,VW_CHAR.Value

	,VW_CHAR.SCDStartDate
	,VW_CHAR.SCDEndDate
	,VW_CHAR.SCDActiveFlag
	,VW_CHAR.SCDVersion
	,VW_CHAR.SCDLOVRecordSourceId
	,VW_CHAR.ETLRunLogId
	,VW_CHAR.PSARowKey

FROM
	[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR

	INNER JOIN CTE_LATE_STARTS
	ON VW_CHAR.PlanogramId = CTE_LATE_STARTS.PlanogramId
	AND VW_CHAR.LOVCharacteristicId = CTE_LATE_STARTS.LOVCharacteristicId

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for entities whose lives do not start on 1900-01-01', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-------------------------------------------------------------------------------
-- Test: Check for entities whose lives do not end on 9999-12-31
-- Expected result: No rows returned

WITH CTE_EARLY_ENDS AS
(
	SELECT
		PlanogramId
		,LOVCharacteristicId

	FROM
		[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR

	GROUP BY
		PlanogramId
		,LOVCharacteristicId

	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
)
SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	VW_CHAR.LOVRecordSourceId
	,VW_CHAR.RECORD_SOURCE_KEY

	,VW_CHAR.PlanogramId

	,VW_CHAR.LOVCharacteristicId
	,VW_CHAR.CHAR_NAME

	,VW_CHAR.Value

	,VW_CHAR.SCDStartDate
	,VW_CHAR.SCDEndDate
	,VW_CHAR.SCDActiveFlag
	,VW_CHAR.SCDVersion
	,VW_CHAR.SCDLOVRecordSourceId
	,VW_CHAR.ETLRunLogId
	,VW_CHAR.PSARowKey

FROM
	[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR

	INNER JOIN CTE_EARLY_ENDS
	ON VW_CHAR.PlanogramId = CTE_EARLY_ENDS.PlanogramId
	AND VW_CHAR.LOVCharacteristicId = CTE_EARLY_ENDS.LOVCharacteristicId

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for entities whose lives do not end on 9999-12-31', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-------------------------------------------------------------------------------
-- Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	*
FROM
	[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR

WHERE
	((SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
	OR
	(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y'))

	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-------------------------------------------------------------------------------
-- Test: Check which distinct planogram characteristics are showing in the data
-- Expected result: 27 rows returned showing the following values for CHAR_KEY: 
--		Build Date
--		Comments
--		Fitting Type
--		Furniture Type
--		LM01 List Name
--		LM01 List Owner
--		MAP Family name
--		Mid Gondolas
--		Offer details
--		Planogram Messages
--		pogHead Layout Name
--		Reason for version
--		Sales Plan File Name
--		Sales Plan Finish Date
--		Sales Plan Offer Desc
--		Sales Plan Offer Desc_1
--		Sales Plan Offer Desc_2
--		Sales Plan Period No
--		Sales Plan Start Date
--		SAP Loaded Date
--		SM Codes_1
--		Space Planner Name
--		Sub-Format
--		URL of planogram documentation
--		**EDITED**
--		Acceptable but not mandatory char keys are
--		SM Codes_2
--		SM Codes_3
--		SM Codes_4


-- New test version, rewritten to be a set equality check. Split into two subset tests. 

-- Define expected and actual results sets as CTEs

WITH CTE_RS_SK_COMBOS_ACTUALS AS
(
SELECT DISTINCT
	CHAR_KEY
FROM
	[con_mon].[VW_PLANOGRAM_CHARACTERISTIC_AM] as VW_CHAR
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

,CTE_RS_SK_COMBOS_EXPECTED AS
(
	SELECT N'Build Date' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Comments' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Fitting Type' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Furniture Type' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'LM01 List Name' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'LM01 List Owner' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'MAP Family name' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Mid Gondolas' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Offer details' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Planogram Messages' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'pogHead Layout Name' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Reason for version' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Sales Plan File Name' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Sales Plan Finish Date' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Sales Plan Offer Desc' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Sales Plan Offer Desc_1' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Sales Plan Offer Desc_2' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Sales Plan Period No' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Sales Plan Start Date' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'SAP Loaded Date' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'SM Codes_1' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Space Planner Name' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'Sub-Format' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'URL of planogram documentation' AS CHAR_KEY, 1 AS REQUIRED UNION
	SELECT N'SM Codes_2' AS CHAR_KEY, 0 AS REQUIRED UNION
	SELECT N'SM Codes_3' AS CHAR_KEY, 0 AS REQUIRED UNION
	SELECT N'SM Codes_4' AS CHAR_KEY, 0 AS REQUIRED
)

-- Test 1 - Check that the actual results contain at least all of the expected results
-- Expected result: No rows returned. Any rows that are returned were expected to be present in the actual data but are missing. 

SELECT @V_ROW_COUNT = COUNT(*) FROM (
(SELECT CHAR_KEY FROM CTE_RS_SK_COMBOS_EXPECTED WHERE REQUIRED=1
EXCEPT
SELECT CHAR_KEY FROM CTE_RS_SK_COMBOS_ACTUALS
)UNION

---- Test 2 - Check that no unexpected rows are present in the actual results
---- Expected result: No rows returned. Any rows that are returned are present in the actual data but should not be. 
(
SELECT CHAR_KEY FROM CTE_RS_SK_COMBOS_ACTUALS
EXCEPT
SELECT CHAR_KEY FROM CTE_RS_SK_COMBOS_EXPECTED
))a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT= 0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check which distinct planogram characteristics are showing in the data', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

END
﻿/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_FLOOR_PLAN_AM]    Script Date: 5/25/2023 11:11:12 AM ******/

CREATE PROC [con_mon].[USP_PLANOGRAM_FLOOR_PLAN_AM] @P_RUN_DATE [DATETIME] AS

/*************************************************************************************************************************
Procedure Name					: [USP_PLANOGRAM_FLOOR_PLAN_AM]
Purpose							: UAT Automation Testing for ser.PlanogramFloorPlan table		

**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

25-05-2023   : Nancy Khandelwal		  : Initial Version
**************************************************************************************************************************/

BEGIN 

DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.PlanogramFloorPlan';
DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_FLOOR_PLAN_AM';
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;

-----------------------------------------------------------------------------------
-- Drop and recreate the con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE temp table

IF OBJECT_ID (N'con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE', N'U') IS NOT NULL
	DROP TABLE con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE
;

CREATE TABLE con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE
WITH
(
	CLUSTERED INDEX (SCD_START_UBOUND ASC, SCD_END_LBOUND ASC)
	,DISTRIBUTION = REPLICATE
)
AS

-- Insert into the con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE temp table the distinct SCDStartDate values from the table being
-- tested, which should therefore be the full list of datetimes that need to be tested to get full coverage of all the data
-- in that table. 

SELECT DISTINCT
	VW_FP.SCDStartDate AS SCD_START_UBOUND
	,DATEADD(SECOND, -1, VW_FP.SCDStartDate) AS SCD_END_LBOUND
FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
WHERE
	VW_FP.RECORD_SOURCE_KEY = N'BTCBY'
;

-----------------------------------------------------------------------------------
-- Test: Check for duplicate record sources per surrogate business ID
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	PlanogramFloorPlanId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
GROUP BY
	PlanogramFloorPlanId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for duplicate record sources per surrogate business ID', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-----------------------------------------------------------------------------------
-- Test: Check for duplicate record sources per composite business key
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	SK_TYPE_KEY
	,SourceKey
	,ParentPlanogramId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
GROUP BY
	SK_TYPE_KEY
	,SourceKey
	,ParentPlanogramId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for duplicate record sources per composite business key', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Check for how many delta changes have taken place in the table

SET @V_DELTA_COUNT_1 = (
SELECT
	COUNT(*) AS THE_ROWS
FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

SET @V_DELTA_COUNT_2 = (
SELECT
	COUNT(*) AS DISTINCT_FPS
FROM
	(
		SELECT DISTINCT
			PlanogramFloorPlanId
		FROM
			[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
	) AS QRY_DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for how many delta changes have taken place in the table',@P_RUN_DATE,@V_ROW_COUNT,'Y',@V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for NULL start or end datetimes or active flags
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	*
FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	AND RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for NULL start or end datetimes or active flags', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for back-to-front start and end datetimes
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	*
FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
WHERE
	-- In Curate each record is active from and including SCDStartDate up to but not including SCDEndDate + 1 second
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for back-to-front start and end datetimes', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for multiple surrogate business IDs per composite business key
-- Expected result: No rows returned

WITH CTE_DISTINCTS AS
(
	SELECT DISTINCT
		SK_TYPE_KEY
		,SourceKey
		,ParentPlanogramId
		,PlanogramFloorPlanId
	FROM
		[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
	--WHERE
	--	RECORD_SOURCE_KEY = N'BTCBY'
)

,CTE_DISTINCT_SURROGATES AS
(
	SELECT
		SK_TYPE_KEY
		,SourceKey
		,ParentPlanogramId
		,COUNT(*) AS DISTINCT_SURROGATE_IDS
	FROM
		CTE_DISTINCTS
	GROUP BY
		SK_TYPE_KEY
		,SourceKey
		,ParentPlanogramId
	HAVING
		COUNT(*) > 1
)

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	CTE_DISTINCT_SURROGATES.DISTINCT_SURROGATE_IDS
	,VW_FP.*

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	INNER JOIN CTE_DISTINCT_SURROGATES
	ON VW_FP.SK_TYPE_KEY = CTE_DISTINCT_SURROGATES.SK_TYPE_KEY
	AND VW_FP.SourceKey = CTE_DISTINCT_SURROGATES.SourceKey
	-- NULL safe equality check. ParentPlanogramId cannot be negative
	AND ISNULL(VW_FP.ParentPlanogramId, -1) = ISNULL(CTE_DISTINCT_SURROGATES.ParentPlanogramId, -1)

WHERE
	VW_FP.RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for multiple surrogate business IDs per composite business key', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-----------------------------------------------------------------------------------
-- Test: Check for multiple composite business keys per surrogate business ID
-- Expected result: No rows returned

WITH CTE_DISTINCTS AS
(
	SELECT DISTINCT
		SK_TYPE_KEY
		,SourceKey
		,ParentPlanogramId
		,PlanogramFloorPlanId
	FROM
		[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
	--WHERE
	--	RECORD_SOURCE_KEY = N'BTCBY'
)

,CTE_DISTINCT_COMPOSITES AS
(
	SELECT
		PlanogramFloorPlanId
		,COUNT(*) AS DISTINCT_COMPOSITE_KEYS
	FROM
		CTE_DISTINCTS
	GROUP BY
		PlanogramFloorPlanId
	HAVING
		COUNT(*) > 1
)

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	CTE_DISTINCT_COMPOSITES.DISTINCT_COMPOSITE_KEYS
	,VW_FP.*

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	INNER JOIN CTE_DISTINCT_COMPOSITES
	ON VW_FP.PlanogramFloorPlanId = CTE_DISTINCT_COMPOSITES.PlanogramFloorPlanId

WHERE
	VW_FP.RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for multiple composite business keys per surrogate business ID', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for rows with identical start and end datetimes
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	COUNT(*) AS DUPLICATES
	,PlanogramFloorPlanId
	,SCDStartDate
	,SCDEndDate
FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramFloorPlanId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for rows with identical start and end datetimes', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for overlapping start-end periods
-- Prerequisites: Above tests must have passed
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramFloorPlanId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for overlapping start-end periods', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for underlapping start-end periods
-- Prerequisites: Above tests must have passed
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramFloorPlanId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for underlapping start-end periods', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for entities whose lives do not start on 1900-01-01
-- Expected result: No rows returned

WITH CTE_LATE_STARTS AS
(
	SELECT
		PlanogramFloorPlanId

	FROM
		[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramFloorPlanId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	VW_FP.*

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	INNER JOIN CTE_LATE_STARTS
	ON VW_FP.PlanogramFloorPlanId = CTE_LATE_STARTS.PlanogramFloorPlanId

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for entities whose lives do not start on 1900-01-01', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for entities whose lives do not end on 9999-12-31
-- Expected result: No rows returned

WITH CTE_EARLY_ENDS AS
(
	SELECT
		PlanogramFloorPlanId

	FROM
		[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramFloorPlanId

	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	VW_FP.*

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	INNER JOIN CTE_EARLY_ENDS
	ON VW_FP.PlanogramFloorPlanId = CTE_EARLY_ENDS.PlanogramFloorPlanId

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for entities whose lives do not end on 9999-12-31', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	*

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

WHERE
	(
		(SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
		OR
		(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y')
	)

	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for expected Blue Yonder record source and source key type combinations
-- Expected result: Exactly 2 rows returned, both with RECORD_SOURCE_KEY = 'BTCBY' and
-- with SK_TYPE_KEY being 'BY Planogram Store FP Key' / 'BY Planogram Store Family Key'. 
-- No NULLs and no other values. 

-- Define expected and actual results sets as CTEs


WITH CTE_RS_SK_COMBOS_ACTUALS AS
(
SELECT DISTINCT
	RECORD_SOURCE_KEY
	,SK_TYPE_KEY
FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
	OR SK_TYPE_KEY IN (N'BY Planogram Store FP Key', N'BY Planogram Store Family Key')	
)

,CTE_RS_SK_COMBOS_EXPECTED AS
(
	SELECT N'BTCBY' AS RECORD_SOURCE_KEY, N'BY Planogram Key' AS SK_TYPE_KEY
UNION ALL
	SELECT N'BTCBY' AS RECORD_SOURCE_KEY, N'BY Planogram Store Family Key' AS SK_TYPE_KEY	
)

-- SubTest1 - Check that the actual results contain at least all of the expected results
-- Expected result: No rows returned. Any rows that are returned were expected to be present in the actual data but are missing. 


SELECT @V_ROW_COUNT = COUNT(*) FROM 
(
(SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS)
UNION

---- SubTest2 - Check that no unexpected rows are present in the actual results
---- Expected result: No rows returned. Any rows that are returned are present in the actual data but should not be. 

(SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED)
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT=0 THEN 0 ELSE 1 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for expected Blue Yonder record source and source key type combinations', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that Blue Yonder source key types align as expected with the presence of relevant FK's
-- Expected result: For the SK_TYPE_KEY of 'BY Planogram Store Family Key' all of the FK columns should be NULL. 
-- For the SK_TYPE_KEY of 'BY Planogram Store FP Key' all of the FK columns should be 'Not NULL'. 
-- No other combinations. 


-- Define expected and actual results sets as CTEs


WITH CTE_RS_SK_COMBOS_ACTUALS AS
(
SELECT DISTINCT
	RECORD_SOURCE_KEY
	,SK_TYPE_KEY
	,CASE WHEN ParentPlanogramId IS NOT NULL THEN N'Not NULL' END AS ParentPlanogramId
	,CASE WHEN PlanogramSiteRoleId IS NOT NULL THEN N'Not NULL' END AS PlanogramSiteRoleId
	,CASE WHEN ParentPlanogramFloorPlanId IS NOT NULL THEN N'Not NULL' END AS ParentPlanogramFloorPlanId
FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

,CTE_RS_SK_COMBOS_EXPECTED AS
(
	SELECT N'BTCBY' AS RECORD_SOURCE_KEY, N'BY Planogram Store Family Key' AS SK_TYPE_KEY, NULL AS ParentPlanogramId, NULL AS PlanogramSiteRoleId, NULL AS ParentPlanogramFloorPlanId
UNION ALL
	SELECT N'BTCBY' AS RECORD_SOURCE_KEY, N'BY Planogram Store FP Key' AS SK_TYPE_KEY, N'Not NULL'AS ParentPlanogramId, N'Not NULL'AS PlanogramSiteRoleId, N'Not NULL'AS ParentPlanogramFloorPlanId	
)

-- SubTest1 - Check that the actual results contain at least all of the expected results
-- Expected result: No rows returned. Any rows that are returned were expected to be present in the actual data but are missing. 


SELECT @V_ROW_COUNT = COUNT(*) FROM 
(
(SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS)
UNION

---- SubTest2 - Check that no unexpected rows are present in the actual results
---- Expected result: No rows returned. Any rows that are returned are present in the actual data but should not be. 

(SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED)
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT=0 THEN 0 ELSE 1 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that Blue Yonder source key types align as expected with the presence of relevant FKs', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that child level Blue Yonder floor plans all and only link to parent Blue Yonder planograms
-- Expected result: Exactly one row returned with FP_RECORD_SOURCE_KEY = 'BTCBY', FP_SK_TYPE_KEY = 'BY Planogram Store FP Key', 
-- POG_RECORD_SOURCE_KEY = 'BTCBY' and POG_SK_TYPE_KEY = 'BY Planogram Family Key'

WITH CTE_POG_KEYS AS
(
	SELECT
		POG.PlanogramId
		,CASE WHEN MAX(CASE WHEN POG.SourceKey IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT POG.SourceKey) > 1 THEN N'Dupe' ELSE MAX(POG.SourceKey) END AS SourceKey
		,CASE WHEN MAX(CASE WHEN LOV_RS.LOVKey IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOV_RS.LOVKey) > 1 THEN N'Dupe' ELSE MAX(LOV_RS.LOVKey) END AS RECORD_SOURCE_KEY
		,CASE WHEN MAX(CASE WHEN LOV_RS.LOVName IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOV_RS.LOVName) > 1 THEN N'Dupe' ELSE MAX(LOV_RS.LOVName) END AS RECORD_SOURCE_NAME
		,CASE WHEN MAX(CASE WHEN LOV_SK_TYPE.LOVKey IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOV_SK_TYPE.LOVKey) > 1 THEN N'Dupe' ELSE MAX(LOV_SK_TYPE.LOVKey) END AS SK_TYPE_KEY
		,CASE WHEN MAX(CASE WHEN LOV_SK_TYPE.LOVName IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOV_SK_TYPE.LOVName) > 1 THEN N'Dupe' ELSE MAX(LOV_SK_TYPE.LOVName) END AS SK_TYPE_NAME

	FROM
		ser.Planogram AS POG

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON POG.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

		LEFT JOIN ser.RefLOV AS LOV_SK_TYPE
		ON POG.LOVSourceKeyTypeId = LOV_SK_TYPE.LOVId
		AND LOV_SK_TYPE.ActiveFlag = 1

	--WHERE
	--	LOV_RS.LOVKey = N'BTCBY'

	GROUP BY
		POG.PlanogramId
)

-- Define expected and actual results sets as CTEs


,CTE_RS_SK_COMBOS_ACTUALS AS
(
SELECT
	VW_FP.RECORD_SOURCE_KEY AS FP_RECORD_SOURCE_KEY
	,VW_FP.SK_TYPE_KEY AS FP_SK_TYPE_KEY
	,CTE_POG_KEYS.RECORD_SOURCE_KEY AS POG_RECORD_SOURCE_KEY
	,CTE_POG_KEYS.SK_TYPE_KEY AS POG_SK_TYPE_KEY

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	LEFT JOIN CTE_POG_KEYS
	ON VW_FP.ParentPlanogramId = CTE_POG_KEYS.PlanogramId

WHERE
	VW_FP.SK_TYPE_KEY = N'BY Planogram Store FP Key'

GROUP BY
	VW_FP.RECORD_SOURCE_KEY
	,VW_FP.SK_TYPE_KEY
	,CTE_POG_KEYS.RECORD_SOURCE_KEY
	,CTE_POG_KEYS.SK_TYPE_KEY
)

,CTE_RS_SK_COMBOS_EXPECTED AS
(
	SELECT N'BTCBY' AS FP_RECORD_SOURCE_KEY, N'BY Planogram Store FP Key' AS FP_SK_TYPE_KEY, N'BTCBY' AS POG_RECORD_SOURCE_KEY, N'BY Planogram Family Key' AS POG_SK_TYPE_KEY 
)

-- SubTest1 - Check that the actual results contain at least all of the expected results
-- Expected result: No rows returned. Any rows that are returned were expected to be present in the actual data but are missing. 


SELECT @V_ROW_COUNT = COUNT(*) FROM 
(
(SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS)
UNION

---- SubTest2 - Check that no unexpected rows are present in the actual results
---- Expected result: No rows returned. Any rows that are returned are present in the actual data but should not be. 

(SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED)
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT=0 THEN 0 ELSE 1 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that child level Blue Yonder floor plans all and only link to parent Blue Yonder planograms', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that all Blue Yonder FP rows are covered by at least one of the test dates
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	DATES.*
	,VW_FP.*

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	LEFT JOIN con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE AS DATES
	ON VW_FP.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < VW_FP.SCDEndDate

WHERE
	-- Failed left join
	DATES.SCD_START_UBOUND IS NULL

	AND VW_FP.RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that all Blue Yonder FP rows are covered by at least one of the test dates', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that all child level Blue Yonder floor plans successfully link to ser.PlanogramSiteRole
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	VW_FP.*
	,P2SR.PlanogramSiteRoleId AS P2SR_PlanogramSiteRoleId

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS VW_FP

	LEFT JOIN con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE AS DATES
	ON VW_FP.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < VW_FP.SCDEndDate

	LEFT JOIN ser.PlanogramSiteRole AS P2SR
	ON VW_FP.PlanogramSiteRoleId = P2SR.PlanogramSiteRoleId
	AND P2SR.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < P2SR.SCDEndDate

WHERE
	VW_FP.SK_TYPE_KEY = N'BY Planogram Store FP Key'

	AND P2SR.PlanogramSiteRoleId IS NULL

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that all child level Blue Yonder floor plans successfully link to ser.PlanogramSiteRole', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that no Blue Yonder FP has a parent or child from another record source
-- Expected result: One row only with both values as 'BTCBY'

-- Define expected and actual results sets as CTEs

WITH CTE_RS_SK_COMBOS_ACTUALS AS
(
SELECT DISTINCT
	CHILD_FP.RECORD_SOURCE_KEY AS CHILD_RS
	,PARENT_FP.RECORD_SOURCE_KEY AS PARENT_RS

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS CHILD_FP

	INNER JOIN [con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS PARENT_FP
	ON CHILD_FP.ParentPlanogramFloorPlanId = PARENT_FP.PlanogramFloorPlanId

WHERE
	N'BTCBY' IN (CHILD_FP.RECORD_SOURCE_KEY, PARENT_FP.RECORD_SOURCE_KEY)
)

,CTE_RS_SK_COMBOS_EXPECTED AS
(
	SELECT N'BTCBY' AS CHILD_RS, N'BTCBY' AS PARENT_RS
)

-- SubTest1 - Check that the actual results contain at least all of the expected results
-- Expected result: No rows returned. Any rows that are returned were expected to be present in the actual data but are missing. 


SELECT @V_ROW_COUNT = COUNT(*) FROM 
(
(SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS)
UNION

---- SubTest2 - Check that no unexpected rows are present in the actual results
---- Expected result: No rows returned. Any rows that are returned are present in the actual data but should not be. 

(SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED)
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT=0 THEN 0 ELSE 1 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that no Blue Yonder FP has a parent or child from another record source', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that all Blue Yonder FPs that have a non-NULL parent FP FK do indeed link to a parent FP
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	CHILD_FP.RECORD_SOURCE_KEY AS C_RECORD_SOURCE_KEY
	,PARENT_FP.RECORD_SOURCE_KEY AS P_RECORD_SOURCE_KEY
	,CHILD_FP.SK_TYPE_KEY AS C_SK_TYPE_KEY
	,PARENT_FP.SK_TYPE_KEY AS P_SK_TYPE_KEY
	,CHILD_FP.PlanogramFloorPlanId AS C_PlanogramFloorPlanId
	,CHILD_FP.ParentPlanogramFloorPlanId AS C_ParentPlanogramFloorPlanId
	,PARENT_FP.PlanogramFloorPlanId AS P_PlanogramFloorPlanId
	,PARENT_FP.ParentPlanogramFloorPlanId AS P_ParentPlanogramFloorPlanId
	,CHILD_FP.SCDStartDate AS C_SCDStartDate
	,CHILD_FP.SCDEndDate AS C_SCDEndDate
	,PARENT_FP.SCDStartDate AS P_SCDStartDate
	,PARENT_FP.SCDEndDate AS P_SCDEndDate

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS CHILD_FP

	LEFT JOIN con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE AS DATES
	ON CHILD_FP.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < CHILD_FP.SCDEndDate

	LEFT JOIN [con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS PARENT_FP
	ON CHILD_FP.ParentPlanogramFloorPlanId = PARENT_FP.PlanogramFloorPlanId
	AND PARENT_FP.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < PARENT_FP.SCDEndDate

WHERE
	CHILD_FP.RECORD_SOURCE_KEY = N'BTCBY'

	AND CHILD_FP.ParentPlanogramFloorPlanId IS NOT NULL
	AND PARENT_FP.PlanogramFloorPlanId IS NULL

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that all Blue Yonder FPs that have a non-NULL parent FP FK do indeed link to a parent FP', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-----------------------------------------------------------------------------------
-- Test: Check that all Blue Yonder 'BY Planogram Store Family Key' FPs are indeed parents of another FP
-- Prerequisites: Above tests must have passed
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	PARENT_FP.RECORD_SOURCE_KEY AS P_RECORD_SOURCE_KEY
	,CHILD_FP.RECORD_SOURCE_KEY AS C_RECORD_SOURCE_KEY
	,PARENT_FP.SK_TYPE_KEY AS P_SK_TYPE_KEY
	,CHILD_FP.SK_TYPE_KEY AS C_SK_TYPE_KEY
	,PARENT_FP.PlanogramFloorPlanId AS P_PlanogramFloorPlanId
	,PARENT_FP.ParentPlanogramFloorPlanId AS P_ParentPlanogramFloorPlanId
	,CHILD_FP.PlanogramFloorPlanId AS C_PlanogramFloorPlanId
	,CHILD_FP.ParentPlanogramFloorPlanId AS C_ParentPlanogramFloorPlanId
	,PARENT_FP.SCDStartDate AS P_SCDStartDate
	,PARENT_FP.SCDEndDate AS P_SCDEndDate
	,CHILD_FP.SCDStartDate AS C_SCDStartDate
	,CHILD_FP.SCDEndDate AS C_SCDEndDate

FROM
	[con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS PARENT_FP

	LEFT JOIN con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE AS DATES
	ON PARENT_FP.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < PARENT_FP.SCDEndDate

	LEFT JOIN [con_mon].[VW_PLANOGRAM_FLOOR_PLAN_AM] AS CHILD_FP
	ON PARENT_FP.PlanogramFloorPlanId = CHILD_FP.ParentPlanogramFloorPlanId
	AND CHILD_FP.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < CHILD_FP.SCDEndDate

WHERE
	PARENT_FP.SK_TYPE_KEY = N'BY Planogram Store Family Key'
	AND CHILD_FP.PlanogramFloorPlanId IS NULL

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that all Blue Yonder FPs that have a non-NULL parent FP FK do indeed link to a parent FP: Check cases not covered by the midnight times', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-----------------------------------------------------------------------------------
-- Drop temp tables

IF OBJECT_ID (N'con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE', N'U') IS NOT NULL
	DROP TABLE con_mon.TMP_PLANOGRAM_FLOOR_PLAN_AM_DATE_RANGE
;

END
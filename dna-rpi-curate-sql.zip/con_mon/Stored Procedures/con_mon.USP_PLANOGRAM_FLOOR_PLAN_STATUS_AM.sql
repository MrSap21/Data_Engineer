﻿/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_FLOOR_PLAN_STATUS_AM]    Script Date: 5/25/2023 10:08:29 AM ******/

CREATE PROC [con_mon].[USP_PLANOGRAM_FLOOR_PLAN_STATUS_AM] @P_RUN_DATE [DATETIME] AS

/*************************************************************************************************************************
Procedure Name					: USP_PLANOGRAM_FLOOR_PLAN_STATUS_AM
Purpose							: UAT Automation Testing for ser.PlanogramFloorPlanStatus table		

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

24-05-2023	 : Mayank Bhardwaj		  : Initial Version
**************************************************************************************************************************/

BEGIN

DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.PlanogramFloorPlanStatus';
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;
DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_FLOOR_PLAN_STATUS_AM';
----------------------------------------------------------------------------------------------------------------
-- Test: Check for duplicate record sources
-- Expected result: No rows returned

---- Where STATUS_SET_NAME = 'FPStatus'

SELECT @V_ROW_COUNT = COUNT(*) FROM								
(														
SELECT
	PlanogramFloorPlanId
	,LOVPlanogramFloorPlanStatusSetId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
WHERE
	STATUS_SET_NAME = N'FPStatus'
GROUP BY
	PlanogramFloorPlanId
	,LOVPlanogramFloorPlanStatusSetId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for duplicate record sources Where STATUS_SET_NAME = ''FPStatus''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------------
-- Test: Check for duplicate record sources
-- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'FP Status Type' and STATUS_KEY = 'FPPendingDate'

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	PlanogramFloorPlanId
	,LOVPlanogramFloorPlanStatusSetId
	,LOVStatusId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
WHERE
	STATUS_SET_NAME = N'FP Status Type'
	AND STATUS_KEY = N'FPPendingDate'
GROUP BY
	PlanogramFloorPlanId
	,LOVPlanogramFloorPlanStatusSetId
	,LOVStatusId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for duplicate record sources Where STATUS_SET_NAME = ''FP Status Type'' and STATUS_KEY = ''FPPendingDate''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------------------
---- Test: Check for NULL start or end datetimes or active flags
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for NULL start or end datetimes or active flags',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

----------------------------------------------------------------------------------------------------------
---- Test: Check for back-to-front start and end datetimes
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
WHERE
	-- In Curate each record is active from and including SCDStartDate up to but not including SCDEndDate + 1 second
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for back-to-front start and end datetimes',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-------------------------------------------------------------------------------------------------------------
---- Test: Check for rows with identical start and end datetimes
---- Expected result: No rows returned

-- Where STATUS_SET_NAME = 'FPStatus'

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	COUNT(*) AS DUPLICATES
	,PlanogramFloorPlanId
	,LOVPlanogramFloorPlanStatusSetId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
WHERE
	STATUS_SET_NAME = N'FPStatus'
	AND RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramFloorPlanId
	,LOVPlanogramFloorPlanStatusSetId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for rows with identical start and end datetimes Where STATUS_SET_NAME = ''FPStatus''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------------------------------------
---- Test: Check for rows with identical start and end datetimes
---- Expected result: No rows returned

-- Where STATUS_SET_NAME = 'FP Status Type' and STATUS_KEY = 'FPPendingDate'

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	COUNT(*) AS DUPLICATES
	,PlanogramFloorPlanId
	,LOVPlanogramFloorPlanStatusSetId
	,LOVStatusId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
WHERE
	STATUS_SET_NAME = N'FP Status Type'
	AND STATUS_KEY = N'FPPendingDate'
	AND RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramFloorPlanId
	,LOVPlanogramFloorPlanStatusSetId
	,LOVStatusId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for rows with identical start and end datetimes Where STATUS_SET_NAME = ''FP Status Type'' and STATUS_KEY = ''FPPendingDate''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------------------------------
---- Test: Check for overlapping or underlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

---- Where STATUS_SET_NAME = 'FPStatus'

-- Check for SCD overlaps

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramFloorPlanId
					,LOVPlanogramFloorPlanStatusSetId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM

		WHERE
			STATUS_SET_NAME = N'FPStatus'

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for overlapping start-end periods Where STATUS_SET_NAME = ''FPStatus''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-- Check for SCD underlaps (i.e. gaps)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramFloorPlanId
					,LOVPlanogramFloorPlanStatusSetId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM

		WHERE
			STATUS_SET_NAME = N'FPStatus'

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for underlapping start-end periods Where STATUS_SET_NAME = ''FPStatus''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------------------------------------
---- Test: Check for overlapping or underlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned
---- Where STATUS_SET_NAME = 'FP Status Type' and STATUS_KEY = 'FPPendingDate'

-- Check for SCD overlaps

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*
			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramFloorPlanId
					,LOVPlanogramFloorPlanStatusSetId
					,LOVStatusId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM

		WHERE
			STATUS_SET_NAME = N'FP Status Type'
			AND STATUS_KEY = N'FPPendingDate'

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for overlapping start-end periods Where STATUS_SET_NAME = ''FP Status Type'' and STATUS_KEY = ''FPPendingDate''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-- Check for SCD underlaps (i.e. gaps)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*
			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramFloorPlanId
					,LOVPlanogramFloorPlanStatusSetId
					,LOVStatusId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM

		WHERE
			STATUS_SET_NAME = N'FP Status Type'
			AND STATUS_KEY = N'FPPendingDate'

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for underlapping start-end periods Where STATUS_SET_NAME = ''FP Status Type'' and STATUS_KEY = ''FPPendingDate''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

--------------------------------------------------------------------------------------------------------
---- Test: Check for entities whose lives do not start on 1900-01-01
---- Expected result: No rows returned

-- Where STATUS_SET_NAME = 'FPStatus'

WITH CTE_LATE_STARTS AS
(
	SELECT
		PlanogramFloorPlanId
		,LOVPlanogramFloorPlanStatusSetId

	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM

	WHERE
		STATUS_SET_NAME = N'FPStatus'
		AND RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramFloorPlanId
		,LOVPlanogramFloorPlanStatusSetId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_FP_STATUS.*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM AS VW_FP_STATUS

	INNER JOIN CTE_LATE_STARTS
	ON VW_FP_STATUS.PlanogramFloorPlanId = CTE_LATE_STARTS.PlanogramFloorPlanId
	AND VW_FP_STATUS.LOVPlanogramFloorPlanStatusSetId = CTE_LATE_STARTS.LOVPlanogramFloorPlanStatusSetId
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not start on 1900-01-01 Where STATUS_SET_NAME = ''FPStatus''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
----------------------------------------------------------------------------------------------------------
---- Test: Check for entities whose lives do not start on 1900-01-01
---- Expected result: No rows returned

-- Where STATUS_SET_NAME = 'FP Status Type' and STATUS_KEY = 'FPPendingDate'

WITH CTE_LATE_STARTS AS
(
	SELECT
		PlanogramFloorPlanId
		,LOVPlanogramFloorPlanStatusSetId
		,LOVStatusId

	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM

	WHERE
		STATUS_SET_NAME = N'FP Status Type'
		AND STATUS_KEY = N'FPPendingDate'
		AND RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramFloorPlanId
		,LOVPlanogramFloorPlanStatusSetId
		,LOVStatusId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_FP_STATUS.*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM AS VW_FP_STATUS

	INNER JOIN CTE_LATE_STARTS
	ON VW_FP_STATUS.PlanogramFloorPlanId = CTE_LATE_STARTS.PlanogramFloorPlanId
	AND VW_FP_STATUS.LOVPlanogramFloorPlanStatusSetId = CTE_LATE_STARTS.LOVPlanogramFloorPlanStatusSetId
	AND VW_FP_STATUS.LOVStatusId = CTE_LATE_STARTS.LOVStatusId
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not start on 1900-01-01 Where STATUS_SET_NAME = ''FP Status Type'' and STATUS_KEY = ''FPPendingDate''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

------------------------------------------------------------------------------------------------------------
---- Test: Check for entities whose lives do not end on 9999-12-31
---- Expected result: No rows returned

-- Where STATUS_SET_NAME = 'FPStatus'

WITH CTE_EARLY_ENDS AS
(
	SELECT
		PlanogramFloorPlanId
		,LOVPlanogramFloorPlanStatusSetId

	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM

	WHERE
		STATUS_SET_NAME = N'FPStatus'
		AND RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramFloorPlanId
		,LOVPlanogramFloorPlanStatusSetId

	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_FP_STATUS.*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM AS VW_FP_STATUS

	INNER JOIN CTE_EARLY_ENDS
	ON VW_FP_STATUS.PlanogramFloorPlanId = CTE_EARLY_ENDS.PlanogramFloorPlanId
	AND VW_FP_STATUS.LOVPlanogramFloorPlanStatusSetId = CTE_EARLY_ENDS.LOVPlanogramFloorPlanStatusSetId
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not end on 9999-12-31 Where STATUS_SET_NAME = ''FPStatus''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
----------------------------------------------------------------------------------------------------------------------
---- Test: Check for entities whose lives do not end on 9999-12-31
---- Expected result: No rows returned

---- Where STATUS_SET_NAME = 'FP Status Type' and STATUS_KEY = 'FPPendingDate'

WITH CTE_EARLY_ENDS AS
(
	SELECT
		PlanogramFloorPlanId
		,LOVPlanogramFloorPlanStatusSetId
		,LOVStatusId

	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM

	WHERE
		STATUS_SET_NAME = N'FP Status Type'
		AND STATUS_KEY = N'FPPendingDate'
		AND RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramFloorPlanId
		,LOVPlanogramFloorPlanStatusSetId
		,LOVStatusId

	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_FP_STATUS.*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM AS VW_FP_STATUS

	INNER JOIN CTE_EARLY_ENDS
	ON VW_FP_STATUS.PlanogramFloorPlanId = CTE_EARLY_ENDS.PlanogramFloorPlanId
	AND VW_FP_STATUS.LOVPlanogramFloorPlanStatusSetId = CTE_EARLY_ENDS.LOVPlanogramFloorPlanStatusSetId
	AND VW_FP_STATUS.LOVStatusId = CTE_EARLY_ENDS.LOVStatusId
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not end on 9999-12-31 Where STATUS_SET_NAME = ''FP Status Type'' and STATUS_KEY = ''FPPendingDate''',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-------------------------------------------------------------------------------------------------------
-- Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM

WHERE
	(
		(SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
		OR
		(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y')
	)

	AND RECORD_SOURCE_KEY = N'BTCBY'
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

--------------------------------------------------------------------------------------------------------
---- Check for how many delta changes have taken place in the table
---- Where STATUS_SET_NAME = 'FPStatus'

SET @V_DELTA_COUNT_1 =
(
SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
	AND STATUS_SET_NAME = N'FPStatus'
)

SET @V_DELTA_COUNT_2 =
(
SELECT
	COUNT(*) AS DISTINCT_P_STATUSES
FROM
	(
		SELECT DISTINCT
			PlanogramFloorPlanId
			,LOVPlanogramFloorPlanStatusSetId
		FROM
			con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
			AND STATUS_SET_NAME = N'FPStatus'
	) AS DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for how many delta changes have taken place in the table Where STATUS_SET_NAME = ''FPStatus''',@P_RUN_DATE,@V_ROW_COUNT,'Y',@V_ALERT_FLAG);
----------------------------------------------------------------------------------------------------------------------
---- Check for how many delta changes have taken place in the table
---- Where STATUS_SET_NAME = 'FP Status Type' and STATUS_KEY = 'FPPendingDate'

SET @V_DELTA_COUNT_1 =											
(														
SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
	AND STATUS_SET_NAME = N'FP Status Type'
	AND STATUS_KEY = N'FPPendingDate'
)

SET @V_DELTA_COUNT_2 =
(
SELECT
	COUNT(*) AS DISTINCT_P_STATUSES
FROM
	(
		SELECT DISTINCT
			PlanogramFloorPlanId
			,LOVPlanogramFloorPlanStatusSetId
		FROM
			con_mon.VW_PLANOGRAM_FLOOR_PLAN_STATUS_AM
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
			AND STATUS_SET_NAME = N'FP Status Type'
			AND STATUS_KEY = N'FPPendingDate'
	) AS DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2								
															
SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for how many delta changes have taken place in the table Where STATUS_SET_NAME = ''FP Status Type'' and STATUS_KEY = ''FPPendingDate''',@P_RUN_DATE,@V_ROW_COUNT,'Y',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------------------

END
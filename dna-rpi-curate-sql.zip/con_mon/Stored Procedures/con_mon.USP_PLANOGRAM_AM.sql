﻿/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_AM]    Script Date: 5/25/2023 11:09:49 AM ******/

CREATE PROC [con_mon].[USP_PLANOGRAM_AM] @P_RUN_DATE [DATETIME] AS

/*************************************************************************************************************************
Procedure Name					: [USP_PLANOGRAM_AM]
Purpose							: UAT Automation Testing for ser.Planogram table		

**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

25-05-2023   : Nancy Khandelwal		   Initial Version
**************************************************************************************************************************/

BEGIN

DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.Planogram';
DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_AM';
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;

-----------------------------------------------------------------------------------
---- Drop and recreate the con_mon.TMP_PLANOGRAM_AM_DATE_RANGE temp table

IF OBJECT_ID (N'con_mon.TMP_PLANOGRAM_AM_DATE_RANGE', N'U') IS NOT NULL
	DROP TABLE con_mon.TMP_PLANOGRAM_AM_DATE_RANGE
;

CREATE TABLE con_mon.TMP_PLANOGRAM_AM_DATE_RANGE
WITH
(
	CLUSTERED INDEX (SCD_START_UBOUND ASC, SCD_END_LBOUND ASC)
	,DISTRIBUTION = REPLICATE
)
AS

-- Insert into the con_mon.TMP_PLANOGRAM_AM_DATE_RANGE temp table the distinct SCDStartDate values from the table being
-- tested, which should therefore be the full list of datetimes that need to be tested to get full coverage of all the data
-- in that table. 

SELECT DISTINCT
	VW_POG.SCDStartDate AS SCD_START_UBOUND
	,DATEADD(SECOND, -1, VW_POG.SCDStartDate) AS SCD_END_LBOUND
FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG
WHERE
	VW_POG.RECORD_SOURCE_KEY = N'BTCBY'
;

-----------------------------------------------------------------------------------
-- Check for how many delta changes have taken place in the table

SET @V_DELTA_COUNT_1 = 
(SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

SET @V_DELTA_COUNT_2 = 
(SELECT
	COUNT(*) AS DISTINCT_POGS
FROM
	(
		SELECT DISTINCT
			PlanogramId
		FROM
			con_mon.VW_PLANOGRAM_AM AS VW_POG
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
	) AS QRY_DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for how many delta changes have taken place in the table',@P_RUN_DATE,@V_ROW_COUNT,'Y',@V_ALERT_FLAG);
---------------------------------------------------------------------------------

-- Test: Check for NULL start or end datetimes or active flags
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	AND RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for NULL start or end datetimes or active flags', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------

-- Test: Check for back-to-front start and end datetimes
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG
WHERE
	-- In Curate each record is active from and including SCDStartDate up to but not including SCDEndDate + 1 second
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for back-to-front start and end datetimes', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for multiple surrogate business IDs per composite business key
-- Expected result: No rows returned

WITH CTE_DISTINCT_SURROGATES AS
(
	SELECT
		RECORD_SOURCE_KEY
		,SK_TYPE_KEY
		,SourceKey
		,COUNT(*) AS DISTINCT_SURROGATE_IDS
	FROM
		con_mon.VW_PLANOGRAM_DISTINCT_AM AS VW_DISTINCTS
	GROUP BY
		RECORD_SOURCE_KEY
		,SK_TYPE_KEY
		,SourceKey
	HAVING
		COUNT(*) > 1
)
SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	CTE_DISTINCT_SURROGATES.DISTINCT_SURROGATE_IDS
	,VW_POG.*

FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG

	INNER JOIN CTE_DISTINCT_SURROGATES
	ON VW_POG.RECORD_SOURCE_KEY = CTE_DISTINCT_SURROGATES.RECORD_SOURCE_KEY
	AND VW_POG.SK_TYPE_KEY = CTE_DISTINCT_SURROGATES.SK_TYPE_KEY
	AND VW_POG.SourceKey = CTE_DISTINCT_SURROGATES.SourceKey

WHERE
	VW_POG.RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for multiple surrogate business IDs per composite business key', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-----------------------------------------------------------------------------------
-- Test: Check for multiple composite business keys per surrogate business ID
-- Expected result: No rows returned

WITH CTE_DISTINCT_COMPOSITES AS
(
	SELECT
		PlanogramId
		,COUNT(*) AS DISTINCT_COMPOSITE_KEYS
	FROM
		con_mon.VW_PLANOGRAM_DISTINCT_AM AS VW_DISTINCTS
	GROUP BY
		PlanogramId
	HAVING
		COUNT(*) > 1
)
SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	CTE_DISTINCT_COMPOSITES.DISTINCT_COMPOSITE_KEYS
	,VW_POG.*

FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG

	INNER JOIN CTE_DISTINCT_COMPOSITES
	ON VW_POG.PlanogramId = CTE_DISTINCT_COMPOSITES.PlanogramId

WHERE
	VW_POG.RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for multiple composite business keys per surrogate business ID', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-----------------------------------------------------------------------------------

-- Test: Check for rows with identical start and end datetimes
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	COUNT(*) AS DUPLICATES
	,PlanogramId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for rows with identical start and end datetimes', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for overlapping or underlapping start-end periods
-- Prerequisites: Above tests must have passed
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_AM AS VW_POG

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for overlapping start-end periods', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for underlapping start-end periods
-- Prerequisites: Above tests must have passed
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_AM AS VW_POG

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for underlapping start-end periods', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------

-- Test: Check for entities whose lives do not start on 1900-01-01
-- Expected result: No rows returned

WITH CTE_LATE_STARTS AS
(
	SELECT
		PlanogramId
	FROM
		con_mon.VW_PLANOGRAM_AM AS VW_POG
	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'
	GROUP BY
		PlanogramId
	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME

)
SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	VW_POG.*

FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG

	INNER JOIN CTE_LATE_STARTS
	ON VW_POG.PlanogramId = CTE_LATE_STARTS.PlanogramId

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for entities whose lives do not start on 1900-01-01', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check for entities whose lives do not end on 9999-12-31
-- Expected result: No rows returned

WITH CTE_EARLY_ENDS AS
(
	SELECT
		PlanogramId
	FROM
		con_mon.VW_PLANOGRAM_AM AS VW_POG
	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'
	GROUP BY
		PlanogramId
	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
)
SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	VW_POG.*

FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG

	INNER JOIN CTE_EARLY_ENDS
	ON VW_POG.PlanogramId = CTE_EARLY_ENDS.PlanogramId

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for entities whose lives do not end on 9999-12-31', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
 --Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
 --Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG

WHERE
	(
		(SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
		OR
		(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y')
	)

	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

-----------------------------------------------------------------------------------
-- Test: Check for expected Blue Yonder record source and source key type combinations
-- Expected result: Exactly 2 rows returned, both with RECORD_SOURCE_KEY = 'BTCBY' and
-- with SK_TYPE_KEY being 'BY Planogram Key' / 'BY Planogram Family Key'. No NULLs and
-- no other values. 


-- New test version, rewritten to be a set equality check. Split into two subset tests. 

-- Define expected and actual results sets as CTEs

WITH CTE_RS_SK_COMBOS_ACTUALS AS
(
	SELECT DISTINCT
		RECORD_SOURCE_KEY
		,SK_TYPE_KEY
	FROM
		con_mon.VW_PLANOGRAM_AM AS VW_POG
	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'
		OR SK_TYPE_KEY IN (N'BY Planogram Key', N'BY Planogram Family Key')
)

,CTE_RS_SK_COMBOS_EXPECTED AS
(
	SELECT N'BTCBY' AS RECORD_SOURCE_KEY, N'BY Planogram Key' AS SK_TYPE_KEY
	UNION ALL
	SELECT N'BTCBY' AS RECORD_SOURCE_KEY, N'BY Planogram Family Key' AS SK_TYPE_KEY
)

---- SubTest 1 - Check that the actual results contain at least all of the expected results
---- Expected result: No rows returned. Any rows that are returned were expected to be present in the actual data but are missing. 

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
(
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
)


---- SubTest 2 - Check that no unexpected rows are present in the actual results
---- Expected result: No rows returned. Any rows that are returned are present in the actual data but should not be. 


UNION
(
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
)
)a



SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT=0 THEN 0 ELSE 1 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for Blue Yonder record source and source key type combinations', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that Blue Yonder source key types align as expected with the presence of a parent planogram FK
-- Expected result: SK_TYPE_KEY should always be 'BY Planogram Family Key' for NULL ParentPlanogramId. 
-- SK_TYPE_KEY should always be 'BY Planogram Key' for Non-NULL ParentPlanogramId. No other combinations. 


-- New test version, rewritten to be a set equality check. Split into two subset tests. 

-- Define expected and actual results sets as CTEs

WITH CTE_RS_SK_COMBOS_ACTUALS AS
(
SELECT DISTINCT
	RECORD_SOURCE_KEY
	,SK_TYPE_KEY
	,CASE WHEN ParentPlanogramId IS NOT NULL THEN N'Not NULL' END AS ParentPlanogramId
FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

,CTE_RS_SK_COMBOS_EXPECTED AS
(
	SELECT  N'BTCBY' AS RECORD_SOURCE_KEY, N'BY Planogram Family Key' AS SK_TYPE_KEY, NULL AS ParentPlanogramId
	UNION ALL
	SELECT  N'BTCBY' AS RECORD_SOURCE_KEY, N'BY Planogram Key' AS SK_TYPE_KEY, N'Not NULL' AS ParentPlanogramId
)

---- SubTest 1 - Check that the actual results contain at least all of the expected results
---- Expected result: No rows returned. Any rows that are returned were expected to be present in the actual data but are missing. 

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
(
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
)
UNION

---- SubTest 2 - Check that no unexpected rows are present in the actual results
---- Expected result: No rows returned. Any rows that are returned are present in the actual data but should not be. 
(
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
)
)b

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT=0 THEN 0 ELSE 1 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that Blue Yonder source key types align as expected with the presence of a parent planogram FK', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that all Blue Yonder planogram rows are covered by at least one of the test dates
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	DATES.*
	,VW_POG.*

FROM
	con_mon.VW_PLANOGRAM_AM AS VW_POG

	LEFT JOIN con_mon.TMP_PLANOGRAM_AM_DATE_RANGE AS DATES
	ON VW_POG.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < VW_POG.SCDEndDate

WHERE
	-- Failed left join
	DATES.SCD_START_UBOUND IS NULL

	AND VW_POG.RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that all Blue Yonder planogram rows are covered by at least one of the test dates', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that no Blue Yonder planogram has a parent or child from another record source
-- Expected result: One row only with both values as 'BTCBY'

-- New test version, rewritten to be a set equality check. Split into two subset tests. 

-- Define expected and actual results sets as CTEs

WITH CTE_RS_SK_COMBOS_ACTUALS AS
(
SELECT DISTINCT
	CHILD_POG.RECORD_SOURCE_KEY AS CHILD_RS
	,PARENT_POG.RECORD_SOURCE_KEY AS PARENT_RS

FROM
	con_mon.VW_PLANOGRAM_AM AS CHILD_POG

	INNER JOIN con_mon.VW_PLANOGRAM_AM AS PARENT_POG
	ON CHILD_POG.ParentPlanogramId = PARENT_POG.PlanogramId

WHERE
	N'BTCBY' IN (CHILD_POG.RECORD_SOURCE_KEY, PARENT_POG.RECORD_SOURCE_KEY)
)

,CTE_RS_SK_COMBOS_EXPECTED AS
(
	SELECT  N'BTCBY' AS CHILD_RS, N'BTCBY' AS PARENT_RS
)

---- SubTest 1 - Check that the actual results contain at least all of the expected results
---- Expected result: No rows returned. Any rows that are returned were expected to be present in the actual data but are missing. 

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
(
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
)
UNION

---- SubTest 2 - Check that no unexpected rows are present in the actual results
---- Expected result: No rows returned. Any rows that are returned are present in the actual data but should not be. 

(
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
)
)b

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT=0 THEN 0 ELSE 1 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that no Blue Yonder planogram has a parent or child from another record source', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that all Blue Yonder planograms that have a non-NULL parent FK do indeed link to a parent
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	CHILD_POG.RECORD_SOURCE_KEY AS C_RECORD_SOURCE_KEY
	,PARENT_POG.RECORD_SOURCE_KEY AS P_RECORD_SOURCE_KEY
	,CHILD_POG.SK_TYPE_KEY AS C_SK_TYPE_KEY
	,PARENT_POG.SK_TYPE_KEY AS P_SK_TYPE_KEY
	,CHILD_POG.PlanogramId AS C_PlanogramId
	,CHILD_POG.ParentPlanogramId AS C_ParentPlanogramId
	,PARENT_POG.PlanogramId AS P_PlanogramId
	,PARENT_POG.ParentPlanogramId AS P_ParentPlanogramId
	,CHILD_POG.SCDStartDate AS C_SCDStartDate
	,CHILD_POG.SCDEndDate AS C_SCDEndDate
	,PARENT_POG.SCDStartDate AS P_SCDStartDate
	,PARENT_POG.SCDEndDate AS P_SCDEndDate

FROM
	con_mon.VW_PLANOGRAM_AM AS CHILD_POG

	LEFT JOIN con_mon.TMP_PLANOGRAM_AM_DATE_RANGE AS DATES
	ON CHILD_POG.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < CHILD_POG.SCDEndDate

	LEFT JOIN con_mon.VW_PLANOGRAM_AM AS PARENT_POG
	ON CHILD_POG.ParentPlanogramId = PARENT_POG.PlanogramId
	AND PARENT_POG.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < PARENT_POG.SCDEndDate

WHERE
	CHILD_POG.RECORD_SOURCE_KEY = N'BTCBY'

	AND CHILD_POG.ParentPlanogramId IS NOT NULL
	AND PARENT_POG.PlanogramId IS NULL

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that all Blue Yonder planograms that have a non-NULL parent FK do indeed link to a parent', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Test: Check that all Blue Yonder 'BY Planogram Family Key' planograms are indeed parents of another planogram
-- Prerequisites: Above tests must have passed
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM (
SELECT
	PARENT_POG.RECORD_SOURCE_KEY AS P_RECORD_SOURCE_KEY
	,CHILD_POG.RECORD_SOURCE_KEY AS C_RECORD_SOURCE_KEY
	,PARENT_POG.SK_TYPE_KEY AS P_SK_TYPE_KEY
	,CHILD_POG.SK_TYPE_KEY AS C_SK_TYPE_KEY
	,PARENT_POG.PlanogramId AS P_PlanogramId
	,PARENT_POG.ParentPlanogramId AS P_ParentPlanogramId
	,CHILD_POG.PlanogramId AS C_PlanogramId
	,CHILD_POG.ParentPlanogramId AS C_ParentPlanogramId
	,PARENT_POG.SCDStartDate AS P_SCDStartDate
	,PARENT_POG.SCDEndDate AS P_SCDEndDate
	,CHILD_POG.SCDStartDate AS C_SCDStartDate
	,CHILD_POG.SCDEndDate AS C_SCDEndDate

FROM
	con_mon.VW_PLANOGRAM_AM AS PARENT_POG

	LEFT JOIN con_mon.TMP_PLANOGRAM_AM_DATE_RANGE AS DATES
	ON PARENT_POG.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < PARENT_POG.SCDEndDate

	LEFT JOIN con_mon.VW_PLANOGRAM_AM AS CHILD_POG
	ON PARENT_POG.PlanogramId = CHILD_POG.ParentPlanogramId
	AND CHILD_POG.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < CHILD_POG.SCDEndDate

WHERE
	PARENT_POG.SK_TYPE_KEY = N'BY Planogram Family Key'
	AND CHILD_POG.PlanogramId IS NULL

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that all Blue Yonder ''BY Planogram Family Key'' planograms are indeed parents of another planogram', @P_RUN_DATE, @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------
-- Drop temp tables

IF OBJECT_ID (N'con_mon.TMP_PLANOGRAM_AM_DATE_RANGE', N'U') IS NOT NULL
	DROP TABLE con_mon.TMP_PLANOGRAM_AM_DATE_RANGE
;

END
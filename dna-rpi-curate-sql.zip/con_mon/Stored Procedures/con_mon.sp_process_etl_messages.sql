﻿CREATE PROCEDURE con_mon.sp_process_etl_messages
	@MonitorID BIGINT 
AS

/*
ProcedureName : [con_mon.sp_process_etl_messages]
Purpose       : Process all ETL Messages which have been added since the last time it's ran
*/

BEGIN

	DECLARE @fromdate DATETIME, @todate DATETIME

	SELECT @todate = Monitor_Datetime FROM [con_mon].[monitor_master]
	WHERE Monitor_ID = @MonitorID

	SELECT @fromdate = Monitor_Datetime FROM [con_mon].[monitor_master]
	WHERE Monitor_ID = (@MonitorID-1)

	IF @fromdate IS NULL
	  SET @fromdate = '1900-01-01 00:00:00.000'

	insert into [con_mon].[process_etl_messages]
	(
	RuleEntityInstanceID,
	Monitor_ID,
	Project_ID,
	Feed_ID,
	Entity_Code,
	Attribute_Name,
	Attribute_Description,
	Rule_Name,
	Rule_Detail,
	Time_Created,
	ETLRunLogID,
	PSARowKey
	)
	select 
	rei.RuleEntityInstanceID,
	@MonitorID as Monitor_ID,
	so.ProjectID as Project_ID,
	so.FeedID as Feed_ID,
	e.EntityCode as Entity_Code,
	a.AttributeName as Attribute_Name,
	a.AttributeDescription as Attribute_Description,
	r.RuleName as Rule_Name,
	rei.RuleDetail as Rule_Detail,
	rei.DTCreated as Time_Created,
	rei.ETLRunLogID,
	rei.PSARowKey

	from [psa].[RuleEntityInstance] rei
	-- Change this is new Table of Feeds + Entites + Attributes
	inner join psa.Entity e ON (e.EntityID = rei.EntityID)
	inner join psa.Attribute a ON (a.AttributeID = rei.AttributeID)
	--
	inner join psa.[Rule] r ON (rei.RuleID = r.RuleID)
	-- New Table
	LEFT OUTER JOIN (	select DISTINCT 
						ProjectID,
						FeedID,
						EntityID,
						EntityCode ,
						TargetMapping2
						from [con_mon].[source_feed_info] ) so ON (rei.EntityID = so.TargetMapping2)

	WHERE rei.DTCreated BETWEEN @fromdate AND @todate

END

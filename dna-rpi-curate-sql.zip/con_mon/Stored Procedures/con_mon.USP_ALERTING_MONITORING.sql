﻿/****** Object:  StoredProcedure [con_mon].[USP_ALERTING_MONITORING]    Script Date: 5/25/2023 9:35:05 AM ******/

CREATE PROC [con_mon].[USP_ALERTING_MONITORING] @P_PROJECT_NAME [VARCHAR](max),@P_RUN_DATE [DATETIME] AS

/*************************************************************************************************************************
Procedure Name					: USP_ALERTING_MONITORING
Purpose							: Stored Procedure for UAT Automation Testing	

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

25-05-2023   :  Mayank Bhardwaj		  : Initial Version
**************************************************************************************************************************/

BEGIN

IF @P_PROJECT_NAME = 'rprs'
	
	BEGIN

		EXEC [con_mon].[USP_PLANOGRAM_SITE_ROLE_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_POSITION_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_MEASURE_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_CHARACTERISTIC_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_FIXTURE_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_FLOOR_PLAN_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_FLOOR_PLAN_STATUS_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_GROUP_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_INDICATOR_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_POSITION_PROPERTY_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_PROPERTY_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PLANOGRAM_STATUS_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_PRODUCT_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_REFLOV_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_REFLOVSET_AM] @P_RUN_DATE
		EXEC [con_mon].[USP_SITE_ROLE_AM] @P_RUN_DATE

	END


END
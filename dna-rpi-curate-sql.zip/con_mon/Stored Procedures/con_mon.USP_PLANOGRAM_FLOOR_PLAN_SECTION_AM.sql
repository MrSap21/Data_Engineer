﻿CREATE PROC [con_mon].[USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM] @P_RUN_DATE [DATETIME] AS 
 
/*************************************************************************************************************************
Procedure Name					: USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM
Purpose							: UAT Automation Testing for ser.PlanogramFloorPlanSection		

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

25-05-2023   :  Rohit Shaw	          : Initial Version
**************************************************************************************************************************/
BEGIN

DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
 
DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM';
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.PlanogramFloorPlanSection';
DECLARE @V_ROW_COUNT bigint;
DECLARE @V_ALERT_FLAG bigint;
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;

---------------------------------------------------------------------------------
---- Drop and recreate the con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE temp table

IF OBJECT_ID (N'con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE', N'U') IS NOT NULL
	DROP TABLE con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE
;

CREATE TABLE con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE
WITH
(
	CLUSTERED INDEX (SCD_START_UBOUND ASC, SCD_END_LBOUND ASC)
	,DISTRIBUTION = REPLICATE
)
AS

---------------------------------------------------------------------------------

---- Insert into the con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE temp table the distinct SCDStartDate values from the table being
---- tested, which should therefore be the full list of datetimes that need to be tested to get full coverage of all the data
---- in that table. 

	SELECT DISTINCT
		VW_FP_SECT.SCDStartDate AS SCD_START_UBOUND
		,DATEADD(SECOND, -1, VW_FP_SECT.SCDStartDate) AS SCD_END_LBOUND
	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM AS VW_FP_SECT
	WHERE
		VW_FP_SECT.RECORD_SOURCE_KEY = N'BTCBY'

	UNION

	SELECT DISTINCT
		VW_FP.SCDStartDate AS SCD_START_UBOUND
		,DATEADD(SECOND, -1, VW_FP.SCDStartDate) AS SCD_END_LBOUND
	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_AM AS VW_FP
	WHERE
		VW_FP.RECORD_SOURCE_KEY = N'BTCBY'
;

---------------------------------------------------------------------------------

---- Test: Check for duplicate record sources per surrogate business ID
---- Expected result: No rows returned

SELECT  @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	PlanogramFloorPlanSectionId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM
GROUP BY
	PlanogramFloorPlanSectionId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
 
)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for duplicate record sources per surrogate business ID',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for duplicate record sources per composite business key
---- Expected result: No rows returned

SELECT  @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	PlanogramFloorPlanId
	,SourceKey
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM
GROUP BY
	PlanogramFloorPlanId
	,SourceKey
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
 )a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for duplicate record sources per composite business key',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Check for how many delta changes have taken place in the table

SET @V_DELTA_COUNT_1 = 
(
SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

SET @V_DELTA_COUNT_2 =
(
SELECT
	COUNT(*) AS DISTINCT_P_POSITIONS
FROM
	(
		SELECT DISTINCT
			PlanogramFloorPlanSectionId
		FROM
			con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
	) AS QRY_DISTINCTS
)
SET  @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 0 ELSE 1 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME,'Check for how many delta changes have taken place in the table', @P_RUN_DATE, @V_ROW_COUNT,'Y',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for NULL start or end datetimes or active flags
---- Expected result: No rows returned

SELECT  @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	*
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	AND RECORD_SOURCE_KEY = N'BTCBY'
 
)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for NULL start or end datetimes or active flags',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for back-to-front start and end datetimes
---- Expected result: No rows returned

SELECT  @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	*
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM
WHERE
	-- In Curate each record is active from and including SCDStartDate up to but not including SCDEndDate + 1 second
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for back-to-front start and end datetimes',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);


---------------------------------------------------------------------------------

---- Test: Check for multiple surrogate business IDs per composite business key
---- Expected result: No rows returned

WITH CTE_DISTINCT_SURROGATES AS
(
	SELECT
		PlanogramFloorPlanId
		,SourceKey
		,COUNT(*) AS DISTINCT_SURROGATE_IDS
	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_DISTINCT_AM
	GROUP BY
		PlanogramFloorPlanId
		,SourceKey
	HAVING
		COUNT(*) > 1
)
SELECT  @V_ROW_COUNT = COUNT(*) FROM 
(
SELECT  
	CTE_DISTINCT_SURROGATES.DISTINCT_SURROGATE_IDS
	,VW_FP_SECT.*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM AS VW_FP_SECT

	INNER JOIN CTE_DISTINCT_SURROGATES
	ON VW_FP_SECT.PlanogramFloorPlanId = CTE_DISTINCT_SURROGATES.PlanogramFloorPlanId
	AND VW_FP_SECT.SourceKey = CTE_DISTINCT_SURROGATES.SourceKey

WHERE
	VW_FP_SECT.RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for multiple surrogate business IDs per composite business key',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);


---------------------------------------------------------------------------------

---- Test: Check for multiple composite business keys per surrogate business ID
---- Expected result: No rows returned

WITH CTE_DISTINCT_COMPOSITES AS
(
	SELECT
		PlanogramFloorPlanSectionId
		,COUNT(*) AS DISTINCT_COMPOSITE_KEYS
	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_DISTINCT_AM
	GROUP BY
		PlanogramFloorPlanSectionId
	HAVING
		COUNT(*) > 1
)

SELECT  @V_ROW_COUNT = COUNT(*) FROM 
(
SELECT  
	CTE_DISTINCT_COMPOSITES.DISTINCT_COMPOSITE_KEYS
	,VW_FP_SECT.*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM AS VW_FP_SECT

	INNER JOIN CTE_DISTINCT_COMPOSITES
	ON VW_FP_SECT.PlanogramFloorPlanSectionId = CTE_DISTINCT_COMPOSITES.PlanogramFloorPlanSectionId

WHERE
	VW_FP_SECT.RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for multiple composite business keys per surrogate business ID',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for rows with identical start and end datetimes
---- Expected result: No rows returned

SELECT  @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	COUNT(*) AS DUPLICATES
	,PlanogramFloorPlanSectionId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramFloorPlanSectionId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1
 
)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for rows with identical start and end datetimes',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for overlapping or underlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

-- Check for SCD overlaps

SELECT  @V_ROW_COUNT = COUNT(*) FROM 
(
SELECT  
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramFloorPlanSectionId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate

	 
)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for overlapping start-end periods',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---- Check for SCD underlaps (i.e. gaps)


SELECT  @V_ROW_COUNT = COUNT(*) FROM 
(
SELECT  
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramFloorPlanSectionId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	 

	---- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate

)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for underlapping start-end periods',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not start on 1900-01-01
---- Expected result: No rows returned

WITH CTE_LATE_STARTS AS
(
	SELECT  
		PlanogramFloorPlanSectionId

	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM

	WHERE
	RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramFloorPlanSectionId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
		 
)
SELECT  @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_FP_SECT.*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM AS VW_FP_SECT

	INNER JOIN CTE_LATE_STARTS
	ON VW_FP_SECT.PlanogramFloorPlanSectionId = CTE_LATE_STARTS.PlanogramFloorPlanSectionId

 
)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for entities whose lives do not start on 1900-01-01',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
---- Expected result: No rows returned

SELECT  @V_ROW_COUNT = COUNT(*) FROM 
(
SELECT  
	*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM

WHERE
	(
		(SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
		OR
		(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y')
	)

	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);


---------------------------------------------------------------------------------

---- Test: Check that all FP section rows are covered by at least one of the test dates
---- Expected result: No rows returned

SELECT  @V_ROW_COUNT = COUNT(*) FROM 
(
SELECT  
	DATES.*
	,VW_FP_SECT.*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM AS VW_FP_SECT

	LEFT JOIN con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE AS DATES
	ON VW_FP_SECT.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < VW_FP_SECT.SCDEndDate
	
WHERE
	-- Failed left join
	DATES.SCD_START_UBOUND IS NULL

	AND VW_FP_SECT.RECORD_SOURCE_KEY = N'BTCBY'

 	)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that all FP section rows are covered by at least one of the test dates',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);

 

-----------------------------------------------------------------------------------
 
---- Test: Check that all Blue Yonder FP rows are covered by at least one of the test dates
---- Expected result: No rows returned

SELECT  @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	DATES.*
	,VW_FP.*

FROM
	con_mon.VW_PLANOGRAM_FLOOR_PLAN_AM AS VW_FP

	LEFT JOIN con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE AS DATES
	ON VW_FP.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < VW_FP.SCDEndDate

WHERE
	-- Failed left join
	DATES.SCD_START_UBOUND IS NULL

	AND VW_FP.RECORD_SOURCE_KEY = N'BTCBY'
	)a

SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT>0 THEN 1 ELSE 0 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that all Blue Yonder FP rows are covered by at least one of the test dates',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);
 
 ----------------------------------------------------------------------------------------------------------------
 -- Test: Check that Blue Yonder floor plan sections all and only link to child Blue Yonder floor plans, 
-- and Blue Yonder floor plans are never linked to from a floor plan section of another record source

-- Expected result:
-- At least the following two rows returned:
--		FP_SECT_RS_KEY		FP_RS_KEY		FP_SK_TYPE_KEY
--		'BTCBY'				'BTCBY'			'BY Planogram Store FP Key'
--		NULL				'BTCBY'			'BY Planogram Store Family Key'
-- Possibly the following one additional row returned: 
--		FP_SECT_RS_KEY		FP_RS_KEY		FP_SK_TYPE_KEY
--		NULL				'BTCBY'			'BY Planogram Store FP Key'
-- No other rows returned


WITH CTE_FP_SECT_WITH_DATES AS
(
	SELECT
		DATES.SCD_START_UBOUND
		,VW_FP_SECT.*

	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_SECTION_AM AS VW_FP_SECT

		INNER JOIN con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE AS DATES
		ON VW_FP_SECT.SCDStartDate <= DATES.SCD_START_UBOUND
		AND DATES.SCD_END_LBOUND < VW_FP_SECT.SCDEndDate
)

 ,CTE_FP_WITH_DATES AS
(
	SELECT
		DATES.SCD_START_UBOUND
		,VW_FP.*

	FROM
		con_mon.VW_PLANOGRAM_FLOOR_PLAN_AM AS VW_FP

		INNER JOIN con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE AS DATES
		ON VW_FP.SCDStartDate <= DATES.SCD_START_UBOUND
		AND DATES.SCD_END_LBOUND < VW_FP.SCDEndDate
)



-- New test version, rewritten to be two subset tests. 

-- Test: Check for expected Blue Yonder record source and source key type combinations
-- Define expected and actual results sets as CTEs

,CTE_RS_SK_COMBOS_ACTUALS AS
(
	SELECT DISTINCT
		FP_SECT.RECORD_SOURCE_KEY AS FP_SECT_RS_KEY
		,FP.RECORD_SOURCE_KEY AS FP_RS_KEY
		,FP.SK_TYPE_KEY AS FP_SK_TYPE_KEY

	FROM
		CTE_FP_SECT_WITH_DATES AS FP_SECT

		FULL OUTER JOIN CTE_FP_WITH_DATES AS FP
		ON FP_SECT.PlanogramFloorPlanId = FP.PlanogramFloorPlanId
		AND FP_SECT.SCD_START_UBOUND = FP.SCD_START_UBOUND

	WHERE
		N'BTCBY' IN (FP_SECT.RECORD_SOURCE_KEY, FP.RECORD_SOURCE_KEY)
)

,CTE_RS_SK_COMBOS_EXPECTED AS
(
	SELECT N'BTCBY' AS FP_SECT_RS_KEY, N'BTCBY' AS FP_RS_KEY, N'BY Planogram Store FP Key' AS FP_SK_TYPE_KEY, 1 AS REQUIRED
	UNION ALL
	SELECT NULL AS FP_SECT_RS_KEY, N'BTCBY' AS FP_RS_KEY, N'BY Planogram Store Family Key' AS FP_SK_TYPE_KEY, 1 AS REQUIRED
	UNION ALL
	SELECT NULL AS FP_SECT_RS_KEY, N'BTCBY' AS FP_RS_KEY, N'BY Planogram Store FP Key' AS FP_SK_TYPE_KEY, 0 AS REQUIRED
)



 SELECT  @V_ROW_COUNT = COUNT(*) FROM 
(
(
 SELECT FP_SECT_RS_KEY, FP_RS_KEY, FP_SK_TYPE_KEY FROM CTE_RS_SK_COMBOS_EXPECTED WHERE REQUIRED = 1
  EXCEPT
 SELECT FP_SECT_RS_KEY, FP_RS_KEY, FP_SK_TYPE_KEY FROM CTE_RS_SK_COMBOS_ACTUALS
)
  UNION
(
 SELECT FP_SECT_RS_KEY, FP_RS_KEY, FP_SK_TYPE_KEY FROM CTE_RS_SK_COMBOS_ACTUALS
  EXCEPT
 SELECT FP_SECT_RS_KEY, FP_RS_KEY, FP_SK_TYPE_KEY FROM CTE_RS_SK_COMBOS_EXPECTED
)
)a


SET @V_ALERT_FLAG = (CASE WHEN  @V_ROW_COUNT=0 THEN 0 ELSE 1 END);

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME, @V_SP_NAME, 'Check that Blue Yonder floor plan sections all and only link to child Blue Yonder floor plans, and Blue Yonder floor plans are never linked to from a floor plan section of another record source',  @P_RUN_DATE,  @V_ROW_COUNT, 'N', @V_ALERT_FLAG);
 
-------------------------------------------------------------------------------------------------------------

---- Drop temp tables 

 
IF OBJECT_ID (N'con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE', N'U') IS NOT NULL
	DROP TABLE con_mon.TMP_USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM_DATE_RANGE
;



END
﻿/****** Object:  StoredProcedure [con_mon].[USP_REFLOVSET_AM]    Script Date: 5/25/2023 8:17:48 AM ******/

CREATE PROC [con_mon].[USP_REFLOVSET_AM] @P_RUN_DATE [DATETIME] AS

/*************************************************************************************************************************
Procedure Name					: USP_REFLOVSET_AM
Purpose							: UAT Automation Testing for ser.REFLOVSET table		

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

25-05-2023   :  Rohit Shaw		      :Initial Version
  
**************************************************************************************************************************/

BEGIN
   
DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
DECLARE @V_SP_NAME VARCHAR(200) =  'con_mon.USP_REFLOVSET_AM'
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.RefLOVSet';
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
 
 
  

-----------------------------------------------------------------------------------------------
-- Test: Check for multiple active records per surrogate ID. Check this for all record sources. 
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT  
	*
FROM
	con_mon.VW_REFLOVSET_AM
WHERE
	DUPES <> 1
  
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for multiple active records per surrogate ID', @P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
 

END
﻿/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_SITE_ROLE_AM]    Script Date: 5/25/2023 10:10:21 AM ******/

CREATE PROC [con_mon].[USP_PLANOGRAM_SITE_ROLE_AM] @P_RUN_DATE [DATETIME] AS

/*************************************************************************************************************************
Procedure Name					: USP_PLANOGRAM_SITE_ROLE_AM
Purpose							: UAT Automation Testing for ser.PlanogramSiteRole table		

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

24-05-2023   :  Mayank Bhardwaj		  : Initial Version
**************************************************************************************************************************/

BEGIN

DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.PlanogramSiteRole';
DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_SITE_ROLE_AM';
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;
---------------------------------------------------------------------------------------------------

---- Create and populate con_mon.TMP_USP_PLANOGRAM_SITE_ROLE_AM_DATE_RANGE temp table
---- Create this as a replicated clustered row indexed table to optimise subsequent use of the table

IF OBJECT_ID (N'con_mon.TMP_USP_PLANOGRAM_SITE_ROLE_AM_DATE_RANGE', N'U') IS NOT NULL	
	DROP TABLE con_mon.TMP_USP_PLANOGRAM_SITE_ROLE_AM_DATE_RANGE
;

CREATE TABLE con_mon.TMP_USP_PLANOGRAM_SITE_ROLE_AM_DATE_RANGE
WITH
(
	CLUSTERED INDEX (SCD_START_UBOUND ASC, SCD_END_LBOUND ASC)
	,DISTRIBUTION = REPLICATE
)
AS

---- Insert into the con_mon.TMP_USP_PLANOGRAM_SITE_ROLE_AM_DATE_RANGE temp table the distinct SCDStartDate values from the table being
---- tested, which should therefore be the full list of datetimes that need to be tested to get full coverage of all the data
---- in that table. 

SELECT DISTINCT
	VW_P2SR.SCDStartDate AS SCD_START_UBOUND
	,DATEADD(SECOND, -1, VW_P2SR.SCDStartDate) AS SCD_END_LBOUND
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM AS VW_P2SR
WHERE
	VW_P2SR.RECORD_SOURCE_KEY = N'BTCBY'
;

---------------------------------------------------------------------------------------------

---- Test: Check for duplicate record sources per surrogate business ID
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	PlanogramSiteRoleId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM
GROUP BY
	PlanogramSiteRoleId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for duplicate record sources per surrogate business ID',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------------------

---- Test: Check for duplicate record sources per composite business key
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	PlanogramId
	,SiteRoleId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM
GROUP BY
	PlanogramId
	,SiteRoleId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for duplicate record sources per composite business key',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
------------------------------------------------------------------------------------------------

---- Check for how many delta changes have taken place in the table

SET @V_DELTA_COUNT_1 =
(
SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

SET @V_DELTA_COUNT_2 =
(
SELECT
	COUNT(*) AS DISTINCT_P2SR
FROM
	(
		SELECT DISTINCT
			PlanogramSiteRoleId
		FROM
			con_mon.VW_PLANOGRAM_SITE_ROLE_AM
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
	) AS QRY_DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for how many delta changes have taken place in the table',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------

---- Test: Check for NULL start or end datetimes or active flags
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for NULL start or end datetimes or active flags',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------

---- Test: Check for back-to-front start and end datetimes
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM
WHERE
	--In Curate each record is active from and including SCDStartDate up to but not including SCDEndDate + 1 second
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for back-to-front start and end datetimes',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-----------------------------------------------------------------------------------------------

---- Test: Check for multiple surrogate business IDs per composite business key
---- Expected result: No rows returned

WITH CTE_DISTINCT_SURROGATES AS
(
	SELECT
		PlanogramId
		,SiteRoleId
		,COUNT(*) AS DISTINCT_SURROGATE_IDS
	FROM
		con_mon.VW_PLANOGRAM_SITE_ROLE_DISTINCT_AM
	GROUP BY
		PlanogramId
		,SiteRoleId
	HAVING
		COUNT(*) > 1
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	CTE_DISTINCT_SURROGATES.DISTINCT_SURROGATE_IDS
	,VW_P2SR.*

FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM AS VW_P2SR

	INNER JOIN CTE_DISTINCT_SURROGATES
	ON VW_P2SR.PlanogramId = CTE_DISTINCT_SURROGATES.PlanogramId
	AND VW_P2SR.SiteRoleId = CTE_DISTINCT_SURROGATES.SiteRoleId

WHERE
	VW_P2SR.RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for multiple surrogate business IDs per composite business key',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-----------------------------------------------------------------------------------------------------------

---- Test: Check for multiple composite business keys per surrogate business ID
---- Expected result: No rows returned

WITH CTE_DISTINCT_COMPOSITES AS
(
	SELECT
		PlanogramSiteRoleId
		,COUNT(*) AS DISTINCT_COMPOSITE_KEYS
	FROM
		con_mon.VW_PLANOGRAM_SITE_ROLE_DISTINCT_AM
	GROUP BY
		PlanogramSiteRoleId
	HAVING
		COUNT(*) > 1
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	CTE_DISTINCT_COMPOSITES.DISTINCT_COMPOSITE_KEYS
	,VW_P2SR.*

FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM AS VW_P2SR

	INNER JOIN CTE_DISTINCT_COMPOSITES
	ON VW_P2SR.PlanogramSiteRoleId = CTE_DISTINCT_COMPOSITES.PlanogramSiteRoleId

WHERE
	VW_P2SR.RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for multiple composite business keys per surrogate business ID',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
------------------------------------------------------------------------------------------------------------

---- Test: Check for rows with identical start and end datetimes
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	COUNT(*) AS DUPLICATES
	,PlanogramSiteRoleId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramSiteRoleId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for rows with identical start and end datetimes',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
----------------------------------------------------------------------------------------------------

---- Test: Check for overlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*
FROM
	(
		SELECT
			*
			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramSiteRoleId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_SITE_ROLE_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for overlapping start-end periods',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
----------------------------------------------------------------------------------------------

---- Test: Check for underlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*
FROM
	(
		SELECT
			*
			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramSiteRoleId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_SITE_ROLE_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	---- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for underlapping start-end periods',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-------------------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not start on 1900-01-01
---- Expected result: No rows returned

WITH CTE_LATE_STARTS AS
(
	SELECT
		PlanogramSiteRoleId

	FROM
		con_mon.VW_PLANOGRAM_SITE_ROLE_AM

	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramSiteRoleId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_P2SR.*
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM AS VW_P2SR

	INNER JOIN CTE_LATE_STARTS
	ON VW_P2SR.PlanogramSiteRoleId = CTE_LATE_STARTS.PlanogramSiteRoleId
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not start on 1900-01-01',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-----------------------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not end on 9999-12-31
---- Expected result: No rows returned

WITH CTE_EARLY_ENDS AS
(
	SELECT
		PlanogramSiteRoleId

	FROM
		con_mon.VW_PLANOGRAM_SITE_ROLE_AM

	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramSiteRoleId

	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_P2SR.*

FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM AS VW_P2SR

	INNER JOIN CTE_EARLY_ENDS
	ON VW_P2SR.PlanogramSiteRoleId = CTE_EARLY_ENDS.PlanogramSiteRoleId
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not end on 9999-12-31',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------

-- Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
-- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM

WHERE
	(
		(SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
		OR
		(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y')
	)

	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------------------------------

------ Test: Check that all Blue Yonder planogram-to-siterole rows successfully link to ser.SiteRole
------ Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_P2SR.*
	,SITES.SiteRoleId AS SITES_SiteRoleId
FROM
	con_mon.VW_PLANOGRAM_SITE_ROLE_AM AS VW_P2SR

	LEFT JOIN con_mon.TMP_USP_PLANOGRAM_SITE_ROLE_AM_DATE_RANGE AS DATES
	ON VW_P2SR.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < VW_P2SR.SCDEndDate

	LEFT JOIN ser.SiteRole AS SITES
	ON VW_P2SR.SiteRoleId = SITES.SiteRoleId
	AND SITES.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < SITES.SCDEndDate

WHERE
	VW_P2SR.RECORD_SOURCE_KEY = N'BTCBY'
	AND SITES.SiteRoleId IS NULL
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check that all Blue Yonder planogram-to-siterole rows successfully link to ser.SiteRole',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
------------------------------------------------------------------------------------------------------------

---- Drop temp tables

IF OBJECT_ID (N'con_mon.TMP_USP_PLANOGRAM_SITE_ROLE_AM_DATE_RANGE', N'U') IS NOT NULL
	DROP TABLE con_mon.TMP_USP_PLANOGRAM_SITE_ROLE_AM_DATE_RANGE
;
------------------------------------------------------------------------------------------------------

END
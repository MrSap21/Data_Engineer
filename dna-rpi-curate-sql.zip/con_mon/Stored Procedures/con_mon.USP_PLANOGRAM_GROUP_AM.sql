﻿CREATE PROC [con_mon].[USP_PLANOGRAM_GROUP_AM] @P_RUN_DATE [DATETIME] AS
/*************************************************************************************************************************
Procedure Name					: USP_PLANOGRAM_GROUP_AM
Purpose							: UAT Automation Testing for ser.PlanogramGroup table		

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

25-05-2023   :  Ritikh Gunnala		  : Initial Version		  
**************************************************************************************************************************/


BEGIN
    
DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.PlanogramGroup';
DECLARE @V_ADD_COUNT BIGINT;
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_NO_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_GROUP_AM'
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;

-----------------------------------------------------------------------------------------------

---- Check for how many delta changes have taken place in the table

SET @V_DELTA_COUNT_1 =
(
SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_GROUP_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

SET @V_DELTA_COUNT_2 =
(
SELECT
	COUNT(*) AS DISTINCT_P_GROUPS
FROM
	(
		SELECT DISTINCT
			PlanogramGroupId
		FROM
			con_mon.VW_PLANOGRAM_GROUP_AM
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
	) AS QRY_DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for how many delta changes have taken place in the table',@P_RUN_DATE,@V_ROW_COUNT,'Y',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for NULL start or end datetimes or active flags
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_GROUP_AM
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for NULL start or end datetimes or active flags',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for back-to-front start and end datetimes
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_GROUP_AM
WHERE
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for back-to-front start and end datetimes',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for multiple surrogate business IDs per composite business key
---- Expected result: No rows returned


WITH CTE_DISTINCT_SURROGATES AS
(
SELECT
	PlanogramId
	,GROUP_SET_NAME
	,COUNT(*) AS DISTINCT_SURROGATE_IDS
FROM
	con_mon.VW_PLANOGRAM_GROUP_DISTINCT_AM
GROUP BY
	PlanogramId
	,GROUP_SET_NAME
HAVING
	COUNT(*) > 1
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	CTE_DISTINCT_SURROGATES.DISTINCT_SURROGATE_IDS
	,VW_GROUP.*

FROM
	con_mon.VW_PLANOGRAM_GROUP_AM as VW_GROUP

	INNER JOIN CTE_DISTINCT_SURROGATES
	ON VW_GROUP.PlanogramId = CTE_DISTINCT_SURROGATES.PlanogramId
	AND VW_GROUP.GROUP_SET_NAME = CTE_DISTINCT_SURROGATES.GROUP_SET_NAME

WHERE
	VW_GROUP.RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for multiple surrogate business IDs per composite business key',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for multiple composite business keys per surrogate business ID
---- Expected result: No rows returned


WITH CTE_DISTINCT_COMPOSITES AS
(
SELECT
	PlanogramGroupId
	,COUNT(*) AS DISTINCT_COMPOSITE_KEYS
FROM
	con_mon.VW_PLANOGRAM_GROUP_DISTINCT_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramGroupId
HAVING
	COUNT(*) > 1
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	CTE_DISTINCT_COMPOSITES.DISTINCT_COMPOSITE_KEYS
	,VW_GROUP.*

FROM
	con_mon.VW_PLANOGRAM_GROUP_AM as VW_GROUP

	INNER JOIN CTE_DISTINCT_COMPOSITES
	ON VW_GROUP.PlanogramGroupId = CTE_DISTINCT_COMPOSITES.PlanogramGroupId

WHERE
	VW_GROUP.RECORD_SOURCE_KEY = N'BTCBY'


)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,' Check for multiple composite business keys per surrogate business ID',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for rows with identical start and end datetimes
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	COUNT(*) AS DUPLICATES
	,PlanogramGroupId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_GROUP_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramGroupId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for rows with identical start and end datetimes',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------

---------------------------------------------------------------------------------

---- Test: Check for overlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramGroupId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_GROUP_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate

)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for overlapping start-end periods',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

------------------------------------------------------------------------------------------------------
---- Test: Check for underlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramGroupId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_GROUP_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	---- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate

)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for underlapping start-end periods',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not start on 1900-01-01
---- Expected result: No rows returned

 WITH CTE_LATE_STARTS AS
(
	SELECT
		PlanogramGroupId

	FROM
		con_mon.VW_PLANOGRAM_GROUP_AM

	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramGroupId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_GROUP.*

FROM
	con_mon.VW_PLANOGRAM_GROUP_AM AS VW_GROUP

	INNER JOIN CTE_LATE_STARTS
	ON VW_GROUP.PlanogramGroupId = CTE_LATE_STARTS.PlanogramGroupId

)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not start on 1900-01-01',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not end on 9999-12-31
---- Expected result: No rows returned

 WITH CTE_EARLY_ENDS AS
(
	SELECT
		PlanogramGroupId

	FROM
		con_mon.VW_PLANOGRAM_GROUP_AM

	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramGroupId

	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
)
SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_GROUP.*

FROM
	con_mon.VW_PLANOGRAM_GROUP_AM AS VW_GROUP

	INNER JOIN CTE_EARLY_ENDS
	ON VW_GROUP.PlanogramGroupId = CTE_EARLY_ENDS.PlanogramGroupId

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not end on 9999-12-31',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*

FROM
	con_mon.VW_PLANOGRAM_GROUP_AM

WHERE
	(
		(SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
		OR
		(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y')
	)

	AND RECORD_SOURCE_KEY = N'BTCBY'
)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check which distinct planogram group sets are showing in the data
---- Expected result: 11 rows returned showing the following values for GROUP_SET_NAME: 
----		Ad-Hoc avg Service Level
----		Company
----		Department
----		Footprint
----		Part module number
----		Planner Family
----		POG Type
----		POGCategory
----		SP Period No
----		Store Format
----		Version Number


WITH CTE_GROUP_SET_ACTUALS AS
(
	SELECT DISTINCT GROUP_SET_NAME FROM con_mon.VW_PLANOGRAM_GROUP_AM WHERE RECORD_SOURCE_KEY = N'BTCBY'
)

,CTE_GROUP_SET_EXPECTED AS
(
	SELECT N'Ad-Hoc avg Service Level' AS GROUP_SET_NAME
	UNION
	SELECT N'Company' AS GROUP_SET_NAME
	UNION
	SELECT N'Department' AS GROUP_SET_NAME
	UNION
	SELECT N'Footprint' AS GROUP_SET_NAME
	UNION
	SELECT N'Part module number' AS GROUP_SET_NAME
	UNION
	SELECT N'Planner Family' AS GROUP_SET_NAME
	UNION
	SELECT N'POG Type' AS GROUP_SET_NAME
	UNION
	SELECT N'POGCategory' AS GROUP_SET_NAME
	UNION
	SELECT N'SP Period No' AS GROUP_SET_NAME
	UNION
	SELECT N'Store Format' AS GROUP_SET_NAME
	UNION
	SELECT N'Version Number' AS GROUP_SET_NAME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(

(
SELECT * FROM CTE_GROUP_SET_EXPECTED
EXCEPT
SELECT * FROM CTE_GROUP_SET_ACTUALS
)

UNION

(
SELECT * FROM CTE_GROUP_SET_ACTUALS
EXCEPT
SELECT * FROM CTE_GROUP_SET_EXPECTED
)

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT = 0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check which distinct planogram group sets are showing in the data',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-----------------------------------------------------------------------------------------------


END
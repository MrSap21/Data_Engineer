﻿CREATE PROC [con_mon].[USP_PLANOGRAM_PROPERTY_AM] @P_RUN_DATE [DATETIME] AS

/*************************************************************************************************************************
Procedure Name					: USP_PLANOGRAM_PROPERTY_AM
Purpose							: UAT Automation Testing for ser.PlanogramProperty table		

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

25-05-2023   :  Ritikh Gunnala		  : Initial Version		  
**************************************************************************************************************************/


BEGIN

DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.PlanogramProperty';
DECLARE @V_ADD_COUNT BIGINT;
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_NO_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_PROPERTY_AM'
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;


---------------------------------------------------------------------------------

---- Test: Check for inconsistent record sources
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT DISTINCT
	LOVRecordSourceId
	,RECORD_SOURCE_KEY
	,RECORD_SOURCE_NAME

	,MEASURE_LOVRecordSourceId
	,MEASURE_RECORD_SOURCE_KEY
	,MEASURE_RECORD_SOURCE_NAME

FROM
	con_mon.VW_PLANOGRAM_PROPERTY_AM

WHERE
	LOVRecordSourceId IS NULL
	OR MEASURE_LOVRecordSourceId IS NULL
	OR LOVRecordSourceId <> MEASURE_LOVRecordSourceId

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for inconsistent record sources',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------

---- Test: Check for duplicate record sources
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	PlanogramId
	,MeasureId
	,MAX(CASE WHEN LOVRecordSourceId IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_PROPERTY_AM
GROUP BY
	PlanogramId
	,MeasureId
HAVING
	MAX(CASE WHEN LOVRecordSourceId IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOVRecordSourceId) <> 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for duplicate record sources',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------

---- Check for how many delta changes have taken place in the table

SET @V_DELTA_COUNT_1 =
(
SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_PROPERTY_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

SET @V_DELTA_COUNT_2 =
(
SELECT
	COUNT(*) AS DISTINCT_P_PROPS
FROM
	(
		SELECT DISTINCT
			PlanogramId
			,MeasureId
		FROM
			con_mon.VW_PLANOGRAM_PROPERTY_AM
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
	) AS DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for how many delta changes have taken place in the table',@P_RUN_DATE,@V_ROW_COUNT,'Y',@V_ALERT_FLAG);

---------------------------------------------------------------------------------
---- Test: Check for NULL start or end datetimes or active flags
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_PROPERTY_AM
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	 AND RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for NULL start or end datetimes or active flags',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

---------------------------------------------------------------------------------

---- Test: Check for back-to-front start and end datetimes
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_PROPERTY_AM
WHERE
	
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'

)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for back-to-front start and end datetimes',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------------------
---- Test: Check for rows with identical start and end datetimes
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	COUNT(*) AS DUPLICATES
	,PlanogramId
	,MeasureId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_PROPERTY_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramId
	,MeasureId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1

)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for rows with identical start and end datetimes',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------
---- Test: Check for overlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
					,MeasureId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_PROPERTY_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate

)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for overlapping start-end periods',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

------------------------------------------------------------------------------------------------------
---- Test: Check for underlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*

			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramId
					,MeasureId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_PROPERTY_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	---- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate

)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for underlapping start-end periods',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

----------------------------------------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not start on 1900-01-01
---- Expected result: No rows returned

 WITH CTE_LATE_STARTS AS
(
	SELECT 
		PlanogramId
		,MeasureId

	FROM
		con_mon.VW_PLANOGRAM_PROPERTY_AM

	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramId
		,MeasureId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
		
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_PROP.*

FROM
	con_mon.VW_PLANOGRAM_PROPERTY_AM AS VW_PROP

	INNER JOIN CTE_LATE_STARTS
	ON VW_PROP.PlanogramId = CTE_LATE_STARTS.PlanogramId
	AND VW_PROP.MeasureId = CTE_LATE_STARTS.MeasureId

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not start on 1900-01-01',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-----------------------------------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not end on 9999-12-31
---- Expected result: No rows returned

WITH CTE_EARLY_ENDS AS
(
	SELECT 
		PlanogramId
		,MeasureId

	FROM
		con_mon.VW_PLANOGRAM_PROPERTY_AM

	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramId
		,MeasureId

	HAVING
		MAX(SCDEndDate) <> @V_END_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_PROP.*

FROM
	con_mon.VW_PLANOGRAM_PROPERTY_AM AS VW_PROP

	INNER JOIN CTE_EARLY_ENDS
	ON VW_PROP.PlanogramId = CTE_EARLY_ENDS.PlanogramId
	AND VW_PROP.MeasureId = CTE_EARLY_ENDS.MeasureId

)a


SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not end on 9999-12-31',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-------------------------------------------------------------------------------------------------------------

---- Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*

FROM
	con_mon.VW_PLANOGRAM_PROPERTY_AM

WHERE
	(SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
	OR
	(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y')

	AND RECORD_SOURCE_KEY = N'BTCBY'

)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

------------------------------------------------------------------------------------------------------------------------

---- Test: Check which distinct measures are showing in the data
---- Expected result: 43 rows returned showing the following values for MeasureName: 
----		Ad-Hoc avg adj EPOS Margin
----		Ad-Hoc avg adj EPOS Prof Prod
----		Ad-Hoc avg adj EPOS Profit
----		Ad-Hoc avg EPOS Gross Profit
----		Ad-Hoc avg EPOS Prof Marg Percentage
----		Ad-Hoc avg EPOS Prof Prod
----		Ad-Hoc avg Sales TESP
----		Ad-Hoc avg Sales TISP
----		Ad-Hoc avg TESP Productivity
----		Ad-Hoc avg TISP Productivity
----		Ad-Hoc avg Unit Productivity
----		Ad-Hoc avg units
----		Ad-Hoc Trend
----		Adj EPOS Margin
----		Adj EPOS Profit
----		Adj EPOS Profit Productivity
----		Ave 13wk Margin
----		Ave 13wk Profit
----		Build Size
----		EPOS margin
----		EPOS Profit
----		EPOS Profit Productivity
----		Furniture Depth
----		Furniture Height
----		Linear Space Used
----		No. of New Products
----		No. removed Products
----		numberOfProductsAllocated
----		numberOfSegments
----		numberOfStores
----		numberOfSubplanogramSpaces
----		Part module build size
----		percentage sold on promotion
----		planogram_depth
----		planogram_height
----		planogram_width
----		Sales TESP
----		Sales TISP
----		Sales Units
----		TESP Productivity
----		TISP Productivity
----		Unit Productivity
----		Wks pogHead Active


WITH CTE_MeasureName_ACTUALS AS
(
	SELECT DISTINCT MeasureName FROM con_mon.VW_PLANOGRAM_PROPERTY_AM WHERE RECORD_SOURCE_KEY = N'BTCBY'
)

,CTE_MeasureName_EXPECTED AS
(
	SELECT N'Ad-Hoc avg adj EPOS Margin' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg adj EPOS Prof Prod' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg adj EPOS Profit' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg EPOS Gross Profit' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg EPOS Prof Marg Percentage' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg EPOS Prof Prod' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg Sales TESP' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg Sales TISP' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg TESP Productivity' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg TISP Productivity' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg Unit Productivity' AS MeasureName
	UNION
	SELECT N'Ad-Hoc avg units' AS MeasureName
	UNION
	SELECT N'Ad-Hoc Trend' AS MeasureName
	UNION
	SELECT N'Adj EPOS Margin' AS MeasureName
	UNION
	SELECT N'Adj EPOS Profit' AS MeasureName
	UNION
	SELECT N'Adj EPOS Profit Productivity' AS MeasureName
	UNION
	SELECT N'Ave 13wk Margin' AS MeasureName
	UNION
	SELECT N'Ave 13wk Profit' AS MeasureName
	UNION
	SELECT N'Build Size' AS MeasureName
	UNION
	SELECT N'EPOS margin' AS MeasureName
	UNION
	SELECT N'EPOS Profit' AS MeasureName
	UNION
	SELECT N'EPOS Profit Productivity' AS MeasureName
	UNION
	SELECT N'Furniture Depth' AS MeasureName
	UNION
	SELECT N'Furniture Height' AS MeasureName
	UNION
	SELECT N'Linear Space Used' AS MeasureName
	UNION
	SELECT N'No. of New Products' AS MeasureName
	UNION
	SELECT N'No. removed Products' AS MeasureName
	UNION
	SELECT N'numberOfProductsAllocated' AS MeasureName
	UNION
	SELECT N'numberOfSegments' AS MeasureName
	UNION
	SELECT N'numberOfStores' AS MeasureName
	UNION
	SELECT N'numberOfSubplanogramSpaces' AS MeasureName
	UNION
	SELECT N'Part module build size' AS MeasureName
	UNION
	SELECT N'percentage sold on promotion' AS MeasureName
	UNION
	SELECT N'planogram_depth' AS MeasureName
	UNION
	SELECT N'planogram_height' AS MeasureName
	UNION
	SELECT N'planogram_width' AS MeasureName
	UNION
	SELECT N'Sales TESP' AS MeasureName
	UNION
	SELECT N'Sales TISP' AS MeasureName
	UNION
	SELECT N'Sales Units' AS MeasureName
	UNION
	SELECT N'TESP Productivity' AS MeasureName
	UNION
	SELECT N'TISP Productivity' AS MeasureName
	UNION
	SELECT N'Unit Productivity' AS MeasureName
	UNION
	SELECT N'Wks pogHead Active' AS MeasureName
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
(
SELECT * FROM CTE_MeasureName_EXPECTED
EXCEPT
SELECT * FROM CTE_MeasureName_ACTUALS
)
UNION
(
SELECT * FROM CTE_MeasureName_ACTUALS
EXCEPT
SELECT * FROM CTE_MeasureName_EXPECTED
)
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT = 0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check which distinct measures are showing in the data',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

------------------------------------------------------------------------------------------------------------

---- Test: Check which distinct measure types are showing in the data
---- Expected result: All rows returned should have a MEASURE_TYPE_KEY value of 'PLANOGRAM_DIM'

WITH CTE_MEASURE_TYPES_ACTUALS AS
(
	SELECT DISTINCT MEASURE_TYPE_KEY FROM con_mon.VW_PLANOGRAM_PROPERTY_AM WHERE RECORD_SOURCE_KEY = N'BTCBY'
)

,CTE_MEASURE_TYPES_EXPECTED AS
(
	SELECT N'PLANOGRAM_DIM' AS MEASURE_TYPE_KEY
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
(
SELECT * FROM CTE_MEASURE_TYPES_EXPECTED
EXCEPT
SELECT * FROM CTE_MEASURE_TYPES_ACTUALS
)
UNION
(
SELECT * FROM CTE_MEASURE_TYPES_ACTUALS
EXCEPT
SELECT * FROM CTE_MEASURE_TYPES_EXPECTED
)
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT = 0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check which distinct measure types are showing in the data',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);

-------------------------------------------------------------------------------------------------------------------------

END
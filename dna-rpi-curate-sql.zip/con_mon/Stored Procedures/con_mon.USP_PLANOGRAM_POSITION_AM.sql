﻿/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_POSITION_AM]    Script Date: 5/25/2023 10:03:20 AM ******/

CREATE PROC [con_mon].[USP_PLANOGRAM_POSITION_AM] @P_RUN_DATE [DATETIME] AS

/*************************************************************************************************************************
Procedure Name					: USP_PLANOGRAM_POSITION_AM
Purpose							: UAT Automation Testing for ser.PlanogramPosition table		

**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		      : Description
==========================================================================================================================

24-05-2023   :  Mayank Bhardwaj		  : Initial Version
**************************************************************************************************************************/

BEGIN

DECLARE @V_START_OF_TIME DATETIME = '1900-01-01';
DECLARE @V_END_OF_TIME DATETIME = '9999-12-31';
DECLARE @V_TABLE_NAME VARCHAR(100) = 'ser.PlanogramPosition';
DECLARE @V_ROW_COUNT BIGINT;
DECLARE @V_ALERT_FLAG BIGINT;
DECLARE @V_DELTA_COUNT_1 BIGINT;
DECLARE @V_DELTA_COUNT_2 BIGINT;
DECLARE @V_SP_NAME VARCHAR(200) = 'con_mon.USP_PLANOGRAM_POSITION_AM';
----------------------------------------------------------------------------------------------------------

---- Create and populate con_mon.TMP_USP_PLANOGRAM_POSITION_AM_DATE_RANGE temp table
---- Create this as a replicated clustered row indexed table to optimise subsequent use of the table

IF OBJECT_ID (N'con_mon.TMP_USP_PLANOGRAM_POSITION_AM_DATE_RANGE', N'U') IS NOT NULL
	DROP TABLE con_mon.TMP_USP_PLANOGRAM_POSITION_AM_DATE_RANGE
;

CREATE TABLE con_mon.TMP_USP_PLANOGRAM_POSITION_AM_DATE_RANGE
WITH
(
	CLUSTERED INDEX (SCD_START_UBOUND ASC, SCD_END_LBOUND ASC)
	,DISTRIBUTION = REPLICATE
)
AS

-----------------------------------------------------------------------------------------------------------

---- Insert into the con_mon.TMP_USP_PLANOGRAM_POSITION_AM_DATE_RANGE temp table the distinct SCDStartDate values from the table being
---- tested, which should therefore be the full list of datetimes that need to be tested to get full coverage of all the data
---- in that table. 

SELECT DISTINCT
	VW_POS.SCDStartDate AS SCD_START_UBOUND
	,DATEADD(SECOND, -1, VW_POS.SCDStartDate) AS SCD_END_LBOUND
FROM
	con_mon.VW_PLANOGRAM_POSITION_AM AS VW_POS
WHERE
	VW_POS.RECORD_SOURCE_KEY = N'BTCBY'
;

----------------------------------------------------------------------------------------------------------\

---- Test: Check for duplicate record sources per surrogate business ID
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	PlanogramPositionId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_POSITION_AM
GROUP BY
	PlanogramPositionId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for duplicate record sources per surrogate business ID',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-------------------------------------------------------------------------------------------------------

---- Test: Check for duplicate record sources per composite business key
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	PlanogramId
	,PlanogramFixtureId
	,ProductId
	,COUNT(DISTINCT LOVRecordSourceId) AS DISTINCTS
FROM
	con_mon.VW_PLANOGRAM_POSITION_AM
GROUP BY
	PlanogramId
	,PlanogramFixtureId
	,ProductId
HAVING
	COUNT(DISTINCT LOVRecordSourceId) <> 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for duplicate record sources per composite business key',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------------

---- Check for how many delta changes have taken place in the table

SET @V_DELTA_COUNT_1 =
(
SELECT
	COUNT(*) AS THE_ROWS
FROM
	con_mon.VW_PLANOGRAM_POSITION_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
)

SET @V_DELTA_COUNT_2 =
(
SELECT
	COUNT(*) AS DISTINCT_P_POSITIONS
FROM
	(
		SELECT DISTINCT
			PlanogramPositionId
		FROM
			con_mon.VW_PLANOGRAM_POSITION_AM
		WHERE
			RECORD_SOURCE_KEY = N'BTCBY'
	) AS QRY_DISTINCTS
)

SET @V_ROW_COUNT = @V_DELTA_COUNT_1 - @V_DELTA_COUNT_2

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 0 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for how many delta changes have taken place in the table',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------------

---- Test: Check for NULL start or end datetimes or active flags
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_POSITION_AM
WHERE
	(SCDStartDate IS NULL OR SCDEndDate IS NULL OR SCDActiveFlag IS NULL)
	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for NULL start or end datetimes or active flags',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------------

---- Test: Check for back-to-front start and end datetimes
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_POSITION_AM
WHERE
	-- In Curate each record is active from and including SCDStartDate up to but not including SCDEndDate + 1 second
	DATEADD(ss, 1, SCDEndDate) <= SCDStartDate
	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for back-to-front start and end datetimes',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-------------------------------------------------------------------------------------------------------

---- Test: Check for multiple surrogate business IDs per composite business key
---- Expected result: No rows returned

WITH CTE_DISTINCT_SURROGATES AS
(
	SELECT
		PlanogramId
		,PlanogramFixtureId
		,ProductId
		,SourceKey
		,COUNT(*) AS DISTINCT_SURROGATE_IDS
	FROM
		con_mon.VW_PLANOGRAM_POSITION_DISTINCT_AM
	GROUP BY
		PlanogramId
		,PlanogramFixtureId
		,ProductId
		,SourceKey
	HAVING
		COUNT(*) > 1
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT
	CTE_DISTINCT_SURROGATES.DISTINCT_SURROGATE_IDS
	,VW_POS.*

FROM
	con_mon.VW_PLANOGRAM_POSITION_AM AS VW_POS

	INNER JOIN CTE_DISTINCT_SURROGATES
	ON VW_POS.PlanogramId = CTE_DISTINCT_SURROGATES.PlanogramId
	AND VW_POS.PlanogramFixtureId = CTE_DISTINCT_SURROGATES.PlanogramFixtureId
	AND VW_POS.ProductId = CTE_DISTINCT_SURROGATES.ProductId
	AND VW_POS.SourceKey = CTE_DISTINCT_SURROGATES.SourceKey

WHERE
	VW_POS.RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for multiple surrogate business IDs per composite business key',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-----------------------------------------------------------------------------------------------------

---- Test: Check for multiple composite business keys per surrogate business ID
---- Expected result: No rows returned

WITH CTE_DISTINCT_COMPOSITES AS
(
	SELECT
		PlanogramPositionId
		,COUNT(*) AS DISTINCT_COMPOSITE_KEYS
	FROM
		con_mon.VW_PLANOGRAM_POSITION_DISTINCT_AM
	GROUP BY
		PlanogramPositionId
	HAVING
		COUNT(*) > 1
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT
	CTE_DISTINCT_COMPOSITES.DISTINCT_COMPOSITE_KEYS
	,VW_POS.*

FROM
	con_mon.VW_PLANOGRAM_POSITION_AM AS VW_POS

	INNER JOIN CTE_DISTINCT_COMPOSITES
	ON VW_POS.PlanogramPositionId = CTE_DISTINCT_COMPOSITES.PlanogramPositionId

WHERE
	VW_POS.RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for multiple composite business keys per surrogate business ID',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-----------------------------------------------------------------------------------------------------

---- Test: Check for rows with identical start and end datetimes
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT
	COUNT(*) AS DUPLICATES
	,PlanogramPositionId
	,SCDStartDate
	,SCDEndDate
FROM
	con_mon.VW_PLANOGRAM_POSITION_AM
WHERE
	RECORD_SOURCE_KEY = N'BTCBY'
GROUP BY
	PlanogramPositionId
	,SCDStartDate
	,SCDEndDate
HAVING
	COUNT(*) > 1
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for rows with identical start and end datetimes',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------------------------

---- Test: Check for overlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*
			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramPositionId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_POSITION_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	-- Check for SCD overlaps
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) > QRY_NEXT_START.NextSCDStartDate
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for overlapping start-end periods',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
------------------------------------------------------------------------------------------------

---- Test: Check for underlapping start-end periods
---- Prerequisites: Above tests must have passed
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT
	QRY_NEXT_START.*

FROM
	(
		SELECT
			*
			,LEAD(SCDStartDate)
			OVER
			(
				PARTITION BY
					PlanogramPositionId
				ORDER BY
					SCDStartDate
					,SCDEndDate
			) AS NextSCDStartDate

		FROM
			con_mon.VW_PLANOGRAM_POSITION_AM

	) AS QRY_NEXT_START

WHERE
	QRY_NEXT_START.NextSCDStartDate IS NOT NULL

	AND QRY_NEXT_START.RECORD_SOURCE_KEY = N'BTCBY'

	---- Check for SCD underlaps (i.e. gaps)
	AND DATEADD(ss, 1, QRY_NEXT_START.SCDEndDate) < QRY_NEXT_START.NextSCDStartDate
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for underlapping start-end periods',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------

---- Test: Check for entities whose lives do not start on 1900-01-01
---- Expected result: No rows returned

WITH CTE_LATE_STARTS AS
(
	SELECT
		PlanogramPositionId

	FROM
		con_mon.VW_PLANOGRAM_POSITION_AM

	WHERE
		RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		PlanogramPositionId

	HAVING
		MIN(SCDStartDate) <> @V_START_OF_TIME
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT
	VW_POS.*

FROM
	con_mon.VW_PLANOGRAM_POSITION_AM AS VW_POS

	INNER JOIN CTE_LATE_STARTS
	ON VW_POS.PlanogramPositionId = CTE_LATE_STARTS.PlanogramPositionId
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities whose lives do not start on 1900-01-01',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
--------------------------------------------------------------------------------------------------------------

---- Test: Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
( 
SELECT
	*
FROM
	con_mon.VW_PLANOGRAM_POSITION_AM

WHERE
	(
		(SCDEndDate >= @V_END_OF_TIME AND SCDActiveFlag = N'N')
		OR
		(SCDEndDate < @V_END_OF_TIME AND SCDActiveFlag = N'Y')
	)

	AND RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check for entities with inconsistent SCDEndDate and SCDActiveFlag fields',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
-----------------------------------------------------------------------------------------------------------------

---- Test: Check that Blue Yonder Planogram positions all and only link to child Blue Yonder planograms
---- Expected result: Exactly one row returned with POG_RECORD_SOURCE_KEY = 'BTCBY' and POG_SK_TYPE_KEY
---- = 'BY Planogram Key'

WITH CTE_POG_KEYS AS
(
	SELECT
		POG.PlanogramId
		,CASE WHEN MAX(CASE WHEN POG.SourceKey IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT POG.SourceKey) > 1 THEN N'Dupe' ELSE MAX(POG.SourceKey) END AS SourceKey
		,CASE WHEN MAX(CASE WHEN LOV_RS.LOVKey IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOV_RS.LOVKey) > 1 THEN N'Dupe' ELSE MAX(LOV_RS.LOVKey) END AS RECORD_SOURCE_KEY
		,CASE WHEN MAX(CASE WHEN LOV_RS.LOVName IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOV_RS.LOVName) > 1 THEN N'Dupe' ELSE MAX(LOV_RS.LOVName) END AS RECORD_SOURCE_NAME
		,CASE WHEN MAX(CASE WHEN LOV_SK_TYPE.LOVKey IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOV_SK_TYPE.LOVKey) > 1 THEN N'Dupe' ELSE MAX(LOV_SK_TYPE.LOVKey) END AS SK_TYPE_KEY
		,CASE WHEN MAX(CASE WHEN LOV_SK_TYPE.LOVName IS NULL THEN 1 ELSE 0 END) + COUNT(DISTINCT LOV_SK_TYPE.LOVName) > 1 THEN N'Dupe' ELSE MAX(LOV_SK_TYPE.LOVName) END AS SK_TYPE_NAME

	FROM
		ser.Planogram AS POG

		LEFT JOIN ser.RefLOV AS LOV_RS
		ON POG.LOVRecordSourceId = LOV_RS.LOVId
		AND LOV_RS.ActiveFlag = 1

		LEFT JOIN ser.RefLOV AS LOV_SK_TYPE
		ON POG.LOVSourceKeyTypeId = LOV_SK_TYPE.LOVId
		AND LOV_SK_TYPE.ActiveFlag = 1

	GROUP BY
		POG.PlanogramId
)

,CTE_RS_SK_COMBOS_ACTUALS AS
(
	SELECT
		CTE_POG_KEYS.RECORD_SOURCE_KEY AS POG_RECORD_SOURCE_KEY
		,CTE_POG_KEYS.SK_TYPE_KEY AS POG_SK_TYPE_KEY

	FROM
		con_mon.VW_PLANOGRAM_POSITION_AM AS VW_POS

		LEFT JOIN CTE_POG_KEYS
		ON VW_POS.PlanogramId = CTE_POG_KEYS.PlanogramId

	WHERE
		VW_POS.RECORD_SOURCE_KEY = N'BTCBY'

	GROUP BY
		VW_POS.RECORD_SOURCE_KEY
		,CTE_POG_KEYS.RECORD_SOURCE_KEY
		,CTE_POG_KEYS.SK_TYPE_KEY
)

, CTE_RS_SK_COMBOS_EXPECTED AS
(
SELECT N'BTCBY' AS POG_RECORD_SOURCE_KEY, N'BY Planogram Key' AS POG_SK_TYPE_KEY
)

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
(
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
)
UNION
(
SELECT * FROM CTE_RS_SK_COMBOS_ACTUALS
EXCEPT
SELECT * FROM CTE_RS_SK_COMBOS_EXPECTED
)
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT = 0 THEN 0 ELSE 1 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check that Blue Yonder Planogram positions all and only link to child Blue Yonder planograms',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------------------------------------

---- Test: Check that all Blue Yonder planogram position rows are covered by at least one of the test dates
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	DATES.*
	,VW_POS.*

FROM
	con_mon.VW_PLANOGRAM_POSITION_AM AS VW_POS

	LEFT JOIN con_mon.TMP_USP_PLANOGRAM_POSITION_AM_DATE_RANGE AS DATES
	ON VW_POS.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < VW_POS.SCDEndDate

WHERE
	-- Failed left join
	DATES.SCD_START_UBOUND IS NULL

	AND VW_POS.RECORD_SOURCE_KEY = N'BTCBY'
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check that all Blue Yonder planogram position rows are covered by at least one of the test dates',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
---------------------------------------------------------------------------------------------------------

---- Test: Check that all Blue Yonder Planogram positions successfully link to ser.Product
---- Expected result: No rows returned

SELECT @V_ROW_COUNT = COUNT(*) FROM
(
SELECT
	VW_POS.*
	,PROD.ProductId AS PROD_ProductId

FROM
	con_mon.VW_PLANOGRAM_POSITION_AM AS VW_POS

	LEFT JOIN con_mon.TMP_USP_PLANOGRAM_POSITION_AM_DATE_RANGE AS DATES
	ON VW_POS.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < VW_POS.SCDEndDate

	LEFT JOIN ser.Product AS PROD
	ON VW_POS.ProductId = PROD.ProductId
	AND PROD.SCDStartDate <= DATES.SCD_START_UBOUND
	AND DATES.SCD_END_LBOUND < PROD.SCDEndDate

WHERE
	VW_POS.RECORD_SOURCE_KEY = N'BTCBY'

	AND PROD.ProductId IS NULL
)a

SET @V_ALERT_FLAG = (CASE WHEN @V_ROW_COUNT>0 THEN 1 ELSE 0 END)

INSERT INTO [con_mon].[RPT_ALERTING_MONITORING]
VALUES (@V_TABLE_NAME,@V_SP_NAME,'Check that all Blue Yonder Planogram positions successfully link to ser.Product',@P_RUN_DATE,@V_ROW_COUNT,'N',@V_ALERT_FLAG);
------------------------------------------------------------------------------------------------------------

---- Drop temp tables

IF OBJECT_ID (N'con_mon.TMP_USP_PLANOGRAM_POSITION_AM_DATE_RANGE', N'U') IS NOT NULL
	DROP TABLE con_mon.TMP_USP_PLANOGRAM_POSITION_AM_DATE_RANGE
;
-----------------------------------------------------------------------------------------------

END
﻿
/****** Object:  StoredProcedure [psa].[sp_IncrementalDeletion_Martech]    Script Date: 9/9/2021 9:19:54 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_Incremental_Anonymisation_CRM_Cust]    Script Date: 9/9/2021 9:20:46 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Advantage_Card_customer_child]    Script Date: 9/8/2021 8:11:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Advantage_Card_customer_clubs]    Script Date: 9/8/2021 8:12:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Advantage_Card_customers]    Script Date: 9/8/2021 8:13:25 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Advantage_Card_membership_activity]    Script Date: 9/8/2021 8:14:48 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Advantage_Card_membership_card]    Script Date: 9/8/2021 8:15:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Advantage_Card_membership_points]    Script Date: 9/8/2021 8:16:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Advantage_Card_transactions]    Script Date: 9/8/2021 8:16:41 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Customer_Status_Change]    Script Date: 9/8/2021 8:17:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SVOC_Customer_address]    Script Date: 9/8/2021 8:18:06 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SVOC_Customer_consent]    Script Date: 9/8/2021 8:19:11 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SVOC_Customer_consent_entity_link]    Script Date: 9/8/2021 8:19:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SVOC_Customer_data]    Script Date: 9/8/2021 8:20:17 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SVOC_Customer_email]    Script Date: 9/8/2021 8:20:46 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SVOC_Customer_entity_link]    Script Date: 9/8/2021 8:21:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SVOC_Customer_identifier]    Script Date: 9/8/2021 8:21:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SVOC_Customer_phone]    Script Date: 9/8/2021 8:22:11 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SVOC_Customer_social_media]    Script Date: 9/8/2021 8:22:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Advantage_Card_customers]    Script Date: 9/16/2021 6:14:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_pz].[sp_dm_SAPCRM_Advantage_Card_customers]    Script Date: 9/16/2021 6:14:51 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_aw_membership_card]    Script Date: 8/26/2021 3:16:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_base_plan_product]    Script Date: 04/09/2020 10:59:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*************************************************************************************************************************************************************************
Procedure Name                      : sp_inc_uk_base_plan_product
Purpose                             : Load Incremental daily data From Base Plan Product table in psa layer(SAP BW) into Serve Layer Table
Domain                              : Merchandise
ServeLayer Target Tables            : Total 5 tables involved
                                      Through SP           -> FactInstance,FactDimensionInstance
                                      DML One Off Insert   -> Fact,Dimension,FactDimension
RecordSourceID for base_plan_product  : 12006
*************************************************************************************************************************************************************************
Modification History
*************************************************************************************************************************************************************************
04-Aug-20  : Incorporated BUK_ROI_Merchandise_Incremental_v1.3 mapping changes
*************************************************************************************************************************************************************************/

IF OBJECT_ID('[psa].[sp_inc_uk_base_plan_product]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_uk_base_plan_product] 
END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_base_store_plan]    Script Date: 04/09/2020 12:36:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*************************************************************************************************************************************************************************
Procedure Name                      : sp_inc_uk_base_store_plan
Purpose                             : Load Incremental daily data From Base Store Plan table in psa layer(SAP BW) into Serve Layer Table
Domain                              : Merchandise
ServeLayer Target Tables            : Total 8 tables involved
                                      Through SP           -> FactInstance,FactDimensionInstance,FactMeasurenInstance
                                      DML One Off Insert   -> Fact,Dimension,Measure,FactDimension,FactMeasure
RecordSourceID for base_store_plan  : 12006
*************************************************************************************************************************************************************************/

IF OBJECT_ID('[psa].[sp_inc_uk_base_store_plan]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_uk_base_store_plan] 
END
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_uk_mf_dwtoffer') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_uk_mf_dwtoffer 
    
END
GO

IF OBJECT_ID('psa.sp_uk_abacus_header') IS NOT NULL
BEGIN
    DROP PROC psa.sp_uk_abacus_header
END;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_uk_abacus_item') IS NOT NULL
BEGIN
    DROP PROC psa.sp_uk_abacus_item
END;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_aw_membership_card]    Script Date: 8/26/2021 3:16:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_base_plan_product]    Script Date: 04/09/2020 10:59:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*************************************************************************************************************************************************************************
Procedure Name                      : sp_inc_uk_base_plan_product
Purpose                             : Load Incremental daily data From Base Plan Product table in psa layer(SAP BW) into Serve Layer Table
Domain                              : Merchandise
ServeLayer Target Tables            : Total 5 tables involved
                                      Through SP           -> FactInstance,FactDimensionInstance
                                      DML One Off Insert   -> Fact,Dimension,FactDimension
RecordSourceID for base_plan_product  : 12006
*************************************************************************************************************************************************************************
Modification History
*************************************************************************************************************************************************************************
04-Aug-20  : Incorporated BUK_ROI_Merchandise_Incremental_v1.3 mapping changes
*************************************************************************************************************************************************************************/

IF OBJECT_ID('[psa].[sp_inc_uk_base_plan_product]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_uk_base_plan_product] 
END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_base_store_plan]    Script Date: 04/09/2020 12:36:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*************************************************************************************************************************************************************************
Procedure Name                      : sp_inc_uk_base_store_plan
Purpose                             : Load Incremental daily data From Base Store Plan table in psa layer(SAP BW) into Serve Layer Table
Domain                              : Merchandise
ServeLayer Target Tables            : Total 8 tables involved
                                      Through SP           -> FactInstance,FactDimensionInstance,FactMeasurenInstance
                                      DML One Off Insert   -> Fact,Dimension,Measure,FactDimension,FactMeasure
RecordSourceID for base_store_plan  : 12006
*************************************************************************************************************************************************************************/

IF OBJECT_ID('[psa].[sp_inc_uk_base_store_plan]') IS NOT NULL
BEGIN
    DROP PROC [psa].[sp_inc_uk_base_store_plan] 
END
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_uk_mf_dwtoffer') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_uk_mf_dwtoffer 
    
END
GO

IF OBJECT_ID('psa.sp_uk_abacus_header') IS NOT NULL
BEGIN
    DROP PROC psa.sp_uk_abacus_header
END;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_uk_abacus_item') IS NOT NULL
BEGIN
    DROP PROC psa.sp_uk_abacus_item
END;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_btc_mdm_store]    Script Date: 11/20/2020 10:09:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_btc_mdm_store') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_btc_mdm_store
   
END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_mdm_article]    Script Date: 11/20/2020 9:29:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_uk_btc_mdm_article') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_uk_btc_mdm_article 
    
END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_btc_mdm_store]    Script Date: 11/20/2020 10:09:38 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_btc_mdm_store') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_btc_mdm_store
   
END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_mdm_article]    Script Date: 11/20/2020 9:29:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID('psa.sp_inc_uk_btc_mdm_article') IS NOT NULL
BEGIN
    DROP PROC psa.sp_inc_uk_btc_mdm_article 
    
END
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_customer_hierarchy_egress]    Script Date: 6/9/2022 5:08:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_customer_member_egress]    Script Date: 6/13/2022 10:30:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_DERMStoreRetailer]    Script Date: 6/9/2022 4:46:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Kohls_Retailer]    Script Date: 6/9/2022 4:44:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Shoppers_Drug_Mart_Retailer]    Script Date: 6/9/2022 4:42:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Singer_Group_Retailer]    Script Date: 6/9/2022 4:40:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Skin_Store_Retailer]    Script Date: 6/9/2022 4:35:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Target]    Script Date: 6/9/2022 4:55:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_UltaRetailer]    Script Date: 6/9/2022 4:53:58 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Walgreens_Retailer]    Script Date: 6/9/2022 4:48:54 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_walmart]    Script Date: 6/9/2022 4:50:40 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[Sp_dm_actual_si]    Script Date: 6/9/2022 4:59:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_party_role_relationship]    Script Date: 6/16/2022 6:02:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [lod].[RPIDNA_GBSAP_SAP_MBEW]    Script Date: 6/16/2022 6:27:54 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [psa].[RPIDNA_GBSAP_SAP_MBEW]    Script Date: 6/16/2022 6:25:14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_product_hierarchy_egress]    Script Date: 6/22/2022 11:17:13 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_product_member_egress]    Script Date: 6/9/2022 5:06:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_Product_Master]    Script Date: 6/22/2022 11:21:35 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_standard_cost_egress]    Script Date: 6/22/2022 7:33:14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_Coggs]    Script Date: 6/23/2022 5:46:33 AM ******/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_cogs_ProductandStore]    Script Date: 6/23/2022 5:49:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[ProductSiteRoleRelationship]    Script Date: 5/12/2022 8:20:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_actual_si_so_egress]    Script Date: 6/29/2022 7:40:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[Sp_dm_actual_si]    Script Date: 6/29/2022 7:48:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_product_hierarchy_egress]    Script Date: 7/4/2022 1:38:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_standard_cost_egress]    Script Date: 6/22/2022 7:33:14 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_actual_si_so_egress]    Script Date: 6/29/2022 7:40:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[Sp_dm_actual_si]    Script Date: 7/4/2022 9:53:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_DERMStoreRetailer]    Script Date: 7/6/2022 6:00:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Kohls_Retailer]    Script Date: 7/4/2022 5:24:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Shoppers_Drug_Mart_Retailer]    Script Date: 7/4/2022 9:21:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Singer_Group_Retailer]    Script Date: 7/4/2022 5:26:33 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Skin_Store_Retailer]    Script Date: 7/4/2022 11:12:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_UltaRetailer]    Script Date: 7/4/2022 8:28:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Walgreens_Retailer]    Script Date: 7/4/2022 6:23:16 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Wrapper]    Script Date: 7/5/2022 10:02:24 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_payments_egress]    Script Date: 7/1/2022 12:07:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_product_hierarchy_egress]    Script Date: 7/12/2022 2:23:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_product_member_egress]    Script Date: 7/12/2022 2:13:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [lod].[RPIDNA_GBSAP_SAP_BKPF]    Script Date: 4/22/2022 6:10:28 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [lod].[RPIDNA_GBSAP_SAP_BSEG]    Script Date: 4/22/2022 6:29:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [psa].[RPIDNA_GBSAP_SAP_BKPF]    Script Date: 4/22/2022 6:11:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [psa].[RPIDNA_GBSAP_SAP_BSEG]    Script Date: 4/22/2022 6:29:39 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[DocumentCharacteristic]    Script Date: 6/15/2022 12:35:40 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[DocumentLineCharacteristic]    Script Date: 6/15/2022 12:36:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_ALSHAYA_Retailer]    Script Date: 7/19/2022 5:44:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_CHILE_Retailer]    Script Date: 7/19/2022 5:45:37 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_MECCA_Retailer]    Script Date: 7/19/2022 5:50:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_MEXICO_Retailer]    Script Date: 7/19/2022 5:51:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[Sp_dm_actual_si]    Script Date: 8/4/2022 9:56:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Baozun_Retailer]    Script Date: 8/8/2022 5:59:13 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Hjartat_Retailer]    Script Date: 8/8/2022 6:00:15 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_THAILAND_Retailer]    Script Date: 8/8/2022 5:56:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Wrapper]    Script Date: 8/8/2022 6:06:25 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_BUK_Retailer]    Script Date: 7/19/2022 5:51:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_cogs_ProductandStore]    Script Date: 8/16/2022 10:03:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_product_hierarchy_egress]    Script Date: 9/19/2022 9:42:29 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_product_member_egress]    Script Date: 9/19/2022 9:28:05 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [lod].[SAPCOE_SAPBW_BootsUK_Loss_SAP_STOCK_ZPA_SAPBW_Incr]    Script Date: 12/15/2022 11:15:06 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [psa].[SAPCOE_SAPBW_BootsUK_Loss_SAP_STOCK_ZPA_SAPBW_Incr]    Script Date: 12/15/2022 4:59:46 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[ProductLossMeasure]    Script Date: 12/15/2022 5:23:39 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[ProductLoss]    Script Date: 12/15/2022 5:23:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_loss]    Script Date: 1/6/2023 11:14:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_no_crp_item_transaction]  ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
************************************************************************************************************
Procedure Name							: sp_no_crp_item_transaction
Purpose									: Load Incremental data from norway transaction source table(rawno.crp_item_transaction) into Serve Layer Table
Domain									: Transaction
ServeLayer Target Tables	 			: Till(onetime insert done), SiteRole(onetimeinsert done),paryrolesiterolerelationship(onetimeinsert done), Product, Transaction, TransactionLineItem, TransactionLineItemMeasure, 
										  
RecordSourceID  for norway Transaction	: 12005

**************************************************************************************************************
Default values
************************************************************************************************************
				SCDEndDate for higest version   :  '9999-12-31' 
				SCDLOVRecordSourceId			:  12005 
				ETLRunLogId						:  @serveETLRunLogID passed as argument

*************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		                     : Description
==========================================================================================================================

11-nov-2022  :  Pranathi Reddy Mendu 				  pervious the data was coming in transaction level but now the data 
                                                      is coming as product level so modified according to it

**************************************************************************************************************************/


IF OBJECT_ID('psa.sp_no_crp_item_transaction') IS NOT NULL
BEGIN
	DROP PROC psa.sp_no_crp_item_transaction
END
GO

CREATE TABLE [psa].[WBAHK_FactMIDATA_GSOOPEN_HKSQLDB](
[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[DATEKEY] [varchar](8) NULL,
	[OWNER] [nvarchar](255) NOT NULL,
	[BIZ_CODE] [nvarchar](200) NULL,
	[BUSINESS] [nvarchar](255) NULL,
	[DEPARTMENT] [nvarchar](600) NULL,
	[SUBDEPARTMENT] [nvarchar](255) NULL,
	[DEPARTMENT_FY16] [nvarchar](255) NULL,
	[SUBDEPARTMENT_FY16] [nvarchar](255) NULL,
	[WBATIER1CODE] [nvarchar](255) NULL,
	[WBATIER2CODE] [nvarchar](255) NULL,
	[WBA_CATEGORYTIER1] [nvarchar](255) NULL,
	[WBA_CATEGORYTIER2] [nvarchar](255) NULL,
	[PRODUCTGROUP] [nvarchar](255) NULL,
	[BRAND] [nvarchar](255) NULL,
	[BRAND_NAME] [nvarchar](255) NULL,
	[BRAND_TYPECODE] [nvarchar](255) NULL,
	[BRAND_TYPENAME] [nvarchar](255) NULL,
	[SEASON] [nvarchar](255) NULL,
	[PO_ORDERTYPE] [nvarchar](255) NULL,
	[IS_CMI] [nvarchar](255) NULL,
	[CUSTOMERCOMPANY] [nvarchar](255) NULL,
	[SUPPLIER] [nvarchar](255) NULL,
	[SUPPLIERNAME] [nvarchar](255) NULL,
	[PO_STATUS] [nvarchar](255) NULL,
	[CUSTOMERONO] [nvarchar](255) NOT NULL,
	[QUOTENO] [nvarchar](255) NULL,
	[PROJECT] [nvarchar](255) NULL,
	[RANGE] [nvarchar](255) NULL,
	[OFFERNO] [nvarchar](255) NULL,
	[SAP_PONO] [nvarchar](255) NULL,
	[WBA_PONO] [nvarchar](255) NULL,
	[PROFORMAPONO] [nvarchar](255) NOT NULL,
	[PO_LINENO] [nvarchar](500) NOT NULL,
	[ITEMCODE] [nvarchar](255) NOT NULL,
	[DESCRIPTION] [nvarchar](255) NULL,
	[QTYPEROUTER] [nvarchar](500) NULL,
	[QTYPERINNER] [nvarchar](500) NULL,
	[ORIGINALCUR] [nvarchar](255) NULL,
	[UNITPRICE] [nvarchar](500) NULL,
	[PO_QTY] [nvarchar](500) NULL,
	[POQTYAMT_OC] [nvarchar](500) NULL,
	[ACTUALSHIPPEDQTY] [nvarchar](384) NULL,
	[SAQTY] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
	[EXRATE] [nvarchar](384) NULL,
	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_GBP] [nvarchar](500) NULL,
	[COUNTRYOFORIGIN] [nvarchar](255) NULL,
	[PORTOFLADING] [nvarchar](255) NULL,
	[PORTOFLADING_NAME] [nvarchar](255) NULL,
	[PORT_LEADTIME] [nvarchar](384) NULL,
	[PORT_COUNTRY] [nvarchar](255) NULL,
	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
	[LTPO_ETDREDUCED] [nvarchar](500)) NULL,
	[MODEOFTRANSPORT] [nvarchar](18) NULL,
	[LOADINGMODE] [nvarchar](35) NULL,
	[SHIPPINGTERMS] [nvarchar](6) NULL,
	[SHIPPINGCOMPANY] [nvarchar](17) NULL,
	[DELIVERWAREHOUSE] [nvarchar](17) NULL,
	[IMPORTCOUNTRY] [nvarchar](3) NULL,
	[PO_DATE] [nvarchar](55) NULL,
	[PO_RELEASEDATE] [nvarchar](55) NULL,
	[POVSRELDATE] [nvarchar](500) NULL,
	[CUSTREQ_SIW] [nvarchar](55) NULL,
	[OLSD] [nvarchar](55) NULL,
	[CURRENT_ESD] [nvarchar](55) NULL,
	[CLSD] [nvarchar](55) NULL,
	[CSIW] [nvarchar](55) NULL,
	[OSIW] [nvarchar](55) NULL,
	[ACRD] [nvarchar](55) NULL,
	[AETD] [nvarchar](55) NULL,
	[CLSD_OLSD] [nvarchar](55) NULL,
	[ACRDVSCLSD] [nvarchar](500) NULL,
	[AETDVSCLSD] [nvarchar](500) NULL,
	[AETDVSOLSD] [nvarchar](500) NULL,
	[PO_CLSD] [nvarchar](500) NULL,
	[PO_AETD] [nvarchar](500) NULL,
	[PO_ACRD] [nvarchar](500) NULL,
	[POREL_CLSD] [nvarchar](500) NULL,
	[POREL_AETD] [nvarchar](500) NULL,
	[POREL_ACRD] [nvarchar](500) NULL,
	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
	[CLSDVSOLSD] [nvarchar](500) NULL,
	[SHIPWINDOWRESULT] [nvarchar](4) NULL,
	[SHIPWINDOWRESULT_FY16] [nvarchar](4) NULL,
	[DELAYCODE] [nvarchar](35) NULL,
	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
	[BQORDERLTPORTCODE] [nvarchar](384) NULL,
	[LTDIFF] [nvarchar](500) NULL,
	[PODATERESULT] [nvarchar](55) NULL,
	[TEAM_CODE] [nvarchar](35) NULL,
	[TEAM_SUBCODE] [nvarchar](2) NULL,
	[TEAM_CODE_FY16] [nvarchar](200) NULL,
	[TEAM_SUBCODE_FY16] [nvarchar](2) NULL,
	[XREF] [nvarchar](35) NULL,
	[BUSINESSUNIT] [nvarchar](35) NULL,
	[BUFILTER] [nvarchar](5) NULL,
	[BUFILTER_TSS] [nvarchar](12) NULL,
	[SARELEASEDATE] [nvarchar](55) NULL,
	[SANO] [nvarchar](35) NULL,
	[FACTORY] [nvarchar](17) NULL,
	[CONFIRMEDDATE] [nvarchar](55) NULL,
	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
	[BCMK_REFNO] [nvarchar](35) NULL,
	[SHIPMENT PHASE] [nvarchar](500) NULL,
	[OFFERSTATUS] [nvarchar](35) NULL,
	[PRICEDEVIATION] [nvarchar](500) NULL,
	[SETRELATIONSHIP] [nvarchar](35) NULL,
	[LINENO] [nvarchar](35) NULL,
	[SEASONYEAR] [nvarchar](500) NULL,
	[COMMENTS] [nvarchar](250) NULL,
	[LASTMODIFIEDDT] [nvarchar](55) NULL,
	[LASTMODIFIEDBY] [nvarchar](18) NULL,
	[ISSARELEASED] [nvarchar](35) NULL,
	[PARTYNAME] [nvarchar](80) NULL,
	[POSERIES] [nvarchar](6) NULL,
	[LENGTH] [nvarchar](384) NULL,
	[WIDTH] [nvarchar](384) NULL,
	[HEIGHT] [nvarchar](384) NULL,
	[TTL_KGS] [nvarchar](384) NULL,
	[TTL_CBM] [nvarchar](384) NULL,
	[SUPPLIERRESULT] [nvarchar](4) NULL,
	[OVERALLRESULT] [nvarchar](4) NULL,
	[ASMRESULT] [nvarchar](4) NULL,
	[CHECK1] [nvarchar](5) NULL,
	[CHECK2] [nvarchar](5) NULL,
	[CHECK3] [nvarchar](5) NULL,
	[CHECK4] [nvarchar](5) NULL,
	[CHECK5] [nvarchar](5) NULL,
	[CHECK6] [nvarchar](5) NULL,
	[PENALTYSEC] [nvarchar](200) NULL,
	[PENALTY_RATE] [nvarchar](384) NULL,
	[POQTYAMT_OC_PENALTY] [nvarchar](384) NULL,
	[POQTYAMT_USD_PENALTY] [nvarchar](384) NULL,
	[DATASOURCE] [varchar](3) NOT NULL,
	[DATASOURCE_IDX] [varchar](42) NOT NULL,
	[LASTUPDATED] [nvarchar](55) NOT NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
) 
GO

--Syntax Error: Incorrect syntax near NULL.
--CREATE TABLE [psa].[WBAHK_FactMIDATA_GSOOPEN_HKSQLDB](
--[row_id] [bigint] IDENTITY(1,1) NOT NULL,
--	[DATEKEY] [varchar](8) NULL,
--	[OWNER] [nvarchar](255) NOT NULL,
--	[BIZ_CODE] [nvarchar](200) NULL,
--	[BUSINESS] [nvarchar](255) NULL,
--	[DEPARTMENT] [nvarchar](600) NULL,
--	[SUBDEPARTMENT] [nvarchar](255) NULL,
--	[DEPARTMENT_FY16] [nvarchar](255) NULL,
--	[SUBDEPARTMENT_FY16] [nvarchar](255) NULL,
--	[WBATIER1CODE] [nvarchar](255) NULL,
--	[WBATIER2CODE] [nvarchar](255) NULL,
--	[WBA_CATEGORYTIER1] [nvarchar](255) NULL,
--	[WBA_CATEGORYTIER2] [nvarchar](255) NULL,
--	[PRODUCTGROUP] [nvarchar](255) NULL,
--	[BRAND] [nvarchar](255) NULL,
--	[BRAND_NAME] [nvarchar](255) NULL,
--	[BRAND_TYPECODE] [nvarchar](255) NULL,
--	[BRAND_TYPENAME] [nvarchar](255) NULL,
--	[SEASON] [nvarchar](255) NULL,
--	[PO_ORDERTYPE] [nvarchar](255) NULL,
--	[IS_CMI] [nvarchar](255) NULL,
--	[CUSTOMERCOMPANY] [nvarchar](255) NULL,
--	[SUPPLIER] [nvarchar](255) NULL,
--	[SUPPLIERNAME] [nvarchar](255) NULL,
--	[PO_STATUS] [nvarchar](255) NULL,
--	[CUSTOMERONO] [nvarchar](255) NOT NULL,
--	[QUOTENO] [nvarchar](255) NULL,
--	[PROJECT] [nvarchar](255) NULL,
--	[RANGE] [nvarchar](255) NULL,
--	[OFFERNO] [nvarchar](255) NULL,
--	[SAP_PONO] [nvarchar](255) NULL,
--	[WBA_PONO] [nvarchar](255) NULL,
--	[PROFORMAPONO] [nvarchar](255) NOT NULL,
--	[PO_LINENO] [nvarchar](500) NOT NULL,
--	[ITEMCODE] [nvarchar](255) NOT NULL,
--	[DESCRIPTION] [nvarchar](255) NULL,
--	[QTYPEROUTER] [nvarchar](500) NULL,
--	[QTYPERINNER] [nvarchar](500) NULL,
--	[ORIGINALCUR] [nvarchar](255) NULL,
--	[UNITPRICE] [nvarchar](500) NULL,
--	[PO_QTY] [nvarchar](500) NULL,
--	[POQTYAMT_OC] [nvarchar](500) NULL,
--	[ACTUALSHIPPEDQTY] [nvarchar](384) NULL,
--	[SAQTY] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
--	[EXRATE] [nvarchar](384) NULL,
--	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_GBP] [nvarchar](500) NULL,
--	[COUNTRYOFORIGIN] [nvarchar](255) NULL,
--	[PORTOFLADING] [nvarchar](255) NULL,
--	[PORTOFLADING_NAME] [nvarchar](255) NULL,
--	[PORT_LEADTIME] [nvarchar](384) NULL,
--	[PORT_COUNTRY] [nvarchar](255) NULL,
--	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
--	[LTPO_ETDREDUCED] [nvarchar](500)) NULL,
--	[MODEOFTRANSPORT] [nvarchar](18) NULL,
--	[LOADINGMODE] [nvarchar](35) NULL,
--	[SHIPPINGTERMS] [nvarchar](6) NULL,
--	[SHIPPINGCOMPANY] [nvarchar](17) NULL,
--	[DELIVERWAREHOUSE] [nvarchar](17) NULL,
--	[IMPORTCOUNTRY] [nvarchar](3) NULL,
--	[PO_DATE] [nvarchar](55) NULL,
--	[PO_RELEASEDATE] [nvarchar](55) NULL,
--	[POVSRELDATE] [nvarchar](500) NULL,
--	[CUSTREQ_SIW] [nvarchar](55) NULL,
--	[OLSD] [nvarchar](55) NULL,
--	[CURRENT_ESD] [nvarchar](55) NULL,
--	[CLSD] [nvarchar](55) NULL,
--	[CSIW] [nvarchar](55) NULL,
--	[OSIW] [nvarchar](55) NULL,
--	[ACRD] [nvarchar](55) NULL,
--	[AETD] [nvarchar](55) NULL,
--	[CLSD_OLSD] [nvarchar](55) NULL,
--	[ACRDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSOLSD] [nvarchar](500) NULL,
--	[PO_CLSD] [nvarchar](500) NULL,
--	[PO_AETD] [nvarchar](500) NULL,
--	[PO_ACRD] [nvarchar](500) NULL,
--	[POREL_CLSD] [nvarchar](500) NULL,
--	[POREL_AETD] [nvarchar](500) NULL,
--	[POREL_ACRD] [nvarchar](500) NULL,
--	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
--	[CLSDVSOLSD] [nvarchar](500) NULL,
--	[SHIPWINDOWRESULT] [nvarchar](4) NULL,
--	[SHIPWINDOWRESULT_FY16] [nvarchar](4) NULL,
--	[DELAYCODE] [nvarchar](35) NULL,
--	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
--	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
--	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
--	[BQORDERLTPORTCODE] [nvarchar](384) NULL,
--	[LTDIFF] [nvarchar](500) NULL,
--	[PODATERESULT] [nvarchar](55) NULL,
--	[TEAM_CODE] [nvarchar](35) NULL,
--	[TEAM_SUBCODE] [nvarchar](2) NULL,
--	[TEAM_CODE_FY16] [nvarchar](200) NULL,
--	[TEAM_SUBCODE_FY16] [nvarchar](2) NULL,
--	[XREF] [nvarchar](35) NULL,
--	[BUSINESSUNIT] [nvarchar](35) NULL,
--	[BUFILTER] [nvarchar](5) NULL,
--	[BUFILTER_TSS] [nvarchar](12) NULL,
--	[SARELEASEDATE] [nvarchar](55) NULL,
--	[SANO] [nvarchar](35) NULL,
--	[FACTORY] [nvarchar](17) NULL,
--	[CONFIRMEDDATE] [nvarchar](55) NULL,
--	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
--	[BCMK_REFNO] [nvarchar](35) NULL,
--	[SHIPMENT PHASE] [nvarchar](500) NULL,
--	[OFFERSTATUS] [nvarchar](35) NULL,
--	[PRICEDEVIATION] [nvarchar](500) NULL,
--	[SETRELATIONSHIP] [nvarchar](35) NULL,
--	[LINENO] [nvarchar](35) NULL,
--	[SEASONYEAR] [nvarchar](500) NULL,
--	[COMMENTS] [nvarchar](250) NULL,
--	[LASTMODIFIEDDT] [nvarchar](55) NULL,
--	[LASTMODIFIEDBY] [nvarchar](18) NULL,
--	[ISSARELEASED] [nvarchar](35) NULL,
--	[PARTYNAME] [nvarchar](80) NULL,
--	[POSERIES] [nvarchar](6) NULL,
--	[LENGTH] [nvarchar](384) NULL,
--	[WIDTH] [nvarchar](384) NULL,
--	[HEIGHT] [nvarchar](384) NULL,
--	[TTL_KGS] [nvarchar](384) NULL,
--	[TTL_CBM] [nvarchar](384) NULL,
--	[SUPPLIERRESULT] [nvarchar](4) NULL,
--	[OVERALLRESULT] [nvarchar](4) NULL,
--	[ASMRESULT] [nvarchar](4) NULL,
--	[CHECK1] [nvarchar](5) NULL,
--	[CHECK2] [nvarchar](5) NULL,
--	[CHECK3] [nvarchar](5) NULL,
--	[CHECK4] [nvarchar](5) NULL,
--	[CHECK5] [nvarchar](5) NULL,
--	[CHECK6] [nvarchar](5) NULL,
--	[PENALTYSEC] [nvarchar](200) NULL,
--	[PENALTY_RATE] [nvarchar](384) NULL,
--	[POQTYAMT_OC_PENALTY] [nvarchar](384) NULL,
--	[POQTYAMT_USD_PENALTY] [nvarchar](384) NULL,
--	[DATASOURCE] [varchar](3) NOT NULL,
--	[DATASOURCE_IDX] [varchar](42) NOT NULL,
--	[LASTUPDATED] [nvarchar](55) NOT NULL,
--	[etl_runlog_id] [nvarchar](20) NULL,
--	[asset_id] [nvarchar](20) NULL,
--	[record_source_id] [nvarchar](20) NULL,
--	[row_status] [int] NULL,
--	[created_timestamp] [datetime] NULL,
--	[active_flag] [char](1) NULL
--) 



GO

CREATE TABLE [psa].[WBAHK_FactMIDATA_GSOOPEN_HKSQLDB](
[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[DATEKEY] [varchar](8) NULL,
	[OWNER] [nvarchar](255) NOT NULL,
	[BIZ_CODE] [nvarchar](200) NULL,
	[BUSINESS] [nvarchar](255) NULL,
	[DEPARTMENT] [nvarchar](600) NULL,
	[SUBDEPARTMENT] [nvarchar](255) NULL,
	[DEPARTMENT_FY16] [nvarchar](255) NULL,
	[SUBDEPARTMENT_FY16] [nvarchar](255) NULL,
	[WBATIER1CODE] [nvarchar](255) NULL,
	[WBATIER2CODE] [nvarchar](255) NULL,
	[WBA_CATEGORYTIER1] [nvarchar](255) NULL,
	[WBA_CATEGORYTIER2] [nvarchar](255) NULL,
	[PRODUCTGROUP] [nvarchar](255) NULL,
	[BRAND] [nvarchar](255) NULL,
	[BRAND_NAME] [nvarchar](255) NULL,
	[BRAND_TYPECODE] [nvarchar](255) NULL,
	[BRAND_TYPENAME] [nvarchar](255) NULL,
	[SEASON] [nvarchar](255) NULL,
	[PO_ORDERTYPE] [nvarchar](255) NULL,
	[IS_CMI] [nvarchar](255) NULL,
	[CUSTOMERCOMPANY] [nvarchar](255) NULL,
	[SUPPLIER] [nvarchar](255) NULL,
	[SUPPLIERNAME] [nvarchar](255) NULL,
	[PO_STATUS] [nvarchar](255) NULL,
	[CUSTOMERONO] [nvarchar](255) NOT NULL,
	[QUOTENO] [nvarchar](255) NULL,
	[PROJECT] [nvarchar](255) NULL,
	[RANGE] [nvarchar](255) NULL,
	[OFFERNO] [nvarchar](255) NULL,
	[SAP_PONO] [nvarchar](255) NULL,
	[WBA_PONO] [nvarchar](255) NULL,
	[PROFORMAPONO] [nvarchar](255) NOT NULL,
	[PO_LINENO] [nvarchar](500) NOT NULL,
	[ITEMCODE] [nvarchar](255) NOT NULL,
	[DESCRIPTION] [nvarchar](255) NULL,
	[QTYPEROUTER] [nvarchar](500) NULL,
	[QTYPERINNER] [nvarchar](500) NULL,
	[ORIGINALCUR] [nvarchar](255) NULL,
	[UNITPRICE] [nvarchar](500) NULL,
	[PO_QTY] [nvarchar](500) NULL,
	[POQTYAMT_OC] [nvarchar](500) NULL,
	[ACTUALSHIPPEDQTY] [nvarchar](384) NULL,
	[SAQTY] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
	[EXRATE] [nvarchar](384) NULL,
	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_GBP] [nvarchar](500) NULL,
	[COUNTRYOFORIGIN] [nvarchar](255) NULL,
	[PORTOFLADING] [nvarchar](255) NULL,
	[PORTOFLADING_NAME] [nvarchar](255) NULL,
	[PORT_LEADTIME] [nvarchar](384) NULL,
	[PORT_COUNTRY] [nvarchar](255) NULL,
	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
	[LTPO_ETDREDUCED] [nvarchar](500)) NULL,
	[MODEOFTRANSPORT] [nvarchar](18) NULL,
	[LOADINGMODE] [nvarchar](35) NULL,
	[SHIPPINGTERMS] [nvarchar](6) NULL,
	[SHIPPINGCOMPANY] [nvarchar](17) NULL,
	[DELIVERWAREHOUSE] [nvarchar](17) NULL,
	[IMPORTCOUNTRY] [nvarchar](3) NULL,
	[PO_DATE] [nvarchar](55) NULL,
	[PO_RELEASEDATE] [nvarchar](55) NULL,
	[POVSRELDATE] [nvarchar](500) NULL,
	[CUSTREQ_SIW] [nvarchar](55) NULL,
	[OLSD] [nvarchar](55) NULL,
	[CURRENT_ESD] [nvarchar](55) NULL,
	[CLSD] [nvarchar](55) NULL,
	[CSIW] [nvarchar](55) NULL,
	[OSIW] [nvarchar](55) NULL,
	[ACRD] [nvarchar](55) NULL,
	[AETD] [nvarchar](55) NULL,
	[CLSD_OLSD] [nvarchar](55) NULL,
	[ACRDVSCLSD] [nvarchar](500) NULL,
	[AETDVSCLSD] [nvarchar](500) NULL,
	[AETDVSOLSD] [nvarchar](500) NULL,
	[PO_CLSD] [nvarchar](500) NULL,
	[PO_AETD] [nvarchar](500) NULL,
	[PO_ACRD] [nvarchar](500) NULL,
	[POREL_CLSD] [nvarchar](500) NULL,
	[POREL_AETD] [nvarchar](500) NULL,
	[POREL_ACRD] [nvarchar](500) NULL,
	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
	[CLSDVSOLSD] [nvarchar](500) NULL,
	[SHIPWINDOWRESULT] [nvarchar](4) NULL,
	[SHIPWINDOWRESULT_FY16] [nvarchar](4) NULL,
	[DELAYCODE] [nvarchar](35) NULL,
	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
	[BQORDERLTPORTCODE] [nvarchar](384) NULL,
	[LTDIFF] [nvarchar](500) NULL,
	[PODATERESULT] [nvarchar](55) NULL,
	[TEAM_CODE] [nvarchar](35) NULL,
	[TEAM_SUBCODE] [nvarchar](2) NULL,
	[TEAM_CODE_FY16] [nvarchar](200) NULL,
	[TEAM_SUBCODE_FY16] [nvarchar](2) NULL,
	[XREF] [nvarchar](35) NULL,
	[BUSINESSUNIT] [nvarchar](35) NULL,
	[BUFILTER] [nvarchar](5) NULL,
	[BUFILTER_TSS] [nvarchar](12) NULL,
	[SARELEASEDATE] [nvarchar](55) NULL,
	[SANO] [nvarchar](35) NULL,
	[FACTORY] [nvarchar](17) NULL,
	[CONFIRMEDDATE] [nvarchar](55) NULL,
	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
	[BCMK_REFNO] [nvarchar](35) NULL,
	[SHIPMENT PHASE] [nvarchar](500) NULL,
	[OFFERSTATUS] [nvarchar](35) NULL,
	[PRICEDEVIATION] [nvarchar](500) NULL,
	[SETRELATIONSHIP] [nvarchar](35) NULL,
	[LINENO] [nvarchar](35) NULL,
	[SEASONYEAR] [nvarchar](500) NULL,
	[COMMENTS] [nvarchar](250) NULL,
	[LASTMODIFIEDDT] [nvarchar](55) NULL,
	[LASTMODIFIEDBY] [nvarchar](18) NULL,
	[ISSARELEASED] [nvarchar](35) NULL,
	[PARTYNAME] [nvarchar](80) NULL,
	[POSERIES] [nvarchar](6) NULL,
	[LENGTH] [nvarchar](384) NULL,
	[WIDTH] [nvarchar](384) NULL,
	[HEIGHT] [nvarchar](384) NULL,
	[TTL_KGS] [nvarchar](384) NULL,
	[TTL_CBM] [nvarchar](384) NULL,
	[SUPPLIERRESULT] [nvarchar](4) NULL,
	[OVERALLRESULT] [nvarchar](4) NULL,
	[ASMRESULT] [nvarchar](4) NULL,
	[CHECK1] [nvarchar](5) NULL,
	[CHECK2] [nvarchar](5) NULL,
	[CHECK3] [nvarchar](5) NULL,
	[CHECK4] [nvarchar](5) NULL,
	[CHECK5] [nvarchar](5) NULL,
	[CHECK6] [nvarchar](5) NULL,
	[PENALTYSEC] [nvarchar](200) NULL,
	[PENALTY_RATE] [nvarchar](384) NULL,
	[POQTYAMT_OC_PENALTY] [nvarchar](384) NULL,
	[POQTYAMT_USD_PENALTY] [nvarchar](384) NULL,
	[DATASOURCE] [varchar](3) NOT NULL,
	[DATASOURCE_IDX] [varchar](42) NOT NULL,
	[LASTUPDATED] [nvarchar](55) NOT NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
) 
GO

--Syntax Error: Incorrect syntax near NULL.
--CREATE TABLE [psa].[WBAHK_FactMIDATA_GSOOPEN_HKSQLDB](
--[row_id] [bigint] IDENTITY(1,1) NOT NULL,
--	[DATEKEY] [varchar](8) NULL,
--	[OWNER] [nvarchar](255) NOT NULL,
--	[BIZ_CODE] [nvarchar](200) NULL,
--	[BUSINESS] [nvarchar](255) NULL,
--	[DEPARTMENT] [nvarchar](600) NULL,
--	[SUBDEPARTMENT] [nvarchar](255) NULL,
--	[DEPARTMENT_FY16] [nvarchar](255) NULL,
--	[SUBDEPARTMENT_FY16] [nvarchar](255) NULL,
--	[WBATIER1CODE] [nvarchar](255) NULL,
--	[WBATIER2CODE] [nvarchar](255) NULL,
--	[WBA_CATEGORYTIER1] [nvarchar](255) NULL,
--	[WBA_CATEGORYTIER2] [nvarchar](255) NULL,
--	[PRODUCTGROUP] [nvarchar](255) NULL,
--	[BRAND] [nvarchar](255) NULL,
--	[BRAND_NAME] [nvarchar](255) NULL,
--	[BRAND_TYPECODE] [nvarchar](255) NULL,
--	[BRAND_TYPENAME] [nvarchar](255) NULL,
--	[SEASON] [nvarchar](255) NULL,
--	[PO_ORDERTYPE] [nvarchar](255) NULL,
--	[IS_CMI] [nvarchar](255) NULL,
--	[CUSTOMERCOMPANY] [nvarchar](255) NULL,
--	[SUPPLIER] [nvarchar](255) NULL,
--	[SUPPLIERNAME] [nvarchar](255) NULL,
--	[PO_STATUS] [nvarchar](255) NULL,
--	[CUSTOMERONO] [nvarchar](255) NOT NULL,
--	[QUOTENO] [nvarchar](255) NULL,
--	[PROJECT] [nvarchar](255) NULL,
--	[RANGE] [nvarchar](255) NULL,
--	[OFFERNO] [nvarchar](255) NULL,
--	[SAP_PONO] [nvarchar](255) NULL,
--	[WBA_PONO] [nvarchar](255) NULL,
--	[PROFORMAPONO] [nvarchar](255) NOT NULL,
--	[PO_LINENO] [nvarchar](500) NOT NULL,
--	[ITEMCODE] [nvarchar](255) NOT NULL,
--	[DESCRIPTION] [nvarchar](255) NULL,
--	[QTYPEROUTER] [nvarchar](500) NULL,
--	[QTYPERINNER] [nvarchar](500) NULL,
--	[ORIGINALCUR] [nvarchar](255) NULL,
--	[UNITPRICE] [nvarchar](500) NULL,
--	[PO_QTY] [nvarchar](500) NULL,
--	[POQTYAMT_OC] [nvarchar](500) NULL,
--	[ACTUALSHIPPEDQTY] [nvarchar](384) NULL,
--	[SAQTY] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
--	[EXRATE] [nvarchar](384) NULL,
--	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_GBP] [nvarchar](500) NULL,
--	[COUNTRYOFORIGIN] [nvarchar](255) NULL,
--	[PORTOFLADING] [nvarchar](255) NULL,
--	[PORTOFLADING_NAME] [nvarchar](255) NULL,
--	[PORT_LEADTIME] [nvarchar](384) NULL,
--	[PORT_COUNTRY] [nvarchar](255) NULL,
--	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
--	[LTPO_ETDREDUCED] [nvarchar](500)) NULL,
--	[MODEOFTRANSPORT] [nvarchar](18) NULL,
--	[LOADINGMODE] [nvarchar](35) NULL,
--	[SHIPPINGTERMS] [nvarchar](6) NULL,
--	[SHIPPINGCOMPANY] [nvarchar](17) NULL,
--	[DELIVERWAREHOUSE] [nvarchar](17) NULL,
--	[IMPORTCOUNTRY] [nvarchar](3) NULL,
--	[PO_DATE] [nvarchar](55) NULL,
--	[PO_RELEASEDATE] [nvarchar](55) NULL,
--	[POVSRELDATE] [nvarchar](500) NULL,
--	[CUSTREQ_SIW] [nvarchar](55) NULL,
--	[OLSD] [nvarchar](55) NULL,
--	[CURRENT_ESD] [nvarchar](55) NULL,
--	[CLSD] [nvarchar](55) NULL,
--	[CSIW] [nvarchar](55) NULL,
--	[OSIW] [nvarchar](55) NULL,
--	[ACRD] [nvarchar](55) NULL,
--	[AETD] [nvarchar](55) NULL,
--	[CLSD_OLSD] [nvarchar](55) NULL,
--	[ACRDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSOLSD] [nvarchar](500) NULL,
--	[PO_CLSD] [nvarchar](500) NULL,
--	[PO_AETD] [nvarchar](500) NULL,
--	[PO_ACRD] [nvarchar](500) NULL,
--	[POREL_CLSD] [nvarchar](500) NULL,
--	[POREL_AETD] [nvarchar](500) NULL,
--	[POREL_ACRD] [nvarchar](500) NULL,
--	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
--	[CLSDVSOLSD] [nvarchar](500) NULL,
--	[SHIPWINDOWRESULT] [nvarchar](4) NULL,
--	[SHIPWINDOWRESULT_FY16] [nvarchar](4) NULL,
--	[DELAYCODE] [nvarchar](35) NULL,
--	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
--	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
--	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
--	[BQORDERLTPORTCODE] [nvarchar](384) NULL,
--	[LTDIFF] [nvarchar](500) NULL,
--	[PODATERESULT] [nvarchar](55) NULL,
--	[TEAM_CODE] [nvarchar](35) NULL,
--	[TEAM_SUBCODE] [nvarchar](2) NULL,
--	[TEAM_CODE_FY16] [nvarchar](200) NULL,
--	[TEAM_SUBCODE_FY16] [nvarchar](2) NULL,
--	[XREF] [nvarchar](35) NULL,
--	[BUSINESSUNIT] [nvarchar](35) NULL,
--	[BUFILTER] [nvarchar](5) NULL,
--	[BUFILTER_TSS] [nvarchar](12) NULL,
--	[SARELEASEDATE] [nvarchar](55) NULL,
--	[SANO] [nvarchar](35) NULL,
--	[FACTORY] [nvarchar](17) NULL,
--	[CONFIRMEDDATE] [nvarchar](55) NULL,
--	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
--	[BCMK_REFNO] [nvarchar](35) NULL,
--	[SHIPMENT PHASE] [nvarchar](500) NULL,
--	[OFFERSTATUS] [nvarchar](35) NULL,
--	[PRICEDEVIATION] [nvarchar](500) NULL,
--	[SETRELATIONSHIP] [nvarchar](35) NULL,
--	[LINENO] [nvarchar](35) NULL,
--	[SEASONYEAR] [nvarchar](500) NULL,
--	[COMMENTS] [nvarchar](250) NULL,
--	[LASTMODIFIEDDT] [nvarchar](55) NULL,
--	[LASTMODIFIEDBY] [nvarchar](18) NULL,
--	[ISSARELEASED] [nvarchar](35) NULL,
--	[PARTYNAME] [nvarchar](80) NULL,
--	[POSERIES] [nvarchar](6) NULL,
--	[LENGTH] [nvarchar](384) NULL,
--	[WIDTH] [nvarchar](384) NULL,
--	[HEIGHT] [nvarchar](384) NULL,
--	[TTL_KGS] [nvarchar](384) NULL,
--	[TTL_CBM] [nvarchar](384) NULL,
--	[SUPPLIERRESULT] [nvarchar](4) NULL,
--	[OVERALLRESULT] [nvarchar](4) NULL,
--	[ASMRESULT] [nvarchar](4) NULL,
--	[CHECK1] [nvarchar](5) NULL,
--	[CHECK2] [nvarchar](5) NULL,
--	[CHECK3] [nvarchar](5) NULL,
--	[CHECK4] [nvarchar](5) NULL,
--	[CHECK5] [nvarchar](5) NULL,
--	[CHECK6] [nvarchar](5) NULL,
--	[PENALTYSEC] [nvarchar](200) NULL,
--	[PENALTY_RATE] [nvarchar](384) NULL,
--	[POQTYAMT_OC_PENALTY] [nvarchar](384) NULL,
--	[POQTYAMT_USD_PENALTY] [nvarchar](384) NULL,
--	[DATASOURCE] [varchar](3) NOT NULL,
--	[DATASOURCE_IDX] [varchar](42) NOT NULL,
--	[LASTUPDATED] [nvarchar](55) NOT NULL,
--	[etl_runlog_id] [nvarchar](20) NULL,
--	[asset_id] [nvarchar](20) NULL,
--	[record_source_id] [nvarchar](20) NULL,
--	[row_status] [int] NULL,
--	[created_timestamp] [datetime] NULL,
--	[active_flag] [char](1) NULL
--) 



GO

CREATE TABLE [psa].[WBAHK_FactMIDATA_HKSQLDB](
[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[DateKey] [varchar](50) NULL,
	[OWNER] [varchar](100) NULL,
	[BIZ_CODE] [varchar](50) NULL,
	[BUSINESS] [varchar](100) NULL,
	[DEPARTMENT] [varchar](200) NULL,
	[SUBDEPARTMENT] [varchar](200) NULL,
	[DEPARTMENT_FY16] [varchar](100) NULL,
	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
	[WBATIER1CODE] [varchar](100) NULL,
	[WBATIER2CODE] [varchar](100) NULL,
	[WBA_CATEGORYTIER1] [varchar](100) NULL,
	[WBA_CATEGORYTIER2] [varchar](100) NULL,
	[PRODUCTGROUP] [varchar](100) NULL,
	[BRAND] [varchar](255) NULL,
	[BRAND_NAME] [varchar](255) NULL,
	[BRAND_TYPECODE] [varchar](100) NULL,
	[BRAND_TYPENAME] [varchar](255) NULL,
	[SEASON] [varchar](100) NULL,
	[PO_ORDERTYPE] [nvarchar](100) NULL,
	[IS_CMI] [nvarchar](100) NULL,
	[CUST_CODE] [nvarchar](100) NULL,
	[VENDORCODE] [nvarchar](100) NULL,
	[SUPPLIERNAME] [varchar](200) NULL,
	[PO_STATUS] [varchar](100) NULL,
	[CUSTOMERONO] [varchar](100) NULL,
	[QUOTENO] [varchar](100) NULL,
	[PROJECTGROUP] [varchar](100) NULL,
	[PROJECTNAME] [varchar](100) NULL,
	[OFFERNO] [varchar](100) NULL,
	[SAP_PONO] [varchar](100) NULL,
	[WBA_PONO] [varchar](100) NULL,
	[PROFORMAPONO] [varchar](100) NULL,
	[PO_LINENO] [nvarchar](50) NULL,
	[ITEMCODE] [varchar](100) NULL,
	[DESCRIPTION] [nvarchar](160) NULL,
	[QTYPEROUTER] [varchar](100) NULL,
	[QTYPERINNER] [varchar](100) NULL,
	[ORIGINALCUR] [nvarchar](6) NULL,
	[UNITPRICE] [nvarchar](500) NULL,
	[PO_QTY] [nvarchar](500) NULL,
	[POQTYAMT_OC] [nvarchar](500) NULL,
	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
	[SAQTY] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
	[EXRATE] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_GBP] [nvarchar](500) NULL,
	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
	[PORTOFLADING] [varchar](100) NULL,
	[PORTOFLADING_NAME] [varchar](100) NULL,
	[PORT_LEADTIME] [nvarchar](500) NULL,
	[PORT_COUNTRY] [varchar](100) NULL,
	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
	[MODEOFTRANSPORT] [varchar](100) NULL,
	[LOADINGMODE] [varchar](100) NULL,
	[SHIPPINGTERMS] [varchar](100) NULL,
	[SHIPPINGCOMPANY] [varchar](100) NULL,
	[DELIVERWAREHOUSE] [varchar](100) NULL,
	[IMPORTCOUNTRY] [varchar](100) NULL,
	[PO_DATE] [nvarchar](55) NULL,
	[PO_RELEASEDATE] [nvarchar](55) NULL,
	[POVSRELDATE] [nvarchar](500) NULL,
	[CUSTREQ_SIW] [nvarchar](55) NULL,
	[OLSD] [nvarchar](55) NULL,
	[CURRENT_ESD] [nvarchar](55) NULL,
	[CLSD] [nvarchar](55) NULL,
	[CSIW] [nvarchar](55) NULL,
	[OSIW] [nvarchar](55)] NULL,
	[ACRD] [nvarchar](55) NULL,
	[AETD] [nvarchar](55) NULL,
	[CLSD_OLSD] [nvarchar](55) NULL,
	[ACRDVSCLSD] [nvarchar](500) NULL,
	[AETDVSCLSD] [nvarchar](500) NULL,
	[AETDVSOLSD] [nvarchar](500) NULL,
	[PO_CLSD] [nvarchar](500) NULL,
	[PO_AETD] [nvarchar](500) NULL,
	[PO_ACRD] [nvarchar](500) NULL,
	[POREL_CLSD] [nvarchar](500) NULL,
	[POREL_AETD] [nvarchar](500) NULL,
	[POREL_ACRD] [nvarchar](500) NULL,
	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
	[CLSDVSOLSD] [nvarchar](500) NULL,
	[SHIPWINDOWRESULT] [varchar](100) NULL,
	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
	[DELAYCODE] [varchar](100) NULL,
	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
	[LTDIFF] [nvarchar](500) NULL,
	[PODATERESULT] [nvarchar](55) NULL,
	[TEAM_CODE] [varchar](50) NULL,
	[TEAM_SUB_CODE] [varchar](50) NULL,
	[TEAM_CODE_FY16] [varchar](50) NULL,
	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
	[XREF] [varchar](50) NULL,
	[BUSINESSUNIT] [varchar](50) NULL,
	[BUFILTER] [varchar](50) NULL,
	[BUFILTER_TSS] [varchar](50) NULL,
	[SARELEASEDATE] [nvarchar](55) NULL,
	[SANO] [varchar](50) NULL,
	[FACTORY] [varchar](50) NULL,
	[CONFIRMEDDATE] [varchar](50) NULL,
	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
	[BCMK_REFNO] [varchar](50) NULL,
	[SHIPMENT_PHASE] [varchar](50) NULL,
	[OFFERSTATUS] [varchar](50) NULL,
	[PRICEDEVIATION] [nvarchar](500) NULL,
	[SETRELATIONSHIP] [varchar](50) NULL,
	[LINENO] [varchar](50) NULL,
	[SEASONYEAR] [varchar](50) NULL,
	[COMMENTS] [varchar](255) NULL,
	[LASTMODIFIEDDT] [nvarchar](55) NULL,
	[LASTMODIFIEDBY] [varchar](50) NULL,
	[ISSARELEASED] [varchar](50) NULL,
	[PARTYNAME] [varchar](255) NULL,
	[POSERIES] [varchar](50) NULL,
	[LENGTH] [nvarchar](500) NULL,
	[WIDTH] [nvarchar](500) NULL,
	[HEIGHT] [nvarchar](500) NULL,
	[TTL_KGS] [nvarchar](500) NULL,
	[TTL_CBM] [nvarchar](500) NULL,
	[SUPPLIERRESULT] [varchar](50) NULL,
	[OVERALLRESULT] [varchar](50) NULL,
	[ASMRESULT] [varchar](50) NULL,
	[CHECK1] [nvarchar](10) NULL,
	[CHECK2] [nvarchar](10) NULL,
	[CHECK3] [nvarchar](10) NULL,
	[CHECK4] [nvarchar](10) NULL,
	[CHECK5] [nvarchar](10) NULL,
	[CHECK6] [nvarchar](10) NULL,
	[PENALTYSEC] [nvarchar](40) NULL,
	[PENALTY_RATE] [nvarchar](500) NULL,
	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
	[DATASOURCE] [varchar](50) NULL,
	[DATASOURCE_IDX] [varchar](255) NULL,
	[LASTUPDATED] [nvarchar](55) NULL,
	[UNIQUE_KEY] [nvarchar](500) IDENTITY(1,1) NOT NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
) 
GO

--Syntax Error: Incorrect syntax near ].
--CREATE TABLE [psa].[WBAHK_FactMIDATA_HKSQLDB](
--[row_id] [bigint] IDENTITY(1,1) NOT NULL,
--	[DateKey] [varchar](50) NULL,
--	[OWNER] [varchar](100) NULL,
--	[BIZ_CODE] [varchar](50) NULL,
--	[BUSINESS] [varchar](100) NULL,
--	[DEPARTMENT] [varchar](200) NULL,
--	[SUBDEPARTMENT] [varchar](200) NULL,
--	[DEPARTMENT_FY16] [varchar](100) NULL,
--	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
--	[WBATIER1CODE] [varchar](100) NULL,
--	[WBATIER2CODE] [varchar](100) NULL,
--	[WBA_CATEGORYTIER1] [varchar](100) NULL,
--	[WBA_CATEGORYTIER2] [varchar](100) NULL,
--	[PRODUCTGROUP] [varchar](100) NULL,
--	[BRAND] [varchar](255) NULL,
--	[BRAND_NAME] [varchar](255) NULL,
--	[BRAND_TYPECODE] [varchar](100) NULL,
--	[BRAND_TYPENAME] [varchar](255) NULL,
--	[SEASON] [varchar](100) NULL,
--	[PO_ORDERTYPE] [nvarchar](100) NULL,
--	[IS_CMI] [nvarchar](100) NULL,
--	[CUST_CODE] [nvarchar](100) NULL,
--	[VENDORCODE] [nvarchar](100) NULL,
--	[SUPPLIERNAME] [varchar](200) NULL,
--	[PO_STATUS] [varchar](100) NULL,
--	[CUSTOMERONO] [varchar](100) NULL,
--	[QUOTENO] [varchar](100) NULL,
--	[PROJECTGROUP] [varchar](100) NULL,
--	[PROJECTNAME] [varchar](100) NULL,
--	[OFFERNO] [varchar](100) NULL,
--	[SAP_PONO] [varchar](100) NULL,
--	[WBA_PONO] [varchar](100) NULL,
--	[PROFORMAPONO] [varchar](100) NULL,
--	[PO_LINENO] [nvarchar](50) NULL,
--	[ITEMCODE] [varchar](100) NULL,
--	[DESCRIPTION] [nvarchar](160) NULL,
--	[QTYPEROUTER] [varchar](100) NULL,
--	[QTYPERINNER] [varchar](100) NULL,
--	[ORIGINALCUR] [nvarchar](6) NULL,
--	[UNITPRICE] [nvarchar](500) NULL,
--	[PO_QTY] [nvarchar](500) NULL,
--	[POQTYAMT_OC] [nvarchar](500) NULL,
--	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
--	[SAQTY] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
--	[EXRATE] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_GBP] [nvarchar](500) NULL,
--	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
--	[PORTOFLADING] [varchar](100) NULL,
--	[PORTOFLADING_NAME] [varchar](100) NULL,
--	[PORT_LEADTIME] [nvarchar](500) NULL,
--	[PORT_COUNTRY] [varchar](100) NULL,
--	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
--	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
--	[MODEOFTRANSPORT] [varchar](100) NULL,
--	[LOADINGMODE] [varchar](100) NULL,
--	[SHIPPINGTERMS] [varchar](100) NULL,
--	[SHIPPINGCOMPANY] [varchar](100) NULL,
--	[DELIVERWAREHOUSE] [varchar](100) NULL,
--	[IMPORTCOUNTRY] [varchar](100) NULL,
--	[PO_DATE] [nvarchar](55) NULL,
--	[PO_RELEASEDATE] [nvarchar](55) NULL,
--	[POVSRELDATE] [nvarchar](500) NULL,
--	[CUSTREQ_SIW] [nvarchar](55) NULL,
--	[OLSD] [nvarchar](55) NULL,
--	[CURRENT_ESD] [nvarchar](55) NULL,
--	[CLSD] [nvarchar](55) NULL,
--	[CSIW] [nvarchar](55) NULL,
--	[OSIW] [nvarchar](55)] NULL,
--	[ACRD] [nvarchar](55) NULL,
--	[AETD] [nvarchar](55) NULL,
--	[CLSD_OLSD] [nvarchar](55) NULL,
--	[ACRDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSOLSD] [nvarchar](500) NULL,
--	[PO_CLSD] [nvarchar](500) NULL,
--	[PO_AETD] [nvarchar](500) NULL,
--	[PO_ACRD] [nvarchar](500) NULL,
--	[POREL_CLSD] [nvarchar](500) NULL,
--	[POREL_AETD] [nvarchar](500) NULL,
--	[POREL_ACRD] [nvarchar](500) NULL,
--	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
--	[CLSDVSOLSD] [nvarchar](500) NULL,
--	[SHIPWINDOWRESULT] [varchar](100) NULL,
--	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
--	[DELAYCODE] [varchar](100) NULL,
--	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
--	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
--	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
--	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
--	[LTDIFF] [nvarchar](500) NULL,
--	[PODATERESULT] [nvarchar](55) NULL,
--	[TEAM_CODE] [varchar](50) NULL,
--	[TEAM_SUB_CODE] [varchar](50) NULL,
--	[TEAM_CODE_FY16] [varchar](50) NULL,
--	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
--	[XREF] [varchar](50) NULL,
--	[BUSINESSUNIT] [varchar](50) NULL,
--	[BUFILTER] [varchar](50) NULL,
--	[BUFILTER_TSS] [varchar](50) NULL,
--	[SARELEASEDATE] [nvarchar](55) NULL,
--	[SANO] [varchar](50) NULL,
--	[FACTORY] [varchar](50) NULL,
--	[CONFIRMEDDATE] [varchar](50) NULL,
--	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
--	[BCMK_REFNO] [varchar](50) NULL,
--	[SHIPMENT_PHASE] [varchar](50) NULL,
--	[OFFERSTATUS] [varchar](50) NULL,
--	[PRICEDEVIATION] [nvarchar](500) NULL,
--	[SETRELATIONSHIP] [varchar](50) NULL,
--	[LINENO] [varchar](50) NULL,
--	[SEASONYEAR] [varchar](50) NULL,
--	[COMMENTS] [varchar](255) NULL,
--	[LASTMODIFIEDDT] [nvarchar](55) NULL,
--	[LASTMODIFIEDBY] [varchar](50) NULL,
--	[ISSARELEASED] [varchar](50) NULL,
--	[PARTYNAME] [varchar](255) NULL,
--	[POSERIES] [varchar](50) NULL,
--	[LENGTH] [nvarchar](500) NULL,
--	[WIDTH] [nvarchar](500) NULL,
--	[HEIGHT] [nvarchar](500) NULL,
--	[TTL_KGS] [nvarchar](500) NULL,
--	[TTL_CBM] [nvarchar](500) NULL,
--	[SUPPLIERRESULT] [varchar](50) NULL,
--	[OVERALLRESULT] [varchar](50) NULL,
--	[ASMRESULT] [varchar](50) NULL,
--	[CHECK1] [nvarchar](10) NULL,
--	[CHECK2] [nvarchar](10) NULL,
--	[CHECK3] [nvarchar](10) NULL,
--	[CHECK4] [nvarchar](10) NULL,
--	[CHECK5] [nvarchar](10) NULL,
--	[CHECK6] [nvarchar](10) NULL,
--	[PENALTYSEC] [nvarchar](40) NULL,
--	[PENALTY_RATE] [nvarchar](500) NULL,
--	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
--	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
--	[DATASOURCE] [varchar](50) NULL,
--	[DATASOURCE_IDX] [varchar](255) NULL,
--	[LASTUPDATED] [nvarchar](55) NULL,
--	[UNIQUE_KEY] [nvarchar](500) IDENTITY(1,1) NOT NULL,
--	[etl_runlog_id] [nvarchar](20) NULL,
--	[asset_id] [nvarchar](20) NULL,
--	[record_source_id] [nvarchar](20) NULL,
--	[row_status] [int] NULL,
--	[created_timestamp] [datetime] NULL,
--	[active_flag] [char](1) NULL
--) 



GO

CREATE TABLE [psa].[WBAHK_FactMIDATA_LIMA_OPEN_HKSQLDB](
[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[DateKey] [varchar](50) NULL,
	[OWNER] [varchar](100) NULL,
	[BIZ_CODE] [varchar](50) NULL,
	[BUSINESS] [varchar](100) NULL,
	[DEPARTMENT] [varchar](100) NULL,
	[SUBDEPARTMENT] [varchar](100) NULL,
	[DEPARTMENT_FY16] [varchar](100) NULL,
	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
	[WBATIER1CODE] [varchar](100) NULL,
	[WBATIER2CODE] [varchar](100) NULL,
	[WBA_CATEGORYTIER1] [varchar](100) NULL,
	[WBA_CATEGORYTIER2] [varchar](100) NULL,
	[PRODUCTGROUP] [varchar](100) NULL,
	[SEASON] [varchar](100) NULL,
	[PO_ORDERTYPE] [nvarchar](100) NULL,
	[CUST_CODE] [nvarchar](100) NULL,
	[VENDORCODE] [nvarchar](100) NULL,
	[SUPPLIERNAME] [varchar](200) NULL,
	[PO_STATUS] [varchar](100) NULL,
	[CUSTOMERONO] [varchar](100) NOT NULL,
	[QUOTENO] [varchar](100) NULL,
	[PROJECTGROUP] [varchar](100) NULL,
	[PROJECTNAME] [varchar](100) NOT NULL,
	[OFFERNO] [varchar](100) NULL,
	[SAP_PONO] [varchar](100) NULL,
	[WBA_PONO] [varchar](100) NULL,
	[PROFORMAPONO] [varchar](100) NULL,
	[PO_LINENO] [nvarchar](50) NULL,
	[ITEMCODE] [varchar](100) NULL,
	[DESCRIPTION] [nvarchar](160) NULL,
	[ORIGINALCUR] [nvarchar](6) NULL,
	[UNITPRICE] [nvarchar](500) NULL,
	[PO_QTY] [nvarchar](500) NULL,
	[POQTYAMT_OC] [nvarchar](500) NULL,
	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
	[SAQTY] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
	[EXRATE] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_USD] [nvarchar](500) NULL,
	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
	[PORTOFLADING] [varchar](100) NULL,
	[PORTOFLADING_NAME] [varchar](100) NULL,
	[PORT_LEADTIME] [nvarchar](500) NULL,
	[PORT_COUNTRY] [varchar](100) NULL,
	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
	[MODEOFTRANSPORT] [varchar](100) NULL,
	[LOADINGMODE] [varchar](100) NULL,
	[SHIPPINGTERMS] [varchar](100) NULL,
	[SHIPPINGCOMPANY] [varchar](100) NULL,
	[DELIVERWAREHOUSE] [varchar](100) NULL,
	[IMPORTCOUNTRY] [varchar](100) NULL,
	[PO_DATE] [nvarchar](55) NULL,
	[PO_RELEASEDATE] [nvarchar](55) NULL,
	[POVSRELDATE] [nvarchar](500) NULL,
	[CUSTREQ_SIW] [nvarchar](55) NULL,
	[OLSD] [nvarchar](55) NULL,
	[CURRENT_ESD] [nvarchar](55) NULL,
	[CLSD] [nvarchar](55) NULL,
	[CSIW] [nvarchar](55) NULL,
	[ACRD] [nvarchar](55) NULL,
	[AETD] [nvarchar](55) NULL,
	[ACRDVSCLSD] [nvarchar](500) NULL,
	[AETDVSCLSD] [nvarchar](500) NULL,
	[AETDVSOLSD] [nvarchar](500) NULL,
	[PO_CLSD] [nvarchar](500) NULL,
	[PO_AETD] [nvarchar](500) NULL,
	[PO_ACRD] [nvarchar](500) NULL,
	[POREL_CLSD] [nvarchar](500) NULL,
	[POREL_AETD] [nvarchar](500) NULL,
	[POREL_ACRD] [nvarchar](500) NULL,
	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
	[CLSDVSOLSD] [nvarchar](500) NULL,
	[SHIPWINDOWRESULT] [varchar](100) NULL,
	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
	[DELAYCODE] [varchar](100) NULL,
	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
	[LTDIFF] [nvarchar](500) NULL,
	[PODATERESULT] [nvarchar](55) NULL,
	[POSERIES] [varchar](100) NULL,
	[LENGTH] [nvarchar](500) NULL,
	[WIDTH] [nvarchar](500) NULL,
	[HEIGHT] [nvarchar](500)) NULL,
	[TTL_KGS] [nvarchar](500) NULL,
	[TTL_CBM] [nvarchar](500) NULL,
	[SUPPLIERRESULT] [varchar](50) NULL,
	[OVERALLRESULT] [varchar](50) NULL,
	[ASMRESULT] [varchar](50) NULL,
	[CHECK1] [nvarchar](10) NULL,
	[CHECK2] [nvarchar](10) NULL,
	[CHECK3] [nvarchar](10) NULL,
	[CHECK4] [nvarchar](10) NULL,
	[CHECK5] [nvarchar](10) NULL,
	[CHECK6] [nvarchar](10) NULL,
	[PENALTYSEC] [nvarchar](40) NULL,
	[PENALTY_RATE] [nvarchar](500) NULL,
	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
	[DATASOURCE] [varchar](50) NULL,
	[DATASOURCE_IDX] [varchar](255) NULL,
	[TEAM_CODE] [varchar](50) NULL,
	[TEAM_SUB_CODE] [varchar](50) NULL,
	[TEAM_CODE_FY16] [varchar](50) NULL,
	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
	[TEAM_CODE_FY17] [varchar](50) NULL,
	[UsageFlag] [varchar](50) NULL,
	[IsQVReported] [varchar](50) NULL,
	[IsSpendReclasstoNextReportPeriod] [varchar](50) NULL,
	[LASTUPDATED] [nvarchar](55)NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
) 
GO

--Syntax Error: Incorrect syntax near NULL.
--CREATE TABLE [psa].[WBAHK_FactMIDATA_LIMA_OPEN_HKSQLDB](
--[row_id] [bigint] IDENTITY(1,1) NOT NULL,
--	[DateKey] [varchar](50) NULL,
--	[OWNER] [varchar](100) NULL,
--	[BIZ_CODE] [varchar](50) NULL,
--	[BUSINESS] [varchar](100) NULL,
--	[DEPARTMENT] [varchar](100) NULL,
--	[SUBDEPARTMENT] [varchar](100) NULL,
--	[DEPARTMENT_FY16] [varchar](100) NULL,
--	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
--	[WBATIER1CODE] [varchar](100) NULL,
--	[WBATIER2CODE] [varchar](100) NULL,
--	[WBA_CATEGORYTIER1] [varchar](100) NULL,
--	[WBA_CATEGORYTIER2] [varchar](100) NULL,
--	[PRODUCTGROUP] [varchar](100) NULL,
--	[SEASON] [varchar](100) NULL,
--	[PO_ORDERTYPE] [nvarchar](100) NULL,
--	[CUST_CODE] [nvarchar](100) NULL,
--	[VENDORCODE] [nvarchar](100) NULL,
--	[SUPPLIERNAME] [varchar](200) NULL,
--	[PO_STATUS] [varchar](100) NULL,
--	[CUSTOMERONO] [varchar](100) NOT NULL,
--	[QUOTENO] [varchar](100) NULL,
--	[PROJECTGROUP] [varchar](100) NULL,
--	[PROJECTNAME] [varchar](100) NOT NULL,
--	[OFFERNO] [varchar](100) NULL,
--	[SAP_PONO] [varchar](100) NULL,
--	[WBA_PONO] [varchar](100) NULL,
--	[PROFORMAPONO] [varchar](100) NULL,
--	[PO_LINENO] [nvarchar](50) NULL,
--	[ITEMCODE] [varchar](100) NULL,
--	[DESCRIPTION] [nvarchar](160) NULL,
--	[ORIGINALCUR] [nvarchar](6) NULL,
--	[UNITPRICE] [nvarchar](500) NULL,
--	[PO_QTY] [nvarchar](500) NULL,
--	[POQTYAMT_OC] [nvarchar](500) NULL,
--	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
--	[SAQTY] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
--	[EXRATE] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_USD] [nvarchar](500) NULL,
--	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
--	[PORTOFLADING] [varchar](100) NULL,
--	[PORTOFLADING_NAME] [varchar](100) NULL,
--	[PORT_LEADTIME] [nvarchar](500) NULL,
--	[PORT_COUNTRY] [varchar](100) NULL,
--	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
--	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
--	[MODEOFTRANSPORT] [varchar](100) NULL,
--	[LOADINGMODE] [varchar](100) NULL,
--	[SHIPPINGTERMS] [varchar](100) NULL,
--	[SHIPPINGCOMPANY] [varchar](100) NULL,
--	[DELIVERWAREHOUSE] [varchar](100) NULL,
--	[IMPORTCOUNTRY] [varchar](100) NULL,
--	[PO_DATE] [nvarchar](55) NULL,
--	[PO_RELEASEDATE] [nvarchar](55) NULL,
--	[POVSRELDATE] [nvarchar](500) NULL,
--	[CUSTREQ_SIW] [nvarchar](55) NULL,
--	[OLSD] [nvarchar](55) NULL,
--	[CURRENT_ESD] [nvarchar](55) NULL,
--	[CLSD] [nvarchar](55) NULL,
--	[CSIW] [nvarchar](55) NULL,
--	[ACRD] [nvarchar](55) NULL,
--	[AETD] [nvarchar](55) NULL,
--	[ACRDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSOLSD] [nvarchar](500) NULL,
--	[PO_CLSD] [nvarchar](500) NULL,
--	[PO_AETD] [nvarchar](500) NULL,
--	[PO_ACRD] [nvarchar](500) NULL,
--	[POREL_CLSD] [nvarchar](500) NULL,
--	[POREL_AETD] [nvarchar](500) NULL,
--	[POREL_ACRD] [nvarchar](500) NULL,
--	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
--	[CLSDVSOLSD] [nvarchar](500) NULL,
--	[SHIPWINDOWRESULT] [varchar](100) NULL,
--	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
--	[DELAYCODE] [varchar](100) NULL,
--	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
--	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
--	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
--	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
--	[LTDIFF] [nvarchar](500) NULL,
--	[PODATERESULT] [nvarchar](55) NULL,
--	[POSERIES] [varchar](100) NULL,
--	[LENGTH] [nvarchar](500) NULL,
--	[WIDTH] [nvarchar](500) NULL,
--	[HEIGHT] [nvarchar](500)) NULL,
--	[TTL_KGS] [nvarchar](500) NULL,
--	[TTL_CBM] [nvarchar](500) NULL,
--	[SUPPLIERRESULT] [varchar](50) NULL,
--	[OVERALLRESULT] [varchar](50) NULL,
--	[ASMRESULT] [varchar](50) NULL,
--	[CHECK1] [nvarchar](10) NULL,
--	[CHECK2] [nvarchar](10) NULL,
--	[CHECK3] [nvarchar](10) NULL,
--	[CHECK4] [nvarchar](10) NULL,
--	[CHECK5] [nvarchar](10) NULL,
--	[CHECK6] [nvarchar](10) NULL,
--	[PENALTYSEC] [nvarchar](40) NULL,
--	[PENALTY_RATE] [nvarchar](500) NULL,
--	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
--	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
--	[DATASOURCE] [varchar](50) NULL,
--	[DATASOURCE_IDX] [varchar](255) NULL,
--	[TEAM_CODE] [varchar](50) NULL,
--	[TEAM_SUB_CODE] [varchar](50) NULL,
--	[TEAM_CODE_FY16] [varchar](50) NULL,
--	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
--	[TEAM_CODE_FY17] [varchar](50) NULL,
--	[UsageFlag] [varchar](50) NULL,
--	[IsQVReported] [varchar](50) NULL,
--	[IsSpendReclasstoNextReportPeriod] [varchar](50) NULL,
--	[LASTUPDATED] [nvarchar](55)NULL,
--	[etl_runlog_id] [nvarchar](20) NULL,
--	[asset_id] [nvarchar](20) NULL,
--	[record_source_id] [nvarchar](20) NULL,
--	[row_status] [int] NULL,
--	[created_timestamp] [datetime] NULL,
--	[active_flag] [char](1) NULL
--) 



GO

CREATE TABLE [psa].[WBAHK_FactMIDATA_GSOOPEN_HKSQLDB](
[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[DATEKEY] [varchar](8) NULL,
	[OWNER] [nvarchar](255) NOT NULL,
	[BIZ_CODE] [nvarchar](200) NULL,
	[BUSINESS] [nvarchar](255) NULL,
	[DEPARTMENT] [nvarchar](600) NULL,
	[SUBDEPARTMENT] [nvarchar](255) NULL,
	[DEPARTMENT_FY16] [nvarchar](255) NULL,
	[SUBDEPARTMENT_FY16] [nvarchar](255) NULL,
	[WBATIER1CODE] [nvarchar](255) NULL,
	[WBATIER2CODE] [nvarchar](255) NULL,
	[WBA_CATEGORYTIER1] [nvarchar](255) NULL,
	[WBA_CATEGORYTIER2] [nvarchar](255) NULL,
	[PRODUCTGROUP] [nvarchar](255) NULL,
	[BRAND] [nvarchar](255) NULL,
	[BRAND_NAME] [nvarchar](255) NULL,
	[BRAND_TYPECODE] [nvarchar](255) NULL,
	[BRAND_TYPENAME] [nvarchar](255) NULL,
	[SEASON] [nvarchar](255) NULL,
	[PO_ORDERTYPE] [nvarchar](255) NULL,
	[IS_CMI] [nvarchar](255) NULL,
	[CUSTOMERCOMPANY] [nvarchar](255) NULL,
	[SUPPLIER] [nvarchar](255) NULL,
	[SUPPLIERNAME] [nvarchar](255) NULL,
	[PO_STATUS] [nvarchar](255) NULL,
	[CUSTOMERONO] [nvarchar](255) NOT NULL,
	[QUOTENO] [nvarchar](255) NULL,
	[PROJECT] [nvarchar](255) NULL,
	[RANGE] [nvarchar](255) NULL,
	[OFFERNO] [nvarchar](255) NULL,
	[SAP_PONO] [nvarchar](255) NULL,
	[WBA_PONO] [nvarchar](255) NULL,
	[PROFORMAPONO] [nvarchar](255) NOT NULL,
	[PO_LINENO] [nvarchar](500) NOT NULL,
	[ITEMCODE] [nvarchar](255) NOT NULL,
	[DESCRIPTION] [nvarchar](255) NULL,
	[QTYPEROUTER] [nvarchar](500) NULL,
	[QTYPERINNER] [nvarchar](500) NULL,
	[ORIGINALCUR] [nvarchar](255) NULL,
	[UNITPRICE] [nvarchar](500) NULL,
	[PO_QTY] [nvarchar](500) NULL,
	[POQTYAMT_OC] [nvarchar](500) NULL,
	[ACTUALSHIPPEDQTY] [nvarchar](384) NULL,
	[SAQTY] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
	[EXRATE] [nvarchar](384) NULL,
	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_GBP] [nvarchar](500) NULL,
	[COUNTRYOFORIGIN] [nvarchar](255) NULL,
	[PORTOFLADING] [nvarchar](255) NULL,
	[PORTOFLADING_NAME] [nvarchar](255) NULL,
	[PORT_LEADTIME] [nvarchar](384) NULL,
	[PORT_COUNTRY] [nvarchar](255) NULL,
	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
	[LTPO_ETDREDUCED] [nvarchar](500)) NULL,
	[MODEOFTRANSPORT] [nvarchar](18) NULL,
	[LOADINGMODE] [nvarchar](35) NULL,
	[SHIPPINGTERMS] [nvarchar](6) NULL,
	[SHIPPINGCOMPANY] [nvarchar](17) NULL,
	[DELIVERWAREHOUSE] [nvarchar](17) NULL,
	[IMPORTCOUNTRY] [nvarchar](3) NULL,
	[PO_DATE] [nvarchar](55) NULL,
	[PO_RELEASEDATE] [nvarchar](55) NULL,
	[POVSRELDATE] [nvarchar](500) NULL,
	[CUSTREQ_SIW] [nvarchar](55) NULL,
	[OLSD] [nvarchar](55) NULL,
	[CURRENT_ESD] [nvarchar](55) NULL,
	[CLSD] [nvarchar](55) NULL,
	[CSIW] [nvarchar](55) NULL,
	[OSIW] [nvarchar](55) NULL,
	[ACRD] [nvarchar](55) NULL,
	[AETD] [nvarchar](55) NULL,
	[CLSD_OLSD] [nvarchar](55) NULL,
	[ACRDVSCLSD] [nvarchar](500) NULL,
	[AETDVSCLSD] [nvarchar](500) NULL,
	[AETDVSOLSD] [nvarchar](500) NULL,
	[PO_CLSD] [nvarchar](500) NULL,
	[PO_AETD] [nvarchar](500) NULL,
	[PO_ACRD] [nvarchar](500) NULL,
	[POREL_CLSD] [nvarchar](500) NULL,
	[POREL_AETD] [nvarchar](500) NULL,
	[POREL_ACRD] [nvarchar](500) NULL,
	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
	[CLSDVSOLSD] [nvarchar](500) NULL,
	[SHIPWINDOWRESULT] [nvarchar](4) NULL,
	[SHIPWINDOWRESULT_FY16] [nvarchar](4) NULL,
	[DELAYCODE] [nvarchar](35) NULL,
	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
	[BQORDERLTPORTCODE] [nvarchar](384) NULL,
	[LTDIFF] [nvarchar](500) NULL,
	[PODATERESULT] [nvarchar](55) NULL,
	[TEAM_CODE] [nvarchar](35) NULL,
	[TEAM_SUBCODE] [nvarchar](2) NULL,
	[TEAM_CODE_FY16] [nvarchar](200) NULL,
	[TEAM_SUBCODE_FY16] [nvarchar](2) NULL,
	[XREF] [nvarchar](35) NULL,
	[BUSINESSUNIT] [nvarchar](35) NULL,
	[BUFILTER] [nvarchar](5) NULL,
	[BUFILTER_TSS] [nvarchar](12) NULL,
	[SARELEASEDATE] [nvarchar](55) NULL,
	[SANO] [nvarchar](35) NULL,
	[FACTORY] [nvarchar](17) NULL,
	[CONFIRMEDDATE] [nvarchar](55) NULL,
	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
	[BCMK_REFNO] [nvarchar](35) NULL,
	[SHIPMENT PHASE] [nvarchar](500) NULL,
	[OFFERSTATUS] [nvarchar](35) NULL,
	[PRICEDEVIATION] [nvarchar](500) NULL,
	[SETRELATIONSHIP] [nvarchar](35) NULL,
	[LINENO] [nvarchar](35) NULL,
	[SEASONYEAR] [nvarchar](500) NULL,
	[COMMENTS] [nvarchar](250) NULL,
	[LASTMODIFIEDDT] [nvarchar](55) NULL,
	[LASTMODIFIEDBY] [nvarchar](18) NULL,
	[ISSARELEASED] [nvarchar](35) NULL,
	[PARTYNAME] [nvarchar](80) NULL,
	[POSERIES] [nvarchar](6) NULL,
	[LENGTH] [nvarchar](384) NULL,
	[WIDTH] [nvarchar](384) NULL,
	[HEIGHT] [nvarchar](384) NULL,
	[TTL_KGS] [nvarchar](384) NULL,
	[TTL_CBM] [nvarchar](384) NULL,
	[SUPPLIERRESULT] [nvarchar](4) NULL,
	[OVERALLRESULT] [nvarchar](4) NULL,
	[ASMRESULT] [nvarchar](4) NULL,
	[CHECK1] [nvarchar](5) NULL,
	[CHECK2] [nvarchar](5) NULL,
	[CHECK3] [nvarchar](5) NULL,
	[CHECK4] [nvarchar](5) NULL,
	[CHECK5] [nvarchar](5) NULL,
	[CHECK6] [nvarchar](5) NULL,
	[PENALTYSEC] [nvarchar](200) NULL,
	[PENALTY_RATE] [nvarchar](384) NULL,
	[POQTYAMT_OC_PENALTY] [nvarchar](384) NULL,
	[POQTYAMT_USD_PENALTY] [nvarchar](384) NULL,
	[DATASOURCE] [varchar](3) NOT NULL,
	[DATASOURCE_IDX] [varchar](42) NOT NULL,
	[LASTUPDATED] [nvarchar](55) NOT NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
) 
GO

--Syntax Error: Incorrect syntax near NULL.
--CREATE TABLE [psa].[WBAHK_FactMIDATA_GSOOPEN_HKSQLDB](
--[row_id] [bigint] IDENTITY(1,1) NOT NULL,
--	[DATEKEY] [varchar](8) NULL,
--	[OWNER] [nvarchar](255) NOT NULL,
--	[BIZ_CODE] [nvarchar](200) NULL,
--	[BUSINESS] [nvarchar](255) NULL,
--	[DEPARTMENT] [nvarchar](600) NULL,
--	[SUBDEPARTMENT] [nvarchar](255) NULL,
--	[DEPARTMENT_FY16] [nvarchar](255) NULL,
--	[SUBDEPARTMENT_FY16] [nvarchar](255) NULL,
--	[WBATIER1CODE] [nvarchar](255) NULL,
--	[WBATIER2CODE] [nvarchar](255) NULL,
--	[WBA_CATEGORYTIER1] [nvarchar](255) NULL,
--	[WBA_CATEGORYTIER2] [nvarchar](255) NULL,
--	[PRODUCTGROUP] [nvarchar](255) NULL,
--	[BRAND] [nvarchar](255) NULL,
--	[BRAND_NAME] [nvarchar](255) NULL,
--	[BRAND_TYPECODE] [nvarchar](255) NULL,
--	[BRAND_TYPENAME] [nvarchar](255) NULL,
--	[SEASON] [nvarchar](255) NULL,
--	[PO_ORDERTYPE] [nvarchar](255) NULL,
--	[IS_CMI] [nvarchar](255) NULL,
--	[CUSTOMERCOMPANY] [nvarchar](255) NULL,
--	[SUPPLIER] [nvarchar](255) NULL,
--	[SUPPLIERNAME] [nvarchar](255) NULL,
--	[PO_STATUS] [nvarchar](255) NULL,
--	[CUSTOMERONO] [nvarchar](255) NOT NULL,
--	[QUOTENO] [nvarchar](255) NULL,
--	[PROJECT] [nvarchar](255) NULL,
--	[RANGE] [nvarchar](255) NULL,
--	[OFFERNO] [nvarchar](255) NULL,
--	[SAP_PONO] [nvarchar](255) NULL,
--	[WBA_PONO] [nvarchar](255) NULL,
--	[PROFORMAPONO] [nvarchar](255) NOT NULL,
--	[PO_LINENO] [nvarchar](500) NOT NULL,
--	[ITEMCODE] [nvarchar](255) NOT NULL,
--	[DESCRIPTION] [nvarchar](255) NULL,
--	[QTYPEROUTER] [nvarchar](500) NULL,
--	[QTYPERINNER] [nvarchar](500) NULL,
--	[ORIGINALCUR] [nvarchar](255) NULL,
--	[UNITPRICE] [nvarchar](500) NULL,
--	[PO_QTY] [nvarchar](500) NULL,
--	[POQTYAMT_OC] [nvarchar](500) NULL,
--	[ACTUALSHIPPEDQTY] [nvarchar](384) NULL,
--	[SAQTY] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
--	[EXRATE] [nvarchar](384) NULL,
--	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_GBP] [nvarchar](500) NULL,
--	[COUNTRYOFORIGIN] [nvarchar](255) NULL,
--	[PORTOFLADING] [nvarchar](255) NULL,
--	[PORTOFLADING_NAME] [nvarchar](255) NULL,
--	[PORT_LEADTIME] [nvarchar](384) NULL,
--	[PORT_COUNTRY] [nvarchar](255) NULL,
--	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
--	[LTPO_ETDREDUCED] [nvarchar](500)) NULL,
--	[MODEOFTRANSPORT] [nvarchar](18) NULL,
--	[LOADINGMODE] [nvarchar](35) NULL,
--	[SHIPPINGTERMS] [nvarchar](6) NULL,
--	[SHIPPINGCOMPANY] [nvarchar](17) NULL,
--	[DELIVERWAREHOUSE] [nvarchar](17) NULL,
--	[IMPORTCOUNTRY] [nvarchar](3) NULL,
--	[PO_DATE] [nvarchar](55) NULL,
--	[PO_RELEASEDATE] [nvarchar](55) NULL,
--	[POVSRELDATE] [nvarchar](500) NULL,
--	[CUSTREQ_SIW] [nvarchar](55) NULL,
--	[OLSD] [nvarchar](55) NULL,
--	[CURRENT_ESD] [nvarchar](55) NULL,
--	[CLSD] [nvarchar](55) NULL,
--	[CSIW] [nvarchar](55) NULL,
--	[OSIW] [nvarchar](55) NULL,
--	[ACRD] [nvarchar](55) NULL,
--	[AETD] [nvarchar](55) NULL,
--	[CLSD_OLSD] [nvarchar](55) NULL,
--	[ACRDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSOLSD] [nvarchar](500) NULL,
--	[PO_CLSD] [nvarchar](500) NULL,
--	[PO_AETD] [nvarchar](500) NULL,
--	[PO_ACRD] [nvarchar](500) NULL,
--	[POREL_CLSD] [nvarchar](500) NULL,
--	[POREL_AETD] [nvarchar](500) NULL,
--	[POREL_ACRD] [nvarchar](500) NULL,
--	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
--	[CLSDVSOLSD] [nvarchar](500) NULL,
--	[SHIPWINDOWRESULT] [nvarchar](4) NULL,
--	[SHIPWINDOWRESULT_FY16] [nvarchar](4) NULL,
--	[DELAYCODE] [nvarchar](35) NULL,
--	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
--	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
--	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
--	[BQORDERLTPORTCODE] [nvarchar](384) NULL,
--	[LTDIFF] [nvarchar](500) NULL,
--	[PODATERESULT] [nvarchar](55) NULL,
--	[TEAM_CODE] [nvarchar](35) NULL,
--	[TEAM_SUBCODE] [nvarchar](2) NULL,
--	[TEAM_CODE_FY16] [nvarchar](200) NULL,
--	[TEAM_SUBCODE_FY16] [nvarchar](2) NULL,
--	[XREF] [nvarchar](35) NULL,
--	[BUSINESSUNIT] [nvarchar](35) NULL,
--	[BUFILTER] [nvarchar](5) NULL,
--	[BUFILTER_TSS] [nvarchar](12) NULL,
--	[SARELEASEDATE] [nvarchar](55) NULL,
--	[SANO] [nvarchar](35) NULL,
--	[FACTORY] [nvarchar](17) NULL,
--	[CONFIRMEDDATE] [nvarchar](55) NULL,
--	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
--	[BCMK_REFNO] [nvarchar](35) NULL,
--	[SHIPMENT PHASE] [nvarchar](500) NULL,
--	[OFFERSTATUS] [nvarchar](35) NULL,
--	[PRICEDEVIATION] [nvarchar](500) NULL,
--	[SETRELATIONSHIP] [nvarchar](35) NULL,
--	[LINENO] [nvarchar](35) NULL,
--	[SEASONYEAR] [nvarchar](500) NULL,
--	[COMMENTS] [nvarchar](250) NULL,
--	[LASTMODIFIEDDT] [nvarchar](55) NULL,
--	[LASTMODIFIEDBY] [nvarchar](18) NULL,
--	[ISSARELEASED] [nvarchar](35) NULL,
--	[PARTYNAME] [nvarchar](80) NULL,
--	[POSERIES] [nvarchar](6) NULL,
--	[LENGTH] [nvarchar](384) NULL,
--	[WIDTH] [nvarchar](384) NULL,
--	[HEIGHT] [nvarchar](384) NULL,
--	[TTL_KGS] [nvarchar](384) NULL,
--	[TTL_CBM] [nvarchar](384) NULL,
--	[SUPPLIERRESULT] [nvarchar](4) NULL,
--	[OVERALLRESULT] [nvarchar](4) NULL,
--	[ASMRESULT] [nvarchar](4) NULL,
--	[CHECK1] [nvarchar](5) NULL,
--	[CHECK2] [nvarchar](5) NULL,
--	[CHECK3] [nvarchar](5) NULL,
--	[CHECK4] [nvarchar](5) NULL,
--	[CHECK5] [nvarchar](5) NULL,
--	[CHECK6] [nvarchar](5) NULL,
--	[PENALTYSEC] [nvarchar](200) NULL,
--	[PENALTY_RATE] [nvarchar](384) NULL,
--	[POQTYAMT_OC_PENALTY] [nvarchar](384) NULL,
--	[POQTYAMT_USD_PENALTY] [nvarchar](384) NULL,
--	[DATASOURCE] [varchar](3) NOT NULL,
--	[DATASOURCE_IDX] [varchar](42) NOT NULL,
--	[LASTUPDATED] [nvarchar](55) NOT NULL,
--	[etl_runlog_id] [nvarchar](20) NULL,
--	[asset_id] [nvarchar](20) NULL,
--	[record_source_id] [nvarchar](20) NULL,
--	[row_status] [int] NULL,
--	[created_timestamp] [datetime] NULL,
--	[active_flag] [char](1) NULL
--) 



GO

CREATE TABLE [psa].[WBAHK_FactMIDATA_HKSQLDB](
[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[DateKey] [varchar](50) NULL,
	[OWNER] [varchar](100) NULL,
	[BIZ_CODE] [varchar](50) NULL,
	[BUSINESS] [varchar](100) NULL,
	[DEPARTMENT] [varchar](200) NULL,
	[SUBDEPARTMENT] [varchar](200) NULL,
	[DEPARTMENT_FY16] [varchar](100) NULL,
	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
	[WBATIER1CODE] [varchar](100) NULL,
	[WBATIER2CODE] [varchar](100) NULL,
	[WBA_CATEGORYTIER1] [varchar](100) NULL,
	[WBA_CATEGORYTIER2] [varchar](100) NULL,
	[PRODUCTGROUP] [varchar](100) NULL,
	[BRAND] [varchar](255) NULL,
	[BRAND_NAME] [varchar](255) NULL,
	[BRAND_TYPECODE] [varchar](100) NULL,
	[BRAND_TYPENAME] [varchar](255) NULL,
	[SEASON] [varchar](100) NULL,
	[PO_ORDERTYPE] [nvarchar](100) NULL,
	[IS_CMI] [nvarchar](100) NULL,
	[CUST_CODE] [nvarchar](100) NULL,
	[VENDORCODE] [nvarchar](100) NULL,
	[SUPPLIERNAME] [varchar](200) NULL,
	[PO_STATUS] [varchar](100) NULL,
	[CUSTOMERONO] [varchar](100) NULL,
	[QUOTENO] [varchar](100) NULL,
	[PROJECTGROUP] [varchar](100) NULL,
	[PROJECTNAME] [varchar](100) NULL,
	[OFFERNO] [varchar](100) NULL,
	[SAP_PONO] [varchar](100) NULL,
	[WBA_PONO] [varchar](100) NULL,
	[PROFORMAPONO] [varchar](100) NULL,
	[PO_LINENO] [nvarchar](50) NULL,
	[ITEMCODE] [varchar](100) NULL,
	[DESCRIPTION] [nvarchar](160) NULL,
	[QTYPEROUTER] [varchar](100) NULL,
	[QTYPERINNER] [varchar](100) NULL,
	[ORIGINALCUR] [nvarchar](6) NULL,
	[UNITPRICE] [nvarchar](500) NULL,
	[PO_QTY] [nvarchar](500) NULL,
	[POQTYAMT_OC] [nvarchar](500) NULL,
	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
	[SAQTY] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
	[EXRATE] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_GBP] [nvarchar](500) NULL,
	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
	[PORTOFLADING] [varchar](100) NULL,
	[PORTOFLADING_NAME] [varchar](100) NULL,
	[PORT_LEADTIME] [nvarchar](500) NULL,
	[PORT_COUNTRY] [varchar](100) NULL,
	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
	[MODEOFTRANSPORT] [varchar](100) NULL,
	[LOADINGMODE] [varchar](100) NULL,
	[SHIPPINGTERMS] [varchar](100) NULL,
	[SHIPPINGCOMPANY] [varchar](100) NULL,
	[DELIVERWAREHOUSE] [varchar](100) NULL,
	[IMPORTCOUNTRY] [varchar](100) NULL,
	[PO_DATE] [nvarchar](55) NULL,
	[PO_RELEASEDATE] [nvarchar](55) NULL,
	[POVSRELDATE] [nvarchar](500) NULL,
	[CUSTREQ_SIW] [nvarchar](55) NULL,
	[OLSD] [nvarchar](55) NULL,
	[CURRENT_ESD] [nvarchar](55) NULL,
	[CLSD] [nvarchar](55) NULL,
	[CSIW] [nvarchar](55) NULL,
	[OSIW] [nvarchar](55)] NULL,
	[ACRD] [nvarchar](55) NULL,
	[AETD] [nvarchar](55) NULL,
	[CLSD_OLSD] [nvarchar](55) NULL,
	[ACRDVSCLSD] [nvarchar](500) NULL,
	[AETDVSCLSD] [nvarchar](500) NULL,
	[AETDVSOLSD] [nvarchar](500) NULL,
	[PO_CLSD] [nvarchar](500) NULL,
	[PO_AETD] [nvarchar](500) NULL,
	[PO_ACRD] [nvarchar](500) NULL,
	[POREL_CLSD] [nvarchar](500) NULL,
	[POREL_AETD] [nvarchar](500) NULL,
	[POREL_ACRD] [nvarchar](500) NULL,
	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
	[CLSDVSOLSD] [nvarchar](500) NULL,
	[SHIPWINDOWRESULT] [varchar](100) NULL,
	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
	[DELAYCODE] [varchar](100) NULL,
	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
	[LTDIFF] [nvarchar](500) NULL,
	[PODATERESULT] [nvarchar](55) NULL,
	[TEAM_CODE] [varchar](50) NULL,
	[TEAM_SUB_CODE] [varchar](50) NULL,
	[TEAM_CODE_FY16] [varchar](50) NULL,
	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
	[XREF] [varchar](50) NULL,
	[BUSINESSUNIT] [varchar](50) NULL,
	[BUFILTER] [varchar](50) NULL,
	[BUFILTER_TSS] [varchar](50) NULL,
	[SARELEASEDATE] [nvarchar](55) NULL,
	[SANO] [varchar](50) NULL,
	[FACTORY] [varchar](50) NULL,
	[CONFIRMEDDATE] [varchar](50) NULL,
	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
	[BCMK_REFNO] [varchar](50) NULL,
	[SHIPMENT_PHASE] [varchar](50) NULL,
	[OFFERSTATUS] [varchar](50) NULL,
	[PRICEDEVIATION] [nvarchar](500) NULL,
	[SETRELATIONSHIP] [varchar](50) NULL,
	[LINENO] [varchar](50) NULL,
	[SEASONYEAR] [varchar](50) NULL,
	[COMMENTS] [varchar](255) NULL,
	[LASTMODIFIEDDT] [nvarchar](55) NULL,
	[LASTMODIFIEDBY] [varchar](50) NULL,
	[ISSARELEASED] [varchar](50) NULL,
	[PARTYNAME] [varchar](255) NULL,
	[POSERIES] [varchar](50) NULL,
	[LENGTH] [nvarchar](500) NULL,
	[WIDTH] [nvarchar](500) NULL,
	[HEIGHT] [nvarchar](500) NULL,
	[TTL_KGS] [nvarchar](500) NULL,
	[TTL_CBM] [nvarchar](500) NULL,
	[SUPPLIERRESULT] [varchar](50) NULL,
	[OVERALLRESULT] [varchar](50) NULL,
	[ASMRESULT] [varchar](50) NULL,
	[CHECK1] [nvarchar](10) NULL,
	[CHECK2] [nvarchar](10) NULL,
	[CHECK3] [nvarchar](10) NULL,
	[CHECK4] [nvarchar](10) NULL,
	[CHECK5] [nvarchar](10) NULL,
	[CHECK6] [nvarchar](10) NULL,
	[PENALTYSEC] [nvarchar](40) NULL,
	[PENALTY_RATE] [nvarchar](500) NULL,
	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
	[DATASOURCE] [varchar](50) NULL,
	[DATASOURCE_IDX] [varchar](255) NULL,
	[LASTUPDATED] [nvarchar](55) NULL,
	[UNIQUE_KEY] [nvarchar](500) IDENTITY(1,1) NOT NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
) 
GO

--Syntax Error: Incorrect syntax near ].
--CREATE TABLE [psa].[WBAHK_FactMIDATA_HKSQLDB](
--[row_id] [bigint] IDENTITY(1,1) NOT NULL,
--	[DateKey] [varchar](50) NULL,
--	[OWNER] [varchar](100) NULL,
--	[BIZ_CODE] [varchar](50) NULL,
--	[BUSINESS] [varchar](100) NULL,
--	[DEPARTMENT] [varchar](200) NULL,
--	[SUBDEPARTMENT] [varchar](200) NULL,
--	[DEPARTMENT_FY16] [varchar](100) NULL,
--	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
--	[WBATIER1CODE] [varchar](100) NULL,
--	[WBATIER2CODE] [varchar](100) NULL,
--	[WBA_CATEGORYTIER1] [varchar](100) NULL,
--	[WBA_CATEGORYTIER2] [varchar](100) NULL,
--	[PRODUCTGROUP] [varchar](100) NULL,
--	[BRAND] [varchar](255) NULL,
--	[BRAND_NAME] [varchar](255) NULL,
--	[BRAND_TYPECODE] [varchar](100) NULL,
--	[BRAND_TYPENAME] [varchar](255) NULL,
--	[SEASON] [varchar](100) NULL,
--	[PO_ORDERTYPE] [nvarchar](100) NULL,
--	[IS_CMI] [nvarchar](100) NULL,
--	[CUST_CODE] [nvarchar](100) NULL,
--	[VENDORCODE] [nvarchar](100) NULL,
--	[SUPPLIERNAME] [varchar](200) NULL,
--	[PO_STATUS] [varchar](100) NULL,
--	[CUSTOMERONO] [varchar](100) NULL,
--	[QUOTENO] [varchar](100) NULL,
--	[PROJECTGROUP] [varchar](100) NULL,
--	[PROJECTNAME] [varchar](100) NULL,
--	[OFFERNO] [varchar](100) NULL,
--	[SAP_PONO] [varchar](100) NULL,
--	[WBA_PONO] [varchar](100) NULL,
--	[PROFORMAPONO] [varchar](100) NULL,
--	[PO_LINENO] [nvarchar](50) NULL,
--	[ITEMCODE] [varchar](100) NULL,
--	[DESCRIPTION] [nvarchar](160) NULL,
--	[QTYPEROUTER] [varchar](100) NULL,
--	[QTYPERINNER] [varchar](100) NULL,
--	[ORIGINALCUR] [nvarchar](6) NULL,
--	[UNITPRICE] [nvarchar](500) NULL,
--	[PO_QTY] [nvarchar](500) NULL,
--	[POQTYAMT_OC] [nvarchar](500) NULL,
--	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
--	[SAQTY] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
--	[EXRATE] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_GBP] [nvarchar](500) NULL,
--	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
--	[PORTOFLADING] [varchar](100) NULL,
--	[PORTOFLADING_NAME] [varchar](100) NULL,
--	[PORT_LEADTIME] [nvarchar](500) NULL,
--	[PORT_COUNTRY] [varchar](100) NULL,
--	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
--	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
--	[MODEOFTRANSPORT] [varchar](100) NULL,
--	[LOADINGMODE] [varchar](100) NULL,
--	[SHIPPINGTERMS] [varchar](100) NULL,
--	[SHIPPINGCOMPANY] [varchar](100) NULL,
--	[DELIVERWAREHOUSE] [varchar](100) NULL,
--	[IMPORTCOUNTRY] [varchar](100) NULL,
--	[PO_DATE] [nvarchar](55) NULL,
--	[PO_RELEASEDATE] [nvarchar](55) NULL,
--	[POVSRELDATE] [nvarchar](500) NULL,
--	[CUSTREQ_SIW] [nvarchar](55) NULL,
--	[OLSD] [nvarchar](55) NULL,
--	[CURRENT_ESD] [nvarchar](55) NULL,
--	[CLSD] [nvarchar](55) NULL,
--	[CSIW] [nvarchar](55) NULL,
--	[OSIW] [nvarchar](55)] NULL,
--	[ACRD] [nvarchar](55) NULL,
--	[AETD] [nvarchar](55) NULL,
--	[CLSD_OLSD] [nvarchar](55) NULL,
--	[ACRDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSOLSD] [nvarchar](500) NULL,
--	[PO_CLSD] [nvarchar](500) NULL,
--	[PO_AETD] [nvarchar](500) NULL,
--	[PO_ACRD] [nvarchar](500) NULL,
--	[POREL_CLSD] [nvarchar](500) NULL,
--	[POREL_AETD] [nvarchar](500) NULL,
--	[POREL_ACRD] [nvarchar](500) NULL,
--	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
--	[CLSDVSOLSD] [nvarchar](500) NULL,
--	[SHIPWINDOWRESULT] [varchar](100) NULL,
--	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
--	[DELAYCODE] [varchar](100) NULL,
--	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
--	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
--	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
--	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
--	[LTDIFF] [nvarchar](500) NULL,
--	[PODATERESULT] [nvarchar](55) NULL,
--	[TEAM_CODE] [varchar](50) NULL,
--	[TEAM_SUB_CODE] [varchar](50) NULL,
--	[TEAM_CODE_FY16] [varchar](50) NULL,
--	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
--	[XREF] [varchar](50) NULL,
--	[BUSINESSUNIT] [varchar](50) NULL,
--	[BUFILTER] [varchar](50) NULL,
--	[BUFILTER_TSS] [varchar](50) NULL,
--	[SARELEASEDATE] [nvarchar](55) NULL,
--	[SANO] [varchar](50) NULL,
--	[FACTORY] [varchar](50) NULL,
--	[CONFIRMEDDATE] [varchar](50) NULL,
--	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
--	[BCMK_REFNO] [varchar](50) NULL,
--	[SHIPMENT_PHASE] [varchar](50) NULL,
--	[OFFERSTATUS] [varchar](50) NULL,
--	[PRICEDEVIATION] [nvarchar](500) NULL,
--	[SETRELATIONSHIP] [varchar](50) NULL,
--	[LINENO] [varchar](50) NULL,
--	[SEASONYEAR] [varchar](50) NULL,
--	[COMMENTS] [varchar](255) NULL,
--	[LASTMODIFIEDDT] [nvarchar](55) NULL,
--	[LASTMODIFIEDBY] [varchar](50) NULL,
--	[ISSARELEASED] [varchar](50) NULL,
--	[PARTYNAME] [varchar](255) NULL,
--	[POSERIES] [varchar](50) NULL,
--	[LENGTH] [nvarchar](500) NULL,
--	[WIDTH] [nvarchar](500) NULL,
--	[HEIGHT] [nvarchar](500) NULL,
--	[TTL_KGS] [nvarchar](500) NULL,
--	[TTL_CBM] [nvarchar](500) NULL,
--	[SUPPLIERRESULT] [varchar](50) NULL,
--	[OVERALLRESULT] [varchar](50) NULL,
--	[ASMRESULT] [varchar](50) NULL,
--	[CHECK1] [nvarchar](10) NULL,
--	[CHECK2] [nvarchar](10) NULL,
--	[CHECK3] [nvarchar](10) NULL,
--	[CHECK4] [nvarchar](10) NULL,
--	[CHECK5] [nvarchar](10) NULL,
--	[CHECK6] [nvarchar](10) NULL,
--	[PENALTYSEC] [nvarchar](40) NULL,
--	[PENALTY_RATE] [nvarchar](500) NULL,
--	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
--	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
--	[DATASOURCE] [varchar](50) NULL,
--	[DATASOURCE_IDX] [varchar](255) NULL,
--	[LASTUPDATED] [nvarchar](55) NULL,
--	[UNIQUE_KEY] [nvarchar](500) IDENTITY(1,1) NOT NULL,
--	[etl_runlog_id] [nvarchar](20) NULL,
--	[asset_id] [nvarchar](20) NULL,
--	[record_source_id] [nvarchar](20) NULL,
--	[row_status] [int] NULL,
--	[created_timestamp] [datetime] NULL,
--	[active_flag] [char](1) NULL
--) 



GO

CREATE TABLE [psa].[WBAHK_FactMIDATA_LIMA_OPEN_HKSQLDB](
[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[DateKey] [varchar](50) NULL,
	[OWNER] [varchar](100) NULL,
	[BIZ_CODE] [varchar](50) NULL,
	[BUSINESS] [varchar](100) NULL,
	[DEPARTMENT] [varchar](100) NULL,
	[SUBDEPARTMENT] [varchar](100) NULL,
	[DEPARTMENT_FY16] [varchar](100) NULL,
	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
	[WBATIER1CODE] [varchar](100) NULL,
	[WBATIER2CODE] [varchar](100) NULL,
	[WBA_CATEGORYTIER1] [varchar](100) NULL,
	[WBA_CATEGORYTIER2] [varchar](100) NULL,
	[PRODUCTGROUP] [varchar](100) NULL,
	[SEASON] [varchar](100) NULL,
	[PO_ORDERTYPE] [nvarchar](100) NULL,
	[CUST_CODE] [nvarchar](100) NULL,
	[VENDORCODE] [nvarchar](100) NULL,
	[SUPPLIERNAME] [varchar](200) NULL,
	[PO_STATUS] [varchar](100) NULL,
	[CUSTOMERONO] [varchar](100) NOT NULL,
	[QUOTENO] [varchar](100) NULL,
	[PROJECTGROUP] [varchar](100) NULL,
	[PROJECTNAME] [varchar](100) NOT NULL,
	[OFFERNO] [varchar](100) NULL,
	[SAP_PONO] [varchar](100) NULL,
	[WBA_PONO] [varchar](100) NULL,
	[PROFORMAPONO] [varchar](100) NULL,
	[PO_LINENO] [nvarchar](50) NULL,
	[ITEMCODE] [varchar](100) NULL,
	[DESCRIPTION] [nvarchar](160) NULL,
	[ORIGINALCUR] [nvarchar](6) NULL,
	[UNITPRICE] [nvarchar](500) NULL,
	[PO_QTY] [nvarchar](500) NULL,
	[POQTYAMT_OC] [nvarchar](500) NULL,
	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
	[SAQTY] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
	[EXRATE] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_USD] [nvarchar](500) NULL,
	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
	[PORTOFLADING] [varchar](100) NULL,
	[PORTOFLADING_NAME] [varchar](100) NULL,
	[PORT_LEADTIME] [nvarchar](500) NULL,
	[PORT_COUNTRY] [varchar](100) NULL,
	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
	[MODEOFTRANSPORT] [varchar](100) NULL,
	[LOADINGMODE] [varchar](100) NULL,
	[SHIPPINGTERMS] [varchar](100) NULL,
	[SHIPPINGCOMPANY] [varchar](100) NULL,
	[DELIVERWAREHOUSE] [varchar](100) NULL,
	[IMPORTCOUNTRY] [varchar](100) NULL,
	[PO_DATE] [nvarchar](55) NULL,
	[PO_RELEASEDATE] [nvarchar](55) NULL,
	[POVSRELDATE] [nvarchar](500) NULL,
	[CUSTREQ_SIW] [nvarchar](55) NULL,
	[OLSD] [nvarchar](55) NULL,
	[CURRENT_ESD] [nvarchar](55) NULL,
	[CLSD] [nvarchar](55) NULL,
	[CSIW] [nvarchar](55) NULL,
	[ACRD] [nvarchar](55) NULL,
	[AETD] [nvarchar](55) NULL,
	[ACRDVSCLSD] [nvarchar](500) NULL,
	[AETDVSCLSD] [nvarchar](500) NULL,
	[AETDVSOLSD] [nvarchar](500) NULL,
	[PO_CLSD] [nvarchar](500) NULL,
	[PO_AETD] [nvarchar](500) NULL,
	[PO_ACRD] [nvarchar](500) NULL,
	[POREL_CLSD] [nvarchar](500) NULL,
	[POREL_AETD] [nvarchar](500) NULL,
	[POREL_ACRD] [nvarchar](500) NULL,
	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
	[CLSDVSOLSD] [nvarchar](500) NULL,
	[SHIPWINDOWRESULT] [varchar](100) NULL,
	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
	[DELAYCODE] [varchar](100) NULL,
	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
	[LTDIFF] [nvarchar](500) NULL,
	[PODATERESULT] [nvarchar](55) NULL,
	[POSERIES] [varchar](100) NULL,
	[LENGTH] [nvarchar](500) NULL,
	[WIDTH] [nvarchar](500) NULL,
	[HEIGHT] [nvarchar](500)) NULL,
	[TTL_KGS] [nvarchar](500) NULL,
	[TTL_CBM] [nvarchar](500) NULL,
	[SUPPLIERRESULT] [varchar](50) NULL,
	[OVERALLRESULT] [varchar](50) NULL,
	[ASMRESULT] [varchar](50) NULL,
	[CHECK1] [nvarchar](10) NULL,
	[CHECK2] [nvarchar](10) NULL,
	[CHECK3] [nvarchar](10) NULL,
	[CHECK4] [nvarchar](10) NULL,
	[CHECK5] [nvarchar](10) NULL,
	[CHECK6] [nvarchar](10) NULL,
	[PENALTYSEC] [nvarchar](40) NULL,
	[PENALTY_RATE] [nvarchar](500) NULL,
	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
	[DATASOURCE] [varchar](50) NULL,
	[DATASOURCE_IDX] [varchar](255) NULL,
	[TEAM_CODE] [varchar](50) NULL,
	[TEAM_SUB_CODE] [varchar](50) NULL,
	[TEAM_CODE_FY16] [varchar](50) NULL,
	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
	[TEAM_CODE_FY17] [varchar](50) NULL,
	[UsageFlag] [varchar](50) NULL,
	[IsQVReported] [varchar](50) NULL,
	[IsSpendReclasstoNextReportPeriod] [varchar](50) NULL,
	[LASTUPDATED] [nvarchar](55)NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
) 
GO

--Syntax Error: Incorrect syntax near NULL.
--CREATE TABLE [psa].[WBAHK_FactMIDATA_LIMA_OPEN_HKSQLDB](
--[row_id] [bigint] IDENTITY(1,1) NOT NULL,
--	[DateKey] [varchar](50) NULL,
--	[OWNER] [varchar](100) NULL,
--	[BIZ_CODE] [varchar](50) NULL,
--	[BUSINESS] [varchar](100) NULL,
--	[DEPARTMENT] [varchar](100) NULL,
--	[SUBDEPARTMENT] [varchar](100) NULL,
--	[DEPARTMENT_FY16] [varchar](100) NULL,
--	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
--	[WBATIER1CODE] [varchar](100) NULL,
--	[WBATIER2CODE] [varchar](100) NULL,
--	[WBA_CATEGORYTIER1] [varchar](100) NULL,
--	[WBA_CATEGORYTIER2] [varchar](100) NULL,
--	[PRODUCTGROUP] [varchar](100) NULL,
--	[SEASON] [varchar](100) NULL,
--	[PO_ORDERTYPE] [nvarchar](100) NULL,
--	[CUST_CODE] [nvarchar](100) NULL,
--	[VENDORCODE] [nvarchar](100) NULL,
--	[SUPPLIERNAME] [varchar](200) NULL,
--	[PO_STATUS] [varchar](100) NULL,
--	[CUSTOMERONO] [varchar](100) NOT NULL,
--	[QUOTENO] [varchar](100) NULL,
--	[PROJECTGROUP] [varchar](100) NULL,
--	[PROJECTNAME] [varchar](100) NOT NULL,
--	[OFFERNO] [varchar](100) NULL,
--	[SAP_PONO] [varchar](100) NULL,
--	[WBA_PONO] [varchar](100) NULL,
--	[PROFORMAPONO] [varchar](100) NULL,
--	[PO_LINENO] [nvarchar](50) NULL,
--	[ITEMCODE] [varchar](100) NULL,
--	[DESCRIPTION] [nvarchar](160) NULL,
--	[ORIGINALCUR] [nvarchar](6) NULL,
--	[UNITPRICE] [nvarchar](500) NULL,
--	[PO_QTY] [nvarchar](500) NULL,
--	[POQTYAMT_OC] [nvarchar](500) NULL,
--	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
--	[SAQTY] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
--	[EXRATE] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_USD] [nvarchar](500) NULL,
--	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
--	[PORTOFLADING] [varchar](100) NULL,
--	[PORTOFLADING_NAME] [varchar](100) NULL,
--	[PORT_LEADTIME] [nvarchar](500) NULL,
--	[PORT_COUNTRY] [varchar](100) NULL,
--	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
--	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
--	[MODEOFTRANSPORT] [varchar](100) NULL,
--	[LOADINGMODE] [varchar](100) NULL,
--	[SHIPPINGTERMS] [varchar](100) NULL,
--	[SHIPPINGCOMPANY] [varchar](100) NULL,
--	[DELIVERWAREHOUSE] [varchar](100) NULL,
--	[IMPORTCOUNTRY] [varchar](100) NULL,
--	[PO_DATE] [nvarchar](55) NULL,
--	[PO_RELEASEDATE] [nvarchar](55) NULL,
--	[POVSRELDATE] [nvarchar](500) NULL,
--	[CUSTREQ_SIW] [nvarchar](55) NULL,
--	[OLSD] [nvarchar](55) NULL,
--	[CURRENT_ESD] [nvarchar](55) NULL,
--	[CLSD] [nvarchar](55) NULL,
--	[CSIW] [nvarchar](55) NULL,
--	[ACRD] [nvarchar](55) NULL,
--	[AETD] [nvarchar](55) NULL,
--	[ACRDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSOLSD] [nvarchar](500) NULL,
--	[PO_CLSD] [nvarchar](500) NULL,
--	[PO_AETD] [nvarchar](500) NULL,
--	[PO_ACRD] [nvarchar](500) NULL,
--	[POREL_CLSD] [nvarchar](500) NULL,
--	[POREL_AETD] [nvarchar](500) NULL,
--	[POREL_ACRD] [nvarchar](500) NULL,
--	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
--	[CLSDVSOLSD] [nvarchar](500) NULL,
--	[SHIPWINDOWRESULT] [varchar](100) NULL,
--	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
--	[DELAYCODE] [varchar](100) NULL,
--	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
--	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
--	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
--	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
--	[LTDIFF] [nvarchar](500) NULL,
--	[PODATERESULT] [nvarchar](55) NULL,
--	[POSERIES] [varchar](100) NULL,
--	[LENGTH] [nvarchar](500) NULL,
--	[WIDTH] [nvarchar](500) NULL,
--	[HEIGHT] [nvarchar](500)) NULL,
--	[TTL_KGS] [nvarchar](500) NULL,
--	[TTL_CBM] [nvarchar](500) NULL,
--	[SUPPLIERRESULT] [varchar](50) NULL,
--	[OVERALLRESULT] [varchar](50) NULL,
--	[ASMRESULT] [varchar](50) NULL,
--	[CHECK1] [nvarchar](10) NULL,
--	[CHECK2] [nvarchar](10) NULL,
--	[CHECK3] [nvarchar](10) NULL,
--	[CHECK4] [nvarchar](10) NULL,
--	[CHECK5] [nvarchar](10) NULL,
--	[CHECK6] [nvarchar](10) NULL,
--	[PENALTYSEC] [nvarchar](40) NULL,
--	[PENALTY_RATE] [nvarchar](500) NULL,
--	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
--	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
--	[DATASOURCE] [varchar](50) NULL,
--	[DATASOURCE_IDX] [varchar](255) NULL,
--	[TEAM_CODE] [varchar](50) NULL,
--	[TEAM_SUB_CODE] [varchar](50) NULL,
--	[TEAM_CODE_FY16] [varchar](50) NULL,
--	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
--	[TEAM_CODE_FY17] [varchar](50) NULL,
--	[UsageFlag] [varchar](50) NULL,
--	[IsQVReported] [varchar](50) NULL,
--	[IsSpendReclasstoNextReportPeriod] [varchar](50) NULL,
--	[LASTUPDATED] [nvarchar](55)NULL,
--	[etl_runlog_id] [nvarchar](20) NULL,
--	[asset_id] [nvarchar](20) NULL,
--	[record_source_id] [nvarchar](20) NULL,
--	[row_status] [int] NULL,
--	[created_timestamp] [datetime] NULL,
--	[active_flag] [char](1) NULL
--) 



GO

CREATE TABLE [psa].[WBAHK_FactMIDATA_LIMA_OPEN_HKSQLDB](
[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[DateKey] [varchar](50) NULL,
	[OWNER] [varchar](100) NULL,
	[BIZ_CODE] [varchar](50) NULL,
	[BUSINESS] [varchar](100) NULL,
	[DEPARTMENT] [varchar](100) NULL,
	[SUBDEPARTMENT] [varchar](100) NULL,
	[DEPARTMENT_FY16] [varchar](100) NULL,
	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
	[WBATIER1CODE] [varchar](100) NULL,
	[WBATIER2CODE] [varchar](100) NULL,
	[WBA_CATEGORYTIER1] [varchar](100) NULL,
	[WBA_CATEGORYTIER2] [varchar](100) NULL,
	[PRODUCTGROUP] [varchar](100) NULL,
	[SEASON] [varchar](100) NULL,
	[PO_ORDERTYPE] [nvarchar](100) NULL,
	[CUST_CODE] [nvarchar](100) NULL,
	[VENDORCODE] [nvarchar](100) NULL,
	[SUPPLIERNAME] [varchar](200) NULL,
	[PO_STATUS] [varchar](100) NULL,
	[CUSTOMERONO] [varchar](100) NOT NULL,
	[QUOTENO] [varchar](100) NULL,
	[PROJECTGROUP] [varchar](100) NULL,
	[PROJECTNAME] [varchar](100) NOT NULL,
	[OFFERNO] [varchar](100) NULL,
	[SAP_PONO] [varchar](100) NULL,
	[WBA_PONO] [varchar](100) NULL,
	[PROFORMAPONO] [varchar](100) NULL,
	[PO_LINENO] [nvarchar](50) NULL,
	[ITEMCODE] [varchar](100) NULL,
	[DESCRIPTION] [nvarchar](160) NULL,
	[ORIGINALCUR] [nvarchar](6) NULL,
	[UNITPRICE] [nvarchar](500) NULL,
	[PO_QTY] [nvarchar](500) NULL,
	[POQTYAMT_OC] [nvarchar](500) NULL,
	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
	[SAQTY] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
	[EXRATE] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_USD] [nvarchar](500) NULL,
	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
	[PORTOFLADING] [varchar](100) NULL,
	[PORTOFLADING_NAME] [varchar](100) NULL,
	[PORT_LEADTIME] [nvarchar](500) NULL,
	[PORT_COUNTRY] [varchar](100) NULL,
	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
	[MODEOFTRANSPORT] [varchar](100) NULL,
	[LOADINGMODE] [varchar](100) NULL,
	[SHIPPINGTERMS] [varchar](100) NULL,
	[SHIPPINGCOMPANY] [varchar](100) NULL,
	[DELIVERWAREHOUSE] [varchar](100) NULL,
	[IMPORTCOUNTRY] [varchar](100) NULL,
	[PO_DATE] [nvarchar](55) NULL,
	[PO_RELEASEDATE] [nvarchar](55) NULL,
	[POVSRELDATE] [nvarchar](500) NULL,
	[CUSTREQ_SIW] [nvarchar](55) NULL,
	[OLSD] [nvarchar](55) NULL,
	[CURRENT_ESD] [nvarchar](55) NULL,
	[CLSD] [nvarchar](55) NULL,
	[CSIW] [nvarchar](55) NULL,
	[ACRD] [nvarchar](55) NULL,
	[AETD] [nvarchar](55) NULL,
	[ACRDVSCLSD] [nvarchar](500) NULL,
	[AETDVSCLSD] [nvarchar](500) NULL,
	[AETDVSOLSD] [nvarchar](500) NULL,
	[PO_CLSD] [nvarchar](500) NULL,
	[PO_AETD] [nvarchar](500) NULL,
	[PO_ACRD] [nvarchar](500) NULL,
	[POREL_CLSD] [nvarchar](500) NULL,
	[POREL_AETD] [nvarchar](500) NULL,
	[POREL_ACRD] [nvarchar](500) NULL,
	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
	[CLSDVSOLSD] [nvarchar](500) NULL,
	[SHIPWINDOWRESULT] [varchar](100) NULL,
	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
	[DELAYCODE] [varchar](100) NULL,
	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
	[LTDIFF] [nvarchar](500) NULL,
	[PODATERESULT] [nvarchar](55) NULL,
	[POSERIES] [varchar](100) NULL,
	[LENGTH] [nvarchar](500) NULL,
	[WIDTH] [nvarchar](500) NULL,
	[HEIGHT] [nvarchar](500)) NULL,
	[TTL_KGS] [nvarchar](500) NULL,
	[TTL_CBM] [nvarchar](500) NULL,
	[SUPPLIERRESULT] [varchar](50) NULL,
	[OVERALLRESULT] [varchar](50) NULL,
	[ASMRESULT] [varchar](50) NULL,
	[CHECK1] [nvarchar](10) NULL,
	[CHECK2] [nvarchar](10) NULL,
	[CHECK3] [nvarchar](10) NULL,
	[CHECK4] [nvarchar](10) NULL,
	[CHECK5] [nvarchar](10) NULL,
	[CHECK6] [nvarchar](10) NULL,
	[PENALTYSEC] [nvarchar](40) NULL,
	[PENALTY_RATE] [nvarchar](500) NULL,
	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
	[DATASOURCE] [varchar](50) NULL,
	[DATASOURCE_IDX] [varchar](255) NULL,
	[TEAM_CODE] [varchar](50) NULL,
	[TEAM_SUB_CODE] [varchar](50) NULL,
	[TEAM_CODE_FY16] [varchar](50) NULL,
	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
	[TEAM_CODE_FY17] [varchar](50) NULL,
	[UsageFlag] [varchar](50) NULL,
	[IsQVReported] [varchar](50) NULL,
	[IsSpendReclasstoNextReportPeriod] [varchar](50) NULL,
	[LASTUPDATED] [nvarchar](55)NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
) 
GO

--Syntax Error: Incorrect syntax near NULL.
--CREATE TABLE [psa].[WBAHK_FactMIDATA_LIMA_OPEN_HKSQLDB](
--[row_id] [bigint] IDENTITY(1,1) NOT NULL,
--	[DateKey] [varchar](50) NULL,
--	[OWNER] [varchar](100) NULL,
--	[BIZ_CODE] [varchar](50) NULL,
--	[BUSINESS] [varchar](100) NULL,
--	[DEPARTMENT] [varchar](100) NULL,
--	[SUBDEPARTMENT] [varchar](100) NULL,
--	[DEPARTMENT_FY16] [varchar](100) NULL,
--	[SUBDEPARTMENT_FY16] [varchar](100) NULL,
--	[WBATIER1CODE] [varchar](100) NULL,
--	[WBATIER2CODE] [varchar](100) NULL,
--	[WBA_CATEGORYTIER1] [varchar](100) NULL,
--	[WBA_CATEGORYTIER2] [varchar](100) NULL,
--	[PRODUCTGROUP] [varchar](100) NULL,
--	[SEASON] [varchar](100) NULL,
--	[PO_ORDERTYPE] [nvarchar](100) NULL,
--	[CUST_CODE] [nvarchar](100) NULL,
--	[VENDORCODE] [nvarchar](100) NULL,
--	[SUPPLIERNAME] [varchar](200) NULL,
--	[PO_STATUS] [varchar](100) NULL,
--	[CUSTOMERONO] [varchar](100) NOT NULL,
--	[QUOTENO] [varchar](100) NULL,
--	[PROJECTGROUP] [varchar](100) NULL,
--	[PROJECTNAME] [varchar](100) NOT NULL,
--	[OFFERNO] [varchar](100) NULL,
--	[SAP_PONO] [varchar](100) NULL,
--	[WBA_PONO] [varchar](100) NULL,
--	[PROFORMAPONO] [varchar](100) NULL,
--	[PO_LINENO] [nvarchar](50) NULL,
--	[ITEMCODE] [varchar](100) NULL,
--	[DESCRIPTION] [nvarchar](160) NULL,
--	[ORIGINALCUR] [nvarchar](6) NULL,
--	[UNITPRICE] [nvarchar](500) NULL,
--	[PO_QTY] [nvarchar](500) NULL,
--	[POQTYAMT_OC] [nvarchar](500) NULL,
--	[ACTUALSHIPPEDQTY] [nvarchar](500) NULL,
--	[SAQTY] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
--	[EXRATE] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_USD] [nvarchar](500) NULL,
--	[COUNTRYOFORIGIN] [nvarchar](100) NULL,
--	[PORTOFLADING] [varchar](100) NULL,
--	[PORTOFLADING_NAME] [varchar](100) NULL,
--	[PORT_LEADTIME] [nvarchar](500) NULL,
--	[PORT_COUNTRY] [varchar](100) NULL,
--	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
--	[LTPO_ETDREDUCED] [nvarchar](500) NULL,
--	[MODEOFTRANSPORT] [varchar](100) NULL,
--	[LOADINGMODE] [varchar](100) NULL,
--	[SHIPPINGTERMS] [varchar](100) NULL,
--	[SHIPPINGCOMPANY] [varchar](100) NULL,
--	[DELIVERWAREHOUSE] [varchar](100) NULL,
--	[IMPORTCOUNTRY] [varchar](100) NULL,
--	[PO_DATE] [nvarchar](55) NULL,
--	[PO_RELEASEDATE] [nvarchar](55) NULL,
--	[POVSRELDATE] [nvarchar](500) NULL,
--	[CUSTREQ_SIW] [nvarchar](55) NULL,
--	[OLSD] [nvarchar](55) NULL,
--	[CURRENT_ESD] [nvarchar](55) NULL,
--	[CLSD] [nvarchar](55) NULL,
--	[CSIW] [nvarchar](55) NULL,
--	[ACRD] [nvarchar](55) NULL,
--	[AETD] [nvarchar](55) NULL,
--	[ACRDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSOLSD] [nvarchar](500) NULL,
--	[PO_CLSD] [nvarchar](500) NULL,
--	[PO_AETD] [nvarchar](500) NULL,
--	[PO_ACRD] [nvarchar](500) NULL,
--	[POREL_CLSD] [nvarchar](500) NULL,
--	[POREL_AETD] [nvarchar](500) NULL,
--	[POREL_ACRD] [nvarchar](500) NULL,
--	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
--	[CLSDVSOLSD] [nvarchar](500) NULL,
--	[SHIPWINDOWRESULT] [varchar](100) NULL,
--	[SHIPWINDOWRESULT_FY16] [varchar](100) NULL,
--	[DELAYCODE] [varchar](100) NULL,
--	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
--	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
--	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
--	[BQORDERLTPORTCODE] [nvarchar](500) NULL,
--	[LTDIFF] [nvarchar](500) NULL,
--	[PODATERESULT] [nvarchar](55) NULL,
--	[POSERIES] [varchar](100) NULL,
--	[LENGTH] [nvarchar](500) NULL,
--	[WIDTH] [nvarchar](500) NULL,
--	[HEIGHT] [nvarchar](500)) NULL,
--	[TTL_KGS] [nvarchar](500) NULL,
--	[TTL_CBM] [nvarchar](500) NULL,
--	[SUPPLIERRESULT] [varchar](50) NULL,
--	[OVERALLRESULT] [varchar](50) NULL,
--	[ASMRESULT] [varchar](50) NULL,
--	[CHECK1] [nvarchar](10) NULL,
--	[CHECK2] [nvarchar](10) NULL,
--	[CHECK3] [nvarchar](10) NULL,
--	[CHECK4] [nvarchar](10) NULL,
--	[CHECK5] [nvarchar](10) NULL,
--	[CHECK6] [nvarchar](10) NULL,
--	[PENALTYSEC] [nvarchar](40) NULL,
--	[PENALTY_RATE] [nvarchar](500) NULL,
--	[POQTYAMT_OC_PENALTY] [nvarchar](500) NULL,
--	[POQTYAMT_USD_PENALTY] [nvarchar](500) NULL,
--	[DATASOURCE] [varchar](50) NULL,
--	[DATASOURCE_IDX] [varchar](255) NULL,
--	[TEAM_CODE] [varchar](50) NULL,
--	[TEAM_SUB_CODE] [varchar](50) NULL,
--	[TEAM_CODE_FY16] [varchar](50) NULL,
--	[TEAM_SUB_CODE_FY16] [varchar](50) NULL,
--	[TEAM_CODE_FY17] [varchar](50) NULL,
--	[UsageFlag] [varchar](50) NULL,
--	[IsQVReported] [varchar](50) NULL,
--	[IsSpendReclasstoNextReportPeriod] [varchar](50) NULL,
--	[LASTUPDATED] [nvarchar](55)NULL,
--	[etl_runlog_id] [nvarchar](20) NULL,
--	[asset_id] [nvarchar](20) NULL,
--	[record_source_id] [nvarchar](20) NULL,
--	[row_status] [int] NULL,
--	[created_timestamp] [datetime] NULL,
--	[active_flag] [char](1) NULL
--) 



GO

CREATE TABLE [psa].[WBAHK_FactMIDATA_GSOOPEN_HKSQLDB](
[row_id] [bigint] IDENTITY(1,1) NOT NULL,
	[DATEKEY] [varchar](8) NULL,
	[OWNER] [nvarchar](255) NOT NULL,
	[BIZ_CODE] [nvarchar](200) NULL,
	[BUSINESS] [nvarchar](255) NULL,
	[DEPARTMENT] [nvarchar](600) NULL,
	[SUBDEPARTMENT] [nvarchar](255) NULL,
	[DEPARTMENT_FY16] [nvarchar](255) NULL,
	[SUBDEPARTMENT_FY16] [nvarchar](255) NULL,
	[WBATIER1CODE] [nvarchar](255) NULL,
	[WBATIER2CODE] [nvarchar](255) NULL,
	[WBA_CATEGORYTIER1] [nvarchar](255) NULL,
	[WBA_CATEGORYTIER2] [nvarchar](255) NULL,
	[PRODUCTGROUP] [nvarchar](255) NULL,
	[BRAND] [nvarchar](255) NULL,
	[BRAND_NAME] [nvarchar](255) NULL,
	[BRAND_TYPECODE] [nvarchar](255) NULL,
	[BRAND_TYPENAME] [nvarchar](255) NULL,
	[SEASON] [nvarchar](255) NULL,
	[PO_ORDERTYPE] [nvarchar](255) NULL,
	[IS_CMI] [nvarchar](255) NULL,
	[CUSTOMERCOMPANY] [nvarchar](255) NULL,
	[SUPPLIER] [nvarchar](255) NULL,
	[SUPPLIERNAME] [nvarchar](255) NULL,
	[PO_STATUS] [nvarchar](255) NULL,
	[CUSTOMERONO] [nvarchar](255) NOT NULL,
	[QUOTENO] [nvarchar](255) NULL,
	[PROJECT] [nvarchar](255) NULL,
	[RANGE] [nvarchar](255) NULL,
	[OFFERNO] [nvarchar](255) NULL,
	[SAP_PONO] [nvarchar](255) NULL,
	[WBA_PONO] [nvarchar](255) NULL,
	[PROFORMAPONO] [nvarchar](255) NOT NULL,
	[PO_LINENO] [nvarchar](500) NOT NULL,
	[ITEMCODE] [nvarchar](255) NOT NULL,
	[DESCRIPTION] [nvarchar](255) NULL,
	[QTYPEROUTER] [nvarchar](500) NULL,
	[QTYPERINNER] [nvarchar](500) NULL,
	[ORIGINALCUR] [nvarchar](255) NULL,
	[UNITPRICE] [nvarchar](500) NULL,
	[PO_QTY] [nvarchar](500) NULL,
	[POQTYAMT_OC] [nvarchar](500) NULL,
	[ACTUALSHIPPEDQTY] [nvarchar](384) NULL,
	[SAQTY] [nvarchar](500) NULL,
	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
	[EXRATE] [nvarchar](384) NULL,
	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_USD] [nvarchar](500) NULL,
	[POQTYAMT_GBP] [nvarchar](500) NULL,
	[COUNTRYOFORIGIN] [nvarchar](255) NULL,
	[PORTOFLADING] [nvarchar](255) NULL,
	[PORTOFLADING_NAME] [nvarchar](255) NULL,
	[PORT_LEADTIME] [nvarchar](384) NULL,
	[PORT_COUNTRY] [nvarchar](255) NULL,
	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
	[LTPO_ETDREDUCED] [nvarchar](500)) NULL,
	[MODEOFTRANSPORT] [nvarchar](18) NULL,
	[LOADINGMODE] [nvarchar](35) NULL,
	[SHIPPINGTERMS] [nvarchar](6) NULL,
	[SHIPPINGCOMPANY] [nvarchar](17) NULL,
	[DELIVERWAREHOUSE] [nvarchar](17) NULL,
	[IMPORTCOUNTRY] [nvarchar](3) NULL,
	[PO_DATE] [nvarchar](55) NULL,
	[PO_RELEASEDATE] [nvarchar](55) NULL,
	[POVSRELDATE] [nvarchar](500) NULL,
	[CUSTREQ_SIW] [nvarchar](55) NULL,
	[OLSD] [nvarchar](55) NULL,
	[CURRENT_ESD] [nvarchar](55) NULL,
	[CLSD] [nvarchar](55) NULL,
	[CSIW] [nvarchar](55) NULL,
	[OSIW] [nvarchar](55) NULL,
	[ACRD] [nvarchar](55) NULL,
	[AETD] [nvarchar](55) NULL,
	[CLSD_OLSD] [nvarchar](55) NULL,
	[ACRDVSCLSD] [nvarchar](500) NULL,
	[AETDVSCLSD] [nvarchar](500) NULL,
	[AETDVSOLSD] [nvarchar](500) NULL,
	[PO_CLSD] [nvarchar](500) NULL,
	[PO_AETD] [nvarchar](500) NULL,
	[PO_ACRD] [nvarchar](500) NULL,
	[POREL_CLSD] [nvarchar](500) NULL,
	[POREL_AETD] [nvarchar](500) NULL,
	[POREL_ACRD] [nvarchar](500) NULL,
	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
	[CLSDVSOLSD] [nvarchar](500) NULL,
	[SHIPWINDOWRESULT] [nvarchar](4) NULL,
	[SHIPWINDOWRESULT_FY16] [nvarchar](4) NULL,
	[DELAYCODE] [nvarchar](35) NULL,
	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
	[BQORDERLTPORTCODE] [nvarchar](384) NULL,
	[LTDIFF] [nvarchar](500) NULL,
	[PODATERESULT] [nvarchar](55) NULL,
	[TEAM_CODE] [nvarchar](35) NULL,
	[TEAM_SUBCODE] [nvarchar](2) NULL,
	[TEAM_CODE_FY16] [nvarchar](200) NULL,
	[TEAM_SUBCODE_FY16] [nvarchar](2) NULL,
	[XREF] [nvarchar](35) NULL,
	[BUSINESSUNIT] [nvarchar](35) NULL,
	[BUFILTER] [nvarchar](5) NULL,
	[BUFILTER_TSS] [nvarchar](12) NULL,
	[SARELEASEDATE] [nvarchar](55) NULL,
	[SANO] [nvarchar](35) NULL,
	[FACTORY] [nvarchar](17) NULL,
	[CONFIRMEDDATE] [nvarchar](55) NULL,
	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
	[BCMK_REFNO] [nvarchar](35) NULL,
	[SHIPMENT PHASE] [nvarchar](500) NULL,
	[OFFERSTATUS] [nvarchar](35) NULL,
	[PRICEDEVIATION] [nvarchar](500) NULL,
	[SETRELATIONSHIP] [nvarchar](35) NULL,
	[LINENO] [nvarchar](35) NULL,
	[SEASONYEAR] [nvarchar](500) NULL,
	[COMMENTS] [nvarchar](250) NULL,
	[LASTMODIFIEDDT] [nvarchar](55) NULL,
	[LASTMODIFIEDBY] [nvarchar](18) NULL,
	[ISSARELEASED] [nvarchar](35) NULL,
	[PARTYNAME] [nvarchar](80) NULL,
	[POSERIES] [nvarchar](6) NULL,
	[LENGTH] [nvarchar](384) NULL,
	[WIDTH] [nvarchar](384) NULL,
	[HEIGHT] [nvarchar](384) NULL,
	[TTL_KGS] [nvarchar](384) NULL,
	[TTL_CBM] [nvarchar](384) NULL,
	[SUPPLIERRESULT] [nvarchar](4) NULL,
	[OVERALLRESULT] [nvarchar](4) NULL,
	[ASMRESULT] [nvarchar](4) NULL,
	[CHECK1] [nvarchar](5) NULL,
	[CHECK2] [nvarchar](5) NULL,
	[CHECK3] [nvarchar](5) NULL,
	[CHECK4] [nvarchar](5) NULL,
	[CHECK5] [nvarchar](5) NULL,
	[CHECK6] [nvarchar](5) NULL,
	[PENALTYSEC] [nvarchar](200) NULL,
	[PENALTY_RATE] [nvarchar](384) NULL,
	[POQTYAMT_OC_PENALTY] [nvarchar](384) NULL,
	[POQTYAMT_USD_PENALTY] [nvarchar](384) NULL,
	[DATASOURCE] [varchar](3) NOT NULL,
	[DATASOURCE_IDX] [varchar](42) NOT NULL,
	[LASTUPDATED] [nvarchar](55) NOT NULL,
	[etl_runlog_id] [nvarchar](20) NULL,
	[asset_id] [nvarchar](20) NULL,
	[record_source_id] [nvarchar](20) NULL,
	[row_status] [int] NULL,
	[created_timestamp] [datetime] NULL,
	[active_flag] [char](1) NULL
) 
GO

--Syntax Error: Incorrect syntax near NULL.
--CREATE TABLE [psa].[WBAHK_FactMIDATA_GSOOPEN_HKSQLDB](
--[row_id] [bigint] IDENTITY(1,1) NOT NULL,
--	[DATEKEY] [varchar](8) NULL,
--	[OWNER] [nvarchar](255) NOT NULL,
--	[BIZ_CODE] [nvarchar](200) NULL,
--	[BUSINESS] [nvarchar](255) NULL,
--	[DEPARTMENT] [nvarchar](600) NULL,
--	[SUBDEPARTMENT] [nvarchar](255) NULL,
--	[DEPARTMENT_FY16] [nvarchar](255) NULL,
--	[SUBDEPARTMENT_FY16] [nvarchar](255) NULL,
--	[WBATIER1CODE] [nvarchar](255) NULL,
--	[WBATIER2CODE] [nvarchar](255) NULL,
--	[WBA_CATEGORYTIER1] [nvarchar](255) NULL,
--	[WBA_CATEGORYTIER2] [nvarchar](255) NULL,
--	[PRODUCTGROUP] [nvarchar](255) NULL,
--	[BRAND] [nvarchar](255) NULL,
--	[BRAND_NAME] [nvarchar](255) NULL,
--	[BRAND_TYPECODE] [nvarchar](255) NULL,
--	[BRAND_TYPENAME] [nvarchar](255) NULL,
--	[SEASON] [nvarchar](255) NULL,
--	[PO_ORDERTYPE] [nvarchar](255) NULL,
--	[IS_CMI] [nvarchar](255) NULL,
--	[CUSTOMERCOMPANY] [nvarchar](255) NULL,
--	[SUPPLIER] [nvarchar](255) NULL,
--	[SUPPLIERNAME] [nvarchar](255) NULL,
--	[PO_STATUS] [nvarchar](255) NULL,
--	[CUSTOMERONO] [nvarchar](255) NOT NULL,
--	[QUOTENO] [nvarchar](255) NULL,
--	[PROJECT] [nvarchar](255) NULL,
--	[RANGE] [nvarchar](255) NULL,
--	[OFFERNO] [nvarchar](255) NULL,
--	[SAP_PONO] [nvarchar](255) NULL,
--	[WBA_PONO] [nvarchar](255) NULL,
--	[PROFORMAPONO] [nvarchar](255) NOT NULL,
--	[PO_LINENO] [nvarchar](500) NOT NULL,
--	[ITEMCODE] [nvarchar](255) NOT NULL,
--	[DESCRIPTION] [nvarchar](255) NULL,
--	[QTYPEROUTER] [nvarchar](500) NULL,
--	[QTYPERINNER] [nvarchar](500) NULL,
--	[ORIGINALCUR] [nvarchar](255) NULL,
--	[UNITPRICE] [nvarchar](500) NULL,
--	[PO_QTY] [nvarchar](500) NULL,
--	[POQTYAMT_OC] [nvarchar](500) NULL,
--	[ACTUALSHIPPEDQTY] [nvarchar](384) NULL,
--	[SAQTY] [nvarchar](500) NULL,
--	[SHIPPEDQTYAMT_OC] [nvarchar](500) NULL,
--	[EXRATE] [nvarchar](384) NULL,
--	[SHIPPEDQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_USD] [nvarchar](500) NULL,
--	[POQTYAMT_GBP] [nvarchar](500) NULL,
--	[COUNTRYOFORIGIN] [nvarchar](255) NULL,
--	[PORTOFLADING] [nvarchar](255) NULL,
--	[PORTOFLADING_NAME] [nvarchar](255) NULL,
--	[PORT_LEADTIME] [nvarchar](384) NULL,
--	[PORT_COUNTRY] [nvarchar](255) NULL,
--	[LTPO_ETDNORMAL] [nvarchar](500) NULL,
--	[LTPO_ETDREDUCED] [nvarchar](500)) NULL,
--	[MODEOFTRANSPORT] [nvarchar](18) NULL,
--	[LOADINGMODE] [nvarchar](35) NULL,
--	[SHIPPINGTERMS] [nvarchar](6) NULL,
--	[SHIPPINGCOMPANY] [nvarchar](17) NULL,
--	[DELIVERWAREHOUSE] [nvarchar](17) NULL,
--	[IMPORTCOUNTRY] [nvarchar](3) NULL,
--	[PO_DATE] [nvarchar](55) NULL,
--	[PO_RELEASEDATE] [nvarchar](55) NULL,
--	[POVSRELDATE] [nvarchar](500) NULL,
--	[CUSTREQ_SIW] [nvarchar](55) NULL,
--	[OLSD] [nvarchar](55) NULL,
--	[CURRENT_ESD] [nvarchar](55) NULL,
--	[CLSD] [nvarchar](55) NULL,
--	[CSIW] [nvarchar](55) NULL,
--	[OSIW] [nvarchar](55) NULL,
--	[ACRD] [nvarchar](55) NULL,
--	[AETD] [nvarchar](55) NULL,
--	[CLSD_OLSD] [nvarchar](55) NULL,
--	[ACRDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSCLSD] [nvarchar](500) NULL,
--	[AETDVSOLSD] [nvarchar](500) NULL,
--	[PO_CLSD] [nvarchar](500) NULL,
--	[PO_AETD] [nvarchar](500) NULL,
--	[PO_ACRD] [nvarchar](500) NULL,
--	[POREL_CLSD] [nvarchar](500) NULL,
--	[POREL_AETD] [nvarchar](500) NULL,
--	[POREL_ACRD] [nvarchar](500) NULL,
--	[CSIWVSCUSTSIW] [nvarchar](500) NULL,
--	[CLSDVSOLSD] [nvarchar](500) NULL,
--	[SHIPWINDOWRESULT] [nvarchar](4) NULL,
--	[SHIPWINDOWRESULT_FY16] [nvarchar](4) NULL,
--	[DELAYCODE] [nvarchar](35) NULL,
--	[ACTUALLT_AETDVSAGREEDLT] [nvarchar](500) NULL,
--	[ACTUALLT_AETDVSPOLT] [nvarchar](500) NULL,
--	[ORDERLT_POVSCUSTSIW] [nvarchar](500) NULL,
--	[BQORDERLTPORTCODE] [nvarchar](384) NULL,
--	[LTDIFF] [nvarchar](500) NULL,
--	[PODATERESULT] [nvarchar](55) NULL,
--	[TEAM_CODE] [nvarchar](35) NULL,
--	[TEAM_SUBCODE] [nvarchar](2) NULL,
--	[TEAM_CODE_FY16] [nvarchar](200) NULL,
--	[TEAM_SUBCODE_FY16] [nvarchar](2) NULL,
--	[XREF] [nvarchar](35) NULL,
--	[BUSINESSUNIT] [nvarchar](35) NULL,
--	[BUFILTER] [nvarchar](5) NULL,
--	[BUFILTER_TSS] [nvarchar](12) NULL,
--	[SARELEASEDATE] [nvarchar](55) NULL,
--	[SANO] [nvarchar](35) NULL,
--	[FACTORY] [nvarchar](17) NULL,
--	[CONFIRMEDDATE] [nvarchar](55) NULL,
--	[LATEST_TOTAL_PO_QTY] [nvarchar](500) NULL,
--	[BCMK_REFNO] [nvarchar](35) NULL,
--	[SHIPMENT PHASE] [nvarchar](500) NULL,
--	[OFFERSTATUS] [nvarchar](35) NULL,
--	[PRICEDEVIATION] [nvarchar](500) NULL,
--	[SETRELATIONSHIP] [nvarchar](35) NULL,
--	[LINENO] [nvarchar](35) NULL,
--	[SEASONYEAR] [nvarchar](500) NULL,
--	[COMMENTS] [nvarchar](250) NULL,
--	[LASTMODIFIEDDT] [nvarchar](55) NULL,
--	[LASTMODIFIEDBY] [nvarchar](18) NULL,
--	[ISSARELEASED] [nvarchar](35) NULL,
--	[PARTYNAME] [nvarchar](80) NULL,
--	[POSERIES] [nvarchar](6) NULL,
--	[LENGTH] [nvarchar](384) NULL,
--	[WIDTH] [nvarchar](384) NULL,
--	[HEIGHT] [nvarchar](384) NULL,
--	[TTL_KGS] [nvarchar](384) NULL,
--	[TTL_CBM] [nvarchar](384) NULL,
--	[SUPPLIERRESULT] [nvarchar](4) NULL,
--	[OVERALLRESULT] [nvarchar](4) NULL,
--	[ASMRESULT] [nvarchar](4) NULL,
--	[CHECK1] [nvarchar](5) NULL,
--	[CHECK2] [nvarchar](5) NULL,
--	[CHECK3] [nvarchar](5) NULL,
--	[CHECK4] [nvarchar](5) NULL,
--	[CHECK5] [nvarchar](5) NULL,
--	[CHECK6] [nvarchar](5) NULL,
--	[PENALTYSEC] [nvarchar](200) NULL,
--	[PENALTY_RATE] [nvarchar](384) NULL,
--	[POQTYAMT_OC_PENALTY] [nvarchar](384) NULL,
--	[POQTYAMT_USD_PENALTY] [nvarchar](384) NULL,
--	[DATASOURCE] [varchar](3) NOT NULL,
--	[DATASOURCE_IDX] [varchar](42) NOT NULL,
--	[LASTUPDATED] [nvarchar](55) NOT NULL,
--	[etl_runlog_id] [nvarchar](20) NULL,
--	[asset_id] [nvarchar](20) NULL,
--	[record_source_id] [nvarchar](20) NULL,
--	[row_status] [int] NULL,
--	[created_timestamp] [datetime] NULL,
--	[active_flag] [char](1) NULL
--) 



GO

/****** Object:  StoredProcedure [con_tpm].[sp_dl_payments_egress_test]    Script Date: 1/31/2023 4:17:05 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_tpm].[sp_dm_ActualSO_Walgreens_Retailer_test]    Script Date: 1/30/2023 8:22:41 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [con_dwh].[TBL_SER_GAMIFICATION_GAME_RESULT_Dailyload]    Script Date: 2/17/2023 11:39:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_load_GAMIFICATION_ELIGIBILITY]    Script Date: 2/17/2023 4:00:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [con_dwh].[TBL_SER_GAMIFICATION_GAME_RESULT_Dailyload]    Script Date: 2/17/2023 11:39:39 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_load_GAMIFICATION_ELIGIBILITY]    Script Date: 2/17/2023 4:00:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[PartySocialMediaInfo]    Script Date: 1/16/2023 8:10:06 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[PersonConsent]    Script Date: 1/16/2023 8:06:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[REFCurrency]    Script Date: 1/16/2023 8:23:13 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[REFPersonConsentType]    Script Date: 1/16/2023 8:00:18 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[REFSiteType]    Script Date: 1/16/2023 8:25:27 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[REFSocialMediaType]    Script Date: 1/16/2023 8:16:50 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[SAPCRMADCardCustomerChild]    Script Date: 1/16/2023 8:21:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[SAPCRMADCardCustomerClubs]    Script Date: 1/16/2023 8:21:18 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[SAPCRMADCardMembershipActivity]    Script Date: 1/16/2023 8:22:27 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[SAPCRMADCardMembershipPoints]    Script Date: 1/16/2023 8:19:46 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[SAPCRMADCardTransactions]    Script Date: 1/16/2023 8:20:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[SAPCRMCustomerStatusChange]    Script Date: 1/16/2023 8:26:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[Site]    Script Date: 1/16/2023 8:26:06 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[SiteRole]    Script Date: 1/16/2023 8:24:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [Curate_Enterprise].[SVOCDeletedCustomer]    Script Date: 1/16/2023 8:07:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [curate_enterprise].[VW_SER_GAMIFICATION_Relationship] ASÂ select [PersonRelationshipID]
Â Â Â Â Â  ,[SRCRelationshipTypeName]
Â Â Â Â Â  ,[ParentPersonId]
Â Â Â Â Â  ,[ChildPersonId]
Â Â Â Â Â  ,[DeleteIndicator]
Â Â Â Â Â  ,[EffectiveFrom]
Â Â Â Â Â  ,[EffectiveTo]
Â Â Â Â Â  ,[MemberUpdateTime]
Â Â Â Â Â  ,[SourceCreateTime]
Â Â Â Â Â  ,[SourceUpdateTime]
Â Â Â Â Â  ,[RecordSourceCode]
Â Â Â Â Â  ,[LOVRecordSourceId]
Â Â Â Â Â  ,[RunDateTime]
Â Â Â Â Â  ,[DLCreateDateTime]
Â Â Â Â Â  ,[DLUpdateDateTime]
Â Â Â Â Â  ,[DLSCDStartDateTime]
Â Â Â Â Â  ,[DLSCDEndDateTime]
Â Â Â Â Â  ,[DLSCDActiveFlag]
Â Â Â Â Â  ,[DLETLRunLogID]
Â Â Â Â Â  ,[DLCurateStandardRowKey] from (
SELECT [PersonRelationshipID]
Â Â Â Â Â  ,[SRCRelationshipTypeName]
Â Â Â Â Â  ,[ParentPersonId]
Â Â Â Â Â  ,[ChildPersonId]
Â Â Â Â Â  ,[DeleteIndicator]
Â Â Â Â Â  ,[EffectiveFrom]
Â Â Â Â Â  ,[EffectiveTo]
Â Â Â Â Â  ,[MemberUpdateTime]
Â Â Â Â Â  ,[SourceCreateTime]
Â Â Â Â Â  ,[SourceUpdateTime]
Â Â Â Â Â  ,[RecordSourceCode]
Â Â Â Â Â  ,[LOVRecordSourceId]
Â Â Â Â Â  ,[RunDateTime]
Â Â Â Â Â  ,[DLCreateDateTime]
Â Â Â Â Â  ,[DLUpdateDateTime]
Â Â Â Â Â  ,[DLSCDStartDateTime]
Â Â Â Â Â  ,[DLSCDEndDateTime]
Â Â Â Â Â  ,[DLSCDActiveFlag]
Â Â Â Â Â  ,[DLETLRunLogID]
Â Â Â Â Â  ,[DLCurateStandardRowKey]
Â Â Â Â Â  , row_number() over(partition by [ChildPersonId] order by [MemberUpdateTime] desc, [SourceCreateTime] desc,[SourceUpdateTime] desc ) row_val
Â Â  FROM (select * from [curate_enterprise].[PersonRelationship] where [DLSCDActiveFlag]='Y') src ) srcrow whereÂ  row_val=1;Â GO

GO

--Syntax Error: Incorrect syntax near ASÂ.
--CREATE VIEW [curate_enterprise].[VW_SER_GAMIFICATION_Relationship] ASÂ select [PersonRelationshipID]
--Â Â Â Â Â  ,[SRCRelationshipTypeName]
--Â Â Â Â Â  ,[ParentPersonId]
--Â Â Â Â Â  ,[ChildPersonId]
--Â Â Â Â Â  ,[DeleteIndicator]
--Â Â Â Â Â  ,[EffectiveFrom]
--Â Â Â Â Â  ,[EffectiveTo]
--Â Â Â Â Â  ,[MemberUpdateTime]
--Â Â Â Â Â  ,[SourceCreateTime]
--Â Â Â Â Â  ,[SourceUpdateTime]
--Â Â Â Â Â  ,[RecordSourceCode]
--Â Â Â Â Â  ,[LOVRecordSourceId]
--Â Â Â Â Â  ,[RunDateTime]
--Â Â Â Â Â  ,[DLCreateDateTime]
--Â Â Â Â Â  ,[DLUpdateDateTime]
--Â Â Â Â Â  ,[DLSCDStartDateTime]
--Â Â Â Â Â  ,[DLSCDEndDateTime]
--Â Â Â Â Â  ,[DLSCDActiveFlag]
--Â Â Â Â Â  ,[DLETLRunLogID]
--Â Â Â Â Â  ,[DLCurateStandardRowKey] from (
--SELECT [PersonRelationshipID]
--Â Â Â Â Â  ,[SRCRelationshipTypeName]
--Â Â Â Â Â  ,[ParentPersonId]
--Â Â Â Â Â  ,[ChildPersonId]
--Â Â Â Â Â  ,[DeleteIndicator]
--Â Â Â Â Â  ,[EffectiveFrom]
--Â Â Â Â Â  ,[EffectiveTo]
--Â Â Â Â Â  ,[MemberUpdateTime]
--Â Â Â Â Â  ,[SourceCreateTime]
--Â Â Â Â Â  ,[SourceUpdateTime]
--Â Â Â Â Â  ,[RecordSourceCode]
--Â Â Â Â Â  ,[LOVRecordSourceId]
--Â Â Â Â Â  ,[RunDateTime]
--Â Â Â Â Â  ,[DLCreateDateTime]
--Â Â Â Â Â  ,[DLUpdateDateTime]
--Â Â Â Â Â  ,[DLSCDStartDateTime]
--Â Â Â Â Â  ,[DLSCDEndDateTime]
--Â Â Â Â Â  ,[DLSCDActiveFlag]
--Â Â Â Â Â  ,[DLETLRunLogID]
--Â Â Â Â Â  ,[DLCurateStandardRowKey]
--Â Â Â Â Â  , row_number() over(partition by [ChildPersonId] order by [MemberUpdateTime] desc, [SourceCreateTime] desc,[SourceUpdateTime] desc ) row_val
--Â Â  FROM (select * from [curate_enterprise].[PersonRelationship] where [DLSCDActiveFlag]='Y') src ) srcrow whereÂ  row_val=1;Â GO



GO

/****** Object:  StoredProcedure [psa].[sp_inc_step_product_exclusion]    Script Date: 3/2/2023 1:52:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [psa].[GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel]    Script Date: 3/2/2023 1:30:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [curate_enterprise].[PartyEmail]    Script Date: 3/8/2023 12:06:41 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [curate_enterprise].[PartyPhone]    Script Date: 3/8/2023 12:09:57 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_EnterpriseSynapseSCD_DE]    Script Date: 3/21/2023 7:07:18 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [lod].[GlobalBrands_No7FINExcel_GlobalBrands_Props_product_list_No7FINExcel]    Script Date: 3/21/2023 5:25:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_by_spc_Merch_store]    Script Date: 3/20/2023 12:27:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROC [psa].[sp_inc_uk_btc_by_spc_Merch_store] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS
    DECLARE
        @SCDLOVRecordSourceID           int,
        @psaETLRunLogID                 [varchar](max),
        @maxPlanogramFixtureID          bigint,
        @rlsLOVRecordSourceID           bigint,
        @SCDDefaultEndDate              datetime,
        @duplicateRowStatus             bigint,
        @LOVSourceKeyTypeID             bigint,
        @LOVRecordSourceID              bigint,
        @SCDStartDate                   datetime,
        @SCDEndDate                     datetime,
        @psaRowStatus                   bigint,
        @serRowStatus                   bigint,
        @DQCOUNTER                      bigint,
        @MeasureId                      bigint,
        @LOVUOMID                       bigint,
        @COUNTER                        bigint,
        @MAXID                          bigint,
        @rule_id                        int,
        @asset_id                       int,
        @max_PlanogramGroupId           bigint,
        @DQROWS                         bigint,
        @DQrowid                        bigint,
        @rule_entity_id                 bigint,
        @rule_attribute_id              bigint,
        @DQcolumn                       [varchar](max),
        @rule_source_entity_id          bigint,
        @rule_detail                    [varchar](max),
        @rule_dt_created                smalldatetime,
        @rule_user_created              [varchar](max),
        @rule_source_attribute_id       [varchar](max),
        @SCDEndDate_final               datetime,
        @SCDActiveFlag                  char,
        @SCDVersion                     smallint,
        @SCDStartDate_initial           datetime,
        @maxPlanogramSiteRoleId         bigint,
        @maxSiteRoleId                  bigint,
        @maxPlanogramFloorPlanId        bigint,
        @maxPlanogram_childFloorPlanId  bigint,
        @maxPlanogramFloorPlanSectionId bigint,
        @l_tableName                    [varchar](max),
        @l_serveETLRunLogID             [varchar](max),
        @l_psaEntityId                  [varchar](max),
        @msg                            varchar(8000),
        @feed_entityid                  [varchar](max),
        @attributeid1                   [varchar](max),
        @attributeid2                   [varchar](max),
        @attr                           [varchar](max),
        @l_check_att                    VARCHAR(2000),
        @tablecolumns                   VARCHAR(500),
        @exec_sql                       VARCHAR(1000);
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];
        END
    IF OBJECT_ID('psa.TmpPSATable') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[TmpPSATable];
        END

    /**********Creating a temporary table to iterate through all the asset IDs present in PSA table********/
    CREATE TABLE [psa].[fixture_cursor_table]
        (
            [RowID]    bigint,
            [asset_id] int
        );
    BEGIN

        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'StoreNumber'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[StoreNumber]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBFamilyKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBFamilyKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBFamilyKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPSecDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPSecDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPSecDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @SCDDefaultEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31')
            );
        SET @LOVRecordSourceID = 1800052563;
        SET @rlsLOVRecordSourceID = 12012;
        SET @psaRowStatus = 26001;
        SET @serRowStatus = 26002;
        SET @duplicateRowStatus = 26010;
        SET @SCDLOVRecordSourceID = @LOVRecordSourceID;
        SET @SCDStartDate_initial =
            (
                SELECT
                    CONVERT(datetime, '1900-01-01 00:00:00')
            )
        SET @SCDEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31 00:00:00')
            )
        SET @SCDActiveFlag = 'Y'
        SET @SCDVersion = 1
        SET @SCDEndDate_final = DATEADD(second, -1, @SCDStartDate)
        SET @LOVSourceKeyTypeID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                where
                    r.LOVKey = 'BY Planogram Family Key' --'BY Planogram Key'
                    AND r.LOVSetName = 'Source Key Type'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        SET @MeasureId =
            (
                SELECT
                    m.MeasureID
                FROM
                    [ser].[Measure] m
                WHERE
                    m.MeasureName = 'shelf_number'
                    AND m.LOVRECORDSOURCEID = @LOVRecordSourceID
                    AND m.SCDActiveFlag = 'Y'
            );
        SET @LOVUOMID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                WHERE
                    r.LOVKey = 'Unknown'
                    AND r.LOVSetName = 'Unit Of Measure'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        BEGIN TRY
            SET @COUNTER = 1
            SELECT
                @MAXID = COUNT(distinct asset_id)
            FROM
                [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf
            WHERE
                row_status = @psaRowStatus;
            print 'Total Number of Loops : ' + cast(@MAXID as varchar) + '';

            --select * from [psa].[fixture_cursor_table]
            INSERT INTO [psa].[fixture_cursor_table]
                        SELECT DISTINCT
                            DENSE_RANK() OVER (ORDER BY (asset_id)) AS RowID,
                            asset_id                                as asset_id
                        FROM
                            [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                        WHERE
                            row_status = @psaRowStatus;
            WHILE (@COUNTER <= @MAXID)
                BEGIN
                    Print 'The loop count is ' + cast(@COUNTER as varchar);
                    SELECT
                        @asset_id = asset_id
                    from
                        [psa].[fixture_cursor_table]
                    where
                        RowID = @COUNTER;
                    PRINT 'Current Asset ID: ' + CAST(@asset_id as varchar) + '';

                    --select * from ser.PlanogramSiteRole
                    SET @SCDStartDate = current_timestamp;
                    PRINT '****************Inserting into SiteRole Table Started *********************';
                    SET @maxSiteRoleId =
                        (
                            SELECT
                                COALESCE(MAX(SiteRoleId), 0)
                            FROM
                                [ser].SiteRole
                        )
                    SET @tablecolumns
                        = '[SiteRoleId]' + ',[SiteId]' + ',[LOVRoleId]' + ',[SourceKey]' + ',[LOVSourceKeyTypeId]'
                          + ',[SiteRoleName]' + ',[SiteRoleShortName]' + ',[LOVRecordSourceId]' + ',[SCDStartDate]'
                          + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]' + ',[SCDLOVRecordSourceId]'
                          + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: SiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_siterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_siterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns + ' INTO #RPRS_Merch_Store_siterole FROM [ser].[SiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_siterole
                                SELECT
                                    SiteRoleId,
                                    SiteId,
                                    LOVRoleId,
                                    SourceKey,
                                    LOVSourceKeyTypeId,
                                    SiteRoleName,
                                    SiteRoleShortName,
                                    LovRecordSourceID,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as SiteRoleId,
                                            '-1'                  SiteId,
                                            '159000007'           LOVRoleId,
                                            ixf.storenumber       SourceKey,
                                            NULL                  LOVSourceKeyTypeId,
                                            NULL                  SiteRoleName,
                                            NULL                  SiteRoleShortName,
                                            '12008'               LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr st
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                    and not exists
                                                    (
                                                        select
                                                            1
                                                        from
                                                            ser.SiteRole temp
                                                        where
                                                            st.storenumber = temp.Sourcekey
                                                            and temp.LOVRoleId = '159000007'
                                                            and temp.LOVRecordSourceId = '12008'
                                                            and temp.SCDActiveFlag = 'Y'
                                                    )
                                                group by
                                                    storenumber
                                            ) ixf
                                    ) a;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_siterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'SiteRole',
                        @l_table_bus_pk = N'SourceKey,LOVRoleId,LovRecordSourceID',
                        @l_table_pk = N'SiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in SiteRole Table *********************';
                    PRINT '****************Inserting into PlanogramSiteRole Table *********************';
                    SET @tablecolumns
                        = '[PlanogramSiteRoleId]' + ',[PlanogramId]' + ',[SiteRoleId]' + ',[LOVRecordSourceId]'
                          + ',[SCDStartDate]' + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]'
                          + ',[SCDLOVRecordSourceId]' + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: PlanogramSiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_Plansiterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_Plansiterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_Plansiterole FROM [ser].[PlanogramSiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_Plansiterole
                                SELECT
                                    PlanogramSiteRoleId,
                                    PlanogramId,
                                    SiteRoleId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as PlanogramSiteRoleId,
                                            p.PlanogramID         PlanogramID,
                                            s.SiteRoleId          SiteRoleId,
                                            ixf.record_source_id  LOVRecordSourceID,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id,
                                                    min(row_id) row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id
                                            )                     ixf
                                            JOIN
                                                [ser].[Planogram] p
                                                    on ixf.POGDBFamilyKey = p.SourceKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = @LOVRecordSourceID
                                                       AND p.SCDActiveFlag = 'Y'
                                            join
                                                ser.siterole      s
                                                    on s.sourcekey = ixf.StoreNumber
                                                       and s.LOVRecordSourceId = '12008'
                                                       AND s.SCDActiveFlag = 'Y'
                                                       and s.LOVRoleId = '159000007'
                                                       and not exists
                                                                   (
                                                                       select
                                                                           1
                                                                       from
                                                                           ser.PlanogramSiteRole temp
                                                                       where
                                                                           ixf.POGDBFamilyKey = p.SourceKey
                                                                           and p.PlanogramID = temp.PlanogramID
                                                                           and s.SiteRoleId = temp.SiteRoleId
                                                                           and temp.LOVRecordSourceId = '1800052563'
                                                                           and p.scdactiveflag = 'Y'
                                                                           and temp.SCDActiveFlag = 'Y'
                                                                   )
                                    ) b;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_Plansiterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramSiteRole',
                        @l_table_bus_pk = N'PlanogramID,SiteRoleId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramSiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramSiteRole Table *********************';
                    ----Delete Added 	
                    /*     UPDATE [ser].PlanogramSiteRole
   SET SCDEndDate =
   (
   SELECT DATEADD(second, -1, @SCDStartDate)
   ),
   SCDActiveFlag = 'N'
   from [ser].PlanogramSiteRole ps
   inner join (select storenumber, pogdbfamilykey,record_source_id, min(row_id) row_id from  [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
   where asset_id = @asset_id  AND row_status = @psaRowStatus and odsflag = 'DELETE'
   group by storenumber, pogdbfamilykey,record_source_id ) ixf
   JOIN [ser].[Planogram] p
   on ixf.POGDBFamilyKey = p.SourceKey
   and ps.PlanogramID=p.PlanogramID
   and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
   and p.LOVRecordSourceId = @LOVRecordSourceID
   AND p.SCDActiveFlag = 'Y'
   join ser.siterole s
   on s.sourcekey = ixf.StoreNumber
   and s.SiteRoleId= ps.SiteRoleId
   and s.LOVRecordSourceId = '12008'
   AND s.SCDActiveFlag = 'Y'
   and s.LOVRoleId = '159000007'
   where ps.SCDActiveFlag='Y'
   )
   */
                    PRINT '****************Insert Parent into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                     as PlanogramFloorPlanId,
                                            NULL                  ParentPlanogramId,
                                            NULL                  PlanogramSiteRoleId,
                                            '1800055636'          LOVSourceKeyTypeId,
                                            ixf.FPDBFamilyKey     SourceKey,
                                            NULL                  FloorPlanStartDate,
                                            NULL                  FloorPlanEndDate,
                                            NULL                  FloorLevel,
                                            NULL                  FloorPlanName,
                                            NULL                  ParentPlanogramFloorPlanId,
                                            '1800052563'          LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    FPDBFamilyKey,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBFamilyKey is not null
                                                    and FPDBFamilyKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    FPDBFamilyKey
                                            ) ixf
                                        where
                                            not exists
                                            (
                                                select
                                                    1
                                                from
                                                    ser.PlanogramFloorPlan temp
                                                where
                                                    ixf.FPDBFamilyKey = temp.Sourcekey
                                                    and temp.LOVSourceKeyTypeId = '1800055636'
                                                    and temp.LOVRecordSourceId = '1800052563'
                                                    and temp.SCDActiveFlag = 'Y'
                                                    and temp.ParentPlanogramFloorPlanId is null
                                                    and temp.ParentPlanogramId is null
                                            )
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';


                    PRINT '****************Completed Inserting Parent into PlanogramFloorPlan Table completed *********************';
                    SET @maxPlanogram_childFloorPlanId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanId), 0)
                            FROM
                                [ser].PlanogramFloorPlan
                        )
                    PRINT '****************Insert Child  into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                       as PlanogramFloorPlanId,
                                            p.planogramid           ParentPlanogramId,
                                            psr.PlanogramSiteRoleId PlanogramSiteRoleId,
                                            '1800055637'            LOVSourceKeyTypeId,
                                            ixf.FPDBKey             SourceKey,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveFrom = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveFrom
                                             END
                                            )                       FloorPlanStartDate,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveTo = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveTo
                                             END
                                            )                       FloorPlanEndDate,
                                            ixf.FPDesc2             FloorLevel,
                                            ixf.FPName              FloorPlanName,
                                            pf.PlanogramFloorPlanId ParentPlanogramFloorPlanId,
                                            '1800052563'            LOVRecordSourceId,
                                            -- @SCDStartDate SCDStartDate,
                                            NULL                    as [SCDStartDate],
                                            NULL                    as [SCDEndDate],
                                            NULL                    as [SCDActiveFlag],
                                            NULL                    as [SCDVersion],
                                            @SCDLOVRecordSourceId   SCDLOVRecordSourceID,
                                            @serveETLRunLogID       ETLRunLogID,
                                            ixf.row_id              PSARowKey
                                        FROM
                                            (
                                                select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2
                                            )                          ixf
                                            join
                                                ser.SiteRole           sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563'
                                            left join
                                                ser.PlanogramFloorPlan cpf
                                                    on cpf.sourcekey = ixf.FPDBKey
                                                       and cpf.LOVRecordSourceId = '1800052563'
                                                       and cpf.LOVSourceKeyTypeId = '1800055637'
                                                       and cpf.ParentPlanogramFloorPlanId is not NULL
                                                       and cpf.SCDActiveFlag = 'Y'
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';
					
					
					PRINT '****************Process DELETE  records in PlanogramFloorPlanSection Table *********************';


update ser.PlanogramFloorPlansection  set scdactiveflag= 'N' ,SCDEndDate =(
                    SELECT DATEADD(second, -1, @SCDStartDate)                )
from ser.PlanogramFloorPlansection sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and ixf.FPSecDBKey =sec.sourcekey
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


	PRINT '****************Process DELETE  records in PlanogramFloorPlanStatus Table *********************';

---komal scdenddate
/*
update ser.PlanogramFloorPlanStatus  set scdactiveflag= 'N' ,SCDEndDate =( SELECT DATEADD(second, -1, @SCDStartDate))
from ser.PlanogramFloorPlanStatus sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


*/

PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';


---komalscdenddate
/*
update ser.PlanogramFloorPlan  set scdactiveflag= 'N' ,SCDEndDate =(SELECT DATEADD(second, -1, @SCDStartDate)
                )
from ser.PlanogramFloorPlan cpf
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and cpf.SCDActiveFlag = 'Y'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            --inner join
                                            --    ser.PlanogramFloorPlan pf
                                            --        on pf.sourcekey = ixf.FPDBFamilyKey
                                            --           and pf.LOVRecordSourceId = '1800052563'
                                            --           and pf.LOVSourceKeyTypeId = '1800055636'
                                            --           and pf.ParentPlanogramFloorPlanId is NULL 
                                            --           and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId
                                            
*/

PRINT '****************Closed DELETE records, if any, in PlanogramFloorPlan Table *********************';



                    PRINT '****************Start Inserting  into PlanogramFloorPlanSection Table completed *********************';
                    SET @maxPlanogramFloorPlanSectionId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanSectionId), 0)
                            FROM
                                [ser].PlanogramFloorPlanSection
                        );
                    SET @tablecolumns
                        = '[PlanogramFloorPlanSectionId]' + ',	[PlanogramFloorPlanId]'   + ',	[LOVSourceKeyTypeId]'
                          + ',	[SourceKey]' + ',	[SegmentStart]' + ',	[HostPlanogram]' + ',	[LOVRecordSourceId]'
                          + ',	[SCDStartDate]'  + ',	[SCDEndDate]'  + ',	[SCDActiveFlag]'  + ',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlanSection') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlanSection;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlanSection FROM [ser].[PlanogramFloorPlanSection]'
                    EXEC (@exec_sql)
					select * from [ser].[PlanogramFloorPlanSection]

Insert into #RPRS_Merch_Store_PlanogramFloorPlanSection
Select distinct
    0 as PlanogramFloorPlanSectionId,
    pfp.planogramfloorplanid PlanogramFloorPlanId,
    '1800055638' LOVSourceKeyTypeId,
    FPSecDBKey SourceKey,
    FPSecSegmentStart SegmentStart,
    FPSecHostPlanogram HostPlanogram,
    '1800052563' LOVRecordSourceId,
    NULL as [SCDStartDate],
    NULL as [SCDEndDate],
    NULL as [SCDActiveFlag],
    NULL as [SCDVersion],
	  @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
    row_id PSARowKey
FROM
(
    select FPDBKey,
           FPSecDBKey,
           FPSecSegmentStart,
           storenumber,
           POGDBFamilyKey,
           FPSecHostPlanogram,
           min(row_id) as row_id
    from [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
    where asset_id = @asset_id
          AND row_status = @psaRowStatus
          and odsflag <> 'DELETE'
    group by FPDBKey,
             FPSecDBKey,
             FPSecSegmentStart,
             storenumber,
             POGDBFamilyKey,
             FPSecHostPlanogram,
             FPSecHostPlanogram
) ixf
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanSection Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlanSection',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanSection',
                        @l_table_bus_pk = N'SourceKey,PlanogramFloorPlanId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanSectionId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '**************** SCD Load Complete, if any, in PlanogramFloorPlanSection Table *********************';


                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'

                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282117'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --  '200008' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = 'FPPendingDate'
                                                            AND LOVSetId = '282117'
                                                    )                        LOVStatusId,
                                                    ixf.FPPendingDate        EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                        select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate,
                                                    min(row_id) as row_id
                                                from
                                                   [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												 FPPendingDate is not null
                                                            and FPPendingDate != '' and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate
                                                    )                        ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                       
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVStatusId,SCDLOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  				  		  

										  

										  
PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';
                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;
					
					SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select distinct
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select distinct
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceId,
                                            ETLRunLogId,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282083'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --'200007' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = ixf.FPDBStatus
                                                            AND LOVSetId = '282083'
                                                    )                        LOVStatusId,
                                                    NULL                     EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                         select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												  FPDBStatus is not null
                                                            and FPDBStatus != ''
                                                            and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                   and asset_id = @asset_id   AND row_status = @psaRowStatus
												  -- and asset_id= 42134
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus
                                                    )  ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                        
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  
				  

                    UPDATE
                        [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                    SET
                        Row_Status = @serRowStatus
                    WHERE
                        row_Status = @psaRowStatus
                        AND asset_id = @asset_id;

                    SET @COUNTER = @COUNTER + 1;
                END
        --      COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            THROW;
        END CATCH
    END
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];

        END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_by_spc_Merch_store]    Script Date: 3/20/2023 12:27:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROC [psa].[sp_inc_uk_btc_by_spc_Merch_store] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS
    DECLARE
        @SCDLOVRecordSourceID           int,
        @psaETLRunLogID                 [varchar](max),
        @maxPlanogramFixtureID          bigint,
        @rlsLOVRecordSourceID           bigint,
        @SCDDefaultEndDate              datetime,
        @duplicateRowStatus             bigint,
        @LOVSourceKeyTypeID             bigint,
        @LOVRecordSourceID              bigint,
        @SCDStartDate                   datetime,
        @SCDEndDate                     datetime,
        @psaRowStatus                   bigint,
        @serRowStatus                   bigint,
        @DQCOUNTER                      bigint,
        @MeasureId                      bigint,
        @LOVUOMID                       bigint,
        @COUNTER                        bigint,
        @MAXID                          bigint,
        @rule_id                        int,
        @asset_id                       int,
        @max_PlanogramGroupId           bigint,
        @DQROWS                         bigint,
        @DQrowid                        bigint,
        @rule_entity_id                 bigint,
        @rule_attribute_id              bigint,
        @DQcolumn                       [varchar](max),
        @rule_source_entity_id          bigint,
        @rule_detail                    [varchar](max),
        @rule_dt_created                smalldatetime,
        @rule_user_created              [varchar](max),
        @rule_source_attribute_id       [varchar](max),
        @SCDEndDate_final               datetime,
        @SCDActiveFlag                  char,
        @SCDVersion                     smallint,
        @SCDStartDate_initial           datetime,
        @maxPlanogramSiteRoleId         bigint,
        @maxSiteRoleId                  bigint,
        @maxPlanogramFloorPlanId        bigint,
        @maxPlanogram_childFloorPlanId  bigint,
        @maxPlanogramFloorPlanSectionId bigint,
        @l_tableName                    [varchar](max),
        @l_serveETLRunLogID             [varchar](max),
        @l_psaEntityId                  [varchar](max),
        @msg                            varchar(8000),
        @feed_entityid                  [varchar](max),
        @attributeid1                   [varchar](max),
        @attributeid2                   [varchar](max),
        @attr                           [varchar](max),
        @l_check_att                    VARCHAR(2000),
        @tablecolumns                   VARCHAR(500),
        @exec_sql                       VARCHAR(1000);
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];
        END
    IF OBJECT_ID('psa.TmpPSATable') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[TmpPSATable];
        END

    /**********Creating a temporary table to iterate through all the asset IDs present in PSA table********/
    CREATE TABLE [psa].[fixture_cursor_table]
        (
            [RowID]    bigint,
            [asset_id] int
        );
    BEGIN

        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'StoreNumber'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[StoreNumber]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBFamilyKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBFamilyKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBFamilyKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPSecDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPSecDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPSecDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @SCDDefaultEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31')
            );
        SET @LOVRecordSourceID = 1800052563;
        SET @rlsLOVRecordSourceID = 12012;
        SET @psaRowStatus = 26001;
        SET @serRowStatus = 26002;
        SET @duplicateRowStatus = 26010;
        SET @SCDLOVRecordSourceID = @LOVRecordSourceID;
        SET @SCDStartDate_initial =
            (
                SELECT
                    CONVERT(datetime, '1900-01-01 00:00:00')
            )
        SET @SCDEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31 00:00:00')
            )
        SET @SCDActiveFlag = 'Y'
        SET @SCDVersion = 1
        SET @SCDEndDate_final = DATEADD(second, -1, @SCDStartDate)
        SET @LOVSourceKeyTypeID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                where
                    r.LOVKey = 'BY Planogram Family Key' --'BY Planogram Key'
                    AND r.LOVSetName = 'Source Key Type'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        SET @MeasureId =
            (
                SELECT
                    m.MeasureID
                FROM
                    [ser].[Measure] m
                WHERE
                    m.MeasureName = 'shelf_number'
                    AND m.LOVRECORDSOURCEID = @LOVRecordSourceID
                    AND m.SCDActiveFlag = 'Y'
            );
        SET @LOVUOMID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                WHERE
                    r.LOVKey = 'Unknown'
                    AND r.LOVSetName = 'Unit Of Measure'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        BEGIN TRY
            SET @COUNTER = 1
            SELECT
                @MAXID = COUNT(distinct asset_id)
            FROM
                [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf
            WHERE
                row_status = @psaRowStatus;
            print 'Total Number of Loops : ' + cast(@MAXID as varchar) + '';

            --select * from [psa].[fixture_cursor_table]
            INSERT INTO [psa].[fixture_cursor_table]
                        SELECT DISTINCT
                            DENSE_RANK() OVER (ORDER BY (asset_id)) AS RowID,
                            asset_id                                as asset_id
                        FROM
                            [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                        WHERE
                            row_status = @psaRowStatus;
            WHILE (@COUNTER <= @MAXID)
                BEGIN
                    Print 'The loop count is ' + cast(@COUNTER as varchar);
                    SELECT
                        @asset_id = asset_id
                    from
                        [psa].[fixture_cursor_table]
                    where
                        RowID = @COUNTER;
                    PRINT 'Current Asset ID: ' + CAST(@asset_id as varchar) + '';

                    --select * from ser.PlanogramSiteRole
                    SET @SCDStartDate = current_timestamp;
                    PRINT '****************Inserting into SiteRole Table Started *********************';
                    SET @maxSiteRoleId =
                        (
                            SELECT
                                COALESCE(MAX(SiteRoleId), 0)
                            FROM
                                [ser].SiteRole
                        )
                    SET @tablecolumns
                        = '[SiteRoleId]' + ',[SiteId]' + ',[LOVRoleId]' + ',[SourceKey]' + ',[LOVSourceKeyTypeId]'
                          + ',[SiteRoleName]' + ',[SiteRoleShortName]' + ',[LOVRecordSourceId]' + ',[SCDStartDate]'
                          + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]' + ',[SCDLOVRecordSourceId]'
                          + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: SiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_siterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_siterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns + ' INTO #RPRS_Merch_Store_siterole FROM [ser].[SiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_siterole
                                SELECT
                                    SiteRoleId,
                                    SiteId,
                                    LOVRoleId,
                                    SourceKey,
                                    LOVSourceKeyTypeId,
                                    SiteRoleName,
                                    SiteRoleShortName,
                                    LovRecordSourceID,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as SiteRoleId,
                                            '-1'                  SiteId,
                                            '159000007'           LOVRoleId,
                                            ixf.storenumber       SourceKey,
                                            NULL                  LOVSourceKeyTypeId,
                                            NULL                  SiteRoleName,
                                            NULL                  SiteRoleShortName,
                                            '12008'               LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr st
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                    and not exists
                                                    (
                                                        select
                                                            1
                                                        from
                                                            ser.SiteRole temp
                                                        where
                                                            st.storenumber = temp.Sourcekey
                                                            and temp.LOVRoleId = '159000007'
                                                            and temp.LOVRecordSourceId = '12008'
                                                            and temp.SCDActiveFlag = 'Y'
                                                    )
                                                group by
                                                    storenumber
                                            ) ixf
                                    ) a;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_siterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'SiteRole',
                        @l_table_bus_pk = N'SourceKey,LOVRoleId,LovRecordSourceID',
                        @l_table_pk = N'SiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in SiteRole Table *********************';
                    PRINT '****************Inserting into PlanogramSiteRole Table *********************';
                    SET @tablecolumns
                        = '[PlanogramSiteRoleId]' + ',[PlanogramId]' + ',[SiteRoleId]' + ',[LOVRecordSourceId]'
                          + ',[SCDStartDate]' + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]'
                          + ',[SCDLOVRecordSourceId]' + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: PlanogramSiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_Plansiterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_Plansiterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_Plansiterole FROM [ser].[PlanogramSiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_Plansiterole
                                SELECT
                                    PlanogramSiteRoleId,
                                    PlanogramId,
                                    SiteRoleId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as PlanogramSiteRoleId,
                                            p.PlanogramID         PlanogramID,
                                            s.SiteRoleId          SiteRoleId,
                                            ixf.record_source_id  LOVRecordSourceID,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id,
                                                    min(row_id) row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id
                                            )                     ixf
                                            JOIN
                                                [ser].[Planogram] p
                                                    on ixf.POGDBFamilyKey = p.SourceKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = @LOVRecordSourceID
                                                       AND p.SCDActiveFlag = 'Y'
                                            join
                                                ser.siterole      s
                                                    on s.sourcekey = ixf.StoreNumber
                                                       and s.LOVRecordSourceId = '12008'
                                                       AND s.SCDActiveFlag = 'Y'
                                                       and s.LOVRoleId = '159000007'
                                                       and not exists
                                                                   (
                                                                       select
                                                                           1
                                                                       from
                                                                           ser.PlanogramSiteRole temp
                                                                       where
                                                                           ixf.POGDBFamilyKey = p.SourceKey
                                                                           and p.PlanogramID = temp.PlanogramID
                                                                           and s.SiteRoleId = temp.SiteRoleId
                                                                           and temp.LOVRecordSourceId = '1800052563'
                                                                           and p.scdactiveflag = 'Y'
                                                                           and temp.SCDActiveFlag = 'Y'
                                                                   )
                                    ) b;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_Plansiterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramSiteRole',
                        @l_table_bus_pk = N'PlanogramID,SiteRoleId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramSiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramSiteRole Table *********************';
                    ----Delete Added 	
                    /*     UPDATE [ser].PlanogramSiteRole
   SET SCDEndDate =
   (
   SELECT DATEADD(second, -1, @SCDStartDate)
   ),
   SCDActiveFlag = 'N'
   from [ser].PlanogramSiteRole ps
   inner join (select storenumber, pogdbfamilykey,record_source_id, min(row_id) row_id from  [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
   where asset_id = @asset_id  AND row_status = @psaRowStatus and odsflag = 'DELETE'
   group by storenumber, pogdbfamilykey,record_source_id ) ixf
   JOIN [ser].[Planogram] p
   on ixf.POGDBFamilyKey = p.SourceKey
   and ps.PlanogramID=p.PlanogramID
   and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
   and p.LOVRecordSourceId = @LOVRecordSourceID
   AND p.SCDActiveFlag = 'Y'
   join ser.siterole s
   on s.sourcekey = ixf.StoreNumber
   and s.SiteRoleId= ps.SiteRoleId
   and s.LOVRecordSourceId = '12008'
   AND s.SCDActiveFlag = 'Y'
   and s.LOVRoleId = '159000007'
   where ps.SCDActiveFlag='Y'
   )
   */
                    PRINT '****************Insert Parent into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                     as PlanogramFloorPlanId,
                                            NULL                  ParentPlanogramId,
                                            NULL                  PlanogramSiteRoleId,
                                            '1800055636'          LOVSourceKeyTypeId,
                                            ixf.FPDBFamilyKey     SourceKey,
                                            NULL                  FloorPlanStartDate,
                                            NULL                  FloorPlanEndDate,
                                            NULL                  FloorLevel,
                                            NULL                  FloorPlanName,
                                            NULL                  ParentPlanogramFloorPlanId,
                                            '1800052563'          LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    FPDBFamilyKey,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBFamilyKey is not null
                                                    and FPDBFamilyKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    FPDBFamilyKey
                                            ) ixf
                                        where
                                            not exists
                                            (
                                                select
                                                    1
                                                from
                                                    ser.PlanogramFloorPlan temp
                                                where
                                                    ixf.FPDBFamilyKey = temp.Sourcekey
                                                    and temp.LOVSourceKeyTypeId = '1800055636'
                                                    and temp.LOVRecordSourceId = '1800052563'
                                                    and temp.SCDActiveFlag = 'Y'
                                                    and temp.ParentPlanogramFloorPlanId is null
                                                    and temp.ParentPlanogramId is null
                                            )
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';


                    PRINT '****************Completed Inserting Parent into PlanogramFloorPlan Table completed *********************';
                    SET @maxPlanogram_childFloorPlanId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanId), 0)
                            FROM
                                [ser].PlanogramFloorPlan
                        )
                    PRINT '****************Insert Child  into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                       as PlanogramFloorPlanId,
                                            p.planogramid           ParentPlanogramId,
                                            psr.PlanogramSiteRoleId PlanogramSiteRoleId,
                                            '1800055637'            LOVSourceKeyTypeId,
                                            ixf.FPDBKey             SourceKey,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveFrom = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveFrom
                                             END
                                            )                       FloorPlanStartDate,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveTo = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveTo
                                             END
                                            )                       FloorPlanEndDate,
                                            ixf.FPDesc2             FloorLevel,
                                            ixf.FPName              FloorPlanName,
                                            pf.PlanogramFloorPlanId ParentPlanogramFloorPlanId,
                                            '1800052563'            LOVRecordSourceId,
                                            -- @SCDStartDate SCDStartDate,
                                            NULL                    as [SCDStartDate],
                                            NULL                    as [SCDEndDate],
                                            NULL                    as [SCDActiveFlag],
                                            NULL                    as [SCDVersion],
                                            @SCDLOVRecordSourceId   SCDLOVRecordSourceID,
                                            @serveETLRunLogID       ETLRunLogID,
                                            ixf.row_id              PSARowKey
                                        FROM
                                            (
                                                select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2
                                            )                          ixf
                                            join
                                                ser.SiteRole           sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563'
                                            left join
                                                ser.PlanogramFloorPlan cpf
                                                    on cpf.sourcekey = ixf.FPDBKey
                                                       and cpf.LOVRecordSourceId = '1800052563'
                                                       and cpf.LOVSourceKeyTypeId = '1800055637'
                                                       and cpf.ParentPlanogramFloorPlanId is not NULL
                                                       and cpf.SCDActiveFlag = 'Y'
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';
					
					
					PRINT '****************Process DELETE  records in PlanogramFloorPlanSection Table *********************';


update ser.PlanogramFloorPlansection  set scdactiveflag= 'N' ,SCDEndDate =(
                    SELECT DATEADD(second, -1, @SCDStartDate)                )
from ser.PlanogramFloorPlansection sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and ixf.FPSecDBKey =sec.sourcekey
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


	PRINT '****************Process DELETE  records in PlanogramFloorPlanStatus Table *********************';

---komal scdenddate
/*
update ser.PlanogramFloorPlanStatus  set scdactiveflag= 'N' ,SCDEndDate =( SELECT DATEADD(second, -1, @SCDStartDate))
from ser.PlanogramFloorPlanStatus sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


*/

PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';


---komalscdenddate
/*
update ser.PlanogramFloorPlan  set scdactiveflag= 'N' ,SCDEndDate =(SELECT DATEADD(second, -1, @SCDStartDate)
                )
from ser.PlanogramFloorPlan cpf
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and cpf.SCDActiveFlag = 'Y'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            --inner join
                                            --    ser.PlanogramFloorPlan pf
                                            --        on pf.sourcekey = ixf.FPDBFamilyKey
                                            --           and pf.LOVRecordSourceId = '1800052563'
                                            --           and pf.LOVSourceKeyTypeId = '1800055636'
                                            --           and pf.ParentPlanogramFloorPlanId is NULL 
                                            --           and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId
                                            
*/

PRINT '****************Closed DELETE records, if any, in PlanogramFloorPlan Table *********************';



                    PRINT '****************Start Inserting  into PlanogramFloorPlanSection Table completed *********************';
                    SET @maxPlanogramFloorPlanSectionId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanSectionId), 0)
                            FROM
                                [ser].PlanogramFloorPlanSection
                        );
                    SET @tablecolumns
                        = '[PlanogramFloorPlanSectionId]' + ',	[PlanogramFloorPlanId]'   + ',	[LOVSourceKeyTypeId]'
                          + ',	[SourceKey]' + ',	[SegmentStart]' + ',	[HostPlanogram]' + ',	[LOVRecordSourceId]'
                          + ',	[SCDStartDate]'  + ',	[SCDEndDate]'  + ',	[SCDActiveFlag]'  + ',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlanSection') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlanSection;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlanSection FROM [ser].[PlanogramFloorPlanSection]'
                    EXEC (@exec_sql)
					select * from [ser].[PlanogramFloorPlanSection]

Insert into #RPRS_Merch_Store_PlanogramFloorPlanSection
Select distinct
    0 as PlanogramFloorPlanSectionId,
    pfp.planogramfloorplanid PlanogramFloorPlanId,
    '1800055638' LOVSourceKeyTypeId,
    FPSecDBKey SourceKey,
    FPSecSegmentStart SegmentStart,
    FPSecHostPlanogram HostPlanogram,
    '1800052563' LOVRecordSourceId,
    NULL as [SCDStartDate],
    NULL as [SCDEndDate],
    NULL as [SCDActiveFlag],
    NULL as [SCDVersion],
	  @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
    row_id PSARowKey
FROM
(
    select FPDBKey,
           FPSecDBKey,
           FPSecSegmentStart,
           storenumber,
           POGDBFamilyKey,
           FPSecHostPlanogram,
           min(row_id) as row_id
    from [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
    where asset_id = @asset_id
          AND row_status = @psaRowStatus
          and odsflag <> 'DELETE'
    group by FPDBKey,
             FPSecDBKey,
             FPSecSegmentStart,
             storenumber,
             POGDBFamilyKey,
             FPSecHostPlanogram,
             FPSecHostPlanogram
) ixf
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanSection Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlanSection',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanSection',
                        @l_table_bus_pk = N'SourceKey,PlanogramFloorPlanId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanSectionId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '**************** SCD Load Complete, if any, in PlanogramFloorPlanSection Table *********************';


                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'

                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282117'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --  '200008' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = 'FPPendingDate'
                                                            AND LOVSetId = '282117'
                                                    )                        LOVStatusId,
                                                    ixf.FPPendingDate        EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                        select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate,
                                                    min(row_id) as row_id
                                                from
                                                   [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												 FPPendingDate is not null
                                                            and FPPendingDate != '' and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate
                                                    )                        ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                       
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVStatusId,SCDLOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  				  		  

										  

										  
PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';
                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;
					
					SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select distinct
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select distinct
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceId,
                                            ETLRunLogId,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282083'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --'200007' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = ixf.FPDBStatus
                                                            AND LOVSetId = '282083'
                                                    )                        LOVStatusId,
                                                    NULL                     EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                         select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												  FPDBStatus is not null
                                                            and FPDBStatus != ''
                                                            and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                   and asset_id = @asset_id   AND row_status = @psaRowStatus
												  -- and asset_id= 42134
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus
                                                    )  ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                        
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  
				  

                    UPDATE
                        [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                    SET
                        Row_Status = @serRowStatus
                    WHERE
                        row_Status = @psaRowStatus
                        AND asset_id = @asset_id;

                    SET @COUNTER = @COUNTER + 1;
                END
        --      COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            THROW;
        END CATCH
    END
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];

        END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_by_spc_Merch_store]    Script Date: 3/20/2023 12:27:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROC [psa].[sp_inc_uk_btc_by_spc_Merch_store] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS
    DECLARE
        @SCDLOVRecordSourceID           int,
        @psaETLRunLogID                 [varchar](max),
        @maxPlanogramFixtureID          bigint,
        @rlsLOVRecordSourceID           bigint,
        @SCDDefaultEndDate              datetime,
        @duplicateRowStatus             bigint,
        @LOVSourceKeyTypeID             bigint,
        @LOVRecordSourceID              bigint,
        @SCDStartDate                   datetime,
        @SCDEndDate                     datetime,
        @psaRowStatus                   bigint,
        @serRowStatus                   bigint,
        @DQCOUNTER                      bigint,
        @MeasureId                      bigint,
        @LOVUOMID                       bigint,
        @COUNTER                        bigint,
        @MAXID                          bigint,
        @rule_id                        int,
        @asset_id                       int,
        @max_PlanogramGroupId           bigint,
        @DQROWS                         bigint,
        @DQrowid                        bigint,
        @rule_entity_id                 bigint,
        @rule_attribute_id              bigint,
        @DQcolumn                       [varchar](max),
        @rule_source_entity_id          bigint,
        @rule_detail                    [varchar](max),
        @rule_dt_created                smalldatetime,
        @rule_user_created              [varchar](max),
        @rule_source_attribute_id       [varchar](max),
        @SCDEndDate_final               datetime,
        @SCDActiveFlag                  char,
        @SCDVersion                     smallint,
        @SCDStartDate_initial           datetime,
        @maxPlanogramSiteRoleId         bigint,
        @maxSiteRoleId                  bigint,
        @maxPlanogramFloorPlanId        bigint,
        @maxPlanogram_childFloorPlanId  bigint,
        @maxPlanogramFloorPlanSectionId bigint,
        @l_tableName                    [varchar](max),
        @l_serveETLRunLogID             [varchar](max),
        @l_psaEntityId                  [varchar](max),
        @msg                            varchar(8000),
        @feed_entityid                  [varchar](max),
        @attributeid1                   [varchar](max),
        @attributeid2                   [varchar](max),
        @attr                           [varchar](max),
        @l_check_att                    VARCHAR(2000),
        @tablecolumns                   VARCHAR(500),
        @exec_sql                       VARCHAR(1000);
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];
        END
    IF OBJECT_ID('psa.TmpPSATable') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[TmpPSATable];
        END

    /**********Creating a temporary table to iterate through all the asset IDs present in PSA table********/
    CREATE TABLE [psa].[fixture_cursor_table]
        (
            [RowID]    bigint,
            [asset_id] int
        );
    BEGIN

        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'StoreNumber'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[StoreNumber]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBFamilyKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBFamilyKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBFamilyKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPSecDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPSecDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPSecDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @SCDDefaultEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31')
            );
        SET @LOVRecordSourceID = 1800052563;
        SET @rlsLOVRecordSourceID = 12012;
        SET @psaRowStatus = 26001;
        SET @serRowStatus = 26002;
        SET @duplicateRowStatus = 26010;
        SET @SCDLOVRecordSourceID = @LOVRecordSourceID;
        SET @SCDStartDate_initial =
            (
                SELECT
                    CONVERT(datetime, '1900-01-01 00:00:00')
            )
        SET @SCDEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31 00:00:00')
            )
        SET @SCDActiveFlag = 'Y'
        SET @SCDVersion = 1
        SET @SCDEndDate_final = DATEADD(second, -1, @SCDStartDate)
        SET @LOVSourceKeyTypeID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                where
                    r.LOVKey = 'BY Planogram Family Key' --'BY Planogram Key'
                    AND r.LOVSetName = 'Source Key Type'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        SET @MeasureId =
            (
                SELECT
                    m.MeasureID
                FROM
                    [ser].[Measure] m
                WHERE
                    m.MeasureName = 'shelf_number'
                    AND m.LOVRECORDSOURCEID = @LOVRecordSourceID
                    AND m.SCDActiveFlag = 'Y'
            );
        SET @LOVUOMID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                WHERE
                    r.LOVKey = 'Unknown'
                    AND r.LOVSetName = 'Unit Of Measure'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        BEGIN TRY
            SET @COUNTER = 1
            SELECT
                @MAXID = COUNT(distinct asset_id)
            FROM
                [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf
            WHERE
                row_status = @psaRowStatus;
            print 'Total Number of Loops : ' + cast(@MAXID as varchar) + '';

            --select * from [psa].[fixture_cursor_table]
            INSERT INTO [psa].[fixture_cursor_table]
                        SELECT DISTINCT
                            DENSE_RANK() OVER (ORDER BY (asset_id)) AS RowID,
                            asset_id                                as asset_id
                        FROM
                            [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                        WHERE
                            row_status = @psaRowStatus;
            WHILE (@COUNTER <= @MAXID)
                BEGIN
                    Print 'The loop count is ' + cast(@COUNTER as varchar);
                    SELECT
                        @asset_id = asset_id
                    from
                        [psa].[fixture_cursor_table]
                    where
                        RowID = @COUNTER;
                    PRINT 'Current Asset ID: ' + CAST(@asset_id as varchar) + '';

                    --select * from ser.PlanogramSiteRole
                    SET @SCDStartDate = current_timestamp;
                    PRINT '****************Inserting into SiteRole Table Started *********************';
                    SET @maxSiteRoleId =
                        (
                            SELECT
                                COALESCE(MAX(SiteRoleId), 0)
                            FROM
                                [ser].SiteRole
                        )
                    SET @tablecolumns
                        = '[SiteRoleId]' + ',[SiteId]' + ',[LOVRoleId]' + ',[SourceKey]' + ',[LOVSourceKeyTypeId]'
                          + ',[SiteRoleName]' + ',[SiteRoleShortName]' + ',[LOVRecordSourceId]' + ',[SCDStartDate]'
                          + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]' + ',[SCDLOVRecordSourceId]'
                          + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: SiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_siterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_siterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns + ' INTO #RPRS_Merch_Store_siterole FROM [ser].[SiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_siterole
                                SELECT
                                    SiteRoleId,
                                    SiteId,
                                    LOVRoleId,
                                    SourceKey,
                                    LOVSourceKeyTypeId,
                                    SiteRoleName,
                                    SiteRoleShortName,
                                    LovRecordSourceID,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as SiteRoleId,
                                            '-1'                  SiteId,
                                            '159000007'           LOVRoleId,
                                            ixf.storenumber       SourceKey,
                                            NULL                  LOVSourceKeyTypeId,
                                            NULL                  SiteRoleName,
                                            NULL                  SiteRoleShortName,
                                            '12008'               LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr st
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                    and not exists
                                                    (
                                                        select
                                                            1
                                                        from
                                                            ser.SiteRole temp
                                                        where
                                                            st.storenumber = temp.Sourcekey
                                                            and temp.LOVRoleId = '159000007'
                                                            and temp.LOVRecordSourceId = '12008'
                                                            and temp.SCDActiveFlag = 'Y'
                                                    )
                                                group by
                                                    storenumber
                                            ) ixf
                                    ) a;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_siterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'SiteRole',
                        @l_table_bus_pk = N'SourceKey,LOVRoleId,LovRecordSourceID',
                        @l_table_pk = N'SiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in SiteRole Table *********************';
                    PRINT '****************Inserting into PlanogramSiteRole Table *********************';
                    SET @tablecolumns
                        = '[PlanogramSiteRoleId]' + ',[PlanogramId]' + ',[SiteRoleId]' + ',[LOVRecordSourceId]'
                          + ',[SCDStartDate]' + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]'
                          + ',[SCDLOVRecordSourceId]' + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: PlanogramSiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_Plansiterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_Plansiterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_Plansiterole FROM [ser].[PlanogramSiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_Plansiterole
                                SELECT
                                    PlanogramSiteRoleId,
                                    PlanogramId,
                                    SiteRoleId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as PlanogramSiteRoleId,
                                            p.PlanogramID         PlanogramID,
                                            s.SiteRoleId          SiteRoleId,
                                            ixf.record_source_id  LOVRecordSourceID,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id,
                                                    min(row_id) row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id
                                            )                     ixf
                                            JOIN
                                                [ser].[Planogram] p
                                                    on ixf.POGDBFamilyKey = p.SourceKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = @LOVRecordSourceID
                                                       AND p.SCDActiveFlag = 'Y'
                                            join
                                                ser.siterole      s
                                                    on s.sourcekey = ixf.StoreNumber
                                                       and s.LOVRecordSourceId = '12008'
                                                       AND s.SCDActiveFlag = 'Y'
                                                       and s.LOVRoleId = '159000007'
                                                       and not exists
                                                                   (
                                                                       select
                                                                           1
                                                                       from
                                                                           ser.PlanogramSiteRole temp
                                                                       where
                                                                           ixf.POGDBFamilyKey = p.SourceKey
                                                                           and p.PlanogramID = temp.PlanogramID
                                                                           and s.SiteRoleId = temp.SiteRoleId
                                                                           and temp.LOVRecordSourceId = '1800052563'
                                                                           and p.scdactiveflag = 'Y'
                                                                           and temp.SCDActiveFlag = 'Y'
                                                                   )
                                    ) b;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_Plansiterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramSiteRole',
                        @l_table_bus_pk = N'PlanogramID,SiteRoleId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramSiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramSiteRole Table *********************';
                    ----Delete Added 	
                    /*     UPDATE [ser].PlanogramSiteRole
   SET SCDEndDate =
   (
   SELECT DATEADD(second, -1, @SCDStartDate)
   ),
   SCDActiveFlag = 'N'
   from [ser].PlanogramSiteRole ps
   inner join (select storenumber, pogdbfamilykey,record_source_id, min(row_id) row_id from  [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
   where asset_id = @asset_id  AND row_status = @psaRowStatus and odsflag = 'DELETE'
   group by storenumber, pogdbfamilykey,record_source_id ) ixf
   JOIN [ser].[Planogram] p
   on ixf.POGDBFamilyKey = p.SourceKey
   and ps.PlanogramID=p.PlanogramID
   and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
   and p.LOVRecordSourceId = @LOVRecordSourceID
   AND p.SCDActiveFlag = 'Y'
   join ser.siterole s
   on s.sourcekey = ixf.StoreNumber
   and s.SiteRoleId= ps.SiteRoleId
   and s.LOVRecordSourceId = '12008'
   AND s.SCDActiveFlag = 'Y'
   and s.LOVRoleId = '159000007'
   where ps.SCDActiveFlag='Y'
   )
   */
                    PRINT '****************Insert Parent into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                     as PlanogramFloorPlanId,
                                            NULL                  ParentPlanogramId,
                                            NULL                  PlanogramSiteRoleId,
                                            '1800055636'          LOVSourceKeyTypeId,
                                            ixf.FPDBFamilyKey     SourceKey,
                                            NULL                  FloorPlanStartDate,
                                            NULL                  FloorPlanEndDate,
                                            NULL                  FloorLevel,
                                            NULL                  FloorPlanName,
                                            NULL                  ParentPlanogramFloorPlanId,
                                            '1800052563'          LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    FPDBFamilyKey,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBFamilyKey is not null
                                                    and FPDBFamilyKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    FPDBFamilyKey
                                            ) ixf
                                        where
                                            not exists
                                            (
                                                select
                                                    1
                                                from
                                                    ser.PlanogramFloorPlan temp
                                                where
                                                    ixf.FPDBFamilyKey = temp.Sourcekey
                                                    and temp.LOVSourceKeyTypeId = '1800055636'
                                                    and temp.LOVRecordSourceId = '1800052563'
                                                    and temp.SCDActiveFlag = 'Y'
                                                    and temp.ParentPlanogramFloorPlanId is null
                                                    and temp.ParentPlanogramId is null
                                            )
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';


                    PRINT '****************Completed Inserting Parent into PlanogramFloorPlan Table completed *********************';
                    SET @maxPlanogram_childFloorPlanId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanId), 0)
                            FROM
                                [ser].PlanogramFloorPlan
                        )
                    PRINT '****************Insert Child  into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                       as PlanogramFloorPlanId,
                                            p.planogramid           ParentPlanogramId,
                                            psr.PlanogramSiteRoleId PlanogramSiteRoleId,
                                            '1800055637'            LOVSourceKeyTypeId,
                                            ixf.FPDBKey             SourceKey,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveFrom = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveFrom
                                             END
                                            )                       FloorPlanStartDate,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveTo = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveTo
                                             END
                                            )                       FloorPlanEndDate,
                                            ixf.FPDesc2             FloorLevel,
                                            ixf.FPName              FloorPlanName,
                                            pf.PlanogramFloorPlanId ParentPlanogramFloorPlanId,
                                            '1800052563'            LOVRecordSourceId,
                                            -- @SCDStartDate SCDStartDate,
                                            NULL                    as [SCDStartDate],
                                            NULL                    as [SCDEndDate],
                                            NULL                    as [SCDActiveFlag],
                                            NULL                    as [SCDVersion],
                                            @SCDLOVRecordSourceId   SCDLOVRecordSourceID,
                                            @serveETLRunLogID       ETLRunLogID,
                                            ixf.row_id              PSARowKey
                                        FROM
                                            (
                                                select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2
                                            )                          ixf
                                            join
                                                ser.SiteRole           sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563'
                                            left join
                                                ser.PlanogramFloorPlan cpf
                                                    on cpf.sourcekey = ixf.FPDBKey
                                                       and cpf.LOVRecordSourceId = '1800052563'
                                                       and cpf.LOVSourceKeyTypeId = '1800055637'
                                                       and cpf.ParentPlanogramFloorPlanId is not NULL
                                                       and cpf.SCDActiveFlag = 'Y'
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';
					
					
					PRINT '****************Process DELETE  records in PlanogramFloorPlanSection Table *********************';


update ser.PlanogramFloorPlansection  set scdactiveflag= 'N' ,SCDEndDate =(
                    SELECT DATEADD(second, -1, @SCDStartDate)                )
from ser.PlanogramFloorPlansection sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and ixf.FPSecDBKey =sec.sourcekey
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


	PRINT '****************Process DELETE  records in PlanogramFloorPlanStatus Table *********************';

---komal scdenddate
/*
update ser.PlanogramFloorPlanStatus  set scdactiveflag= 'N' ,SCDEndDate =( SELECT DATEADD(second, -1, @SCDStartDate))
from ser.PlanogramFloorPlanStatus sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


*/

PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';


---komalscdenddate
/*
update ser.PlanogramFloorPlan  set scdactiveflag= 'N' ,SCDEndDate =(SELECT DATEADD(second, -1, @SCDStartDate)
                )
from ser.PlanogramFloorPlan cpf
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and cpf.SCDActiveFlag = 'Y'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            --inner join
                                            --    ser.PlanogramFloorPlan pf
                                            --        on pf.sourcekey = ixf.FPDBFamilyKey
                                            --           and pf.LOVRecordSourceId = '1800052563'
                                            --           and pf.LOVSourceKeyTypeId = '1800055636'
                                            --           and pf.ParentPlanogramFloorPlanId is NULL 
                                            --           and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId
                                            
*/

PRINT '****************Closed DELETE records, if any, in PlanogramFloorPlan Table *********************';



                    PRINT '****************Start Inserting  into PlanogramFloorPlanSection Table completed *********************';
                    SET @maxPlanogramFloorPlanSectionId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanSectionId), 0)
                            FROM
                                [ser].PlanogramFloorPlanSection
                        );
                    SET @tablecolumns
                        = '[PlanogramFloorPlanSectionId]' + ',	[PlanogramFloorPlanId]'   + ',	[LOVSourceKeyTypeId]'
                          + ',	[SourceKey]' + ',	[SegmentStart]' + ',	[HostPlanogram]' + ',	[LOVRecordSourceId]'
                          + ',	[SCDStartDate]'  + ',	[SCDEndDate]'  + ',	[SCDActiveFlag]'  + ',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlanSection') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlanSection;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlanSection FROM [ser].[PlanogramFloorPlanSection]'
                    EXEC (@exec_sql)
					select * from [ser].[PlanogramFloorPlanSection]

Insert into #RPRS_Merch_Store_PlanogramFloorPlanSection
Select distinct
    0 as PlanogramFloorPlanSectionId,
    pfp.planogramfloorplanid PlanogramFloorPlanId,
    '1800055638' LOVSourceKeyTypeId,
    FPSecDBKey SourceKey,
    FPSecSegmentStart SegmentStart,
    FPSecHostPlanogram HostPlanogram,
    '1800052563' LOVRecordSourceId,
    NULL as [SCDStartDate],
    NULL as [SCDEndDate],
    NULL as [SCDActiveFlag],
    NULL as [SCDVersion],
	  @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
    row_id PSARowKey
FROM
(
    select FPDBKey,
           FPSecDBKey,
           FPSecSegmentStart,
           storenumber,
           POGDBFamilyKey,
           FPSecHostPlanogram,
           min(row_id) as row_id
    from [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
    where asset_id = @asset_id
          AND row_status = @psaRowStatus
          and odsflag <> 'DELETE'
    group by FPDBKey,
             FPSecDBKey,
             FPSecSegmentStart,
             storenumber,
             POGDBFamilyKey,
             FPSecHostPlanogram,
             FPSecHostPlanogram
) ixf
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanSection Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlanSection',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanSection',
                        @l_table_bus_pk = N'SourceKey,PlanogramFloorPlanId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanSectionId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '**************** SCD Load Complete, if any, in PlanogramFloorPlanSection Table *********************';


                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'

                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282117'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --  '200008' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = 'FPPendingDate'
                                                            AND LOVSetId = '282117'
                                                    )                        LOVStatusId,
                                                    ixf.FPPendingDate        EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                        select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate,
                                                    min(row_id) as row_id
                                                from
                                                   [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												 FPPendingDate is not null
                                                            and FPPendingDate != '' and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate
                                                    )                        ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                       
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVStatusId,SCDLOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  				  		  

										  

										  
PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';
                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;
					
					SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select distinct
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select distinct
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceId,
                                            ETLRunLogId,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282083'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --'200007' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = ixf.FPDBStatus
                                                            AND LOVSetId = '282083'
                                                    )                        LOVStatusId,
                                                    NULL                     EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                         select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												  FPDBStatus is not null
                                                            and FPDBStatus != ''
                                                            and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                   and asset_id = @asset_id   AND row_status = @psaRowStatus
												  -- and asset_id= 42134
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus
                                                    )  ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                        
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  
				  

                    UPDATE
                        [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                    SET
                        Row_Status = @serRowStatus
                    WHERE
                        row_Status = @psaRowStatus
                        AND asset_id = @asset_id;

                    SET @COUNTER = @COUNTER + 1;
                END
        --      COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            THROW;
        END CATCH
    END
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];

        END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_by_spc_Merch_store]    Script Date: 3/20/2023 12:27:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROC [psa].[sp_inc_uk_btc_by_spc_Merch_store] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS
    DECLARE
        @SCDLOVRecordSourceID           int,
        @psaETLRunLogID                 [varchar](max),
        @maxPlanogramFixtureID          bigint,
        @rlsLOVRecordSourceID           bigint,
        @SCDDefaultEndDate              datetime,
        @duplicateRowStatus             bigint,
        @LOVSourceKeyTypeID             bigint,
        @LOVRecordSourceID              bigint,
        @SCDStartDate                   datetime,
        @SCDEndDate                     datetime,
        @psaRowStatus                   bigint,
        @serRowStatus                   bigint,
        @DQCOUNTER                      bigint,
        @MeasureId                      bigint,
        @LOVUOMID                       bigint,
        @COUNTER                        bigint,
        @MAXID                          bigint,
        @rule_id                        int,
        @asset_id                       int,
        @max_PlanogramGroupId           bigint,
        @DQROWS                         bigint,
        @DQrowid                        bigint,
        @rule_entity_id                 bigint,
        @rule_attribute_id              bigint,
        @DQcolumn                       [varchar](max),
        @rule_source_entity_id          bigint,
        @rule_detail                    [varchar](max),
        @rule_dt_created                smalldatetime,
        @rule_user_created              [varchar](max),
        @rule_source_attribute_id       [varchar](max),
        @SCDEndDate_final               datetime,
        @SCDActiveFlag                  char,
        @SCDVersion                     smallint,
        @SCDStartDate_initial           datetime,
        @maxPlanogramSiteRoleId         bigint,
        @maxSiteRoleId                  bigint,
        @maxPlanogramFloorPlanId        bigint,
        @maxPlanogram_childFloorPlanId  bigint,
        @maxPlanogramFloorPlanSectionId bigint,
        @l_tableName                    [varchar](max),
        @l_serveETLRunLogID             [varchar](max),
        @l_psaEntityId                  [varchar](max),
        @msg                            varchar(8000),
        @feed_entityid                  [varchar](max),
        @attributeid1                   [varchar](max),
        @attributeid2                   [varchar](max),
        @attr                           [varchar](max),
        @l_check_att                    VARCHAR(2000),
        @tablecolumns                   VARCHAR(500),
        @exec_sql                       VARCHAR(1000);
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];
        END
    IF OBJECT_ID('psa.TmpPSATable') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[TmpPSATable];
        END

    /**********Creating a temporary table to iterate through all the asset IDs present in PSA table********/
    CREATE TABLE [psa].[fixture_cursor_table]
        (
            [RowID]    bigint,
            [asset_id] int
        );
    BEGIN

        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'StoreNumber'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[StoreNumber]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBFamilyKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBFamilyKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBFamilyKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPSecDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPSecDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPSecDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @SCDDefaultEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31')
            );
        SET @LOVRecordSourceID = 1800052563;
        SET @rlsLOVRecordSourceID = 12012;
        SET @psaRowStatus = 26001;
        SET @serRowStatus = 26002;
        SET @duplicateRowStatus = 26010;
        SET @SCDLOVRecordSourceID = @LOVRecordSourceID;
        SET @SCDStartDate_initial =
            (
                SELECT
                    CONVERT(datetime, '1900-01-01 00:00:00')
            )
        SET @SCDEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31 00:00:00')
            )
        SET @SCDActiveFlag = 'Y'
        SET @SCDVersion = 1
        SET @SCDEndDate_final = DATEADD(second, -1, @SCDStartDate)
        SET @LOVSourceKeyTypeID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                where
                    r.LOVKey = 'BY Planogram Family Key' --'BY Planogram Key'
                    AND r.LOVSetName = 'Source Key Type'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        SET @MeasureId =
            (
                SELECT
                    m.MeasureID
                FROM
                    [ser].[Measure] m
                WHERE
                    m.MeasureName = 'shelf_number'
                    AND m.LOVRECORDSOURCEID = @LOVRecordSourceID
                    AND m.SCDActiveFlag = 'Y'
            );
        SET @LOVUOMID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                WHERE
                    r.LOVKey = 'Unknown'
                    AND r.LOVSetName = 'Unit Of Measure'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        BEGIN TRY
            SET @COUNTER = 1
            SELECT
                @MAXID = COUNT(distinct asset_id)
            FROM
                [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf
            WHERE
                row_status = @psaRowStatus;
            print 'Total Number of Loops : ' + cast(@MAXID as varchar) + '';

            --select * from [psa].[fixture_cursor_table]
            INSERT INTO [psa].[fixture_cursor_table]
                        SELECT DISTINCT
                            DENSE_RANK() OVER (ORDER BY (asset_id)) AS RowID,
                            asset_id                                as asset_id
                        FROM
                            [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                        WHERE
                            row_status = @psaRowStatus;
            WHILE (@COUNTER <= @MAXID)
                BEGIN
                    Print 'The loop count is ' + cast(@COUNTER as varchar);
                    SELECT
                        @asset_id = asset_id
                    from
                        [psa].[fixture_cursor_table]
                    where
                        RowID = @COUNTER;
                    PRINT 'Current Asset ID: ' + CAST(@asset_id as varchar) + '';

                    --select * from ser.PlanogramSiteRole
                    SET @SCDStartDate = current_timestamp;
                    PRINT '****************Inserting into SiteRole Table Started *********************';
                    SET @maxSiteRoleId =
                        (
                            SELECT
                                COALESCE(MAX(SiteRoleId), 0)
                            FROM
                                [ser].SiteRole
                        )
                    SET @tablecolumns
                        = '[SiteRoleId]' + ',[SiteId]' + ',[LOVRoleId]' + ',[SourceKey]' + ',[LOVSourceKeyTypeId]'
                          + ',[SiteRoleName]' + ',[SiteRoleShortName]' + ',[LOVRecordSourceId]' + ',[SCDStartDate]'
                          + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]' + ',[SCDLOVRecordSourceId]'
                          + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: SiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_siterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_siterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns + ' INTO #RPRS_Merch_Store_siterole FROM [ser].[SiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_siterole
                                SELECT
                                    SiteRoleId,
                                    SiteId,
                                    LOVRoleId,
                                    SourceKey,
                                    LOVSourceKeyTypeId,
                                    SiteRoleName,
                                    SiteRoleShortName,
                                    LovRecordSourceID,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as SiteRoleId,
                                            '-1'                  SiteId,
                                            '159000007'           LOVRoleId,
                                            ixf.storenumber       SourceKey,
                                            NULL                  LOVSourceKeyTypeId,
                                            NULL                  SiteRoleName,
                                            NULL                  SiteRoleShortName,
                                            '12008'               LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr st
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                    and not exists
                                                    (
                                                        select
                                                            1
                                                        from
                                                            ser.SiteRole temp
                                                        where
                                                            st.storenumber = temp.Sourcekey
                                                            and temp.LOVRoleId = '159000007'
                                                            and temp.LOVRecordSourceId = '12008'
                                                            and temp.SCDActiveFlag = 'Y'
                                                    )
                                                group by
                                                    storenumber
                                            ) ixf
                                    ) a;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_siterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'SiteRole',
                        @l_table_bus_pk = N'SourceKey,LOVRoleId,LovRecordSourceID',
                        @l_table_pk = N'SiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in SiteRole Table *********************';
                    PRINT '****************Inserting into PlanogramSiteRole Table *********************';
                    SET @tablecolumns
                        = '[PlanogramSiteRoleId]' + ',[PlanogramId]' + ',[SiteRoleId]' + ',[LOVRecordSourceId]'
                          + ',[SCDStartDate]' + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]'
                          + ',[SCDLOVRecordSourceId]' + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: PlanogramSiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_Plansiterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_Plansiterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_Plansiterole FROM [ser].[PlanogramSiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_Plansiterole
                                SELECT
                                    PlanogramSiteRoleId,
                                    PlanogramId,
                                    SiteRoleId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as PlanogramSiteRoleId,
                                            p.PlanogramID         PlanogramID,
                                            s.SiteRoleId          SiteRoleId,
                                            ixf.record_source_id  LOVRecordSourceID,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id,
                                                    min(row_id) row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id
                                            )                     ixf
                                            JOIN
                                                [ser].[Planogram] p
                                                    on ixf.POGDBFamilyKey = p.SourceKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = @LOVRecordSourceID
                                                       AND p.SCDActiveFlag = 'Y'
                                            join
                                                ser.siterole      s
                                                    on s.sourcekey = ixf.StoreNumber
                                                       and s.LOVRecordSourceId = '12008'
                                                       AND s.SCDActiveFlag = 'Y'
                                                       and s.LOVRoleId = '159000007'
                                                       and not exists
                                                                   (
                                                                       select
                                                                           1
                                                                       from
                                                                           ser.PlanogramSiteRole temp
                                                                       where
                                                                           ixf.POGDBFamilyKey = p.SourceKey
                                                                           and p.PlanogramID = temp.PlanogramID
                                                                           and s.SiteRoleId = temp.SiteRoleId
                                                                           and temp.LOVRecordSourceId = '1800052563'
                                                                           and p.scdactiveflag = 'Y'
                                                                           and temp.SCDActiveFlag = 'Y'
                                                                   )
                                    ) b;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_Plansiterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramSiteRole',
                        @l_table_bus_pk = N'PlanogramID,SiteRoleId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramSiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramSiteRole Table *********************';
                    ----Delete Added 	
                    /*     UPDATE [ser].PlanogramSiteRole
   SET SCDEndDate =
   (
   SELECT DATEADD(second, -1, @SCDStartDate)
   ),
   SCDActiveFlag = 'N'
   from [ser].PlanogramSiteRole ps
   inner join (select storenumber, pogdbfamilykey,record_source_id, min(row_id) row_id from  [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
   where asset_id = @asset_id  AND row_status = @psaRowStatus and odsflag = 'DELETE'
   group by storenumber, pogdbfamilykey,record_source_id ) ixf
   JOIN [ser].[Planogram] p
   on ixf.POGDBFamilyKey = p.SourceKey
   and ps.PlanogramID=p.PlanogramID
   and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
   and p.LOVRecordSourceId = @LOVRecordSourceID
   AND p.SCDActiveFlag = 'Y'
   join ser.siterole s
   on s.sourcekey = ixf.StoreNumber
   and s.SiteRoleId= ps.SiteRoleId
   and s.LOVRecordSourceId = '12008'
   AND s.SCDActiveFlag = 'Y'
   and s.LOVRoleId = '159000007'
   where ps.SCDActiveFlag='Y'
   )
   */
                    PRINT '****************Insert Parent into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                     as PlanogramFloorPlanId,
                                            NULL                  ParentPlanogramId,
                                            NULL                  PlanogramSiteRoleId,
                                            '1800055636'          LOVSourceKeyTypeId,
                                            ixf.FPDBFamilyKey     SourceKey,
                                            NULL                  FloorPlanStartDate,
                                            NULL                  FloorPlanEndDate,
                                            NULL                  FloorLevel,
                                            NULL                  FloorPlanName,
                                            NULL                  ParentPlanogramFloorPlanId,
                                            '1800052563'          LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    FPDBFamilyKey,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBFamilyKey is not null
                                                    and FPDBFamilyKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    FPDBFamilyKey
                                            ) ixf
                                        where
                                            not exists
                                            (
                                                select
                                                    1
                                                from
                                                    ser.PlanogramFloorPlan temp
                                                where
                                                    ixf.FPDBFamilyKey = temp.Sourcekey
                                                    and temp.LOVSourceKeyTypeId = '1800055636'
                                                    and temp.LOVRecordSourceId = '1800052563'
                                                    and temp.SCDActiveFlag = 'Y'
                                                    and temp.ParentPlanogramFloorPlanId is null
                                                    and temp.ParentPlanogramId is null
                                            )
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';


                    PRINT '****************Completed Inserting Parent into PlanogramFloorPlan Table completed *********************';
                    SET @maxPlanogram_childFloorPlanId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanId), 0)
                            FROM
                                [ser].PlanogramFloorPlan
                        )
                    PRINT '****************Insert Child  into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                       as PlanogramFloorPlanId,
                                            p.planogramid           ParentPlanogramId,
                                            psr.PlanogramSiteRoleId PlanogramSiteRoleId,
                                            '1800055637'            LOVSourceKeyTypeId,
                                            ixf.FPDBKey             SourceKey,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveFrom = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveFrom
                                             END
                                            )                       FloorPlanStartDate,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveTo = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveTo
                                             END
                                            )                       FloorPlanEndDate,
                                            ixf.FPDesc2             FloorLevel,
                                            ixf.FPName              FloorPlanName,
                                            pf.PlanogramFloorPlanId ParentPlanogramFloorPlanId,
                                            '1800052563'            LOVRecordSourceId,
                                            -- @SCDStartDate SCDStartDate,
                                            NULL                    as [SCDStartDate],
                                            NULL                    as [SCDEndDate],
                                            NULL                    as [SCDActiveFlag],
                                            NULL                    as [SCDVersion],
                                            @SCDLOVRecordSourceId   SCDLOVRecordSourceID,
                                            @serveETLRunLogID       ETLRunLogID,
                                            ixf.row_id              PSARowKey
                                        FROM
                                            (
                                                select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2
                                            )                          ixf
                                            join
                                                ser.SiteRole           sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563'
                                            left join
                                                ser.PlanogramFloorPlan cpf
                                                    on cpf.sourcekey = ixf.FPDBKey
                                                       and cpf.LOVRecordSourceId = '1800052563'
                                                       and cpf.LOVSourceKeyTypeId = '1800055637'
                                                       and cpf.ParentPlanogramFloorPlanId is not NULL
                                                       and cpf.SCDActiveFlag = 'Y'
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';
					
					
					PRINT '****************Process DELETE  records in PlanogramFloorPlanSection Table *********************';


update ser.PlanogramFloorPlansection  set scdactiveflag= 'N' ,SCDEndDate =(
                    SELECT DATEADD(second, -1, @SCDStartDate)                )
from ser.PlanogramFloorPlansection sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and ixf.FPSecDBKey =sec.sourcekey
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


	PRINT '****************Process DELETE  records in PlanogramFloorPlanStatus Table *********************';

---komal scdenddate
/*
update ser.PlanogramFloorPlanStatus  set scdactiveflag= 'N' ,SCDEndDate =( SELECT DATEADD(second, -1, @SCDStartDate))
from ser.PlanogramFloorPlanStatus sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


*/

PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';


---komalscdenddate
/*
update ser.PlanogramFloorPlan  set scdactiveflag= 'N' ,SCDEndDate =(SELECT DATEADD(second, -1, @SCDStartDate)
                )
from ser.PlanogramFloorPlan cpf
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and cpf.SCDActiveFlag = 'Y'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            --inner join
                                            --    ser.PlanogramFloorPlan pf
                                            --        on pf.sourcekey = ixf.FPDBFamilyKey
                                            --           and pf.LOVRecordSourceId = '1800052563'
                                            --           and pf.LOVSourceKeyTypeId = '1800055636'
                                            --           and pf.ParentPlanogramFloorPlanId is NULL 
                                            --           and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId
                                            
*/

PRINT '****************Closed DELETE records, if any, in PlanogramFloorPlan Table *********************';



                    PRINT '****************Start Inserting  into PlanogramFloorPlanSection Table completed *********************';
                    SET @maxPlanogramFloorPlanSectionId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanSectionId), 0)
                            FROM
                                [ser].PlanogramFloorPlanSection
                        );
                    SET @tablecolumns
                        = '[PlanogramFloorPlanSectionId]' + ',	[PlanogramFloorPlanId]'   + ',	[LOVSourceKeyTypeId]'
                          + ',	[SourceKey]' + ',	[SegmentStart]' + ',	[HostPlanogram]' + ',	[LOVRecordSourceId]'
                          + ',	[SCDStartDate]'  + ',	[SCDEndDate]'  + ',	[SCDActiveFlag]'  + ',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlanSection') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlanSection;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlanSection FROM [ser].[PlanogramFloorPlanSection]'
                    EXEC (@exec_sql)
					select * from [ser].[PlanogramFloorPlanSection]

Insert into #RPRS_Merch_Store_PlanogramFloorPlanSection
Select distinct
    0 as PlanogramFloorPlanSectionId,
    pfp.planogramfloorplanid PlanogramFloorPlanId,
    '1800055638' LOVSourceKeyTypeId,
    FPSecDBKey SourceKey,
    FPSecSegmentStart SegmentStart,
    FPSecHostPlanogram HostPlanogram,
    '1800052563' LOVRecordSourceId,
    NULL as [SCDStartDate],
    NULL as [SCDEndDate],
    NULL as [SCDActiveFlag],
    NULL as [SCDVersion],
	  @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
    row_id PSARowKey
FROM
(
    select FPDBKey,
           FPSecDBKey,
           FPSecSegmentStart,
           storenumber,
           POGDBFamilyKey,
           FPSecHostPlanogram,
           min(row_id) as row_id
    from [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
    where asset_id = @asset_id
          AND row_status = @psaRowStatus
          and odsflag <> 'DELETE'
    group by FPDBKey,
             FPSecDBKey,
             FPSecSegmentStart,
             storenumber,
             POGDBFamilyKey,
             FPSecHostPlanogram,
             FPSecHostPlanogram
) ixf
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanSection Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlanSection',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanSection',
                        @l_table_bus_pk = N'SourceKey,PlanogramFloorPlanId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanSectionId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '**************** SCD Load Complete, if any, in PlanogramFloorPlanSection Table *********************';


                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'

                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282117'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --  '200008' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = 'FPPendingDate'
                                                            AND LOVSetId = '282117'
                                                    )                        LOVStatusId,
                                                    ixf.FPPendingDate        EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                        select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate,
                                                    min(row_id) as row_id
                                                from
                                                   [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												 FPPendingDate is not null
                                                            and FPPendingDate != '' and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate
                                                    )                        ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                       
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVStatusId,SCDLOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  				  		  

										  

										  
PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';
                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;
					
					SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select distinct
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select distinct
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceId,
                                            ETLRunLogId,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282083'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --'200007' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = ixf.FPDBStatus
                                                            AND LOVSetId = '282083'
                                                    )                        LOVStatusId,
                                                    NULL                     EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                         select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												  FPDBStatus is not null
                                                            and FPDBStatus != ''
                                                            and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                   and asset_id = @asset_id   AND row_status = @psaRowStatus
												  -- and asset_id= 42134
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus
                                                    )  ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                        
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  
				  

                    UPDATE
                        [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                    SET
                        Row_Status = @serRowStatus
                    WHERE
                        row_Status = @psaRowStatus
                        AND asset_id = @asset_id;

                    SET @COUNTER = @COUNTER + 1;
                END
        --      COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            THROW;
        END CATCH
    END
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];

        END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_by_spc_Merch_store]    Script Date: 3/20/2023 12:27:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROC [psa].[sp_inc_uk_btc_by_spc_Merch_store] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS
    DECLARE
        @SCDLOVRecordSourceID           int,
        @psaETLRunLogID                 [varchar](max),
        @maxPlanogramFixtureID          bigint,
        @rlsLOVRecordSourceID           bigint,
        @SCDDefaultEndDate              datetime,
        @duplicateRowStatus             bigint,
        @LOVSourceKeyTypeID             bigint,
        @LOVRecordSourceID              bigint,
        @SCDStartDate                   datetime,
        @SCDEndDate                     datetime,
        @psaRowStatus                   bigint,
        @serRowStatus                   bigint,
        @DQCOUNTER                      bigint,
        @MeasureId                      bigint,
        @LOVUOMID                       bigint,
        @COUNTER                        bigint,
        @MAXID                          bigint,
        @rule_id                        int,
        @asset_id                       int,
        @max_PlanogramGroupId           bigint,
        @DQROWS                         bigint,
        @DQrowid                        bigint,
        @rule_entity_id                 bigint,
        @rule_attribute_id              bigint,
        @DQcolumn                       [varchar](max),
        @rule_source_entity_id          bigint,
        @rule_detail                    [varchar](max),
        @rule_dt_created                smalldatetime,
        @rule_user_created              [varchar](max),
        @rule_source_attribute_id       [varchar](max),
        @SCDEndDate_final               datetime,
        @SCDActiveFlag                  char,
        @SCDVersion                     smallint,
        @SCDStartDate_initial           datetime,
        @maxPlanogramSiteRoleId         bigint,
        @maxSiteRoleId                  bigint,
        @maxPlanogramFloorPlanId        bigint,
        @maxPlanogram_childFloorPlanId  bigint,
        @maxPlanogramFloorPlanSectionId bigint,
        @l_tableName                    [varchar](max),
        @l_serveETLRunLogID             [varchar](max),
        @l_psaEntityId                  [varchar](max),
        @msg                            varchar(8000),
        @feed_entityid                  [varchar](max),
        @attributeid1                   [varchar](max),
        @attributeid2                   [varchar](max),
        @attr                           [varchar](max),
        @l_check_att                    VARCHAR(2000),
        @tablecolumns                   VARCHAR(500),
        @exec_sql                       VARCHAR(1000);
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];
        END
    IF OBJECT_ID('psa.TmpPSATable') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[TmpPSATable];
        END

    /**********Creating a temporary table to iterate through all the asset IDs present in PSA table********/
    CREATE TABLE [psa].[fixture_cursor_table]
        (
            [RowID]    bigint,
            [asset_id] int
        );
    BEGIN

        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'StoreNumber'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[StoreNumber]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBFamilyKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBFamilyKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBFamilyKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPSecDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPSecDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPSecDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @SCDDefaultEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31')
            );
        SET @LOVRecordSourceID = 1800052563;
        SET @rlsLOVRecordSourceID = 12012;
        SET @psaRowStatus = 26001;
        SET @serRowStatus = 26002;
        SET @duplicateRowStatus = 26010;
        SET @SCDLOVRecordSourceID = @LOVRecordSourceID;
        SET @SCDStartDate_initial =
            (
                SELECT
                    CONVERT(datetime, '1900-01-01 00:00:00')
            )
        SET @SCDEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31 00:00:00')
            )
        SET @SCDActiveFlag = 'Y'
        SET @SCDVersion = 1
        SET @SCDEndDate_final = DATEADD(second, -1, @SCDStartDate)
        SET @LOVSourceKeyTypeID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                where
                    r.LOVKey = 'BY Planogram Family Key' --'BY Planogram Key'
                    AND r.LOVSetName = 'Source Key Type'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        SET @MeasureId =
            (
                SELECT
                    m.MeasureID
                FROM
                    [ser].[Measure] m
                WHERE
                    m.MeasureName = 'shelf_number'
                    AND m.LOVRECORDSOURCEID = @LOVRecordSourceID
                    AND m.SCDActiveFlag = 'Y'
            );
        SET @LOVUOMID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                WHERE
                    r.LOVKey = 'Unknown'
                    AND r.LOVSetName = 'Unit Of Measure'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        BEGIN TRY
            SET @COUNTER = 1
            SELECT
                @MAXID = COUNT(distinct asset_id)
            FROM
                [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf
            WHERE
                row_status = @psaRowStatus;
            print 'Total Number of Loops : ' + cast(@MAXID as varchar) + '';

            --select * from [psa].[fixture_cursor_table]
            INSERT INTO [psa].[fixture_cursor_table]
                        SELECT DISTINCT
                            DENSE_RANK() OVER (ORDER BY (asset_id)) AS RowID,
                            asset_id                                as asset_id
                        FROM
                            [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                        WHERE
                            row_status = @psaRowStatus;
            WHILE (@COUNTER <= @MAXID)
                BEGIN
                    Print 'The loop count is ' + cast(@COUNTER as varchar);
                    SELECT
                        @asset_id = asset_id
                    from
                        [psa].[fixture_cursor_table]
                    where
                        RowID = @COUNTER;
                    PRINT 'Current Asset ID: ' + CAST(@asset_id as varchar) + '';

                    --select * from ser.PlanogramSiteRole
                    SET @SCDStartDate = current_timestamp;
                    PRINT '****************Inserting into SiteRole Table Started *********************';
                    SET @maxSiteRoleId =
                        (
                            SELECT
                                COALESCE(MAX(SiteRoleId), 0)
                            FROM
                                [ser].SiteRole
                        )
                    SET @tablecolumns
                        = '[SiteRoleId]' + ',[SiteId]' + ',[LOVRoleId]' + ',[SourceKey]' + ',[LOVSourceKeyTypeId]'
                          + ',[SiteRoleName]' + ',[SiteRoleShortName]' + ',[LOVRecordSourceId]' + ',[SCDStartDate]'
                          + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]' + ',[SCDLOVRecordSourceId]'
                          + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: SiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_siterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_siterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns + ' INTO #RPRS_Merch_Store_siterole FROM [ser].[SiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_siterole
                                SELECT
                                    SiteRoleId,
                                    SiteId,
                                    LOVRoleId,
                                    SourceKey,
                                    LOVSourceKeyTypeId,
                                    SiteRoleName,
                                    SiteRoleShortName,
                                    LovRecordSourceID,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as SiteRoleId,
                                            '-1'                  SiteId,
                                            '159000007'           LOVRoleId,
                                            ixf.storenumber       SourceKey,
                                            NULL                  LOVSourceKeyTypeId,
                                            NULL                  SiteRoleName,
                                            NULL                  SiteRoleShortName,
                                            '12008'               LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr st
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                    and not exists
                                                    (
                                                        select
                                                            1
                                                        from
                                                            ser.SiteRole temp
                                                        where
                                                            st.storenumber = temp.Sourcekey
                                                            and temp.LOVRoleId = '159000007'
                                                            and temp.LOVRecordSourceId = '12008'
                                                            and temp.SCDActiveFlag = 'Y'
                                                    )
                                                group by
                                                    storenumber
                                            ) ixf
                                    ) a;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_siterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'SiteRole',
                        @l_table_bus_pk = N'SourceKey,LOVRoleId,LovRecordSourceID',
                        @l_table_pk = N'SiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in SiteRole Table *********************';
                    PRINT '****************Inserting into PlanogramSiteRole Table *********************';
                    SET @tablecolumns
                        = '[PlanogramSiteRoleId]' + ',[PlanogramId]' + ',[SiteRoleId]' + ',[LOVRecordSourceId]'
                          + ',[SCDStartDate]' + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]'
                          + ',[SCDLOVRecordSourceId]' + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: PlanogramSiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_Plansiterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_Plansiterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_Plansiterole FROM [ser].[PlanogramSiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_Plansiterole
                                SELECT
                                    PlanogramSiteRoleId,
                                    PlanogramId,
                                    SiteRoleId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as PlanogramSiteRoleId,
                                            p.PlanogramID         PlanogramID,
                                            s.SiteRoleId          SiteRoleId,
                                            ixf.record_source_id  LOVRecordSourceID,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id,
                                                    min(row_id) row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id
                                            )                     ixf
                                            JOIN
                                                [ser].[Planogram] p
                                                    on ixf.POGDBFamilyKey = p.SourceKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = @LOVRecordSourceID
                                                       AND p.SCDActiveFlag = 'Y'
                                            join
                                                ser.siterole      s
                                                    on s.sourcekey = ixf.StoreNumber
                                                       and s.LOVRecordSourceId = '12008'
                                                       AND s.SCDActiveFlag = 'Y'
                                                       and s.LOVRoleId = '159000007'
                                                       and not exists
                                                                   (
                                                                       select
                                                                           1
                                                                       from
                                                                           ser.PlanogramSiteRole temp
                                                                       where
                                                                           ixf.POGDBFamilyKey = p.SourceKey
                                                                           and p.PlanogramID = temp.PlanogramID
                                                                           and s.SiteRoleId = temp.SiteRoleId
                                                                           and temp.LOVRecordSourceId = '1800052563'
                                                                           and p.scdactiveflag = 'Y'
                                                                           and temp.SCDActiveFlag = 'Y'
                                                                   )
                                    ) b;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_Plansiterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramSiteRole',
                        @l_table_bus_pk = N'PlanogramID,SiteRoleId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramSiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramSiteRole Table *********************';
                    ----Delete Added 	
                    /*     UPDATE [ser].PlanogramSiteRole
   SET SCDEndDate =
   (
   SELECT DATEADD(second, -1, @SCDStartDate)
   ),
   SCDActiveFlag = 'N'
   from [ser].PlanogramSiteRole ps
   inner join (select storenumber, pogdbfamilykey,record_source_id, min(row_id) row_id from  [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
   where asset_id = @asset_id  AND row_status = @psaRowStatus and odsflag = 'DELETE'
   group by storenumber, pogdbfamilykey,record_source_id ) ixf
   JOIN [ser].[Planogram] p
   on ixf.POGDBFamilyKey = p.SourceKey
   and ps.PlanogramID=p.PlanogramID
   and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
   and p.LOVRecordSourceId = @LOVRecordSourceID
   AND p.SCDActiveFlag = 'Y'
   join ser.siterole s
   on s.sourcekey = ixf.StoreNumber
   and s.SiteRoleId= ps.SiteRoleId
   and s.LOVRecordSourceId = '12008'
   AND s.SCDActiveFlag = 'Y'
   and s.LOVRoleId = '159000007'
   where ps.SCDActiveFlag='Y'
   )
   */
                    PRINT '****************Insert Parent into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                     as PlanogramFloorPlanId,
                                            NULL                  ParentPlanogramId,
                                            NULL                  PlanogramSiteRoleId,
                                            '1800055636'          LOVSourceKeyTypeId,
                                            ixf.FPDBFamilyKey     SourceKey,
                                            NULL                  FloorPlanStartDate,
                                            NULL                  FloorPlanEndDate,
                                            NULL                  FloorLevel,
                                            NULL                  FloorPlanName,
                                            NULL                  ParentPlanogramFloorPlanId,
                                            '1800052563'          LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    FPDBFamilyKey,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBFamilyKey is not null
                                                    and FPDBFamilyKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    FPDBFamilyKey
                                            ) ixf
                                        where
                                            not exists
                                            (
                                                select
                                                    1
                                                from
                                                    ser.PlanogramFloorPlan temp
                                                where
                                                    ixf.FPDBFamilyKey = temp.Sourcekey
                                                    and temp.LOVSourceKeyTypeId = '1800055636'
                                                    and temp.LOVRecordSourceId = '1800052563'
                                                    and temp.SCDActiveFlag = 'Y'
                                                    and temp.ParentPlanogramFloorPlanId is null
                                                    and temp.ParentPlanogramId is null
                                            )
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';


                    PRINT '****************Completed Inserting Parent into PlanogramFloorPlan Table completed *********************';
                    SET @maxPlanogram_childFloorPlanId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanId), 0)
                            FROM
                                [ser].PlanogramFloorPlan
                        )
                    PRINT '****************Insert Child  into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                       as PlanogramFloorPlanId,
                                            p.planogramid           ParentPlanogramId,
                                            psr.PlanogramSiteRoleId PlanogramSiteRoleId,
                                            '1800055637'            LOVSourceKeyTypeId,
                                            ixf.FPDBKey             SourceKey,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveFrom = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveFrom
                                             END
                                            )                       FloorPlanStartDate,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveTo = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveTo
                                             END
                                            )                       FloorPlanEndDate,
                                            ixf.FPDesc2             FloorLevel,
                                            ixf.FPName              FloorPlanName,
                                            pf.PlanogramFloorPlanId ParentPlanogramFloorPlanId,
                                            '1800052563'            LOVRecordSourceId,
                                            -- @SCDStartDate SCDStartDate,
                                            NULL                    as [SCDStartDate],
                                            NULL                    as [SCDEndDate],
                                            NULL                    as [SCDActiveFlag],
                                            NULL                    as [SCDVersion],
                                            @SCDLOVRecordSourceId   SCDLOVRecordSourceID,
                                            @serveETLRunLogID       ETLRunLogID,
                                            ixf.row_id              PSARowKey
                                        FROM
                                            (
                                                select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2
                                            )                          ixf
                                            join
                                                ser.SiteRole           sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563'
                                            left join
                                                ser.PlanogramFloorPlan cpf
                                                    on cpf.sourcekey = ixf.FPDBKey
                                                       and cpf.LOVRecordSourceId = '1800052563'
                                                       and cpf.LOVSourceKeyTypeId = '1800055637'
                                                       and cpf.ParentPlanogramFloorPlanId is not NULL
                                                       and cpf.SCDActiveFlag = 'Y'
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';
					
					
					PRINT '****************Process DELETE  records in PlanogramFloorPlanSection Table *********************';


update ser.PlanogramFloorPlansection  set scdactiveflag= 'N' ,SCDEndDate =(
                    SELECT DATEADD(second, -1, @SCDStartDate)                )
from ser.PlanogramFloorPlansection sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and ixf.FPSecDBKey =sec.sourcekey
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


	PRINT '****************Process DELETE  records in PlanogramFloorPlanStatus Table *********************';

---komal scdenddate
/*
update ser.PlanogramFloorPlanStatus  set scdactiveflag= 'N' ,SCDEndDate =( SELECT DATEADD(second, -1, @SCDStartDate))
from ser.PlanogramFloorPlanStatus sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


*/

PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';


---komalscdenddate
/*
update ser.PlanogramFloorPlan  set scdactiveflag= 'N' ,SCDEndDate =(SELECT DATEADD(second, -1, @SCDStartDate)
                )
from ser.PlanogramFloorPlan cpf
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and cpf.SCDActiveFlag = 'Y'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            --inner join
                                            --    ser.PlanogramFloorPlan pf
                                            --        on pf.sourcekey = ixf.FPDBFamilyKey
                                            --           and pf.LOVRecordSourceId = '1800052563'
                                            --           and pf.LOVSourceKeyTypeId = '1800055636'
                                            --           and pf.ParentPlanogramFloorPlanId is NULL 
                                            --           and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId
                                            
*/

PRINT '****************Closed DELETE records, if any, in PlanogramFloorPlan Table *********************';



                    PRINT '****************Start Inserting  into PlanogramFloorPlanSection Table completed *********************';
                    SET @maxPlanogramFloorPlanSectionId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanSectionId), 0)
                            FROM
                                [ser].PlanogramFloorPlanSection
                        );
                    SET @tablecolumns
                        = '[PlanogramFloorPlanSectionId]' + ',	[PlanogramFloorPlanId]'   + ',	[LOVSourceKeyTypeId]'
                          + ',	[SourceKey]' + ',	[SegmentStart]' + ',	[HostPlanogram]' + ',	[LOVRecordSourceId]'
                          + ',	[SCDStartDate]'  + ',	[SCDEndDate]'  + ',	[SCDActiveFlag]'  + ',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlanSection') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlanSection;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlanSection FROM [ser].[PlanogramFloorPlanSection]'
                    EXEC (@exec_sql)
					select * from [ser].[PlanogramFloorPlanSection]

Insert into #RPRS_Merch_Store_PlanogramFloorPlanSection
Select distinct
    0 as PlanogramFloorPlanSectionId,
    pfp.planogramfloorplanid PlanogramFloorPlanId,
    '1800055638' LOVSourceKeyTypeId,
    FPSecDBKey SourceKey,
    FPSecSegmentStart SegmentStart,
    FPSecHostPlanogram HostPlanogram,
    '1800052563' LOVRecordSourceId,
    NULL as [SCDStartDate],
    NULL as [SCDEndDate],
    NULL as [SCDActiveFlag],
    NULL as [SCDVersion],
	  @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
    row_id PSARowKey
FROM
(
    select FPDBKey,
           FPSecDBKey,
           FPSecSegmentStart,
           storenumber,
           POGDBFamilyKey,
           FPSecHostPlanogram,
           min(row_id) as row_id
    from [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
    where asset_id = @asset_id
          AND row_status = @psaRowStatus
          and odsflag <> 'DELETE'
    group by FPDBKey,
             FPSecDBKey,
             FPSecSegmentStart,
             storenumber,
             POGDBFamilyKey,
             FPSecHostPlanogram,
             FPSecHostPlanogram
) ixf
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanSection Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlanSection',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanSection',
                        @l_table_bus_pk = N'SourceKey,PlanogramFloorPlanId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanSectionId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '**************** SCD Load Complete, if any, in PlanogramFloorPlanSection Table *********************';


                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'

                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282117'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --  '200008' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = 'FPPendingDate'
                                                            AND LOVSetId = '282117'
                                                    )                        LOVStatusId,
                                                    ixf.FPPendingDate        EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                        select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate,
                                                    min(row_id) as row_id
                                                from
                                                   [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												 FPPendingDate is not null
                                                            and FPPendingDate != '' and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate
                                                    )                        ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                       
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVStatusId,SCDLOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  				  		  

										  

										  
PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';
                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;
					
					SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select distinct
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select distinct
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceId,
                                            ETLRunLogId,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282083'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --'200007' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = ixf.FPDBStatus
                                                            AND LOVSetId = '282083'
                                                    )                        LOVStatusId,
                                                    NULL                     EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                         select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												  FPDBStatus is not null
                                                            and FPDBStatus != ''
                                                            and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                   and asset_id = @asset_id   AND row_status = @psaRowStatus
												  -- and asset_id= 42134
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus
                                                    )  ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                        
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  
				  

                    UPDATE
                        [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                    SET
                        Row_Status = @serRowStatus
                    WHERE
                        row_Status = @psaRowStatus
                        AND asset_id = @asset_id;

                    SET @COUNTER = @COUNTER + 1;
                END
        --      COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            THROW;
        END CATCH
    END
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];

        END
GO

/****** Object:  StoredProcedure [psa].[sp_inc_uk_btc_by_spc_Merch_store]    Script Date: 3/20/2023 12:27:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER PROC [psa].[sp_inc_uk_btc_by_spc_Merch_store] @tableName [VARCHAR](max),@serveETLRunLogID [VARCHAR](max),@psaEntityId [varchar](max) AS
    DECLARE
        @SCDLOVRecordSourceID           int,
        @psaETLRunLogID                 [varchar](max),
        @maxPlanogramFixtureID          bigint,
        @rlsLOVRecordSourceID           bigint,
        @SCDDefaultEndDate              datetime,
        @duplicateRowStatus             bigint,
        @LOVSourceKeyTypeID             bigint,
        @LOVRecordSourceID              bigint,
        @SCDStartDate                   datetime,
        @SCDEndDate                     datetime,
        @psaRowStatus                   bigint,
        @serRowStatus                   bigint,
        @DQCOUNTER                      bigint,
        @MeasureId                      bigint,
        @LOVUOMID                       bigint,
        @COUNTER                        bigint,
        @MAXID                          bigint,
        @rule_id                        int,
        @asset_id                       int,
        @max_PlanogramGroupId           bigint,
        @DQROWS                         bigint,
        @DQrowid                        bigint,
        @rule_entity_id                 bigint,
        @rule_attribute_id              bigint,
        @DQcolumn                       [varchar](max),
        @rule_source_entity_id          bigint,
        @rule_detail                    [varchar](max),
        @rule_dt_created                smalldatetime,
        @rule_user_created              [varchar](max),
        @rule_source_attribute_id       [varchar](max),
        @SCDEndDate_final               datetime,
        @SCDActiveFlag                  char,
        @SCDVersion                     smallint,
        @SCDStartDate_initial           datetime,
        @maxPlanogramSiteRoleId         bigint,
        @maxSiteRoleId                  bigint,
        @maxPlanogramFloorPlanId        bigint,
        @maxPlanogram_childFloorPlanId  bigint,
        @maxPlanogramFloorPlanSectionId bigint,
        @l_tableName                    [varchar](max),
        @l_serveETLRunLogID             [varchar](max),
        @l_psaEntityId                  [varchar](max),
        @msg                            varchar(8000),
        @feed_entityid                  [varchar](max),
        @attributeid1                   [varchar](max),
        @attributeid2                   [varchar](max),
        @attr                           [varchar](max),
        @l_check_att                    VARCHAR(2000),
        @tablecolumns                   VARCHAR(500),
        @exec_sql                       VARCHAR(1000);
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];
        END
    IF OBJECT_ID('psa.TmpPSATable') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[TmpPSATable];
        END

    /**********Creating a temporary table to iterate through all the asset IDs present in PSA table********/
    CREATE TABLE [psa].[fixture_cursor_table]
        (
            [RowID]    bigint,
            [asset_id] int
        );
    BEGIN

        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'StoreNumber'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[StoreNumber]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBFamilyKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in StoreNumber column'
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBFamilyKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBFamilyKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @l_tableName = @tableName
        SET @l_serveETLRunLogID = @serveETLRunLogID
        SET @l_psaEntityId = @psaEntityId
        SET @l_psaEntityId =
            (
                select
                    max(entityid)
                from
                    psa.entity
                where
                    entityname = 'BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr'
                    and schemaname = 'psa'
            )
        SET @feed_entityid =
            (
                select
                    sourceentityid
                from
                    psa.[MappingEntity] me
                    inner join
                        psa.[Entity]    e
                            on me.sourceentityid = e.EntityID
                where
                    me.[TargetEntityID] = @l_psaEntityId
                    and e.SchemaName like '%feed%'
            );
        PRINT 'Feed Entity ID : ' + @feed_entityid
        SET @attributeid1 =
            (
                SELECT
                    AttributeId
                FROM
                    psa.Attribute
                WHERE
                    attributename = 'FPSecDBKey'
                    AND entityid = @feed_entityid
            );
        Print 'Attribute 1 : ' + @attributeid1
        PRINT 'Info: Quarantine the records if NULL OR No length string values in FPSecDBKey column'
        EXEC [psa].[sp_inc_perform_quarantine]
            @tableName = 'psa.[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]',
            @rule = 'DL',
            @columnName = '[FPSecDBKey]',
            @columnType = N'varchar',
            @psaEntityId = @psaEntityId,
            @attributeid = @attributeid1,
            @attr = @attributeid1,
            @serveETLRunLogID = @serveETLRunLogID
        SET @SCDDefaultEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31')
            );
        SET @LOVRecordSourceID = 1800052563;
        SET @rlsLOVRecordSourceID = 12012;
        SET @psaRowStatus = 26001;
        SET @serRowStatus = 26002;
        SET @duplicateRowStatus = 26010;
        SET @SCDLOVRecordSourceID = @LOVRecordSourceID;
        SET @SCDStartDate_initial =
            (
                SELECT
                    CONVERT(datetime, '1900-01-01 00:00:00')
            )
        SET @SCDEndDate =
            (
                SELECT
                    CONVERT(datetime, '9999-12-31 00:00:00')
            )
        SET @SCDActiveFlag = 'Y'
        SET @SCDVersion = 1
        SET @SCDEndDate_final = DATEADD(second, -1, @SCDStartDate)
        SET @LOVSourceKeyTypeID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                where
                    r.LOVKey = 'BY Planogram Family Key' --'BY Planogram Key'
                    AND r.LOVSetName = 'Source Key Type'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        SET @MeasureId =
            (
                SELECT
                    m.MeasureID
                FROM
                    [ser].[Measure] m
                WHERE
                    m.MeasureName = 'shelf_number'
                    AND m.LOVRECORDSOURCEID = @LOVRecordSourceID
                    AND m.SCDActiveFlag = 'Y'
            );
        SET @LOVUOMID =
            (
                SELECT
                    r.LOVID
                FROM
                    [ser].[RefLOVSetInfo] r
                WHERE
                    r.LOVKey = 'Unknown'
                    AND r.LOVSetName = 'Unit Of Measure'
                    AND r.LOVRecordSourceID = @rlsLOVRecordSourceID
            );
        BEGIN TRY
            SET @COUNTER = 1
            SELECT
                @MAXID = COUNT(distinct asset_id)
            FROM
                [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf
            WHERE
                row_status = @psaRowStatus;
            print 'Total Number of Loops : ' + cast(@MAXID as varchar) + '';

            --select * from [psa].[fixture_cursor_table]
            INSERT INTO [psa].[fixture_cursor_table]
                        SELECT DISTINCT
                            DENSE_RANK() OVER (ORDER BY (asset_id)) AS RowID,
                            asset_id                                as asset_id
                        FROM
                            [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                        WHERE
                            row_status = @psaRowStatus;
            WHILE (@COUNTER <= @MAXID)
                BEGIN
                    Print 'The loop count is ' + cast(@COUNTER as varchar);
                    SELECT
                        @asset_id = asset_id
                    from
                        [psa].[fixture_cursor_table]
                    where
                        RowID = @COUNTER;
                    PRINT 'Current Asset ID: ' + CAST(@asset_id as varchar) + '';

                    --select * from ser.PlanogramSiteRole
                    SET @SCDStartDate = current_timestamp;
                    PRINT '****************Inserting into SiteRole Table Started *********************';
                    SET @maxSiteRoleId =
                        (
                            SELECT
                                COALESCE(MAX(SiteRoleId), 0)
                            FROM
                                [ser].SiteRole
                        )
                    SET @tablecolumns
                        = '[SiteRoleId]' + ',[SiteId]' + ',[LOVRoleId]' + ',[SourceKey]' + ',[LOVSourceKeyTypeId]'
                          + ',[SiteRoleName]' + ',[SiteRoleShortName]' + ',[LOVRecordSourceId]' + ',[SCDStartDate]'
                          + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]' + ',[SCDLOVRecordSourceId]'
                          + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: SiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_siterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_siterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns + ' INTO #RPRS_Merch_Store_siterole FROM [ser].[SiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_siterole
                                SELECT
                                    SiteRoleId,
                                    SiteId,
                                    LOVRoleId,
                                    SourceKey,
                                    LOVSourceKeyTypeId,
                                    SiteRoleName,
                                    SiteRoleShortName,
                                    LovRecordSourceID,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as SiteRoleId,
                                            '-1'                  SiteId,
                                            '159000007'           LOVRoleId,
                                            ixf.storenumber       SourceKey,
                                            NULL                  LOVSourceKeyTypeId,
                                            NULL                  SiteRoleName,
                                            NULL                  SiteRoleShortName,
                                            '12008'               LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr st
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                    and not exists
                                                    (
                                                        select
                                                            1
                                                        from
                                                            ser.SiteRole temp
                                                        where
                                                            st.storenumber = temp.Sourcekey
                                                            and temp.LOVRoleId = '159000007'
                                                            and temp.LOVRecordSourceId = '12008'
                                                            and temp.SCDActiveFlag = 'Y'
                                                    )
                                                group by
                                                    storenumber
                                            ) ixf
                                    ) a;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_siterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'SiteRole',
                        @l_table_bus_pk = N'SourceKey,LOVRoleId,LovRecordSourceID',
                        @l_table_pk = N'SiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in SiteRole Table *********************';
                    PRINT '****************Inserting into PlanogramSiteRole Table *********************';
                    SET @tablecolumns
                        = '[PlanogramSiteRoleId]' + ',[PlanogramId]' + ',[SiteRoleId]' + ',[LOVRecordSourceId]'
                          + ',[SCDStartDate]' + ',[SCDEndDate]' + ',[SCDActiveFlag]' + ',[SCDVersion]'
                          + ',[SCDLOVRecordSourceId]' + ',[ETLRunLogId]' + ',[PSARowKey]';
                    PRINT 'Info: PlanogramSiteRole Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_Plansiterole') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_Plansiterole;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_Plansiterole FROM [ser].[PlanogramSiteRole]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_Plansiterole
                                SELECT
                                    PlanogramSiteRoleId,
                                    PlanogramId,
                                    SiteRoleId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT
                                            0                     as PlanogramSiteRoleId,
                                            p.PlanogramID         PlanogramID,
                                            s.SiteRoleId          SiteRoleId,
                                            ixf.record_source_id  LOVRecordSourceID,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id,
                                                    min(row_id) row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    storenumber,
                                                    pogdbfamilykey,
                                                    record_source_id
                                            )                     ixf
                                            JOIN
                                                [ser].[Planogram] p
                                                    on ixf.POGDBFamilyKey = p.SourceKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = @LOVRecordSourceID
                                                       AND p.SCDActiveFlag = 'Y'
                                            join
                                                ser.siterole      s
                                                    on s.sourcekey = ixf.StoreNumber
                                                       and s.LOVRecordSourceId = '12008'
                                                       AND s.SCDActiveFlag = 'Y'
                                                       and s.LOVRoleId = '159000007'
                                                       and not exists
                                                                   (
                                                                       select
                                                                           1
                                                                       from
                                                                           ser.PlanogramSiteRole temp
                                                                       where
                                                                           ixf.POGDBFamilyKey = p.SourceKey
                                                                           and p.PlanogramID = temp.PlanogramID
                                                                           and s.SiteRoleId = temp.SiteRoleId
                                                                           and temp.LOVRecordSourceId = '1800052563'
                                                                           and p.scdactiveflag = 'Y'
                                                                           and temp.SCDActiveFlag = 'Y'
                                                                   )
                                    ) b;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_Plansiterole',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramSiteRole',
                        @l_table_bus_pk = N'PlanogramID,SiteRoleId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramSiteRoleId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramSiteRole Table *********************';
                    ----Delete Added 	
                    /*     UPDATE [ser].PlanogramSiteRole
   SET SCDEndDate =
   (
   SELECT DATEADD(second, -1, @SCDStartDate)
   ),
   SCDActiveFlag = 'N'
   from [ser].PlanogramSiteRole ps
   inner join (select storenumber, pogdbfamilykey,record_source_id, min(row_id) row_id from  [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
   where asset_id = @asset_id  AND row_status = @psaRowStatus and odsflag = 'DELETE'
   group by storenumber, pogdbfamilykey,record_source_id ) ixf
   JOIN [ser].[Planogram] p
   on ixf.POGDBFamilyKey = p.SourceKey
   and ps.PlanogramID=p.PlanogramID
   and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
   and p.LOVRecordSourceId = @LOVRecordSourceID
   AND p.SCDActiveFlag = 'Y'
   join ser.siterole s
   on s.sourcekey = ixf.StoreNumber
   and s.SiteRoleId= ps.SiteRoleId
   and s.LOVRecordSourceId = '12008'
   AND s.SCDActiveFlag = 'Y'
   and s.LOVRoleId = '159000007'
   where ps.SCDActiveFlag='Y'
   )
   */
                    PRINT '****************Insert Parent into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                     as PlanogramFloorPlanId,
                                            NULL                  ParentPlanogramId,
                                            NULL                  PlanogramSiteRoleId,
                                            '1800055636'          LOVSourceKeyTypeId,
                                            ixf.FPDBFamilyKey     SourceKey,
                                            NULL                  FloorPlanStartDate,
                                            NULL                  FloorPlanEndDate,
                                            NULL                  FloorLevel,
                                            NULL                  FloorPlanName,
                                            NULL                  ParentPlanogramFloorPlanId,
                                            '1800052563'          LOVRecordSourceId,
                                            NULL                  as [SCDStartDate],
                                            NULL                  as [SCDEndDate],
                                            NULL                  as [SCDActiveFlag],
                                            NULL                  as [SCDVersion],
                                            @SCDLOVRecordSourceId SCDLOVRecordSourceID,
                                            @serveETLRunLogID     ETLRunLogID,
                                            ixf.row_id            PSARowKey
                                        FROM
                                            (
                                                select
                                                    FPDBFamilyKey,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBFamilyKey is not null
                                                    and FPDBFamilyKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    FPDBFamilyKey
                                            ) ixf
                                        where
                                            not exists
                                            (
                                                select
                                                    1
                                                from
                                                    ser.PlanogramFloorPlan temp
                                                where
                                                    ixf.FPDBFamilyKey = temp.Sourcekey
                                                    and temp.LOVSourceKeyTypeId = '1800055636'
                                                    and temp.LOVRecordSourceId = '1800052563'
                                                    and temp.SCDActiveFlag = 'Y'
                                                    and temp.ParentPlanogramFloorPlanId is null
                                                    and temp.ParentPlanogramId is null
                                            )
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';


                    PRINT '****************Completed Inserting Parent into PlanogramFloorPlan Table completed *********************';
                    SET @maxPlanogram_childFloorPlanId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanId), 0)
                            FROM
                                [ser].PlanogramFloorPlan
                        )
                    PRINT '****************Insert Child  into  PlanogramFloorPlan Table *********************';
                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',	[ParentPlanogramId]'   + ',	[PlanogramSiteRoleId]'
                          + ',	[LOVSourceKeyTypeId]'+ ',	[SourceKey]'+ ',	[FloorPlanStartDate]'
                          + ',	[FloorPlanEndDate]' + ',	[FloorLevel]' + ',	[FloorPlanName]'
                          + ',	[ParentPlanogramFloorPlanId]'  + ',	[LOVRecordSourceId]'  + ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    PRINT 'Info: Child PlanogramFloorPlan Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlan') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlan;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlan FROM [ser].[PlanogramFloorPlan]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_PlanogramFloorPlan
                                SELECT
                                    PlanogramFloorPlanId,
                                    ParentPlanogramId,
                                    PlanogramSiteRoleId,
                                    LOVSourceKeyTypeId,
                                    SourceKey,
                                    FloorPlanStartDate,
                                    FloorPlanEndDate,
                                    FloorLevel,
                                    FloorPlanName,
                                    ParentPlanogramFloorPlanId,
                                    LOVRecordSourceId,
                                    SCDStartDate,
                                    SCDEndDate,
                                    SCDActiveFlag,
                                    SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                FROM
                                    (
                                        SELECT distinct
                                            0                       as PlanogramFloorPlanId,
                                            p.planogramid           ParentPlanogramId,
                                            psr.PlanogramSiteRoleId PlanogramSiteRoleId,
                                            '1800055637'            LOVSourceKeyTypeId,
                                            ixf.FPDBKey             SourceKey,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveFrom = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveFrom
                                             END
                                            )                       FloorPlanStartDate,
                                            (CASE
                                                 When ixf.FPDBDateEffectiveTo = ''
                                                     then NULL
                                                 ELSE
                                                     ixf.FPDBDateEffectiveTo
                                             END
                                            )                       FloorPlanEndDate,
                                            ixf.FPDesc2             FloorLevel,
                                            ixf.FPName              FloorPlanName,
                                            pf.PlanogramFloorPlanId ParentPlanogramFloorPlanId,
                                            '1800052563'            LOVRecordSourceId,
                                            -- @SCDStartDate SCDStartDate,
                                            NULL                    as [SCDStartDate],
                                            NULL                    as [SCDEndDate],
                                            NULL                    as [SCDActiveFlag],
                                            NULL                    as [SCDVersion],
                                            @SCDLOVRecordSourceId   SCDLOVRecordSourceID,
                                            @serveETLRunLogID       ETLRunLogID,
                                            ixf.row_id              PSARowKey
                                        FROM
                                            (
                                                select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
                                                where
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPName,
                                                    FPDBDateEffectiveFrom,
                                                    FPDBDateEffectiveTo,
                                                    FPDesc2
                                            )                          ixf
                                            join
                                                ser.SiteRole           sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563'
                                            left join
                                                ser.PlanogramFloorPlan cpf
                                                    on cpf.sourcekey = ixf.FPDBKey
                                                       and cpf.LOVRecordSourceId = '1800052563'
                                                       and cpf.LOVSourceKeyTypeId = '1800055637'
                                                       and cpf.ParentPlanogramFloorPlanId is not NULL
                                                       and cpf.SCDActiveFlag = 'Y'
                                    ) d;

                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlan',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlan',
                        @l_table_bus_pk = N'SourceKey,ParentPlanogramId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '****************Closed old records, if any, in PlanogramFloorPlan Table *********************';
					
					
					PRINT '****************Process DELETE  records in PlanogramFloorPlanSection Table *********************';


update ser.PlanogramFloorPlansection  set scdactiveflag= 'N' ,SCDEndDate =(
                    SELECT DATEADD(second, -1, @SCDStartDate)                )
from ser.PlanogramFloorPlansection sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and ixf.FPSecDBKey =sec.sourcekey
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


	PRINT '****************Process DELETE  records in PlanogramFloorPlanStatus Table *********************';

---komal scdenddate
/*
update ser.PlanogramFloorPlanStatus  set scdactiveflag= 'N' ,SCDEndDate =( SELECT DATEADD(second, -1, @SCDStartDate))
from ser.PlanogramFloorPlanStatus sec
inner join  ser.PlanogramFloorPlan cpf on sec.PlanogramFloorPlanId= cpf.PlanogramFloorPlanId and sec.SCDActiveFlag = 'Y' and cpf.SCDActiveFlag = 'Y'
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            inner join
                                                ser.PlanogramFloorPlan pf
                                                    on pf.sourcekey = ixf.FPDBFamilyKey
                                                       and pf.LOVRecordSourceId = '1800052563'
                                                       and pf.LOVSourceKeyTypeId = '1800055636'
                                                       and pf.ParentPlanogramFloorPlanId is NULL 
                                                       and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId


*/

PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';


---komalscdenddate
/*
update ser.PlanogramFloorPlan  set scdactiveflag= 'N' ,SCDEndDate =(SELECT DATEADD(second, -1, @SCDStartDate)
                )
from ser.PlanogramFloorPlan cpf
inner join [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr ixf 
		on cpf.sourcekey = ixf.FPDBKey and cpf.LOVRecordSourceId = '1800052563'
		and cpf.LOVSourceKeyTypeId = '1800055637' and cpf.SCDActiveFlag = 'Y'
		and cpf.ParentPlanogramFloorPlanId is not NULL
		and cpf.SCDActiveFlag = 'Y' and ixf.odsflag= 'DELETE' and ixf.asset_id = @asset_id AND ixf.row_status = @psaRowStatus
 join
                                                ser.SiteRole sr
                                                    on sr.sourcekey = ixf.storenumber
                                                       and sr.LOVRecordSourceId = 12008
                                                       AND sr.SCDActiveFlag = 'Y'
                                                       AND sr.LOVRoleId = '159000007'
                                            join
                                                ser.planogram          p
                                                    on p.sourcekey = ixf.POGDBFamilyKey
                                                       and p.LOVSourceKeyTypeId = @LOVSourceKeyTypeID
                                                       and p.LOVRecordSourceId = '1800052563'
                                                       and p.SCDActiveFlag = 'Y' and p.PlanogramId = cpf.ParentPlanogramId 

                                            --inner join
                                            --    ser.PlanogramFloorPlan pf
                                            --        on pf.sourcekey = ixf.FPDBFamilyKey
                                            --           and pf.LOVRecordSourceId = '1800052563'
                                            --           and pf.LOVSourceKeyTypeId = '1800055636'
                                            --           and pf.ParentPlanogramFloorPlanId is NULL 
                                            --           and pf.SCDActiveFlag = 'Y'
                                            inner join
                                                ser.planogramsiterole  psr
                                                    on psr.siteroleid = sr.siteroleid
                                                       and psr.planogramid = p.planogramid
                                                       and psr.scdactiveflag = 'y'
                                                       and psr.LOVRecordSourceId = '1800052563' and psr.PlanogramSiteRoleId = cpf.PlanogramSiteRoleId
                                            
*/

PRINT '****************Closed DELETE records, if any, in PlanogramFloorPlan Table *********************';



                    PRINT '****************Start Inserting  into PlanogramFloorPlanSection Table completed *********************';
                    SET @maxPlanogramFloorPlanSectionId =
                        (
                            SELECT
                                COALESCE(MAX(PlanogramFloorPlanSectionId), 0)
                            FROM
                                [ser].PlanogramFloorPlanSection
                        );
                    SET @tablecolumns
                        = '[PlanogramFloorPlanSectionId]' + ',	[PlanogramFloorPlanId]'   + ',	[LOVSourceKeyTypeId]'
                          + ',	[SourceKey]' + ',	[SegmentStart]' + ',	[HostPlanogram]' + ',	[LOVRecordSourceId]'
                          + ',	[SCDStartDate]'  + ',	[SCDEndDate]'  + ',	[SCDActiveFlag]'  + ',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_PlanogramFloorPlanSection') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_PlanogramFloorPlanSection;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_PlanogramFloorPlanSection FROM [ser].[PlanogramFloorPlanSection]'
                    EXEC (@exec_sql)
					select * from [ser].[PlanogramFloorPlanSection]

Insert into #RPRS_Merch_Store_PlanogramFloorPlanSection
Select distinct
    0 as PlanogramFloorPlanSectionId,
    pfp.planogramfloorplanid PlanogramFloorPlanId,
    '1800055638' LOVSourceKeyTypeId,
    FPSecDBKey SourceKey,
    FPSecSegmentStart SegmentStart,
    FPSecHostPlanogram HostPlanogram,
    '1800052563' LOVRecordSourceId,
    NULL as [SCDStartDate],
    NULL as [SCDEndDate],
    NULL as [SCDActiveFlag],
    NULL as [SCDVersion],
	  @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
    row_id PSARowKey
FROM
(
    select FPDBKey,
           FPSecDBKey,
           FPSecSegmentStart,
           storenumber,
           POGDBFamilyKey,
           FPSecHostPlanogram,
           min(row_id) as row_id
    from [psa].BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr
    where asset_id = @asset_id
          AND row_status = @psaRowStatus
          and odsflag <> 'DELETE'
    group by FPDBKey,
             FPSecDBKey,
             FPSecSegmentStart,
             storenumber,
             POGDBFamilyKey,
             FPSecHostPlanogram,
             FPSecHostPlanogram
) ixf
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanSection Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_PlanogramFloorPlanSection',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanSection',
                        @l_table_bus_pk = N'SourceKey,PlanogramFloorPlanId,LovRecordSourceID',
                        @l_table_pk = N'PlanogramFloorPlanSectionId',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                    PRINT '**************** SCD Load Complete, if any, in PlanogramFloorPlanSection Table *********************';


                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;

                    SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'

                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282117'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --  '200008' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = 'FPPendingDate'
                                                            AND LOVSetId = '282117'
                                                    )                        LOVStatusId,
                                                    ixf.FPPendingDate        EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                        select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate,
                                                    min(row_id) as row_id
                                                from
                                                   [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												 FPPendingDate is not null
                                                            and FPPendingDate != '' and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                    and asset_id = @asset_id
                                                    AND row_status = @psaRowStatus
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPPendingDate
                                                    )                        ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                       
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVStatusId,SCDLOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  				  		  

										  

										  
PRINT '****************Process DELETE  records in PlanogramFloorPlan Table *********************';
                    PRINT '****************Staerted loading PlanogramFloorPlanStatus Table *********************';

                    SET @tablecolumns
                        = '[PlanogramFloorPlanId]' + ',[LOVPlanogramFloorPlanStatusSetId]' + ',	[LOVStatusId]'
                          + ',	[EffectiveFrom]'+ ',	[EffectiveTo]'+ ',	[LOVRecordSourceId]'+ ',	[SCDStartDate]'
                          + ',	[SCDEndDate]'   + ',	[SCDActiveFlag]'+',	[SCDVersion]'
                          + ',	[SCDLOVRecordSourceId]' + ',	[ETLRunLogId]' + ',	[PSARowKey]';

                    PRINT 'Info: [ser].PlanogramFloorPlanStatus Table Serve Loading Started';
                    PRINT 'Info: Inserting the new version of record if there is a change in the attribute';
                    /* Below shows a example SQL Query of how the temporary table is created, Replace this with your code */
                    IF OBJECT_ID('tempdb..#RPRS_Merch_Store_FloorPlanStatus') IS NOT NULL
                        DROP TABLE #RPRS_Merch_Store_FloorPlanStatus;
					
					SET @exec_sql
                        = ' SELECT TOP 0 ' + @tablecolumns
                          + ' INTO #RPRS_Merch_Store_FloorPlanStatus FROM [ser].[PlanogramFloorPlanStatus]'
                    EXEC (@exec_sql)
                    INSERT INTO #RPRS_Merch_Store_FloorPlanStatus
                                select distinct
                                    PlanogramFloorPlanId,
                                    LOVPlanogramFloorPlanStatusSetId,
                                    LOVStatusId,
                                    EffectiveFrom,
                                    EffectiveTo,
                                    LOVRecordSourceId,
                                    NULL                            as SCDStartDate,
                                    NULL                            SCDEndDate,
                                    NULL                            SCDActiveFlag,
                                    NULL                            SCDVersion,
                                    SCDLOVRecordSourceId,
                                    ETLRunLogId,
                                    PSARowKey
                                from
                                    (
                                        select distinct
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceId,
                                            ETLRunLogId,
                                            min(PSARowKey) as PSArowkey
                                        from
                                            (
                                                SELECT distinct
                                                    pfp.PlanogramFloorPlanId PlanogramFloorPlanId,
                                                    '282083'                 LOVPlanogramFloorPlanStatusSetId,
                                                    --'200007' LOVStatusId,
                                                    (
                                                        select
                                                            LOVId
                                                        from
                                                            ser.RefLOV
                                                        where
                                                            LOVKey = ixf.FPDBStatus
                                                            AND LOVSetId = '282083'
                                                    )                        LOVStatusId,
                                                    NULL                     EffectiveFrom,
                                                    NULL                     EffectiveTo,
                                                    '1800052563'             LOVRecordSourceId,
                                                    @SCDLOVRecordSourceId    SCDLOVRecordSourceID,
                                                    @serveETLRunLogID        ETLRunLogID,
                                                    ixf.row_id               PSARowKey
                                                FROM
                                                    (
                                                         select
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus,
                                                    min(row_id) as row_id
                                                from
                                                    [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                                                where
												  FPDBStatus is not null
                                                            and FPDBStatus != ''
                                                            and
                                                    FPDBKey is not null
                                                    and FPDBKey != ''
                                                   and asset_id = @asset_id   AND row_status = @psaRowStatus
												  -- and asset_id= 42134
                                                    and odsflag <> 'DELETE'
                                                group by
                                                    StoreNumber,
                                                    FPDBKey,
                                                    POGDBFamilyKey,
                                                    FPDBFamilyKey,
                                                    FPDBStatus
                                                    )  ixf                                                     
    join ser.siterole s
        on s.sourcekey = ixf.storenumber
           and s.lovroleid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Role'
                     and lovkey = 'Store'
           )
           and s.scdactiveflag = 'Y'
    join ser.planogram pl
        on pl.sourcekey = ixf.POGDBFamilyKey
           and pl.lovsourcekeytypeid =
           (
               select lovid
               from ser.reflovsetinfo
               where lovsetname = 'Source Key Type'
                     and lovkey = 'BY Planogram Family Key'
           )
           and pl.scdactiveflag = 'Y'
    join ser.planogramsiterole ps
        on ps.siteroleid = s.siteroleid
           and ps.planogramid = pl.planogramid
           and ps.scdactiveflag = 'Y'
    inner join ser.PlanogramFloorPlan pfp
        on pfp.sourcekey = ixf.FPDBKey
           and pfp.planogramsiteroleid = ps.planogramsiteroleid
           and pfp.LOVSourceKeyTypeId = '1800055637'
           and pfp.LOVRecordSourceId = '1800052563'

                                            ) a
                                        group by
                                            PlanogramFloorPlanId,
                                            LOVPlanogramFloorPlanStatusSetId,
                                            LOVStatusId,
                                            EffectiveFrom,
                                            EffectiveTo,
                                            LOVRecordSourceId,
                                            SCDLOVRecordSourceID,
                                            ETLRunLogID
                                        
                                    ) c


                    PRINT '****************SCD Inserting  into PlanogramFloorPlanStatus Table Started *********************';
                    /* Perform SCD and Load into Target Table */
                    SET @tablecolumns = REPLACE(REPLACE(@tablecolumns, '[', ''''), ']', '''');
                    EXEC [psa].[sp_inc_perform_scd_merch]
                        @l_source_table = N'#RPRS_Merch_Store_FloorPlanStatus',
                        @l_target_schema = N'ser',
                        @l_target_table = N'PlanogramFloorPlanStatus',
                        @l_table_bus_pk = N'PlanogramFloorPlanId,LOVPlanogramFloorPlanStatusSetId,LOVRecordSourceId',
                        @l_table_pk = N'',
                        @l_table_columns = @tablecolumns,
                        @l_drop_source = 1,
                        @l_drop_target = 0
                  
				  

                    UPDATE
                        [psa].[BUKIT_BTCBY_BootsUK_Merchandising_Planogram_Store_Data_BTCBY_Incr]
                    SET
                        Row_Status = @serRowStatus
                    WHERE
                        row_Status = @psaRowStatus
                        AND asset_id = @asset_id;

                    SET @COUNTER = @COUNTER + 1;
                END
        --      COMMIT TRANSACTION;
        END TRY
        BEGIN CATCH
            THROW;
        END CATCH
    END
    IF OBJECT_ID('psa.fixture_cursor_table') IS NOT NULL
        BEGIN
            DROP TABLE [psa].[fixture_cursor_table];

        END
GO

/****** Object:  Table [ser].[Measure]    Script Date: 5/25/2023 12:16:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[Planogram]    Script Date: 5/25/2023 12:16:58 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[PlanogramFixture]    Script Date: 5/25/2023 12:13:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[PlanogramGroup]    Script Date: 5/25/2023 12:18:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[PlanogramIndicator]    Script Date: 5/25/2023 12:19:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[PlanogramPosition]    Script Date: 5/25/2023 12:09:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[PlanogramPositionProperty]    Script Date: 5/25/2023 12:20:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[PlanogramProperty]    Script Date: 5/25/2023 12:20:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[PlanogramStatus]    Script Date: 5/25/2023 12:22:29 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[product]    Script Date: 5/25/2023 12:23:25 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[RefLOV]    Script Date: 5/25/2023 12:10:54 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[RefLOVSet]    Script Date: 5/25/2023 12:10:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [ser].[SiteRole]    Script Date: 5/25/2023 12:24:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_GROUP_AM]    Script Date: 6/6/2023 7:25:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_GROUP_AM]    Script Date: 6/6/2023 7:25:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [psa].[sp_insertretailertostep_productrelationship]    Script Date: 6/28/2023 6:07:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_FIXTURE_AM]    Script Date: 7/6/2023 9:10:32 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_FLOOR_PLAN_SECTION_AM]    Script Date: 7/5/2023 11:55:31 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_GROUP_AM]    Script Date: 7/6/2023 8:57:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [con_mon].[USP_PLANOGRAM_PROPERTY_AM]    Script Date: 7/6/2023 8:54:56 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  Table [SER_PHARMACEUTICALS].[ParameterValue]    Script Date: 8/30/2023 6:31:34 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

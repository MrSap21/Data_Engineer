﻿CREATE TABLE [con_pz].[SAPCRM_Advantage_Card_customer_child]
(
	[RECORD_TYPE] [nvarchar](10) NULL,
	[CUSTOMER_NUMBER] [nvarchar](500) NULL,
	[CHILD_NUMBER] [nvarchar](500) NULL,
	[DATE_TYPE] [nvarchar](30) NULL,
	[CHILD_DOB] [nvarchar](500) NULL,
	[CHILD_FORENAME] [nvarchar](500) NULL,
	[CHILD_GENDER] [nvarchar](500) NULL,
	[IUD_FLAG] [nvarchar](10) NULL,
	[CREATE_USER] [nvarchar](500) NULL,
	[CHANGE_USER] [nvarchar](500) NULL,
	[CREATED_BY_CHANNEL] [nvarchar](20) NULL,
	[UPDATED_BY_CHANNEL] [nvarchar](20) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
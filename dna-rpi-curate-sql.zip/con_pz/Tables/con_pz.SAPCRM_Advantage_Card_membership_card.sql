﻿CREATE TABLE [con_pz].[SAPCRM_Advantage_Card_membership_card]
(
	[record_type] [nvarchar](80) NULL,
	[CARD_NUMBER] [nvarchar](500) NULL,
	[CHECK_DIGIT] [nvarchar](80) NULL,
	[STATUS_CODE] [nvarchar](80) NULL,
	[CUSTOMER_NUMBER] [nvarchar](500) NULL,
	[DESP_TO_CUST_DATE] [nvarchar](80) NULL,
	[CFA_ID] [nvarchar](80) NULL,
	[ACCOUNT_NUMBER] [nvarchar](500) NULL,
	[PROD_BATCH_NUMBER] [nvarchar](80) NULL,
	[GEOGRAPHY_CODE] [nvarchar](80) NULL,
	[ADVCD_TMNTD_TMSTMP] [nvarchar](80) NULL,
	[CARD_TYPE_CODE] [nvarchar](80) NULL,
	[CARD_ACTIVATION_DATE] [nvarchar](80) NULL,
	[CARD_EXPIRY_DATE] [nvarchar](80) NULL,
	[CHANGE_USER] [nvarchar](80) NULL,
	[CREATED_BY_CHANNEL] [nvarchar](80) NULL,
	[UPDATED_BY_CHANNEL] [nvarchar](80) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
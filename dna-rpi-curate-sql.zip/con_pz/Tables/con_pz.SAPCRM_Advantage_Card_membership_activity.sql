﻿CREATE TABLE [con_pz].[SAPCRM_Advantage_Card_membership_activity]
(
	[RECORD_TYPE] [nvarchar](10) NULL,
	[ACCOUNT_NUMBER] [nvarchar](500) NULL,
	[MEMBER_ACTIVITY_ID] [nvarchar](20) NULL,
	[POINT_TRANSACTION_DATE] [nvarchar](10) NULL,
	[POINT_TRANSACTION_TIME] [nvarchar](14) NULL,
	[CUSTOMER_NUMBER] [nvarchar](500) NULL,
	[POINTS_REQUESTED] [nvarchar](15) NULL,
	[POINTS_BALANCE] [nvarchar](15) NULL,
	[QUALIFIYING_SPEND] [nvarchar](18) NULL,
	[TOTAL_SPEND] [nvarchar](18) NULL,
	[POINT_ACCOUNT_ID] [nvarchar](500) NULL,
	[CURRENCY_CODE] [nvarchar](10) NULL,
	[EXTERNAL_REF_NO] [nvarchar](20) NULL,
	[THIRD_PARTY_ID] [nvarchar](12) NULL,
	[TILL_TXN_TIMESTAMP] [nvarchar](30) NULL,
	[STORE_NUMBER] [nvarchar](20) NULL,
	[TERMINAL_ID] [nvarchar](20) NULL,
	[CHANNEL_ID] [nvarchar](20) NULL,
	[ACTIVITY_TYPE] [nvarchar](10) NULL,
	[CATEGORY] [nvarchar](10) NULL,
	[OPERATOR_ID] [nvarchar](500) NULL,
	[MANUAL_FLAG] [nvarchar](10) NULL,
	[CARD_NUMBER] [nvarchar](500) NULL,
	[RECEIPT_NUMBER] [nvarchar](34) NULL,
	[COUNTRY_CODE] [nvarchar](500) NULL,
	[ADCARD_PRESENTATION_METHOD] [nvarchar](20) NULL,
	[CHANGED_BY] [nvarchar](500) NULL,
	[OFFLINE_FLAG] [nvarchar](10) NULL,
	[MEMBER_ACTIVITY_STATUS] [nvarchar](10) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [con_pz].[SVOC_Customer_identifier]
(
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[STAFF_DISCOUNT_CARD] [nvarchar](500) NULL,
	[NHS_NUMBER] [nvarchar](500) NULL,
	[CHI_NUMBER] [nvarchar](500) NULL,
	[HSCN_NUMBER] [nvarchar](500) NULL,
	[ADCARD_NUMBER] [nvarchar](500) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](30) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](30) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
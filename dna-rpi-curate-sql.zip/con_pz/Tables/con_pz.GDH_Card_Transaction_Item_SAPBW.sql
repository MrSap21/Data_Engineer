﻿CREATE TABLE [con_pz].[GDH_Card_Transaction_Item_SAPBW]
(
	[CUSTOMER_CARD_NUMBER] [nvarchar](500) NULL,
	[ITEM_CODE] [nvarchar](10) NULL,
	[STORE_NUMBER] [nvarchar](10) NULL,
	[TILL_TRANSACTION_DATE] [nvarchar](25) NULL,
	[TILL_TRANSACTION_TIME] [nvarchar](25) NULL,
	[TILL_TRANSACTION_TYPE_CODE] [nvarchar](1) NULL,
	[SALES_UNITS] [nvarchar](10) NULL,
	[SALES_AT_TISP] [nvarchar](100) NULL,
	[SALES_AT_TESP] [nvarchar](100) NULL,
	[SALES_EPOS_PROFIT] [nvarchar](100) NULL,
	[SALE_ITEM_DISCOUNT_PERCENTAGE] [nvarchar](100) NULL,
	[ITEM_DISCOUNT_OVERRIDDEN_FLAG] [nvarchar](1) NULL,
	[PRICE_OVERRIDDEN_ITEM_FLAG] [nvarchar](1) NULL,
	[TILL_TRANSACTION_NUMBER] [nvarchar](10) NULL,
	[TILL_NUMBER] [nvarchar](10) NULL,
	[TAKINGS] [nvarchar](100) NULL,
	[REVENUE] [nvarchar](100) NULL,
	[EPOS_PROFIT_ADJUSTED] [nvarchar](100) NULL,
	[ITEM_POINTS_QUANTITY] [nvarchar](100) NULL,
	[ITEM_POINTS_VALUE] [nvarchar](100) NULL,
	[MAP] [nvarchar](100) NULL,
	[SAP_SALES_AT_TISP] [nvarchar](100) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [con_pz].[SAPCRM_Advantage_Card_transactions]
(
	[RECORD_TYPE] [nvarchar](10) NULL,
	[CUSTOMER_NUMBER] [nvarchar](500) NULL,
	[ACCOUNT_NUMBER] [nvarchar](500) NULL,
	[MEMBER_ACTIVITY_ID] [nvarchar](20) NULL,
	[CARD_NUMBER] [nvarchar](500) NULL,
	[TRANSACTION_TYPE] [nvarchar](10) NULL,
	[POINTS_MOVEMENT] [nvarchar](15) NULL,
	[CREATION_TIMESTAMP] [nvarchar](30) NULL,
	[POINTS_EXPIRY_DATE] [nvarchar](30) NULL,
	[POINT_ACCOUNT_ID] [nvarchar](500) NULL,
	[POINT_TYPE] [nvarchar](20) NULL,
	[CHANGE_USER] [nvarchar](500) NULL,
	[REWARD_RULE_ID] [nvarchar](10) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
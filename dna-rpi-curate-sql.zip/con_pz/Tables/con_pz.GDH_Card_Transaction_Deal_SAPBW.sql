﻿CREATE TABLE [con_pz].[GDH_Card_Transaction_Deal_SAPBW]
(
	[CUSTOMER_CARD_NUMBER] [nvarchar](500) NULL,
	[DEAL_NUMBER] [nvarchar](10) NULL,
	[STORE_NUMBER] [nvarchar](10) NULL,
	[TILL_TRANSACTION_DATE] [nvarchar](25) NULL,
	[TILL_TRANSACTION_TIME] [nvarchar](25) NULL,
	[DEAL_NUMBER_OF_ITEMS] [nvarchar](10) NULL,
	[TILL_NUMBER] [nvarchar](10) NULL,
	[TILL_TRANSACTION_NUMBER] [nvarchar](10) NULL,
	[DEAL_TOTAL_SAVING_POINTS] [nvarchar](100) NULL,
	[PROMOTION_NUMBER] [nvarchar](20) NULL,
	[DEAL_TOTAL_SAVING_MONEY] [nvarchar](100) NULL,
	[DEAL_TYPE_FLAG] [nvarchar](1) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [con_pz].[SAPCRM_Advantage_Card_customer_clubs]
(
	[RECORD_TYPE] [nvarchar](10) NULL,
	[CUSTOMER_NUMBER] [nvarchar](500) NULL,
	[CLUB_TYPE] [nvarchar](10) NULL,
	[CLUB_NAME] [nvarchar](10) NULL,
	[CLUB_STATUS] [nvarchar](20) NULL,
	[CLUB_NUMBER] [nvarchar](20) NULL,
	[CLUB_JOIN_SOURCE] [nvarchar](10) NULL,
	[DATE_JOINED_CLUB] [nvarchar](30) NULL,
	[DATE_RESIGNED_CLUB] [nvarchar](30) NULL,
	[DATE_ACTIVATED] [nvarchar](30) NULL,
	[DATE_EXPIRED] [nvarchar](30) NULL,
	[CLUB_RESIGN_SOURCE] [nvarchar](10) NULL,
	[CLUB_TOPIC] [nvarchar](20) NULL,
	[CREATE_USER] [nvarchar](500) NULL,
	[CHANGE_USER] [nvarchar](500) NULL,
	[CREATED_BY_CHANNEL] [nvarchar](20) NULL,
	[UPDATED_BY_CHANNEL] [nvarchar](20) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
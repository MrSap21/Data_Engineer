﻿CREATE TABLE [con_pz].[SAPCRM_Advantage_Card_membership_points]
(
	[RECORD_TYPE] [nvarchar](10) NULL,
	[ACCOUNT_NUMBER] [nvarchar](500) NULL,
	[CUSTOMER_NUMBER] [nvarchar](500) NULL,
	[MEMBERSHIP_TYPE_CODE] [nvarchar](10) NULL,
	[POINTS_BALANCE] [nvarchar](15) NULL,
	[POINTS_EARNED] [nvarchar](15) NULL,
	[ACCOUNT_TERMINATED_DATE] [nvarchar](30) NULL,
	[ACCOUNT_ENROLLED_DATE] [nvarchar](30) NULL,
	[POINTS_REDEEMED] [nvarchar](15) NULL,
	[POINTS_EXPIRED] [nvarchar](15) NULL,
	[MEMBERSHIP_STATUS] [nvarchar](32) NULL,
	[POINT_ACCOUNT_ID] [nvarchar](500) NULL,
	[GEOGRAPHY_CODE] [nvarchar](10) NULL,
	[LATEST_TXN_DATE] [nvarchar](10) NULL,
	[CHANGED_BY] [nvarchar](500) NULL,
	[CREATED_BY_CHANNEL] [nvarchar](20) NULL,
	[UPDATED_BY_CHANNEL] [nvarchar](20) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
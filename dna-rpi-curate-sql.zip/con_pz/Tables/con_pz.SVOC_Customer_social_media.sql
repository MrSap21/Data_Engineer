﻿CREATE TABLE [con_pz].[SVOC_Customer_social_media]
(
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[SOCIAL_MEDIA_TYPE] [nvarchar](30) NULL,
	[SOCIAL_MEDIA_ID] [nvarchar](500) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](30) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](30) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
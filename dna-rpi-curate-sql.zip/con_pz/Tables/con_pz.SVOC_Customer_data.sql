﻿CREATE TABLE [con_pz].[SVOC_Customer_data]
(
	[ENTITY_ID] [nvarchar](500) NULL,
	[PARTY_ID] [nvarchar](500) NULL,
	[TITLE] [nvarchar](500) NULL,
	[FIRST_NAME] [nvarchar](500) NULL,
	[MIDDLE_NAME] [nvarchar](500) NULL,
	[LAST_NAME] [nvarchar](500) NULL,
	[CHOSEN_FIRST_NAME] [nvarchar](500) NULL,
	[BIRTH_LAST_NAME] [nvarchar](500) NULL,
	[GENDER] [nvarchar](500) NULL,
	[DATE_OF_BIRTH] [nvarchar](500) NULL,
	[DATE_OF_DEATH] [nvarchar](500) NULL,
	[SOURCE_DECEASED_INFO] [nvarchar](500) NULL,
	[DEATH_NOTIFICATION_DATE] [nvarchar](500) NULL,
	[THIRD_PARTY_PROVIDED_FLG] [nvarchar](10) NULL,
	[NO_DATA_SHARE_FLG] [nvarchar](10) NULL,
	[NO_DUTY_OF_CARE_FLG] [nvarchar](10) NULL,
	[SPECIAL_FLG3] [nvarchar](10) NULL,
	[SPECIAL_FLG4] [nvarchar](10) NULL,
	[SPECIAL_FLG5] [nvarchar](10) NULL,
	[SPECIAL_FLG6] [nvarchar](10) NULL,
	[SPECIAL_FLG7] [nvarchar](10) NULL,
	[SPECIAL_FLG8] [nvarchar](10) NULL,
	[SPECIAL_FLG9] [nvarchar](10) NULL,
	[SPECIAL_FLG10] [nvarchar](10) NULL,
	[ENTITY_CREATE_TIME] [nvarchar](30) NULL,
	[ENTITY_LAST_UPDATE_TIME] [nvarchar](30) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [con_pz].[SAPCRM_Customer_Status_Change]
(
	[CUSTOMER_NUMBER] [nvarchar](500) NULL,
	[ABACUS_ACCOUNT_STATUS] [nvarchar](20) NULL,
	[EXTRACT_DATE] [nvarchar](30) NULL,
	[CRM_NEW_STATUS] [nvarchar](20) NULL,
	[delta_ind] [char](1) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
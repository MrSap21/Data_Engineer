﻿CREATE PROC [con_pz].[sp_dm_SAPCRM_Advantage_Card_transactions] @pETLRunLogID [nvarchar](255) AS	
/*
************************************************************************************************************
Procedure Name				: [con_pz].[sp_dm_SAPCRM_Advantage_Card_transactions] 
Purpose						: Insert into datamart table from psa table with appropriate delta indicator(I)
Target Table                : con_pz.SAPCRM_Advantage_Card_transactions
********************************************************************************************************************
Default values
************************************************************************************************************
ETLRunLogID                 : @pETLRunLogID passed as an argument
*************************************************************************************************************
Modification History
************************************************************************************************************
22-June-2021      : Ashlin T : Initial Version
02-August-2021	  : Ashlin T : Modified to handle delta indicator
15-Sept-2021	  : Abhilaksh Agnihotri: Time conversion modification
04-April-2022	  : Saurabh Menon: Added order by clause when fetching columns from INFORMATION_SCHEMA.COLUMNS
*/ 

/*Declare  and initialize the Variables required */
BEGIN

SET NOCOUNT ON

DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
        DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';



DECLARE 
@history_feed_id INT, --history feed id
@count INT, --count variable for counting incremental feed id in egress audit table
		@feed_id INT,
		@execsql NVARCHAR(MAX),
		@prev_createdTimeStamp NVARCHAR(MAX),
		@columnNames NVARCHAR(MAX),
		@selectCond NVARCHAR(MAX),
		@delta_ind nvarchar(1),
		@tempTableName nvarchar(max),
		@maxAssetID bigint,
		@new_createdTimeStamp nvarchar(max),
		@maxETLRunLogID NVARCHAR(max);
		
	SET @feed_id = (select feed_id from psa.cf_feed_configuration where psa_table_name='SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions' and active_flag=1)
	SET @count=(select count (*) from psa.egress_audit_status where feed_id=@feed_id) --counting number of incremental feed id values in egress audit table
	 
	SET @history_feed_id= (select feed_id from psa.cf_feed_configuration where psa_table_name='SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions' and active_flag=0) --setting history feed id where active flag is 0
	  

	IF (@count>0)
	BEGIN
	
		SET @prev_createdTimeStamp = (select convert(nvarchar,created_timestamp,121) from psa.egress_audit_status where feed_id=@feed_id) -- setting feed_id= incremental feed id 
		
	END

	ELSE IF(@count=0)
	BEGIN
	
		SET @prev_createdTimeStamp = (select convert(nvarchar,created_timestamp,121) from psa.egress_audit_status where feed_id=@history_feed_id) --setting feed_id= history_feed_id if incremental feed id is null
		
	END
	--gets the created_timestamp of the last processed asset from audit table
	--SET @prev_createdTimeStamp = (select created_timestamp from psa.egress_audit_status where feed_id=@feed_id)
	
	SET @columnNames = (SELECT STRING_AGG(column_name, ',') WITHIN GROUP (ORDER BY ordinal_position) FROM(SELECT DISTINCT CAST(column_name AS VARCHAR(MAX)) AS column_name,ordinal_position FROM INFORMATION_SCHEMA.COLUMNS WHERE table_schema='con_pz' AND table_name = 'SAPCRM_Advantage_Card_transactions')t)

    SET @selectCond =  (SELECT STRING_AGG(column_name, ',') WITHIN GROUP (ORDER BY ordinal_position) FROM(SELECT DISTINCT CAST(column_name AS VARCHAR(MAX)) AS column_name,ordinal_position FROM INFORMATION_SCHEMA.COLUMNS WHERE table_schema='psa' AND table_name = 'SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions' and column_name NOT IN('row_id','etl_runlog_id','asset_id','record_source_id','row_status','created_timestamp','active_flag')) t)
	SET @maxETLRunLogID = (select max(etl_runlog_id) from psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions)
	--stores the maximum value of asset_id in the psa table
	SET @maxAssetID = (select max(asset_id) from psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions)
	
	--stores the maximum value of created_timestamp in the psa table
	SET @new_createdTimeStamp = (select convert(nvarchar,max(created_timestamp),121) from psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions)
		
	BEGIN TRANSACTION;
	BEGIN TRY
				
		PRINT 'Inserting data to the datamart table started';	
		
		SET @delta_ind='I'
		
		--inserting records with delta_ind='I' to the datamart table
		SET @execsql='INSERT INTO con_pz.SAPCRM_Advantage_Card_transactions(' + @columnNames + ') SELECT ' + @selectCond + ',''' + @delta_ind+ ''' delta_ind,created_timestamp,[etl_runlog_id] = '+ @pETLRunLogID+' FROM psa.SAPCOE_SAPCRM_BUK_SAPCRM_Advantage_Card_transactions a where a.created_timestamp>try_cast('''+@prev_createdTimeStamp+ ''' as datetime)'
		
		EXEC(@execsql)
		
		PRINT 'Inserting data to the datamart table completed'
		
		--updating the audit table to store latest values of etlrunlogid,asset_id and created_timestamp
		IF (@count>0) --updating the egress audit status table when incremental feed id is already present in egress audit table
		BEGIN
			UPDATE psa.egress_audit_status
			set etl_runlog_id = @maxETLRunLogID, asset_id = @maxAssetID, created_timestamp=try_cast(@new_createdTimeStamp as datetime) where feed_id=@feed_id
		END
		
		ELSE IF (@count=0) -- inserting new row into egress audit status table when incremental feed id is not present
		BEGIN
			INSERT INTO psa.egress_audit_status values(@feed_id,@maxETLRunLogID,@maxAssetID,@new_createdTimeStamp)
		END
	
		SELECT @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;



END TRY
		BEGIN CATCH
		IF @@TRANCOUNT>0
			ROLLBACK TRANSACTION;

			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_dm_SAPCRM_Advantage_Card_transactions]',ERROR_MESSAGE(),GETDATE();
		THROW;					
								
		END CATCH 
		IF @@TRANCOUNT>0
			COMMIT TRANSACTION;

	IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
	
END
GO
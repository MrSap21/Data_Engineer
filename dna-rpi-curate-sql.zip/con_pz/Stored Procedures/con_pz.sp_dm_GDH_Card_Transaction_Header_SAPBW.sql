﻿CREATE PROC [con_pz].[sp_dm_GDH_Card_Transaction_Header_SAPBW] @pETLRunLogID [nvarchar](255) AS	
/*
************************************************************************************************************
Procedure Name              : [con_pz].[sp_dm_GDH_Card_Transaction_Header_SAPBW]
Purpose                     : Insert into datamart table from psa table with appropriate delta indicator(I/U)                        
Target Tables               : con_pz.GDH_Card_Transaction_Header_SAPBW
************************************************************************************************************
ETLRunLogID                 : @pETLRunLogID passed as an argument
*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :  Modified By     : Description
==========================================================================================================================
30-Nov-2021  :  Jacob Roy       : Initial Version
04-April-2022  : Ashlin T       : Added order by clause when fetching columns from INFORMATION_SCHEMA.COLUMNS

**************************************************************************************************************************
*/

/*Declare  and initialize the Variables required */
BEGIN

SET NOCOUNT ON

DECLARE 
		@count INT,
		@feed_id INT,
		@businessKeys NVARCHAR(max),
		@execsql NVARCHAR(MAX),
		@busKeyCond NVARCHAR(MAX),
		@prev_createdTimeStamp NVARCHAR(MAX),
		@columnNames NVARCHAR(MAX),
		@selectCond NVARCHAR(MAX),
		@delta_ind nvarchar(1),
		@tempTableName nvarchar(max),
		@maxAssetID bigint,
		@new_createdTimeStamp nvarchar(max),
		@maxETLRunLogID NVARCHAR(max),
		@vProcedureMessage NVARCHAR(MAX),
		@vProcedureStatus NVARCHAR(20);
		
	SET @vProcedureMessage = 'OK'
	SET @vProcedureStatus = '0'
		
	SET @feed_id = (select feed_id from psa.cf_feed_configuration where psa_table_name='uk_abacus_header' and active_flag=1)
	
	--counting number of incremental feed id values in egress audit table
	SET @count=(select count (*) from psa.egress_audit_status where feed_id=@feed_id) 
	
	IF (@count>0)
	BEGIN
		--gets the created_timestamp of the last processed asset from audit table
		SET @prev_createdTimeStamp=(select convert(nvarchar,created_timestamp,121) from psa.egress_audit_status where feed_id=@feed_id);
		
	END

	ELSE IF(@count=0)
	BEGIN
		--if there is no entry for the feed, assign a default value to created_timestamp
		SET @prev_createdTimeStamp = (select CAST('1900-01-01 00:00:00.000' AS DATETIME) )
		
	END
	
	SET @businessKeys = 'STORE_NUMBER,TILL_NUMBER,TILL_TXN_NUMBER,TILL_TXN_DATE,TILL_TXN_TIME'
	
	SET @columnNames = (SELECT STRING_AGG(column_name,',') WITHIN GROUP (ORDER BY ordinal_position) FROM INFORMATION_SCHEMA.COLUMNS WHERE table_schema='con_pz' AND table_name = 'GDH_Card_Transaction_Header_SAPBW')
	
	SET @selectCond = (select STRING_AGG(c.name,',') WITHIN GROUP (ORDER BY column_id) from sys.columns c join sys.views v on v.object_id=c.object_id and v.name='VW_GDH_Card_Transaction_Header_SAPBW' and c.name NOT IN('etl_runlog_id','asset_id','record_source_id','row_status','created_timestamp','active_flag'))
	
	
	SET @busKeyCond = (SELECT STRING_AGG('ISNULL(a.'+value+','''') = ISNULL(b.'+value+','''')', ' AND ') busKeyCond FROM 
													(SELECT CAST(value AS VARCHAR(MAX)) AS value FROM STRING_SPLIT(@businessKeys, ','))t)
	
	--stores the maximum value of etl_runlog_id in the psa table	
	SET @maxETLRunLogID = (select max(etl_runlog_id) from psa.VW_GDH_Card_Transaction_Header_SAPBW)
	
	--stores the maximum value of asset_id in the psa table
	SET @maxAssetID = (select max(asset_id) from psa.VW_GDH_Card_Transaction_Header_SAPBW)
	
	--stores the maximum value of created_timestamp in the psa table
	SET @new_createdTimeStamp = (select convert(nvarchar,max(created_timestamp),121) from psa.VW_GDH_Card_Transaction_Header_SAPBW)
	
	SET @tempTableName = 'tempdb..#uk_abacus_header_temp'
	
	IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
	
	--creating temp table to store records with created_timestamp greater than prev_createdTimeStamp along with row numbers(partitioned by businesskeys and ordered in ascending order of created_timestamp)
	
	set @execsql='select a.*,row_number() over(partition by '+@businessKeys+' order by created_timestamp)RN into '+@tempTableName+' from(select b.*,row_number() over(partition by '+@businessKeys+',asset_id order by created_timestamp)row_num from psa.VW_GDH_Card_Transaction_Header_SAPBW b where b.created_timestamp>try_cast('''+@prev_createdTimeStamp+ ''' as datetime))a where row_num=1'
	
	EXEC(@execsql)
	
	BEGIN TRANSACTION;
	BEGIN TRY
				
		PRINT 'Inserting data to the datamart table started';	
		
		SET @delta_ind='I'
		
		--inserting records with delta_ind='I' to the datamart table
		SET @execsql='INSERT INTO con_pz.GDH_Card_Transaction_Header_SAPBW(' + @columnNames + ') SELECT ' + @selectCond + ',''' + @delta_ind+ ''' delta_ind,created_timestamp,[etl_runlog_id] = '+ @pETLRunLogID+' FROM '+@tempTableName+' a WHERE NOT EXISTS (SELECT 1 FROM psa.VW_GDH_Card_Transaction_Header_SAPBW b WHERE ('+ @busKeyCond + ') and created_timestamp < = try_cast('''+@prev_createdTimeStamp+''' as datetime)) and RN=1'
		
		EXEC(@execsql)
		
		SET @delta_ind='U'
		
		--inserting updates to existing records with delta_ind='U'
		SET @execsql='INSERT INTO con_pz.GDH_Card_Transaction_Header_SAPBW(' + @columnNames + ') SELECT ' + @selectCond + ',''' + @delta_ind+ ''' delta_ind,created_timestamp,[etl_runlog_id] = '+ @pETLRunLogID+' FROM '+@tempTableName+' a WHERE EXISTS (SELECT 1 FROM psa.VW_GDH_Card_Transaction_Header_SAPBW b WHERE ('+ @busKeyCond + ') and created_timestamp < = try_cast('''+@prev_createdTimeStamp+''' as datetime))'
		
		EXEC(@execsql)
		
		--inserting updates to new records(if any) with delta_ind='U'
		SET @execsql='INSERT INTO con_pz.GDH_Card_Transaction_Header_SAPBW(' + @columnNames + ') SELECT ' + @selectCond + ',''' + @delta_ind+ ''' delta_ind,created_timestamp,[etl_runlog_id] = '+ @pETLRunLogID+' FROM '+@tempTableName+' a WHERE NOT EXISTS (SELECT 1 FROM psa.VW_GDH_Card_Transaction_Header_SAPBW b WHERE ('+ @busKeyCond + ') and created_timestamp < = try_cast('''+@prev_createdTimeStamp+''' as datetime)) and RN>1'
		
		EXEC(@execsql)
		
		PRINT 'Inserting data to the datamart table completed'
		
		--updating the audit table to store latest values of etlrunlogid,asset_id and created_timestamp	
		IF (@count>0) --updating the egress audit status table when incremental feed id is already present in egress audit table
		BEGIN
			UPDATE psa.egress_audit_status
			set etl_runlog_id = @maxETLRunLogID, asset_id = @maxAssetID, created_timestamp=try_cast(@new_createdTimeStamp as datetime) where feed_id=@feed_id
		END
		
		ELSE IF (@count=0) -- inserting new row into egress audit status table when incremental feed id is not present
		BEGIN
			INSERT INTO psa.egress_audit_status values(@feed_id,@maxETLRunLogID,@maxAssetID,@new_createdTimeStamp)
		END

		SELECT @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;


END TRY
		BEGIN CATCH
		IF @@TRANCOUNT>0
			ROLLBACK TRANSACTION;

			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_dm_GDH_Card_Transaction_Header_SAPBW]',ERROR_MESSAGE(),GETDATE();
		THROW;					
								
		END CATCH 
		IF @@TRANCOUNT>0
			COMMIT TRANSACTION;

	IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
	
END
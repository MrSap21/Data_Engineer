﻿CREATE PROC [con_pz].[sp_dm_SVOC_Customer_entity_link] @pETLRunLogID [nvarchar](255) AS	
/*
************************************************************************************************************
Procedure Name				: [con_pz].[sp_dm_SVOC_Customer_entity_link] 
Purpose						: Insert into datamart table from psa table with appropriate delta indicator(I/U/D)
Target Table                : con_pz.SVOC_Customer_entity_link
********************************************************************************************************************
Default values
************************************************************************************************************
ETLRunLogID                 : @pETLRunLogID passed as an argument
*************************************************************************************************************
Modification History
************************************************************************************************************
22-July-2021      : Soujanya T : Initial Version
02-August-2021	  : Soujanya T : Modified to handle delta indicator
15-Sept-2021	  : Abhilaksh Agnihotri: Time conversion modification
04-April-2022	  : Saurabh Menon: Added order by clause when fetching columns from INFORMATION_SCHEMA.COLUMNS
04-May-2022		  :	Ashlin T : Modified to handle deletion for each table seperately for perfomance improvement
*/ 

/*Declare  and initialize the Variables required */
BEGIN

SET NOCOUNT ON
exec [psa].[sp_IncrementalDeletion_Martech] 'BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link'
DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
        DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';
		

DECLARE 
@history_feed_id INT, --history feed id
@count INT, --count variable for counting incremental feed id in egress audit table
		@feed_id INT,
		@entity_id INT,
		@businessKeys NVARCHAR(max),
		@execsql NVARCHAR(MAX),
		@busKeyCond NVARCHAR(MAX),
		@prev_createdTimeStamp NVARCHAR(MAX),
		@columnNames NVARCHAR(MAX),
		@selectCond NVARCHAR(MAX),
		@delta_ind nvarchar(1),
		@tempTableName nvarchar(max),
		@deltempTableName nvarchar(max),
		@maxAssetID bigint,
		@new_createdTimeStamp NVARCHAR(MAX),
		@maxETLRunLogID NVARCHAR(max);
		
	SET @feed_id = (select feed_id from psa.cf_feed_configuration where psa_table_name='BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link' and active_flag=1)
	SET @count=(select count (*) from psa.egress_audit_status where feed_id=@feed_id) --counting number of incremental feed id values in egress audit table
	 
	SET @history_feed_id= (select feed_id from psa.cf_feed_configuration where psa_table_name='BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link' and active_flag=0) --setting history feed id where active flag is 0
	  

	IF (@count>0)
	BEGIN
	
		SET @prev_createdTimeStamp = (select convert(nvarchar,created_timestamp,121) from psa.egress_audit_status where feed_id=@feed_id) -- setting feed_id= incremental feed id 
		
	END

	ELSE IF(@count=0)
	BEGIN
	
		SET @prev_createdTimeStamp = (select convert(nvarchar,created_timestamp,121) from psa.egress_audit_status where feed_id=@history_feed_id) --setting feed_id= history_feed_id if incremental feed id is null
		
	END
	SET @entity_id = (select EntityID from psa.Entity where EntityName = 'SVoC Customer entity link - incremental' and SchemaName like 'Feed%')
	
	SET @businessKeys = (SELECT STRING_AGG(AttributeName, ',') AttributeName from psa.attribute where entityId =@entity_id and attributeType=40001)
	
	--gets the created_timestamp of the last processed asset from audit table
	--SET @prev_createdTimeStamp = (select created_timestamp from psa.egress_audit_status where feed_id=@feed_id)
	
	SET @columnNames = (SELECT STRING_AGG(column_name, ',') WITHIN GROUP (ORDER BY ordinal_position) FROM(SELECT DISTINCT CAST(column_name AS VARCHAR(MAX)) AS column_name,ordinal_position FROM INFORMATION_SCHEMA.COLUMNS WHERE table_schema='con_pz' AND table_name = 'SVOC_Customer_entity_link')t)

    SET @selectCond =  (SELECT STRING_AGG(column_name, ',') WITHIN GROUP (ORDER BY ordinal_position) FROM(SELECT DISTINCT CAST(column_name AS VARCHAR(MAX)) AS column_name,ordinal_position FROM INFORMATION_SCHEMA.COLUMNS WHERE table_schema='psa' AND table_name = 'BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link' and column_name NOT IN('row_id','INSERT_DATE','UPDATE_DATE','etl_runlog_id','asset_id','record_source_id','row_status','created_timestamp','active_flag')) t)
	
	SET @busKeyCond = (SELECT STRING_AGG('ISNULL(a.'+value+','''') = ISNULL(b.'+value+','''')', ' AND ') busKeyCond FROM 
													(SELECT CAST(value AS VARCHAR(MAX)) AS value FROM STRING_SPLIT(@businessKeys, ','))t)
	
	
	SET @tempTableName = 'tempdb..#BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link_temp'
	
	IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END

	--creating temp table to store records with created_timestamp greater than prev_createdTimeStamp along with row numbers(partitioned by businesskeys and ordered in ascending order of created_timestamp)
	set @execsql='select a.*,row_number() over(partition by '+@businessKeys+' order by created_timestamp)RN into '+@tempTableName+' from psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link a where a.created_timestamp>try_cast('''+@prev_createdTimeStamp+ ''' as datetime)'
		
	EXEC(@execsql)
	SET @maxETLRunLogID = (select max(etl_runlog_id) from psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link)

	--stores the maximum value asset_id in the psa table
	SET @maxAssetID = (select max(asset_id) from psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link)

	--stores the maximum value of created_timestamp in the psa table
	SET @new_createdTimeStamp = (select convert(nvarchar,max(created_timestamp),121) from psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link)
		
	SET @deltempTableName = 'tempdb..#del_BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link_temp'
	
	IF OBJECT_ID(@deltempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@deltempTableName)
	END
	
	--creating temp table to store deleted records
	EXEC('SELECT TOP 0 '+@selectCond+',created_timestamp INTO '+ @deltempTableName +' FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link')
	
	--inserting the deleted records to the temp table
	set @execsql='INSERT INTO '+ @deltempTableName + ' SELECT '+@selectCond+',created_timestamp from psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link a where exists(select * from psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link b where '+@busKeyCond+' and a.row_id=b.row_id and a.asset_id=b.asset_id and b.created_timestamp<a.created_timestamp and a.created_timestamp>try_cast('''+@prev_createdTimeStamp+ ''' as datetime)) and a.active_flag=''N'''
	
	EXEC(@execsql)

	BEGIN TRANSACTION;
	BEGIN TRY
				
		PRINT 'Inserting data to the datamart table started';	
		
		SET @delta_ind='I'
		
		--inserting new records with delta_ind='I' to the datamart table
		SET @execsql='INSERT INTO con_pz.SVOC_Customer_entity_link(' + @columnNames + ') SELECT ' + @selectCond + ',''' + @delta_ind+ ''' delta_ind,created_timestamp,[etl_runlog_id] = '+ @pETLRunLogID+' FROM '+@tempTableName+' a WHERE NOT EXISTS (SELECT 1 FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link b WHERE ('+ @busKeyCond + ') and created_timestamp < = try_cast('''+@prev_createdTimeStamp+''' as datetime)) and RN=1'
		
		EXEC(@execsql)
		
		PRINT('Inserted new records with delta indicator I')
		
		SET @delta_ind='U'
		
		--inserting updates to existing records with delta_ind='U'
		SET @execsql='INSERT INTO con_pz.SVOC_Customer_entity_link(' + @columnNames + ') SELECT ' + @selectCond + ',''' + @delta_ind+ ''' delta_ind,created_timestamp,[etl_runlog_id] = '+ @pETLRunLogID+' FROM '+@tempTableName+' a WHERE EXISTS (SELECT 1 FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link b WHERE ('+ @busKeyCond + ') and created_timestamp < = try_cast('''+@prev_createdTimeStamp+''' as datetime)) and created_timestamp not in(select distinct(created_timestamp) from '+@deltempTableName+')'
		
		EXEC(@execsql)
		
		--inserting updates to new records(if any) with delta_ind='U'
		SET @execsql='INSERT INTO con_pz.SVOC_Customer_entity_link(' + @columnNames + ') SELECT ' + @selectCond + ',''' + @delta_ind+ ''' delta_ind,created_timestamp,[etl_runlog_id] = '+ @pETLRunLogID+' FROM '+@tempTableName+' a WHERE NOT EXISTS (SELECT 1 FROM psa.BUKIT_BTCSVOC_BUK_SVOC_Customer_entity_link b WHERE ('+ @busKeyCond + ') and created_timestamp < = try_cast('''+@prev_createdTimeStamp+''' as datetime)) and RN>1 and created_timestamp not in(select distinct(created_timestamp) from '+@deltempTableName+')'
		
		EXEC(@execsql)
		
		PRINT('Inserted updated records with delta indicator U')
		
		SET @delta_ind='D'
		
		--inserting deleted records with delta_ind='D'
		SET @execsql='INSERT INTO con_pz.SVOC_Customer_entity_link(' + @columnNames + ') SELECT ' + @selectCond + ',''' + @delta_ind+ ''' delta_ind,created_timestamp,[etl_runlog_id] = '+ @pETLRunLogID+' FROM '+@deltempTableName
		
		EXEC(@execsql)
		
		PRINT('Inserted deleted records with delta indicator D')
		
		PRINT 'Inserting data to the datamart table completed'
		
		--updating the audit table to store latest values of etlrunlogid,asset_id and created_timestamp
		IF (@count>0) --updating the egress audit status table when incremental feed id is already present in egress audit table
		BEGIN
			UPDATE psa.egress_audit_status
			set etl_runlog_id = @maxETLRunLogID, asset_id = @maxAssetID, created_timestamp=try_cast(@new_createdTimeStamp as datetime) where feed_id=@feed_id
		END
		
		ELSE IF (@count=0) -- inserting new row into egress audit status table when incremental feed id is not present
		BEGIN
			INSERT INTO psa.egress_audit_status values(@feed_id,@maxETLRunLogID,@maxAssetID,@new_createdTimeStamp)
		END
		SELECT  @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;



END TRY
		BEGIN CATCH
		IF @@TRANCOUNT>0
			ROLLBACK TRANSACTION;
			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;
			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_dm_SVOC_Customer_entity_link]',ERROR_MESSAGE(),GETDATE();
		THROW;					
								
		END CATCH 
		IF @@TRANCOUNT>0
			COMMIT TRANSACTION;

	IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
	
	IF OBJECT_ID(@deltempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@deltempTableName)
	END
END
GO
﻿CREATE FUNCTION [con_sa].[RemoveLeadingTrailingZeros] (@input [nvarchar](max)) RETURNS nvarchar(max)
AS
BEGIN
    DECLARE @inter_result nvarchar(max),
			@final_result nvarchar(max)

    SET @inter_result = REPLACE(LTRIM(RTRIM(REPLACE(@input,'0',' '))),' ','0')
	
	SET @final_result = (CASE  
							WHEN @inter_result='.' THEN '0'
							WHEN @inter_result=''  THEN '0'
							WHEN RIGHT(@inter_result,1) = '.' THEN LEFT(@inter_result,LEN(@inter_result)-1)
							ELSE @inter_result
						END)
						
    RETURN @final_result
END
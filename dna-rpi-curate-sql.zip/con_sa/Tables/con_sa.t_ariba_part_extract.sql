﻿CREATE TABLE [con_sa].[t_ariba_part_extract]
(
	[PART_NUMBER] [nvarchar](30) NOT NULL,
	[REVISION_NUMBER] [nvarchar](1) NULL,
	[DESCRIPTION1] [nvarchar](60) NULL,
	[DESCRIPTION2] [nvarchar](60) NULL,
	[STANDARD_COST] [nvarchar](10) NULL,
	[STANDARD_COST_CURRENCY] [nvarchar](3) NULL,
	[STANDARD_COST_DATE] [nvarchar](1) NULL,
	[STOCK_INDICATOR] [nvarchar](1) NULL,
	[MANUFACTURER_NAME] [nvarchar](1) NULL,
	[MANUFACTURER_PART_NUMBER] [nvarchar](1) NULL,
	[LEAD_TIME_IN_DAYS] [nvarchar](1) NULL,
	[FLEX_FIELD_1] [nvarchar](1) NULL,
	[FLEX_FIELD_2] [nvarchar](1) NULL,
	[FLEX_FIELD_3] [nvarchar](1) NULL,
	[PART_FLEX_TEXT_1] [nvarchar](1) NULL,
	[PART_FLEX_TEXT_2] [nvarchar](10) NULL,
	[PART_FLEX_TEXT_3] [nvarchar](1) NULL,
	[ORIGIN_COUNTRY] [nvarchar](1) NULL,
	[MATERIAL_COMPOSITION] [nvarchar](1) NULL,
	[FORECAST_USAGE_1] [nvarchar](1) NULL,
	[FORECAST_USAGE_2] [nvarchar](1) NULL,
	[FORECAST_USAGE_3] [nvarchar](1) NULL,
	[DSS_CREATE_TIME] [date] NULL,
	[DSS_UPDATE_TIME] [date] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [con_sa].[t_ariba_part]
(
	[PART_NUMBER] [nvarchar](30) NOT NULL,
	[REVISION_NUMBER] [nvarchar](1) ,
	[DESCRIPTION1] [nvarchar](60) ,
	[DESCRIPTION2] [nvarchar](60) ,
	[STANDARD_COST] [decimal](10, 5) ,
	[STANDARD_COST_CURRENCY] [nvarchar](3) ,
	[STANDARD_COST_DATE] [nvarchar](1) ,
	[STOCK_INDICATOR] [nvarchar](1) ,
	[MANUFACTURER_NAME] [nvarchar](1) ,
	[MANUFACTURER_PART_NUMBER] [nvarchar](1) ,
	[LEAD_TIME_IN_DAYS] [nvarchar](1) ,
	[FLEX_FIELD_1] [nvarchar](1) ,
	[FLEX_FIELD_2] [nvarchar](1) ,
	[FLEX_FIELD_3] [nvarchar](1) ,
	[PART_FLEX_TEXT_1] [nvarchar](1) ,
	[PART_FLEX_TEXT_2] [nvarchar](10) ,
	[PART_FLEX_TEXT_3] [nvarchar](1) ,
	[ORIGIN_COUNTRY] [nvarchar](1) ,
	[MATERIAL_COMPOSITION] [nvarchar](1) ,
	[FORECAST_USAGE_1] [nvarchar](1) ,
	[FORECAST_USAGE_2] [nvarchar](1) ,
	[FORECAST_USAGE_3] [nvarchar](1) ,
	[DSS_CREATE_TIME] [date] ,
	[DSS_UPDATE_TIME] [date] 
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
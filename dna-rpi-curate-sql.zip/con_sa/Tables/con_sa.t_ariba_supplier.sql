﻿CREATE TABLE [con_sa].[t_ariba_supplier]
(
	[SUPPLIER_ID] [bigint] NULL,
	[SUPPLIER_LOCATION_ID] [nvarchar](1) NULL,
	[SUPPLIER_NAME] [nvarchar](200) NULL,
	[STREET_ADDRESS] [nvarchar](123) NULL,
	[CITY] [nvarchar](30) NULL,
	[STATE] [nvarchar](30) NULL,
	[COUNTRY] [nvarchar](2) NULL,
	[POSTAL_CODE] [nvarchar](30) NULL,
	[SUPPLIER_TYPE] [nvarchar](10) NULL,
	[CONTACT_FIRST_NAME] [nvarchar](30) NULL,
	[CONTACT_LAST_NAME] [nvarchar](10) NULL,
	[CONTACT_PHONE_NUMBER] [nvarchar](30) NULL,
	[CONTACT_EMAIL] [nvarchar](30) NULL,
	[PREFERRED_LANGUAGE] [nvarchar](10) NULL,
	[FAX_NUMBER] [nvarchar](30) NULL,
	[DUNS_NUMBER] [nvarchar](10) NULL,
	[AN_NUMBER] [nvarchar](10) NULL,
	[PAYMENT_TYPE] [nvarchar](30) NULL,
	[DIVERSITY] [nvarchar](10) NULL,
	[MINORITY_OWNED] [nvarchar](10) NULL,
	[WOMAN_OWNED] [nvarchar](10) NULL,
	[VETERAN_OWNED] [nvarchar](10) NULL,
	[FLEX_FIELD_2] [nvarchar](4000) NULL,
	[ORDER_ROUTING_TYPE] [nvarchar](10) NULL,
	[DSS_CREATE_TIME] [datetime2](7) NULL,
	[DSS_UPDATE_TIME] [datetime2](7) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
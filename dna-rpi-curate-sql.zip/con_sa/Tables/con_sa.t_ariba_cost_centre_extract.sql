﻿CREATE TABLE [con_sa].[t_ariba_cost_centre_extract]
(
	[COST_CENTER_ID] [bigint] NULL,
	[COMPANY_CODE] [nvarchar](10) NULL,
	[COST_CENTER_NAME] [nvarchar](200) NULL,
	[DSS_CREATE_TIME] [datetime2](7) NULL,
	[DSS_UPDATE_TIME] [datetime2](7) NULL,
	[ETLRunLogId] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE PROC [con_sa].[sp_ext_t_ariba_part_extract] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name              : sp_ext_t_ariba_part_extract
Purpose						: Load Extract History table for Part
Target Tables             	: t_ariba_part_extract
*****************************************************************************************
Default values
************************************************************************************************************
               	ETLRunLogId						:  @pETLRunLogID passed as argument


*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Praveen Kumar  	:  Initial Version

**************************************************************************************************************************
*/

     /*--Declarations---*/
	DECLARE @dssTime DATE;


BEGIN    

     SET @dssTime= CURRENT_TIMESTAMP
    BEGIN TRANSACTION;


 BEGIN TRY

 /* Inserting the materialisation output to the final extract table for the latest etlrunlogid */
        
INSERT INTO [con_sa].[t_ariba_part_extract]
(
   ETLRunLogId,
   PART_NUMBER,
   REVISION_NUMBER,
   DESCRIPTION1,
   DESCRIPTION2,
   STANDARD_COST,
   STANDARD_COST_CURRENCY,
   STANDARD_COST_DATE,
   STOCK_INDICATOR,
   MANUFACTURER_NAME,
   MANUFACTURER_PART_NUMBER,
   LEAD_TIME_IN_DAYS,
   FLEX_FIELD_1,
   FLEX_FIELD_2,
   FLEX_FIELD_3,
   PART_FLEX_TEXT_1,
   PART_FLEX_TEXT_2,
   PART_FLEX_TEXT_3,
   ORIGIN_COUNTRY,
   MATERIAL_COMPOSITION,
   FORECAST_USAGE_1,
   FORECAST_USAGE_2,
   FORECAST_USAGE_3,
   DSS_CREATE_TIME         ,
   DSS_UPDATE_TIME         
)
SELECT 
@pETLRunLogID as EtlLogrunId,
a.PART_NUMBER AS PART_NUMBER,
ISNull(a.Revision_number,'') AS REVISION_NUMBER, 
ISNull(a.DESCRIPTION1,'') AS DESCRIPTION1, 
ISNull(a.DESCRIPTION2,'') AS DESCRIPTION2, 
[con_sa].[RemoveLeadingTrailingZeros](a.STANDARD_COST) AS STANDARD_COST, 
ISNull(a.STANDARD_COST_CURRENCY,'') AS STANDARD_COST_CURRENCY, 
ISNull(a.STANDARD_COST_DATE,'') AS STANDARD_COST_DATE, 
ISNull(a.STOCK_INDICATOR,'') AS STOCK_INDICATOR,          
ISNull(a.MANUFACTURER_NAME,'') AS MANUFACTURER_NAME, 
ISNull(a.MANUFACTURER_PART_NUMBER,'') AS MANUFACTURER_PART_NUMBER,
ISNull(a.LEAD_TIME_IN_DAYS,'') AS LEAD_TIME_IN_DAYS,
ISNull(a.FLEX_FIELD_1,'') AS FLEX_FIELD_1,
ISNull(a.FLEX_FIELD_2,'') AS FLEX_FIELD_2,  
ISNull(a.FLEX_FIELD_3,'') AS FLEX_FIELD_3,
ISNull(a.PART_FLEX_TEXT_1,'') AS PART_FLEX_TEXT_1,
ISNull(a.PART_FLEX_TEXT_2,'') AS PART_FLEX_TEXT_2,
ISNull(a.PART_FLEX_TEXT_3,'') AS PART_FLEX_TEXT_3,
ISNull(a.ORIGIN_COUNTRY,'') AS ORIGIN_COUNTRY,
ISNull(a.MATERIAL_COMPOSITION,'') AS MATERIAL_COMPOSITION,       
ISNull(a.FORECAST_USAGE_1,'') AS FORECAST_USAGE_1,     
ISNull(a.FORECAST_USAGE_2,'') AS FORECAST_USAGE_2,  
ISNull(a.FORECAST_USAGE_3,'') AS FORECAST_USAGE_3,
@dssTime AS DSS_CREATE_TIME,
@dssTime AS DSS_UPDATE_TIME
FROM [con_sa].[t_ariba_part] a ;	
   
		
        PRINT 'Info : Completed insertion of t_ariba_part_extract'

		
    COMMIT TRANSACTION;                    
        END TRY
        BEGIN CATCH
                THROW;
                ROLLBACK TRANSACTION ;    
            END CATCH 


END
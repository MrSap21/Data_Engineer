﻿CREATE PROC [con_sa].[sp_ext_t_ariba_cost_centre_extract] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_ext_t_ariba_cost_centre_extract
Purpose						: Loads Extract History table for Cost Centre
Target Tables             	: t_ariba_cost_centre_extract

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Jacob Roy   	:  Initial Version

**************************************************************************************************************************
 */
 
/*--Declarations---*/
DECLARE @current_datetime DATETIME2;
	
BEGIN	
	SET NOCOUNT ON
	SET @current_datetime = CURRENT_TIMESTAMP

	BEGIN TRY
 
	BEGIN TRANSACTION;
	
	
	/* Inserting the materialisation output to the final extract table */
	
		INSERT INTO [con_sa].[t_ariba_cost_centre_extract]
		(
			cost_center_id,
			company_code,
			cost_center_name,
			dss_create_time,
			dss_update_time,
			etlrunlogid
		)
		SELECT 
			cost_center_id, 
			ISNULL(company_code,''), 
			ISNULL(cost_center_name,''),
			@current_datetime dss_create_time,
			@current_datetime dss_update_time,
			@pETLRunLogID etlrunlogid
		FROM con_sa.t_ariba_cost_centre;
                 	  
                
        PRINT 'Info : Completed insertion of t_ariba_cost_centre_extract';
		
    COMMIT TRANSACTION;					
	END TRY
	
	BEGIN CATCH
		THROW
		ROLLBACK TRANSACTION;
	END CATCH 
	
END
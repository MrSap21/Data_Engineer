﻿CREATE PROC [con_sa].[sp_mat_t_ariba_erp_commodity] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name                : sp_mat_t_ariba_erp_commodity
Purpose                        : Load Incremental data For Commodity Materialisation
Target Tables                 : t_ariba_erp_commodity
*****************************************************************************************
Default values
************************************************************************************************************
                ETLRunLogId                        :  @pETLRunLogID passed as argument
*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Shivansh Bajpai   	:  Initial Version

**************************************************************************************************************************
*/

DECLARE @v_Sql VARCHAR(255);    
DECLARE @rowStatusPSACode BIGINT, 
		@time_stamp DATE;

 

BEGIN    
    SET @v_sql = 'TRUNCATE TABLE [con_sa].[t_ariba_erp_commodity];'
	SET @time_stamp= CURRENT_TIMESTAMP
	SET @rowStatusPSACode = 26001
    EXEC(@v_Sql);



    BEGIN TRANSACTION;


 BEGIN TRY
 
  /* Inserting the active psa records (row_status=26001 and active_flag='Y') to the materialisation output table for erp_commodity */
  
    INSERT INTO [con_sa].[t_ariba_erp_commodity]
	(
		[COMMODITY_ID],
		[COMMODITY_NAME],
		[COMMODITY_TYPE],
		[DSS_CREATE_TIME],
		[DSS_UPDATE_TIME]
	) 
	SELECT DISTINCT
	CONVERT(BIGINT,REPLACE(ProductGroupID, ',', '')) AS COMMODITY_ID ,
	REPLACE(trim(cast (Description AS NVARCHAR(40))),'_','') AS  COMMODITY_NAME,
	NULL,
	@time_stamp,
	@time_stamp
	FROM [psa].[LEIT_LEXDH_LE_Product_Group_LEXDH_Incr]
	WHERE row_status = @rowStatusPSACode 
	AND active_flag= 'Y';
	
	PRINT 'Info : Completed insertion of t_ariba_erp_commodity'
    
    COMMIT TRANSACTION;                    
        END TRY
        BEGIN CATCH
                THROW;
                ROLLBACK TRANSACTION ;    
            END CATCH 

 

END
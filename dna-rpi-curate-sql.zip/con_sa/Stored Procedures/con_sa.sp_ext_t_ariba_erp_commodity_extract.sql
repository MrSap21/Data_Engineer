﻿CREATE PROC [con_sa].[sp_ext_t_ariba_erp_commodity_extract] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name                : sp_ext_t_ariba_erp_commodity_extract
Purpose                       : Load extract history table for commodity
Target Tables                 : t_ariba_erp_commodity_extract
*****************************************************************************************
Default values
************************************************************************************************************ 
                ETLRunLogId                        :  @pETLRunLogID passed as argument 
*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Shivansh Bajpai   	:  Initial Version

**************************************************************************************************************************
 */
DECLARE @time_stamp DATE;

 

BEGIN    
SET @time_stamp= CURRENT_TIMESTAMP
 

    BEGIN TRANSACTION;

 

 BEGIN TRY
 
 /* Inserting the materialisation output to the final extract table */
 
		INSERT INTO [con_sa].[t_ariba_erp_commodity_extract]
		(
		[COMMODITY_ID],
		[COMMODITY_NAME],
		[COMMODITY_TYPE],
		[DSS_CREATE_TIME],
		[DSS_UPDATE_TIME],
		[ETLRunLogID]
		)
		SELECT
		COMMODITY_ID AS COMMODITY_ID,
		ISNULL(COMMODITY_NAME,'') AS COMMODITY_NAME,
		ISNULL(COMMODITY_TYPE,'') AS COMMODITY_TYPE,
		@time_stamp AS DSS_CREATE_TIME,
		@time_stamp AS DSS_UPDATE_TIME,
		@pETLRunLogID ETLRunLogId
		FROM [con_sa].[t_ariba_erp_commodity];
    
        
    COMMIT TRANSACTION;                    
        END TRY
        BEGIN CATCH
                THROW;
                ROLLBACK TRANSACTION ;    
            END CATCH 

 

END
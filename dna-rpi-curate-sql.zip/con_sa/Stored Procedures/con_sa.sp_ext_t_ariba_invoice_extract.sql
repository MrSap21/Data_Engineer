﻿CREATE PROC [con_sa].[sp_ext_t_ariba_invoice_extract] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_ext_t_ariba_invoice_extract
Purpose						: Load Extract History table for Invoice
Target Tables             	: t_ariba_invoice_extract

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Disti Jain   	:  Initial Version

**************************************************************************************************************************
 */

	    /*--Declarations---*/
	DECLARE @processingTime DATETIME2;

BEGIN	

    SET @processingTime = CURRENT_TIMESTAMP;
	
	
	BEGIN TRANSACTION;
	
	
 BEGIN TRY
 
 WITH 		 invoice_latest
             AS (SELECT invoice_id,
                        extra_invoice_key,
                        invoice_line_number,
						extra_invoice_line_key,
                        Max(etlrunlogid) AS ETLRunLogId
                 FROM   con_sa.t_ariba_invoice_extract hist
                 GROUP  BY invoice_id,
                           extra_invoice_key,
                           invoice_line_number,
						   extra_invoice_line_key),-- logic to find etlrunlogid last send to ARIBA  for a particular business key combination
             invoice_last_sent
             AS (SELECT hist.*
                 FROM   con_sa.t_ariba_invoice_extract hist
                        JOIN invoice_latest
                          ON hist.etlrunlogid = invoice_latest.etlrunlogid
                             AND hist.invoice_id = invoice_latest.invoice_id
                             AND hist.extra_invoice_key = invoice_latest.extra_invoice_key
                             AND hist.invoice_line_number = invoice_latest.invoice_line_number
							 AND hist.extra_invoice_line_key = invoice_latest.extra_invoice_line_key)-- logic to find the last send records for the business key combination
 
 
 /* Loading the final extract table */
 
		INSERT INTO con_sa.t_ariba_invoice_extract
        SELECT 		ISNULL(INVOICE_ID,''),
					EXTRA_INVOICE_KEY,
					INVOICE_LINE_NUMBER,
					ISNULL(EXTRA_INVOICE_LINE_KEY,''),
					ISNULL(SPLIT_ACCOUNTING_NUMBER,''),
					ACCOUNTING_DATE,
					QUANTITY,
					ISNULL(con_sa.RemoveLeadingTrailingZeros(AMOUNT),''),
					ISNULL(AMOUNT_CURRENCY,''),
					ISNULL(DESCRIPTION,''),
					ERP_COMMODITY_ID,
					ISNULL(PART_NUMBER,''),
					ISNULL(PART_REVISION_NUMBER,''),
					ISNULL(UNIT_OF_MEASURE,''),
					SUPPLIER_ID,
					ISNULL(SUPPLIER_LOCATION_ID,''),
					ISNULL(REQUESTER_ID,''),
					ACCOUNT_ID,
					ISNULL(ACCOUNT_COMPANY_CODE,''),
					ISNULL(COMPANY_SITE_ID,''),
					COST_CENTER_ID,
					ISNULL(COST_CENTER_COMPANY_CODE,''),
					ISNULL(CONTRACT_ID,''),
					PO_ID,
					ISNULL(EXTRA_PO_KEY,''),
					ISNULL(PO_LINE_NUMBER,''),
					ISNULL(EXTRA_PO_LINE_KEY,''),
					INVOICE_DATE,
					ISNULL(PAID_DATE,''),
					ISNULL(INVOICE_NUMBER,''),
					ISNULL(AP_PAYMENT_TERMS,''),
					ISNULL(LINE_TYPE,''),
					ISNULL(FLEX_FIELD_ID_1,''),
					ISNULL(FLEX_FIELD_ID_2,''),
					ISNULL(FLEX_FIELD_ID_3,''),
					ISNULL(FLEX_FIELD_ID_4,''),
					ISNULL(FLEX_FIELD_ID_5,''),
					ISNULL(FLEX_FIELD_ID_6,''),
					ISNULL(FLEX_FIELD_ID_7,''),
					ISNULL(FLEX_FIELD_ID_8,''),
					ISNULL(FLEX_FIELD_ID_9,''),
					ISNULL(FLEX_FIELD_ID_10,''),
					ISNULL(FLEX_FIELD_ID_11,''),
					ISNULL(FLEX_FIELD_ID_12,''),
					ISNULL(FLEX_FIELD_ID_13,''),
					ISNULL(FLEX_FIELD_ID_14,''),
					ISNULL(FLEX_MEASURE_1,''),
					ISNULL(FLEX_MEASURE_2,''),
					ISNULL(FLEX_MEASURE_3,''),
					ISNULL(FLEX_MEASURE_4,''),
					ISNULL(FLEX_MEASURE_5,''),
					ISNULL(FLEX_DATE_1,''),
					ISNULL(FLEX_DATE_2,''),
					ISNULL(FLEX_DATE_3,''),
					ISNULL(FLEX_DATE_4,''),
					ISNULL(FLEX_DATE_5,''),
					ISNULL(FLEX_STRING_1,''),
					ISNULL(FLEX_STRING_2,''),
					ISNULL(FLEX_STRING_3,''),
					ISNULL(FLEX_STRING_4,''),
					ISNULL(FLEX_STRING_5,''),
					ISNULL(FLEX_STRING_6,''),
					ISNULL(FLEX_STRING_7,''),
					ISNULL(FLEX_STRING_8,''),
					ISNULL(FLEX_STRING_9,''),
					ISNULL(FLEX_STRING_10,''),
					@processingTime               DSS_CREATE_TIME,
				    Cast(@processingTime AS TIME) DSS_UPDATE_TIME,
				    @pETLRunLogID                 ETLRunLogId
					FROM   con_sa.t_ariba_invoice a -- To check and insert only new or updated active records for the business key combination. Records without any change are not inserted again.
					WHERE  NOT EXISTS (SELECT 1
                    FROM   invoice_last_sent b
                    WHERE         ISNULL(a.INVOICE_ID, '') = ISNULL(b.INVOICE_ID, '')
                                  AND ISNULL(a.EXTRA_INVOICE_KEY, -1) = ISNULL(b.EXTRA_INVOICE_KEY, -1)
                                  AND ISNULL(a.INVOICE_LINE_NUMBER, -1) = ISNULL(b.INVOICE_LINE_NUMBER, -1)
                                  AND ISNULL(a.EXTRA_INVOICE_LINE_KEY, '') = ISNULL(b.EXTRA_INVOICE_LINE_KEY, '')
                                  AND ISNULL(a.SPLIT_ACCOUNTING_NUMBER, '') = ISNULL(b.SPLIT_ACCOUNTING_NUMBER, '')
                                  AND a.ACCOUNTING_DATE = b.ACCOUNTING_DATE
                                  AND ISNULL(a.QUANTITY, -1) = ISNULL(b.QUANTITY, -1)
                                  AND ISNULL(con_sa.RemoveLeadingTrailingZeros(a.AMOUNT), -1) = ISNULL(b.AMOUNT, -1)
                                  AND ISNULL(a.AMOUNT_CURRENCY, '') = ISNULL(b.AMOUNT_CURRENCY, '')
                                  AND ISNULL(a.DESCRIPTION, '') = ISNULL(b.DESCRIPTION, '')
                                  AND ISNULL(a.ERP_COMMODITY_ID, -1) = ISNULL(b.ERP_COMMODITY_ID, -1)
                                  AND ISNULL(a.PART_NUMBER, '') = ISNULL(b.PART_NUMBER, '')
                                  AND ISNULL(a.PART_REVISION_NUMBER, '') = ISNULL(b.PART_REVISION_NUMBER, '')
                                  AND ISNULL(a.UNIT_OF_MEASURE, '') = ISNULL(b.UNIT_OF_MEASURE, '')
                                  AND ISNULL(a.SUPPLIER_ID, -1) = ISNULL(b.SUPPLIER_ID, -1)
                                  AND ISNULL(a.SUPPLIER_LOCATION_ID, '') = ISNULL(b.SUPPLIER_LOCATION_ID, '')
                                  AND ISNULL(a.REQUESTER_ID, '') = ISNULL(b.REQUESTER_ID, '')
                                  AND ISNULL(a.ACCOUNT_ID, -1) = ISNULL(b.ACCOUNT_ID, -1)
                                  AND ISNULL(a.ACCOUNT_COMPANY_CODE, '') = ISNULL(b.ACCOUNT_COMPANY_CODE, '')
                                  AND ISNULL(a.COMPANY_SITE_ID, '') = ISNULL(b.COMPANY_SITE_ID, '')
                                  AND ISNULL(a.COST_CENTER_ID, -1) = ISNULL(b.COST_CENTER_ID, -1)
                                  AND ISNULL(a.COST_CENTER_COMPANY_CODE, '') = ISNULL(b.COST_CENTER_COMPANY_CODE, '')
                                  AND ISNULL(a.CONTRACT_ID, '') = ISNULL(b.CONTRACT_ID, '')
                                  AND ISNULL(a.PO_ID, -1) = ISNULL(b.PO_ID, -1)
                                  AND ISNULL(a.EXTRA_PO_KEY, '') = ISNULL(b.EXTRA_PO_KEY, '')
								  AND ISNULL(a.PO_LINE_NUMBER, -1) = ISNULL(b.PO_LINE_NUMBER, -1)
								  AND ISNULL(a.EXTRA_PO_LINE_KEY, '') = ISNULL(b.EXTRA_PO_LINE_KEY, '')
								  AND a.INVOICE_DATE = b.INVOICE_DATE
								  AND ISNULL(a.PAID_DATE, '') = ISNULL(b.PAID_DATE, '')
								  AND ISNULL(a.INVOICE_NUMBER, '') = ISNULL(b.INVOICE_NUMBER, '')
								  AND ISNULL(a.AP_PAYMENT_TERMS, '') = ISNULL(b.AP_PAYMENT_TERMS, '')
								  AND ISNULL(a.LINE_TYPE, '') = ISNULL(b.LINE_TYPE, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_1, '') = ISNULL(b.FLEX_FIELD_ID_1, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_2, '') = ISNULL(b.FLEX_FIELD_ID_2, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_3, '') = ISNULL(b.FLEX_FIELD_ID_3, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_4, '') = ISNULL(b.FLEX_FIELD_ID_4, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_5, '') = ISNULL(b.FLEX_FIELD_ID_5, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_6, '') = ISNULL(b.FLEX_FIELD_ID_6, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_7, '') = ISNULL(b.FLEX_FIELD_ID_7, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_8, '') = ISNULL(b.FLEX_FIELD_ID_8, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_9, '') = ISNULL(b.FLEX_FIELD_ID_9, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_10, '') = ISNULL(b.FLEX_FIELD_ID_10, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_11, '') = ISNULL(b.FLEX_FIELD_ID_11, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_12, '') = ISNULL(b.FLEX_FIELD_ID_12, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_13, '') = ISNULL(b.FLEX_FIELD_ID_13, '')
                                  AND ISNULL(a.FLEX_FIELD_ID_14, '') = ISNULL(b.FLEX_FIELD_ID_14, '')
                                  AND ISNULL(a.FLEX_MEASURE_1, '') = ISNULL(b.FLEX_MEASURE_1, '')
                                  AND ISNULL(a.FLEX_MEASURE_2, '') = ISNULL(b.FLEX_MEASURE_2, '')
                                  AND ISNULL(a.FLEX_MEASURE_3, '') = ISNULL(b.FLEX_MEASURE_3, '')
                                  AND ISNULL(a.FLEX_MEASURE_4, '') = ISNULL(b.FLEX_MEASURE_4, '')
                                  AND ISNULL(a.FLEX_MEASURE_5, '') = ISNULL(b.FLEX_MEASURE_5, '')
                                  AND ISNULL(a.FLEX_DATE_1, '') = ISNULL(b.FLEX_DATE_1, '')
                                  AND ISNULL(a.FLEX_DATE_2, '') = ISNULL(b.FLEX_DATE_2, '')
                                  AND ISNULL(a.FLEX_DATE_3, '') = ISNULL(b.FLEX_DATE_3, '')
                                  AND ISNULL(a.FLEX_DATE_4, '') = ISNULL(b.FLEX_DATE_4, '')
                                  AND ISNULL(a.FLEX_DATE_5, '') = ISNULL(b.FLEX_DATE_5, '')
                                  AND ISNULL(a.FLEX_STRING_1, '') = ISNULL(b.FLEX_STRING_1, '')
                                  AND ISNULL(a.FLEX_STRING_2, '') = ISNULL(b.FLEX_STRING_2, '')
                                  AND ISNULL(a.FLEX_STRING_3, '') = ISNULL(b.FLEX_STRING_3, '')
                                  AND ISNULL(a.FLEX_STRING_4, '') = ISNULL(b.FLEX_STRING_4, '')
                                  AND ISNULL(a.FLEX_STRING_5, '') = ISNULL(b.FLEX_STRING_5, '')
                                  AND ISNULL(a.FLEX_STRING_6, '') = ISNULL(b.FLEX_STRING_6, '')
                                  AND ISNULL(a.FLEX_STRING_7, '') = ISNULL(b.FLEX_STRING_7, '')
                                  AND ISNULL(a.FLEX_STRING_8, '') = ISNULL(b.FLEX_STRING_8, '')
                                  AND ISNULL(a.FLEX_STRING_9, '') = ISNULL(b.FLEX_STRING_9, '')
                                  AND ISNULL(a.FLEX_STRING_10, '') = ISNULL(b.FLEX_STRING_10, ''))
								  AND (accounting_date < Dateadd(month, Datediff(month, 0, @processingTime),0))
					-- Records with accounting_date less than the current processing month only should be inserted
					
				PRINT 'Info : Completed insertion of t_ariba_invoice_extract'
		
    COMMIT TRANSACTION;					
		END TRY
	    BEGIN CATCH
				THROW;
			END CATCH 

END
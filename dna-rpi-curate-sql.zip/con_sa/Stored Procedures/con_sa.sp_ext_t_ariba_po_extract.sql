﻿CREATE PROC [con_sa].[sp_ext_t_ariba_po_extract] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_ext_t_ariba_po_extract
Purpose						: Load Extract History table for Purchase Order
Target Tables             	: t_ariba_po_extract

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Sunitha George V  	:  Initial Version

**************************************************************************************************************************
*/

	    /*--Declarations---*/
	DECLARE @processingTime DATETIME2;

BEGIN	

    SET @processingTime = CURRENT_TIMESTAMP;
	
	
	BEGIN TRANSACTION;
	
	
 BEGIN TRY

        WITH po_latest
             AS (SELECT po_id,
                        extra_po_key,
                        po_line_number,
                        extra_po_line_key,
                        Max(etlrunlogid) AS ETLRunLogId
                 FROM   con_sa.t_ariba_po_extract hist
                 GROUP  BY po_id,
                           extra_po_key,
                           po_line_number,
                           extra_po_line_key),-- logic to find etlrunlogid last send to ARIBA  for a particular business key combination
             po_last_sent
             AS (SELECT hist.*
                 FROM   con_sa.t_ariba_po_extract hist
                        JOIN po_latest
                          ON hist.etlrunlogid = po_latest.etlrunlogid
                             AND hist.po_id = po_latest.po_id
                             AND ISNULL(hist.extra_po_key,'') = ISNULL(po_latest.extra_po_key, '')
                             AND hist.po_line_number = po_latest.po_line_number
                             AND hist.extra_po_line_key = po_latest.extra_po_line_key) -- logic to find the last send records for the business key combination
							 
		 /* Loading the final extract table */
		 
        INSERT INTO con_sa.t_ariba_po_extract
        SELECT po_id,
               ISNULL(extra_po_key,''),
               po_line_number,
               ISNULL(extra_po_line_key,''),
               ISNULL(split_accounting_number,''),
               ISNULL(ordered_date,''),
               quantity,
               ISNULL(amount,''),
               ISNULL(amount_currency,''),
               ISNULL(description,''),
               erp_commodity_id,
               ISNULL(part_number,''),
               ISNULL(part_revision_number,''),
               ISNULL(unit_of_measure,''),
               supplier_id,
               ISNULL(supplier_location_id,''),
               ISNULL(requester_id,''),
               account_id,
               ISNULL(account_company_code,''),
               ISNULL(company_site_id,''),
               cost_center_id,
               ISNULL(cost_center_company_code,''),
               ISNULL(contract_id,''),
               ISNULL(duration_in_months,''),
               ISNULL(open_po_indicator,''),
               ISNULL(line_type,''),
               ISNULL(flex_field_id_1,''),
               ISNULL(flex_field_id_2,''),
               ISNULL(flex_field_id_3,''),
               ISNULL(flex_field_id_4,''),
               ISNULL(flex_field_id_5,''),
               ISNULL(flex_field_id_6,''),
               ISNULL(flex_field_id_7,''),
               ISNULL(flex_field_id_8,''),
               ISNULL(flex_field_id_9,''),
               ISNULL(flex_field_id_10,''),
               ISNULL(flex_field_id_11,''),
               ISNULL(flex_field_id_12,''),
               ISNULL(flex_field_id_13,''),
               ISNULL(flex_field_id_14,''),
               ISNULL(flex_measure_1,''),
               ISNULL(flex_measure_2,''),
               ISNULL(flex_measure_3,''),
               ISNULL(flex_measure_4,''),
               ISNULL(flex_measure_5,''),
               ISNULL(flex_date_1,''),
               ISNULL(flex_date_2,''),
               ISNULL(flex_date_3,''),
               ISNULL(flex_date_4,''),
               ISNULL(flex_date_5,''),
               ISNULL(flex_string_1,''),
               ISNULL(flex_string_2,''),
               ISNULL(flex_string_3,''),
               ISNULL(flex_string_4,''),
               ISNULL(flex_string_5,''),
               ISNULL(flex_string_6,''),
               ISNULL(flex_string_7,''),
               ISNULL(flex_string_8,''),
               ISNULL(flex_string_9,''),
               ISNULL(flex_string_10,''),
               @processingTime               DSS_CREATE_TIME,
               Cast(@processingTime AS TIME) DSS_UPDATE_TIME,
               @pETLRunLogID                         ETLRunLogId
        FROM   con_sa.t_ariba_po a -- To check and insert only new or updated active records for the business key combination. Records without any change are not inserted again.
        WHERE  NOT EXISTS (SELECT 1
                           FROM   po_last_sent b
                           WHERE  ISNULL(a.po_id, -1) = ISNULL(b.po_id, -1)
                                  AND ISNULL(a.extra_po_key, '') = ISNULL(b.extra_po_key, '')
                                  AND ISNULL(a.po_line_number, -1) = ISNULL(b.po_line_number, -1)
                                  AND ISNULL(a.extra_po_line_key, '') = ISNULL(b.extra_po_line_key, '')
                                  AND ISNULL(a.split_accounting_number, '') = ISNULL(b.split_accounting_number, '')
                                  AND ISNULL(a.ordered_date,'') = ISNULL(b.ordered_date,'')
                                  AND ISNULL(a.quantity, -1) = ISNULL(b.quantity, -1)
                                  AND ISNULL(a.amount, '') = ISNULL(b.amount, '')
                                  AND ISNULL(a.amount_currency, '') = ISNULL(b.amount_currency, '')
                                  AND ISNULL(a.description, '') = ISNULL(b.description, '')
                                  AND ISNULL(a.erp_commodity_id, -1) = ISNULL(b.erp_commodity_id, -1)
                                  AND ISNULL(a.part_number, '') = ISNULL(b.part_number, '')
                                  AND ISNULL(a.part_revision_number, '') = ISNULL(b.part_revision_number, '')
                                  AND ISNULL(a.unit_of_measure, '') = ISNULL(b.unit_of_measure, '')
                                  AND ISNULL(a.supplier_id, -1) = ISNULL(b.supplier_id, -1)
                                  AND ISNULL(a.supplier_location_id, '') = ISNULL(b.supplier_location_id, '')
                                  AND ISNULL(a.requester_id, '') = ISNULL(b.requester_id, '')
                                  AND ISNULL(a.account_id, -1) = ISNULL(b.account_id, -1)
                                  AND ISNULL(a.account_company_code, '') = ISNULL(b.account_company_code, '')
                                  AND ISNULL(a.company_site_id, '') = ISNULL(b.company_site_id, '')
                                  AND ISNULL(a.cost_center_id, -1) = ISNULL(b.cost_center_id, -1)
                                  AND ISNULL(a.cost_center_company_code, '') = ISNULL(b.cost_center_company_code, '')
                                  AND ISNULL(a.contract_id, '') = ISNULL(b.contract_id, '')
                                  AND ISNULL(a.duration_in_months, '') = ISNULL(b.duration_in_months, '')
                                  AND ISNULL(a.open_po_indicator, '') = ISNULL(b.open_po_indicator, '')
                                  AND ISNULL(a.line_type, '') = ISNULL(b.line_type, '')
                                  AND ISNULL(a.flex_field_id_1, '') = ISNULL(b.flex_field_id_1, '')
                                  AND ISNULL(a.flex_field_id_2, '') = ISNULL(b.flex_field_id_2, '')
                                  AND ISNULL(a.flex_field_id_3, '') = ISNULL(b.flex_field_id_3, '')
                                  AND ISNULL(a.flex_field_id_4, '') = ISNULL(b.flex_field_id_4, '')
                                  AND ISNULL(a.flex_field_id_5, '') = ISNULL(b.flex_field_id_5, '')
                                  AND ISNULL(a.flex_field_id_6, '') = ISNULL(b.flex_field_id_6, '')
                                  AND ISNULL(a.flex_field_id_7, '') = ISNULL(b.flex_field_id_7, '')
                                  AND ISNULL(a.flex_field_id_8, '') = ISNULL(b.flex_field_id_8, '')
                                  AND ISNULL(a.flex_field_id_9, '') = ISNULL(b.flex_field_id_9, '')
                                  AND ISNULL(a.flex_field_id_10, '') = ISNULL(b.flex_field_id_10, '')
                                  AND ISNULL(a.flex_field_id_11, '') = ISNULL(b.flex_field_id_11, '')
                                  AND ISNULL(a.flex_field_id_12, '') = ISNULL(b.flex_field_id_12, '')
                                  AND ISNULL(a.flex_field_id_13, '') = ISNULL(b.flex_field_id_13, '')
                                  AND ISNULL(a.flex_field_id_14, '') = ISNULL(b.flex_field_id_14, '')
                                  AND ISNULL(a.flex_measure_1, '') = ISNULL(b.flex_measure_1, '')
                                  AND ISNULL(a.flex_measure_2, '') = ISNULL(b.flex_measure_2, '')
                                  AND ISNULL(a.flex_measure_3, '') = ISNULL(b.flex_measure_3, '')
                                  AND ISNULL(a.flex_measure_4, '') = ISNULL(b.flex_measure_4, '')
                                  AND ISNULL(a.flex_measure_5, '') = ISNULL(b.flex_measure_5, '')
                                  AND ISNULL(a.flex_date_1, '') = ISNULL(b.flex_date_1, '')
                                  AND ISNULL(a.flex_date_2, '') = ISNULL(b.flex_date_2, '')
                                  AND ISNULL(a.flex_date_3, '') = ISNULL(b.flex_date_3, '')
                                  AND ISNULL(a.flex_date_4, '') = ISNULL(b.flex_date_4, '')
                                  AND ISNULL(a.flex_date_5, '') = ISNULL(b.flex_date_5, '')
                                  AND ISNULL(a.flex_string_1, '') = ISNULL(b.flex_string_1, '')
                                  AND ISNULL(a.flex_string_2, '') = ISNULL(b.flex_string_2, '')
                                  AND ISNULL(a.flex_string_3, '') = ISNULL(b.flex_string_3, '')
                                  AND ISNULL(a.flex_string_4, '') = ISNULL(b.flex_string_4, '')
                                  AND ISNULL(a.flex_string_5, '') = ISNULL(b.flex_string_5, '')
                                  AND ISNULL(a.flex_string_6, '') = ISNULL(b.flex_string_6, '')
                                  AND ISNULL(a.flex_string_7, '') = ISNULL(b.flex_string_7, '')
                                  AND ISNULL(a.flex_string_8, '') = ISNULL(b.flex_string_8, '')
                                  AND ISNULL(a.flex_string_9, '') = ISNULL(b.flex_string_9, '')
                                  AND ISNULL(a.flex_string_10, '') = ISNULL(b.flex_string_10, ''))
               AND ordered_date < Dateadd(month, Datediff(month, 0, @processingTime),0)  
			  -- Records with ordered_date less than the current processing month only should be inserted 
			   
            PRINT 'Info : Completed insertion of t_ariba_po_extract'
		
    COMMIT TRANSACTION;					
		END TRY
	    BEGIN CATCH
				THROW;
			END CATCH 

END
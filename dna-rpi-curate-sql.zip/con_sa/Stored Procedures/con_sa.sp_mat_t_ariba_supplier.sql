﻿CREATE PROC [con_sa].[sp_mat_t_ariba_supplier] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_mat_t_ariba_supplier
Purpose						: Load Incremental data For Supplier Materialisation
Target Tables             	: t_ariba_supplier

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Jacob Roy   	:  Initial Version

**************************************************************************************************************************
*/

/*--Declarations---*/
DECLARE @rowStatusPSACode BIGINT,
		@trunc_sql varchar(255),
		@current_datetime DATETIME2;
	
BEGIN	
	SET NOCOUNT ON
	SET @trunc_sql = 'TRUNCATE TABLE [con_sa].[t_ariba_supplier]'		
	SET @current_datetime = CURRENT_TIMESTAMP
	SET @rowStatusPSACode = 26001
	
	/*-------------------------------Dropping temp table if already exists-------------------------------*/
	IF OBJECT_ID('tempdb..#t_ariba_supplier_stage') IS NOT NULL
	BEGIN
		DROP table  tempdb..#t_ariba_supplier_stage
	END
	
    /*-------------------------------Truncate target table-------------------------------*/

    EXEC (@trunc_sql)	
		
	PRINT 'Info : Completed truncating t_ariba_supplier';
	
	
    WITH pl_supplier_account AS
    (
       SELECT
          CONVERT(BIGINT, REPLACE(PLSupplierAccountID, ',', '')) PLSupplierAccountID,
          SupplierAccountName,
          REPLACE(LEIT_LEXDH_LE_PL_Supplier_Account_LEXDH_Incr.PaymentTermsInDays, ',', '') PaymentTermsInDays,
          CONVERT(BIGINT, REPLACE(PLPaymentGroupID, ',', '')) PLPaymentGroupID,
          CONVERT(BIGINT, REPLACE(SYSPaymentTermsBasisID, ',', '')) SYSPaymentTermsBasisID 
       FROM
          psa.LEIT_LEXDH_LE_PL_Supplier_Account_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    , -- picking the active records from LEIT_LEXDH_LE_PL_Supplier_Account_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    sys_contact_type AS
    (
       SELECT
          SYSContactTypeID,
          Name 
       FROM
          psa.LEIT_LEXDH_LE_Sys_Contact_Type_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    , -- picking the active records from LEIT_LEXDH_LE_Sys_Contact_Type_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    pl_supplier_contact AS
    (
       SELECT
          CONVERT(BIGINT, REPLACE(PLSupplierContactID, ',', '')) PLSupplierContactID,
          CONVERT(BIGINT, REPLACE(PLSupplierAccountID, ',', '')) PLSupplierAccountID,
          CAST(ContactName AS nvarchar(30)) ContactName,
          CONVERT(BIGINT, REPLACE(PLSupplierLocationID, ',', '')) PLSupplierLocationID 
       FROM
          psa.LEIT_LEXDH_LE_PL_Supplier_Contact_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    , -- picking the active records from LEIT_LEXDH_LE_PL_Supplier_Contact_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    pl_supplier_contact_value AS
    (
       SELECT
          CAST(ContactValue AS nvarchar(30)) ContactValue,
          CAST(IsPreferredValue AS nvarchar(5)) IsPreferredValue,
          CONVERT(BIGINT, REPLACE(PLSupplierContactID, ',', '')) PLSupplierContactID,
          CONVERT(BIGINT, REPLACE(SYSContactTypeID, ',', '')) SYSContactTypeID 
       FROM
          psa.LEIT_LEXDH_LE_PL_Supplier_Contact_Value_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    ,  -- picking the active records from LEIT_LEXDH_LE_PL_Supplier_Contact_Value_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    pl_supplier_contact_role AS
    (
       SELECT
          CONVERT(BIGINT, REPLACE(SYSTraderContactRoleID, ',', '')) SYSTraderContactRoleID,
          CAST(IsPreferredContactForRole AS nvarchar(5)) IsPreferredContactForRole,
          CONVERT(BIGINT, REPLACE(PLSupplierContactID, ',', '')) PLSupplierContactID 
       FROM
          psa.LEIT_LEXDH_LE_PL_Supplier_Contact_Role_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    , -- picking the active records from LEIT_LEXDH_LE_PL_Supplier_Contact_Role_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    sys_trader_contact_role AS
    (
       SELECT
          CONVERT(BIGINT, REPLACE(SYSTraderContactRoleID, ',', '')) SYSTraderContactRoleID 
       FROM
          psa.LEIT_LEXDH_LE_SYS_Trader_Contact_Role_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    , -- picking the active records from LEIT_LEXDH_LE_SYS_Trader_Contact_Role_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    pl_supplier_location AS
    (
       SELECT
          CAST(AddressLine1 AS nvarchar(30)) AddressLine1,
          CAST(AddressLine2 AS nvarchar(30)) AddressLine2,
          CAST(AddressLine3 AS nvarchar(30)) AddressLine3,
          CAST(AddressLine4 AS nvarchar(30)) AddressLine4,
          CAST(City AS nvarchar(30)) City,
          CAST(County AS nvarchar(30)) County,
          CAST(PostCode AS nvarchar(30)) PostCode,
          CONVERT(BIGINT, REPLACE(PLSupplierLocationID, ',', '')) PLSupplierLocationID,
          CAST(Country AS nvarchar(30)) Country 
       FROM
          psa.LEIT_LEXDH_LE_PL_Supplier_Location_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    ,  -- picking the active records from LEIT_LEXDH_LE_PL_Supplier_Location_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    sys_country_code AS
    (
       SELECT
          CAST(Code AS nvarchar(2)) Code,
          CAST(Name AS nvarchar(30)) Name 
       FROM
          psa.LEIT_LEXDH_LE_SYS_Country_Code_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    , -- picking the active records from LEIT_LEXDH_LE_SYS_Country_Code_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    pl_payment_group AS
    (
       SELECT
          CAST(Description AS nvarchar(30)) Description,
          CONVERT(BIGINT, REPLACE(PLPaymentGroupID, ',', '')) PLPaymentGroupID 
       FROM
          psa.LEIT_LEXDH_LE_PL_Payment_Group_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    , -- picking the active records from LEIT_LEXDH_LE_PL_Payment_Group_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    sys_payment_terms_basis AS
    (
       SELECT
          CAST(Name AS nvarchar(40)) Name,
          CONVERT(BIGINT, REPLACE(SYSPaymentTermsBasisID, ',', '')) SYSPaymentTermsBasisID 
       FROM
          psa.LEIT_LEXDH_LE_SYS_Payment_Terms_Basis_LEXDH_Incr 
       WHERE
          active_flag = 'Y' 
          and row_status = @rowStatusPSACode 
    )
    ,  -- picking the active records from LEIT_LEXDH_LE_SYS_Payment_Terms_Basis_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
	
    sage_acct_contact_7_latest AS
    (
       SELECT
          PLSupplierAccountID AS pl_supplier_account_id,
          PLSupplierContactID AS pl_supplier_contact_id,
          ROW_NUMBER() OVER (PARTITION BY PLSupplierAccountID 
       ORDER BY
          PLSupplierContactID DESC) AS rn 
       FROM
          pl_supplier_contact 
    )
    , -- finding the row_number  based on the PLSupplierAccountID and  PLSupplierContactID from pl_supplier_contact
	
    sage_acct_contact_1_all_dat AS
    (
       SELECT
          pl_supplier_account.PLSupplierAccountID pl_supplier_account_id,
          sys_contact_type.SYSContactTypeID contact_type_id,
          pl_supplier_contact.PLSupplierContactID pl_supplier_contact_id,
          sys_contact_type.Name contact_type_description,
          pl_supplier_contact_value.ContactValue contact_value,
          pl_supplier_contact_role.SYSTraderContactRoleID sys_trader_contact_role_id,
          pl_supplier_contact_role.IsPreferredContactForRole is_preferred_contact_for_role,
          pl_supplier_contact_value.IsPreferredValue is_preferred_value,
          sys_trader_contact_role.SYSTraderContactRoleID lineage_only_column 
       FROM
          pl_supplier_contact 
          JOIN
             pl_supplier_contact_role 
             ON pl_supplier_contact.PLSupplierContactID = pl_supplier_contact_role.PLSupplierContactID 
          JOIN
             sys_trader_contact_role 
             ON pl_supplier_contact_role.SYSTraderContactRoleID = sys_trader_contact_role.SYSTraderContactRoleID 
          JOIN
             pl_supplier_contact_value 
             ON pl_supplier_contact_role.PLSupplierContactID = pl_supplier_contact_value.PLSupplierContactID 
          JOIN
             sys_contact_type 
             ON pl_supplier_contact_value.SYSContactTypeID = sys_contact_type.SYSContactTypeID 
          JOIN
             pl_supplier_account 
             ON pl_supplier_account.PLSupplierAccountID = pl_supplier_contact.PLSupplierAccountID 
    )
    , -- joining psa tables  aliases to create the alias sage_acct_contact_1_all_dat to use in the below aliases
	
    sage_acct_contact_2_prefer AS 
    (
       SELECT
          sage_acct_contact_1_all_dat.pl_supplier_account_id,
          sage_acct_contact_1_all_dat.contact_type_id,
          sage_acct_contact_1_all_dat.pl_supplier_contact_id,
          sage_acct_contact_1_all_dat.contact_type_description,
          sage_acct_contact_1_all_dat.contact_value 
       FROM
          sage_acct_contact_1_all_dat 
       WHERE
          sys_trader_contact_role_id = 1 
          AND is_preferred_contact_for_role = 'True' 
          AND is_preferred_value = 'True' 
          AND contact_value IS NOT NULL 
    )
    , -- pulling records for supplier which has sys_trader_contact_role_id=1 and is_preferred_contact_for_role and is_preferred_value as 'True' and contact_value is not NULL
	
    sage_acct_contact_3_all_ord AS 
    (
       SELECT
          sage_acct_contact_1_all_dat.pl_supplier_account_id,
          sage_acct_contact_1_all_dat.contact_type_id,
          sage_acct_contact_1_all_dat.pl_supplier_contact_id,
          sage_acct_contact_1_all_dat.contact_type_description,
          sage_acct_contact_1_all_dat.contact_value,
          ROW_NUMBER() OVER (PARTITION BY pl_supplier_account_id, contact_type_id 
       ORDER BY
          pl_supplier_contact_id DESC) rn 
       FROM
          sage_acct_contact_1_all_dat 
       WHERE
          sys_trader_contact_role_id = 1 
          AND contact_value IS NOT NULL 
    )
    , -- ranking the records with sys_trader_contact_role_id = 1  and contact_value IS NOT NULL 
	
    sage_acct_contact_4_youngst AS 
    (
       SELECT
          sage_acct_contact_3_all_ord.pl_supplier_account_id,
          sage_acct_contact_3_all_ord.contact_type_id,
          sage_acct_contact_3_all_ord.pl_supplier_contact_id,
          sage_acct_contact_3_all_ord.contact_type_description,
          sage_acct_contact_3_all_ord.contact_value 
       FROM
          sage_acct_contact_3_all_ord sage_acct_contact_3_all_ord 
       WHERE
          rn = 1 
    )
    , -- pulling records with row_number 1 alone 
	
    sage_acct_contact_5_combine AS 
    (
       SELECT
          sage_acct_contact_4_youngst.pl_supplier_account_id,
          sage_acct_contact_4_youngst.contact_type_id,
          ISNULL(sage_acct_contact_2_prefer.pl_supplier_contact_id , sage_acct_contact_4_youngst.pl_supplier_contact_id ) pl_supplier_contact_id,
          ISNULL(sage_acct_contact_2_prefer.contact_type_description , sage_acct_contact_4_youngst.contact_type_description) contact_type_description,
          ISNULL(sage_acct_contact_2_prefer.contact_value , sage_acct_contact_4_youngst.contact_value) contact_value 
       FROM
          sage_acct_contact_2_prefer sage_acct_contact_2_prefer 
          RIGHT JOIN
             sage_acct_contact_4_youngst sage_acct_contact_4_youngst 
             ON sage_acct_contact_2_prefer.pl_supplier_account_id = sage_acct_contact_4_youngst.pl_supplier_account_id 
             AND sage_acct_contact_2_prefer.contact_type_id = sage_acct_contact_4_youngst.contact_type_id 
    )
    , -- joining psa tables  aliases to create the alias sage_acct_contact_5_combine to use in the below aliases
	
    sage_acct_contact_6_telephn AS 
    (
       SELECT
          sage_acct_contact_5_combine.pl_supplier_account_id,
          sage_acct_contact_5_combine.pl_supplier_contact_id,
          sage_acct_contact_5_combine.contact_value contact_telephone_number 
       FROM
          sage_acct_contact_5_combine sage_acct_contact_5_combine 
       WHERE
          contact_type_description = 'Telephone Number' 
    )
    , -- pulling records with contact_type_description as  'Telephone Number'
	
    sage_acct_contact_6_email AS 
    (
       SELECT
          sage_acct_contact_5_combine.pl_supplier_account_id,
          sage_acct_contact_5_combine.pl_supplier_contact_id,
          sage_acct_contact_5_combine.contact_value contact_email_address 
       FROM
          sage_acct_contact_5_combine sage_acct_contact_5_combine 
       WHERE
          contact_type_description = 'E-mail Address' 
    )
    , -- pulling records with contact_type_description as  email 
	
    sage_acct_contact_6_fax AS 
    (
       SELECT
          sage_acct_contact_5_combine.pl_supplier_account_id,
          sage_acct_contact_5_combine.pl_supplier_contact_id,
          sage_acct_contact_5_combine.contact_value contact_fax_number 
       FROM
          sage_acct_contact_5_combine sage_acct_contact_5_combine 
       WHERE
          contact_type_description = 'Fax Number' 
    ) -- pulling records with contact_type_description as  fax 
    	
    	SELECT DISTINCT
        pl_supplier_account.PLSupplierAccountID AS supplier_id,
        NULL AS supplier_location_id,
        pl_supplier_account.SupplierAccountName AS supplier_name,
        pl_supplier_location.AddressLine1 + COALESCE(', ' + pl_supplier_location.AddressLine2, '')
        + COALESCE(', ' + pl_supplier_location.AddressLine3, '') + COALESCE(', ' + pl_supplier_location.AddressLine4, '') AS street_address,
        pl_supplier_location.City AS city,
        pl_supplier_location.County AS state,
        sys_country_code.Code AS country,
        pl_supplier_location.PostCode AS postal_code,
        'External' AS supplier_type,
        pl_supplier_contact.ContactName AS contact_first_name,
        NULL AS contact_last_name,
        sage_acct_contact_6_telephn.contact_telephone_number AS contact_phone_number,
        sage_acct_contact_6_email.contact_email_address AS contact_email,
        'English' AS preferred_language,
        sage_acct_contact_6_fax.contact_fax_number AS fax_number,
        NULL AS duns_number,
        NULL AS an_number,
        pl_payment_group.Description AS payment_type,
        NULL AS diversity,
        NULL AS minority_owned,
        NULL AS woman_owned,
        NULL AS veteran_owned,
        CASE
            WHEN sys_payment_terms_basis.Name = 'Calendar Monthly' THEN
                'Calendar monthly'
            ELSE
                pl_supplier_account.PaymentTermsInDays + ' days ' + LOWER(sys_payment_terms_basis.Name)
        END AS flex_field_2,
        NULL AS order_routing_type
    into #t_ariba_supplier_stage
    FROM pl_supplier_account
        LEFT JOIN sage_acct_contact_6_telephn sage_acct_contact_6_telephn
            ON pl_supplier_account.PLSupplierAccountID = sage_acct_contact_6_telephn.pl_supplier_account_id
        LEFT JOIN sage_acct_contact_6_email sage_acct_contact_6_email
            ON pl_supplier_account.PLSupplierAccountID = sage_acct_contact_6_email.pl_supplier_account_id
        LEFT JOIN sage_acct_contact_6_fax sage_acct_contact_6_fax
            ON pl_supplier_account.PLSupplierAccountID = sage_acct_contact_6_fax.pl_supplier_account_id
        LEFT JOIN sage_acct_contact_7_latest
            ON pl_supplier_account.PLSupplierAccountID = sage_acct_contact_7_latest.pl_supplier_account_id
               AND sage_acct_contact_7_latest.rn = 1
        LEFT JOIN pl_supplier_contact
            ON pl_supplier_contact.PLSupplierContactID = COALESCE(sage_acct_contact_6_telephn.pl_supplier_contact_id, sage_acct_contact_6_email.pl_supplier_contact_id, sage_acct_contact_6_fax.pl_supplier_contact_id, sage_acct_contact_7_latest.pl_supplier_contact_id)
        LEFT JOIN pl_supplier_location
            ON pl_supplier_contact.PLSupplierLocationID = pl_supplier_location.PLSupplierLocationID
        LEFT JOIN pl_payment_group
            ON pl_supplier_account.PLPaymentGroupID = pl_payment_group.PLPaymentGroupID
        LEFT JOIN sys_payment_terms_basis
            ON pl_supplier_account.SYSPaymentTermsBasisID = sys_payment_terms_basis.SYSPaymentTermsBasisID
        LEFT JOIN sys_country_code
            ON pl_supplier_location.Country = sys_country_code.Name
	
	BEGIN TRY
 
	BEGIN TRANSACTION;
	
	/* Inserting the data from  t_ariba_supplier_stage to the materialisation output table for supplier  */
	
		INSERT INTO [con_sa].[t_ariba_supplier]
		(
			supplier_id,
			supplier_location_id,
			supplier_name,
			street_address,
			city,
			state,
			country,
			postal_code,
			supplier_type,
			contact_first_name,
			contact_last_name,
			contact_phone_number,
			contact_email,
			preferred_language,
			fax_number,
			duns_number,
			an_number,
			payment_type,
			diversity,
			minority_owned,
			woman_owned,
			veteran_owned,
			flex_field_2,
			order_routing_type,
			dss_create_time,
			dss_update_time
		)
		SELECT 
			supplier_id,
			supplier_location_id,
			REPLACE(TRIM(supplier_name),'_',''),
			REPLACE(TRIM(street_address),'_',''),
			REPLACE(TRIM(city),'_',''),
			REPLACE(TRIM(state),'_',''),
			REPLACE(TRIM(country),'_',''),
			REPLACE(TRIM(postal_code),'_',''),
			REPLACE(TRIM(supplier_type),'_',''),
			REPLACE(TRIM(contact_first_name),'_',''),
			contact_last_name,
			REPLACE(TRIM(contact_phone_number),'_',''),
			REPLACE(TRIM(contact_email),'_',''),
			REPLACE(TRIM(preferred_language),'_',''),
			REPLACE(TRIM(fax_number),'_',''),
			duns_number,
			an_number,
			REPLACE(TRIM(payment_type),'_',''),
			diversity,
			minority_owned,
			woman_owned,
			veteran_owned,
			REPLACE(TRIM(flex_field_2),'_',''),
			order_routing_type,
			@current_datetime,
			@current_datetime
		FROM #t_ariba_supplier_stage;
                 	  
        PRINT 'Info : Completed insertion of t_ariba_supplier'
		
    COMMIT TRANSACTION;					
	END TRY
	BEGIN CATCH
		THROW
		ROLLBACK TRANSACTION;
	END CATCH 

END
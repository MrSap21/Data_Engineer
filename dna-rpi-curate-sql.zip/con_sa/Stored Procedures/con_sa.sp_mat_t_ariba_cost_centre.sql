﻿CREATE PROC [con_sa].[sp_mat_t_ariba_cost_centre] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_mat_t_ariba_cost_centre
Purpose						: Load Incremental data For Cost Centre Materialisation
Target Tables             	: t_ariba_cost_centre

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Jacob Roy   	:  Initial Version

**************************************************************************************************************************
*/

/*--Declarations---*/
DECLARE @rowStatusPSACode BIGINT,
		@trunc_sql varchar(255),
		@current_datetime DATETIME2;
	
BEGIN	
	SET NOCOUNT ON
	SET @trunc_sql = 'TRUNCATE TABLE [con_sa].[t_ariba_cost_centre]'		
	SET @current_datetime = CURRENT_TIMESTAMP
	SET @rowStatusPSACode = 26001

    /*-------------------------------Truncate target table-------------------------------*/

    EXEC (@trunc_sql)	
		
	PRINT 'Info : Completed truncating t_ariba_cost_centre'

	BEGIN TRY
 
	BEGIN TRANSACTION;
	
	 /* Inserting the active psa records (row_status=26001 and active_flag='Y') to the materialisation output table for cost_centre */
	 
		INSERT  INTO [con_sa].[t_ariba_cost_centre]
		(
			cost_center_id,
			company_code,
			cost_center_name,
			dss_create_time,
			dss_update_time
		)
		SELECT DISTINCT
			CONVERT(BIGINT,(REPLACE(NLCostCentreID, ',', ''))),
			REPLACE(TRIM(CAST(CONVERT(BIGINT,(REPLACE(Code, ',', ''))) AS nvarchar(10))),'_',''),
			REPLACE(TRIM(Name),'_',''),
			@current_datetime,
			@current_datetime
		FROM psa.LEIT_LEXDH_LE_NL_Cost_Centre_LEXDH_Incr
		WHERE active_flag = 'Y' and row_status=@rowStatusPSACode;
                 	  
        PRINT 'Info : Completed insertion of t_ariba_cost_centre'
		
    COMMIT TRANSACTION;					
	END TRY
	BEGIN CATCH
		THROW
		ROLLBACK TRANSACTION;
	END CATCH 

END
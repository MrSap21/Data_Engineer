﻿CREATE PROC [con_sa].[sp_mat_t_ariba_invoice] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_mat_t_ariba_invoice
Purpose						: Load Incremental data For Invoice Materialisation
Target Tables             	: t_ariba_invoice

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Disti Jain   	:  Initial Version

**************************************************************************************************************************
*/

     /*--Declarations---*/
	DECLARE @rowStatusPSACode BIGINT,
			@processingTime DATETIME2;
		
	
/*-------------------------------Drop temporary source table-------------------------------*/
	
	IF OBJECT_ID('tempdb..#t_ariba_invoice_stage') IS NOT NULL
	BEGIN
		drop table tempdb..#t_ariba_invoice_stage;
	END
	
   /*-------------------------------Truncate target table-------------------------------*/

    truncate table con_sa.t_ariba_invoice	
		
	PRINT 'Info : Completed truncating t_ariba_invoice'

BEGIN	
	
	SET @rowStatusPSACode = 26001;	
	SET @processingTime = CURRENT_TIMESTAMP;
	
 BEGIN TRY
 	
     WITH pl_posted_supplier_trans AS (
    			SELECT  DISTINCT TransactionReference AS transaction_reference,
    					PLPostedSupplierTranID AS pl_posted_supplier_tran_id,
    					TransactionDate AS transaction_date,	
    					PostedDate AS posted_date,					
    					PLSupplierAccountID AS pl_supplier_account_id,
    					FullSettlementDate AS full_settlement_date,
    					ROW_NUMBER() OVER ( 
    					PARTITION BY TransactionReference, TransactionDate 
    					ORDER BY FullSettlementDate DESC, PLPostedSupplierTranID DESC 
    					) AS rn
    				    FROM   [psa].[LEIT_LEXDH_LE_PL_Posted_Supplier_Transaction_LEXDH_Incr]
                        WHERE Source = 8 AND row_status = @rowStatusPSACode AND active_flag = 'Y'),
            -- picking the active records from LEIT_LEXDH_LE_PL_Posted_Supplier_Transaction_LEXDH_Incr for the Invoice source (8) with row_status = 26001 and active_flag = 'Y' 
    		
    	 pop_invoice_credit_line AS (
    			SELECT  DISTINCT CONVERT(BIGINT, Replace(POPInvoiceCreditLineID, ',', '')) AS pop_invoice_credit_line_id ,
    					CONVERT(DECIMAL(10,2), Replace(InvoiceCreditQuantity, ',', ''))  AS invoice_credit_quantity,
    					CONVERT(DECIMAL(10,2), Replace(LineTotalValue, ',', ''))  AS line_total_value,
    					CONVERT(DECIMAL(10,2), Replace(LineTaxValue, ',', '')) AS  line_tax_value,
    					CONVERT(BIGINT, Replace(POPInvoiceCreditTypeID, ',', '')) AS pop_invoice_credit_type_id,
    					InvoiceCreditDate AS invoice_credit_date,
    					CONVERT(BIGINT, Replace(POPOrderReturnLineID, ',', '')) AS pop_order_return_line_id ,
    					POPInvoiceCreditNo AS pop_invoice_credit_no   
    					FROM  [psa].[LEIT_LEXDH_LE_POP_Invoice_Credit_Line_LEXDH_Incr] 
    					WHERE  row_status = @rowStatusPSACode AND active_flag = 'Y'),
    		-- picking the active records from LEIT_LEXDH_LE_POP_Invoice_Credit_Line_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
    		
    	 pl_supplier_account AS ( 
    		    SELECT  DISTINCT PLSupplierAccountID AS pl_supplier_account_id ,
    					SYSPaymentTermsBasisID AS sys_payment_terms_basis_id,
    					SYSCurrencyID  AS sys_currency_id
    					FROM [psa].[LEIT_LEXDH_LE_PL_Supplier_Account_LEXDH_Incr]
    					WHERE  row_status = @rowStatusPSACode AND active_flag = 'Y'  ),
    		-- picking the active records from LEIT_LEXDH_LE_PL_Supplier_Account_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
    		
    	 pop_order_return_line AS ( 
    			SELECT DISTINCT ItemCode AS item_code,
    				   POPOrderReturnLineID AS pop_order_return_line_id,
    				   POPOrderReturnID AS pop_order_return_id,
    				   NominalAccountRef AS nominal_account_ref,
    				   BuyingUnitDescription AS buying_unit_description
    				   FROM [psa].[LEIT_LEXDH_LE_POP_Order_Return_Line_LEXDH_Incr] 
    				   WHERE  row_status = @rowStatusPSACode AND active_flag = 'Y'),
    		-- picking the active records from LEIT_LEXDH_LE_POP_Order_Return_Line_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
    				   
    	 pop_order_return AS ( 
    			SELECT DISTINCT POPOrderReturnID AS pop_order_return_id,
    				   CONVERT(BIGINT,Replace(Replace(DocumentNo, '#', ''), ',', '')) AS document_no
    				   FROM [psa].[LEIT_LEXDH_LE_POP_Order_Return_LEXDH_Incr]
    				   WHERE  row_status = @rowStatusPSACode AND active_flag = 'Y' ),
    		-- picking the active records from LEIT_LEXDH_LE_POP_Order_Return_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
    		
    	 payment_terms_basis AS (
    			SELECT  DISTINCT SYSPaymentTermsBasisID AS sys_payment_terms_basis_id,
    					Name AS name
    					FROM [psa].[LEIT_LEXDH_LE_SYS_Payment_Terms_Basis_LEXDH_Incr] 
    					WHERE  row_status = @rowStatusPSACode AND active_flag = 'Y'),
    		-- picking the active records from LEIT_LEXDH_LE_SYS_Payment_Terms_Basis_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
    		
    	 nl_nominal_account AS (
    			SELECT DISTINCT NLNominalAccountID AS nl_nominal_account_id,
    				   AccountNumber AS account_number,
    				   NLCostCentreId AS nl_cost_centre_id
    				   FROM [psa].[LEIT_LEXDH_LE_NL_Nominal_Account_LEXDH_Incr]
    				   WHERE  row_status = @rowStatusPSACode AND active_flag = 'Y'),
    		-- picking the active records from LEIT_LEXDH_LE_NL_Nominal_Account_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
    		
    	 nl_cost_centre AS (
    			SELECT  DISTINCT NLCostCentreID AS nl_cost_centre_id
    					FROM  [psa].[LEIT_LEXDH_LE_NL_Cost_Centre_LEXDH_Incr] 
    					WHERE  row_status = @rowStatusPSACode AND active_flag = 'Y'),
    		-- picking the active records from LEIT_LEXDH_LE_NL_Cost_Centre_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
    					
    	 sys_currency AS (
    			SELECT  DISTINCT symbol AS symbol ,
    					SYSCurrencyId  as sys_currency_id 
    					FROM [psa].[LEIT_LEXDH_LE_SYS_Currency_LEXDH_Incr]
    					WHERE  row_status = @rowStatusPSACode AND active_flag = 'Y'),
    	    -- picking the active records from LEIT_LEXDH_LE_SYS_Currency_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
    					
    	 stock_item AS (
    			SELECT  DISTINCT ProductGroupId AS product_group_id, 
    					code AS code 
    					FROM [psa].[LEIT_LEXDH_LE_Stock_Item_LEXDH_Incr]
    					WHERE  row_status = @rowStatusPSACode AND active_flag = 'Y'),
    		-- picking the active records from LEIT_LEXDH_LE_Stock_Item_LEXDH_Incr with row_status = 26001 and active_flag = 'Y'
    		
    	 iso_units_of_measure AS (
    			SELECT DISTINCT code, 
    							description
    							FROM   psa.iso_units_of_measure),
    		-- picking code and description from the static table iso_units_of_measure
    							
    	 taxindicator AS (SELECT 'Total' as total_tax_ind
                             UNION 
                             SELECT 'Tax' as total_tax_ind)
    							
    	    -- tax_indicator is set as Total(W) and Tax (T)
    		
    	-- Populating the stage table t_ariba_invoice_stage by joining the psa table used above
    
    	SELECT DISTINCT
        REPLACE(TRIM(CAST(pl_posted_supplier_trans.transaction_reference AS NVARCHAR(20))), '_', '') AS INVOICE_ID,
        pop_invoice_credit_line.pop_invoice_credit_line_id AS EXTRA_INVOICE_KEY,
        pl_posted_supplier_trans.pl_posted_supplier_tran_id AS INVOICE_LINE_NUMBER,
        REPLACE(
                   TRIM(Upper(Concat(
                                        FORMAT(CAST(pl_posted_supplier_trans.transaction_date AS date), 'dd-MMM-yy'),
                                        CASE tax.total_tax_ind
                                            WHEN 'Total' THEN
                                                'W'
                                            WHEN 'Tax' THEN
                                                'T'
                                        END
                                    )
                             )
                       ),
                   '_',
                   ''
               ) AS EXTRA_INVOICE_LINE_KEY,
        NULL AS SPLIT_ACCOUNTING_NUMBER,
        REPLACE(TRIM(FORMAT(CAST(pl_posted_supplier_trans.posted_date AS date), 'yyyy-MM-dd')), '_', '') AS ACCOUNTING_DATE,
        pop_invoice_credit_line.invoice_credit_quantity AS QUANTITY,
        CASE tax.total_tax_ind
            WHEN 'Total' THEN
                pop_invoice_credit_line.line_total_value
            WHEN 'Tax' THEN
                pop_invoice_credit_line.line_tax_value
        END * CASE
                  WHEN pop_invoice_credit_line.pop_invoice_credit_type_id = 0 THEN
                      1
                  WHEN pop_invoice_credit_line.pop_invoice_credit_type_id = 1 THEN
                      -1
              END AS AMOUNT,
        REPLACE(TRIM(CAST(sys_currency.symbol AS NVARCHAR(10))), '_', '') AS AMOUNT_CURRENCY,
        REPLACE(TRIM(t_ariba_part.description1), '_', '') AS DESCRIPTION,
        stock_item.product_group_id AS ERP_COMMODITY_ID,
        REPLACE(TRIM(CAST(pop_order_return_line.item_code AS NVARCHAR(20))), '_', '') AS PART_NUMBER,
        NULL AS PART_REVISION_NUMBER,
        REPLACE(TRIM(CAST(iso_units_of_measure.code AS NVARCHAR(2))), '_', '') AS UNIT_OF_MEASURE,
        pl_posted_supplier_trans.pl_supplier_account_id AS SUPPLIER_ID,
        NULL AS SUPPLIER_LOCATION_ID,
        NULL AS REQUESTER_ID,
        nl_nominal_account.nl_nominal_account_id AS ACCOUNT_ID,
        NULL AS ACCOUNT_COMPANY_CODE,
        NULL AS COMPANY_SITE_ID,
        nl_cost_centre.nl_cost_centre_id AS COST_CENTER_ID,
        NULL AS COST_CENTER_COMPANY_CODE,
        NULL AS CONTRACT_ID,
        pop_order_return.pop_order_return_id AS PO_ID,
        NULL AS EXTRA_PO_KEY,
        pop_order_return_line.pop_order_return_line_id AS PO_LINE_NUMBER,
        REPLACE(TRIM(Concat(   pop_order_return.document_no,
                               CASE tax.total_tax_ind
                                   WHEN 'Total' THEN
                                       'W'
                                   WHEN 'Tax' THEN
                                       'T'
                               END
                           )
                    ),
                '_',
                ''
               ) AS EXTRA_PO_LINE_KEY,
        REPLACE(TRIM(FORMAT(CAST(pl_posted_supplier_trans.transaction_date AS date), 'yyyy-MM-dd')), '_', '') AS INVOICE_DATE,
        REPLACE(TRIM(FORMAT(CAST(pl_posted_supplier_trans.full_settlement_date AS date), 'yyyy-MM-dd')), '_', '') AS PAID_DATE,
        REPLACE(TRIM(CAST(pl_posted_supplier_trans.transaction_reference AS NVARCHAR(20))), '_', '') AS INVOICE_NUMBER,
        REPLACE(TRIM(CAST(payment_terms_basis.name AS NVARCHAR(40))), '_', '') AS AP_PAYMENT_TERMS,
        REPLACE(TRIM(   CASE tax.total_tax_ind
                            WHEN 'Total' THEN
                                'W'
                            WHEN 'Tax' THEN
                                'T'
                        END
                    ),
                '_',
                ''
               ) AS LINE_TYPE,
        NULL AS FLEX_FIELD_ID_1,
        NULL AS FLEX_FIELD_ID_2,
        NULL AS FLEX_FIELD_ID_3,
        NULL AS FLEX_FIELD_ID_4,
        NULL AS FLEX_FIELD_ID_5,
        NULL AS FLEX_FIELD_ID_6,
        NULL AS FLEX_FIELD_ID_7,
        NULL AS FLEX_FIELD_ID_8,
        NULL AS FLEX_FIELD_ID_9,
        NULL AS FLEX_FIELD_ID_10,
        NULL AS FLEX_FIELD_ID_11,
        NULL AS FLEX_FIELD_ID_12,
        NULL AS FLEX_FIELD_ID_13,
        NULL AS FLEX_FIELD_ID_14,
        NULL AS FLEX_MEASURE_1,
        NULL AS FLEX_MEASURE_2,
        NULL AS FLEX_MEASURE_3,
        NULL AS FLEX_MEASURE_4,
        NULL AS FLEX_MEASURE_5,
        NULL AS FLEX_DATE_1,
        NULL AS FLEX_DATE_2,
        NULL AS FLEX_DATE_3,
        NULL AS FLEX_DATE_4,
        NULL AS FLEX_DATE_5,
        NULL AS FLEX_STRING_1,
        NULL AS FLEX_STRING_2,
        NULL AS FLEX_STRING_3,
        NULL AS FLEX_STRING_4,
        NULL AS FLEX_STRING_5,
        NULL AS FLEX_STRING_6,
        NULL AS FLEX_STRING_7,
        NULL AS FLEX_STRING_8,
        NULL AS FLEX_STRING_9,
        NULL AS FLEX_STRING_10,
        @processingTime AS DSS_CREATE_TIME,
        @processingTime AS DSS_UPDATE_TIME
    into #t_ariba_invoice_stage
    FROM pl_posted_supplier_trans
        JOIN pop_invoice_credit_line
            ON pop_invoice_credit_line.pop_invoice_credit_no = pl_posted_supplier_trans.transaction_reference
               AND pop_invoice_credit_line.invoice_credit_date = pl_posted_supplier_trans.transaction_date
        JOIN pl_supplier_account
            ON pl_supplier_account.pl_supplier_account_id = pl_posted_supplier_trans.pl_supplier_account_id
        JOIN pop_order_return_line
            ON pop_order_return_line.pop_order_return_line_id = pop_invoice_credit_line.pop_order_return_line_id
        JOIN pop_order_return
            ON pop_order_return.pop_order_return_id = pop_order_return_line.pop_order_return_id
        JOIN payment_terms_basis
            ON payment_terms_basis.sys_payment_terms_basis_id = pl_supplier_account.sys_payment_terms_basis_id
        JOIN nl_nominal_account
            ON nl_nominal_account.account_number = pop_order_return_line.nominal_account_ref
        JOIN nl_cost_centre
            ON nl_cost_centre.nl_cost_centre_id = nl_nominal_account.nl_cost_centre_id
        JOIN sys_currency
            ON sys_currency.sys_currency_id = pl_supplier_account.sys_currency_id
        JOIN stock_item
            ON stock_item.code = pop_order_return_line.item_code
        JOIN iso_units_of_measure
            ON iso_units_of_measure.description = pop_order_return_line.buying_unit_description
        JOIN [con_sa].t_ariba_part
            ON t_ariba_part.part_number = pop_order_return_line.item_code
        CROSS JOIN taxindicator tax
    WHERE pl_posted_supplier_trans.rn = 1
          AND nl_nominal_account.account_number = 130100
          AND pl_posted_supplier_trans.transaction_reference NOT LIKE 'PO%'

        -- Records wth nominal account number for Invoice and PO (130100) and with row_number 1 from pl_posted_supplier_trans only needs to be picked and transaction reference should not be PO 
		
	PRINT 'Info : Completed insertion of t_ariba_invoice_stage'


BEGIN TRANSACTION;
 
 
    /* Inserting the data from  t_ariba_invoice_stage to the materialisation output table for invoice  */
	
			INSERT INTO [con_sa].[t_ariba_invoice]
			SELECT  STG.INVOICE_ID,
					STG.EXTRA_INVOICE_KEY,
					STG.INVOICE_LINE_NUMBER,
					STG.EXTRA_INVOICE_LINE_KEY,
					STG.SPLIT_ACCOUNTING_NUMBER,
					STG.ACCOUNTING_DATE,
					STG.QUANTITY,
					STG.AMOUNT,
					STG.AMOUNT_CURRENCY,
					STG.DESCRIPTION,
					STG.ERP_COMMODITY_ID,
					STG.PART_NUMBER,
					STG.PART_REVISION_NUMBER,
					STG.UNIT_OF_MEASURE,
					STG.SUPPLIER_ID,
					STG.SUPPLIER_LOCATION_ID,
					STG.REQUESTER_ID,
					STG.ACCOUNT_ID,
					STG.ACCOUNT_COMPANY_CODE,
					STG.COMPANY_SITE_ID,
					STG.COST_CENTER_ID,
					STG.COST_CENTER_COMPANY_CODE,
					STG.CONTRACT_ID,
					STG.PO_ID,
					STG.EXTRA_PO_KEY,
					STG.PO_LINE_NUMBER,
					STG.EXTRA_PO_LINE_KEY,
					STG.INVOICE_DATE,
					STG.PAID_DATE,
					STG.INVOICE_NUMBER,
					STG.AP_PAYMENT_TERMS,
					STG.LINE_TYPE,
					STG.FLEX_FIELD_ID_1,
					STG.FLEX_FIELD_ID_2,
					STG.FLEX_FIELD_ID_3,
					STG.FLEX_FIELD_ID_4,
					STG.FLEX_FIELD_ID_5,
					STG.FLEX_FIELD_ID_6,
					STG.FLEX_FIELD_ID_7,
					STG.FLEX_FIELD_ID_8,
					STG.FLEX_FIELD_ID_9,
					STG.FLEX_FIELD_ID_10,
					STG.FLEX_FIELD_ID_11,
					STG.FLEX_FIELD_ID_12,
					STG.FLEX_FIELD_ID_13,
					STG.FLEX_FIELD_ID_14,
					STG.FLEX_MEASURE_1,
					STG.FLEX_MEASURE_2,
					STG.FLEX_MEASURE_3,
					STG.FLEX_MEASURE_4,
					STG.FLEX_MEASURE_5,
					STG.FLEX_DATE_1,
					STG.FLEX_DATE_2,
					STG.FLEX_DATE_3,
					STG.FLEX_DATE_4,
					STG.FLEX_DATE_5,
					STG.FLEX_STRING_1,
					STG.FLEX_STRING_2,
					STG.FLEX_STRING_3,
					STG.FLEX_STRING_4,
					STG.FLEX_STRING_5,
					STG.FLEX_STRING_6,
					STG.FLEX_STRING_7,
					STG.FLEX_STRING_8,
					STG.FLEX_STRING_9,
					STG.FLEX_STRING_10,
					STG.DSS_CREATE_TIME,
					STG.DSS_UPDATE_TIME
					FROM  #t_ariba_invoice_stage STG
					WHERE STG.INVOICE_DATE >=  '2016-09-01' 
					OR STG.ACCOUNTING_DATE >=  '2016-09-01'
				-- Only records having invoice_date or accounting_date >=	'2016-09-01' are picked 
					

					 

      PRINT 'Info : Completed insertion of t_ariba_invoice'
		
    COMMIT TRANSACTION;					
		END TRY
	    BEGIN CATCH
				THROW;
			END CATCH 

END
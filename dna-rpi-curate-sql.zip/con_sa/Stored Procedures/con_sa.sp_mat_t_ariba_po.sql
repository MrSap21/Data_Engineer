﻿CREATE PROC [con_sa].[sp_mat_t_ariba_po] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_mat_t_ariba_po
Purpose						: Load Incremental data For Purchase Order Materialisation
Target Tables             	: t_ariba_po

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Sunitha George V   	:  Initial Version

**************************************************************************************************************************
*/

     /*--Declarations---*/
	DECLARE @rowStatusPSACode BIGINT,
	        @processingTime DATETIME2;
	
	/*-------------------------------Drop temporary source table-------------------------------*/
	
	IF OBJECT_ID('tempdb..#t_ariba_po_stage') IS NOT NULL
	BEGIN
		drop table tempdb..#t_ariba_po_stage;
	END	

    /*-------------------------------Truncate target table-------------------------------*/

    truncate table con_sa.t_ariba_po
		
	PRINT 'Info : Completed truncating t_ariba_po'
	
	
BEGIN	
	
	SET @rowStatusPSACode = 26001;
	SET @processingTime = CURRENT_TIMESTAMP;


 BEGIN TRY
 
 
        WITH orderreturn AS 
                (
                   SELECT DISTINCT
                      CONVERT(BIGINT, Replace(poporderreturnid, ',', '')) AS pop_order_return_id,
                      CONVERT(BIGINT, Replace(supplierid, ',', '')) AS supplier_id,
                      CONVERT(BIGINT, Replace(documentstatusid, ',', '')) AS document_status_id,
                      CONVERT(BIGINT, Replace(Replace(documentno, '#', ''), ',', '')) AS document_no,
                      CONVERT(VARCHAR, documentdate, 20) AS document_date 
                   FROM
                      psa.leit_lexdh_le_pop_order_return_lexdh_incr 
                   WHERE
                      row_status = @rowStatusPSACode 
                      AND active_flag = 'Y' 
                      and poporderreturnid is NOT NULL 
                      and documentno is NOT NULL 
                )
        , -- picking the active records from leit_lexdh_le_pop_order_return_lexdh_incr with row_status = 26001 and active_flag = 'Y'. poporderreturnid and documentno are not null columns and since only dq warning is raised, these columns,if coming as NULL from source, should not be inserted
		
        orderreturnline AS 
                (
                   SELECT DISTINCT
                      CONVERT(BIGINT, Replace(poporderreturnlineid, ',', '')) AS pop_order_return_line_id,
                      CONVERT(BIGINT, Replace(poporderreturnid, ',', '')) AS pop_order_return_id,
                      itemcode AS item_code,
                      CONVERT(BIGINT, Replace(linetypeid, ',', '')) AS line_type_id,
                      nominalaccountref AS nominal_account_ref,
                      buyingunitdescription AS buying_unit_description,
                      CONVERT(DECIMAL(10, 2), Replace(linequantity, ',', '')) AS line_quantity,
                      CONVERT(DECIMAL(10, 2), Replace(linetotalvalue, ',', '')) AS line_total_value,
                      CONVERT(DECIMAL(10, 2), Replace(linetaxvalue, ',', '')) AS line_tax_value,
                      itemdescription AS item_description 
                   FROM
                      psa.leit_lexdh_le_pop_order_return_line_lexdh_incr 
                   WHERE
                      row_status = @rowStatusPSACode 
                      AND active_flag = 'Y' 
                      and poporderreturnlineid is not null 
                )
        , -- picking the active records from leit_lexdh_le_pop_order_return_line_lexdh_incr with row_status = 26001 and active_flag = 'Y'. poporderreturnlineid is a not null column and since only dq warning is raised, these columns,if coming as NULL from source, should not be inserted
		
        plsupplieraccount AS 
                (
                   SELECT DISTINCT
                      CONVERT(BIGINT, Replace(plsupplieraccountid, ',', '')) AS pl_supplier_account_id,
                      CONVERT(BIGINT, Replace(syscurrencyid, ',', '')) AS sys_currency_id 
                   FROM
                      psa.leit_lexdh_le_pl_supplier_account_lexdh_incr 
                   WHERE
                      row_status = @rowStatusPSACode 
                      AND active_flag = 'Y' 
                )
        , -- picking the active records from leit_lexdh_le_pl_supplier_account_lexdh_incr with row_status = 26001 and active_flag = 'Y'
		
        syscurrency AS 
                (
                   SELECT DISTINCT
                      CONVERT(BIGINT, Replace(syscurrencyid, ',', '')) AS sys_currency_id,
                      CONVERT(BIGINT, Replace(syscurrencyisocodeid, ',', '')) AS sys_currency_iso_code_id 
                   FROM
                      psa.leit_lexdh_le_sys_currency_lexdh_incr 
                   WHERE
                      row_status = @rowStatusPSACode 
                      AND active_flag = 'Y' 
                )
        , -- picking the active records from leit_lexdh_le_sys_currency_lexdh_incr with row_status = 26001 and active_flag = 'Y'
		
        syscurrencyiso AS 
                (
                   SELECT DISTINCT
                      CONVERT(BIGINT, Replace(syscurrencyisocodeid, ',', '')) AS sys_currency_iso_code_id,
                      code 
                   FROM
                      psa.leit_lexdh_le_sys_currency_iso_code_lexdh_incr 
                   WHERE
                      row_status = @rowStatusPSACode 
                      AND active_flag = 'Y' 
                )
        , -- picking the active records from leit_lexdh_le_sys_currency_iso_code_lexdh_incr with row_status = 26001 and active_flag = 'Y'
		
        stockitem AS 
                (
                   SELECT DISTINCT
                      code AS code,
                      CONVERT(BIGINT, Replace(productgroupid, ',', '')) AS product_group_id 
                   FROM
                      psa.leit_lexdh_le_stock_item_lexdh_incr 
                   WHERE
                      row_status = @rowStatusPSACode 
                      AND active_flag = 'Y' 
                )
        , -- picking the active records from leit_lexdh_le_stock_item_lexdh_incr with row_status = 26001 and active_flag = 'Y'
		
        returnlinetype AS 
                (
                   SELECT DISTINCT
                      CONVERT(BIGINT, Replace(orderreturnlinetypeid, ',', '')) AS order_return_line_type_id 
                   FROM
                      psa.leit_lexdh_le_order_return_line_type_lexdh_incr 
                   WHERE
                      row_status = @rowStatusPSACode 
                      AND active_flag = 'Y' 
                )
        , -- picking the active records from leit_lexdh_le_order_return_line_type_lexdh_incr with row_status = 26001 and active_flag = 'Y'
		
        documentstatus AS 
                (
                   SELECT DISTINCT
                        CONVERT(BIGINT, Replace(documentstatusid, ',', '')) AS document_status_id,
                        CASE NAME
                            WHEN 'Live' THEN
                                'open'
                            WHEN 'On Hold' THEN
                                'open'
                            WHEN 'Disputed' THEN
                                'open'
                            WHEN 'Completed' THEN
                                'closed'
                            WHEN 'Cancelled' THEN
                                'closed'
                            ELSE
                                'open'
                        END AS ariba_open_po_indicator
                    FROM psa.leit_lexdh_le_document_status_lexdh_incr
                    WHERE row_status = @rowStatusPSACode
                          AND active_flag = 'Y'
                )
        , -- picking the active records from leit_lexdh_le_document_status_lexdh_incr with row_status = 26001 and active_flag = 'Y'
		
		nominalaccount AS 
                (
                   SELECT DISTINCT
                      CONVERT(BIGINT, Replace(nlnominalaccountid, ',', '')) AS nl_nominal_account_id,
                      CONVERT(BIGINT, Replace(nlcostcentreid, ',', '')) AS nl_cost_centre_id,
                      Replace(accountnumber, ',', '') AS account_number 
                   FROM
                      psa.leit_lexdh_le_nl_nominal_account_lexdh_incr 
                   WHERE
                      row_status = @rowStatusPSACode 
                      AND active_flag = 'Y' 
                      AND Replace(accountnumber, ',', '') = '130100' 
                )
        , -- picking the active records from leit_lexdh_le_stock_item_lexdh_incr with row_status = 26001 and active_flag = 'Y' and with nominal account number for Invoice and PO (130100) 
		
        unitsmeasure AS 
                (
                   SELECT DISTINCT
                      code,
                      description 
                   FROM
                      psa.iso_units_of_measure 
                )
        ,-- picking code and description from the static table iso_units_of_measure
		
        taxindicator AS 
                (
                   SELECT
                      'Total' as total_tax_ind 
                   UNION
                   SELECT
                      'Tax' as total_tax_ind 
                )
        -- tax_indicator is set as Total(W) and Tax (T)

-- Populating the stage table t_ariba_po_stage by joining the psa tables used above		
                 
        SELECT DISTINCT
            orderreturn.pop_order_return_id AS PO_ID,
            NULL AS EXTRA_PO_KEY,
            orderreturnline.pop_order_return_line_id AS PO_LINE_NUMBER,
            trim(Concat(   orderreturn.document_no,
                           CASE tax.total_tax_ind
                               WHEN 'Total' THEN
                                   'W'
                               WHEN 'Tax' THEN
                                   'T'
                           END
                       )
                ) AS EXTRA_PO_LINE_KEY,
            NULL AS SPLIT_ACCOUNTING_NUMBER,
            cast(trim(orderreturn.document_date) as nvarchar(10)) AS ORDERED_DATE,
            orderreturnline.line_quantity AS QUANTITY,
            CASE tax.total_tax_ind
                WHEN 'Total' THEN
                    orderreturnline.line_total_value
                WHEN 'Tax' THEN
                    orderreturnline.line_tax_value
            END AS AMOUNT,
            cast(trim(syscurrencyiso.code) as nvarchar(3)) AS AMOUNT_CURRENCY,
            cast(trim(orderreturnline.item_description) as nvarchar(255)) AS DESCRIPTION,
            stockitem.product_group_id AS ERP_COMMODITY_ID,
            cast(trim(orderreturnline.item_code) as nvarchar(20)) AS PART_NUMBER,
            NULL AS PART_REVISION_NUMBER,
            trim(unitsmeasure.code) AS UNIT_OF_MEASURE,
            orderreturn.supplier_id AS SUPPLIER_ID,
            NULL AS SUPPLIER_LOCATION_ID,
            NULL AS REQUESTER_ID,
            nominalaccount.nl_nominal_account_id AS ACCOUNT_ID,
            NULL AS ACCOUNT_COMPANY_CODE,
            NULL AS COMPANY_SITE_ID,
            nominalaccount.nl_cost_centre_id AS COST_CENTER_ID,
            NULL AS COST_CENTER_COMPANY_CODE,
            NULL AS CONTRACT_ID,
            NULL AS DURATION_IN_MONTHS,
            trim(documentstatus.ariba_open_po_indicator) AS OPEN_PO_INDICATOR,
            CASE tax.total_tax_ind
                WHEN 'Total' THEN
                    'W'
                WHEN 'Tax' THEN
                    'T'
            END AS LINE_TYPE,
            NULL AS FLEX_FIELD_ID_1,
            NULL AS FLEX_FIELD_ID_2,
            NULL AS FLEX_FIELD_ID_3,
            NULL AS FLEX_FIELD_ID_4,
            NULL AS FLEX_FIELD_ID_5,
            NULL AS FLEX_FIELD_ID_6,
            NULL AS FLEX_FIELD_ID_7,
            NULL AS FLEX_FIELD_ID_8,
            NULL AS FLEX_FIELD_ID_9,
            NULL AS FLEX_FIELD_ID_10,
            NULL AS FLEX_FIELD_ID_11,
            NULL AS FLEX_FIELD_ID_12,
            NULL AS FLEX_FIELD_ID_13,
            NULL AS FLEX_FIELD_ID_14,
            NULL AS FLEX_MEASURE_1,
            NULL AS FLEX_MEASURE_2,
            NULL AS FLEX_MEASURE_3,
            NULL AS FLEX_MEASURE_4,
            NULL AS FLEX_MEASURE_5,
            NULL AS FLEX_DATE_1,
            NULL AS FLEX_DATE_2,
            NULL AS FLEX_DATE_3,
            NULL AS FLEX_DATE_4,
            NULL AS FLEX_DATE_5,
            NULL AS FLEX_STRING_1,
            NULL AS FLEX_STRING_2,
            NULL AS FLEX_STRING_3,
            NULL AS FLEX_STRING_4,
            NULL AS FLEX_STRING_5,
            NULL AS FLEX_STRING_6,
            NULL AS FLEX_STRING_7,
            NULL AS FLEX_STRING_8,
            NULL AS FLEX_STRING_9,
            NULL AS FLEX_STRING_10
        into #t_ariba_po_stage
        FROM orderreturn
            JOIN orderreturnline
                ON orderreturnline.pop_order_return_id = orderreturn.pop_order_return_id
            JOIN plsupplieraccount
                ON plsupplieraccount.pl_supplier_account_id = orderreturn.supplier_id
            JOIN syscurrency
                ON syscurrency.sys_currency_id = plsupplieraccount.sys_currency_id
            JOIN syscurrencyiso
                ON syscurrencyiso.sys_currency_iso_code_id = syscurrency.sys_currency_iso_code_id
            JOIN stockitem
                ON stockitem.code = orderreturnline.item_code
            JOIN returnlinetype
                ON returnlinetype.order_return_line_type_id = orderreturnline.line_type_id
            JOIN documentstatus
                ON documentstatus.document_status_id = orderreturn.document_status_id
            JOIN nominalaccount
                ON nominalaccount.account_number = orderreturnline.nominal_account_ref
            JOIN unitsmeasure
                ON unitsmeasure.description = orderreturnline.buying_unit_description
            CROSS JOIN taxindicator tax;
	   
	   
	PRINT 'Info : Completed insertion of t_ariba_po_stage'	 


BEGIN TRANSACTION;

    /* Inserting the data from  t_ariba_po_stage to the materialisation output table for po  */
	   
                INSERT INTO con_sa.t_ariba_po
                SELECT DISTINCT
				       stg.po_id,
                       REPLACE(stg.extra_po_key,'_',''),
                       stg.po_line_number,
                       REPLACE(stg.extra_po_line_key,'_',''),
                       stg.split_accounting_number,
                       stg.ordered_date,
                       stg.quantity,
                       con_sa.RemoveLeadingTrailingZeros(stg.amount) as amount,
                       REPLACE(stg.amount_currency,'_',''),
                       REPLACE(stg.description,'_',''),
                       stg.erp_commodity_id,
                       REPLACE(stg.part_number,'_',''),
                       REPLACE(stg.part_revision_number,'_',''),
                       REPLACE(stg.unit_of_measure,'_',''),
                       stg.supplier_id,
                       stg.supplier_location_id,
                       stg.requester_id,
                       stg.account_id,
                       stg.account_company_code,
                       stg.company_site_id,
                       stg.cost_center_id,
                       stg.cost_center_company_code,
                       stg.contract_id,
                       stg.duration_in_months,
                       REPLACE(stg.open_po_indicator,'_',''),
                       stg.line_type,
                       stg.flex_field_id_1,
                       stg.flex_field_id_2,
                       stg.flex_field_id_3,
                       stg.flex_field_id_4,
                       stg.flex_field_id_5,
                       stg.flex_field_id_6,
                       stg.flex_field_id_7,
                       stg.flex_field_id_8,
                       stg.flex_field_id_9,
                       stg.flex_field_id_10,
                       stg.flex_field_id_11,
                       stg.flex_field_id_12,
                       stg.flex_field_id_13,
                       stg.flex_field_id_14,
                       stg.flex_measure_1,
                       stg.flex_measure_2,
                       stg.flex_measure_3,
                       stg.flex_measure_4,
                       stg.flex_measure_5,
                       stg.flex_date_1,
                       stg.flex_date_2,
                       stg.flex_date_3,
                       stg.flex_date_4,
                       stg.flex_date_5,
                       stg.flex_string_1,
                       stg.flex_string_2,
                       stg.flex_string_3,
                       stg.flex_string_4,
                       stg.flex_string_5,
                       stg.flex_string_6,
                       stg.flex_string_7,
                       stg.flex_string_8,
                       stg.flex_string_9,
                       stg.flex_string_10,
					   @processingTime,
					   @processingTime
                FROM   #t_ariba_po_stage stg
                       LEFT JOIN con_sa.t_ariba_invoice invoice
                              ON stg.po_id = invoice.po_id
                WHERE  stg.ordered_date >= '2016-09-01'
                        OR invoice.po_id IS NOT NULL 	
						
                -- Only records having ordered_date >=	'2016-09-01' or a corresponding po_id in t_ariba_invoice are picked 
				

        PRINT 'Info : Completed insertion of t_ariba_po'
		
    COMMIT TRANSACTION;					
		END TRY
	    BEGIN CATCH
				THROW;
			END CATCH 

END
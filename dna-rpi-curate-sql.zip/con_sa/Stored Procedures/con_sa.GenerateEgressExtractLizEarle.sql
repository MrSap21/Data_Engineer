﻿CREATE PROCEDURE con_sa.GenerateEgressExtractLizEarle
(
    @pETLRunLogID                        AS NVARCHAR(255)   
)
AS
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================
--
-- FileName    : GenerateEgressExtractLizEarle.sql
-- Description : Populate Data in LizEarle Egress DataMarts for the 7 feeds
--
-- =============================================================================
--
-- Change History
-- Name                Date            Description
-- Sunitha George V   02-June-2021     Created
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
BEGIN
    BEGIN TRY

      /* Declare and Initialize Generic variables*/
	    DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
        DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';
		DECLARE @vNumRows                           AS INT           = 0;
		  
		DECLARE   @entityid_poporderreturn BIGINT,
		          @entityid_PSA_poporderreturn BIGINT,
				  @entityid_poporderreturnline BIGINT,
			      @entityid_PSA_poporderreturnline BIGINT,
				  @entityid_nlnominalaccount BIGINT,
				  @entityid_PSA_nlnominalaccount BIGINT,
				  @entityid_plpostedsuppliertran BIGINT,
				  @entityid_PSA_plpostedsuppliertran BIGINT,
				  @entityid_popinvoicecreditline BIGINT,
				  @entityid_PSA_popinvoicecreditline BIGINT,
				  @entityid_productgroup BIGINT,
				  @entityid_PSA_productgroup BIGINT,
				  @entityid_stockitem BIGINT,
			      @entityid_PSA_stockitem BIGINT;
				  
		
		/* DQ Framework NULL checks for all the 7 feeds */
		
		SET @entityid_poporderreturn = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Purchase Order Processing Order Return Details%');
	    SET @entityid_PSA_poporderreturn = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_POP_Order_Return_LEXDH_Incr');		  
					
		EXEC [psa].[sp_ApplyDQ] @entityid_poporderreturn,@entityid_PSA_poporderreturn,NULL
		
		
        SET @entityid_poporderreturnline = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Purchase Order Processing Order Return Line Details%');
		SET @entityid_PSA_poporderreturnline = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_POP_Order_Return_Line_LEXDH_Incr');
		
		EXEC [psa].[sp_ApplyDQ] @entityid_poporderreturnline,@entityid_PSA_poporderreturnline,NULL
		
		
		SET @entityid_nlnominalaccount =(SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Nominal Ledger Nominal Account%');
		SET @entityid_PSA_nlnominalaccount =(SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_NL_Nominal_Account_LEXDH_Incr');

		EXEC [psa].[sp_ApplyDQ] @entityid_nlnominalaccount,@entityid_PSA_nlnominalaccount,NULL
		
		
		SET @entityid_plpostedsuppliertran =(SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Purchase Ledger Posted Supplier Transaction Details%');
		SET @entityid_PSA_plpostedsuppliertran =(SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_PL_Posted_Supplier_Transaction_LEXDH_Incr');

		EXEC [psa].[sp_ApplyDQ] @entityid_plpostedsuppliertran,@entityid_PSA_plpostedsuppliertran,NULL
		
		

		SET @entityid_popinvoicecreditline =(SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Purchase Order Processing Invoice Credit Line Details%');
		SET @entityid_PSA_popinvoicecreditline =(SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_POP_Invoice_Credit_Line_LEXDH_Incr');

		EXEC [psa].[sp_ApplyDQ] @entityid_popinvoicecreditline,@entityid_PSA_popinvoicecreditline,NULL

		
		
		SET @entityid_productgroup = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Product Group Details%');
		SET @entityid_PSA_productgroup = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_Product_Group_LEXDH_Incr');
		
		EXEC [psa].[sp_ApplyDQ] @entityid_productgroup,@entityid_PSA_productgroup,NULL
		
		
		
		SET @entityid_stockitem = (SELECT entityId FROM psa.entity WHERE schemaname LIKE '%feed%' AND entityname like '%Stock Item Details%');
        SET @entityid_PSA_stockitem = (SELECT entityid FROM psa.entity WHERE schemaname = 'psa' AND entityname = 'LEIT_LEXDH_LE_Stock_Item_LEXDH_Incr');
		
		EXEC [psa].[sp_ApplyDQ] @entityid_stockitem,@entityid_PSA_stockitem,NULL
		
			/*Liz Earle DataMarts Population */
			
			/* Materialisation procedures */
			
			/* Truncate and load tables are the output. All active records from psa is loaded to the materialisation tables.
			   Order of execution is required only for part,invoice and po. Invoice depends on Part and PO depends on Invoice. */
			   
		 	EXEC [con_sa].[sp_mat_t_ariba_account] @pETLRunLogID
	        Print 'Info: Account Materialisation proc completed ';
			
			EXEC [con_sa].[sp_mat_t_ariba_cost_centre] @pETLRunLogID
	        Print 'Info: Cost Centre Materialisation proc completed ';
			
			EXEC [con_sa].[sp_mat_t_ariba_erp_commodity] @pETLRunLogID
	        Print 'Info: ERP Commodity Materialisation proc completed ';
			
			EXEC [con_sa].[sp_mat_t_ariba_part] @pETLRunLogID
	        Print 'Info: Part Materialisation proc completed ';
			
			EXEC [con_sa].[sp_mat_t_ariba_supplier] @pETLRunLogID
	        Print 'Info: Supplier Materialisation proc completed ';
			
			EXEC [con_sa].[sp_mat_t_ariba_invoice] @pETLRunLogID
	        Print 'Info: Invoice Materialisation proc completed ';
			
			EXEC [con_sa].[sp_mat_t_ariba_po] @pETLRunLogID
	        Print 'Info: PO Materialisation proc completed ';
			
			Print 'Info: Materialisation completed successfully '; 
			
			
	        /* Extraction procedures */
			
			/* Load the final extraction tables for the 7 feeds. Data will be extracted into csv files based on the latest etlrunlogid */
			
			EXEC [con_sa].[sp_ext_t_ariba_invoice_extract] @pETLRunLogID	
            Print 'Info: Invoice Extraction  proc completed ';
			
            EXEC [con_sa].[sp_ext_t_ariba_po_extract] @pETLRunLogID	
            Print 'Info: PO Extraction  proc completed ';
			
			EXEC [con_sa].[sp_ext_t_ariba_account_extract] @pETLRunLogID	
            Print 'Info: Account Extraction  proc completed ';
			
			EXEC [con_sa].[sp_ext_t_ariba_cost_centre_extract] @pETLRunLogID	
            Print 'Info: Cost Centre Extraction  proc completed ';
			
			EXEC [con_sa].[sp_ext_t_ariba_erp_commodity_extract] @pETLRunLogID	
            Print 'Info: ERP Commodity Extraction  proc completed ';
			
			EXEC [con_sa].[sp_ext_t_ariba_part_extract] @pETLRunLogID	
            Print 'Info: Part Extraction  proc completed ';
			
			EXEC [con_sa].[sp_ext_t_ariba_supplier_extract] @pETLRunLogID	
            Print 'Info: Supplier Extraction  proc completed '; 

			/*Return*/
			SELECT @vNumRows AS NumRows, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

    END TRY

    BEGIN CATCH
		
			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT @vNumRows AS NumRows
            , '-1' AS ProcedureStatus
            , @vProcedureMessage
      ;
    END CATCH;
END
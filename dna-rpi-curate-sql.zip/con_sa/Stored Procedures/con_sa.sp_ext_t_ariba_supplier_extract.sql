﻿CREATE PROC [con_sa].[sp_ext_t_ariba_supplier_extract] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_ext_t_ariba_supplier_extract
Purpose						: Loads Extract History table for Supplier
Target Tables             	: t_ariba_supplier_extract

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Jacob Roy   	:  Initial Version

**************************************************************************************************************************
*/

/*--Declarations---*/
DECLARE @current_datetime DATETIME2;
	
BEGIN	
	SET NOCOUNT ON
	SET @current_datetime = CURRENT_TIMESTAMP

	BEGIN TRY
 
	BEGIN TRANSACTION;
	
	/* Inserting the materialisation output to the final extract table for the latest etlrunlogid */

		INSERT INTO [con_sa].[t_ariba_supplier_extract]
		( 	
			supplier_id               ,
			supplier_location_id      ,
			supplier_name             ,
			street_address            ,
			city                      ,
			state                     ,
			country                   ,
			postal_code               ,
			supplier_type             ,
			contact_first_name        ,
			contact_last_name         ,
			contact_phone_number      ,
			contact_email             ,
			preferred_language        ,
			fax_number                ,
			order_routing_type        ,
			duns_number               ,
			an_number                 ,
			payment_type              ,
			diversity                 ,
			minority_owned            ,
			woman_owned               ,
			veteran_owned             ,
			diversity_hub_zone        ,
			diversity_sdb             ,
			diversity_sba_8a          ,
			diversity_dvo             ,
			diversity_ethni_city      ,
			diversity_glb_towned      ,
			diversity_disable_downed  ,
			diversity_labor_surplus   ,
			diversity_hbcu            ,
			diversity_small_business  ,
			diversity_green           ,
			certified_diversity       ,
			certified_minority_owned  ,
			certified_woman_owned     ,
			certified_veteran_owned   ,
			certified_sba_8a          ,
			certified_hub_zone        ,
			certified_sdb             ,
			certified_ethni_city      ,
			certified_disable_downed  ,
			certified_disadvantaged   ,
			diversity_enterprise      ,
			minority_owned_enterprise ,
			woman_owned_enterprise    ,
			veteran_owned_enterprise  ,
			dvo_enterprise            ,
			ethni_city_enterprise     ,
			disadvantaged_enterprise  ,
			number_of_employees       ,
			flex_field_1			  ,
			flex_field_2              ,
			flex_field_3			  ,
			dss_create_time           ,
			dss_update_time		      ,
			etlrunlogid
		)
		SELECT 
			supplier_id, 
			ISNULL(supplier_location_id,''), 
			ISNULL(supplier_name,''),
			ISNULL(street_address,''),
			ISNULL(city,''),
			ISNULL(state,''),
			ISNULL(country,''),
			ISNULL(postal_code,''),
			ISNULL(supplier_type,''),
			ISNULL(contact_first_name,''),
			ISNULL(contact_last_name,''),
			ISNULL(contact_phone_number,''),
			ISNULL(contact_email,''),
			ISNULL(preferred_language,''),
			ISNULL(fax_number,''),
			ISNULL(order_routing_type,''),
			ISNULL(duns_number,''),
			ISNULL(an_number,''),
			ISNULL(payment_type,''),
			ISNULL(diversity,''),
			ISNULL(minority_owned,''),
			ISNULL(woman_owned,''),
			ISNULL(veteran_owned,''),
			'' AS diversity_hub_zone        ,
			'' AS diversity_sdb             ,
			'' AS diversity_sba_8a          ,
			'' AS diversity_dvo             ,
			'' AS diversity_ethni_city      ,
			'' AS diversity_glb_towned      ,
			'' AS diversity_disable_downed  ,
			'' AS diversity_labor_surplus   ,
			'' AS diversity_hbcu            ,
			'' AS diversity_small_business  ,
			'' AS diversity_green           ,
			'' AS certified_diversity       ,
			'' AS certified_minority_owned  ,
			'' AS certified_woman_owned     ,
			'' AS certified_veteran_owned   ,
			'' AS certified_sba_8a          ,
			'' AS certified_hub_zone        ,
			'' AS certified_sdb             ,
			'' AS certified_ethni_city      ,
			'' AS certified_disable_downed  ,
			'' AS certified_disadvantaged   ,
			'' AS diversity_enterprise      ,
			'' AS minority_owned_enterprise ,
			'' AS woman_owned_enterprise    ,
			'' AS veteran_owned_enterprise  ,
			'' AS dvo_enterprise            ,
			'' AS ethni_city_enterprise     ,
			'' AS disadvantaged_enterprise  ,
			'' AS number_of_employees       ,
			'' AS flex_field_1			  ,
			ISNULL(flex_field_2,''),
			'' AS flex_field_3			  ,
			@current_datetime dss_create_time, 
			@current_datetime dss_update_time,
			@pETLRunLogID	etlrunlogid
		FROM con_sa.t_ariba_supplier;
                 	         
        PRINT 'Info : Completed insertion of t_ariba_supplier_extract';
	
    COMMIT TRANSACTION;					
	END TRY
	
	BEGIN CATCH
		THROW
		ROLLBACK TRANSACTION;
	END CATCH 
	
END
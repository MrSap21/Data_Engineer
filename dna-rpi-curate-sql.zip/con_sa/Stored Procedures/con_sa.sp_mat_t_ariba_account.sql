﻿CREATE PROC [con_sa].[sp_mat_t_ariba_account] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_mat_t_ariba_account
Purpose						: Load Incremental data For Account Materialisation
Target Tables             	: t_ariba_account

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Disti Jain   	:  Initial Version

**************************************************************************************************************************
*/

 
 /*--Declarations---*/
	DECLARE @rowStatusPSACode BIGINT,
			@dssTime DATE;
	
	/*-------------------------------Truncate target table-------------------------------*/
	
	TRUNCATE TABLE [con_sa].[t_ariba_account];
	
	PRINT 'Info : Completed truncating t_ariba_account'

BEGIN	
	
	SET @rowStatusPSACode = 26001
	SET @dssTime= CURRENT_TIMESTAMP

 BEGIN TRY
 BEGIN TRANSACTION;
 
 /* Inserting the active psa records (row_status=26001 and active_flag='Y') to the materialisation output table for account */
 
	INSERT INTO [con_sa].[t_ariba_account]
	(
	   [ACCOUNT_ID]              ,
	   [COMPANY_CODE]            ,
	   [ACCOUNT_NAME]            ,
	   [MAJOR_ACCOUNT_ID]        ,
	   [MAJOR_ACCOUNT_NAME]      ,
	   [CHARTS_OF_ACCOUNT_ID]    ,
	   [CHARTS_OF_ACCOUNT_NAME]  ,
	   [DSS_CREATE_TIME]         ,
	   [DSS_UPDATE_TIME]         
	)
	SELECT DISTINCT
	CONVERT(BIGINT,REPLACE(NLNominalAccountID, ',', '')) AS [ACCOUNT_ID],
	CONVERT(BIGINT,REPLACE(AccountNumber, ',', '')) AS [COMPANY_CODE],
	REPLACE(TRIM(CAST(AccountName AS NVARCHAR(50))),'_','') AS [ACCOUNT_NAME],
	NULL AS [MAJOR_ACCOUNT_ID],
	NULL AS [MAJOR_ACCOUNT_NAME],
	NULL AS [CHARTS_OF_ACCOUNT_ID],
	NULL AS [CHARTS_OF_ACCOUNT_NAME],
	@dssTime AS [DSS_CREATE_TIME],
	@dssTime AS [DSS_UPDATE_TIME]
	FROM [psa].[LEIT_LEXDH_LE_NL_Nominal_Account_LEXDH_Incr]
	WHERE row_status = @rowStatusPSACode 
	AND active_flag= 'Y'; 
	
	PRINT 'Info : Completed insertion of t_ariba_account'
	
    COMMIT TRANSACTION;					
		END TRY
	    BEGIN CATCH
				THROW;
			END CATCH 

END
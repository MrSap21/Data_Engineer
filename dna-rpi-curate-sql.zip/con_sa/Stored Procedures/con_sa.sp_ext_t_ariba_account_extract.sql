﻿CREATE PROC [con_sa].[sp_ext_t_ariba_account_extract] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_ext_t_ariba_account_extract
Purpose						: Load Extract History table for Account
Target Tables             	: t_ariba_account_extract

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Disti Jain   	:  Initial Version

**************************************************************************************************************************
*/

	
	 /*--Declarations---*/
	DECLARE @dssTime DATE;

BEGIN	


	SET @dssTime= CURRENT_TIMESTAMP

	

 BEGIN TRY
 
		BEGIN TRANSACTION;
		
		/* Inserting the materialisation output to the final extract table for the latest etlrunlogid */
		
		INSERT INTO [con_sa].[t_ariba_account_extract]
		(
		   ACCOUNT_ID              ,
		   COMPANY_CODE            ,
		   ACCOUNT_NAME            ,
		   MAJOR_ACCOUNT_ID        ,
		   MAJOR_ACCOUNT_NAME      ,
		   CHARTS_OF_ACCOUNT_ID    ,
		   CHARTS_OF_ACCOUNT_NAME  ,
		   DSS_CREATE_TIME         ,
		   DSS_UPDATE_TIME         ,
		   ETLRunLogID			
		)
		SELECT 
		ACCOUNT_ID AS ACCOUNT_ID,            
		COMPANY_CODE AS COMPANY_CODE,          
		ISNULL(ACCOUNT_NAME,'') AS ACCOUNT_NAME,          
		ISNULL(MAJOR_ACCOUNT_ID,'') AS MAJOR_ACCOUNT_ID,     
		ISNULL(MAJOR_ACCOUNT_NAME,'') AS MAJOR_ACCOUNT_NAME,  
		ISNULL(CHARTS_OF_ACCOUNT_ID,'') AS CHARTS_OF_ACCOUNT_ID,
		ISNULL(CHARTS_OF_ACCOUNT_NAME,'') AS CHARTS_OF_ACCOUNT_NAME,
		@dssTime AS DSS_CREATE_TIME,
		@dssTime AS DSS_UPDATE_TIME,
		@pETLRunLogID ETLRunLogId
		FROM [con_sa].[t_ariba_account];	
		
		PRINT 'Info : Completed insertion of t_ariba_account_extract'
		

		
    COMMIT TRANSACTION;					
		END TRY
	    BEGIN CATCH
				THROW;
				ROLLBACK TRANSACTION ;	
			END CATCH 

END
﻿CREATE PROC [con_sa].[sp_mat_t_ariba_part] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name              : sp_mat_t_ariba_part
Purpose						: Load Incremental data For part Materialisation
Target Tables             	: t_ariba_part
 

*****************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

03-06-2021   :  Praveen Kumar   	:  Initial Version

**************************************************************************************************************************
*/
    
/*--Declarations---*/
	DECLARE @rowStatusPSACode BIGINT,
	        @dssTime DATE;
		
	
	/*-------------------------------Truncate target table-------------------------------*/
	
	TRUNCATE TABLE [con_sa].[t_ariba_part];
	
	PRINT 'Info : Completed truncating t_ariba_part'

BEGIN    
    SET @rowStatusPSACode = 26001
	SET @dssTime= CURRENT_TIMESTAMP
	


 BEGIN TRY
 BEGIN TRANSACTION;
 
 /* Inserting the active psa records to the materialisation output table for part */
 
INSERT INTO [con_sa].[t_ariba_part]
(
  PART_NUMBER,
  REVISION_NUMBER,
  DESCRIPTION1,
  DESCRIPTION2,
  STANDARD_COST,
  STANDARD_COST_CURRENCY,
  STANDARD_COST_DATE,
  STOCK_INDICATOR,
  MANUFACTURER_NAME,
  MANUFACTURER_PART_NUMBER,
  LEAD_TIME_IN_DAYS,
  FLEX_FIELD_1,
  FLEX_FIELD_2,
  FLEX_FIELD_3,
  PART_FLEX_TEXT_1,
  PART_FLEX_TEXT_2,
  PART_FLEX_TEXT_3,
  ORIGIN_COUNTRY,
  MATERIAL_COMPOSITION,
  FORECAST_USAGE_1,
  FORECAST_USAGE_2,
  FORECAST_USAGE_3,
  DSS_CREATE_TIME,
  DSS_UPDATE_TIME       
)
SELECT Distinct
    REPLACE(trim(CAST(item_code.ItemCode AS NVARCHAR(30))), '_', '') AS ItemCode,
    NULL,
    REPLACE(trim(CAST(stock_item.Name AS NVARCHAR(60))), '_', '') AS Name,
    REPLACE(trim(CAST(stock_item.Description AS NVARCHAR(60))), '_', '') AS Description,
    CONVERT(DECIMAL(10, 5), stock_item.StandardCost) AS StandardCost,
    'GBP',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    'Liz Earle',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    @dssTime AS [DSS_CREATE_TIME],
    @dssTime AS [DSS_UPDATE_TIME]
FROM psa.LEIT_LEXDH_LE_Stock_Item_LEXDH_Incr stock_item
    JOIN psa.LEIT_LEXDH_LE_POP_Order_Return_Line_LEXDH_Incr item_code
        ON stock_item.code = item_code.ItemCode
		-- Picking active records (row_status=26001 and active_flag='Y') with common code between LEIT_LEXDH_LE_Stock_Item_LEXDH_Incr and LEIT_LEXDH_LE_POP_Order_Return_Line_LEXDH_Incr
where stock_item.row_status = @rowStatusPSACode
      and stock_item.active_flag = 'Y'
      and item_code.row_status = @rowStatusPSACode
      and item_code.active_flag = 'Y'
      and item_code.ItemCode is not null
      and stock_item.code is not null;
	  
	-- ItemCode and code are not null column in the table and DQ Warning has been raised for the same. Hence if these columns have NULL values, they should not be inserted into the table

PRINT 'Info : Completed insertion of t_ariba_part'
    
    COMMIT TRANSACTION;                    
        END TRY
        BEGIN CATCH
                THROW;
                ROLLBACK TRANSACTION ;    
            END CATCH 


END
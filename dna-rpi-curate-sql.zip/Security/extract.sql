﻿/****** Object:  Schema [extract]    Script Date: 17/09/2020 09:30:09 ******/
CREATE SCHEMA [extract]
﻿/****** Object:  Schema [con_rprs]    Script Date: 21/08/2022 11:13:45 ******/
CREATE SCHEMA [con_rprs]
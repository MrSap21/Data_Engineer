﻿/****** Object:  Schema [con_dwh]    Script Date: 09/02/2021 13:10:45 ******/
CREATE SCHEMA [con_dwh]
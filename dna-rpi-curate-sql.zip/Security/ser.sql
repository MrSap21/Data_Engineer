﻿/****** Object:  Schema [ser]    Script Date: 6/7/2021 4:46:10 PM ******/
CREATE SCHEMA [ser]
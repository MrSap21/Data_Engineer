﻿/****** Object:  Schema [psa]    Script Date: 21/03/2023  ******/
create schema [ser_pharmaceuticals]
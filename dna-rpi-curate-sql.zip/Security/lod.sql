﻿/****** Object:  Schema [lod]    Script Date: 03/09/2020 14:15:29 ******/
CREATE SCHEMA [lod]
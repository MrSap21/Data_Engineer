﻿/****** Object:  Schema [dc_metadata]    Script Date: 30/06/2021 14:42:29 ******/
CREATE SCHEMA [dc_metadata]
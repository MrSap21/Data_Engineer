﻿/****** Object:  Schema [con_psa]    Script Date: 09/02/2021 13:10:45 ******/
CREATE SCHEMA [con_psa]
﻿CREATE SCHEMA [lab_ir]

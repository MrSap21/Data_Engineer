﻿CREATE PROC [con_odh].[GenerateEgressExtractODH] @pETLRunLogID [NVARCHAR](255) AS
/*
FileName    : [sp_GenerateEgressODH]
Description : Populate Data in ODH Egress DataMarts.
*/

/* Declare and Initialize Generic variables*/
		DECLARE @vProcedureMessage                   NVARCHAR(MAX) ,
				@vProcedureStatus                    NVARCHAR(max)  ;
			 		
		
BEGIN

	BEGIN TRY

	          SET @vProcedureMessage = 'OK'
			  SET @vProcedureStatus = '0'
	 	
			
	Truncate table con_odh.DL_Customer_Address_OPS
	Insert into con_odh.DL_Customer_Address_OPS select * from con_odh.tmp_DL_Customer_Address_OPS
PRINT 'DL_Customer_Address_OPS  completed';

	Truncate table con_odh.DL_Customer_Appointment_OPS
	Insert into con_odh.DL_Customer_Appointment_OPS select * from con_odh.tmp_DL_Customer_Appointment_OPS
PRINT 'DL_Customer_Appointment_OPS  completed';

	Truncate table con_odh.DL_Customer_Master_OPS
	Insert into con_odh.DL_Customer_Master_OPS select * from con_odh.tmp_DL_Customer_Master_OPS
PRINT 'DL_Customer_Master_OPS  completed';

	Truncate table con_odh.DL_Customer_Summary_OPS
	Insert into con_odh.DL_Customer_Summary_OPS select * from con_odh.tmp_DL_Customer_Summary_OPS
PRINT 'DL_Customer_Summary_OPS  completed';

	Truncate table con_odh.DL_Transaction_Reference_OPS
	Insert into con_odh.DL_Transaction_Reference_OPS select * from con_odh.tmp_DL_Customer_Transaction_OPS
PRINT 'DL_Transaction_Reference_OPS  completed';
					
			
			SELECT  @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

	END TRY

	BEGIN CATCH
	THROW;
				
    END CATCH;
END
GO
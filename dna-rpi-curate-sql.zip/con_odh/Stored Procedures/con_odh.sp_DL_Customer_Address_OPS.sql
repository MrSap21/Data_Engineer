﻿CREATE PROC [con_odh].[sp_DL_Customer_Address_OPS] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_DL_Customer_Address_OPS
Purpose						: Load Extract table for Address
Target Tables             	: con_odh.DL_Customer_Address_OPS

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed AS argument

*************************************************************************************************************
03-11-2022   :  Disti Jain	     Inital Version 1.0
 */


BEGIN	


      /* Declare and Initialize Generic variables*/
	    DECLARE @vProcedureMessage                  as nvarchar(MAX) = 'OK';
        DECLARE @vProcedureStatus                   as nvarchar(20)  = '0';
		DECLARE @vNumRows                           AS INT           = 0;
		/*DECLARE @PersonETLRunId                      INT;*/
		/*DECLARE @PartyAddressETLRunId                INT;*/
		DECLARE @cnt AS INT=0;
		DECLARE @count INT;
		DECLARE @total_records INT;
		DECLARE @egress_status AS Int=0;
		DECLARE @frequency as nvarchar(255)='History';
		DECLARE @curr_timestamp NVARCHAR(max);
		DECLARE @limit int;
		DECLARE @RunTime DATETIME;
		DECLARE @rerun AS INT=0; 
		DECLARE @endRunTime as DATETIME='9999-12-31 00:00:00.000';
		DECLARE @flag INT;
		DECLARE @feed_name nvarchar(100);
		DECLARE @rowsextracted as int;
		DECLARE @batch as int=0;
		DECLARE @prev_batch as int=0;

	

 BEGIN TRY
 
		
		
	BEGIN TRANSACTION;
		
		SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
		SET @feed_name='DL_Customer_Address_OPS_'+@curr_timestamp

		SET @count = (SELECT Count(*)  FROM  psa.egress_sp_logs_odh WHERE  project_name = 'ODH' AND feed_name like 'DL_Customer_Address_OPS_%' and active_flag='Y')
				
		IF @count !=0
		BEGIN
			SELECT top 1 @egress_status=egress_status,@batch=batch  FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Address_OPS_%' and active_flag='Y' order by  dt_created desc
			select @rerun=ReRun_Flag,@frequency=frequency from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Address_OPS_%' and active_flag='Y' and ReRun_Flag='1'
		END
				
			IF (@count != 0 and @egress_status != '0')
			BEGIN 
				SELECT top 1 @frequency=frequency,@cnt=rowid_extracted  FROM  psa.egress_sp_logs_odh  where  project_name = 'ODH' AND feed_name like 'DL_Customer_Address_OPS_%' and active_flag='Y' order by  dt_created desc
			END
			
			
			IF @count != 0 and @egress_status = '0' and @rerun!=1
			BEGIN 
				SET @frequency = 'Incremental'
			END
			
			print @frequency
			
			IF @frequency = 'History'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='History_limit')
			END
			
			IF @frequency = 'Incremental'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='Incr_limit')
			END
			
			print @egress_status
				
			IF @egress_status = '0'
			BEGIN 
				IF @rerun='1'
				BEGIN
					SELECT @endRunTime=dt_created,@batch=batch from psa.egress_sp_logs_odh where  project_name = 'ODH' AND feed_name like 'DL_Customer_Address_OPS_%' and ReRun_Flag='1' and active_flag='Y'
				END
				ELSE
				BEGIN
					SET @endRunTime='9999-12-31 00:00:00.000';
					SET @batch=@batch+1
				END
				print @endRunTime
				
				SELECT TOP 1 @flag=isnull(min(egress_status),0),@prev_batch=isnull(min(batch),0) From
				(select ROW_NUMBER() OVER(ORDER BY dt_created desc) AS rn,* from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Address_OPS_%'  and active_flag='Y' and dt_created<@endRunTime) a where rn=2
				print @flag
				
				if @flag != '0'
				begin
				set @RunTime=(SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Address_OPS_%' and active_flag='Y' and dt_created<@endRunTime and batch =@prev_batch order by  dt_created asc);
				end
				if @flag = '0'
				begin
				set @RunTime=(SELECT ISNULL(min(a.dt_created), cast('1900-01-01' as datetime)) as dt_created from (SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where 
				project_name = 'ODH' AND feed_name like 'DL_Customer_Address_OPS_%' and active_flag='Y' and dt_created<@endRunTime order by  dt_created desc)a);
				end
				
				print @RunTime
							
				/*SET @PersonETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.Person where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @PartyAddressETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.PartyAddress where RunDateTime > cast(@RunTime as datetime) )*/
			
			INSERT INTO [con_odh].[temp_DL_Customer_Address_OPS]
			(
			OPS_CUSTOMER_NUMBER	,
			SURNAME              ,
			FORENAME             ,
			TITLE                ,
			BUILDING_NAME        ,
			BUILDING_NUM         ,
			UNIT                 ,
			ROAD                 ,
			LOCALITY             ,
			TOWN                 ,
			COUNTY               ,
			POSTCODE             ,
			COUNTRY              ,
			ROW_ID
			)
			SELECT DISTINCT 
			isnull(cast(Person.CustomerNumber as nvarchar(max)) ,'') AS OPS_CUSTOMER_NUMBER,
			isnull(cast(Person.LastName as nvarchar(max)) ,'') AS SURNAME,
			isnull(cast(Person.FirstName as nvarchar(max)) ,'') AS FORENAME,
			isnull(cast(Person.Title as nvarchar(max)) ,'') AS TITLE,
			isnull(cast(PartyAddress.BuildingName as nvarchar(max)) ,'') AS BUILDING_NAME,
			isnull(cast(PartyAddress.HouseNumber as nvarchar(max)) ,'') AS BUILDING_NUM,
			isnull(cast(PartyAddress.UnitDescription as nvarchar(max)) ,'') AS UNIT,
			isnull(cast(PartyAddress.Address1 as nvarchar(max)) ,'') AS ROAD,
			isnull(cast(PartyAddress.Address2 as nvarchar(max)) ,'') AS LOCALITY,
			isnull(cast(PartyAddress.City as nvarchar(max)) ,'') AS TOWN,
			isnull(cast(PartyAddress.Address3 as nvarchar(max)) ,'') AS COUNTY,
			isnull(cast(PartyAddress.PostCode as nvarchar(max)) ,'') AS POSTCODE,
			isnull(cast(REFCountry.CountryCode as nvarchar(max)) ,'') AS COUNTRY,
			ROW_NUMBER() OVER(ORDER BY Person.CustomerNumber ASC) AS Row_id
			FROM (select * from curate_enterprise.Person where DLSCDActiveFlag ='Y' AND RecordSourceCode = 'BUKOPMS' AND CustomerTypeName='ODH Patient' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) Person 
			INNER JOIN (select * from curate_enterprise.PartyAddress where DLSCDActiveFlag ='Y' AND RecordSourceCode = 'BUKOPMS' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) PartyAddress  
			ON Person.PartyID = PartyAddress.PartyID
			INNER JOIN (select * from curate_enterprise.REFCountry where DLSCDActiveFlag ='Y' AND RecordSourceCode = 'BUKOPMS') REFCountry 
			ON PartyAddress.REFCountryID = REFCountry.REFCountryID;
			
			
			PRINT 'Info : Completed insertion of DL_Customer_Address_OPS'
			
			END
	
			SET @total_records = (SELECT count(*) FROM  con_odh.temp_DL_Customer_Address_OPS)
			print @total_records
			
			insert into con_odh.DL_Customer_Address_OPS select distinct OPS_CUSTOMER_NUMBER	,SURNAME,FORENAME,TITLE,BUILDING_NAME,BUILDING_NUM,UNIT,ROAD,LOCALITY,TOWN,COUNTY,POSTCODE,COUNTRY from (select top (@limit) * from con_odh.temp_DL_Customer_Address_OPS where row_id>@cnt order by row_id)a
			
			SET @rowsextracted=@total_records-@cnt
			SET @cnt= (select max(a.row_id) from (select top (@limit) * from con_odh.temp_DL_Customer_Address_OPS where row_id>@cnt order by row_id)a)
			
			IF @cnt != @total_records
			BEGIN 
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag=0 where rerun_flag=1 and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',1,0)
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',0,0)
				END
			END
			
			IF @cnt = @total_records
			BEGIN 
				--Truncate table [con_odh].[temp_DL_Customer_Address_OPS]
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag='0' where rerun_flag='1' and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',1,0)
					update psa.egress_sp_logs_odh set active_flag='N' where rerun_flag='1'
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',0,0)
				END
			END
		
    	
    SELECT @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

 

 

END TRY
        BEGIN CATCH
        IF @@TRANCOUNT>0
            ROLLBACK TRANSACTION;

 

            DECLARE @vErrorMessage as nvarchar(500) = 
            (SELECT CONCAT( '{"Error number":'    ,'"', ERROR_NUMBER()    ,'"',', '
                                          ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
                                            ,'"Severity":' ,         '"', ERROR_SEVERITY()  ,'"',', '
                                        ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
                                            ,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

 

            SET @vProcedureMessage = @vErrorMessage

 

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;

 

 

            INSERT INTO [psa].[DNA_DB_Errors_Log] 
            SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_DL_Customer_Address_OPS]',ERROR_MESSAGE(),GETDATE();
        THROW;                    
                                
        END CATCH 
        IF @@TRANCOUNT>0
            COMMIT TRANSACTION;
			
		IF @cnt = @total_records
		BEGIN 
			Truncate table [con_odh].[temp_DL_Customer_Address_OPS]
		END
 

END
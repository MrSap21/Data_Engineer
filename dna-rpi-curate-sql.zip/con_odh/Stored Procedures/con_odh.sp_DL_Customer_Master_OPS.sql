﻿CREATE PROC [con_odh].[sp_DL_Customer_Master_OPS] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_DL_Customer_Master_OPS
Purpose						: Load Extract table for Address
Target Tables             	: con_odh.DL_Customer_Master_OPS

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed AS argument

*************************************************************************************************************
03-11-2022   :  Disti Jain	     Inital Version 1.0
 */


BEGIN	


      /* Declare and Initialize Generic variables*/
	    DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
        DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';
		DECLARE @vNumRows                           AS INT           = 0;
		DECLARE @cnt AS INT=0;
		DECLARE @count INT;
		DECLARE @total_records INT;
		DECLARE @egress_status AS Int=0;
		DECLARE @frequency AS nvarchar(255)='History';
		DECLARE @curr_timestamp NVARCHAR(max);
		DECLARE @limit int;
		DECLARE @RunTime DATETIME;
		DECLARE @rerun AS INT=0; 
		DECLARE @endRunTime as DATETIME='9999-12-31 00:00:00.000';
		DECLARE @flag INT;
		DECLARE @feed_name nvarchar(100);
		DECLARE @rowsextracted as int;
		DECLARE @batch as int=0;
		DECLARE @prev_batch as int=0;
		DECLARE @exec_sql NVARCHAR(MAX);
		--DECLARE @tablecolumns VARCHAR(1500);

	
		

 BEGIN TRY
 
 
	IF OBJECT_ID('tempdb..#DL_Customer_Master_OPS_test_temp') IS NOT NULL
		BEGIN
			EXEC ('DROP table tempdb..#DL_Customer_Master_OPS_test_temp')
		END
		SET @exec_sql = 'SELECT TOP 0 *,OPS_CUSTOMER_NUMBER AS PRESCRIPTION_CODE,/*CLRS_REG_DATE AS LAST_UPDATE,CLRS_REG_DATE AS EyeCheckUpDateTime,*/CLRS_REG_DATE AS PrevLensCheckDate,CLRS_REG_DATE AS DDLReportDate,CLRS_REG_DATE AS ExpiryDate, CLRS_REG_DATE AS LastUpdateReward, CLRS_REG_DATE AS UpdateTimeStamp,CLRS_REG_DATE AS LastUpdateSpecification,CLRS_REG_DATE AS PrescriptionDateTime,OPS_CUSTOMER_NUMBER AS Comm_UpdateTimeStamp INTO tempdb..#DL_Customer_Master_OPS_test_temp FROM [con_odh].[DL_Customer_Master_OPS]'
		EXEC(@exec_sql)		
		
	BEGIN TRANSACTION;
		
		SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
		SET @feed_name='DL_Customer_Master_OPS_'+@curr_timestamp

		SET @count = (SELECT Count(*)  FROM  psa.egress_sp_logs_odh WHERE  project_name = 'ODH' AND feed_name like 'DL_Customer_Master_OPS_%' and active_flag='Y')
				
		IF @count !=0
		BEGIN
			SELECT top 1 @egress_status=egress_status,@batch=batch  FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Master_OPS_%' and active_flag='Y' order by  dt_created desc
			select @rerun=ReRun_Flag,@frequency=frequency from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Master_OPS_%' and active_flag='Y' and ReRun_Flag='1'
		END
				
			IF (@count != 0 and @egress_status != '0')
			BEGIN 
				SELECT top 1 @frequency=frequency,@cnt=rowid_extracted  FROM  psa.egress_sp_logs_odh  where  project_name = 'ODH' AND feed_name like 'DL_Customer_Master_OPS_%' and active_flag='Y' order by  dt_created desc
			END
			
			
			IF @count != 0 and @egress_status = '0' and @rerun!=1
			BEGIN 
				SET @frequency = 'Incremental'
			END
			
			print @frequency
			
			IF @frequency = 'History'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='History_limit')
			END
			
			IF @frequency = 'Incremental'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='Incr_limit')
			END
			
			print @egress_status
				
			IF @egress_status = '0'
			BEGIN 
				IF @rerun='1'
				BEGIN
					SELECT @endRunTime=dt_created,@batch=batch from psa.egress_sp_logs_odh where  project_name = 'ODH' AND feed_name like 'DL_Customer_Master_OPS_%' and ReRun_Flag='1' and active_flag='Y'
				END
				ELSE
				BEGIN
					SET @endRunTime='9999-12-31 00:00:00.000';
					SET @batch=@batch+1
				END
				print @endRunTime
				
				SELECT TOP 1 @flag=isnull(min(egress_status),0),@prev_batch=isnull(min(batch),0) From
				(select ROW_NUMBER() OVER(ORDER BY dt_created desc) AS rn,* from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Master_OPS_%'  and active_flag='Y' and dt_created<@endRunTime) a where rn=2
				print @flag
				
				if @flag != '0'
				begin
				set @RunTime=(SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Master_OPS_%' and active_flag='Y' and dt_created<@endRunTime and batch =@prev_batch order by  dt_created asc);
				end
				if @flag = '0'
				begin
				set @RunTime=(SELECT ISNULL(min(a.dt_created), cast('1900-01-01' as datetime)) as dt_created from (SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where 
				project_name = 'ODH' AND feed_name like 'DL_Customer_Master_OPS_%' and active_flag='Y' and dt_created<@endRunTime order by  dt_created desc)a);
				end
				
				print @RunTime
				--SET @tempTableName = 'tempdb..#DL_Customer_Master_OPS_test_temp'
    
		
			INSERT INTO tempdb..#DL_Customer_Master_OPS_test_temp	--[con_odh].[temp_DL_Customer_Master_OPS]
		(
		    OPS_CUSTOMER_NUMBER			  ,
			DATE_OF_BIRTH	              ,
			TELEPHONE_HOME 	              ,
			TELEPHONE_WORK	              ,
			TELEPHONE_MOBILE	          ,
			EMAIL	                      ,
			CLRS_NUMBER	                  ,
			CLRS_SCHEME_STATUS	          ,
			CLRS_REG_DATE	              ,
			CLCS_REG_DATE	              ,
			CLCS_SCHEME_STATUS	          ,
			CLCS_EXPIRY_DATE	          ,
			OPS_STORE_NUMBER	          ,
			GENDER	                      ,
			EYE_TEST_RESULT	              ,
			EYE_TEST_RECALL_CYCLE	      ,
			LAST_EYE_TEST_DATE	          ,
			CL_RECALL_CYCLE	              ,
			LAST_CL_DATE	              ,
			NHS_OR_PRIVATE	              ,
			CL_SUITABLE_FLAG	          ,
			COMM_PREFERENCE	              ,
			CONTACT_VIA_MAIL_FLAG	      ,
			CONTACT_VIA_PHONE_FLAG	      ,
			CONTACT_VIA_SMS_FLAG	      ,
			CONTACT_VIA_EMAIL_FLAG	      ,
			GONE_AWAY_FLAG	              ,
			DECEASED_FLAG	              ,
			MASTER_SUPPRESSION_FLAG	      ,
			EXTERNAL_PRESCRIPTION_FLAG	  ,
			EXTERNAL_PROVIDER	          ,
			SENSITIVE_CONSENT_FLAG	      ,
			SENSITIVE_CONSENT_GIVEN_DATE  ,
			PRESCRIPTION_CHANGED_FLAG	  ,
			PRESCRIPTION_CODE			  ,
			/*LAST_UPDATE					  ,
			EyeCheckUpDateTime			  ,*/
			PrevLensCheckDate			  ,
			DDLReportDate				  ,
			EXPIRYDATE					  ,
			LastUpdateReward			  ,
			UpdateTimeStamp				  ,
			LastUpdateSpecification       ,
			PrescriptionDateTime          ,
			Comm_UpdateTimeStamp
		)
		SELECT DISTINCT
		isnull(cast(Person.CustomerNumber as nvarchar(max)) ,'') AS OPS_CUSTOMER_NUMBER,
		isnull(cast(convert(char(10),Person.DateOfBirth,126) as nvarchar(max)) ,'') AS DATE_OF_BIRTH,
		isnull(cast(PartyPhoneHome.PhoneNumber as nvarchar(max)) ,'') AS TELEPHONE_HOME,
		isnull(cast(PartyPhoneWork.PhoneNumber as nvarchar(max)) ,'') AS TELEPHONE_WORK,
		isnull(cast(PartyPhoneMobile.PhoneNumber as nvarchar(max)) ,'') AS TELEPHONE_MOBILE,
		isnull(cast(PartyEmail.EmailAddress as nvarchar(max)) ,'') AS EMAIL,
		isnull(cast(ODHPatientReward.SchemeNumber as nvarchar(max)) ,'') AS CLRS_NUMBER,
		isnull(cast(case when ODHPatientReward.PlanStatus is not null then ODHPatientReward.PlanStatus else (case when ODHOrderHeader.cnt>0 then 'Cash' else '' end) end  as nvarchar(max)) ,'') AS CLRS_SCHEME_STATUS,
		isnull(cast(convert(char(10),ODHPatientReward.DDLReportDate,126) as nvarchar(max)) ,'') AS CLRS_REG_DATE,
		isnull(cast(convert(char(10),ODHPatientContactLensCarePlan.CreationTimestamp,126) as nvarchar(max)) ,'') AS CLCS_REG_DATE,
		isnull(case when ODHPatientContactLensCarePlan.ExpiryDate>= getdate() then 'LIVE' when ODHPatientContactLensCarePlan.ExpiryDate is null then Null else 'ARCH' end,'') AS CLCS_SCHEME_STATUS,
		isnull(cast(convert(char(10),ODHPatientContactLensCarePlan.ExpiryDate,126) as nvarchar(max)) ,'') AS CLCS_EXPIRY_DATE,
		--isnull(cast(SiteRole.SourceSiteRoleCode as nvarchar(max)) ,'') AS OPS_STORE_NUMBER,
		isnull(case when SiteRole1.SourceSiteRoleCode is not null THEN SiteRole1.SourceSiteRoleCode ELSE SiteRole2.SourceSiteRoleCode END,'') AS  OPS_STORE_NUMBER,
		isnull(cast(Person.SRCGender as nvarchar(max)) ,'') AS GENDER,
		isnull(case when ODHServiceGroupAdviceGiven.NoCorrection=1 then 'No Correction' when ODHServiceGroupAdviceGiven.NoCorrection is null then (case when ODHServiceGroupAdviceGiven.Referral= 1 then 'Referral' else ODHServiceGroupAdviceGiven.CorrectionType end) else ODHServiceGroupAdviceGiven.CorrectionType END,'') AS EYE_TEST_RESULT,
		isnull(cast(SUBSTRING(ODHAdditionalPrescription.Recall,1,len(ODHAdditionalPrescription.Recall)-1) as nvarchar(max)) ,'') AS EYE_TEST_RECALL_CYCLE,
		isnull(cast(ODHAdditionalPrescription.PrescriptionDate as nvarchar(max)) ,'') AS LAST_EYE_TEST_DATE,
		isnull(cast(ODHPatientContactLensSpecification.RecallPeriod as nvarchar(max)) ,'') AS CL_RECALL_CYCLE,
		isnull(cast(convert(char(10),ODHPatientContactLensSpecification.PrevLensCheckDate,126) as nvarchar(max)) ,'') AS LAST_CL_DATE,
		isnull(cast(CASE WHEN OdhPatientPrescription.Status= 'Active' and (OdhPatientPrescription.ExternalType <> 'CLSpecification' or OdhPatientPrescription.ExternalType is null) and (x.PaymentMethodName like '%GOS1%' or x.PaymentMethodName like '%GOS 1%') THEN  'N' ELSE 'P' END as nvarchar(max)),'') AS NHS_OR_PRIVATE,
		isnull(cast(ODHServiceGroupAdviceGiven.SuitableContactLenses as nvarchar(max)),'') AS CL_SUITABLE_FLAG,
		isnull(case WHEN (ODHPatientConsentInfo_COMM_PREFERENCE.ConsentTypeName = 'No Communications' AND ODHPatientConsentInfo_COMM_PREFERENCE.AgreementStatus = 1) THEN '3'
		WHEN (ODHPatientConsentInfo_COMM_PREFERENCE.ConsentTypeName = 'Marketing Permission' AND ODHPatientConsentInfo_COMM_PREFERENCE.AgreementStatus = 1) THEN '1'
		WHEN (ODHPatientConsentInfo_COMM_PREFERENCE.ConsentTypeName = 'Reminders Only' AND ODHPatientConsentInfo_COMM_PREFERENCE.AgreementStatus = 1) THEN '5'
		WHEN (ODHPatientConsentInfo_COMM_PREFERENCE.ConsentTypeName= 'Reminders Only WITH Offers' AND ODHPatientConsentInfo_COMM_PREFERENCE.AgreementStatus = 1) THEN '2'
		WHEN (ODHPatientConsentInfo_COMM_PREFERENCE.ConsentTypeName = 'Reminders Only WITHOUT Offers' AND ODHPatientConsentInfo_COMM_PREFERENCE.AgreementStatus = 1) THEN '4'
		ELSE '' END,'') AS COMM_PREFERENCE,
		isnull(case when ODHPatientConsentInfo_Post.ConsentTypeName = 'Post'  AND ODHPatientConsentInfo_Post.AgreementStatus = 1 THEN 'Y' ELSE 'N' END,'') AS  CONTACT_VIA_MAIL_FLAG,
		isnull(case when ODHPatientConsentInfo_Phone.ConsentTypeName = 'Phone'  AND ODHPatientConsentInfo_Phone.AgreementStatus = 1 THEN 'Y' ELSE 'N' END,'') AS  CONTACT_VIA_PHONE_FLAG,
		isnull(case when ODHPatientConsentInfo_Text.ConsentTypeName = 'Text'  AND ODHPatientConsentInfo_Text.AgreementStatus = 1 THEN 'Y' ELSE 'N' END,'') AS  CONTACT_VIA_SMS_FLAG,
		isnull(case when ODHPatientConsentInfo_Email.ConsentTypeName = 'Email'  AND ODHPatientConsentInfo_Email.AgreementStatus = 1 THEN 'Y' ELSE 'N' END,'') AS CONTACT_VIA_EMAIL_FLAG,
		isnull(cast(PartyAddress.GoneAway as nvarchar(max)) ,'') AS GONE_AWAY_FLAG,
		isnull(cast(ODHPatient.Status as nvarchar(max)) ,'') AS DECEASED_FLAG,
		isnull(cast(NULL as nvarchar(max)) ,'') AS MASTER_SUPPRESSION_FLAG,
		isnull(cast(ODHAdditionalPrescription.ExternalPrescription as nvarchar(max)) ,'') AS EXTERNAL_PRESCRIPTION_FLAG,
		isnull(cast(ODHAdditionalPrescription.ExternalPrescriptionFrom as nvarchar(max)) ,'') AS EXTERNAL_PROVIDER,
		isnull(case WHEN (ODHPatientConsentInfo_Sensitive_Marketing.ConsentTypeName = 'Sensitive Marketing' AND ODHPatientConsentInfo_Sensitive_Marketing.AgreementStatus='1') THEN '1' ELSE 0 end,'') AS SENSITIVE_CONSENT_FLAG,
		isnull(cast(convert(char(10),ODHPatientConsentInfo_Sensitive_Marketing.UpdateTimeStamp,126) as nvarchar(max)),'') AS SENSITIVE_CONSENT_GIVEN_DATE,
		isnull(cast(case when ODHServiceGroupAdviceGiven.Correction is Null then '' when ODHServiceGroupAdviceGiven.Correction ='0' then '' when ODHServiceGroupAdviceGiven.Correction='1' then (case when ODHServiceGroupAdviceGiven.CorrectionType = 'NEW' THEN '1' when ODHServiceGroupAdviceGiven.CorrectionType = 'STABLE' THEN '0' else '' end) end as nvarchar(max)),'') AS PRESCRIPTION_CHANGED_FLAG,
		isnull(cast(ODHAdditionalPrescription.PRESCRIPTIONCODE as nvarchar(max)),'') AS PRESCRIPTION_CODE,
		/*isnull(convert(nvarchar,join1.LASTUPDATE , 21),'')  AS LAST_UPDATE,
		isnull(convert(nvarchar,join1.EyeCheckUpDateTime , 21),'')  AS EyeCheckUpDateTime,*/
		isnull(convert(nvarchar,ODHPatientContactLensSpecification.PrevLensCheckDate , 21),'')  AS PrevLensCheckDate,
		isnull(convert(nvarchar,ODHPatientReward.DDLReportDate , 21),'')  AS DDLReportDate,
		isnull(convert(nvarchar,ODHPatientContactLensCarePlan.ExpiryDate , 21),'')  AS ExpiryDate,
		isnull(convert(nvarchar,ODHPatientReward.LastUpdate , 21),'') AS LastUpdateReward,		
		isnull(convert(nvarchar,ODHPatientConsentInfo_Sensitive_Marketing.UpdateTimeStamp , 21),'')  AS UpdateTimeStamp,
		isnull(convert(nvarchar,ODHPatientContactLensSpecification.LastUpdate , 21),'') AS LastUpdateSpecification,
		isnull(convert(nvarchar,OdhPatientPrescription.PrescriptionDateTime , 21),'') AS PrescriptionDateTime,
		isnull(convert(nvarchar,ODHPatientConsentInfo_COMM_PREFERENCE.UpdateTimeStamp , 21),'')  AS Comm_UpdateTimeStamp
		from (select * from curate_enterprise.Person where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and CustomerTypeName='ODH Patient' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)Person
		left outer join (select * from curate_enterprise.PartyPhone where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and SRCPhoneType = 'HOME_TELEPHONE_NUMBER' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)PartyPhoneHome on Person.PartyID=PartyPhoneHome.PartyID
		left outer join (select * from curate_enterprise.PartyPhone where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and SRCPhoneType = 'WORK_TELEPHONE_NUMBER' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)PartyPhoneWork on Person.PartyID=PartyPhoneWork.PartyID
		left outer join (select * from curate_enterprise.PartyPhone where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and SRCPhoneType = 'MOBILE_TELEPHONE_NUMBER' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)PartyPhoneMobile on Person.PartyID=PartyPhoneMobile.PartyID
		left outer join (select * from curate_enterprise.PartyEmail where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and SRCEmailType = 'EMAIL' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) PartyEmail on Person.PartyID=PartyEmail.PartyID
		left outer join (select * from curate_enterprise.ODHPatientReward where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHPatientReward on Person.PersonID=ODHPatientReward.PersonID
		left outer join (select * from curate_enterprise.ODHPatientContactLensCarePlan where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHPatientContactLensCarePlan on Person.PersonID=ODHPatientContactLensCarePlan.PersonID
		left outer join (select * from curate_enterprise.ODHPatient where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHPatient on Person.PersonID=ODHPatient.PersonID
		left outer join (select * from curate_enterprise.ODHPatientServiceGroup where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHPatientServiceGroup on Person.PersonID=ODHPatientServiceGroup.PersonID
		left outer join (select * from curate_enterprise.OdhPatientPrescription where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime and (STATUS ='Active' or Status is null))OdhPatientPrescription on Person.PersonID=OdhPatientPrescription.PersonID
		left outer join  (select * from (select row_number() over (partition by PatientPrescriptionId order by prescriptiondate desc,prescriptioncode desc) as rn,* from curate_enterprise.ODHAdditionalPrescription  where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS')   t where rn=1 AND DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime and ServiceItemType ='Prescription')ODHAdditionalPrescription on OdhPatientPrescription.PrescriptionCode=ODHAdditionalPrescription.ServiceItemCode
		left outer join (select * from curate_enterprise.ODHServiceGroupAdviceGiven where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime and ServiceItemType IN ('FinalRefraction','Prescription'))ODHServiceGroupAdviceGiven on OdhPatientPrescription.PrescriptionCode=ODHServiceGroupAdviceGiven.ServiceItemCode
		left outer join (select * from curate_enterprise.SiteRole where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RoleId=(select Roleid from curate_enterprise.REFRole where RoleName='Practice' and RecordSourceCode='DNARDM') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )SiteRole1 on OdhPatientPrescription.PracticeSiteRoleId=SiteRole1.SiteRoleId
		left outer join (select * from curate_enterprise.SiteRole where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RoleId=(select Roleid from curate_enterprise.REFRole where RoleName='Practice' and RecordSourceCode='DNARDM') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )SiteRole2 on ODHPatient.PracticeSiteRoleId=SiteRole2.SiteRoleId
		left outer join (select * from curate_enterprise.ODHPatientContactLensSpecification where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and status in ('final','final_clof') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHPatientContactLensSpecification on Person.PersonID=ODHPatientContactLensSpecification.PersonID
		left outer join (select * from curate_enterprise.PartyAddress where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )PartyAddress on Person.PartyID	= PartyAddress.PartyID
		left outer join (select * from curate_enterprise.ODHPatientConsentInfo where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and (ConsentTypeName = 'No Communications' or ConsentTypeName = 'Marketing Permission' or ConsentTypeName = 'Reminders Only' or ConsentTypeName= 'Reminders Only WITH Offers' or ConsentTypeName = 'Reminders Only WITHOUT Offers') and  AgreementStatus='1' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHPatientConsentInfo_COMM_PREFERENCE  on Person.PersonID=ODHPatientConsentInfo_COMM_PREFERENCE.PersonID
		left outer join (select * from curate_enterprise.ODHPatientConsentInfo where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and ConsentTypeName = 'Post' and  AgreementStatus='1' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHPatientConsentInfo_Post  on Person.PersonID=ODHPatientConsentInfo_Post.PersonID
		left outer join (select * from curate_enterprise.ODHPatientConsentInfo where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and ConsentTypeName = 'Phone' and  AgreementStatus='1' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHPatientConsentInfo_Phone  on Person.PersonID=ODHPatientConsentInfo_Phone.PersonID
		left outer join (select * from curate_enterprise.ODHPatientConsentInfo where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and ConsentTypeName = 'Text' and  AgreementStatus='1' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHPatientConsentInfo_Text  on Person.PersonID=ODHPatientConsentInfo_Text.PersonID
		left outer join (select * from curate_enterprise.ODHPatientConsentInfo where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and ConsentTypeName = 'Email' and  AgreementStatus='1' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHPatientConsentInfo_Email  on Person.PersonID=ODHPatientConsentInfo_Email.PersonID
		left outer join (select * from curate_enterprise.ODHPatientConsentInfo where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and ConsentTypeName = 'Sensitive Marketing' and  AgreementStatus='1' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHPatientConsentInfo_Sensitive_Marketing  on Person.PersonID=ODHPatientConsentInfo_Sensitive_Marketing.PersonID
		left outer join (select  personid,count(*) as cnt from curate_enterprise.ODHOrderHeader where DLSCDActiveFlag='Y' and RecordSourceCode='BUKOPMS' and OrderHeaderType = 'CONTACT_LENS' AND status NOT IN ( 'CANCELLED', 'INITIAL_STATE', 'VALIDATED', 'ADDED_TO_BASKET', 'KLARNA_ORDER') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime  AND orderdate >= DATEADD(month, -12, getdate()) group by personid)ODHOrderHeader on ODHOrderHeader.PersonId=Person.PersonId
		LEFT OUTER JOIN 
		(select ODHFinPaymentMethod.PaymentMethodName,ODHBusinessPartner.CBPartnerValue from 
		(select PersonId,CBPartnerValue from curate_enterprise.ODhBusinessPartner where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHBusinessPartner 
		INNER JOIN (select OrderId,PersonId from curate_enterprise.[Order] where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )Order1 ON ODHBusinessPartner.PersonId=Order1.PersonId
		INNER JOIN (select ODHOrderId,PersonId from curate_enterprise.ODHOrder where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHOrder ON Order1.OrderId=ODHOrder.ODHOrderId
		INNER JOIN (select OrderLineID,OrderId from curate_enterprise.OrderLine where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )OrderLine ON OrderLine.OrderId=ODHOrder.ODHOrderId
		INNER JOIN (select ODHOrderLineID from curate_enterprise.ODHOrderLine where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHOrderLine ON OrderLine.OrderLineID=ODHOrderLine.ODHOrderLineID
		INNER JOIN (select ODHOrderLineID,PaymentMethodId from curate_enterprise.ODHCustomOrderLinePayments where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHCustomOrderLinePayments ON ODHCustomOrderLinePayments.ODHOrderLineID=ODHOrderLine.ODHOrderLineID
		INNER JOIN (select PaymentMethodId,PaymentMethodName from curate_enterprise.ODHFinPaymentMethod where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHFinPaymentMethod ON ODHCustomOrderLinePayments.PaymentMethodId=ODHFinPaymentMethod.PaymentMethodId
		)x ON Person.CustomerNumber=x.CBPartnerValue
		;

		
		
		PRINT 'Info : Completed insertion of #tmp'
			
			insert into con_odh.temp_DL_Customer_Master_OPS select OPS_CUSTOMER_NUMBER,DATE_OF_BIRTH,TELEPHONE_HOME ,TELEPHONE_WORK,TELEPHONE_MOBILE,EMAIL,CLRS_NUMBER,CLRS_SCHEME_STATUS,CLRS_REG_DATE,CLCS_REG_DATE,CLCS_SCHEME_STATUS,CLCS_EXPIRY_DATE,OPS_STORE_NUMBER,GENDER,EYE_TEST_RESULT,EYE_TEST_RECALL_CYCLE,LAST_EYE_TEST_DATE,CL_RECALL_CYCLE,LAST_CL_DATE,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,COMM_PREFERENCE,CONTACT_VIA_MAIL_FLAG,CONTACT_VIA_PHONE_FLAG,CONTACT_VIA_SMS_FLAG,CONTACT_VIA_EMAIL_FLAG,GONE_AWAY_FLAG,DECEASED_FLAG,MASTER_SUPPRESSION_FLAG,EXTERNAL_PRESCRIPTION_FLAG,EXTERNAL_PROVIDER,SENSITIVE_CONSENT_FLAG,SENSITIVE_CONSENT_GIVEN_DATE,PRESCRIPTION_CHANGED_FLAG,row_number() over (order by a.OPS_CUSTOMER_NUMBER ASC) as row_id from (select dense_rank() over (partition by OPS_CUSTOMER_NUMBER order by LAST_EYE_TEST_DATE desc,PRESCRIPTION_CODE desc,DDLReportDate desc,EXPIRYDATE desc,PrevLensCheckDate desc,/*LAST_UPDATE desc,EyeCheckUpDateTime desc,*/LastUpdateReward desc,UpdateTimeStamp desc,LastUpdateSpecification desc,PrescriptionDateTime desc,Comm_UpdateTimeStamp desc,NHS_OR_PRIVATE asc) as RN,OPS_CUSTOMER_NUMBER,DATE_OF_BIRTH,TELEPHONE_HOME ,TELEPHONE_WORK,TELEPHONE_MOBILE,EMAIL,CLRS_NUMBER,CLRS_SCHEME_STATUS,CLRS_REG_DATE,CLCS_REG_DATE,CLCS_SCHEME_STATUS,CLCS_EXPIRY_DATE,OPS_STORE_NUMBER,GENDER,EYE_TEST_RESULT,EYE_TEST_RECALL_CYCLE,LAST_EYE_TEST_DATE,CL_RECALL_CYCLE,LAST_CL_DATE,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,COMM_PREFERENCE,CONTACT_VIA_MAIL_FLAG,CONTACT_VIA_PHONE_FLAG,CONTACT_VIA_SMS_FLAG,CONTACT_VIA_EMAIL_FLAG,GONE_AWAY_FLAG,DECEASED_FLAG,MASTER_SUPPRESSION_FLAG,EXTERNAL_PRESCRIPTION_FLAG,EXTERNAL_PROVIDER,SENSITIVE_CONSENT_FLAG,SENSITIVE_CONSENT_GIVEN_DATE,PRESCRIPTION_CHANGED_FLAG,PRESCRIPTION_CODE,/*LAST_UPDATE,EyeCheckUpDateTime,*/PrevLensCheckDate,DDLReportDate,EXPIRYDATE,LastUpdateReward,UpdateTimeStamp,LastUpdateSpecification,PrescriptionDateTime,Comm_UpdateTimeStamp FROM tempdb..#DL_Customer_Master_OPS_test_temp)a where a.RN=1 /*and a.OPS_STORE_NUMBER <> ''*/ ;
		
		PRINT 'Info : Completed insertion of temp_DL_Customer_Master_OPS'
			
			
			END
	
			SET @total_records = (SELECT count(*) FROM  con_odh.temp_DL_Customer_Master_OPS)
			print @total_records
			
			insert into con_odh.DL_Customer_Master_OPS select distinct OPS_CUSTOMER_NUMBER,DATE_OF_BIRTH,TELEPHONE_HOME ,TELEPHONE_WORK,TELEPHONE_MOBILE,EMAIL,CLRS_NUMBER,CLRS_SCHEME_STATUS,CLRS_REG_DATE,CLCS_REG_DATE,CLCS_SCHEME_STATUS,CLCS_EXPIRY_DATE,OPS_STORE_NUMBER,GENDER,EYE_TEST_RESULT,EYE_TEST_RECALL_CYCLE,LAST_EYE_TEST_DATE,CL_RECALL_CYCLE,LAST_CL_DATE,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,COMM_PREFERENCE,CONTACT_VIA_MAIL_FLAG,CONTACT_VIA_PHONE_FLAG,CONTACT_VIA_SMS_FLAG,CONTACT_VIA_EMAIL_FLAG,GONE_AWAY_FLAG,DECEASED_FLAG,MASTER_SUPPRESSION_FLAG,EXTERNAL_PRESCRIPTION_FLAG,EXTERNAL_PROVIDER,SENSITIVE_CONSENT_FLAG,SENSITIVE_CONSENT_GIVEN_DATE,PRESCRIPTION_CHANGED_FLAG from (select top (@limit) * from con_odh.temp_DL_Customer_Master_OPS where row_id>@cnt order by row_id)a
			
			PRINT 'Info : Completed insertion of DL_Customer_Master_OPS'
			
			SET @rowsextracted=@total_records-@cnt
			SET @cnt= (select max(a.row_id) from (select top (@limit) * from con_odh.temp_DL_Customer_Master_OPS where row_id>@cnt order by row_id)a)
			
			IF @cnt != @total_records
			BEGIN 
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag=0 where rerun_flag=1 and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',1,0)
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',0,0)
				END
			END
			
			IF @cnt = @total_records
			BEGIN 
				--Truncate table [con_odh].[temp_DL_Customer_Master_OPS]
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag='0' where rerun_flag='1' and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',1,0)
					update psa.egress_sp_logs_odh set active_flag='N' where rerun_flag='1'
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',0,0)
				END
			END
		
    	
    SELECT @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

 

 

END TRY
        BEGIN CATCH
        IF @@TRANCOUNT>0
            ROLLBACK TRANSACTION;

 

            DECLARE @vErrorMessage AS NVARCHAR(500) = 
            (SELECT CONCAT( '{"Error number":'    ,'"', ERROR_NUMBER()    ,'"',', '
                                          ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
                                            ,'"Severity":' ,         '"', ERROR_SEVERITY()  ,'"',', '
                                        ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
                                            ,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

 

            SET @vProcedureMessage = @vErrorMessage

 

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;

 

 

            INSERT INTO [psa].[DNA_DB_Errors_Log] 
            SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_DL_Customer_Master_OPS]',ERROR_MESSAGE(),GETDATE();
        THROW;                    
                                
        END CATCH 
        IF @@TRANCOUNT>0
            COMMIT TRANSACTION;
		
		delete from [con_odh].[DL_Customer_Master_OPS] where SENSITIVE_CONSENT_GIVEN_DATE='' and SENSITIVE_CONSENT_FLAG = '1';
		
		IF @cnt = @total_records
		BEGIN 
			Truncate table [con_odh].[temp_DL_Customer_Master_OPS]
		END
 

END
﻿CREATE PROC [con_odh].[sp_DL_Customer_Summary_OPS] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_DL_Customer_Summary_OPS
Purpose						: Load Extract table for Summary
Target Tables             	: con_odh.DL_Customer_Summary_OPS

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed AS argument

*************************************************************************************************************
03-11-2022   :  Ashlin T	     Inital Version 1.0
 */
	

BEGIN	


      /* Declare and Initialize Generic variables*/
	    DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
        DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';
		DECLARE @vNumRows                           AS INT           = 0;
		
		/*DECLARE @ODHOrderHeaderETLRunId 					   INT;*/
		/*DECLARE @PersonETLRunId                              INT;*/
		/*DECLARE @AppointmentETLRunId                         INT;*/
		/*DECLARE @ODHPatientContactLensSpecificationETLRunId  INT;*/
		/*DECLARE @ODHPatientServiceGroupETLRunId              INT;*/
		/*DECLARE @ODHServiceGroupEyeCheckupETLRunId           INT;*/
		/*DECLARE @ODHServiceGroupAdviceGivenETLRunId          INT;*/
		/*DECLARE @ODHPatientPrescriptionETLRunId              INT;*/
		/*DECLARE @ODHAdditionalPrescriptionETLRunId           INT;*/
		DECLARE @cnt AS INT=0;
		DECLARE @count INT;
		DECLARE @total_records INT;
		DECLARE @egress_status AS Int=0;
		DECLARE @frequency AS nvarchar(255)='History';
		DECLARE @curr_timestamp NVARCHAR(max);
		DECLARE @limit int;
		DECLARE @RunTime DATETIME;
		DECLARE @rerun AS INT=0; 
		DECLARE @endRunTime as DATETIME='9999-12-31 00:00:00.000';
		DECLARE @flag INT;
		DECLARE @feed_name nvarchar(100);
		DECLARE @rowsextracted as int;
		DECLARE @batch as int=0;
		DECLARE @prev_batch as int=0; 
        DECLARE @execsql NVARCHAR(MAX);
		DECLARE @orderHEaderCodeCount nvarchar(max);
        DECLARE @tempTableName nvarchar(max);
		DECLARE @tempTableName2 nvarchar(max);
		DECLARE @exec_sql NVARCHAR(MAX);
	
		
		--Creating temp table for selecting the OrderHEaderCode for a particular PersonId in PersonTAble values by joining Person & ODHOrderHeader tables

		SET @tempTableName = 'tempdb..#DL_Customer_Summary_OPS_test_temp'
    
		IF OBJECT_ID(@tempTableName) IS NOT NULL
		BEGIN
			EXEC ('DROP table '+@tempTableName)
		END
       
		--Inserting the OfferName column in the ranking order into temp table from ODHOffer by joining with ODHOrderLineOffer with OfferId columns order by SourceCreated column 
        set @execsql='SELECT ODHOrderHeader.OrderHeaderCode,ODHOrderHeader.PersonId,ODHOrderHeader.OrderHeaderType,ODHOrderHeader.Status,row_number() over(partition by Person.PersonId order by 
		ODHOrderHeader.PersonId)RN into '+@tempTableName+' FROM curate_enterprise.ODHOrderHeader ODHOrderHeader 
		INNER JOIN curate_enterprise.Person Person ON ODHOrderHeader.PersonId=Person.PersonId 
		where Person.RecordSourceCode = ''BUKOPMS'' and Person.DLSCDActiveFlag =''Y'' and Person.CustomerTypeName=''ODH Patient''
		AND ODHOrderHeader.RecordSourceCode = ''BUKOPMS'' and ODHOrderHeader.DLSCDActiveFlag =''Y'' ';
		
		EXEC(@execsql)
		PRINT 'Info : Temp table1 got loaded'
				
			
		IF OBJECT_ID('tempdb..#DL_Customer_Summary_OPS_temp') IS NOT NULL
		BEGIN
			EXEC ('DROP table tempdb..#DL_Customer_Summary_OPS_temp')
		END
		EXEC('SELECT TOP 0 *,OPS_CUSTOMER_NUMBER AS PRESCRIPTION_DATE,/*OPS_CUSTOMER_NUMBER AS EyeCheckUpDateTime,OPS_CUSTOMER_NUMBER AS LastUpdate,*/ OPS_CUSTOMER_NUMBER AS PrevLensCheckDate,OPS_CUSTOMER_NUMBER AS SpecificationLastUpdate,OPS_CUSTOMER_NUMBER AS PrescriptionCode,OPS_CUSTOMER_NUMBER as AppointmentDate,OPS_CUSTOMER_NUMBER AS BookingTime into tempdb..#DL_Customer_Summary_OPS_temp FROM [con_odh].[DL_Customer_Summary_OPS]')
		

		
	BEGIN TRY
	
	
 
		BEGIN TRANSACTION;	
		
		SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
		SET @feed_name='DL_Customer_Summary_OPS_'+@curr_timestamp

		SET @count = (SELECT Count(*)  FROM  psa.egress_sp_logs_odh WHERE  project_name = 'ODH' AND feed_name like 'DL_Customer_Summary_OPS_%' and active_flag='Y')
				
		IF @count !=0
		BEGIN
			SELECT top 1 @egress_status=egress_status,@batch=batch  FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Summary_OPS_%' and active_flag='Y' order by  dt_created desc
			select @rerun=ReRun_Flag,@frequency=frequency from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Summary_OPS_%' and active_flag='Y' and ReRun_Flag='1'
		END
				
			IF (@count != 0 and @egress_status != '0')
			BEGIN 
				SELECT top 1 @frequency=frequency,@cnt=rowid_extracted  FROM  psa.egress_sp_logs_odh  where  project_name = 'ODH' AND feed_name like 'DL_Customer_Summary_OPS_%' and active_flag='Y' order by  dt_created desc
			END
			
			
			IF @count != 0 and @egress_status = '0' and @rerun!=1
			BEGIN 
				SET @frequency = 'Incremental'
			END
			
			print @frequency
			
			IF @frequency = 'History'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='History_limit')
			END
			
			IF @frequency = 'Incremental'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='Incr_limit')
			END
			
			print @egress_status
				
			IF @egress_status = '0'
			BEGIN 
				IF @rerun='1'
				BEGIN
					SELECT @endRunTime=dt_created,@batch=batch from psa.egress_sp_logs_odh where  project_name = 'ODH' AND feed_name like 'DL_Customer_Summary_OPS_%' and ReRun_Flag='1' and active_flag='Y'
				END
				ELSE
				BEGIN
					SET @endRunTime='9999-12-31 00:00:00.000';
					SET @batch=@batch+1
				END
				print @endRunTime
				
				SELECT TOP 1 @flag=isnull(min(egress_status),0),@prev_batch=isnull(min(batch),0) From
				(select ROW_NUMBER() OVER(ORDER BY dt_created desc) AS rn,* from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Summary_OPS_%'  and active_flag='Y' and dt_created<@endRunTime) a where rn=2
				print @flag
				
				if @flag != '0'
				begin
				set @RunTime=(SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Summary_OPS_%' and active_flag='Y' and dt_created<@endRunTime and batch =@prev_batch order by  dt_created asc);
				end
				if @flag = '0'
				begin
				set @RunTime=(SELECT ISNULL(min(a.dt_created), cast('1900-01-01' as datetime)) as dt_created from (SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where 
				project_name = 'ODH' AND feed_name like 'DL_Customer_Summary_OPS_%' and active_flag='Y' and dt_created<@endRunTime order by  dt_created desc)a);
				end
				
				print @RunTime
							
				/*SET @ODHOrderHeaderETLRunId 					 = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHOrderHeader where RunDateTime > cast(@RunTime as datetime) )	*/
				/*SET @PersonETLRunId                              = (SELECT MIN(DLETLRunLogId) from curate_enterprise.Person where RunDateTime > cast(@RunTime as datetime) )	*/
				/*SET @AppointmentETLRunId                         = (SELECT MIN(DLETLRunLogId) from curate_enterprise.Appointment where RunDateTime > cast(@RunTime as datetime) )	*/
				/*SET @ODHPatientContactLensSpecificationETLRunId  = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHPatientContactLensSpecification where RunDateTime > cast(@RunTime as datetime) )	*/
				/*SET @ODHPatientServiceGroupETLRunId              = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHPatientServiceGroup where RunDateTime > cast(@RunTime as datetime) )	*/
				/*SET @ODHServiceGroupEyeCheckupETLRunId           = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHServiceGroupEyeCheckup where RunDateTime > cast(@RunTime as datetime) )	*/
				/*SET @ODHServiceGroupAdviceGivenETLRunId          = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHServiceGroupAdviceGiven where RunDateTime > cast(@RunTime as datetime) )	*/
				/*SET @ODHPatientPrescriptionETLRunId              = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHPatientPrescription where RunDateTime > cast(@RunTime as datetime) )	*/
				/*SET @ODHAdditionalPrescriptionETLRunId           = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHAdditionalPrescription where RunDateTime > cast(@RunTime as datetime) )	*/
		
		INSERT INTO tempdb..#DL_Customer_Summary_OPS_temp --[con_odh].[temp_DL_Customer_Summary_OPS]
		(
			OPS_CUSTOMER_NUMBER				,
			AGE                             ,
			EYE_TEST_DUE_DATE               ,
			PRESC_CORRECTION_NEEDED_FLAG    ,
			LAST_SPECTACLE_DISPENSE_DATE    ,
			CL_DUE_DATE                     ,
			CL_DISPENSE_COUNT               ,
			EYE_TEST_FWD_APPT_FLAG          ,
			CL_FWD_APPT_FLAG				,
			PRESCRIPTION_DATE				,
			--EyeCheckUpDateTime,
			--LastUpdate,
			PrevLensCheckDate,
			SpecificationLastUpdate,
			PrescriptionCode,
			AppointmentDate,
			BookingTime
		)
		SELECT DISTINCT
		isnull(cast(Person.CustomerNumber  as nvarchar(max)),'') AS OPS_CUSTOMER_NUMBER,
		isnull(cast(CONVERT(date,Person.DateOfBirth,23) as nvarchar(max)),'') AS AGE,
		isnull(cast(CONVERT(date,DATEADD(month,convert(int,SUBSTRING(ODHAdditionalPrescription.Recall,1,len(ODHAdditionalPrescription.Recall)-1)),ODHAdditionalPrescription.PrescriptionDate),23) as nvarchar(max)),'') AS EYE_TEST_DUE_DATE,
		isnull(cast(case when ODHServiceGroupAdviceGiven.correction='1' then 'Y' ELSE (case when ODHServiceGroupAdviceGiven.nocorrection='1' then 'N' else '' end) END as nvarchar(max)),'') AS PRESC_CORRECTION_NEEDED_FLAG,
		isnull(cast((select ODHOrderHeader.DatePlaced where ODHOrderHeader.OrderHeaderType='GLASSES') as nvarchar(max)),'') AS LAST_SPECTACLE_DISPENSE_DATE,
		isnull(cast(CONVERT(date,DATEADD(month, convert(int,ODHPatientContactLensSpecification.RecallPeriod), ODHPatientContactLensSpecification.PrevLensCheckDate),23) as nvarchar(max)),'') AS CL_DUE_DATE,
		isnull(cast(case when t.orderHeaderCodeCount >=1 THEN t.orderHeaderCodeCount ELSE NULL END as nvarchar(max)),'')  AS CL_DISPENSE_COUNT,
		isnull(cast(CASE WHEN Appointment_Eye.AppointmentType LIKE 'Eye Check%' and Appointment_Eye.AppointmentDate >= getdate() THEN 'Y' ELSE 'N' END as nvarchar(max)),'') AS EYE_TEST_FWD_APPT_FLAG,
		isnull(cast(CASE WHEN Appointment_CL.AppointmentType LIKE '%C/L%' and Appointment_CL.AppointmentDate >= getdate() THEN 'Y' ELSE 'N' END  as nvarchar(max)),'') AS CL_FWD_APPT_FLAG,
		isnull(convert(nvarchar,ODHPatientPrescription.PrescriptionDateTime , 21),'') AS PRESCRIPTION_DATE,
		--isnull(convert(nvarchar,join1.EyeCheckUpDateTime , 21),'') AS EyeCheckUpDateTime,
		--isnull(convert(nvarchar,join1.LastUpdate , 21),'') AS LastUpdate,
		isnull(convert(nvarchar,ODHPatientContactLensSpecification.PrevLensCheckDate , 21),'') AS PrevLensCheckDate,
		isnull(convert(nvarchar,ODHPatientContactLensSpecification.LastUpdate , 21),'') AS SpecificationLastUpdate,
		isnull(cast(ODHPatientPrescription.PrescriptionCode as nvarchar(max)),'') AS PrescriptionCode,
		isnull(cast(CONVERT(date,Appointment.AppointmentDate,23) as nvarchar(max)),'') AS AppointmentDate,
		isnull(convert(nvarchar,ODHPatientBooking.BookingTime , 21),'') AS BookingTime
		
		FROM (select CustomerNumber,DateOfBirth,PersonId from curate_enterprise.Person where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and CustomerTypeName='ODH Patient' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) Person 
		LEFT OUTER JOIN (select DatePlaced,OrderHeaderType,PersonId from curate_enterprise.ODHOrderHeader where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHOrderHeader ON ODHOrderHeader.PersonId=Person.PersonId
		LEFT OUTER JOIN (SELECT count(*) as orderHEaderCodeCount,PersonId FROM  tempdb..#DL_Customer_Summary_OPS_test_temp where Status in ('COLLECTED','ORDERED') and OrderHeaderType = 'CONTACT_LENS' group by personid) t on t.PersonId=Person.PersonId
		LEFT OUTER JOIN (select * from curate_enterprise.Appointment where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime and (AppointmentType like '%Eye Check%' or AppointmentType like '%C/L%') ) Appointment ON Appointment.PersonId=Person.PersonId
		LEFT OUTER JOIN (select * from curate_enterprise.Appointment where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime and AppointmentType like '%Eye Check%') Appointment_Eye ON Appointment_Eye.PersonId=Person.PersonId
		LEFT OUTER JOIN (select * from curate_enterprise.Appointment where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime and AppointmentType like '%C/L%') Appointment_CL ON Appointment_CL.PersonId=Person.PersonId
		LEFT OUTER JOIN (select RecallPeriod,PrevLensCheckDate,PersonId,LastUpdate from curate_enterprise.ODHPatientContactLensSpecification where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and status in ('final','final_clof') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHPatientContactLensSpecification ON ODHPatientContactLensSpecification.PersonId=Person.PersonId
		LEFT OUTER JOIN (select PatientPrescriptionId,PersonId,PrescriptionCode,PrescriptionDateTime from curate_enterprise.ODHPatientPrescription where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHPatientPrescription ON Person.PersonId=ODHPatientPrescription.PersonId
		LEFT OUTER JOIN (select Recall,PrescriptionDate,PatientPrescriptionId,PRESCRIPTIONCODE from curate_enterprise.ODHAdditionalPrescription where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHAdditionalPrescription ON ODHPatientPrescription.PatientPrescriptionId=ODHAdditionalPrescription.PatientPrescriptionId
		LEFT OUTER JOIN (select ServiceItemCode,NoCorrection,correction from curate_enterprise.ODHServiceGroupAdviceGiven where RecordSourceCode = 'BUKOPMS' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHServiceGroupAdviceGiven ON ODHPatientPrescription.PrescriptionCode=ODHServiceGroupAdviceGiven.ServiceItemCode
		left outer join (select * from curate_enterprise.ODHPatientAppointment where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHPatientAppointment on Person.PersonId=ODHPatientAppointment.PersonId
		left outer join (select * from curate_enterprise.ODHPatientBooking where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and Bookingstatus='Completed' and ServiceType like '%Eye Check%' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHPatientBooking on ODHPatientAppointment.PatientAppointmentId=ODHPatientBooking.PatientAppointmentId

		
		;

		PRINT 'Info : Completed insertion of #tmp'
			
			insert into con_odh.temp_DL_Customer_Summary_OPS select OPS_CUSTOMER_NUMBER,AGE,EYE_TEST_DUE_DATE,PRESC_CORRECTION_NEEDED_FLAG,LAST_SPECTACLE_DISPENSE_DATE,CL_DUE_DATE,CL_DISPENSE_COUNT,EYE_TEST_FWD_APPT_FLAG,CL_FWD_APPT_FLAG,row_number() over (order by a.OPS_CUSTOMER_NUMBER ASC) as row_id from (select dense_rank() over (partition by OPS_CUSTOMER_NUMBER order by PRESCRIPTION_DATE desc,PrescriptionCode desc,/*EyeCheckUpDateTime desc,LastUpdate desc,*/PrevLensCheckDate desc,SpecificationLastUpdate desc,LAST_SPECTACLE_DISPENSE_DATE desc,AppointmentDate desc,BookingTime desc) as RN,OPS_CUSTOMER_NUMBER,AGE,EYE_TEST_DUE_DATE,PRESC_CORRECTION_NEEDED_FLAG,LAST_SPECTACLE_DISPENSE_DATE,CL_DUE_DATE,CL_DISPENSE_COUNT,EYE_TEST_FWD_APPT_FLAG,CL_FWD_APPT_FLAG,PRESCRIPTION_DATE,PrescriptionCode ,/*EyeCheckUpDateTime ,LastUpdate ,*/PrevLensCheckDate ,SpecificationLastUpdate,AppointmentDate   FROM tempdb..#DL_Customer_Summary_OPS_temp)a where a.RN=1 ;
		
		PRINT 'Info : Completed insertion of temp_DL_Customer_Summary_OPS'
		
	END
	
			SET @total_records = (SELECT count(*) FROM  con_odh.temp_DL_Customer_Summary_OPS)
			print @total_records
			
			insert into con_odh.DL_Customer_Summary_OPS select distinct OPS_CUSTOMER_NUMBER,AGE,EYE_TEST_DUE_DATE,PRESC_CORRECTION_NEEDED_FLAG,LAST_SPECTACLE_DISPENSE_DATE,CL_DUE_DATE,CL_DISPENSE_COUNT,EYE_TEST_FWD_APPT_FLAG,CL_FWD_APPT_FLAG from (select top (@limit) * from con_odh.temp_DL_Customer_Summary_OPS where row_id>@cnt order by row_id)a
			
			SET @rowsextracted=@total_records-@cnt
			SET @cnt= (select max(a.row_id) from (select top (@limit) * from con_odh.temp_DL_Customer_Summary_OPS where row_id>@cnt order by row_id)a)
			
			IF @cnt != @total_records
			BEGIN 
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag=0 where rerun_flag=1 and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',1,0)
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',0,0)
				END
			END
			
			IF @cnt = @total_records
			BEGIN 
				--Truncate table [con_odh].[temp_DL_Customer_Summary_OPS]
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag='0' where rerun_flag='1' and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',1,0)
					update psa.egress_sp_logs_odh set active_flag='N' where rerun_flag='1'
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',0,0)
				END
			END
	
		SELECT @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

	END TRY
	BEGIN CATCH
        IF @@TRANCOUNT>0
            ROLLBACK TRANSACTION;
            DECLARE @vErrorMessage AS NVARCHAR(500) = 
            (SELECT CONCAT( '{"Error number":'    ,'"', ERROR_NUMBER()    ,'"',', '
                                          ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
                                            ,'"Severity":' ,         '"', ERROR_SEVERITY()  ,'"',', '
                                        ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
                                            ,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'))
			SET @vProcedureMessage = @vErrorMessage
			SELECT  '-1' AS ProcedureStatus, @vProcedureMessage As ProcedureMessage;
			
			INSERT INTO [psa].[DNA_DB_Errors_Log] 
            SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_DL_Customer_Summary_OPS]',ERROR_MESSAGE(),GETDATE();
        THROW;                    
                                
        END CATCH 
        IF @@TRANCOUNT>0
            COMMIT TRANSACTION;
 
	IF @cnt = @total_records
		BEGIN 
			Truncate table [con_odh].[temp_DL_Customer_Summary_OPS]
		END
		

END
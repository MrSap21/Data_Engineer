﻿CREATE PROC [con_odh].[sp_DL_Customer_Appointment_OPS] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_DL_Customer_Appointment_OPS
Purpose						: Load Extract table for Appointment
Target Tables             	: con_odh.DL_Customer_Appointment_OPS

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed AS argument

*************************************************************************************************************
03-11-2022   :  Ashlin T	     Inital Version 1.0
 */
	

BEGIN	


      /* Declare and Initialize Generic variables*/
	    DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
        DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';
		DECLARE @vNumRows                           AS INT           = 0;
		/*DECLARE @ODHPatientServiceGroupETLRunId				  INT;  */
		/*DECLARE @PersonETLRunId                                 INT;  */
		/*DECLARE @OdhPatientPrescriptionETLRunId                 INT;  */
		/*DECLARE @ODHPatientETLRunId                             INT;  */
		/*DECLARE @SiteRoleETLRunId                               INT;  */
		/*DECLARE @ODHBusinessPartnerETLRunId                     INT;  */
		/*DECLARE @ODHOrderETLRunId                               INT;  */
		/*DECLARE @ODHFinPaymentMethodETLRunId                    INT;  */
		/*DECLARE @ODHServiceGroupAdviceGivenETLRunId             INT;  */
		/*DECLARE @ODHServiceGroupEyeCheckupETLRunId              INT;  */
		/*DECLARE @ODHPatientContactLensSpecificationETLRunId     INT;  */
		/*DECLARE @ODHPatientBookingETLRunId					  INT;  */
		/*DECLARE @ODHPatientAppointmentETLRunId				  INT;  */
		/*DECLARE @OrderLineETLRunId                              INT;  */
		/*DECLARE @ODHOrderLineETLRunId                           INT;  */
		/*DECLARE @ODHOrderlineMeasureETLRunId                    INT;  */
		DECLARE @cnt AS INT=0;
		DECLARE @count INT;
		DECLARE @total_records INT;
		DECLARE @egress_status AS Int=0;
		DECLARE @frequency AS nvarchar(255)='History';
		DECLARE @curr_timestamp NVARCHAR(max);
		DECLARE @limit int;
		DECLARE @RunTime DATETIME;
		DECLARE @rerun AS INT=0; 
		DECLARE @endRunTime as DATETIME='9999-12-31 00:00:00.000';
		DECLARE @flag INT;
		DECLARE @feed_name nvarchar(100);
		DECLARE @rowsextracted as int;
		DECLARE @batch as int=0;
		DECLARE @prev_batch as int=0;
		DECLARE @exec_sql NVARCHAR(MAX);
		DECLARE @orderHEaderCodeCount nvarchar(max);
        DECLARE @tempTableName nvarchar(max);
		
  
	
	
	BEGIN TRY
	
		IF OBJECT_ID('tempdb..#DL_Customer_Appointment_OPS_temp') IS NOT NULL
		BEGIN
			EXEC ('DROP table tempdb..#DL_Customer_Appointment_OPS_temp')
		END
		SET @exec_sql = 'SELECT TOP 0 * INTO tempdb..#DL_Customer_Appointment_OPS_temp FROM [con_odh].[DL_Customer_Appointment_OPS]'
		EXEC(@exec_sql)
		
		IF OBJECT_ID('tempdb..#DL_Customer_Appointment_OPS_temp_case3') IS NOT NULL
		BEGIN
			EXEC ('DROP table tempdb..#DL_Customer_Appointment_OPS_temp_case3')
		END
		SET @exec_sql = 'SELECT TOP 0 *,CATEGORY as PrevLensCheckDate,CATEGORY AS LastUpdate INTO tempdb..#DL_Customer_Appointment_OPS_temp_case3 FROM [con_odh].[DL_Customer_Appointment_OPS]'
		EXEC(@exec_sql)
		
		IF OBJECT_ID('tempdb..#DL_Customer_Appointment_OPS_temp_case2') IS NOT NULL
		BEGIN
			EXEC ('DROP table tempdb..#DL_Customer_Appointment_OPS_temp_case2')
		END
		SET @exec_sql = 'SELECT TOP 0 *,CATEGORY as PRESCRIPTION_DATETIME INTO tempdb..#DL_Customer_Appointment_OPS_temp_case2 FROM [con_odh].[DL_Customer_Appointment_OPS]'
		EXEC(@exec_sql)
		
		IF OBJECT_ID('tempdb..#DL_Customer_Appointment_OPS_temp_case1') IS NOT NULL
		BEGIN
			EXEC ('DROP table tempdb..#DL_Customer_Appointment_OPS_temp_case1')
		END
		SET @exec_sql = 'SELECT TOP 0 *,CATEGORY as BookingTime INTO tempdb..#DL_Customer_Appointment_OPS_temp_case1 FROM [con_odh].[DL_Customer_Appointment_OPS]'
		EXEC(@exec_sql)
		
		BEGIN TRANSACTION;	
		SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
		SET @feed_name='DL_Customer_Appointment_OPS_'+@curr_timestamp

		SET @count = (SELECT Count(*)  FROM  psa.egress_sp_logs_odh WHERE  project_name = 'ODH' AND feed_name like 'DL_Customer_Appointment_OPS_%' and active_flag='Y')
				
		IF @count !=0
		BEGIN
			SELECT top 1 @egress_status=egress_status,@batch=batch  FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Appointment_OPS_%' and active_flag='Y' order by  dt_created desc
			select @rerun=ReRun_Flag,@frequency=frequency from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Appointment_OPS_%' and active_flag='Y' and ReRun_Flag='1'
		END
				
			IF (@count != 0 and @egress_status != '0')
			BEGIN 
				SELECT top 1 @frequency=frequency,@cnt=rowid_extracted  FROM  psa.egress_sp_logs_odh  where  project_name = 'ODH' AND feed_name like 'DL_Customer_Appointment_OPS_%' and active_flag='Y' order by  dt_created desc
			END
			
			
			IF @count != 0 and @egress_status = '0' and @rerun!=1
			BEGIN 
				SET @frequency = 'Incremental'
			END
			
			print @frequency
			
			IF @frequency = 'History'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='History_limit')
			END
			
			IF @frequency = 'Incremental'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='Incr_limit')
			END
			
			print @egress_status
				
			IF @egress_status = '0'
			BEGIN 
				IF @rerun='1'
				BEGIN
					SELECT @endRunTime=dt_created,@batch=batch from psa.egress_sp_logs_odh where  project_name = 'ODH' AND feed_name like 'DL_Customer_Appointment_OPS_%' and ReRun_Flag='1' and active_flag='Y'
				END
				ELSE
				BEGIN
					SET @endRunTime='9999-12-31 00:00:00.000';
					SET @batch=@batch+1
				END
				print @endRunTime
				
				SELECT TOP 1 @flag=isnull(min(egress_status),0),@prev_batch=isnull(min(batch),0) From
				(select ROW_NUMBER() OVER(ORDER BY dt_created desc) AS rn,* from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Appointment_OPS_%'  and active_flag='Y' and dt_created<@endRunTime) a where rn=2
				print @flag
				
				if @flag != '0'
				begin
				set @RunTime=(SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Customer_Appointment_OPS_%' and active_flag='Y' and dt_created<@endRunTime and batch =@prev_batch order by  dt_created asc);
				end
				if @flag = '0'
				begin
				set @RunTime=(SELECT ISNULL(min(a.dt_created), cast('1900-01-01' as datetime)) as dt_created from (SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where 
				project_name = 'ODH' AND feed_name like 'DL_Customer_Appointment_OPS_%' and active_flag='Y' and dt_created<@endRunTime order by  dt_created desc)a);
				end
				
				print @RunTime
							
				
				/*SET @ODHPatientServiceGroupETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHPatientServiceGroup where RunDateTime > cast(@RunTime as datetime) )  */
				/*SET @PersonETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.Person where RunDateTime > cast(@RunTime as datetime) ) */
				/*SET @OdhPatientPrescriptionETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.OdhPatientPrescription where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHPatientETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHPatient where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @SiteRoleETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.SiteRole where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHBusinessPartnerETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHBusinessPartner where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHOrderETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHOrder_tmp_0603 where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHFinPaymentMethodETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHFinPaymentMethod where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHServiceGroupAdviceGivenETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHServiceGroupAdviceGiven where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHServiceGroupEyeCheckupETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHServiceGroupEyeCheckup where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHPatientContactLensSpecificationETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHPatientContactLensSpecification where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @OrderLineETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.OrderLine where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHOrderLineETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHOrderLine where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHPatientBookingETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHPatientBooking where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHPatientAppointmentETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHPatientAppointment where RunDateTime > cast(@RunTime as datetime) )*/
		
		INSERT INTO tempdb..#DL_Customer_Appointment_OPS_temp_case3
		(
			CATEGORY						,
			APPT_DATE                       ,
			OPS_CUSTOMER_NUMBER             ,
			STATUS                          ,
			RIGHT_SPHERE                    ,
			RIGHT_CYLINDER                  ,
			RIGHT_AXIS                      ,
			RIGHT_PRISM_1                   ,
			RIGHT_PRISM_1_BASE              ,
			RIGHT_PRISM_2                   ,
			RIGHT_PRISM_2_BASE              ,
			RIGHT_ADDTNL_POWER              ,
			RIGHT_ADDTNL_PRISM_1            ,
			RIGHT_ADDTNL_PRISM_1_BASE       ,
			RIGHT_ADDTNL_PRISM_2            ,
			RIGHT_ADDTNL_PRISM_2_BASE       ,
			RIGHT_INTERMEDIATE_ADDTN        ,
			RIGHT_BVD                       ,
			LEFT_SPHERE                     ,
			LEFT_CYLINDER                   ,
			LEFT_AXIS                       ,
			LEFT_PRISM_1                    ,
			LEFT_PRISM_1_BASE               ,
			LEFT_PRISM_2                    ,
			LEFT_PRISM_2_BASE               ,
			LEFT_ADDTNL_POWER               ,
			LEFT_ADDTNL_PRISM_1             ,
			LEFT_ADDTNL_PRISM_BASE          ,
			LEFT_ADDTNL_PRISM_2             ,
			LEFT_ADDTNL_PRISM_2_BASE        ,
			LEFT_INTERMEDIATE_ADDTN         ,
			LEFT_BVD                        ,
			BRANCH_NUMBER                   ,
			NHS_OR_PRIVATE                  ,
			CL_SUITABLE_FLAG                ,
			CL_CHECK_CYCLE                  ,
			RETAIL_PRICE                    ,
			PAID_PRICE						,
			--PRESCRIPTION_CODE				,
			PrevLensCheckDate				,
			LastUpdate
            
		)
		SELECT DISTINCT 
			isnull(cast(ODHPatientPrescription.ExternalType as nvarchar(max)),'')    AS CATEGORY,
            isnull(cast(CONVERT(date,ODHPatientPrescription.PrescriptionDateTime,23) as nvarchar(max)),'') AS APPT_DATE,
            isnull(cast(Person.CustomerNumber as nvarchar(max)),'') AS OPS_CUSTOMER_NUMBER,
            isnull(cast('Completed' as nvarchar(max)),'') AS STATUS,
            isnull(cast(OdhPatientPrescription.RightSPH as nvarchar(max)),'') AS RIGHT_SPHERE,
            isnull(cast(OdhPatientPrescription.RightCYL as nvarchar(max)),'') AS RIGHT_CYLINDER,
            isnull(cast(OdhPatientPrescription.RightAxis as nvarchar(max)),'') AS RIGHT_AXIS,
            isnull(cast(OdhPatientPrescription.RightNprismh as nvarchar(max)),'') AS RIGHT_PRISM_1,
            isnull(cast(OdhPatientPrescription.RightNprismhType as nvarchar(max)),'') AS RIGHT_PRISM_1_BASE,
            isnull(cast(OdhPatientPrescription.RightNprismv as nvarchar(max)) ,'')AS RIGHT_PRISM_2,
            isnull(cast(OdhPatientPrescription.RightNprismvType as nvarchar(max)),'') AS RIGHT_PRISM_2_BASE,
            isnull(cast(OdhPatientPrescription.RightNearAdd as nvarchar(max)),'') AS RIGHT_ADDTNL_POWER,
            isnull(cast(OdhPatientPrescription.RightDprismh as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_1,
            isnull(cast(OdhPatientPrescription.RightDprismhType as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_1_BASE,
            isnull(cast(OdhPatientPrescription.RightDprismv as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_2,
            isnull(cast(OdhPatientPrescription.RightDprismvType as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_2_BASE,
            isnull(cast(OdhPatientPrescription.RightInterAdd as nvarchar(max)),'') AS RIGHT_INTERMEDIATE_ADDTN,
            isnull(cast(OdhPatientPrescription.BVD as nvarchar(max)),'') AS RIGHT_BVD,
            isnull(cast(OdhPatientPrescription.LeftSPH as nvarchar(max)),'') AS LEFT_SPHERE,
            isnull(cast(OdhPatientPrescription.LeftCYL as nvarchar(max)),'') AS LEFT_CYLINDER,
            isnull(cast(OdhPatientPrescription.LeftAxis as nvarchar(max)),'') AS LEFT_AXIS,  
            isnull(cast(OdhPatientPrescription.LeftNprismh as nvarchar(max)),'') AS LEFT_PRISM_1,
            isnull(cast(OdhPatientPrescription.LeftNprismhType as nvarchar(max)),'') AS LEFT_PRISM_1_BASE,
            isnull(cast(OdhPatientPrescription.LeftNprismv as nvarchar(max)),'') AS LEFT_PRISM_2,
            isnull(cast(OdhPatientPrescription.LeftNprismvType as nvarchar(max)),'') AS LEFT_PRISM_2_BASE,
            isnull(cast(OdhPatientPrescription.LeftNearAdd as nvarchar(max)),'') AS LEFT_ADDTNL_POWER,
            isnull(cast(OdhPatientPrescription.LeftDprismh as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_1,
            isnull(cast(OdhPatientPrescription.LeftDprismhType as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_BASE,
            isnull(cast(OdhPatientPrescription.LeftDprismv as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_2,
            isnull(cast(OdhPatientPrescription.LeftDprismvType as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_2_BASE,
            isnull(cast(OdhPatientPrescription.LeftInterAdd as nvarchar(max)),'') AS LEFT_INTERMEDIATE_ADDTN,
            isnull(cast(OdhPatientPrescription.BVD as nvarchar(max)),'') AS LEFT_BVD,
            isnull(cast(SiteRole.SourceSiteRoleCode as nvarchar(max)),'') AS BRANCH_NUMBER,
            isnull(cast(NULL as nvarchar(max)),'') AS NHS_OR_PRIVATE,
            isnull(cast(ODHServiceGroupAdviceGiven.SuitableContactLenses as nvarchar(max)),'') AS CL_SUITABLE_FLAG,
            isnull(cast(ODHPatientContactLensSpecification.RecallPeriod as nvarchar(max)),'')  AS CL_CHECK_CYCLE,
            isnull(NULL,'') AS RETAIL_PRICE,
            isnull(NULL,'') AS PAID_PRICE,
            --isnull(cast(OdhPatientPrescription.PRESCRIPTIONCODE as nvarchar(max)),'') AS PRESCRIPTION_CODE,
			isnull(convert(nvarchar,ODHPatientContactLensSpecification.PrevLensCheckDate , 21),'')  AS PrevLensCheckDate,
			isnull(convert(nvarchar,ODHPatientContactLensSpecification.LastUpdate , 21),'') AS LastUpdate
	
		
		FROM  (select * FROM curate_enterprise.OdhPatientPrescription where dlscdactiveflag='Y' and Recordsourcecode='BUKOPMS' and ExternalType = 'CLSpecification' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)OdhPatientPrescription
		INNER JOIN (select * from curate_enterprise.SiteRole where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RoleId=(select RoleId from curate_enterprise.REFRole where RoleName='Practice' and RecordSourceCode='DNARDM') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)SiteRole ON OdhPatientPrescription.PracticeSiteRoleId=SiteRole.SiteRoleId
		INNER JOIN (select * from curate_enterprise.Person  where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and CustomerTypeName='ODH Patient' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )Person ON Person.PersonID=OdhPatientPrescription.PersonID
		LEFT OUTER JOIN (select * from curate_enterprise.ODHServiceGroupAdviceGiven where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and ServiceItemType='Prescription' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHServiceGroupAdviceGiven ON OdhPatientPrescription.PrescriptionCode=ODHServiceGroupAdviceGiven.ServiceItemCode
		LEFT OUTER JOIN (select * from curate_enterprise.ODHPatientContactLensSpecification where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and Status in ('Final','Final_CLOF') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHPatientContactLensSpecification ON ODHPatientPrescription.ExternalCode =ODHPatientContactLensSpecification.SRCCLSpecificationId
		;
		PRINT 'Info : Completed insertion of #tmp_case3'
		
		INSERT INTO tempdb..#DL_Customer_Appointment_OPS_temp_case2
		(
			CATEGORY						,
			APPT_DATE                       ,
			OPS_CUSTOMER_NUMBER             ,
			STATUS                          ,
			RIGHT_SPHERE                    ,
			RIGHT_CYLINDER                  ,
			RIGHT_AXIS                      ,
			RIGHT_PRISM_1                   ,
			RIGHT_PRISM_1_BASE              ,
			RIGHT_PRISM_2                   ,
			RIGHT_PRISM_2_BASE              ,
			RIGHT_ADDTNL_POWER              ,
			RIGHT_ADDTNL_PRISM_1            ,
			RIGHT_ADDTNL_PRISM_1_BASE       ,
			RIGHT_ADDTNL_PRISM_2            ,
			RIGHT_ADDTNL_PRISM_2_BASE       ,
			RIGHT_INTERMEDIATE_ADDTN        ,
			RIGHT_BVD                       ,
			LEFT_SPHERE                     ,
			LEFT_CYLINDER                   ,
			LEFT_AXIS                       ,
			LEFT_PRISM_1                    ,
			LEFT_PRISM_1_BASE               ,
			LEFT_PRISM_2                    ,
			LEFT_PRISM_2_BASE               ,
			LEFT_ADDTNL_POWER               ,
			LEFT_ADDTNL_PRISM_1             ,
			LEFT_ADDTNL_PRISM_BASE          ,
			LEFT_ADDTNL_PRISM_2             ,
			LEFT_ADDTNL_PRISM_2_BASE        ,
			LEFT_INTERMEDIATE_ADDTN         ,
			LEFT_BVD                        ,
			BRANCH_NUMBER                   ,
			NHS_OR_PRIVATE                  ,
			CL_SUITABLE_FLAG                ,
			CL_CHECK_CYCLE                  ,
			RETAIL_PRICE                    ,
			PAID_PRICE						,
			PRESCRIPTION_DATETIME
			
		)
		SELECT DISTINCT 
			isnull(cast(case when ODHPatientPrescription.ExternalType is not null then ODHPatientPrescription.ExternalType else 'EyeCheck' end as nvarchar(max)),'')    AS CATEGORY,
            isnull(cast(CONVERT(date,ODHPatientPrescription.PrescriptionDateTime,23) as nvarchar(max)),'') AS APPT_DATE,
            isnull(cast(Person.CustomerNumber as nvarchar(max)),'') AS OPS_CUSTOMER_NUMBER,
            isnull(cast('Completed' as nvarchar(max)),'') AS STATUS,
            isnull(cast(OdhPatientPrescription.RightSPH as nvarchar(max)),'') AS RIGHT_SPHERE,
            isnull(cast(OdhPatientPrescription.RightCYL as nvarchar(max)),'') AS RIGHT_CYLINDER,
            isnull(cast(OdhPatientPrescription.RightAxis as nvarchar(max)),'') AS RIGHT_AXIS,
            isnull(cast(OdhPatientPrescription.RightNprismh as nvarchar(max)),'') AS RIGHT_PRISM_1,
            isnull(cast(OdhPatientPrescription.RightNprismhType as nvarchar(max)),'') AS RIGHT_PRISM_1_BASE,
            isnull(cast(OdhPatientPrescription.RightNprismv as nvarchar(max)) ,'')AS RIGHT_PRISM_2,
            isnull(cast(OdhPatientPrescription.RightNprismvType as nvarchar(max)),'') AS RIGHT_PRISM_2_BASE,
            isnull(cast(OdhPatientPrescription.RightNearAdd as nvarchar(max)),'') AS RIGHT_ADDTNL_POWER,
            isnull(cast(OdhPatientPrescription.RightDprismh as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_1,
            isnull(cast(OdhPatientPrescription.RightDprismhType as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_1_BASE,
            isnull(cast(OdhPatientPrescription.RightDprismv as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_2,
            isnull(cast(OdhPatientPrescription.RightDprismvType as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_2_BASE,
            isnull(cast(OdhPatientPrescription.RightInterAdd as nvarchar(max)),'') AS RIGHT_INTERMEDIATE_ADDTN,
            isnull(cast(OdhPatientPrescription.BVD as nvarchar(max)),'') AS RIGHT_BVD,
            isnull(cast(OdhPatientPrescription.LeftSPH as nvarchar(max)),'') AS LEFT_SPHERE,
            isnull(cast(OdhPatientPrescription.LeftCYL as nvarchar(max)),'') AS LEFT_CYLINDER,
            isnull(cast(OdhPatientPrescription.LeftAxis as nvarchar(max)),'') AS LEFT_AXIS,  
            isnull(cast(OdhPatientPrescription.LeftNprismh as nvarchar(max)),'') AS LEFT_PRISM_1,
            isnull(cast(OdhPatientPrescription.LeftNprismhType as nvarchar(max)),'') AS LEFT_PRISM_1_BASE,
            isnull(cast(OdhPatientPrescription.LeftNprismv as nvarchar(max)),'') AS LEFT_PRISM_2,
            isnull(cast(OdhPatientPrescription.LeftNprismvType as nvarchar(max)),'') AS LEFT_PRISM_2_BASE,
            isnull(cast(OdhPatientPrescription.LeftNearAdd as nvarchar(max)),'') AS LEFT_ADDTNL_POWER,
            isnull(cast(OdhPatientPrescription.LeftDprismh as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_1,
            isnull(cast(OdhPatientPrescription.LeftDprismhType as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_BASE,
            isnull(cast(OdhPatientPrescription.LeftDprismv as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_2,
            isnull(cast(OdhPatientPrescription.LeftDprismvType as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_2_BASE,
            isnull(cast(OdhPatientPrescription.LeftInterAdd as nvarchar(max)),'') AS LEFT_INTERMEDIATE_ADDTN,
            isnull(cast(OdhPatientPrescription.BVD as nvarchar(max)),'') AS LEFT_BVD,
            isnull(cast(SiteRole.SourceSiteRoleCode as nvarchar(max)),'') AS BRANCH_NUMBER,
            isnull(cast(CASE WHEN (x.PaymentMethodName like '%GOS1%' or x.PaymentMethodName like '%GOS 1%') THEN  'NHS' ELSE 'Private' END as nvarchar(max)),'') AS NHS_OR_PRIVATE,
            isnull(cast(ODHServiceGroupAdviceGiven.SuitableContactLenses as nvarchar(max)),'') AS CL_SUITABLE_FLAG,
            isnull(cast(NULL as nvarchar(max)),'')  AS CL_CHECK_CYCLE,
            isnull(cast(NULL as nvarchar(max)),'') AS RETAIL_PRICE,
            isnull(cast(NULL as nvarchar(max)),'') AS PAID_PRICE,
			isnull(convert(nvarchar,ODHPatientPrescription.PrescriptionDateTime , 21),'') AS PRESCRIPTION_DATETIME
            	
		
		FROM  (select * FROM curate_enterprise.OdhPatientPrescription where dlscdactiveflag='Y' and Recordsourcecode='BUKOPMS' and (ExternalType is NULL OR ExternalType <> 'CLSpecification') and Status = 'Active' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)OdhPatientPrescription
		INNER JOIN (select * from curate_enterprise.SiteRole where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RoleId=(select RoleId from curate_enterprise.REFRole where RoleName='Practice' and RecordSourceCode='DNARDM') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)SiteRole ON OdhPatientPrescription.PracticeSiteRoleId=SiteRole.SiteRoleId
		INNER JOIN (select * from curate_enterprise.Person  where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)Person ON Person.PersonID=OdhPatientPrescription.PersonID
		LEFT OUTER JOIN (select * from curate_enterprise.ODHServiceGroupAdviceGiven where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and ServiceItemType='Prescription' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHServiceGroupAdviceGiven ON OdhPatientPrescription.PrescriptionCode=ODHServiceGroupAdviceGiven.ServiceItemCode
		LEFT OUTER JOIN 
		(select ODHFinPaymentMethod.PaymentMethodName,ODHBusinessPartner.CBPartnerValue from 
		(select PersonId,CBPartnerValue from curate_enterprise.ODhBusinessPartner where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHBusinessPartner 
		INNER JOIN (select OrderId,PersonId from curate_enterprise.[Order] where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)Order1 ON ODHBusinessPartner.PersonId=Order1.PersonId
		INNER JOIN (select ODHOrderId,PersonId from curate_enterprise.ODHOrder where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHOrder ON Order1.OrderId=ODHOrder.ODHOrderId
		INNER JOIN (select OrderLineID,OrderId from curate_enterprise.OrderLine where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)OrderLine ON OrderLine.OrderId=ODHOrder.ODHOrderId
		INNER JOIN (select ODHOrderLineID from curate_enterprise.ODHOrderLine where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHOrderLine ON OrderLine.OrderLineID=ODHOrderLine.ODHOrderLineID
		INNER JOIN (select ODHOrderLineID,PaymentMethodId from curate_enterprise.ODHCustomOrderLinePayments where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHCustomOrderLinePayments ON ODHCustomOrderLinePayments.ODHOrderLineID=ODHOrderLine.ODHOrderLineID
		INNER JOIN (select PaymentMethodId,PaymentMethodName from curate_enterprise.ODHFinPaymentMethod where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHFinPaymentMethod ON ODHCustomOrderLinePayments.PaymentMethodId=ODHFinPaymentMethod.PaymentMethodId
		)x ON Person.CustomerNumber=x.CBPartnerValue
		;
		PRINT 'Info : Completed insertion of #tmp_case2'
		
		INSERT INTO tempdb..#DL_Customer_Appointment_OPS_temp_case1
		(
			CATEGORY						,
			APPT_DATE                       ,
			OPS_CUSTOMER_NUMBER             ,
			STATUS                          ,
			RIGHT_SPHERE                    ,
			RIGHT_CYLINDER                  ,
			RIGHT_AXIS                      ,
			RIGHT_PRISM_1                   ,
			RIGHT_PRISM_1_BASE              ,
			RIGHT_PRISM_2                   ,
			RIGHT_PRISM_2_BASE              ,
			RIGHT_ADDTNL_POWER              ,
			RIGHT_ADDTNL_PRISM_1            ,
			RIGHT_ADDTNL_PRISM_1_BASE       ,
			RIGHT_ADDTNL_PRISM_2            ,
			RIGHT_ADDTNL_PRISM_2_BASE       ,
			RIGHT_INTERMEDIATE_ADDTN        ,
			RIGHT_BVD                       ,
			LEFT_SPHERE                     ,
			LEFT_CYLINDER                   ,
			LEFT_AXIS                       ,
			LEFT_PRISM_1                    ,
			LEFT_PRISM_1_BASE               ,
			LEFT_PRISM_2                    ,
			LEFT_PRISM_2_BASE               ,
			LEFT_ADDTNL_POWER               ,
			LEFT_ADDTNL_PRISM_1             ,
			LEFT_ADDTNL_PRISM_BASE          ,
			LEFT_ADDTNL_PRISM_2             ,
			LEFT_ADDTNL_PRISM_2_BASE        ,
			LEFT_INTERMEDIATE_ADDTN         ,
			LEFT_BVD                        ,
			BRANCH_NUMBER                   ,
			NHS_OR_PRIVATE                  ,
			CL_SUITABLE_FLAG                ,
			CL_CHECK_CYCLE                  ,
			RETAIL_PRICE                    ,
			PAID_PRICE						,
			BookingTime
			
		)
		SELECT DISTINCT 
			isnull(cast(ODHPatientBooking.ServiceType as nvarchar(max)),'')    AS CATEGORY,
            isnull(cast(CONVERT(date,ODHPatientBooking.BookingTime,23) as nvarchar(max)),'') AS APPT_DATE,
            isnull(cast(Person.CustomerNumber as nvarchar(max)),'') AS OPS_CUSTOMER_NUMBER,
            isnull(cast(ODHPatientBooking.BookingStatus as nvarchar(max)),'') AS STATUS,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_SPHERE,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_CYLINDER,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_AXIS,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_PRISM_1,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_PRISM_1_BASE,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_PRISM_2,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_PRISM_2_BASE,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_ADDTNL_POWER,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_1,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_1_BASE,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_2,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_ADDTNL_PRISM_2_BASE,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_INTERMEDIATE_ADDTN,
            isnull(cast(NULL as nvarchar(max)),'') AS RIGHT_BVD,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_SPHERE,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_CYLINDER,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_AXIS,  
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_PRISM_1,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_PRISM_1_BASE,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_PRISM_2,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_PRISM_2_BASE,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_ADDTNL_POWER,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_1,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_BASE,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_2,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_ADDTNL_PRISM_2_BASE,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_INTERMEDIATE_ADDTN,
            isnull(cast(NULL as nvarchar(max)),'') AS LEFT_BVD,
            isnull(cast(SiteRole.SourceSiteRoleCode as nvarchar(max)),'') AS BRANCH_NUMBER,
            isnull(cast(NULL as nvarchar(max)),'') AS NHS_OR_PRIVATE,
            isnull(cast(NULL as nvarchar(max)),'') AS CL_SUITABLE_FLAG,
            isnull(cast(NULL as nvarchar(max)),'')  AS CL_CHECK_CYCLE,
            isnull(cast(NULL as nvarchar(max)),'')  AS RETAIL_PRICE,
            isnull(cast(NULL as nvarchar(max)),'')  AS PAID_PRICE,
            --isnull(cast(OdhPatientPrescription.PRESCRIPTIONCODE as nvarchar(max)),'') AS PRESCRIPTION_CODE,
			isnull(convert(nvarchar,ODHPatientBooking.BookingTime , 21),'')  AS BookingTime
	
		
		FROM  (select * FROM curate_enterprise.ODHPatientBooking where dlscdactiveflag='Y' and Recordsourcecode='BUKOPMS' and BookingStatus IN ('Booked', 'Confirmed', 'Rescheduled', 'Cancelled', 'Failed To Attend' , 'Arrived') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )ODHPatientBooking
		INNER JOIN (select * from curate_enterprise.SiteRole where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RoleId=(select RoleId from curate_enterprise.REFRole where RoleName='Practice' and RecordSourceCode='DNARDM') and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)SiteRole ON ODHPatientBooking.PracticeSiteRoleId=SiteRole.SiteRoleId
		INNER JOIN (select * from curate_enterprise.ODHPatientAppointment where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime)ODHPatientAppointment ON ODHPatientBooking.PatientAppointmentId=ODHPatientAppointment.PatientAppointmentId
		INNER JOIN (select * from curate_enterprise.Person  where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and CustomerTypeName='ODH Patient' and RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime )Person ON Person.PersonID=ODHPatientAppointment.PersonID
		;
		PRINT 'Info : Completed insertion of #tmp_case1'
		
		insert into tempdb..#DL_Customer_Appointment_OPS_temp select * from (select CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE from (select dense_rank() over (partition by Category,appt_date,ops_Customer_Number,[Status],Right_Sphere,Right_Cylinder,Right_Axis,Left_Sphere,Left_Cylinder,Left_Axis,branch_number order by PrevLensCheckDate desc,LastUpdate desc ) as RN,CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE,/*PRESCRIPTION_CODE,*/PrevLensCheckDate,LastUpdate FROM tempdb..#DL_Customer_Appointment_OPS_temp_case3)a where a.RN=1 union select CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE from (select dense_rank() over (partition by Category,appt_date,ops_Customer_Number,[Status],Right_Sphere,Right_Cylinder,Right_Axis,Left_Sphere,Left_Cylinder,Left_Axis,branch_number order by PRESCRIPTION_DATETIME desc,NHS_OR_PRIVATE asc ) as RN,CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE,PRESCRIPTION_DATETIME FROM tempdb..#DL_Customer_Appointment_OPS_temp_case2)a where a.RN=1 union select CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE from(select dense_rank() over (partition by Category,appt_date,ops_Customer_Number,[Status],Right_Sphere,Right_Cylinder,Right_Axis,Left_Sphere,Left_Cylinder,Left_Axis,branch_number order by BookingTime desc ) as RN,CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE,/*PRESCRIPTION_CODE,*/BookingTime FROM tempdb..#DL_Customer_Appointment_OPS_temp_case1)b where b.RN=1 ) x ;
		
		PRINT 'Info : Completed insertion of #tmp'
		
		insert into con_odh.temp_DL_Customer_Appointment_OPS select CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE,row_number() over (order by OPS_CUSTOMER_NUMBER ASC) as row_id from tempdb..#DL_Customer_Appointment_OPS_temp where BRANCH_NUMBER <> ''

		
			/*
			PRINT 'Info : Completed insertion of #tmp'
			
			insert into con_odh.temp_DL_Customer_Appointment_OPS select CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE,row_number() over (order by a.OPS_CUSTOMER_NUMBER ASC) as row_id from (select dense_rank() over (partition by CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER order by PrevLensCheckDate desc ) as RN,CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE,PrevLensCheckDate FROM tempdb..#DL_Customer_Appointment_OPS_temp)a where a.RN=1 ;*/
		
		PRINT 'Info : Completed insertion of temp_DL_Customer_Appointment_OPS'
		
		
		
		END
	
			SET @total_records = (SELECT count(*) FROM  con_odh.temp_DL_Customer_Appointment_OPS)
			print @total_records
			
			insert into con_odh.DL_Customer_Appointment_OPS select distinct CATEGORY,APPT_DATE,OPS_CUSTOMER_NUMBER,STATUS,RIGHT_SPHERE,RIGHT_CYLINDER,RIGHT_AXIS,RIGHT_PRISM_1,RIGHT_PRISM_1_BASE,RIGHT_PRISM_2,RIGHT_PRISM_2_BASE,RIGHT_ADDTNL_POWER,RIGHT_ADDTNL_PRISM_1,RIGHT_ADDTNL_PRISM_1_BASE,RIGHT_ADDTNL_PRISM_2,RIGHT_ADDTNL_PRISM_2_BASE,RIGHT_INTERMEDIATE_ADDTN,RIGHT_BVD,LEFT_SPHERE,LEFT_CYLINDER,LEFT_AXIS,LEFT_PRISM_1,LEFT_PRISM_1_BASE,LEFT_PRISM_2,LEFT_PRISM_2_BASE,LEFT_ADDTNL_POWER,LEFT_ADDTNL_PRISM_1,LEFT_ADDTNL_PRISM_BASE,LEFT_ADDTNL_PRISM_2,LEFT_ADDTNL_PRISM_2_BASE,LEFT_INTERMEDIATE_ADDTN,LEFT_BVD,BRANCH_NUMBER,NHS_OR_PRIVATE,CL_SUITABLE_FLAG,CL_CHECK_CYCLE,RETAIL_PRICE,PAID_PRICE from (select top (@limit) * from con_odh.temp_DL_Customer_Appointment_OPS where row_id>@cnt order by row_id)a
			
			PRINT 'Info : Completed insertion of DL_Customer_Appointment_OPS'
			
			SET @rowsextracted=@total_records-@cnt
			SET @cnt= (select max(a.row_id) from (select top (@limit) * from con_odh.temp_DL_Customer_Appointment_OPS where row_id>@cnt order by row_id)a)
			
			IF @cnt != @total_records
			BEGIN 
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag=0 where rerun_flag=1 and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',1,0)
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',0,0)
				END
			END
			
			IF @cnt = @total_records
			BEGIN 
				--Truncate table [con_odh].[temp_DL_Customer_Appointment_OPS]
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag='0' where rerun_flag='1' and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',1,0)
					update psa.egress_sp_logs_odh set active_flag='N' where rerun_flag='1'
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',0,0)
				END
			END
		
		SELECT @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

	END TRY
	BEGIN CATCH
        IF @@TRANCOUNT>0
            ROLLBACK TRANSACTION;
            DECLARE @vErrorMessage AS NVARCHAR(500) = 
            (SELECT CONCAT( '{"Error number":'    ,'"', ERROR_NUMBER()    ,'"',', '
                                          ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
                                            ,'"Severity":' ,         '"', ERROR_SEVERITY()  ,'"',', '
                                        ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
                                            ,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'))
			SET @vProcedureMessage = @vErrorMessage
			SELECT  '-1' AS ProcedureStatus, @vProcedureMessage As ProcedureMessage;
			
			INSERT INTO [psa].[DNA_DB_Errors_Log] 
            SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_DL_Customer_Appointment_OPS]',ERROR_MESSAGE(),GETDATE();
        THROW;                    
                                
        END CATCH 
        IF @@TRANCOUNT>0
            COMMIT TRANSACTION;
 
		IF @cnt = @total_records
		BEGIN 
			Truncate table [con_odh].[temp_DL_Customer_Appointment_OPS]
		END

END
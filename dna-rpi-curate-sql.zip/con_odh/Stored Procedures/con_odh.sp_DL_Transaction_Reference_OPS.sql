﻿CREATE PROC [con_odh].[sp_DL_Transaction_Reference_OPS] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_DL_Transaction_Reference_OPS
Purpose						: Load Extract table for Transaction
Target Tables             	: con_odh.DL_Transaction_Reference

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed AS argument

*************************************************************************************************************
03-11-2022   :  Ashlin T	     Inital Version 1.0
 */
	

BEGIN	


      /* Declare and Initialize Generic variables*/
	    DECLARE @vProcedureMessage 					AS NVARCHAR(MAX) = 'OK';
        DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';
		DECLARE @vNumRows                           AS INT           = 0;
		/*DECLARE @OrderETLRunId INT;*/
		/*DECLARE @ODHBusinessPartnerETLRunId INT;*/
		/*DECLARE @ODHAdOrgETLRunId  INT;*/
		/*DECLARE @ODHOrderETLRunId  INT;*/
		/*DECLARE @OrderLineETLRunId  INT;*/
		/*DECLARE @ODHOrderLineETLRunId  INT;*/
		/*DECLARE @ODHOrderlineMeasureETLRunId  INT;*/
		/*DECLARE @ODHCustomOrderLineETLRunId  INT;*/
		/*DECLARE @ProductETLRunId  INT;*/
		/*DECLARE @ODHProductETLRunId  INT;*/
		/*DECLARE @ODHOrderLineOfferETLRunId  INT;*/
		/*DECLARE @ODHProductCategoryETLRunId  INT;*/
		/*DECLARE @ODHOfferETLRunId  INT;*/
		DECLARE @cnt AS INT=0;
		DECLARE @count INT;
		DECLARE @total_records INT;
		DECLARE @egress_status AS Int=0;
		DECLARE @frequency AS nvarchar(255)='History';
		DECLARE @curr_timestamp NVARCHAR(max);
		DECLARE @limit int;
		DECLARE @RunTime DATETIME;
		DECLARE @rerun AS INT=0; 
		DECLARE @endRunTime as DATETIME='9999-12-31 00:00:00.000';
		DECLARE @flag INT;
		DECLARE @feed_name nvarchar(100);
		DECLARE @rowsextracted as int;
		DECLARE @batch as int=0;
		DECLARE @prev_batch as int=0;
		DECLARE @execsql NVARCHAR(MAX);
        DECLARE @tempTableName nvarchar(max);
		DECLARE @execsql2 NVARCHAR(MAX);
        DECLARE @tempTableName2 nvarchar(max);
	

	
		--Creating temp table for selecting the DISCOUNT_CODE values by joining ODHOffer & ODHOrderLineOffer tables

		SET @tempTableName = 'tempdb..#DL_Transaction_Reference_OPS_test_temp_case1'
    
		IF OBJECT_ID(@tempTableName) IS NOT NULL
		BEGIN
			EXEC ('DROP table '+@tempTableName)
		END
        
		--Inserting the OfferName column in the ranking order into temp table from ODHOffer by joining with ODHOrderLineOffer with OfferId columns order by SourceCreated column 
        set @execsql='select dense_rank() over(partition by Order1.OrderId,ODHOrderLine.EmHorcusDraftOrderNumber order by x.OfferName) as RN ,Order1.OrderId,ODHProduct.ProductValue as Primary_transaction_code,ODHOrderLine.EmHorcusDraftOrderNumber,x.* into '+@tempTableName+' from
		(SELECT ODHOffer.OfferName as OfferName,ODHOrderLineOffer.SourceCreated as SourceCreated,ODHOrderLineOffer.ODHOrderlineId as ODHOrderlineId,ODHOrderLineOffer.DLETLRunLogId as 
		ODHOrderLineOfferETLRunId,ODHOrderLineOffer.RunDateTime as ODHOrderLineOfferRunDateTime,ODHOffer.DLETLRunLogId as ODHOfferETLRunId,ODHOffer.
		RunDateTime AS ODHOfferRunDateTime FROM (select * from curate_enterprise.ODHOffer where RecordSourceCode = ''BUKOPMS'' and DLSCDActiveFlag =''Y'') ODHOffer 
		INNER JOIN (select * from curate_enterprise.ODHOrderLineOffer where RecordSourceCode = ''BUKOPMS'' and DLSCDActiveFlag =''Y'') ODHOrderLineOffer 
		ON ODHOrderLineOffer.OfferId=ODHOffer.OfferId ) x
		INNER JOIN (select * from curate_enterprise.ODHOrderLine where RecordSourceCode = ''BUKOPMS'' and DLSCDActiveFlag =''Y'' ) ODHOrderLine ON x.ODHOrderlineId=ODHOrderLine.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.OrderLine where RecordSourceCode =''BUKOPMS'' and DLSCDActiveFlag =''Y'') OrderLine ON OrderLine.OrderLineId=ODHOrderLine.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.ODHOrder where RecordSourceCode =''BUKOPMS'' and DLSCDActiveFlag =''Y'' and ISSOTRX=''Y'' ) ODHOrder ON ODHOrder.ODHOrderId=OrderLine.OrderId
		INNER JOIN (select * from curate_enterprise.[Order] where RecordSourceCode = ''BUKOPMS'' and DLSCDActiveFlag =''Y'') Order1 ON Order1.OrderId=ODHOrder.ODHOrderId
		INNER JOIN (select * from curate_enterprise.ODHCustomOrderLine where RecordSourceCode =''BUKOPMS'' and DLSCDActiveFlag =''Y'' ) ODHCustomOrderLine ON ODHOrderLine.ODHOrderlineId=ODHCustomOrderLine.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.Product where RecordSourceCode =''BUKOPMS'' and DLSCDActiveFlag =''Y'') Product ON ODHCustomOrderLine.ProductID=Product.ProductId
		INNER JOIN (select * from curate_enterprise.ODHProduct where RecordSourceCode =''BUKOPMS'' and DLSCDActiveFlag =''Y'') ODHProduct ON ODHProduct.ProductId=Product.ProductId
		;'
		EXEC(@execsql)
		PRINT 'Info : CASE 1 Temp table got loaded'
		
		SET @tempTableName2 = 'tempdb..#DL_Transaction_Reference_OPS_test_temp_case2'
    
		IF OBJECT_ID(@tempTableName2) IS NOT NULL
		BEGIN
			EXEC ('DROP table '+@tempTableName2)
		END
        
		--Inserting the OfferName column in the ranking order into temp table from ODHOffer by joining with ODHOrderLineOffer with OfferId columns order by SourceCreated column 
        set @execsql2='select dense_rank() over(partition by Order1.OrderId,ODHOrderLine.EmHorcusDraftOrderNumber order by x.OfferName) as RN ,Order1.OrderId,ODHProduct.ProductValue as Primary_transaction_code,ODHOrderLine.EmHorcusDraftOrderNumber,x.* into '+@tempTableName2+' from
		(SELECT ODHOffer.OfferName as OfferName,ODHOrderLineOffer.SourceCreated as SourceCreated,ODHOrderLineOffer.ODHOrderlineId as ODHOrderlineId,ODHOrderLineOffer.DLETLRunLogId as 
		ODHOrderLineOfferETLRunId,ODHOrderLineOffer.RunDateTime as ODHOrderLineOfferRunDateTime,ODHOffer.DLETLRunLogId as ODHOfferETLRunId,ODHOffer.
		RunDateTime AS ODHOfferRunDateTime FROM (select * from curate_enterprise.ODHOffer where RecordSourceCode = ''BUKOPMS'' and DLSCDActiveFlag =''Y'') ODHOffer 
		INNER JOIN (select * from curate_enterprise.ODHOrderLineOffer where RecordSourceCode = ''BUKOPMS'' and DLSCDActiveFlag =''Y'') ODHOrderLineOffer 
		ON ODHOrderLineOffer.OfferId=ODHOffer.OfferId ) x
		INNER JOIN (select * from curate_enterprise.ODHOrderLine where RecordSourceCode = ''BUKOPMS'' and DLSCDActiveFlag =''Y'' ) ODHOrderLine ON x.ODHOrderlineId=ODHOrderLine.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.OrderLine where RecordSourceCode =''BUKOPMS'' and DLSCDActiveFlag =''Y'') OrderLine ON OrderLine.OrderLineId=ODHOrderLine.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.ODHOrder where RecordSourceCode =''BUKOPMS'' and DLSCDActiveFlag =''Y'' and ISSOTRX=''Y'' ) ODHOrder ON ODHOrder.ODHOrderId=OrderLine.OrderId
		INNER JOIN (select * from curate_enterprise.[Order] where RecordSourceCode = ''BUKOPMS'' and DLSCDActiveFlag =''Y'') Order1 ON Order1.OrderId=ODHOrder.ODHOrderId
		INNER JOIN (select * from curate_enterprise.Product where RecordSourceCode =''BUKOPMS'' and DLSCDActiveFlag =''Y'') Product ON ODHOrderLine.ProductId=Product.ProductId 
		INNER JOIN (select * from curate_enterprise.ODHProduct where RecordSourceCode =''BUKOPMS'' and DLSCDActiveFlag =''Y'') ODHProduct ON ODHProduct.ProductId=Product.ProductId
		;'
		EXEC(@execsql2)
		PRINT 'Info : CASE 2 Temp table got loaded'
		
		IF OBJECT_ID('tempdb..#DL_Transaction_Reference_OPS_temp') IS NOT NULL
		BEGIN
			EXEC ('DROP table tempdb..#DL_Transaction_Reference_OPS_temp')
		END
		EXEC('SELECT TOP 0 *,OPS_CUSTOMER_NUMBER AS SourceCreated1,OPS_CUSTOMER_NUMBER AS SourceCreated2,OPS_CUSTOMER_NUMBER AS SourceCreated3,OPS_CUSTOMER_NUMBER AS SourceCreated4,OPS_CUSTOMER_NUMBER AS SourceCreated5 into tempdb..#DL_Transaction_Reference_OPS_temp FROM [con_odh].[DL_Transaction_Reference_OPS]')

	BEGIN TRY
 
		BEGIN TRANSACTION;
		
		SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
		SET @feed_name='DL_Transaction_Reference_OPS_'+@curr_timestamp

		SET @count = (SELECT Count(*)  FROM  psa.egress_sp_logs_odh WHERE  project_name = 'ODH' AND feed_name like 'DL_Transaction_Reference_OPS_%' and active_flag='Y')
				
		IF @count !=0
		BEGIN
			SELECT top 1 @egress_status=egress_status,@batch=batch  FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Transaction_Reference_OPS_%' and active_flag='Y' order by  dt_created desc
			select @rerun=ReRun_Flag,@frequency=frequency from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Transaction_Reference_OPS_%' and active_flag='Y' and ReRun_Flag='1'
		END
				
			IF (@count != 0 and @egress_status != '0')
			BEGIN 
				SELECT top 1 @frequency=frequency,@cnt=rowid_extracted  FROM  psa.egress_sp_logs_odh  where  project_name = 'ODH' AND feed_name like 'DL_Transaction_Reference_OPS_%' and active_flag='Y' order by  dt_created desc
			END
			
			
			IF @count != 0 and @egress_status = '0' and @rerun!=1
			BEGIN 
				SET @frequency = 'Incremental'
			END
			
			print @frequency
			
			IF @frequency = 'History'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='History_limit')
			END
			
			IF @frequency = 'Incremental'
			BEGIN
				SET @limit=(select param_value from dc_metadata.GDHDynamicADFparams where project_name='ODH' and param_key='Incr_limit')
			END
			
			print @egress_status
				
			IF @egress_status = '0'
			BEGIN 
				IF @rerun='1'
				BEGIN
					SELECT @endRunTime=dt_created,@batch=batch from psa.egress_sp_logs_odh where  project_name = 'ODH' AND feed_name like 'DL_Transaction_Reference_OPS_%' and ReRun_Flag='1' and active_flag='Y'
				END
				ELSE
				BEGIN
					SET @endRunTime='9999-12-31 00:00:00.000';
					SET @batch=@batch+1
				END
				print @endRunTime
				
				SELECT TOP 1 @flag=isnull(min(egress_status),0),@prev_batch=isnull(min(batch),0) From
				(select ROW_NUMBER() OVER(ORDER BY dt_created desc) AS rn,* from psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Transaction_Reference_OPS_%'  and active_flag='Y' and dt_created<@endRunTime) a where rn=2
				print @flag
				
				if @flag != '0'
				begin
				set @RunTime=(SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where project_name = 'ODH' AND feed_name like 'DL_Transaction_Reference_OPS_%' and active_flag='Y' and dt_created<@endRunTime and batch =@prev_batch order by  dt_created asc);
				end
				if @flag = '0'
				begin
				set @RunTime=(SELECT ISNULL(min(a.dt_created), cast('1900-01-01' as datetime)) as dt_created from (SELECT top 1  dt_created FROM  psa.egress_sp_logs_odh where 
				project_name = 'ODH' AND feed_name like 'DL_Transaction_Reference_OPS_%' and active_flag='Y' and dt_created<@endRunTime order by  dt_created desc)a);
				end
				
				print @RunTime
				
				/*SET @OrderETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.[Order] where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHBusinessPartnerETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHBusinessPartner where RunDateTime > cast(@RunTime as datetime) )*/			
				/*SET @ODHAdOrgETLRunId       = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHAdOrg where RunDateTime > cast(@RunTime as datetime) ) */            
				/*SET @ODHOrderETLRunId  = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHOrder where RunDateTime > cast(@RunTime as datetime) ) */                
				/*SET @OrderLineETLRunId   = (SELECT MIN(DLETLRunLogId) from curate_enterprise.OrderLine where RunDateTime > cast(@RunTime as datetime) ) */              
				/*SET @ODHOrderLineETLRunId   = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHOrderLine where RunDateTime > cast(@RunTime as datetime) )*/           
				/*SET @ODHOrderlineMeasureETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHOrderlineMeasure where RunDateTime > cast(@RunTime as datetime) ) */     
				/*SET @ODHCustomOrderLineETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHCustomOrderLine where RunDateTime > cast(@RunTime as datetime) )*/     
				/*SET @ProductETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.Product where RunDateTime > cast(@RunTime as datetime) )*/ 
				/*SET @ODHProductETLRunId    = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHProduct where RunDateTime > cast(@RunTime as datetime) ) */             
				/*SET @ODHOrderLineOfferETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHOrderLineOffer where RunDateTime > cast(@RunTime as datetime) )  */      
				/*SET @ODHProductCategoryETLRunId   = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHProductCategory where RunDateTime > cast(@RunTime as datetime) )*/
				/*SET @ODHOfferETLRunId = (SELECT MIN(DLETLRunLogId) from curate_enterprise.ODHOffer where RunDateTime > cast(@RunTime as datetime) )*/
				
		
		INSERT INTO tempdb..#DL_Transaction_Reference_OPS_temp
		(
			TRANSACTION_NUMBER       ,
			OPS_CUSTOMER_NUMBER      ,
			TRANSACTION_TYPE         ,
			ORDER_DATE               ,
			PRIMARY_TRANSACTION_CODE ,
			PAID_PRICE               ,
			ADDTNL_PROCESS_CODE_1    ,
			ADDTNL_PROCESS_CODE_2    ,
			ADDTNL_PROCESS_CODE_3    ,
			RIGHT_LENS_CODE          ,
			LEFT_LENS_CODE           ,
			DISCOUNT_CODE_1          ,
			DISCOUNT_CODE_2          ,
			DISCOUNT_CODE_3          ,
			DISCOUNT_CODE_4          ,
			DISCOUNT_CODE_5          ,
			BRANCH_NUMBER            ,
			WORK_ORDER_NUMBER        ,
			RETAIL_PRICE             ,
			SourceCreated1			 ,
			SourceCreated2			 ,
			SourceCreated3			 ,
			SourceCreated4			 ,
			SourceCreated5
		)
		SELECT 
		isnull(cast(Order1.DocumentNo as nvarchar(max)),'') AS TRANSACTION_NUMBER,
		isnull(cast(ODHBusinessPartner.CBPartnerValue as nvarchar(max)),'') AS OPS_CUSTOMER_NUMBER,
		isnull(cast(case when ODHOrderlineMeasure.QtyOrderd <0 then concat((case when ODHProductCategory.CategoryValue ='Frame' then ODHProductCategory.CategoryValue else (case when ODHCustomOrderLine.Side ='R' then concat('R ',ODHProductCategory.CategoryValue) when ODHCustomOrderLine.Side ='L' then concat('L ',ODHProductCategory.CategoryValue) end) end),' Refund') else (case when ODHProductCategory.CategoryValue ='Frame' then ODHProductCategory.CategoryValue else (case when ODHCustomOrderLine.Side ='R' then concat('R ',ODHProductCategory.CategoryValue) when ODHCustomOrderLine.Side ='L' then concat('L ',ODHProductCategory.CategoryValue) end) end) end as nvarchar(max)),'') AS TRANSACTION_TYPE, 
		isnull(cast(CONVERT(date, OrderLine.DateOrdered, 23) as nvarchar(max)),'') AS ORDER_DATE,
		isnull(cast(ODHProduct.ProductValue  as nvarchar(max)),'') AS PRIMARY_TRANSACTION_CODE,
		isnull(cast(cast(ODHCustomOrderLine.HorcusPrice as numeric(15,2))*ODHCustomOrderLine.HorcusQuantity as nvarchar(max)),'') AS PAID_PRICE,
		isnull(cast(NULL  as nvarchar(max)),'') AS ADDTNL_PROCESS_CODE_1,
		isnull(cast(NULL  as nvarchar(max)),'') AS ADDTNL_PROCESS_CODE_2,
		isnull(cast(NULL  as nvarchar(max)),'') AS ADDTNL_PROCESS_CODE_3,
		isnull(cast(NULL  as nvarchar(max)),'') AS RIGHT_LENS_CODE,
		isnull(cast(NULL  as nvarchar(max)),'') AS LEFT_LENS_CODE,
		isnull(cast(tmp_table1.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_1,
		isnull(cast(tmp_table2.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_2,
		isnull(cast(tmp_table3.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_3,
		isnull(cast(tmp_table4.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_4,
		isnull(cast(tmp_table5.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_5,
		isnull(cast(ODHAdOrg.OrgValue as nvarchar(max)),'') AS BRANCH_NUMBER,
		isnull(cast(ODHOrderLine.EmHorcusDraftOrderNumber as nvarchar(max)),'') AS WORK_ORDER_NUMBER,
		isnull(cast(case when ODHCustomOrderLine.HorcusOriginalPrice is null then cast(ODHCustomOrderLine.HorcusPrice as numeric(15,2))*ODHCustomOrderLine.HorcusQuantity  else cast(ODHCustomOrderLine.HorcusOriginalPrice*ODHCustomOrderLine.HorcusQuantity as numeric(15,2))  end as nvarchar(max)),'') AS RETAIL_PRICE,
		isnull(cast(tmp_table1.SourceCreated as nvarchar(max)),'') AS SourceCreated1,
		isnull(cast(tmp_table2.SourceCreated as nvarchar(max)),'') AS SourceCreated2,
		isnull(cast(tmp_table3.SourceCreated as nvarchar(max)),'') AS SourceCreated3,
		isnull(cast(tmp_table4.SourceCreated as nvarchar(max)),'') AS SourceCreated4,
		isnull(cast(tmp_table5.SourceCreated as nvarchar(max)),'') AS SourceCreated5
			
		FROM (select * from curate_enterprise.[Order] where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and DocumentStatus='CO' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) Order1
		INNER JOIN (select * from curate_enterprise.ODHOrder where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and ISSOTRX='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHOrder ON Order1.OrderId=ODHOrder.ODHOrderId
		INNER JOIN (select * from curate_enterprise.ODHBusinesspartner where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHBusinessPartner ON ODHBusinessPartner.PersonId=Order1.PersonId
		INNER JOIN (select * from curate_enterprise.ODHAdOrg where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHAdOrg ON ODHOrder.OrganisationId=ODHAdOrg.OrganisationId
		INNER JOIN (select * from curate_enterprise.OrderLine where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) OrderLine ON ODHOrder.ODHOrderId=OrderLine.OrderId
		INNER JOIN (select * from curate_enterprise.ODHOrderLine where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHOrderLine ON OrderLine.OrderLineId=ODHOrderLine.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.ODHCustomOrderLine where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHCustomOrderLine ON ODHOrderLine.ODHOrderlineId=ODHCustomOrderLine.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.ODHOrderlineMeasure where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHOrderlineMeasure ON ODHCustomOrderLine.ODHOrderlineId=ODHOrderlineMeasure.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.Product where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) Product ON ODHCustomOrderLine.ProductID=Product.ProductId
		INNER JOIN (select * from curate_enterprise.ODHProduct where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHProduct ON ODHProduct.ProductId=Product.ProductId
		INNER JOIN (select * from curate_enterprise.ODHProductCategory where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and CategoryValue  not in  ('Package','Service','Accessory','Cover') AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHProductCategory ON ODHProduct.ODHProductCategoryId=ODHProductCategory.ODHProductCategoryId
		left JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case1 where RN=1 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table1 ON Order1.OrderId=tmp_table1.OrderId and ODHProduct.ProductValue = tmp_table1.primary_transaction_Code and isnull(tmp_table1.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
	    LEFT JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case1 where RN=2 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table2 ON Order1.OrderId=tmp_table2.OrderId and ODHProduct.ProductValue = tmp_table2.primary_transaction_Code and isnull(tmp_table2.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
		LEFT JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case1 where RN=3 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table3 ON Order1.OrderId=tmp_table3.OrderId and ODHProduct.ProductValue = tmp_table3.primary_transaction_Code and isnull(tmp_table3.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
		LEFT JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case1 where RN=4 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table4 ON Order1.OrderId=tmp_table4.OrderId and ODHProduct.ProductValue = tmp_table4.primary_transaction_Code and isnull(tmp_table4.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
		LEFT JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case1 where RN=5 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table5 ON Order1.OrderId=tmp_table5.OrderId and ODHProduct.ProductValue = tmp_table5.primary_transaction_Code and isnull(tmp_table5.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
		UNION 
		SELECT 
		isnull(cast(Order1.DocumentNo as nvarchar(max)),'') AS TRANSACTION_NUMBER,
		isnull(cast(ODHBusinessPartner.CBPartnerValue as nvarchar(max)),'') AS OPS_CUSTOMER_NUMBER,
		isnull(cast(ODHProductCategory.CategoryValue as nvarchar(max)),'') AS TRANSACTION_TYPE, 
		isnull(cast(CONVERT(date, OrderLine.DateOrdered, 23) as nvarchar(max)),'') AS ORDER_DATE,
		isnull(cast(ODHProduct.ProductValue  as nvarchar(max)),'') AS PRIMARY_TRANSACTION_CODE,
		isnull(cast(cast(ODHOrderlineMeasure.LineGrossAmount*ODHOrderlineMeasure.QtyOrderd  as numeric(15,2)) as nvarchar(max)),'') AS PAID_PRICE,
		isnull(cast(NULL  as nvarchar(max)),'') AS ADDTNL_PROCESS_CODE_1,
		isnull(cast(NULL  as nvarchar(max)),'') AS ADDTNL_PROCESS_CODE_2,
		isnull(cast(NULL  as nvarchar(max)),'') AS ADDTNL_PROCESS_CODE_3,
		isnull(cast(NULL  as nvarchar(max)),'') AS RIGHT_LENS_CODE,
		isnull(cast(NULL  as nvarchar(max)),'') AS LEFT_LENS_CODE,
		isnull(cast(tmp_table1.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_1,
		isnull(cast(tmp_table2.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_2,
		isnull(cast(tmp_table3.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_3,
		isnull(cast(tmp_table4.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_4,
		isnull(cast(tmp_table5.OfferName as nvarchar(max)),'') AS DISCOUNT_CODE_5,
		isnull(cast(ODHAdOrg.OrgValue as nvarchar(max)),'') AS BRANCH_NUMBER,
		isnull(cast(ODHOrderLine.EmHorcusDraftOrderNumber as nvarchar(max)),'') AS WORK_ORDER_NUMBER,
		isnull(cast(cast(ODHOrderlineMeasure.PriceStd*ODHOrderlineMeasure.QtyOrderd as numeric(15,2))as nvarchar(max)),'') AS RETAIL_PRICE,
		isnull(cast(tmp_table1.SourceCreated as nvarchar(max)),'') AS SourceCreated1,
		isnull(cast(tmp_table2.SourceCreated as nvarchar(max)),'') AS SourceCreated2,
		isnull(cast(tmp_table3.SourceCreated as nvarchar(max)),'') AS SourceCreated3,
		isnull(cast(tmp_table4.SourceCreated as nvarchar(max)),'') AS SourceCreated4,
		isnull(cast(tmp_table5.SourceCreated as nvarchar(max)),'') AS SourceCreated5
			
		FROM (select * from curate_enterprise.[Order] where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and DocumentStatus='CO' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) Order1
		INNER JOIN (select * from curate_enterprise.ODHOrder where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and ISSOTRX='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHOrder ON Order1.OrderId=ODHOrder.ODHOrderId
		INNER JOIN (select * from curate_enterprise.ODHBusinessPartner where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHBusinessPartner ON ODHBusinessPartner.PersonId=Order1.PersonId
		INNER JOIN (select * from curate_enterprise.ODHAdOrg where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHAdOrg ON ODHOrder.OrganisationId=ODHAdOrg.OrganisationId
		INNER JOIN (select * from curate_enterprise.OrderLine where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) OrderLine ON ODHOrder.ODHOrderId=OrderLine.OrderId
		INNER JOIN (select * from curate_enterprise.ODHOrderLine where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHOrderLine ON OrderLine.OrderLineId=ODHOrderLine.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.ODHOrderlineMeasure where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHOrderlineMeasure ON ODHOrderLine.ODHOrderlineId=ODHOrderlineMeasure.ODHOrderlineId
		INNER JOIN (select * from curate_enterprise.Product where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) Product ON ODHOrderLine.ProductId=Product.ProductId 
		INNER JOIN (select * from curate_enterprise.ODHProduct where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHProduct ON ODHProduct.ProductId=Product.ProductId
		INNER JOIN (select * from curate_enterprise.ODHProductCategory where RecordSourceCode = 'BUKOPMS' and DLSCDActiveFlag ='Y' and CategoryValue in ('Service','Accessory','Cover') AND RunDateTime > cast(@RunTime as datetime) and RunDateTime<@endRunTime) ODHProductCategory ON ODHProduct.ODHProductCategoryId=ODHProductCategory.ODHProductCategoryId
		left JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case2 where RN=1 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table1 ON Order1.OrderId=tmp_table1.OrderId and ODHProduct.ProductValue = tmp_table1.primary_transaction_Code and isnull(tmp_table1.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
	    LEFT JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case2 where RN=2 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table2 ON Order1.OrderId=tmp_table2.OrderId and ODHProduct.ProductValue = tmp_table2.primary_transaction_Code and isnull(tmp_table2.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
		LEFT JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case2 where RN=3 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table3 ON Order1.OrderId=tmp_table3.OrderId and ODHProduct.ProductValue = tmp_table3.primary_transaction_Code and isnull(tmp_table3.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
		LEFT JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case2 where RN=4 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table4 ON Order1.OrderId=tmp_table4.OrderId and ODHProduct.ProductValue = tmp_table4.primary_transaction_Code and isnull(tmp_table4.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
		LEFT JOIN (select * from tempdb..#DL_Transaction_Reference_OPS_test_temp_case2 where RN=5 and ODHOrderLineOfferRunDateTime > cast(@RunTime as datetime) and ODHOrderLineOfferRunDateTime<@endRunTime and ODHOfferRunDatetIme > cast(@RunTime as datetime) and ODHOfferRunDatetIme<@endRunTime) tmp_table5 ON Order1.OrderId=tmp_table5.OrderId and ODHProduct.ProductValue = tmp_table5.primary_transaction_Code and isnull(tmp_table5.EmHorcusDraftOrderNumber,'')=isnull(ODHOrderLine.EmHorcusDraftOrderNumber,'')
		;
		PRINT 'Info : Completed insertion of #tmp_DL_Transaction_Reference'
		
		
			insert into con_odh.temp_DL_Transaction_Reference_OPS select TRANSACTION_NUMBER,OPS_CUSTOMER_NUMBER,TRANSACTION_TYPE,ORDER_DATE,PRIMARY_TRANSACTION_CODE,PAID_PRICE,ADDTNL_PROCESS_CODE_1,ADDTNL_PROCESS_CODE_2,ADDTNL_PROCESS_CODE_3,RIGHT_LENS_CODE,LEFT_LENS_CODE,DISCOUNT_CODE_1,DISCOUNT_CODE_2,DISCOUNT_CODE_3,DISCOUNT_CODE_4,DISCOUNT_CODE_5,BRANCH_NUMBER,WORK_ORDER_NUMBER,RETAIL_PRICE,row_number() over (order by a.OPS_CUSTOMER_NUMBER ASC) as row_id from (select dense_rank() over (partition by Transaction_Number,Ops_Customer_Number,Order_Date,Paid_Price,Retail_Price,transaction_type,work_order_number,Primary_transaction_Code order by SourceCreated1 desc,SourceCreated2 desc,SourceCreated3 desc,SourceCreated4 desc,SourceCreated5 desc) as RN,TRANSACTION_NUMBER,OPS_CUSTOMER_NUMBER,TRANSACTION_TYPE,ORDER_DATE,PRIMARY_TRANSACTION_CODE,PAID_PRICE,ADDTNL_PROCESS_CODE_1,ADDTNL_PROCESS_CODE_2,ADDTNL_PROCESS_CODE_3,RIGHT_LENS_CODE,LEFT_LENS_CODE,DISCOUNT_CODE_1,DISCOUNT_CODE_2,DISCOUNT_CODE_3,DISCOUNT_CODE_4,DISCOUNT_CODE_5,BRANCH_NUMBER,WORK_ORDER_NUMBER,RETAIL_PRICE,SourceCreated1,SourceCreated2,SourceCreated3,SourceCreated4,SourceCreated5   FROM tempdb..#DL_Transaction_Reference_OPS_temp)a where a.RN=1 ;
		
		PRINT 'Info : Completed insertion of temp_DL_Transaction_Reference_OPS'
		
		END
	
			SET @total_records = (SELECT count(*) FROM con_odh.temp_DL_Transaction_Reference_OPS)
			print @total_records
			
			insert into con_odh.DL_Transaction_Reference_OPS select distinct TRANSACTION_NUMBER,OPS_CUSTOMER_NUMBER,TRANSACTION_TYPE,ORDER_DATE,PRIMARY_TRANSACTION_CODE,PAID_PRICE,ADDTNL_PROCESS_CODE_1,ADDTNL_PROCESS_CODE_2,ADDTNL_PROCESS_CODE_3,RIGHT_LENS_CODE,LEFT_LENS_CODE,DISCOUNT_CODE_1,DISCOUNT_CODE_2,DISCOUNT_CODE_3,DISCOUNT_CODE_4,DISCOUNT_CODE_5,BRANCH_NUMBER,WORK_ORDER_NUMBER,RETAIL_PRICE from (select top (@limit) * from con_odh.temp_DL_Transaction_Reference_OPS where row_id>@cnt order by row_id)a
			
			SET @rowsextracted=@total_records-@cnt
			SET @cnt= (select max(a.row_id) from (select top (@limit) * from con_odh.temp_DL_Transaction_Reference_OPS where row_id>@cnt order by row_id)a)
			
			IF @cnt != @total_records
			BEGIN 
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag=0 where rerun_flag=1 and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',1,0)
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@limit,@total_records,1,@batch,@curr_timestamp,'Y',0,0)
				END
			END
			
			IF @cnt = @total_records
			BEGIN 
				--Truncate table [con_odh].[temp_DL_Transaction_Reference_OPS]
				IF @rerun='1'
				BEGIN
					if @endRunTime != '9999-12-31 00:00:00.000'
					begin
						update psa.egress_sp_logs_odh set rerun_etlrunlogid=@pETLRunLogID where rerun_flag='1' and active_flag='Y'
						update psa.egress_sp_logs_odh set rerun_flag='0' where rerun_flag='1' and active_flag='Y'
					end
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',1,0)
					update psa.egress_sp_logs_odh set active_flag='N' where rerun_flag='1'
				END
				ELSE
				BEGIN
					insert into psa.egress_sp_logs_odh values ('ODH',@feed_name,@frequency,@pETLRunLogID,@cnt,@rowsextracted,@total_records,'0',@batch,@curr_timestamp,'Y',0,0)
				END
			END
		
		SELECT @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

	END TRY
	BEGIN CATCH
        IF @@TRANCOUNT>0
            ROLLBACK TRANSACTION;
            DECLARE @vErrorMessage AS NVARCHAR(500) = 
            (SELECT CONCAT( '{"Error number":'    ,'"', ERROR_NUMBER()    ,'"',', '
                                          ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
                                            ,'"Severity":' ,         '"', ERROR_SEVERITY()  ,'"',', '
                                        ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
                                            ,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'))
			SET @vProcedureMessage = @vErrorMessage
			SELECT  '-1' AS ProcedureStatus, @vProcedureMessage As ProcedureMessage;
			
			INSERT INTO [psa].[DNA_DB_Errors_Log] 
            SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_DL_Transaction_Reference_OPS]',ERROR_MESSAGE(),GETDATE();
        THROW;                    
                                
        END CATCH 
        IF @@TRANCOUNT>0
            COMMIT TRANSACTION;
 IF @cnt = @total_records
		BEGIN 
			Truncate table [con_odh].[temp_DL_Transaction_Reference_OPS]
		END

END
﻿CREATE TABLE [con_odh].[tmp_DL_Customer_Address_OPS]
(
	[OPS_CUSTOMER_NUMBER] [nvarchar](255) NOT NULL,
	[SURNAME] [nvarchar](255) NULL,
	[FORENAME] [nvarchar](255) NULL,
	[TITLE] [nvarchar](255) NULL,
	[BUILDING_NAME] [nvarchar](255) NULL,
	[BUILDING_NUM] [nvarchar](255) NULL,
	[UNIT] [nvarchar](255) NULL,
	[ROAD] [nvarchar](255) NULL,
	[LOCALITY] [nvarchar](255) NULL,
	[TOWN] [nvarchar](255) NULL,
	[COUNTY] [nvarchar](255) NULL,
	[POSTCODE] [nvarchar](255) NULL,
	[COUNTRY] [nvarchar](255) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
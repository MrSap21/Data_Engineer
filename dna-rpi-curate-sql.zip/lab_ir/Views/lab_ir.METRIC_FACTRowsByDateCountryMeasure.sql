CREATE VIEW [lab_ir].[METRIC_FACTRowsByDateCountryMeasure] AS
WITH the_countries AS
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : LAB_IR.METRIC_FACTRowsByDateCountryMeasure.sql
-- Description : This view shows count of FACT rows by Date, Country and Measure
--                                                                                                                                                      
-- =============================================================================                                                                        
-- Change History                                                                                                                                      
-- Name         Date           Description
-- Jeff Moss    11-JAN-2020    Created
-- Shailen		06-Jun-2020    Added Mexico and Netherlands
--
(
SELECT 'Norway' country
UNION ALL
SELECT 'Thailand'
UNION ALL
SELECT 'Chile'
UNION ALL
SELECT 'Mexico'
UNION ALL
SELECT 'Netherlands'
)
, the_measures AS
(
SELECT 'POS Profit' measure
UNION ALL
SELECT 'SALES'
UNION ALL
SELECT 'Wholesale'
)
, all_cells AS
(
SELECT tc.country
,      tm.measure
FROM   the_countries tc
CROSS JOIN the_measures tm
)
SELECT src.analysis_date
,      ac.country
,      ac.measure
,      COUNT(src.analysis_date) count_rows
FROM   all_cells ac
LEFT OUTER JOIN lab_ir.fact_international_retail_sales src  
ON (ac.country = src.country
	AND ac.measure = src.measure)
GROUP BY src.analysis_date
,      ac.country
,      ac.measure

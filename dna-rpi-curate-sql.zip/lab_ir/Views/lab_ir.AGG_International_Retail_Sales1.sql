CREATE VIEW [lab_ir].[AGG_International_Retail_Sales1] AS 
WITH the_data AS 
(
SELECT Analysis_Date
,      Country
,      Category
,      Measure
,      SUM(CAST(REPLACE(Actual_USD, ',', '.') AS numeric)) Sales_Day_Actual
,      SUM(CAST(REPLACE(Number_Of_Transactions, ',', '.') AS numeric)) Sales_Day_Number_Of_Transactions
,      SUM(CAST(REPLACE(Budget_USD, ',', '.') AS numeric)) Sales_Day_Budget
,      SUM(CAST(REPLACE(Forecast_USD, ',', '.') AS numeric)) Sales_Day_Forecast
FROM   lab_ir.fact_international_retail_sales
WHERE  Measure = 'Sales' 
   OR  Measure = 'Wholesale'
GROUP BY analysis_date
,        country
,        category
,        measure
)
SELECT CONVERT(DateTime, Analysis_Date,103) as Analysis_Date
,      CONVERT(VARCHAR(8), CONVERT(DateTime, Analysis_Date,103), 112) as YearMonthDay
,      CASE WHEN MONTH(CONVERT(DateTime, Analysis_Date,103)) <9 
            THEN CONVERT(VARCHAR(4),(CONVERT(DateTime,Analysis_Date,103)),112)-1 
            ELSE CONVERT(VARCHAR(4),(CONVERT(DateTime,Analysis_Date,103)),112) 
             END AS FiscalYear
,      CONVERT(VARCHAR(6),(CONVERT(DateTime,Analysis_Date,103)), 112) as YearMonth 
,      (CONVERT(DateTime, Analysis_Date,103)) - (DATEPART(dw,(CONVERT(DateTime,Analysis_Date,103))-1)-1) as Week
,      CONVERT(VARCHAR(2),(CONVERT(DateTime,Analysis_Date,3)), 3) as Day
,      Country
,      Category
,      Measure
,      Sales_Day_Actual
,      Sales_Day_Number_Of_Transactions
,      Sales_Day_Budget
,      Sales_Day_Forecast
FROM   the_data;
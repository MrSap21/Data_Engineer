CREATE VIEW [lab_ir].[METRIC_MaxDateByCountryMeasure] AS
SELECT country
-- -----------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : LAB_IR.METRIC_MaxDateByCountryMeasure.sql
-- Description : This view shows latest date by country/measure in the 
--               International Retail Sales FACT table
--                                                                                                                                                      
-- =============================================================================                                                                        
-- Change History                                                                                                                                      
-- Name         Date           Description
-- Jeff Moss    20-JAN-2020    Created
--
,      measure
,      MAX(CAST(analysis_date AS DATE)) latest_date
FROM   lab_ir.fact_international_retail_sales
GROUP BY country
,        measure
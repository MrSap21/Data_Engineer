CREATE VIEW [lab_ir].[AGG_International_Retail_Profit1] AS
SELECT Analysis_Date as POS_Analysis_Date
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : FACT_International_Retail_Sales.sql
-- Description : This view shows tactical international retail sales data for PowerBI
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                      
-- Name         Date           Description
-- Jeff Moss    30-SEP-2019    Created
-- Jeff Moss    29-OCT-2019    Set number_of_transactions to zero on daily sales profit
-- Jeff Moss    30-OCT-2019    Changed format mask on datetime convert on Norway DailySales/Profit
--                             from 103 to 101.
-- Jeff Moss    04-NOV-2019    Changed format mask on datetime convert on Chile from 103 to 101.
--                             CHanged all DECIMAL(25,16) to DECIMAL(25) to stop data overflows.
-- Jeff Moss    28-NOV-2019    Added Thailand.
-- Jeff Moss    29-NOV-2019    Resolved errors with data
-- Jeff Moss    04-DEC-2019    Changed format mask on datetime convert on Norway DailySales/Profit
--                             from 103 to 101.
-- Jeff Moss    04-DEC-2019    Changed DATETIME conversion on Thailand to DATE.
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
,      Country AS POS_Country
,      Category AS POS_Category
,      SUM(CAST(REPLACE(Actual_USD, ',', '.') AS numeric)) Profit_Day_Actual
,      SUM(CAST(REPLACE(Number_Of_Transactions, ',', '.') AS numeric)) Profit_Day_Number_Of_Transactions
,      SUM(CAST(REPLACE(Budget_USD, ',', '.') AS numeric)) Profit_Day_Budget
,      SUM(CAST(REPLACE(Forecast_USD, ',', '.') AS numeric)) Profit_Day_Forecast
FROM   LAB_IR.FACT_International_Retail_Sales
WHERE  Measure = 'POS Profit'
GROUP BY Analysis_Date
,        Country
,        Category;
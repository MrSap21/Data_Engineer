CREATE TABLE [lab_ir].[IR_DailySalesCategoryMapping]
(
	[channel] [varchar](60) NOT NULL,
	[international_category] [varchar](100) NOT NULL,
	[country] [varchar](60) NOT NULL,
	[country_category] [varchar](100) NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)
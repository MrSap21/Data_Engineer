CREATE TABLE [lab_ir].[FACT_International_Retail_Sales](
  Country                                [nvarchar](50)    NOT NULL
, Currency_Code                          [nvarchar](60)    NOT NULL
, Analysis_Date                          [datetime]        NOT NULL
, Measure                                [nvarchar](50)    NOT NULL
, Category                               [nvarchar](100)   NOT NULL
, Actual_LC                              [numeric]         NULL
, Number_Of_Transactions                 [integer]         NULL
, Budget_LC                              [numeric]         NULL
, Forecast_LC                            [numeric]         NULL
, Actual_Last_Year_LC                    [numeric]         NULL
, Adjusted_Last_Full_Month_LC            [numeric]         NULL
, Actual_USD                             [numeric]         NULL
, Budget_USD                             [numeric]         NULL
, Forecast_USD                           [numeric]         NULL
, Actual_Last_Year_USD                   [numeric]         NULL
, Adjusted_Last_Full_Month_USD           [numeric]         NULL
) 
WITH
(
    HEAP,
	DISTRIBUTION = ROUND_ROBIN
)
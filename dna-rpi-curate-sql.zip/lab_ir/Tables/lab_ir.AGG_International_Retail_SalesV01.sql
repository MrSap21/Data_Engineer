CREATE TABLE [lab_ir].[AGG_International_Retail_SalesV01]
(
 [Country] [nvarchar](50) NOT NULL
,[Category] [nvarchar](100) NOT NULL
,[Measure] [nvarchar](50) NOT NULL
,[Analysis_Date] [datetime] NULL
,[FiscalYear] [int] NULL
,[YearMonth] [varchar](6) NULL
,[MonthName] [varchar](3) NULL
,[MonthOrder] [int] NULL
,[Week] [datetime] NULL
,[WeekDay] [varchar](3) NULL
,[WeekDayOrder] [int] NULL
,[Analysis_Date_Selector] [varchar](22) NULL
--,[DW] [int] NULL
--,[Year] [int] NULL
--,[YearMonthDay] [varchar](8) NULL
--,[Day] [varchar](2) NULL
,[Sales_Day_Actual] [numeric] NULL
,[Sales_Week_Actual] [numeric] NULL
,[Sales_Month_Actual] [numeric] NULL
,[Sales_Year_Actual] [numeric] NULL
,[Sales_Day_Previous_Year] [numeric] NULL
,[Sales_Week_Previous_Year] [numeric] NULL
,[Sales_Month_Previous_Year] [numeric] NULL
,[Sales_Year_Previous_Year] [numeric] NULL
,[Profit_Day_Actual] [numeric] NOT NULL
,[Profit_Week_Actual] [numeric] NOT NULL
,[Profit_Month_Actual] [numeric] NOT NULL
,[Profit_Year_Actual] [numeric] NOT NULL
,[Profit_Day_Previous_Year] [numeric] NULL
,[Profit_Week_Previous_Year] [numeric] NULL
,[Profit_Month_Previous_Year] [numeric] NULL
,[Profit_Year_Previous_Year] [numeric] NULL
,[Sales_Day_Budget] [numeric] NULL
,[Sales_Week_Budget] [numeric] NULL
,[Sales_Month_Budget] [numeric] NULL
,[Sales_Year_Budget] [numeric] NULL
,[Profit_Day_Budget] [numeric] NOT NULL
,[Profit_Week_Budget] [numeric] NOT NULL
,[Profit_Month_Budget] [numeric] NOT NULL
,[Profit_Year_Budget] [numeric] NOT NULL
,[Sales_Day_Forecast] [numeric] NULL
,[Sales_Week_Forecast] [numeric] NULL
,[Sales_Month_Forecast] [numeric] NULL
,[Sales_Year_Forecast] [numeric] NULL
,[Profit_Day_Forecast] [numeric] NOT NULL
,[Profit_Week_Forecast] [numeric] NOT NULL
,[Profit_Month_Forecast] [numeric] NOT NULL
,[Profit_Year_Forecast] [numeric] NOT NULL
,[Sales_Day_Number_Of_Transactions] [numeric] NULL
,[Sales_Week_Number_Of_Transactions] [numeric] NULL
,[Sales_Month_Number_Of_Transactions] [numeric] NULL
,[Sales_Year_Number_Of_Transactions] [numeric] NULL
,[Sales_Day_Number_Of_Transactions_Previous_Year] [numeric] NULL
,[Sales_Week_Number_Of_Transactions_Previous_Year] [numeric] NULL
,[Sales_Month_Number_Of_Transactions_Previous_Year] [numeric] NULL
,[Sales_Year_Number_Of_Transactions_Previous_Year] [numeric] NULL
,[Profit_Day_Number_Of_Transactions] [numeric] NOT NULL
,[Profit_Week_Number_Of_Transactions] [numeric] NOT NULL
,[Profit_Month_Number_Of_Transactions] [numeric] NOT NULL
,[Profit_Year_Number_Of_Transactions] [numeric] NOT NULL
)
WITH
(
     DISTRIBUTION = ROUND_ROBIN
    ,HEAP
);


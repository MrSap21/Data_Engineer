CREATE TABLE [lab_ir].[IR_FX_Rates]
(
	[country_region] [varchar](100) NOT NULL,
	[currency_code] [varchar](60) NOT NULL,
	[source] [varchar](100) NOT NULL,
	[transaction_currency] [decimal](10, 6) NOT NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
)
create proc lab_ir.refresh_AGG_International_Retail_SalesV01 as
begin
TRUNCATE TABLE [lab_ir].[AGG_International_Retail_SalesV01]
INSERT INTO [lab_ir].[AGG_International_Retail_SalesV01]
SELECT * FROM [lab_ir].[vwAGG_International_Retail]
end
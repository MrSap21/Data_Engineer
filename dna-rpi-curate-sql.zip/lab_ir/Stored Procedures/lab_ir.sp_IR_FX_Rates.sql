/**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

2021         :  Gourik Nandy	  Inital Version
01-11-2021   :  Gourik Nandy      Updated Version	(Tag - FX22Rates)	
								  Purpose : This change will add the financial year 2022 budget rates
23-11-2021   :  Gourik Nandy      Updated Version	(Tag - FX22Rates_23Nov21)	
								  Purpose : This change will comment out the financial year 2021 budget rates as they are 
								  no longer needed
16-09-2022   :  Rakesh Andotra    Updated Version	(Tag - FX23Rates_16Sep22)	
								  Purpose : This change will comment out the financial year 2022 budget rates as they are 
								  no longer needed						  
**************************************************************************************************************************/

CREATE PROC [lab_ir].[sp_IR_FX_Rates] AS

BEGIN

DELETE from lab_ir.IR_FX_Rates

--FX22Rates_23Nov21 starts

--INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('United Kingdom','GBP','FY21 Budget',1.28727428571429);
--INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Thailand','THB','FY21 Budget',0.032205);
--INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Lithuania','LTL','FY21 Budget',0.345171);
--INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Mexico','MXN','FY21 Budget',0.043527);
--INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Chile','CLP','FY21 Budget',0.001288);
--INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('European Union (Euro)','EUR','FY21 Budget',1.14990207142857);
--INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Norway','NOK','FY21 Budget',0.111768);
--INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Netherlands','EUR','FY21 Budget',1.14990207142857);

--FX22Rates_23Nov21 ends


-- FX22Rates starts

-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('UAE','AED','FY22 Budget',0.272121)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Brazil','BRL','FY22 Budget',0.170326)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Canada','CAD','FY22 Budget',0.796181)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Switzerland','CHF','FY22 Budget',1.070503)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Chile','CLP','FY22 Budget',0.00139)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('China','RMB','FY22 Budget',0.148385)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Czech Republic','CZK','FY22 Budget',0.04484)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Algeria ','DZD','FY22 Budget',0.007466)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Egypt','EGP','FY22 Budget',0.056681)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Europe','EUR','FY22 Budget',1.182679)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('United Kingdom','GBP','FY22 Budget',1.379971)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Hong Kong','HKD','FY22 Budget',0.128649)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Croatia','HRK','FY22 Budget',0.156026)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Lithuania','LTL','FY22 Budget',0.342519)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Mexico','MXN','FY22 Budget',0.0469)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Norway','NOK','FY22 Budget',0.11677)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Poland','PLN','FY22 Budget',0.25345)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Romania','RON','FY22 Budget',0.234097)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Sweden','SEK','FY22 Budget',0.114967)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Singapore','SGD','FY22 Budget',0.742622)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Thailand','THB','FY22 Budget',0.031854)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Turkey','TRL','FY22 Budget',0.097249)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Taiwan ','TWD','FY22 Budget',0.036295)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('United States of America','USD','FY22 Budget',1)
-- INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Uruguay','UYU','FY22 Budget',0.021351)

-- FX22Rates ends

-- FX23Rates starts

INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('UAE','AED','FY23 Budget',0.272273319)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Brazil','BRL','FY23 Budget',0.186706707)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Canada','CAD','FY23 Budget',0.771120608)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Switzerland','CHF','FY23 Budget',1.05331457)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Chile','CLP','FY23 Budget',0.001044472)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('China','RMB','FY23 Budget',0.146411212)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Czech Republic','CZK','FY23 Budget',0.039747423)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Algeria ','DZD','FY23 Budget',0.007083407)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Egypt','EGP','FY23 Budget',0.043978733)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Europe','EUR','FY23 Budget',1.011308451)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('United Kingdom','GBP','FY23 Budget',1.18257546)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Hong Kong','HKD','FY23 Budget',0.127766365)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Croatia','HRK','FY23 Budget',0.13444534)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Lithuania','LTL','FY23 Budget',0.292723423)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Mexico','MXN','FY23 Budget',0.048292092)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Norway','NOK','FY23 Budget',0.103415333)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Poland','PLN','FY23 Budget',0.202525534)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Romania','RON','FY23 Budget',0.199067568)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Sweden','SEK','FY23 Budget',0.095106504)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Singapore','SGD','FY23 Budget',0.719500552)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Thailand','THB','FY23 Budget',0.028058284)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Turkey','TRL','FY23 Budget',0.044111409)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Taiwan ','TWD','FY23 Budget',0.033509178)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('United States of America','USD','FY23 Budget',1)
INSERT INTO lab_ir.IR_FX_Rates(country_region,currency_code,source,transaction_currency) VALUES('Uruguay','UYU','FY23 Budget',0.023843792)

-- FX23Rates ends


END
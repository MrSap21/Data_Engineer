-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : insert_lab_ir.sql
-- Description : This procedure performs an INSERT to a lab_ir table
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                      
-- Name         Date           Description
-- Jeff Moss    30-SEP-2019    Created
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE lab_ir.insert_lab_ir 
 @MappingID [int]
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
BEGIN TRY
    DECLARE @SourceObjectSchema VARCHAR(254)
    ,       @SourceObjectName VARCHAR(254)
    ,       @TargetObjectSchema VARCHAR(254)
    ,       @TargetObjectName VARCHAR(254)
    ,       @JoinCondition VARCHAR(8000)
    ,       @SourceColumnsString VARCHAR(8000)
    ,       @TargetColumnsString VARCHAR(8000)
    ,       @log_message_text VARCHAR(8000)
    ,       @LabelContext VARCHAR(254)
    ,       @RowCount BIGINT
    
    exec dc_metadata.LogSystemLog @log_type = 'INFORMATION', @log_message = 'Starting lab_ir.insert_lab_ir.';
    SET @log_message_text = CONCAT('MappingID:',STR(@MappingID));
    exec dc_metadata.LogSystemLog @log_type = 'PARAMETERS', @log_message = @log_message_text;
    
    BEGIN
      exec dc_metadata.LogSystemLog @log_type = 'INFORMATION', @log_message = 'Mapping is enabled';
  
      -- Get mapping dataset details
      exec dc_metadata.GetMappingDataset 
	         @MappingID = @MappingID
	       , @SourceObjectSchema = @SourceObjectSchema OUTPUT
	       , @SourceObjectName = @SourceObjectName OUTPUT
	       , @TargetObjectSchema = @TargetObjectSchema OUTPUT
	       , @TargetObjectName = @TargetObjectName OUTPUT
	       , @JoinCondition = @JoinCondition OUTPUT
	  
      -- Get columns as string for Source dataset
      exec dc_metadata.GetSourceColumnsString 
	         @MappingID = @MappingID
	       , @ObjectSchema = @SourceObjectSchema
	       , @ObjectName = @SourceObjectName
	       , @ColumnsString = @SourceColumnsString OUTPUT

      -- Get columns as string for Target dataset
      exec dc_metadata.GetTargetColumnsString 
	         @MappingID = @MappingID
	       , @ObjectSchema = @TargetObjectSchema
	       , @ObjectName = @TargetObjectName
	       , @ColumnsString = @TargetColumnsString OUTPUT

      -- Truncate target table
      exec dc_metadata.TruncateTable 
	         @ObjectSchema = @TargetObjectSchema
	       , @ObjectName = @TargetObjectName

      -- Now insert the rows to target
      DECLARE @exec_sql NVARCHAR(MAX)
	  SET @exec_sql = CONCAT('INSERT INTO ',@TargetObjectSchema,'.',@TargetObjectName,' '
                            ,'( ',@TargetColumnsString
                            ,')  '
                            ,'SELECT ',@SourceColumnsString
                            ,' FROM  ',@SourceObjectSchema,'.',@SourceObjectName
	  				      ,' OPTION (LABEL = ''INSERT_lab_ir;MAPPINGID:',LTRIM(STR(@MappingID)),''')');

      SET @log_message_text = CONCAT('exec_sql:',@exec_sql);
   	  exec dc_metadata.LogSystemLog @log_type = 'INFORMATION', @log_message = @log_message_text;
      EXEC(@exec_sql);
      
	  -- Now get the rows affected...
      SET @LabelContext = CONCAT('insert_lab_ir;MAPPINGID:',@MappingID);
   	  exec dc_metadata.GetSQLRowCount @LabelContext = @LabelContext, @RowCount = @RowCount OUTPUT;

      SET @log_message_text = CONCAT('INSERT INTO Rows Processed:',@RowCount);
   	  exec dc_metadata.LogSystemLog @log_type = 'INFORMATION', @log_message = @log_message_text;

    END;
  
    exec dc_metadata.LogSystemLog @log_type = 'INFORMATION', @log_message = 'Ending lab_ir.insert_lab_ir.';

END TRY
BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
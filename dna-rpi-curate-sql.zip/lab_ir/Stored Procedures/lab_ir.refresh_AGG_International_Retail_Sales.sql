create proc lab_ir.refresh_AGG_International_Retail_Sales as
begin
TRUNCATE TABLE [lab_ir].[AGG_International_Retail_Sales]
INSERT INTO [lab_ir].[AGG_International_Retail_Sales]
SELECT * FROM [lab_ir].[vwAGG_International_Retail]
end
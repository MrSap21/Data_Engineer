﻿/*
************************************************************************************************************************
View Name : uk_btc_promotion_deal_View
Purpose : This view shows promotion deal Information for PowerBI
**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date : Modified By : Description
==========================================================================================================================
12-01-2022 : Somya Singh Inital Version
**************************************************************************************************************************
*/
CREATE VIEW [con_psa].[uk_btc_promotion_deal_View] AS
SELECT
 [row_id], 
 [promotion_number], 
 [deal_number], 
 [deal_four_digit_number], 
 [deal_type], 
 [object_description], 
 [currency], 
 [status], 
 [merchandise_category], 
 [date_from], 
 [date_to], 
 [start_time], 
 [finish_time], 
 [all_active_inactive_flag], 
 [mon_active_inactive_flag], 
 [tue_active_inactive_flag], 
 [wed_active_inactive_flag], 
 [thur_active_inactive_flag], 
 [fri_active_inactive_flag], 
 [sat_active_inactive_flag], 
 [sun_active_inactive_flag], 
 [message1], [message2], 
 [message_text1], 
 [message_text2], 
 [sales_organization], 
 [distribution_channel], 
 [price_list_type], 
 [active_inactive_flag1], 
 [active_inactive_flag2], 
 [last_changed_by], 
 [last_change_date], 
 [object_saved_flag], 
 [selection_flag], 
 [status2], 
 [call_lead_time], 
 [boots_prompt_till], 
 [bus_centre_merchandise_group], 
 [leg_deal_number], 
 [cost_allocation_type], 
 [gift_prompt_till], 
 [is_active_indicator], 
 [marketing_channel], 
 [disc_exempt_flag], 
 [priority], 
 [exempt_tills], 
 [etl_runlog_id], 
 [asset_id], 
 [record_source_id], 
 [row_status], 
 [created_timestamp], 
 [active_flag]
FROM [psa].[uk_btc_promotion_deal]
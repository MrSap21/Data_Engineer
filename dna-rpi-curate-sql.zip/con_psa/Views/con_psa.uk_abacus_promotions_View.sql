﻿/*
************************************************************************************************************************
View Name : uk_abacus_promotions_View
Purpose : This view shows promotions Information for PowerBI
**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date : Modified By : Description
==========================================================================================================================
12-01-2022 : Somya Singh Inital Version
**************************************************************************************************************************
*/
CREATE VIEW [con_psa].[uk_abacus_promotions_View] AS
SELECT
 [row_id], 
 [record_type], 
 [STORE_NUMBER], 
 [TILL_NUMBER], 
 [TILL_TXN_NUMBER], 
 [TILL_TXN_DATE], 
 [TILL_TXN_TIME], 
 [DEAL_NUMBER], 
 [EPOS_TXN_TYPE_FLAG], 
 [PROMOTION_NUMBER], 
 [DEAL_TIMES_QUALIFIED], 
 [ITEM_DEAL_COUNT], 
 [ITEM_TXN_UNITS], 
 [ITEM_CODE], 
 [SIGN_1], 
 [DEAL_REWARD_MONEY], 
 [SIGN_2], 
 [DEAL_REWARD_PTS], 
 [SIGN_3], 
 [ITEM_TXN_BASE_PTS], 
 [SIGN_4], 
 [ITEM_TXN_BASE_PTS_SPLIT], 
 [etl_runlog_id], 
 [asset_id], 
 [record_source_id], 
 [row_status], 
 [created_timestamp], 
 [active_flag]
FROM [psa].[uk_abacus_promotions]
﻿CREATE VIEW [con_psa].[uk_abacus_header_View] AS
SELECT 
/*
************************************************************************************************************************
View Name                    : uk_abacus_header_View
Purpose                      : This view shows Header Information for PowerBI
**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :       Modified By          : Description
==========================================================================================================================
16-12-2021   :  Devbrat Yadav              Inital Version
**************************************************************************************************************************
*/

      [row_id]
     ,[record_type]
     ,[STORE_NUMBER]
     ,[TILL_NUMBER]
     ,[TILL_TXN_NUMBER]
     ,[TILL_TXN_DATE]
     ,[TILL_TXN_TIME]
     ,[EPOS_TXN_TYPE_FLAG]
     ,[OPERATOR_ID]
     ,[CARD_NUMBER]
     ,[DISC_CARD_USER_FLG]
     ,[DISC_CARD_NUMBER]
     ,[ALL_IT_PTS_MULT_PC]
     ,[BTC_IT_PTS_MULT_PC]
     ,[SIGN]
     ,[POINTS_CHANGE]
     ,[MAIN_PAYMENT_METH]
     ,[VALIDATION_BARCODE]
     ,[CHANNEL]
     ,[SUBCHANNEL]
     ,[TRANSACTION_QUALIFIED_FLAG]
     ,[ERROR_IND]
     ,[ADCARD_PRESENTATION_METHOD]
     ,[etl_runlog_id]
     ,[asset_id]
     ,[record_source_id]
     ,[row_status]
     ,[created_timestamp]
     ,[active_flag]
  FROM [psa].[uk_abacus_header]
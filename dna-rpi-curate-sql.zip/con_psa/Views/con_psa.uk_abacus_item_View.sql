﻿CREATE VIEW [con_psa].[uk_abacus_item_View] AS
SELECT 
/*
************************************************************************************************************************
View Name                    : uk_abacus_item_View
Purpose                      : This view shows Item Information for PowerBI
**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :       Modified By          : Description
==========================================================================================================================
16-12-2021   :  Devbrat Yadav              Inital Version
**************************************************************************************************************************
*/

     [row_id]
    ,[record_type]
    ,[ITEM_CODE]
    ,[STORE_NUMBER]
    ,[TILL_NUMBER]
    ,[TILL_TXN_NUMBER]
    ,[TILL_TXN_DATE]
    ,[TILL_TXN_TIME]
    ,[SIGN]
    ,[SALES_UNITS]
    ,[SIGN_TISP]
    ,[SALES_AT_TISP]
    ,[SIGN_TESP]
    ,[SALES_AT_TESP]
    ,[SIGN_PROFIT]
    ,[EPOS_PROFIT]
    ,[SIGN_NCP]
    ,[SALES_AT_NCP]
    ,[SIGN_DISCPC]
    ,[SALE_ITEM_DISC_PC]
    ,[SIGN_ITEM]
    ,[ITEM_REDUCTION_AMT]
    ,[ITEM_DISC_ORIDE_FLG]
    ,[PRICE_ORIDE_IT_FLG]
    ,[SIGN_TAKINGS]
    ,[TAKINGS]
    ,[SIGN_REVENUE]
    ,[REVENUE]
    ,[SIGN_EPOS]
    ,[EPOS_PROFIT_ADJ]
    ,[SIGN_ITMPNTQTY]
    ,[ITEM_POINTS_QUANTITY]
    ,[SIGN_ITMPNTVAL]
    ,[ITEM_POINTS_VALUE]
    ,[etl_runlog_id]
    ,[asset_id]
    ,[record_source_id]
    ,[row_status]
    ,[created_timestamp]
    ,[active_flag]
  FROM [psa].[uk_abacus_item]
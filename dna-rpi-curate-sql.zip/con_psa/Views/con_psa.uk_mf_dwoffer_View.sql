﻿/*
************************************************************************************************************************
View Name : psa.uk_mf_dwoffer_View
Purpose : This view shows dwoffer Information for PowerBI
**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date : Modified By : Description
==========================================================================================================================
12-01-2022 : Somya Singh Inital Version
**************************************************************************************************************************
*/
CREATE VIEW [con_psa].[uk_mf_dwoffer_View] AS
SELECT
 [row_id], 
 [ITEM_CODE], 
 [ITEM_DESCRIPTION], 
 [ITEM_STATUS], 
 [ITEM_INTRO_DATE], 
 [ITEM_DELETION_DATE], 
 [UNIT_NCP], 
 [OFFER_START_DATE], 
 [OFFER_END_DATE], 
 [IBMSNAP_LOGMARKER], 
 [ADV_POINTS_EXEMPT], 
 [ADV_REDEEMABLE_FLG], 
 [OWN_BRAND_FLAG], 
 [CURRENT_STD_TISP], 
 [BUSINESS_CENTRE_NO], 
 [CONCEPT_GROUP_NO], 
 [CONCEPT_SEQ_NO], 
 [MERCH_GROUP_NO], 
 [PRODUCT_GROUP_NO], 
 [MERCHANDISE_GRP_NO], 
 [MERCH_RANGE], 
 [MERCH_SUB_RANGE], 
 [EAN_CODE], 
 [etl_runlog_id], 
 [asset_id], 
 [record_source_id], 
 [row_status], 
 [created_timestamp], 
 [active_flag]
FROM [psa].[uk_mf_dwoffer]
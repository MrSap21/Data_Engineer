﻿/*
************************************************************************************************************************
View Name                    : BOPSAPPMAN_BUKOPTMI_BUK_Opticians_Transaction_Sales_Price_Data_Opticians_MI_Incr_View
Purpose                      : This view shows Optician Transaction Sales Information for PowerBI
**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :       Modified By          : Description
==========================================================================================================================
09-02-2021   :  Gauri Nair          Inital Version
**************************************************************************************************************************
*/

CREATE VIEW [con_psa].[BOPSAPPMAN_BUKOPTMI_BUK_Opticians_Transaction_Sales_Price_Data_Opticians_MI_Incr_View] AS
SELECT * FROM [psa].[BOPSAPPMAN_BUKOPTMI_BUK_Opticians_Transaction_Sales_Price_Data_Opticians_MI_Incr]
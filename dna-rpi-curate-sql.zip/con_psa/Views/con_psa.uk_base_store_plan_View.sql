﻿CREATE VIEW [con_psa].[uk_base_store_plan_View] AS
SELECT 
/*
************************************************************************************************************************
View Name                    : uk_base_store_plan_View
Purpose                      : This view shows Plan Information for PowerBI
**************************************************************************************************************************
**************************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :       Modified By          : Description
==========================================================================================================================
13-11-2021   :  Devbrat Yadav              Inital Version
**************************************************************************************************************************
*/


 	[row_id],
	[calendar_week],
	[fiscal_week],
	[store],
	[floor_plan],
	[pog_id],
	[build_size],
	[sales_qty],
	[sales_tisp],
	[sales_tesp],
	[sales_epgp],
	[instances],
	[modular_build],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
FROM [psa].[uk_base_store_plan];
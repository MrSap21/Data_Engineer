﻿CREATE TABLE [con_tpm].[DL_Payments_GB]
(
	[AccountCode] [nvarchar](255) NULL,
	[SupplierCode] [nvarchar](255) NULL,
	[InvoiceNumber] [nvarchar](255) NULL,
	[InvoiceDate] [nvarchar](255) NULL,
	[InvoiceDescription] [nvarchar](255) NULL,
	[ProductDesc] [nvarchar](255) NULL,
	[TaxLevelCode] [nvarchar](255) NULL,
	[ERPInvoiceID] [nvarchar](255) NULL,
	[CustomerLevelMatching] [nvarchar](255) NULL,
	[DocType] [nvarchar](255) NULL,
	[PromoID] [nvarchar](255) NULL,
	[Value] [nvarchar](255) NULL,
	[Attribute1] [nvarchar](255) NULL,
	[Attribute2] [nvarchar](255) NULL,
	[Attribute3] [nvarchar](255) NULL,
	[Attribute4] [nvarchar](255) NULL,
	[Attribute5] [nvarchar](255) NULL,
	[Attribute6] [nvarchar](255) NULL,
	[Attribute7] [nvarchar](255) NULL,
	[Attribute8] [nvarchar](255) NULL,
	[Attribute9] [nvarchar](255) NULL,
	[Attribute10] [nvarchar](255) NULL,
	[Attachment_1] [nvarchar](255) NULL,
	[Attachment_2] [nvarchar](255) NULL,
	[InvoiceCreatedDate] [nvarchar](255) NULL,
	[InvoiceCreatedBy] [nvarchar](255) NULL,
	[Region] [nvarchar](255) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿/*****************************************************************
Abhilaksh Agnihotri 		  Initial Version 1.0
*************************************************************************/

CREATE TABLE [con_tpm].[DL_PRODUCT_MEMBER_GB]
(
	[MemberCode] [nvarchar](128) NOT NULL,
	[MemberDesc] [nvarchar](128) NULL,
	[LevelCode] [nvarchar](128) NOT NULL,
	[UOM1] [nvarchar](128) NOT NULL,
	[UOM2] [nvarchar](128) NOT NULL,
	[UOM3] [nvarchar](128) NOT NULL,
	[UnitPerUom0] [nvarchar](128) NOT NULL,
	[IsNPD] [nvarchar](128) NOT NULL,
	[FormatSize] [nvarchar](50) NULL,
	[IsActive] [nvarchar](128) NOT NULL,
	[Custom] [nvarchar](50) NULL,
	[ExternalCreationDate] [nvarchar](50) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿/*****************************************************************
Archana Rajendran		  Initial Version 1.0
*************************************************************************/

CREATE TABLE [con_tpm].[DL_Actuals_SI_SO_GB]
(
	[From_Company_Code] [nvarchar](80) NULL,
	[From_Company_Level_Code] [nvarchar](80) NULL,
	[C1_Code] [nvarchar](80) NULL,
	[P1_Code] [nvarchar](80) NULL,
	[C0_Code] [nvarchar](80) NOT NULL,
	[P0_Code] [nvarchar](80) NOT NULL,
	[Metric_Code] [nvarchar](80) NULL,
	[PromoID] [nvarchar](80) NULL,
	[From_Date] [nvarchar](100) NULL,
	[To_Date] [nvarchar](100) NULL,
	[Value] [nvarchar](255) NOT NULL,
	[Region] [nvarchar](255) NOT NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
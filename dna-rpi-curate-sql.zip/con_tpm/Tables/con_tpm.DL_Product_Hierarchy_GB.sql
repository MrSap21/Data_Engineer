﻿/*****************************************************************
	Bikram Mondal 		  Initial Version 1.0
*************************************************************************/

CREATE TABLE [con_tpm].[DL_Product_Hierarchy_GB]
(
	[HierarchyCode] [nvarchar](255) NOT NULL,
	[MemberCode] [nvarchar](255) NULL,
	[MemberLevel] [nvarchar](255) NULL,
	[ParentMemberCode] [nvarchar](255) NULL,
	[ParentMemberLevel] [nvarchar](255) NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
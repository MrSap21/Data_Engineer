﻿/*****************************************************************
		Abhilaksh Agnihotri 		  Initial Version 1.0
*************************************************************************/

CREATE TABLE [con_tpm].[DL_CUSTOMER_MEMBER_GB]
(
	[MemberCode] [nvarchar](128) NOT NULL,
	[MemberDesc] [nvarchar](128) NOT NULL,
	[LevelCode] [nvarchar](128) NOT NULL,
	[TerritoryCode] [nvarchar](255) NULL,
	[CustomerTypeID] [nvarchar](50) NULL,
	[PriceListCode] [nvarchar](50) NULL,
	[IsActive] [nvarchar](50) NULL,
	[ActiveForPayments] [nvarchar](50) NULL,
	[ExternalCreationDate] [nvarchar](50) NULL,
	[SwitchDateSI] [nvarchar](50) NULL,
	[SwitchDateSO] [nvarchar](50) NULL,
	[Region] [nvarchar](128) NOT NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿/*****************************************************************
	Bikram Mondal 		  Initial Version 1.0
*************************************************************************/


create table [con_tpm].[DL_Customer_Hierarchy_GB]
(
[HierarchyCode] [nvarchar] (255) not null,
[MemberCode] 	[nvarchar] (255) not null,
[MemberLevel]	[nvarchar] (255) not null,
[ParentMemberCode]	[nvarchar] (255)  not null,
[ParentMemberLevel]	[nvarchar] (255) not null,
[Region]	[nvarchar] (255) not null,
[created_timestamp] [datetime] null,
[ETLRunLogId] [bigint] not null
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
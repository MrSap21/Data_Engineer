﻿CREATE TABLE [con_tpm].[DL_Standard_Cost_GB]
(
	[P1] [nvarchar](255) NOT NULL,
	[C1] [nvarchar](255) NULL,
	[Territory_Code] [nvarchar](255) NULL,
	[Metric_Code] [nvarchar](255) NULL,
	[From_Date] [nvarchar](255) NULL,
	[To_Date] [nvarchar](255) NULL,
	[Include] [nvarchar](255) NULL,
	[Value] [nvarchar](255) NULL,
	[Region] [nvarchar](255) NOT NULL,
	[created_timestamp] [datetime] NULL,
	[ETLRunLogId] [bigint] NOT NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
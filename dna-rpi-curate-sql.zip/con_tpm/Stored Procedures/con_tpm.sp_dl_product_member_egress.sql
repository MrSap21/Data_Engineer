﻿CREATE PROC [con_tpm].[sp_dl_product_member_egress] @pETLRunLogID [NVARCHAR](255) AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[sp_dl_product_member_egress]
  Purpose                : Insert into datamart table from serve table.
  Target Table           : con_tpm.[DL_PRODUCT_MEMBER_GB]
  ********************************************************************************************************************
  Default values
  ************************************************************************************************************
  ETLRunLogID                 : @pETLRunLogID passed as an argument
  
  *************************************************************************************************************
  
  Abhilaksh Agnihotri  Initial Versio 1.0
  Bikram Mondal    Added Data cleansing logic version 1.1
  19/07/2023    Shivangi Arora            Updated logic as per new hierarchies given for WBAPH and WBAPH2. Tag : 'CRQ82130_WBAPH2hierarchychanges'
  
  
  Note:The LOVRecordSourceID to be changed from 12023 to 12025 once the STEP project goes live.
  */
  BEGIN
  BEGIN TRY
	DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
      declare @vNumRows         AS INT           = 0;                                           
 
      DECLARE @execsql              NVARCHAR(max),
              @curr_timestamp       NVARCHAR(max),
              @columnNames          NVARCHAR(max),
			  @project_name       as  NVARCHAR(max)='TPM',
              @feed_id              INT,
			  @tempTableName                       nvarchar(max)
			  
			  SET @tempTableName = 'tempdb..#DL_PRODUCT_MEMBER_GB_Temp'
		IF OBJECT_ID('[con_tpm].[DL_PRODUCT_MEMBER_GB]') IS NOT NULL
          BEGIN
          EXEC ('TRUNCATE TABLE [con_tpm].[DL_PRODUCT_MEMBER_GB]')
		  PRINT 'TRUNCATED DATAMART TABLE SUCCESSFULLY.'
          END   
		 
		IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
		set @execsql='select a.* into '+@tempTableName+' from [CON_TPM].[DL_PRODUCT_MEMBER_GB] a WHERE 1=2 '
	EXEC(@execsql)
      
			   
      SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
       
      SET @columnNames = (SELECT String_agg('[' + column_name + ']', ',')
                          FROM   information_schema.columns
                          WHERE  table_schema = 'con_tpm'
                                 AND table_name = 'DL_PRODUCT_MEMBER_GB')
     
     

      
	  BEGIN TRANSACTION
		
         
          PRINT 'Inserting data to the datamart table started';   

        insert into #DL_PRODUCT_MEMBER_GB_Temp 
		([MemberCode] ,
[MemberDesc] ,
[LevelCode]	 ,
[UOM1],
[UOM2],
[UOM3],
[UnitPerUom0],
[IsNPD],
[FormatSize],
[IsActive],
[Custom],
[ExternalCreationDate],
[created_timestamp],
[ETLRunLogId]) 
select 
CASE WHEN len(Item) >50 THEN substring(Item,1,50) ELSE Item END as [MemberCode],
CASE WHEN len(Item_Description) >50 THEN substring(Item_Description,1,50) ELSE Item_Description END as [MemberDesc],
'Sku' as [LevelCode],
1 as [UOM1],
1 as [UOM2],
1 as [UOM3],
1 as [UnitPerUom0],
0 as [IsNPD],
null as [FormatSize],
1 as [IsActive],
null as [Custom],
null as [ExternalCreationDate],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId]
from(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check ,
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check , 
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check , --CRQ82130_WBAPH2hierarchychanges
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,

--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
RefPT.[LOVKey] Product_Type,  --CRQ82130_WBAPH2hierarchychanges 
RefSC.[LOVKey] Sub_Category,  --CRQ82130_WBAPH2hierarchychanges 
RefRC.[LOVKey] Category,      --CRQ82130_WBAPH2hierarchychanges 
RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  AND
--main.Category_to_Brand_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND --CRQ82130_WBAPH2hierarchychanges 
main.Brand_to_BrandGroup_check = 1		

union

select 
CASE WHEN len(Item_Parent) >50 THEN substring(Item_Parent,1,50) ELSE Item_Parent END as [MemberCode],
CASE WHEN len(Item_Parent) >50 THEN substring(Item_Parent,1,50) ELSE Item_Parent END as [MemberDesc],
'SkuGroup' as [LevelCode],
1 as [UOM1],
1 as [UOM2],
1 as [UOM3],
1 as [UnitPerUom0],
0 as [IsNPD],
null as [FormatSize],
1 as [IsActive],
null as [Custom],
null as [ExternalCreationDate],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId]
from(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check ,
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check , 
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check , --CRQ82130_WBAPH2hierarchychanges
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
RefPT.[LOVKey] Product_Type,  --CRQ82130_WBAPH2hierarchychanges 
RefSC.[LOVKey] Sub_Category,  --CRQ82130_WBAPH2hierarchychanges 
RefRC.[LOVKey] Category,      --CRQ82130_WBAPH2hierarchychanges 
RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  AND
--main.Category_to_Brand_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND --CRQ82130_WBAPH2hierarchychanges 
main.Brand_to_BrandGroup_check = 1


union

select 
CASE WHEN len(Product_Type) >50 THEN substring(Product_Type,1,50) ELSE Product_Type END as [MemberCode],
CASE WHEN len(Product_Type) >50 THEN substring(Product_Type,1,50) ELSE Product_Type END as [MemberDesc],
'WBAProductType' as [LevelCode],
1 as [UOM1],
1 as [UOM2],
1 as [UOM3],
1 as [UnitPerUom0],
0 as [IsNPD],
null as [FormatSize],
1 as [IsActive],
null as [Custom],
null as [ExternalCreationDate],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId]
from(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check ,
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check , 
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check , --CRQ82130_WBAPH2hierarchychanges
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
RefPT.[LOVKey] Product_Type,  --CRQ82130_WBAPH2hierarchychanges 
RefSC.[LOVKey] Sub_Category,  --CRQ82130_WBAPH2hierarchychanges 
RefRC.[LOVKey] Category,      --CRQ82130_WBAPH2hierarchychanges 
RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  AND
--main.Category_to_Brand_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND --CRQ82130_WBAPH2hierarchychanges 
main.Brand_to_BrandGroup_check = 1

union
select 
CASE WHEN len(Sub_Category) >50 THEN substring(Sub_Category,1,50) ELSE Sub_Category END as [MemberCode],
CASE WHEN len(Sub_Category) >50 THEN substring(Sub_Category,1,50) ELSE Sub_Category END as [MemberDesc],
'WBASubCategory' as [LevelCode],
1 as [UOM1],
1 as [UOM2],
1 as [UOM3],
1 as [UnitPerUom0],
0 as [IsNPD],
null as [FormatSize],
1 as [IsActive],
null as [Custom],
null as [ExternalCreationDate],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId]
from(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check ,
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check , 
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check , --CRQ82130_WBAPH2hierarchychanges
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
RefPT.[LOVKey] Product_Type,  --CRQ82130_WBAPH2hierarchychanges 
RefSC.[LOVKey] Sub_Category,  --CRQ82130_WBAPH2hierarchychanges 
RefRC.[LOVKey] Category,      --CRQ82130_WBAPH2hierarchychanges 
RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  AND
--main.Category_to_Brand_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND --CRQ82130_WBAPH2hierarchychanges 
main.Brand_to_BrandGroup_check = 1	

union
select 
CASE WHEN len(Category) >50 THEN substring(Category,1,50) ELSE Category END as [MemberCode],
CASE WHEN len(Category) >50 THEN substring(Category,1,50) ELSE Category END as [MemberDesc],
'Segment' as [LevelCode],
1 as [UOM1],
1 as [UOM2],
1 as [UOM3],
1 as [UnitPerUom0],
0 as [IsNPD],
null as [FormatSize],
1 as [IsActive],
null as [Custom],
null as [ExternalCreationDate],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId]

from(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check ,
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check , 
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check , --CRQ82130_WBAPH2hierarchychanges
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
RefPT.[LOVKey] Product_Type,  --CRQ82130_WBAPH2hierarchychanges 
RefSC.[LOVKey] Sub_Category,  --CRQ82130_WBAPH2hierarchychanges 
RefRC.[LOVKey] Category,      --CRQ82130_WBAPH2hierarchychanges 
RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  AND
--main.Category_to_Brand_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND --CRQ82130_WBAPH2hierarchychanges 
main.Brand_to_BrandGroup_check = 1

union 
select 
CASE WHEN len(ReportingBrand) >50 THEN substring(ReportingBrand,1,50) ELSE ReportingBrand END as [MemberCode],
CASE WHEN len(ReportingBrand) >50 THEN substring(ReportingBrand,1,50) ELSE ReportingBrand END as [MemberDesc],
'Brand' as [LevelCode],
1 as [UOM1],
1 as [UOM2],
1 as [UOM3],
1 as [UnitPerUom0],
0 as [IsNPD],
null as [FormatSize],
1 as [IsActive],
null as [Custom],
null as [ExternalCreationDate],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId]
from(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check ,
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check , 
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check , --CRQ82130_WBAPH2hierarchychanges
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
RefPT.[LOVKey] Product_Type,  --CRQ82130_WBAPH2hierarchychanges 
RefSC.[LOVKey] Sub_Category,  --CRQ82130_WBAPH2hierarchychanges 
RefRC.[LOVKey] Category,      --CRQ82130_WBAPH2hierarchychanges 
RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  AND
--main.Category_to_Brand_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND --CRQ82130_WBAPH2hierarchychanges 
main.Brand_to_BrandGroup_check = 1

union 
select 
CASE WHEN len(BrandGroup) >50 THEN substring(BrandGroup,1,50) ELSE BrandGroup END as [MemberCode],
CASE WHEN len(BrandGroup) >50 THEN substring(BrandGroup,1,50) ELSE BrandGroup END as [MemberDesc],
'BrandGroup' as [LevelCode],  ----CRQ82130_WBAPH2hierarchychanges
1 as [UOM1],
1 as [UOM2],
1 as [UOM3],
1 as [UnitPerUom0],
0 as [IsNPD],
null as [FormatSize],
1 as [IsActive],
null as [Custom],
null as [ExternalCreationDate],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId]
from(


select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check ,
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check , 
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check , --CRQ82130_WBAPH2hierarchychanges
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
RefPT.[LOVKey] Product_Type,  --CRQ82130_WBAPH2hierarchychanges 
RefSC.[LOVKey] Sub_Category,  --CRQ82130_WBAPH2hierarchychanges 
RefRC.[LOVKey] Category,      --CRQ82130_WBAPH2hierarchychanges 
RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  AND
--main.Category_to_Brand_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND --CRQ82130_WBAPH2hierarchychanges 
main.Brand_to_BrandGroup_check = 1


insert into #DL_PRODUCT_MEMBER_GB_Temp values
('Category','Category','AllSkus',1,1,1,1,0,null,1,null,null,@curr_timestamp,@pETLRunLogID)  --CRQ82130_WBAPH2hierarchychanges




	
          PRINT( 'Inserted records into datamart table '  )
		  
		  insert into [con_tpm].[DL_PRODUCT_MEMBER_GB]
			([MemberCode] ,
[MemberDesc] ,
[LevelCode]	 ,
[UOM1],
[UOM2],
[UOM3],
[UnitPerUom0],
[IsNPD],
[FormatSize],
[IsActive],
[Custom],
[ExternalCreationDate],
[created_timestamp],
[ETLRunLogId])
select  
[MemberCode] ,
[MemberDesc] ,
[LevelCode]	 ,
[UOM1],
[UOM2],
[UOM3],
[UnitPerUom0],
[IsNPD],
[FormatSize],
[IsActive],
[Custom],
[ExternalCreationDate],
[created_timestamp],
[ETLRunLogId]
			from #DL_PRODUCT_MEMBER_GB_Temp
				 			
			INSERT into   psa.egress_sp_logs VALUES(@project_name,'DL_PRODUCT_MEMBER_GB',@pETLRunLogID,@curr_timestamp)
			
          SELECT @vProcedureStatus  AS ProcedureStatus,
                 @vProcedureMessage AS ProcedureMessage;
				 

                              
       COMMIT TRANSACTION
	   
	   END TRY

      BEGIN CATCH
	IF(@@TRANCOUNT>0)
	ROLLBACK TRANSACTION;
	
			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),
			ERROR_SEVERITY(),'[sp_dl_product_member_egress]',
			ERROR_MESSAGE(),GETDATE();				
						
    END CATCH;
  END
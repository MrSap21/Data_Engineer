﻿CREATE PROC [con_tpm].[sp_dl_standard_cost_egress] @pETLRunLogID [NVARCHAR](255) AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[sp_dl_standard_cost_egress]

  Target Table           : con_tpm.[DL_Standard_Cost_GB]
  ********************************************************************************************************************
  Default values
  ************************************************************************************************************
  ETLRunLogID                 : @pETLRunLogID passed as an argument
  
  *************************************************************************************************************
  05/0/2022   Manaswi Ghosh      Initial Version
  *************************************************************************************************************
  */
  BEGIN
  BEGIN TRY
  IF OBJECT_ID('[con_tpm].[DL_Standard_Cost_GB]') IS NOT NULL
          BEGIN
          EXEC ('TRUNCATE TABLE [con_tpm].[DL_Standard_Cost_GB]')
		  PRINT 'TRUNCATED DATAMART TABLE SUCCESSFULLY.'
          END 
		
   
      DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
      declare @vNumRows         AS INT           = 0;                                           
 
      DECLARE @execsql              NVARCHAR(max),
			  @tempTableName        nvarchar(max),
			  @feed_name             as NVARCHAR(max)='DL_Standard_Cost_GB',
              @curr_timestamp       NVARCHAR(max),
              @columnNames          NVARCHAR(max),
			  @project_name       as  NVARCHAR(max)='TPM',
              @feed_id              INT
	  SET @tempTableName = 'tempdb..#DL_Standard_Cost_GB_Temp'
	  IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
	
	--creating temp table to store records with created_timestamp greater than prev_createdTimeStamp along with row numbers(partitioned by businesskeys and ordered in ascending order of created_timestamp)
	set @execsql='select a.* into '+@tempTableName+' from [con_tpm].[DL_Standard_Cost_GB] a WHERE 1=2 '
		
	EXEC(@execsql)
	
			   
      SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
       
      SET @columnNames = (SELECT String_agg('[' + column_name + ']', ',')
                          FROM   information_schema.columns
                          WHERE  table_schema = 'con_tpm'
                                 AND table_name = 'DL_Standard_Cost_GB')
     
	 print  @columnNames
     

      
	  BEGIN TRANSACTION
	  
	  
	  PRINT 'Inserting data to the datamart table started';  		  -- Incremental data insertion
		  
        insert into #DL_Standard_Cost_GB_Temp 
    ([P1],
	[C1],
	[Territory_Code],
	[Metric_Code],
	[From_Date],
	[To_Date],
	[Include],
	[Value],
	[Region],
	[created_timestamp],
	[ETLRunLogId])

select 
abc.MATNR [P1],
'' [C1],
(case when abc.Region = 'North America' then 'US' else 'UK' end)
 [Territory_Code],
6001 [Metric_Code],
format(abc.fromdate,'yyyyMMdd') [From_Date],
'20991231' [To_Date],
1 [Include],
abc.VALUE_ [Value],
abc.Region [Region],
@curr_timestamp [created_timestamp],
@pETLRunLogID [ETLRunLogId]
from
(select us.mtnr MATNR, us.val as VALUE_,us.reg as Region,us.pl plant, us.fromdate as fromdate from 
(
select a.matnr mtnr, a.Plant pl, a.value1 val, a.region reg,a.startdate fromdate from
(
select  main.MATNR as matnr,main.Plant as Plant,
(case when main.indicator = 'S' then main.StdPrice
when main.indicator = 'V' then main.MovPrice
end) as value1, 
(case when main.Plant in ('P220','P225','P22V') then 'North America'
when main.Plant in ('P101','P10V','P150','P260','P102') then 'UK (Incl.ROI)' end) region,
(case when main.indicator = 'S' then main.sfrom_date
when main.indicator = 'V' then main.mfrom_date
end) startdate
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
StdPerValue.SCDstartdate as sfrom_date,
StdPerValue.SCDenddate as stodate,
MovPerValue.value as MovPrice,
MovPerValue.SCDstartdate as mfrom_date,
MovPerValue.SCDenddate as mtodate
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'	
) main
where main.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main.Indicator !='') a
where a.region = 'North America'
and a.matnr in 
(select x.matnr from (select  main.MATNR as matnr,main.Plant as Plant,
(case when main.indicator = 'S' then main.StdPrice
when main.indicator = 'V' then main.MovPrice
end) as value1, 
(case when main.Plant in ('P220','P225','P22V') then 'North America'
when main.Plant in ('P101','P10V','P150','P260','P102') then 'UK (Incl.ROI)' end) region
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
MovPerValue.value as MovPrice
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'	
) main
where main.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main.Indicator !='' )x 
group by x.matnr having count(x.matnr)>1)) us where us.pl = 'P220'

union 

select uk.mtnr MATNR, uk.val as VALUE_,uk.reg as Region, uk.pl plant, uk.fromdate fromdate 
from (
select a.matnr mtnr, a.Plant pl, a.value1 val, a.region reg,a.startdate fromdate
 from
(
select  main.MATNR as matnr,main.Plant as Plant,
(case when main.indicator = 'S' then main.StdPrice
when main.indicator = 'V' then main.MovPrice
end) as value1, 
(case when main.Plant in ('P220','P225','P22V') then 'North America'
when main.Plant in ('P101','P10V','P150','P260','P102') then 'UK (Incl.ROI)' end) region,
(case when main.indicator = 'S' then main.sfrom_date
when main.indicator = 'V' then main.mfrom_date
end) startdate
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
StdPerValue.SCDstartdate as sfrom_date,
StdPerValue.SCDenddate as stodate,
StdPerValue.SCDActiveFlag as sflag,
MovPerValue.value as MovPrice,
MovPerValue.SCDstartdate as mfrom_date,
MovPerValue.SCDenddate as mtodate,
StdPerValue.SCDActiveFlag as mflag
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'	
) main
where main.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main.Indicator !='') a
where a.region = 'UK (Incl.ROI)'
and a.matnr in 
(select x.matnr from (select  main.MATNR as matnr,main.Plant as Plant,
(case when main.indicator = 'S' then main.StdPrice
when main.indicator = 'V' then main.MovPrice
end) as value1, 
(case when main.Plant in ('P220','P225','P22V') then 'North America'
when main.Plant in ('P101','P10V','P150','P260','P102') then 'UK (Incl.ROI)' end) region
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
MovPerValue.value as MovPrice
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'	
) main
where main.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main.Indicator !='' )x 
group by x.matnr having count(x.matnr)>1)) uk where uk.pl = 'P101'

union

select a.matnr MATNR,  a.value1 VALUE_, a.region Region, a.Plant plant, a.startdate fromdate
 from
(
select  main.MATNR as matnr,main.Plant as Plant,
(case when main.indicator = 'S' then main.StdPrice
when main.indicator = 'V' then main.MovPrice
end) as value1, 
(case when main.Plant in ('P220','P225','P22V') then 'North America'
when main.Plant in ('P101','P10V','P150','P260','P102') then 'UK (Incl.ROI)' end) region,
(case when main.indicator = 'S' then main.sfrom_date
when main.indicator = 'V' then main.mfrom_date
end) startdate
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
StdPerValue.SCDstartdate as sfrom_date,
StdPerValue.SCDenddate as stodate,
MovPerValue.value as MovPrice,
MovPerValue.SCDstartdate as mfrom_date,
MovPerValue.SCDenddate as mtodate
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'	
) main
where main.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main.Indicator !='') a
where a.matnr in (select x.matnr from (select  main.MATNR as matnr,main.Plant as Plant,
(case when main.indicator = 'S' then main.StdPrice
when main.indicator = 'V' then main.MovPrice
end) as value1, 
(case when main.Plant in ('P220','P225','P22V') then 'North America'
when main.Plant in ('P101','P10V','P150','P260','P102') then 'UK (Incl.ROI)' end) region
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
MovPerValue.value as MovPrice
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'
	) main
where main.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main.Indicator !='' )x 
group by x.matnr having count(x.matnr)=1)
union

select row1.mtnr MATNR, row1.val as VALUE_,row1.reg as Region, row1.pl plant, row1.fromdate fromdate 
from (
select a.matnr mtnr, a.Plant pl, a.value1 val, a.region reg,a.startdate fromdate
 from
(
select  main1.MATNR as matnr,main1.Plant as Plant,
(case when main1.indicator = 'S' then main1.StdPrice
when main1.indicator = 'V' then main1.MovPrice
end) as value1, 
(case when main1.Plant in ('P220','P225','P22V') then 'North America'
when main1.Plant in ('P101','P10V','P150','P260','P102') then 'Rest of World' end) region,
(case when main1.indicator = 'S' then main1.sfrom_date
when main1.indicator = 'V' then main1.mfrom_date
end) startdate
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
StdPerValue.SCDstartdate as sfrom_date,
StdPerValue.SCDenddate as stodate,
StdPerValue.SCDActiveFlag as sflag,
MovPerValue.value as MovPrice,
MovPerValue.SCDstartdate as mfrom_date,
MovPerValue.SCDenddate as mtodate,
StdPerValue.SCDActiveFlag as mflag
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'	
) main1
where main1.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main1.Indicator !='') a
where a.region = 'Rest of World'
and a.matnr in 
(select x.matnr from (select  main1.MATNR as matnr,main1.Plant as Plant,
(case when main1.indicator = 'S' then main1.StdPrice
when main1.indicator = 'V' then main1.MovPrice
end) as value1, 
(case when main1.Plant in ('P220','P225','P22V') then 'North America'
when main1.Plant in ('P101','P10V','P150','P260','P102') then 'Rest of World' end) region
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
MovPerValue.value as MovPrice
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'	
) main1
where main1.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main1.Indicator !='' )x 
group by x.matnr having count(x.matnr)>1)) row1 where row1.pl = 'P101'

union

select row2.matnr MATNR,  row2.value1 VALUE_, row2.region Region, row2.Plant plant, row2.startdate fromdate
 from
(
select  main1.MATNR as matnr,main1.Plant as Plant,
(case when main1.indicator = 'S' then main1.StdPrice
when main1.indicator = 'V' then main1.MovPrice
end) as value1, 
(case when main1.Plant in ('P220','P225','P22V') then 'North America'
when main1.Plant in ('P101','P10V','P150','P260','P102') then 'Rest of World' end) region,
(case when main1.indicator = 'S' then main1.sfrom_date
when main1.indicator = 'V' then main1.mfrom_date
end) startdate
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
StdPerValue.SCDstartdate as sfrom_date,
StdPerValue.SCDenddate as stodate,
MovPerValue.value as MovPrice,
MovPerValue.SCDstartdate as mfrom_date,
MovPerValue.SCDenddate as mtodate
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'	
) main1
where main1.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main1.Indicator !='') row2
where row2.matnr in (select x.matnr from (select  main1.MATNR as matnr,main1.Plant as Plant,
(case when main1.indicator = 'S' then main1.StdPrice
when main1.indicator = 'V' then main1.MovPrice
end) as value1, 
(case when main1.Plant in ('P220','P225','P22V') then 'North America'
when main1.Plant in ('P101','P10V','P150','P260','P102') then 'Rest of World' end) region
from
(
SELECT 
SR.SourceKey as Plant,
P.SourceKey as MATNR,
ind.Value as Indicator,
StdPerValue.value as StdPrice,
MovPerValue.value as MovPrice
FROM
ser.ProductSiteRoleRelationship PSRR
INNER JOIN
ser.SITEROLE SR
ON
PSRR.SiteRoleId = SR.SiteRoleId
AND
PSRR.LOVRelationshipTypeId = 
(
select LovID 
from ser.RefLOV where 
LOVKey = 'Associated With'  AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Relationship Type' and [RecordSourceId] = 12012
And ActiveFlag = 1) AND [RecordSourceId] = 12012 AND ActiveFlag = 1
)
AND
SR.LOVRoleId = (
select LovID from ser.RefLOV where LOVKey = 'Plant' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where LOVSetName = 'Role') and RecordSourceId=12012
)

AND 
PSRR.LOVRecordSourceId = 12025
AND PSRR.SCDActiveFlag = 'Y'
AND 
SR.LOVRecordSourceId = 12025
AND SR.SCDActiveFlag = 'Y'

INNER JOIN ser.PRODUCT P
ON 
P.ProductID = PSRR.ProductID
and P. LOVRecordSourceID = 12025
and P.SCDActiveFlag = 'Y'

INNER JOIN ser.ProductSiteRoleRelationshipIndicator ind
ON ind.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and ind.LOVIndicatorId = 
(
select LovID from ser.RefLOV where 
LOVKey = 'price_control' AND 
LovSetID = (select LovSetID from ser.RefLOVSet where 
LOVSetName = 'Indicator - GBSAP Product'
and RecordSourceID = 12012)
)

Left outer join ser.ProductSiteRoleRelationshipMeasure StdPerValue
ON StdPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
StdPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'StandardPricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and StdPerValue. LOVRecordSourceID = 12025
and StdPerValue.SCDActiveFlag = 'Y'


Left outer join ser.ProductSiteRoleRelationshipMeasure MovPerValue
ON MovPerValue.ProductSiteRoleRelationshipId = PSRR.ProductSiteRoleRelationshipId
and
MovPerValue.MeasureID = 
(
SELECT MeasureID FROM ser.MEASURE WHERE MeasureName = 'MovingAveragePricePerValue'
AND LovMeasureTypeID = (SELECT LOVId FROM ser.REFLOV where LOVName = 'Product Financial Measure' 							  
and lovsetid =  (select LOVSetId  from SER.REFLOVSET where  LovSetName = 'Measure Type') AND recordsourceid=12012)
AND LovRecordSourceID =  12025
)
and MovPerValue. LOVRecordSourceID = 12025
and MovPerValue.SCDActiveFlag = 'Y'
	) main1
where main1.Plant in ('P101','P10V','P150','P260','P220','P225','P22V','P102') and main1.Indicator !='' )x 
group by x.matnr having count(x.matnr)=1)
) abc


PRINT( 'Inserted records into datamart table '  )
		  
		   insert into [con_tpm].[DL_Standard_Cost_GB]
			([P1], [C1], [Territory_Code], [Metric_Code], [From_Date], [To_Date], [Include], [Value], [Region], [created_timestamp], [ETLRunLogId])
			select  
			[P1], [C1], [Territory_Code], [Metric_Code], [From_Date], [To_Date], [Include], [Value], [Region], [created_timestamp], [ETLRunLogId]
			from #DL_Standard_Cost_GB_Temp
			
			INSERT into   psa.egress_sp_logs VALUES(@project_name,@feed_name,@pETLRunLogID,@curr_timestamp)

          SELECT @vProcedureStatus  AS ProcedureStatus,
                 @vProcedureMessage AS ProcedureMessage;
				 
			 
       COMMIT TRANSACTION
	   
	   END TRY

    BEGIN CATCH
	IF(@@TRANCOUNT>0)
	ROLLBACK TRANSACTION;
	DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus,
			@vProcedureMessage As ProcedureMessage;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_dl_standard_cost_egress]',ERROR_MESSAGE(),GETDATE();
    END CATCH;
  END
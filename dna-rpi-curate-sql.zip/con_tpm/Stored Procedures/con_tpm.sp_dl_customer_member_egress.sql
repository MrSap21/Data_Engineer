﻿CREATE  PROC [con_tpm].[sp_dl_customer_member_egress] @pETLRunLogID [NVARCHAR](255) AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[sp_dl_customer_member_egress]
  Purpose                : Insert into datamart table from serve table.
  Target Table           : con_tpm.[DL_CUSTOMER_MEMBER_GB]
  ********************************************************************************************************************
  Default values
  ************************************************************************************************************
  ETLRunLogID                 : @pETLRunLogID passed as an argument
  
  *************************************************************************************************************
  */
  BEGIN
  BEGIN TRY
	DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
      declare @vNumRows         AS INT           = 0;                                           
 
      DECLARE @execsql              NVARCHAR(max),
              @curr_timestamp       NVARCHAR(max),
              @columnNames          NVARCHAR(max),
			  @project_name       as  NVARCHAR(max)='TPM',
              @feed_id              INT,
			  @tempTableName                       nvarchar(max)
			  
			  SET @tempTableName = 'tempdb..#DL_Customer_Member_GB_Temp'
		IF OBJECT_ID('[con_tpm].[DL_Customer_Member_GB]') IS NOT NULL
          BEGIN
          EXEC ('TRUNCATE TABLE [con_tpm].[DL_Customer_Member_GB]')
		  PRINT 'TRUNCATED DATAMART TABLE SUCCESSFULLY.'
          END   
		 
		IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
		set @execsql='select a.* into '+@tempTableName+' from [CON_TPM].[DL_Customer_Member_GB] a WHERE 1=2 '
		
	EXEC(@execsql)
      
			   
      SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
       
      SET @columnNames = (SELECT String_agg('[' + column_name + ']', ',')
                          FROM   information_schema.columns
                          WHERE  table_schema = 'con_tpm'
                                 AND table_name = 'DL_Customer_Member_GB')
     
     

      
	  BEGIN TRANSACTION
		
         
          PRINT 'Inserting data to the datamart table started';    -- Incremental data insertion

        insert into  #DL_Customer_Member_GB_Temp 
		([MemberCode] ,
[MemberDesc] ,
[LevelCode]	 ,
[TerritoryCode]	 ,
[CustomerTypeID] ,
[PriceListCode]	 ,
[IsActive] ,
[ActiveForPayments] ,
[ExternalCreationDate]	 ,
[SwitchDateSI] ,
[SwitchDateSO] ,
[Region]	 ,
[created_timestamp],
[ETLRunLogId]) 
SELECT 
GR5_code AS MemberCode, 
GR5_Description AS MemberDescription,
Grp5_level as LevelCode,
terry as [TerritoryCode],
1 as [CustomerTypeID],
null as [PriceListCode],
1 as [IsActive],
1 as [ActiveForPayments],
null as [ExternalCreationDate],
null as [SwitchDateSI],
null as [SwitchDateSO],
Region as Region,
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
FROM 
(
select  DISTINCT
GR5_code,
GR5_Description,
Grp5_level,
terry,
Region,
row_number() over (partition by BTB_Customer 
order by GR5_code desc, GR5_Description desc, 
Grp5_level desc,
  terry desc,
Region desc) as row_numb
FROM 
(
SELECT 
PRR.[PartyRoleId] AS BTB_Customer,
SUBSTRING(reflov_channel.[LOVName],1,6) as GR5_code,
SUBSTRING(reflov_channel.[LOVName],7,LEN(reflov_channel.[LOVName])) as GR5_Description,
'Customer' as Grp5_level,
 ref1.lovkey as terry,
reflov_region.[LOVName] as Region
FROM 
[ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
join [ser].[PartyRoleRelationship] PRR
ON PR.[PartyRoleId] = PRR.[PartyRoleId]
AND R.[LOVKey] = 'Customer - BTB' and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 and
PRR.[ParentPartyRoleId] IN
(
select PR.[PartyRoleId]
from [ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
where R.[LOVKey] = 'Sales Organisation' and
R.LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1) and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 
 )

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_channel
ON PRRG_channel.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_channel.[SCDActiveFlag] = 'Y'
and PRRG_channel.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_channel
ON
PRRG_channel.[LOVGroupId] = reflov_channel.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_channel
ON
reflov_channel.[LOVSetId] = reflovset_channel.[LOVSetId]
and
reflovset_channel.[LOVSetName]='Customer Group 5' and 
reflovset_channel.[RecordSourceId]=12025 and
reflovset_channel.[ActiveFlag] = 1

-- Channel Ends 

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_region
ON PRRG_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_region.[SCDActiveFlag] = 'Y'
and PRRG_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region
ON
PRRG_region.[LOVGroupId] = reflov_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_region
ON
reflov_region.[LOVSetId] = reflovset_region.[LOVSetId]
and
reflovset_region.[LOVSetName]='Customer Group 1' and
reflovset_region.[RecordSourceId]=12025 and
reflovset_region.[ActiveFlag] = 1


-- Region Ends

join ser.reflov ref1
on ref1.LOVName = reflov_region.[LOVName]
and ref1.[RecordSourceId] = 12012
and ref1.[LOVSetId] = (select LOVToSetId from [ser].[RefLOVMappingSet]  where LOVFROMSetId =  (Select [LOVSetId] 
from [ser].[RefLOVSet] where [LOVSetName] = 'Customer Group 1' and [RecordSourceId]=12025))
 ) Q 
 )Q1
 where row_numb=1						


union
SELECT 
GR4_code AS MemberCode, 
GR4_Description AS MemberDescription,
Grp4_level as LevelCode,
terry as [TerritoryCode],
1 as [CustomerTypeID],
null as [PriceListCode],
1 as [IsActive],
1 as [ActiveForPayments],
null as [ExternalCreationDate],
null as [SwitchDateSI],
null as [SwitchDateSO],
Region as Region,
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
FROM 
(
select  DISTINCT
GR4_code,
GR4_Description,
Grp4_level,
terry,
Region,
row_number() over (partition by BTB_Customer 
order by GR4_code desc, GR4_Description desc, 
Grp4_level desc,
  terry desc,
Region desc) as row_numb
FROM 
(
SELECT 
PRR.[PartyRoleId] AS BTB_Customer,
reflov_channel_parent.[LOVKey] as GR4_code,
reflov_channel_parent.[LOVName] as GR4_Description,
'ParentCompany' as Grp4_level,
 ref1.lovkey as terry,
reflov_region.[LOVName] as Region
FROM 
[ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
join [ser].[PartyRoleRelationship] PRR
ON PR.[PartyRoleId] = PRR.[PartyRoleId]
AND R.[LOVKey] = 'Customer - BTB' and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 and
PRR.[ParentPartyRoleId] IN
(
select PR.[PartyRoleId]
from [ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
where R.[LOVKey] = 'Sales Organisation' and
R.LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1) and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 
 )
 
-- Channel Ends
 LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_channel_parent
ON PRRG_channel_parent.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_channel_parent.[SCDActiveFlag] = 'Y'
and PRRG_channel_parent.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_channel_parent
ON
PRRG_channel_parent.[LOVGroupId] = reflov_channel_parent.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_channel_parent
ON
reflov_channel_parent.[LOVSetId] = reflovset_channel_parent.[LOVSetId]
and
reflovset_channel_parent.[LOVSetName]='Customer Group 4' and 
reflovset_channel_parent.[RecordSourceId]=12025 and
reflovset_channel_parent.[ActiveFlag] = 1
-- Channel_Parent Ends
 
LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_region
ON PRRG_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_region.[SCDActiveFlag] = 'Y'
and PRRG_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region
ON
PRRG_region.[LOVGroupId] = reflov_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_region
ON
reflov_region.[LOVSetId] = reflovset_region.[LOVSetId]
and
reflovset_region.[LOVSetName]='Customer Group 1' and
reflovset_region.[RecordSourceId]=12025 and
reflovset_region.[ActiveFlag] = 1


-- Region Ends

join ser.reflov ref1
on ref1.LOVName = reflov_region.[LOVName]
and ref1.[RecordSourceId] = 12012
and ref1.[LOVSetId] = (select LOVToSetId from [ser].[RefLOVMappingSet]  where LOVFROMSetId =  (Select [LOVSetId] 
from [ser].[RefLOVSet] where [LOVSetName] = 'Customer Group 1' and [RecordSourceId]=12025))
 ) Q 
 )Q1
 where row_numb=1						


 union 
 
 SELECT 
GR3_code AS MemberCode, 
GR3_Description AS MemberDescription,
Grp3_level as LevelCode,
terry as [TerritoryCode],
1 as [CustomerTypeID],
null as [PriceListCode],
1 as [IsActive],
1 as [ActiveForPayments],
null as [ExternalCreationDate],
null as [SwitchDateSI],
null as [SwitchDateSO],
Region as Region,
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
FROM 
(
select  DISTINCT
GR3_code,
GR3_Description,
Grp3_level,
terry,
Region,
row_number() over (partition by BTB_Customer 
order by GR3_code desc, GR3_Description desc, 
Grp3_level desc,
  terry desc,
Region desc) as row_numb
FROM 
(
SELECT 
PRR.[PartyRoleId] AS BTB_Customer,
reflov_area.[LOVKey] as GR3_code,
reflov_area.[LOVName] as GR3_Description,
'WBAArea' as Grp3_level,
 ref1.lovkey as terry,
reflov_region.[LOVName] as Region
FROM 
[ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
join [ser].[PartyRoleRelationship] PRR
ON PR.[PartyRoleId] = PRR.[PartyRoleId]
AND R.[LOVKey] = 'Customer - BTB' and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 and
PRR.[ParentPartyRoleId] IN
(
select PR.[PartyRoleId]
from [ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
where R.[LOVKey] = 'Sales Organisation' and
R.LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1) and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 
 )
 LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_area
ON PRRG_area.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_area.[SCDActiveFlag] = 'Y'
and PRRG_area.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_area
ON
PRRG_area.[LOVGroupId] = reflov_area.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_area
ON
reflov_area.[LOVSetId] = reflovset_area.[LOVSetId]
and
reflovset_area.[LOVSetName]='Customer Group 3' and
reflovset_area.[RecordSourceId]=12025 and
reflovset_area.[ActiveFlag] = 1
-- Area ends
LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_region
ON PRRG_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_region.[SCDActiveFlag] = 'Y'
and PRRG_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region
ON
PRRG_region.[LOVGroupId] = reflov_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_region
ON
reflov_region.[LOVSetId] = reflovset_region.[LOVSetId]
and
reflovset_region.[LOVSetName]='Customer Group 1' and
reflovset_region.[RecordSourceId]=12025 and
reflovset_region.[ActiveFlag] = 1


-- Region Ends

join ser.reflov ref1
on ref1.LOVName = reflov_region.[LOVName]
and ref1.[RecordSourceId] = 12012
and ref1.[LOVSetId] = (select LOVToSetId from [ser].[RefLOVMappingSet]  where LOVFROMSetId =  (Select [LOVSetId] 
from [ser].[RefLOVSet] where [LOVSetName] = 'Customer Group 1' and [RecordSourceId]=12025))
 ) Q 
 )Q1
 where row_numb=1	
 
 union
 SELECT 
GR2_code AS MemberCode, 
GR2_Description AS MemberDescription,
Grp2_level as LevelCode,
terry as [TerritoryCode],
1 as [CustomerTypeID],
null as [PriceListCode],
1 as [IsActive],
1 as [ActiveForPayments],
null as [ExternalCreationDate],
null as [SwitchDateSI],
null as [SwitchDateSO],
Region as Region,
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
FROM 
(
select  DISTINCT
GR2_code,
GR2_Description,
Grp2_level,
terry,
Region,
row_number() over (partition by BTB_Customer 
order by GR2_code desc, GR2_Description desc, 
Grp2_level desc,
  terry desc,
Region desc) as row_numb
FROM 
(
SELECT 
PRR.[PartyRoleId] AS BTB_Customer,
reflov_sub_region.[LOVKey] as GR2_code,
reflov_sub_region.[LOVName] as GR2_Description,
'WBASubRegion' as Grp2_level,
 ref1.lovkey as terry,
reflov_region.[LOVName] as Region
FROM 
[ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
join [ser].[PartyRoleRelationship] PRR
ON PR.[PartyRoleId] = PRR.[PartyRoleId]
AND R.[LOVKey] = 'Customer - BTB' and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 and
PRR.[ParentPartyRoleId] IN
(
select PR.[PartyRoleId]
from [ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
where R.[LOVKey] = 'Sales Organisation' and
R.LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1) and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 
 )

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_sub_region
ON PRRG_sub_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_sub_region.[SCDActiveFlag] = 'Y'
and PRRG_sub_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_sub_region
ON
PRRG_sub_region.[LOVGroupId] = reflov_sub_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_sub_region
ON
reflov_sub_region.[LOVSetId] = reflovset_sub_region.[LOVSetId]
and
reflovset_sub_region.[LOVSetName]='Customer Group 2' and
reflovset_sub_region.[RecordSourceId]=12025 and
reflovset_sub_region.[ActiveFlag] = 1
-- sub_region Ends 
 
LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_region
ON PRRG_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_region.[SCDActiveFlag] = 'Y'
and PRRG_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region
ON
PRRG_region.[LOVGroupId] = reflov_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_region
ON
reflov_region.[LOVSetId] = reflovset_region.[LOVSetId]
and
reflovset_region.[LOVSetName]='Customer Group 1' and
reflovset_region.[RecordSourceId]=12025 and
reflovset_region.[ActiveFlag] = 1


-- Region Ends

join ser.reflov ref1
on ref1.LOVName = reflov_region.[LOVName]
and ref1.[RecordSourceId] = 12012
and ref1.[LOVSetId] = (select LOVToSetId from [ser].[RefLOVMappingSet]  where LOVFROMSetId =  (Select [LOVSetId] 
from [ser].[RefLOVSet] where [LOVSetName] = 'Customer Group 1' and [RecordSourceId]=12025))
 ) Q 
 )Q1
 where row_numb=1
 
 union
 SELECT 
GR1_code AS MemberCode, 
GR1_Description AS MemberDescription,
Grp1_level as LevelCode,
terry as [TerritoryCode],
1 as [CustomerTypeID],
null as [PriceListCode],
1 as [IsActive],
1 as [ActiveForPayments],
null as [ExternalCreationDate],
null as [SwitchDateSI],
null as [SwitchDateSO],
Region as Region,
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
FROM 
(
select  DISTINCT
GR1_code,
GR1_Description,
Grp1_level,
terry,
Region,
row_number() over (partition by BTB_Customer 
order by GR1_code desc, GR1_Description desc, 
Grp1_level desc,
  terry desc,
Region desc) as row_numb
FROM 
(
SELECT 
PRR.[PartyRoleId] AS BTB_Customer,
reflov_region.[LOVKey] as GR1_code,
reflov_region.[LOVName] as GR1_Description,
'WBARegion' as Grp1_level,
 ref1.lovkey as terry,
reflov_region.[LOVName] as Region
FROM 
[ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
join [ser].[PartyRoleRelationship] PRR
ON PR.[PartyRoleId] = PRR.[PartyRoleId]
AND R.[LOVKey] = 'Customer - BTB' and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 and
PRR.[ParentPartyRoleId] IN
(
select PR.[PartyRoleId]
from [ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
where R.[LOVKey] = 'Sales Organisation' and
R.LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1) and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 
 )

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_region
ON PRRG_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_region.[SCDActiveFlag] = 'Y'
and PRRG_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region
ON
PRRG_region.[LOVGroupId] = reflov_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_region
ON
reflov_region.[LOVSetId] = reflovset_region.[LOVSetId]
and
reflovset_region.[LOVSetName]='Customer Group 1' and
reflovset_region.[RecordSourceId]=12025 and
reflovset_region.[ActiveFlag] = 1


-- Region Ends

join ser.reflov ref1
on ref1.LOVName = reflov_region.[LOVName]
and ref1.[RecordSourceId] = 12012
and ref1.[LOVSetId] = (select LOVToSetId from [ser].[RefLOVMappingSet]  where LOVFROMSetId =  (Select [LOVSetId] 
from [ser].[RefLOVSet] where [LOVSetName] = 'Customer Group 1' and [RecordSourceId]=12025))
 ) Q 
 )Q1
 where row_numb=1		

 
          PRINT( 'Inserted records into datamart table '  )
		  
		  insert into [con_tpm].[DL_Customer_Member_GB]
			([MemberCode], [MemberDesc], [LevelCode], [TerritoryCode], [CustomerTypeID], [PriceListCode], [IsActive], [ActiveForPayments], [ExternalCreationDate], [SwitchDateSI], [SwitchDateSO], [Region], [created_timestamp], [ETLRunLogId])
			select  
			[MemberCode], [MemberDesc], [LevelCode], [TerritoryCode], [CustomerTypeID], [PriceListCode], [IsActive], [ActiveForPayments], [ExternalCreationDate], [SwitchDateSI], [SwitchDateSO], [Region], [created_timestamp], [ETLRunLogId]
			from #DL_Customer_Member_GB_Temp
				 			
			INSERT into   psa.egress_sp_logs VALUES(@project_name,'DL_Customer_Member_GB',@pETLRunLogID,@curr_timestamp)
			
          SELECT @vProcedureStatus  AS ProcedureStatus,
                 @vProcedureMessage AS ProcedureMessage;
				 

                              
       COMMIT TRANSACTION
	   
	   END TRY

    BEGIN CATCH
	IF(@@TRANCOUNT>0)
	ROLLBACK TRANSACTION;
	
			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),
			ERROR_SEVERITY(),'[sp_dl_customer_member_egress]',
			ERROR_MESSAGE(),GETDATE();				
						
    END CATCH;
  END
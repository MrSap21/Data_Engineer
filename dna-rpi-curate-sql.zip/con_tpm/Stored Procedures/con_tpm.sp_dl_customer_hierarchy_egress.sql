﻿CREATE PROC [con_tpm].[sp_dl_customer_hierarchy_egress] @pETLRunLogID [NVARCHAR](255) AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[sp_dl_customer_hierarchy_egress]

  Target Table           : con_tpm.[DL_Customer_Hierarchy_GB]
  ********************************************************************************************************************
  Default values
  ************************************************************************************************************
  ETLRunLogID                 : @pETLRunLogID passed as an argument
  
  *************************************************************************************************************
  Bikram Mondal Initial Version 1.0
  05/02/2022   Bikram Mondal             Added duplicate removal logic Version 1.1
  *************************************************************************************************************
  */
  BEGIN
  BEGIN TRY
  IF OBJECT_ID('[con_tpm].[DL_Customer_Hierarchy_GB]') IS NOT NULL
          BEGIN
          EXEC ('TRUNCATE TABLE [con_tpm].[DL_Customer_Hierarchy_GB]')
		  PRINT 'TRUNCATED DATAMART TABLE SUCCESSFULLY.'
          END 
		
   
      DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
      declare @vNumRows         AS INT           = 0;                                           
 
      DECLARE @execsql              NVARCHAR(max),
			  @tempTableName        nvarchar(max),
			  @feed_name             as NVARCHAR(max)='DL_Customer_Hierarchy_GB',
              @curr_timestamp       NVARCHAR(max),
              @columnNames          NVARCHAR(max),
			  @project_name       as  NVARCHAR(max)='TPM',
              @feed_id              INT
	  SET @tempTableName = 'tempdb..#DL_Customer_Hierarchy_GB_Temp'
	  IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
	
	--creating temp table to store records with created_timestamp greater than prev_createdTimeStamp along with row numbers(partitioned by businesskeys and ordered in ascending order of created_timestamp)
	set @execsql='select a.* into '+@tempTableName+' from [con_tpm].[DL_Customer_Hierarchy_GB] a WHERE 1=2 '
		
	EXEC(@execsql)
	
			   
      SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
       
      SET @columnNames = (SELECT String_agg('[' + column_name + ']', ',')
                          FROM   information_schema.columns
                          WHERE  table_schema = 'con_tpm'
                                 AND table_name = 'DL_Customer_Hierarchy_GB')
     
	 print  @columnNames
     

      
	  BEGIN TRANSACTION
		
	
          PRINT 'Inserting data to the datamart table started';  		  -- Incremental data insertion
		  
        insert into #DL_Customer_Hierarchy_GB_Temp 
([HierarchyCode],
[MemberCode],
[MemberLevel],
[ParentMemberCode],
[ParentMemberLevel],
[Region],
[created_timestamp],
[ETLRunLogId]) 
 
 SELECT 
'WBACH' as [HierarchyCode],
GR5_code as MemberCode,
Grp5_level as MemberLevel,
GR4_code as ParentMemberCode,
Grp4_level as ParentMemberLevel,
Region as Region,
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
FROM 
(
select DISTINCT
GR5_code,GR5_Description,Grp5_level,
GR4_code,GR4_Description,Grp4_level,
Region,
row_number() over (partition by BTB_Customer 
order by GR5_code desc, GR5_Description desc, Grp5_level desc,
GR4_code desc, GR4_Description desc,Grp4_level desc,
Region desc) as row_numb
FROM 
(
SELECT 
PRR.[PartyRoleId] AS BTB_Customer,
SUBSTRING(reflov_channel.[LOVName],1,6) as GR5_code,
SUBSTRING(reflov_channel.[LOVName],7,LEN(reflov_channel.[LOVName])) as GR5_Description,
'Customer' as Grp5_level,
reflov_channel_parent.[LOVKey] as GR4_code,
reflov_channel_parent.[LOVName] as GR4_Description,
'ParentCompany' as Grp4_level,
reflov_region.[LOVName] as Region
FROM 
[ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
join [ser].[PartyRoleRelationship] PRR
ON PR.[PartyRoleId] = PRR.[PartyRoleId]
AND R.[LOVKey] = 'Customer - BTB' and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 and
PRR.[ParentPartyRoleId] IN
(
select PR.[PartyRoleId]
from [ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
where R.[LOVKey] = 'Sales Organisation' and
R.LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1) and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 
 )

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_channel
ON PRRG_channel.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_channel.[SCDActiveFlag] = 'Y'
and PRRG_channel.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_channel
ON
PRRG_channel.[LOVGroupId] = reflov_channel.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_channel
ON
reflov_channel.[LOVSetId] = reflovset_channel.[LOVSetId]
and
reflovset_channel.[LOVSetName]='Customer Group 5' and 
reflovset_channel.[RecordSourceId]=12025 and
reflovset_channel.[ActiveFlag] = 1

-- Channel Ends
LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_channel_parent
ON PRRG_channel_parent.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_channel_parent.[SCDActiveFlag] = 'Y'
and PRRG_channel_parent.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_channel_parent
ON
PRRG_channel_parent.[LOVGroupId] = reflov_channel_parent.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_channel_parent
ON
reflov_channel_parent.[LOVSetId] = reflovset_channel_parent.[LOVSetId]
and
reflovset_channel_parent.[LOVSetName]='Customer Group 4' and 
reflovset_channel_parent.[RecordSourceId]=12025 and
reflovset_channel_parent.[ActiveFlag] = 1
-- Channel_Parent Ends
LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_region
ON PRRG_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_region.[SCDActiveFlag] = 'Y'
and PRRG_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region
ON
PRRG_region.[LOVGroupId] = reflov_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_region
ON
reflov_region.[LOVSetId] = reflovset_region.[LOVSetId]
and
reflovset_region.[LOVSetName]='Customer Group 1' and
reflovset_region.[RecordSourceId]=12025 and
reflovset_region.[ActiveFlag] = 1
-- Region Ends
) Q 
 )Q1
 where row_numb=1
 
 UNION
 
 SELECT 
'WBACH' as [HierarchyCode],
 GR4_code as MemberCode,
 Grp4_level as MemberLevel,
GR3_code as ParentMemberCode,
Grp3_level as ParentMemberLevel,
Region as Region,
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 

FROM 
(
select  DISTINCT
GR4_code,GR4_Description,Grp4_level,
GR3_code,GR3_Description,Grp3_level,
Region,
row_number() over (partition by BTB_Customer 
order by  
GR4_code desc, GR4_Description desc,Grp4_level desc,
GR3_code desc, GR3_Description desc,Grp3_level desc,
Region desc) as row_numb
FROM 
(
SELECT 
PRR.[PartyRoleId] AS BTB_Customer,
reflov_channel_parent.[LOVKey] as GR4_code,
reflov_channel_parent.[LOVName] as GR4_Description,
'ParentCompany' as Grp4_level,
reflov_area.[LOVKey] as GR3_code,
reflov_area.[LOVName] as GR3_Description,
'WBAArea' as Grp3_level,
reflov_region.[LOVName] as Region
FROM 
[ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
join [ser].[PartyRoleRelationship] PRR
ON PR.[PartyRoleId] = PRR.[PartyRoleId]
AND R.[LOVKey] = 'Customer - BTB' and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 and
PRR.[ParentPartyRoleId] IN
(
select PR.[PartyRoleId]
from [ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
where R.[LOVKey] = 'Sales Organisation' and
R.LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1) and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 
 )
 LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_channel_parent
ON PRRG_channel_parent.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_channel_parent.[SCDActiveFlag] = 'Y'
and PRRG_channel_parent.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_channel_parent
ON
PRRG_channel_parent.[LOVGroupId] = reflov_channel_parent.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_channel_parent
ON
reflov_channel_parent.[LOVSetId] = reflovset_channel_parent.[LOVSetId]
and
reflovset_channel_parent.[LOVSetName]='Customer Group 4' and 
reflovset_channel_parent.[RecordSourceId]=12025 and
reflovset_channel_parent.[ActiveFlag] = 1
-- Channel_Parent Ends
LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_area
ON PRRG_area.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_area.[SCDActiveFlag] = 'Y'
and PRRG_area.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_area
ON
PRRG_area.[LOVGroupId] = reflov_area.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_area
ON
reflov_area.[LOVSetId] = reflovset_area.[LOVSetId]
and
reflovset_area.[LOVSetName]='Customer Group 3' and
reflovset_area.[RecordSourceId]=12025 and
reflovset_area.[ActiveFlag] = 1
-- Area ends

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_region
ON PRRG_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_region.[SCDActiveFlag] = 'Y'
and PRRG_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region
ON
PRRG_region.[LOVGroupId] = reflov_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_region
ON
reflov_region.[LOVSetId] = reflovset_region.[LOVSetId]
and
reflovset_region.[LOVSetName]='Customer Group 1' and
reflovset_region.[RecordSourceId]=12025 and
reflovset_region.[ActiveFlag] = 1
-- Region Ends
 ) Q 
 )Q1
 where row_numb=1
 
 UNION

SELECT 
 'WBACH' as [HierarchyCode],
 GR3_code as MemberCode,
 Grp3_level as MemberLevel,
GR2_code as ParentMemberCode,
Grp2_level as ParentMemberLevel,
Region as Region,
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId]
FROM 
(
 SELECT DISTINCT  
GR3_code,GR3_Description,Grp3_level,
GR2_code,GR2_Description,Grp2_level,
Region,
row_number() over (partition by BTB_Customer 
order by 
GR3_code desc, GR3_Description desc,Grp3_level desc,
GR2_code desc, GR2_Description desc,Grp2_level desc,
Region desc) as row_numb
FROM 
(
SELECT 
PRR.[PartyRoleId] AS BTB_Customer,
reflov_area.[LOVKey] as GR3_code,
reflov_area.[LOVName] as GR3_Description,
'WBAArea' as Grp3_level,
reflov_sub_region.[LOVKey] as GR2_code,
reflov_sub_region.[LOVName] as GR2_Description,
'WBASubRegion' as Grp2_level,
reflov_region.[LOVName] as Region
FROM 
[ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
join [ser].[PartyRoleRelationship] PRR
ON PR.[PartyRoleId] = PRR.[PartyRoleId]
AND R.[LOVKey] = 'Customer - BTB' and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 and
PRR.[ParentPartyRoleId] IN
(
select PR.[PartyRoleId]
from [ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
where R.[LOVKey] = 'Sales Organisation' and
R.LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1) and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 
 )
 LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_area
ON PRRG_area.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_area.[SCDActiveFlag] = 'Y'
and PRRG_area.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_area
ON
PRRG_area.[LOVGroupId] = reflov_area.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_area
ON
reflov_area.[LOVSetId] = reflovset_area.[LOVSetId]
and
reflovset_area.[LOVSetName]='Customer Group 3' and
reflovset_area.[RecordSourceId]=12025 and
reflovset_area.[ActiveFlag] = 1
-- Area ends

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_sub_region
ON PRRG_sub_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_sub_region.[SCDActiveFlag] = 'Y'
and PRRG_sub_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_sub_region
ON
PRRG_sub_region.[LOVGroupId] = reflov_sub_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_sub_region
ON
reflov_sub_region.[LOVSetId] = reflovset_sub_region.[LOVSetId]
and
reflovset_sub_region.[LOVSetName]='Customer Group 2' and
reflovset_sub_region.[RecordSourceId]=12025 and
reflovset_sub_region.[ActiveFlag] = 1
-- sub_region Ends

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_region
ON PRRG_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_region.[SCDActiveFlag] = 'Y'
and PRRG_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region
ON
PRRG_region.[LOVGroupId] = reflov_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_region
ON
reflov_region.[LOVSetId] = reflovset_region.[LOVSetId]
and
reflovset_region.[LOVSetName]='Customer Group 1' and
reflovset_region.[RecordSourceId]=12025 and
reflovset_region.[ActiveFlag] = 1
-- Region Ends

 ) Q 
 )Q1
 where row_numb=1			

UNION

SELECT 
 'WBACH' as [HierarchyCode],
 GR2_code as MemberCode,
 Grp2_level as MemberLevel,
 GR1_code as ParentMemberCode,
Grp1_level as ParentMemberLevel,
Region as Region,
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId]
FROM 
(
select  DISTINCT
GR2_code,GR2_Description,Grp2_level,
GR1_code,GR1_Description,Grp1_level,
Region,
row_number() over (partition by BTB_Customer 
order by 
GR2_code desc, GR2_Description desc,Grp2_level desc,
GR1_code desc, GR1_Description desc,Grp1_level desc,
Region desc) as row_numb
FROM 
(
SELECT 
PRR.[PartyRoleId] AS BTB_Customer,
reflov_sub_region.[LOVKey] as GR2_code,
reflov_sub_region.[LOVName] as GR2_Description,
'WBASubRegion' as Grp2_level,
reflov_region.[LOVKey] as GR1_code,
reflov_region.[LOVName] as GR1_Description,
'WBARegion' as Grp1_level,
reflov_region.[LOVName] as Region
FROM 
[ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
join [ser].[PartyRoleRelationship] PRR
ON PR.[PartyRoleId] = PRR.[PartyRoleId]
AND R.[LOVKey] = 'Customer - BTB' and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 and
PRR.[ParentPartyRoleId] IN
(
select PR.[PartyRoleId]
from [ser].[PartyRole] PR join [ser].[RefLOV] R
ON PR.[LOVRoleId] = R.[LOVId]
where R.[LOVKey] = 'Sales Organisation' and
R.LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1) and
PR.[SCDActiveFlag] = 'Y' and
PR.[LOVRecordSourceId] = 12025 
 )
LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_sub_region
ON PRRG_sub_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_sub_region.[SCDActiveFlag] = 'Y'
and PRRG_sub_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_sub_region
ON
PRRG_sub_region.[LOVGroupId] = reflov_sub_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_sub_region
ON
reflov_sub_region.[LOVSetId] = reflovset_sub_region.[LOVSetId]
and
reflovset_sub_region.[LOVSetName]='Customer Group 2' and
reflovset_sub_region.[RecordSourceId]=12025 and
reflovset_sub_region.[ActiveFlag] = 1
-- sub_region Ends

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG_region
ON PRRG_region.[PartyRoleRelationshipId] = PRR.[PartyRoleRelationshipId]
and PRRG_region.[SCDActiveFlag] = 'Y'
and PRRG_region.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region
ON
PRRG_region.[LOVGroupId] = reflov_region.[LOVId]

 
inner join [ser].[RefLOVSet] reflovset_region
ON
reflov_region.[LOVSetId] = reflovset_region.[LOVSetId]
and
reflovset_region.[LOVSetName]='Customer Group 1' and
reflovset_region.[RecordSourceId]=12025 and
reflovset_region.[ActiveFlag] = 1
-- Region Ends

 ) Q 
 )Q1
 where row_numb=1


 

          PRINT( 'Inserted records into datamart table '  )
		  
		   insert into [con_tpm].[DL_Customer_Hierarchy_GB]
			([HierarchyCode],[MemberCode],[MemberLevel],[ParentMemberCode],[ParentMemberLevel],[Region],[created_timestamp],[ETLRunLogId])
			select  
			[HierarchyCode],[MemberCode],[MemberLevel],[ParentMemberCode],[ParentMemberLevel],[Region],[created_timestamp],[ETLRunLogId]
			from #DL_Customer_Hierarchy_GB_Temp
			
			INSERT into   psa.egress_sp_logs VALUES(@project_name,@feed_name,@pETLRunLogID,@curr_timestamp)

          SELECT @vProcedureStatus  AS ProcedureStatus,
                 @vProcedureMessage AS ProcedureMessage;
				 
			 
       COMMIT TRANSACTION
	   
	   END TRY

    BEGIN CATCH
	IF(@@TRANCOUNT>0)
	ROLLBACK TRANSACTION;
	
			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),
			ERROR_SEVERITY(),'[sp_dl_customer_hierarchy_egress]',
			ERROR_MESSAGE(),GETDATE();				
						
    END CATCH;
  END
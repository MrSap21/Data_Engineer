﻿CREATE PROC [con_tpm].[sp_dl_payments_egress] @pETLRunLogID [NVARCHAR](255) AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[sp_dl_payments_egress]

  Target Table           : con_tpm.[DL_Payments_GB]
  ********************************************************************************************************************
  Default values
  ************************************************************************************************************
  ETLRunLogID                 : @pETLRunLogID passed as an argument
  
  *************************************************************************************************************
  05/02/2022   Bikram Mondal            Initial Version 1.0
  02/03/2023   Shivangi Arora			Modified Version (Tag: 'CRQ70793')
										Purpose: Modify column A to have channel code and include active values from tables to calculate value for the documents. Also modify the value as a decimal datatype.
  *************************************************************************************************************
  */
  BEGIN
  BEGIN TRY
  IF OBJECT_ID('[con_tpm].[DL_Payments_GB]') IS NOT NULL
          BEGIN
          EXEC ('TRUNCATE TABLE [con_tpm].[DL_Payments_GB]')
		  PRINT 'TRUNCATED DATAMART TABLE SUCCESSFULLY.'
          END 
		
   
      DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
      declare @vNumRows         AS INT           = 0;                                           
 
      DECLARE @execsql              NVARCHAR(max),
			  @tempTableName        nvarchar(max),
			  @feed_name             as NVARCHAR(max)='DL_Payments_GB',
              @curr_timestamp       NVARCHAR(max),
              @columnNames          NVARCHAR(max),
			  @project_name       as  NVARCHAR(max)='TPM',
              @feed_id              INT,
			  @inc_date_range		INT,
		      @hist_date_range		INT,
			  @start_timestamp      NVARCHAR(MAX),
			  @count                INT
	  SET @tempTableName = 'tempdb..#DL_Payments_GB_Temp'
	  IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
	
	--creating temp table to store records with created_timestamp greater than prev_createdTimeStamp along with row numbers(partitioned by businesskeys and ordered in ascending order of created_timestamp)
	set @execsql='select a.* into '+@tempTableName+' from [con_tpm].[DL_Payments_GB] a WHERE 1=2 '
		
	EXEC(@execsql)
	
	
			   
      SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
	    SET @hist_date_range=-18
		SET @inc_date_range=-35
		SET @count= (SELECT Count(*)  from  psa.egress_sp_logs WHERE  project_name = 'TPM'and feed_name=@feed_name) 
       
      SET @columnNames = (SELECT String_agg('[' + column_name + ']', ',')
                          FROM   information_schema.columns
                          WHERE  table_schema = 'con_tpm'
                                 AND table_name = 'DL_Payments_GB')
     
	 print  @columnNames
     IF ( @count = 0 )
        BEGIN
            print 'history block'
            
			SET @start_timestamp=(select format(dateadd(mm,@hist_date_range,convert(datetime,convert(varchar(20),getdate(),112))),'yyyy-MM-dd hh:mm:ss tt'))
			
        END

      IF ( @count > 0 )
        BEGIN
		print 'inc block'
			
			SET @start_timestamp=(select format(dateadd(dd,@inc_date_range,convert(datetime,convert(varchar(20),getdate(),112))),'yyyy-MM-dd hh:mm:ss tt'))
           
        END

      
	  BEGIN TRANSACTION
		
	
          PRINT 'Inserting data to the datamart table started';  		  -- Incremental data insertion
		  
        insert into #DL_Payments_GB_Temp 
([AccountCode],
[SupplierCode],
[InvoiceNumber],
[InvoiceDate],
[InvoiceDescription],
[ProductDesc],
[TaxLevelCode],
[ERPInvoiceID],
[CustomerLevelMatching],
[DocType],
[PromoID],
[Value],
[Attribute1],
[Attribute2],
[Attribute3],
[Attribute4],
[Attribute5],
[Attribute6],
[Attribute7],
[Attribute8],
[Attribute9],
[Attribute10],
[Attachment_1],
[Attachment_2],
[InvoiceCreatedDate],
[InvoiceCreatedBy],
[Region],
[created_timestamp],
[ETLRunLogId]) 
 Select 
main.channel_code as [AccountCode],
NULL as [SupplierCode],
Concat(main.Doc_Num,'_',main.LineItmNum) as [InvoiceNumber],
format(main.DocDate,'yyyyMMdd') as [InvoiceDate],
main.InvoiceDescription as [InvoiceDescription],
main.MATNR as [ProductDesc],
NULL as [TaxLevelCode],
main.Doc_Num as [ERPInvoiceID],
NULL as [CustomerLevelMatching],
CASE main.DocType
WHEN 'TPM_Invoices' THEN 'CHK'
WHEN 'TPM_Deductions' THEN 'DED'
WHEN 'TPM_Credit_Notes' THEN 'CRD'
END as [DocType],
NULL as [PromoID],
SUM(CAST(main.DMBTR_local_currency as DECIMAL(18,2))) as [Value], --CRQ70793
main.Attribute1 as [Attribute1],
NULL as [Attribute2],
NULL as [Attribute3],
NULL as [Attribute4],
NULL as [Attribute5],
NULL as [Attribute6],
NULL as [Attribute7],
NULL as [Attribute8],
NULL as [Attribute9],
NULL as [Attribute10],
(select null as [Attachment_1])[Attachment_1],
(select null as [Attachment_2])[Attachment_2],
(select null as [InvoiceCreatedDate])[InvoiceCreatedDate],
NULL as [InvoiceCreatedBy],
main.Region as [Region],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(
select
 D.[SourceKey] as Doc_Num, 
D.[DocumentDate] as DocDate, 
DL.[SourceKey] as LineItmNum,
prrd.channel as channel_code,
PR_1.[SourceKey] as CustNum,
Prod.[SourceKey] as MATNR, 
FA.[SourceKey] as HKNOT_FAcode, 
DLC.value as InvoiceDescription,
DC.value as Attribute1,
DTSet.LovSetName as DocType,
DLM194.Value as DMBTR_local_currency, 
DLM194.HWAER as HWAER_local_currency_code,
prrd.Region as Region

from  [ser].[Document] D  join 
[ser].[DocumentLine] DL

ON
DL.[DocumentId] = D.[DocumentId] and D.SCDActiveFlag = 'Y' and D.[LOVRecordSourceId]= 12025
and
DL.[LOVRecordSourceId]= 12025 and DL.SCDActiveFlag = 'Y'
AND D.[DocumentDate] between @start_timestamp  and  @curr_timestamp
														   
AND DL.[LOVDocumentLineTypeId] = ( select reflov.[LOVId] from [ser].[RefLOV] reflov where 
reflov.[LOVKey] = 'PnL GL accounts' and
reflov.[LOVSetId] = (select [LOVSetId] from [ser].[RefLOVSet] where  
 [LOVSetName] = 'Document line type' and [RecordSourceId] = 12012))


 Left join ser.DocumentLineCharacteristic DLC
ON DLC.[DocumentLineId] = DL.[DocumentLineId]
and DLC.SCDActiveFlag = 'Y' --CRQ70793
AND DLC.[LOVCharacteristicId] = 
(
select LOVId from ser.RefLOV where 
LOVKey = 'Document_Line_Text'
AND LOVSetId = (select LOVSetId from ser.RefLOVSet where LOVSetName = 'GB_SAP_Document_Line_Characteristics')
AND ActiveFlag = 1
and RecordSourceID = 12012)


 Left join ser.DocumentCharacteristic DC
 ON DC.[DocumentId] = D.[DocumentId] 
 and DC.SCDActiveFlag = 'Y' --CRQ70793
 AND DC.[LOVCharacteristicId] = 
(
 select LOVId from ser.RefLOV where 
LOVKey = 'Document_Reference_Text'
AND LOVSetId = (select LOVSetId from ser.RefLOVSet where LOVSetName = 'GB_SAP_Document_Characteristics')
AND ActiveFlag = 1
and RecordSourceID = 12012)



INNER JOIN [ser].[DocumentGroup] DG1
ON D.[DocumentId] = DG1.[DocumentId]
and DG1.SCDActiveFlag = 'Y' --CRQ70793
and DG1.LOVGroupSetId = (select LovSetID  from ser.RefLOVSet where LOVsetName ='finance_document_types' and RecordSourceId = 12025)
and DG1.LOVRecordSourceId = 12025


INNER JOIN ser.reflov DGR
ON DG1.LOVGroupId = DGR.LOVID
and DGR.RecordSourceId = 12025
and DGR.activeflag =1

INNER JOIN ser.reflov DT
ON DGR.LOVKey = DT.LOVKey
and DT.activeflag =1 --CRQ70793
and DT.LOVsetid IN (
select LOVSetId from ser.reflovset where lovsetname IN ('TPM_Invoices','TPM_Deductions','TPM_Credit_Notes'))

INNER JOIN ser.reflovset DTSet
ON DT.LOVsetid = DTSet.LOVsetid
and DT.RecordSourceId = 12012
and DT.ActiveFlag = 1
and DTSet.RecordSourceId = 12012
and DTSet.ActiveFlag = 1
--Considered 'DA','DG','DR','RA','RV','AB','SA','DZ' DocTypes


join [ser].[Party] P
ON D.[PartyId] = P.[PartyId] and P.SCDActiveFlag = 'Y'

INNER join [ser].[FinanceAccount] FA
ON DL.[FinanceAccountId] = FA.[FinanceAccountId] and FA.SCDActiveFlag = 'Y'
and FA.[sourcekey] IN (
select LOVKey from ser.reflov 
where LOVsetid IN (
select LOVsetid from ser.reflovset where lovsetname = 'TPM_GL_Accounts')
) 


LEFT OUTER join [ser].[Product] Prod
ON DL.[ProductId] = Prod.[ProductId] and Prod.SCDActiveFlag = 'Y'

join [ser].[DocumentLinePartyRole] DLPR
ON DL.[DocumentLineId] = DLPR.[DocumentLineId] and DLPR.SCDActiveFlag = 'Y'
join [ser].[PartyRole] PR_1
ON DLPR.[PartyRoleId] = PR_1.[PartyRoleId] and PR_1.SCDActiveFlag = 'Y'


left outer join 
(select DLM.[DocumentLineId],reflov.[LOVKey] as HWAER, DLM.value as Value
from [ser].[RefLOV] reflov join [ser].[DocumentLineMeasure] DLM
ON DLM.[LOVUOMId] = reflov.[LOVId]
where LovSetID = (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'Currency ISO 4217'
and [RecordSourceId] = 12012 And [ActiveFlag] = 1)
AND [RecordSourceId] = 12012 AND [ActiveFlag] = 1
and DLM.[MeasureId] = 194 and DLM.[SCDActiveFlag] = 'Y' and DLM.[LOVRecordSourceId] = 12025
)DLM194
ON DL.[DocumentLineId] = DLM194.[DocumentLineId] 



inner join
(
select * from (
select (prr.partyroleid) as retailer,
prr.[ParentPartyRoleId] as sales_org
,substring(reflov_channel.[LOVName],1,6) as  channel
,substring(reflov_channel.[LOVName],7,LEN(reflov_channel.[LOVName])) as description

,reflov_region.[LOVName] as region
, row_number() over (partition by prr.partyroleid order by reflov_channel.[LOVKey] desc,reflov_region.[LOVName] desc) as row_num

from 
(
select * from [ser].[PartyRoleRelationship] PRR
where 
PRR.[LOVRecordSourceId] = 12025
and PRR.[SCDActiveFlag] = 'Y'
and PRR.ParentPartyRoleId  IN    (
SELECT [PartyRoleId] from [ser].[PartyRole] WHERE
 [LOVRecordSourceId] = 12025
 and SCDActiveFlag='Y' --CRQ70793
And LOVRoleId = (SELECT LOVId from [ser].[RefLOV] where
[LOVKey] = 'Sales Organisation' and LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1)) )) prr


LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG
ON PRRG.[PartyRoleRelationshipId] = prr.[PartyRoleRelationshipId]
and PRRG.[SCDActiveFlag] = 'Y'
and PRRG.[LOVRecordSourceId] = 12025

inner join [ser].[RefLOV] reflov_channel
ON
PRRG.[LOVGroupId] = reflov_channel.[LOVId]
and reflov_channel.ActiveFlag=1 --CRQ70793

inner join [ser].[RefLOVSet] reflovset
ON
reflov_channel.[LOVSetId] = reflovset.[LOVSetId]
and
reflovset.[LOVSetName]='Customer Group 5' and --CRQ70793
reflovset.[RecordSourceId]=12025 and
reflovset.[ActiveFlag] = 1

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG1
ON PRRG1.[PartyRoleRelationshipId] = prr.[PartyRoleRelationshipId]
and PRRG1.[SCDActiveFlag] = 'Y'
and PRRG1.[LOVRecordSourceId] = 12025

inner join [ser].[RefLOV] reflov_region
ON
PRRG1.[LOVGroupId] = reflov_region.[LOVId]
and reflov_region.ActiveFlag=1 --CRQ70793
inner join [ser].[RefLOVSet] reflovset_reg
ON
reflov_region.[LOVSetId] = reflovset_reg.[LOVSetId]
and
reflovset_reg.[LOVSetName]='Customer Group 1' and
reflovset_reg.[RecordSourceId]=12025 and
reflovset_reg.[ActiveFlag] = 1

) partrel where row_num=1) prrd
ON prrd.retailer = PR_1.[PartyRoleId]									
)main
group by main.channel_code,main.Doc_Num,main.LineItmNum,main.DocDate,
main.InvoiceDescription,main.MATNR,
main.Doc_Num,main.DocType,main.Attribute1,main.Region










          PRINT( 'Inserted records into datamart table '  )
		  
		   insert into [con_tpm].[DL_Payments_GB]
			([AccountCode],
[SupplierCode],
[InvoiceNumber],
[InvoiceDate],
[InvoiceDescription],
[ProductDesc],
[TaxLevelCode],
[ERPInvoiceID],
[CustomerLevelMatching],
[DocType],
[PromoID],
[Value],
[Attribute1],
[Attribute2],
[Attribute3],
[Attribute4],
[Attribute5],
[Attribute6],
[Attribute7],
[Attribute8],
[Attribute9],
[Attribute10],
[Attachment_1],
[Attachment_2],
[InvoiceCreatedDate],
[InvoiceCreatedBy],
[Region],
[created_timestamp],
[ETLRunLogId]) 
			select  
			[AccountCode],
[SupplierCode],
[InvoiceNumber],
[InvoiceDate],
[InvoiceDescription],
[ProductDesc],
[TaxLevelCode],
[ERPInvoiceID],
[CustomerLevelMatching],
[DocType],
[PromoID],
[Value],
[Attribute1],
[Attribute2],
[Attribute3],
[Attribute4],
[Attribute5],
[Attribute6],
[Attribute7],
[Attribute8],
[Attribute9],
[Attribute10],
[Attachment_1],
[Attachment_2],
[InvoiceCreatedDate],
[InvoiceCreatedBy],
[Region],
[created_timestamp],
[ETLRunLogId]
			from #DL_Payments_GB_Temp
			
			INSERT into   psa.egress_sp_logs VALUES(@project_name,@feed_name,@pETLRunLogID,@curr_timestamp)

          SELECT @vProcedureStatus  AS ProcedureStatus,
                 @vProcedureMessage AS ProcedureMessage;
				 
			 
       COMMIT TRANSACTION
	   
	   END TRY

      BEGIN CATCH
	IF(@@TRANCOUNT>0)
	ROLLBACK TRANSACTION;
	
			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),
			ERROR_SEVERITY(),'[sp_dl_payments_egress]',
			ERROR_MESSAGE(),GETDATE();				
						
    END CATCH;
  END
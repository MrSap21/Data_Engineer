﻿CREATE PROC [con_tpm].[sp_dm_ActualSO_Target] @pETLRunLogID [NVARCHAR](255),@pstart_timestamp [nvarchar](255) AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[sp_dm_ActualSO_Target]
  Purpose                : Insert into datamart table from serve table.
  Target Table           : con_tpm.[DL_Actuals_SI_SO_GB]
  ********************************************************************************************************************
  Default values
  ************************************************************************************************************
  ETLRunLogID                 : @pETLRunLogID passed as an argument
  *************************************************************************************************************
   - -2022   :  Archana Rajendran	     Inital Version 1.0
01-04-2022	 :  Archana Rajendran		  Metric Code Addition  version 1.1
 - -2022	 :	Manaswi Ghosh	      Added Duplicate Removal logic and fix the bugs version 1.2
  */
  BEGIN
      SET nocount ON

      DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
	  declare @vNumRows         AS INT           = 0;																							   
	   
      --etl , last run date(current timestamp) where transaction date between
      --where transaction date between @startdate and @enddate
      -- enddate : curr date, startdate: select max(last run date)+1 from temptable
      -- insert new record to temp table with etl, last run date : curr date
      -- if(count=0)first run: start date - currdate-2yrs , end date:curr date
	  
      DECLARE @execsql              NVARCHAR(max),
              @curr_timestamp       NVARCHAR(max),
              @columnNames          NVARCHAR(max)
			 

     SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
	 
      SET @columnNames = (SELECT String_agg('[' + column_name + ']', ',')
                          FROM   information_schema.columns
                          WHERE  table_schema = 'con_tpm'
                                 AND table_name ='DL_Actuals_SI_SO_GB')
   

			   
      

      BEGIN try
	  
	  
          PRINT 'Inserting data to the datamart table started';
          -- Incremental data insertion

          insert into #DL_Actuals_SI_SO_GB_Temp  ([From_Company_Code],[From_Company_Level_Code],[C1_Code],[P1_Code],[C0_Code],[P0_Code],
		[Metric_Code],[PromoID],[From_Date],[To_Date],[Value],[Region],[created_timestamp],[ETLRunLogId])
SELECT
null as [From_Company_Code],
null as [From_Company_Level_Code],
null as [C1_Code],
null as [P1_Code],
main.C0_code as [CO_Code],   
main.P0_code as [PO_Code],
main.Metric_Code as [Metric_Code],
null as [PromoID],
format(main.From_date,'yyyyMMdd') as [From_Date],
format(main.From_date,'yyyyMMdd') as [To_Date], 
main.value as [Value], 
main.Region as [Region],
@curr_timestamp as[created_timestamp],@pETLRunLogID  as [ETLRunLogId]
from
(
SELECT 
P_SAP.[SourceKey] as P0_code, t.[TransactionDatetime] From_date,
prrd.channel as C0_code , --prrd.description Channel_Description,
prrd.region Region,
( case when unit.Measureid in 
 (SELECT [MeasureId] from [ser].[Measure] where 
 [MeasureName] in ('SALES U') AND [LOVRecordSourceId] = 134) then '1001'
 else '1114' End) Metric_Code,
sum(case when  try_cast(REPLACE(unit.value,  '$','') as decimal(16,4)) is null and unit.value='' then 0 else 
cast(REPLACE(unit.value,  '$','') as  decimal(16,2)) end ) as value

FROM [ser].[Transaction] t
INNER JOIN ser.Transactionlineitem tl
ON t.TransactionId=tl.transactionid AND tl.LOVrecordsourceid=134
AND t.[TransactionDatetime] between @pstart_timestamp  and  @curr_timestamp
AND t.[SCDActiveFlag] = 'Y'
AND tl.[SCDActiveFlag] = 'Y'

INNER JOIN ser.Transactionlineitemmeasure unit
ON tl.Transactionlineitemid=unit.Transactionlineitemid
AND unit.[MeasureId] in (SELECT [MeasureId] from [ser].[Measure] where 
[MeasureName] in ('SALES U','SALES $') 
AND [LOVMeasureTypeId] = (SELECT [LOVId] from [ser].[RefLOV] where  
LOVKey = 'RETAIL_TRANS_AGG' 
AND  [LOVSetId] = (Select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'Measure Type' and [RecordSourceId] = 12012))
AND [LOVRecordSourceId] = 134)
AND unit.[LOVRecordSourceId]=134
and unit.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductRelationship] PR1 -- Get the Golden Record [FromProductId]
ON PR1.[ToProductId] = tl.[ProductId]
and PR1.[LOVRecordSourceId] = 12034
and PR1.[SCDActiveFlag] = 'Y'

 

INNER JOIN [ser].[ProductRelationship] PR2 -- 
ON PR2.[FromProductId] = PR1.[FromProductId]
and PR2.[LOVRecordSourceId] = 12034
and PR2.[SCDActiveFlag] = 'Y'


INNER JOIN ser.Product P_SAP
ON P_SAP.Productid=PR2.toproductid
AND P_SAP.SCDActiveflag='Y'
AND P_SAP.lovrecordsourceid=12025
AND P_SAP.[LOVSourceKeyTypeId]=
(SELECT LOVId from SER.RefLOV where 
LOVKey = 'SAP Material Number'
AND LOVSetId = (SELECT LOVSetId from SER.RefLOVSet where LOVSetName = 'Source Key Type')
AND ActiveFlag = 1)

INNER JOIN ser.productStatus ps
ON 
P_SAP.productid=ps.productid
AND ps.LOVStatusid = (
SELECT LovID from SER.RefLOV where 
LOVKey ='INTRDCD'
AND 
LovSetId = (SELECT LovSetID from SER.RefLOVSet
where LOVSetName = 'Status Type'
and RecordSourceId = 12012
AND ActiveFlag = 1)
)
AND ps.LOVProductStatusSetId =  (
SELECT LovSetID from SER.RefLOVSet
where LOVSetName = 'Status Type'
and RecordSourceId = 12012
AND ActiveFlag = 1
)
and ps.lovrecordsourceid=12025

INNER JOIN ser.partyrolesiterolerelationship psr
on t.siteroleid=psr.siteroleid
and psr.lovrelationshiptypeid= (select lovid from ser.reflov where lovkey='Operates From'
and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Relationship Type' and recordsourceid=12012)
and recordsourceid=12012)
and psr.lovrecordsourceid=12023 and psr.scdactiveflag='Y'

-----------SUB Query Starts---------------------------Solution To The Multiple Occurance of Sales_Organisation for a BTB_Customer-----------------
INNER JOIN
(
select *
from (
select (prr.partyroleid) as retailer,prr.[ParentPartyRoleId] as btbcustomer,
prr1.[ParentPartyRoleId] as sales_org
,substring(reflov_channel.[LOVName],1,6) as  channel --CO_CODE
,substring(reflov_channel.[LOVName],7,LEN(reflov_channel.[LOVName])) as description --Channel Description
,reflov_region.[LOVName] as region --region
, row_number() over (partition by prr.partyroleid order by reflov_channel.[LOVKey] desc,reflov_region.[LOVName] desc) as row_num
from (select * from [ser].[PartyRoleRelationship] prr where
prr.partyroleid in (select partyroleid from ser.partyrole where sourcekey='Target' and [SCDActiveFlag] = 'Y' and --chng
 ---respective retailer name to be considered in the sourcekey above---------

Lovroleid in (select lovid from ser.reflov where lovkey='Retailer' and recordsourceid=12012
and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Role' and recordsourceid=12012)))
AND prr.[SCDActiveFlag] = 'Y'
AND prr.[LOVRecordSourceId] =12025
and prr.ParentPartyRoleId IN (
SELECT [PartyRoleId] from [ser].[PartyRole] WHERE
[LOVRecordSourceId] = 12025
and [SCDActiveFlag] = 'Y'
And LOVRoleId=(SELECT [LOVId] from [ser].[RefLOV] where
[LOVKey] = 'Customer - BTB' )
)
) prr


INNER JOIN (Select * from [ser].[PartyRoleRelationship] prr1 where prr1.[SCDActiveFlag] = 'Y'
AND prr1.[LOVRecordSourceId] =12025
AND prr1.ParentPartyRoleId IN
(
SELECT [PartyRoleId] from [ser].[PartyRole] WHERE
scdactiveflag='Y' and [LOVRecordSourceId] = 12025
And LOVRoleId=(SELECT [LOVId] from [ser].[RefLOV] where
[LOVKey] = 'Sales Organisation' )
) ) prr1
ON prr1.[PartyRoleId] = prr.[ParentPartyRoleId]





LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG
ON PRRG.[PartyRoleRelationshipId] = prr1.[PartyRoleRelationshipId]
and PRRG.[SCDActiveFlag] = 'Y'
and PRRG.[LOVRecordSourceId] = 12025





inner join [ser].[RefLOV] reflov_channel
ON
PRRG.[LOVGroupId] = reflov_channel.[LOVId]



inner join [ser].[RefLOVSet] reflovset
ON
reflov_channel.[LOVSetId] = reflovset.[LOVSetId]
and
reflovset.[LOVSetName]='Customer Group 5' and
reflovset.[RecordSourceId]=12025 and
reflovset.[ActiveFlag] = 1


LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG1
ON PRRG1.[PartyRoleRelationshipId] = prr1.[PartyRoleRelationshipId]
and PRRG1.[SCDActiveFlag] = 'Y'
and PRRG1.[LOVRecordSourceId] = 12025





inner join [ser].[RefLOV] reflov_region
ON
PRRG1.[LOVGroupId] = reflov_region.[LOVId]
inner join [ser].[RefLOVSet] reflovset_reg
ON
reflov_region.[LOVSetId] = reflovset_reg.[LOVSetId]
and
reflovset_reg.[LOVSetName]='Customer Group 1' and
reflovset_reg.[RecordSourceId]=12025 and
reflovset_reg.[ActiveFlag] = 1
) partrel where row_num=1) prrd


ON psr.partyroleid=prrd.retailer



-----------SUB Query Ends---------------------------Solution To The Multiple Occurance of Sales_Organisation for a BTB_Customer-----------------   



GROUP BY P_SAP.[SourceKey] , t.[TransactionDatetime],--prrd.description
prrd.channel,
prrd.region	,unit.measureid)main



          PRINT( 'Inserted records into datamart table '  )
 --SELECT @vNumRows AS NumRows, @vProcedureStatus  AS ProcedureStatus,
                 --@vProcedureMessage AS ProcedureMessage;
     
	END TRY

	BEGIN CATCH

         DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      --SELECT  '-1' AS ProcedureStatus,
						--@vProcedureMessage As ProcedureMessage;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_dm_ActualSO_Target]',ERROR_MESSAGE(),GETDATE();
			THROW ;																							

	END CATCH;																							
  END
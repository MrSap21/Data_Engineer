﻿CREATE PROC [con_tpm].[sp_dm_ActualSO_Walgreens_Retailer] @pETLRunLogID [NVARCHAR](255),@pstart_timestamp [nvarchar](255) 
AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[sp_dm_ActualSO_Walgreens_Retailer_test]
  Purpose                : Insert into datamart table from serve table.
  Target Table           : con_tpm.[DL_Actuals_SI_SO_GB]
  ********************************************************************************************************************
  Default values
  ************************************************************************************************************
  ETLRunLogID                 : @pETLRunLogID passed as an argument
  *************************************************************************************************************
  22-03-2022   :  Aditya Vikram Pareek	     Inital Version version 1.0
 - -2022	 : Archana Rajendran             Metric Code Addition  version 1.1
 - -2022	 :	Abhilaksh Agnihotri	      Added Duplicate Removal logic and fix the bugs version 1.2
 --2023		 : Archana Rajendran			New Walgreens RSI Feed data changes implemented
  */
  BEGIN
      SET nocount ON

      DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
                  declare @vNumRows         AS INT           = 0;                                                                                                                 
                  
      DECLARE @execsql              NVARCHAR(max),
              @curr_timestamp       NVARCHAR(max),
              @columnNames          NVARCHAR(max)


     SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
                
      SET @columnNames = (SELECT String_agg('[' + column_name + ']', ',')
                          FROM   information_schema.columns
                          WHERE  table_schema = 'con_tpm'
                                 AND table_name ='DL_Actuals_SI_SO_GB')
   

                                                   
      

      BEGIN try
                  
          PRINT 'Inserting data to the datamart table started';
          -- Incremental data insertion

           insert into #DL_Actuals_SI_SO_GB_Temp ([From_Company_Code],[From_Company_Level_Code],[C1_Code],[P1_Code],[C0_Code],[P0_Code],
                                [Metric_Code],[PromoID],[From_Date],[To_Date],[Value],[Region],[created_timestamp],[ETLRunLogId])
SELECT
null as [From_Company_Code],
null as [From_Company_Level_Code],
null as [C1_Code],
null as [P1_Code],
main.C0_code as [CO_Code],  
main.P0_code as [PO_Code],
main.Metric_Code as [Metric_Code],
null as [PromoID],
format(main.Startdate,'yyyyMMdd') as [From_date],
format(main.End_date,'yyyyMMdd') as [To_Date],
main.Quantity as [Value],
main.Region as [Region],
@curr_timestamp as  [created_timestamp], @pETLRunLogID as [ETLRunLogId]
from
(
select P0_code,End_date,Startdate, C0_code,Region,Metric_Code,Sum(Value_) Quantity from (SELECT
P_SAP.[SourceKey] as P0_code, t.[TransactionDatetime] End_date,t.[TransactionDatetime] Startdate,
G4.Member_Code as C0_code,
G1.Member_Description Region,
( case when unit.Measureid in (SELECT [MeasureId] from [ser].[Measure] where
[MeasureName] in ('Sales Units')) then '1001'
  else '1114' End) Metric_Code,
sum(cast(unit.value as decimal(18,2))) as Value_
FROM [ser].[Transaction] t
INNER JOIN ser.Transactionlineitem tl
ON t.TransactionId=tl.transactionid AND tl.LOVrecordsourceid=12035
AND T.[TransactionDatetime] between @pstart_timestamp  and  @curr_timestamp
AND t.[SCDActiveFlag] = 'Y'
AND tl.[SCDActiveFlag] = 'Y'
INNER JOIN ser.Transactionlineitemmeasure unit
ON tl.Transactionlineitemid=unit.Transactionlineitemid
AND unit.[MeasureId] in (SELECT [MeasureId] from [ser].[Measure] where
[MeasureName] in ('Sales amount','Sales Units')
AND [LOVMeasureTypeId] = (SELECT [LOVId] from [ser].[RefLOV] where  
LOVKey = 'RETAIL_TRANS_AGG'
AND  [LOVSetId] = (Select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'Measure Type' and [RecordSourceId] = 12012))
AND [LOVRecordSourceId] = 12035)
AND unit.[LOVRecordSourceId]=12035
and unit.[SCDActiveFlag] = 'Y'
INNER JOIN [ser].[ProductRelationship] PR1 -- Get the Golden Record [FromProductId]
ON PR1.[ToProductId] = tl.[ProductId]
and PR1.[LOVRecordSourceId] = 12034
and PR1.[SCDActiveFlag] = 'Y'
INNER JOIN [ser].[ProductRelationship] PR2 --
ON PR2.[FromProductId] = PR1.[FromProductId]
and PR2.[LOVRecordSourceId] = 12034
and PR2.[SCDActiveFlag] = 'Y'
INNER JOIN ser.Product P_SAP
ON P_SAP.Productid=PR2.toproductid
AND P_SAP.SCDActiveflag='Y'
AND P_SAP.lovrecordsourceid=12025
AND P_SAP.[LOVSourceKeyTypeId]=
(SELECT LOVId from SER.RefLOV where
LOVKey = 'SAP Material Number'
AND LOVSetId = (SELECT LOVSetId from SER.RefLOVSet where LOVSetName = 'Source Key Type')
AND ActiveFlag = 1)
INNER JOIN ser.productStatus ps
ON
P_SAP.productid=ps.productid
AND ps.LOVStatusid = (
SELECT LovID from SER.RefLOV where
LOVKey ='INTRDCD'
AND
LovSetId = (SELECT LovSetID from SER.RefLOVSet
where LOVSetName = 'Status Type'
and RecordSourceId = 12012
AND ActiveFlag = 1)
)
AND ps.LOVProductStatusSetId =  (
SELECT LovSetID from SER.RefLOVSet
where LOVSetName = 'Status Type'
and RecordSourceId = 12012
AND ActiveFlag = 1
)
and ps.lovrecordsourceid=12025
INNER JOIN ser.partyrolesiterolerelationship psr
on t.siteroleid=psr.siteroleid
and psr.lovrelationshiptypeid= (select lovid from ser.reflov where lovkey='Operates From'
and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Relationship Type' and recordsourceid=12012)
and recordsourceid=12012)
and psr.lovrecordsourceid=12035 and psr.scdactiveflag='Y'
INNER JOIN [ser].[PartyRoleRelationship] prr
ON prr.[PartyRoleId] = psr.[PartyRoleId]
AND prr.[SCDActiveFlag] = 'Y'
AND prr.[LOVRecordSourceId] =12025
and prr.ParentPartyRoleId IN (
SELECT [PartyRoleId] from [ser].[PartyRole] WHERE
[LOVRecordSourceId] = 12025
and [SCDActiveFlag] = 'Y'
And LOVRoleId=(SELECT [LOVId] from [ser].[RefLOV] where
[LOVKey] = 'Customer - BTB' )
)
INNER JOIN [ser].[PartyRoleRelationship] prr1
ON prr1.[PartyRoleId] = prr.[ParentPartyRoleId]
AND prr1.[SCDActiveFlag] = 'Y'
AND prr1.[LOVRecordSourceId] =12025
AND prr1.ParentPartyRoleId IN (
SELECT [PartyRoleId] from [ser].[PartyRole] WHERE
[LOVRecordSourceId] = 12025
And LOVRoleId=(SELECT [LOVId] from [ser].[RefLOV] where
[LOVKey] = 'Sales Organisation' )
)
 --**************************************
left outer join
(
select distinct substring (reflov.[LOVName] ,1,6)  Member_Code,substring (reflov.[LOVName],7,len(reflov.[LOVName])) Member_Description,PRRG.PartyRoleRelationshipId
from [ser].[PartyRoleRelationshipGroup] PRRG join [ser].[RefLOV] reflov
ON
PRRG.[LOVGroupId] = reflov.[LOVId]
join [ser].[RefLOVSet] reflovset
 ON
reflov.[LOVSetId] = reflovset.[LOVSetId]
WHERE
reflovset.[LOVSetName]='Customer Group 5'  and
reflovset.[RecordSourceId]=12025 and
reflovset.[ActiveFlag] = 1 and
PRRG.[SCDActiveFlag] = 'Y' and
PRRG.PartyRoleRelationshipId IS NOT NULL
)as G4
ON prr1.[PartyRoleRelationshipId] = G4.[PartyRoleRelationshipId]
--****************************************
left outer join
(
select distinct substring (reflov.[LOVName] ,1,6)  Member_Code,substring (reflov.[LOVName],7,len(reflov.[LOVName])) Member_Description,PRRG.PartyRoleRelationshipId
from [ser].[PartyRoleRelationshipGroup] PRRG join [ser].[RefLOV] reflov
ON
PRRG.[LOVGroupId] = reflov.[LOVId]
join [ser].[RefLOVSet] reflovset
 ON
reflov.[LOVSetId] = reflovset.[LOVSetId]
WHERE
reflovset.[LOVSetName]='Customer Group 1'  and
reflovset.[RecordSourceId]=12025 and
reflovset.[ActiveFlag] = 1 and
PRRG.[SCDActiveFlag] = 'Y' and
PRRG.PartyRoleRelationshipId IS NOT NULL
)as G1
ON prr1.[PartyRoleRelationshipId] = G1.[PartyRoleRelationshipId]
--****************************
GROUP BY P_SAP.[SourceKey] , t.[TransactionDatetime],
t.[TransactionDatetime], G4.Member_Code,
G1.Member_Description,unit.measureid) n Group By n.P0_code,n.End_date,n.Startdate,n.C0_code,n.Region,n.Metric_Code --order by n.P0_code,n.End_date,n.[Start_date],n.C0_code
)main



          PRINT( 'Inserted records into datamart table '  )
--SELECT @vNumRows AS NumRows, @vProcedureStatus  AS ProcedureStatus,
                 --@vProcedureMessage AS ProcedureMessage;
                END TRY

                BEGIN CATCH

         DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      --SELECT  '-1' AS ProcedureStatus,
						--@vProcedureMessage As ProcedureMessage;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_dm_ActualSO_Walgreens_Retailer]',ERROR_MESSAGE(),GETDATE();
			THROW ;																							

	END CATCH;																							
  END
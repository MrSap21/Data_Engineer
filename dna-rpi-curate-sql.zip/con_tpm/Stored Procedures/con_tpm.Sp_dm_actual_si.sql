﻿CREATE PROC [con_tpm].[Sp_dm_actual_si] @pETLRunLogID [NVARCHAR](255),@pstart_timestamp [nvarchar](255) AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[Sp_dm_actual_si]
  Purpose                : Insert into datamart table from serve table.
  Target Table           : con_tpm.[DL_Actuals_SI_SO_GB]
  ********************************************************************************************************************
  Default values
  ************************************************************************************************************
  ETLRunLogID                 : @pETLRunLogID passed as an argument
  *************************************************************************************************************
  Initial Version 1.0
  */
  BEGIN
      SET nocount ON

      DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
      --etl , last run date(current timestamp) where transaction date between
      --where transaction date between @startdate and @enddate
      -- enddate : curr date, startdate: select max(last run date)+1 from temptable
      -- insert new record to temp table with etl, last run date : curr date
      -- if(count=0)first run: start date - currdate-2yrs , end date:curr date
      DECLARE @execsql              NVARCHAR(max),
              @curr_timestamp       NVARCHAR(max),
              @columnNames          NVARCHAR(max)

      SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
       
      SET @columnNames = (SELECT String_agg('[' + column_name + ']', ',')
                          FROM   information_schema.columns
                          WHERE  table_schema = 'con_tpm'
                                 AND table_name = 'DL_Actuals_SI_SO_GB')
     
                 print  @columnNames
     

      BEGIN TRY
                  
                  
         
          PRINT 'Inserting data to the datamart table started';    -- Incremental data insertion

        insert into #DL_Actuals_SI_SO_GB_Temp ([From_Company_Code],[From_Company_Level_Code],[C1_Code],[P1_Code],[C0_Code],[P0_Code],
                                [Metric_Code],[PromoID],[From_Date],[To_Date],[Value],[Region],[created_timestamp],[ETLRunLogId]) 
SELECT
null as [From_Company_Code],
null as [From_Company_Level_Code],
null as [C1_Code],
null as [P1_Code],
main.Channel as [CO_Code],
main.productcode as [PO_Code],
main.Metric_Code as [Metric_Code],
null as [PromoID],
format(main.transactiondatetime,'yyyyMMdd') as [From_Date],
format(main.transactiondatetime,'yyyyMMdd') as [To_Date],
main.Value as [Value],
main.Region as [Region], 
@curr_timestamp as[created_timestamp],@pETLRunLogID as [ETLRunLogId]  
from
(
select a.productcode,a.Channel, a.transactiondatetime, a.Metric_Code,a.description,
sum(try_convert(decimal(18,2),a.quantity)) as Value,a.Region
from
(
select t.transactionid,tli.transactionlineitemid,tlim.measureid,
tlim.value as quantity,
p.sourcekey as productcode,pr.sourcekey as Customer_code,t.transactiondatetime,
t.lovtransactiontypeid,tpr.partyroleid,tpr.lovrelationshiptypeid,tli.productid,
p.lovsourcekeytypeid,p.productname,pr.lovroleid,
prrd.channel as channel, prrd.Region Region,prrd.description as description,
( case 
when tlim.measureid in (select [MeasureId] from [ser].[Measure]
where 
[MeasureName] in ( 'Billing_Quantity') and
[SCDActiveFlag] = 'Y' and
[LOVRecordSourceId] = 12025) then '1010'
else '1110' End) Metric_Code

from ser.[transaction] t
inner join ser.transactionpartyrole tpr
on tpr.transactionid=t.transactionid
and t.lovrecordsourceid=12025
and tpr.lovrecordsourceid=12025
AND t.[TransactionDatetime] between @pstart_timestamp  and  @curr_timestamp
and t.scdactiveflag='Y'
and tpr.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and 
lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012) --187000002
and LOVRelationshipTypeId=(select lovid from ser.reflov where lovkey='Payer' and 
lovsetid=(select lovsetid from ser.reflovset where lovsetname='Relationship Type' and recordsourceid=12012) and recordsourceid=12012) --in ('157000004')

inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and tli.scdactiveflag='Y'

inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'

inner join ser.transactionlineitemmeasure tlim
on tlim.transactionlineitemid=tli.transactionlineitemid
and tlim.measureid in (select [MeasureId] from [ser].[Measure]
where 
[MeasureName] in ( 'Net_Value','Billing_Quantity') and
[SCDActiveFlag] = 'Y' and
[LOVRecordSourceId] = 12025)
and tlim.scdactiveflag='Y'

inner join ser.partyrole pr
on pr.partyroleid=tpr.partyroleid
and pr.scdactiveflag='Y'
and lovroleid=(select lovid from ser.reflov where lovsetid=
(select Lovsetid from ser.reflovset where lovsetname='Role') and LOVkey ='Customer - BTB' and ActiveFlag=1)


inner join
(
select * from (
select (prr.partyroleid) as retailer,
prr.[ParentPartyRoleId] as sales_org
,substring(reflov_channel.[LOVName],1,6) as  channel
,substring(reflov_channel.[LOVName],7,LEN(reflov_channel.[LOVName])) as description

,reflov_region.[LOVName] as region
, row_number() over (partition by prr.partyroleid order by reflov_channel.[LOVKey] desc,reflov_region.[LOVName] desc) as row_num

from 
(
select * from [ser].[PartyRoleRelationship] PRR
where 
PRR.[LOVRecordSourceId] = 12025
and PRR.[SCDActiveFlag] = 'Y'
and PRR.ParentPartyRoleId  IN    (
SELECT [PartyRoleId] from [ser].[PartyRole] WHERE
[LOVRecordSourceId] = 12025
And LOVRoleId = (SELECT LOVId from [ser].[RefLOV] where
[LOVKey] = 'Sales Organisation' and LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1)) )) prr


LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG
ON PRRG.[PartyRoleRelationshipId] = prr.[PartyRoleRelationshipId]
and PRRG.[SCDActiveFlag] = 'Y'
and PRRG.[LOVRecordSourceId] = 12025

inner join [ser].[RefLOV] reflov_channel
ON
PRRG.[LOVGroupId] = reflov_channel.[LOVId]

inner join [ser].[RefLOVSet] reflovset
ON
reflov_channel.[LOVSetId] = reflovset.[LOVSetId]
and
reflovset.[LOVSetName]='Customer Group 5' and
reflovset.[RecordSourceId]=12025 and
reflovset.[ActiveFlag] = 1

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG1
ON PRRG1.[PartyRoleRelationshipId] = prr.[PartyRoleRelationshipId]
and PRRG1.[SCDActiveFlag] = 'Y'
and PRRG1.[LOVRecordSourceId] = 12025

inner join [ser].[RefLOV] reflov_region
ON
PRRG1.[LOVGroupId] = reflov_region.[LOVId]
inner join [ser].[RefLOVSet] reflovset_reg
ON
reflov_region.[LOVSetId] = reflovset_reg.[LOVSetId]
and
reflovset_reg.[LOVSetName]='Customer Group 1' and
reflovset_reg.[RecordSourceId]=12025 and
reflovset_reg.[ActiveFlag] = 1

) partrel where row_num=1) prrd
ON prrd.retailer = pr.partyroleid

)a
group by a.productcode,a.Channel, a.transactiondatetime,a.Metric_Code,a.Region,a.description



union all


	   

	   

select a.productcode,a.Channel, a.transactiondatetime, a.Metric_Code,a.description,

sum(try_convert(decimal(18,2),a.quantity)) as Value,a.Region

from

(

select t.transactionid,tli.transactionlineitemid,tlim.measureid,

--tlim.value as quantity,

( case

when tlim.measureid in

(select [MeasureId]

from [ser].[Measure]

where

[MeasureName] = 'Quantity Sold' and

[SCDActiveFlag] = 'Y' and

[LOVRecordSourceId] = 12052)

then tlim.value

else b.value1 End) quantity,



p.sourcekey as productcode,pr.sourcekey as Customer_code,t.transactiondatetime,

t.lovtransactiontypeid,tpr.partyroleid,tpr.lovrelationshiptypeid,tli.productid,

p.lovsourcekeytypeid,p.productname,pr.lovroleid,

prrd.channel as channel, prrd.Region Region,prrd.description as description,

( case

when tlim.measureid in

(select [MeasureId]

from [ser].[Measure]

where

[MeasureName] = 'Quantity Sold' and

[SCDActiveFlag] = 'Y' and

[LOVRecordSourceId] = 12052)

then '1010'

else '1110' End) Metric_Code

 

from ser.[transaction] t

inner join ser.transactionpartyrole tpr

on tpr.transactionid=t.transactionid

and t.lovrecordsourceid=12052

AND t.[TransactionDatetime] between @pstart_timestamp  and  @curr_timestamp

and tpr.lovrecordsourceid=12052

and t.scdactiveflag='Y'

and tpr.scdactiveflag='Y'

and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and

lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012) --187000002

and LOVRelationshipTypeId=(select lovid from ser.reflov where lovkey='Payer' and

lovsetid=(select lovsetid from ser.reflovset where lovsetname='Relationship Type' and recordsourceid=12012) and recordsourceid=12012) --in ('157000004')

 

inner join ser.transactionlineitem tli

on t.transactionid=tli.transactionid

and tli.scdactiveflag='Y'

and tli.lovrecordsourceid=12052

 

inner join ser.product p

on p.productid=tli.productid

and p.scdactiveflag='Y'

and p.LOVRecordSourceId = 12025



inner join ser.transactionlineitemmeasure tlim

on tlim.transactionlineitemid=tli.transactionlineitemid

and tlim.measureid in (

(select [MeasureId] from [ser].[Measure]

where

[MeasureName] in ('Quantity Sold','Unit Price') and

[SCDActiveFlag] = 'Y' and

[LOVRecordSourceId] = 12052) 

)

and tlim.scdactiveflag='Y'

inner join
(
select 
a.transactionlineitemID,((try_convert(decimal(18,2),a.Value))*(try_convert(decimal(18,2),a1.Value))) as value1
FROM
(select tlim.transactionlineitemID,tlim.Value from ser.transactionlineitemmeasure tlim where tlim.measureid in
(select [MeasureId] from [ser].[Measure]
where
[MeasureName] = 'Quantity Sold' and
[SCDActiveFlag] = 'Y' and
[LOVRecordSourceId] = 12052)
and tlim.scdactiveflag='Y') a
inner join
(select tlim1.transactionlineitemID,tlim1.Value from ser.transactionlineitemmeasure tlim1 where tlim1.measureid in
(select [MeasureId] from [ser].[Measure]
where
[MeasureName] = 'Unit Price' and
[SCDActiveFlag] = 'Y' and
[LOVRecordSourceId] = 12052)
and tlim1.scdactiveflag='Y') a1
ON  a.transactionlineitemID = a1.transactionlineitemID
) b
on b.transactionlineitemid=tli.transactionlineitemid

 

inner join ser.partyrole pr

on pr.partyroleid=tpr.partyroleid

and pr.scdactiveflag='Y'

and lovroleid=(select lovid from ser.reflov where lovsetid=

(select Lovsetid from ser.reflovset where lovsetname='Role') and LOVkey ='Customer - BTB' and ActiveFlag=1)

 

 

inner join

(

select * from (

select (prr.partyroleid) as retailer,

prr.[ParentPartyRoleId] as sales_org

,substring(reflov_channel.[LOVName],1,6) as  channel

,substring(reflov_channel.[LOVName],7,LEN(reflov_channel.[LOVName])) as description

 

,reflov_region.[LOVName] as region

, row_number() over (partition by prr.partyroleid order by reflov_channel.[LOVKey] desc,reflov_region.[LOVName] desc) as row_num

 

from

(

select * from [ser].[PartyRoleRelationship] PRR

where

PRR.[LOVRecordSourceId] = 12025

and PRR.[SCDActiveFlag] = 'Y'

and PRR.ParentPartyRoleId  IN    (

SELECT [PartyRoleId] from [ser].[PartyRole] WHERE

[LOVRecordSourceId] = 12025

And LOVRoleId = (SELECT LOVId from [ser].[RefLOV] where

[LOVKey] = 'Sales Organisation' and LOVSetid=(SELECT LOVSetid from [ser].[RefLOVset] where [LOVsetname] = 'Role' and ActiveFlag=1)) )) prr

 

 

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG

ON PRRG.[PartyRoleRelationshipId] = prr.[PartyRoleRelationshipId]

and PRRG.[SCDActiveFlag] = 'Y'

and PRRG.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_channel

ON

PRRG.[LOVGroupId] = reflov_channel.[LOVId]

 

inner join [ser].[RefLOVSet] reflovset

ON

reflov_channel.[LOVSetId] = reflovset.[LOVSetId]

and

reflovset.[LOVSetName]='Customer Group 5' and

reflovset.[RecordSourceId]=12025 and

reflovset.[ActiveFlag] = 1

 

LEFT OUTER JOIN [ser].[PartyRoleRelationshipGroup] PRRG1

ON PRRG1.[PartyRoleRelationshipId] = prr.[PartyRoleRelationshipId]

and PRRG1.[SCDActiveFlag] = 'Y'

and PRRG1.[LOVRecordSourceId] = 12025

 

inner join [ser].[RefLOV] reflov_region

ON

PRRG1.[LOVGroupId] = reflov_region.[LOVId]

inner join [ser].[RefLOVSet] reflovset_reg

ON

reflov_region.[LOVSetId] = reflovset_reg.[LOVSetId]

and

reflovset_reg.[LOVSetName]='Customer Group 1' and

reflovset_reg.[RecordSourceId]=12025 and

reflovset_reg.[ActiveFlag] = 1

 

) partrel where row_num=1) prrd

ON prrd.retailer = pr.partyroleid

 

)a

group by a.productcode,a.Channel, a.transactiondatetime,a.Metric_Code,a.Region,a.description
)main 
                           



                                                                  
                                                        
                                            

          PRINT( 'Inserted records into datamart table '  )
                                                       
                                                   
                                                 

          --SELECT @vProcedureStatus  AS ProcedureStatus,
            --     @vProcedureMessage AS ProcedureMessage;
                              
       END TRY

       BEGIN CATCH

         DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      --SELECT  '-1' AS ProcedureStatus
           -- , @vProcedureMessage As ProcedureMessage;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[Sp_dm_actual_si]',ERROR_MESSAGE(),GETDATE();
			THROW;
    
	END CATCH;
  END
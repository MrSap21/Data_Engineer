﻿CREATE PROC [con_tpm].[sp_dm_ActualSO_Wrapper] @pETLRunLogID [NVARCHAR](255),@pstart_timestamp [nvarchar](255) AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[sp_dm_ActualSO_Wrapper]
  Purpose                : Actual so wrapper procedure calling Actual SO subprocedures.
  
 */
  BEGIN
 
  DECLARE @vProcedureMessage                  AS NVARCHAR(MAX) = 'OK';
        DECLARE @vProcedureStatus                   AS NVARCHAR(20)  = '0';
		DECLARE @vNumRows                           AS INT           = 0;
  PRINT 'INSIDE ACTUAL SO WRAPPER';
    BEGIN TRY
				EXEC [con_tpm].[sp_dm_ActualSO_walmart] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO WALMART PROCEDURE COMPLETED';
							
				/*EXEC [con_tpm].[sp_dm_ActualSO_target] @pETLRunLogID,@pstart_timestamp
		        Print 'Actual SO Target proc completed ';*/

			    EXEC [con_tpm].[sp_dm_ActualSO_UltaRetailer] @pETLRunLogID,@pstart_timestamp
		        Print 'Actual SO Ulta proc completed ';

				/*EXEC [con_tpm].[sp_dm_ActualSO_DERMStoreRetailer] @pETLRunLogID,@pstart_timestamp
		        Print 'Actual SO DERM Store proc completed ';*/

				EXEC [con_tpm].[sp_dm_ActualSO_Skin_Store_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO SKINSTORE PROC COMPLETED';

				/*EXEC [con_tpm].[sp_dm_ActualSO_Shoppers_Drug_Mart_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO SHOPPERS DRUG MART PROC COMPLETED';

				EXEC [con_tpm].[sp_dm_ActualSO_Kohls_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO SHOPPERS KOHLS PROC COMPLETED';

				EXEC [con_tpm].[sp_dm_ActualSO_Walgreens_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO WALGREENS COMPLETED';

				EXEC [con_tpm].[sp_dm_ActualSO_Singer_Group_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO SINGER GROUP PROC COMPLETED';
			    
				EXEC [con_tpm].[sp_dm_ActualSO_ALSHAYA_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO ALSHAYA GROUP PROC COMPLETED';

				EXEC [con_tpm].[sp_dm_ActualSO_CHILE_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO CHILE GROUP PROC COMPLETED';

				EXEC [con_tpm].[sp_dm_ActualSO_Hjartat_Retailer]  @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO Hjartat GROUP PROC COMPLETED';

				EXEC [con_tpm].[sp_dm_ActualSO_MECCA_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO MECCA GROUP PROC COMPLETED';

				EXEC [con_tpm].[sp_dm_ActualSO_MEXICO_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO MEXICO GROUP PROC COMPLETED';
				
				EXEC [con_tpm].[sp_dm_ActualSO_Baozun_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO BAOZUN GROUP PROC COMPLETED';

				EXEC [con_tpm].[sp_dm_ActualSO_THAILAND_Retailer] @pETLRunLogID,@pstart_timestamp
		        PRINT 'ACTUAL SO THAILAND GROUP PROC COMPLETED';

				EXEC [con_tpm].[sp_dm_ActualSO_BUK_Retailer] @pETLRunLogID,@pstart_timestamp
                PRINT 'ACTUAL SO BUK GROUP PROC COMPLETED';
				*/

			/*Return*/
			--SELECT @vNumRows AS NumRows, @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;
    END TRY

    BEGIN CATCH
         DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      --SELECT  '-1' AS ProcedureStatus
           -- , @vProcedureMessage As ProcedureMessage;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),ERROR_SEVERITY(),'[sp_dm_ActualSO_Wrapper]',ERROR_MESSAGE(),GETDATE();
			THROW;
    
	END CATCH;
  END
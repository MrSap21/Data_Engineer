﻿CREATE PROC [con_tpm].[sp_dl_actual_si_so_egress] @pETLRunLogID [NVARCHAR](255) AS
/*
FileName    : [sp_dl_actual_si_so_egress]
Description : Populate Data in TPM Egress DataMarts.
Target Table Name:  [CON_TPM].[DL_Actuals_SI_SO_GB]
*/

/* Declare and Initialize Generic variables*/
		DECLARE @vProcedureMessage                   NVARCHAR(MAX) ,
				@vProcedureStatus                    NVARCHAR(20)  ,
				@execsql                             NVARCHAR(MAX),
				@tempTableName                       nvarchar(max),
				  @project_name         NVARCHAR(max),
				  @count                INT,
				  @start_timestamp      NVARCHAR(MAX),
				  @feed_name             as NVARCHAR(max)='DL Actuals SI SO GB',
				  @inc_date_range		INT,
				  @hist_date_range		INT,
				  @curr_timestamp	NVARCHAR(MAX);
			  
			
		
BEGIN

	BEGIN TRY

	          SET @vProcedureMessage = 'OK'
			  SET @vProcedureStatus = '0'
			  SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
			  SET @hist_date_range=-18
			  SET @inc_date_range=-42
			  SET @project_name='TPM'
		     
		      SET @count= (SELECT Count(*)  from  psa.egress_sp_logs WHERE  project_name = 'TPM'and feed_name=@feed_name) 
              SET @tempTableName = 'tempdb..#DL_Actuals_SI_SO_GB_Temp'
	
	IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
	
	--creating temp table to store records with created_timestamp greater than prev_createdTimeStamp along with row numbers(partitioned by businesskeys and ordered in ascending order of created_timestamp)
	set @execsql='select a.* into '+@tempTableName+' from [CON_TPM].[DL_Actuals_SI_SO_GB] a WHERE 1=2 '
		
	EXEC(@execsql)

   

			
		 IF ( @count = 0 )
        BEGIN
            print 'history block'
            
			SET @start_timestamp=(select format(dateadd(mm,@hist_date_range,convert(datetime,convert(varchar(20),getdate(),112))),'yyyy-MM-dd hh:mm:ss tt'))

        END

      IF ( @count > 0 )
        BEGIN
		print 'inc block'
			
			SET @start_timestamp=(select format(dateadd(dd,@inc_date_range,convert(datetime,convert(varchar(20),getdate(),112))),'yyyy-MM-dd hh:mm:ss tt'))
           
        END
			  
		 	EXEC [con_tpm].[Sp_dm_actual_si] @pETLRunLogID,@start_timestamp
		    Print 'Actual SI proc completed';
			
			EXEC [con_tpm].[sp_dm_ActualSO_Wrapper] @pETLRunLogID,@start_timestamp
	        Print 'Actual SO proc completed ';

			EXEC ('Truncate table [CON_TPM].[DL_Actuals_SI_SO_GB]')

			 BEGIN TRANSACTION;

			insert into [CON_TPM].[DL_Actuals_SI_SO_GB]
			([From_Company_Code], [From_Company_Level_Code], [C1_Code], [P1_Code], [C0_Code], [P0_Code], [Metric_Code], [PromoID],[From_Date],[To_Date], [Value], [Region], [created_timestamp], [ETLRunLogId])
			select  
			[From_Company_Code],[From_Company_Level_Code],[C1_Code],[P1_Code],[C0_Code],[P0_Code],[Metric_Code],[PromoID],[From_Date],[To_Date],[Value],[Region],[created_timestamp],[ETLRunLogId]
			from #DL_Actuals_SI_SO_GB_Temp
			
INSERT into   psa.egress_sp_logs VALUES
(
 @project_name,
@feed_name,
@pETLRunLogID,
@curr_timestamp)	
			/*Return*/
			SELECT  @vProcedureStatus AS ProcedureStatus, @vProcedureMessage AS ProcedureMessage;

   
	COMMIT TRANSACTION;	
	 

	END TRY

	BEGIN CATCH
	IF(@@TRANCOUNT>0)
	ROLLBACK TRANSACTION;
	
			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),
			ERROR_SEVERITY(),'[sp_dl_actual_si_so_egress]',
			ERROR_MESSAGE(),GETDATE();
						
						
    END CATCH;
END
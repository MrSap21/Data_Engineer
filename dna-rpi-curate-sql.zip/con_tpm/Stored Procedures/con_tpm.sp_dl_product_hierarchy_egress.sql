﻿CREATE PROC [con_tpm].[sp_dl_product_hierarchy_egress] @pETLRunLogID [NVARCHAR](255) AS
  /*
  ************************************************************************************************************
  Procedure Name         : [con_tpm].[sp_dl_product_hierarchy_egress]

  Target Table           : con_tpm.[DL_Product_Hierarchy_GB]
  ********************************************************************************************************************
  Default values
  ************************************************************************************************************
  ETLRunLogID                 : @pETLRunLogID passed as an argument
  
  *************************************************************************************************************
  05/02/2022    Bikram Mondal         Added duplicate removal logic and 4t & 5t changes
  19/07/2023    Shivangi Arora    :   Updated logic as per new hierarchies given for WBAPH and WBAPH2. Tag : 'CRQ82130_WBAPH2hierarchychanges'
               
		Note:The LOVRecordSourceID to be changed from 12023 to 12025 once the STEP project goes live.
  *************************************************************************************************************
  */
  BEGIN
  BEGIN TRY
  IF OBJECT_ID('[con_tpm].[DL_Product_Hierarchy_GB]') IS NOT NULL
          BEGIN
          EXEC ('TRUNCATE TABLE [con_tpm].[DL_Product_Hierarchy_GB]')
		  PRINT 'TRUNCATED DATAMART TABLE SUCCESSFULLY.'
          END 
		
   
      DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
      declare @vNumRows         AS INT           = 0;                                           
 
      DECLARE @execsql              NVARCHAR(max),
			  @tempTableName        nvarchar(max),
			  @feed_name             as NVARCHAR(max)='DL_Product_Hierarchy_GB',
              @curr_timestamp       NVARCHAR(max),
              @columnNames          NVARCHAR(max),
			  @project_name       as  NVARCHAR(max)='TPM',
              @feed_id              INT
	  SET @tempTableName = 'tempdb..#DL_Product_Hierarchy_GB_Temp'
	  IF OBJECT_ID(@tempTableName) IS NOT NULL
	BEGIN
		EXEC ('DROP table '+@tempTableName)
	END
	
	--creating temp table to store records with created_timestamp greater than prev_createdTimeStamp along with row numbers(partitioned by businesskeys and ordered in ascending order of created_timestamp)
	set @execsql='select a.* into '+@tempTableName+' from [con_tpm].[DL_Product_Hierarchy_GB] a WHERE 1=2 '
		
	EXEC(@execsql)
	
			   
      SET @curr_timestamp= CONVERT(NVARCHAR(max), Getdate(), 21)
       
      SET @columnNames = (SELECT String_agg('[' + column_name + ']', ',')
                          FROM   information_schema.columns
                          WHERE  table_schema = 'con_tpm'
                                 AND table_name = 'DL_Product_Hierarchy_GB')
     
	 print  @columnNames
     

      
	  BEGIN TRANSACTION
		
	
          PRINT 'Inserting data to the datamart table started';  		  -- Incremental data insertion
		  
        insert into #DL_Product_Hierarchy_GB_Temp 
([HierarchyCode],
[MemberCode],
[MemberLevel],
[ParentMemberCode],
[ParentMemberLevel],
[created_timestamp],
[ETLRunLogId]) 
 
--WBAPH starts--

select
'WBAPH' as [HierarchyCode],
CASE WHEN len(Item) >50 THEN substring(Item,1,50) ELSE Item END as [MemberCode],
'Sku' as [MemberLevel],
Item_Parent as [ParentMemberCode],
'SkuGroup' as [ParentMemberLevel],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check 
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check ,
--rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check --CRQ82130_WBAPH2hierarchychanges
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
--RefRB.[LOVKey] ReportingBrand,
--RefBG.[LOVKey] BrandGroup
RefPT.[LOVKey] Product_Type,
RefSC.[LOVKey] Sub_Category,
RefRC.[LOVKey] Category --CRQ82130_WBAPH2hierarchychanges
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

/*
INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]
*/ --CRQ82130_WBAPH2hierarchychanges

INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  --AND
--main.Category_to_Brand_check  = 1  AND
--main.Brand_to_BrandGroup_check = 1  ----CRQ82130_WBAPH2hierarchychanges

UNION

select
'WBAPH' as [HierarchyCode],
CASE WHEN len(Item_Parent) >50 THEN substring(Item_Parent,1,50) ELSE Item_Parent END as [MemberCode],
'SkuGroup' as [MemberLevel],
Product_Type as [ParentMemberCode],
'WBAProductType' as [ParentMemberLevel],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check ,
--rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check --CRQ82130_WBAPH2hierarchychanges
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
--RefRB.[LOVKey] ReportingBrand,
--RefBG.[LOVKey] BrandGroup
RefPT.[LOVKey] Product_Type,
RefSC.[LOVKey] Sub_Category,
RefRC.[LOVKey] Category --CRQ82130_WBAPH2hierarchychanges
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

/*
INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]
*/ --CRQ82130_WBAPH2hierarchychanges

INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1 --AND
--main.Category_to_Brand_check  = 1  AND
--main.Brand_to_BrandGroup_check = 1  ----CRQ82130_WBAPH2hierarchychanges

UNION

select
'WBAPH' as [HierarchyCode],
CASE WHEN len(Product_Type) >50 THEN substring(Product_Type,1,50) ELSE Product_Type END as [MemberCode],
'WBAProductType' as [MemberLevel],
Sub_Category as [ParentMemberCode],
'WBASubCategory' as [ParentMemberLevel],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check 
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check ,
--rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check --CRQ82130_WBAPH2hierarchychanges
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
--RefRB.[LOVKey] ReportingBrand,
--RefBG.[LOVKey] BrandGroup
RefPT.[LOVKey] Product_Type,
RefSC.[LOVKey] Sub_Category,
RefRC.[LOVKey] Category --CRQ82130_WBAPH2hierarchychanges
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

/*
INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]
*/ --CRQ82130_WBAPH2hierarchychanges

INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  --AND
--main.Category_to_Brand_check  = 1  AND
--main.Brand_to_BrandGroup_check = 1  ----CRQ82130_WBAPH2hierarchychanges

UNION

select
'WBAPH' as [HierarchyCode],
CASE WHEN len(Sub_Category) >50 THEN substring(Sub_Category,1,50) ELSE Sub_Category END as [MemberCode],
'WBASubCategory' as [MemberLevel],
Category as [ParentMemberCode],
'Segment' as [ParentMemberLevel],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(		

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check 
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check ,
--rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check --CRQ82130_WBAPH2hierarchychanges
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
--RefRB.[LOVKey] ReportingBrand,
--RefBG.[LOVKey] BrandGroup
RefPT.[LOVKey] Product_Type,
RefSC.[LOVKey] Sub_Category,
RefRC.[LOVKey] Category --CRQ82130_WBAPH2hierarchychanges
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

/*
INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]
*/ --CRQ82130_WBAPH2hierarchychanges

INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  --AND
--main.Category_to_Brand_check  = 1  AND
--main.Brand_to_BrandGroup_check = 1  ----CRQ82130_WBAPH2hierarchychanges

UNION

select
'WBAPH' as [HierarchyCode],
CASE WHEN len(Category) >50 THEN substring(Category,1,50) ELSE Category END as [MemberCode],
'Segment' as [MemberLevel],
'Category' as [ParentMemberCode], --CRQ82130_WBAPH2hierarchychanges
'AllSkus' as [ParentMemberLevel], --CRQ82130_WBAPH2hierarchychanges
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(		

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check 
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check ,
--rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check --CRQ82130_WBAPH2hierarchychanges
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
--RefRB.[LOVKey] ReportingBrand,
--RefBG.[LOVKey] BrandGroup
RefPT.[LOVKey] Product_Type,
RefSC.[LOVKey] Sub_Category,
RefRC.[LOVKey] Category --CRQ82130_WBAPH2hierarchychanges
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

/*
INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]
*/ --CRQ82130_WBAPH2hierarchychanges

INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  --AND
--main.Category_to_Brand_check  = 1  AND
--main.Brand_to_BrandGroup_check = 1  ----CRQ82130_WBAPH2hierarchychanges

--WBAPH ends--

/* CRQ82130_WBAPH2hierarchychanges
UNION

select
'WBAPH' as [HierarchyCode],
CASE WHEN len(ReportingBrand) >50 THEN substring(ReportingBrand,1,50) ELSE ReportingBrand END as [MemberCode],
'Brand' as [MemberLevel],
BrandGroup as [ParentMemberCode],
'WBABrandGroup' as [ParentMemberLevel],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by Product_Type ) as ItemParent_to_ProducType_check ,
rank() over(partition by Product_Type order by Sub_Category ) as ProductType_to_SubCategory_check,
rank() over(partition by Sub_Category order by Category ) as SubCategory_to_Category_check 
--rank() over(partition by Category order by ReportingBrand ) as Category_to_Brand_check ,
--rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check --CRQ82130_WBAPH2hierarchychanges
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,


--CONCAT(RefPT.[LOVKey],'(',RefRB.[LOVKey],')') Product_Type,
--RefSC.[LOVKey] Retail_Sub_Category,
--CONCAT(RefSC.[LOVKey],'(',RefRB.[LOVKey],')') Sub_Category,
--CONCAT(RefRC.[LOVKey],'(',RefRB.[LOVKey],')') Category,
--RefRB.[LOVKey] ReportingBrand,
--RefBG.[LOVKey] BrandGroup
RefPT.[LOVKey] Product_Type,
RefSC.[LOVKey] Sub_Category,
RefRC.[LOVKey] Category --CRQ82130_WBAPH2hierarchychanges
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'

INNER JOIN [ser].[ProductGroup] PGPT -- For ProdType
ON PGPT.ProductId = BP.ProductId
AND PGPT.SCDActiveFlag = 'Y'
AND PGPT.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ProductType')
INNER JOIN ser.RefLOV RefPT --Reflov For ProdType
ON PGPT.[LOVGroupId] = RefPT.[LOVId]

INNER JOIN [ser].[ProductGroup] PGSC -- For SubCatg
ON PGSC.ProductId = BP.ProductId
AND PGSC.SCDActiveFlag = 'Y'
AND PGSC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailSubCategory')
INNER JOIN ser.RefLOV RefSC --Reflov For SubCatg
ON PGSC.[LOVGroupId] = RefSC.[LOVId]


INNER JOIN [ser].[ProductGroup] PGRC -- For RetailCatg
ON PGRC.ProductId = BP.ProductId
AND PGRC.SCDActiveFlag = 'Y'
AND PGRC.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'RetailCategory')
INNER JOIN ser.RefLOV RefRC --Reflov For Catg
ON PGRC.[LOVGroupId] = RefRC.[LOVId]

INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_ProducType_check  = 1  AND
main.ProductType_to_SubCategory_check = 1  AND
main.SubCategory_to_Category_check  = 1  AND
main.Category_to_Brand_check  = 1  AND
main.Brand_to_BrandGroup_check = 1  

*/ --CRQ82130_WBAPH2hierarchychanges

UNION

--WBAPH2 start --CRQ82130_WBAPH2hierarchychanges

select
'WBAPH2' as [HierarchyCode],
CASE WHEN len(Item) >50 THEN substring(Item,1,50) ELSE Item END as [MemberCode],
'Sku' as [MemberLevel],
Item_Parent as [ParentMemberCode],
'SkuGroup' as [ParentMemberLevel],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check ,
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,

RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'


INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND
main.Brand_to_BrandGroup_check = 1

UNION

select
'WBAPH2' as [HierarchyCode],
CASE WHEN len(Item_Parent) >50 THEN substring(Item_Parent,1,50) ELSE Item_Parent END as [MemberCode],
'SkuGroup' as [MemberLevel],
ReportingBrand as [ParentMemberCode],
'Brand' as [ParentMemberLevel],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check ,
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,

RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'


INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND
main.Brand_to_BrandGroup_check = 1

UNION

select
'WBAPH2' as [HierarchyCode],
CASE WHEN len(ReportingBrand) >50 THEN substring(ReportingBrand,1,50) ELSE ReportingBrand END as [MemberCode],
'Brand' as [MemberLevel],
BrandGroup as [ParentMemberCode],
'BrandGroup' as [ParentMemberLevel],
@curr_timestamp as[created_timestamp],
@pETLRunLogID as [ETLRunLogId] 
from
(

select * , 
rank() over(partition by Item order by Item_Parent ) as Item_to_ItemParent_check ,
rank() over(partition by Item_Parent order by ReportingBrand ) as ItemParent_to_Brand_check ,
rank() over(partition by ReportingBrand order by BrandGroup ) as Brand_to_BrandGroup_check 
FROM
(

select  distinct 
--BP.ProductId ProductId,
BP.SourceKey Item ,
BP.[ProductName] Item_Description,

(CASE  WHEN PP.SourceKey LIKE 'Unknown%' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey IS NULL THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = '0' THEN CONCAT(BP.SourceKey,'_0')
WHEN PP.SourceKey = 'Not Required' THEN CONCAT(BP.SourceKey,'_0')
ELSE PP.SourceKey
END) AS
 Item_Parent,

RefRB.[LOVKey] ReportingBrand,
RefBG.[LOVKey] BrandGroup
from Ser.Product GRP INNER JOIN Ser.ProductRelationship PR --Get the Golden Record Products
ON GRP.ProductId = PR.FromProductId
and GRP.[LOVRecordSourceId] = 12034
and PR.[SCDActiveFlag] = 'Y'
and GRP.[SCDActiveFlag] = 'Y'

INNER JOIN Ser.Product BP --Filter the Base Products 12025
ON BP.ProductId = PR.ToProductId
AND BP.[LOVRecordSourceId] = 12025
AND BP.[SCDActiveFlag] = 'Y'
AND BP.SourceKey IN
---*****************For Material_Group****
(
SELECT DISTINCT P.[SourceKey]
FROM [ser].[Product] P INNER JOIN [ser].[ProductGroup] PG
ON PG.[ProductId] = P.[ProductId]
AND P.[LOVRecordSourceId] = 12025
AND P.[SCDActiveFlag] = 'Y'
AND P.[LOVSourceKeyTypeId] = 
(
SELECT LOVId from [ser].[RefLOV] where 
[LOVKey] = 'SAP Material Number'
AND 
LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet] where [LOVSetName] = 'Source Key Type'
AND ActiveFlag = 1 and RecordSourceId = 12012)
AND ActiveFlag = 1
and RecordSourceId = 12012
)

AND PG.[LOVRecordSourceId] = 12025
AND PG.[SCDActiveFlag] ='Y'
AND PG.[LOVGroupId] IN  
(
SELECT [LOVId]  
from [ser].[RefLOV] where
LOVKey IN (
SELECT LOVKey
from [ser].[RefLOV] where 
LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_material_group_inclusion'--'material_group' -- 'TPM_Product_material_group_inclusion'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1))
AND LOVSetId = (SELECT LOVSetId from [ser].[RefLOVSet]
          where [LOVSetName] = 'material_group' and [ActiveFlag]=1)
)
)
---************************


AND BP.SourceKey IN
(
SELECT DISTINCT p.SourceKey FROM 
ser.[transaction] t
inner join ser.transactionlineitem tli
on t.transactionid=tli.transactionid
and t.lovrecordsourceid=12025
and t.scdactiveflag='Y'
and t.lovtransactiontypeid=(select lovid from ser.reflov where lovkey='WHOLESALE' and lovsetid=(select lovsetid from ser.reflovset where lovsetname='Transaction Type' and recordsourceid=12012) and recordsourceid=12012)
and tli.scdactiveflag='Y'
inner join ser.product p
on p.productid=tli.productid
and p.scdactiveflag='Y'
and CAST(t.[TransactionDatetime] AS Date) >=  
--Instead of '2019-09-01' USE 'TPM_Product_transaction_date_control' - new set
(
SELECT [LOVKey]  
from [ser].[RefLOV] where 
          LovSetId = (SELECT LovSetID from [ser].[RefLOVSet]
          where [LOVSetName] = 'TPM_Product_transaction_date_control'
          and [RecordSourceId] = 12025 and [ActiveFlag]=1)
)
)

--PR table is not updated to have latest Active Relationships The obsolete Relationships are not updated.
--Below code change to handle the multiple active entries 
INNER JOIN
(
select [FromProductId],[ToProductId] 
from (
select [FromProductId],[ToProductId],
row_number() over(partition by ToProductId order by pr.[ETLRunLogId] desc, p.sourcekey asc ) as row_num
from Ser.ProductRelationship pr
inner join ser.product p
on p.SCDActiveFlag = 'Y' and pr.SCDActiveFlag = 'Y' 
and p.productid=pr.fromproductid
and p.[LOVRecordSourceId]= 12025
and pr.[LOVRecordSourceId]= 12025
) Sub where Sub.row_num=1
) PRP 
on BP.ProductId = PRP.[ToProductId]

INNER JOIN Ser.Product PP --Get the Source Key of the parent ID(ParentProduct)
ON PP.ProductId = PRP.FromProductId
AND PP.[LOVRecordSourceId] = 12025
and PP.[SCDActiveFlag] = 'Y'


INNER JOIN [ser].[ProductGroup] PGRB -- For RepBrnd
ON PGRB.ProductId = BP.ProductId
AND PGRB.SCDActiveFlag = 'Y'
AND PGRB.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'ReportingBrand')
INNER JOIN ser.RefLOV RefRB --Reflov For RepBrand
ON PGRB.[LOVGroupId] = RefRB.[LOVId]


INNER JOIN [ser].[ProductGroup] PGBG -- For BrndGrp
ON PGBG.ProductId = BP.ProductId
AND PGBG.SCDActiveFlag = 'Y'
AND PGBG.LOVProductGroupSetId in (select [LOVSetId] from [ser].[RefLOVSet] where [LOVSetName] = 'BrandGroup')
INNER JOIN ser.RefLOV RefBG --Reflov For BrndGrp
ON PGBG.[LOVGroupId] = RefBG.[LOVId]
and RefBG.[LOVKey] IN ('CPG','Entreprenurial')
)a
)main
where main.Item_to_ItemParent_check  = 1  AND
main.ItemParent_to_Brand_check  = 1  AND
main.Brand_to_BrandGroup_check = 1


--WBAPH2 ends-- CRQ82130_WBAPH2hierarchychanges


          PRINT( 'Inserted records into datamart table '  )
		  
		   insert into [con_tpm].[DL_Product_Hierarchy_GB]
			([HierarchyCode],[MemberCode],[MemberLevel],[ParentMemberCode],[ParentMemberLevel],[created_timestamp],[ETLRunLogId])
			select  
			[HierarchyCode],[MemberCode],[MemberLevel],[ParentMemberCode],[ParentMemberLevel],[created_timestamp],[ETLRunLogId]
			from #DL_Product_Hierarchy_GB_Temp
			
			INSERT into   psa.egress_sp_logs VALUES(@project_name,@feed_name,@pETLRunLogID,@curr_timestamp)

          SELECT @vProcedureStatus  AS ProcedureStatus,
                 @vProcedureMessage AS ProcedureMessage;
				 
			 
       COMMIT TRANSACTION
	   
	   END TRY

    BEGIN CATCH
	IF(@@TRANCOUNT>0)
	ROLLBACK TRANSACTION;
	
			DECLARE @vErrorMessage AS NVARCHAR(500) = 
			(SELECT CONCAT( '{"Error number":'	,'"', ERROR_NUMBER()    ,'"',', '
										  ,'"Error message":' ,'"', ERROR_MESSAGE()   ,'"',', '
											,'"Severity":' ,		 '"', ERROR_SEVERITY()  ,'"',', '
									    ,'"State":'         ,'"', ERROR_STATE()     ,'"',','
											,'"Procedure name":','"', ERROR_PROCEDURE() ,'"','}'
      ))

			SET @vProcedureMessage = @vErrorMessage

      SELECT  '-1' AS ProcedureStatus
            , @vProcedureMessage As ProcedureMessage
      ;



			INSERT INTO [psa].[DNA_DB_Errors_Log] 
			SELECT  SUSER_SNAME(),ERROR_NUMBER(),ERROR_STATE(),
			ERROR_SEVERITY(),'[sp_dl_product_hierarchy_egress]',
			ERROR_MESSAGE(),GETDATE();				
						
    END CATCH;
  END
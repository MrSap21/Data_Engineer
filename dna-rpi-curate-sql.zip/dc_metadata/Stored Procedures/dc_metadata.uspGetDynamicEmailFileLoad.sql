﻿----------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		11/12/2019
--DESCRIPTION:	New SP to get Email Files
--				for LogicApp
----------------------------------------------------
CREATE PROCEDURE [dc_metadata].[uspGetDynamicEmailFileLoad]
AS 

BEGIN
SET NOCOUNT ON

SELECT [FilePatternId]
      ,[SourceFileNamePattern]
      ,[AuthorizedEmailSender]
      ,[BlobPath]
      ,[Retailer]
      ,[ModifiedBy]
      ,[Active]
      ,[LastUpdated]
      ,[LastFileUpdate]
  FROM [dc_metadata].[DynamicEmailFileLoad];

SET NOCOUNT OFF
END
﻿--------------------------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		13/12/2019
--DESCRIPTION:	New SP to retrieve the sharepoint roots for Dynamic
--				Sharepoint File from LogicApp
--------------------------------------------------------------------
CREATE PROC [dc_metadata].[uspGetSharepointRoots] 
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
BEGIN TRY
  SET NOCOUNT ON;  
  SELECT DISTINCT gf.SharepointSite,gf.SharepointRootFolder
  FROM   [dc_metadata].[DynamicSharepointFileLoad] gf;
END TRY
BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
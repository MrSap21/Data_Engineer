﻿----------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		11/12/2019
--DESCRIPTION:	New SP to get Sharepoint Files
--				for LogicApp
----------------------------------------------------
CREATE PROCEDURE [dc_metadata].[uspGetDynamicSharepointFileLoad]
AS 

BEGIN
SET NOCOUNT ON

SELECT [FilePatternId]
      ,[SourceFileNamePattern]
      ,[SharepointFolder]
      ,[BlobPath]
      ,[Retailer]
      ,[ModifiedBy]
      ,[Active]
      ,[LastUpdated]
      ,[SharepointSite]
      ,[SharepointRootFolder]
      ,[LastFileUpdate]
  FROM [dc_metadata].[DynamicSharepointFileLoad];
 
SET NOCOUNT OFF
END
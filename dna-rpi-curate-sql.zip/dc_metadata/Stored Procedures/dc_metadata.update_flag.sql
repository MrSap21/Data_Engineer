﻿-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : update_flag.sql
-- Description : This procedure updates flag.
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                      
-- Name         Date           Description
-- Ann Jose     21-DEC-2021    Created Procedure
-- -----------------------------------------------------------------------------------------------------------------------------------------------------

CREATE PROC [dc_metadata].[update_flag] @flag [nvarchar](5),@env [nvarchar](5),@project [nvarchar](30),@key [nvarchar](25),@proceed_flag [nvarchar](55) OUT AS
BEGIN	
	DECLARE @current_flag nvarchar(5)
	SELECT @current_flag = param_value 
		FROM dc_metadata.GDHDynamicADFParams 
		WHERE Project_name = @project and Environment = @env and param_key = @key;
	if @flag = 'ON'
		BEGIN
		if @current_flag = 'OFF'
			BEGIN
			UPDATE dc_metadata.GDHDynamicADFParams 
				SET param_value = @flag 
				WHERE Environment = @env and Project_name = @project and param_key = @key;
			SET @proceed_flag = '1' + '_update to ON successful and current flag is ' + @current_flag
			SELECT @proceed_flag AS proceed_flag
			END
		else if @current_flag = 'ON'
			BEGIN
			SET @proceed_flag = '0' + '_current flag is on and current flag is ' + @current_flag
			SELECT @proceed_flag AS proceed_flag
			END
		END
	else if @flag = 'OFF'
		BEGIN
		UPDATE dc_metadata.GDHDynamicADFParams 
			SET param_value = @flag 
			WHERE Environment = @env and Project_name = @project and param_key = @key;
		SET @proceed_flag = '1' + '_update to OFF successful and current flag is ' + @current_flag 
		SELECT @proceed_flag AS proceed_flag
		END
	
END
﻿--------------------------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		13/12/2019
--DESCRIPTION:	New SP to update the LastUpdate field dynamically for
--				Sharepoint File from LogicApp
--------------------------------------------------------------------


CREATE PROC [dc_metadata].[uspUpdateEmailIngestFileUpdateDate] 
@FilePatternId [INT],@ModifiedDate [DATETIME2](7) 
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON

BEGIN TRY

    UPDATE dc_metadata.DynamicEmailFileLoad SET LastFileUpdate = @ModifiedDate WHERE FilePatternId = @FilePatternId

END TRY

BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
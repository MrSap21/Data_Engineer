﻿-------------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		23/12/2019
--DESCRIPTION:	New SP to insert audit row for Dynamic
--				Email File from LogicApp
-------------------------------------------------------

CREATE PROC [dc_metadata].[uspInsertRowIntoEmailAudit] 
@EmailSender [VARCHAR](50),
@BlobPath [VARCHAR](255),
@Retailer [VARCHAR](255),
@FileName [VARCHAR](50),
@EmailReceivedTime [VARCHAR](50) 

AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON

BEGIN TRY
	DECLARE @date_time	datetime2(7);
	SET @date_time = GETDATE();
	-- Insert a row using the received parameters
	INSERT INTO [dc_metadata].[DynamicEmailFileLoadAudit]
		VALUES (@date_time,
				@EmailSender,
				@BlobPath,
				@Retailer,
				@FileName,
				@EmailReceivedTime);
END TRY

BEGIN CATCH
	DECLARE @msg nvarchar(2048) = error_message()  
	RAISERROR (@msg, 16, 1)
END CATCH
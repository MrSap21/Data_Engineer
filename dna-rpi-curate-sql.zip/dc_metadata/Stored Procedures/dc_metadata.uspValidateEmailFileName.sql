﻿--------------------------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		23/12/2019
--DESCRIPTION:	New SP to validate the name of the
--				Email File from LogicApp
--------------------------------------------------------------------

CREATE PROC [dc_metadata].[uspValidateEmailFileName] 
@EmailAddress [VARCHAR](100),
@FileName [VARCHAR](50),
@Validated [VARCHAR](1) OUT,
@BlobPath [VARCHAR](255) OUT,
@Retailer [VARCHAR](255) OUT,
@LastFileUpdate [DATETIME2](7) OUT,
@FilePatternId [INT] OUT AS

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON

BEGIN TRY

    DECLARE @ValidPatterns INT = 0;
    SET @Validated = '0';

    -- Select the only row for the valid pattern
    SELECT @FilePatternId	= FilePatternId
		  ,@ValidPatterns  = count(SourceFileNamePattern)
          ,@BlobPath	   = trim(BlobPath)
		  ,@Retailer       = trim(Retailer)
		  ,@LastFileUpdate = LastFileUpdate
    FROM dc_metadata.DynamicEmailFileLoad
    WHERE AuthorizedEmailSender LIKE @EmailAddress
      AND @FileName LIKE SourceFileNamePattern 
      AND Active = '1'
	GROUP BY FilePatternId, trim(BlobPath), trim(Retailer), LastFileUpdate


    IF @ValidPatterns > 0
        BEGIN
            SET @Validated = '1';
        END

END TRY

BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
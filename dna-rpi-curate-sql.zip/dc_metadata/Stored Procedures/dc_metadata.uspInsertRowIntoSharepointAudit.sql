﻿----------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		13/12/2019
--DESCRIPTION:	New SP to insert audit row for Dynamic
--				Sharepoint File from LogicApp
----------------------------------------------------

CREATE PROC [dc_metadata].[uspInsertRowIntoSharepointAudit] 
@SharepointFolder [VARCHAR](255),@BlobPath [VARCHAR](255),@Retailer [VARCHAR](255),@FileName [VARCHAR](50),@SharePointRootFolder [VARCHAR](255),@SharePointSite [VARCHAR](255) 
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON

BEGIN TRY
	
	DECLARE @date_time	datetime2(7);
	
	SET @date_time = SYSDATETIME();

	-- Insert a row using the received parameters
	INSERT INTO [dc_metadata].[DynamicSharepointFileLoadAudit]
		VALUES (@date_time, @SharepointFolder, @BlobPath, @Retailer, @FileName, @SharePointRootFolder, @SharePointSite);


END TRY

BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
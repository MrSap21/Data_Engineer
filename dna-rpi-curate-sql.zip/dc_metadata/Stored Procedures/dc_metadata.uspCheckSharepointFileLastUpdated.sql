﻿--------------------------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		13/12/2019
--DESCRIPTION:	New SP to check the LastUpdate field for
--				Sharepoint File from LogicApp
--------------------------------------------------------------------


CREATE PROC [dc_metadata].[uspCheckSharepointFileLastUpdated] 
@PatternId [INT],
@ModifiedDate [DATETIME2](7),
@Validated [VARCHAR](1) OUT AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON

BEGIN TRY

    DECLARE @UpdatedPatterns INT = 0;
    SET @Validated = '0';

    -- Check if the provided pattern LastFileUpdate is greater or null than the Modified Date of the file
    SET @UpdatedPatterns = (SELECT COUNT(FilePatternId)
							FROM dc_metadata.DynamicSharepointFileLoad
							WHERE FilePatternId = @PatternId
							  AND (@ModifiedDate > LastFileUpdate
									OR LastFileUpdate IS NULL
							  ) 
							  AND Active='1' 
							);

    -- Set the output parameter depending on the former select
    IF @UpdatedPatterns > 0
        BEGIN
            SET @Validated = '1';
        END

END TRY

BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
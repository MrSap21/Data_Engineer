﻿--------------------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		13/12/2019
--DESCRIPTION:	New SP to extract sharepoint file metadata 
--				for the LogicApp
--------------------------------------------------------------

	
CREATE PROC [dc_metadata].[uspGetSharepointLogicAppMetadata] 
@LogicAppName [CHAR](100) 
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
BEGIN TRY
  SET NOCOUNT ON;  
  SELECT DISTINCT ActionName,ServerName,DatabaseName,TRIM(DBSchema),StoredProcedure,(TRIM(DBSchema)+'.'+StoredProcedure) as StoredProcedureFullName
  FROM dc_metadata.DynamicSharepointFileLoadMetadata
    WHERE IsActive=1
	AND LogicAppName=@LogicAppName
END TRY
BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
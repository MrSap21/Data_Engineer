﻿--------------------------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		13/12/2019
--DESCRIPTION:	New SP to validate the sharepoint folder for Dynamic
--				Sharepoint File from LogicApp
--------------------------------------------------------------------


CREATE PROC [dc_metadata].[uspValidateSharepointFolder] @SharepointFolder [VARCHAR](100),@SharepointSite [VARCHAR](255),@SharepointRoot [VARCHAR](255),@Validated [VARCHAR](1) OUT,@BlobRootPath [VARCHAR](50) OUT,@FileRetailer [VARCHAR](50) OUT AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON

BEGIN TRY

    DECLARE @AuthorizedFolders INT = 0;
    SET @Validated = '0';

    -- Get the number of rows that match with the @SharepointFolder
    SET @AuthorizedFolders = (SELECT Count(SharepointFolder)
                              FROM dc_metadata.DynamicSharepointFileLoad
                              WHERE SharepointFolder = @SharepointFolder
							  AND SharepointRootFolder   = @SharepointRoot
							  AND SharepointSite   = @SharepointSite
                              AND Active = '1');

    -- Set the output parameter depending on the former select
    IF @AuthorizedFolders > 0
        BEGIN
			SET @BlobRootPath = (SELECT DISTINCT BlobPath
								   FROM dc_metadata.DynamicSharepointFileLoad
                                   WHERE SharepointFolder = @SharepointFolder
								   AND SharepointRootFolder   = @SharepointRoot
								   AND SharepointSite   = @SharepointSite
                                   AND Active = '1');
		    SET @FileRetailer = (SELECT DISTINCT Retailer
								   FROM dc_metadata.DynamicSharepointFileLoad
                                   WHERE SharepointFolder = @SharepointFolder
								   AND SharepointRootFolder   = @SharepointRoot
								   AND SharepointSite   = @SharepointSite
                                   AND Active = '1');

            SET @Validated = '1';
        END

END TRY

BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
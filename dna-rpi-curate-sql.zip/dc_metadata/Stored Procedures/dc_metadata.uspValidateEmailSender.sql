﻿--------------------------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		23/12/2019
--DESCRIPTION:	New SP to validate the name of the
--				Email Sender from LogicApp
--------------------------------------------------------------------

CREATE PROC [dc_metadata].[uspValidateEmailSender] 
@EmailSender [VARCHAR](100),
@Validated [VARCHAR](1) OUT AS

SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON

BEGIN TRY

    DECLARE @AuthorizedSenders INT = 0;
    SET @Validated = '0';

    -- Get the number of rows that match with the email sender
    SET @AuthorizedSenders = (SELECT Count(AuthorizedEmailSender)
                              FROM dc_metadata.DynamicEmailFileLoad
                              WHERE AuthorizedEmailSender = @EmailSender
                              AND Active = '1');

    -- Set the output parameter depending on the former select
    IF @AuthorizedSenders > 0
        BEGIN
            SET @Validated = '1';
        END

END TRY

BEGIN CATCH
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
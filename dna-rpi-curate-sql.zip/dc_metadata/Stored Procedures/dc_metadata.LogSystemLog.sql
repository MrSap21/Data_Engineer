﻿-- -----------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================================================                                                                        
--                                                                                                                                                      
-- FileName    : LogSystemLog.sql
-- Description : This procedure logs a message to the system log.
--                                                                                                                                                      
-- =============================================================================                                                                        
--                                                                                                                                                      
-- Change History                                                                                                                                      
-- Name         Date           Description
-- Jeff Moss    23-JUL-2019    Added Header
-- Jeff Moss    17-JAN-2020    Removed DROP PROCEDURE
-- -----------------------------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE dc_metadata.LogSystemLog 
 @log_type [nvarchar](254)
,@log_message [nvarchar](MAX)
AS
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
SET XACT_ABORT ON
SET NOCOUNT ON
BEGIN TRY
  BEGIN TRANSACTION
    DECLARE @log_date datetime;
    SET @log_date = GETDATE();
  
    INSERT INTO dc_metadata.systemLog([log_date]
                                     ,[log_type]
                                     ,[log_message]
                             	       )  
    VALUES(@log_date
          ,@log_type
          ,@log_message
  		);
  COMMIT TRANSACTION

END TRY
BEGIN CATCH
  ROLLBACK TRANSACTION
  DECLARE @msg nvarchar(2048) = error_message()  
  RAISERROR (@msg, 16, 1)
END CATCH
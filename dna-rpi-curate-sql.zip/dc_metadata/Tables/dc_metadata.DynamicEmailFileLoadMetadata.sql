﻿CREATE TABLE [dc_metadata].[DynamicEmailFileLoadMetadata]
(
	[ActionID] [int] IDENTITY(1,1) NOT NULL,
	[ActionName] [varchar](255) NULL,
	[ServerName] [varchar](255) NULL,
	[DatabaseName] [varchar](255) NULL,
	[DBSchema] [char](10) NOT NULL,
	[TableName] [varchar](100) NULL,
	[StoredProcedure] [varchar](255) NULL,
	[LastUpdate] [datetime2](7) NOT NULL,
	[IsActive] [bit] NULL,
	[LogicAppName] [varchar](255) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)
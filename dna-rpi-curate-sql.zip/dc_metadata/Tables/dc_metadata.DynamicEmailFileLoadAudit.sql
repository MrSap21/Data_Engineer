﻿CREATE TABLE [dc_metadata].[DynamicEmailFileLoadAudit]
(
	[FileId] [int] IDENTITY(1,1) NOT NULL,
	[LogDate] [datetime2](7) NOT NULL,
	[EmailSender] [varchar](50) NULL,
	[BlobPath] [varchar](255) NOT NULL,
	[Retailer] [varchar](255) NOT NULL,
	[FileName] [varchar](50) NOT NULL,
	[EmailReceivedTime] [varchar](50) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)
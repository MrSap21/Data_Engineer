﻿CREATE TABLE [dc_metadata].[DynamicSharepointFileLoadAudit]
(
	[FileId] [int] IDENTITY(1,1) NOT NULL,
	[LogDate] [datetime2](7) NOT NULL,
	[SharepointFolder] [varchar](255) NULL,
	[BlobPath] [varchar](255) NOT NULL,
	[Retailer] [varchar](255) NOT NULL,
	[FileName] [varchar](50) NOT NULL,
	[SharepointRootFolder] [varchar](255) NULL,
	[SharepointSite] [varchar](255) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)
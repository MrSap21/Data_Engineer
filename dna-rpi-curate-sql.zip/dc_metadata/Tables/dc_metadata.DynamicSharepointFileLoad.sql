﻿----------------------------------------------------
--CREATED BY:	NISHANT NIGAM
--DATED:		11/12/2019
--DESCRIPTION:	Metadata Table for ADF Dynamic
--				Pipeline Azure Storage to LogicApp
----------------------------------------------------
--DROP TABLE [dc_metadata].[DynamicSharepointFileLoad]
CREATE TABLE [dc_metadata].[DynamicSharepointFileLoad]
(
	
	[FilePatternId] [int] NOT NULL,
	[SourceFileNamePattern] [varchar](100) NULL,
	[SharepointFolder] [varchar](255) NULL,
	[BlobPath] [varchar](255) NOT NULL,
	[Retailer] [varchar](50) NOT NULL,
	[ModifiedBy] [varchar](50) NULL,
	[Active] [char](1) NOT NULL,
	[LastUpdated] [datetime2](7) NOT NULL,
	[SharepointSite] [varchar](255) NULL,
	[SharepointRootFolder] [varchar](255) NULL,
	[LastFileUpdate] [datetime2](7) NULL
	
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	HEAP
)
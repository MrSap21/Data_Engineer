﻿CREATE TABLE [dc_metadata].[systemLog](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[log_date] [DATETIME] NOT NULL,
	[log_type] [nvarchar](60) NOT NULL,
	[log_message] [nvarchar](MAX) NULL
) 
WITH
(
    HEAP,
	DISTRIBUTION = REPLICATE
)
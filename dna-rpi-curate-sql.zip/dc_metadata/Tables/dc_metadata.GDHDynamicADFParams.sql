﻿CREATE TABLE [dc_metadata].[GDHDynamicADFParams]
(
	[Project_Name] [nvarchar](200) NOT NULL,
	[Job_name] [nvarchar](200) NULL,
	[Environment] [char](5) NULL,
    [Process_Name] [nvarchar](200) NOT NULL,
	[Param_key] [nvarchar](200) NOT NULL,
	[Param_value] [nvarchar](max) NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	HEAP
);
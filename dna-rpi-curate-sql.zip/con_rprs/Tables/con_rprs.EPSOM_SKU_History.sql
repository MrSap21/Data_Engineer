﻿CREATE TABLE [con_rprs].[EPSOM_SKU_History]
(
	[Product Id] [nvarchar](255) NULL,
	[Store Number] [nvarchar](255) NULL,
	[Operation Code] [nvarchar](255) NULL,
	[DeltaDate] [nvarchar](255) NULL,
	[File Sequence Number] [nvarchar](255) NULL,
	[seq] [int] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [con_rprs].[EPSOM_SAD]
(
	[Operation Code] [nvarchar](255) NULL,
	[Product Id] [nvarchar](255) NULL,
	[Store Number] [nvarchar](255) NULL,
	[DeltaDate] [nvarchar](255) NULL,
	[Planogram ID] [nvarchar](255) NULL,
	[minimal display quantity(MDQ)] [nvarchar](255) NULL,
	[pysical shelf capacity(PSC)] [nvarchar](255) NULL,
	[File Sequence Number] [nvarchar](255) NULL,
	[Seq] [nvarchar](255) NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
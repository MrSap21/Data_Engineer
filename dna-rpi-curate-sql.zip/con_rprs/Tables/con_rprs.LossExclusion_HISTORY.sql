﻿CREATE TABLE [con_rprs].[LossExclusion_HISTORY]
(   
    [Store] nvarchar(255) NOT NULL,
	[Product] nvarchar(255) NOT NULL
	
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
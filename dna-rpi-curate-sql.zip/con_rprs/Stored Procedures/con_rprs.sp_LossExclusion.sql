﻿CREATE PROC [con_rprs].[sp_LossExclusion] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name                : sp_LossExculsion
Purpose                        : Loads Data Mart for Product Loss Exclusion
Target Tables                 : con_rprs.sp_LossExclusion

 

*****************************************************************************************
Default values
************************************************************************************************************

 

                ETLRunLogId                        :  @pETLRunLogID passed as argument

 

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :    Modified By        : Description
==========================================================================================================================

 

10-10-2022   :  Ann Elza Jose      :  Initial Version

 

**************************************************************************************************************************
 */
 
/*--Declarations---*/
    DECLARE @current_datetime DATETIME2;
    DECLARE @vProcedureMessage  NVARCHAR(max) = 'OK',
    @vProcedureStatus NVARCHAR(20) = '0',
    @vNumRows INT          = 0,     
    @LOVSourceKeyTypeId  BIGINT,
    @Siteid  BIGINT,
    @LOVRecordSourceId BIGINT,
    @LOVRoleId INT,
    @srRecordSourceID BIGINT,
    @prRecordSourceID BIGINT;
    
BEGIN    
    SET NOCOUNT ON
    SET @current_datetime = CURRENT_TIMESTAMP
	SET @LOVSourceKeyTypeId = (select LOVId from ser.RefLOV where LOVKey = 'SAP Article Number' AND 
                               LOVSetId = (select LOVSetId from ser.RefLOVSet where lovsetname = 'Source Key Type') AND ActiveFlag = 1)
    SET @LovRecordSourceID = (select LovId from ser.Reflov where LOVSetId = (select LOVSetId from ser.REFLOVSET
                                where LOVSetName = 'System of Record') and LOVKey= 'BTCDSE')
    SET @LOVRoleId = (select LovID from ser.RefLOV where LOVKey = 'Store' AND
                               LovSetID = (select LovSetID from ser.RefLOVSet where LOVsetName = 'Role'))
    SET @Siteid = (select siteid from ser.Site where Site.Sourcekey = 0 AND Site.LOVRecordSourceId = 12012
                                AND LOVSiteTypeId = (select LOVID from ser.RefLov where LOVKey ='0'
                                AND LOVSetID = (select LOVSetID from ser.RefLovSet where LOVsetName = 'Site Type')))
    SET @srRecordSourceID = 12008
    SET @prRecordSourceID = 12008 
 

    BEGIN TRY
	BEGIN
	 EXEC ('TRUNCATE TABLE [con_rprs].LossExclusion')
	 PRINT 'TRUNCATED DATAMART TABLE SUCCESSFULLY.'
	END
    BEGIN TRANSACTION;
 
        INSERT INTO [con_rprs].LossExclusion
        (
            
            [Store] , [Product]
        )
		SELECT 
        sr.SourceKey,pd.SourceKey
        FROM ser.ProductLossExclusion pl	
        INNER JOIN ser.product pd
        ON pd.productID = pl.productID
        and pd.LOVsourcekeytypeid=@LOVSourceKeyTypeId
        AND pd.LOVRecordSourceId = @prRecordSourceID
        AND pd.SCDActiveFlag = 'Y'
        inner join ser.siterole sr
        on sr.siteroleid=pl.SiteRoleID
        and sr.LOVRecordSourceId = @srRecordSourceID
        AND sr.SCDActiveFlag = 'Y'
        AND sr.siteId=@Siteid
        AND sr.LOVRoleId=@LOVRoleId
		where pl.ExportFlag=0
		and pl.scdactiveflag='Y';
    
    PRINT 'Info : Inserted records into datamart table- LossExclusion';
		
		UPDATE ser.ProductLossExclusion set ExportFlag=1 where scdactiveflag='Y';
	PRINT 'Info : Updated records into datamart table- LossExclusion';

         INSERT INTO [con_rprs].LossExclusion_HISTORY
         Select * from  [con_rprs].LossExclusion;
                
    PRINT 'Info : Inserted records into datamart backup table- LossExclusion_HISTORY';     
        
        
          SELECT @vNumRows AS NumRows, @vProcedureStatus  AS ProcedureStatus,
                 @vProcedureMessage AS ProcedureMessage;

 

    COMMIT TRANSACTION;                    
    END TRY
    
    BEGIN CATCH
        THROW
        ROLLBACK TRANSACTION;
    END CATCH 
    
END
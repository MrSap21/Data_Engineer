﻿--/****** Object:  StoredProcedure [con_rprs].[sp_EPSOM_SAD]    Script Date: 9/15/2023 5:27:09 AM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
CREATE PROC [con_rprs].[sp_EPSOM_SAD] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_EPSOM_SAD
Purpose						: Loads Data Mart for Delta SAD
Target Tables             	: con_rprs.EPSOM_SAD

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

10-08-2022   :  Vijay Ganesan  	:  Initial Version

**************************************************************************************************************************
 */
 
/*--Declarations---*/
DECLARE @current_datetime DATETIME2;
	
BEGIN	
	SET NOCOUNT ON
	SET @current_datetime = CURRENT_TIMESTAMP

	BEGIN TRY

	BEGIN
          EXEC ('TRUNCATE TABLE [con_rprs].EPSOM_SAD')
		  PRINT 'TRUNCATED DATAMART TABLE SUCCESSFULLY.'
	END 


	    DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
      declare @vNumRows         AS INT           = 0;       
 
	BEGIN TRANSACTION;
	
	
	/* Inserting the materialisation output to the final extract table */
	
		INSERT INTO [con_rprs].EPSOM_SAD
		(
			[Operation Code],	[Product Id],	[Store Number],	[DeltaDate],	[Planogram ID],	[minimal display quantity(MDQ)],	[pysical shelf capacity(PSC)],	[File Sequence Number],[seq]
		)
		 SELECT 
			[Action],	[Item],	Store,	[Date],	Pog,	MDQ	,PSC,	--FixedWidth
			[Action]+	[Item]+Store+[Date]+	Pog+	MDQ	+PSC+
isnull(FixedWidth,'') +space(40- (len(isnull([Action],'')) +len(isnull([Item],''))+len(isnull(Store,''))+len(isnull([Date],''))
+len(isnull(Pog,''))+len(isnull(MDQ,''))+len(isnull(PSC,''))
			+len(isnull(FixedWidth,'')))) as FixedWidth,seq 
--cast(isnull(FixedWidth,'') +space(80- len(isnull([Action],'')) -len(isnull([Item],''))-len(isnull(Store,''))-len(isnull([Date],''))-len(isnull(Pog,''))-Len(isnull(MDQ,''))-len(isnull(PSC,''))) as char(80))FixedWidth
		FROM [ser].[Delta_SAD_0037];
	PRINT 'Info : Inserted records into datamart table- EPSOM_SAD';

          
					  INSERT INTO [con_rprs].EPSOM_SAD_HISTORY
					  Select * from  [con_rprs].EPSOM_SAD;
                
   PRINT 'Info : Inserted records into datamart backup table- EPSOM_SAD_History';     
		
		
          SELECT @vNumRows AS NumRows, @vProcedureStatus  AS ProcedureStatus,
                 @vProcedureMessage AS ProcedureMessage;

    COMMIT TRANSACTION;		
	truncate table [ser].[Delta_SAD_0037];
	END TRY
	
	BEGIN CATCH
		THROW
		ROLLBACK TRANSACTION;
	END CATCH 
	
END
﻿--/****** Object:  StoredProcedure [con_rprs].[sp_EPSOM_SKU]    Script Date: 9/15/2023 5:28:16 AM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO
CREATE PROC [con_rprs].[sp_EPSOM_SKU] @pETLRunLogID [NVARCHAR](255) AS 
/*
************************************************************************************************************
Procedure Name				: sp_EPSOM_SKU
Purpose						: Loads Data Mart for Delta SKU
Target Tables             	: con_rprs.EPSOM_SKU

*****************************************************************************************
Default values
************************************************************************************************************

				ETLRunLogId						:  @pETLRunLogID passed as argument

*************************************************************************************************************
Modification History
**************************************************************************************************************************
Date         :	Modified By		: Description
==========================================================================================================================

10-08-2022   :  Vijay Ganesan  	:  Initial Version

**************************************************************************************************************************
 */
 
/*--Declarations---*/
DECLARE @current_datetime DATETIME2;
	
BEGIN	
	SET NOCOUNT ON
	SET @current_datetime = CURRENT_TIMESTAMP

	BEGIN TRY

	BEGIN
          EXEC ('TRUNCATE TABLE [con_rprs].EPSOM_SKU')
		  PRINT 'TRUNCATED DATAMART TABLE SUCCESSFULLY.'
	END 


	    DECLARE @vProcedureMessage AS NVARCHAR(max) = 'OK';
      DECLARE @vProcedureStatus AS NVARCHAR(20) = '0';
      declare @vNumRows         AS INT           = 0;       
 
	BEGIN TRANSACTION;
	
	
	/* Inserting the materialisation output to the final extract table */
	
		INSERT INTO [con_rprs].EPSOM_SKU
		(
			[Product Id],	[Store Number],	[Operation Code],	DeltaDate,	[File Sequence Number], [seq]
		)
		SELECT 
			Product,	Store,	[Action],	[Date],	--FixedWidth
			Product+	Store+	[Action]+	[Date]+
			isnull(FixedWidth,'') +space(40- (len(isnull(Product,'')) +len(isnull(Store,''))+len(isnull([Action],''))+len(isnull([Date],''))
			+len(isnull(FixedWidth,'')))) as FixedWidth,seq
	
--			cast(FixedWidth +space(60- len(isnull(Product,'')) -len(isnull(Store,''))-len(isnull([Action],''))-len(isnull([Date],''))-len(isnull(FixedWidth,''))) as char(60))FixedWidth
		FROM [ser].[Delta_SKU_0036];
            
			Insert into [con_rprs].EPSOM_SKU_History
			Select * from [con_rprs].EPSOM_SKU;
                
        PRINT 'Info : Inserted records into datamart table- EPSOM_SKU';
		
		
          SELECT @vNumRows AS NumRows, @vProcedureStatus  AS ProcedureStatus,
                 @vProcedureMessage AS ProcedureMessage;

    COMMIT TRANSACTION;		
	truncate table [ser].[Delta_SKU_0036];
	END TRY
	
	BEGIN CATCH
		THROW
		ROLLBACK TRANSACTION;
	END CATCH 
	
END
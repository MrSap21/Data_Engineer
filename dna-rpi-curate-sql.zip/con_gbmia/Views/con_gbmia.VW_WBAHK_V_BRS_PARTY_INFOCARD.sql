﻿CREATE VIEW [con_gbmia].[VW_WBAHK_V_BRS_PARTY_INFOCARD]
AS
SELECT
    [row_id],
	[OWNER],
	[VENDORCODE],
	[VENDORNAME],
	[BRANDTYPE],
	[CREDITCHECKSTATUS],
	[CONTRACT_STATUS],
	[VENDORSTATUS],
	[INFOCARD_NO],
	[FactoryID],
	[FactoryName],
	[FACTORY_STATUS],
	[COC_STATUS],
	[QMSSTATUS],
	[RELATION_TYPE],
	[OWNER_1],
	[OWNER_2],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_V_BRS_PARTY_INFOCARD_HKSQLDB]
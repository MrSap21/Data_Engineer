﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOR_GROUP]
AS
    Select 
	[row_id],
	[GroupVendorParentCode],
	[GroupVendorParentName],
	cast([Group_Forecast_USDM] as [float]) as [Group_Forecast_USDM],
	cast([Group_Forecast_USDM_FY2] as [float]) as [Group_Forecast_USDM_FY2],
	cast([Group_Forecast_Ranking] as [int]) as [Group_Forecast_Ranking],
	[Group_TOPN],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_DIM_VENDOR_GROUP_HKSQLDB]
﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_ADR7_PAYTERMS]
AS
SELECT
    [row_id],
	[VENDOR_NUMBER],
	[VEND_TERMS_ALW_TYPE],
	[VEND_TERMS_ALLOW_STATUS],
	[VEND_TERMS_ALW_IND],
	[PAYTERMS],
	[EFF_DATE],
	[LASTUPDATE],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_DIM_ADR7_PAYTERMS_HKSQLDB]
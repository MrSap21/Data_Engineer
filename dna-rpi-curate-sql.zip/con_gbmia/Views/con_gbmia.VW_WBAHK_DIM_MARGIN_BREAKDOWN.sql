﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_MARGIN_BREAKDOWN]
AS
SELECT
    [row_id],
	[VENDORCODE],
	[MERCH_OPSTUDY_NBR],
	cast([Sales Units] as float) as [Sales Units],
	cast([Sales Units LY] as float) as [Sales Units LY],
	cast([Sales Dlrs] as money) as [Sales Dlrs],
	cast([Sales Dlrs LY] as money) as [Sales Dlrs LY],
	cast([Profit Dlrs] as money) as [Profit Dlrs],
	cast([Profit Dlrs LY] as money) as [Profit Dlrs LY],
	[DATASOURCE_IDX],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
    from [psa].[WBAHK_DIM_MARGIN_BREAKDOWN_HKSQLDB]
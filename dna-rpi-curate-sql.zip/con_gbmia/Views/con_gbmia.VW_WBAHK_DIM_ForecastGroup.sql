﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_ForecastGroup]
AS
    Select 
		[row_id],
	    [BIZ_CODE],
	    [WBATIER2CODE] ,
	    [ForecastGroup] ,
	    convert(datetime,[FG_CREATED_DT],101) as [FG_CREATED_DT],
		[etl_runlog_id] ,
		[asset_id],
		[record_source_id],
		[row_status],
		[created_timestamp],
		[active_flag]
	from [psa].[WBAHK_DIM_ForecastGroup_HKSQLDB]
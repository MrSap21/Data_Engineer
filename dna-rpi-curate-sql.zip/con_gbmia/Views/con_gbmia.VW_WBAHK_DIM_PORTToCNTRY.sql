﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_PORTToCNTRY]
AS
    Select 
		[row_id],
		[PORTOFLADING],
		[PortDescription],
		cast([Leadtime] as [float]) as [Leadtime],
		[PortArea] ,
		[PortCountry],
		[CNTRY_GRP_CODE],
		[IsAsia],
		[etl_runlog_id] ,
		[asset_id],
		[record_source_id],
		[row_status],
		[created_timestamp],
		[active_flag]
	from [psa].[WBAHK_DIM_PORTToCNTRY_HKSQLDB]
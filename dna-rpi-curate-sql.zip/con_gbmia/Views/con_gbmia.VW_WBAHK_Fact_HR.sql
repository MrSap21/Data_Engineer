﻿CREATE VIEW [con_gbmia].[VW_WBAHK_Fact_HR]
AS
    Select 
	[row_id],
	[PeriodKey_HR],
	[HR_TEAM_CODE],
	[HR_TEAM_NAME_Ref],
	[HRDVCODE],
	cast([DataValue_HR] as [float]) as [DataValue_HR],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_Fact_HR_HKSQLDB]
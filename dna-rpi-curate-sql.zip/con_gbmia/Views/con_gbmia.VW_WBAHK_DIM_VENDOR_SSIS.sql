﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOR_SSIS]
AS
SELECT
    [row_id],
	[VENDORCODE],
	[MERCH_OPSTUDY_NBR],
	[FY_SSIS],
	[ReportPeriod],
	[TEAM_CODE],
	cast([Store Outs] as [float]) as [Store Outs],
	cast([Store Count] as [float]) as [Store Count],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
FROM [psa].[WBAHK_DIM_VENDOR_SSIS_HKSQLDB]
﻿CREATE VIEW [con_gbmia].[VW_WBAHK_TEMP_EthicalSummary]
AS
    Select 
	[row_id],
	[Category],
	[Sub-Category],
	[Factory linked Supplier ID],
	[Supplier],
	[Factory Party ID],
	[Factory],
	convert(datetime,[Assessment Date],101) as[Assessment Date],
	convert(datetime,[Next Re-audit Date],101) as[Next Re-audit Date],
	[Ethical Assessment Rating],
	[Critical Findings],
	[Ethical Status Update],
	[BSC Deadline (FY20)],
	[Upload Fact Sheet Noted],
	[DATASOURCE_IDX],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_TEMP_EthicalSummary_HKSQLDB]
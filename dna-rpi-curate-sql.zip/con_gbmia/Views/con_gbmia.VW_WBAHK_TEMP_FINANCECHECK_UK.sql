﻿CREATE VIEW [con_gbmia].[VW_WBAHK_TEMP_FINANCECHECK_UK]
AS
select
	[row_id],
	[PRIVATE_*Party Id],
	[*Name],
	[*Type],
	[*Classification],
	[Status],
	[Comments],
	convert(datetime,[Credit Check Approved/Rejected Date],101) as[Credit Check Approved/Rejected Date],
	[Credit Check Approved Status],
	convert(datetime,[To be reviewed date],101) as[To be reviewed date],
	cast([FY21 Q2] as [float]) as [FY21 Q2],
	[DATASOURCE_IDX],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
    from [psa].[WBAHK_TEMP_FINANCECHECK_UK_HKSQLDB]
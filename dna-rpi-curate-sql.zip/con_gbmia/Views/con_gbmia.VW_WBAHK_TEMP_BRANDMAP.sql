﻿CREATE VIEW [con_gbmia].[VW_WBAHK_TEMP_BRANDMAP]
AS
    Select 
	[row_id],
	[TEAM_GRP],
	[BRAND],
	[BRAND_TYPECODE],
	[Parent Brand],
	[DATASOURCE_IDX],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_TEMP_BRANDMAP_HKSQLDB]
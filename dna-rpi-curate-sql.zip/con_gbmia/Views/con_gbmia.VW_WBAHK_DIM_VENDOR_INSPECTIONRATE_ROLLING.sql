﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOR_INSPECTIONRATE_ROLLING]
AS
    Select 
	[row_id],
	[FY_INSP],
	[TEAM_CODE],
	[VENDORCODE],
	[INSPECTNAME],
	[INSPECTRESULT],
	cast([PO COUNT] as [int]) as [PO COUNT],
	cast([PASS COUNT] as [int]) as [PASS COUNT],
	cast([FAIL COUNT] as [int]) as [FAIL COUNT],
	cast([CONCES COUNT] as [int]) as [CONCES COUNT],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_DIM_VENDOR_INSPECTIONRATE_ROLLING_HKSQLDB]
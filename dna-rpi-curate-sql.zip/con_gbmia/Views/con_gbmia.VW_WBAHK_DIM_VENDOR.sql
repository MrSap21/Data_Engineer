﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOR]
AS
    Select 
	[row_id],
	[VENDORCODE],
	[VENDORNAME],
	[VENDORGROUP],
    convert(date,[EffectiveDate],101) as[EffectiveDate],
	[GroupVendorParentCode],
	[VendorType],
	[isJBP],
	cast([Forecast_USDM] as [float]) as [Forecast_USDM],
	cast([Forecast_Ranking] as [int]) as [Forecast_Ranking],
	[TOPNGROUP],
	[SOURCE],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_DIM_VENDOR_HKSQLDB]
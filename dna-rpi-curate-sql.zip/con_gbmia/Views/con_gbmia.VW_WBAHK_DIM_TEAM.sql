﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_TEAM]
AS
    Select 
	[row_id],
	cast([SortOrder_Team] as [int]) as [SortOrder_Team],
	[TEAM_CODE],
	[TEAM_NAME],
	[TEAM_CODE_FY16],
	[TEAM_GRP_FY16],
	[TEAM_GRP_FY17],
	[TEAM_GRP],
	[VISIBLE_TEAM],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_DIM_TEAM_HKSQLDB]
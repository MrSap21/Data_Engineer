﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_COLOR]
AS
SELECT
[row_id],
	[ColorCode],
	[ColorName],
	cast([Red] as [int]) as [Red],
	cast([Green] as [int]) as [Green],
	cast([Blue] as [int]) as [Blue],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
    from [psa].[WBAHK_DIM_COLOR_HKSQLDB]
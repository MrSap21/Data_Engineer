﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_CUSTOMER]
AS
    Select 
		[row_id],
	[CUST_CODE] ,
	[CUST_NAME] ,
	convert(datetime,[LASTUPDATED],101) as [LASTUPDATED],
	[etl_runlog_id] ,
	[asset_id],
	[record_source_id] ,
	[row_status],
	[created_timestamp] ,
	[active_flag] 
	from [psa].[WBAHK_DIM_CUSTOMER_HKSQLDB]
﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOR_MOQOAT]
AS
    Select 
	[row_id],
	[VENDORCODE],
	[MERCH_OPSTUDY_NBR],
	cast([MAX_MOQ_US] as [float]) as [MAX_MOQ_US],
	cast([MIN_MOQ_US] as [float]) as [MIN_MOQ_US],
	cast([AVG_MOQ_US] as [float]) as [AVG_MOQ_US],
	cast([MAX_OAT_US] as [float]) as [MAX_OAT_US],
	cast([MAX_MOQ_US] as [float]) as [MIN_OAT_US],
	cast([AVG_OAT_US] as [float]) as [AVG_OAT_US],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_DIM_VENDOR_MOQOAT_HKSQLDB]
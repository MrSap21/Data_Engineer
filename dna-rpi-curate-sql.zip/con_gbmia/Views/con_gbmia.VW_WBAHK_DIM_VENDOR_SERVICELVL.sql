﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOR_SERVICELVL]
AS
SELECT
    [row_id],
	[FY_SL],
	[ReportPeriod_UK],
	[VENDORCODE],
	cast([Actual Sales] as money) as [Actual Sales],
	cast([Probable Lost Sales] as money) as [Probable Lost Sales],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
FROM [psa].[WBAHK_DIM_VENDOR_SERVICELVL_HKSQLDB]
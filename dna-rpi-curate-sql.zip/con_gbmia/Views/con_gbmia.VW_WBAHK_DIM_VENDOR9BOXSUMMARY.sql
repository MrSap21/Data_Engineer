﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOR9BOXSUMMARY]
AS
SELECT
    [row_id] ,
	[VENDORCODE] ,
	[Measurement] ,
	cast([Scoring] as [float]) as [Scoring],
	[etl_runlog_id] ,
	[asset_id] ,
	[record_source_id] ,
	[row_status] ,
	[created_timestamp] ,
	[active_flag] 
FROM [psa].[WBAHK_DIM_VENDOR9BOXSUMMARY_HKSQLDB]
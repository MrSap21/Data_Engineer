﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_ITEM]
AS
    Select 
	
	[row_id],
	[ITEMCODE],
	[ITEMNAME],
	[ItemCatCode] ,
	[BUSINESS_DIM] ,
	[DEPARTMENT_DIM],
	[SUBDEPARTMENT_DIM],
	[DEPARTMENT_DIM_FY16],
	[SUBDEPARTMENT_DIM_FY16],
	[TEAM_CODE_ITEMLVL],
	[CMI_CODE],
	[ItemBrandTypeCode],
	[ITEM_SOURCE],
	[isCMI],
	[OpstudyCode],
	[OpstudyName] ,
	[isReplenishItem],
	FORMAT(convert(datetime,[Conversion_Date],101),'MM/dd/yyyy hh:mm:ss tt') as [Conversion_Date],
	[UpdatedDate],
	[Market],
    [Addressable],
	[etl_runlog_id],
	[asset_id] ,
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_DIM_ITEM_HKSQLDB]
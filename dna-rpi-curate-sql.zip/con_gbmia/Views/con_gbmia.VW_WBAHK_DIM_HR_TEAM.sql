﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_HR_TEAM]
AS
SELECT
    [row_id],
	[HR_TEAM_CODE],
	[HR_TEAM_NAME],
	[HR_TEAM_NAME_FY16],
	[HR_TEAM_NAME_FY17],
	[isVisible_HR],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
    from [psa].[WBAHK_DIM_HR_TEAM_HKSQLDB]
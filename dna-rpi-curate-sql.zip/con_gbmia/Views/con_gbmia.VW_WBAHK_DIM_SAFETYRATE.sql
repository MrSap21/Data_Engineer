﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_SAFETYRATE]
AS
    Select 
		[row_id],
		[MERCH_OPSTUDY_NBR],
		[VENDORCODE],
		[FY],
		[Safety Testing 1st Pass],
		[etl_runlog_id],
		[asset_id],
		[record_source_id],
		[row_status],
		[created_timestamp],
		[active_flag]
	from [psa].[WBAHK_DIM_SAFETYRATE_HKSQLDB]
﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_METRIC_GRP]
AS
    Select 
		[row_id],
		cast([SortOrder_Grp] as [int]) as [SortOrder_Grp],
	    [ParentMetricCode] ,
	    [ParentMetricName] ,
	    [ParentMetricName2] ,
	    [Frequency_Grp] ,
	    [IsVisible_Grp] ,
		[etl_runlog_id] ,
		[asset_id],
		[record_source_id],
		[row_status],
		[created_timestamp],
		[active_flag]
	from [psa].[WBAHK_DIM_METRIC_GRP_HKSQLDB]
﻿CREATE VIEW [con_gbmia].[VW_WBAHK_FactManualDataFY]
AS
SELECT
    [row_id],
	[DataFiscalYear],
	[TEAM_CODE],
	[TEAM_NAME_REF],
	[MetricCode],
	[MetricName_Ref],
	cast([FY_VALUE_RESULT] as [float]) as [FY_VALUE_RESULT],
	cast([FY_VALUE_f_Numerator] as [float]) as [FY_VALUE_f_Numerator],
	cast([FY_VALUE_f_Denominator] as [float]) as [FY_VALUE_f_Denominator],
	convert(datetime,[LASTUPDATED_MD],101) as [LASTUPDATED_MD],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
FROM [psa].[WBAHK_Dashboard_Metric_Parameter_HKSQLDB]
﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOROPS]
AS
SELECT
    [row_id],
	[VENDORCODE],
	[MERCH_OPSTUDY_NBR],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
FROM [psa].[WBAHK_DIM_VENDOROPS_HKSQLDB]
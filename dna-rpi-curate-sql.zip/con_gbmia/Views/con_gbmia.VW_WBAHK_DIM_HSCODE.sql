﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_HSCODE]
AS
    Select 
		[row_id],
		[ITEMCODE],
	    [ITEM_DESCRIPTION],
	    [VENDORCODE] ,
	    [VENDOR_NAME1],
	    [MERCH_OPSTUDY_NBR],
	    [MERCH_OPSTUDY_DESC] ,
	    [PROD_CATEG_CODE],
	    [PROD_CATEG_DESC],
	    [COMP_INFO_PROVIDER_TYPE] ,
	    cast([TARIFF_COMPONENT_SEQ_NUM] as [float]) as [TARIFF_COMPONENT_SEQ_NUM],
	    [COMP_DESCRIPTION] ,
	    [HTS_CLASSIFICATION] ,
		cast(COMP_VALUE_PCT_LIST as [float]) as COMP_VALUE_PCT_LIST,
		cast([COMP_DUTY_PCT_OF_VALUE] as [float]) as [COMP_DUTY_PCT_OF_VALUE],
		cast([COMP_FLAT_DUTY___VALUE] as [float]) as [COMP_FLAT_DUTY___VALUE],
	    [COUNTRY_CODE],
		cast([EFFECTIVE_DATE] as [float]) as [EFFECTIVE_DATE],
	    [ITEM_LIFECYCLE_STATUS] ,
		[etl_runlog_id] ,
		[asset_id],
		[record_source_id],
		[row_status],
		[created_timestamp],
		[active_flag]
	from [psa].[WBAHK_Walgreens_HS_Code_List_HKSQLDB]
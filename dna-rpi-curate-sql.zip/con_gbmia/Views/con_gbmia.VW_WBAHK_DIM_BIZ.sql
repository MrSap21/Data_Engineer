﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_BIZ]
AS
    Select 
		[row_id] ,
	    [BIZ_CODE],
	    [BIZ_BNAME],
	    [etl_runlog_id],
	    [asset_id] ,
	    [record_source_id],
	    [row_status],
	    [created_timestamp],
	    [active_flag]
	from [psa].[WBAHK_DIM_BIZ_HKSQLDB]
﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOR_DEALS]
AS
    Select 
	[row_id],
	[VENDORCODE],
	cast([Full Year Synergy Forecast] as money) as [Full Year Synergy Forecast],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_DIM_VENDOR_DEALS_HKSQLDB]
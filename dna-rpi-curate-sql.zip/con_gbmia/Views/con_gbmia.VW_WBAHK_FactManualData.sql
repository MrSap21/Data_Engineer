﻿CREATE VIEW [con_gbmia].[VW_WBAHK_FactManualData]
AS
SELECT
    [row_id],
	[ForecastRptPeriod],
	[PeriodKey2],
	[DataFiscalYear],
	[DataCalendarYear],
	[DataCalendarMonth],
	[TEAM_CODE],
	[TEAM_NAME_REF],
	[MetricCode],
	[MetricName_Ref],
	[Frequency],
	cast([MONTH_DATAVALUE] as [float]) as [MONTH_DATAVALUE],
	cast([MONTH_Numerator] as [float]) as [MONTH_Numerator],
	cast([MONTH_Denominator] as [float]) as [MONTH_Denominator],
	cast([FY_VALUE] as [float]) as [FY_VALUE],
	convert(datetime,[LASTUPDATED_MT],101) as [LASTUPDATED_MT],
	cast([ROWID_FMD] as [int]) as [ROWID_FMD],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
FROM [psa].[WBAHK_Dashboard_Metric_Grouping_HKSQLDB]
﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_HR_Datatype]
AS 
SELECT 
[row_id],
	[HRDVCODE],
	[HRDVTYPE],
	[isVisible],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
    from [psa].[WBAHK_DIM_HR_Datatype_HKSQLDB]
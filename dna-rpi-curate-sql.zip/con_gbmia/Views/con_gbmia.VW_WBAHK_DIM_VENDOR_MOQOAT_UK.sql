﻿CREATE VIEW [con_gbmia].[VW_WBAHK_DIM_VENDOR_MOQOAT_UK]
AS
    Select 
	[row_id],
	[VENDORCODE],
	cast([MAX_MOQ] as [float]) as [MAX_MOQ],
	cast([MIN_MOQ] as [float]) as [MIN_MOQ],
	cast([AVG_MOQ] as [float]) as [AVG_MOQ],
	cast([MAX_OAT] as [float]) as [MAX_OAT],
	cast([MIN_OAT] as [float]) as [MIN_OAT],
	cast([AVG_OAT] as [float]) as [AVG_OAT],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_DIM_VENDOR_MOQOAT_UK_HKSQLDB]
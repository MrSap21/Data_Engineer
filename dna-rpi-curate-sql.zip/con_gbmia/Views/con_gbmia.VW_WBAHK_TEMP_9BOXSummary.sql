﻿CREATE VIEW [con_gbmia].[VW_WBAHK_TEMP_9BOXSummary]
AS
    Select 
	[row_id],
	[VENDORCODE],
	[etl_runlog_id],
	[asset_id],
	[record_source_id],
	[row_status],
	[created_timestamp],
	[active_flag]
	from [psa].[WBAHK_TEMP_9BOXSummary_HKSQLDB]
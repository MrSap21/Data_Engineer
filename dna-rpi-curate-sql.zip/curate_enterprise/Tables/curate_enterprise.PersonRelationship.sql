﻿CREATE TABLE curate_enterprise.PersonRelationship(
    PersonRelationshipID       nvarchar(40)     NOT NULL,
    SRCRelationshipTypeName    nvarchar(50)     NULL,
    ParentPersonId             nvarchar(40)     NOT NULL,
    ChildPersonId              nvarchar(40)     NOT NULL,
    DeleteIndicator            nvarchar(10)     NULL,
    EffectiveFrom              datetime         NULL,
    EffectiveTo                datetime         NULL,
    MemberUpdateTime           datetime         NULL,
    SourceCreateTime           datetime         NULL,
    SourceUpdateTime           datetime         NULL,
    RecordSourceCode           nvarchar(100)    NULL,
    LOVRecordSourceId          int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
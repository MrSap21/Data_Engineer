﻿CREATE TABLE [Curate_Enterprise].[REFSocialMediaType]
(
	[REFSocialMediaTypeID] [nvarchar](40) NOT NULL,
	[SocialMediaCode] [nvarchar](10) NULL,
	[SocialMediaTypeName] [nvarchar](50) NULL,
	[SocialMediaTypeDescription] [nvarchar](100) NULL,
	[STDSocialMediaType] [nvarchar](100) NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
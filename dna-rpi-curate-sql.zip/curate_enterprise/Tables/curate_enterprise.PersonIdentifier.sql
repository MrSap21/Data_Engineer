﻿Create TABLE curate_enterprise.PersonIdentifier(
    PersonIdentifierId        nvarchar(40)     NOT NULL,
    PersonID                  nvarchar(40)     NOT NULL,
    StaffDiscountCard         nvarchar(100)    NULL,
    NHSNumber                 nvarchar(50)     NULL,
    CHINumber                 nvarchar(50)     NULL,
    HSCNNumber                nvarchar(50)     NULL,
    ADCardNumber              nvarchar(50)     NULL,
    SourceEntityCreateTime    datetime         NULL,
    SourceEntityUpdateTime    datetime         NULL,
    RecordSourceCode          nvarchar(100)    NULL,
    LOVRecordSourceId         int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
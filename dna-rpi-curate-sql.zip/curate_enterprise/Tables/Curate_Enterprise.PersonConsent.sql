﻿CREATE TABLE [Curate_Enterprise].[PersonConsent]
(
	[PersonConsentId] [nvarchar](40) NOT NULL,
	[PersonID] [nvarchar](40) NOT NULL,
	[SRCSystemCode] [nvarchar](10) NULL,
	[ConsentTypeID] [nvarchar](40) NOT NULL,
	[ConsentOptInValue] [char](10) NULL,
	[ConsentUpdateDateTime] [datetime] NULL,
	[EffectiveFromDateTime] [datetime] NULL,
	[EffectiveToDateTime] [datetime] NULL,
	[SourceContentID] [nvarchar](20) NULL,
	[SourceCreateTime] [datetime] NULL,
	[SourceUpdateTime] [datetime] NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
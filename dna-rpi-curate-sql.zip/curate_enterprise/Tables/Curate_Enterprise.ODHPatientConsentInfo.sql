﻿CREATE TABLE [Curate_Enterprise].[ODHPatientConsentInfo]
(
 	[PatientConsentInfoId] [nvarchar](40) NOT NULL,
	[PersonID] [nvarchar](40) NOT NULL,
	[SRCPatientConsentId] [nvarchar](80) NOT NULL,
	[ConsentTypeID] [nvarchar](40) NOT NULL,
	[ConsentTypeName] [nvarchar](100) NULL,
	[ConsentInfoValue] [nvarchar](255) NULL,
	[ConsentInfoVersion] [smallint] NULL,
	[ConsentInfoLabel] [nvarchar](255) NULL,
	[AgreementStatus] [nvarchar](1) NULL,
	[CreationTimeStamp] [datetime] NULL,
	[Deleted] [nvarchar](1) NULL,
	[FieldCode] [smallint] NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[UpdatedBy] [nvarchar](50) NULL,
	[UpdateTimeStamp] [datetime] NULL,
	[FieldInitial] [nvarchar](10) NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
	)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
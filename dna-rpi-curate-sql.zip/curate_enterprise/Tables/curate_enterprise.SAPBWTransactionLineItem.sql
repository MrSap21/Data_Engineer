﻿CREATE TABLE curate_enterprise.SAPBWTransactionLineItem(
    TransactionLineItemId       nvarchar(40)      NOT NULL,
    UnadjustedMargin            decimal(10, 2)    NULL,
    AdjustedMargin              decimal(10, 2)    NULL,
    DiscountFlag                nvarchar(10)      NULL,
    ItemAdcardPointsQuantity    decimal(10, 2)    NULL,
    ItemAdCardPointsValue       decimal(10, 2)    NULL,
    ItemDiscountAmount          decimal(10, 2)    NULL,
    PriceOverrideFlag           nvarchar(10)      NULL,
    Revenue                     decimal(10, 2)    NULL,
    CostofGoods                 decimal(10, 2)    NULL,
    ItemDiscountPercentage      decimal(10, 2)    NULL,
    Takings                     decimal(10, 2)    NULL,
    RecordSourceCode            nvarchar(100)     NOT NULL,
    LOVRecordSourceId           int               NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
    (
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
    )
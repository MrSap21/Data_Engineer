﻿CREATE TABLE curate_enterprise.MarTechEligibleCustomers(
    EligibleCustomersId         nvarchar(40)     NOT NULL,
    CampaignId                  int              NOT NULL,
    GameId                      int              NOT NULL,
    ContactId                   bigint           NOT NULL,
    SourceCreateDateTime        datetime         NOT NULL,
    REFCountryID                nvarchar(40)      NULL,
    SRCCountryID                nvarchar(16)     NULL,
    STDCountryName              nvarchar(50)     NULL,
    CampaignStartDate           date             NULL,
    CampaignEndDate             date             NULL,
    ContactPersonId             nvarchar(40)     NOT NULL,
    CIAMsId                     nvarchar(80)     NULL,
    CIAMSPersonId               nvarchar(40)     NULL,
    DigitalId                   nvarchar(80)     NULL,
    DigitalPersonId             nvarchar(40)     NULL,
    SAPCustomerNumber           nvarchar(20)     NULL,
    SAPCRMPersonId              nvarchar(40)     NULL,
    MaxLimit                    smallint         NULL,
    TotalOpportunitiesEarned    smallint         NULL,
	MarTechEligibleCustomersField1 nvarchar(50)     NULL,
	MarTechEligibleCustomersField2 nvarchar(50)     NULL,
    RecordSourceCode            nvarchar(100)    NULL,
    LOVRecordSourceId           int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
﻿CREATE TABLE curate_enterprise.Till(
    TillId                  nvarchar(40)          NOT NULL,
    TillNumber              nvarchar(25)    NOT NULL,
    TillName                nvarchar(100)    NULL,
	RecordSourceCode        nvarchar(100)    NOT NULL,
    LOVRecordSourceId       int          NOT NULL,
    RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
    (
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
    )
﻿CREATE TABLE curate_enterprise.REFPartyType(
    PartyTypeId          nvarchar(40)     NOT NULL,
    PartyTypeName        nvarchar(100)    NULL,
    RoleDescription      nvarchar(255)    NULL,
    RecordSourceCode     nvarchar(100)    NULL,
    LOVRecordSourceId    int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
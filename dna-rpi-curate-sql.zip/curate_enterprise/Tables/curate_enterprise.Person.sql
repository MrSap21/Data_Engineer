﻿CREATE TABLE curate_enterprise.Person(
    PersonID             nvarchar(40)     NOT NULL,
    PartyId              nvarchar(40)     NOT NULL,
    CustomerNumber       nvarchar(100)     NOT NULL,
    CustomerTypeID       nvarchar(40)     NULL,
    CustomerTypeName     nvarchar(100)    NULL,
    Title                nvarchar(50)     NULL,
    FirstName            nvarchar(500)    NULL,
    MiddleName           nvarchar(500)    NULL,
    LastName             nvarchar(500)    NULL,
    BirthSurname         nvarchar(500)    NULL,
    GenderTypeId         nvarchar(40)     NULL,
    STDGender            nvarchar(50)     NULL,
    SRCGender            nvarchar(50)     NULL,
    DateOfBirth          nvarchar(500)    NULL,
    DateOfDeath          nvarchar(500)    NULL,
    RecordSourceCode     nvarchar(100)    NULL,
    LOVRecordSourceId    int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
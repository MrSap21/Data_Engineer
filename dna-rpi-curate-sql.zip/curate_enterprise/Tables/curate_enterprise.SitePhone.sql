﻿CREATE TABLE [curate_enterprise].[SitePhone](
    PhoneId                   nvarchar(40)     NOT NULL,
    SiteRoleId                nvarchar(40)     NOT NULL,
    PhoneTypeId               nvarchar(40)     NOT NULL,
    PhoneType                 nvarchar(50)     NULL,
    PhoneNumber               nvarchar(50)     NULL,
    MobileValidFlag           nvarchar(1)      NULL,
    PhoneValidFlag            nvarchar(1)      NULL,
    PhoneCertainityFlag       nvarchar(1)      NULL,
    PhoneExtraInfoFlag        nvarchar(1)      NULL,
    DeleteIndicatorFlag       nvarchar(1)      NULL,
    SourceInsertDate          datetime         NULL,
    SourceUpdateDate          datetime         NULL,
    SourceEntityCreateTime    datetime         NULL,
    SourceEntityUpdateTime    datetime         NULL,
    RecordSourceCode          nvarchar(100)    NULL,
    LOVRecordSourceId         int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
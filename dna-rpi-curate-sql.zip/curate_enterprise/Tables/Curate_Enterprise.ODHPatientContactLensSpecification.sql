﻿CREATE TABLE Curate_Enterprise.ODHPatientContactLensSpecification(
    PatientCLSpecificationId       nvarchar(40)      NOT NULL,
    SRCCLSpecificationId           nvarchar(80)      NOT NULL,
    LastUpdate                     datetime          NULL,
    PersonID                       nvarchar(40)      NOT NULL,
    EntityCode                     nvarchar(50)      NULL,
    CreationDate                   datetime          NULL,
    DueDate                        datetime          NULL,
    EntityType                     nvarchar(50)      NULL,
    CreatedBy                      nvarchar(50)      NULL,
    ExpiryDate                     datetime          NULL,
    OnlyLeftlensDetails            smallint          NULL,
    OnlyRightLensDetail            smallint          NULL,
    Source                         nvarchar(50)      NULL,
    Status                         nvarchar(50)      NULL,
    SourceOther                    nvarchar(255)     NULL,
    PrevLensCheckDate              datetime          NULL,
    RecallPeriod                   nvarchar(50)      NULL,
    ReasonOriginalAmendSpecific    nvarchar(1000)    NULL,
    ParentCLSpecificationId        nvarchar(40)      NULL,
    Deleted                        nvarchar(1)       NULL,
    LastCashPurchaseDate           datetime          NULL,
    RecordSourceCode               nvarchar(100)     NULL,
    LOVRecordSourceId              int               NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
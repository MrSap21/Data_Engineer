﻿CREATE TABLE curate_enterprise.CEPGameOpportunities(
    GameOpportunitiesId                nvarchar(40)     NOT NULL,
    EligibleCustomerOpportunitiesId    nvarchar(40)     NULL,
    OpportunityId                      int              NOT NULL,
    Reward                             smallint         NULL,
    RewardType                         nvarchar(255)    NULL,
    GamePlayStartDateTime              datetime         NULL,
    GamePlayEndDateTime                datetime         NULL,
    CreatedDate                        datetime         NULL,
	CEPGameOpportunitiesField4         nvarchar(50)     NULL,
    RecordSourceCode                   nvarchar(100)    NULL,
    LOVRecordSourceId                  int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
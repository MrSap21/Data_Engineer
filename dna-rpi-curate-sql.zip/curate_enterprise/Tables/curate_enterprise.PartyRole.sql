﻿create table curate_enterprise.PartyRole(
    PartyRoleId          nvarchar(40)     NOT NULL,
    PartyId              nvarchar(40)     NOT NULL,
    RoleId               nvarchar(40)     NOT NULL,
    PartyRoleName        nvarchar(100)    NULL,
    RecordSourceCode           nvarchar(100)    NULL,
    LOVRecordSourceId    int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
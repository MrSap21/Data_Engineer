﻿CREATE TABLE [curate_enterprise].[ODHOrderLineIndicator]
(
    ODHOrderLineIndicatorId    		nvarchar(40)     NOT NULL,
    ODHOrderLineId             		nvarchar(40)     NOT NULL,
    Directship                 		char(1)          NULL,
    IsDescription              		char(1)          NULL,
    CancelPriceAD              		char(1)          NULL,
    IsEditLineNetAmt           		char(1)          NULL,
    ManageReservation          		char(1)          NULL,
    ManagePreservation         		char(1)          NULL,
    Explode                    		char(1)          NULL,
    EMHorcusCover              		char(1)          NULL,
    EmHorcusCLCP               		char(1)          NULL,
    EMHorcusPractToSupFrame    		char(1)          NULL,
    EmHorcusRemoteEdging       		char(1)          NULL,
    EmHorcusUncatLens          		char(1)          NULL,
    EMHorcusPaytoCollected     		char(1)          NULL,
    EMHorcusIsCNCLLDLN         		char(1)          NULL,
    EMHorcusPRRTPRCSSD         		char(1)          NULL,
    EMHorcusPractToSupLens     		char(1)          NULL,
    EMHorcusIsOnlyLeftLens     		char(1)          NULL,
    EMHorcusIsOnlyRightLens    		char(1)          NULL,
    EMHorcusInitialSupply      		char(1)          NULL,
    RecordSourceCode           		nvarchar(100)    NULL,
    LOVRecordSourceId          		int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
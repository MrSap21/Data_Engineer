﻿CREATE TABLE curate_enterprise.SAPBWTransactionHeader(
    TransactionId                    nvarchar(40)      NOT NULL,
    PointsMultiplierPercentage       decimal(10, 2)    NULL,
    BTCPointsMultiplierPercentage    decimal(10, 2)    NULL,
    Channel                          nvarchar(10)      NULL,
    IsDiscountCard                   nvarchar(10)      NULL,
    Subchannel                       nvarchar(25)      NULL,
    ErrorIndicator                   nvarchar(10)      NULL,
    PointsChange                     nvarchar(10)      NULL,
    TransactionQualifiedFlag         nvarchar(10)      NULL,
    ValidationBarcode                nvarchar(100)     NULL,
    RecordSourceCode                 nvarchar(100)     NOT NULL,
    LOVRecordSourceId                int               NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
    (
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
    )
﻿CREATE TABLE [curate_enterprise].[ODHPatientAppointment](
    PatientAppointmentId    nvarchar(40)     NOT NULL,
    PersonID                nvarchar(40)     NULL,
    SRCAppointmentId        nvarchar(80)     NOT NULL,
    QFlowCustomerId         nvarchar(50)     NOT NULL,
    Title                   nvarchar(50)     NULL,
    FirstName               nvarchar(100)    NULL,
    LastName                nvarchar(100)    NULL,
    DOB                     date             NULL,
    Address                 nvarchar(255)    NULL,
    UpdateTime              datetime         NULL,
    Deleted                 char(1)          NULL,
    Version                 nvarchar(50)     NULL,
    MatchStatus             nvarchar(255)    NULL,
    TelNumber               nvarchar(50)     NULL,
    Email                   nvarchar(100)     NULL,
    RecordSourceCode        nvarchar(100)    NULL,
    LOVRecordSourceId       int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [curate_enterprise].[SiteEmail](
    EmailID                   nvarchar(40)     NOT NULL,
    SiteRoleId                nvarchar(40)     NOT NULL,
    REFEmailTypeID            nvarchar(40)     NOT NULL,
    EmailType                 nvarchar(50)     NULL,
    EmailAddress              nvarchar(100)    NULL,
    STDEmailType              nvarchar(100)    NULL,
    EmailValidFlag            nvarchar(1)      NULL,
    EmailCertainityFlag       nvarchar(1)      NULL,
    EmailExtraInfoFlag        nvarchar(1)      NULL,
    SourceEntityCreateTime    datetime         NULL,
    SourceEntityUpdateTime    datetime         NULL,
    RecordSourceCode          nvarchar(100)    NULL,
    LOVRecordSourceId         int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
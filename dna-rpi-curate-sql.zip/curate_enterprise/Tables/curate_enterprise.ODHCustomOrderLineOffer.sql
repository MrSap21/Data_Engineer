﻿CREATE TABLE [curate_enterprise].[ODHCustomOrderLineOffer]
(
    HorcusOrderLineOfferId      nvarchar(40)     NOT NULL,
    SRCHorcusOrderLineOfferId   nvarchar(80)     NOT NULL,
    ClientId                    nvarchar(40)     NOT NULL,
    OrganisationID              nvarchar(40)     NOT NULL,
    ODHCustomOrderLineId        nvarchar(40)     NOT NULL,
    OfferId                     nvarchar(40)     NOT NULL,
    IsActive                    char(1)          NULL,
    SourceCreated               datetime         NULL,
    SourceCreatedBy             nvarchar(32)     NULL,
    SourceUpdated               datetime         NULL,
    SourceUpdatedBy             nvarchar(32)     NULL,
    Line                        smallint         NOT NULL,
    OBDISCPCouponId             bigint           NULL,
    PriceOffer                  int              NULL,
    AmtOffer                    int              NULL,
    PriceOfferGross             int              NULL,
    TotalAmt                    int              NULL,
    DisplayedTotalAmt           int              NULL,
    HorcusPromotionalPoint      int              NULL,
    OBDISCQTYOffer              int              NULL,
    OBDISCIdentifier            nvarchar(50)     NULL,
    RecordSourceCode            nvarchar(100)     NULL,
    LOVRecordSourceId           int               NOT NULL,
    RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [curate_enterprise].[ODHPOSAppCashUp]
(
    ODHPOSAppCashUpId            nvarchar(40)     NOT NULL,
	OrganisationID               nvarchar(40)     NOT NULL,
    ClientId                     nvarchar(40)     NOT NULL,
    SRCOBPOSAppCashUpId          nvarchar(80)     NOT NULL,
    IsActive                     char(1)          NULL,
    SourceCreated                date             NULL,
    SourceCreatedBy              nvarchar(32)     NULL,
    SourceUpdated                date             NULL,
    SourceUpdatedBy              nvarchar(32)     NULL,
    ODHPOSApplicationsId         nvarchar(40)     NOT NULL,
    CashUpdate                   date             NULL,
    ADUserId                     nvarchar(40)     NOT NULL,
    CashUpReport                 char(1)          NULL,
    NetSales                     int              NULL,
    GrossSales                   int              NULL,
    NetReturns                   int              NULL,
    GrossReturns                 int              NULL,
    TotalRetailTransactions      int              NULL,
    IsBeingProcessed             char(1)          NULL,
    IsProcessed                  char(1)          NULL,
    IsProcessedBO                int              NULL,
    ParentOBPOSAppCashUpId       nvarchar(40)     NULL,
    EmHorcusApprovalUser         nvarchar(32)     NULL,
    EmHorcusDiscrepancyAmount    int              NULL,
    ODHCustomReasonId  nvarchar(40)     NULL,
    EmHorcusTotalDeposit         int              NULL,
    RecordSourceCode             nvarchar(100)    NULL,
    LOVRecordSourceId            int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [Curate_Enterprise].[ODHClinicalOrderLine]
(
    ClinicalOrderLineId         nvarchar(40)      NOT NULL,
    SRCClinicalOrderLineId      nvarchar(80)      NOT NULL,
    OrderHeaderId               nvarchar(40)      NOT NULL,
    Quantity                    smallint          NULL,
    CatalogType                 nvarchar(50)      NULL,
	ProductId                   nvarchar(40)      NULL,
	SRCProductCode              nvarchar(50)      NULL,
    ProductType                 nvarchar(50)      NULL,
    Deleted                     char(1)           NULL,
    RetailPriceAmount           numeric(24, 4)    NULL,
    RetailPriceISoCode          nvarchar(3)       NULL,
    RetailPriceExcrateId        bigint            NULL,
    Description                 nvarchar(255)     NULL,
    Side                        nvarchar(50)      NULL,
    Available                   char(1)           NULL,
    Brand                       nvarchar(50)      NULL,
    Material                    nvarchar(50)      NULL,
    PackSize                    smallint          NULL,
    BrandExternal               smallint          NULL,
    Manufacturer                nvarchar(20)      NULL,
    SupplierCode                nvarchar(20)      NULL,
    ThirdPartyLensSupplement    smallint          NULL,
    RecordSourceCode            nvarchar(100)     NULL,
    LOVRecordSourceId           int               NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
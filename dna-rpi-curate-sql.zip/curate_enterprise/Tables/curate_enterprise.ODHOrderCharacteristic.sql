﻿CREATE TABLE [curate_enterprise].[ODHOrderCharacteristic]
(
    ODHOrderCharacteristicId    nvarchar(40)      NOT NULL,
    ODHOrderId                  nvarchar(40)      NOT NULL,
    InvoiceRule                 nvarchar(60)      NULL,
    DeliveryRule                nvarchar(60)      NULL,
    FreightCostRule             nvarchar(60)      NULL,
    DeliveryViaRule             nvarchar(60)      NULL,
    PriorityRule                nvarchar(60)      NULL,
    Posted                      nvarchar(60)      NULL,
    DeliveryNotes               nvarchar(2000)    NULL,
    IncotermsDescription        nvarchar(255)     NULL,
    EMHocusAdvantageCard        nvarchar(32)      NULL,
    EMHorcusEmployeeCard        nvarchar(32)      NULL,
    EMHorcusDraftOrderNumber    nvarchar(60)      NULL,
    EMHorcusOldShipmentLine     nvarchar(32)      NULL,
    EMOBKPAYHppSession          nvarchar(50)      NULL,
    EMOBKPAYDistribute          nvarchar(100)     NULL,
    RecordSourceCode            nvarchar(100)     NULL,
    LOVRecordSourceId           int               NOT NULL,
    RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
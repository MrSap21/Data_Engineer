﻿CREATE TABLE curate_enterprise.ETLSourceCodeCustomerType(
    ETLSourceCodeCustomerTypeId  nvarchar(40)     NOT NULL,
    RecordSourceCode             nvarchar(100)    NULL,
    CustomerType                 nvarchar(100)    NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
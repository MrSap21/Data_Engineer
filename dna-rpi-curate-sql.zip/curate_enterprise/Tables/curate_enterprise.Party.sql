﻿CREATE TABLE curate_enterprise.Party(
    PartyId              nvarchar(40)     NOT NULL,
    PartyTypeId          nvarchar(40)     NOT NULL,
    PartyTypeName        nvarchar(100)    NULL,
    SourcePartyCode      nvarchar(100)    NULL,
    SourcePartyName      nvarchar(1000)    NULL,
    RecordSourceCode     nvarchar(100)    NULL,
    LOVRecordSourceId    int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
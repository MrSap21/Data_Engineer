﻿CREATE TABLE curate_enterprise.REFEmailType(
    REFEmailTypeID          nvarchar(40)     NOT NULL,
    EmailTypeCode           nvarchar(10)     NULL,
    EmailTypeName           nvarchar(50)     NULL,
    EmailTypeDescription    nvarchar(100)    NULL,
    STDEmailType            nvarchar(100)    NULL,
    RecordSourceCode        nvarchar(100)    NULL,
    LOVRecordSourceId       int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
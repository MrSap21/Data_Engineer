﻿CREATE TABLE [curate_enterprise].[OrderLine]
(
    OrderLineID                 nvarchar(40)      NOT NULL,
    OrderID                     nvarchar(40)      NOT NULL,
    SourceOrderLineId           nvarchar(100)     NULL,
    IsActive                    nvarchar(1)       NULL,
    Line                        int               NULL,
    DateOrdered                 datetime          NULL,
    DatePromised                datetime          NULL,
    DatePrinted                 datetime          NULL,
    DateDelivered               datetime          NULL,
    DateInvoiced                datetime          NULL,
    Description                 nvarchar(2000)     NULL,
    CreateReservationRequest    nvarchar(1)       NULL,
    ReservationDone             nvarchar(1)       NULL,
    Amount                      decimal(12, 2)    NULL,
    UnitPrice                   decimal(12, 2)    NULL,
    VAT                         decimal(12, 2)    NULL,
    Discount                    decimal(12, 2)    NULL,
    DiscountPercentage          decimal(12, 2)    NULL,
    TotalAmount                 decimal(14, 2)    NULL,
    SRCCreatedDatetime          datetime          NULL,
    SRCUpdateDateTime           datetime          NULL,
    RecordSourceCode            nvarchar(100)     NULL,
    LOVRecordSourceId           int               NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
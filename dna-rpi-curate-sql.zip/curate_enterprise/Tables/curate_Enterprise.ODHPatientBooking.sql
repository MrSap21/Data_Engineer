﻿CREATE TABLE [curate_Enterprise].[ODHPatientBooking]
(
    PatientBookingId        nvarchar(40)     NOT NULL,
    PracticeSiteRoleId      nvarchar(40)     NULL,
    PatientAppointmentId    nvarchar(40)     NULL,
    SRCBookingId            nvarchar(80)     NOT NULL,
    QFlowBookingId          nvarchar(50)     NOT NULL,
    BookingChannel          nvarchar(50)     NULL,
    QFlowCustomerId         nvarchar(50)     NOT NULL,
    BookingDate             date             NULL,
    BookingTime             datetime         NOT NULL,
    BookingDuration         smallint         NULL,
    Clinic                  nvarchar(255)    NULL,
    ServiceType             nvarchar(255)    NULL,
    BookingStatus           nvarchar(255)    NULL,
    Notes                   nvarchar(4000)   NULL,
    Deleted                 nvarchar(1)      NULL,
    Version                 nvarchar(50)     NULL,
	CompositeBookingId      nvarchar(50)     NULL,
    RecordSourceCode        nvarchar(100)    NULL,
    LOVRecordSourceId       int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
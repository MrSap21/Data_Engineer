﻿CREATE TABLE [curate_enterprise].[Appointment](
    AppointmentId          nvarchar(40)     NOT NULL,
    PersonID               nvarchar(40)     NOT NULL,
    SRCPersonId            nvarchar(50)     NULL,
    AppointmentDate        date             NULL,
    AppointmentFromTime    datetime         NULL,
    AppointmentToTime      datetime         NULL,
    AppointmentType        nvarchar(100)    NULL,
    ServiceType            nvarchar(100)    NULL,
    SRCDateCreated         datetime         NULL,
	MatchingStatus         nvarchar(500)    NULL,
    RecordSourceCode       nvarchar(100)    NULL,
    LOVRecordSourceId      int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
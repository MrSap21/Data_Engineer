﻿CREATE TABLE curate_enterprise.ETLRecordSourceCodeMap(
    RecordSourceCodeMapId  nvarchar(40)     NOT NULL,
    RecordSourceCode       nvarchar(100)    NULL,
    DataLynxSourceCode     nvarchar(100)    NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
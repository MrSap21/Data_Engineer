﻿CREATE TABLE [Curate_Enterprise].[SAPCRMADCardMembershipPoints]
(
	[ADCardMembershipPointsId] [nvarchar](40) NOT NULL,
	[PersonID] [nvarchar](40) NOT NULL,
	[CustomerNumber] [nvarchar](20) NULL,
	[AccountNumber] [nvarchar](100) NULL,
	[MembershipTypeCode] [nvarchar](50) NULL,
	[PointsBalance] [numeric](12, 2) NULL,
	[PointsEarned] [numeric](12, 2) NULL,
	[AccountEnrolledDate] [datetime] NULL,
	[AccountTerminatedDate] [datetime] NULL,
	[PointsRedeemed] [numeric](12, 2) NULL,
	[PointsExpired] [numeric](12, 2) NULL,
	[MembershipStatus] [nvarchar](100) NULL,
	[PointAccountId] [nvarchar](100) NULL,
	[GeographyCode] [nvarchar](50) NULL,
	[LatestTransactionDate] [datetime] NULL,
	[ChangedBy] [nvarchar](100) NULL,
	[CreatedByChannel] [smallint] NULL,
	[UpdatedByChannel] [smallint] NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
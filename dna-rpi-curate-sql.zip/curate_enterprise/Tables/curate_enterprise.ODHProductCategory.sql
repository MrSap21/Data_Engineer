﻿CREATE TABLE [curate_enterprise].[ODHProductCategory](
    ODHProductCategoryId           nvarchar(40)     NOT NULL,
    SRCProductCategoryId           nvarchar(80)     NOT NULL,
    OrganisationID                 nvarchar(40)     NOT NULL,
    ClientId                       nvarchar(40)     NOT NULL,
    SourceCreated                  date             NULL,
    SourceCreatedBy                nvarchar(32)     NULL,
    SourceUpdated                  date             NULL,
    SourceUpdatedBy                nvarchar(32)     NULL,
    CategoryValue                  nvarchar(40)     NOT NULL,
    CategoryName                   nvarchar(60)     NULL,
    Description                    nvarchar(255)    NULL,
    IsDefault                      char(1)          NULL,
    PlannedMargin                  int              NULL,
    IsSummary                      char(1)          NULL,
    EmHorcusPriority               int              NULL,
    EmHorcusProductType            nvarchar(60)     NULL,
    EMHorcusPercentageOfPayment    int              NULL,
    EMHorcusIsInclAssortment       char(1)          NULL,
    EMHorcusGenericBasket          char(1)          NULL,
    EmHorcusCustomerBasket         char(1)          NULL,
    RecordSourceCode               nvarchar(100)    NULL,
    LOVRecordSourceId              int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
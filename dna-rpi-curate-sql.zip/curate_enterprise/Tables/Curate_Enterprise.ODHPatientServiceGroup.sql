﻿CREATE TABLE [Curate_Enterprise].[ODHPatientServiceGroup]
(
	[PatientServiceGroupId] [nvarchar](40) NOT NULL,
	[SRCServiceGroupId] [nvarchar](80) NOT NULL,
	[PersonID] [nvarchar](40) NOT NULL,
	[SRCEntityCode] [nvarchar](50) NULL,
	[ServiceGroupType] [nvarchar](50) NOT NULL,
	[LastUpdate] [datetime] NOT NULL,
	[EntityType] [nvarchar](50) NULL,
	[ServiceDateTime] [datetime] NULL,
	[Destination] [nvarchar](50) NULL,
	[Status] [nvarchar](50) NULL,
	[PathStatus] [nvarchar](50) NULL,
	[JourneyStatus] [nvarchar](50) NULL,
	[Deleted] [nvarchar](1) NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
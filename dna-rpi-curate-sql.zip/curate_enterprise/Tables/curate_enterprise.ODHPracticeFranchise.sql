﻿CREATE TABLE [curate_enterprise].[ODHPracticeFranchise](
    ODHPracticeFranchiseId    nvarchar(40)     NOT NULL,
    SRCFranchiseId            nvarchar(80)     NOT NULL,
    PracticeSiteRoleId        nvarchar(40)     NOT NULL,
    Street                    nvarchar(255)    NULL,
    County                    nvarchar(100)    NULL,
    PostCode                  nvarchar(30)     NULL,
    City                      nvarchar(100)    NULL,
	REFCountryID              nvarchar(40)      NULL,
    SRCCountryCode            nvarchar(50)    NULL,
	STDCountryCode            nvarchar(50)    NULL,
    FranchiseNumber           nvarchar(50)     NULL,
    FranchiseBusinessName     nvarchar(255)    NULL,
    FranchiseDirector         nvarchar(255)    NULL,
    CreationTimeStamp         datetime         NULL,
    LastUpdateTimeStamp       datetime         NULL,
    Deleted                   nvarchar(1)      NULL,
    RecordSourceCode          nvarchar(100)    NULL,
    LOVRecordSourceId         int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
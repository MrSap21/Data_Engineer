﻿CREATE TABLE curate_enterprise.SAPCRMADCardCustomer(
    PersonID               nvarchar(40)     NOT NULL,
    BusinessPartnerRole    nvarchar(100)    NULL,
    UserID                 nvarchar(50)     NULL,
    Initial                nvarchar(50)     NULL,
    NOInHousehold          smallint         NULL,
    DonorFlag              smallint         NULL,
    ApplSourceCode         nvarchar(100)    NULL,
    TrafficLight           nvarchar(50)     NULL,
    DoNotMail              nvarchar(100)    NULL,
    GoneAwayDate           nvarchar(20)     NULL,
    CorrectiveEyewear      smallint         NULL,
    ContactPreference      nvarchar(100)    NULL,
    SRCCreateUser          nvarchar(100)    NULL,
    SRCChangeUser          nvarchar(100)    NULL,
    CreatedByChannel       smallint         NULL,
    UpdatedByChannel       smallint         NULL,
    RecordSourceCode       nvarchar(100)    NULL,
    LOVRecordSourceId      int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
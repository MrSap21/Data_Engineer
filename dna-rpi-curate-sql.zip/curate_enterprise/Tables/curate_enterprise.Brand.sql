﻿CREATE TABLE [curate_enterprise].[Brand]
(
    BrandId              			nvarchar(40)     NOT NULL,
    BrandName            			nvarchar(100)    NULL,
    BrandCode            			nvarchar(50)     NULL,
    BrandDescription     			nvarchar(255)    NULL,
    RecordSourceCode     			nvarchar(100)    NULL,
    LOVRecordSourceId    			int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
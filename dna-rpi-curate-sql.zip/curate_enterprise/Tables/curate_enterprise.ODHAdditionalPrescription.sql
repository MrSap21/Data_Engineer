﻿CREATE TABLE [curate_enterprise].[ODHAdditionalPrescription]
(
    PatientPrescriptionId           nvarchar(40)     NOT NULL,
    SRCAdditionalPrescriptionId     nvarchar(80)     NOT NULL,
    PrescriptionCode                nvarchar(100)    NOT NULL,
    ServiceItemCode                 nvarchar(50)     NOT NULL,
    ServiceItemType                 nvarchar(50)     NOT NULL,
    EarlyRetest                     smallint         NULL,
    WalesBand                       smallint         NULL,
    EarlyRetestType                 nvarchar(50)     NULL,
    WalesBandType                   nvarchar(50)     NULL,
    NHSVoucherIssued                smallint         NULL,
    Recall                          nvarchar(50)     NULL,
    ExternalPrescription            smallint         NULL,
    ExternalPrescriptionFrom        nvarchar(50)     NULL,
    ExternalPrescriptionDescript    nvarchar(255)    NULL,
    PrescriptionDate                date             NULL,
    Deleted                         nvarchar(1)      NULL,
    ServiceType                     nvarchar(40)     NULL,
    EnhancedServiceType             nvarchar(40)     NULL,
    ServiceDescription              nvarchar(255)    NULL,
    RefractionPerformed             nvarchar(1)      NULL,
    ClinicianName                   nvarchar(100)    NULL,
    RecordSourceCode                nvarchar(100)    NULL,
    LOVRecordSourceId               int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
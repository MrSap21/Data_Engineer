﻿CREATE TABLE [Curate_Enterprise].[SAPCRMADCardTransactions]
(
	[ADCardTransactionsId] [nvarchar](40) NOT NULL,
	[AccountNumber] [nvarchar](100) NULL,
	[CustomerNumber] [nvarchar](20) NULL,
	[ADCardMembershipActivityId] [nvarchar](40) NOT NULL,
	[ADCardMembershipCardId] [nvarchar](40) NOT NULL,
	[TransactionType] [nvarchar](50) NULL,
	[PointsMovement] [bigint] NULL,
	[CreationTimeStamp] [datetime] NULL,
	[PointsExpiryDate] [datetime] NULL,
	[PointAccountId] [nvarchar](100) NULL,
	[PointType] [nvarchar](100) NULL,
	[ChangeUser] [nvarchar](100) NULL,
	[RewardRuleId] [nvarchar](10) NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [Curate_Enterprise].[ODHOrgType]
(
	[OrgTypeId] [nvarchar](40) NOT NULL,
	[SRCOrgTypeId] [nvarchar](80) NULL,
	[OrganisationID] [nvarchar](40) NULL,
	[ClientId] [nvarchar](40) NULL,
	[IsActive] [char](1) NULL,
	[OrgTypeName] [nvarchar](60) NOT NULL,
	[SourceCreated] [date] NULL,
	[SourceCreatedBy] [nvarchar](32) NULL,
	[SourceUpdated] [date] NULL,
	[SourceUpdatedBy] [nvarchar](32) NULL,
	[IsDefault] [char](1) NULL,
	[Description] [nvarchar](255) NULL,
	[IsLegalEntity] [char](1) NULL,
	[IsBusinessUnit] [char](1) NULL,
	[IsTransactionAllowed] [char](1) NULL,
	[IsAcctLegalEntity] [char](1) NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
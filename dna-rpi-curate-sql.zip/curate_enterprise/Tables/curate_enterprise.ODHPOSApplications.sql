﻿CREATE TABLE [curate_enterprise].[ODHPOSApplications]
(

   ODHPOSApplicationsId        nvarchar(40)      NOT NULL,
    ClientId                    nvarchar(40)      NOT NULL,
    OrganisationID              nvarchar(40)      NOT NULL,
    SRCOBPOSApplicationsId      nvarchar(80)      NOT NULL,
    PersonID                    nvarchar(40)      NOT NULL,
    VendorId                    nvarchar(40)      NULL,
    IsActive                    char(1)           NULL,
    SourceCreated               date              NULL,
    SourceCreatedBy             nvarchar(32)      NULL,
    SourceUpdated               date              NULL,
    SourceUpdatedBy             nvarchar(32)      NULL,
    ApplicationValue            nvarchar(40)      NOT NULL,
    ApplicationName             nvarchar(60)      NULL,
    HardwareUrl                 nvarchar(1024)    NULL,
    ScaleUrl                    nvarchar(1024)    NULL,
    OrderDocNoPrefix            nvarchar(60)      NULL,
    QuotationDocNoPrefix        nvarchar(60)      NULL,
    DefaultWebPOSTab            nvarchar(60)      NULL,
    PrintOffline                char(1)           NULL,
    IsLinked                    char(1)           NULL,
    UnlinkDevice                char(1)           NULL,
    LastAssignedNum             smallint          NULL,
    IsMaster                    char(1)           NULL,
    QuotationLastAssignedNum    smallint          NULL,
    EMHorcusTill                nvarchar(40)      NULL,
    EMOBPOSCSCopyTerminal       char(1)           NULL,
    EmHorcusQuicklyQUTTN        nvarchar(32)      NULL,
    RecordSourceCode            nvarchar(100)     NULL,
    LOVRecordSourceId           int               NOT NULL,
    RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
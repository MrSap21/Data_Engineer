﻿CREATE TABLE [Curate_Enterprise].[ODHPriceListVersion]
(
	[PricelistVersionId] [nvarchar](40) NOT NULL,
	[SRCPriceListVersionId] [nvarchar](32) NOT NULL,
	[ClientId] [nvarchar](40) NOT NULL,
	[OrganisationID] [nvarchar](40) NOT NULL,
	[PriceListVersionName] [nvarchar](60) NOT NULL,
	[ValidFrom] [date] NOT NULL,
	[IsActive] [char](1) NULL,
	[SourceCreated] [date] NULL,
	[SourceCreatedBy] [nvarchar](32) NULL,
	[SourceUpdated] [date] NULL,
	[SourceUpdatedBy] [nvarchar](32) NULL,
	[Description] [nvarchar](255) NULL,
	[OpticianPriceListId] [nvarchar](40) NOT NULL,
	[ProcCreate] [char](1) NULL,
	[PriceListVersionGenerate] [char](1) NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
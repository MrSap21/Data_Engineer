﻿CREATE TABLE [curate_enterprise].[ODHOfferType](
    OfferTypeId           nvarchar(40)     NOT NULL,
    SRCOfferTypeId        nvarchar(80)     NOT NULL,
    OrganisationID        nvarchar(40)     NOT NULL,
    ClientId              nvarchar(40)     NOT NULL,
    IsActive              char(1)          NULL,
    SourceCreated         date             NULL,
    SourceCreatedBy       nvarchar(32)     NULL,
    SourceUpdated         date             NULL,
    SourceUpdatedBy       nvarchar(32)     NULL,
    OfferTypeName         nvarchar(60)     NOT NULL,
    Description           nvarchar(255)    NULL,
    PLOrderImplementor    nvarchar(60)     NULL,
    EMOBPOSIsCategory     char(1)          NULL,
    EMOBPOSImage          nvarchar(32)     NULL,
    EMHorcusPRMTNTP       nvarchar(60)     NULL,
    RecordSourceCode      nvarchar(100)    NULL,
    LOVRecordSourceId     int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
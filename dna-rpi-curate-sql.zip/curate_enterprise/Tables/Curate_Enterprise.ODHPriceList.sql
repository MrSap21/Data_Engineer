﻿CREATE TABLE [Curate_Enterprise].[ODHPriceList]
(
	[OpticianPriceListId] [nvarchar](40) NOT NULL,
	[SRCPriceListId] [nvarchar](32) NOT NULL,
	[OrganisationID] [nvarchar](40) NOT NULL,
	[ClientId] [nvarchar](40) NOT NULL,
	[PriceListName] [nvarchar](60) NOT NULL,
	[SourceCreated] [date] NULL,
	[SourceCreatedBy] [nvarchar](32) NULL,
	[SourceUpdated] [date] NULL,
	[SourceUpdatedBy] [nvarchar](32) NULL,
	[Description] [nvarchar](255) NULL,
	[IsTaxIncluded] [char](1) NULL,
	[IsSoPriceList] [char](1) NULL,
	[IsDefault] [char](1) NULL,
	[SRCCurrencyId] [nvarchar](32) NULL,
	[EnforcePriceLimit] [char](1) NULL,
	[CostBased] [char](1) NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
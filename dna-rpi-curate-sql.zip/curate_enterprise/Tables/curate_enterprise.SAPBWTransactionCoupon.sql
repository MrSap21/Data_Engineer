﻿CREATE TABLE curate_enterprise.SAPBWTransactionCoupon(
    SAPBWTransactionCouponId    nvarchar(40)     NOT NULL,
    TransactionId               nvarchar(40)     NOT NULL,
    CouponBarCode               nvarchar(100)    NOT NULL,
    CouponType                  nvarchar(10)     NULL,
    CouponValue                 nvarchar(100)    NULL,
    CouponValueOverride         nvarchar(10)     NULL,
    CouponWandedQuantity        int              NULL,
    RecordSourceCode            nvarchar(100)    NOT NULL,
    LOVRecordSourceId           int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
    (
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
    )
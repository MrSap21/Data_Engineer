﻿CREATE TABLE [curate_enterprise].[ODHClinicalOrderLineLens]
(
    OrderLineLensId               	nvarchar(40)      NOT NULL,
    SRCClinicalOrderLineLensId    	nvarchar(80)      NOT NULL,
    ClinicalOrderLineId           	nvarchar(40)      NOT NULL,
    LensFinishExternalRef         	nvarchar(50)      NULL,
    LensFinishValue               	nvarchar(50)      NULL,
    ManufacturerLeadTime          	smallint          NULL,
    TintTypeExternalRef           	nvarchar(50)      NULL,
    TintTypeValue                 	nvarchar(50)      NULL,
    TintColorValue                	nvarchar(50)      NULL,
    TintColorExternalRef          	nvarchar(50)      NULL,
    TintDepthExternalRef          	nvarchar(50)      NULL,
    TintDepthValue                	nvarchar(50)      NULL,
    VisionType                    	nvarchar(50)      NULL,
    VisionSubType                 	nvarchar(50)      NULL,
    FinishCode                    	nvarchar(50)      NULL,
    LensIndex                     	numeric(15, 5)    NULL,
    TintCode                      	nvarchar(50)      NULL,
    ToOrder                       	smallint          NULL,
    Deleted                       	nvarchar(1)       NULL,
    BlankDiam                     	numeric(15, 5)    NULL,
    VDec                          	numeric(15, 5)    NULL,
    HDesc                         	numeric(15, 5)    NULL,
    BlankDiamterAngle             	numeric(15, 5)    NULL,
    IsStock                       	smallint          NULL,
    Thickness                     	numeric(15, 5)    NULL,
    RecordSourceCode              	nvarchar(100)     NULL,
    LOVRecordSourceId             	int               NOT NULL,
    RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [curate_enterprise].[ODHBrand]
(
    BrandId               			nvarchar(40)     NOT NULL,
    SRCBrandId            			nvarchar(80)     NULL,
    IsActive              			char(1)          NULL,
    OrganisationID        			nvarchar(40)     NOT NULL,
    ClientId              			nvarchar(40)     NOT NULL,
    SourceCreated         			date             NOT NULL,
    SourceCreatedBy       			nvarchar(32)     NULL,
    SourceUpdated         			date             NULL,
    SourceUpdatedBy       			nvarchar(32)     NULL,
    EMHorcusIsExternal    			char(1)          NULL,
    RecordSourceCode      			nvarchar(100)    NULL,
    LOVRecordSourceId     			int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
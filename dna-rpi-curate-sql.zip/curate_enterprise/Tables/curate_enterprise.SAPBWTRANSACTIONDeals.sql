﻿CREATE TABLE curate_enterprise.SAPBWTRANSACTIONDeals(
    SAPBWTransactionDealID    nvarchar(40)     NOT NULL,
    TransactionId             nvarchar(40)     NOT NULL,
    PromotionNumber           nvarchar(50)     NOT NULL,
    DealNumber                nvarchar(50)     NOT NULL,
    DEALNoOfItems             nvarchar(20)     NULL,
    UnitOfMeasureId           nvarchar(40)     NULL,
    DEALTotalSavingMoney      nvarchar(100)    NULL,
    DEALTotalSavingPoints     nvarchar(100)    NULL,
    DEALTypeFlag              nvarchar(10)     NULL,
    RetailLocation            nvarchar(100)    NULL,
    RecordSourceCode          nvarchar(100)    NOT NULL,
    LOVRecordSourceId         int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
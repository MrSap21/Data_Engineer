﻿CREATE TABLE curate_enterprise.PartyToEntity(
    PartyToEntityId      nvarchar(40)     NOT NULL,
    PersonID             nvarchar(40)     NULL,
    OrganisationID       nvarchar(40)     NULL,
    UserId               nvarchar(40)     NULL,
    ClientId             nvarchar(40)     NULL,
	VendorId             nvarchar(40)     NULL,
    PartyId              nvarchar(40)     NOT NULL,
    RecordSourceCode     nvarchar(100)    NULL,
    LOVRecordSourceId    int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
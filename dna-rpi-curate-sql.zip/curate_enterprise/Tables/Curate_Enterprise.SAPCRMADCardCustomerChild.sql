﻿CREATE TABLE [Curate_Enterprise].[SAPCRMADCardCustomerChild]
(
	[ADCardCustomerChildId] [nvarchar](40) NOT NULL,
	[PersonID] [nvarchar](40) NOT NULL,
	[CustomerNumber] [nvarchar](20) NULL,
	[ChildNumber] [smallint] NULL,
	[DateType] [nvarchar](50) NULL,
	[ChildDOB] [nvarchar](500) NULL,
	[ChildForeName] [nvarchar](500) NULL,
	[ChildGender] [nvarchar](50) NULL,
	[IUDFlag] [nvarchar](10) NULL,
	[CreateUser] [nvarchar](100) NULL,
	[ChangeUser] [nvarchar](100) NULL,
	[CreatedByChannel] [smallint] NULL,
	[UpdatedByChannel] [smallint] NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
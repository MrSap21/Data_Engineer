﻿CREATE TABLE curate_enterprise.REFCountry(
    REFCountryID        nvarchar(40)      NOT NULL,
    CountryCode         nvarchar(5)      NULL,
    CountryName         nvarchar(50)     NULL,
    STDCountryName      nvarchar(100)    NULL,
    STDCountryCode      nvarchar(10)     NULL,
    ISOCountryCode      nvarchar(3)      NULL,
    RecordSourceCode    nvarchar(100)    NULL,
	LOVRecordSourceId     int            NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
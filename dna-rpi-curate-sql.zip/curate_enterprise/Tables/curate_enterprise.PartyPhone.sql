﻿CREATE TABLE [curate_enterprise].[PartyPhone]
(
	[PhoneId] [nvarchar](40) NOT NULL,
	[PartyId] [nvarchar](40) NOT NULL,
	[PhoneTypeId] [nvarchar](40) NOT NULL,
	[SRCPhoneType] [char](500) NULL,
	[PhoneType] [nvarchar](50) NULL,
	[PhoneNumber] [nvarchar](500) NULL,
	[MobileValidFlag] [nvarchar](1) NULL,
	[PhoneValidFlag] [nvarchar](1) NULL,
	[PhoneCertainityFlag] [nvarchar](10) NULL,
	[PhoneExtraInfoFlag] [nvarchar](10) NULL,
	[DeleteIndicatorFlag] [nvarchar](1) NULL,
	[SourceInsertDate] [datetime] NULL,
	[SourceUpdateDate] [datetime] NULL,
	[SourceEntityCreateTime] [datetime] NULL,
	[SourceEntityUpdateTime] [datetime] NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
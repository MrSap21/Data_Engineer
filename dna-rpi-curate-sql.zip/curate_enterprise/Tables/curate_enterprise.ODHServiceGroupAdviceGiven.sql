﻿CREATE TABLE [curate_enterprise].[ODHServiceGroupAdviceGiven]
(
    ServiceGroupAdviceGivenId    	nvarchar(40)     NOT NULL,
    SRCAdviceGivenId             	nvarchar(80)     NOT NULL,
    ServiceItemCode                 nvarchar(40)     NOT NULL,
    ServiceItemType              	nvarchar(50)     NOT NULL,
    Correction                   	nvarchar(1)      NULL,
    CorrectionType               	nvarchar(50)     NULL,
    FullTimeWear                 	nvarchar(1)      NULL,
    PartTimeWear                 	nvarchar(1)      NULL,
    NoCorrection                 	nvarchar(1)      NULL,
    SuitableContactLenses        	nvarchar(1)      NULL,
    Referral                     	nvarchar(1)      NULL,
    ReferralType                 	nvarchar(50)     NULL,
    BookFurtherAppointment       	nvarchar(1)      NULL,
    Deleted                      	nvarchar(1)      NULL,
    RecordSourceCode             	nvarchar(100)    NULL,
    LOVRecordSourceId            	int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
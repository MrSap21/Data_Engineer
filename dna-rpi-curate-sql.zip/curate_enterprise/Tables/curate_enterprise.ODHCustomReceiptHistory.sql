﻿CREATE TABLE [curate_enterprise].[ODHCustomReceiptHistory](
    ODHCustomReceiptHistoryId         nvarchar(40)     NOT NULL,
    SRCHorcusReceiptHistoryId         nvarchar(80)     NOT NULL,
    OrganisationID                    nvarchar(40)     NOT NULL,
    ODHOrderId                        nvarchar(40)     NOT NULL,
    ClientId                          nvarchar(40)     NOT NULL,
    IsActive                          char(1)          NULL,
    SourceCreated                     date             NULL,
    SourceCreatedBy                   nvarchar(32)     NULL,
    SourceUpdated                     date             NULL,
    SourceUpdatedBy                   nvarchar(32)     NULL,
    BasketStatus                      nvarchar(60)     NULL,
    TransactionType                   nvarchar(60)     NULL,
    ReceiptNumber                     nvarchar(40)     NOT NULL,
    ReceiptDate                       date             NULL,
    RecordSourceCode                  nvarchar(100)    NULL,
    LOVRecordSourceId                 int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
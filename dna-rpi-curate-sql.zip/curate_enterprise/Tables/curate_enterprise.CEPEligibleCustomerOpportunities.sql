﻿CREATE TABLE curate_enterprise.CEPEligibleCustomerOpportunities(
    EligibleCustomerOpportunitiesId    nvarchar(40)     NOT NULL,
    CustomerEligibilityId              nvarchar(80)     NULL,
    CampaignId                         int              NOT NULL,
    GameId                             int              NOT NULL,
    REFCountryID                       nvarchar(40)      NULL,
    SRCCountryId                       nvarchar(16)     NULL,
    STDCountryName                     nvarchar(50)     NULL,
    ContactId                          bigint           NOT NULL,
    ContactPersonId                    nvarchar(40)     NOT NULL,
    ObfuscatedCustomerId               nvarchar(80)     NULL,
    CIAMsId                            nvarchar(80)     NULL,
    CIAMSPersonId                      nvarchar(40)     NULL,
    InitialCEPEligibility              smallint         NULL,
    Channel                            nvarchar(100)    NULL,
    EventVersion                       nvarchar(100)    NULL,
    EventId                            nvarchar(100)    NULL,
    EventName                          nvarchar(100)    NULL,
    Producer                           nvarchar(100)    NULL,
    CreatedDate                        datetime         NULL,
    RecordSourceCode                   nvarchar(100)    NULL,
    LOVRecordSourceId                  int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
    (
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
    )
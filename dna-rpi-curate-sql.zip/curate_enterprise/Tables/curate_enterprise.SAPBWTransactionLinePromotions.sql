﻿CREATE TABLE curate_enterprise.SAPBWTransactionLinePromotions(
    TransactionPromotionsId    nvarchar(40)      NOT NULL,
    TransactionId              nvarchar(40)      NOT NULL,
    PromotionNumber            nvarchar(20)      NOT NULL,
    DealNumber                 nvarchar(10)      NOT NULL,
    ProductId                  nvarchar(40)      NULL,
    ItemCode                   nvarchar(50)      NOT NULL,
    UnitOfMeasureId            nvarchar(40)      NULL,
    ItemDealCount              nvarchar(10)      NULL,
    ItemTransactionUnits       decimal(12, 2)    NULL,
    RewardPoints               nvarchar(100)     NULL,
    RewardMoney                nvarchar(100)     NULL,
    NumberofQualifiedDeals     nvarchar(10)      NULL,
    TransactionType            nvarchar(10)      NULL,
    ItemBasePoints             nvarchar(100)     NULL,
    ItemBaseSplitPoint         nvarchar(100)     NULL,
    RecordSourceCode           nvarchar(100)     NOT NULL,
    LOVRecordSourceId          int               NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
    (
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
    )
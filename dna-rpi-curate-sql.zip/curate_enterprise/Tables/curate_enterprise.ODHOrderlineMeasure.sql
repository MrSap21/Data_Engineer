﻿CREATE TABLE [curate_enterprise].[ODHOrderlineMeasure]
(
    ODHOrderLineMeasureId    nvarchar(40)     NOT NULL,
    ODHOrderLineId           nvarchar(40)     NOT NULL,
    QTYOrderd                int              NULL,
    QTYReserved              int              NULL,
    QTYDeliverd              int              NULL,
    QTYInvoiced              int              NULL,
    PriceList                int              NULL,
    PriceActual              int              NULL,
    PriceLimit               int              NULL,
    LineNetAmt               int              NULL,
    Discount                 int              NULL,
    FreightAmt               int              NULL,
    ChargeAmt                int              NULL,
    QuantityOrder            int              NULL,
    PriceSTD                 numeric(15, 2)   NULL,
    TaxBaseAmt               int              NULL,
    GrossUnitPrice           int              NULL,
    LineGrossAmount          numeric(15, 2)   NULL,
    GrossPriceList           int              NULL,
    GrossPriceStd            int              NULL,
    RecordSourceCode         nvarchar(100)    NULL,
    LOVRecordSourceId        int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE curate_enterprise.REFCustomerNumberType(
    CustomerTypeID       nvarchar(40)     NOT NULL,
    CustomerTypeName     nvarchar(100)    NULL,
    CustomerTypeCode     nvarchar(50)     NULL,
    Description          nvarchar(255)    NULL,
    RecordSourceCode     nvarchar(100)    NULL,
    LOVRecordSourceId    int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
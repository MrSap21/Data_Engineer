﻿CREATE TABLE [curate_enterprise].[ODHServiceGroupEyeCheckup](
    ServiceGroupEyeCheckupId    nvarchar(40)     NOT NULL,
    SRCEyeCheckupId             nvarchar(80)     NOT NULL,
    PatientServiceGroupId  nvarchar(40)     NOT NULL,
    EyeCheckupDateTime          datetime         NULL,
    LastUpdate                  datetime         NULL,
    Duration                    smallint         NULL,
    Status                      nvarchar(50)     NULL,
    PathStatus                  nvarchar(50)     NULL,
    ServiceType                 nvarchar(50)     NULL,
    StartTime                   datetime         NULL,
    EndTime                     datetime         NULL,
    Deleted                     nvarchar(1)      NULL,
    CreatedBy                   nvarchar(50)     NULL,
    UpdatedBy                   nvarchar(50)     NULL,
    RecordSourceCode            nvarchar(100)    NULL,
    LOVRecordSourceId           int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
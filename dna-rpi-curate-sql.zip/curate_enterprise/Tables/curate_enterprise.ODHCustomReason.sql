﻿CREATE TABLE [curate_enterprise].[ODHCustomReason]
(
    ODHCustomReasonId         		nvarchar(40)     NOT NULL,
    OrganisationID            		nvarchar(40)     NOT NULL,
    ClientId                  		nvarchar(40)     NOT NULL,
    IsActive                  		char(1)          NULL,
    SRCHorcusReasonId         		nvarchar(80)     NOT NULL,
    SourceCreated             		date             NULL,
    SourceCreatedBy           		nvarchar(32)     NULL,
    SourceUpdated             		date             NULL,
    SourceUpdatedBy           		nvarchar(32)     NULL,
    ReasonValue               		nvarchar(255)    NOT NULL,
    ReasonName                		nvarchar(255)    NULL,
    ReasonType                		nvarchar(100)    NULL,
    RecordSourceCode          		nvarchar(100)    NULL,
    LOVRecordSourceId         		int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
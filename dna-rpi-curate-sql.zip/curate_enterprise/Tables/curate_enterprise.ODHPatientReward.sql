﻿CREATE TABLE [curate_enterprise].[ODHPatientReward]
(
    PatientRewardId        			nvarchar(40)     NOT NULL,
    SRCRewardSchemeId      			nvarchar(80)     NOT NULL,
    PersonID               			nvarchar(40)     NOT NULL,
    CreationDate           			datetime         NOT NULL,
    EntityCode             			nvarchar(50)     NULL,
    LastUpdate             			datetime         NULL,
    EntityType             			nvarchar(50)     NULL,
    PracticeSiteRoleId     			nvarchar(40)     NULL,
    ExpiryDate             			date             NULL,
    PlanStatus             			nvarchar(50)     NULL,
    SchemeNumber           			nvarchar(50)     NULL,
    CLRecallDate           			datetime         NULL,
    ApprovedBy             			nvarchar(50)     NULL,
    Deleted                			nvarchar(1)      NULL,
    Draft                  			nvarchar(1)      NULL,
    Discontinued           			nvarchar(1)      NULL,
    CancellationReason     			nvarchar(255)    NULL,
    ADCardNumber           			nvarchar(50)     NULL,
    ADCardNumberDisplay    			nvarchar(1)      NULL,
    DeliveryAddressType    			nvarchar(50)     NULL,
    TACReportDate          			datetime         NULL,
    DDlReportDate          			datetime         NULL,
    CancellationDate       			date             NULL,
    SuspensionDate         			date             NULL,
    ReinstatementDate      			date             NULL,
    TillId                 			nvarchar(10)     NULL,
    RecordSourceCode       			nvarchar(100)    NULL,
    LOVRecordSourceId      			int              NOT NULL,
    RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
﻿CREATE TABLE [curate_enterprise].[ODHDocumentType]
(
    DocumentTypeId       			nvarchar(40)      NOT NULL,
    SRCDocumentTypeId    			nvarchar(80)      NOT NULL,
    OrganisationID       			nvarchar(40)      NOT NULL,
    ClientId             			nvarchar(40)      NOT NULL,
    IsActive             			char(1)           NULL,
    SourceCreated        			date              NULL,
    SourceCreatedBy      			nvarchar(32)      NULL,
    SourceUpdated        			date              NULL,
    SourceUpdatedBy      			nvarchar(32)      NULL,
    DocumentTypeName     			nvarchar(60)      NOT NULL,
    PrintName            			nvarchar(60)      NULL,
    Description          			nvarchar(255)     NULL,
    DocBaseType          			nvarchar(60)      NULL,
    ISSOTRX              			char(1)           NULL,
    DocsSubTypeSO        			nvarchar(60)      NULL,
    DocumentNote         			nvarchar(2000)    NULL,
    IsDefault            			char(1)           NULL,
    DocumentCopies       			nvarchar(10)      NULL,
    OrgFiltered          			char(1)           NULL,
    IsExpense            			char(1)           NULL,
    IsReversal           			char(1)           NULL,
    IsReturn             			char(1)           NULL,
    RecordSourceCode     			nvarchar(100)     NULL,
    LOVRecordSourceId    			int               NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
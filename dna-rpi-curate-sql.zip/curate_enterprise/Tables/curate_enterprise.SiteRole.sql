﻿CREATE TABLE [Curate_Enterprise].[SiteRole]
(
	[SiteRoleId] [nvarchar](40) NOT NULL,
	[SiteId] [nvarchar](40) NOT NULL,
	[RoleId] [nvarchar](40) NOT NULL,
	[SourceSiteRoleCode] [nvarchar](100) NULL,
	[SourceKeyTypeCode] [nvarchar](50) NULL,
	[SiteRoleName] [nvarchar](100) NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
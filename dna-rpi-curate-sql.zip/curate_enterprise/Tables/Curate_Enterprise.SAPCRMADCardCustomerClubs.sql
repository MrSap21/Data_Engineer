﻿CREATE TABLE [Curate_Enterprise].[SAPCRMADCardCustomerClubs]
(
	[ADCardCustomerClubsId] [nvarchar](40) NOT NULL,
	[PersonID] [nvarchar](40) NOT NULL,
	[CustomerNumber] [nvarchar](20) NULL,
	[ClubTypeCode] [nvarchar](50) NULL,
	[ClubName] [nvarchar](100) NULL,
	[ClubMembershipStatus] [smallint] NULL,
	[ClubNumber] [smallint] NULL,
	[ClubJoinSource] [nvarchar](100) NULL,
	[ClubJoinedDate] [date] NULL,
	[ClubResignedDate] [date] NULL,
	[ActivatedDate] [date] NULL,
	[ExpiredDate] [date] NULL,
	[ClubResignSource] [nvarchar](100) NULL,
	[ClubTopic] [nvarchar](255) NULL,
	[CreateUser] [nvarchar](100) NULL,
	[ChangeUser] [nvarchar](100) NULL,
	[CreatedByChannel] [smallint] NULL,
	[UpdatedByChannel] [smallint] NULL,
	[RecordSourceCode] [nvarchar](100) NULL,
	[LOVRecordSourceId] [int] NOT NULL,
	[RunDateTime] [datetime] NULL,
	[DLCreateDateTime] [datetime] NULL,
	[DLUpdateDateTime] [datetime] NULL,
	[DLSCDStartDateTime] [datetime] NULL,
	[DLSCDEndDateTime] [datetime] NULL,
	[DLSCDActiveFlag] [char](1) NULL,
	[DLETLRunLogID] [int] NULL,
	[DLCurateStandardRowKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
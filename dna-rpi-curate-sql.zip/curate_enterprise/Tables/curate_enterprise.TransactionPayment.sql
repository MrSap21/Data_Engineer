﻿CREATE TABLE curate_enterprise.TransactionPayment(
    TransactionPaymentId     nvarchar(40)      NOT NULL,
    TransactionId            nvarchar(40)      NOT NULL,
    PaymentMethodID          nvarchar(40)      NOT NULL,
    STDPaymentMethodName     nvarchar(100)     NULL,
    TransactionPaycard       nvarchar(50)      NULL,
    PaymentAmount            decimal(13, 2)    NULL,
    CurrencyId               nvarchar(40)      NOT NULL,
    ISOCurrencyCode          nvarchar(5)       NULL,
    TransactionYear          nvarchar(10)      NOT NULL,
    TransactionMonth         nvarchar(10)      NOT NULL,
    TransactionDay           nvarchar(10)      NOT NULL,
    RecordSourceCode         nvarchar(100)     NOT NULL,
    LOVRecordSourceId        int               NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
    (
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
    )
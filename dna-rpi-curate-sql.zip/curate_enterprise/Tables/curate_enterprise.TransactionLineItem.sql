﻿CREATE TABLE curate_enterprise.TransactionLineItem(
    TransactionLineItemId       nvarchar(40)      NOT NULL,
    TransactionId               nvarchar(40)      NULL,
    SalesItemLineNumber         nvarchar(255)     NOT NULL,
    ProductId                   nvarchar(40)      NULL,
    ItemCode                    nvarchar(50)      NOT NULL,
    Quantity                    decimal(13, 2)    NULL,
    UnitOfMeasureId             nvarchar(40)      NULL,
    UnitOfMeasure               nvarchar(40)        NULL,
    SellingPriceExcludingTax    decimal(13, 2)    NULL,
    SellingPriceIncludingTax    decimal(13, 2)    NULL,
    DiscountAmount              decimal(13, 2)    NULL,
    TaxAmount                   decimal(13, 2)    NULL,
    ISOCurrencyCode             nvarchar(5)       NULL,
    CurrencyId                  nvarchar(40)      NULL,
    RecordSourceCode            nvarchar(100)     NOT NULL,
    LOVRecordSourceId           int               NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
    (
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
    )
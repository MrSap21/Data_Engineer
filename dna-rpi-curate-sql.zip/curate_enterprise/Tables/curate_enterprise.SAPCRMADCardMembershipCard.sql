﻿CREATE TABLE curate_enterprise.SAPCRMADCardMembershipCard(
    ADCardMembershipCardId    nvarchar(40)     NOT NULL,
    PersonID                  nvarchar(40)     NOT NULL,
    CustomerNumber            nvarchar(20)     NULL,
    AccountNumber             nvarchar(100)    NULL,
    ADCardNumber                nvarchar(20)     NOT NULL,
    CardCheckDigit            smallint         NULL,
    CardStatusCode            nvarchar(50)     NULL,
    DespToCustDate            datetime         NULL,
    CFAID                     nvarchar(100)    NULL,
    ProdBatchNumber           nvarchar(100)    NULL,
    GeographyCode             nvarchar(100)    NULL,
    ADVCDTMNTDTMSTMP          nvarchar(50)     NULL,
    CardTypeCode              nvarchar(100)    NULL,
    CardActivationDate        date             NULL,
    CardExpiryDate            date             NULL,
    ChangeUser                nvarchar(100)    NULL,
    CreatedByChannel          nvarchar(100)    NULL,
    UpdatedByChannel          nvarchar(100)    NULL,
    RecordSourceCode          nvarchar(100)    NULL,
    LOVRecordSourceId         int              NOT NULL,
	RunDateTime                     datetime         NULL,
    DLCreateDateTime                datetime         NULL,
    DLUpdateDateTime                datetime         NULL,
    DLSCDStartDateTime              datetime         NULL,
    DLSCDEndDateTime                datetime         NULL,
    DLSCDActiveFlag                 char(1)          NULL,
    DLETLRunLogID                   int              NULL,
    DLCurateStandardRowKey          bigint           NULL
	)
	WITH
	(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
	)
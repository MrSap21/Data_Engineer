# Data Lynx Unity Catalog

The infrastructure-as-code for managing Unity Catalog in the Data Lynx Platform.

## References

- [Frequently Asked Questions](https://dev.azure.com/WBA/Data%20and%20Analytics%20Phase%202/_wiki/wikis/Data-and-Analytics-Phase-2.wiki/8682/Unity-Catalog-FAQ)

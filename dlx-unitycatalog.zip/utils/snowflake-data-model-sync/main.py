import csv
import json
import argparse

def snowflake_data_model_converter(snowflakeCSVPath, terraformConfigPath):
	tr={}

	# Map the Snowflake databases to Databricks catalogs
	with open(snowflakeCSVPath, encoding='utf-8-sig') as csvf:
		csvReader = csv.DictReader(csvf)
		data = {}
		for rows in csvReader:
			name={}
			key=rows['database_name']
			name['name']=rows['database_name']
			name['owner']='null'
			name['comment']='null'
			name['properties']={}
			data[key]=name
			tr['catalogs']=data

	# Map the Snowflake schemas to Databricks schemas
	with open(snowflakeCSVPath, encoding='utf-8-sig') as csvf:
		csvReader = csv.DictReader(csvf)
		data = {}
		for rows in csvReader:
			name={}
			key=rows['database_name']+'.'+rows['schema_name']
			name['catalog_name']=rows['database_name']
			name['name']=rows['schema_name']
			name['owner']='null'
			name['comment']='null'
			name['properties']={}
			data[key]=name
			tr['schemas']=data

	# Snowflake data model CSV is missing fields to support table sync.
	# See user story #913297. For tables we need a minimum of:
	#	- table_type (managed or external)
	#	- data_source_format (delta, csv, json, etc)
	#	- and at least one column
	# 
	# with open(snowflakeCSVPath, encoding='utf-8-sig') as csvf:
	# 	csvReader = csv.DictReader(csvf)
	# 	data = {}
	# 	for rows2 in csvReader:
	# 		name={}
	# 		key = rows2['database_name']+'.'+rows2['schema_name']+'.'+rows2['name']
	# 		name['catalog_name']=rows2['database_name']
	# 		name['schema_name']=rows2['schema_name']
	# 		name['name']=rows2['name']
	# 		name['owner']='null'
	# 		name['comment']='null'
	# 		name['properties']={}
	# 		data[key] = name
	# 		tr['tables']=data

	# Write the terraform input file.
	with open(terraformConfigPath, 'w', encoding='utf-8') as jsonf:
		jsonf.write(json.dumps(tr, indent=4))
		
if  __name__ == '__main__':
	parser = argparse.ArgumentParser(
		description='This script converts a Snowflake data model CSV into Terraform input for Databricks.'
	)
	parser.add_argument('path', help='set the path to the Snowflake CSV file.')
	parser.add_argument('--terraform-config', default=r'terraform.tfvars.json', help="change the output path. Default is terraform.tfvars.json")
	args = parser.parse_args()

	snowflake_data_model_converter(args.path, args.terraform_config)

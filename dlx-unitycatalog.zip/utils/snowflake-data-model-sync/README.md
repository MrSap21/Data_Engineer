# Snowflake Data Model Sync

This python script takes a CSV export of the Snowflake data model and produces
Terraform input for Databricks. The goal is to simplify keeping these two
systems in sync.

## Getting Started

1. First step is to obtain a CSV export of the Snowflake data model.
   This script assumes the following format (header names in double quotes):

   - Column: "database_name" (Equivalent to a `catalog` in Databricks).
   - Column: "schema_name"

2. Run the python script.

```bash
python main.py <path/to/snowflake.csv>
#=> terraform.tfvars

# For help
python main.py --help
```

3. Validate the output.

```bash
terraform init
#=> Terraform has been successfully initialized!
terraform validate
#=> Success! The configuration is valid.
terraform plan
#=> Plan: 216 to add, 0 to change, 0 to destroy.
```

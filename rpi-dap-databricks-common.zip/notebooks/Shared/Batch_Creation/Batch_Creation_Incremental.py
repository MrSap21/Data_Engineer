# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from pyspark.sql.window import Window
import os

# COMMAND ----------

dbutils.widgets.text("BatchNo", "","")
batchNo = dbutils.widgets.get("BatchNo")

dbutils.widgets.text("SourcePath", "","")
source_Path = dbutils.widgets.get("SourcePath")

# dbutils.widgets.text("Destination_Path", "","")
# dest_Path = dbutils.widgets.get("Destination_Path")


dbutils.widgets.text("From Date", "","")
from_date = dbutils.widgets.get("From Date")

dbutils.widgets.text("To Date", "","")
to_date = dbutils.widgets.get("To Date")

batchName = 'Inc_Batch_' + batchNo + '_' + from_date + "_" + to_date
sourcePath='/mnt/idf-cleansed/'+source_Path
destination_Path = '/mnt/idf-cleansed/SAPCOE/SAPCAR/IF_07680/' + batchName

print(destination_Path)


# COMMAND ----------

dbutils.fs.rm(destination_Path,True)

# COMMAND ----------

from datetime import timedelta, date

def daterange(date1, date2):
    for n in range(int ((date2 - date1).days)+1):
        yield date1 + timedelta(n)

start_dt = date(int(from_date[0:4]), int(from_date[4:6]), int(from_date[6:8]))
end_dt = date(int(to_date[0:4]), int(to_date[4:6]), int(to_date[6:8]))
date_list=[]
for dt in daterange(start_dt, end_dt):
    date_list.append(dt.strftime("%Y%m%d"))
    
#print(date_list)

# COMMAND ----------

fileList=dbutils.fs.ls(sourcePath)
fileNameList=[]
for file in fileList:
  fileNameList.append(file.name)
#print(fileNameList)

# COMMAND ----------

for datelst in date_list:
  for filelst in fileNameList:
    if datelst in filelst:
      dbutils.fs.cp(sourcePath + '/'+filelst,destination_Path + '/'+filelst)

# COMMAND ----------


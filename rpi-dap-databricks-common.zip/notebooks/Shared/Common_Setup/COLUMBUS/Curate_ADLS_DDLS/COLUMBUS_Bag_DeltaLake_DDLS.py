# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Bag
# MAGIC (
# MAGIC BagSKID INT,
# MAGIC PrescriptionGroupID INT,
# MAGIC PatientPartyRoleID INT,
# MAGIC PharmacyStoreSiteRoleId INT,
# MAGIC ToteID INT,
# MAGIC SourceKey STRING,
# MAGIC PrescriptionGroupCode STRING,
# MAGIC PatientCode STRING,
# MAGIC StoreCode STRING,
# MAGIC ToteCode STRING,
# MAGIC BagStatus STRING,
# MAGIC CreationTime TIMESTAMP,
# MAGIC UpdateTime TIMESTAMP,
# MAGIC BagSource STRING,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Bag"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
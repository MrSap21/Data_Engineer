# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PurchaseOrderGroup
# MAGIC (
# MAGIC PurchaseOrderGroupSKID BIGINT,
# MAGIC   OrderTypeID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   OrderGroupQuantity BIGINT,
# MAGIC   PurchaseOrderGroupStatus STRING,
# MAGIC   OrderTypeCode STRING,
# MAGIC   ProcessingTime TIMESTAMP,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PurchaseOrderGroup"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_DispensingQueueItem
# MAGIC (
# MAGIC DispensingQueueItemSKID	INT,
# MAGIC PharmacyStoreSiteRoleId	INT,
# MAGIC PrescriptionGroupID	INT,
# MAGIC SourceKey	STRING  ,
# MAGIC StoreCode	STRING  ,
# MAGIC CreationDate	TIMESTAMP,
# MAGIC CreationTime	TIMESTAMP,
# MAGIC DispensingQueueItemType	STRING  ,
# MAGIC TaskGroupReference	STRING  ,
# MAGIC DispensingQueueItemStatus	STRING  ,
# MAGIC BusinessStatus	STRING  ,
# MAGIC EntityType	STRING  ,
# MAGIC SourceEntry	STRING  ,
# MAGIC LinkedEntry	STRING  ,
# MAGIC NumberOfItem	BIGINT,
# MAGIC EstimatedTime	TIMESTAMP,
# MAGIC CompletionTime	TIMESTAMP,
# MAGIC IsCompletedInTimeIndicator INT,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/DispensingQueueItem"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
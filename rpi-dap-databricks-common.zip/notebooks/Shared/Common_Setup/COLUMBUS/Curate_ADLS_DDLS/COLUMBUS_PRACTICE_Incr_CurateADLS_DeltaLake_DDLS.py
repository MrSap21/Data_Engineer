# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Practice
# MAGIC (
# MAGIC PracticeSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   PracticeContext STRING,
# MAGIC   PracticeFullname STRING,
# MAGIC   NationalCode STRING,
# MAGIC   PostalCode STRING,
# MAGIC   PracticeName STRING,
# MAGIC   PracticeStatus STRING,
# MAGIC   StoreCode STRING,
# MAGIC   PracticeType STRING,
# MAGIC   DueBackDays BIGINT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Practice"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

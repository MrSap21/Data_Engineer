# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_tradesellingprice (
# MAGIC   TradeSellingPriceSKID BIGINT,
# MAGIC   ActualProductPackID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   StartDate DATE,
# MAGIC   EndDate DATE,
# MAGIC   PriceAmount DECIMAL(24,4),
# MAGIC   PriceISOCode STRING,
# MAGIC   PriceScheme STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/TradeSellingPrice'

# COMMAND ----------



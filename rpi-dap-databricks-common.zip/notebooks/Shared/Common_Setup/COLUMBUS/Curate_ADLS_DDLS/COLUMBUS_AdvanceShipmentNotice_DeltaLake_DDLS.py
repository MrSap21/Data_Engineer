# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_AdvanceShipmentNotice
# MAGIC (
# MAGIC AdvanceShipmentNoticeSKID	INT,
# MAGIC PurchaseOrderGroupID	INT,
# MAGIC PurchaseOrderID	INT,
# MAGIC SourceKey	STRING  ,
# MAGIC SourceSystemID	INT,
# MAGIC CreationTime	TIMESTAMP,
# MAGIC CustomerCode	STRING  ,
# MAGIC AdvanceShipmentNoticeType	STRING  ,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/AdvanceShipmentNotice"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


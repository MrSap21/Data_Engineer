# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_GridCell
# MAGIC (
# MAGIC GridCellSKID	INT,
# MAGIC GridLayerID	INT,
# MAGIC GridCellValueID	INT,
# MAGIC SourceKey	STRING,
# MAGIC GridCellPositionX	INT,
# MAGIC GridCellPositionY	INT,
# MAGIC RunDateTime	TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC LOVRecordSourceID	INT,
# MAGIC GridCellDate	TIMESTAMP,
# MAGIC GridCellTimestamp	TIMESTAMP,
# MAGIC RecordStatusFlag	  STRING,
# MAGIC CreatedTime 	TIMESTAMP,
# MAGIC UpdatedTime	TIMESTAMP,
# MAGIC ActiveFlag	STRING,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/GridCell"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_OutOfPocketExpenses
# MAGIC (
# MAGIC OutOfPocketExpensesSKID INT,
# MAGIC AdditionalEndorsementID INT,
# MAGIC SourceKey STRING,
# MAGIC OutOfPocketExpensesItemPriceAmount DECIMAL(24,4),
# MAGIC OutOfPocketExpensesItemPriceISOCode STRING,
# MAGIC OutOfPocketExpensesReason STRING,
# MAGIC IsOutOfPocketExpensesVATIncludedIndicator INT,
# MAGIC IsOutOfPocketExpensesPostagePackagingIndicator INT,
# MAGIC OutOfPocketExpensesPostagePriceAmount DECIMAL(24,4),
# MAGIC OutOfPocketExpensesPostagePriceISOCode STRING,
# MAGIC IsOutOfPocketExpensesHandlingChargeIndicator INT,
# MAGIC OutOfPocketExpensesHandlingPriceAmount DECIMAL(24,4),
# MAGIC OutOfPocketExpensesHandlingPriceISOCode STRING,
# MAGIC IsOutOfPocketExpensesOtherChargeIndicator INT,
# MAGIC OutOfPocketExpensesOtherPriceAmount DECIMAL(24,4),
# MAGIC OutOfPocketExpensesOtherPriceISOCode STRING, 
# MAGIC OutOfPocketExpensesOtherExpensesDescr STRING,
# MAGIC RunDateTime TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag STRING,
# MAGIC LOVRecordSourceID INT,
# MAGIC ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/OutOfPocketExpenses"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PatientRegistration
# MAGIC (
# MAGIC PatientRegistrationSKID  INT,
# MAGIC PatientPartyRoleID  BIGINT,
# MAGIC PharmacyStoreSiteRoleId  BIGINT ,
# MAGIC SourceKey  STRING ,
# MAGIC PatientCode  STRING ,
# MAGIC PrescribeCode  STRING ,
# MAGIC PatientRegistrationStatus  STRING ,
# MAGIC StatusDescription  STRING ,
# MAGIC ProcessedDate  TIMESTAMP ,
# MAGIC StartDate  TIMESTAMP ,
# MAGIC SiteCode  STRING ,
# MAGIC TransmissionStatus  STRING ,
# MAGIC RequestID  STRING ,
# MAGIC StatusRequested  STRING ,
# MAGIC CreationTime  TIMESTAMP ,
# MAGIC UpdateTime  TIMESTAMP ,
# MAGIC ServiceType  STRING ,
# MAGIC RejectionCode  STRING,
# MAGIC RejectionClass  STRING ,
# MAGIC RejectionDescription  STRING ,
# MAGIC EndDate  TIMESTAMP ,
# MAGIC RunDateTime TIMESTAMP,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC ETLRunLogId INT,
# MAGIC LOVRecordSourceId INT,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag string
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PatientRegistration"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
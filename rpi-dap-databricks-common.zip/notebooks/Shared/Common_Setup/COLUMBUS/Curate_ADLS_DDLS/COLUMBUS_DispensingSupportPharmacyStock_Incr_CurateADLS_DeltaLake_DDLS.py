# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_DispensingSupportPharmacyStock
# MAGIC (
# MAGIC DispensingSupportPharmacyStockID	INT,
# MAGIC ActualProductPackID	INT,
# MAGIC SourceKey	STRING,
# MAGIC PIPCode	STRING,
# MAGIC DispensingSupportPharmacyCode	STRING,
# MAGIC Location	STRING,
# MAGIC UpdateTime	timestamp,
# MAGIC LastOrderDate	timestamp,
# MAGIC LeftoverQuantity	INT,
# MAGIC CarryOverQuantity	INT,
# MAGIC AllocatedQuantity	INT,
# MAGIC SafetyQuantity	DECIMAL(15,5),
# MAGIC LastCountedTime	timestamp,
# MAGIC ExceptionTime	timestamp,
# MAGIC LastConsumptionDate	timestamp,
# MAGIC RunDateTime	timestamp,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC RecordStatusFlag	STRING,
# MAGIC CreatedTime 	timestamp,
# MAGIC UpdatedTime	timestamp,
# MAGIC LOVRecordSourceID	INT,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/DispensingSupportPharmacyStock"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Supplier
# MAGIC (
# MAGIC SupplierPartyRoleID	INT,
# MAGIC SourceKey	STRING,
# MAGIC SupplierName	STRING,
# MAGIC SupplierStatus	STRING,
# MAGIC IsThirdPartyIndicator	STRING,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC LOVRecordSourceId INT,
# MAGIC ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Supplier"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
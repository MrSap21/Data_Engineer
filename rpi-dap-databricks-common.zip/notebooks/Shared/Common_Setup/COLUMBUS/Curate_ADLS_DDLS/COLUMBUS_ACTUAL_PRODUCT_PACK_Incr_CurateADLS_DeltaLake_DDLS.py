# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_ActualProductPack
# MAGIC (
# MAGIC ActualProductPackSKID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   SupplierID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   CommonDrugServiceCode STRING,
# MAGIC   Description STRING,
# MAGIC   IsNotAutomatableProductIndicator INT,
# MAGIC   BuyingMultiple BIGINT,
# MAGIC   IsBuyingMultipleOptimisationIndicator INT,
# MAGIC   IsNorthWestOstomySuppliesIndicator INT,
# MAGIC   IsBuyingMultipleEnforcedIndicator INT,
# MAGIC   PackName STRING,
# MAGIC   IsPreferredIndicator INT,
# MAGIC   PIPCode STRING,
# MAGIC   Quantity DECIMAL(15,5),
# MAGIC   ReceivingQuantity DECIMAL(15,5),
# MAGIC   RegionCode STRING,
# MAGIC   ShortName STRING,
# MAGIC   IsSpecialItemIndicator INT,
# MAGIC   Status STRING,
# MAGIC   SupplierCode STRING,
# MAGIC   IsTenderLineIndicator INT,
# MAGIC   BusinessItemCode STRING,
# MAGIC   IsControlledDrugIndicator INT,
# MAGIC   DmdSpecial STRING,
# MAGIC   IsFridgeLineIndicator INT,
# MAGIC   LegalCategory STRING,
# MAGIC   SnomedDescription STRING,
# MAGIC   NWOSCategory STRING,
# MAGIC   NWOSStartDate DATE,
# MAGIC   NWOSEndDate DATE,
# MAGIC   IsMASEligibleIndicator INT,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/ActualProductPack"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

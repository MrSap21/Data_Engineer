# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_ProductProductSKU
# MAGIC (
# MAGIC ProductProductSKUSKID BIGINT,
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   IsPreferredIndicator INT,
# MAGIC   IsPrimarySKUIndicator INT,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/ProductProductSKU"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

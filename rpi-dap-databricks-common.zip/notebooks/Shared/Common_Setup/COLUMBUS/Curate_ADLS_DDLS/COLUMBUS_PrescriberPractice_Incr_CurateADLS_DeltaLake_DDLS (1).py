# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PrescriberPractice
# MAGIC (
# MAGIC PrescriberPracticeSKID BIGINT,
# MAGIC   PrescriberID BIGINT,
# MAGIC   PracticeID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   IsDefaultPracticeIndicator INT,
# MAGIC   StartDate DATE,
# MAGIC   EndDate DATE,
# MAGIC   PrescriberPracticeStatus STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PrescriberPractice"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

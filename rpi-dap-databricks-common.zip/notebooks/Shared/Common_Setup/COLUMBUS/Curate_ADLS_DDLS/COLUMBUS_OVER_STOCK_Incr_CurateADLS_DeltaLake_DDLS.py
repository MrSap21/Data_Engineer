# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_OverStock
# MAGIC (OverStockSKID	INT,
# MAGIC PharmacyProductID	INT,
# MAGIC PharmacyStoreSiteRoleId	BIGINT,
# MAGIC SourceKey	STRING,
# MAGIC CreationTime	TIMESTAMP,
# MAGIC ProductCode	STRING,
# MAGIC Quantity	DECIMAL (15,5),
# MAGIC StoreCode	STRING,
# MAGIC TotalOnShelfQuantity	DECIMAL (15,5),
# MAGIC UpdateTime 	TIMESTAMP,
# MAGIC QuantitySecondary	DECIMAL (15,5),
# MAGIC TOTOnShelfSecondary	DECIMAL (15,5),
# MAGIC TOTOverstockSecondary	DECIMAL (15,5),
# MAGIC RunDateTime timestamp ,
# MAGIC Year  string ,
# MAGIC Month  string ,
# MAGIC Day  string ,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC LOVRecordSourceID INT,
# MAGIC ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/OverStock"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
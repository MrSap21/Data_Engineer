# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_ReplenishmentItem
# MAGIC (
# MAGIC ReplenishmentItemSKID BIGINT,
# MAGIC   ReplenishmentOrderLineID BIGINT,
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   DispensedItemID BIGINT,
# MAGIC   PrescriptionFormID BIGINT,
# MAGIC   PrescribedItemID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   DispensedItemCode STRING,
# MAGIC   GroupCode STRING,
# MAGIC   Quantity DECIMAL(15,5),
# MAGIC   PrescriptionFormCode STRING,
# MAGIC   ReplenishmentItemStatus STRING,
# MAGIC   IsOverstockedIndicator INT,
# MAGIC   PrescribedItemCode STRING,
# MAGIC   ProductCode STRING,
# MAGIC   LinkedROLCode STRING,
# MAGIC   CumulativeQuantity DECIMAL(15,5),
# MAGIC   RundateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT 
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/ReplenishmentItem"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

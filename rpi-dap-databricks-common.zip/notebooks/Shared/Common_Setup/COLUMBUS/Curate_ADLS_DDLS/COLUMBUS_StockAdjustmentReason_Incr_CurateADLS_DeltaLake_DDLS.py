# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_StockAdjustmentReason
# MAGIC (
# MAGIC StockAdjustmentReasonSKID  int,
# MAGIC SourceKey  string,
# MAGIC ClosedTime  timestamp  ,
# MAGIC SourceSystemID  int,
# MAGIC CreationTime  timestamp  ,
# MAGIC Description  string  ,
# MAGIC LastUpdate  timestamp  ,
# MAGIC StockAdjustmentReasonType  string  ,
# MAGIC UserName  string  ,
# MAGIC IsSendToFinanceIndicator  int  ,
# MAGIC RunDateTime  timestamp  ,
# MAGIC Year string  ,
# MAGIC Month string  ,
# MAGIC Day string  ,
# MAGIC RecordStatusFlag  string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC LOVRecordSourceID  INT,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/StockAdjustmentReason"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


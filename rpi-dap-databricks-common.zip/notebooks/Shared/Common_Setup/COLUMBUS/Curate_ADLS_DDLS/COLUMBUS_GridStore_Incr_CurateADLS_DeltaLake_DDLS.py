# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_GridStore
# MAGIC (
# MAGIC GridStoreSKID	INT,
# MAGIC GridID	INT,
# MAGIC PharmacyStoreSiteRoleId	BIGINT,
# MAGIC SourceKey	STRING,
# MAGIC SourceSystemID	INT,
# MAGIC GridCode	STRING,
# MAGIC StoreCode	STRING,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC LOVRecordSourceId INT,
# MAGIC GridStoreDate	timestamp,
# MAGIC GridStoreTimestamp	timestamp,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC ActiveFlag	STRING,
# MAGIC ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/GridStore"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_ParameterValue
# MAGIC (
# MAGIC ParameterValueSKID INT,
# MAGIC ParameterID INT,
# MAGIC PharmacyProductID STRING,
# MAGIC PharmacyProductSKUID INT,
# MAGIC PharmacyStoreSiteRoleId BIGINT,
# MAGIC EntityCode STRING,
# MAGIC EntityType STRING,
# MAGIC SourceType STRING,
# MAGIC ServiceTypeCode STRING,
# MAGIC CreationTime TIMESTAMP,
# MAGIC UpdateTime TIMESTAMP,
# MAGIC SiteCode STRING,
# MAGIC Value STRING,
# MAGIC ValueComment STRING,
# MAGIC Area STRING,
# MAGIC ReviewDate DATE,
# MAGIC ConfigurationLevel STRING,
# MAGIC SourceKey INT,
# MAGIC StartDate DATE,
# MAGIC EndDate DATE,
# MAGIC RunDateTime TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag STRING,
# MAGIC LOVRecordSourceID INT,
# MAGIC ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/ParameterValue"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------



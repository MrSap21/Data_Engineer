# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_GridAxisThreshold
# MAGIC (
# MAGIC GridAxisThresholdSKID	INT,
# MAGIC GridAxisID	INT,
# MAGIC SourceKey	STRING,
# MAGIC GridAxisValue	INT,
# MAGIC SequenceNumber	INT,
# MAGIC RunDateTime	TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC LOVRecordSourceID	INT,
# MAGIC GridAxisThresholdDate	TIMESTAMP,
# MAGIC GridAxisThresholdTimestamp	TIMESTAMP,
# MAGIC RecordStatusFlag	  STRING,
# MAGIC CreatedTime 	TIMESTAMP,
# MAGIC UpdatedTime	TIMESTAMP,
# MAGIC ActiveFlag	STRING,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/GridAxisThreshold"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
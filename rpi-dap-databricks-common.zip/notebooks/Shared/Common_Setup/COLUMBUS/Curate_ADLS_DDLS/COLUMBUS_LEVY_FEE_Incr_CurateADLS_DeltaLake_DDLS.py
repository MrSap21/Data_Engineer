# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_LevyFee
# MAGIC (
# MAGIC LevyFeeSKID	INT,
# MAGIC SourceKey	STRING,
# MAGIC LevyFeeAmount	DECIMAL(24,4),
# MAGIC LevyFeeISOCode	STRING,
# MAGIC StartDate	timestamp,
# MAGIC EndDate	timestamp,
# MAGIC Region	STRING,
# MAGIC LevyFeeStatus	STRING,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC LOVRecordSourceId INT,
# MAGIC ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/LevyFee"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
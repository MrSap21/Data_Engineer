# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.curateadls_SiteRole
# MAGIC (
# MAGIC SiteRoleId BIGINT,
# MAGIC SiteId BIGINT,
# MAGIC LOVRoleId INT,
# MAGIC SourceKey STRING,
# MAGIC LOVSourceKeyTypeId INT,
# MAGIC SiteRoleName STRING,
# MAGIC SiteRoleShortName STRING,
# MAGIC LOVRecordSourceId INT,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag string,
# MAGIC
# MAGIC ETLRunLogId INT,
# MAGIC PSARowKey BIGINT,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING
# MAGIC
# MAGIC
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/SiteRole"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


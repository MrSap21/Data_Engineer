# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_MessageNotification
# MAGIC (
# MAGIC MessageNotificationSKID INT,
# MAGIC PharmacyStoreSiteRoleId BIGINT,
# MAGIC SourceKey STRING,
# MAGIC SiteCode STRING,
# MAGIC SendingTime TIMESTAMP,
# MAGIC MessageReasonCode STRING,
# MAGIC MessageNotificationStatus STRING,
# MAGIC APIVersion STRING,
# MAGIC Payload STRING,
# MAGIC MessageID STRING,
# MAGIC TotalMessages INT,
# MAGIC RecipientList STRING,
# MAGIC ErrorPayload STRING,
# MAGIC RunDateTime TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC RecordStatusFlag STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID INT,
# MAGIC ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/MessageNotification"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_OrderUpdateNotification
# MAGIC (
# MAGIC OrderUpdateNotificationSKID INT,
# MAGIC PharmacyStoreSiteRoleId INT,
# MAGIC DispensedItemID INT,
# MAGIC SourceSystemID BIGINT,
# MAGIC OldDispensedPharmacyProductSKUID INT,
# MAGIC NewDispensedPharmacyProductSKUID INT,
# MAGIC OldDispensedActualProductPackID INT,
# MAGIC NewDispensedActualProductPackID INT,
# MAGIC PrescriptionFormID INT,
# MAGIC SourceKey STRING,
# MAGIC ProcessingTime TIMESTAMP,
# MAGIC CreationTime TIMESTAMP,
# MAGIC OldDispensedSKUCode STRING,
# MAGIC NewDispensedSKUCode STRING,
# MAGIC OldDispensedAppCode STRING,
# MAGIC NewDispensedAppCode STRING,
# MAGIC PrescriptionFormCode STRING,
# MAGIC StoreCode STRING,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/OrderUpdateNotification"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


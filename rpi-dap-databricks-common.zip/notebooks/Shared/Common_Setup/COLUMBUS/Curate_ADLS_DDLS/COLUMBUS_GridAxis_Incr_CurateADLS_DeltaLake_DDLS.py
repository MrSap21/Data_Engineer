# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_GridAxis
# MAGIC (
# MAGIC GridAxisSKID	INT,
# MAGIC GridID	INT,
# MAGIC SourceKey	STRING,
# MAGIC GridAxisType	STRING,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC LOVRecordSourceId INT,
# MAGIC GridAxisDate timestamp,
# MAGIC GridAxisTimestamp timestamp,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC ActiveFlag	STRING,
# MAGIC ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/GridAxis"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
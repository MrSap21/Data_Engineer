# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PreferredActualProductPack
# MAGIC (
# MAGIC PreferredAppSKID BIGINT,
# MAGIC   ActualProductPackID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   StartDate DATE,
# MAGIC   EndDate DATE,
# MAGIC   Region STRING,
# MAGIC   PreferredType STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PreferredActualProductPack"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------



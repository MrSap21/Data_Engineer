# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_DispensingEvent
# MAGIC (
# MAGIC DispensingEventSKID int,
# MAGIC PharmacyStoreSiteRoleId BIGINT,
# MAGIC SourceKey String,
# MAGIC MasterUPN String,
# MAGIC PrescriptionFormCode String,
# MAGIC IsClaimedItemsIndicator int,
# MAGIC DispensingDate DATE,
# MAGIC IsExceptionItemsIndicator int,
# MAGIC IsToBeClaimedItemsIndicator int,
# MAGIC Status String,
# MAGIC StoreCode String,
# MAGIC IsDueDateItemsIndicator int,
# MAGIC AtRiskDate timestamp,
# MAGIC LOVRecordSourceId INT,
# MAGIC ETLRunLogId INT,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag string
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/DispensingEvent"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PatientMedicalCondition
# MAGIC (
# MAGIC PatientMedicalConditionSKID BIGINT,
# MAGIC   PatientPartyRoleID BIGINT,
# MAGIC   MedicalConditionID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   PatientMedicalConditionCode STRING,
# MAGIC   PatientMedicalConditionNoteDate TIMESTAMP,
# MAGIC   PatientMedicalConditionNotes STRING,
# MAGIC   PatientMedicalConditionUserCode STRING,
# MAGIC   LegacyMedicalConditionCode STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PatientMedicalCondition"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_prescriptionsiteinformation (
# MAGIC   PrescriptionSiteInformationSKID BIGINT,
# MAGIC   PrescriptionGroupID BIGINT,
# MAGIC   PharmacyStoreSiteRoleID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   AccountNumber STRING,
# MAGIC   AddressLine1 STRING,
# MAGIC   AddressLine2 STRING,
# MAGIC   AddressLine3 STRING,
# MAGIC   AddressLine4 STRING,
# MAGIC   AddressLine5 STRING,
# MAGIC   SiteCode STRING,
# MAGIC   PostalCode STRING,
# MAGIC   SiteName STRING,
# MAGIC   TelephoneNumber STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PrescriptionSiteInformation'

# COMMAND ----------



# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_NoCheaperStockObtainable
# MAGIC (
# MAGIC NoCheaperStockObtainableSKID INT,
# MAGIC AdditionalEndorsementID INT,
# MAGIC SourceKey STRING,
# MAGIC NoCheaperStockObtainableDispensedDate TIMESTAMP,
# MAGIC NoCheaperStockObtainablePackSize DECIMAL(15,5),
# MAGIC NoCheaperStockObtainableSupplier STRING,
# MAGIC NoCheaperStockObtainableUserInitial STRING,
# MAGIC NoCheaperStockObtainablePackQuantity STRING,
# MAGIC RunDateTime TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC RecordStatusFlag STRING,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC LOVRecordSourceID INT,
# MAGIC ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/NoCheaperStockObtainable"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PrescriptionItemInformation
# MAGIC (
# MAGIC PrescriptionItemInformationSKID INT,
# MAGIC BagPartID INT,
# MAGIC DispensedItemID INT,
# MAGIC DispensedProductID INT,
# MAGIC PrescribedProductID INT,
# MAGIC PrescribedItemID INT,
# MAGIC SourceKey STRING,
# MAGIC DispensedProductCode STRING,
# MAGIC DispensedProductName STRING,
# MAGIC DispensedQuantity DECIMAL(15,5),
# MAGIC DosageDirection STRING,
# MAGIC DosageUnit STRING,
# MAGIC LineNumber STRING,
# MAGIC PackSize DECIMAL(15,5),
# MAGIC PrescribedProductCode STRING,
# MAGIC PrescribedProductName STRING,
# MAGIC PrescribedQuantity DECIMAL(15,5),
# MAGIC SourcePrescriptionID STRING,
# MAGIC BNFWarning STRING,
# MAGIC PrescribedItemCode STRING,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PrescriptionItemInformation"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


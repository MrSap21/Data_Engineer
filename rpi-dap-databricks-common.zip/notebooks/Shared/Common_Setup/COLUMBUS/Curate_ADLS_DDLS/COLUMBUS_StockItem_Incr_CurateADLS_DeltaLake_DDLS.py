# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_stockitem (
# MAGIC   StockItemSKID BIGINT,
# MAGIC   StockID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   Quantity DECIMAL(15,5),
# MAGIC   IsSoftAllocatedIndicator INT,
# MAGIC   StockItemType STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/StockItem'

# COMMAND ----------



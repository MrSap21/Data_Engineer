# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_GlobalCodeAndParameterElementValue
# MAGIC (
# MAGIC   GlobalCodeAndParameterElementValueSKID BIGINT,
# MAGIC   GlobalCodeAndParameterElementID BIGINT,
# MAGIC   ElementValueType STRING,
# MAGIC   AttributeValue STRING,
# MAGIC   AttributeName STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/GlobalCodeAndParameterElementValue"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

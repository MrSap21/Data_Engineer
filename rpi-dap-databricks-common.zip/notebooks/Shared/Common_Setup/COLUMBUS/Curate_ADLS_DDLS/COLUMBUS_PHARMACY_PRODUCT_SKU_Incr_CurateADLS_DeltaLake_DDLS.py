# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql 
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS  COLUMBUS_CURATION.CurateADLS_PharmacyProductSKU
# MAGIC (
# MAGIC     PharmacyProductSKUID  INT,
# MAGIC     SourceKey  STRING ,
# MAGIC     SourceSystemID INT,
# MAGIC     PackQuantity DECIMAL(15,5),
# MAGIC     ProductSKUName  STRING ,
# MAGIC     ProductSKUStatus  STRING ,
# MAGIC     IsSubPackIndicator  INT,
# MAGIC     SubPackQuantity  DECIMAL(15,5) ,
# MAGIC     IsCSSPLineIndicator INT ,
# MAGIC     IsRetailTypeIndicator INT ,
# MAGIC     DosageUnitCode  STRING ,
# MAGIC     ProductFlavourID  INT,
# MAGIC     LOVRecordSourceId INT,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag string,
# MAGIC ETLRunLogId INT , 
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PharmacyProductSKU"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day)

# COMMAND ----------


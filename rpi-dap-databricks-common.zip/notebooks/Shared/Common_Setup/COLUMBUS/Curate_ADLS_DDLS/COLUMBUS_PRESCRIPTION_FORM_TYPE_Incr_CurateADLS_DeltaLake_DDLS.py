# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PrescriptionFormType
# MAGIC (
# MAGIC PrescriptionFormTypeSKID BIGINT,
# MAGIC   FormularyID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   ColourDark STRING,
# MAGIC   ColourDescription STRING,
# MAGIC   ColourLight STRING,
# MAGIC   IsDefaultValueIndicator INT,
# MAGIC   Description STRING,
# MAGIC   IsEndorsableIndicator INT,
# MAGIC   IsNationalFormTypeIndicator INT,
# MAGIC   IsPerformDURIndicator INT,
# MAGIC   PrescriptionFormTypeStatus STRING,
# MAGIC   IsCentralPharmacyDispensingIndicator INT,
# MAGIC   ExpiryPeriod BIGINT,
# MAGIC   InstalmentDefaultDays BIGINT,
# MAGIC   InstalmentSchedule STRING,
# MAGIC   MaxItemNumber BIGINT,
# MAGIC   IsPrivateNumberRequiredIndicator INT,
# MAGIC   IsSelectableIndicator INT,
# MAGIC   IsVATExtempIndicator INT,
# MAGIC   InstalmentScheduleType STRING,
# MAGIC   IsNWOSEligibleIndicator INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PrescriptionFormType"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_MedicinesUseReviewForm
# MAGIC (
# MAGIC MedicinesUseReviewFormSKID INT,
# MAGIC PharmacyStoreSiteRoleId INT,
# MAGIC PatientPartyRoleID INT,
# MAGIC PrescriberPartyRoleID INT,
# MAGIC PracticeID INT,
# MAGIC SourceKey STRING,
# MAGIC IsCompiledInStoreIndicator INT,
# MAGIC IsCompiledWithPatientIndicator INT,
# MAGIC CreationTime TIMESTAMP,
# MAGIC MedicinesUseReviewFormIdentifier STRING,
# MAGIC MedicinesUseReviewFormType STRING,
# MAGIC PatientCode STRING,
# MAGIC IsPCOPermissionIndicator INT,
# MAGIC PharmacistCode STRING,
# MAGIC PharmacyContractorNumber STRING,
# MAGIC PracticeCode STRING,
# MAGIC PrescriberCode STRING,
# MAGIC PresentRole STRING,
# MAGIC ReasonNotInStore STRING,
# MAGIC ReasonNotWithPatient STRING,
# MAGIC ReferenceNumber STRING,
# MAGIC ReviewDate DATE,
# MAGIC ReviewLocation STRING,
# MAGIC MedicinesUseReviewFormStatus STRING,
# MAGIC StoreCode STRING,
# MAGIC StoreEmail STRING,
# MAGIC UpdateTime TIMESTAMP,
# MAGIC IsWrittenConsentIndicator INT,
# MAGIC RegionalReviewType STRING,
# MAGIC MedicinesUseReviewFormIdentifierNote STRING,
# MAGIC IsAdviceLivingIndicator INT,
# MAGIC OldPatientCode STRING,
# MAGIC Ethnicity STRING,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/MedicinesUseReviewForm"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE spark_catalog.columbus_curation.curateadls_orderstatusupdate (
# MAGIC   OrderStatusUpdateSKID BIGINT,
# MAGIC   PurchaseOrderID BIGINT,
# MAGIC   PharmacyStoreSiteRoleID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   OrderStatusUpdateCode STRING,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   DeliveryDate DATE,
# MAGIC   DeliveryReference STRING,
# MAGIC   DeliveryRoute STRING,
# MAGIC   DeliveryShift STRING,
# MAGIC   DeliveryWarehouse STRING,
# MAGIC   PurchaseOrderCode STRING,
# MAGIC   SendingTime TIMESTAMP,
# MAGIC   SupplierType STRING,
# MAGIC   OrderStatusUpdateType STRING,
# MAGIC   StoreCode STRING,
# MAGIC   ServiceEntryMode STRING,
# MAGIC   DispatchTime TIMESTAMP,
# MAGIC   CustomerWholesalerCode STRING,
# MAGIC   OrderSource STRING,
# MAGIC   OrderWholesalerCode STRING,
# MAGIC   OrderWholesalerCreationTime TIMESTAMP,
# MAGIC   SOCOrderCode STRING,
# MAGIC   SOCOrderCreationTime TIMESTAMP,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/OrderStatusUpdate'

# COMMAND ----------



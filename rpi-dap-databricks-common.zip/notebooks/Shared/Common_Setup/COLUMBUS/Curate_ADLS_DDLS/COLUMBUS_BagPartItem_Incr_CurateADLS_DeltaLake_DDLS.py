# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_bagpartitem (
# MAGIC   BagPartItemSKID BIGINT,
# MAGIC   BagPartID BIGINT,
# MAGIC   SuppliedActualProductPackID BIGINT,
# MAGIC   OrderedActualProductPackID BIGINT,
# MAGIC   PrescribedItemID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   OrderedPack BIGINT,
# MAGIC   OrderLineReference STRING,
# MAGIC   OrderLineType STRING,
# MAGIC   SheetReferences STRING,
# MAGIC   SuppliedPack BIGINT,
# MAGIC   SuppliedProductCode STRING,
# MAGIC   ToteReference STRING,
# MAGIC   OrderedProductCode STRING,
# MAGIC   BagPartItemStatus STRING,
# MAGIC   SourcePrescriptionID STRING,
# MAGIC   OrderedPills DECIMAL(15,5),
# MAGIC   SuppliedPills DECIMAL(15,5),
# MAGIC   PrescribedProductCode STRING,
# MAGIC   PrescribedItemCode STRING,
# MAGIC   LeftOverSuppliedPills BIGINT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/BagPartItem'

# COMMAND ----------



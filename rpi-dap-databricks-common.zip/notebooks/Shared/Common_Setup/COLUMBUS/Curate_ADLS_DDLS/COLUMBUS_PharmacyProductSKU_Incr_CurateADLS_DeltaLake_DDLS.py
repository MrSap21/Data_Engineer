# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PharmacyProductSKU
# MAGIC (
# MAGIC PharmacyProductSKUID BIGINT,
# MAGIC   DosageUnitID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   PackQuantity DECIMAL(15,5),
# MAGIC   ProductSKUName STRING,
# MAGIC   ProductSKUStatus STRING,
# MAGIC   IsSubPackIndicator INT,
# MAGIC   SubPackQuantity DECIMAL(15,5),
# MAGIC   IsCSSPLineIndicator INT,
# MAGIC   IsRetailTypeIndicator INT,
# MAGIC   DosageUnitCode STRING,
# MAGIC   ProductFlavourID BIGINT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PharmacyProductSKU"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

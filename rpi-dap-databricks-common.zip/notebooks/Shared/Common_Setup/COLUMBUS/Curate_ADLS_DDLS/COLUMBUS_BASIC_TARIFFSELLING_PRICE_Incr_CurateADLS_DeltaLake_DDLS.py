# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_BasicTariffSellingPrice
# MAGIC (
# MAGIC   BasicTariffSellingPriceSKID BIGINT,
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   EndDate TIMESTAMP,
# MAGIC   PriceAmount DECIMAL(24,4),
# MAGIC   PriceISOCode STRING,
# MAGIC   PriceScheme STRING,
# MAGIC   Region STRING,
# MAGIC   StartDate TIMESTAMP,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/BasicTariffSellingPrice"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------



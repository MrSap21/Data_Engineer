# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_DispensingSupportPharmacyStockLocation
# MAGIC (
# MAGIC DispensingSupportPharmacyStockLocationID INT,
# MAGIC DispensingSupportPharmacyStockID INT,
# MAGIC ActualProductPackID INT,
# MAGIC SourceKey STRING,
# MAGIC LocationCode STRING,
# MAGIC PIPCode STRING,
# MAGIC DispensingSupportPharmacyCode STRING,
# MAGIC UpdateTime TIMESTAMP,
# MAGIC CreationTime TIMESTAMP,
# MAGIC SourceCreationTime TIMESTAMP,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/DispensingSupportPharmacyStockLocation"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


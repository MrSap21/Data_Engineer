# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_countlist (
# MAGIC   CountListSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   PrescribedProductID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   PrescribedProductCode STRING,
# MAGIC   Source STRING,
# MAGIC   StoreCode STRING,
# MAGIC   ThirdPartyCompany STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/CountList'

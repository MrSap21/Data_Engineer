# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_orderstatusupdateline (
# MAGIC   OrderStatusUpdateLineSKID BIGINT,
# MAGIC   OrderStatusUpdateID BIGINT,
# MAGIC   PurchaseOrderLineID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   LineNumber BIGINT,
# MAGIC   DeliveryDate DATE,
# MAGIC   DeliveryRoute STRING,
# MAGIC   DeliveryShift STRING,
# MAGIC   DeliveryReference STRING,
# MAGIC   DeliveryWarehouse STRING,
# MAGIC   SupplierType STRING,
# MAGIC   OrderStatusUpdateLineType STRING,
# MAGIC   DispatchTime TIMESTAMP,
# MAGIC   NotSuppliedQuantity DECIMAL(15,5),
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/OrderStatusUpdateLine'

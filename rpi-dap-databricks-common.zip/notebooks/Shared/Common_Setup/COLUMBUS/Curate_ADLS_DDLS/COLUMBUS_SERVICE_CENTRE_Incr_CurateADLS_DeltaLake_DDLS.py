# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_servicecentre (
# MAGIC   ServiceCentreSiteRoleID BIGINT,
# MAGIC   SourceKey VARCHAR(80),
# MAGIC   SourceSystemID DECIMAL(19,0),
# MAGIC   TerminalCode VARCHAR(50),
# MAGIC   TrunkingPriority DECIMAL(12,0),
# MAGIC   WholesalerCode VARCHAR(50),
# MAGIC   CompanyCode VARCHAR(50),
# MAGIC   ServiceCentreStatus VARCHAR(50),
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year VARCHAR(4),
# MAGIC   Month VARCHAR(2),
# MAGIC   Day VARCHAR(2),
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT NOT NULL,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/ServiceCentre'

# COMMAND ----------



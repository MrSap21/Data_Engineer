# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_purchaseorder (
# MAGIC   PurchaseOrderSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   OrderTypeID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   CustomerCode STRING,
# MAGIC   ProductCodeType STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   SendingTime TIMESTAMP,
# MAGIC   SiteCode STRING,
# MAGIC   Status STRING,
# MAGIC   TerminalID STRING,
# MAGIC   ServiceType STRING,
# MAGIC   PurchaseOrderGroupID BIGINT,
# MAGIC   OrderResponseID BIGINT,
# MAGIC   OrderTypeCode STRING,
# MAGIC   ServiceEntryMode STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   ExemptionID BIGINT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PurchaseOrder'

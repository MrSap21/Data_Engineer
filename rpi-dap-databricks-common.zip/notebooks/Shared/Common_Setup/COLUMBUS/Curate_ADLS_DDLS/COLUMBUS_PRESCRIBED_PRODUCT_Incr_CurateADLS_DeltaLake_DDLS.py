# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC CREATE TABLE columbus_curation.curateadls_prescribedproduct (
# MAGIC   PrescribedProductSKID BIGINT,
# MAGIC   PrescribedItemID BIGINT,
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   BNFWarning STRING,
# MAGIC   CommonDrugServiceCode STRING,
# MAGIC   PrescribedProductName STRING,
# MAGIC   ProductCode STRING,
# MAGIC   ShortName STRING,
# MAGIC   AverageTradePriceAmount DECIMAL(24,4),
# MAGIC   AverageTradePriceISOCode STRING,
# MAGIC   BasicTariffPriceAmount DECIMAL(24,4),
# MAGIC   BasicTariffPriceISOCode STRING,
# MAGIC   ProductClass STRING,
# MAGIC   IsDrugNotMappedIndicator INT,
# MAGIC   IsFreeFormatDrugIndicator INT,
# MAGIC   DosageUnitDescription STRING,
# MAGIC   IsEndorsableIndicator INT,
# MAGIC   IsFlavouredIndicator INT,
# MAGIC   PrescribedProductType STRING,
# MAGIC   IsHighRiskIndicator INT,
# MAGIC   IsCommonDrugServiceCodeMatchedIndicator INT,
# MAGIC   ControlledDrugCode STRING,
# MAGIC   UncatalogueProductType STRING,
# MAGIC   BNFWarning2 STRING,
# MAGIC   Form STRING,
# MAGIC   Strength STRING,
# MAGIC   IsControlledDrugIndicator INT,
# MAGIC   DMDDescription STRING,
# MAGIC   OriginalProductName STRING,
# MAGIC   VTMCode STRING,
# MAGIC   VTMDescription STRING,
# MAGIC   OldCommonDrugServiceCode STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PrescribedProduct'

# COMMAND ----------



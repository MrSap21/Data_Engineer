# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_BagPart
# MAGIC (
# MAGIC BagPartSKID INT,
# MAGIC PrescriptionGroupID INT,
# MAGIC PatientPartyRoleID INT,
# MAGIC PharmacyStoreSiteRoleId INT,
# MAGIC ToteID INT,
# MAGIC SourceKey STRING,
# MAGIC LegacyStoreCode STRING,
# MAGIC PatientCode STRING,
# MAGIC PrescriptionGroupCode STRING,
# MAGIC PrescriptionGroupCreationDate TIMESTAMP,
# MAGIC SourceGroupID STRING,
# MAGIC SourcePatientID STRING,
# MAGIC StoreCode STRING,
# MAGIC WholeSalerCode STRING,
# MAGIC BagPartStatus STRING,
# MAGIC ExpectedQuantity INT,
# MAGIC ReceivedQuantity INT,
# MAGIC IsCPCReceivedIndicator INT,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/BagPart"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_orderstatusupdatelinesupplied (
# MAGIC   OrderStatusUpdateLineSuppliedSKID BIGINT,
# MAGIC   OrderStatusUpdateLineOrderedID BIGINT,
# MAGIC   HandlingUnitID BIGINT,
# MAGIC   ToteID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   AcceptedQuantity BIGINT,
# MAGIC   OrderStatusUpdateLineSuppliedCode STRING,
# MAGIC   HandlingUnitCode STRING,
# MAGIC   Messages STRING,
# MAGIC   NetCostAmount DECIMAL(24,4),
# MAGIC   NetCostISOCode STRING,
# MAGIC   PackSize BIGINT,
# MAGIC   PIPCode STRING,
# MAGIC   ProductDescription STRING,
# MAGIC   ReasonCode STRING,
# MAGIC   SuppliedQuantity BIGINT,
# MAGIC   ToteCode STRING,
# MAGIC   VatRateAmount DECIMAL(24,4),
# MAGIC   VatRateISOCode STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/OrderStatusUpdateLineSupplied'

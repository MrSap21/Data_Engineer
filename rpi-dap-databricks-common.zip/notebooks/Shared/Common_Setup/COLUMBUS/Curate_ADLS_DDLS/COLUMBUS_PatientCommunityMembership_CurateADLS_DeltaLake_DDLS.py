# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PatientCommunityMembership
# MAGIC (
# MAGIC PatientCommunityMembershipSKID BIGINT,
# MAGIC   PatientCommunityID BIGINT,
# MAGIC   PatientPartyRoleID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   PatientCode STRING,
# MAGIC   PatientCommunityCode STRING,
# MAGIC   PatientCommunityMembershipPosition STRING,
# MAGIC   PatientCommunityMembershipStatus STRING,
# MAGIC   UpdateTime TIMESTAMP,
# MAGIC   OldPatientCode STRING,
# MAGIC   ChildCareHomeCode STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   SCDStartDate TIMESTAMP,
# MAGIC   SCDEndDate TIMESTAMP,
# MAGIC   SCDActiveFlag STRING,
# MAGIC   SCDVersion INT,
# MAGIC   SCDLOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PatientCommunityMembership"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------



# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_replenishmentorderline (
# MAGIC   ReplenishmentOrderLineSKID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   ActualProductPackID BIGINT,
# MAGIC   OrderTypeID BIGINT,
# MAGIC   ManualOrderReasonID BIGINT,
# MAGIC   DispensedItemID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   ActualProductPackCode STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   DispensedItemCode STRING,
# MAGIC   IsDPPExcludeIndicator DECIMAL(1,0),
# MAGIC   OrderQuantity BIGINT,
# MAGIC   PackSize DECIMAL(15,5),
# MAGIC   IsPatientPreferenceIndicator DECIMAL(1,0),
# MAGIC   PIPCode STRING,
# MAGIC   QuantityUsed DECIMAL(15,5),
# MAGIC   ServiceEntryMode STRING,
# MAGIC   ServiceType STRING,
# MAGIC   SiteCode STRING,
# MAGIC   IsSpecialConfirmationIndicator DECIMAL(1,0),
# MAGIC   ProcessingTime TIMESTAMP,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   ProductSKUCode STRING,
# MAGIC   SuggestedOrderQuantity BIGINT,
# MAGIC   IsTransmittedIndicator DECIMAL(1,0),
# MAGIC   IsExcludedIndicator DECIMAL(1,0),
# MAGIC   IsDebarredIndicator DECIMAL(1,0),
# MAGIC   IsCSSPLineIndicator DECIMAL(1,0),
# MAGIC   UserName STRING,
# MAGIC   IsFullUsedIndicator DECIMAL(1,0),
# MAGIC   ProductDescription STRING,
# MAGIC   IsUncataloguedProductIndicator DECIMAL(1,0),
# MAGIC   UnitOfMeasure STRING,
# MAGIC   ReceivingQuantity DECIMAL(15,5),
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/ReplenishmentOrderLine'

# COMMAND ----------



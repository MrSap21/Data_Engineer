# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

CREATE TABLE columbus_curation.curateadls_patientadversereaction (
  PatientAdverseReactionSKID BIGINT,
  PatientPartyRoleID BIGINT,
  AdverseReactionID BIGINT,
  SourceKey STRING,
  AdverseReactionDate TIMESTAMP,
  PatientAdverseReactionCode STRING,
  PatientAdverseReactionUserCode STRING,
  LegacyAdverseReactionCode STRING,
  PatientAdverseReactionNote STRING,
  RunDateTime TIMESTAMP,
  Year STRING,
  Month STRING,
  Day STRING,
  RecordStatusFlag STRING,
  CreatedTime TIMESTAMP,
  UpdatedTime TIMESTAMP,
  LOVRecordSourceId INT,
  ETLRunLogId INT)
USING delta
PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PatientAdverseReaction'
TBLPROPERTIES (
  'Type' = 'EXTERNAL',
  'delta.minReaderVersion' = '1',
  'delta.minWriterVersion' = '2')

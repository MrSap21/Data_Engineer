# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PharmacyUncataloguedProduct
# MAGIC (
# MAGIC UncataloguedProductSKID INT NOT NULL,
# MAGIC PharmacyStoreSiteRoleId INT,
# MAGIC FormulationID INT,
# MAGIC DosageUnitID INT,
# MAGIC SourceKey STRING NOT NULL,
# MAGIC AdditionalNote STRING,
# MAGIC CreationTime TIMESTAMP,
# MAGIC UncataloguedProductDescription STRING,
# MAGIC EndorsementDetail STRING,
# MAGIC ItemName STRING,
# MAGIC LegalClassification STRING,
# MAGIC NormalizedName STRING,
# MAGIC UncataloguedProductStatus STRING,
# MAGIC StoreCode STRING,
# MAGIC Strength STRING,
# MAGIC UncataloguedProductType STRING,
# MAGIC DosageUnitCode STRING,
# MAGIC FormulationCode STRING,
# MAGIC IsControlledDrugIndicator INT,
# MAGIC PackQuantity STRING,
# MAGIC RunDateTime TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC RecordStatusFlag CHAR(1),
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID INT NOT NULL,
# MAGIC ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PharmacyUncataloguedProduct"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
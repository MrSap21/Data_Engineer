# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_ProductUsage
# MAGIC (
# MAGIC ProductUsageSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleID BIGINT,
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   AverageDayQuantity DECIMAL(15,5),
# MAGIC   HoldingDemand DECIMAL(15,5),
# MAGIC   HoldingFrequency DECIMAL(15,5),
# MAGIC   HoldingPeriodScripts BIGINT,
# MAGIC   LongTermFrequency DECIMAL(15,5),
# MAGIC   LongTermScripts BIGINT,
# MAGIC   MaxDailyQuantity DECIMAL(15,5),
# MAGIC   ProductCode STRING,
# MAGIC   RangingCostAmount DECIMAL(24,4),
# MAGIC   RangingCostISOCode STRING,
# MAGIC   RangingFrequency DECIMAL(15,5),
# MAGIC   RangingFrequencyType STRING,
# MAGIC   ShortTermFrequency DECIMAL(15,5),
# MAGIC   ShortTermScripts BIGINT,
# MAGIC   StoreCode STRING,
# MAGIC   TradingAdjustmentFactor DECIMAL(15,5),
# MAGIC   IsTradingAdjustmentFactorUpliftIndicator INT,
# MAGIC   LongTermUnits BIGINT,
# MAGIC   ShortTermUnits BIGINT,
# MAGIC   DemandMovement STRING,
# MAGIC   WeekTermScript BIGINT,
# MAGIC   WeekTermUnits DECIMAL(15,5),
# MAGIC   JobExecutionID BIGINT,
# MAGIC   GridID BIGINT,
# MAGIC   RangingX BIGINT,
# MAGIC   RangingY BIGINT,
# MAGIC   HoldingX BIGINT,
# MAGIC   HoldingY BIGINT,
# MAGIC   JobCalculationDate TIMESTAMP,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/ProductUsage"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

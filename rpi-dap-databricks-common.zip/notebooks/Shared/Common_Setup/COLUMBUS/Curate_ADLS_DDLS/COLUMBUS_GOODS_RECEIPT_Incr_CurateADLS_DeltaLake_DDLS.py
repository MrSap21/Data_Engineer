# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_GoodsReceipt
# MAGIC (
# MAGIC   GoodsReceiptSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   DeliveryReference STRING,
# MAGIC   GoodsReceiptStatus STRING,
# MAGIC   SupplierType STRING,
# MAGIC   WorkType STRING,
# MAGIC   StoreCode STRING,
# MAGIC   ReceivedTime TIMESTAMP,
# MAGIC   DeliveryDate DATE,
# MAGIC   DeliveryWarehouse STRING,
# MAGIC   ServiceEntryMode STRING,
# MAGIC   ServiceType STRING,
# MAGIC   IsTelesaleOrderIndicator INT,
# MAGIC   DeliverySlot BIGINT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/GoodsReceipt"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

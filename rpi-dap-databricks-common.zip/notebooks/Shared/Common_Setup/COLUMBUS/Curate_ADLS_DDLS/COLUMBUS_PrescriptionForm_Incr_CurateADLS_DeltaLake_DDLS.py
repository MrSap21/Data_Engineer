# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PrescriptionForm
# MAGIC (
# MAGIC PrescriptionFormSKID  BIGINT,
# MAGIC PrescriptionFormTypeID  INT  ,
# MAGIC ElectronicPrescriptionID  INT ,
# MAGIC PrescriptionGroupID INT,
# MAGIC PrescriptionServiceID  INT  ,
# MAGIC SourceKey  STRING  NOT NULL,
# MAGIC SourceSystemID INT,
# MAGIC PracticeCode  STRING  ,
# MAGIC PracticeContext  STRING ,
# MAGIC PrescriberCode  STRING  ,
# MAGIC PrescriberContext STRING  ,
# MAGIC PrescriptionDate  TIMESTAMP  ,
# MAGIC PrescriptionNumber  INT ,
# MAGIC PrescriptionTypeCode  STRING  ,
# MAGIC Reason  STRING  ,
# MAGIC SourcePrescriptionID  STRING  ,
# MAGIC PrescriptionFormStatus  STRING  ,
# MAGIC PrescriberLegacyCode  STRING  ,
# MAGIC PracticeLegacyCode  STRING ,
# MAGIC LastEnteredTime  TIMESTAMP  ,
# MAGIC TotalPriceAmount  DECIMAL(24,4)  ,
# MAGIC TotalPriceISOCode  STRING  ,
# MAGIC ProcessingTime  TIMESTAMP  ,
# MAGIC LevyFeeCode  STRING  ,
# MAGIC DiscountAmount  DECIMAL(24,4)  ,
# MAGIC DiscountISOCode  STRING ,
# MAGIC PrivateReferenceNumber STRING ,
# MAGIC IsElectronicIndicator  INT  ,
# MAGIC IsStockedIndicator  INT  ,
# MAGIC ExpirationDate  DATE  ,
# MAGIC IsManualPriceIndicator  INT  ,
# MAGIC LocalPracticeName  STRING  ,
# MAGIC LocalPrescriberName STRING  ,
# MAGIC DefaultPracticeCode STRING  ,
# MAGIC DefaultPrescriberCode STRING  ,
# MAGIC EPSServiceType  STRING  ,
# MAGIC ClaimedTime  TIMESTAMP  ,
# MAGIC UniquePrescriptionNumber  STRING  ,
# MAGIC AdditionalFeeAmount DECIMAL(24,4)  ,
# MAGIC AdditionalFeeISOCode  STRING  ,
# MAGIC VATApplied  INT  ,
# MAGIC TotalVATAmount  DECIMAL(24,4)  ,
# MAGIC TotalVATISOCode  STRING  ,
# MAGIC ProducedDate  DATE  ,
# MAGIC IsPrescriberFullMatchIndicator  INT  ,
# MAGIC ClaimStatus STRING  ,
# MAGIC IsExemptionEvidenceSeenIndicator  INT ,
# MAGIC NotifiedExemptionCode  STRING ,
# MAGIC Fulfilled  STRING  ,
# MAGIC ExemptionType  STRING  ,
# MAGIC RunDateTime  TIMESTAMP  ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT,
# MAGIC ETLRunLogID  INT 
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PrescriptionForm"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


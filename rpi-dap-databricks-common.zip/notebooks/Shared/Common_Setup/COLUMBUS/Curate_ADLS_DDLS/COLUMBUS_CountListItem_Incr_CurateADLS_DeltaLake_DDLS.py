# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_countlistitem (
# MAGIC   CountListItemSKID BIGINT,
# MAGIC   CountListID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   CountedPackQuantity BIGINT,
# MAGIC   CountedUnitQuantity DECIMAL(15,5),
# MAGIC   OnShelfUnitQuantity DECIMAL(15,5),
# MAGIC   IsPreferredIndicator INT,
# MAGIC   IsPrimaryIndicator INT,
# MAGIC   ProductSKUCode STRING,
# MAGIC   Reason STRING,
# MAGIC   CountListItemStatus STRING,
# MAGIC   UpdateTime TIMESTAMP,
# MAGIC   UserInitial STRING,
# MAGIC   UserName STRING,
# MAGIC   IsOrderableIndicator INT,
# MAGIC   RundateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/CountListItem'

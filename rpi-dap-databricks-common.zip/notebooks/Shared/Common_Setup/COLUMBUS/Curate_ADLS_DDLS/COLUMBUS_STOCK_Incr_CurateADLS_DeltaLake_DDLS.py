# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Stock
# MAGIC (
# MAGIC StockSKID INT ,
# MAGIC PharmacyProductSKUID INT ,
# MAGIC PharmacyStoreSiteRoleId BIGINT ,
# MAGIC SourceKey STRING ,
# MAGIC LastUpdateTime TIMESTAMP ,
# MAGIC NextDeliveryDate TIMESTAMP ,
# MAGIC ProductSKUCode STRING ,
# MAGIC StockStatus STRING ,
# MAGIC StoreCode STRING ,
# MAGIC OnShelfQuantity DECIMAL(15,5) ,
# MAGIC LastOperation STRING ,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC LOVRecordSourceId INT,
# MAGIC ETLRunLogId INT ,
# MAGIC EndDate DATE ,
# MAGIC StartDate DATE ,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag STRING
# MAGIC
# MAGIC
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Stock"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
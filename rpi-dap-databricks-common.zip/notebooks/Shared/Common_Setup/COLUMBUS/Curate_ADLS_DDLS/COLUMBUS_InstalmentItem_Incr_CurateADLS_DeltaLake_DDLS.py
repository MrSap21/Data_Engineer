# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_InstalmentItem
# MAGIC (
# MAGIC   InstalmentItemSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   InstalmentID BIGINT,
# MAGIC   DispensedItemID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   CollectionDate DATE,
# MAGIC   DailyQuantity DECIMAL(15,5),
# MAGIC   InstalmentDate DATE,
# MAGIC   Ordering BIGINT,
# MAGIC   Progressive BIGINT,
# MAGIC   Quantity DECIMAL(15,5),
# MAGIC   InstalmentStatus STRING,
# MAGIC   IsSupervisedIndicator INT,
# MAGIC   IsPrintedIndicator INT,
# MAGIC   DispensedItemCode STRING,
# MAGIC   UpdateStatusTime TIMESTAMP,
# MAGIC   IsCollectedIndicator INT,
# MAGIC   StoreCode STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/InstalmentItem"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

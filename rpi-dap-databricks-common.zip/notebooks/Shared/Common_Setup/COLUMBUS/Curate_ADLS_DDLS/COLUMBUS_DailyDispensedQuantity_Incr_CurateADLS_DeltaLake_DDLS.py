# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_dailydispensedquantity (
# MAGIC   DailyDispensedQuantitySKID BIGINT,
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   ActualProductPackID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   AppCode STRING,
# MAGIC   DispensedDate DATE,
# MAGIC   PipCode STRING,
# MAGIC   ProductCode STRING,
# MAGIC   Quantity DECIMAL(15,5),
# MAGIC   ScriptNumber BIGINT,
# MAGIC   SKUCode STRING,
# MAGIC   StoreCode STRING,
# MAGIC   ServiceEntryMode STRING,
# MAGIC   OwingQuantityRedeemed DECIMAL(15,5),
# MAGIC   OwingQuantityOutstanding DECIMAL(15,5),
# MAGIC   OwingNumber BIGINT,
# MAGIC   ServiceType STRING,
# MAGIC   PrescriptionDate DATE,
# MAGIC   ScriptNumberOutstanding BIGINT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/DailyDispensedQuantity'

# COMMAND ----------



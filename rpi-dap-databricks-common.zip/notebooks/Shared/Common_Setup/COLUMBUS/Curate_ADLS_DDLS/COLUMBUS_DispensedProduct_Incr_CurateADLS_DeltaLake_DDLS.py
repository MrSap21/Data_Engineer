# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_dispensedproduct (
# MAGIC   DispensedProductSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   DispensedItemID BIGINT,
# MAGIC   ActualProductPackID BIGINT,
# MAGIC   SupplierID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   ActualProductPackCode STRING,
# MAGIC   CommonDrugServiceCode STRING,
# MAGIC   CostPriceAmount DECIMAL(24,4),
# MAGIC   CostPriceISOCode STRING,
# MAGIC   DispensedProductName STRING,
# MAGIC   ProductSKUCode STRING,
# MAGIC   ShortName STRING,
# MAGIC   SourceType STRING,
# MAGIC   TariffPriceAmount DECIMAL(24,4),
# MAGIC   TariffPriceISOCode STRING,
# MAGIC   UnitPriceAmount DECIMAL(24,4),
# MAGIC   UnitPriceISOCode STRING,
# MAGIC   PackQuantity DECIMAL(15,5),
# MAGIC   BuyingMultiple BIGINT,
# MAGIC   IsBuyingMultipleEnforcedIndicator INT,
# MAGIC   IsBuyingMultipleOptimisationIndicator INT,
# MAGIC   PackName STRING,
# MAGIC   IsPreferredIndicator INT,
# MAGIC   PIPCode STRING,
# MAGIC   RecevingQuantity DECIMAL(15,5),
# MAGIC   SupplierCode STRING,
# MAGIC   IsRetailUsedIndicator INT,
# MAGIC   DosageUnitDescription STRING,
# MAGIC   StoreCode STRING,
# MAGIC   FullDescription STRING,
# MAGIC   DMDDescription STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/DispensedProduct'

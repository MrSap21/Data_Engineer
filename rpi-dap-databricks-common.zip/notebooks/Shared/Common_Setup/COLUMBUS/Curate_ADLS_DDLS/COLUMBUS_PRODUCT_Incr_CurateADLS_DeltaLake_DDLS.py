# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateAdls_Product
# MAGIC (
# MAGIC ProductId BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   LOVSourceKeyTypeId INT,
# MAGIC   ProductName STRING,
# MAGIC   ProductDescription STRING,
# MAGIC   LOVBrandId INT,
# MAGIC   LOVSubBrandId INT,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ParentProductId BIGINT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   ETLRunLogId INT,
# MAGIC   PSARowKey INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING
# MAGIC
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Product"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

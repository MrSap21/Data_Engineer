# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_DispensingSupportPharmacyPrescription
# MAGIC (
# MAGIC DispensingSupportPharmacyPrescriptionSKID int,
# MAGIC PharmacyStoreSiteRoleId bigint,
# MAGIC PatientPartyRoleId bigint,
# MAGIC PrescriptionGroupId int,
# MAGIC SourceKey string,
# MAGIC SourceType string,
# MAGIC IsExcludedIndicator int,
# MAGIC CreationTime timestamp,
# MAGIC UpdateTime timestamp,
# MAGIC IsPartialIndicator int,
# MAGIC ProcessingTime timestamp,
# MAGIC DeliveryDate timestamp,
# MAGIC DispensingSupportPharmacyPrescriptionStatus string,
# MAGIC Source string,
# MAGIC RunDateTime	TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC RecordStatusFlag	 STRING,
# MAGIC CreatedTime 	TIMESTAMP,
# MAGIC UpdatedTime	TIMESTAMP,
# MAGIC LOVRecordSourceID	INT,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/DispensingSupportPharmacyPrescription"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


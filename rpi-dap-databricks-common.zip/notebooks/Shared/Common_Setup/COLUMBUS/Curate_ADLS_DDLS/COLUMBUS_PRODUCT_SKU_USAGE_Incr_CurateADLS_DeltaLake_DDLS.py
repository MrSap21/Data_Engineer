# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_productskuusage (
# MAGIC   ProductSKUUsageSKID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   PharmacyStoreSiteRoleID BIGINT,
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   AverageDayQuantity DECIMAL(15,5),
# MAGIC   DistributionPercentage DECIMAL(5,2),
# MAGIC   ProductSKUCode STRING,
# MAGIC   StoreCode STRING,
# MAGIC   MinimunValue DECIMAL(15,5),
# MAGIC   MaximumValue DECIMAL(15,5),
# MAGIC   ProductCode STRING,
# MAGIC   CDCApplyTime TIMESTAMP,
# MAGIC   JobExecutionID BIGINT,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/ProductSKUUsage'

# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_packqualifier (
# MAGIC   PackQualifierSKID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   PharmacyRegionalProductSKUID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   NumberOfCycles BIGINT,
# MAGIC   PackType STRING,
# MAGIC   PackQualifierStatus STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PackQualifier'

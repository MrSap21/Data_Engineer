# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_orderstatusupdatelineordered (
# MAGIC   OrderStatusUpdateLineOrderedSKID BIGINT,
# MAGIC   OrderStatusUpdateLineID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   PackSize BIGINT,
# MAGIC   PIPCode STRING,
# MAGIC   ProductDescription STRING,
# MAGIC   Quantity BIGINT,
# MAGIC   OrderStatusUpdateLineOrderedCode STRING,
# MAGIC   SupplyingWarehouse STRING,
# MAGIC   LineOrderedReference STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/OrderStatusUpdateLineOrdered'

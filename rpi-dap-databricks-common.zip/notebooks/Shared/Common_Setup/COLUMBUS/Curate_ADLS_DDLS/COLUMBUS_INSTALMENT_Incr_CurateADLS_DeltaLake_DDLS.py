# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Instalment
# MAGIC (
# MAGIC   InstalmentSKID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   PrescribedItemID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   CollectionDays BIGINT,
# MAGIC   CollectionFrequency STRING,
# MAGIC   Duration BIGINT,
# MAGIC   InstalmentStartDate TIMESTAMP,
# MAGIC   IsMondayIndicator INT,
# MAGIC   IsTuesdayIndicator INT,
# MAGIC   IsWednesdayIndicator INT,
# MAGIC   IsThursdayIndicator INT,
# MAGIC   IsFridayIndicator INT,
# MAGIC   IsSaturdayIndicator INT,
# MAGIC   IsSundayIndicator INT,
# MAGIC   IsSeparateContainersIndicator INT,
# MAGIC   IsSupervisedIndicator INT,
# MAGIC   IsTwoInstalmentsPerDayIndicator INT,
# MAGIC   ProductSKUCode STRING,
# MAGIC   LinePrinted BIGINT,
# MAGIC   InstalmentType STRING,
# MAGIC   UpdateTime TIMESTAMP,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT 
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Instalment"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------



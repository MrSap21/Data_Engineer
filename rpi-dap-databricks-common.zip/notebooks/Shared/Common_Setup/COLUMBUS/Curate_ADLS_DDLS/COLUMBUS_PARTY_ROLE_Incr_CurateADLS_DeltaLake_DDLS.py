# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PartyRole
# MAGIC (
# MAGIC PartyRoleId BIGINT,
# MAGIC LOVRoleId INT,
# MAGIC PartyId BIGINT,
# MAGIC SourceKey STRING,
# MAGIC PartyRoleName STRING,
# MAGIC LOVRecordSourceId INT,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag string,
# MAGIC ETLRunLogId INT,
# MAGIC PSARowKey BIGINT,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PartyRole"
# MAGIC PARTITIONED BY(LOVRecordSourceID,Year,Month,Day);

# COMMAND ----------


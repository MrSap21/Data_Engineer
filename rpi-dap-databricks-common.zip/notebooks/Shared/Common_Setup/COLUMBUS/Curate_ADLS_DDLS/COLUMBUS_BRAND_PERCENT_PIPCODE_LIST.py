# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_BrandPercentagePIPCodeList
# MAGIC (
# MAGIC BrandPercentagePIPCodeListSKID numeric(19, 0) NOT NULL,
# MAGIC PIPCODE string NOT NULL,
# MAGIC CreationDateTime timestamp NOT NULL,
# MAGIC EgressStatusFlag string NOT NULL,
# MAGIC LOVRecordSourceID int,
# MAGIC RunDateTime timestamp,
# MAGIC SCDStartDate timestamp,
# MAGIC SCDEndDate timestamp,
# MAGIC SCDActiveFlag string,
# MAGIC SCDVersion int,
# MAGIC ETLRunLogID int
# MAGIC )
# MAGIC
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/BrandPercentagePIPCodeList"

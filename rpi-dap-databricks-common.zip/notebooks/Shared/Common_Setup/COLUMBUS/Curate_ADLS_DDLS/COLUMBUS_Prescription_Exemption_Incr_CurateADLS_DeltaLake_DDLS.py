# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_prescriptionexemption (
# MAGIC   SourceSystemID BIGINT,
# MAGIC   PrescriptionExemptionSKId BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   PatientPartyRoleId BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceType STRING,
# MAGIC   IsActiveIndicator INT,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   UpdateTime TIMESTAMP,
# MAGIC   RepeatIssueNumber STRING,
# MAGIC   TransmissionId STRING,
# MAGIC   ResponseType STRING,
# MAGIC   ResponseMessage STRING,
# MAGIC   ExemptionId BIGINT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PrescriptionExemption'

# COMMAND ----------



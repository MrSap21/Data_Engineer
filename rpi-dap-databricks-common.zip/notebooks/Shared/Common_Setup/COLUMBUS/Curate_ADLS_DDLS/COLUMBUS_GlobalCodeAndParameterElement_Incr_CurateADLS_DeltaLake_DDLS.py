# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_GlobalCodeAndParameterElement
# MAGIC (
# MAGIC   GlobalCodeAndParameterElementSKID BIGINT,
# MAGIC   SourceKey BIGINT,
# MAGIC   MetadataSourceKey BIGINT,
# MAGIC   GlobalCodeAndParameterElementCategory STRING,
# MAGIC   GlobalCodeAndParameterElementComment STRING,
# MAGIC   CustomizationKey STRING,
# MAGIC   FullReference STRING,
# MAGIC   OrderElement BIGINT,
# MAGIC   SubCategory STRING,
# MAGIC   GlobalCodeAndParameterElementParentID BIGINT,
# MAGIC   LogicalName STRING,
# MAGIC   DefaultLabel STRING,
# MAGIC   DefaultValue STRING,
# MAGIC   GlobalCodeAndParameterElementDescription STRING,
# MAGIC   MinValue STRING,
# MAGIC   MaxValue STRING,
# MAGIC   IsMandatoryIndicator INT,
# MAGIC   IsListIndicator INT,
# MAGIC   IsAllowAddIndicator INT,
# MAGIC   IsEnumerationIndicator INT,
# MAGIC   IsAllowDeleteIndicator INT,
# MAGIC   EnumValueReference STRING,
# MAGIC   ValidityStartDate DATE,
# MAGIC   ValidityEndDate DATE,
# MAGIC   StartRelease BIGINT,
# MAGIC   EndRelease BIGINT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/GlobalCodeAndParameterElement"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_masterprescribeditem (
# MAGIC   MasterPrescribedItemSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   ElectronicPrescribedItemID BIGINT,
# MAGIC   PrescriptionFormID BIGINT,
# MAGIC   PrescribedItemID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   EPrescribedItemCode STRING,
# MAGIC   PrescriptionFormCode STRING,
# MAGIC   PrescribedItemCode STRING,
# MAGIC   EventsNumber BIGINT,
# MAGIC   CurrentEventNumber BIGINT,
# MAGIC   Duration STRING,
# MAGIC   DurationUOM STRING,
# MAGIC   Frequency STRING,
# MAGIC   IsNotDispensableIndicator INT,
# MAGIC   DispensingEventQuantity DECIMAL(15,5),
# MAGIC   StoreCode STRING,
# MAGIC   MasterPrescribedItemStatus STRING,
# MAGIC   ProductDescription STRING,
# MAGIC   ProductCommonDrugServiceCode STRING,
# MAGIC   RunningTotal DECIMAL(15,5),
# MAGIC   PrescribedDate DATE,
# MAGIC   TSRPracticeReportID BIGINT,
# MAGIC   TSRReferenceCode STRING,
# MAGIC   IsElectronicIndicator INT,
# MAGIC   NotDispensableDate DATE,
# MAGIC   CancelledDate DATE,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/MasterPrescribedItem'

# COMMAND ----------



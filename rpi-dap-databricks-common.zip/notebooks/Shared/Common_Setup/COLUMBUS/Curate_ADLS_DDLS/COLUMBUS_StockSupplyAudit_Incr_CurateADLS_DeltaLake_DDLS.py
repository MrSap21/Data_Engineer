# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_StockSupplyAudit
# MAGIC (
# MAGIC StockSupplyAuditSKID int,
# MAGIC PurchaseOrderID	int,
# MAGIC ProductProductSKUID	int,
# MAGIC PharmacyStoreSiteRoleId	BIGINT,
# MAGIC PharmacyProductID int,
# MAGIC SourceKey String,
# MAGIC OnOrder	decimal(15,5),
# MAGIC OnShelf	decimal(15,5),
# MAGIC Reserved decimal(15,5),
# MAGIC Overstock decimal(15,5),
# MAGIC Status String,
# MAGIC StoreCode String,
# MAGIC OperationType String,
# MAGIC ProductCode	String,
# MAGIC PurchaseOrderRef String,
# MAGIC ProductSKUCode String,
# MAGIC RequestTime	timestamp,
# MAGIC ResultDescription String,
# MAGIC MinimumSKUValue decimal(15,5),
# MAGIC MaximumSKUValue	decimal(15,5),
# MAGIC StockSupplyRequestID int,
# MAGIC RunDateTime timestamp ,
# MAGIC Year  string ,
# MAGIC Month  string ,
# MAGIC Day string ,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC LOVRecordSourceID INT,
# MAGIC ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/StockSupplyAudit"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


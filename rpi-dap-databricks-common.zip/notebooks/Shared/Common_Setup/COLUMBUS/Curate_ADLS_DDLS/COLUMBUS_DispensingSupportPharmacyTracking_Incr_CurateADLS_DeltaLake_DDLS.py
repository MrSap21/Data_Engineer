# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_DispensingSupportPharmacyTracking
# MAGIC (
# MAGIC DspTrackingSKID INT,
# MAGIC SourceKey STRING,
# MAGIC CreationTime TIMESTAMP,
# MAGIC PrescriptionGroupCode STRING,
# MAGIC Result STRING,
# MAGIC NumberOfItems INT,
# MAGIC Process STRING,
# MAGIC AppCodeFailed STRING,
# MAGIC Reason STRING,
# MAGIC TriagedItems INT,
# MAGIC PrescriptionFormCode STRING,
# MAGIC RunDateTime TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC RecordStatusFlag  string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC LOVRecordSourceID INT,
# MAGIC ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/DispensingSupportPharmacyTracking"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
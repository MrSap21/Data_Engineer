# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Exemption
# MAGIC (
# MAGIC ExemptionSKID	INT,
# MAGIC SourceKey	STRING,
# MAGIC IsAgeExemptionIndicator	INT,
# MAGIC ExemptionDescription	STRING,
# MAGIC MaxAge	INT,
# MAGIC MinAge	INT,
# MAGIC IsEligibleCMSIndicator	INT,
# MAGIC IsEligibleMASIndicator	INT,
# MAGIC DisplaySequence	INT,
# MAGIC IsMandatoryAgeExemptionIndicator	INT,
# MAGIC MessageHandlingSystemCode	STRING,
# MAGIC IsExpiryDateRequiredIndicator	INT,
# MAGIC IsEvidenceSeenIndicator	INT,
# MAGIC IsNorthWestOstomySuppliesEligibleIndicator	INT,
# MAGIC IsSelectableIndicator	INT,
# MAGIC RunDateTime	timestamp,
# MAGIC Year 	STRING,
# MAGIC Month 	STRING,
# MAGIC Day 	STRING,
# MAGIC RecordStatusFlag	 STRING,
# MAGIC CreatedTime 	timestamp,
# MAGIC UpdatedTime	timestamp,
# MAGIC LOVRecordSourceID	INT,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Exemption"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
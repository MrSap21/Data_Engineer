# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_pharmacystore (
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   IsCentralPharmacyIndicator INT,
# MAGIC   WholesalerCode STRING,
# MAGIC   Description STRING,
# MAGIC   TerminalCode STRING,
# MAGIC   LegacyStoreID STRING,
# MAGIC   LegacyCode STRING,
# MAGIC   CompanyCode STRING,
# MAGIC   PrinterLabelAddress STRING,
# MAGIC   PrinterLabelName STRING,
# MAGIC   StoreStatus STRING,
# MAGIC   NACSCode STRING,
# MAGIC   NHSCode STRING,
# MAGIC   EPSPriority INT,
# MAGIC   PDCCode STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogID INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PharmacyStore'

# COMMAND ----------



# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_owing (
# MAGIC   OwingSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   PrescribedItemID BIGINT,
# MAGIC   DispensedItemID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   CreationDate TIMESTAMP,
# MAGIC   LastChangeDate TIMESTAMP,
# MAGIC   IsNotDispensedIndicator DECIMAL(1,0),
# MAGIC   OwingQuantity DECIMAL(15,5),
# MAGIC   OwingStatus STRING,
# MAGIC   DispensedItemCode STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   QuantityNotSupplied DECIMAL(15,5),
# MAGIC   OldQuantity DECIMAL(15,5),
# MAGIC   StoreCode STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/Owing'

# COMMAND ----------



# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql 
# MAGIC CREATE TABLE columbus_curation.curateadls_pharmacyproduct (
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   ApplianceRefNumber STRING,
# MAGIC   CDSchedule STRING,
# MAGIC   CommonDrugServiceCode STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   ProductDescription STRING,
# MAGIC   IsNoCheaperStockObtainableIndicator INT,
# MAGIC   NoCheaperStockObtainableEffectiveEndDate DATE,
# MAGIC   NoCheaperStockObtainableEffectiveStartDate DATE,
# MAGIC   NormalizedProductName STRING,
# MAGIC   ProductClass STRING,
# MAGIC   ProductName STRING,
# MAGIC   ProductShortName STRING,
# MAGIC   ProductStatus STRING,
# MAGIC   IsSugarFreeIndicator INT,
# MAGIC   ProductFormID BIGINT,
# MAGIC   ProductFlavourID BIGINT,
# MAGIC   ControlledDrugCode STRING,
# MAGIC   IsHighRiskIndicator INT,
# MAGIC   IsContraceptiveUseIndicator INT,
# MAGIC   SnomedCode STRING,
# MAGIC   VTMCode STRING,
# MAGIC   VTMDescription STRING,
# MAGIC   IsNMSEligibleIndicator INT,
# MAGIC   IsForceClinicalCheckIndicator INT,
# MAGIC   OldCommonDrugServiceCode STRING,
# MAGIC   OldSnomedCode STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PharmacyProduct'

# COMMAND ----------



# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_additionalendorsement (
# MAGIC   AdditionalEndorsementSKID BIGINT,
# MAGIC   PrescribedItemID BIGINT,
# MAGIC   DispensedItemID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   IsDispensedAdditionalEndorsementIndicator INT,
# MAGIC   AdditionalDescription STRING,
# MAGIC   BatchNumber STRING,
# MAGIC   IsBrokenBulkIndicator INT,
# MAGIC   IsBrokenBulkSurplusIndicator INT,
# MAGIC   IsContraceptiveItemIndicator INT,
# MAGIC   IsExtempIndicator INT,
# MAGIC   IsExtraContainerIndicator INT,
# MAGIC   IsExtraItemIndicator INT,
# MAGIC   InvoiceNumber STRING,
# MAGIC   Manufacturer INT,
# MAGIC   IsMeasuredFittedIndicator INT,
# MAGIC   IsNotCollectIndicator INT,
# MAGIC   PrescriptionDispensedDate TIMESTAMP,
# MAGIC   IsPrescriberContactedIndicator INT,
# MAGIC   PrescriberDetail STRING,
# MAGIC   IsPrescriberPCFlagIndicator INT,
# MAGIC   Region STRING,
# MAGIC   IsRepeatDispensedIndicator INT,
# MAGIC   IsRepeatInterventionIndicator INT,
# MAGIC   SupplierLicenceID STRING,
# MAGIC   IsUrgentSupplyIndicator INT,
# MAGIC   UrgentSupplyDispensedTime TIMESTAMP,
# MAGIC   UserInitial STRING,
# MAGIC   NumberPackagedDose BIGINT,
# MAGIC   IsPackagedDoseIndicator INT,
# MAGIC   IsRebatClaimedIndicator INT,
# MAGIC   IsWasteReductionIndicator INT,
# MAGIC   IsInvoicePriceIndicator INT,
# MAGIC   InvoicePriceValue DECIMAL(15,5),
# MAGIC   IsLevyChargedIndicator INT,
# MAGIC   IsUrgentDispensingIndicator INT,
# MAGIC   IsPublicHolidayIndicator INT,
# MAGIC   UrgentDispensingDateTime TIMESTAMP,
# MAGIC   IsPMRCheckedIndicator INT,
# MAGIC   PharmacistName STRING,
# MAGIC   AmendmentNote STRING,
# MAGIC   PrescriberContactedDate DATE,
# MAGIC   Licence STRING,
# MAGIC   BrokenBulkDate DATE,
# MAGIC   IsShortSupplyIndicator INT,
# MAGIC   IsLimitedLifeIndicator INT,
# MAGIC   IsInstalmentDispenseIndicator INT,
# MAGIC   IsNotCollectedIndicator INT,
# MAGIC   IsMadeToMeasureIndicator INT,
# MAGIC   IsOtherEndorsementIndicator INT,
# MAGIC   BrandOrManufacturer STRING,
# MAGIC   InvoicePricePackQuantity STRING,
# MAGIC   InvoicePriceManufacturer STRING,
# MAGIC   BrokenBulkPackQuantity STRING,
# MAGIC   IsSSPIndicator INT,
# MAGIC   SSPCode STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/AdditionalEndorsement'

# COMMAND ----------



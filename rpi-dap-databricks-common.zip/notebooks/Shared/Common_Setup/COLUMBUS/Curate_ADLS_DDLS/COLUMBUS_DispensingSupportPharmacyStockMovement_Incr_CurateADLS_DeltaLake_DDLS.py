# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_DispensingSupportPharmacyStockMovement
# MAGIC (
# MAGIC DispensingSupportPharmacyStockMovementID	INT,
# MAGIC ActualProductPackID	INT,
# MAGIC SourceKey	STRING,
# MAGIC LeftoverQuantityBefore	INT,
# MAGIC LeftoverQuantityAfter	INT,
# MAGIC CarryOverQuantityBefore	INT,
# MAGIC CarryOverQuantityAfter	INT,
# MAGIC AllocatedQuantityBefore	INT,
# MAGIC AllocatedQuantityAfter	INT,
# MAGIC CreationTime	timestamp,
# MAGIC TransactionID	STRING,
# MAGIC OperationType	STRING,
# MAGIC OperationID	STRING,
# MAGIC PIPCode	STRING,
# MAGIC DispensingSupportPharmacyCode	STRING,
# MAGIC RunDateTime	timestamp,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC RecordStatusFlag	 STRING,
# MAGIC CreatedTime 	timestamp,
# MAGIC UpdatedTime	timestamp,
# MAGIC LOVRecordSourceID	INT,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/DispensingSupportPharmacyStockMovement"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PatientOptedInOut
# MAGIC (
# MAGIC PatientOptedInOutSKID    numeric(19, 0)    NOT NULL ,
# MAGIC PatientPartyRoleID       bigint            NOT NULL,
# MAGIC SourceKey                string      ,
# MAGIC OptedInIndicator         string           ,
# MAGIC CreationDateTime         timestamp          ,
# MAGIC LOVRecordSourceID        int               ,
# MAGIC RecordStatusFlag         string      ,
# MAGIC RunDateTime              timestamp          ,
# MAGIC SCDStartDate             timestamp          ,
# MAGIC SCDEndDate               timestamp          ,
# MAGIC SCDActiveFlag            string        ,
# MAGIC SCDVersion               int               ,
# MAGIC ETLRunLogID              int               
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PatientOptedInOut";
# MAGIC
# MAGIC --drop table COLUMBUS_CURATION.CurateADLS_PatientOptedInOut
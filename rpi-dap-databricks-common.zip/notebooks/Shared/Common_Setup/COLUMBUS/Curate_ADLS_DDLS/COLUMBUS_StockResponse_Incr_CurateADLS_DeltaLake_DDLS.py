# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_StockResponse
# MAGIC (
# MAGIC StockResponseSKID	INT,
# MAGIC SourceKey	STRING,
# MAGIC PSTMessage	STRING,
# MAGIC StockEnquiryMessage	STRING,
# MAGIC StockUserMessage	STRING,
# MAGIC StockFlag	STRING,
# MAGIC RunDateTime	timestamp,
# MAGIC Year 	STRING,
# MAGIC Month 	STRING,
# MAGIC Day 	STRING,
# MAGIC RecordStatusFlag	 STRING,
# MAGIC CreatedTime 	timestamp,
# MAGIC UpdatedTime	timestamp,
# MAGIC LOVRecordSourceID	INT,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/StockResponse"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
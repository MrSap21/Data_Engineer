# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Patient
# MAGIC (
# MAGIC PatientPartyRoleID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   Alias STRING,
# MAGIC   BirthDate DATE,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   ExemptionDate DATE,
# MAGIC   FirstName STRING,
# MAGIC   FullName STRING,
# MAGIC   Gender STRING,
# MAGIC   LastName STRING,
# MAGIC   NationalCode STRING,
# MAGIC   IsNoFixedAddressIndicator INT,
# MAGIC   PostalCode STRING,
# MAGIC   PracticeCode STRING,
# MAGIC   PracticeContext STRING,
# MAGIC   PrescriberCode STRING,
# MAGIC   PrescriberContext STRING,
# MAGIC   PatientStatus STRING,
# MAGIC   PatientTitle STRING,
# MAGIC   PatientType STRING,
# MAGIC   ExemptionID BIGINT,
# MAGIC   SourcePatientID STRING,
# MAGIC   UpdateTime TIMESTAMP,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   IsEMarOptOutIndicator INT,
# MAGIC   SendingEMarTime TIMESTAMP,
# MAGIC   SynchronizedTime TIMESTAMP,
# MAGIC   IsVisuallyImpairedIndicator INT,
# MAGIC   IsNationalCodeRetrievedIndicator INT,
# MAGIC   LastMURDate DATE,
# MAGIC   IsExemptionEvidenceSeenIndicator INT,
# MAGIC   ExemptionExpiryDate DATE,
# MAGIC   LastDurDate TIMESTAMP,
# MAGIC   SerialChangeNumber STRING,
# MAGIC   NormalizedFirstname STRING,
# MAGIC   NormalizedSurname STRING,
# MAGIC   MergedInto STRING,
# MAGIC   MergedDate DATE,
# MAGIC   IsPrescriberLockIndicator INT,
# MAGIC   IsExcludeDspIndicator INT,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   SCDStartDate TIMESTAMP,
# MAGIC   SCDEndDate TIMESTAMP,
# MAGIC   SCDActiveFlag STRING,
# MAGIC   SCDVersion SMALLINT,
# MAGIC   SCDLOVRecordSourceID INT,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Patient"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------



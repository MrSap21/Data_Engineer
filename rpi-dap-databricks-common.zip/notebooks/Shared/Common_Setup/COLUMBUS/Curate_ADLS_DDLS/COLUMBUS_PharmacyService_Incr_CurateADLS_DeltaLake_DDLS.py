# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_pharmacyservice (
# MAGIC   PharmacyServiceSKID BIGINT,
# MAGIC   PrescriptionFormID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   PatientPartyRoleID BIGINT,
# MAGIC   PrescriberPartyRoleID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   PrescriptionFormCode STRING,
# MAGIC   StoreCode STRING,
# MAGIC   PatientCode STRING,
# MAGIC   ServiceType STRING,
# MAGIC   ConsultationType STRING,
# MAGIC   PrescriberCode STRING,
# MAGIC   PharmacyServiceStatus STRING,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   UpdateTime TIMESTAMP,
# MAGIC   UserCode STRING,
# MAGIC   PharmacyServiceNote STRING,
# MAGIC   TransmissionID STRING,
# MAGIC   ClinicalServiceCode STRING,
# MAGIC   AtRiskDate TIMESTAMP,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PharmacyService'

# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_electronicprescribeditem (
# MAGIC   ElectronicPrescribedItemSKID BIGINT,
# MAGIC   ElectronicPrescriptionID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   CommonDrugServiceCode STRING,
# MAGIC   Description STRING,
# MAGIC   DosageUnit STRING,
# MAGIC   Quantity STRING,
# MAGIC   UpdateTime TIMESTAMP,
# MAGIC   ClaimStatus STRING,
# MAGIC   DispensingEvent STRING,
# MAGIC   ControlledDrugIndicator STRING,
# MAGIC   ControlledDrugSchedule STRING,
# MAGIC   NHSStatus STRING,
# MAGIC   Duration STRING,
# MAGIC   DurationUOM STRING,
# MAGIC   Frequency STRING,
# MAGIC   DispensingEventNumber BIGINT,
# MAGIC   DosageUnitCommonDrugServiceCode STRING,
# MAGIC   MedicationStartDate DATE,
# MAGIC   CurrentEventNumber BIGINT,
# MAGIC   DosageDirection STRING,
# MAGIC   QuantityDescription STRING,
# MAGIC   AdditionalDirection STRING,
# MAGIC   ItemSequence BIGINT,
# MAGIC   DictionaryVersion STRING,
# MAGIC   DrugDictionary STRING,
# MAGIC   DoseDescription STRING,
# MAGIC   MappingInformation STRING,
# MAGIC   AmendmentReason STRING,
# MAGIC   AmendmentDateTime TIMESTAMP,
# MAGIC   IsNotDispensableIndicator INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/ElectronicPrescribedItem'

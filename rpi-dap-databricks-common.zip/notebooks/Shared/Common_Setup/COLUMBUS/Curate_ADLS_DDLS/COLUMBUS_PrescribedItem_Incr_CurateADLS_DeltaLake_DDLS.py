# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_prescribeditem (
# MAGIC   PrescribedItemSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   PrescriptionFormID BIGINT,
# MAGIC   DosageUnitID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   DosageUnit STRING,
# MAGIC   IsEmergencySuppliedIndicator INT,
# MAGIC   EnteredQuantity STRING,
# MAGIC   ItemNumber BIGINT,
# MAGIC   IsNotDispensedIndicator INT,
# MAGIC   Ordering BIGINT,
# MAGIC   PrescribedItemDate TIMESTAMP,
# MAGIC   IsReconciledIndicator INT,
# MAGIC   Status STRING,
# MAGIC   StoreCode STRING,
# MAGIC   Quantity DECIMAL(15,5),
# MAGIC   StockedTime TIMESTAMP,
# MAGIC   LastUpdatedTime TIMESTAMP,
# MAGIC   ProcessingTime TIMESTAMP,
# MAGIC   IsDosageAmendedIndicator INT,
# MAGIC   ElectronicItemCode STRING,
# MAGIC   IsElectronicIndicator INT,
# MAGIC   PrescribedItemUOM STRING,
# MAGIC   IsTrustedDirectionIndicator INT,
# MAGIC   VisuallyImpairedRefLetter STRING,
# MAGIC   ClaimedTime TIMESTAMP,
# MAGIC   ReconciliationType STRING,
# MAGIC   ExpirationDate DATE,
# MAGIC   DosageDirections STRING,
# MAGIC   DosageDirections2 STRING,
# MAGIC   PriceAmount DECIMAL(24,4),
# MAGIC   PriceISOCode STRING,
# MAGIC   NotDispensedUpdateTime TIMESTAMP,
# MAGIC   NotDispensedReason STRING,
# MAGIC   NotificationTime TIMESTAMP,
# MAGIC   IsExpirationProcessedIndicator INT,
# MAGIC   OriginalQuantity DECIMAL(15,5),
# MAGIC   OriginalDosageUnit STRING,
# MAGIC   IsLevyIndicator INT,
# MAGIC   IsNewItemPMRIndicator INT,
# MAGIC   ItemNote STRING,
# MAGIC   Fulfilled STRING,
# MAGIC   IsOverstockConsumedIndicator INT,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/PrescribedItem'

# COMMAND ----------



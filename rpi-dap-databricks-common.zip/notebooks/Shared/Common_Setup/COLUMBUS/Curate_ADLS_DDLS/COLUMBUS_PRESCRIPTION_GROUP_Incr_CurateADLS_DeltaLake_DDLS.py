# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PrescriptionGroup
# MAGIC (
# MAGIC PrescriptionGroupSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   PatientPartyRoleID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   PatientCode STRING,
# MAGIC   ServiceEntryMode STRING,
# MAGIC   ServiceType STRING,
# MAGIC   SourceGroupID STRING,
# MAGIC   PrescriptionGroupStatus STRING,
# MAGIC   StoreCode STRING,
# MAGIC   UpdateTime TIMESTAMP,
# MAGIC   ProcessingTime TIMESTAMP,
# MAGIC   IsCentralPharmacyIndicator INT,
# MAGIC   IsOrderableIndicator INT,
# MAGIC   Forms BIGINT,
# MAGIC   PrescriptionSourceType STRING,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   DeliveryDate DATE,
# MAGIC   AnimalCode STRING,
# MAGIC   MessageType STRING,
# MAGIC   IsDummyGroupIndicator INT,
# MAGIC   OldPatientCode STRING,
# MAGIC   IsFMDVerifiedIndicator INT,
# MAGIC   PrescriptionSource STRING,
# MAGIC   Fulfilled STRING,
# MAGIC   DSPSendingTime TIMESTAMP,
# MAGIC   RetrievalStatus STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PrescriptionGroup"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

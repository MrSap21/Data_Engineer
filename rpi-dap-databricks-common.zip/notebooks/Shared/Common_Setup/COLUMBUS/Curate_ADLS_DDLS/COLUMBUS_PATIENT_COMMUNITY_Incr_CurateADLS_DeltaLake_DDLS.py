# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PatientCommunity
# MAGIC (
# MAGIC PatientCommunitySKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   IsCareServicePreferenceIndicator INT,
# MAGIC   PatientCommunityName STRING,
# MAGIC   PatientCommunityType STRING,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   IsEMARStatusIndicator INT,
# MAGIC   GoLiveDate DATE,
# MAGIC   SendingEMARTime TIMESTAMP,
# MAGIC   PatientCommunityStatus STRING,
# MAGIC   StoreCode STRING,
# MAGIC   UpdateTime TIMESTAMP,
# MAGIC   UserInitials STRING,
# MAGIC   IsLandscapeFormatIndicator INT,
# MAGIC   SourceCommunityID STRING,
# MAGIC   EMARServiceProvider STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   SCDStartDate TIMESTAMP,
# MAGIC   SCDEndDate TIMESTAMP,
# MAGIC   SCDActiveFlag STRING,
# MAGIC   SCDVersion INT,
# MAGIC   SCDLOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PatientCommunity"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

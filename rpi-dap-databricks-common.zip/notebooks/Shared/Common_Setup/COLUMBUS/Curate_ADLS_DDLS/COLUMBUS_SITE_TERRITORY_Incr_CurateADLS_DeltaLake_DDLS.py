# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.curateadls_SiteTerritory
# MAGIC (
# MAGIC SiteId BIGINT,
# MAGIC LOVSiteTerritorySetId INT,
# MAGIC LOVTerritoryId INT,
# MAGIC LOVRecordSourceId INT,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag STRING,
# MAGIC ETLRunLogId INT,
# MAGIC PSARowKey BIGINT,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/SiteTerritory"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
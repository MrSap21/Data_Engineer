# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_advanceshipmentnoticelinesupplied (
# MAGIC   AdvanceShipmentNoticeLineSuppliedSKID BIGINT,
# MAGIC   AdvanceShipmentNoticeLineOrderedID BIGINT,
# MAGIC   ToteID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   AdvanceShipmentNoticeSuppliedNote STRING,
# MAGIC   NetCostAmount DECIMAL(24,4),
# MAGIC   NetCostISOCode STRING,
# MAGIC   NetCostExcrateID BIGINT,
# MAGIC   PackagingInfo STRING,
# MAGIC   PackSize INT,
# MAGIC   PIPCode STRING,
# MAGIC   Quantity INT,
# MAGIC   AdvanceShipmentNoticeLineSuppliedReason STRING,
# MAGIC   ToteCode STRING,
# MAGIC   ValueAddedTaxRate INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogId INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/AdvanceShipmentNoticeLineSupplied'

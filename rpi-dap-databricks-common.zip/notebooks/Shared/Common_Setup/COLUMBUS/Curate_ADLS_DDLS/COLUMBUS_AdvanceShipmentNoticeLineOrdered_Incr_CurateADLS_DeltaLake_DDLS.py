# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_AdvanceShipmentNoticeLineOrdered
# MAGIC (
# MAGIC AdvanceShipmentNoticeLineorderedSKID	INT,
# MAGIC AdvanceShipmentNoticeLineID	INT,
# MAGIC SourceKey	STRING,
# MAGIC SourceSystemID	INT,
# MAGIC PackSize	INT,
# MAGIC PIPCode	STRING,
# MAGIC Quantity	INT,
# MAGIC RunDateTime	TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC RecordStatusFlag	 STRING,
# MAGIC CreatedTime 	TIMESTAMP,
# MAGIC UpdatedTime	TIMESTAMP,
# MAGIC LOVRecordSourceID	INT,
# MAGIC ETLRunLogId	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/AdvanceShipmentNoticeLineOrdered"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
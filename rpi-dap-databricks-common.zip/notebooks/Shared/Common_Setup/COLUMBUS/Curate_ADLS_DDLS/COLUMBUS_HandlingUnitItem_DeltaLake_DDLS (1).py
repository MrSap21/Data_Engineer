# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_HandlingUnitItem
# MAGIC (
# MAGIC HandlingUnitItemSKID INT,
# MAGIC HandlingUnitID INT,
# MAGIC PharmacyProductSKUID INT,
# MAGIC OrderStatusUpdateLineSuppliedID INT,
# MAGIC PurchaseOrderLineID INT,
# MAGIC SourceKey STRING,
# MAGIC ClosingTime TIMESTAMP,
# MAGIC ExpectedQuantity INT,
# MAGIC LineNumber INT,
# MAGIC OriginalExpectedQuantity INT,
# MAGIC OrderStatusUpdateLineSuppliedCode STRING,
# MAGIC DispensingPrescribableProductCode STRING,
# MAGIC ReceivedQuantity INT,
# MAGIC CreationTime TIMESTAMP,
# MAGIC HandlingUnitItemStatus STRING,
# MAGIC IsScannedIndicator INT,
# MAGIC IsLapsedIndicator INT,
# MAGIC PurchaseOrderReference STRING,
# MAGIC PurchaseOrderLineNumber INT,
# MAGIC PurchaseOrderCreationTime TIMESTAMP,
# MAGIC ServiceType STRING,
# MAGIC IsExternalSourceOrderIndicator INT,
# MAGIC ServiceEntryMode STRING,
# MAGIC OldReceivedQuantity INT,
# MAGIC PIPCode STRING,
# MAGIC CommonDrugServiceCode STRING,
# MAGIC PackSize DECIMAL(15,5),
# MAGIC ProductBarCode STRING,
# MAGIC ProductDescription STRING,
# MAGIC ProductSKUCode STRING,
# MAGIC ReceivingQuantity INT,
# MAGIC IsTelesaleOrderIndicator INT,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/HandlingUnitItem"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
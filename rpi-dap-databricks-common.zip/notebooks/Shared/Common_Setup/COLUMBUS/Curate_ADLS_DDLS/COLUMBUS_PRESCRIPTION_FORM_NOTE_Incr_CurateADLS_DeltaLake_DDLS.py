# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PrescriptionFormNote
# MAGIC (
# MAGIC PrescriptionFormNoteSKID BIGINT,
# MAGIC   PrescriptionFormID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   CreationDate TIMESTAMP,
# MAGIC   Note STRING,
# MAGIC   PriceAmount DECIMAL(24,4),
# MAGIC   PriceISOCode STRING,
# MAGIC   PrescriptionFormNoteStatus STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PrescriptionFormNote"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------



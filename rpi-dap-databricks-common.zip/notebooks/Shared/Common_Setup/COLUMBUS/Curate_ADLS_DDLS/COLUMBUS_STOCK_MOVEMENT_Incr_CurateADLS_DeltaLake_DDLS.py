# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_StockMovement
# MAGIC (
# MAGIC StockMovementSKID BIGINT,
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   ActualProductPackSKID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   CreationTime TIMESTAMP,
# MAGIC   EntityType STRING,
# MAGIC   StockAdjustmentID BIGINT,
# MAGIC   StockAdjustmentItemID BIGINT,
# MAGIC   PrescriptionFormID BIGINT,
# MAGIC   PrescribedItemID BIGINT,
# MAGIC   DispensedItemID BIGINT,
# MAGIC   CountListID BIGINT,
# MAGIC   CountListItemID BIGINT,
# MAGIC   NextDeliveryDate TIMESTAMP,
# MAGIC   Operation STRING,
# MAGIC   Process STRING,
# MAGIC   ProcessingTime TIMESTAMP,
# MAGIC   ProductCode STRING,
# MAGIC   ProductSKUCode STRING,
# MAGIC   Reason STRING,
# MAGIC   StockedTime TIMESTAMP,
# MAGIC   StoreCode STRING,
# MAGIC   UserName STRING,
# MAGIC   ServiceEntryMode STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT 
# MAGIC
# MAGIC
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/StockMovement"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

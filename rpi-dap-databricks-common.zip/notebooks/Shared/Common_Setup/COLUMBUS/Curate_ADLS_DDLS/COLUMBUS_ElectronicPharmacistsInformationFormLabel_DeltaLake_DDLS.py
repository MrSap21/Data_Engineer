# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_ElectronicPharmacistsInformationFormLabel
# MAGIC (
# MAGIC ElectronicPharmacistsInformationFormLabelSKID	INT,
# MAGIC PrescriptionGroupID	INT,
# MAGIC PharmacyStoreSiteRoleId	INT,
# MAGIC SourceKey	STRING,
# MAGIC PrescriptionGroupCode	STRING,
# MAGIC StoreCode	STRING,
# MAGIC Label	STRING,
# MAGIC CreationTime	TIMESTAMP ,
# MAGIC UpdateTime	TIMESTAMP ,
# MAGIC IsNewMedicineServiceVerifiedIndicator	INT,
# MAGIC RunDateTime  TIMESTAMP ,
# MAGIC Year STRING  ,
# MAGIC Month STRING ,
# MAGIC Day STRING  ,
# MAGIC RecordStatusFlag  STRING,
# MAGIC CreatedTime TIMESTAMP,
# MAGIC UpdatedTime TIMESTAMP,
# MAGIC LOVRecordSourceID  INT  NOT NULL,
# MAGIC ETLRunLogID  INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/ElectronicPharmacistsInformationFormLabel"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


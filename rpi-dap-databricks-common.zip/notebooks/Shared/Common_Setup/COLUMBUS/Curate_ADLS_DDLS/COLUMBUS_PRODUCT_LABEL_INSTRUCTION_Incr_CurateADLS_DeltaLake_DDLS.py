# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_ProductLabelInstruction
# MAGIC (
# MAGIC ProductLabelInstructionSKID	INT,
# MAGIC PharmacyProductID	INT,
# MAGIC LabelInstructionID	INT,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC LOVRecordSourceId INT,
# MAGIC ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/ProductLabelInstruction"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
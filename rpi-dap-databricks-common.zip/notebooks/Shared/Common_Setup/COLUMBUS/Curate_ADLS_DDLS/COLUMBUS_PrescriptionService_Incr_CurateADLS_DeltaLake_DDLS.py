# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PrescriptionService
# MAGIC (
# MAGIC PrescriptionServiceSKID	INT,
# MAGIC SourceKey	STRING,
# MAGIC PrescriptionServiceType	STRING,
# MAGIC PrescriptionServiceDescription	STRING,
# MAGIC RunDateTime	timestamp,
# MAGIC Year 	STRING,
# MAGIC Month 	STRING,
# MAGIC Day 	STRING,
# MAGIC RecordStatusFlag	 STRING,
# MAGIC CreatedTime 	timestamp,
# MAGIC UpdatedTime	timestamp,
# MAGIC LOVRecordSourceID	INT,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PrescriptionService"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
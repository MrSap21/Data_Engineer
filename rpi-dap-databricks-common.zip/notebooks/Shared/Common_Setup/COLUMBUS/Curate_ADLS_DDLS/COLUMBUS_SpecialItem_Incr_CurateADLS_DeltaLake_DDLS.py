# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_SpecialItem
# MAGIC (
# MAGIC SpecialItemSKID INT,
# MAGIC AdditionalEndorsementID INT,
# MAGIC SourceKey STRING,
# MAGIC SpecialItemPriceAmount DECIMAL(24,4),
# MAGIC SpecialItemPriceISOCode STRING,
# MAGIC SpecialManufacturer STRING,
# MAGIC SpecialPackQuantity STRING,
# MAGIC RunDateTime TIMESTAMP,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC RecordStatusFlag STRING,
# MAGIC LOVRecordSourceID INT,
# MAGIC ETLRunLogID INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/SpecialItem"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


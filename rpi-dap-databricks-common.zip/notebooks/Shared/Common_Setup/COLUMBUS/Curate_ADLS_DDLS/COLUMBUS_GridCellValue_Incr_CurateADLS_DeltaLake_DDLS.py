# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_GridCellValue
# MAGIC (
# MAGIC GridCellValueSKID	int,
# MAGIC SourceKey	String,
# MAGIC DaysStockCoverNumber	decimal(15,5),
# MAGIC IsStockCoverIndicator	int,
# MAGIC RangingValue	String,
# MAGIC IsAverageDaysIndicator	int,
# MAGIC AverageDaysNumber	decimal(15,5),
# MAGIC MaxDaily	String,
# MAGIC OccurencesNumber	int,
# MAGIC IsStockedIndicator	int,
# MAGIC IsUpliftIndicator	int,
# MAGIC GridType	String,
# MAGIC MinLevelSetting	String,
# MAGIC RunDateTime	timestamp,
# MAGIC Year String,
# MAGIC Month String,
# MAGIC Day String,
# MAGIC LOVRecordSourceID	INT,
# MAGIC GridCellValueDate	timestamp,
# MAGIC GridCellValueTimestamp	timestamp,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime 	timestamp,
# MAGIC UpdatedTime	timestamp,
# MAGIC ActiveFlag	String,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/GridCellValue"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


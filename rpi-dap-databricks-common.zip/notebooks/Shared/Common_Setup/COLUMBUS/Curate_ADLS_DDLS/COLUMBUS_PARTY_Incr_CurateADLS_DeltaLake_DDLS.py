# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Party
# MAGIC (
# MAGIC PartyId BIGINT,
# MAGIC LOVPartyTypeId INT,
# MAGIC SourceKey STRING,
# MAGIC LOVRecordSourceId INT,
# MAGIC
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC ETLRunLogID INT,
# MAGIC PSARowKey BIGINT,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp, 
# MAGIC RecordStatusFlag string
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Party"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------


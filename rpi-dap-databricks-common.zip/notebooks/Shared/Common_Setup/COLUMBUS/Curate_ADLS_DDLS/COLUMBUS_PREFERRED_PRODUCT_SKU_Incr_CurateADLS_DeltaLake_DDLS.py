# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_PreferredProductSKU
# MAGIC (
# MAGIC PreferredProductSKUSKID BIGINT,
# MAGIC   PharmacyProductSKUID BIGINT,
# MAGIC   PharmacyProductID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   Region STRING,
# MAGIC   PreferredType STRING,
# MAGIC   StartDate TIMESTAMP,
# MAGIC   EndDate TIMESTAMP,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/PreferredProductSKU"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

# COMMAND ----------



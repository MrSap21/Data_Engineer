# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS columbus_curation.curateadls_storeservicecentre (
# MAGIC   StoreServiceCentreSKID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   ServiceCentreSiteRoleID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   Type STRING,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   RecordStatusFlag STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceId, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/StoreServiceCentre'

# COMMAND ----------



# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_GridLayer
# MAGIC (
# MAGIC GridLayerSKID	INT,
# MAGIC GridID	INT,
# MAGIC SourceKey	STRING,
# MAGIC SourceSystemID	INT,
# MAGIC GridType	STRING,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC LOVRecordSourceId INT,
# MAGIC GridLayerDate	timestamp,
# MAGIC GridLayerTimestamp	timestamp,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC ActiveFlag	STRING,
# MAGIC ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/GridLayer"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
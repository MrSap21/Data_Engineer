# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Prescriber
# MAGIC (
# MAGIC PrescriberPartyRoleID BIGINT,
# MAGIC   PharmacyStoreSiteRoleId BIGINT,
# MAGIC   PrescriberTypeID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   PrescriberContext STRING,
# MAGIC   PrescriberFirstName STRING,
# MAGIC   PrescriberFullName STRING,
# MAGIC   MedicalCouncilCode STRING,
# MAGIC   NationalCode STRING,
# MAGIC   NormalizedName STRING,
# MAGIC   PrescriberPrivateControlledDrugCode STRING,
# MAGIC   ReimbursementCode STRING,
# MAGIC   PrescriberStatus STRING,
# MAGIC   StoreCode STRING,
# MAGIC   PrescriberSurname STRING,
# MAGIC   PrescriberTitle STRING,
# MAGIC   GMCCode STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceId INT,
# MAGIC   ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Prescriber"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);

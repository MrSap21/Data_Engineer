# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_UnsuppliedPurchaseOrderLine
# MAGIC (
# MAGIC UnsuppliedPurchaseOrderLineSKID	INT,
# MAGIC PharmacyStoreSiteRoleId	BIGINT,
# MAGIC PharmacyProductSKUID	INT,
# MAGIC SourceKey	STRING,
# MAGIC IsUrgentIndicator	INT,
# MAGIC StoreCode	STRING,
# MAGIC ProductSKUCode	STRING,
# MAGIC UnsuppliedPOLStatus	STRING,
# MAGIC CreationTime timestamp,
# MAGIC ProcessingTime timestamp,
# MAGIC RecordStatusFlag string,
# MAGIC createdtime timestamp,
# MAGIC updatedtime timestamp,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC LOVRecordSourceId INT,
# MAGIC ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/UnsuppliedPurchaseOrderLine"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
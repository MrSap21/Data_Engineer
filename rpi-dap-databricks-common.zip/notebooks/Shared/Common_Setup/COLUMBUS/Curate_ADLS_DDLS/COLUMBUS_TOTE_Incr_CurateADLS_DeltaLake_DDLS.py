# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_Tote
# MAGIC (
# MAGIC ToteSKID	INT,
# MAGIC ServiceCentreSiteRoleID	BIGINT,
# MAGIC SourceKey	STRING,
# MAGIC ToteCode	STRING,
# MAGIC PhysicalTote	STRING,
# MAGIC SheetNumber	INT,
# MAGIC ToteCreationDate	DATE,
# MAGIC ToteType	STRING,
# MAGIC IsLogicalToteIndicator	INT,
# MAGIC Priority	STRING,
# MAGIC ServiceCentreWholesalerCode	STRING,
# MAGIC OrderCreationDate	timestamp,
# MAGIC TotalAdvanceShipmentNoticeExpected	INT,
# MAGIC TotalAdvanceShipmentNoticeReceived	INT,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING,
# MAGIC RecordStatusFlag string,
# MAGIC CreatedTime timestamp,
# MAGIC UpdatedTime timestamp,
# MAGIC LOVRecordSourceId INT,
# MAGIC ETLRunLogId INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/Tote"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
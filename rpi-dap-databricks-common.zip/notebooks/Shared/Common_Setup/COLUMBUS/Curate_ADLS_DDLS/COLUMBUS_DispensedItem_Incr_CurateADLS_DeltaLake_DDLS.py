# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE columbus_curation.curateadls_dispenseditem (
# MAGIC   DispensedItemSKID BIGINT,
# MAGIC   OwingID BIGINT,
# MAGIC   PrescribedItemID BIGINT,
# MAGIC   SourceKey STRING,
# MAGIC   AutomationStatus STRING,
# MAGIC   SourceSystemID BIGINT,
# MAGIC   DispensedDate TIMESTAMP,
# MAGIC   ItemNumber BIGINT,
# MAGIC   Quantity DECIMAL(15,5),
# MAGIC   Sequence BIGINT,
# MAGIC   IsPatientPreferenceIndicator DECIMAL(1,0),
# MAGIC   ReasonForSupply STRING,
# MAGIC   ReasonManualConfirmation STRING,
# MAGIC   ReplacedDispensedCode STRING,
# MAGIC   ReplacedUser STRING,
# MAGIC   ScannedQuantity DECIMAL(15,5),
# MAGIC   ScanStatus STRING,
# MAGIC   DosageUnit STRING,
# MAGIC   DispensedQuantity DECIMAL(15,5),
# MAGIC   IsSKUOverStockedIndicator DECIMAL(1,0),
# MAGIC   ExpirationDate DATE,
# MAGIC   QuantityNotified DECIMAL(15,5),
# MAGIC   NotificationTime TIMESTAMP,
# MAGIC   Orderable STRING,
# MAGIC   IsAdditionalEndorsementIndicator DECIMAL(1,0),
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING,
# MAGIC   RecordStatusFlag STRING,
# MAGIC   CreatedTime TIMESTAMP,
# MAGIC   UpdatedTime TIMESTAMP,
# MAGIC   LOVRecordSourceID INT,
# MAGIC   ETLRunLogID INT)
# MAGIC USING delta
# MAGIC PARTITIONED BY (LOVRecordSourceID, Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-curate/Pharmaceuticals/DispensedItem'

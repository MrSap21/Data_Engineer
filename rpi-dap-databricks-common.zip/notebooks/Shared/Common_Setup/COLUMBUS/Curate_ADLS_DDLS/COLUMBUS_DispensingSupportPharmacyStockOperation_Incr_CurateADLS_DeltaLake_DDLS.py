# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS COLUMBUS_CURATION;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS COLUMBUS_CURATION.CurateADLS_DispensingSupportPharmacyStockOperation
# MAGIC (
# MAGIC DispensingSupportPharmacyStockOperationID	INT,
# MAGIC ActualProductPackID	INT,
# MAGIC SourceKey	STRING,
# MAGIC CreationTime	timestamp,
# MAGIC UserCode	STRING,
# MAGIC UpdateTime	timestamp,
# MAGIC DispensingSupportPharmacyStockOperationStatus	STRING,
# MAGIC DispensingSupportPharmacyCode	STRING,
# MAGIC PIPCode	STRING,
# MAGIC DispensingSupportPharmacyStockOperationType	STRING,
# MAGIC Quantity	INT,
# MAGIC LocationCode	STRING,
# MAGIC OperationalTime	timestamp,
# MAGIC EntryType	STRING,
# MAGIC SourceType	STRING,
# MAGIC ReasonDescription	STRING,
# MAGIC RunDateTime	timestamp,
# MAGIC Year STRING,
# MAGIC Month STRING,
# MAGIC Day STRING,
# MAGIC RecordStatusFlag STRING,
# MAGIC CreatedTime 	timestamp,
# MAGIC UpdatedTime	timestamp,
# MAGIC LOVRecordSourceID	INT,
# MAGIC ETLRunLogID	INT
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Pharmaceuticals/DispensingSupportPharmacyStockOperation"
# MAGIC PARTITIONED BY(LOVRecordSourceId,Year,Month,Day);
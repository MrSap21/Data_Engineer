# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS exception_handling;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE spark_catalog.exception_handling.curatestandard_formulary_product_backup (
# MAGIC   ID_PRODUCT BIGINT,
# MAGIC   ID STRING,
# MAGIC   FORMULARY_CODE STRING,
# MAGIC   MESSAGE_OPERATION STRING,
# MAGIC   MESSAGE_SEQUENCE STRING,
# MAGIC   EXTRACTION_TIME TIMESTAMP,
# MAGIC   ETLRunLogId INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING)
# MAGIC USING delta
# MAGIC PARTITIONED BY (Year, Month, Day)
# MAGIC LOCATION 'dbfs:/mnt/idf-reports/Exception_Handling/BUKIT/BTCCLMBSMDM/BootsUK_FORMULARY_PRODUCT_BTCCLMBSMDM_Incr'

# COMMAND ----------



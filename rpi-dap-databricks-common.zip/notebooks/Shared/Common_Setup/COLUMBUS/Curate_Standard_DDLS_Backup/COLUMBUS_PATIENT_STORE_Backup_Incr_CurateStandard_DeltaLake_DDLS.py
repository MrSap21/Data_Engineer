# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS exception_handling;

# COMMAND ----------

# MAGIC %sql drop table exception_handling.CurateStandard_Patient_Store_Backup

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS exception_handling.CurateStandard_Patient_Store_Backup
# MAGIC (
# MAGIC ID BIGINT,
# MAGIC   MESSAGE_OPERATION STRING,
# MAGIC   MESSAGE_SEQUENCE STRING,
# MAGIC   LAST_VISITED_DATE TIMESTAMP,
# MAGIC   STORE_CODE STRING,
# MAGIC   ID_PATIENT BIGINT,
# MAGIC   EXTRACTION_TIME TIMESTAMP,
# MAGIC   ETLRunLogId INT,
# MAGIC   PSARowKey INT,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING
# MAGIC
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-reports/Exception_Handling/BUKIT/BTCCLMBSPMS/BootsUK_PATIENT_STORE_BTCCLMBSPMS_Incr"
# MAGIC PARTITIONED BY(Year,Month,Day);

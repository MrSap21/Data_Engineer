# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS exception_handling;

# COMMAND ----------

# MAGIC %sql drop table exception_handling.CurateStandard_SUPPLIER_Backup

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS exception_handling.CurateStandard_SUPPLIER_Backup
# MAGIC (
# MAGIC CODE STRING,
# MAGIC NAME STRING,
# MAGIC STATUS STRING,
# MAGIC THIRD_PARTY STRING,
# MAGIC MESSAGE_OPERATION STRING,
# MAGIC MESSAGE_SEQUENCE STRING,
# MAGIC EXTRACTION_TIME timestamp, 
# MAGIC ETLRunLogId INT ,
# MAGIC RunDateTime timestamp,
# MAGIC Year STRING, 
# MAGIC Month STRING, 
# MAGIC Day STRING
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-reports/Exception_Handling/BUKIT/BTCCLMBSMDM/BootsUK_SUPPLIER_BTCCLMBSMDM_Incr/"
# MAGIC PARTITIONED BY(Year,Month,Day);

# COMMAND ----------


# Databricks notebook source
##### COBA-121552
##### TENDULKAR, USAIN, VEZZALI TRAIN
##### 

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_DAILY_PRODUCT_CLASS','Fact','FACT_DAILY_PRODUCT_CLASS','R5D00505'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_RTEC_PRESCRIPTION','Fact','FACT_RTEC_PRESCRIPTION','R5WM0510'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_WEEKLY_PRODUCT_CLASS','Fact','FACT_WEEKLY_PRODUCT_CLASS','R5WM0510'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_MONTHLY_PRODUCT_CLASS','Fact','FACT_MONTHLY_PRODUCT_CLASS','R5M10515'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_DUE_NOW_WAIT','Fact','FACT_DUE_NOW_WAIT','R5WM0510'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_DUE_DATE_WAIT','Fact','FACT_DUE_DATE_WAIT','R5WM0510'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_ORDERS','Fact','FACT_ORDERS','R5D00505'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

# COMMAND ----------

#### USAIN

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_STOCK_MOVEMENTS','Fact','FACT_STOCK_MOVEMENTS','R5D00505'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_DSP_PRESCRIPTION','Fact','FACT_DSP_PRESCRIPTION','R5D00505'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

# COMMAND ----------

#### VEZZALI

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into RPI_Consumption_DB.Metadata_Consumption  
# MAGIC select max(unique_id)+1 
# MAGIC ,'NA','NA','NA','csv','True','NA','NA','|','NA','NA','NA','/Shared/Consumption/Columbus/Incremental/FACT_2DRX_ERD_PRESCRIPTION','Fact','FACT_2DRX_ERD_PRESCRIPTION','R5WM0510'
# MAGIC from RPI_Consumption_DB.Metadata_Consumption;

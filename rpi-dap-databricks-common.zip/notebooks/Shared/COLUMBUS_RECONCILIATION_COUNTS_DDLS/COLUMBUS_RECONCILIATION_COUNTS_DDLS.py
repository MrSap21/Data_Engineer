# Databricks notebook source
# MAGIC %sql
# MAGIC create Database if not exists rpi_reference_db;

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists rpi_reference_db.Curation_Columbus_ReconciliationCounts(ReconExecutionDate timestamp,LevelName string, TopicName string,TableName string,countQueryOutput Bigint,DupcountQueryOutput Bigint,Yearvalue string,MonthValue string,DayValue string)
# MAGIC using delta 
# MAGIC partitioned by (LevelName,ReconExecutionDate)
# MAGIC location '/mnt/idf-reports/RPI_Reference/Curation/Curation_Columbus_ReconciliationCounts';
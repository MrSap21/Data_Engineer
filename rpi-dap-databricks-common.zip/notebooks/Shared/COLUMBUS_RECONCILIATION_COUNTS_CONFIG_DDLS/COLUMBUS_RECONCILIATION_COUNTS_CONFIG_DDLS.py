# Databricks notebook source
# MAGIC %sql
# MAGIC create Database if not exists rpi_reference_db;

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists rpi_reference_db.Curation_Columbus_ReconciliationCounts_config (LevelName string, TopicName string,TableName string,countQuery String,DupcountQuery String,Statusflag string)
# MAGIC using delta 
# MAGIC partitioned by (LevelName,TopicName)
# MAGIC location '/mnt/idf-reports/RPI_Reference/Curation/Curation_Columbus_ReconciliationCounts_config';
# Databricks notebook source
# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_EYE_CHECKUP_DETAILS_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC ID  string,
# MAGIC CODE  string,
# MAGIC SERVICE_GROUP_CODE  string,
# MAGIC DATE_TIME  string,
# MAGIC LAST_UPDATE  string,
# MAGIC DURATION  string,
# MAGIC STATUS  string, 
# MAGIC PATH_STATUS  string, 
# MAGIC SERVICE_TYPE  string, 
# MAGIC START_TIME  string,
# MAGIC END_TIME  string, 
# MAGIC DELETED  string, 
# MAGIC CREATED_BY  string,
# MAGIC UPDATED_BY  string,
# MAGIC OPERATION  string,
# MAGIC TIMESTAMP  string,
# MAGIC TRANSACTIONID string,
# MAGIC RunDateTime    timestamp    ,
# MAGIC Year    string    ,
# MAGIC Month    string    ,
# MAGIC Day    string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PRACTICE_OPS_USER_DETAILS_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC ID   string,CITY   string,DE_ACTIVED   string,EMPLOYEE_ID   string,EXPIRATION_DATE   string,FIRST_NAME   string,HOME_COMPANY   string,HOME_SITE   string,ID_CONTACT   string,LAST_ACCESS_DATE   string,LOCALE   string,LOGON_UNSUCCESSFULL_COUNTER   string,NAMED_USER   string,PASSWORD   string,PASSWORD_CHANGE_INDICATOR   string,PHARMACIST_ID   string,PROVINCE   string,PWD_LAST_CHG_DATE   string,SURNAME   string,USER_NAME   string,VALIDITY_END   string,VALIDITY_START   string,DELETED   string,INSTANCE_KEY   string,REFERENCE_CODE   string,CURRENT_STATE   string,COMPANY   string,EMAIL   string,UPN   string,SID   string,DISABLED   string,USER_TYPE   string,GOC_NUMBER   string,GOC_EXPIRATION_DATE   string,QNOMY_PROFILE_CHANGE_DATE   string,QNOMY_PROFILE   string,EXPORT_QNOMY_PROFILE   string,LAST_ACTIVE_QNOMY_PROFILE   string,CREATION_DATETIME   string,LASTUPDATE_DATETIME   string,USER_ID   string,OPERATION   string,TIMESTAMP   string,TRANSACTIONID string,
# MAGIC RunDateTime    timestamp    ,
# MAGIC Year    string    ,
# MAGIC Month    string    ,
# MAGIC Day    string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_VENDOR_DETAILS_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC C_BPARTNER_ID  string,AD_CLIENT_ID  string,AD_ORG_ID  string,ISACTIVE  string,CREATED  string,CREATEDBY  string,UPDATED  string,UPDATEDBY  string,VALUE  string,NAME  string,NAME2  string,DESCRIPTION  string,ISSUMMARY  string,C_BP_GROUP_ID  string,ISONETIME  string,ISPROSPECT  string,ISVENDOR  string,ISCUSTOMER  string,ISEMPLOYEE  string,ISSALESREP  string,REFERENCENO  string,DUNS  string,URL  string,AD_LANGUAGE  string,TAXID  string,ISTAXEXEMPT  string,C_INVOICESCHEDULE_ID  string,RATING  string,SALESVOLUME  string,NUMBEREMPLOYEES  string,NAICS  string,FIRSTSALE  string,ACQUSITIONCOST  string,POTENTIALLIFETIMEVALUE  string,ACTUALLIFETIMEVALUE  string,SHAREOFCUSTOMER  string,PAYMENTRULE  string,SO_CREDITLIMIT  string,SO_CREDITUSED  string,C_PAYMENTTERM_ID  string,M_PRICELIST_ID  string,ISDISCOUNTPRINTED  string,SO_DESCRIPTION  string,POREFERENCE  string,PAYMENTRULEPO  string,PO_PRICELIST_ID  string,PO_PAYMENTTERM_ID  string,DOCUMENTCOPIES  string,C_GREETING_ID  string,INVOICERULE  string,DELIVERYRULE  string,DELIVERYVIARULE  string,SALESREP_ID  string,BPARTNER_PARENT_ID  string,SOCREDITSTATUS  string,AD_FORCED_ORG_ID  string,SHOWPRICEINORDER  string,INVOICEGROUPING  string,FIXMONTHDAY  string,FIXMONTHDAY2  string,FIXMONTHDAY3  string,ISWORKER  string,UPC  string,C_SALARY_CATEGORY_ID  string,INVOICE_PRINTFORMAT  string,LAST_DAYS  string,PO_BANKACCOUNT_ID  string,PO_BP_TAXCATEGORY_ID  string,PO_FIXMONTHDAY  string,PO_FIXMONTHDAY2  string,PO_FIXMONTHDAY3  string,SO_BANKACCOUNT_ID  string,SO_BP_TAXCATEGORY_ID  string,FISCALCODE  string,ISOFISCALCODE  string,PO_C_INCOTERMS_ID  string,SO_C_INCOTERMS_ID  string,FIN_PAYMENTMETHOD_ID  string,PO_PAYMENTMETHOD_ID  string,FIN_FINANCIAL_ACCOUNT_ID  string,PO_FINANCIAL_ACCOUNT_ID  string,CUSTOMER_BLOCKING  string,VENDOR_BLOCKING  string,SO_PAYMENT_BLOCKING  string,PO_PAYMENT_BLOCKING  string,SO_INVOICE_BLOCKING  string,PO_INVOICE_BLOCKING  string,SO_ORDER_BLOCKING  string,PO_ORDER_BLOCKING  string,SO_GOODS_BLOCKING  string,PO_GOODS_BLOCKING  string,ISCASHVAT  string,UPDATE_CURRENCY  string,BP_CURRENCY_ID  string,EM_HORCUS_NHS  string,EM_HORCUS_CLRS  string,EM_HORCUS_OPENBASKET  string,EM_HORCUS_CLCP_EXPIRE_DATE  string,EM_HORCUS_SYNC_CLCP_EXP_DATE  string,EM_HORCUS_CLCP  string,EM_HORCUS_EMPLOYEECARD  string,EM_HORCUS_DOB  string,EM_HORCUS_GENDER  string,EM_HORCUS_EMPLOYEECARDNUMBER  string,EM_HORCUS_CARDISVALID  string,EM_HORCUS_TITLE  string,EM_HORCUS_TRD_PRT_LNS_SPPLMNT  string,EM_HORCUS_IS_SPPLR  string,EM_HORCUS_DEFAULTVENDOR  string,EM_HORCUS_PS_TRMNL_WNR_BSKT  string,EM_HORCUS_ADCARD  string,OPERATION  string,TIMESTAMP  string,TRANSACTIONID string,
# MAGIC RunDateTime    timestamp    ,
# MAGIC Year    string    ,
# MAGIC Month    string    ,
# MAGIC Day    string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_BASKET_LEVEL_INFO_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC HORCUS_ORDERLINE_ID  string,C_ORDERLINE_ID  string,M_PRODUCT_ID  string,AD_CLIENT_ID  string,AD_ORG_ID  string,ISACTIVE  string,CREATED  string,CREATEDBY  string,UPDATED  string,UPDATEDBY  string,HORCUS_PRICE  string,HORCUS_TOTALPOINTS  string,HORCUS_QUANTITY  string,DISCOUNT  string,HORCUS_ISLEFT  string,HORCUS_PRODUCTTYPE  string,HORCUS_TINTQUALIFIER  string,GLAZING_CLASSIFICATION  string,SIDE  string,MISC_FINISH  string,MISC_TINT  string,CLMISC_NAME  string,LENSMISC_NAME  string,HORCUS_ORIGINAL_PRICE  string,HORCUS_INITIAL_SUPPLY  string,HORCUS_DISPOSABLE_QUANTITY  string,OPERATION  string,TIMESTAMP  string,TRANSACTIONID string,
# MAGIC RunDateTime    timestamp    ,
# MAGIC Year    string    ,
# MAGIC Month    string    ,
# MAGIC Day    string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_ORDER_INFO_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC C_ORDERLINE_ID string,
# MAGIC AD_CLIENT_ID string,
# MAGIC AD_ORG_ID string,
# MAGIC ISACTIVE string,
# MAGIC CREATED string,
# MAGIC CREATEDBY string,
# MAGIC UPDATED string,
# MAGIC UPDATEDBY string,
# MAGIC C_ORDER_ID string,
# MAGIC LINE string,
# MAGIC C_BPARTNER_ID string,
# MAGIC C_BPARTNER_LOCATION_ID string,
# MAGIC DATEORDERED string,
# MAGIC DATEPROMISED string,
# MAGIC DATEDELIVERED string,
# MAGIC DATEINVOICED string,
# MAGIC DESCRIPTION string,
# MAGIC M_PRODUCT_ID string,
# MAGIC M_WAREHOUSE_ID string,
# MAGIC DIRECTSHIP string,
# MAGIC C_UOM_ID string,
# MAGIC QTYORDERED string,
# MAGIC QTYRESERVED string,
# MAGIC QTYDELIVERED string,
# MAGIC QTYINVOICED string,
# MAGIC M_SHIPPER_ID string,
# MAGIC C_CURRENCY_ID string,
# MAGIC PRICELIST string,
# MAGIC PRICEACTUAL string,
# MAGIC PRICELIMIT string,
# MAGIC LINENETAMT string,
# MAGIC DISCOUNT string,
# MAGIC FREIGHTAMT string,
# MAGIC C_CHARGE_ID string,
# MAGIC CHARGEAMT string,
# MAGIC C_TAX_ID string,
# MAGIC S_RESOURCEASSIGNMENT_ID string,
# MAGIC REF_ORDERLINE_ID string,
# MAGIC M_ATTRIBUTESETINSTANCE_ID string,
# MAGIC ISDESCRIPTION string,
# MAGIC QUANTITYORDER string,
# MAGIC M_PRODUCT_UOM_ID string,
# MAGIC M_OFFER_ID string,
# MAGIC PRICESTD string,
# MAGIC CANCELPRICEAD string,
# MAGIC C_ORDER_DISCOUNT_ID string,
# MAGIC ISEDITLINENETAMT string,
# MAGIC TAXBASEAMT string,
# MAGIC M_INOUTLINE_ID string,
# MAGIC C_RETURN_REASON_ID string,
# MAGIC GROSS_UNIT_PRICE string,
# MAGIC LINE_GROSS_AMOUNT string,
# MAGIC GROSSPRICELIST string,
# MAGIC C_COSTCENTER_ID string,
# MAGIC GROSSPRICESTD string,
# MAGIC A_ASSET_ID string,
# MAGIC M_WAREHOUSE_RULE_ID string,
# MAGIC USER1_ID string,
# MAGIC QUOTATIONLINE_ID string,
# MAGIC USER2_ID string,
# MAGIC CREATE_RESERVATION string,
# MAGIC C_PROJECT_ID string,
# MAGIC SO_RES_STATUS string,
# MAGIC MANAGE_RESERVATION string,
# MAGIC MANAGE_PRERESERVATION string,
# MAGIC EXPLODE string,
# MAGIC BOM_PARENT_ID string,
# MAGIC EM_HORRET_POS_LINE_IDENTIFIER string,
# MAGIC EM_HORCUS_C_ORDER_ID string,
# MAGIC EM_HORCUS_DRAFTORDERNUMBER string,
# MAGIC EM_HORCUS_TOTALPOINTS string,
# MAGIC EM_HORCUS_SYNCH string,
# MAGIC EM_HORCUS_DRAFTORDERTYPE string,
# MAGIC EM_HORCUS_COVER string,
# MAGIC EM_HORCUS_COVER_EXPIRE_DATE string,
# MAGIC EM_HORCUS_CLCP string,
# MAGIC EM_HORCUS_CLCP_EXPIRE_DATE string,
# MAGIC EM_HORCUS_POINTTOSENDFORRETURN string,
# MAGIC EM_HORCUS_POINTTOSENDFORSALES string,
# MAGIC EM_HORCUS_ORIGINALORDER string,
# MAGIC EM_HORCUS_PRACT_TO_SUP_FRAME string,
# MAGIC EM_HORCUS_REMOTE_EDGING string,
# MAGIC EM_HORCUS_UNCAT_LENS string,
# MAGIC EM_HORCUS_PAY_TO_COLLECTED string,
# MAGIC EM_HORCUS_RDRLN_CNCLLD_LN string,
# MAGIC EM_HORCUS_IS_CNCLLD_LN string,
# MAGIC EM_HORCUS_PMS_STTS_RDR string,
# MAGIC EM_HORCUS_PMS_CLN_LN_LNK string,
# MAGIC EM_HORCUS_PR_RT_PRCSSD string,
# MAGIC EM_HORCUS_PARENTORDERLINE string,
# MAGIC EM_HORCUS_CONTRIBUTION_AMT string,
# MAGIC EM_HORCUS_OLD_SHIPMENT_LINE string,
# MAGIC EM_HORCUS_OLD_PRICE string,
# MAGIC EM_HORCUS_APPLYPOSTAGEFEE string,
# MAGIC EM_HORCUS_PRACT_TO_SUP_LENS string,
# MAGIC EM_HORCUS_IS_ONLY_LEFT_LENS string,
# MAGIC EM_HORCUS_IS_ONLY_RIGHT_LENS string,
# MAGIC EM_HORCUS_CANCEL_COVERBASKET string,
# MAGIC EM_HORCUS_EXPORT_TIMESTAMP string,
# MAGIC EM_HORCUS_INITIALSUPPLY string,
# MAGIC EM_HORCUS_RECEIPT_HISTORY_ID string,
# MAGIC EM_HORCUS_FIRST_DISPENSES string,
# MAGIC OPERATION string,
# MAGIC TIMESTAMP string,
# MAGIC TRANSACTIONID  string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_PATIENT_BOOKING_DETAILS_BUKOPMS_Incr/BackUp` ( CurateStandardRowKey long,
# MAGIC id string,
# MAGIC booking_channel string,
# MAGIC qflow_customer_id string,
# MAGIC booking_date string,
# MAGIC booking_time string,
# MAGIC qflow_booking_id string,
# MAGIC booking_duration string,
# MAGIC clinic string,
# MAGIC service_type string,
# MAGIC booking_status string,
# MAGIC notes string,
# MAGIC booking_store string,
# MAGIC deleted string,
# MAGIC version string,
# MAGIC composite_booking_id string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string  	
# MAGIC 			
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_MASTER_PRICE_LIST_VERSION_BUKOPMS_Incr/BackUp` (CurateStandardRowKey long,
# MAGIC
# MAGIC m_pricelist_version_id	string	,
# MAGIC ad_client_id	string	,
# MAGIC ad_org_id	string	,
# MAGIC isactive	string	,
# MAGIC created	string	,
# MAGIC createdby	string	,
# MAGIC updated	string	,
# MAGIC updatedby	string	,
# MAGIC name	string	,
# MAGIC description	string	,
# MAGIC m_pricelist_id	string	,
# MAGIC m_discountschema_id	string	,
# MAGIC validfrom	string	,
# MAGIC proccreate	string	,
# MAGIC m_pricelist_version_base_id	string	,
# MAGIC m_pricelist_version_generate	string	,
# MAGIC operation	string	,
# MAGIC timestamp	string	,
# MAGIC transactionid	string	,
# MAGIC RunDateTime	timestamp	,
# MAGIC Year	string	,
# MAGIC Month	string	,
# MAGIC Day	string	
# MAGIC 			
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_MASTER_PRODUCT_PRICE_BUKOPMS_Incr/BackUp` (CurateStandardRowKey long,
# MAGIC
# MAGIC m_pricelist_id string,
# MAGIC ad_client_id string,
# MAGIC ad_org_id string,
# MAGIC isactive string,
# MAGIC created string,
# MAGIC createdby string,
# MAGIC updated string,
# MAGIC updatedby string,
# MAGIC name string,
# MAGIC description string,
# MAGIC basepricelist_id string,
# MAGIC istaxincluded string,
# MAGIC issopricelist string,
# MAGIC isdefault string,
# MAGIC c_currency_id string,
# MAGIC enforcepricelimit string,
# MAGIC costbased string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string,
# MAGIC 			
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_PATIENT_BOOKING_DETAILS_ADDITIONAL_INFO_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC ID  string,QFLOW_CUSTOMER_ID  string,TITLE  string,FIRST_NAME  string,LAST_NAME  string,DOB  string,CREATION_TIME  string,ADDRESS  string,UPDATE_TIME  string,DELETED  string,VERSION  string,MATCH_STATUS  string,OPS_CUSTOMER_ID  string,TEL_NUMBER  string,EMAIL  string,OPERATION  string,TIMESTAMP  string,TRANSACTIONID string,
# MAGIC RunDateTime    timestamp    ,
# MAGIC Year    string    ,
# MAGIC Month    string    ,
# MAGIC Day    string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_OFFER_TYPE_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC M_OFFER_TYPE_ID  string,AD_CLIENT_ID  string,AD_ORG_ID  string,ISACTIVE  string,CREATED  string,CREATEDBY  string,UPDATED  string,UPDATEDBY  string,AD_MODULE_ID  string,NAME  string,DESCRIPTION  string,PL_ORDER_IMPLEMENTOR  string,EM_OBPOS_ISCATEGORY  string,EM_OBPOS_IMAGE  string,EM_HORCUS_PRMTN_TP  string,OPERATION  string,TIMESTAMP  string,TRANSACTIONID string,
# MAGIC RunDateTime    timestamp    ,
# MAGIC Year    string    ,
# MAGIC Month    string    ,
# MAGIC Day    string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_OFFER_INFO_BUKOPMS_Incr/BackUp/`
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC m_offer_id string,
# MAGIC ad_client_id string,
# MAGIC ad_org_id string,
# MAGIC isactive string,
# MAGIC created string,
# MAGIC createdby string,
# MAGIC updated string,
# MAGIC updatedby string,
# MAGIC name string,
# MAGIC priority string,
# MAGIC addamt string,
# MAGIC discount string,
# MAGIC fixed string,
# MAGIC datefrom string,
# MAGIC dateto string,
# MAGIC bpartner_selection string,
# MAGIC bp_group_selection string,
# MAGIC product_selection string,
# MAGIC prod_cat_selection string,
# MAGIC description string,
# MAGIC pricelist_selection string,
# MAGIC qty_from string,
# MAGIC qty_to string,
# MAGIC m_offer_type_id string,
# MAGIC apply_next string,
# MAGIC print_name string,
# MAGIC org_selection string,
# MAGIC ismultiple string,
# MAGIC multiple string,
# MAGIC characteristics_selection string,
# MAGIC em_horcus_ncldd_cstmr_flds string,
# MAGIC em_horcus_isnhs string,
# MAGIC em_horcus_min_amt string,
# MAGIC em_horcus_disc_perc string,
# MAGIC em_horcus_minimummoney string,
# MAGIC em_horcus_point string,
# MAGIC em_horcus_factorpoint string,
# MAGIC em_horcus_prom_selection string,
# MAGIC em_horcus_status string,
# MAGIC em_horcus_pending string,
# MAGIC em_horcus_approval string,
# MAGIC em_horcus_withdrawn string,
# MAGIC em_horcus_advcard string,
# MAGIC em_horcus_percentagesecpair string,
# MAGIC em_horcus_amtdiscount string,
# MAGIC em_horcus_country_prom string,
# MAGIC em_horcus_club_prom string,
# MAGIC em_horcus_regionlist_button string,
# MAGIC em_disct_totalreceipt string,
# MAGIC em_disct_totalamountdisc string,
# MAGIC em_disct_totalpercdisc string,
# MAGIC em_obdiscp_monday string,
# MAGIC em_obdiscp_tuesday string,
# MAGIC em_obdiscp_wednesday string,
# MAGIC em_obdiscp_thursday string,
# MAGIC em_obdiscp_friday string,
# MAGIC em_obdiscp_saturday string,
# MAGIC em_obdiscp_sunday string,
# MAGIC em_obdiscp_wholeweek string,
# MAGIC em_obdiscp_iscoupon string,
# MAGIC em_obdiscp_cloneoffer string,
# MAGIC em_obdisc_x string,
# MAGIC em_obdisc_y string,
# MAGIC em_obdisc_subtype string,
# MAGIC em_obdisc_distribute string,
# MAGIC em_obdisc_price string,
# MAGIC em_obdisc_c_currency_id string,
# MAGIC em_obdisc_upc string,
# MAGIC em_obdisc_image string,
# MAGIC em_obdisc_amt string,
# MAGIC em_obdisc_percentage string,
# MAGIC em_obdisc_role_selection string,
# MAGIC em_obdisc_approval_required string,
# MAGIC em_horcus_frame_only string,
# MAGIC em_horcus_sort string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string 
# MAGIC 							
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_PAYMENT_METHOD_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1 INCREMENT BY 1),
# MAGIC FIN_PAYMENTMETHOD_ID  string ,AD_CLIENT_ID  string ,AD_ORG_ID  string ,CREATED  string ,CREATEDBY  string ,UPDATED  string ,UPDATEDBY  string ,ISACTIVE  string ,NAME  string ,DESCRIPTION  string ,AUTOMATIC_RECEIPT  string ,AUTOMATIC_PAYMENT  string ,AUTOMATIC_DEPOSIT  string ,AUTOMATIC_WITHDRAWN  string ,PAYIN_ALLOW  string ,PAYOUT_ALLOW  string ,PAYIN_EXECUTION_TYPE  string ,PAYOUT_EXECUTION_TYPE  string ,PAYIN_EXECUTION_PROCESS_ID  string ,PAYOUT_EXECUTION_PROCESS_ID  string ,PAYIN_DEFERRED  string ,PAYOUT_DEFERRED  string ,UPONRECEIPTUSE  string ,UPONDEPOSITUSE  string ,INUPONCLEARINGUSE  string ,UPONPAYMENTUSE  string ,UPONWITHDRAWALUSE  string ,OUTUPONCLEARINGUSE  string ,PAYIN_ISMULTICURRENCY  string ,PAYOUT_ISMULTICURRENCY  string ,EM_HORCUS_PRRT_CLCLT  string ,EM_OBPOS_BANKABLE  string ,OPERATION  string ,TIMESTAMP  string ,TRANSACTIONID string,
# MAGIC RunDateTime    timestamp    ,
# MAGIC Year    string    ,
# MAGIC Month    string    ,
# MAGIC Day    string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_CONTACT_LENS_CARE_PLAN_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT,
# MAGIC id string,
# MAGIC code string,
# MAGIC expiry_date string,
# MAGIC active string,
# MAGIC customer_code string,
# MAGIC creation_timestamp string,
# MAGIC deleted string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_ORGANIZATION_APPOINTMENT_DETAILS_BUKOPMS_Incr/BackUp` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT,
# MAGIC id string,
# MAGIC code string,
# MAGIC entity_type string,
# MAGIC entity_code string,
# MAGIC date_time string,
# MAGIC destination string,
# MAGIC status string,
# MAGIC path_status string,
# MAGIC journey_status string,
# MAGIC service_group_type string,
# MAGIC deleted string,
# MAGIC last_update string,
# MAGIC start_time string,
# MAGIC end_time string,
# MAGIC ext_appointment_id string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC   CREATE TABLE if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_CONTACT_LENS_SPECIFICATION_BUKOPMS_Incr/BackUp` (
# MAGIC   CurateStandardRowKey BIGINT,
# MAGIC   id STRING,
# MAGIC   code STRING,
# MAGIC   creation_date STRING,
# MAGIC   entity_code STRING,
# MAGIC   due_date STRING,
# MAGIC   entity_type STRING,
# MAGIC   created_by STRING,
# MAGIC   expiry_date STRING,
# MAGIC   last_update STRING,
# MAGIC   only_left_lens_detail STRING,
# MAGIC   only_right_lens_detail STRING,
# MAGIC   source STRING,
# MAGIC   status STRING,
# MAGIC   customer_code STRING,
# MAGIC   source_other STRING,
# MAGIC   prev_lens_check_date STRING,
# MAGIC   recall_period STRING,
# MAGIC   reason_original_amend_specific STRING,
# MAGIC   parent_code STRING,
# MAGIC   deleted STRING,
# MAGIC   last_cash_purchase_date STRING,
# MAGIC   operation STRING,
# MAGIC   timestamp STRING,
# MAGIC   transactionid STRING,
# MAGIC   RunDateTime TIMESTAMP,
# MAGIC   Year STRING,
# MAGIC   Month STRING,
# MAGIC   Day STRING)

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_MASTER_PRODUCT_MANUFACTURER_INFO_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC M_BRAND_ID string,
# MAGIC AD_CLIENT_ID string,
# MAGIC AD_ORG_ID string,
# MAGIC ISACTIVE string,
# MAGIC CREATED string,
# MAGIC CREATEDBY string,
# MAGIC UPDATED string,
# MAGIC UPDATEDBY string,
# MAGIC NAME string,
# MAGIC DESCRIPTION string,
# MAGIC EM_HORCUS_ISEXTERNAL string,
# MAGIC OPERATION string,
# MAGIC TIMESTAMP string,
# MAGIC TRANSACTIONID string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string )

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_MASTER_PRODUCT_CATEGORY_BUKOPMS_Incr/BackUp/`
# MAGIC (CurateStandardRowKey bigint 
# MAGIC ,m_product_category_id string
# MAGIC ,ad_client_id string
# MAGIC ,ad_org_id string
# MAGIC ,isactive string
# MAGIC ,created string
# MAGIC ,createdby string
# MAGIC ,updated string
# MAGIC ,updatedby string
# MAGIC ,value string
# MAGIC ,name string
# MAGIC ,description string
# MAGIC ,isdefault string
# MAGIC ,plannedmargin string
# MAGIC ,a_asset_group_id string
# MAGIC ,ad_image_id string
# MAGIC ,issummary string
# MAGIC ,em_horie_ie_entity string
# MAGIC ,em_horcus_priority string
# MAGIC ,em_horcus_producttype string
# MAGIC ,em_horcus_percentageofpayment string
# MAGIC ,em_horcus_isinclassortment string
# MAGIC ,em_horcus_generic_basket string
# MAGIC ,em_horcus_customer_basket string
# MAGIC ,operation string
# MAGIC ,timestamp string
# MAGIC ,transactionid string
# MAGIC ,RunDateTime timestamp
# MAGIC ,Year string
# MAGIC ,Month string
# MAGIC ,Day string)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE  TABLE IF NOT EXISTS delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_MASTER_SOLD_PRODUCT_DETAILS_BUKOPMS_Incr/BackUp/`
# MAGIC (CurateStandardRowKey BIGINT 
# MAGIC , m_product_id
# MAGIC string , ad_client_id
# MAGIC string , ad_org_id
# MAGIC string , isactive
# MAGIC string , created
# MAGIC string , createdby
# MAGIC string , updated
# MAGIC string , updatedby
# MAGIC string , value
# MAGIC string , name
# MAGIC string , description
# MAGIC string , documentnote
# MAGIC string , help
# MAGIC string , upc
# MAGIC string , sku
# MAGIC string , c_uom_id
# MAGIC string , salesrep_id
# MAGIC string , issummary
# MAGIC string , isstocked
# MAGIC string , ispurchased
# MAGIC string , issold
# MAGIC string , isbom
# MAGIC string , isinvoiceprintdetails
# MAGIC string , ispicklistprintdetails
# MAGIC string , isverified
# MAGIC string , m_product_category_id
# MAGIC string , classification
# MAGIC string , volume
# MAGIC string , weight
# MAGIC string , shelfwidth
# MAGIC string , shelfheight
# MAGIC string , shelfdepth
# MAGIC string , unitsperpallet
# MAGIC string , c_taxcategory_id
# MAGIC string , s_resource_id
# MAGIC string , discontinued
# MAGIC string , discontinuedby
# MAGIC string , processing
# MAGIC string , s_expensetype_id
# MAGIC string , producttype
# MAGIC string , imageurl
# MAGIC string , descriptionurl
# MAGIC string , guaranteedays
# MAGIC string , versionno
# MAGIC string , m_attributeset_id
# MAGIC string , m_attributesetinstance_id
# MAGIC string , downloadurl
# MAGIC string , m_freightcategory_id
# MAGIC string , m_locator_id
# MAGIC string , ad_image_id
# MAGIC string , c_bpartner_id
# MAGIC string , ispriceprinted
# MAGIC string , name2
# MAGIC string , costtype
# MAGIC string , coststd
# MAGIC string , stock_min
# MAGIC string , enforce_attribute
# MAGIC string , calculated
# MAGIC string , ma_processplan_id
# MAGIC string , production
# MAGIC string , capacity
# MAGIC string , delaymin
# MAGIC string , mrp_planner_id
# MAGIC string , mrp_planningmethod_id
# MAGIC string , qtymax
# MAGIC string , qtymin
# MAGIC string , qtystd
# MAGIC string , qtytype
# MAGIC string , stockmin
# MAGIC string , attrsetvaluetype
# MAGIC string , isquantityvariable
# MAGIC string , isdeferredrevenue
# MAGIC string , revplantype
# MAGIC string , periodnumber
# MAGIC string , isdeferredexpense
# MAGIC string , expplantype
# MAGIC string , periodnumber_exp
# MAGIC string , defaultperiod
# MAGIC string , defaultperiod_exp
# MAGIC string , bookusingpoprice
# MAGIC string , c_uom_weight_id
# MAGIC string , m_brand_id
# MAGIC string , isgeneric
# MAGIC string , generic_product_id
# MAGIC string , createvariants
# MAGIC string , characteristic_desc
# MAGIC string , updateinvariants
# MAGIC string , managevariants
# MAGIC string , em_horcus_availability
# MAGIC string , em_horcus_case_id
# MAGIC string , em_horcus_display_sequence
# MAGIC string , em_horcus_percentage
# MAGIC string , em_horcus_eye_size
# MAGIC string , em_horcus_bridge_size
# MAGIC string , em_horcus_side_length
# MAGIC string , em_horcus_availabilityfromdate
# MAGIC string , em_horcus_art_sub_grp_id
# MAGIC string , em_horcus_ischarity
# MAGIC string , em_horcus_deliverytm_promised
# MAGIC string , em_horcus_advg_crd_pnts
# MAGIC string , em_horcus_allw_prc_ovrrd
# MAGIC string , em_horcus_allw_tll_dscnt
# MAGIC string , em_horcus_hm_dlvr
# MAGIC string , em_horcus_elgbl_glss_cvr
# MAGIC string , em_horcus_water_content
# MAGIC string , em_horcus_box_bdl
# MAGIC string , em_horcus_box_dcd
# MAGIC string , em_horcus_edge_thickness
# MAGIC string , em_horcus_mrcndsng_ctgr
# MAGIC string , em_horcus_fshn_ctgr
# MAGIC string , em_horcus_cntct_lns_mtrl
# MAGIC string , em_horcus_cntct_lns_fml
# MAGIC string , em_horcus_exma_ctgr
# MAGIC string , em_horcus_exma_tp
# MAGIC string , em_horcus_manufacturer
# MAGIC string , em_horcus_manufacturer_colour
# MAGIC string , em_horcus_receipt_descriptions
# MAGIC string , em_horcus_isbalanced
# MAGIC string , em_horcus_isfrosted
# MAGIC string , em_horcus_wrkng_dstnc
# MAGIC string , em_horcus_bw_ngl
# MAGIC string , em_horcus_yf_it_vl
# MAGIC string , em_horcus_lfstyl_bs
# MAGIC string , em_horcus_zss_ngrvng
# MAGIC string , em_horcus_lgbl_rfnd
# MAGIC string , em_horcus_rqrsstck
# MAGIC string , em_horcus_prsm_tnnng
# MAGIC string , em_horcus_cntr
# MAGIC string , em_horcus_dk
# MAGIC string , em_horcus_sltn_grp
# MAGIC string , em_horcus_bvd_frm
# MAGIC string , em_horcus_btch_lt
# MAGIC string , em_horcus_rm_tp
# MAGIC string , em_horcus_blnk_sz_clc_crdnts
# MAGIC string , em_horcus_plshng
# MAGIC string , em_horcus_clr_grp
# MAGIC string , em_horcus_dd_grp
# MAGIC string , em_horcus_contact_lens_group
# MAGIC string , em_horcus_glzng_clssfctn_id
# MAGIC string , em_horcus_offset_v
# MAGIC string , em_horcus_offset_h
# MAGIC string , em_horcus_article_type_id
# MAGIC string , em_horcus_ct_ls_clsstctn_mdlt
# MAGIC string , em_horcus_dsptch_frqunc
# MAGIC string , em_horcus_supplier
# MAGIC string , em_horcus_pck_quntt
# MAGIC string , em_obpos_scale
# MAGIC string , em_obpos_groupedproduct
# MAGIC string , em_obpos_showstock
# MAGIC string , em_obpos_show_ch_desc
# MAGIC string , em_horcus_pantascopic_tilt
# MAGIC string , em_horcus_issafety
# MAGIC string , em_horcus_sun_frame
# MAGIC string , em_horcus_rqrs_goc_pprvl
# MAGIC string , em_horcus_prdct_lst_mmbrsp
# MAGIC string , em_horcus_prscrptn_cptr_ptnl
# MAGIC string , em_horcus_stock_lens
# MAGIC string , operation
# MAGIC string , timestamp
# MAGIC string , transactionid
# MAGIC string , RunDateTime
# MAGIC timestamp, Year
# MAGIC string , Month
# MAGIC string , Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE  TABLE IF NOT EXISTS delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_RECEIPT_TRACKING_DETAILS_BUKOPMS_Incr/BackUp/`
# MAGIC (CurateStandardRowKey BIGINT
# MAGIC ,horcus_receipt_history_id string
# MAGIC ,ad_client_id string
# MAGIC ,ad_org_id string
# MAGIC ,isactive string
# MAGIC ,created string
# MAGIC ,createdby string
# MAGIC ,updated string
# MAGIC ,updatedby string
# MAGIC ,basket_status string
# MAGIC ,transaction_type string
# MAGIC ,receipt_date string
# MAGIC ,receipt_number string
# MAGIC ,c_order_id string
# MAGIC ,operation string
# MAGIC ,timestamp string
# MAGIC ,transactionid string
# MAGIC ,RunDateTime timestamp
# MAGIC ,Year string
# MAGIC ,Month string
# MAGIC ,Day string)

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PRACTICE_POS_TERMINAL_DETAILS_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT,
# MAGIC obpos_applications_id    string,
# MAGIC ad_client_id    string,
# MAGIC ad_org_id    string,
# MAGIC isactive    string,
# MAGIC created    string,
# MAGIC createdby    string,
# MAGIC updated    string,
# MAGIC updatedby    string,
# MAGIC value    string,
# MAGIC name    string,
# MAGIC hardwareurl    string,
# MAGIC scaleurl    string,
# MAGIC orderdocno_prefix    string,
# MAGIC obpos_terminaltype_id    string,
# MAGIC quotationdocno_prefix    string,
# MAGIC defaultwebpostab    string,
# MAGIC c_bpartner_id    string,
# MAGIC obpos_c_bpartner_loc_id    string,
# MAGIC printoffline    string,
# MAGIC terminal_key_id    string,
# MAGIC islinked    string,
# MAGIC unlinkdevice    string,
# MAGIC lastassignednum    string,
# MAGIC ismaster    string,
# MAGIC masterterminal_id    string,
# MAGIC quotationslastassignednum    string,
# MAGIC current_cache_session_id    string,
# MAGIC em_horcus_till    string,
# MAGIC em_obposcs_copy_terminal    string,
# MAGIC em_horcus_quickly_quttn    string,
# MAGIC operation    string,
# MAGIC timestamp    string,
# MAGIC transactionid    string,
# MAGIC RunDateTime    timestamp,
# MAGIC Year    string,
# MAGIC Month    string,
# MAGIC Day    string,
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PRACTICE_ORG_TYPE_DETAILS_BUKOPMS_Incr/BackUp` (
# MAGIC
# MAGIC CurateStandardRowKey	bigint	,
# MAGIC ad_orgtype_id	string	,
# MAGIC ad_client_id	string	,
# MAGIC ad_org_id	string	,
# MAGIC isactive	string	,
# MAGIC created	date	,
# MAGIC createdby	string,	
# MAGIC updated	date	,
# MAGIC updatedby	string,	
# MAGIC isdefault	string	,
# MAGIC name	string	,
# MAGIC description	string,	
# MAGIC islegalentity	string	,
# MAGIC isbusinessunit	string	,
# MAGIC istransactionsallowed	string,	
# MAGIC isacctlegalentity	string	,
# MAGIC operation	string	,
# MAGIC timestamp	string	,
# MAGIC transactionid	string,	
# MAGIC RunDateTime	timestamp	,
# MAGIC Year	string	,
# MAGIC Month	string	,
# MAGIC Day	string			
# MAGIC 			
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PRACTICE_CASHUP_DETAILS_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC OBPOS_APP_CASHUP_ID  string ,
# MAGIC AD_CLIENT_ID  string ,
# MAGIC AD_ORG_ID  string ,
# MAGIC ISACTIVE  string ,
# MAGIC CREATED  string ,
# MAGIC CREATEDBY  string ,
# MAGIC UPDATED  string ,
# MAGIC UPDATEDBY  string ,
# MAGIC OBPOS_APPLICATIONS_ID  string ,
# MAGIC CASHUPDATE  string ,
# MAGIC AD_USER_ID  string ,
# MAGIC CASHUPREPORT  string ,
# MAGIC NETSALES  string ,
# MAGIC GROSSSALES  string ,
# MAGIC NETRETURNS  string ,
# MAGIC GROSSRETURNS  string ,
# MAGIC TOTALRETAILTRANSACTIONS  string ,
# MAGIC ISBEINGPROCESSED  string ,
# MAGIC ISPROCESSED  string ,
# MAGIC ISPROCESSEDBO  string ,
# MAGIC OBPOS_PARENT_CASHUP_ID  string ,
# MAGIC EM_HORCUS_APPROVAL_USER  string ,
# MAGIC EM_HORCUS_DISCREPANCY_AMOUNT  string ,
# MAGIC EM_HORCUS_REASON_ID  string ,
# MAGIC EM_HORCUS_TOTALTODEPOSIT  string ,
# MAGIC OPERATION  string ,
# MAGIC TIMESTAMP  string ,
# MAGIC TRANSACTIONID string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_DOCUMENT_TYPE_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC C_DOCTYPE_ID  string,
# MAGIC AD_CLIENT_ID  string,
# MAGIC AD_ORG_ID  string,
# MAGIC ISACTIVE  string,
# MAGIC CREATED  string,
# MAGIC CREATEDBY  string,
# MAGIC UPDATED  string,
# MAGIC UPDATEDBY  string,
# MAGIC NAME  string,
# MAGIC PRINTNAME  string,
# MAGIC DESCRIPTION  string,
# MAGIC DOCBASETYPE  string,
# MAGIC ISSOTRX  string,
# MAGIC DOCSUBTYPESO  string,
# MAGIC C_DOCTYPESHIPMENT_ID  string,
# MAGIC C_DOCTYPEINVOICE_ID  string,
# MAGIC ISDOCNOCONTROLLED  string,
# MAGIC DOCNOSEQUENCE_ID  string,
# MAGIC GL_CATEGORY_ID  string,
# MAGIC DOCUMENTNOTE  string,
# MAGIC ISDEFAULT  string,
# MAGIC DOCUMENTCOPIES  string,
# MAGIC AD_TABLE_ID  string,
# MAGIC ORGFILTERED  string,
# MAGIC C_DOCTYPE_REVERSED_ID  string,
# MAGIC ISEXPENSE  string,
# MAGIC ISREVERSAL  string,
# MAGIC ISRETURN  string,
# MAGIC C_DOCTYPEORDER_ID  string,
# MAGIC OPERATION  string,
# MAGIC TIMESTAMP  string,
# MAGIC TRANSACTIONID  string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_CUSTOMER_IDENTIFIER_DETAILS_BUKOPMS_Incr/BackUp`
# MAGIC
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT  ,
# MAGIC id
# MAGIC string , identifier_code
# MAGIC string , identifier_type
# MAGIC string , customer_code
# MAGIC string , start_date
# MAGIC string , expiry_date
# MAGIC string , active
# MAGIC string , deleted
# MAGIC string , changed_status_date
# MAGIC string , lastupdate_timestamp
# MAGIC string , validated
# MAGIC string , hash_code
# MAGIC string , external_ref
# MAGIC string , guest
# MAGIC string , operation
# MAGIC string , timestamp
# MAGIC string , transactionid
# MAGIC string , RunDateTime
# MAGIC timestamp , Year
# MAGIC string , Month
# MAGIC string , Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PRACTICE_REASON_DETAILS_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC HORCUS_REASON_ID string,
# MAGIC AD_CLIENT_ID string,
# MAGIC AD_ORG_ID string,
# MAGIC ISACTIVE string,
# MAGIC CREATED string,
# MAGIC CREATEDBY string,
# MAGIC UPDATED string,
# MAGIC UPDATEDBY string,
# MAGIC VALUE string,
# MAGIC NAME string,
# MAGIC REASON_TYPE string,
# MAGIC OPERATION string,
# MAGIC TIMESTAMP string,
# MAGIC TRANSACTIONID string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_PATIENT_INFO_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC id string,
# MAGIC code string,
# MAGIC practice_code string,
# MAGIC title string,
# MAGIC first_name string,
# MAGIC middle_name string,
# MAGIC surname string,
# MAGIC dob string,
# MAGIC gender string,
# MAGIC status string,
# MAGIC inactivation_reason string,
# MAGIC no_fixed_address string,
# MAGIC deleted string,
# MAGIC last_practice_code string,
# MAGIC creation_timestamp string,
# MAGIC insurance_number string,
# MAGIC lastupdate_timestamp string,
# MAGIC third_party_code string,
# MAGIC transfer_date string,
# MAGIC transfer_type string,
# MAGIC last_practice_name string,
# MAGIC created_by string,
# MAGIC export_timestamp string,
# MAGIC export_date string,
# MAGIC source string,
# MAGIC updated_by string,
# MAGIC version string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string)

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PRACTICE_ORGANIZATION_INFO_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC  AD_ORG_ID     string ,
# MAGIC   AD_CLIENT_ID     string ,
# MAGIC   ISACTIVE     string ,
# MAGIC   CREATED     string ,
# MAGIC   CREATEDBY     string ,
# MAGIC   UPDATED     string ,
# MAGIC   UPDATEDBY     string ,
# MAGIC   VALUE     string ,
# MAGIC   NAME     string ,
# MAGIC   DESCRIPTION     string ,
# MAGIC   ISSUMMARY     string ,
# MAGIC   AD_ORGTYPE_ID     string ,
# MAGIC   ISPERIODCONTROLALLOWED     string ,
# MAGIC   C_CALENDAR_ID     string ,
# MAGIC   ISREADY     string ,
# MAGIC   SOCIAL_NAME     string ,
# MAGIC   C_CURRENCY_ID     string ,
# MAGIC   C_ACCTSCHEMA_ID     string ,
# MAGIC   EM_HORCUS_ORGHIERARCHY     string ,
# MAGIC   EM_HORCUS_SYNCHRNZD_WTH_PMS     string ,
# MAGIC   EM_HORCUS_AD_SEQUENCE_ID     string ,
# MAGIC   EM_HORCUS_CMPLTD_FLDS     string ,
# MAGIC   EM_OBMPR_DEFBP     string ,
# MAGIC   EM_OBMPR_ENABLEWEIGHT     string ,
# MAGIC   EM_OBMPR_BLOCKUNDERWEIGHT     string ,
# MAGIC   EM_OBMPR_BLOCKOVERWEIGHT     string ,
# MAGIC   EM_OBMPR_MINWEIGHT     string ,
# MAGIC   EM_OBMPR_MAXWEIGHT     string ,
# MAGIC   EM_OBRETCO_RETAILORGTYPE     string ,
# MAGIC   EM_OBRETCO_PRICELIST_ID     string ,
# MAGIC   EM_OBRETCO_PRODUCTLIST_ID     string ,
# MAGIC   EM_OBRETCO_C_BPARTNER_ID     string ,
# MAGIC   EM_OBRETCO_C_BP_LOCATION_ID     string ,
# MAGIC   EM_OBRETCO_M_WAREHOUSE_ID     string ,
# MAGIC   EM_OBRETCO_DBP_IRULESID     string ,
# MAGIC   EM_OBRETCO_DBP_PTERMID     string ,
# MAGIC   EM_OBRETCO_DBP_PMETHODID     string ,
# MAGIC   EM_OBRETCO_DBP_BPCATID     string ,
# MAGIC   EM_OBRETCO_DBP_COUNTRYID     string ,
# MAGIC   EM_OBRETCO_DBP_ORGID     string ,
# MAGIC   EM_OBRETCO_SHOWTAXID     string ,
# MAGIC   EM_OBRETCO_SHOWBPCATEGORY     string ,
# MAGIC   EM_OBPOS_TICKET_TEMPLATE_ID     string ,
# MAGIC   EM_OBPOS_CASHUP_TEMPLATE_ID     string ,
# MAGIC   EM_OBPOS_FORMAT_DECIMAL     string ,
# MAGIC   EM_OBPOS_FORMAT_GROUP     string ,
# MAGIC   EM_OBPOS_DATE_FORMAT     string ,
# MAGIC   EM_OBPOS_CLOSEDRECEIPT_TEM_ID     string ,
# MAGIC   EM_OBPOS_INVOICE_TEMPLATE_ID     string ,
# MAGIC   EM_OBPOS_RET_INV_TEMPLATE_ID     string ,
# MAGIC   EM_OBPOS_LAYAWAY_TEMPLATE_ID     string ,
# MAGIC   EM_OBPOS_RETURN_TEMPLATE_ID     string ,
# MAGIC   EM_OBPOS_QUOT_TEMPLATE_ID     string ,
# MAGIC   EM_OBPOSBD_BEST_DEAL_CASE     string ,
# MAGIC   EM_OBPOSBD_PREVENT_LONG_EX     string ,
# MAGIC   EM_OBKPAY_USERNAME     string ,
# MAGIC   EM_OBKPAY_PASSWORD     string ,
# MAGIC   OPERATION     string ,
# MAGIC   TIMESTAMP     string ,
# MAGIC   TRANSACTIONID     string,
# MAGIC   RunDateTime    timestamp    ,
# MAGIC   Year    string    ,
# MAGIC   Month    string    ,
# MAGIC   Day    string
# MAGIC  )

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE  TABLE IF NOT EXISTS delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_PATIENT_PRESCRIPTION_DETAILS_BUKOPMS_Incr/BackUp/`
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC id
# MAGIC string , code
# MAGIC string , customer_code
# MAGIC string , site_code
# MAGIC string , external_code
# MAGIC string , external_type
# MAGIC string , bvd
# MAGIC string , date_time
# MAGIC string , left_balance
# MAGIC string , left_axis
# MAGIC string , left_cyl
# MAGIC string , user_name
# MAGIC string , clinician_name
# MAGIC string , left_dprismh
# MAGIC string , left_dprismh_type
# MAGIC string , start_time
# MAGIC string , left_dprismv
# MAGIC string , left_dprismv_type
# MAGIC string , left_inter_add
# MAGIC string , left_near_add
# MAGIC string , left_nprismh
# MAGIC string , left_nprismh_type
# MAGIC string , left_nprismv
# MAGIC string , left_nprismv_type
# MAGIC string , left_pd_dist
# MAGIC string , left_pd_near
# MAGIC string , left_sph
# MAGIC string , left_va_dist
# MAGIC string , left_va_near
# MAGIC string , right_axis
# MAGIC string , right_balance
# MAGIC string , right_cyl
# MAGIC string , right_dprismh
# MAGIC string , right_dprismh_type
# MAGIC string , right_dprismv
# MAGIC string , right_dprismv_type
# MAGIC string , right_inter_add
# MAGIC string , right_near_add
# MAGIC string , right_nprismh
# MAGIC string , right_nprismh_type
# MAGIC string , right_nprismv
# MAGIC string , right_nprismv_type
# MAGIC string , right_pd_dist
# MAGIC string , right_pd_near
# MAGIC string , right_sph
# MAGIC string , right_va_dist
# MAGIC string , right_va_near
# MAGIC string , deleted
# MAGIC string , bin_va_near
# MAGIC string , bin_va_dist
# MAGIC string , parent_code
# MAGIC string , reason_original_amend
# MAGIC string , status
# MAGIC string , create_version
# MAGIC string , operation
# MAGIC string , timestamp
# MAGIC string , transactionid
# MAGIC string , RunDateTime
# MAGIC timestamp , Year
# MAGIC string , Month
# MAGIC string , Day string )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_CUSTOMER_ADVICE_GIVEN_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC ID  string ,
# MAGIC CODE  string ,
# MAGIC SERVICE_ITEM_CODE  string ,
# MAGIC SERVICE_ITEM_TYPE  string ,
# MAGIC CORRECTION  string ,
# MAGIC CORRECTION_TYPE  string ,
# MAGIC FULL_TIME_WEAR  string ,
# MAGIC PART_TIME_WEAR  string ,
# MAGIC NO_CORRECTION  string ,
# MAGIC SUITABLE_CONTACT_LENSES  string ,
# MAGIC REFERRAL  string ,
# MAGIC REFERRAL_TYPE  string ,
# MAGIC BOOK_FURTHER_APPOINTMENT  string ,
# MAGIC DELETED  string ,
# MAGIC OPERATION  string ,
# MAGIC TIMESTAMP  string ,
# MAGIC TRANSACTIONID string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_ORDERLINE_CLINICAL_INFO_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC id
# MAGIC string , quantity
# MAGIC string , catalog_type
# MAGIC string , product_code
# MAGIC string , product_type
# MAGIC string , deleted
# MAGIC string , id_order_header
# MAGIC string , retail_price_amount
# MAGIC string , retail_price_iso_code
# MAGIC string , retail_price_excrate_id
# MAGIC string , description
# MAGIC string , side
# MAGIC string , available
# MAGIC string , brand
# MAGIC string , material
# MAGIC string , pack_size
# MAGIC string , brand_external
# MAGIC string , manufacturer
# MAGIC string , supplier_code
# MAGIC string , third_party_lens_supplement
# MAGIC string , operation
# MAGIC string , timestamp
# MAGIC string , transactionid
# MAGIC string , RunDateTime
# MAGIC timestamp , Year
# MAGIC string , Month
# MAGIC string , Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE  TABLE IF NOT EXISTS delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_PATIENT_PRIVACY_AGREEMENT_BUKOPMS_Incr/BackUp/`
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC id string
# MAGIC ,date_time string
# MAGIC ,confirm_data_privacy string
# MAGIC ,privacy_version string
# MAGIC ,deleted string
# MAGIC ,patient_code string
# MAGIC ,operation string
# MAGIC ,timestamp string
# MAGIC ,transactionid string
# MAGIC ,RunDateTime timestamp
# MAGIC ,Year string
# MAGIC ,Month string
# MAGIC ,Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_CUSTOMER_REWARD_DETAILS_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC ID  string,
# MAGIC CODE  string,
# MAGIC CREATION_DATE  string,
# MAGIC ENTITY_CODE  string,
# MAGIC CUSTOMER_CODE  string,
# MAGIC LAST_UPDATE  string,
# MAGIC ENTITY_TYPE  string,
# MAGIC EXPIRY_DATE  string,
# MAGIC PLAN_STATUS  string,
# MAGIC SCHEME_NUMBER  string,
# MAGIC CL_RECALL_DATE  string,
# MAGIC APPROVED_BY  string,
# MAGIC DELETED  string,
# MAGIC DRAFT  string,
# MAGIC DISCONTINUED  string,
# MAGIC CANCELLATION_REASON  string,
# MAGIC AD_CARD_NUMBER  string,
# MAGIC AD_CARD_NUMBER_DISPLAY  string,
# MAGIC DELIVERY_ADDRESS_TYPE  string,
# MAGIC TAC_REPORT_DATE  string,
# MAGIC DDI_REPORT_DATE  string,
# MAGIC PRACTICE_CODE  string,
# MAGIC CANCELLATION_DATE  string,
# MAGIC SUSPENSION_DATE  string,
# MAGIC REINSTATEMENT_DATE  string,
# MAGIC TILL_ID  string,
# MAGIC OPERATION  string,
# MAGIC TIMESTAMP  string,
# MAGIC TRANSACTIONID string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string )

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_PATIENT_CONTACT_DETAILS_BUKOPMS_Incr/BackUp`
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC id
# MAGIC string ,patient_code
# MAGIC string ,destination
# MAGIC string ,entity_type
# MAGIC string ,deleted
# MAGIC string ,id_address_horizon
# MAGIC string ,description
# MAGIC string ,entity_code
# MAGIC string ,operation
# MAGIC string ,timestamp
# MAGIC string ,transactionid
# MAGIC string ,RunDateTime
# MAGIC timestamp ,Year
# MAGIC string ,Month
# MAGIC string ,Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_PATIENT_ADDRESS_DETAILS_BUKOPMS_Incr/BackUp`
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC id
# MAGIC string , address1
# MAGIC string , address2
# MAGIC string , address3
# MAGIC string , city
# MAGIC string , post_code
# MAGIC string , country
# MAGIC string , home_tel_number
# MAGIC string , mobile_tel_number
# MAGIC string , work_tel_number
# MAGIC string , preferred_tel_number
# MAGIC string , email
# MAGIC string , deleted
# MAGIC string , building_name
# MAGIC string , country_code
# MAGIC string , creation_timestamp
# MAGIC string , foreign_address
# MAGIC string , house_number
# MAGIC string , lastupdate_timestamp
# MAGIC string , unit_description
# MAGIC string , unit_number
# MAGIC string , validated
# MAGIC string , gone_away
# MAGIC string , operation
# MAGIC string , timestamp
# MAGIC string , transactionid
# MAGIC string , RunDateTime
# MAGIC timestamp , Year
# MAGIC string , Month
# MAGIC string , Day string
# MAGIC
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_ORDER_LINE_LENS_INFO_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC ID string,
# MAGIC LENS_FINISH_EXTERNAL_REF string,
# MAGIC LENS_FINISH_VALUE string,
# MAGIC MANUFACTURER_LEAD_TIME string,
# MAGIC TINT_TYPE_EXTERNAL_REF string,
# MAGIC TINT_TYPE_VALUE string,
# MAGIC TINT_COLOR_VALUE string,
# MAGIC TINT_COLOR_EXTERNAL_REF string,
# MAGIC TINT_DEPTH_EXTERNAL_REF string,
# MAGIC TINT_DEPTH_VALUE string,
# MAGIC VISION_TYPE string,
# MAGIC VISION_SUB_TYPE string,
# MAGIC FINISH_CODE string,
# MAGIC LENS_INDEX string,
# MAGIC TINT_CODE string,
# MAGIC TO_ORDER string,
# MAGIC DELETED string,
# MAGIC ID_ORDER_LINE string,
# MAGIC BLANK_DIAM string,
# MAGIC V_DEC string,
# MAGIC H_DEC string,
# MAGIC BLANK_DIAMETER_ANGLE string,
# MAGIC IS_STOCK string,
# MAGIC THICKNESS string,
# MAGIC OPERATION string,
# MAGIC TIMESTAMP string,
# MAGIC TRANSACTIONID string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string )

# COMMAND ----------

# MAGIC %sql
# MAGIC Create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_CUSTOMER_CONSENT_AGREEMENT_BUKOPMS_Incr/BackUp`
# MAGIC (CurateStandardRowKey Bigint,id string,
# MAGIC info_name string,
# MAGIC info_value string,
# MAGIC info_version string,
# MAGIC info_label string,
# MAGIC agreement_status string,
# MAGIC creation_timestamp string,
# MAGIC deleted string,
# MAGIC id_patient_horizon string,
# MAGIC field_code string,
# MAGIC created_by string,
# MAGIC updated_by string,
# MAGIC update_timestamp string,
# MAGIC field_initial string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_ORDER_CART_INFO_BUKOPMS_Incr/BackUp/` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC c_order_id string,
# MAGIC ad_client_id string,
# MAGIC ad_org_id string,
# MAGIC isactive string,
# MAGIC created string,
# MAGIC createdby string,
# MAGIC updated string,
# MAGIC updatedby string,
# MAGIC issotrx string,
# MAGIC documentno string,
# MAGIC docstatus string,
# MAGIC docaction string,
# MAGIC processing string,
# MAGIC processed string,
# MAGIC c_doctype_id string,
# MAGIC c_doctypetarget_id string,
# MAGIC description string,
# MAGIC isdelivered string,
# MAGIC isinvoiced string,
# MAGIC isprinted string,
# MAGIC isselected string,
# MAGIC salesrep_id string,
# MAGIC dateordered string,
# MAGIC datepromised string,
# MAGIC dateprinted string,
# MAGIC dateacct string,
# MAGIC c_bpartner_id string,
# MAGIC billto_id string,
# MAGIC c_bpartner_location_id string,
# MAGIC poreference string,
# MAGIC isdiscountprinted string,
# MAGIC c_currency_id string,
# MAGIC paymentrule string,
# MAGIC c_paymentterm_id string,
# MAGIC invoicerule string,
# MAGIC deliveryrule string,
# MAGIC freightcostrule string,
# MAGIC freightamt string,
# MAGIC deliveryviarule string,
# MAGIC m_shipper_id string,
# MAGIC c_charge_id string,
# MAGIC chargeamt string,
# MAGIC priorityrule string,
# MAGIC totallines string,
# MAGIC grandtotal string,
# MAGIC m_warehouse_id string,
# MAGIC m_pricelist_id string,
# MAGIC istaxincluded string,
# MAGIC c_campaign_id string,
# MAGIC c_project_id string,
# MAGIC c_activity_id string,
# MAGIC posted string,
# MAGIC ad_user_id string,
# MAGIC copyfrom string,
# MAGIC dropship_bpartner_id string,
# MAGIC dropship_location_id string,
# MAGIC dropship_user_id string,
# MAGIC isselfservice string,
# MAGIC ad_orgtrx_id string,
# MAGIC user1_id string,
# MAGIC user2_id string,
# MAGIC deliverynotes string,
# MAGIC c_incoterms_id string,
# MAGIC incotermsdescription string,
# MAGIC generatetemplate string,
# MAGIC delivery_location_id string,
# MAGIC copyfrompo string,
# MAGIC fin_paymentmethod_id string,
# MAGIC fin_payment_priority_id string,
# MAGIC rm_pickfromshipment string,
# MAGIC rm_receivematerials string,
# MAGIC rm_createinvoice string,
# MAGIC c_return_reason_id string,
# MAGIC rm_addorphanline string,
# MAGIC a_asset_id string,
# MAGIC calculate_promotions string,
# MAGIC c_costcenter_id string,
# MAGIC convertquotation string,
# MAGIC c_reject_reason_id string,
# MAGIC validuntil string,
# MAGIC quotation_id string,
# MAGIC so_res_status string,
# MAGIC create_polines string,
# MAGIC iscashvat string,
# MAGIC rm_pickfromreceipt string,
# MAGIC em_horcus_internalquotstatus string,
# MAGIC em_horcus_is_old string,
# MAGIC em_horcus_status string,
# MAGIC em_horcus_advantage_card string,
# MAGIC em_horcus_pointsend string,
# MAGIC em_horcus_pointsent string,
# MAGIC em_horcus_init_balan_point string,
# MAGIC em_horcus_promotional_point string,
# MAGIC em_horcus_employee_card string,
# MAGIC em_horcus_dateorder string,
# MAGIC em_horcus_order_status string,
# MAGIC em_horcus_point_allocated string,
# MAGIC em_horcus_last_balan_point string,
# MAGIC em_horcus_last_promot_point string,
# MAGIC em_horcus_last_m_disc_point string,
# MAGIC em_horcus_draftordernumber string,
# MAGIC em_horcus_old_shipment_line string,
# MAGIC em_aprm_addpayment string,
# MAGIC em_obmpr_configuration_id string,
# MAGIC em_obdisc_addpack string,
# MAGIC em_obpos_applications_id string,
# MAGIC em_obpos_sendemail string,
# MAGIC em_obpos_email_status string,
# MAGIC em_obpos_app_cashup_id string,
# MAGIC em_obpos_createdabsolute string,
# MAGIC em_obpos_notinvoiceoncashup string,
# MAGIC em_obpos_rejected_quotat_id string,
# MAGIC em_obkpay_status string,
# MAGIC em_obkpay_hppsession string,
# MAGIC em_obkpay_klarna_reference string,
# MAGIC em_obkpay_order_id string,
# MAGIC em_obkpay_distribute string,
# MAGIC em_obkpay_amount string,
# MAGIC em_obkpay_key string,
# MAGIC em_obkpay_email string,
# MAGIC em_obkpay_phone string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime timestamp,
# MAGIC Year string,
# MAGIC Month string,
# MAGIC Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PRACTICE_RETAIL_SCHEMA_DETAILS_BUKOPMS_Incr/BackUp` (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC ad_user_id
# MAGIC string , ad_client_id
# MAGIC string , ad_org_id
# MAGIC string , isactive
# MAGIC string , created
# MAGIC string , createdby
# MAGIC string , updated
# MAGIC string , updatedby
# MAGIC string , name
# MAGIC string , description
# MAGIC string , password
# MAGIC string , email
# MAGIC string , supervisor_id
# MAGIC string , c_bpartner_id
# MAGIC string , processing
# MAGIC string , emailuser
# MAGIC string , emailuserpw
# MAGIC string , c_bpartner_location_id
# MAGIC string , c_greeting_id
# MAGIC string , title
# MAGIC string , comments
# MAGIC string , phone
# MAGIC string , phone2
# MAGIC string , fax
# MAGIC string , lastcontact
# MAGIC string , lastresult
# MAGIC string , birthday
# MAGIC string , ad_orgtrx_id
# MAGIC string , firstname
# MAGIC string , lastname
# MAGIC string , username
# MAGIC string , default_ad_client_id
# MAGIC string , default_ad_language
# MAGIC string , default_ad_org_id
# MAGIC string , default_ad_role_id
# MAGIC string , default_m_warehouse_id
# MAGIC string , islocked
# MAGIC string , ad_image_id
# MAGIC string , grant_portal_access
# MAGIC string , em_horcus_genericopenbasket
# MAGIC string , em_obmpr_default_pop_role
# MAGIC string , em_obpos_default_pos_role
# MAGIC string , em_horcus_rl_fngrprnt
# MAGIC string , em_horcus_org_fngrprnt
# MAGIC string , operation
# MAGIC string , timestamp
# MAGIC string , transactionid
# MAGIC string , RunDateTime
# MAGIC timestamp , Year
# MAGIC string , Month
# MAGIC string , Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_BASKET_ORDERLINE_OFFER_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT,
# MAGIC horcus_orderline_offer_id string,
# MAGIC ad_client_id string,
# MAGIC ad_org_id string,
# MAGIC isactive string,
# MAGIC created string,
# MAGIC createdby string,
# MAGIC updated string,
# MAGIC updatedby string,
# MAGIC horcus_orderline_id string,
# MAGIC line string,
# MAGIC m_offer_id string,
# MAGIC priceoffer string,
# MAGIC amtoffer string,
# MAGIC priceoffergross string,
# MAGIC totalamt string,
# MAGIC displayedtotalamt string,
# MAGIC horcus_promotionalpoint string,
# MAGIC obdisc_qtyoffer string,
# MAGIC obdisc_identifier string,
# MAGIC obdiscp_coupon_id string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime	timestamp	,
# MAGIC Year	string	,
# MAGIC Month	string	,
# MAGIC Day	string	
# MAGIC )

# COMMAND ----------

# MAGIC %sql create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_PATIENT_DETAILS_BUKOPMS_Incr/BackUp/` (
# MAGIC   CurateStandardRowKey BIGINT,
# MAGIC   id string,
# MAGIC   code string,
# MAGIC   nhs_eligible string,
# MAGIC   nhs_reason string,
# MAGIC   nhs_type string,
# MAGIC   deleted string,
# MAGIC   staff_member string,
# MAGIC   default_shipping_preference string,
# MAGIC   personal_discount string,
# MAGIC   monthly_dd string,
# MAGIC   svoc_staff_member string,
# MAGIC   operation string,
# MAGIC   timestamp string,
# MAGIC   transactionid string,
# MAGIC   RunDateTime timestamp,
# MAGIC   Year string,
# MAGIC   Month string,
# MAGIC   Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PRACTICE_ORGANIZATION_FRANCHISE_INFO_BUKOPMS_Incr/BackUp/`
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC ID string,
# MAGIC STREET string,
# MAGIC COUNTY string,POST_CODE string,CITY string,COUNTRY string,FRANCHISE_NUMBER string,FRANCHISE_BUSINESS_NAME string,FRANCHISE_DIRECTOR string,CREATION_TIMESTAMP string,LASTUPDATE_TIMESTAMP string,DELETED string,ID_PRACTICE string,OPERATION string,TIMESTAMP string,TRANSACTIONID string,RunDateTime timestamp ,Year string ,Month string ,Day string
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE  TABLE IF NOT EXISTS delta.`/mnt/idf-curatestandard/BUKIT/APPMNT/BootsUK_EAB_FUTURE_APPOINTMENTS_APPMNT_Incr/BackUp/`
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT ,
# MAGIC
# MAGIC appointment_date string ,
# MAGIC appointment_from_time string,
# MAGIC appointment_to_time string,
# MAGIC appointment_type string,
# MAGIC service_type string,
# MAGIC datecreated string,
# MAGIC Matching_Status string ,
# MAGIC OPS_ID string,
# MAGIC RunDateTime	timestamp,
# MAGIC Year	string	,
# MAGIC Month	string	,
# MAGIC Day	string	
# MAGIC 				
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_ORDER_CLINICAL_INFO_BUKOPMS_Incr/BackUp` (
# MAGIC CurateStandardRowKey bigint ,
# MAGIC id
# MAGIC string , code
# MAGIC string , type
# MAGIC string , status
# MAGIC string , practice_code
# MAGIC string , customer_code
# MAGIC string , prescription_reference
# MAGIC string , additional_information
# MAGIC string , practice_to_supply_lenses
# MAGIC string , practice_to_supply_frame
# MAGIC string , remote_edging
# MAGIC string , order_uncut_lenses
# MAGIC string , creation_timestamp
# MAGIC string , lastupdate_timestamp
# MAGIC string , due_date
# MAGIC string , delete_type
# MAGIC string , deleted
# MAGIC string , safety_range
# MAGIC string , created_by
# MAGIC string , validated_by
# MAGIC string , validation_date
# MAGIC string , colleague_name
# MAGIC string , goc_number
# MAGIC string , cl_spec_ref
# MAGIC string , order_header_code_parent
# MAGIC string , collection_date
# MAGIC string , order_date
# MAGIC string , basket_code
# MAGIC string , date_placed
# MAGIC string , shipping_type
# MAGIC string , lastupdate_username
# MAGIC string , initial_supply
# MAGIC string , prev_lens_check_date
# MAGIC string , export_timestamp
# MAGIC string , creation_date
# MAGIC string , last_update
# MAGIC string , glazing_fee
# MAGIC string , remade_by
# MAGIC string , frame_reused
# MAGIC string , original_created_by
# MAGIC string , operation
# MAGIC string , timestamp
# MAGIC string , transactionid
# MAGIC string , RunDateTime
# MAGIC timestamp , Year
# MAGIC string , Month
# MAGIC string , Day string 
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_PATIENT_ADDITIONAL_PRESCRIPTION_DETAILS_BUKOPMS_Incr/BackUp` (
# MAGIC CurateStandardRowKey bigint ,
# MAGIC ID
# MAGIC string , CODE
# MAGIC string , SERVICE_ITEM_CODE
# MAGIC string , SERVICE_ITEM_TYPE
# MAGIC string , EARLY_RETEST
# MAGIC string , WALES_BAND
# MAGIC string , EARLY_RETEST_TYPE
# MAGIC string , WALES_BAND_TYPE
# MAGIC string , NHS_VOUCHER_ISSUED
# MAGIC string , RECALL
# MAGIC string , EXTERNAL_PRESCRIPTION
# MAGIC string , EXTERNAL_PRESCRIPTION_FROM
# MAGIC string , EXTERNAL_PRESCRIPTION_DESCRIPT
# MAGIC string , PRESCRIPTION_DATE
# MAGIC string , DELETED
# MAGIC string , SERVICE_TYPE
# MAGIC string , ENHANCED_SERVICE_TYPE
# MAGIC string , SERVICE_DESCRIPTION
# MAGIC string , REFRACTION_PERFORMED
# MAGIC string , CLINICIAL_NAME
# MAGIC string , OPERATION
# MAGIC string , TIMESTAMP
# MAGIC string , TRANSACTIONID
# MAGIC string , RunDateTime
# MAGIC timestamp , Year
# MAGIC string , Month
# MAGIC string , Day string
# MAGIC
# MAGIC )

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists delta.`/mnt/idf-curatestandard/BTUKOPTIT/BUKOPMS/BTCOPT_ORDER_DISCOUNT_INFO_BUKOPMS_Incr/BackUp/` 
# MAGIC (
# MAGIC CurateStandardRowKey BIGINT,
# MAGIC c_orderline_offer_id string,
# MAGIC ad_client_id string,
# MAGIC ad_org_id string,
# MAGIC isactive string,
# MAGIC created string,
# MAGIC createdby string,
# MAGIC updated string,
# MAGIC updatedby string,
# MAGIC c_orderline_id string,
# MAGIC line string,
# MAGIC m_offer_id string,
# MAGIC priceoffer string,
# MAGIC amtoffer string,
# MAGIC priceoffergross string,
# MAGIC totalamt string,
# MAGIC displayedtotalamt string,
# MAGIC em_horcus_promotionalpoint string,
# MAGIC em_obdiscp_coupon_id string,
# MAGIC em_obdisc_qtyoffer string,
# MAGIC em_obdisc_identifier string,
# MAGIC operation string,
# MAGIC timestamp string,
# MAGIC transactionid string,
# MAGIC RunDateTime	timestamp	,
# MAGIC Year	string	,
# MAGIC Month	string	,
# MAGIC Day	string	
# MAGIC )

# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import date
from delta.tables import *

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS Collibra_ReferenceDB;
# MAGIC
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS Collibra_ReferenceDB.CollibraWatermarkTable
# MAGIC (
# MAGIC     ProcessStage STRING,
# MAGIC     LastProcessedTime STRING,
# MAGIC     FileName STRING
# MAGIC  )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-reports/Collibra/CollibraWatermarkTable/";

# COMMAND ----------

dbutils.widgets.text("ProcessStage", "","")
ProcessStage = dbutils.widgets.get("ProcessStage")

dbutils.widgets.text("LastProcessedTime", "","")
LastProcessedTime = dbutils.widgets.get("LastProcessedTime")

dbutils.widgets.text("FileNameList", "","")
FileNameList = dbutils.widgets.get("FileNameList")

# COMMAND ----------

deltaTable = DeltaTable.forPath(spark, "/mnt/idf-reports/Collibra/CollibraWatermarkTable/")
FileNameList=eval(FileNameList)
updatedvalue=[]
for file in FileNameList:
    updatedvalue=[(ProcessStage,LastProcessedTime,file)]
    updatedDF=spark.createDataFrame(updatedvalue,schema=['ProcessStage','LastProcessedTime','FileName']).withColumn("LastProcessedTime",col("LastProcessedTime").cast('Timestamp'))
    deltaTable.alias("events").merge(updatedDF.alias("updates"),"events.ProcessStage = updates.ProcessStage and events.FileName =updates.FileName and  updates.ProcessStage =trim('"+str(ProcessStage)+"') and updates.FileName =trim('"+(file)+"')").whenMatchedUpdate(set = {"LastProcessedTime" : "updates.LastProcessedTime"} )\
    .whenNotMatchedInsert(values ={
            "ProcessStage": "updates.ProcessStage",
      "LastProcessedTime": "updates.LastProcessedTime",
      "FileName":"updates.FileName"}).execute()


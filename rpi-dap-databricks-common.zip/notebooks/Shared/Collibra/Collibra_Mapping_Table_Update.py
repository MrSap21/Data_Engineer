# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from datetime import date
import pandas as pd

# COMMAND ----------

#  ========================================= Synapse Connection ===================================================
jdbcHostname = "npro-dna-northeurope-pre-ssrv01.database.windows.net" 
jdbcDatabase = "npro-data-northeurope-pre-dwh-01"
jdbcPort = 1433
# username="AdminUser"
username = dbutils.secrets.get(scope="Databricks-KeyVault",key="sqlserver-username")
password=dbutils.secrets.get(scope="Databricks-KeyVault",key="sqlserver-password")
hostNameInCertificate = "*.database.windows.net"

jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};user={3};password={4};encrypt=true;trustServerCertificate=false;hostNameInCertificate={5};loginTimeout=30;".format(jdbcHostname, jdbcPort, jdbcDatabase, username, password, hostNameInCertificate)

# below config used for staging data in adls storage for synapse spark connection
stg_account_name = "aznednadevdl01.dfs.core.windows.net" 
# stg_account_key = "uSamRqW6ShfOgzcr4iSHmSmMtIA8T8zwi08nmukODetZgdBLYiK4hw42nEy7MlI1lDBj+lMmyX8HOKrPuh8jcg=="
stg_account_key = dbutils.secrets.get(scope="Databricks-KeyVault",key="ADLS-Storage-Key")
acntInfo = "fs.azure.account.key."+ stg_account_name
spark.conf.set(acntInfo,stg_account_key)

spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "true")
spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "false")
temp_dir="abfss://curate@aznednadevdl01.dfs.core.windows.net/curatestage/synapsetemp/"
#     ============================================================================================================

# COMMAND ----------

SynapsedfNew = spark.read \
    .format("jdbc") \
    .option("url", jdbcUrl) \
    .option("useAzureMSI", "true") \
    .option("dbTable", "[dbo].[CollibraReferenceTable]") \
    .load()
SynapsedfNew.createOrReplaceTempView("Synapsedf")

# COMMAND ----------

def updateCurate_StageCollibraMappingTable(filepath,Source_Schema,Target_Schema,Source_Zone,Target_Zone,IsActive):
  path='/mnt/idf-config/'+filepath
  Df1=spark.read.format('json').option("multiline","true").option('inferSchema','true').load(path,header=True).select("data_destination.type_specific_details.destination_path","data_source.type_specific_details.source_path")
  df = Df1.withColumn('source_path', regexp_replace(col('source_path'), "/", ","))
  df2=df.withColumn("FeedName", split(col("source_path"), ",").getItem(5)) \
.withColumn("SourceName",split(col("source_path"),",").getItem(4))
  value=df2.collect()[0]
  SourceName=value[3]
  if (SourceName=="SAPCAR"):
    df3=df2.withColumn("SourceSystemName", split(col("source_path"), ",").getItem(3)).withColumn("TableName", split(col("source_path"),",").getItem(6))
    value=df3.collect()[0]
    SourceName=value[3]
    FeedName=value[2]
    SourceSystemName=value[4]
    TableName=value[5]
    SourceEntityName=FeedName+'_'+TableName
    Finaltarget='idf-curatestandard_'+SourceSystemName+' > '+SourceName+'_'+FeedName+'_'+TableName
  else:
    df3=df2.withColumn("SourceSystemName", split(col("source_path"), ",").getItem(3))
    value=df3.collect()[0]
    SourceEntityName=value[2]
    SourceSystemName=value[4]
    Finaltarget='idf-curatestandard_'+SourceSystemName+' > '+SourceName+'_'+SourceEntityName
  updatedvalue=[(Source_Zone,Source_Schema, SourceEntityName,Target_Zone,Target_Schema,Finaltarget,IsActive)]
  updatedDF=spark.createDataFrame(updatedvalue,schema=['Source_Zone','Source_Schema', 'Source_EntityName','Target_Zone','Target_Schema','Target_EntityName','IsActive'])
  SyapseNewDF=SynapsedfNew.select('Source_Zone','Source_Schema','Source_EntityName','Target_Zone','Target_Schema','Target_EntityName','IsActive')
  updatedDF=updatedDF.subtract(SyapseNewDF)
  maxvalueDF= spark.sql('select max(DG_ID) as DGID from Synapsedf')
  maxvalue=maxvalueDF.filter(col("DGID").isNotNull())
  if maxvalue.rdd.isEmpty():
    DGID=1000
    updatedDF3=updatedDF.withColumn("DG_ID",lit(DGID)).withColumn("Insert_Date",current_date())
    updatedDF3.createOrReplaceTempView("updatedDF3")
  else:
    Max_Value = maxvalue.select('DGID').first()[0]
    updatedDF=updatedDF.withColumn("DG_ID",lit(Max_Value))
    updatedDF3=updatedDF.withColumn("DG_ID",col("DG_ID")+1).withColumn("Insert_Date",current_date())
    updatedDF3.createOrReplaceTempView("updatedDF3")
  FinalDFF=updatedDF3.select('DG_ID','Source_Zone','Source_Schema','Source_EntityName','Target_Zone','Target_Schema','Target_EntityName','Insert_Date','IsActive')   
  #display(FinalDFF)
  FinalDFF.write.format("jdbc")\
      .option("url",jdbcUrl)\
      .option("useAzureMSI","true")\
      .mode("append")\
      .option("dbTable",'[dbo].[CollibraReferenceTable]')\
      .option("tempDir",temp_dir)\
      .option("maxStrLength","4000")\
      .save()
  return {0}

# COMMAND ----------

def updateCurate_ADLSCollibraMappingTable(filepath,Source_Schema,Source_Zone,Target_Zone,IsActive):
  path='/mnt/idf-config/'+filepath
  
  Df1=spark.read.format('json').option("multiline","true").option('inferSchema','true').load(path,header=True)
  Df= Df1.withColumn("cards",explode("cards").alias("cards")).select(first("cards.data_path").alias("Row"))
  df = Df.withColumn('Row', regexp_replace(col('Row'), "/", ","))
  df2=df.withColumn("Schema", split(col("Row"), ",").getItem(3)) \
  .withColumn("TableName",split(col("Row"),",").getItem(4))
  value=df2.collect()[0]
  SchemaName=value[1]
  TableName=value[2]
  Dfnew= Df1.withColumn("cards",explode("cards").alias("cards")).select(last("cards.output_table").alias("Row"))
  df4=Dfnew.withColumn("Schema", split(col('Row'), '\.').getItem(0)) \
 .withColumn("TableName", split(col('Row'), '\.').getItem(1))
  valuenew=df4.collect()[0]  
  SourceEntityName='idf-curate_'+SchemaName+' > '+TableName
  Target_Schema=valuenew[1]
  Finaltarget=valuenew[2]
  
  updatedvalue=[(Source_Zone,Source_Schema, SourceEntityName,Target_Zone,Target_Schema,Finaltarget,IsActive)]
  updatedDF=spark.createDataFrame(updatedvalue,schema=['Source_Zone','Source_Schema', 'Source_EntityName','Target_Zone','Target_Schema','Target_EntityName','IsActive'])
  SyapseNewDF=SynapsedfNew.select('Source_Zone','Source_Schema','Source_EntityName','Target_Zone','Target_Schema','Target_EntityName','IsActive')
  updatedDF=updatedDF.subtract(SyapseNewDF)
  maxvalueDF= spark.sql('select max(DG_ID) as DGID from Synapsedf')
  maxvalue=maxvalueDF.filter(col("DGID").isNotNull())
  if maxvalue.rdd.isEmpty():
    DGID=1000
    updatedDF3=updatedDF.withColumn("DG_ID",lit(DGID)).withColumn("Insert_Date",current_date())
    updatedDF3.createOrReplaceTempView("updatedDF3")
  else:
    Max_Value = maxvalue.select('DGID').first()[0]
    updatedDF=updatedDF.withColumn("DG_ID",lit(Max_Value))
    updatedDF3=updatedDF.withColumn("DG_ID",col("DG_ID")+1).withColumn("Insert_Date",current_date())
    updatedDF3.createOrReplaceTempView("updatedDF3")
  FinalDFF=updatedDF3.select('DG_ID','Source_Zone','Source_Schema','Source_EntityName','Target_Zone','Target_Schema','Target_EntityName','Insert_Date','IsActive')
  FinalDFF.write.format("jdbc")\
      .option("url",jdbcUrl)\
      .option("useAzureMSI","true")\
      .mode("append")\
      .option("dbTable",'[dbo].[CollibraReferenceTable]')\
      .option("tempDir",temp_dir)\
      .option("maxStrLength","4000")\
      .save()
  return {0}
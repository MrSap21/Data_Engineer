# Databricks notebook source
# MAGIC %sql 
# MAGIC delete from Collibra_ReferenceDB.CollibraFileDetails 

# COMMAND ----------

#  ========================================= Synapse Connection ===================================================
jdbcHostname = "npro-dna-northeurope-pre-ssrv01.database.windows.net" 
jdbcDatabase = "npro-data-northeurope-pre-dwh-01"
jdbcPort = 1433
# username="AdminUser"
username = dbutils.secrets.get(scope="Databricks-KeyVault",key="sqlserver-username")
password=dbutils.secrets.get(scope="Databricks-KeyVault",key="sqlserver-password")
hostNameInCertificate = "*.database.windows.net"

jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};user={3};password={4};encrypt=true;trustServerCertificate=false;hostNameInCertificate={5};loginTimeout=30;".format(jdbcHostname, jdbcPort, jdbcDatabase, username, password, hostNameInCertificate)

# below config used for staging data in adls storage for synapse spark connection
stg_account_name = "aznednadevdl01.dfs.core.windows.net" 
# stg_account_key = "uSamRqW6ShfOgzcr4iSHmSmMtIA8T8zwi08nmukODetZgdBLYiK4hw42nEy7MlI1lDBj+lMmyX8HOKrPuh8jcg=="
stg_account_key = dbutils.secrets.get(scope="Databricks-KeyVault",key="ADLS-Storage-Key")
acntInfo = "fs.azure.account.key."+ stg_account_name
spark.conf.set(acntInfo,stg_account_key)

spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "true")
spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "false")
temp_dir="abfss://curate@aznednadevdl01.dfs.core.windows.net/curatestage/synapsetemp/"
#     ============================================================================================================

# COMMAND ----------

Synapsedfnew = spark.read \
    .format("jdbc") \
    .option("url", jdbcUrl) \
    .option("useAzureMSI", "true") \
    .option("dbTable", "[dbo].[CollibraReferenceTableArchive]") \
    .load()
Synapsedfnew.write \
      .format("jdbc")\
      .option("url",jdbcUrl)\
      .option("useAzureMSI","true")\
      .mode("overwrite")\
      .option("truncate", "true")\
      .option("dbTable","[dbo].[CollibraReferenceTableArchive]")\
      .option("tempDir",temp_dir)\
      .option("maxStrLength","4000")\
      .save() 

# COMMAND ----------

Synapsedf = spark.read \
    .format("jdbc") \
    .option("url", jdbcUrl) \
    .option("useAzureMSI", "true") \
    .option("dbTable", "[dbo].[CollibraReferenceTable]") \
    .load()

Synapsedf.write \
      .format("jdbc") \
      .option("url",jdbcUrl) \
      .option("useAzureMSI","true") \
      .mode("append") \
      .option("dbTable","[dbo].[CollibraReferenceTableArchive]") \
      .option("tempDir",temp_dir) \
      .option("maxStrLength","4000") \
      .save() 

# COMMAND ----------

SynapsedfF = spark.read \
    .format("jdbc") \
    .option("url", jdbcUrl) \
    .option("useAzureMSI", "true") \
    .option("dbTable", "[dbo].[CollibraReferenceTable]") \
    .load()
SynapsedfF.write \
      .format("jdbc")\
      .option("url",jdbcUrl)\
      .option("useAzureMSI","true")\
      .mode("overwrite")\
      .option("truncate", "true")\
      .option("dbTable","[dbo].[CollibraReferenceTable]")\
      .option("tempDir",temp_dir)\
      .option("maxStrLength","4000")\
      .save() 
# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import Window
from datetime import date
from delta.tables import *

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS Collibra_ReferenceDB;
# MAGIC
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS Collibra_ReferenceDB.CollibraFileDetails
# MAGIC (
# MAGIC     FileName STRING,
# MAGIC     FilePath STRING
# MAGIC  )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-reports/Collibra/CollibraFileDetails/";

# COMMAND ----------

# MAGIC %run "./Collibra_Mapping_Table_Update"

# COMMAND ----------

deltaTable = DeltaTable.forPath(spark, "/mnt/idf-reports/Collibra/CollibraFileDetails/")
import glob
import os
import pandas as pd
os.chdir(r'/dbfs/mnt/idf-config/')
files = glob.glob('CurateStandard/**/*.json',recursive = True) 
for filepath in files:
  fileName_absolute = os.path.basename(filepath)
  filePath_absolute=os.path.dirname(filepath)
  fileName=spark.sql("select * from Collibra_ReferenceDB.CollibraFileDetails where FileName =='"+str(fileName_absolute)+"' and FilePath =='"+str(filePath_absolute)+"'")
  fileName=fileName.toPandas()
  file = fileName_absolute in fileName.values
  if (file == True):
                     print('The FileName already exsists in the Delta Table')
  else:
                     IsActive='True'
                     Source_Schema=''
                     Target_Schema=''
                     Source_Zone='Curate_Stage'
                     Target_Zone='Curate_Standard'
                     updateCurate_StageCollibraMappingTable(filepath,Source_Schema,Target_Schema,Source_Zone,Target_Zone,IsActive)
                     spark.sql("Insert INTO Collibra_ReferenceDB.CollibraFileDetails(FileName,FilePath) values ('"+str(fileName_absolute)+"','"+str(filePath_absolute)+"') ")
                 

# COMMAND ----------

deltaTable = DeltaTable.forPath(spark, "/mnt/idf-reports/Collibra/CollibraFileDetails/")
import glob
import os
import pandas as pd
os.chdir(r'/dbfs/mnt/idf-config/')
files = glob.glob('CurateSynapse/**/*.json',recursive = True) 
for filepath in files:
  fileName_absolute = os.path.basename(filepath)
  filePath_absolute=os.path.dirname(filepath)
  fileName=spark.sql("select * from Collibra_ReferenceDB.CollibraFileDetails where FileName =='"+str(fileName_absolute)+"' and FilePath =='"+str(filePath_absolute)+"' ")
  fileName=fileName.toPandas()
  file = fileName_absolute in fileName.values
  if (file == True):
                     print('The FileName already exsists in the Delta Table')
  else:
                     IsActive='True'
                     Source_Schema=''
                     Source_Zone='Curate_ADLS'
                     Target_Zone='Consumption'
                     updateCurate_ADLSCollibraMappingTable(filepath,Source_Schema,Source_Zone,Target_Zone,IsActive)
                     spark.sql("Insert INTO Collibra_ReferenceDB.CollibraFileDetails (FileName,FilePath) values ('"+str(fileName_absolute)+"','"+str(filePath_absolute)+"')")
                 
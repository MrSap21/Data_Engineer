# Databricks notebook source
dbutils.widgets.text("Location", "","")
location = dbutils.widgets.get("Location")

dbutils.widgets.text("TransactionYear", "","")
transaction_year = dbutils.widgets.get("TransactionYear")

dbutils.widgets.text("TransactionMonth", "","")
transaction_month = dbutils.widgets.get("TransactionMonth")


file_list = ['ETopupEVoucher', 'GiftCardTransaction', 'LoyaltyAccountEarning', 'Payment', 'Transaction', 'TransactionAdjustment', 'TransactionCoupon', 'TransactionCreditClaim', 'TransactionLineItem', 'TransactionLineItemAdjustment', 'TransactionLoyaltyAccount', 'TransactionPayment', 'TransactionPromotion']



# COMMAND ----------

table_name='Transaction'
dest_path = '/mnt/idf-curate/'+str(location)+'/'+str(table_name)+'/TransactionYear='+str(transaction_year)+'/TransactionMonth='+str(transaction_month)
print(dest_path)

df_curation=spark.read.format("delta").load(dest_path)
# c=df_curation.count()
# print(c)

# COMMAND ----------

file_dict ={}
final_list =[]
total_size =0
c=0
for table_name in file_list:
  dest_path = dest_path = '/mnt/idf-curate/'+str(location)+'/'+str(table_name)+'/TransactionYear='+str(transaction_year)+'/TransactionMonth='+str(transaction_month)
  df_curation=spark.read.format("delta").load(dest_path)
  c=df_curation.count()
  file_dict = { 'Table Name' : table_name, 'TransactionYear': transaction_year,'TransactionMonth': transaction_month,'Data Count': str(c)}
  final_list.append(file_dict)
  
# print(final_list)



# COMMAND ----------

df = spark.createDataFrame(final_list)
df.createOrReplaceTempView("df")

#display(df)


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from df

# COMMAND ----------

#FOR CURATE:

#df_curation=spark.read.format("delta").load("/mnt/idf-curate/SAPCOE/SAPCAR/IF_07680/Transaction/TransactionYear=2018/TransactionMonth=09/")

# COMMAND ----------

#df_curation.createOrReplaceTempView('tran_df')



# COMMAND ----------

# %sql
# select distinct transactionday from tran_df 

# COMMAND ----------

df_curation_test1=spark.read.format("delta").load('/mnt/idf-curate/SAPCOE/SAPCAR/IF_07680/Payment/TransactionYear=2018/TransactionMonth=11')

# COMMAND ----------

df_curation_test2=spark.read.format("delta").load('/mnt/idf-curate/SAPCOE/SAPCAR/IF_07680/Payment/TransactionYear=2018/TransactionMonth=12')

# COMMAND ----------

df_curation_test1.createOrReplaceTempView('tran_df_test1')
df_curation_test2.createOrReplaceTempView('tran_df_test2')


# COMMAND ----------

# MAGIC %sql
# MAGIC select transactiondate , count(1) from (select * from tran_df_test1 union select * from tran_df_test2) 
# MAGIC where transactiondate >= '2018-11-01' and transactiondate <= '2018-12-31'
# MAGIC group by transactiondate order by 1

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC  
# MAGIC -- select * from sapcar_curation.Transaction where rundate>='2021-09-06T10:45:00' and rundate>='2021-09-06T10:39:00'

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC  
# MAGIC select count(1) as cnt,'Transaction','batch12' as bactch   from sapcar_curation.Transaction where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'TransactionAdjustment' ,'batch12' as bactch from sapcar_curation.TransactionAdjustment where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'TransactionLineItemAdjustment','batch12' as bactch  from sapcar_curation.TransactionLineItemAdjustment
# MAGIC where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'TransactionCreditClaim','batch12' as bactch  from sapcar_curation.TransactionCreditClaim
# MAGIC where rundate>='2021-09-07T09:37:00' 
# MAGIC union all
# MAGIC select count(1) as cnt,'TransactionLoyaltyAccount' ,'batch12' as bactch from sapcar_curation.TransactionLoyaltyAccount
# MAGIC where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'TransactionCoupon','batch12' as bactch   from sapcar_curation.TransactionCoupon
# MAGIC where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'TransactionPromotion','batch12' as bactch  from sapcar_curation.TransactionPromotion
# MAGIC where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'TransactionPayment' ,'batch12' as bactch from sapcar_curation.TransactionPayment
# MAGIC where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'Payment','batch12' as bactch from sapcar_curation.Payment
# MAGIC where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'LoyaltyAccountEarning' ,'batch12' as bactch from sapcar_curation.LoyaltyAccountEarning
# MAGIC where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'GiftCardTransaction' ,'batch12' as bactch from sapcar_curation.GiftCardTransaction
# MAGIC where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'ETopupEVoucher' ,'batch12' as bactch from sapcar_curation.ETopupEVoucher
# MAGIC where rundate>='2021-09-07T09:37:00'
# MAGIC union all
# MAGIC select count(1) as cnt,'TransactionLineItem','batch12' as bactch  from sapcar_curation.TransactionLineItem
# MAGIC where rundate>='2021-09-07T09:37:00'

# COMMAND ----------

# %sql

# select count(1) as cnt,'TransactionLineItem','batch12' as bactch  from sapcar_curation.TransactionLineItem
# where rundate>='2021-09-07T08:15:00'

# COMMAND ----------


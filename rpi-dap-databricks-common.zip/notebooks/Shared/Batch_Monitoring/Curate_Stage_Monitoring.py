# Databricks notebook source
dbutils.widgets.text("Location", "","")
location = dbutils.widgets.get("Location")

dbutils.widgets.text("RunDate", "","")
run_date = dbutils.widgets.get("RunDate")

dbutils.widgets.text("History/Incremental", "","")
hist_inc = dbutils.widgets.get("History/Incremental")

file_list = ['ETopupEVoucher', 'GiftCardTransaction', 'LoyaltyAccountEarning', 'Payment', 'Transaction', 'TransactionAdjustment', 'TransactionCoupon', 'TransactionCreditClaim', 'TransactionLineItem', 'TransactionLineItemAdjustment', 'TransactionLoyaltyAccount', 'TransactionPayment', 'TransactionPromotion']



# COMMAND ----------

def convertFloatToDecimal(f=0.0, precision=2):
    '''
    Convert a float to string of decimal.
    precision: by default 2.
    If no arg provided, return "0.00".
    '''
    return ("%." + str(precision) + "f") % f

# COMMAND ----------

file_dict ={}
final_list =[]
total_size =0
for table_name in file_list:
  dest_path = '/mnt/idf-curatestage/'+str(location)+'/'+str(table_name)+'/'+str(hist_inc)+'/'+str(run_date)+'000000'
  try:
    ls_result = dbutils.fs.ls( dest_path)
    invalid_location_flag =False
  except:
    invalid_location_flag =True
#     print('Invalid Location')
    data_count = 0
    file_dict = { 'Table Name' : table_name, 'Data Count': str(data_count), 'Message': 'Invalid Location' }
    final_list.append(file_dict)
  
  if invalid_location_flag == False:
    if len(ls_result) > 0 :
      data_count = 0
      data_count =str(spark.read.format('csv').option('header',True).load(dest_path).count())
      file_size = 0
      for i in ls_result:
        file_size += int(i.size)
      total_size += file_size
      file_dict = { 'Table Name' : table_name, 'Data Count': str(data_count), 'Message': '' }
      final_list.append(file_dict)
    else:
      print('Data not available for '+ table_name)
      file_dict = { 'Table Name' : table_name, 'Data Count': '0', 'Message': 'Data Not Available' }
      final_list.append(file_dict)

size_in_mb = convertFloatToDecimal((total_size/1024.0**2), 6)
size_list =[]
size_dict = {'Total Size in MB': size_in_mb}
size_list.append(size_dict)

# COMMAND ----------

df = spark.createDataFrame(final_list)
df.createOrReplaceTempView("df")

#display(df)


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from df 

# COMMAND ----------

size_df = spark.createDataFrame(size_list)
size_df.createOrReplaceTempView("size_df")
#display(size_df)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from size_df

# COMMAND ----------

#FOR CURATE:

# df_curation=spark.read.format("delta").load("/mnt/idf-curate/SAPCOE/SAPCAR/IF_07680/Transaction/TransactionYear=2018/TransactionMonth=11/")

# COMMAND ----------

# df_curation.createOrReplaceTempView('tran_df')



# COMMAND ----------

# %sql
# select distinct transactionday from tran_df 

# COMMAND ----------

# df_test = spark.read.format("csv").load('/mnt/idf-cleansed/SAPCOE/SAPCAR/IF_07680/Inc_Batch_10_20201005_20201005', header = True,delimiter='|')
# df_test.createOrReplaceTempView('df_tes')


# COMMAND ----------

# %sql
# select distinct _c3  from df_tes 
# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime
from pyspark.sql.window import Window
import os

# COMMAND ----------

dbutils.widgets.text("BatchName", "","")
BatchName = dbutils.widgets.get("BatchName")

BatchPath = '/mnt/idf-cleansed/SAPCOE/SAPCAR/IF_07680/' + BatchName
ProcessedPath = '/mnt/idf-cleansed/SAPCOE/SAPCAR/IF_07680/Processed/' + BatchName


print(BatchPath)
print(ProcessedPath)

# COMMAND ----------

#dbutils.fs.mv(BatchPath,ProcessedPath,recurse=True)
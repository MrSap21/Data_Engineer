# Databricks notebook source
# MAGIC %scala
# MAGIC
# MAGIC val jdbcUsername= dbutils.secrets.get(scope="ADLS-Connection",key="accenture-databricks-access-name")
# MAGIC val jdbcPassword =dbutils.secrets.get(scope="ADLS-Connection",key="accenture-databricks-access-pwd")

# COMMAND ----------

# MAGIC %scala
# MAGIC val jdbcHostname = "prod-dna-pr-ne-sqlsvr01.database.windows.net"
# MAGIC val jdbcPort = 1433
# MAGIC val jdbcDatabase = "prod-dna-platform-pr-ne-tempsqlw01"
# MAGIC
# MAGIC // Create the JDBC URL without passing in the user and password parameters.
# MAGIC val jdbcUrl = s"jdbc:sqlserver://${jdbcHostname}:${jdbcPort};database=${jdbcDatabase}"
# MAGIC
# MAGIC // Create a Properties() object to hold the parameters.
# MAGIC import java.util.Properties
# MAGIC val connectionProperties = new Properties()
# MAGIC
# MAGIC connectionProperties.put("user", s"${jdbcUsername}")
# MAGIC connectionProperties.put("password", s"${jdbcPassword}")

# COMMAND ----------

# MAGIC %scala
# MAGIC val blobStorage = "dnaprdatalakenesa01.dfs.core.windows.net"
# MAGIC val blobContainer = "curate"
# MAGIC val blobAccessKey =  "7Nk+t+hBf9mzCGgRxnwNQ6TawXPojIbQlSkF0d4PDyhhuTf/8r9CJ6H5EK4q13nGVZEHlt+TyeN7ZGWUMay0EA=="
# MAGIC val tempDir = "abfss://" + blobContainer + "@" + blobStorage +"/tempDirs"

# COMMAND ----------

# MAGIC %scala
# MAGIC val acntInfo = "fs.azure.account.key."+ blobStorage
# MAGIC sc.hadoopConfiguration.set(acntInfo, blobAccessKey)

# COMMAND ----------

# MAGIC %scala
# MAGIC //Azure Synapse related settings
# MAGIC val dwDatabase = "prod-dna-platform-pr-ne-tempsqlw01"
# MAGIC val dwServer = "prod-dna-pr-ne-sqlsvr01.database.windows.net"
# MAGIC val dwUser = dbutils.secrets.get(scope = "ADLS-Connection", key = "accenture-databricks-access-name")
# MAGIC val dwPass = dbutils.secrets.get(scope = "ADLS-Connection", key = "accenture-databricks-access-pwd")
# MAGIC val dwJdbcPort =  "1433"
# MAGIC val dwJdbcExtraOptions = "encrypt=true;trustServerCertificate=true;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
# MAGIC val sqlDwUrl = "jdbc:sqlserver://" + dwServer + ":" + dwJdbcPort + ";database=" + dwDatabase + ";user=" + dwUser+";password=" + dwPass + ";$dwJdbcExtraOptions"
# MAGIC val sqlDwUrlSmall = "jdbc:sqlserver://" + dwServer + ":" + dwJdbcPort + ";database=" + dwDatabase + ";user=" + dwUser+";password=" + dwPass

# COMMAND ----------

# MAGIC %scala
# MAGIC // val sql_query = "select distinct transactiondate from ser_retail.[EtopUpEvoucher]"
# MAGIC // where transactiondate between '2018-11-01'  and  '2019-03-31'
# MAGIC val sql_query = "select count(1) as cnt,'Transaction' as tablename ,'batch12' as bactch from ser_retail.[Transaction] where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'TransactionAdjustment' as tablename ,'batch12' as bactch from ser_retail.TransactionAdjustment where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'TransactionLineItemAdjustment' as tablename ,'batch12' as bactch from ser_retail.TransactionLineItemAdjustment where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'TransactionCreditClaim' as tablename ,'batch12' as bactch from ser_retail.TransactionCreditClaim where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'TransactionLoyaltyAccount' as tablename,'batch12' as bactch from ser_retail.TransactionLoyaltyAccount where rundate>='2021-09-07T09:37:00'  union all select count(1) as cnt,'TransactionCoupon' as tablename,'batch12' as bactch from ser_retail.TransactionCoupon where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'TransactionPromotion' as tablename,'batch12' as bactch from ser_retail.TransactionPromotion where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'TransactionPayment' as tablename ,'batch12' as bactch from ser_retail.TransactionPayment where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'Payment' as tablename,'batch12' as bactch from ser_retail.Payment where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'LoyaltyAccountEarning' as tablename ,'batch12' as bactch from ser_retail.LoyaltyAccountEarning where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'GiftCardTransaction' as tablename ,'batch12' as bactch from ser_retail.GiftCardTransaction where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'ETopupEVoucher' as tablename ,'batch12' as bactch from ser_retail.ETopupEVoucher where rundate>='2021-09-07T09:37:00' union all select count(1) as cnt,'TransactionLineItem' as tablename,'batch12' as bactch  from ser_retail.TransactionLineItem where rundate>='2021-09-07T09:37:00'"

# COMMAND ----------

# MAGIC %scala
# MAGIC val df = spark.read.format("com.databricks.spark.sqldw") .option("url", sqlDwUrlSmall) .option("tempDir", tempDir) .option("useAzureMSI","True") .option("query", sql_query) .load()

# COMMAND ----------

# MAGIC %scala
# MAGIC display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(1) from sapcar_curation.Transaction where cast(transactiondate as date) between '2018-04-01'  and  '2019-09-30'

# COMMAND ----------

# where cast(transactiondate as date) between '2018-11-01'  and  '2019-03-31'
# where cast(transactiondate as date) <= '2019-03-31'

# COMMAND ----------

# MAGIC %scala
# MAGIC df1.write.format("com.databricks.spark.sqldw").option("url", sqlDwUrlSmall).option("dbtable", "ser_retail.Transaction").option("useAzureMSI","True").option("tempdir", tempDir).mode("append").save()

# COMMAND ----------

# MAGIC %python
# MAGIC display(dbutils.fs.ls("/databricks-datasets"))

# COMMAND ----------

# MAGIC %scala
# MAGIC val df1 = spark.read.format("parquet").load("/mnt/idf-curate/Staging/SAPCOE/SAPCAR/IF_07680/History/Transaction/")

# COMMAND ----------

# MAGIC %scala
# MAGIC val df1=spark.sql("select * from sapcar_curation.Transaction where cast(transactiondate as date) > '2018-08-31'")

# COMMAND ----------

# MAGIC %scala
# MAGIC  = df1.createOrReplaceTempView("sapcar_curation")

# COMMAND ----------

# MAGIC %python
# MAGIC dbutils.fs.ls("/mnt/idf-curate/etl/SAPCOE/SAPCAR/IF_07680")

# COMMAND ----------

# union all select count(1) as cnt,'TransactionAdjustment' ,'batch12' as bactch from ser_retail.TransactionAdjustment where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionLineItemAdjustment','batch12' as bactch from ser_retail.TransactionLineItemAdjustment where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionCreditClaim','batch12' as bactch from ser_retail.TransactionCreditClaim where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionLoyaltyAccount' ,'batch12' as bactch from ser_retail.TransactionLoyaltyAccount where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionCoupon','batch12' as bactch from ser_retail.TransactionCoupon where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionPromotion','batch12' as bactch from ser_retail.TransactionPromotion where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionPayment' ,'batch12' as bactch from ser_retail.TransactionPayment where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'Payment','batch12' as bactch from ser_retail.Payment where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'LoyaltyAccountEarning' ,'batch12' as bactch from ser_retail.LoyaltyAccountEarning where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'GiftCardTransaction' ,'batch12' as bactch from ser_retail.GiftCardTransaction where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'ETopupEVoucher' ,'batch12' as bactch from ser_retail.ETopupEVoucher where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionLineItem','batch12' as bactch  from ser_retail.TransactionLineItem where rundate>='2021-09-03T12:50:00'"

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC val syn_test = "select count(1) as cnt,'Transaction','batch12' as bactch from ser_retail.Transaction where rundate >= '2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionAdjustment' ,'batch12' as bactch from ser_retail.TransactionAdjustment where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionLineItemAdjustment','batch12' as bactch from ser_retail.TransactionLineItemAdjustment where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionCreditClaim','batch12' as bactch from ser_retail.TransactionCreditClaim where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionLoyaltyAccount' ,'batch12' as bactch from ser_retail.TransactionLoyaltyAccount where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionCoupon','batch12' as bactch from ser_retail.TransactionCoupon where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionPromotion','batch12' as bactch from ser_retail.TransactionPromotion where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionPayment' ,'batch12' as bactch from ser_retail.TransactionPayment where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'Payment','batch12' as bactch from ser_retail.Payment where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'LoyaltyAccountEarning' ,'batch12' as bactch from ser_retail.LoyaltyAccountEarning where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'GiftCardTransaction' ,'batch12' as bactch from ser_retail.GiftCardTransaction where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'ETopupEVoucher' ,'batch12' as bactch from ser_retail.ETopupEVoucher where rundate>='2021-09-03T12:50:00' union all select count(1) as cnt,'TransactionLineItem','batch12' as bactch  from ser_retail.TransactionLineItem where rundate>='2021-09-03T12:50:00'"

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC val test_df = spark.read.format("com.databricks.spark.sqldw").option("url", sqlDwUrlSmall).option("tempDir", tempDir).option("useAzureMSI","True").option("query", syn_test).load()

# COMMAND ----------


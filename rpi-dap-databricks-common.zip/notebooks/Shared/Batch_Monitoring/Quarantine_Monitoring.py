# Databricks notebook source
df_curation=spark.read.format("parquet").load("/mnt/idf-curatequarantine/SAPCOE/SAPCAR/IF_07680/History/ETopupEVoucher/*")

df_curation.createOrReplaceTempView('tran_df')


# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from tran_df

# COMMAND ----------

dbutils.widgets.text("Location", "","")
location = dbutils.widgets.get("Location")

dbutils.widgets.text("StartDate", "","")
start_date = dbutils.widgets.get("StartDate")

dbutils.widgets.text("EndDate", "","")
end_date = dbutils.widgets.get("EndDate")

file_list = ['ETopupEVoucher', 'GiftCardTransaction', 'LoyaltyAccountEarning', 'Payment', 'Transaction', 'TransactionAdjustment', 'TransactionCoupon', 'TransactionCreditClaim', 'TransactionLineItem', 'TransactionLineItemAdjustment', 'TransactionLoyaltyAccount', 'TransactionPayment', 'TransactionPromotion']

# COMMAND ----------

file_dict ={}
final_list =[]
total_size =0
count=0
for table_name in file_list:
  dest_path = dest_path = '/mnt/idf-curatequarantine/'+str(location)+'/'+str(table_name)+'/*'
  df_curation=spark.read.format("parquet").load(dest_path)
  df_curation.createOrReplaceTempView('tran_df')
  count=spark.sql("select * from tran_df where transactiondate >="+start_date+" and transactiondate <="+end_date).count()
  file_dict = { 'Table Name' : table_name, 'StartDate': start_date,'EndDate': end_date,'Data Count': str(c)}
  final_list.append(file_dict)

# COMMAND ----------

df = spark.createDataFrame(final_list)
df.createOrReplaceTempView("df")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from df
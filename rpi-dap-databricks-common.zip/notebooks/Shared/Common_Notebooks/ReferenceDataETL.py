# Databricks notebook source
# DBTITLE 1,Import Packages
import pyspark.sql.functions as F
import time
import datetime
import sys

# COMMAND ----------

# DBTITLE 1,Log Table Transaction Function
def update_logtable(ProcessStage, EntityName, AssetId, FeedId, ETLRunId, BatchId, SourceName, FeedName, Status, Error, RunTime, TriggerId, SourceCount, TargetCount, Remark):
    spark.sql("INSERT INTO RPI_LOGGING.RPI_COMMON_LOGGING VALUES ('"+ str(ProcessStage) +"','"+ str(EntityName) + "','"+ str(AssetId) +"','"+ str(FeedId) +"','"+ str(ETLRunId) +"','"+ str(BatchId) +"','"+ str(SourceName) +"','"+ str(FeedName) +"','"+ str(Status) +"','"+ str(Error) +"','"+ str(RunTime) +"','"+ str(TriggerId) +"','"+ str(SourceCount) +"','"+ str(TargetCount) +"','"+ str(Remark) +"');")

# COMMAND ----------

# DBTITLE 1,Log Process Start
processStage = "CurateADLS"
entityName = "refdata.json"
assetId = None
ETLRunId = None
sourceName = "ReferenceData"
feedName = "RefLov, RefLovSet"
status_started = "Started"
error = None
triggerId = "SparkId"
sourceCount = None
targetCount = None
remark = None
current_utc_timestamp = int(time.time())
batchId = "ReferenceDataETL_"+str(current_utc_timestamp)
runTime = datetime.datetime.now()
update_logtable(processStage,entityName,assetId,ETLRunId,current_utc_timestamp,batchId, \
                sourceName,feedName,status_started,error,runTime,triggerId,sourceCount,targetCount,remark)

# COMMAND ----------

# DBTITLE 1,Read Ref Data
ref_data_path = dbutils.widgets.get("ref_data_path")
try:
    refDF = spark.read.format('json').load(ref_data_path)
except Exception as e:
    error_msg = "Error reading file - "+ref_data_path+"\n "+str(e)
    print(error_msg)
    update_logtable(processStage,entityName,assetId,ETLRunId,current_utc_timestamp,batchId, \
                sourceName,feedName,"Failed",error_msg,runTime,triggerId,sourceCount,targetCount,remark)
    raise

refLovHierarchySetDF = refDF.select("ExportBy", "ExportTimestamp", F.explode_outer("RefLOVHierarchySet").alias('RefLOVHierarchySet'))
refLovSetComboDF = refDF.select("ExportBy", "ExportTimestamp", F.explode_outer("RefLOVSet").alias('RefLOVSet'))

refLovSetComboDF = refLovSetComboDF.select("ExportBy", "ExportTimestamp", "RefLOVSet.ActiveFlag", \
                                            "RefLOVSet.LOVSetDescription", "RefLOVSet.LOVSetID", \
                                            "RefLOVSet.LOVSetName", "RefLOVSet.LOVSetSequence", \
                                            "RefLOVSet.RecordSourceID", F.explode_outer('RefLOVSet.RefLOV').alias('RefLOV'), \
                                            "RefLOVSet.RefLOVSetExport")

refLovSetComboDF = refLovSetComboDF.select("ExportBy", "ExportTimestamp", "ActiveFlag", \
                                      "LOVSetDescription", "LOVSetID", \
                                      "LOVSetName", "LOVSetSequence", \
                                      "RecordSourceID", F.col("RefLOV.ActiveFlag").alias('RefLOVActiveFlag'), \
                                      "RefLOV.LOVDescription", "RefLOV.LOVID", \
                                      "RefLOV.LOVKey", "RefLOV.LOVName", \
                                      "RefLOV.LOVSequence", F.col("RefLOV.RecordSourceID").alias("RefLOVRecordSourceID"), \
                                      F.explode_outer("RefLOVSetExport").alias('RefLOVSetExport'))

refLovSetComboDF = refLovSetComboDF.select("ExportBy", "ExportTimestamp", "ActiveFlag", \
                                      "LOVSetDescription", "LOVSetID", \
                                      "LOVSetName", "LOVSetSequence", \
                                      "RecordSourceID", "RefLOVActiveFlag", \
                                      "LOVDescription", "LOVID", \
                                      "LOVKey", "LOVName", \
                                      "LOVSequence", "RefLOVRecordSourceID", \
                                      "RefLOVSetExport.TargetLayerID") \
                                    .withColumn("ETLRunLogId", F.lit(None)) \
                                    .withColumn("DTCreated", F.col("ExportTimestamp").cast("timestamp")) \
                                    .withColumn("UserCreated", F.lit("DataBricksBatch"))

# COMMAND ----------

# DBTITLE 1,Prepare refLov dataset
refLovDF = refLovSetComboDF.select("LOVId", "LOVSetId", "LOVKey", \
    							   "LOVName","LOVDescription","LOVSequence", \
                  				   "RefLOVRecordSourceID", "ETLRunLogId", \
                         		   "RefLOVActiveFlag", "DTCreated", "UserCreated") \
							.withColumnRenamed("RefLOVActiveFlag", "ActiveFlag") \
							.withColumnRenamed("RefLOVRecordSourceID", "RecordSourceID") \
                            .drop_duplicates() \
                            .dropna(subset="LOVID") \
                            .fillna( {'LOVSequence':0, 'LOVDescription':'' } )

refLovDF.createOrReplaceTempView("src_refLov")

# COMMAND ----------

# DBTITLE 1,Prepare refLovSet dataset
refLovSetDF = refLovSetComboDF.select("LOVSetId", "LOVSetName", "LOVSetDescription", \
                                      "LOVSetSequence","RecordSourceId","ActiveFlag", \
                         		      "ETLRunLogId", "DTCreated", "UserCreated") \
                              .drop_duplicates() \
                              .dropna(subset=("LOVSetId", "RecordSourceId")) \
                              .fillna( {'LOVSetSequence':0, 'LOVSetDescription':'' } )

refLovSetDF.createOrReplaceTempView("src_refLovSet")

# COMMAND ----------

# DBTITLE 1,Create RefLov if not exists
# MAGIC %sql 
# MAGIC
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS curate_enterprise.REFLov
# MAGIC (
# MAGIC 	LOVId int NOT NULL,
# MAGIC 	 LOVSetId   int  NOT NULL,
# MAGIC 	 LOVKey  string  NOT NULL,
# MAGIC 	 LOVName  string NOT NULL,
# MAGIC 	 LOVDescription   string , 
# MAGIC 	 LOVSequence   int  ,
# MAGIC 	 RecordSourceId   int  NOT NULL,
# MAGIC 	 ETLRunLogId   int  ,
# MAGIC 	 ActiveFlag   int  NOT NULL,
# MAGIC 	 DTCreated   timestamp  ,
# MAGIC 	 UserCreated   string  
# MAGIC )  
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Reference/REFLov/"

# COMMAND ----------

# DBTITLE 1,Create RefLovSet if not exists
# MAGIC %sql
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS curate_enterprise.RefLOVSet  
# MAGIC (
# MAGIC 	 LOVSetId    		int   	  NOT NULL,
# MAGIC 	 LOVSetName    		string    NOT NULL,
# MAGIC 	 LOVSetDescription    	string    ,
# MAGIC 	 LOVSetSequence    	int   	  ,
# MAGIC 	 RecordSourceId     	int   	  NOT NULL,
# MAGIC 	 ActiveFlag    		int   	  NOT NULL,
# MAGIC 	 DTCreated    		timestamp      ,
# MAGIC 	 UserCreated    	string    ,
# MAGIC 	 ETLRunLogId    	int   	  
# MAGIC )
# MAGIC USING DELTA
# MAGIC LOCATION "/mnt/idf-curate/Reference/REFLovSet/"

# COMMAND ----------

# DBTITLE 1,Create RefLovSetInfo view based on refLov and refLovSet
# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW curate_enterprise.REFLovSetInfo  ( LOVId ,  LOVSetId ,  LOVKey ,  LOVName ,  LOVDescription ,  LOVSequence ,  LOVRecordSourceId ,  LOVSetName ,  LOVSetDescription ,  LOVSetSequence )
# MAGIC AS SELECT 
# MAGIC r.LOVId ,
# MAGIC r.LOVSetId ,
# MAGIC r.LOVKey ,
# MAGIC r.LOVName ,
# MAGIC r.LOVDescription ,
# MAGIC r.LOVSequence ,
# MAGIC r.RecordSourceId ,
# MAGIC rs.LOVSetName ,
# MAGIC rs.LOVSetDescription ,
# MAGIC rs.LOVSetSequence 
# MAGIC FROM curate_enterprise.RefLOV r
# MAGIC INNER JOIN curate_enterprise.REFLovSet rs
# MAGIC ON r.LOVSetId=rs.LOVSetId
# MAGIC AND r.RecordSourceId =rs.RecordSourceId 
# MAGIC AND r.ActiveFlag='1'
# MAGIC AND rs.ActiveFlag='1'; 
# MAGIC

# COMMAND ----------

# DBTITLE 1,Merge Data into curate_enterprise.refLovSet
try:
    spark.sql("""
            MERGE INTO curate_enterprise.reflovset
            USING src_refLovSet
            ON  curate_enterprise.reflovset.LOVSetId = src_refLovSet.LOVSetId 
            and curate_enterprise.reflovset.RecordSourceId = src_refLovSet.RecordSourceId
            WHEN MATCHED THEN
            UPDATE SET
                LOVSetId = src_refLovSet.LOVSetId,
                LOVSetName = src_refLovSet.LOVSetName,
                LOVSetDescription = src_refLovSet.LOVSetDescription,
                LOVSetSequence = src_refLovSet.LOVSetSequence,
                RecordSourceID = src_refLovSet.RecordSourceID,
                ActiveFlag = src_refLovSet.ActiveFlag,
                ETLRunLogId = src_refLovSet.ETLRunLogId,
                DTCreated = src_refLovSet.DTCreated,
                UserCreated = src_refLovSet.UserCreated
            WHEN NOT MATCHED
            THEN INSERT (
                LOVSetId,
                LOVSetName,
                LOVSetDescription,
                LOVSetSequence,
                RecordSourceID,
                ActiveFlag,
                ETLRunLogId,
                DTCreated,
                UserCreated
            )
            VALUES (
                src_refLovSet.LOVSetId,
                src_refLovSet.LOVSetName,
                src_refLovSet.LOVSetDescription,
                src_refLovSet.LOVSetSequence,
                src_refLovSet.RecordSourceID,
                src_refLovSet.ActiveFlag,
                src_refLovSet.ETLRunLogId,
                src_refLovSet.DTCreated,
                src_refLovSet.UserCreated
            )"""
    )
except Exception as e:
    error_msg = "Merge statement in refLovSet failed \n "+str(e)
    print(error_msg)
    update_logtable(processStage,entityName,assetId,ETLRunId,current_utc_timestamp,batchId, \
                sourceName,feedName,"Failed",error_msg,runTime,triggerId,sourceCount,targetCount,remark)
    raise

# COMMAND ----------

# DBTITLE 1,Merge Data into curate_enterprise.refLov
try:
    spark.sql("""
                MERGE INTO curate_enterprise.reflov
                USING src_refLov
                ON curate_enterprise.reflov.LOVId = src_refLov.LOVId
                WHEN MATCHED THEN
                UPDATE SET
                    LOVId = src_refLov.LOVId,
                    LOVSetId = src_refLov.LOVSetId,
                    LOVKey = src_refLov.LOVKey,
                    LOVName = src_refLov.LOVName,
                    LOVDescription = src_refLov.LOVDescription,
                    LOVSequence = src_refLov.LOVSequence,
                    RecordSourceID = src_refLov.RecordSourceID,
                    ETLRunLogId = src_refLov.ETLRunLogId,
                    ActiveFlag = src_refLov.ActiveFlag,
                    DTCreated = src_reflov.DTCreated,
                    UserCreated = src_reflov.UserCreated
                WHEN NOT MATCHED
                THEN INSERT (
                    LOVId,
                    LOVSetId,
                    LOVKey,
                    LOVName,
                    LOVDescription,
                    LOVSequence,
                    RecordSourceID,
                    ETLRunLogId,
                    ActiveFlag,
                    DTCreated,
                    UserCreated
                )
                VALUES (
                    src_refLov.LOVId,
                    src_refLov.LOVSetId,
                    src_refLov.LOVKey,
                    src_refLov.LOVName,
                    src_refLov.LOVDescription,
                    src_refLov.LOVSequence,
                    src_refLov.RecordSourceID,
                    src_refLov.ETLRunLogId,
                    src_refLov.ActiveFlag,
                    src_refLov.DTCreated,
                    src_refLov.UserCreated
                )"""
    )
except Exception as e:
    error_msg = "Merge statement in refLov failed \n "+str(e)
    print(error_msg)
    update_logtable(processStage,entityName,assetId,ETLRunId,current_utc_timestamp,batchId, \
                sourceName,feedName,"Failed",error_msg,runTime,triggerId,sourceCount,targetCount,remark)
    raise

# COMMAND ----------

# DBTITLE 1,Log Finish
status_finished = "Finished"
current_utc_timestamp_end = int(time.time())
runTimeEnd = datetime.datetime.now()
update_logtable(processStage,entityName,assetId,ETLRunId,current_utc_timestamp_end,batchId, \
                sourceName,feedName,status_finished,error,runTimeEnd,triggerId,sourceCount,targetCount,remark) 

# COMMAND ----------

# DBTITLE 1,Exit Notebook
dbutils.notebook.exit(0)

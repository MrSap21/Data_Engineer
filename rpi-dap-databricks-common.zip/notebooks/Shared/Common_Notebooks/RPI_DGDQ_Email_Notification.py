# Databricks notebook source
from datetime import date,datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import concat,col,concat_ws

d = datetime.strptime(str(date.today()), "%Y-%m-%d")
s = d.strftime('%Y%m%d')

df1=spark.read.format("csv").option("header","true").option("delimiter","|").option("inferSchema","true").load("mnt/email-notification-logs/*error*")
df1.createOrReplaceTempView("ERROR_TABLE")
dfTemp=spark.sql("""CREATE or replace TEMPORARY VIEW ERROR_TABLE_VIEW AS (select ROW_NUMBER() OVER (order by Run_Date desc,Module_Name desc) as Sr_No,Module_Name,Error_Details,Log_File_Path,Run_Date,Event_Date,Error_Message_Count from (SELECT Module_Name,Error_Details,Log_File_Path,Run_Date,Cast(Event_Timestamp as date) as Event_Date ,count(*) as Error_Message_Count  FROM ERROR_TABLE group by Module_Name,Error_Details,Log_File_Path,Run_Date,Cast(Event_Timestamp as date) order by Module_Name desc));""")


# COMMAND ----------

# MAGIC %sql
# MAGIC select *  from ERROR_TABLE_VIEW

# COMMAND ----------

from datetime import date,datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import concat,col,concat_ws

df12=spark.sql("select '<tr><td> '||Sr_No as Sr_No,Module_Name,Error_Details,Event_Date,Log_File_Path,Error_Message_Count||' </td></tr>' as Error_Message_Count,Run_Date as date1 from ERROR_TABLE_VIEW")

df2=df12.filter(df12.date1 == s)
df4=df2.select(concat_ws('</td><td>',df2.Sr_No,df2.Module_Name,df2.Error_Details,df2.Event_Date,df2.Log_File_Path,df2.Error_Message_Count).alias("Error_Details"))
#df4.display()

df_Error_List=df4.rdd.map(lambda x: x[0]).collect()
df_error_Detils=''.join(df_Error_List)
#print(df_error_Detils)

# COMMAND ----------

from pyspark.sql.functions import col
import json
from pyspark.sql.types import *
from pyspark.sql.functions import *
import sys
import os
import requests
from requests.auth import HTTPDigestAuth
import json
from pyspark.sql.types import *
from pyspark.sql.functions import col
from pyspark.sql.functions import *
from pyspark.sql import Row

#following parameters getting from Pipeline
dbutils.widgets.text("First_Name", '', '')
First_Name = dbutils.widgets.get('First_Name')
dbutils.widgets.text("Last_Name", '', '')
Last_Name = dbutils.widgets.get('Last_Name')
dbutils.widgets.text("Description", '', '')
Description = dbutils.widgets.get('Description')
dbutils.widgets.text("Impact", '', '')
Impact = dbutils.widgets.get('Impact')
dbutils.widgets.text("Urgency", '', '')
Urgency = dbutils.widgets.get('Urgency')
dbutils.widgets.text("Status", '', '')
Status = dbutils.widgets.get('Status')
dbutils.widgets.text("Reported_Source", '', '')
Reported_Source = dbutils.widgets.get('Reported_Source')
dbutils.widgets.text("Service_Type", '', '')
Service_Type = dbutils.widgets.get('Service_Type')
dbutils.widgets.text("Module_Name", '', '')
Module_Name = dbutils.widgets.get('Module_Name')

#below variable is getting derived in Command 1

Error=df_error_Detils

print(First_Name)
print(Last_Name)
print(Description)
print(Impact)
print(Urgency)
print(Status)
print(Reported_Source)
print(Service_Type)
print(Module_Name)
print(Error)

# COMMAND ----------

if Error != '':
    LogicAppURL = "https://prod-11.northeurope.logic.azure.com:443/workflows/edf2559675ef402598c85e7186c7196a/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=oTO6HAi3P2vAdPE3PnTIEwbgPoyUWXw336EAVtFnkm8"
    data ={"First_Name":First_Name,
        "Last_Name":Last_Name,
        "Description":Description,
        "Impact":Impact,
        "Urgency":Urgency,
        "Status":Status,
        "Reported_Source":Reported_Source,
        "Service_Type":Service_Type,
        "Module_Name":Module_Name,
        "Error_Details":Error
      }
    myResponse = requests.post(LogicAppURL,params = data)
else:
    print("No Error Message. Hence skipped the Logic App Trigger")

# COMMAND ----------


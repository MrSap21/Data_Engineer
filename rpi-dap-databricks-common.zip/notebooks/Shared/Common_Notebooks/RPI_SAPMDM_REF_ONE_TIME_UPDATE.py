# Databricks notebook source
from pyspark.sql import *
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS SAPMDM_CURATION.SITE_REF (
# MAGIC RefSet STRING NOT NULL,
# MAGIC RefCode STRING NOT NULL,
# MAGIC RefDesc STRING ,
# MAGIC SCDActiveFlag STRING ,
# MAGIC RecordStartDate timestamp ,
# MAGIC RecordEndDate timestamp )

# COMMAND ----------

SITE_REF = spark.read.option('header','true').format('csv').option('delimiter','|').load('/mnt/self-serve/Test/SITE_REF/')
# display(SITE_REF)

# COMMAND ----------

from pyspark.sql.functions import lit,current_timestamp 
from pyspark.sql.types import  TimestampType
SITE_REF=SITE_REF.withColumn("SCDActiveFlag",lit('Y')).withColumn("RecordStartDate",current_timestamp()).withColumn("RecordEndDate",lit(None).cast(TimestampType()))

display(SITE_REF)

# COMMAND ----------

SITE_REF=SITE_REF.dropDuplicates(['RefSet', 'RefCode','RefDesc'])

SITE_REF.createOrReplaceTempView('SITE_REF')
# display(SITE_REF)

# COMMAND ----------

# MAGIC %sql
# MAGIC Insert into SAPMDM_CURATION.SITE_REF  (select RefSet,RefCode,RefDesc,SCDActiveFlag,RecordStartDate,RecordEndDate from SITE_REF )

# COMMAND ----------

# %sql
# select * from  SAPMDM_CURATION.SITE_REF
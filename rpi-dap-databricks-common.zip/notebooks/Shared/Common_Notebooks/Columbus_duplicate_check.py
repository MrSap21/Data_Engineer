# Databricks notebook source
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_site GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_product GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_siterole GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_servicecentre GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_adversereaction GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_PRESCRIPTIONSERVICE GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_StockResponse GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_InterStoreTransferListSKUExcluded GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey,gridtimestamp from columbus_curation.curateadls_Grid GROUP BY sourcekey,gridtimestamp HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey,gridcellvaluetimestamp from columbus_curation.curateadls_GridCellValue GROUP BY sourcekey,gridcellvaluetimestamp HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_ManualOrderReason GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_OrderType GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_PharmacyStore GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_PharmacyProduct GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_CENTRALOFFICE GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_EXEMPTION GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_LABELINSTRUCTION GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_FORMULARY GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_DOSAGEUNIT GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_LEVYFEE GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_PRESCRIBERTYPE GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_medicalcondition GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_pharmacyproductsku GROUP BY sourcekey HAVING COUNT(1) > 
# MAGIC select COUNT(1),PharmacyProductID, startdate, enddate from columbus_curation.curateadls_averagetradesellingprice GROUP BY PharmacyProductID, startdate, enddate HAVING COUNT(1) > 1
# MAGIC %sql 
# MAGIC select COUNT(1),sourcekey from columbus_curation.curateadls_productproductsku GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql
# MAGIC select COUNT(1),storecode,productcode from columbus_curation.curateadls_PRODUCTUSAGE GROUP BY storecode,productcode HAVING COUNT(1) >1 
# MAGIC %sql 
# MAGIC select COUNT(1),sourcekey from columbus_curation.curateadls_basictariffsellingprice GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql 
# MAGIC select COUNT(1),PharmacyProductID,PharmacyProductSKUID,Region,startdate,enddate,PreferredType from columbus_curation.curateadls_preferredproductsku GROUP BY PharmacyProductID,PharmacyProductSKUID,Region,startdate,enddate,PreferredType HAVING COUNT(1) > 1
# MAGIC %sql
# MAGIC select COUNT(1),sourcekey from columbus_curation.curateadls_Patientcommunity GROUP BY sourcekey HAVING COUNT(1) >1 
# MAGIC %sql select COUNT(1),GlobalCodeAndParameterElementParentID,GlobalCodeAndParameterElementChildID from columbus_curation.curateadls_GlobalCodeAndParameterElementRelation GROUP BY GlobalCodeAndParameterElementParentID,GlobalCodeAndParameterElementChildID HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_tote GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),GridID,GridType, gridLayerTimestamp from columbus_curation.curateadls_Gridlayer GROUP BY GridID,GridType, gridLayerTimestamp HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_UnsuppliedPurchaseOrderLine GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_goodsreceipt GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),ProductSKUCode,StoreCode,SourceKey from columbus_curation.curateadls_stock GROUP BY ProductSKUCode,StoreCode,SourceKey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),GridID,GridAxisType,GridAxisDate,GridAxisTimestamp from columbus_curation.curateadls_Gridaxis GROUP BY GridID,GridAxisType,GridAxisDate,GridAxisTimestamp HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),SourceKey from columbus_curation.curateadls_electronicprescription GROUP BY SourceKey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),GridCode, StoreCode,gridstoretimestamp from columbus_curation.curateadls_Gridstore GROUP BY GridCode,StoreCode,gridstoretimestamp HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_stockadjustmentreason GROUP BY SourceKey HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey,LOVPartyTypeID  from columbus_curation.curateadls_party GROUP BY SourceKey,LOVPartyTypeID HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),ProductCode, StoreCode  from columbus_curation.curateadls_overstock GROUP BY ProductCode, StoreCode HAVING COUNT(1) > 1 --removed duplicates based on sourcekey for overstock 
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_purchaseorder GROUP BY sourcekey  HAVING COUNT(1) > 1 --removed duplicates based on sourcesystemid for purchaseorder 
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_patient GROUP BY sourcekey  HAVING COUNT(1) > 1 --removed duplicates based on sourcekey for overstock 
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_prescriber GROUP BY sourcekey  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_supplier GROUP BY sourcekey  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_PatientStore GROUP BY sourcekey  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcesystemid from columbus_curation.curateadls_PatientRegistration GROUP BY sourcesystemid  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_actualproductpack GROUP BY sourcekey  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_patientAdverseReaction GROUP BY sourcekey  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),PatientPartyRoleID from columbus_curation.curateadls_PatientPreference GROUP BY PatientPartyRoleID  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),ActualProductPackID,BarCode,sourcekey from columbus_curation.curateadls_pharmacyProductBarCode GROUP BY ActualProductPackID,BarCode,sourcekey  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcesystemid from columbus_curation.curateadls_Prescriptiongroup GROUP BY sourcesystemid  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_patientcommunitymembership GROUP BY sourcekey  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),GridAxisID,GridAxisValue,SequenceNumber,SourceKey,GridAxisThresholdTimestamp from columbus_curation.curateadls_gridaxisthreshold GROUP BY GridAxisID,GridAxisValue,SequenceNumber,SourceKey,GridAxisThresholdTimestamp HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),GridCellPositionX,GridCellPositionY,GridLayerID,GridCellValueID,sourcekey,GridCellTimestamp   from columbus_curation.curateadls_gridcell GROUP BY GridCellPositionX,GridCellPositionY,GridLayerID,GridCellValueID,sourcekey,GridCellTimestamp   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),SourceKey, GoodsReceiptID   from columbus_curation.curateadls_handlingunit GROUP BY SourceKey, GoodsReceiptID   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),ActualProductPackID,startdate,enddate  from columbus_curation.curateadls_tradesellingprice GROUP BY ActualProductPackID,startdate,enddate   HAVING COUNT(1) > 1
# MAGIC
# MAGIC %sql select COUNT(1),PIPCode  from columbus_curation.curateadls_dispensingsupportpharmacystock GROUP BY PIPCode   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_MEDICINESUSEREVIEWFORM GROUP BY sourcekey   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),PharmacyProductSKUID,ActualProductPackID,Region,PreferredType  from columbus_curation.curateadls_preferredactualproductpack GROUP BY PharmacyProductSKUID,ActualProductPackID,Region,PreferredType   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),ActualProductPackID,ServiceCentreCode  from columbus_curation.curateadls_PharmacyProductLogistics GROUP BY ActualProductPackID,ServiceCentreCode   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),PIPCode,WarehouseCode  from columbus_curation.curateadls_StockAvailabilty GROUP BY PIPCode,WarehouseCode   HAVING COUNT(1) > 1
# MAGIC
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_DispensingSupportPharmacyStockMovement GROUP BY sourcekey   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_DispensingSupportPharmacyStockOperation GROUP BY sourcekey   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_MessageReason GROUP BY sourcekey   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_MessageNotification GROUP BY sourcekey   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_prescriptionForm GROUP BY sourcekey   HAVING COUNT(1) > 1 -- removed duplicates based on Sourcesystemid
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_prescriptionorder GROUP BY sourcekey   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_prescribeditem GROUP BY sourcekey   HAVING COUNT(1) > 1 -- removed based on sourcesystemid for _prescribeditem
# MAGIC %sql select COUNT(1),CustomizationKey, FullReference,logicalName  from columbus_curation.curateadls_globalcodeandparameterelement GROUP BY CustomizationKey, FullReference,logicalName HAVING COUNT(1) > 1  -- removed based ID columns 
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_Patientmedicalcondition GROUP BY sourcekey  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),GlobalCodeAndParameterElementID,AttributeName  from columbus_curation.curateadls_GLOBALCODEANDPARAMETERELEMENTVALUE GROUP BY GlobalCodeAndParameterElementID ,AttributeName  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),GridCode, StoreCode,gridstoretimestamp from columbus_curation.curateadls_Gridstore GROUP BY GridCode,StoreCode,gridstoretimestamp HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_StockAdjustmentItem GROUP BY sourcekey  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_StockItem GROUP BY sourcekey  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),OverStockID,ProductSKuCode from columbus_curation.curateadls_overStockItem GROUP BY OverStockID,ProductSKuCode
# MAGIC HAVING COUNT(1) > 1 -- remove based on sourcekey
# MAGIC %sql select COUNT(1),PIPCode,LocationCode from columbus_curation.curateadls_DispensingSupportPharmacyStockLocation GROUP BY PIPCode,LocationCode
# MAGIC HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),sourcekey from columbus_curation.curateadls_PrescriptionOrder GROUP BY sourcekey
# MAGIC HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),PrescriptionGroupCode,Storecode from columbus_curation.curateadls_ElectronicPharmacistsInformationFormLabel GROUP BY PrescriptionGroupCode,Storecode HAVING COUNT(1) > 1  --remove based on sourcekey
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_bag GROUP BY sourcekey   HAVING COUNT(1) > 1  --removed based on creation_time
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_bagpart GROUP BY sourcekey   HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),OrderStatusUpdateCode,PurchaseOrderCode  from columbus_curation.curateadls_OrderStatusUpdate GROUP BY OrderStatusUpdateCode,PurchaseOrderCode   HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),sourcekey,AdditionalEndorsementID  from columbus_curation.curateadls_OutOfPocketExpenses GROUP BY sourcekey,AdditionalEndorsementID   HAVING COUNT(1) > 1 --got duplicate nulls ,ignored and ran exception
# MAGIC %sql select COUNT(1),sourcekey,CreationTime  from columbus_curation.curateadls_replenishmentorderline GROUP BY sourcekey,CreationTime   HAVING COUNT(1) > 1 --removing duplicates based on sourcesystemid
# MAGIC %sql select COUNT(1),SourceKey, AdditionalEndorsementID  from columbus_curation.curateadls_NoCheaperStockObtainable GROUP BY SourceKey, AdditionalEndorsementID   HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey, IsDispensedAdditionalEndorsementIndicator  from columbus_curation.curateadls_additionalendorsement GROUP BY SourceKey, IsDispensedAdditionalEndorsementIndicator   HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),STORECODE, PRODUCTSKUCODE , PRODUCTCODE  from columbus_curation.curateadls_productskuusage GROUP BY STORECODE, PRODUCTSKUCODE , PRODUCTCODE   HAVING COUNT(1) > 1  -- remove based on sourcekey 
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_DispensingSupportPharmacyTracking GROUP BY SourceKey   HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_Dispensingevent GROUP BY SourceKey   HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_DailyDispensedQuantity GROUP BY SourceKey  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_PrescriptionFormNote GROUP BY SourceKey  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey, AdditionalEndorsementID  from columbus_curation.curateadls_specialitem GROUP BY SourceKey, AdditionalEndorsementID
# MAGIC   HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_PrescribedProduct GROUP BY SourceKey
# MAGIC HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),DispensedItemCode,PrescribedItemCode,ReplenishmentOrderLineID,DispensedItemID  from columbus_curation.curateadls_ReplenishmentItem GROUP BY DispensedItemCode,PrescribedItemCode,ReplenishmentOrderLineID,DispensedItemID  HAVING COUNT(1) > 1 --remove based on sourcekey
# MAGIC
# MAGIC %sql select COUNT(1),sourcesystemid  from columbus_curation.curateadls_PrescriptionExemption GROUP BY sourcesystemid  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),Sourcekey,OrderedActualProductPackID  from columbus_curation.curateadls_BagPartItem GROUP BY Sourcekey,OrderedActualProductPackID  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_clinicalcheck GROUP BY sourcekey   HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey,patientcode  from columbus_curation.curateadls_Pharmacyservice GROUP BY SourceKey,patientcode  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey,CountListID  from columbus_curation.Curateadls_CountListItem GROUP BY SourceKey,CountListID  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.Curateadls_CountList GROUP BY SourceKey  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey,CreationTime  from columbus_curation.Curateadls_DispensingSupportPharmacyPrescription GROUP BY SourceKey,CreationTime  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_instalment GROUP BY SourceKey  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(*),sourcekey from columbus_curation.curateadls_ClinicalCheckDuration GROUP BY sourcekey  HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_instalmentitem GROUP BY SourceKey  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),EPrescribedItemCode,PrescriptionFormCode  from columbus_curation.Curateadls_MasterPrescribedItem GROUP BY ePrescribedItemCode,PrescriptionFormCode  HAVING COUNT(1) > 1 --remove duplicates based on ID 
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_parametervalue GROUP BY SourceKey  HAVING COUNT(1) > 1 
# MAGIC %sql
# MAGIC select COUNT(*),sourcekey,OldDispensedPharmacyProductSKUID,OldDispensedActualProductPackID from columbus_curation.curateadls_OrderUpdateNotification GROUP BY sourcekey,OldDispensedPharmacyProductSKUID,OldDispensedActualProductPackID  HAVING COUNT(1) > 1  -- need to sourcekey with max id but ID not available 
# MAGIC %sql select COUNT(1),parametercode  from columbus_curation.Curateadls_parameter GROUP BY parametercode  HAVING COUNT(1) > 1 -- parametercode is null here , proceed with exception
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_DispensedReconciled GROUP BY SourceKey  HAVING COUNT(1) > 1 
# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_advanceshipmentnotice GROUP BY SourceKey  HAVING COUNT(1) > 1  --removed based on sourcesystemid
# MAGIC %sql select COUNT(1),sourcesystemid  from columbus_curation.Curateadls_owing GROUP BY sourcesystemid   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_baglocation GROUP BY sourcekey   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_stockmovement GROUP BY sourcekey   HAVING COUNT(1) > 1
# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_stockmovementitem GROUP BY sourcekey   HAVING COUNT(1) > 1
# MAGIC %sql
# MAGIC select COUNT(*),sourcekey from columbus_curation.curateadls_OrderUpdateNotification GROUP BY sourcekey HAVING COUNT(1) > 1  -- need to sourcekey with max sourcesystemid 

# COMMAND ----------

# MAGIC %sql select COUNT(1),sourcekey,AdditionalEndorsementID  from columbus_curation.curateadls_OutOfPocketExpenses GROUP BY sourcekey,AdditionalEndorsementID   HAVING COUNT(1) > 1 --got duplicate nulls ,ignored and ran exception

# COMMAND ----------

# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_parametervalue GROUP BY SourceKey  HAVING COUNT(1) > 1 

# COMMAND ----------

# MAGIC %sql select *  from columbus_curation.curateadls_specialitem  where sourcekey='97694' and  AdditionalEndorsementID='1000150530'

# COMMAND ----------

# MAGIC %sql select COUNT(1),EPrescribedItemCode,PrescriptionFormCode  from columbus_curation.Curateadls_MasterPrescribedItem GROUP BY ePrescribedItemCode,PrescriptionFormCode  HAVING COUNT(1) > 1 --remove duplicates based on ID 

# COMMAND ----------

# MAGIC %sql select *  from columbus_curation.Curateadls_MasterPrescribedItem  where PrescriptionFormCode='20023310000008706' and CurrentEventNumber='0'

# COMMAND ----------

# MAGIC %sql select *  from columbus_curation.Curatestandard_Master_Prescribed_Item  where Prescription_Form_Code='20023310000008706'

# COMMAND ----------

# MAGIC %sql
# MAGIC select COUNT(*),sourcekey,dosageunitid from columbus_curation.curateadls_PharmacyUncataloguedProduct GROUP BY sourcekey,dosageunitid HAVING COUNT(1) > 1  -- need to sourcekey with max sourcesystemid 

# COMMAND ----------

# MAGIC %sql
# MAGIC select COUNT(*),sourcekey from columbus_curation.curateadls_OrderUpdateNotification GROUP BY SourceSystemID HAVING COUNT(1) > 1  -- need to sourcekey with max sourcesystemid 

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from columbus_curation.curateadls_OrderUpdateNotification where sourcekey='20009870000152729'

# COMMAND ----------

# MAGIC %sql select COUNT(1),parametercode  from columbus_curation.Curateadls_parameter GROUP BY parametercode  HAVING COUNT(1) > 1 

# COMMAND ----------

# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_advanceshipmentnotice GROUP BY SourceKey  HAVING COUNT(1) > 1 

# COMMAND ----------

# MAGIC %sql select COUNT(1),PrescribedItemCode,PrescriptionFormCode  from columbus_curation.Curateadls_MasterPrescribedItem GROUP BY PrescribedItemCode,PrescriptionFormCode  HAVING COUNT(1) > 1 

# COMMAND ----------

# MAGIC %sql 
# MAGIC --select COUNT(1),sourcekey  from columbus_curation.curateadls_clinicalcheck GROUP BY sourcekey   HAVING COUNT(1) > 1 
# MAGIC --select COUNT(1),sourcekey from columbus_curation.curateadls_PharmacyStore GROUP BY sourcekey HAVING COUNT(1) > 1
# MAGIC --select COUNT(1),sourcesystemid from columbus_curation.curateadls_Prescriptiongroup GROUP BY sourcesystemid  HAVING COUNT(1) > 1
# MAGIC select COUNT(*),sourcekey from columbus_curation.curateadls_ClinicalCheckDuration GROUP BY sourcekey  HAVING COUNT(1) > 1

# COMMAND ----------

# MAGIC %sql select COUNT(1),SourceKey  from columbus_curation.curateadls_outofpocket GROUP BY SourceKey  HAVING COUNT(1) > 1 

# COMMAND ----------

# MAGIC %sql select COUNT(1),SourceKey,patientcode  from columbus_curation.curateadls_Pharmacyservice GROUP BY SourceKey,patientcode  HAVING COUNT(1) > 1 

# COMMAND ----------

# MAGIC %sql select * from columbus_curation.curateadls_specialitem where sourcekey='215965' and AdditionalEndorsementID ='1005085041'

# COMMAND ----------

# MAGIC %sql
# MAGIC update columbus_curation.curateadls_gridaxis set ActiveFlag ='Y';

# COMMAND ----------

# MAGIC %sql
# MAGIC update columbus_curation.curateadls_gridaxis set ActiveFlag ='Y' where concat(Sourcekey,Gridtimestamp) in (Select concat(Sourcekey,max(Gridtimestamp)) from columbus_curation.curateadls_gridaxis group by Sourcekey);
# MAGIC --Select concat(Sourcekey,max(Gridtimestamp)) from columbus_curation.curateadls_grid  where sourcekey='00221'  group by Sourcekey

# COMMAND ----------

# MAGIC
# MAGIC %sql select COUNT(*) from columbus_curation.curateadls_parametervalue --GROUP BY sourcekey HAVING COUNT(1) > 1 

# COMMAND ----------

# to remove duplicates 
from pyspark.sql.window import Window
from pyspark.sql.functions import *
curatetable = spark.sql("select * from columbus_curation.curateadls_OrderUpdateNotification")
curatetable1 = curatetable.withColumn('rank',dense_rank().over(Window.partitionBy('sourcekey').orderBy(col('sourcesystemid').desc())))

curatetable2=curatetable1.withColumn("RecordStatusFlag", when(curatetable1.rank == "1","I").otherwise("D"))
udatedDF=curatetable2.drop('rank')
udatedDF=curatetable2.drop('rank').write.format("delta").mode("overwrite").option("overwriteSchema", "true").partitionBy("LOVRECORDSOURCEID","YEAR","MONTH","DAY").saveAsTable("columbus_curation.curateadls_OrderUpdateNotification")
#  cast if key column is sourecsystem id

# COMMAND ----------

# MAGIC %sql delete from  columbus_curation.curateadls_OrderUpdateNotification where RecordStatusFlag='D'

# COMMAND ----------

# MAGIC %sql select COUNT(1),sourcekey  from columbus_curation.curateadls_prescriptionForm GROUP BY sourcekey  HAVING COUNT(1) > 1 -- removed duplicates based on Sourcesystemid

# COMMAND ----------

from pyspark.sql.functions import when
df3=spark.read.format("parquet").option("Header","True").load("/mnt/idf-cleansed/BUKIT/BTCCLMBSPMS/BootsUK_PRESCRIBED_ITEM_BTCCLMBSPMS_Incr/Incremental")
df3.createOrReplaceTempView("stage")
#display(df3)

#df2=spark.read.parquet('/mnt/idf-curatestage/BUKIT/BTCCLMBSPMS/BootsUK_PRESCRIBED_ITEM_BTCCLMBSPMS_Incr/Incremental')
#df2.createOrReplaceTempView("cleansed")

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct dosage_directions from stage

# COMMAND ----------

from pyspark.sql.functions import when
df3=spark.read.parquet("/mnt/idf-cleansed/BUKIT/BTCCLMBSPMS/BootsUK_MUR_FORM_BTCCLMBSPMS_Incr/Incremental")
df3.createOrReplaceTempView("cleansed")

df= df3.withColumn("REVIEW_DATE", when(df3.REVIEW_DATE == "0020-05-23 23:00:00","1900-01-01 00:00:00").otherwise(df3.REVIEW_DATE))

#display(df)
df.createOrReplaceTempView("cleansed_1")

df.write.parquet('/mnt/idf-curatestage/BUKIT/BTCCLMBSPMS/BootsUK_MUR_FORM_BTCCLMBSPMS_Incr/Incremental/20220624010000')
df2=spark.read.parquet('/mnt/idf-curatestage/BUKIT/BTCCLMBSPMS/BootsUK_MUR_FORM_BTCCLMBSPMS_Incr/Incremental/20220624010000')
display(df2)

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct REVIEW_DATE from cleansed order by REVIEW_DATE asc

# COMMAND ----------

from pyspark.sql.functions import when
df3=spark.read.parquet("/mnt/idf-cleansed/BUKIT/BTCCLMBSPMS/BootsUK_PATIENT_BTCCLMBSPMS_Incr/Incremental")
df3.createOrReplaceTempView("cleansed")

df= df3.withColumn("LAST_MUR_DATE", when(df3.LAST_MUR_DATE == "0020-07-18 23:00:00","1900-01-01 00:00:00").otherwise(df3.LAST_MUR_DATE))

#display(df)
df.createOrReplaceTempView("cleansed_1")

df.write.parquet('/mnt/idf-curatestage/BUKIT/BTCCLMBSPMS/BootsUK_PATIENT_BTCCLMBSPMS_Incr/Incremental/20220624010000')
df2=spark.read.parquet('/mnt/idf-curatestage/BUKIT/BTCCLMBSPMS/BootsUK_PATIENT_BTCCLMBSPMS_Incr/Incremental/20220624010000')
display(df2)

# COMMAND ----------

df2=spark.read.parquet('/mnt/idf-curatestage/BUKIT/BTCCLMBSPMS/BootsUK_PATIENT_BTCCLMBSPMS_Incr/Incremental/20220624000000')
display(df2)

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct LAST_MUR_DATE from cleansed_1 order by LAST_MUR_DATE asc

# COMMAND ----------

from pyspark.sql.functions import when
df3=spark.read.parquet("/mnt/idf-cleansed/BUKIT/BTCCLMBSCOM/BootsUK_GCP_ELEMENT_BTCCLMBSCOM_Incr/Incremental")
df3.createOrReplaceTempView("cleansed")

df= df3.withColumn("VALIDITY_START", when(df3.VALIDITY_START == "0001-01-01 00:00:00","1900-01-01 00:00:00").when(df3.VALIDITY_START == "0001-02-01 00:00:00","1900-01-01 00:00:00").otherwise(df3.VALIDITY_START))

#display(df)
df.createOrReplaceTempView("cleansed_1")

df.write.parquet('/mnt/idf-curatestage/BUKIT/BTCCLMBSCOM/BootsUK_GCP_ELEMENT_BTCCLMBSCOM_Incr/Incremental/20220624010000')
df2=spark.read.parquet('/mnt/idf-curatestage/BUKIT/BTCCLMBSCOM/BootsUK_GCP_ELEMENT_BTCCLMBSCOM_Incr/Incremental/20220624010000')
display(df2)

# COMMAND ----------

# MAGIC %sql
# MAGIC select distinct VALIDITY_START from cleansed_1 order by VALIDITY_START asc
# MAGIC --select * from cleansed_1 where REVIEW_DATE='0020-05-23 23:00:00'
# MAGIC --update cleansed set LAST_MUR_DATE='1900-01-01T00:00:00.000'  where LAST_MUR_DATE='0020-07-18 23:00:00'
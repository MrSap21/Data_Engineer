# Databricks notebook source
try:
    jdbcHostname = "npro-dna-northeurope-pre-ssrv01.database.windows.net"
    jdbcDatabase = "DNAdMetadataSDB01"
    jdbcPort = 1433



# jdbcUsername ="db-serviceacc-loader"
# jdbcPassword = dbutils.secrets.get(scope="ADLS-Connection",key="db-serviceacc-loader-pre-prod")

#jdbcUsername = "DataFactory"
    jdbcUsername = dbutils.secrets.get(scope="Databricks-KeyVault", key="sqlserver-username")
    jdbcPassword = dbutils.secrets.get(scope="Databricks-KeyVault",key="sqlserver-password")



    jdbc_url = "jdbc:sqlserver://"+ jdbcHostname +":"+ str(jdbcPort) +";database="+ jdbcDatabase +";user="+ jdbcUsername +"@npro-dna-northeurope-pre-ssrv01;password="+ jdbcPassword +";encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;"
except:
    print("Cannot connect to metadata DB ")
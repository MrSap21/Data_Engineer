# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS SAPMDM_CURATION.SITE_REF (
# MAGIC RefSet STRING NOT NULL,
# MAGIC RefCode STRING NOT NULL,
# MAGIC RefDesc STRING ,
# MAGIC SCDActiveFlag STRING ,
# MAGIC RecordStartDate timestamp ,
# MAGIC RecordEndDate timestamp )

# COMMAND ----------

SITE_REF = spark.read.option('header','true').format('csv').option('delimiter','|').load('/mnt/self-serve/Test/SITE_REF/')

# COMMAND ----------

from pyspark.sql.functions import lit,current_timestamp 
from pyspark.sql.types import  TimestampType
SITE_REF=SITE_REF.withColumn("SCDActiveFlag",lit('Y')).withColumn("RecordStartDate",current_timestamp()).withColumn("RecordEndDate",lit(None).cast(TimestampType()))


# COMMAND ----------

SITE_REF.createOrReplaceTempView('SITE_REF')

# COMMAND ----------

# MAGIC %sql
# MAGIC Insert into SAPMDM_CURATION.SITE_REF  (select RefSet,RefCode,RefDesc,SCDActiveFlag,RecordStartDate,RecordEndDate from SITE_REF )

# COMMAND ----------

SITES_SAP_MDMDF=spark.read.format("parquet").load("/mnt/idf-curatestage/BUKIT/SAPMDM/BootsUK_SITES_SAP_MDM_Incr/Incremental/20220613140000")
SITES_SAP_MDMDF.createOrReplaceTempView('SITES_SAP_MDM')

# COMMAND ----------

columnname=SITES_SAP_MDMDF.columns
for i in columnname:
    if 'Outbound' in i:
        print(i)

# COMMAND ----------

AllianceHealthCareDCDF=spark.sql("select 'AllianceHealthCareDC' as RefSet, \
PSites_Alliance_Healthcare_DC_Code as RefCode, \
PSites_Alliance_Healthcare_DC_Desc as RefDesc from SITES_SAP_MDM")
AllianceHealthCareDCDF.dropDuplicates()

# COMMAND ----------

AreaDF=spark.sql("select 'Area' as RefSet, \
PSites_Area_Number as RefCode, \
PSites_Area_Name as RefDesc  from SITES_SAP_MDM")
AreaDF.dropDuplicates()

# COMMAND ----------

BenchMarkGroupItemDF=spark.sql("select 'BenchMarkGroupItem' as RefSet, \
PSites_Benchmark_Group_Item_Code as RefCode, \
PSites_Benchmark_Group_Item_Description as RefDesc from SITES_SAP_MDM")
BenchMarkGroupItemDF.dropDuplicates()

# COMMAND ----------

BenchMarkGroupSalesDF=spark.sql("select 'BenchMarkGroupSales' as Refset, \
PSites_Benchmark_Group_Sales_Code as RefCode, \
PSites_Benchmark_Group_Sales_Desc as RefDesc from SITES_SAP_MDM ")
BenchMarkGroupSalesDF.dropDuplicates()

# COMMAND ----------

CACIClassificationDF=spark.sql("select 'CACIClassification' as RefSet, \
PSites_CACI_Classification_code as RefCode, \
PSites_CACI_Classification_Name as RefDesc from SITES_SAP_MDM" )
CACIClassificationDF.dropDuplicates()

# COMMAND ----------

CalendarDF=spark.sql("select 'Calendar' as RefSet, \
PSites_Calendar_Code as RefCode, \
PSites_Calendar_Desc as RefDesc from SITES_SAP_MDM ")
CalendarDF.dropDuplicates()

# COMMAND ----------

CDCDF=spark.sql("select 'CDC' as RefSet, \
PSites_CDC_Number as RefCode, \
PSites_CDC_Long_Name as RefDesc from SITES_SAP_MDM ")
CDCDF.dropDuplicates()

# COMMAND ----------

CeilingTypeDF=spark.sql("select 'CeilingType' as RefSet,\
PFloorDetail_Ceiling_Type as RefCode, \
PFloorDetail_Ceiling_Type_Description as RefDesc from SITES_SAP_MDM  ")
CeilingTypeDF.dropDuplicates()

# COMMAND ----------

ChainLetterDF=spark.sql("select 'ChainLetter' as RefSet,\
PSites_Chain_Letter_Code as RefCode, \
PSites_Chain_Letter_Description as RefDesc from SITES_SAP_MDM  ")
ChainLetterDF.dropDuplicates()

# COMMAND ----------

ChilledFoodDepotDF=spark.sql("select 'ChilledFoodDepot' as RefSet, \
PSites_Chilled_Food_Depot_Code as RefCode, \
PSites_Chilled_Food_Depot_Desc as RefDesc from  SITES_SAP_MDM  ")
ChilledFoodDepotDF.dropDuplicates()

# COMMAND ----------

CountryDF=spark.sql("select 'Country' as RefSet, \
 PSites_Country_Code as RefCode, \
PTax_Country_Name as RefDesc from  SITES_SAP_MDM ")
CountryDF.dropDuplicates()

# COMMAND ----------

CountyDF=spark.sql("select 'County' as RefSet,\
PSites_County_Code as RefCode , \
 PSites_County_Name as RefDesc from SITES_SAP_MDM ")
CountyDF.dropDuplicates()

# COMMAND ----------

CurrencyDF=spark.sql("select 'Currency' as RefSet, \
PSites_POS_Currency_Code  as RefCode, \
PSites_POS_Currency_Desc as RefDesc from SITES_SAP_MDM ")
CurrencyDF.dropDuplicates()

# COMMAND ----------

DeliveryChainDF=spark.sql("select 'DeliveryChain' as RefSet ,\
PSites_Delivery_Chain_code as RefCode, \
PSites_Delivery_Chain_Desc as RefDesc from SITES_SAP_MDM")
DeliveryChainDF.dropDuplicates()

# COMMAND ----------

DepartmentDF=spark.sql("select 'Department' as RefSet ,\
PFloorDept_Dept_Code as RefCode ,\
PFloorDept_Dept_Name as RefDesc from SITES_SAP_MDM")
DepartmentDF.dropDuplicates()

# COMMAND ----------

DispensaryTypeDF=spark.sql("select 'DispensaryType' as RefSet, \
PSites_Dispensary_Type_code as RefCode, \
PSites_Dispensary_Type_Desc as RefDesc from SITES_SAP_MDM")
DispensaryTypeDF.dropDuplicates()

# COMMAND ----------

DistributionChannelDF=spark.sql("select 'DistributionChannel' as RefSet, \
PSites_Distribution_Channel_Code as RefCode, \
PSites_Distribution_Channel_Desc as RefDesc from SITES_SAP_MDM")
DistributionChannelDF.dropDuplicates()

# COMMAND ----------

DivisionDF=spark.sql("select 'Division' as RefSet,\
PSites_Division_Code as RefCode,\
PSites_Division_Name as RefDesc from SITES_SAP_MDM")
DivisionDF.dropDuplicates()

# COMMAND ----------

EscalatorTypeDF=spark.sql("select 'EscalatorType' as RefSet, \
PEscalators_Escalator_Type_Code as RefCode, \
PEscalators_Escalator_Type_Desc as RefDesc from SITES_SAP_MDM ")
EscalatorTypeDF.dropDuplicates()

# COMMAND ----------

ReferenceSiteDF=spark.sql("select 'ReferenceSite' as RefSet, \
PSites_Reference_Site_Code as RefCode, \
PSites_Reference_Site_Name as RefDesc from SITES_SAP_MDM")
ReferenceSiteDF.dropDuplicates()

# COMMAND ----------

SalesOrganisationDF=spark.sql("select 'SalesOrganisation' as RefSet, \
PSites_Sales_Organisation_Code as RefCode, \
PSites_Sales_Organisation_Desc as RefDesc from SITES_SAP_MDM")
SalesOrganisationDF.dropDuplicates()

# COMMAND ----------

SAPCompanyDF=spark.sql("select 'SAPCompany' as RefSet, \
PSites_SAP_Company_Code as RefCode, \
PSites_SAP_Company_Name as RefDesc from SITES_SAP_MDM")
SAPCompanyDF.dropDuplicates()

# COMMAND ----------

SAPSiteProfileDF=spark.sql("select 'SAPSiteProfile' as RefSet, \
PSites_SAP_Site_Profile_Code as RefCode, \
PSites_SAP_Site_Profile_Description as RefDesc from SITES_SAP_MDM")
SAPSiteProfileDF.dropDuplicates()

# COMMAND ----------

SDCountryDF=spark.sql("select 'SDCountry' as RefSet, \
PSites_SD_Country_Code as RefCode, \
PSites_SD_Country_Name as RefDesc from SITES_SAP_MDM")
SDCountryDF.dropDuplicates()

# COMMAND ----------

SecurityCladdingTypeDF=spark.sql("select 'SecurityCladdingType' as RefSet, \
PSecurity_Security_Cladding_Type_Code as RefCode, \
PSecurity_Security_Cladding_Type_Desc as RefDesc from SITES_SAP_MDM")
SecurityCladdingTypeDF.dropDuplicates()

# COMMAND ----------

SiteStatusDF=spark.sql("select 'SiteStatus' as RefSet, \
PSites_Site_Status_Code as RefCode, \
PSites_Site_Status_Description as RefDesc from SITES_SAP_MDM")
SiteStatusDF.dropDuplicates()

# COMMAND ----------

SiteFormatDF=spark.sql("select 'SiteFormat' as RefSet, \
PSites_Format_Code as RefCode, \
PSites_Format_Desc as RefDesc from SITES_SAP_MDM")
SiteFormatDF.dropDuplicates()

# COMMAND ----------

StoreFacilitiesDF=spark.sql("select 'StoreFacilities' as RefSet, \
PSites_Store_Facilities_Code as RefCode, \
PSites_Store_Facilities_Desc as RefDesc from SITES_SAP_MDM")
StoreFacilitiesDF.dropDuplicates()

# COMMAND ----------

StoreTypeDF=spark.sql("select 'StoreType' as RefSet, \
PSites_Stores_Type_Code as RefCode, \
PSites_Stores_Type_Desc as RefDesc from SITES_SAP_MDM")
StoreTypeDF.dropDuplicates()

# COMMAND ----------

SupplyRegionDF=spark.sql("select 'SupplyRegion' as RefSet, \
PSites_Supply_Region_Code as RefCode, \
PSites_Supply_Region_Desc as RefDesc from SITES_SAP_MDM")
SupplyRegionDF.dropDuplicates()

# COMMAND ----------

TaxCategoryDF=spark.sql("select 'TaxCategory' as RefSet, \
PTax_Tax_categories as RefCode, \
PTax_Tax_category_Description as RefDesc from SITES_SAP_MDM")
TaxCategoryDF.dropDuplicates()

# COMMAND ----------

TaxClassificationDF=spark.sql("select 'TaxClassification' as RefSet, \
PTax_Tax_classification as RefCode, \
PTax_Tax_classification_Description as RefDesc from SITES_SAP_MDM")
TaxClassificationDF.dropDuplicates()

# COMMAND ----------

WindowTypeDF=spark.sql("select 'WindowType' as RefSet, \
PWindow_Window_Type_Code as RefCode, \
PWindow_Window_Type_Desc as RefDesc from SITES_SAP_MDM")
WindowTypeDF.dropDuplicates()

# COMMAND ----------

ExternalOrganisationDF=spark.sql("select 'ExternalOrganisation' as RefSet, \
PExtOrg_Ext_Org_Code as RefCode, \
PExtOrg_Ext_Org_Name as RefDesc from SITES_SAP_MDM")
ExternalOrganisationDF.dropDuplicates()

# COMMAND ----------

FloorDF=spark.sql("select 'Floor' as RefSet,\
PFloorDept_Floor_Code as RefCode, \
PFloorDept_Floor_Desc as RefDesc from SITES_SAP_MDM")
FloorDF.dropDuplicates()

# COMMAND ----------

LanguageDF=spark.sql("select 'Language' as RefSet, \
PSites_Language as RefCode, \
PSites_Language_Desc as RefDesc from SITES_SAP_MDM")
LanguageDF.dropDuplicates()

# COMMAND ----------

ManagementOriginDF=spark.sql("select 'ManagementOrigin' as RefSet , \
PSites_Management_Origin_Code as RefCode, \
PSites_Management_Origin_Description as RefDesc from SITES_SAP_MDM")

# COMMAND ----------

PurchasingOrganisationCodeDF=spark.sql("select 'PurchasingOrganisationCode' as RefSet, \
PSites_Purchasing__Organisation_Code as RefCode, \
 PSites_Purchasing_Organisation_Desc as RefDesc from SITES_SAP_MDM")
PurchasingOrganisationCodeDF.dropDuplicates()

# COMMAND ----------

POSOutboundProfileDF=spark.sql("select 'POSOutboundProfile' as RefSet, \
PSites_POS_Outbound_Profile_Code as RefCode, \
 PSites_POS_Outbound_Profile_decs as RefDesc from SITES_SAP_MDM")
POSOutboundProfileDF.dropDuplicates()

# COMMAND ----------

PrimaryCareOrganisationDF=spark.sql("select 'PrimaryCareOrganisation' as RefSet, \
PSites_Primary_Care_Organisation_Code as RefCode, \
PSites_Primary_Care_Organisation_Name as RefDesc from SITES_SAP_MDM")
PrimaryCareOrganisationDF.dropDuplicates()

# COMMAND ----------

PriceBandDF=spark.sql("select 'PriceBand' as RefSet, \
PSites_Price_Band_Code as RefCode, \
PSites_Price_Band_Desc as RefDesc from SITES_SAP_MDM")
PriceBandDF.dropDuplicates()

# COMMAND ----------

POSInboundProfileDF=spark.sql("select 'POSInboundProfile' as RefSet, \
PSites_POS_Inbound_Profile_Code as RefCode, \
PSites_POS_Inbound_Profile_Desc as RefDesc from SITES_SAP_MDM")
POSInboundProfileDF.dropDuplicates()

# COMMAND ----------

PharmacyRegistrationStatusDF=spark.sql("select 'PharmacyRegistrationStatus' as RefSet, \
PSites_Pharmacy_Registration_Status_Code as RefCode, \
PSites_Pharmacy_Registration_Status as RefDesc from SITES_SAP_MDM")
PharmacyRegistrationStatusDF.dropDuplicates()

# COMMAND ----------

PaymentCardDF=spark.sql("select 'PaymentCard' as RefSet, \
PMerchant_Payment_card_code as RefCode, \
PMerchant_Payment_card_Desc as RefDesc from SITES_SAP_MDM")
PaymentCardDF.dropDuplicates()

# COMMAND ----------

NonLFLDF=spark.sql("select 'NonLFL' as RefSet, \
`PSites_Non-LFL_Code` as RefCode, \
`PSites_Non-LFL_Description` as RefDesc from SITES_SAP_MDM ")
NonLFLDF.dropDuplicates()

# COMMAND ----------

NHSContractDF=spark.sql("select 'NHSContract' as RefSet, \
PSites_NHS_Contract_Code as RefCode, \
PSites_NHS_Contract_Desc as RefDesc from SITES_SAP_MDM")
NHSContractDF.dropDuplicates()

# COMMAND ----------

RegionDF=spark.sql("select 'Region' as RefSet, \
PSites_Region_Code as RefCode, \
PSites_Region_Name as RefDesc from SITES_SAP_MDM")
RegionDF.dropDuplicates()

# COMMAND ----------

SiteTypeDF=spark.sql("select 'SiteType' as Refset,\
PSites_SiteType_Code as RefCode, \
PSites_SiteType_Description as RefDesc from SITES_SAP_MDM")
SiteTypeDF.dropDuplicates()

# COMMAND ----------

SAPMDM_Union=AllianceHealthCareDCDF.union(AreaDF).union(BenchMarkGroupItemDF).union(BenchMarkGroupSalesDF).union(CACIClassificationDF).union(CalendarDF).union(CDCDF).union(CeilingTypeDF).union(ChainLetterDF).union(ChilledFoodDepotDF).union(CountryDF).union(CountyDF).union(CurrencyDF).union(DeliveryChainDF).union(DepartmentDF).union(DispensaryTypeDF).union(DistributionChannelDF).union(DivisionDF).union(EscalatorTypeDF).union(ReferenceSiteDF).union(SalesOrganisationDF).union(SAPCompanyDF).union(SAPSiteProfileDF).union(SDCountryDF).union(SecurityCladdingTypeDF).union(SiteStatusDF).union(SiteFormatDF).union(StoreFacilitiesDF).union(StoreTypeDF).union(SupplyRegionDF).union(TaxCategoryDF).union(TaxClassificationDF).union(WindowTypeDF).union(ExternalOrganisationDF).union(FloorDF).union(LanguageDF).union(ManagementOriginDF).union(PurchasingOrganisationCodeDF).union(POSOutboundProfileDF).union(PrimaryCareOrganisationDF).union(PriceBandDF).union(POSInboundProfileDF).union(PharmacyRegistrationStatusDF).union(PaymentCardDF).union(NonLFLDF).union(NHSContractDF).union(RegionDF).union(SiteTypeDF)
SAPMDM_Union.dropDuplicates()
SAPMDM_Union.createOrReplaceTempView('SAPMDM_Union')

# COMMAND ----------

SAPMDM_Union.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC MERGE INTO SAPMDM_CURATION.SITE_REF T
# MAGIC USING (
# MAGIC SELECT D.RefSet as mergeKey1,D.RefCode as mergeKey2,D.RefSet,D.RefCode,D.RefDesc
# MAGIC FROM SAPMDM_Union D
# MAGIC UNION ALL
# MAGIC SELECT NULL as mergeKey1,NULL as mergeKey2,U.RefSet,U.RefCode,U.RefDesc
# MAGIC FROM SAPMDM_Union U JOIN SAPMDM_CURATION.SITE_REF M
# MAGIC ON U.RefSet = M.RefSet and U.RefCode=M.RefCode
# MAGIC WHERE M.SCDActiveFlag = 'Y'
# MAGIC ) S
# MAGIC ON T.RefSet = S.mergeKey1 and T.RefCode = S.mergeKey2
# MAGIC WHEN MATCHED AND T.SCDActiveFlag = 'Y' AND T.RefDesc !=S.RefDesc THEN
# MAGIC UPDATE SET SCDActiveFlag = 'N', RecordEndDate = CURRENT_TIMESTAMP
# MAGIC WHEN NOT MATCHED THEN
# MAGIC INSERT (RefSet,RefCode,RefDesc,SCDActiveFlag,RecordStartDate,RecordEndDate)
# MAGIC VALUES(S.RefSet,S.RefCode,S.RefDesc,'Y',CURRENT_TIMESTAMP,null)
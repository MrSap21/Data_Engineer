# Databricks notebook source
# MAGIC %md CurateStage Watermark Table

# COMMAND ----------

# MAGIC %sql
# MAGIC create Database if not exists RPI_Reference_DB;
# MAGIC
# MAGIC create table if not exists RPI_Reference_DB.CurateStage_WatermarkTable (SourceName string, FeedName string, BatchId string, LastProcessedTime timestamp) 
# MAGIC using delta 
# MAGIC partitioned by (SourceName,FeedName)
# MAGIC location '/mnt/idf-reports/RPI_Reference/CurateStage/WatermarkTable/';

# COMMAND ----------

# MAGIC %md Curation Watermark Table

# COMMAND ----------

# MAGIC %sql
# MAGIC create Database if not exists RPI_Reference_DB;
# MAGIC
# MAGIC create table if not exists RPI_Reference_DB.Curation_WatermarkTable (EntityName string, BatchID string, CurateADLS_LPT timestamp, CurateSynapse_LPT timestamp) 
# MAGIC using delta 
# MAGIC partitioned by (EntityName)
# MAGIC location '/mnt/idf-reports/RPI_Reference/Curation/WatermarkTable/';
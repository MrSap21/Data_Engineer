# Databricks notebook source
dbutils.widgets.text("SourceTable","","")
dbutils.widgets.text("KeyColumns","","")
dbutils.widgets.text("PartitionColumns","","")

# COMMAND ----------

#KeyColumns=eval(dbutils.widgets.get("KeyColumns"))
#print(KeyColumns)
SourceTable=dbutils.widgets.get("SourceTable")
print(SourceTable)
PartitionColumns=eval(dbutils.widgets.get("PartitionColumns"))
print(PartitionColumns)

# COMMAND ----------

actualCount=spark.read.table(SourceTable).count()
print(actualCount)


# COMMAND ----------

uniqueDF=spark.read.table(SourceTable).dropDuplicates()
uniqueCount=uniqueDF.count()
print(uniqueCount)

# COMMAND ----------

if actualCount!=uniqueCount:
    uniqueDF.write \
    .format("delta")\
    .mode("overwrite")\
    .option("overwriteSchema", "true")\
    .partitionBy(PartitionColumns)\
    .saveAsTable(SourceTable)
    
    print("Removed duplicates")
else:
    print('No duplicates available')
# Databricks notebook source
# DBTITLE 1,Fetch CurateStaging Last Processing Time
# MAGIC %sql
# MAGIC
# MAGIC select * from rpi_reference_db.curatestage_watermarktable order by LastProcessedTime desc limit 1 
# MAGIC --This query is to fetch the lastproccessedtime and batch id for the last curatestage run

# COMMAND ----------

# DBTITLE 1,Fetch Curation Last Processing Time
# MAGIC %sql
# MAGIC select EntityName,  max(CurateADLS_LPT) as CurateADLS_LPT , max(CurateSynapse_LPT) as CurateSynapse_LPT from RPI_Reference_DB.Curation_WatermarkTable group by EntityName
# MAGIC
# MAGIC --This query is to fetch the curate adls and curate synapse lastproccessedtime for the last curate run

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select BatchID from RPI_Reference_DB.Curation_WatermarkTable where CurateADLS_LPT = (select max(CurateADLS_LPT) from RPI_Reference_DB.Curation_WatermarkTable ) and CurateSynapse_LPT  = (select max(CurateSynapse_LPT) from RPI_Reference_DB.Curation_WatermarkTable )
# MAGIC
# MAGIC --This query is to fetch the last batchid for curate adls and curate synapse

# COMMAND ----------


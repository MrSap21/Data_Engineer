# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS RPI_LOGGING;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS RPI_LOGGING.RPI_COMMON_LOGGING (
# MAGIC     ProcessStage string COMMENT 'Name of the Processing stage(CurateStaging/CurateADLS/CurateSynapse/Consumption)',
# MAGIC     EntityName string COMMENT 'File name for curate staging / Table name for Others',
# MAGIC     AssetId string COMMENT 'Asset id fetching metadatadb based on Asset name',
# MAGIC     FeedId string COMMENT 'Feed id fetching metadatadb based on Asset name',
# MAGIC     ETLRunId string COMMENT 'ETL run Id retun from dbo.ETLRunLogAddorUpdate stored procedure',
# MAGIC     BatchId string COMMENT 'Batch Id',
# MAGIC     SourceName string COMMENT 'Source System Name',
# MAGIC     FeedName string COMMENT 'Source Feed Name',
# MAGIC     Status string COMMENT 'Status of process',
# MAGIC     Error string COMMENT 'Error Details',
# MAGIC     RunTime string COMMENT 'Trigger Run Time',
# MAGIC     TriggerId string COMMENT 'Trigger Id',
# MAGIC     SourceCount string COMMENT 'Source Data Count / Count of files in Curate stage',
# MAGIC     TargetCount string COMMENT 'Target Data Count/ Count of output table in Curate stage',
# MAGIC     Remark string COMMENT 'Name of output table in Curate stage/ Null for others'
# MAGIC ) USING Delta
# MAGIC
# MAGIC LOCATION '/mnt/idf-reports/RPI_Logging/RPI_Common_Logging/'
# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *

from pyspark import SparkContext
from pyspark.sql import SparkSession

spark: SparkSession = SparkSession.builder.getOrCreate()
sc: SparkContext = spark.sparkContext

# COMMAND ----------

# MAGIC %run ../App_tool/Logger_module

# COMMAND ----------

# MAGIC %run ../App_tool/Job_descriptor_Module

# COMMAND ----------

# MAGIC %md 
# MAGIC Get the parameters

# COMMAND ----------

dbutils.widgets.text("SourceName", "", "")
SourceName = dbutils.widgets.get("SourceName")

dbutils.widgets.text("FeedName", "", "")
FeedName = dbutils.widgets.get("FeedName")

dbutils.widgets.text("LastProcessedTime", "", "")
LastProcessedTime = dbutils.widgets.get("LastProcessedTime")

dbutils.widgets.text("BatchID", "", "")
BatchID = dbutils.widgets.get("BatchID")

# COMMAND ----------

# MAGIC %md 
# MAGIC Create database and table for tracking the latest processing time and batch id for each source

# COMMAND ----------

# MAGIC %sql
# MAGIC create Database if not exists RPI_Reference_DB;
# MAGIC
# MAGIC create table if not exists RPI_Reference_DB.CurateStage_WatermarkTable (SourceName string, FeedName string, BatchId string, LastProcessedTime timestamp) 
# MAGIC using delta 
# MAGIC partitioned by (SourceName,FeedName)
# MAGIC location '/mnt/idf-reports/RPI_Reference/CurateStage/WatermarkTable/';

# COMMAND ----------

# MAGIC %md
# MAGIC create temperory data frame with latest data. Values will be received from pipeline parameters.

# MAGIC Save the data to delta lake table

# COMMAND ----------

job_desc_obj = JobDescriptor()
log_obj = AppLogger()
logger_app = log_obj.get_logger()

@function_logger
def RPI_CurateStaging_WatermarkUpdate_main(SourceName, FeedName, LastProcessedTime, BatchID):
    try:
        # create temperory data frame with latest data. Values will be received from pipeline parameters.

        updatedvalue = [(SourceName, FeedName, BatchID, LastProcessedTime)]
        updatedDF = spark.createDataFrame(updatedvalue,
                                          schema=['SourceName', 'FeedName', 'BatchID', 'LastProcessedTime']).withColumn(
            "LastProcessedTime", col("LastProcessedTime").cast('Timestamp'))

        # Save the data to delta lake table
        updatedDF.write.format("delta").mode("append").partitionBy("SourceName", "FeedName").saveAsTable(
            "RPI_Reference_DB.CurateStage_WatermarkTable")
    except Exception as e:
        logger_app.error(f"RPI_CurateStaging_WatermarkUpdate_main error:{e} ")
        raise

sc.setJobDescription(job_desc_obj.variableDescriptor(SourceName, FeedName, LastProcessedTime, BatchID))
RPI_CurateStaging_WatermarkUpdate_main(SourceName, FeedName, LastProcessedTime, BatchID)

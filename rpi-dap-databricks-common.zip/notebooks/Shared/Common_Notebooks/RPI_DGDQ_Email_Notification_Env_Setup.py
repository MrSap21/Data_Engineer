# Databricks notebook source
source = "wasbs://email-notification-logs@aznednadevdl01.blob.core.windows.net"
mountPoint = "/mnt/email-notification-logs"
if not any(mount.mountPoint == mountPoint for mount in dbutils.fs.mounts()):
    dbutils.fs.mount(
      source = source,
      mount_point = mountPoint,
      extra_configs = {"fs.azure.account.key.aznednadevdl01.blob.core.windows.net":dbutils.secrets.get(scope="Databricks-KeyVault",key="aznednadevdl01-key")})

# COMMAND ----------

display(dbutils.fs.mounts())
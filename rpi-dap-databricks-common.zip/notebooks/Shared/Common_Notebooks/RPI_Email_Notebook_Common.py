# Databricks notebook source

import requests
from pyspark import SparkContext
from pyspark.sql import SparkSession

spark: SparkSession = SparkSession.builder.getOrCreate()
sc: SparkContext = spark.sparkContext

# COMMAND ----------


# MAGIC %run ../App_tool/Logger_module

# COMMAND ----------

# MAGIC %run ../App_tool/Job_descriptor_Module

# COMMAND ----------

dbutils.widgets.text("status", '', '')
status = dbutils.widgets.get('status')
dbutils.widgets.text("driver_config_file_name", '', '')
file_name = dbutils.widgets.get('driver_config_file_name')
dbutils.widgets.text("ErrorDetails", '', '')
error_details = dbutils.widgets.get('ErrorDetails')
dbutils.widgets.text("Pipeline_Process_Name", '', '')
Pipeline_Process_Name = dbutils.widgets.get('Pipeline_Process_Name')
print(status)
print(file_name)
print(error_details)
print(Pipeline_Process_Name)

# COMMAND ----------
job_desc_obj = JobDescriptor()
log_obj = AppLogger()
logger_app = log_obj.get_logger()

@function_logger
def RPI_Email_Notebook_Common_main(status, file_name, error_details, Pipeline_Process_Name):
    try:
        LogicAppURL = "https://prod-26.northeurope.logic.azure.com:443/workflows/96906ba4cc7f45afa05a8f4997a05d1f/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=8080_OwuqbyZjdVD6zBcrWtOP-_JJIRhDWx_XlqFdlY-"
        data = {"FileName": file_name,
                "ErrorDetails": error_details,
                "status": status,
                "Pipeline_Process_Name": Pipeline_Process_Name}
        return requests.post(LogicAppURL, params=data)
    except Exception as e:
        logger_app.error(f"RPI_Email_Notebook_Common_main error:{e} ")
        raise

sc.setJobDescription(job_desc_obj.variableDescriptor(status, file_name, error_details, Pipeline_Process_Name))
myResponse = RPI_Email_Notebook_Common_main(status, file_name, error_details, Pipeline_Process_Name)

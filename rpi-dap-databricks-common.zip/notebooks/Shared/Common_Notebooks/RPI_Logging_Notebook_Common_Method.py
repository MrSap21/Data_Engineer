# Databricks notebook source
# MAGIC %run "./config_for_metadata_db_connectivity"

# COMMAND ----------


# MAGIC %run ../App_tool/Logger_module

# COMMAND ----------

# MAGIC %run ../App_tool/Job_descriptor_Module

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

from pyspark import SparkContext
from pyspark.sql import SparkSession
import json
import os

spark: SparkSession = SparkSession.builder.getOrCreate()
sc: SparkContext = spark.sparkContext

job_desc_obj = JobDescriptor()
log_obj = AppLogger()
logger_app = log_obj.get_logger()

RPI_LOGGING_NOTEBOOK_MAIN_WIDGET = json.loads(os.environ.get('RPI_LOGGING_NOTEBOOK_MAIN_WIDGET'))


@function_logger
def read_asset(asset_name, systemofrecordid):
    print(asset_name)
    df = spark.read \
        .format("com.microsoft.sqlserver.jdbc.spark") \
        .option("url", jdbc_url) \
        .option("query",
                f"select aset.FeedID as FeedID, aset.AssetID as AssetID, asetstat.StatusID from dbo.FEEDSOURCE as fs join dbo.Feed as f on fs.FeedID=f.FeedID join dbo.Asset as aset on aset.FeedID = f.FeedID join dbo.AssetStatus as asetstat on asetstat.AssetID = aset.AssetID left join dbo.FeedDualRunConfig asstat on fs.FeedID =asstat.feedid where asetstat.StatusID=case when asstat.feedid is not null then asstat.StatusID else 24014 end and SystemOfRecordID = {systemofrecordid} and AssetName = '{asset_name}' and asetstat.DTEffectiveto is null").load() #.persist()


    # sc.setJobDescription(job_desc_obj.RPIsparkJobDescription("read_asset count",
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("batch_id"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("source_name"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("feed_name"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("entity_name"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("process_stage"),
    #                                                          ))
    if df.count() == 0:
        output_message = 'No such asset name exists in Asset DB'
        assetid = None
        feedid = None
        print(output_message)
    else:

        # sc.setJobDescription(job_desc_obj.RPIsparkJobDescription("read_asset collect",
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("batch_id"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("source_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("feed_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("entity_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("process_stage"),
        #                                                          ))
        assetid = df.collect()[0].AssetID
        feedid = df.collect()[0].FeedID
    #df.unpersist()
    return assetid, feedid


# COMMAND ----------
@function_logger
def ETLRunLogAssetAddOrUpdate(ETLRunId, AssetId, DtCreated, UserCreated):

    # sc.setJobDescription(job_desc_obj.RPIsparkJobDescription("ETLRunLogAssetAddOrUpdate",
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("batch_id"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("source_name"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("feed_name"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("entity_name"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("process_stage"),
    #                                                          ))
    statement = "EXEC [dbo].[ETLRunLogAssetAddOrUpdate] @pETLRunLogID = N'" + ETLRunId + "', @pAssetID = N'" + AssetId + "', @pDTCreated = N'" + DtCreated + "', @pUserCreated = N'" + UserCreated + "'"
    driver_manager = spark._sc._gateway.jvm.java.sql.DriverManager
    con = driver_manager.getConnection(jdbc_url, jdbcUsername, jdbcPassword)
    exec_statement = con.prepareCall(statement)
    result = exec_statement.execute()
    exec_statement.close()
    con.close()


# COMMAND ----------
@function_logger
def AssetStatusChange(AssetId, StatusID, DtCreated, UserCreated):
    if (str(AssetId) != 'None'):

        # sc.setJobDescription(job_desc_obj.RPIsparkJobDescription("AssetStatusChange",
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("batch_id"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("source_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("feed_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("entity_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("process_stage"),
        #                                                          ))
        statement = "EXEC [dbo].[AssetStatusChange] @pAssetID = '" + AssetId + "', @pStatusID = '" + StatusID + "', @pDTCreated = '" + DtCreated + "', @pUserCreated = '" + UserCreated + "'"
        driver_manager = spark._sc._gateway.jvm.java.sql.DriverManager
        con = driver_manager.getConnection(jdbc_url, jdbcUsername, jdbcPassword)
        exec_statement = con.createStatement()
        rs = exec_statement.executeQuery(statement)
        while (rs.next()):
            if (rs.getInt(3) == -1):
                print("Status not updating for" + str(AssetId))
                rs = exec_statement.executeQuery(statement)
        exec_statement.close()
        con.close()


# COMMAND ----------
@function_logger
def invoke_SP(ETLRunId, DtCreated, UserCreated, AssetId, ProcessStage, Status):
    if Status.replace(" ", "").lower() == 'success' or Status.replace(" ", "").lower() == 'succeeded':
        ETLRunLogAssetAddOrUpdate(ETLRunId, str(AssetId), DtCreated, UserCreated)
        if 'curatestaging' in ProcessStage.replace(" ", "").lower():
            StatusID = '24064'
        elif 'curatestandard' in ProcessStage.replace(" ", "").lower():
            StatusID = '24065'
        elif 'curateadls' in ProcessStage.replace(" ", "").lower():
            StatusID = '24066'
        elif 'curatesynapse' in ProcessStage.replace(" ", "").lower():
            StatusID = '24067'
        AssetStatusChange(str(AssetId), StatusID, DtCreated, UserCreated)
    else:
        ETLRunLogAssetAddOrUpdate(ETLRunId, str(AssetId), DtCreated, UserCreated)


# COMMAND ----------
@function_logger
def update_logtable(ProcessStage, EntityName, AssetId, FeedId, ETLRunId, BatchId, SourceName, FeedName, Status, Error,
                    RunTime, TriggerId, SourceCount, TargetCount, Remark):

    # sc.setJobDescription(job_desc_obj.RPIsparkJobDescription("update_logtable",
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("batch_id"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("source_name"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("feed_name"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("entity_name"),
    #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("process_stage"),
    #                                                          ))
    spark.sql("INSERT INTO RPI_LOGGING.RPI_COMMON_LOGGING VALUES ('" + str(ProcessStage) + "','" + str(
        EntityName) + "','" + str(AssetId) + "','" + str(FeedId) + "','" + str(ETLRunId) + "','" + str(
        BatchId) + "','" + str(SourceName) + "','" + str(FeedName) + "','" + str(Status) + "','" + str(
        Error) + "','" + str(RunTime) + "','" + str(TriggerId) + "','" + str(SourceCount) + "','" + str(
        TargetCount) + "','" + str(Remark) + "');")


# COMMAND ----------
@function_logger
def insert_log(ProcessStage, EntityName, BatchId, SourceName, FeedName, Status, Error, RunTime, TriggerId, SourceCount,
               TargetCount, Remark, ETLRunId, DtCreated, UserCreated, SystemOfRecordId):
    if 'curatestaging' in ProcessStage.replace(" ", "").lower():
        AssetId = 0
        FeedId = 0
        AssetId, FeedId = read_asset(EntityName, SystemOfRecordId)
        if (AssetId != None) and (FeedId != None):
            update_logtable(ProcessStage, EntityName, AssetId, FeedId, ETLRunId, BatchId, SourceName, FeedName, Status,
                            Error, RunTime, TriggerId, SourceCount, TargetCount, Remark)
            invoke_SP(ETLRunId, DtCreated, UserCreated, AssetId, ProcessStage, Status)
        else:
            print("AssetId, FeedId not available in Metadata DB")
            feednamelist = []
            if ',' in FeedName:
                feednamelist = FeedName.split(',')
            else:
                feednamelist.append(FeedName)
            logger_app.info(f"insert_log - if 'curatestaging' line 172 - feednamelist:{feednamelist}")
            for FName in feednamelist:
                update_logtable(ProcessStage, EntityName, AssetId, FeedId, ETLRunId, BatchId, SourceName, FName, Status,
                                Error, RunTime, TriggerId, SourceCount, TargetCount, Remark)
    elif 'curatestandard' in ProcessStage.replace(" ", "").lower():
        log_df = spark.sql(
            "select AssetId,FeedId from RPI_LOGGING.RPI_COMMON_LOGGING where BatchId = '" + BatchId + "' and FeedName = '" + FeedName + "'  ")#.persist()

        # sc.setJobDescription(job_desc_obj.RPIsparkJobDescription("insert_log - if 'curatestandard' count ",
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("batch_id"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("source_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("feed_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("entity_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("process_stage"),
        #                                                          ))
        if log_df.count() == 0:
            output_message = 'No such batchid/asset details exists in logging DB'
            print(output_message)
        else:
            FeedId = log_df.collect()[0].FeedId
            Assetlist = log_df.distinct().select('AssetId').rdd.map(lambda x: x[0]).collect()
            logger_app.info(f"insert_log - for if 'curatestandard' line 184 - Assetlist:{Assetlist}")
            for AssetId in Assetlist:
                invoke_SP(ETLRunId, DtCreated, UserCreated, AssetId, ProcessStage, Status)
                update_logtable(ProcessStage, EntityName, AssetId, FeedId, ETLRunId, BatchId, SourceName, FeedName,
                                Status, Error, RunTime, TriggerId, SourceCount, TargetCount, Remark)
        #log_df.unpersist()

    else:
        feednamelist = []
        if ',' in FeedName:
            feednamelist = FeedName.split(',')
        else:
            feednamelist.append(FeedName)
        logger_app.info(f"insert_log - else line 197 - feednamelist:{feednamelist}")
        # sc.setJobDescription(job_desc_obj.RPIsparkJobDescription("insert_log - else count ",
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("batch_id"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get(
        #                                                              "source_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get("feed_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get(
        #                                                              "entity_name"),
        #                                                          RPI_LOGGING_NOTEBOOK_MAIN_WIDGET.get(
        #                                                              "process_stage"),
        #                                                          ))
        for FName in feednamelist:
            log_df = spark.sql(
                "select AssetId,FeedId from RPI_LOGGING.RPI_COMMON_LOGGING where BatchId = '" + BatchId + "'and FeedName = '" + FName + "'")#.persist()
            if log_df.count() == 0:
                output_message = 'No such batchid/asset details exists in logging DB'
                print(output_message)
            else:
                FeedId = log_df.collect()[0].FeedId
                Assetlist = log_df.distinct().select('AssetId').rdd.map(lambda x: x[0]).collect()

                logger_app.info(f"insert_log - else line 207 - Assetlist:{Assetlist}")
                for AssetId in Assetlist:
                    invoke_SP(ETLRunId, DtCreated, UserCreated, AssetId, ProcessStage, Status)
                    update_logtable(ProcessStage, EntityName, AssetId, FeedId, ETLRunId, BatchId, SourceName, FName,
                                    Status, Error, RunTime, TriggerId, SourceCount, TargetCount, Remark)
            #log_df.unpersist()

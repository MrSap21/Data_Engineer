# Databricks notebook source
def singleton(class_):
    instances = {}

    def getinstance(*args, **kwargs):
        if class_ not in instances:
            instances[class_] = class_(*args, **kwargs)
        return instances[class_]

    return getinstance


@singleton
class JobDescriptor:
    def __init__(self):
        pass

    def ETLsparkJobDescription(self, class_name, config_name, card):
        return f"{class_name}-{config_name}-{card.get('card_id')}-{card.get('card_type')}"

    def sparkJobDescription(self, class_name, method_name, config_name):
        return f"-{class_name} - {method_name} - {config_name}"

    def RPIsparkJobDescription(self, method_name, batch_id, source_name, feed_name, entity_name, process_stage):
        return f"{method_name}-{batch_id}-{source_name}-{feed_name}-{entity_name}-{process_stage}"

    def variableDescriptor(self, *args):
        return '-'.join(args)

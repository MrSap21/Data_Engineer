# Databricks notebook source
import inspect
import logging
import sys
from datetime import datetime
from functools import wraps

from pyspark.dbutils import DBUtils

dbutils: DBUtils = DBUtils()


def singleton(class_):
    instances = {}

    def getinstance(*args, **kwargs):
        if class_ not in instances:
            instances[class_] = class_(*args, **kwargs)
        return instances[class_]

    return getinstance


class StringHandler(logging.Handler):
    def __init__(self, log_level="DEBUG", log_format='%(asctime)s - %(levelname)s - %(filename)s - %(message)s'):
        super().__init__(log_level)
        self.log_string = ""
        self.setFormatter(logging.Formatter(log_format))
        self.setLevel(log_level)

    def emit(self, record):
        log_message = self.format(record)
        self.log_string += log_message + '\n'

    def get_log_string(self):
        return self.log_string


@singleton
class AppLogger:

    def __init__(self):
        self.logger = logging.getLogger('my_logger')
        self.logger.setLevel(logging.INFO)
        self.dict_log_string = {}
        # Create a file handler and set the formatter

        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.DEBUG)
        handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(filename)s - %(message)s'))
        self.logger.addHandler(handler)

    @staticmethod
    def _get_level(level):
        switch = {
            'debug': logging.DEBUG,
            'info': logging.INFO,
            'warning': logging.WARNING,
            'error': logging.ERROR,
            'critical': logging.CRITICAL
        }
        return switch.get(level.lower())

    def get_logger(self):
        return self.logger

    def add_handler(self, handler):
        self.logger.addHandler(handler)

    def add_file_handler(self, file_path, level="DEBUG",
                         formatter='%(asctime)s - %(levelname)s - %(filename)s - %(message)s'):
        log_lever = self._get_level(level)
        file_handler = logging.FileHandler(file_path)
        file_handler.setLevel(log_lever)
        file_handler.setFormatter(logging.Formatter(formatter))
        self.logger.addHandler(file_handler)

    def add_string_handlers(self, string_handler_name, level="DEBUG",
                            formatter='%(asctime)s - %(levelname)s - %(filename)s - %(message)s'):
        log_level = self._get_level(level)
        handler = StringHandler(log_level, formatter)
        self.logger.addHandler(handler)
        self.add_string_handler_string_to_dict(string_handler_name, handler)

    def print_handlers(self):
        for handler in self.get_logger().handlers:
            print(handler)

    def add_string_handler_string_to_dict(self, handler_name, handler_obj):
        self.dict_log_string[handler_name] = handler_obj

    def get_string_handler_dict(self):
        return self.dict_log_string


def function_logger(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        log_obj = AppLogger()
        logger_app = log_obj.get_logger()

        """ call_file_name = (inspect.stack()[1].filename).split('/')[-1]
        line_number = inspect.stack()[1].lineno
        define_file_name = (function.__code__.co_filename).split('\\')[-1]"""

        logger_app.info(
            """Start function {func_name}, Arguments :  {args} """.format(
                func_name=function.__name__,
                args=args))
        start_time = datetime.now()
        function_result = function(*args, **kwargs)
        time_exe = (datetime.now() - start_time)

        formatted_time = "{:02d}H:{:02d}M:{:02d}S.{:03d}ms".format(time_exe.seconds // 3600,
                                                                   (time_exe.seconds // 60) % 60,
                                                                   time_exe.seconds % 60,
                                                                   time_exe.microseconds // 1000)

        logger_app.info("End function {func_name}, execution time: {time_exe} ".format(func_name=function.__name__,
                                                                                       time_exe=formatted_time))
        return function_result

    return wrapper


def function_logger_hide_psw(function):
    @wraps(function)
    def wrapper(*args, **kwargs):

        log_obj = AppLogger()
        logger_app = log_obj.get_logger()
        # file_name = inspect.stack()[1].filename
        file_path = function.__code__.co_filename
        file_name = file_path.split()[-1]

        if "password" in str(args):
            arg_value = args
            for index in range(len(args)):

                if isinstance(args[index], dict):
                    element_copy = args[index].copy()
                    element_copy['password'] = "XXXXXXXXX"
                    arg_value = element_copy
            logger_app.info(
                """Start function {func_name}, Arguments :  {args} """.format(
                    func_name=function.__name__,
                    args=arg_value))
        else:

            logger_app.info(
                "Start function {func_name} define in {file_name}, Arguments :  {args} ".format(
                    func_name=function.__name__,
                    file_name=file_name,
                    args=args))

        start_time = datetime.now()
        function_result = function(*args, **kwargs)
        time_exe = (datetime.now() - start_time)

        formatted_time = "{:02d}H:{:02d}M:{:02d}S.{:03d}ms".format(time_exe.seconds // 3600,
                                                                   (time_exe.seconds // 60) % 60,
                                                                   time_exe.seconds % 60,
                                                                   time_exe.microseconds // 1000)

        logger_app.info("End function {func_name}, execution time: {time_exe} ".format(func_name=function.__name__,
                                                                                       time_exe=formatted_time))
        return function_result

    return wrapper

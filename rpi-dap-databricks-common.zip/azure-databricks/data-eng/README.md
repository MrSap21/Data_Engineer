# Instructions for deployment:
1. Create tag in this format:
    **databricks-<notebook_dir>-<sub_dir>-<YYMMDD>-<incremental_index>**
2. Waiting for the end of pipeline **rpi-dap-adls**

Note: if you insert the following combination of tags: 
 - **databricks-ALL-ALL-<YYMMDD>-<incremental_index>** : copy all notebook on Databricks
 - **databricks-ALL-<sub_dir>-<YYMMDD>-<incremental_index>** : copy <sub_dir> in all Databricks Projects
 - **databricks-<notebook_dir>-ALL-<YYMMDD>-<incremental_index>** : copy all notebooks in Databricks <notebook_dir>
 - **databricks-<notebook_dir>-<sub_dir>-<YYMMDD>-<incremental_index>** : copy <pnotebook_dir>\<sub_dir> on Databricks

# Note: 
  if you inset notebook_directory = ALL, the pipeline distribute  all repositories under notebook/Shared folder
param(
    $region,
    $applicationId,
    $spKey,
    $resourceGroup,
    $subscriptionId,
    $workspaceName,
    $tenant_id
    )
Write-Host "$region"
Write-Host "$applicationId"
Write-Host "$resourceGroup"
Write-Host "$subscriptionId"
Write-Host "$tenant_id"

Install-Module -Name azure.databricks.cicd.tools -Scope CurrentUser -Force
Import-Module -Name azure.databricks.cicd.tools
Connect-Databricks -Region $region -ApplicationId $applicationId -Secret $spKey `
            -ResourceGroupName $resourceGroup `
            -SubscriptionId $subscriptionId `
            -WorkspaceName $workspaceName `
            -TenantId $tenant_id 
Write-Host "adb connect"
Write-Host "Use azure.databricks.cicd.tools to create bearer token" 
$Token = Invoke-DatabricksAPI -Method POST -API "api/2.0/token/create" -Body @{lifetime_seconds=1200;comment='token_test_2_min'}   
$BearerToken = $Token.token_value
$TokenId = $Token.token_info.token_id 
Write-Host "##vso[task.setVariable variable=bearerToken; issecret=true]$BearerToken"
Write-Host "##vso[task.setVariable variable=tokenId]$TokenId"
Write-Host "end script"



param(
    $region,
    $applicationId,
    $spKey,
    $resourceGroup,
    $subscriptionId,
    $workspaceName,
    $tenant_id,
    $tokenId
    )
Write-Host "$region"
Write-Host "$applicationId"
Write-Host "$resourceGroup"
Write-Host "$subscriptionId"
Write-Host "$tenant_id"

Install-Module -Name azure.databricks.cicd.tools -Scope CurrentUser -Force
Import-Module -Name azure.databricks.cicd.tools
Connect-Databricks -Region $region -ApplicationId $applicationId -Secret $spKey `
            -ResourceGroupName $resourceGroup `
            -SubscriptionId $subscriptionId `
            -WorkspaceName $workspaceName `
            -TenantId $tenant_id 
Write-Host "adb connect"
Write-Host "Use azure.databricks.cicd.tools to delete bearer token" 
Invoke-DatabricksAPI  -Method POST -API "api/2.0/token/delete" -Body @{token_id= $tokenId} 
Write-Host "token delete"
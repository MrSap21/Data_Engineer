# Azure Databricks Pipelines
# Installation of packages

## Prerequisites:
Install following python packages in DevOps agent(wba-dnap2) as `adoagent`:
- databricks-cli
- flake8
- flake8_formatter_junit_xml

example: `pip3 install databricks-cli --user --no-cache-dir`

UPDATE $db_param_staging.$pTD_DB_CIF.$pTABLE_NAME_1
SET   edw_etl_step = 'FKEY1'
WHERE cust_pref_prog_group_sk is not null
AND   edw_etl_step = 'FKEY'
AND src_sys_cd = '$pSRC_SYS_CD'
;

begin transaction;
UPDATE ${pDATABASE_DEV_STAGING}.${pTRETAIL_SCHEMA}.iri_ecom_transaction_cost_stg drv
set cost_dlrs=cost_dtl.cost_dlrs
FROM (
select a.sales_txn_id , a.sales_txn_dt, a.sales_txn_type, a.src_sys_cd,
a.line_item_seq_nbr, a.cost_dlrs
from ( select * from ${pDATABASE_RETAIL}.${pTRETAIL_SCHEMA}.sales_transaction_cost_dtl ) a , ${pDATABASE_DEV_STAGING}.${pTRETAIL_SCHEMA}.iri_ecom_transaction_cost_stg d
where a.src_sys_cd ='EC'
AND d.transaction_number=a.sales_txn_id
and d.transaction_date=a.sales_txn_dt
and d.sales_txn_type = a.sales_txn_type
and d.src_sys_cd = a.src_sys_cd
and d.line_item_seq_nbr = a.line_item_seq_nbr
qualify row_number() over(partition by a.sales_txn_id,a.sales_txn_dt,a.src_sys_cd,a.sales_txn_type,a.line_item_seq_nbr
order by a.sales_txn_id,a.sales_txn_dt,a.src_sys_cd,a.sales_txn_type,a.line_item_seq_nbr,a.cost_src_type_cd desc) = 1 ) cost_dtl
where drv.transaction_number=cost_dtl.sales_txn_id
and drv.transaction_date=cost_dtl.sales_txn_dt
and drv.sales_txn_type = cost_dtl.sales_txn_type
and drv.src_sys_cd = cost_dtl.src_sys_cd
and drv.line_item_seq_nbr = cost_dtl.line_item_seq_nbr;
UPDATE ${pDATABASE_DEV_STAGING}.${pTRETAIL_SCHEMA}.iri_ecom_transaction_cost_stg txn_drv
set cost_adj_dlrs=cost_adj.adj_dlrs,
loyalty_cost_adj_dlrs=cost_adj.loyalty_adj_dlrs
FROM (select sales_txn_id , sales_txn_dt, sales_txn_type, src_sys_cd, line_item_seq_nbr,adj_dlrs ,loyalty_adj_dlrs
from ( select * from  ${pDATABASE_RETAIL}.${pTRETAIL_SCHEMA}.sales_transaction_cost_adj where sales_txn_dt > current_date -30) where src_sys_cd ='EC'
group by 1,2,3,4,5,6,7) cost_adj
where txn_drv.transaction_number=cost_adj.sales_txn_id
and txn_drv.transaction_date=cost_adj.sales_txn_dt
and txn_drv.sales_txn_type = cost_adj.sales_txn_type
and txn_drv.src_sys_cd = cost_adj.src_sys_cd
and txn_drv.line_item_seq_nbr = cost_adj.line_item_seq_nbr;
WITH cmpgn_7 as 
(select audience_id, r.total_no_attempt, disposition_code as disp,r.store_nbr as store, c.rx_nbr, response_channel, c.response_id, response_dttm 
from ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_MARKETING}.campaign_resp r join  ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_MARKETING}.campaign_resp_cust c on c.response_id=r.response_id 
where r.campaign_cd='C000000375' and
r.response_channel in ('OUTBOUND','EMAIL', 'TEXT')  and
cast(r.response_dttm as date) >=cast('${extDttm1}' as date) and cast(r.response_dttm as date) <='${extDt2}'
and disposition_code in (38,39,40,41,51,9,20,22,30,34)),

stg_payer_scripts_tst_22 as
(select disp, store, a.rx_nbr, response_channel, response_id, fill_sold_dt, payer, payer2, response_dttm, dspn_fill_nbr
from cmpgn_7 a left join 
 (select p.rx_nbr,
p.relocate_fm_str_nbr as str_nbr,
p.rx_fill_nbr,
p.rx_partial_fill_nbr, 
p.dspn_fill_nbr,
p.fill_sold_dt,
pat_id,
case when plan_type in ('Medicare Part D') then 'Med D'
 when plan_type not in ('Cash', 'Discount Card', 'Medicare Part D', 'State Medicaid', 'Managed Medicaid') then 'Commercial'
 when plan_type in ('Managed Medicaid', 'State Medicaid') then 'Medicaid'
 when plan_type in ('Discount Card') and plan_name in ('Walgreens Prescription Savings Club') or plan_name in ('Walgreens WAGPlus') then 'Prescription saving Club /WAG +' 
 when (plan_type in ('Discount Card') and plan_name not in ('Walgreens Prescription Savings Club')) or plan_type in ('Cash') then 'Discount_Cards_Cash'     
 else 'Unknown'
end as payer,
case when plan_type in ('Discount Card','Cash') then 'CPRx' end as payer2
from
 (select rx_nbr,relocate_fm_str_nbr,str_nbr, rx_fill_nbr,rx_partial_fill_nbr, dspn_fill_nbr,fill_sold_dt,fill_enter_dt,pat_id, fill_sold_yr, fill_enter_mnth from ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_PHARMACY}.prescription_fill p  where  (partial_fill_cd is null or partial_fill_cd='P' ) and fill_sold_yr in ${fillsldyr} and fill_sold_dt between '${extDt1}' and '${extDt2}'  
 and fill_stat_cd = 'SD'
and fill_del_dt IS NULL
and  fill_sold_dt IS NOT NULL
and  fill_sold_dlrs IS NOT NULL
)p
left outer join 
(select pfp.* ,plan_type, plan_name, pc.plan_catg_eff_dt, pc.plan_catg_end_dt from 
(select * from ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_PHARMACY}.prescription_fill_plan  where cob_ind='N' and fill_adjud_cd in ('A','L','X') or fill_adjud_cd is null or fill_adjud_cd = '') pfp                  
left join   (select plan_catg_id, edw_eff_dt, third_party_plan_id, bin_nbr, prcs_ctrl_nbr, plan_group_nbr,  plan_name, plan_type,plan_catg_eff_dt,plan_catg_end_dt from ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_PHARMACY_PLAN}.plan_category where trim(history_seq_cd) = 'C' and src_sys_cd = 'IC' and trim(del_ind) = 'N') pc
            on   coalesce( pfp.third_party_plan_id, '#$#' ) = coalesce(  trim(pc.third_party_plan_id) , '#$#' ) 
            and  coalesce(  pfp.bin_nbr , '#$#'  ) = coalesce( trim(pc.bin_nbr), '#$#' )
            and coalesce(  pfp.prcs_ctrl_nbr , '#$#' ) = coalesce( trim(pc.prcs_ctrl_nbr), '#$#' )
            and  coalesce(  pfp.plan_group_nbr, '#$#'  ) = coalesce( trim(pc.plan_group_nbr), '#$#' )
where (pfp.fill_enter_dt between pc.plan_catg_eff_dt and coalesce(pc.plan_catg_end_dt,'9999-12-31') or pc.third_party_plan_id is NULL)
) PFP
 on p.rx_nbr=pfp.rx_nbr 
            and p.str_nbr=pfp.str_nbr 
            and p.rx_fill_nbr=pfp.rx_fill_nbr 
            and p.rx_partial_fill_nbr=pfp.rx_partial_fill_nbr
         and p.fill_sold_yr = pfp.fill_sold_yr
         and p.fill_enter_mnth = pfp.fill_enter_mnth          
            and pfp.fill_adjud_cd in ('A','L','X',null,'')          
group by p.rx_nbr,p.relocate_fm_str_nbr,p.rx_fill_nbr,p.rx_partial_fill_nbr, p.dspn_fill_nbr,p.fill_sold_dt,pat_id,plan_type,plan_name)b
on a.rx_nbr = b.rx_nbr and a.store = b.str_nbr 
where  (fill_sold_dt<to_date(response_dttm) or fill_sold_dt is null)),

stg_1_payer_scripts_22 as
(select disp, store, rx_nbr, response_channel, fill_sold_dt, payer, payer2, response_dttm from 
(select  disp, store, a.rx_nbr, response_channel, a.fill_sold_dt, payer, payer2, response_dttm,  row_number() over (partition by response_id,store,rx_nbr  order by fill_sold_dt desc , dspn_fill_nbr desc) as last_fill 
from stg_payer_scripts_tst_22 a)p where last_fill = 1
group by disp, store, rx_nbr, response_channel, fill_sold_dt, payer, payer2, response_dttm),

stg_2_payer_scripts_22 as 
(select disp, store, rx_nbr, response_channel, fill_sold_dt, payer, response_dttm from (
select disp, store, rx_nbr, response_channel, fill_sold_dt, payer, response_dttm from stg_1_payer_scripts_22 p
union
select disp, store, rx_nbr, response_channel, fill_sold_dt, payer2, response_dttm  from stg_1_payer_scripts_22 p where payer2 is not null
 )x group by disp, store, rx_nbr, response_channel, fill_sold_dt, payer, response_dttm), 

outbound_base_22 as 
(select disp, store, store_name,  rx_nbr, response_channel, case when payer is null then 'Unknown' else payer end as payer    from (
select r.disp, r.store, loc.store_name, r.rx_nbr, 'IVR_OUTBOUND' as response_channel, payer,
row_number() over  (partition by audience_id ,r.store, r.rx_nbr order by r.total_no_attempt desc ) as rnk
from cmpgn_7 r left join stg_2_payer_scripts_22 p on r.store  = p.store and r.rx_nbr = p.rx_nbr
left join ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_LOCATION}.location_store loc on r.store = loc.store_nbr and '${extDt2}'  between loc.edw_rec_begin_dt and loc.edw_rec_end_dt
where r.disp in (38,39,40,41,51) and r.response_channel = 'OUTBOUND'
and payer <> 'CPRx'
)x where rnk =1 
union 
select r.disp, r.store, loc.store_name, r.rx_nbr, 'IVR_OUTBOUND' as response_channel, payer
from cmpgn_7 r left join stg_2_payer_scripts_22  p on r.store  = p.store and r.rx_nbr = p.rx_nbr
left join ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_LOCATION}.location_store loc on r.store = loc.store_nbr and '${extDt2}' between loc.edw_rec_begin_dt and loc.edw_rec_end_dt
where r.response_channel in ( 'OUTBOUND' )  and
r.disp in (38,39,40,41,51)
and payer = 'CPRx'),

eml_8 as 
(select p.disp, a.store, store_name, a.rx_nbr, a.response_channel, case when payer is null then 'Unknown' else payer end as payer from cmpgn_7 a join stg_2_payer_scripts_22 p on 
a.store = p.store and a.rx_nbr = p.rx_nbr and a.response_dttm = p.response_dttm
left join ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_LOCATION}.location_store loc on a.store = loc.store_nbr and '${extDt2}'  between loc.edw_rec_begin_dt and loc.edw_rec_end_dt
where a.response_channel in ('EMAIL', 'TEXT') AND p.disp in (9,20,22,30,34))

select ad_week, store, store_name, campaign, response_channel, case when payer is null then 'Unknown' else payer end as payer, sum(distinct_count) as distinct_count, sum(delivered_counts) as delivered_counts, sum(refills_ordered_counts) as refills_ordered_counts , sum(do_not_refill_counts) as do_not_refill_counts , sum(refills_failure_counts) as refills_failure_counts from (
select from_unixtime(unix_timestamp('${extDt2}' ,'yyyy-MM-dd'), 'yyyyMMdd') as ad_week, 
store, 
store_name, 
'CIT Refill Reminder Integration (RRI)' as campaign, 
response_channel, 
payer, 
count(distinct rx_nbr) as distinct_count, 
sum(case when disp in ( 38,39,40,41,51) and response_channel in ( 'IVR_OUTBOUND' ) then 1 else 0 end) as delivered_counts,
sum(case when disp = 39 and response_channel in ('IVR_OUTBOUND') then 1 else 0 end) as refills_ordered_counts,
sum(case when disp = 40 and response_channel in ('IVR_OUTBOUND') then 1 else 0 end) as do_not_refill_counts,
sum(case when disp = 51 and response_channel in ('IVR_OUTBOUND') then 1 else 0 end) as refills_failure_counts
from outbound_base_22 a
group by from_unixtime(unix_timestamp('${extDt2}' ,'yyyy-MM-dd'), 'yyyyMMdd'), store, store_name, 'CIT Refill Reminder Integration (RRI)', response_channel, payer
union 
select ad_week, x.store, x.store_name, x.campaign, x.channel, x.payer, case when distinct_count is null then 0 else distinct_count end as distinct_count, delivered_counts, refills_ordered_counts, do_not_refill_counts, refills_failure_counts
from 
(select from_unixtime(unix_timestamp('${extDt2}' ,'yyyy-MM-dd'), 'yyyyMMdd') as ad_week, 
a.store, 
a.store_name, 
'CIT Refill Reminder Integration (RRI)' as campaign, 
a.response_channel as Channel, 
a.payer,  
sum(case when a.disp in (9) and a.response_channel in ('TEXT','EMAIL') then 1 else 0 end) as delivered_counts,
sum(case when a.disp in (20,22) and a.response_channel in ('EMAIL') then 1 else 0 end) as refills_ordered_counts,
sum(case when a.disp = 34 and a.response_channel in ('EMAIL')  then 1 else 0 end) as do_not_refill_counts,
sum(case when a.disp = 30 and a.response_channel in ('EMAIL') then 1 else 0 end) as refills_failure_counts
from eml_8 a  
group by from_unixtime(unix_timestamp('${extDt2}' ,'yyyy-MM-dd'), 'yyyyMMdd'), a.store, a.store_name, 'CIT Refill Reminder Integration (RRI)', a.response_channel, a.payer
) x 
left join (select count(distinct rx_nbr) as distinct_count , b.store, b.response_channel, b.payer from eml_8 b where disp = 9 and response_channel in ('TEXT','EMAIL') group by b.store, b.response_channel, b.payer) b on x.store = b.store and x.payer = b.payer and x.channel = b.response_channel
)x
group by ad_week, store, store_name, campaign, response_channel, case when payer is null then 'Unknown' else payer end;
select
segment_credit_card_link_chng_sk,
mast_cust_id,
card_id,
to_char(src_eff_dt,'YYYYMMDD') as src_eff_dt,
to_char(src_end_dt,'YYYYMMDD') as src_end_dt,
stat_cd,
to_char(edw_create_dttm,'YYYYMMDDHHMISS') as edw_create_dttm,
to_char(edw_update_dttm,'YYYYMMDDHHMISS') as edw_update_dttm,
edw_batch_id
from ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_CUSTOMER}.segmentation_credit_card_link
where edw_update_dttm > TO_TIMESTAMP_NTZ(CURRENT_DATE - 30);
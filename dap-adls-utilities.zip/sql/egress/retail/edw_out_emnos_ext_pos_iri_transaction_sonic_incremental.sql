update            ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg 
from         ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg drv, ( 
select a.sales_txn_id ,  a.sales_txn_dt,  a.sales_txn_type,  a.src_sys_cd,
                        a.ord_pickup_type, a.ord_pickup_loc 
from    ${pDataBase_retail}.${pTD_DB_retail_sales}.Sales_Transaction_addtl a , ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg d
where a.src_sys_cd ='POS' and (a.sales_txn_dt between to_date('${pSQL_PARM_1}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_1}' )
 AND d.sales_txn_id=a.sales_txn_id 
            and            d.sales_txn_dt=a.sales_txn_dt 
            and            d.sales_txn_type = a.sales_txn_type 
            and            d.src_sys_cd = a.src_sys_cd 
            
qualify row_number() over(partition by a.sales_txn_id,a.sales_txn_dt,a.src_sys_cd,a.sales_txn_type 
order  by a.sales_txn_id,a.sales_txn_dt,a.src_sys_cd,a.sales_txn_type,a.src_sys_cd desc) = 1 ) sales_dtl 
set               ord_pickup_type = sales_dtl.ord_pickup_type ,
             ord_pickup_loc = sales_dtl.ord_pickup_loc
where   drv.sales_txn_id=sales_dtl.sales_txn_id 
            and            drv.sales_txn_dt=sales_dtl.sales_txn_dt 
            and            drv.sales_txn_type =sales_dtl.sales_txn_type 
            and            drv.src_sys_cd = sales_dtl.src_sys_cd ;
           
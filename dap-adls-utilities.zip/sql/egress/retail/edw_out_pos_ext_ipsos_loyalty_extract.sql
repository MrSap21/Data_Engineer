with leb as 
(
SELECT  aa.store_nbr , bb.ad_wk_end_dt ,sum(enroll_cnt)  as no_of_enrollments from (
(SELECT enrl_dt ,store_nbr , count(*) as enroll_cnt from "${pDATABASE_MARKETING}"."${pTD_VIEW_DB_LOYAL}".loyalty_enrollment  
where enrl_dt between '${pEXT_DATE_1}' and  to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'  group by 1,2) aa 
join 
(SELECT  * from "${pDATABASE_Master_Data}"."${pTD_VIEW_DB_CAL}".dim_promo_period  where ad_wk_begin_dt 
between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day' )bb
on  enrl_dt between ad_wk_begin_dt and ad_wk_end_dt) group by 1,2
)
select 
to_char(tgt.ad_wk_end_dt,'YYYYMMDD') as ad_wk, 
tgt.store_nbr as store_nbr,
tgt.store_name as store_brand,
tgt.no_of_enrollments as num_of_enrollments,
sum(CAST(tgt.earned_points AS DECIMAL(18,0))) as earned_points, 
sum(CAST(tgt.base_points_earned AS DECIMAL(18,0))) as base_points_earned, 
sum(CAST(tgt.bonus_points_earned AS DECIMAL(18,0))) as bonus_points_earned,
sum(CAST(tgt.points_redeemed AS DECIMAL(18,0))) as points_redeemed, 
sum(CAST(tgt.non_transaction_points AS DECIMAL(18,0))) as non_transaction_points,
sum(CAST(tgt.adjustment_points AS DECIMAL(18,0))) as adjustment_points
from 	
(
Select 
dpp.ad_wk_end_dt,
lp.sales_txn_dt, 
lp.store_nbr,
lstr.store_name,
coalesce(leb.no_of_enrollments,0)as no_of_enrollments,
case when lp.pnt_txn_type_cd in ('N','T','O') then lp.pnt_val else 0 end earned_points,
case when (lp.pnt_txn_type_cd ='T' and ad_evt_seq_nbr = 'P515') then lp.pnt_val else 0 end base_points_earned,
case when (lp.pnt_txn_type_cd ='T' and ad_evt_seq_nbr <> 'P515') then lp.pnt_val else 0 end bonus_points_earned,
case when lp.pnt_txn_type_cd ='R' then lp.pnt_val else 0 end points_redeemed,
case when lp.pnt_txn_type_cd ='N' then lp.pnt_val else 0 end non_transaction_points,
case when lp.pnt_txn_type_cd ='O' then lp.pnt_val else 0 end adjustment_points
from  
(select * from "${pDATABASE_Master_Data}"."${pTD_VIEW_DB_CAL}".dim_promo_period where ad_wk_begin_dt between '${pEXT_DATE_1}'and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day')dpp
inner join
(Select  lpa.store_nbr,lpd.sales_txn_dt, lpd.sales_txn_id, lpd.sales_txn_type,lpd.src_sys_cd,lpd.pnt_txn_type_cd,lpd.pnt_val,lpd.ad_evt_seq_nbr ,lpa.loyalty_vndr_txn_id 
 from (select sales_txn_dt,sales_txn_id,sales_txn_type,src_sys_cd,pnt_txn_type_cd,pnt_val,ad_evt_seq_nbr ,loyalty_vndr_txn_id from "${pDATABASE_CONSUMPTION}"."${pTD_VIEW_OUT}".loyalty_point_activity_detail 
	where sales_txn_dt between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day' )lpd
inner join 
(select loyalty_mbr_id,sales_txn_dt,sales_txn_id,sales_txn_type,src_sys_cd,store_nbr,loyalty_vndr_txn_id from "${pDATABASE_MARKETING}"."${pTD_VIEW_DB_LOYAL}".loyalty_point_activity 
        where  sales_txn_dt between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day' )lpa
        on lpd.loyalty_vndr_txn_id =lpa.loyalty_vndr_txn_id
	and lpd.sales_txn_id = lpa.sales_txn_id
	and lpd.sales_txn_dt = lpa.sales_txn_dt
	and lpd.sales_txn_type = lpa.sales_txn_type
	and lpd.src_sys_cd = lpa.src_sys_cd 
	) lp
	on  lp.sales_txn_dt between dpp.ad_wk_begin_dt and dpp.ad_wk_end_dt
left outer join leb
	on leb.store_nbr=lp.store_nbr 
	and dpp.ad_wk_end_dt = leb.ad_wk_end_dt
left outer join "${pDATABASE_Master_Data}"."${pTD_VIEW_DB_LOC}".location_store lstr 
	on lp.store_nbr = lstr.store_nbr
	and lp.sales_txn_dt between lstr.edw_rec_begin_dt and lstr.edw_rec_end_dt 
	)tgt
group by 
ad_wk,
store_nbr,
store_brand,
num_of_enrollments;

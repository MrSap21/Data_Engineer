SELECT 
	store_nbr,
        state_cd,
        store_name,
        city,
        zip_cd_4,
        zip_cd_5,
        addr_line_1,
        addr_line_2,
        longitude,
        latitude,
        open_dt,
        close_dt,
        operation_nbr,
        operation_name,
        region_nbr,
        region_name,
        area_nbr,
        area_name,
        district_nbr,
        district_name

FROM "${pDATABASE_CONSUMPTION}"."${pTD_VIEW_DB_OUT}"."DIM_LOCATION_IRI_CUR_EXT";

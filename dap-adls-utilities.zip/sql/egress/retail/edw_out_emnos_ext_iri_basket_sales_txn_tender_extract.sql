select 
Distinct
sales_txn_id,
sales_txn_dt,
ewic_wic_ind,
ebt_ind
from 
${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg;

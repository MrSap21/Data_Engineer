select  to_char(b.ad_wk_end_dt,'YYYYMMDD') as ad_wk, 
b.ad_evt_id,
ops_study_nbr as ops_dept_nbr,
upc_nbr_cnt
from
(
select ad_wk_end_dt,
ad_wk_period_id from ${pDataBase_MasterData}.${pTD_VIEW_CALENDAR}.dim_promo_period where ad_wk_begin_dt 
between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day' 
) dpp
inner join
(
select  
b.ad_wk_begin_dt, 
b.ad_wk_end_dt , 
b.ad_wk_period_id, 
a.ad_evt_id,
a.break_dt 
from ${pDataBase_Retail}.${pTD_VIEW_PROMOTIONS}.ad_event a, ${pDataBase_MasterData}.${pTD_VIEW_CALENDAR}.dim_promo_period b 
where  a.break_dt between b.ad_wk_begin_dt and b.ad_wk_end_dt  
and b.ad_wk_begin_dt  between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'
and (a.page_cnt > 0 or a.spot_cnt > 0)
and ad_evt_type_cd = 'ROT') b 
on b.break_dt between b.ad_wk_begin_dt and b.ad_wk_end_dt
inner join
(
select  ad_evt_id, 
ops_dept_nbr as ops_study_nbr,
count(p.upc_nbr) as upc_nbr_cnt
from ${pDataBase_Retail}.${pTD_VIEW_PROMOTIONS}.fct_adwk_upc  c 
inner join ${pDataBase_MasterData}.${pTD_VIEW_PRODUCT}.product p on c.upc_nbr = p.upc_nbr and p.edw_rec_end_dt='9999-12-31' and p.src_sys_cd='POS'
inner join ${pDataBase_MasterData}.${pTD_VIEW_PRODUCT}.product_hierarchy ph on p.prod_sk = ph.prod_sk and ph.edw_rec_end_dt='9999-12-31' and ph.src_sys_cd='POS' group by 1,2
) c 
on b.ad_evt_id = c.ad_evt_id   order by 1,3;

SELECT 
        sales_txn_id,
        sales_txn_dt,
        sales_txn_type,
        src_sys_cd,
        store_nbr,
        CAST(SUBSTR(CAST(txn_end_dttm AS VARCHAR(30)),12,19) AS TIME(0)) as txn_time,
        product_key,
        prod_sk,
        spend_amount,
        loyalty_mbr_id,
        quantity,
        cust_id,
        list_price_dlrs,
        qty_to_return ,
        item_list_price,
        item_net_price ,
        line_item_seq_nbr,
        case when (sales_txn_type = 'R') then (qty_to_return)
        else (quantity) end AS item_quantity,
        case when sales_txn_type = 'R' then 'Y' else 'N' end AS  return_indicator ,
        item_gross_amount,
        mid,
        credit_card,
        wic,
        null as cost_dlrs,
        null as cost_adj_dlrs,
        null as loyalty_cost_adj_dlrs,
        null as gross_profit,
        sale_ind
                
FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.${pSRC_TABLE_NAME} iri_stg
where not exists (select 1 from ${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.sales_transaction_ord_shipment opt_out
where
( (iri_stg.sales_txn_id = opt_out.sales_txn_id
and iri_stg.sales_txn_dt = opt_out.sales_txn_dt
and iri_stg.sales_txn_type = opt_out.sales_txn_type
and iri_stg.src_sys_cd = opt_out.src_sys_cd
and  opt_out.vndr = 'Store'
and (opt_out.sales_txn_dt between to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_2}'
)
)
)
)
;
delete from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.IRI_POS_DRIVER_STG;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.IRI_POS_DRIVER_STG 

with sales_txn_iri_pos_ext_a as

(
select a.sales_txn_id,
a.sales_txn_dt,
a.sales_ord_src_type,
a.sales_txn_type,
a.src_sys_cd,
b.store_nbr,
a.upc_nbr,
a.prod_sk,
b.txn_end_dttm,
a.line_item_seq_nbr,
a.wag_coup_cd , 
a.selling_price_dlrs ,
a.unit_qty ,
a.upc_desc,
a.txn_type,
a.return_ind,
a.sale_ind,
a.rx_nbr,
a.original_price_dlrs,
a.mfg_coup_cd,
a.item_unit_price_dlrs,
CASE 
WHEN a.edw_create_dttm > coalesce(b.edw_create_dttm,to_date('0001-01-01','YYYY-MM-DD' )) THEN a.edw_create_dttm
WHEN b.edw_create_dttm > coalesce(a.edw_create_dttm,to_date('0001-01-01','YYYY-MM-DD' )) THEN b.edw_create_dttm 
END AS edw_create_dttm
from 
(select * from (select * from  ${pDataBase_retail}.${pTD_DB_retail_sales}.SALES_TRANSACTION_DETAIL where  src_sys_cd='POS' and sales_txn_dt > current_date - 45 ) a ,
(select max(EXTRACT_DATE ) as EXTRACT_DATE  from ${pDataBase_etl}.PRDSTGMET.PROC_CNTRL_EXTRACT_BATCH_META_DETAIL_STG  
where proj_name='IRI_extracts' and src_stream_name='transaction_file_ext' and extract_name='IRI_transaction_file' AND extract_create_dt <> to_date('0001-01-01','YYYY-MM-DD' ) ) c
where sales_txn_dt  between c.EXTRACT_DATE-30 and c.EXTRACT_DATE  and src_sys_cd='POS' )  a,
${pDataBase_retail}.${pTD_DB_retail_sales}.SALES_TRANSACTION  b
WHERE
a.sales_txn_id=b.sales_txn_id
AND a.sales_txn_dt=b.sales_txn_dt
AND a.sales_ord_src_type=b.sales_ord_src_type  
AND a.sales_txn_type=b.sales_txn_type
AND a.src_sys_cd=b.src_sys_cd
AND a.src_sys_cd='POS'
AND a.ITEM_VOID_CD='--'    
AND a.PRICE_VERIFY_IND = 'N'  
AND b.TXN_TYPE IN ('10', '11', '12', '13', '14','15','16','25') 
AND b.POST_VOID_STATUS_CD = '--'    
AND b.TXN_INCOMPLETE_IND = 'N'    
AND b.TRAINING_TXN_IND = 'N'    
AND a.UNIT_QTY > 0   
AND a.RX_NBR IS  NULL
)

select
pgrm.sales_txn_id,
pgrm.sales_txn_dt,
pgrm.sales_ord_src_type,
pgrm.sales_txn_type,
pgrm.src_sys_cd,
pgrm.store_nbr,
pgrm.upc_nbr,
pgrm.prod_sk,
pgrm.txn_end_dttm,
pgrm.mfg_coup_cd ,
pgrm.wag_coup_cd, 
pgrm.return_ind ,
pgrm.sale_ind,
pgrm.item_list_price ,
pgrm.tot_selling_price_dlrs,
pgrm.quantity,
pgrm.line_item_seq_nbr,
pgrm.edw_create_dttm
from
(
select
a.sales_txn_id ,
a.sales_txn_dt,
a.sales_ord_src_type ,
a.sales_txn_type ,
a.src_sys_cd,
a.store_nbr,
a.upc_nbr,
a.prod_sk,
a.txn_end_dttm, 
a.mfg_coup_cd , 
a.wag_coup_cd ,
a.return_ind ,
a.sale_ind,
MAX(CASE           
WHEN  a.item_unit_price_dlrs > 0  THEN (a.item_unit_price_dlrs)
WHEN (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0 )  and (a.unit_qty is not null and a.unit_qty <> 0 ) THEN (a.selling_price_dlrs) /(a.unit_qty)
ELSE  coalesce(a.item_unit_price_dlrs,0)
END)  as item_list_price ,
SUM(a.selling_price_dlrs) AS tot_selling_price_dlrs ,
SUM(a.unit_qty) AS quantity,
MAX(a.line_item_seq_nbr) as line_item_seq_nbr,  
MAX(a.edw_create_dttm) as edw_create_dttm 

FROM sales_txn_iri_pos_ext_a a

where a.sales_txn_dt = to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')
and a.return_ind ='N'
and a.mfg_coup_cd = '--'
and a.wag_coup_cd = '--'

group by 1,2,3,4,5,6,7,8,9,10,11,12,13

UNION ALL

select
a.sales_txn_id ,
a.sales_txn_dt,
a.sales_ord_src_type ,
a.sales_txn_type ,
a.src_sys_cd,
a.store_nbr,
a.upc_nbr,
a.prod_sk,
a.txn_end_dttm, 
a.mfg_coup_cd , 
a.wag_coup_cd ,
a.return_ind ,
a.sale_ind,
MAX(CASE           
WHEN  a.item_unit_price_dlrs > 0  THEN (a.item_unit_price_dlrs)
WHEN (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0 )  and (a.unit_qty is not null and a.unit_qty <> 0 ) THEN (a.selling_price_dlrs) /(a.unit_qty)
ELSE  coalesce(a.item_unit_price_dlrs,0)
END)  as item_list_price ,
SUM(a.selling_price_dlrs) AS tot_selling_price_dlrs ,
SUM(a.unit_qty) AS quantity,
MAX(a.line_item_seq_nbr) as line_item_seq_nbr,  
MAX(a.edw_create_dttm) as edw_create_dttm 

FROM sales_txn_iri_pos_ext_a a
where a.sales_txn_dt between to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD')-30  and to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD') -1 and
a.edw_create_dttm > '${pSQL_PARM_1}'

and a.return_ind ='N'
and a.mfg_coup_cd = '--'
and a.wag_coup_cd = '--'

group by 1,2,3,4,5,6,7,8,9,10,11,12,13

UNION ALL 

select
a.sales_txn_id ,
a.sales_txn_dt,
a.sales_ord_src_type ,
a.sales_txn_type ,
a.src_sys_cd,
a.store_nbr,
a.upc_nbr,
a.prod_sk,
a.txn_end_dttm, 
a.mfg_coup_cd , 
a.wag_coup_cd ,
a.return_ind ,
a.sale_ind,
MAX(CASE           
WHEN a.return_ind = 'Y' and a.item_unit_price_dlrs > 0   THEN -1* (a.item_unit_price_dlrs)
WHEN a.return_ind = 'Y' and a.item_unit_price_dlrs < 0   THEN  (a.item_unit_price_dlrs)          
WHEN a.return_ind = 'Y'  and  (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0)  and a.selling_price_dlrs > 0 and (a.unit_qty is not null and a.unit_qty <> 0 )  THEN -1* (a.selling_price_dlrs)/(a.unit_qty)
WHEN a.return_ind = 'Y'  and  (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0)  and (a.unit_qty is not null and a.unit_qty <> 0 ) THEN  (a.selling_price_dlrs)/(a.unit_qty)           
WHEN ( a.wag_coup_cd <> '--' and a.mfg_coup_cd <> '--' )  THEN 0  
ELSE  coalesce(a.item_unit_price_dlrs,0)
END ) as item_list_price ,
SUM(a.selling_price_dlrs) AS tot_selling_price_dlrs ,
SUM(CASE WHEN (a.wag_coup_cd <> '--' or a.mfg_coup_cd <> '--' ) THEN 0 ELSE a.unit_qty END) AS quantity,
MAX(a.line_item_seq_nbr) as line_item_seq_nbr,  
MAX(a.edw_create_dttm) as edw_create_dttm 

FROM sales_txn_iri_pos_ext_a a

where a.sales_txn_dt = to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')

and (a.return_ind ='Y'
or  a.mfg_coup_cd <> '--'
or a.wag_coup_cd <> '--')
group by 1,2,3,4,5,6,7,8,9,10,11,12,13

UNION ALL

select
a.sales_txn_id ,
a.sales_txn_dt,
a.sales_ord_src_type ,
a.sales_txn_type ,
a.src_sys_cd,
a.store_nbr,
a.upc_nbr,
a.prod_sk,
a.txn_end_dttm, 
a.mfg_coup_cd , 
a.wag_coup_cd ,
a.return_ind ,
a.sale_ind,
MAX(CASE           
WHEN a.return_ind = 'Y' and a.item_unit_price_dlrs > 0   THEN -1* (a.item_unit_price_dlrs)
WHEN a.return_ind = 'Y' and a.item_unit_price_dlrs < 0   THEN  (a.item_unit_price_dlrs)          
WHEN a.return_ind = 'Y'  and  (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0)  and a.selling_price_dlrs > 0 and (a.unit_qty is not null and a.unit_qty <> 0 )  THEN -1* (a.selling_price_dlrs)/(a.unit_qty)
WHEN a.return_ind = 'Y'  and  (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0)  and (a.unit_qty is not null and a.unit_qty <> 0 ) THEN  (a.selling_price_dlrs)/(a.unit_qty)           
WHEN ( a.wag_coup_cd <> '--' and a.mfg_coup_cd <> '--' )  THEN 0  
ELSE  coalesce(a.item_unit_price_dlrs,0)
END  ) as item_list_price ,
SUM(a.selling_price_dlrs) AS tot_selling_price_dlrs ,
SUM(CASE WHEN (a.wag_coup_cd <> '--' or a.mfg_coup_cd <> '--' ) THEN 0 ELSE a.unit_qty END) AS quantity,
MAX(a.line_item_seq_nbr) as line_item_seq_nbr,  
MAX(a.edw_create_dttm) as edw_create_dttm 

FROM sales_txn_iri_pos_ext_a a
where a.sales_txn_dt between to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD')-30  and to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD') -1 and
a.edw_create_dttm > '${pSQL_PARM_1}'

and (a.return_ind ='Y'
or  a.mfg_coup_cd <> '--'
or a.wag_coup_cd <> '--')
group by 1,2,3,4,5,6,7,8,9,10,11,12,13
) pgrm;
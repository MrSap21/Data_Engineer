select from_unixtime(unix_timestamp(ad_wk_end_dt ,'yyyy-MM-dd'), 'yyyyMMdd') as ad_week,
store_nbr as Store_nbr,
open_24_hrs_ind,
from_unixtime(unix_timestamp(open_24_hrs_dt ,'yyyy-MM-dd'), 'yyyyMMdd') as open_24_hrs_dt,
clinic_ind,
atm_ind,
cigarette_dept_ind,
convenience_food_dept_ind,
liquor_dept_ind,
one_hr_photo_ind,
phrm_dept_ind,
self_svc_dept_ind,
case when drv_thru_type in ('','None') then 'N'
when drv_thru_type in ( 'Single','Double', 'Triple') then 'Y'
when drv_thru_type is NULL then NULL END AS drv_thru_ind,
sbu_environ,
(COALESCE(general_sales_sqft,0)+
COALESCE(general_stock_sqft,0)+
COALESCE(convenience_sqft,0)+
COALESCE(rx_sales_sqft,0)+
COALESCE(rx_wait_rm_sales_sqft,0)+
COALESCE(liquor_sales_sqft,0)+
COALESCE(liquor_stock_sqft,0)+
COALESCE(photo_sales_sqft,0)+
COALESCE(second_floor_sales_sqft,0)+
COALESCE(second_floor_stock_sqft,0)+
COALESCE(basement_sales_sqft,0)+
COALESCE(basement_stock_sqft,0))as store_total_square_footage
from 
(select * from ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_CALENDAR}.dim_promo_period where ad_wk_end_dt between '${extDt1}' and '${extDt2}') a left outer join ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_LOCATION}.location_store b
on edw_rec_end_dt = day_dt
where ad_wk_end_dt between edw_rec_begin_dt and edw_rec_end_dt 
and store_stat_val='Open';

select
to_char(ad_wk_end_dt,'YYYYMMDD') as ad_wk,
b.ad_evt_id ,
ad_evt_vers_mkt_cd, 
total_page_cnt, 
total_spot_cnt
from	
(
select	* from	${pDataBase_MasterData}.${pTD_VIEW_CALENDAR}.dim_promo_period 
where ad_wk_begin_dt between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}'::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day' ) dpp
join
(
select 
ad_evt_id, 
break_dt as Ad_Week,
sum(page_cnt) as total_page_cnt,
sum(spot_cnt) as total_spot_cnt , 
ad_evt_vers_mkt_cd
from ${pDataBase_Retail}.${pTD_VIEW_PROMOTIONS}.ad_event 
where ad_evt_type_cd = 'ROT'  
and (page_cnt > 0 
or spot_cnt > 0 )
group by ad_evt_id, break_dt , ad_evt_vers_mkt_cd
) b 
on  b.Ad_Week between ad_wk_begin_dt and ad_wk_end_dt;


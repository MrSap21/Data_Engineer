delete from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.${pTD_DB_ecom_txn_drv};

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg
(sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
src_sys_cd,
store_nbr,
product_key,
prod_sk,
txn_end_dttm,
spend_amount,
margin,
quantity,
line_item_seq_nbr,
sale_ind,
prod_type_cd,
mid,
loyalty_mbr_id,
credit_card,
wic,
list_price_dlrs,
qty_to_return,
item_list_price,
item_net_price,
item_gross_amount,
cost_dlrs,
cost_adj_dlrs,
loyalty_cost_adj_dlrs,
edw_create_dttm,
ind
)
select 
pgm.sales_txn_id,
pgm.sales_txn_dt,
pgm.sales_ord_src_type,
pgm.sales_txn_type,
pgm.src_sys_cd,
pgm.store_nbr,
pgm.product_key,
pgm.prod_sk,
pgm.txn_end_dttm,
pgm.spend_amount,
pgm.margin,
pgm.quantity,
pgm.line_item_seq_nbr,
pgm.sale_ind,
null as prod_type_cd,
null as mid,
null as loyalty_mbr_id,
null as credit_card,
null as wic,
pgm.list_price_dlrs,
pgm.qty_to_return,
pgm.item_list_price,
pgm.item_net_price,
pgm.item_gross_amount,
null as cost_dlrs,
null as cost_adj_dlrs,
null as loyalty_cost_adj_dlrs,
edw_create_dttm,
'EC' as ind
from(
select 
d.sales_txn_id,
d.sales_txn_dt,
d.sales_ord_src_type,
d.sales_txn_type,
d.src_sys_cd,
d.store_nbr,
d.upc_nbr as product_key,
d.prod_sk,
d.txn_end_dttm,
d.selling_price_dlrs as spend_amount,
d.selling_price_dlrs - d.prod_cost_dlrs as margin,
d.unit_qty as quantity,
d.line_item_seq_nbr,
d.sale_ind,
d.list_price_dlrs,
d.qty_to_return,
d.item_list_price,
case when((d.sales_txn_type = 'R') and (d.qty_to_return<>0 and d.qty_to_return is not null) and d.selling_price_dlrs > 0)
                                then  ((-1*d.selling_price_dlrs)/d.qty_to_return)
                when((d.sales_txn_type = 'R') and (d.qty_to_return<>0 and d.qty_to_return is not null))
                    then  (d.selling_price_dlrs/d.qty_to_return)
                when ((d.sales_txn_type not in ('R'))  and (d.unit_qty<>0 and d.unit_qty is not null)) then (d.selling_price_dlrs/d.unit_qty)
                 else 0
end as item_net_price,
CASE when (d.sales_txn_type = 'R') then (d.item_list_price*d.qty_to_return)
                ELSE (d.item_list_price*d.unit_qty) end
as item_gross_amount,
d.edw_create_dttm
from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_inc_driver_stg d)pgm 
where (sales_txn_id , sales_txn_dt , line_item_seq_nbr)
not in (select  sales_txn_id ,  txn_dt as sales_txn_dt  , line_item_seq_nbr 
FROM ${pDATABASE_RETAIL}.${pTD_VIEW_DB_PHOTO}.photo_order_sales_transaction
WHERE txn_dt  between to_date('${pSQL_PARM_1}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_1}' );


delete from ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg
SELECT distinct
sales_txn_id,
sales_txn_dt,
tndr_type_cd,
'N' as ewic_wic_ind,
'N' as ebt_ind
from ${pDataBase_retail}.${pTD_DB_retail_sales}.sales_transaction_tender 
where sales_txn_dt between to_char(DATEADD(DAY, -30, '${pSQL_PARM_1}'), 'YYYY-MM-DD')  and (to_date('${pSQL_PARM_1}' ::VARCHAR(30), 'YYYY-MM-DD')) 
and src_sys_cd='POS';


update ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg
set ewic_wic_ind='Y'
where sales_txn_id in (select distinct sales_txn_id from ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg 
where tndr_type_cd IN ('23','102','267','430') );


update ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg
set ebt_ind='Y'
where sales_txn_id in (select distinct sales_txn_id from ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg
where tndr_type_cd IN ('24','25','101','297','365') );

CREATE TEMPORARY TABLE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_basket_temp as
select 
sales_txn_dt  as transaction_date ,
CAST(SUBSTR(CAST(txn_end_dttm AS VARCHAR(30)),12,19) AS TIME(0)) as  transaction_time,
sales_txn_id as transaction_number,
store_nbr as store_number,
loyalty_mbr_id as loyalty_card_number,
mid,
to_decimal(credit_card,18,0) as credit_card,
sum(quantity) as item_total_quantity,
sum(item_gross_amount) as gross_sales_amount,
sum(case 
when mfg_coup_cd = '--' and wag_coup_cd = '--' then  (item_gross_amount) - (item_net_price * quantity)
else item_net_price end) as reduction_total_amount,
ord_pickup_type,
ord_pickup_loc
FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg where product_key  not in (42000000957,42000000907) group by 1,2,3,4,5,6,7,11,12; 



CREATE TEMPORARY TABLE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_sales_txn_tender_ext_temp as
select 
Distinct
sales_txn_id,
sales_txn_dt,
ewic_wic_ind,
ebt_ind
from 
${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg;


create temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_basket_final_temp as 
select 
transaction_date,
transaction_time,
transaction_number,
to_decimal(store_number,30,0) as store_number,
loyalty_card_number,
NVL2(mid, 'E' || mid, mid) AS mid,
NVL2(credit_card, 'C' || to_varchar(credit_card), to_varchar(credit_card)) AS card_id,
to_decimal(item_total_quantity,18,0) as item_total_quantity,
to_decimal(gross_sales_amount,15,2) as gross_sales_amount,
to_decimal(reduction_total_amount,18,2) as reduction_total_amount,
ewic_wic_ind,
ebt_ind,
ord_pickup_type,
ord_pickup_loc
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_basket_temp 
left outer join 
${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_sales_txn_tender_ext_temp
on ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_basket_temp.transaction_number=${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_sales_txn_tender_ext_temp.sales_txn_id
and ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_basket_temp.transaction_date=${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_sales_txn_tender_ext_temp.sales_txn_dt;

delete from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_basket_ext_stg;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_basket_ext_stg
select 
transaction_date,
transaction_time,
transaction_number,
to_decimal(store_number,30,0) as store_number,
loyalty_card_number,
mid,
card_id,
to_decimal(item_total_quantity,18,0) as item_total_quantity,
to_decimal(gross_sales_amount,15,2) as gross_sales_amount,
to_decimal(reduction_total_amount,18,2) as reduction_total_amount,
ewic_wic_ind,
ebt_ind,
ord_pickup_type,
ord_pickup_loc
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_basket_final_temp iri_stg
left outer join
(select cust_src_id 
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.ccpa_stage_optout_table_stg opt_out 
where opt_out.composite_type_cd = 'M' 
          and opt_out.msg_type_cd = '1' 
          and opt_out.src_sys_cd = 'LR'
) csi
on iri_stg.loyalty_card_number=csi.cust_src_id 
left outer join
(select 'E' || opt_out.cust_src_id as mid_1
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.ccpa_stage_optout_table_stg opt_out 
where opt_out.composite_type_cd = 'A' 
          and opt_out.msg_type_cd = '2' 
          and opt_out.src_sys_cd = 'CDI'
) ecsi 
on iri_stg.mid=ecsi.mid_1
where csi.cust_src_id is null 
and ecsi.mid_1 is null;

UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg drv
set mid=cust.cdi_cust_src_id
FROM    ${pDataBase_consumption}.${pTD_PRDFDLVWB}.link_to_customer cust
 where drv.cust_id=cust.cust_src_id
and drv.ind=cust.cust_src_cd
and cust.cdi_msg_type_cd = '2'
and cust.cust_src_cd = '${pSRC_SYS_CD}'
and cust.edw_rec_end_dt = '9999-12-31' ;
UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg drv
set loyalty_mbr_id=pg.prog_cust_id
FROM    ( select 
sales_txn_id,
src_sys_cd,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
prog_type_cd,
prog_cust_id,
case when prog_type_cd ='LYCD' then 1
                                when prog_type_cd ='VCD' then 2
                                when prog_type_cd ='APPLE_WALLET' then 3
                                when prog_type_cd ='ANDROID_PAY' then 4 end as qty
								

from ${pDataBase_retail}.${pTD_DB_retail_sales}.sales_transaction_program
where src_sys_cd = ${pSRC_SYS_CD}
and sales_txn_dt between to_date('${pSQL_PARM_1}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_1}'
and prog_type_cd IN ('LYCD','VCD','APPLE_WALLET','ANDROID_PAY')
qualify row_number() over(partition by sales_txn_id,src_sys_cd,sales_txn_dt,sales_ord_src_type,sales_txn_type
                                order by sales_txn_id,src_sys_cd,sales_txn_dt,sales_ord_src_type,sales_txn_type,qty) = 1 ) pg
                                
where  drv.sales_txn_id=pg.sales_txn_id
and drv.sales_txn_dt=pg.sales_txn_dt
and drv.sales_ord_src_type=pg.sales_ord_src_type
and drv.sales_txn_type=pg.sales_txn_type
and drv.src_sys_cd=pg.src_sys_cd
and pg.src_sys_cd=${pSRC_SYS_CD}
and pg.prog_type_cd IN ('LYCD','VCD','APPLE_WALLET','ANDROID_PAY')
AND pg.prog_cust_id is NOT NULL;

delete from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.${pTD_DB_ecom_drv};

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_inc_driver_stg
(sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
src_sys_cd,
store_nbr,
upc_nbr,
prod_sk,
txn_end_dttm,
selling_price_dlrs,
prod_cost_dlrs,
unit_qty,
line_item_seq_nbr,
sale_ind,
list_price_dlrs,
qty_to_return,
item_list_price,
edw_create_dttm
)
with SALES_TXN_IRI_ECOMM_EXT_a as (
select a.sales_txn_id,
a.sales_txn_dt,
a.sales_ord_src_type,
a.sales_txn_type,
a.src_sys_cd,
b.store_nbr,
a.upc_nbr,
a.prod_sk,
b.txn_end_dttm,
a.line_item_seq_nbr,
a.sale_ind,
a.wag_coup_cd , 
a.selling_price_dlrs ,
a.unit_qty ,
a.prod_cost_dlrs,
a.list_price_dlrs,
a.qty_to_return,
a.item_unit_price_dlrs,
CASE WHEN a.edw_create_dttm > coalesce(b.edw_create_dttm,TO_TIMESTAMP('00010101000000', 'YYYYMMDDHHMISS' )) THEN a.edw_create_dttm
WHEN b.edw_create_dttm > coalesce(a.edw_create_dttm,TO_TIMESTAMP('00010101000000', 'YYYYMMDDHHMISS' )) THEN b.edw_create_dttm END AS edw_create_dttm
from 
(select * from (select * from  ${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.SALES_TRANSACTION_DETAIL
where  src_sys_cd='EC' and sales_txn_dt > current_date - 45 ) a ,
(select 
max(EXTRACT_DATE ) as EXTRACT_DATE 
from ${pDATABASE_ETL}.PRDSTGMET.PROC_CNTRL_EXTRACT_BATCH_META_DETAIL_STG
where proj_name='IRI_extracts' and src_stream_name = 'etransaction_file_ext' and extract_name='IRI_etransaction_file' and extract_create_dt <> to_date('0001-01-01' ::VARCHAR(255), 'YYYY-MM-DD')) c
where sales_txn_dt  between c.EXTRACT_DATE-255 and c.EXTRACT_DATE  and src_sys_cd='EC' )  a,
${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.SALES_TRANSACTION b
where  a.sales_txn_id=b.sales_txn_id
and  a.sales_txn_dt=b.sales_txn_dt
and  a.sales_ord_src_type=b.sales_ord_src_type
and a.sales_txn_type=b.sales_txn_type
and a.src_sys_cd=b.src_sys_cd
and a.src_sys_cd='EC'
and a.sales_ord_src_type <> 'R'
)
select 
pgm.sales_txn_id,
pgm.sales_txn_dt,
pgm.sales_ord_src_type,
pgm.sales_txn_type,
pgm.src_sys_cd,
pgm.store_nbr,
pgm.upc_nbr,
pgm.prod_sk,
pgm.txn_end_dttm,
pgm.selling_price_dlrs,
pgm.prod_cost_dlrs,
pgm.unit_qty,
pgm.line_item_seq_nbr,
pgm.sale_ind,
pgm.list_price_dlrs,
pgm.qty_to_return,
pgm.item_list_price,
edw_create_dttm
from(
select 
a.sales_txn_id,
a.sales_txn_dt,
a.sales_ord_src_type,
a.sales_txn_type,
a.src_sys_cd,
'5995' as store_nbr,
null as upc_nbr,
a.prod_sk,
a.txn_end_dttm,
a.sale_ind,
max(a.list_price_dlrs) as list_price_dlrs,
sum(a.qty_to_return) as qty_to_return ,
max(a.edw_create_dttm) as edw_create_dttm ,
max(a.line_item_seq_nbr) as line_item_seq_nbr,
coalesce (sum(a.selling_price_dlrs),'0') as selling_price_dlrs,
coalesce (sum(a.prod_cost_dlrs),'0') as prod_cost_dlrs,
SUM(a.unit_qty) AS unit_qty,
max(case when ((a.item_unit_price_dlrs is NULL or a.item_unit_price_dlrs = 0) and a.sales_txn_type not in ('R')
                                                                and (a.unit_qty > 0 and a.unit_qty is not null))
                                                then (a.selling_price_dlrs/a.unit_qty)
                                when ( (a.item_unit_price_dlrs is NULL or a.item_unit_price_dlrs = 0)
                                                                                and a.sales_txn_type = 'R' and a.selling_price_dlrs > 0 and (a.qty_to_return > 0 and a.qty_to_return is not null))
                                                then (-1*(a.selling_price_dlrs/a.qty_to_return))
                                 when ( (a.item_unit_price_dlrs is NULL or a.item_unit_price_dlrs = 0)
                                                                                and a.sales_txn_type = 'R' and a.selling_price_dlrs < 0 and (a.qty_to_return > 0 and a.qty_to_return is not null) )
                                                then (a.selling_price_dlrs/a.qty_to_return)
                                when ( a.sales_txn_type = 'R' and  a.item_unit_price_dlrs > 0 )
                                                then (-1 * (a.item_unit_price_dlrs))
                                else  coalesce(a.item_unit_price_dlrs,0)
                end)
     as item_list_price	 
FROM SALES_TXN_IRI_ECOMM_EXT_a a
 where a.sales_txn_dt = to_date('${pSQL_PARM_2}' ::VARCHAR(255), 'YYYY-MM-DD')
group by 1,2,3,4,5,6,7,8,9,10
union all
select 
b.sales_txn_id,
b.sales_txn_dt,
b.sales_ord_src_type,
b.sales_txn_type,
b.src_sys_cd,
'5995' as store_nbr,
null as upc_nbr,
b.prod_sk,
b.txn_end_dttm,
b.sale_ind,
max(b.list_price_dlrs) as list_price_dlrs,
sum(b.qty_to_return) as qty_to_return,
max(b.edw_create_dttm) as edw_create_dttm ,
max(b.line_item_seq_nbr) as line_item_seq_nbr,
coalesce (sum(b.selling_price_dlrs),'0') as selling_price_dlrs,
coalesce (sum(b.prod_cost_dlrs),'0') as prod_cost_dlrs,
SUM(b.unit_qty) AS unit_qty,
max(case when ((b.item_unit_price_dlrs is NULL or b.item_unit_price_dlrs = 0) and b.sales_txn_type not in ('R')
                                                                and (b.unit_qty > 0 and b.unit_qty is not null))
                                                then (b.selling_price_dlrs/b.unit_qty)
                                when ( (b.item_unit_price_dlrs is NULL or b.item_unit_price_dlrs = 0)
                                                                                and b.sales_txn_type = 'R' and b.selling_price_dlrs > 0 and (b.qty_to_return > 0 and b.qty_to_return is not null))
                                                then (-1*(b.selling_price_dlrs/b.qty_to_return))
                                 when ( (b.item_unit_price_dlrs is NULL or b.item_unit_price_dlrs = 0)
                                                                                and b.sales_txn_type = 'R' and b.selling_price_dlrs < 0 and (b.qty_to_return > 0 and b.qty_to_return is not null) )
                                                then (b.selling_price_dlrs/b.qty_to_return)
                                when ( b.sales_txn_type = 'R' and  b.item_unit_price_dlrs > 0 )
                                                then (-1 * (b.item_unit_price_dlrs))
                                else  coalesce(b.item_unit_price_dlrs,0)
                end)
     as item_list_price	 
FROM SALES_TXN_IRI_ECOMM_EXT_a b
 where b.sales_txn_dt between to_date('${pSQL_PARM_2}'::VARCHAR(255), 'YYYY-MM-DD')-255  and to_date('${pSQL_PARM_2}'::VARCHAR(255), 'YYYY-MM-DD') -1 and 
b.edw_create_dttm > '${pSQL_PARM_1}'
group by 1,2,3,4,5,6,7,8,9,10) pgm;


--STEP2---
delete from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.${pTD_DB_ecom_txn_drv};

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg
(sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
src_sys_cd,
store_nbr,
product_key,
prod_sk,
txn_end_dttm,
spend_amount,
margin,
quantity,
line_item_seq_nbr,
sale_ind,
prod_type_cd,
mid,
loyalty_mbr_id,
credit_card,
wic,
list_price_dlrs,
qty_to_return,
item_list_price,
item_net_price,
item_gross_amount,
cost_dlrs,
cost_adj_dlrs,
loyalty_cost_adj_dlrs,
edw_create_dttm,
ind
)
select 
pgm.sales_txn_id,
pgm.sales_txn_dt,
pgm.sales_ord_src_type,
pgm.sales_txn_type,
pgm.src_sys_cd,
pgm.store_nbr,
pgm.product_key,
pgm.prod_sk,
pgm.txn_end_dttm,
pgm.spend_amount,
pgm.margin,
pgm.quantity,
pgm.line_item_seq_nbr,
pgm.sale_ind,
null as prod_type_cd,
null as mid,
null as loyalty_mbr_id,
null as credit_card,
null as wic,
pgm.list_price_dlrs,
pgm.qty_to_return,
pgm.item_list_price,
pgm.item_net_price,
pgm.item_gross_amount,
null as cost_dlrs,
null as cost_adj_dlrs,
null as loyalty_cost_adj_dlrs,
edw_create_dttm,
'EC' as ind
from(
select 
d.sales_txn_id,
d.sales_txn_dt,
d.sales_ord_src_type,
d.sales_txn_type,
d.src_sys_cd,
d.store_nbr,
d.upc_nbr as product_key,
d.prod_sk,
d.txn_end_dttm,
d.selling_price_dlrs as spend_amount,
d.selling_price_dlrs - d.prod_cost_dlrs as margin,
d.unit_qty as quantity,
d.line_item_seq_nbr,
d.sale_ind,
d.list_price_dlrs,
d.qty_to_return,
d.item_list_price,
case when((d.sales_txn_type = 'R') and (d.qty_to_return<>0 and d.qty_to_return is not null) and d.selling_price_dlrs > 0)
                                then  ((-1*d.selling_price_dlrs)/d.qty_to_return)
                when((d.sales_txn_type = 'R') and (d.qty_to_return<>0 and d.qty_to_return is not null))
                    then  (d.selling_price_dlrs/d.qty_to_return)
                when ((d.sales_txn_type not in ('R'))  and (d.unit_qty<>0 and d.unit_qty is not null)) then (d.selling_price_dlrs/d.unit_qty)
                 else 0
end as item_net_price,
CASE when (d.sales_txn_type = 'R') then (d.item_list_price*d.qty_to_return)
                ELSE (d.item_list_price*d.unit_qty) end
as item_gross_amount,
d.edw_create_dttm
from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_inc_driver_stg d)pgm 
where (sales_txn_id , sales_txn_dt , line_item_seq_nbr)
not in (select  sales_txn_id ,  txn_dt as sales_txn_dt  , line_item_seq_nbr 
FROM ${pDATABASE_RETAIL}.${pTD_VIEW_DB_PHOTO}.photo_order_sales_transaction
WHERE txn_dt  between to_date('${pSQL_PARM_2}' ::VARCHAR(255), 'YYYY-MM-DD')-255 and '${pSQL_PARM_2}' );

--STEP3--

UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg drv
set loyalty_mbr_id=pg.prog_cust_id
FROM   ${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.sales_transaction_program pg
where  drv.sales_txn_id=pg.sales_txn_id
and drv.sales_txn_dt=pg.sales_txn_dt
and drv.sales_ord_src_type=pg.sales_ord_src_type
and drv.sales_txn_type=pg.sales_txn_type
and drv.src_sys_cd=pg.src_sys_cd
and pg.src_sys_cd='EC'
and pg.sales_txn_dt between to_date('${pSQL_PARM_2}' ::VARCHAR(255), 'YYYY-MM-DD')-255 and '${pSQL_PARM_2}'
and pg.prog_cust_id is NOT NULL
and pg.prog_type_cd IN ('LYCD','VCD','APPLE_WALLET','ANDROID_PAY');


--STEP4--
UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg drv
set product_key=prd.upc, wic=prd.wic
FROM    ${pDATABASE_MASTER_DATA}.${pTD_VIEW_DB_PRODUCT}.product prd
 where drv.prod_sk=prd.prod_sk
and drv.ind=prd.src_sys_cd
and prd.edw_rec_end_dt = to_date('9999-12-31' ::VARCHAR(255), 'YYYY-MM-DD')
and prd.prod_sk not in (select prod_sk from ${pDataBase_Staging}.${pTD_DB_retail_sales}.ecom_product_nonumrc_upc_stg);

--STEP5--
UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg drv
set credit_card=tndr.card_id
FROM    (select d.* from
(select a.sales_txn_dt,
a.sales_txn_id,
a.src_sys_cd,
a.sales_ord_src_type,
a.sales_txn_type,
a.card_hash_val_sk,
z.card_id,
row_number()over( partition by a.sales_txn_dt,a.sales_txn_id,a.src_sys_cd,a.sales_ord_src_type,a.sales_txn_type order by 
a.tndr_dlrs
desc ) as rownum
from 
(select * from 
${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.sales_transaction_tender 
where src_sys_cd='${pSRC_SYS_CD}'
and card_hash_val_sk <>-1 
and (sales_txn_dt between to_date('${pSQL_PARM_2}' ::VARCHAR(255), 'YYYY-MM-DD')-255 and '${pSQL_PARM_2}' )
and (sales_txn_dt,sales_txn_id,src_sys_cd,sales_ord_src_type,sales_txn_type) 
in
(select sales_txn_dt,sales_txn_id,src_sys_cd,sales_ord_src_type,sales_txn_type 
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg group by 1,2,3,4,5)  ) a
inner join (select * from ${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.Tender_Card_Hash where card_id <> -1) z
on a.card_hash_val_sk = z.card_hash_val_sk
)d where rownum=1) tndr
where drv.sales_txn_id=tndr.sales_txn_id
and  drv.sales_txn_dt=tndr.sales_txn_dt
and drv.sales_ord_src_type=tndr.sales_ord_src_type
and drv.sales_txn_type=tndr.sales_txn_type
and drv.src_sys_cd=tndr.src_sys_cd
and drv.credit_card is null;


--STEP6--


UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg drv
set               cost_dlrs=cost_dtl.cost_dlrs 
FROM    ( 
select a.sales_txn_id ,  a.sales_txn_dt,  a.sales_txn_type,  a.src_sys_cd,
                        a.line_item_seq_nbr, a.cost_dlrs 
from    ${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.sales_transaction_cost_dtl a , ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg d
where a.src_sys_cd ='EC' 
 AND d.sales_txn_id=a.sales_txn_id 
            and            d.sales_txn_dt=a.sales_txn_dt 
            and            d.sales_txn_type = a.sales_txn_type 
            and            d.src_sys_cd = a.src_sys_cd 
            and     d.line_item_seq_nbr = a.line_item_seq_nbr
qualify            row_number() over(partition by a.sales_txn_id,a.sales_txn_dt,a.src_sys_cd,a.sales_txn_type,a.line_item_seq_nbr 
order  by a.sales_txn_id,a.sales_txn_dt,a.src_sys_cd,a.sales_txn_type,a.line_item_seq_nbr,a.cost_src_type_cd desc) = 1 ) cost_dtl 
where   drv.sales_txn_id=cost_dtl.sales_txn_id 
            and            drv.sales_txn_dt=cost_dtl.sales_txn_dt 
            and            drv.sales_txn_type = cost_dtl.sales_txn_type 
            and            drv.src_sys_cd = cost_dtl.src_sys_cd 
            and     drv.line_item_seq_nbr = cost_dtl.line_item_seq_nbr;
 




                UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg txn_drv
set cost_adj_dlrs=cost_adj.adj_dlrs,
       loyalty_cost_adj_dlrs=cost_adj.loyalty_adj_dlrs 
FROM    (select sales_txn_id ,  sales_txn_dt,  sales_txn_type,  src_sys_cd,  line_item_seq_nbr,adj_dlrs ,loyalty_adj_dlrs
from ${pDATABASE_CONSUMPTION}.${pTD_VIEW_DB_prdfdlvwb}.sales_transaction_cost_adj where src_sys_cd ='EC'
group by 1,2,3,4,5,6,7) cost_adj
where txn_drv.sales_txn_id=cost_adj.sales_txn_id
and txn_drv.sales_txn_dt=cost_adj.sales_txn_dt
and txn_drv.sales_txn_type = cost_adj.sales_txn_type
and txn_drv.src_sys_cd = cost_adj.src_sys_cd
                and txn_drv.line_item_seq_nbr = cost_adj.line_item_seq_nbr;



--STEP7--
create temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_etransaction_tmp as
(SELECT 
        sales_txn_id,
        sales_txn_dt,
        sales_txn_type,
        src_sys_cd,
        to_decimal(store_nbr,12,0) as store_nbr,
        CAST(SUBSTR(CAST(txn_end_dttm AS VARCHAR(255)),12,19) AS TIME(0)) as txn_time,
        to_decimal(product_key,14,0) as product_key,
        to_decimal(prod_sk,14,0) as prod_sk,
        to_decimal(spend_amount,12,2) as spend_amount,
        loyalty_mbr_id,
        to_decimal(quantity,18,0) as quantity,
        cust_id,
        to_decimal(list_price_dlrs,12,2) as list_price_dlrs,
        to_decimal(qty_to_return,18,0) as qty_to_return,
        to_decimal(item_list_price,12,2) as item_list_price,
        to_decimal(item_net_price,12,2) as item_net_price,
        to_decimal(line_item_seq_nbr,18,0) as line_item_seq_nbr,
        case when (sales_txn_type = 'R') then (qty_to_return)
        else (quantity) end AS item_quantity,
        case when sales_txn_type = 'R' then 'Y' else 'N' end AS  return_indicator ,
        to_decimal(item_gross_amount,12,2) as item_gross_amount,
        mid,
        to_decimal(credit_card,18,0) as credit_card,
        to_decimal(wic,18,0) as wic,
        null as cost_dlrs,
        null as cost_adj_dlrs,
        null as loyalty_cost_adj_dlrs,
        null as gross_profit,
        sale_ind
                
FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.${pSRC_TABLE_NAME});
--step creating etransaction .dat--

create temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_etransaction_dat_tmp as
select 
sales_txn_dt as transaction_date,
txn_time as transaction_time,
sales_txn_id as transaction_number,
store_nbr as store_number,
loyalty_mbr_id as loyalty_card_number,
NVL2(mid ,'E' || mid , mid ) as mid,
NVL2(credit_card ,'C' || to_varchar(credit_card) , to_varchar(credit_card) ) as card_id,
product_key as upc,
wic,
prod_sk as retailer_product_identifier,
item_list_price,
item_net_price,
item_quantity,
null as weighted_item_weight,
null as weighted_item_count,
null as item_deal_quantity,
null as item_sale_quantity,
null as item_net_amount,
item_gross_amount ,
return_indicator,
cost_dlrs,
cost_adj_dlrs,
loyalty_cost_adj_dlrs,
gross_profit,
sale_ind
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_etransaction_tmp;
--step implementing ccpa logic and creating final .dat temp table--
--create temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_etransaction_ccpa_dat_tmp as
delete from ${pDataBase_Staging}.${pTD_DB_retail_sales}.${pTABLE_NAME_CCPA_IRI_ETRANSACTION_STG};

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.${pTABLE_NAME_CCPA_IRI_ETRANSACTION_STG}
WITH opt_out as
(select
cust_src_id, src_sys_cd,
composite_type_cd,
msg_type_cd,
Optout_begin_dt,optout_end_dt
from ${pDATABASE_RETAIL}.${pTD_VIEW_DB_CCPA}.${pSQL_PARM_1_CCPA}
where reqst_type_cd = 'OPTOUT'
and current_date() between optout_begin_dt and optout_end_dt
group by 1,2,3,4,5,6
UNION
select
cdi_cust_src_id as cust_src_id, 'CDI' as src_sys_cd, cdi_composite_type_cd,cdi_msg_type_cd,
Optout_begin_dt,optout_end_dt
from
(SELECT src_sys_cd, cust_src_id,Optout_begin_dt,optout_end_dt
FROM ${pDATABASE_RETAIL}.${pTD_VIEW_DB_CCPA}.${pSQL_PARM_1_CCPA} where src_sys_cd in
(select src_sys_cd from ${pDataBase_Staging}.${pTD_VIEW_DB_CCPA}.${pSQL_PARM_2_CCPA} where src_sys_cd <> 'CDI')
And reqst_type_cd = 'OPTOUT' and current_date() between optout_begin_dt and optout_end_dt group by 1,2,3,4) a
inner join ${pDATABASE_MASTER_DATA}.${pTD_VIEW_DB_CUSTOMER}.${pSQL_PARM_3_LINK} b
ON a.cust_src_id=b.cust_src_id
and a.src_sys_cd=b.cust_src_cd
and b.cdi_msg_type_cd in ('1','2')
group by 1,2,3,4,5,6
)
SELECT	
transaction_date, 
transaction_time, 
transaction_number,
store_number, 
loyalty_card_number, 
mid,
card_id, 
upc, 
wic, 
retailer_product_identifier,
item_list_price, 
item_net_price, 
item_quantity,
weighted_item_weight,
weighted_item_count,
item_deal_quantity, 
item_sale_quantity,
item_net_amount,
item_gross_amount,
return_indicator,
cost_dlrs,
cost_adj_dlrs, 
loyalty_cost_adj_dlrs,
gross_profit, 
sale_ind
FROM	${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_etransaction_dat_tmp iri_stg
left outer join
(select cust_src_id 
from opt_out 
where opt_out.composite_type_cd = 'M' 
          and opt_out.msg_type_cd = '1' 
          and opt_out.src_sys_cd = 'LR'
) csi
on iri_stg.loyalty_card_number=csi.cust_src_id 
left outer join
(select 'E' || opt_out.cust_src_id as mid_1
from opt_out 
where opt_out.composite_type_cd = 'A' 
          and opt_out.msg_type_cd = '2' 
          and opt_out.src_sys_cd = 'CDI'
) ecsi 
on iri_stg.mid=ecsi.mid_1
where csi.cust_src_id is null 
and ecsi.mid_1 is null;


---step creating addl file--
delete from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_etransaction_addl_stg;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_etransaction_addl_stg
select 
sales_txn_dt as transaction_date,
txn_time as transaction_time,
sales_txn_id as transaction_number,
sales_txn_type,
src_sys_cd,
store_nbr as store_number,
loyalty_mbr_id as loyalty_card_number,
spend_amount as selling_price,
product_key as upc,
prod_sk as retailer_product_identifier,
item_list_price,
item_net_price,
line_item_seq_nbr,
item_quantity,
null as weighted_item_weight,
null as weighted_item_count,
null as item_deal_quantity,
null as item_sale_quantity,
null as item_net_amount,
item_gross_amount,
return_indicator,
NVL2(mid ,'E' || mid , mid ) as mid,
NVL2(credit_card ,'C' || to_varchar(credit_card) , to_varchar(credit_card) ) as card_id,
cost_dlrs,
cost_adj_dlrs,
loyalty_cost_adj_dlrs,
gross_profit,
wic,
sale_ind
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_etransaction_tmp;
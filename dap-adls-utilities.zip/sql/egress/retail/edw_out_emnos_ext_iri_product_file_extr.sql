SELECT
p.upc_nbr
,p.upc
,p.upc_desc
,p.src_sys_cd
,ph.ops_dept_nbr
,ph.ops_dept_name
,ph.prod_cat_nbr
,ph.prod_cat_name
,p.mfr_nbr
,p.mfr_name
,p.brd_prod_id
,p.brd_name
,p.first_scan_dt
,p.item_discontinued_dt
,p.unit_of_measure_abbr
,p.private_label_brd_ind
,p.item_service_type
,ph.sls_cat_prod_id
,ph.sls_cat_name
,ph.mdse_div_nbr
,ph.mdse_div_name
,ph.mdse_cat_nbr
,ph.mdse_cat_name
,ph.pln_nbr
,ph.pln_desc 
,p.prod_sk
,p.prod_desc
,p.gmm_nbr
,p.gmm_name
,p.basic_prod_ind
,p.whse_prod_vendor_name
,p.wic
,p.same_retail_link_nbr
,s.store_count

FROM

( 
SELECT 
upc_nbr
,upc
,upc_desc
,src_sys_cd
,mfr_nbr
,mfr_name
,brd_prod_id
,brd_name
,first_scan_dt
,item_discontinued_dt
,unit_of_measure_abbr
,private_label_brd_ind
,item_service_type
,prod_sk
,prod_desc
,gmm_nbr
,gmm_name
,basic_prod_ind
,whse_prod_vendor_name
,wic
,same_retail_link_nbr


FROM ${pDATABASE_MASTER_DATA}.${pTD_VIEW_DB_OUTP}.product 
WHERE src_sys_cd in ('POS') 
AND  EDW_REC_END_DT = ${pTD_EDW_END_DATE}) p

LEFT OUTER JOIN 

(
SELECT 
ops_dept_nbr
,ops_dept_name
,prod_cat_nbr
,prod_cat_name
,sls_cat_prod_id
,sls_cat_name
,mdse_div_nbr
,mdse_div_name
,mdse_cat_nbr
,mdse_cat_name
,pln_nbr
,pln_desc
,prod_sk
,src_sys_cd

FROM ${pDATABASE_MASTER_DATA}.${pTD_VIEW_DB_OUTP}.product_hierarchy 
WHERE src_sys_cd = 'POS' 
AND  EDW_REC_END_DT = ${pTD_EDW_END_DATE}) ph

ON p.prod_sk=ph.prod_sk 
AND  p.src_sys_cd=ph.src_sys_cd 


left outer join

(select upc_nbr,
count(*)  as store_count
from
(
select upc_nbr,
substr(sales_txn_id,1,5) as str_nbr
from ${pDATABASE_CONSUMPTION}.${pTD_VIEW_DB_OUTS}.sales_transaction_detail where sales_txn_dt >= $pEXT_RUN_DT and sales_txn_dt <= to_date($pEXT_RUN_DT ::VARCHAR(30), 'YYYY-MM-DD') + Interval '6 day' and src_sys_cd in ('POS')group by 1,2) a group by 1) s
on p.src_sys_cd='POS' and coalesce(TO_VARCHAR(p.upc_nbr),'#')=coalesce(TO_VARCHAR(s.upc_nbr),'#')

union


SELECT
p.upc_nbr
,p.upc
,p.upc_desc
,p.src_sys_cd
,ph.ops_dept_nbr
,ph.ops_dept_name
,ph.prod_cat_nbr
,ph.prod_cat_name
,p.mfr_nbr
,p.mfr_name
,p.brd_prod_id
,p.brd_name
,p.first_scan_dt
,p.item_discontinued_dt
,p.unit_of_measure_abbr
,p.private_label_brd_ind
,p.item_service_type
,ph.sls_cat_prod_id
,ph.sls_cat_name
,ph.mdse_div_nbr
,ph.mdse_div_name
,ph.mdse_cat_nbr
,ph.mdse_cat_name
,ph.pln_nbr
,ph.pln_desc 
,p.prod_sk
,p.prod_desc
,p.gmm_nbr
,p.gmm_name
,p.basic_prod_ind
,p.whse_prod_vendor_name
,p.wic
,p.same_retail_link_nbr
,s.store_count

FROM

( 
SELECT 
upc_nbr
,upc
,upc_desc
,src_sys_cd
,mfr_nbr
,mfr_name
,brd_prod_id
,brd_name
,first_scan_dt
,item_discontinued_dt
,unit_of_measure_abbr
,private_label_brd_ind
,item_service_type
,prod_sk
,prod_desc
,gmm_nbr
,gmm_name
,basic_prod_ind
,whse_prod_vendor_name
,wic
,same_retail_link_nbr


FROM ${pDATABASE_MASTER_DATA}.${pTD_VIEW_DB_OUTP}.product 
WHERE src_sys_cd in ('EC') 
AND  EDW_REC_END_DT = ${pTD_EDW_END_DATE}) p

LEFT OUTER JOIN 

(
SELECT 
ops_dept_nbr
,ops_dept_name
,prod_cat_nbr
,prod_cat_name
,sls_cat_prod_id
,sls_cat_name
,mdse_div_nbr
,mdse_div_name
,mdse_cat_nbr
,mdse_cat_name
,pln_nbr
,pln_desc
,prod_sk
,src_sys_cd

FROM ${pDATABASE_MASTER_DATA}.${pTD_VIEW_DB_OUTP}.product_hierarchy 
WHERE src_sys_cd = 'EC' 
AND  EDW_REC_END_DT = ${pTD_EDW_END_DATE}) ph

ON p.prod_sk=ph.prod_sk 
AND  p.src_sys_cd=ph.src_sys_cd 


left outer join

(select upc_nbr,
count(*)  as store_count
from
(
select upc_nbr
from ${pDATABASE_CONSUMPTION}.${pTD_VIEW_DB_OUTS}.sales_transaction_detail where sales_txn_dt >= $pEXT_RUN_DT and sales_txn_dt <= to_date($pEXT_RUN_DT ::VARCHAR(30), 'YYYY-MM-DD') + Interval '6 day' and src_sys_cd in ('EC')group by 1) a group by 1) s
on p.src_sys_cd='EC' 
and  coalesce(p.upc,'#')=coalesce(TO_VARCHAR(s.upc_nbr),'#');

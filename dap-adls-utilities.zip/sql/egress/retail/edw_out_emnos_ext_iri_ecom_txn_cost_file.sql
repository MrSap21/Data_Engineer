SELECT 
        transaction_date,        
        transaction_time,
        transaction_number,
        null as store_number,
	null as loyalty_card_number,
	null as mid,
	null as card_id,
	upc,
	null as wic,
	retailer_product_identifier,
	null as item_list_price,
	null as item_net_price,
	null as item_quantity,
	null as weighted_item_weight,
	null as weighted_item_count,
	null as item_deal_quantity,
	null as item_sale_quantity,
	null as item_net_amount,
	null as item_gross_amount,
	null as return_indicator,
        cost_dlrs,
        cost_adj_dlrs,
        loyalty_cost_adj_dlrs,
        (selling_price - COALESCE(cost_dlrs, 0) + COALESCE(cost_adj_dlrs, 0) + COALESCE(loyalty_cost_adj_dlrs, 0)) as gross_profit,
        null as sale_ind
                
FROM ${pDATABASE_DEV_STAGING}.${pTRETAIL_SCHEMA}.${pSRC_TABLE_NAME};


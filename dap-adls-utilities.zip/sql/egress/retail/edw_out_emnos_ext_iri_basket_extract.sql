select 
sales_txn_dt  as transaction_date ,
CAST(SUBSTR(CAST(txn_end_dttm AS VARCHAR(23)),12,19) AS TIME(0)) as  transaction_time,
sales_txn_id as transaction_number,
store_nbr as store_number,
loyalty_mbr_id as loyalty_card_number,
mid,
credit_card,
sum(quantity) as item_total_quantity,
sum(item_gross_amount) as gross_sales_amount,
sum(case 
when mfg_coup_cd = '--' and wag_coup_cd = '--' then  (item_gross_amount) - (item_net_price * quantity)
else item_net_price end) as reduction_total_amount,
ord_pickup_type,
ord_pickup_loc
FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg where product_key  not in (42000000957,42000000907) group by 1,2,3,4,5,6,7,11,12; 

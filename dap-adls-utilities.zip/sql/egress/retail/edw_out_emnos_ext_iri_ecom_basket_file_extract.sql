with ebasket_1 as 
(
select sales_txn_dt,
CAST(SUBSTR(CAST(txn_end_dttm AS VARCHAR(23)),12,19) AS TIME(0))  AS txn_time,
sales_txn_id,
store_nbr,
loyalty_mbr_id,
sales_txn_type,
mid,
credit_card,
sum(case when (sales_txn_type = 'R') then (qty_to_return) else (quantity) end) AS item_total_quantity ,
sum(item_gross_amount) as gross_sales_amount,
(case when (sales_txn_type = 'R') then (sum(item_gross_amount - (item_net_price*qty_to_return))) 
else (sum( item_gross_amount - (item_net_price*quantity)))
end) as reduction_total_amount
from ${pTD_staging}.${pTD_retail_sales}.IRI_ECOM_TRANSACTION_INC_DRIVER_STG iri_stg
where not exists 
(
select 1 from ${pTD_retail}.${pTD_retail_sales}.sales_transaction_ord_shipment opt_out
 where
 ( (iri_stg.sales_txn_id = opt_out.sales_txn_id
 and iri_stg.sales_txn_dt = opt_out.sales_txn_dt
 and iri_stg.sales_txn_type = opt_out.sales_txn_type 
 and iri_stg.src_sys_cd = opt_out.src_sys_cd
 and  opt_out.vndr = 'Store' 
and (opt_out.sales_txn_dt between to_date('${pRUN_DT}' ::VARCHAR(30), 'YYYY-MM-DD') - Interval '${pSQL_PARM_3}  day' and '${pRUN_DT}')
   ) 
 )
)
group by
1,2,3,4,5,6,7,8
), ccpa_iri_ecom_basket_temp as 



(
select sales_txn_dt,
txn_time AS sales_txn_time,
sales_txn_id as txn_nbr,
store_nbr,
loyalty_mbr_id,
sales_txn_type,
NVL2(mid ,'E' || mid , mid ) as mid,
NVL2(credit_card ,'C' || to_varchar(credit_card) , to_varchar(credit_card) ) as card_id,
item_total_quantity,
gross_sales_amount,
reduction_total_amount,
'N' as ewic_wic_ind,
'N' as ebt_ind 
from ebasket_1

)

select
to_date(sales_txn_dt ::VARCHAR(30), 'YYYY-MM-DD') AS sales_txn_dt,
sales_txn_time,
txn_nbr,
store_nbr,
loyalty_mbr_id,
mid,
card_id,
to_decimal(item_total_quantity,8,0) AS item_total_quantity,
to_decimal(gross_sales_amount,18,2) as gross_sales_amount,
to_decimal(reduction_total_amount,8,2) as reduction_total_amount,
ewic_wic_ind,
ebt_ind
FROM ccpa_iri_ecom_basket_temp as iri_stg
where not exists (select 1 from ${pTD_staging}.${pTD_retail_sales}.CCPA_STAGE_OPTOUT_TABLE_STG opt_out
 where
 ( (iri_stg.loyalty_mbr_id = opt_out.cust_src_id
and opt_out.composite_type_cd = 'M'
 and opt_out.msg_type_cd = '1'
 and opt_out.src_sys_cd = 'LR')
or
(iri_stg.mid = 'E'||opt_out.cust_src_id
and opt_out.composite_type_cd = 'A'
 and opt_out.msg_type_cd = '2'
 and opt_out.src_sys_cd = 'CDI')));
delete from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.${pTABLE_NAME_CCPA_IRI_ETRANSACTION_STG};

  create temporary table prod_typ_1  (
        sales_txn_dt DATE NOT NULL,
        prod_sk BIGINT ,
        prod_type_cd VARCHAR(4) ,
        src_sys_cd VARCHAR(10) ,
        store_nbr INTEGER,
        src_sys_prod_id_1 VARCHAR(40)  )
       ;



create temporary table dim_code_1
       ( src_cd_val VARCHAR(20) ,
      src_sys_cd VARCHAR(10) 
      )
      ;


insert into prod_typ_1
SELECT d.sales_txn_dt,
    d.prod_sk,
    d.prod_type_cd,
    d.src_sys_cd,
    d.store_nbr,
    d.src_sys_prod_id_1
    FROM(select sales_txn_dt,prod_sk,prod_type_cd,src_sys_cd,store_nbr,src_sys_prod_id_1 from  ${pDataBase_master_data}.${pTD_product}.product_type
    where 
  src_sys_cd='POS'
and sales_txn_dt between to_char(DATEADD(DAY, -30, CAST('${pSQL_PARM_1}' as date)), 'YYYY-MM-DD') and '${pSQL_PARM_1}'
and cast (prod_type_cd as INTEGER) > 0 )   d 
INNER JOIN (
        SELECT prod_sk,
        store_nbr,
        src_sys_cd,
        sales_txn_dt
        FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg
        GROUP BY 1,
            2,
            3,
            4) e
 ON d.sales_txn_dt=e.sales_txn_dt
AND d.prod_sk=e.prod_sk
AND d.src_sys_cd=e.src_sys_cd
AND d.store_nbr=e.store_nbr;


  insert into dim_code_1
 select src_cd_val, src_sys_cd from ${pDataBase_master_data}.${pTD_Reference_Code_Values}.dim_code where src_sys_cd='POS'
  and   tgt_col_name='prod_type_cd' 
and tgt_tbl_name='prod_type_cd_bvw'
and  CAST(src_cd_val AS INTEGER) > 0;

UPDATE  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg drv
set prod_type_cd = prod.prod_type_cd
from 
(select 
b.prod_type_cd,
b.sales_txn_dt,
b.store_nbr,
b.src_sys_prod_id_1,
b.src_sys_cd ,
b.prod_sk
from(
select  a.sales_txn_dt,a.store_nbr,a.src_sys_prod_id_1,a.src_sys_cd,a.prod_sk,
a.prod_type_cd
from  prod_typ_1 a,
dim_code_1 dim
where  a.prod_type_cd=dim.src_cd_val
and a.src_sys_cd=dim.src_sys_cd and dim.src_cd_val=4
group by 1,2,3,4,5,6) b 
qualify row_number() over(partition by sales_txn_dt,prod_sk,store_nbr,src_sys_prod_id_1,src_sys_cd order by prod_type_cd)  =1
) prod
where drv.prod_sk=prod.prod_sk
and drv.sales_txn_dt=prod.sales_txn_dt
and drv.store_nbr=prod.store_nbr
and cast(drv.product_key as VARCHAR(40))=prod.src_sys_prod_id_1
and drv.src_sys_cd=drv.src_sys_cd
and drv.loyalty_mbr_id is  null;


select
cmp.ad_wk,
cmp.str_nbr,
cmp.store_name as str_brands,
cmp.ops_dept_nbr,
cmp.gross_sales,                  
cmp.gross_sales - (cmp.wag_coupon_amt + cmp.other_coupon_amt + cmp.return_amount ) as net_sales,
cmp.units,
cmp.wag_coupon_amt as wag_coup_amt,
cmp.other_coupon_amt as other_coup_amt
from
(select
to_char(t.ad_wk_end_dt,'YYYYMMDD') as ad_wk,
t.store_nbr as str_nbr,
t.ops_dept_nbr,

sum(case when ops_dept_nbr>0 and  original_price_dlrs>0 and  rx_nbr is NULL and  wag_coup_cd ='--' and mfg_coup_cd ='--' and  return_ind = 'N'  and unit_qty > 0  and item_void_cd='--'   then item_qty*unit_price_dlrs	
				 when (ops_dept_nbr is NULL  or ops_dept_nbr  <0 ) and wag_coup_cd ='--' and mfg_coup_cd ='--'  then  item_qty*unit_price_dlrs  else 0
	    end) as gross_sales,

sum(case when ops_dept_nbr>0 and promo_desc is null and discnt_dlrs >0 then discnt_dlrs
                 when (ops_dept_nbr is NULL  or ops_dept_nbr  <0 ) and promo_desc is null and discnt_dlrs >0 then discnt_dlrs else 0
       end) as other_coupon_amt,
       
sum(case when ops_dept_nbr>0 and promo_desc is not null  then discnt_dlrs
                 when (ops_dept_nbr is NULL  or ops_dept_nbr  <0 ) and promo_desc is not null  then discnt_dlrs else 0
       end) as wag_coupon_amt,
       
sum(case when ops_dept_nbr>0 and  original_price_dlrs>0 and  rx_nbr is NULL and  wag_coup_cd ='--' and mfg_coup_cd ='--' and  return_ind = 'N'  and unit_qty > 0  and item_void_cd='--'   then item_qty
				 when (ops_dept_nbr is NULL  or ops_dept_nbr  <0 ) and wag_coup_cd ='--' and mfg_coup_cd ='--'  and  original_price_dlrs>0 then  item_qty  else 0
	    end) as units,
	    
sum(case when ops_dept_nbr>0 and return_ind = 'Y'  and  rx_nbr is NULL and  wag_coup_cd ='--' and mfg_coup_cd ='--'  and unit_qty > 0  and item_void_cd='--' then selling_price_dlrs*(-1) else 0 end) as return_amount,
       
lstr.store_name from

(Select dpp.ad_wk_end_dt,E.line_item_seq_nbr,
E.sales_txn_id,E.store_nbr,E.loc_store_sk,E.return_ind,E.ord_id,E.ord_dt,E.ord_src_type_cd,E.prod_sk, E.sales_txn_dt, E.original_price_dlrs, 
E.selling_price_dlrs, E.item_qty, E.unit_price_dlrs, E.item_void_cd,E.rx_nbr, E.wag_coup_cd, E.mfg_coup_cd, E.unit_qty, E.discnt_dlrs,
ops_dept_nbr as ops, 
promo_desc,
case 
when ((ops_dept_nbr <=0 or  ops_dept_nbr is NULL) and ( wag_coup_cd <> '--' or  mfg_coup_cd <> '--' ) )then '-1'
when ((ops_dept_nbr <=0 or  ops_dept_nbr is NULL) and ( wag_coup_cd ='--' or  mfg_coup_cd ='--' ) )then '-1'
else trim(cast(pph.ops_dept_nbr as INTEGER)) end as ops_dept_nbr


from (select * from ${pDataBase_MasterData}.${pTD_VIEW_CALENDAR}.dim_promo_period 
where ad_wk_begin_dt between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day') dpp
inner join
(select ord_dt ,ord_id, ord_src_type_cd,item_qty,unit_price_dlrs,discnt_dlrs,D.* from
(select sales_txn_id,sales_txn_dt,line_item_seq_nbr,A.* from ( select a.ord_dt,b.* from (select ord_id,ord_dt,ord_src_type_cd,fulfillment_type_cd from ${pDataBase_Digital}.${pTD_VIEW_ECOM}.ecom_order ) a inner join  
(select ord_id,ord_item_id, item_qty,unit_price_dlrs,discnt_dlrs,ord_src_type_cd from ${pDataBase_Digital}.${pTD_VIEW_ECOM}.ecom_order_item) b 
on a.ord_id=b.ord_id
and a.ord_dt between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'
and a.ord_src_type_cd='P'
and a.ord_src_type_cd = b.ord_src_type_cd
and a.fulfillment_type_cd in ('S') )A

inner join ${pDataBase_Retail}.${pTD_VIEW_RETAIL_SALES}.pos_ec_photo_link B
on A.ord_id=B.ec_sales_txn_id
group by 1,2,3,4,5,6,7,8,9,10 ) C

inner join
(
select
a.store_nbr,
a.sales_txn_id,
a.sales_txn_dt,
a.src_sys_cd,
a.sales_txn_type,
a.sales_ord_src_type,
b.line_item_seq_nbr,
b.prod_sk,
a.loc_store_sk,
rx_nbr,
photo_env_nbr,
wag_coup_cd,
mfg_coup_cd,
return_ind,
unit_qty,
selling_price_dlrs,
original_price_dlrs,
item_void_cd
from
${pDataBase_Retail}.${pTD_VIEW_RETAIL_SALES}.sales_transaction a
inner join ${pDataBase_Retail}.${pTD_VIEW_RETAIL_SALES}.sales_transaction_detail b
on a.sales_txn_id=b.sales_txn_id
and a.sales_txn_dt=b.sales_txn_dt
and a.sales_ord_src_type=b.sales_ord_src_type
and a.sales_txn_type=b.sales_txn_type
and a.src_sys_cd=a.src_sys_cd
where a.src_sys_cd='${pEDW_SUBJECT_AREA}'
and b.src_sys_cd='${pEDW_SUBJECT_AREA}'
and a.sales_txn_dt  between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'
and b.sales_txn_dt  between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'
and a.txn_type in (10, 11, 12, 13, 14, 15, 16, 25)
and  a.training_txn_ind = 'N'
and a.txn_incomplete_ind = 'N'
and a.post_void_status_cd ='--'
) D
on D.sales_txn_id=C.sales_txn_id
and D.sales_txn_dt=C.sales_txn_dt
and D.line_item_seq_nbr=C.line_item_seq_nbr 
) E

on E.sales_txn_dt between dpp.ad_wk_begin_dt and dpp.ad_wk_end_dt

left outer join ${pDataBase_MasterData}.${pTD_VIEW_PRODUCT}.product_hierarchy pph
ON pph.prod_sk=E.prod_sk
and pph.src_sys_cd='${pEDW_SUBJECT_AREA}'
and E.sales_txn_dt between pph.edw_rec_begin_dt and pph.edw_rec_end_dt
left outer join ${pDataBase_Digital}.${pTD_VIEW_ECOM}.ecom_order_promotion F
on E.ord_id = F.ord_id
and E.ord_src_type_cd = F.ord_src_type_cd
left outer join ${pDataBase_Digital}.${pTD_VIEW_ECOM}.ecom_promotion G
on G.promo_id = F.promo_id
and E.ord_dt between G.promo_start_dt and G.promo_end_dt group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23) t 

left outer join ${pDataBase_MasterData}.${pTD_VIEW_LOCATION}.location_store lstr
on lstr.store_nbr=t.store_nbr 
and lstr.loc_store_sk =t.loc_store_sk
and t.sales_txn_dt between lstr.edw_rec_begin_dt and lstr.edw_rec_end_dt

group by ad_wk,ops_dept_nbr,str_nbr,store_name) cmp;

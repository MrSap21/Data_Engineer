delete from ${pTD_Staging}.${pTD_RETAIL_SALES}.ccpa_stage_optout_table_stg;


insert into ${pTD_Staging}.${pTD_RETAIL_SALES}.ccpa_stage_optout_table_stg
(cust_src_id
,src_sys_cd
,composite_type_cd
,msg_type_cd
,Opt_out_begin_dt
,opt_out_end_dt)
select
cust_src_id, src_sys_cd,
composite_type_cd,
msg_type_cd,
Optout_begin_dt,optout_end_dt
from ${pTD_retail}.CCPA.ccpa_customer_request_list
where reqst_type_cd = 'OPTOUT'
and current_date between optout_begin_dt and optout_end_dt
group by 1,2,3,4,5,6
UNION
select
cdi_cust_src_id as cust_src_id, 'CDI' as src_sys_cd, cdi_composite_type_cd,cdi_msg_type_cd,
Optout_begin_dt,optout_end_dt
from
(SELECT src_sys_cd, cust_src_id,Optout_begin_dt,optout_end_dt
FROM ${pTD_retail}.CCPA.ccpa_customer_request_list where src_sys_cd in
(select src_sys_cd from ${pTD_Staging}.CCPA.ccpa_non_pharmacy_list_stg where src_sys_cd <> 'CDI')
And reqst_type_cd = 'OPTOUT' and current_date between optout_begin_dt and optout_end_dt group by 1,2,3,4) a
inner join ${pTD_master_data}.${pTD_customer}.link_to_customer b
ON a.cust_src_id=b.cust_src_id
and a.src_sys_cd=b.cust_src_cd
and b.cdi_msg_type_cd in ('1','2')
group by 1,2,3,4,5,6;


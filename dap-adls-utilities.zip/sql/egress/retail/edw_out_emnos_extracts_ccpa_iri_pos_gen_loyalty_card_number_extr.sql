select 
        distinct cust_src_id as loyalty_card_number
from ${pTD_DEV_STAGING}.${pTD_RETAIL_SALES}.ccpa_stage_optout_table_stg opt 
where 
composite_type_cd = 'M'
and msg_type_cd = '1'
and src_sys_cd = 'LR';

WITH opt_out as
(select
cust_src_id, src_sys_cd,
composite_type_cd,
msg_type_cd,
Optout_begin_dt,optout_end_dt
from ${pTD_DATABASE_RETAIL}.${pTD_VIEW_DB_CCPA}.${pSQL_PARM_1}
where reqst_type_cd = 'OPTOUT'
and current_date() between optout_begin_dt and optout_end_dt
group by 1,2,3,4,5,6
UNION
select
cdi_cust_src_id as cust_src_id, 'CDI' as src_sys_cd, cdi_composite_type_cd,cdi_msg_type_cd,
Optout_begin_dt,optout_end_dt
from
(SELECT src_sys_cd, cust_src_id,Optout_begin_dt,optout_end_dt
FROM ${pTD_DATABASE_RETAIL}.${pTD_VIEW_DB_CCPA}.${pSQL_PARM_1} where src_sys_cd in
(select src_sys_cd from ${pTD_DATABASE_STAGING}.${pTD_VIEW_DB_CCPA}.${pSQL_PARM_2} where src_sys_cd <> 'CDI')
And reqst_type_cd = 'OPTOUT' and current_date() between optout_begin_dt and optout_end_dt group by 1,2,3,4) a
inner join ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_CUSTOMER}.${pSQL_PARM_3} b
ON a.cust_src_id=b.cust_src_id
and a.src_sys_cd=b.cust_src_cd
and b.cdi_msg_type_cd in ('1','2')
group by 1,2,3,4,5,6
)
SELECT	
transaction_date, 
transaction_time, 
transaction_number,
store_number, 
loyalty_card_number, 
mid,
card_id, 
upc, 
wic, 
retailer_product_identifier,
item_list_price, 
item_net_price, 
item_quantity,
weighted_item_weight,
weighted_item_count,
item_deal_quantity, 
item_sale_quantity,
item_net_amount,
item_gross_amount,
return_indicator,
cost_dlrs,
cost_adj_dlrs, 
loyalty_cost_adj_dlrs,
gross_profit, 
sale_ind
FROM	${pTD_DATABASE_STAGING}.${pTD_DB_retail_sales}.${pTABLE_NAME_CCPA_IRI_ETRANSACTION_STG} iri_stg
left outer join
(select cust_src_id 
from opt_out 
where opt_out.composite_type_cd = 'M' 
          and opt_out.msg_type_cd = '1' 
          and opt_out.src_sys_cd = 'LR'
) csi
on iri_stg.loyalty_card_number=csi.cust_src_id 
left outer join
(select 'E' || opt_out.cust_src_id as mid_1
from opt_out 
where opt_out.composite_type_cd = 'A' 
          and opt_out.msg_type_cd = '2' 
          and opt_out.src_sys_cd = 'CDI'
) ecsi 
on iri_stg.mid=ecsi.mid_1
where csi.cust_src_id is null 
and ecsi.mid_1 is null;

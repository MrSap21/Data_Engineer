delete from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.${pTD_DB_ecom_drv};

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_inc_driver_stg
(sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
src_sys_cd,
store_nbr,
upc_nbr,
prod_sk,
txn_end_dttm,
selling_price_dlrs,
prod_cost_dlrs,
unit_qty,
line_item_seq_nbr,
sale_ind,
list_price_dlrs,
qty_to_return,
item_list_price,
edw_create_dttm
)
with SALES_TXN_IRI_ECOMM_EXT_a as (
select a.sales_txn_id,
a.sales_txn_dt,
a.sales_ord_src_type,
a.sales_txn_type,
a.src_sys_cd,
b.store_nbr,
a.upc_nbr,
a.prod_sk,
b.txn_end_dttm,
a.line_item_seq_nbr,
a.sale_ind,
a.wag_coup_cd , 
a.selling_price_dlrs ,
a.unit_qty ,
a.prod_cost_dlrs,
a.list_price_dlrs,
a.qty_to_return,
a.item_unit_price_dlrs,
CASE WHEN a.edw_create_dttm > coalesce(b.edw_create_dttm,TO_TIMESTAMP('00010101000000', 'YYYYMMDDHHMISS' )) THEN a.edw_create_dttm
WHEN b.edw_create_dttm > coalesce(a.edw_create_dttm,TO_TIMESTAMP('00010101000000', 'YYYYMMDDHHMISS' )) THEN b.edw_create_dttm END AS edw_create_dttm
from 
(select * from (select * from  ${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.SALES_TRANSACTION_DETAIL
where  src_sys_cd='EC' and sales_txn_dt > current_date - 45 ) a ,
(select 
max(EXTRACT_DATE ) as EXTRACT_DATE 
from ${pDATABASE_ETL}.PRDSTGMET.PROC_CNTRL_EXTRACT_BATCH_META_DETAIL_STG
where proj_name='IRI_extracts' and src_stream_name = 'etransaction_file_ext' and extract_name='IRI_etransaction_file' and extract_create_dt <> to_date('0001-01-01' ::VARCHAR(30), 'YYYY-MM-DD')) c
where sales_txn_dt  between c.EXTRACT_DATE-30 and c.EXTRACT_DATE  and src_sys_cd='EC' )  a,
${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.SALES_TRANSACTION b
where  a.sales_txn_id=b.sales_txn_id
and  a.sales_txn_dt=b.sales_txn_dt
and  a.sales_ord_src_type=b.sales_ord_src_type
and a.sales_txn_type=b.sales_txn_type
and a.src_sys_cd=b.src_sys_cd
and a.src_sys_cd='EC'
and a.sales_ord_src_type <> 'R'
)
select 
pgm.sales_txn_id,
pgm.sales_txn_dt,
pgm.sales_ord_src_type,
pgm.sales_txn_type,
pgm.src_sys_cd,
pgm.store_nbr,
pgm.upc_nbr,
pgm.prod_sk,
pgm.txn_end_dttm,
pgm.selling_price_dlrs,
pgm.prod_cost_dlrs,
pgm.unit_qty,
pgm.line_item_seq_nbr,
pgm.sale_ind,
pgm.list_price_dlrs,
pgm.qty_to_return,
pgm.item_list_price,
edw_create_dttm
from(
select 
a.sales_txn_id,
a.sales_txn_dt,
a.sales_ord_src_type,
a.sales_txn_type,
a.src_sys_cd,
'5995' as store_nbr,
null as upc_nbr,
a.prod_sk,
a.txn_end_dttm,
a.sale_ind,
max(a.list_price_dlrs) as list_price_dlrs,
sum(a.qty_to_return) as qty_to_return ,
max(a.edw_create_dttm) as edw_create_dttm ,
max(a.line_item_seq_nbr) as line_item_seq_nbr,
coalesce (sum(a.selling_price_dlrs),'0') as selling_price_dlrs,
coalesce (sum(a.prod_cost_dlrs),'0') as prod_cost_dlrs,
SUM(a.unit_qty) AS unit_qty,
max(case when ((a.item_unit_price_dlrs is NULL or a.item_unit_price_dlrs = 0) and a.sales_txn_type not in ('R')
                                                                and (a.unit_qty > 0 and a.unit_qty is not null))
                                                then (a.selling_price_dlrs/a.unit_qty)
                                when ( (a.item_unit_price_dlrs is NULL or a.item_unit_price_dlrs = 0)
                                                                                and a.sales_txn_type = 'R' and a.selling_price_dlrs > 0 and (a.qty_to_return > 0 and a.qty_to_return is not null))
                                                then (-1*(a.selling_price_dlrs/a.qty_to_return))
                                 when ( (a.item_unit_price_dlrs is NULL or a.item_unit_price_dlrs = 0)
                                                                                and a.sales_txn_type = 'R' and a.selling_price_dlrs < 0 and (a.qty_to_return > 0 and a.qty_to_return is not null) )
                                                then (a.selling_price_dlrs/a.qty_to_return)
                                when ( a.sales_txn_type = 'R' and  a.item_unit_price_dlrs > 0 )
                                                then (-1 * (a.item_unit_price_dlrs))
                                else  coalesce(a.item_unit_price_dlrs,0)
                end)
     as item_list_price	 
FROM SALES_TXN_IRI_ECOMM_EXT_a a
 where a.sales_txn_dt = to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')
group by 1,2,3,4,5,6,7,8,9,10
union all
select 
b.sales_txn_id,
b.sales_txn_dt,
b.sales_ord_src_type,
b.sales_txn_type,
b.src_sys_cd,
'5995' as store_nbr,
null as upc_nbr,
b.prod_sk,
b.txn_end_dttm,
b.sale_ind,
max(b.list_price_dlrs) as list_price_dlrs,
sum(b.qty_to_return) as qty_to_return,
max(b.edw_create_dttm) as edw_create_dttm ,
max(b.line_item_seq_nbr) as line_item_seq_nbr,
coalesce (sum(b.selling_price_dlrs),'0') as selling_price_dlrs,
coalesce (sum(b.prod_cost_dlrs),'0') as prod_cost_dlrs,
SUM(b.unit_qty) AS unit_qty,
max(case when ((b.item_unit_price_dlrs is NULL or b.item_unit_price_dlrs = 0) and b.sales_txn_type not in ('R')
                                                                and (b.unit_qty > 0 and b.unit_qty is not null))
                                                then (b.selling_price_dlrs/b.unit_qty)
                                when ( (b.item_unit_price_dlrs is NULL or b.item_unit_price_dlrs = 0)
                                                                                and b.sales_txn_type = 'R' and b.selling_price_dlrs > 0 and (b.qty_to_return > 0 and b.qty_to_return is not null))
                                                then (-1*(b.selling_price_dlrs/b.qty_to_return))
                                 when ( (b.item_unit_price_dlrs is NULL or b.item_unit_price_dlrs = 0)
                                                                                and b.sales_txn_type = 'R' and b.selling_price_dlrs < 0 and (b.qty_to_return > 0 and b.qty_to_return is not null) )
                                                then (b.selling_price_dlrs/b.qty_to_return)
                                when ( b.sales_txn_type = 'R' and  b.item_unit_price_dlrs > 0 )
                                                then (-1 * (b.item_unit_price_dlrs))
                                else  coalesce(b.item_unit_price_dlrs,0)
                end)
     as item_list_price	 
FROM SALES_TXN_IRI_ECOMM_EXT_a b
 where b.sales_txn_dt between to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD')-30  and to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD') -1 and 
b.edw_create_dttm > '${pSQL_PARM_1}'
group by 1,2,3,4,5,6,7,8,9,10) pgm;
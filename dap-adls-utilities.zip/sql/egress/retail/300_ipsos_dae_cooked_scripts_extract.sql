WITH stg_scripts as
(select p.rx_nbr,
p.str_nbr,
p.rx_fill_nbr,
p.rx_partial_fill_nbr, 
p.dspn_fill_nbr,
p.fill_sold_dt,
pat_id,
max(case when plan_type in ('Medicare Part D') then 1 else 0 end) as MedD_scripts_count,
max(case when plan_type not in ('Cash', 'Discount Card', 'Medicare Part D', 'State Medicaid', 'Managed Medicaid') then 1 else 0 end) as commersial_scripts_count,
max(case when plan_type in ('Managed Medicaid', 'State Medicaid') then 1 else 0 end) as medicaid_scripts_count,
max(case when plan_type in ('Discount Card', 'Cash') then 1 else 0 end) as CPRx_scripts_count,
max(case when (plan_type in ('Discount Card') and  plan_name in ('Walgreens Prescription Savings Club')) or plan_name in ('Walgreens WAGPlus') then 1 else 0 end) as Prescription_saving_Club_WAG_scripts_count,
max(case when ( plan_type in ('Discount Card') and plan_name not in ('Walgreens Prescription Savings Club'))  or plan_type in ('Cash') then 1 else 0 end) as Discount_Cards_Cash_count
from
 (select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr, dspn_fill_nbr,fill_sold_dt,fill_enter_dt,pat_id, fill_sold_yr, fill_enter_mnth from   ${pTD_DATABASE_PHARMACY_HEALTHCARE}.${pTD_VIEW_DB_PATIENT_SERVICES}.prescription_fill p  where  (partial_fill_cd is null or partial_fill_cd='P' ) and fill_sold_dt between '${pextDt1}' and date_add(cast('${pextDt1}' as date),27)
 and fill_stat_cd = 'SD'
and fill_del_dt IS NULL
and  fill_sold_dt IS NOT NULL
and  fill_sold_dlrs IS NOT NULL
)p
left outer join 
(select * from ${pTD_DATABASE_PHARMACY_HEALTHCARE}.${pTD_VIEW_DB_PATIENT_SERVICES}.prescription_fill_plan  where cob_ind='N') pfp
            on p.rx_nbr=pfp.rx_nbr 
            and p.str_nbr=pfp.str_nbr 
            and p.rx_fill_nbr=pfp.rx_fill_nbr 
            and p.rx_partial_fill_nbr=pfp.rx_partial_fill_nbr
      and p.fill_sold_yr = pfp.fill_sold_yr
      and p.fill_enter_mnth = pfp.fill_enter_mnth 
            and (pfp.fill_adjud_cd in ('A','L','X',null,''))         
left outer join   (select plan_catg_id, edw_eff_dt, third_party_plan_id, bin_nbr, prcs_ctrl_nbr, plan_group_nbr,  plan_name, plan_type,plan_catg_eff_dt,plan_catg_end_dt from ${pTD_DATABASE_PHARMACY_HEALTHCARE}.${pTD_VIEW_DB_PLAN}.plan_category where trim(history_seq_cd) = 'C' and src_sys_cd = 'IC' and trim(del_ind) = 'N') pc
            on   coalesce( pfp.third_party_plan_id, '#$#' ) = coalesce(  trim(pc.third_party_plan_id) , '#$#' ) 
            and  coalesce(  pfp.bin_nbr , '#$#'  ) = coalesce( trim(pc.bin_nbr), '#$#' )
            and coalesce(  pfp.prcs_ctrl_nbr , '#$#' ) = coalesce( trim(pc.prcs_ctrl_nbr), '#$#' )
            and  coalesce(  pfp.plan_group_nbr, '#$#'  ) = coalesce( trim(pc.plan_group_nbr), '#$#' )
where (pfp.fill_enter_dt between pc.plan_catg_eff_dt and coalesce(pc.plan_catg_end_dt,'9999-12-31') or pc.third_party_plan_id is NULL)
group by p.rx_nbr,p.str_nbr,p.rx_fill_nbr,p.rx_partial_fill_nbr, p.dspn_fill_nbr,p.fill_sold_dt,pat_id,plan_type,plan_name),
stg_1_scripts as
(select p.rx_nbr,
p.str_nbr,
p.rx_fill_nbr,
p.rx_partial_fill_nbr, 
p.dspn_fill_nbr,
p.fill_sold_dt,
pat_id,
count(*) as total_scripts
from 
(select day_dt, ad_wk_begin_dt, ad_wk_end_dt from ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_CALENDAR}.dim_promo_period  where ad_wk_begin_dt between cast('${pextDt1}' as date) and date_add(cast('${pextDt1}' as date),27) group by day_dt,ad_wk_begin_dt, ad_wk_end_dt
) dpp
left join
(select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr, dspn_fill_nbr,fill_sold_dt,fill_enter_dt,pat_id from   ${pTD_DATABASE_PHARMACY_HEALTHCARE}.${pTD_VIEW_DB_PATIENT_SERVICES}.prescription_fill p  where 
(partial_fill_cd is null or partial_fill_cd='P' ) and fill_sold_dt between '${pextDt1}' and date_add(cast('${pextDt1}' as date),27)
and fill_stat_cd = 'SD'
and fill_del_dt IS NULL
and  fill_sold_dt IS NOT NULL
and  fill_sold_dlrs IS NOT NULL
)p on dpp.day_dt = p.fill_sold_dt 
where p.fill_sold_dt between ad_wk_begin_dt and ad_wk_end_dt
and dpp.day_dt between '${pextDt1}' and date_add(cast('${pextDt1}' as date),27)
group by p.rx_nbr,
p.str_nbr,
p.rx_fill_nbr,
p.rx_partial_fill_nbr, 
p.dspn_fill_nbr,
p.fill_sold_dt, pat_id),
stg_3_scripts as 
(select rx_nbr, str_nbr, rx_fill_nbr, rx_partial_fill_nbr, dspn_fill_nbr, fill_sold_dt, pat_id, sum(MedD_scripts_count)as MedD_scripts_count, sum(commersial_scripts_count) as commersial_scripts_count,
sum(medicaid_scripts_count) as medicaid_scripts_count,
sum(cprx_scripts_count) as cprx_scripts_count,
sum(prescription_saving_club_wag_scripts_count) as prescription_saving_club_wag_scripts_count,
sum(discount_cards_cash_count) as discount_cards_cash_count,
sum(total_scripts) as total_scripts from (
select *, 0 as total_scripts from stg_scripts 
union
select p.rx_nbr,
p.str_nbr,
p.rx_fill_nbr,
p.rx_partial_fill_nbr, 
p.dspn_fill_nbr,
p.fill_sold_dt,
pat_id,
0 as MedD_scripts_count,
0 as commersial_scripts_count,
0 as medicaid_scripts_count,
0 as cprx_scripts_count,
0 as prescription_saving_club_wag_scripts_count,
0 as discount_cards_cash_count,
total_scripts from 
stg_1_scripts p )x
group by rx_nbr, str_nbr, rx_fill_nbr, rx_partial_fill_nbr, dspn_fill_nbr, fill_sold_dt, pat_id),
stg_2_scripts as
(select  ad_wk_begin_dt, ad_wk_end_dt,Pat_id, str_nbr, rx_nbr, rx_fill_nbr, dspn_fill_nbr, fill_sold_dt, fill_stat_cd, Days_Filled,online_initiated_script, Hispanic_script_ind from 
(
select day_dt, ad_wk_begin_dt, ad_wk_end_dt from ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_CALENDAR}.dim_promo_period where  ad_wk_begin_dt between '${pextDt1}' and date_add(cast('${pextDt1}' as date),27) group by day_dt,ad_wk_begin_dt, ad_wk_end_dt
) dpp
left join

(select  Pat_id, str_nbr, rx_nbr, rx_fill_nbr, dspn_fill_nbr, fill_sold_dt, fill_stat_cd, 
    (case   when fill_days_supply >= 84 then '90 Day' 
            when fill_days_supply < 84 then '30 Day' 
    end ) as  Days_Filled,
    (case when ecom_ind='Y' then 'Y' else 'N'  end )as online_initiated_script,
    (case when pat_language_pref_cd='S'  then 'Y' else 'N' end) as Hispanic_script_ind
from  (select * from ${pTD_DATABASE_PHARMACY_HEALTHCARE}.${pTD_VIEW_DB_PATIENT_SERVICES}.prescription_fill where fill_sold_dt between '${pextDt1}' and date_add(cast('${pextDt1}' as date),27))x)p
on dpp.day_dt = p.fill_sold_dt
where p.fill_sold_dt between ad_wk_begin_dt and ad_wk_end_dt
and dpp.day_dt between '${pextDt1}' and date_add(cast('${pextDt1}' as date),27))


select substr(cast (p.ad_wk_end_dt as char(10)),1,4) as ad_year,
from_unixtime(unix_timestamp(p.ad_wk_end_dt ,'yyyy-MM-dd'), 'yyyyMMdd') as ad_week,
p.str_nbr,
lstr.store_name,
Days_Filled,
(case when p.fill_sold_dt is not null and (p.fill_sold_dt between p.ad_wk_end_dt and date_add(p.ad_wk_end_dt,-365)) then 'Existing'  
               when p.fill_sold_dt is not null and (p.fill_sold_dt not between p.ad_wk_end_dt and date_add(p.ad_wk_end_dt,-365)) then'New' 
end) as  patient_type,
p.online_initiated_script, 
p.Hispanic_script_ind,
sum(total_scripts) as total_scripts,
sum(MedD_scripts_count) as MedD_scripts_count,
sum(commersial_scripts_count) as commersial_scripts_count,
sum(medicaid_scripts_count) as medicaid_scripts_count,
sum(CPRx_scripts_count) as CPRx_scripts_count,
sum(Prescription_saving_Club_WAG_scripts_count) as Prescription_saving_Club_WAG_scripts_count,
sum(Discount_Cards_Cash_count) as Discount_Cards_Cash_count

from stg_2_scripts p INNER JOIN stg_3_scripts sp
    ON p.str_nbr= sp.str_nbr
    and p.rx_nbr=sp.rx_nbr
    and p.rx_fill_nbr = sp.rx_fill_nbr
    and p.dspn_fill_nbr = sp.dspn_fill_nbr
    and p.fill_sold_dt = sp.fill_sold_dt
    and p.pat_id = sp.pat_id
    
    left outer join ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_LOCATION}.location_store lstr 
    on  p.str_nbr = lstr.store_nbr
    where p.ad_wk_end_dt between lstr.edw_rec_begin_dt and lstr.edw_rec_end_dt 
   
group by ad_wk_end_dt,p.str_nbr,lstr.store_name,Days_Filled,(case when p.fill_sold_dt is not null and (p.fill_sold_dt between p.ad_wk_end_dt and date_add(p.ad_wk_end_dt,-365)) then 'Existing'  
when p.fill_sold_dt is not null and (p.fill_sold_dt not between p.ad_wk_end_dt and date_add(p.ad_wk_end_dt,-365)) then'New' 
end),p.online_initiated_script, p.Hispanic_script_ind;

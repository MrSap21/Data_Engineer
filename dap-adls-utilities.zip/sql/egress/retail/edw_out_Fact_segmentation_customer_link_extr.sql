WITH opt as
(select
cust_src_id, src_sys_cd,
composite_type_cd,
msg_type_cd,
Optout_begin_dt,optout_end_dt
from ${pTD_DATABASE_RETAIL}.${pTD_VIEW_DB_CCPA}.${pSQL_PARM_1}
where reqst_type_cd = 'OPTOUT'
and current_date() between optout_begin_dt and optout_end_dt
group by 1,2,3,4,5,6
UNION
select
cdi_cust_src_id as cust_src_id, 'CDI' as src_sys_cd, cdi_composite_type_cd,cdi_msg_type_cd,
Optout_begin_dt,optout_end_dt
from
(SELECT src_sys_cd, cust_src_id,Optout_begin_dt,optout_end_dt
FROM ${pTD_DATABASE_RETAIL}.${pTD_VIEW_DB_CCPA}.${pSQL_PARM_1} where src_sys_cd in
(select src_sys_cd from ${pTD_DATABASE_STAGING}.${pTD_VIEW_DB_CCPA}.${pSQL_PARM_2} where src_sys_cd <> 'CDI')
And reqst_type_cd = 'OPTOUT' and current_date() between optout_begin_dt and optout_end_dt group by 1,2,3,4) a
inner join ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_CUSTOMER}.${pSQL_PARM_3} b
ON a.cust_src_id=b.cust_src_id
and a.src_sys_cd=b.cust_src_cd
and b.cdi_msg_type_cd in ('1','2')
group by 1,2,3,4,5,6
),
lookup as
(
select	distinct mast_cust_id
from ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_CUSTOMER}.segmentation_customer_link stg 
inner join opt 
on stg.cust_src_id = opt.cust_src_id
and stg.src_sys_cd = opt.src_sys_cd
and stg.composite_type_cd = opt.composite_type_cd
and stg.msg_type_cd = opt.msg_type_cd
)


select 
segment_cust_link_chng_sk,
segmentation_customer_link.mast_cust_id,
cust_sk,
cust_src_id,
src_sys_cd,
composite_type_cd,
msg_type_cd,
to_char(src_eff_dt,'YYYYMMDD') as src_eff_dt,
to_char(src_end_dt,'YYYYMMDD') as src_end_dt,
stat_cd,
to_char(edw_create_dttm,'YYYYMMDDHHMISS') as edw_create_dttm,
to_char(edw_update_dttm,'YYYYMMDDHHMISS') as edw_update_dttm,
edw_batch_id
from ${pTD_DATABASE_MASTER_DATA}.${pTD_VIEW_DB_CUSTOMER}.segmentation_customer_link
left outer join lookup 
on segmentation_customer_link.mast_cust_id=lookup.mast_cust_id
where lookup.mast_cust_id is null
and edw_update_dttm > TO_TIMESTAMP_NTZ(CURRENT_DATE - 30);
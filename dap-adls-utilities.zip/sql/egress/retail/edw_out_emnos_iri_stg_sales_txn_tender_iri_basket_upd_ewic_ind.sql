update ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg
set ewic_wic_ind='Y'
where sales_txn_id in (select distinct sales_txn_id from ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg 
where tndr_type_cd IN ('23','102','267','430') );

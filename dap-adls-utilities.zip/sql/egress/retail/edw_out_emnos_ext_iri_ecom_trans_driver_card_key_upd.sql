UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg drv
set loyalty_mbr_id=pg.prog_cust_id
FROM   ${pDATABASE_RETAIL}.${pTD_DB_retail_sales}.sales_transaction_program pg
where  drv.sales_txn_id=pg.sales_txn_id
and drv.sales_txn_dt=pg.sales_txn_dt
and drv.sales_ord_src_type=pg.sales_ord_src_type
and drv.sales_txn_type=pg.sales_txn_type
and drv.src_sys_cd=pg.src_sys_cd
and pg.src_sys_cd='EC'
and pg.sales_txn_dt between to_date('${pSQL_PARM_1}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_1}'
and pg.prog_cust_id is NOT NULL
and pg.prog_type_cd IN ('LYCD','VCD','APPLE_WALLET','ANDROID_PAY');

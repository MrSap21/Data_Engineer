UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg drv
set credit_card=tndr.card_id
FROM    (select d.* from
(select a.sales_txn_dt,
a.sales_txn_id,
a.src_sys_cd,
a.sales_ord_src_type,
a.sales_txn_type,
a.card_hash_val_sk,
z.card_id,
row_number()over(partition by a.sales_txn_dt,a.sales_txn_id,a.src_sys_cd,a.sales_ord_src_type,a.sales_txn_type order by   a.tndr_dlrs desc ) as rownum
from 
(select * from ${pDataBase_retail}.${pTD_DB_retail_sales}.sales_transaction_tender where src_sys_cd=${pSRC_SYS_CD}
and card_hash_val_sk <>-1
and (sales_txn_dt between to_date('${pSQL_PARM_1}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_1}' )
and (sales_txn_dt,sales_txn_id,src_sys_cd,sales_ord_src_type,sales_txn_type) 
in
(select sales_txn_dt,sales_txn_id,src_sys_cd,sales_ord_src_type,sales_txn_type 
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg group by 1,2,3,4,5)  ) a
inner join (select * from ${pDataBase_retail}.${pTD_DB_retail_sales}.Tender_Card_Hash where card_id <> -1) z
on a.card_hash_val_sk = z.card_hash_val_sk
)d where rownum=1) tndr
where drv.sales_txn_id=tndr.sales_txn_id
and  drv.sales_txn_dt=tndr.sales_txn_dt
and drv.sales_ord_src_type=tndr.sales_ord_src_type
and drv.sales_txn_type=tndr.sales_txn_type
and drv.src_sys_cd=tndr.src_sys_cd
and drv.credit_card is null;
select 
to_char(p.ad_wk_end_dt,'YYYYMMDD') as ad_wk, 
p.upc_nbr,
p.prod_desc,
ph.ops_dept_nbr,
ph.ops_dept_name,
ph.mdse_cat_nbr,
ph.mdse_cat_name,
ph.mdse_div_nbr,
ph.mdse_div_name,
ph.sls_cat_prod_id,
ph.sls_cat_name 
from 
(
select 
      to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day' as ad_wk_end_dt,
       upc_nbr,
       edw_update_dttm,
       edw_rec_end_dt,
       prod_desc,
       prod_sk,
       src_sys_cd 
       from ${pDataBase_MasterData}.${pTD_VIEW_DB_OUT}.product 
       where src_sys_cd='POS' 
       and upc_nbr IS NOT NULL
       and upc_nbr >= 0
       and edw_rec_end_dt=${pTD_EDW_END_DATE}     
)p
inner join
(
select 	src_sys_cd ,
      	prod_sk,
      	ops_dept_nbr,
      	ops_dept_name,
      	mdse_cat_name,
        mdse_div_nbr,
      	mdse_cat_nbr,
      	mdse_div_name,
      	sls_cat_prod_id,
      	sls_cat_name,
      	edw_update_dttm,
      	edw_rec_end_dt
     	from ${pDataBase_MasterData}.${pTD_VIEW_DB_OUT}.product_hierarchy
     	where src_sys_cd='POS' 
     	and edw_rec_end_dt=${pTD_EDW_END_DATE}
)ph
on
p.prod_sk=ph.prod_sk
and p.src_sys_cd = ph.src_sys_cd
and p.src_sys_cd='POS'; 
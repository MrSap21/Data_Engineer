delete from ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.sales_txn_tender_iri_basket_stg
SELECT distinct
sales_txn_id,
sales_txn_dt,
tndr_type_cd,
'N' as ewic_wic_ind,
'N' as ebt_ind
from ${pDataBase_retail}.${pTD_DB_retail_sales}.sales_transaction_tender 
where sales_txn_dt between to_char(DATEADD(DAY, -30, '${pSQL_PARM_1}'), 'YYYY-MM-DD')  and (to_date('${pSQL_PARM_1}' ::VARCHAR(30), 'YYYY-MM-DD')) 
and src_sys_cd='POS';


delete from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.IRI_POS_DRIVER_STG;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.IRI_POS_DRIVER_STG 

with sales_txn_iri_pos_ext_a as

(
select a.sales_txn_id,
a.sales_txn_dt,
a.sales_ord_src_type,
a.sales_txn_type,
a.src_sys_cd,
b.store_nbr,
a.upc_nbr,
a.prod_sk,
b.txn_end_dttm,
a.line_item_seq_nbr,
a.wag_coup_cd , 
a.selling_price_dlrs ,
a.unit_qty ,
a.upc_desc,
a.txn_type,
a.return_ind,
a.sale_ind,
a.rx_nbr,
a.original_price_dlrs,
a.mfg_coup_cd,
a.item_unit_price_dlrs,
CASE 
WHEN a.edw_create_dttm > coalesce(b.edw_create_dttm,to_date('0001-01-01','YYYY-MM-DD' )) THEN a.edw_create_dttm
WHEN b.edw_create_dttm > coalesce(a.edw_create_dttm,to_date('0001-01-01','YYYY-MM-DD' )) THEN b.edw_create_dttm 
END AS edw_create_dttm
from 
(select * from (select * from  ${pDataBase_retail}.${pTD_DB_retail_sales}.SALES_TRANSACTION_DETAIL where  src_sys_cd='POS' and sales_txn_dt > current_date - 45 ) a ,
(select max(EXTRACT_DATE ) as EXTRACT_DATE  from ${pDataBase_etl}.PRDSTGMET.PROC_CNTRL_EXTRACT_BATCH_META_DETAIL_STG  
where proj_name='IRI_extracts' and src_stream_name='transaction_file_ext' and extract_name='IRI_transaction_file' AND extract_create_dt <> to_date('0001-01-01','YYYY-MM-DD' ) ) c
where sales_txn_dt  between c.EXTRACT_DATE-30 and c.EXTRACT_DATE  and src_sys_cd='POS' )  a,
${pDataBase_retail}.${pTD_DB_retail_sales}.SALES_TRANSACTION  b
WHERE
a.sales_txn_id=b.sales_txn_id
AND a.sales_txn_dt=b.sales_txn_dt
AND a.sales_ord_src_type=b.sales_ord_src_type  
AND a.sales_txn_type=b.sales_txn_type
AND a.src_sys_cd=b.src_sys_cd
AND a.src_sys_cd='POS'
AND a.ITEM_VOID_CD='--'    
AND a.PRICE_VERIFY_IND = 'N'  
AND b.TXN_TYPE IN ('10', '11', '12', '13', '14','15','16','25') 
AND b.POST_VOID_STATUS_CD = '--'    
AND b.TXN_INCOMPLETE_IND = 'N'    
AND b.TRAINING_TXN_IND = 'N'    
AND a.UNIT_QTY > 0   
AND a.RX_NBR IS  NULL
)

select
pgrm.sales_txn_id,
pgrm.sales_txn_dt,
pgrm.sales_ord_src_type,
pgrm.sales_txn_type,
pgrm.src_sys_cd,
pgrm.store_nbr,
pgrm.upc_nbr,
pgrm.prod_sk,
pgrm.txn_end_dttm,
pgrm.mfg_coup_cd ,
pgrm.wag_coup_cd, 
pgrm.return_ind ,
pgrm.sale_ind,
pgrm.item_list_price ,
pgrm.tot_selling_price_dlrs,
pgrm.quantity,
pgrm.line_item_seq_nbr,
pgrm.edw_create_dttm
from
(
select
a.sales_txn_id ,
a.sales_txn_dt,
a.sales_ord_src_type ,
a.sales_txn_type ,
a.src_sys_cd,
a.store_nbr,
a.upc_nbr,
a.prod_sk,
a.txn_end_dttm, 
a.mfg_coup_cd , 
a.wag_coup_cd ,
a.return_ind ,
a.sale_ind,
MAX(CASE           
WHEN  a.item_unit_price_dlrs > 0  THEN (a.item_unit_price_dlrs)
WHEN (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0 )  and (a.unit_qty is not null and a.unit_qty <> 0 ) THEN (a.selling_price_dlrs) /(a.unit_qty)
ELSE  coalesce(a.item_unit_price_dlrs,0)
END)  as item_list_price ,
SUM(a.selling_price_dlrs) AS tot_selling_price_dlrs ,
SUM(a.unit_qty) AS quantity,
MAX(a.line_item_seq_nbr) as line_item_seq_nbr,  
MAX(a.edw_create_dttm) as edw_create_dttm 

FROM sales_txn_iri_pos_ext_a a

where a.sales_txn_dt = to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')
and a.return_ind ='N'
and a.mfg_coup_cd = '--'
and a.wag_coup_cd = '--'

group by 1,2,3,4,5,6,7,8,9,10,11,12,13

UNION ALL

select
a.sales_txn_id ,
a.sales_txn_dt,
a.sales_ord_src_type ,
a.sales_txn_type ,
a.src_sys_cd,
a.store_nbr,
a.upc_nbr,
a.prod_sk,
a.txn_end_dttm, 
a.mfg_coup_cd , 
a.wag_coup_cd ,
a.return_ind ,
a.sale_ind,
MAX(CASE           
WHEN  a.item_unit_price_dlrs > 0  THEN (a.item_unit_price_dlrs)
WHEN (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0 )  and (a.unit_qty is not null and a.unit_qty <> 0 ) THEN (a.selling_price_dlrs) /(a.unit_qty)
ELSE  coalesce(a.item_unit_price_dlrs,0)
END)  as item_list_price ,
SUM(a.selling_price_dlrs) AS tot_selling_price_dlrs ,
SUM(a.unit_qty) AS quantity,
MAX(a.line_item_seq_nbr) as line_item_seq_nbr,  
MAX(a.edw_create_dttm) as edw_create_dttm 

FROM sales_txn_iri_pos_ext_a a
where a.sales_txn_dt between to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD')-30  and to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD') -1 and
a.edw_create_dttm > '${pSQL_PARM_1}'

and a.return_ind ='N'
and a.mfg_coup_cd = '--'
and a.wag_coup_cd = '--'

group by 1,2,3,4,5,6,7,8,9,10,11,12,13

UNION ALL 

select
a.sales_txn_id ,
a.sales_txn_dt,
a.sales_ord_src_type ,
a.sales_txn_type ,
a.src_sys_cd,
a.store_nbr,
a.upc_nbr,
a.prod_sk,
a.txn_end_dttm, 
a.mfg_coup_cd , 
a.wag_coup_cd ,
a.return_ind ,
a.sale_ind,
MAX(CASE           
WHEN a.return_ind = 'Y' and a.item_unit_price_dlrs > 0   THEN -1* (a.item_unit_price_dlrs)
WHEN a.return_ind = 'Y' and a.item_unit_price_dlrs < 0   THEN  (a.item_unit_price_dlrs)          
WHEN a.return_ind = 'Y'  and  (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0)  and a.selling_price_dlrs > 0 and (a.unit_qty is not null and a.unit_qty <> 0 )  THEN -1* (a.selling_price_dlrs)/(a.unit_qty)
WHEN a.return_ind = 'Y'  and  (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0)  and (a.unit_qty is not null and a.unit_qty <> 0 ) THEN  (a.selling_price_dlrs)/(a.unit_qty)           
WHEN ( a.wag_coup_cd <> '--' and a.mfg_coup_cd <> '--' )  THEN 0  
ELSE  coalesce(a.item_unit_price_dlrs,0)
END ) as item_list_price ,
SUM(a.selling_price_dlrs) AS tot_selling_price_dlrs ,
SUM(CASE WHEN (a.wag_coup_cd <> '--' or a.mfg_coup_cd <> '--' ) THEN 0 ELSE a.unit_qty END) AS quantity,
MAX(a.line_item_seq_nbr) as line_item_seq_nbr,  
MAX(a.edw_create_dttm) as edw_create_dttm 

FROM sales_txn_iri_pos_ext_a a

where a.sales_txn_dt = to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')

and (a.return_ind ='Y'
or  a.mfg_coup_cd <> '--'
or a.wag_coup_cd <> '--')
group by 1,2,3,4,5,6,7,8,9,10,11,12,13

UNION ALL

select
a.sales_txn_id ,
a.sales_txn_dt,
a.sales_ord_src_type ,
a.sales_txn_type ,
a.src_sys_cd,
a.store_nbr,
a.upc_nbr,
a.prod_sk,
a.txn_end_dttm, 
a.mfg_coup_cd , 
a.wag_coup_cd ,
a.return_ind ,
a.sale_ind,
MAX(CASE           
WHEN a.return_ind = 'Y' and a.item_unit_price_dlrs > 0   THEN -1* (a.item_unit_price_dlrs)
WHEN a.return_ind = 'Y' and a.item_unit_price_dlrs < 0   THEN  (a.item_unit_price_dlrs)          
WHEN a.return_ind = 'Y'  and  (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0)  and a.selling_price_dlrs > 0 and (a.unit_qty is not null and a.unit_qty <> 0 )  THEN -1* (a.selling_price_dlrs)/(a.unit_qty)
WHEN a.return_ind = 'Y'  and  (a.item_unit_price_dlrs is null  or a.item_unit_price_dlrs = 0)  and (a.unit_qty is not null and a.unit_qty <> 0 ) THEN  (a.selling_price_dlrs)/(a.unit_qty)           
WHEN ( a.wag_coup_cd <> '--' and a.mfg_coup_cd <> '--' )  THEN 0  
ELSE  coalesce(a.item_unit_price_dlrs,0)
END  ) as item_list_price ,
SUM(a.selling_price_dlrs) AS tot_selling_price_dlrs ,
SUM(CASE WHEN (a.wag_coup_cd <> '--' or a.mfg_coup_cd <> '--' ) THEN 0 ELSE a.unit_qty END) AS quantity,
MAX(a.line_item_seq_nbr) as line_item_seq_nbr,  
MAX(a.edw_create_dttm) as edw_create_dttm 

FROM sales_txn_iri_pos_ext_a a
where a.sales_txn_dt between to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD')-30  and to_date('${pSQL_PARM_2}'::VARCHAR(30), 'YYYY-MM-DD') -1 and
a.edw_create_dttm > '${pSQL_PARM_1}'

and (a.return_ind ='Y'
or  a.mfg_coup_cd <> '--'
or a.wag_coup_cd <> '--')
group by 1,2,3,4,5,6,7,8,9,10,11,12,13
) pgrm;


delete from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg
select 
pgm.sales_txn_id,
pgm.sales_txn_dt,
pgm.sales_ord_src_type,
pgm.sales_txn_type,
pgm.src_sys_cd,
pgm.store_nbr,
pgm.product_key,
null as wic,
pgm.prod_sk,
pgm.txn_end_dttm, 
mfg_coup_cd,
wag_coup_cd,
return_ind,
pgm.sale_ind,
item_list_price ,
item_net_price ,
item_gross_amount ,
tot_selling_price_dlrs ,
pgm.quantity,
pgm.line_item_seq_nbr,
null as prod_type_cd,
pop.cust_id as cust_id ,
null as mid,
null as loyalty_mbr_id,
null as credit_card,
NULL AS cost_dlrs,
NULL AS cost_adj_dlrs,
NULL AS loyalty_cost_adj_dlrs,
NULL AS ord_pickup_type ,
NULL AS ord_pickup_loc ,
edw_create_dttm,
'PC' as ind
from(
select 
d.sales_txn_id,
d.sales_txn_dt,
d.sales_ord_src_type,
d.sales_txn_type,
d.src_sys_cd,
d.store_nbr,
d.upc_nbr as product_key,
d.prod_sk,
d.txn_end_dttm,
d.mfg_coup_cd,
d.wag_coup_cd,
d.return_ind,
d.sale_ind,
item_list_price ,
CASE 
WHEN d.quantity is not null and d.quantity > 0 and d.mfg_coup_cd='--' and d.wag_coup_cd= '--' THEN (d.tot_selling_price_dlrs)/(d.quantity) 
ELSE d.tot_selling_price_dlrs END AS item_net_price ,
CASE 
WHEN d.return_ind = 'Y' and d.item_list_price > 0 THEN -1* ((d.item_list_price )*(d.quantity))
WHEN (d.wag_coup_cd <> '--' and d.mfg_coup_cd <> '--' ) THEN 0
ELSE ((d.item_list_price )*(d.quantity))
END AS Item_gross_amount,
tot_selling_price_dlrs ,
quantity,
d.line_item_seq_nbr,
d.edw_create_dttm
from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_pos_driver_stg d
)pgm
left outer join 
( select  sales_txn_id ,  txn_dt , cust_id , line_item_seq_nbr FROM ${pDataBase_retail}.${pTD_DB_photo}.photo_order_sales_transaction  AS pop 
							JOIN ${pDataBase_retail}.${pTD_DB_photo}.photo_order po ON po.loc_id = pop.loc_id   AND po.ord_id= pop.ord_id   AND po.photo_env_nbr = pop.photo_env_nbr    AND po.ord_dt = pop.ord_dt
WHERE txn_dt  between to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_2}'  
)pop
on pgm.sales_txn_id=pop.sales_txn_id
and pgm.sales_txn_dt=pop.txn_dt
and pgm.line_item_seq_nbr=pop.line_item_seq_nbr;




create or replace temporary table  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_mid as
select drv.SALES_TXN_ID,drv.SALES_TXN_DT,drv.SALES_ORD_SRC_TYPE,drv.SALES_TXN_TYPE,drv.SRC_SYS_CD,
	drv.STORE_NBR,drv.PRODUCT_KEY,drv.WIC,drv.PROD_SK,drv.TXN_END_DTTM,drv.MFG_COUP_CD,drv.WAG_COUP_CD,
	drv.RETURN_IND,drv.SALE_IND,drv.ITEM_LIST_PRICE,drv.ITEM_NET_PRICE,drv.ITEM_GROSS_AMOUNT,drv.TOT_SELLING_PRICE_DLRS,
	drv.QUANTITY,drv.LINE_ITEM_SEQ_NBR,drv.PROD_TYPE_CD,drv.CUST_ID,NVL2(cust.cust_src_id,cust.cdi_cust_src_id,DRV.MID) as MID,drv.LOYALTY_MBR_ID,drv.CREDIT_CARD,
	drv.COST_DLRS,drv.COST_ADJ_DLRS,drv.LOYALTY_COST_ADJ_DLRS,drv.ORD_PICKUP_TYPE,drv.ORD_PICKUP_LOC ,drv.EDW_CREATE_DTTM,drv.IND
FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg drv left outer join 
(
select * from ${pDataBase_consumption}.${pTD_prdfdlvwb}.link_to_customer 
WHERE cdi_msg_type_cd = '2'
  AND cust_src_cd = '${pSRC_SYS_CD}'
  AND edw_rec_end_dt = '9999-12-31' 
) cust
ON drv.cust_id=cust.cust_src_id
  AND drv.ind=cust.cust_src_cd;
  


create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_loyalty_mbr_id_inner as 
 SELECT sales_txn_id,
          src_sys_cd,
          sales_txn_dt,
          sales_ord_src_type,
          sales_txn_type,
          prog_type_cd,
          prog_cust_id,
          CASE
              WHEN prog_type_cd ='LYCD' THEN 1
              WHEN prog_type_cd ='VCD' THEN 2
              WHEN prog_type_cd ='APPLE_WALLET' THEN 3
              WHEN prog_type_cd ='ANDROID_PAY' THEN 4
          END AS qty
   FROM ${pDataBase_retail}.${pTD_DB_retail_sales}.sales_transaction_program
   WHERE src_sys_cd = ${pSRC_SYS_CD_card_key_upd}
     and sales_txn_dt between to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_2}'
     AND prog_type_cd IN ('LYCD',
                          'VCD',
                          'APPLE_WALLET',
                          'ANDROID_PAY') qualify row_number() over(PARTITION BY sales_txn_id, src_sys_cd, sales_txn_dt, sales_ord_src_type, sales_txn_type
                                                                   ORDER BY sales_txn_id, src_sys_cd, sales_txn_dt, sales_ord_src_type, sales_txn_type, qty) = 1;

create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_loyalty_mbr_id as 
select drv.SALES_TXN_ID,drv.SALES_TXN_DT,drv.SALES_ORD_SRC_TYPE,drv.SALES_TXN_TYPE,drv.SRC_SYS_CD,
	drv.STORE_NBR,drv.PRODUCT_KEY,drv.WIC,drv.PROD_SK,drv.TXN_END_DTTM,drv.MFG_COUP_CD,drv.WAG_COUP_CD,
	drv.RETURN_IND,drv.SALE_IND,drv.ITEM_LIST_PRICE,drv.ITEM_NET_PRICE,drv.ITEM_GROSS_AMOUNT,drv.TOT_SELLING_PRICE_DLRS,
	drv.QUANTITY,drv.LINE_ITEM_SEQ_NBR,drv.PROD_TYPE_CD,drv.CUST_ID,drv.MID,NVL2(pg.sales_txn_id,pg.prog_cust_id,DRV.loyalty_mbr_id) as loyalty_mbr_id,drv.CREDIT_CARD,
	drv.COST_DLRS,drv.COST_ADJ_DLRS,drv.LOYALTY_COST_ADJ_DLRS,drv.ORD_PICKUP_TYPE,drv.ORD_PICKUP_LOC ,drv.EDW_CREATE_DTTM,drv.IND	
	
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_mid drv  LEFT OUTER JOIN 
(
select * from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_loyalty_mbr_id_inner
WHERE src_sys_cd='POS'
  AND prog_type_cd IN ('LYCD','VCD','APPLE_WALLET','ANDROID_PAY')
  AND prog_cust_id is NOT NULL

) pg
  ON drv.sales_txn_id=pg.sales_txn_id
  AND drv.sales_txn_dt=pg.sales_txn_dt
  AND drv.sales_ord_src_type=pg.sales_ord_src_type
  AND drv.sales_txn_type=pg.sales_txn_type
  AND drv.src_sys_cd=pg.src_sys_cd;

	








  create or replace temporary table prod_typ  (
        sales_txn_dt DATE NOT NULL,
        prod_sk BIGINT ,
        prod_type_cd VARCHAR(4) ,
        src_sys_cd VARCHAR(10) ,
        store_nbr INTEGER,
        src_sys_prod_id_1 VARCHAR(40)  )
       ;



  create or replace temporary table dim_code_2
       ( src_cd_val VARCHAR(20) ,
         src_sys_cd VARCHAR(10) 
      )
      ;

  insert into dim_code_2
  select src_cd_val, src_sys_cd from ${pDataBase_master_data}.${pTD_Reference_Code_Values}.dim_code where src_sys_cd='POS'
  and   tgt_col_name='prod_type_cd' 
  and tgt_tbl_name='prod_type_cd_bvw'
  and  CAST(src_cd_val AS INTEGER) < 0;
  


     insert into prod_typ
     SELECT d.sales_txn_dt,
    d.prod_sk,
    d.prod_type_cd,
    d.src_sys_cd,
    d.store_nbr,
    d.src_sys_prod_id_1
    FROM(select sales_txn_dt,prod_sk,prod_type_cd,src_sys_cd,store_nbr,src_sys_prod_id_1 from   ${pDataBase_master_data}.${pTD_product}.product_type
    where 
    src_sys_cd='POS'
    and sales_txn_dt between to_char(DATEADD(DAY, -30, CAST('${pSQL_PARM_2}' as date)), 'YYYY-MM-DD') and '${pSQL_PARM_2}'
    and cast (prod_type_cd as INTEGER) < 0 )   d 
    INNER JOIN (
    SELECT prod_sk,
        store_nbr,
        src_sys_cd,
        sales_txn_dt
        FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_loyalty_mbr_id
        GROUP BY 1,
            2,
            3,
            4) e
 ON d.sales_txn_dt=e.sales_txn_dt
AND d.prod_sk=e.prod_sk
AND d.src_sys_cd=e.src_sys_cd
AND d.store_nbr=e.store_nbr;


create or replace temporary table  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd_inner as 
SELECT b.prod_type_cd,
          b.sales_txn_dt,
          b.store_nbr,
          b.src_sys_prod_id_1,
          b.src_sys_cd,
          b.prod_sk
   FROM
     (SELECT a.sales_txn_dt,
             a.store_nbr,
             a.src_sys_prod_id_1,
             a.src_sys_cd,
             a.prod_sk,
             a.prod_type_cd
      FROM prod_typ a,
           dim_code_2 dim
      WHERE a.prod_type_cd=dim.src_cd_val
        AND a.src_sys_cd=dim.src_sys_cd
        AND dim.src_cd_val=-2
      GROUP BY 1,
               2,
               3,
               4,
               5,
               6) b qualify row_number() over(PARTITION BY sales_txn_dt, store_nbr, src_sys_prod_id_1, src_sys_cd
                                              ORDER BY prod_type_cd) =1; 


create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd as 
select
drv.SALES_TXN_ID,drv.SALES_TXN_DT,drv.SALES_ORD_SRC_TYPE,drv.SALES_TXN_TYPE,drv.SRC_SYS_CD,
	drv.STORE_NBR,drv.PRODUCT_KEY,drv.WIC,drv.PROD_SK,drv.TXN_END_DTTM,drv.MFG_COUP_CD,drv.WAG_COUP_CD,
	drv.RETURN_IND,drv.SALE_IND,drv.ITEM_LIST_PRICE,drv.ITEM_NET_PRICE,drv.ITEM_GROSS_AMOUNT,drv.TOT_SELLING_PRICE_DLRS,
	drv.QUANTITY,drv.LINE_ITEM_SEQ_NBR,NVL2(prod.prod_sk,NVL2(drv.loyalty_mbr_id,prod.PROD_TYPE_CD,drv.prod_type_cd),drv.prod_type_cd) as prod_type_cd,drv.CUST_ID,drv.MID,drv.LOYALTY_MBR_ID,drv.CREDIT_CARD,
	drv.COST_DLRS,drv.COST_ADJ_DLRS,drv.LOYALTY_COST_ADJ_DLRS,drv.ORD_PICKUP_TYPE,drv.ORD_PICKUP_LOC ,drv.EDW_CREATE_DTTM,drv.IND 	

from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_loyalty_mbr_id drv left outer join 
		${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd_inner prod
ON drv.prod_sk=prod.prod_sk
  AND drv.sales_txn_dt=prod.sales_txn_dt
  AND drv.store_nbr=prod.store_nbr
  AND cast(drv.product_key AS VARCHAR(40))=prod.src_sys_prod_id_1
  AND drv.src_sys_cd=drv.src_sys_cd;
  







  create or replace temporary table prod_typ_1  (
        sales_txn_dt DATE NOT NULL,
        prod_sk BIGINT ,
        prod_type_cd VARCHAR(4) ,
        src_sys_cd VARCHAR(10) ,
        store_nbr INTEGER,
        src_sys_prod_id_1 VARCHAR(40)  )
       ;



create or replace temporary table dim_code_1
       ( src_cd_val VARCHAR(20) ,
      src_sys_cd VARCHAR(10) 
      )
      ;


insert into prod_typ_1
SELECT d.sales_txn_dt,
    d.prod_sk,
    d.prod_type_cd,
    d.src_sys_cd,
    d.store_nbr,
    d.src_sys_prod_id_1
    FROM(select sales_txn_dt,prod_sk,prod_type_cd,src_sys_cd,store_nbr,src_sys_prod_id_1 from  ${pDataBase_master_data}.${pTD_product}.product_type
    where 
  src_sys_cd='POS'
and sales_txn_dt between to_char(DATEADD(DAY, -30, CAST('${pSQL_PARM_2}' as date)), 'YYYY-MM-DD') and '${pSQL_PARM_2}'
and cast (prod_type_cd as INTEGER) > 0 )   d 
INNER JOIN (
        SELECT prod_sk,
        store_nbr,
        src_sys_cd,
        sales_txn_dt
        FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd
        GROUP BY 1,
            2,
            3,
            4) e
ON d.sales_txn_dt=e.sales_txn_dt
AND d.prod_sk=e.prod_sk
AND d.src_sys_cd=e.src_sys_cd
AND d.store_nbr=e.store_nbr;


  insert into dim_code_1
 select src_cd_val, src_sys_cd from ${pDataBase_master_data}.${pTD_Reference_Code_Values}.dim_code where src_sys_cd='POS'
  and   tgt_col_name='prod_type_cd' 
and tgt_tbl_name='prod_type_cd_bvw'
and  CAST(src_cd_val AS INTEGER) > 0;





create or replace temporary table  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd_inner_2 as 
SELECT b.prod_type_cd,
          b.sales_txn_dt,
          b.store_nbr,
          b.src_sys_prod_id_1,
          b.src_sys_cd,
          b.prod_sk
   FROM
     (SELECT a.sales_txn_dt,
             a.store_nbr,
             a.src_sys_prod_id_1,
             a.src_sys_cd,
             a.prod_sk,
             a.prod_type_cd
      FROM prod_typ_1 a,
           dim_code_1 dim
      WHERE a.prod_type_cd=dim.src_cd_val
        AND a.src_sys_cd=dim.src_sys_cd
        AND dim.src_cd_val=4
      GROUP BY 1,
               2,
               3,
               4,
               5,
               6) b qualify row_number() over(PARTITION BY sales_txn_dt, prod_sk, store_nbr, src_sys_prod_id_1, src_sys_cd
                                              ORDER BY prod_type_cd) =1; 





create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd_2 as 
select
drv.SALES_TXN_ID,drv.SALES_TXN_DT,drv.SALES_ORD_SRC_TYPE,drv.SALES_TXN_TYPE,drv.SRC_SYS_CD,
	drv.STORE_NBR,drv.PRODUCT_KEY,drv.WIC,drv.PROD_SK,drv.TXN_END_DTTM,drv.MFG_COUP_CD,drv.WAG_COUP_CD,
	drv.RETURN_IND,drv.SALE_IND,drv.ITEM_LIST_PRICE,drv.ITEM_NET_PRICE,drv.ITEM_GROSS_AMOUNT,drv.TOT_SELLING_PRICE_DLRS,
	drv.QUANTITY,drv.LINE_ITEM_SEQ_NBR,NVL2(prod.prod_sk,NVL2(drv.loyalty_mbr_id,drv.prod_type_cd,prod.PROD_TYPE_CD),drv.prod_type_cd) as prod_type_cd,drv.CUST_ID,drv.MID,drv.LOYALTY_MBR_ID,drv.CREDIT_CARD,
	drv.COST_DLRS,drv.COST_ADJ_DLRS,drv.LOYALTY_COST_ADJ_DLRS,drv.ORD_PICKUP_TYPE,drv.ORD_PICKUP_LOC ,drv.EDW_CREATE_DTTM,drv.IND 	
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd drv left outer join 
		${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd_inner_2 prod
ON drv.prod_sk=prod.prod_sk
  AND drv.sales_txn_dt=prod.sales_txn_dt
  AND drv.store_nbr=prod.store_nbr
  AND cast(drv.product_key AS VARCHAR(40))=prod.src_sys_prod_id_1
  AND drv.src_sys_cd=drv.src_sys_cd;
  





create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_credit_card_inner as
SELECT d.*
   FROM
     (SELECT a.sales_txn_dt,
             a.sales_txn_id,
             a.src_sys_cd,
             a.sales_ord_src_type,
             a.sales_txn_type,
             a.card_hash_val_sk,
             z.card_id,
             row_number()over(PARTITION BY a.sales_txn_dt, a.sales_txn_id, a.src_sys_cd, a.sales_ord_src_type, a.sales_txn_type
                              ORDER BY a.tndr_dlrs,z.card_id DESC) AS rownum
      FROM
        (SELECT *
         FROM ${pDataBase_retail}.${pTD_DB_retail_sales}.sales_transaction_tender
         WHERE src_sys_cd='POS'
           AND card_hash_val_sk <>-1
           AND (sales_txn_dt between to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_2}' )
           AND (sales_txn_dt,
                sales_txn_id,
                src_sys_cd,
                sales_ord_src_type,
                sales_txn_type) in
             (SELECT sales_txn_dt,
                     sales_txn_id,
                     src_sys_cd,
                     sales_ord_src_type,
                     sales_txn_type
              FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd_2
              GROUP BY 1,
                       2,
                       3,
                       4,
                       5) ) a
      INNER JOIN
        (SELECT *
         FROM ${pDataBase_retail}.${pTD_DB_retail_sales}.Tender_Card_Hash
         WHERE card_id <> -1) z ON a.card_hash_val_sk = z.card_hash_val_sk)d
   WHERE rownum=1;

create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_credit_card as 
select
drv.SALES_TXN_ID,drv.SALES_TXN_DT,drv.SALES_ORD_SRC_TYPE,drv.SALES_TXN_TYPE,drv.SRC_SYS_CD,
	drv.STORE_NBR,drv.PRODUCT_KEY,drv.WIC,drv.PROD_SK,drv.TXN_END_DTTM,drv.MFG_COUP_CD,drv.WAG_COUP_CD,
	drv.RETURN_IND,drv.SALE_IND,drv.ITEM_LIST_PRICE,drv.ITEM_NET_PRICE,drv.ITEM_GROSS_AMOUNT,drv.TOT_SELLING_PRICE_DLRS,
	drv.QUANTITY,drv.LINE_ITEM_SEQ_NBR,drv.PROD_TYPE_CD,drv.CUST_ID,drv.MID,drv.LOYALTY_MBR_ID,NVL2(tndr.sales_txn_id,NVL2(drv.credit_card,drv.credit_card,tndr.card_id),drv.credit_card) as credit_card,
	drv.COST_DLRS,drv.COST_ADJ_DLRS,drv.LOYALTY_COST_ADJ_DLRS,drv.ORD_PICKUP_TYPE,drv.ORD_PICKUP_LOC ,drv.EDW_CREATE_DTTM,drv.IND	

from 	${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_prod_type_cd_2 drv left outer join
	${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_credit_card_inner tndr
ON drv.sales_txn_id=tndr.sales_txn_id
  AND drv.sales_txn_dt=tndr.sales_txn_dt
  AND drv.sales_ord_src_type=tndr.sales_ord_src_type
  AND drv.sales_txn_type=tndr.sales_txn_type
  AND drv.src_sys_cd=tndr.src_sys_cd;
  	







create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_cost_dlrs_inner as
SELECT a.sales_txn_id,
          a.sales_txn_dt,
          a.sales_txn_type,
          a.src_sys_cd,
          a.line_item_seq_nbr,
          a.cost_dlrs
   FROM ${pDataBase_consumption}.${pTD_prdfdlvwb}.sales_transaction_cost_dtl a,
        ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_credit_card d
   WHERE a.src_sys_cd ='POS'
     AND d.sales_txn_id=a.sales_txn_id
     AND d.sales_txn_dt=a.sales_txn_dt
     AND d.sales_txn_type = a.sales_txn_type
     AND d.src_sys_cd = a.src_sys_cd
     AND d.line_item_seq_nbr = a.line_item_seq_nbr qualify row_number() over(PARTITION BY a.sales_txn_id, a.sales_txn_dt, a.src_sys_cd, a.sales_txn_type, a.line_item_seq_nbr
                                                                             ORDER  BY a.sales_txn_id, a.sales_txn_dt, a.src_sys_cd, a.sales_txn_type, a.line_item_seq_nbr, a.cost_src_type_cd DESC) = 1;

create temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_cost_dlrs as 
select 
drv.SALES_TXN_ID,drv.SALES_TXN_DT,drv.SALES_ORD_SRC_TYPE,drv.SALES_TXN_TYPE,drv.SRC_SYS_CD,
	drv.STORE_NBR,drv.PRODUCT_KEY,drv.WIC,drv.PROD_SK,drv.TXN_END_DTTM,drv.MFG_COUP_CD,drv.WAG_COUP_CD,
	drv.RETURN_IND,drv.SALE_IND,drv.ITEM_LIST_PRICE,drv.ITEM_NET_PRICE,drv.ITEM_GROSS_AMOUNT,drv.TOT_SELLING_PRICE_DLRS,
	drv.QUANTITY,drv.LINE_ITEM_SEQ_NBR,drv.PROD_TYPE_CD,drv.CUST_ID,drv.MID,drv.LOYALTY_MBR_ID,drv.credit_card,
	NVL2(cost_dtl.sales_txn_id,cost_dtl.cost_dlrs,drv.cost_dlrs) as cost_dlrs,drv.COST_ADJ_DLRS,drv.LOYALTY_COST_ADJ_DLRS,drv.ORD_PICKUP_TYPE,drv.ORD_PICKUP_LOC ,drv.EDW_CREATE_DTTM,drv.IND
from 	${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_credit_card drv left outer join 
		${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_cost_dlrs_inner cost_dtl
ON drv.sales_txn_id=cost_dtl.sales_txn_id
  AND drv.sales_txn_dt=cost_dtl.sales_txn_dt
  AND drv.sales_txn_type = cost_dtl.sales_txn_type
  AND drv.src_sys_cd = cost_dtl.src_sys_cd
  AND drv.line_item_seq_nbr = cost_dtl.line_item_seq_nbr; 
  






create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_cost_adj_dlrs_inner as 
SELECT sales_txn_id,
          sales_txn_dt,
          sales_txn_type,
          src_sys_cd,
          line_item_seq_nbr,
          adj_dlrs,
          loyalty_adj_dlrs
   FROM ${pDataBase_consumption}.${pTD_prdfdlvwb}.sales_transaction_cost_adj
   WHERE src_sys_cd ='POS'
   GROUP BY 1,
            2,
            3,
            4,
            5,
            6,
            7;

create	or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_cost_adj_dlrs as 
select 
txn_drv.SALES_TXN_ID,txn_drv.SALES_TXN_DT,txn_drv.SALES_ORD_SRC_TYPE,txn_drv.SALES_TXN_TYPE,txn_drv.SRC_SYS_CD,
	txn_drv.STORE_NBR,txn_drv.PRODUCT_KEY,txn_drv.WIC,txn_drv.PROD_SK,txn_drv.TXN_END_DTTM,txn_drv.MFG_COUP_CD,txn_drv.WAG_COUP_CD,
	txn_drv.RETURN_IND,txn_drv.SALE_IND,txn_drv.ITEM_LIST_PRICE,txn_drv.ITEM_NET_PRICE,txn_drv.ITEM_GROSS_AMOUNT,txn_drv.TOT_SELLING_PRICE_DLRS,
	txn_drv.QUANTITY,txn_drv.LINE_ITEM_SEQ_NBR,txn_drv.PROD_TYPE_CD,txn_drv.CUST_ID,txn_drv.MID,txn_drv.LOYALTY_MBR_ID,txn_drv.credit_card,
	txn_drv.cost_dlrs,NVL2(cost_adj.sales_txn_id,cost_adj.adj_dlrs,txn_drv.cost_adj_dlrs) as cost_adj_dlrs,
	NVL2(cost_adj.sales_txn_id,cost_adj.loyalty_adj_dlrs,txn_drv.LOYALTY_COST_ADJ_DLRS) as loyalty_cost_adj_dlrs,txn_drv.ORD_PICKUP_TYPE,txn_drv.ORD_PICKUP_LOC ,txn_drv.EDW_CREATE_DTTM,txn_drv.IND		
from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_cost_dlrs txn_drv left outer join 
	  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_cost_adj_dlrs_inner cost_adj
ON txn_drv.sales_txn_id=cost_adj.sales_txn_id
  AND txn_drv.sales_txn_dt=cost_adj.sales_txn_dt
  AND txn_drv.sales_txn_type = cost_adj.sales_txn_type
  AND txn_drv.src_sys_cd = cost_adj.src_sys_cd
  AND txn_drv.line_item_seq_nbr = cost_adj.line_item_seq_nbr; 







create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_wic as
select 
wic_drv.SALES_TXN_ID,wic_drv.SALES_TXN_DT,wic_drv.SALES_ORD_SRC_TYPE,wic_drv.SALES_TXN_TYPE,wic_drv.SRC_SYS_CD,
	wic_drv.STORE_NBR,wic_drv.PRODUCT_KEY,NVL2(p.prod_sk,p.WIC,wic_drv.wic) as wic,wic_drv.PROD_SK,wic_drv.TXN_END_DTTM,wic_drv.MFG_COUP_CD,wic_drv.WAG_COUP_CD,
	wic_drv.RETURN_IND,wic_drv.SALE_IND,wic_drv.ITEM_LIST_PRICE,wic_drv.ITEM_NET_PRICE,wic_drv.ITEM_GROSS_AMOUNT,wic_drv.TOT_SELLING_PRICE_DLRS,
	wic_drv.QUANTITY,wic_drv.LINE_ITEM_SEQ_NBR,wic_drv.PROD_TYPE_CD,wic_drv.CUST_ID,wic_drv.MID,wic_drv.LOYALTY_MBR_ID,wic_drv.credit_card,
	wic_drv.cost_dlrs,wic_drv.cost_adj_dlrs,wic_drv.LOYALTY_COST_ADJ_DLRS,wic_drv.ORD_PICKUP_TYPE,wic_drv.ORD_PICKUP_LOC ,wic_drv.EDW_CREATE_DTTM,wic_drv.IND
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_cost_adj_dlrs wic_drv 
left outer join
(
select * from  ${pDataBase_master_data}.${pTD_product}.product
 WHERE src_sys_cd='POS'
  AND edw_rec_end_dt='9999-12-31'
) p 
ON wic_drv.prod_sk=p.prod_sk;
 






create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.Sales_Transaction_addtl_tmp as
SELECT
            a.sales_txn_id,
            a.sales_txn_dt,
            a.sales_txn_type,
            a.src_sys_cd,
            a.ord_pickup_type,
            a.ord_pickup_loc
        FROM
            ${pDataBase_retail}.${pTD_DB_retail_sales}.Sales_Transaction_addtl a,
            ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_wic d
        where a.src_sys_cd ='POS' and (a.sales_txn_dt between to_date('${pSQL_PARM_2}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_2}' )           
            AND d.sales_txn_id = a.sales_txn_id
            AND d.sales_txn_dt = a.sales_txn_dt
            AND d.sales_txn_type = a.sales_txn_type
            AND d.src_sys_cd = a.src_sys_cd qualify ROW_NUMBER() OVER(
                PARTITION BY a.sales_txn_id,
                a.sales_txn_dt,
                a.src_sys_cd,
                a.sales_txn_type
                ORDER BY
                    a.sales_txn_id,
                    a.sales_txn_dt,
                    a.src_sys_cd,
                    a.sales_txn_type,
                    a.src_sys_cd desc
            ) = 1;

create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_1 as 
select drv.SALES_TXN_ID,drv.SALES_TXN_DT,drv.SALES_ORD_SRC_TYPE,drv.SALES_TXN_TYPE,drv.SRC_SYS_CD,
	drv.STORE_NBR,drv.PRODUCT_KEY,drv.WIC,drv.PROD_SK,drv.TXN_END_DTTM,drv.MFG_COUP_CD,drv.WAG_COUP_CD,
	drv.RETURN_IND,drv.SALE_IND,drv.ITEM_LIST_PRICE,drv.ITEM_NET_PRICE,drv.ITEM_GROSS_AMOUNT,drv.TOT_SELLING_PRICE_DLRS,
	drv.QUANTITY,drv.LINE_ITEM_SEQ_NBR,drv.PROD_TYPE_CD,drv.CUST_ID,drv.MID,drv.LOYALTY_MBR_ID,drv.CREDIT_CARD,
	drv.COST_DLRS,drv.COST_ADJ_DLRS,drv.LOYALTY_COST_ADJ_DLRS,nvl2(sales_dtl.sales_txn_id,sales_dtl.ord_pickup_type,drv.ord_pickup_type) as ord_pickup_type,
	nvl2(sales_dtl.sales_txn_id,sales_dtl.ord_pickup_loc,drv.ord_pickup_loc)  as ord_pickup_loc,drv.EDW_CREATE_DTTM,drv.IND	
	
	
FROM
    ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_update_wic drv left outer join 
    ${pDataBase_Staging}.${pTD_DB_retail_sales}.SALES_TRANSACTION_ADDTL_TMP sales_dtl

ON  drv.sales_txn_id = sales_dtl.sales_txn_id
AND drv.sales_txn_dt = sales_dtl.sales_txn_dt
AND drv.sales_txn_type = sales_dtl.sales_txn_type
AND drv.src_sys_cd = sales_dtl.src_sys_cd;


delete from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg;
insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg 
select * from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_1;
           






delete from ${pDataBase_Staging}.${pTD_DB_retail_sales}.ccpa_stage_optout_table_stg;


insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.ccpa_stage_optout_table_stg
(cust_src_id
,src_sys_cd
,composite_type_cd
,msg_type_cd
,Opt_out_begin_dt
,opt_out_end_dt)
select
cust_src_id, src_sys_cd,
composite_type_cd,
msg_type_cd,
Optout_begin_dt,optout_end_dt
from ${pDataBase_retail}.CCPA.ccpa_customer_request_list
where reqst_type_cd = 'OPTOUT'
and current_date between optout_begin_dt and optout_end_dt
group by 1,2,3,4,5,6
UNION
select
cdi_cust_src_id as cust_src_id, 'CDI' as src_sys_cd, cdi_composite_type_cd,cdi_msg_type_cd,
Optout_begin_dt,optout_end_dt
from
(SELECT src_sys_cd, cust_src_id,Optout_begin_dt,optout_end_dt
FROM ${pDataBase_retail}.CCPA.ccpa_customer_request_list where src_sys_cd in
(select src_sys_cd from ${pDataBase_Staging}.CCPA.ccpa_non_pharmacy_list_stg where src_sys_cd <> 'CDI')
And reqst_type_cd = 'OPTOUT' and current_date between optout_begin_dt and optout_end_dt group by 1,2,3,4) a
inner join ${pDataBase_master_data}.${pTD_customer}.link_to_customer b
ON a.cust_src_id=b.cust_src_id
and a.src_sys_cd=b.cust_src_cd
and b.cdi_msg_type_cd in ('1','2')
group by 1,2,3,4,5,6;


create or replace temporary table ${pDataBase_Staging}.${pTD_DB_retail_sales}.transaction_intermediate_file as 
select 
sales_txn_dt as transaction_date  ,  
CAST(SUBSTR(CAST(txn_end_dttm AS VARCHAR(23)),12,19) AS TIME(0))  as transaction_time ,
sales_txn_id as  transaction_number,
sales_txn_type,
src_sys_cd,
to_decimal(store_nbr,30,0) as store_number ,
loyalty_mbr_id as loyalty_card_number ,
tot_selling_price_dlrs as selling_price, 
mid ,
to_decimal(credit_card ,18,0) as credit_card,
product_key as upc ,
wic,
null as retailer_product_identifier,
item_list_price ,
item_net_price ,
to_decimal(line_item_seq_nbr,30,0) as line_item_seq_nbr,
quantity  as item_quantity ,
null as weighted_item_weight ,
null as weighted_item_count ,
null as item_deal_quantity ,
null as item_sale_quantity ,
null as item_net_amount ,
item_gross_amount,
return_ind as return_indicator ,
null as cost_dlrs ,
null as cost_adj_dlrs ,
null as loyalty_cost_adj_dlrs ,
null as gross_profit,
sale_ind
FROM ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg_1 where product_key  not in (42000000957,42000000907);



delete from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_addl_file_stg;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_addl_file_stg
select  
to_date(transaction_date ::VARCHAR(30), 'YYYY-MM-DD') as transaction_date,
transaction_time,
transaction_number,
sales_txn_type,
src_sys_cd,
store_number,
loyalty_card_number,
to_decimal(selling_price,12,2) as selling_price,
NVL2(mid ,'E' || mid , mid ) as mid,
NVL2(credit_card ,'C' || to_varchar(credit_card) , to_varchar(credit_card) ) as card_id,
to_decimal(upc,18,0) as upc,
to_decimal(wic,18,0) as wic,
to_decimal(retailer_product_identifier,30,0) as retailer_product_identifier,
to_decimal(item_list_price,12,2) as item_list_price,
to_decimal(item_net_price,12,2) as item_net_price,
max(line_item_seq_nbr) as line_item_seq_nbr,
to_decimal(item_quantity,18,0) as item_quantity,
to_decimal(weighted_item_weight,30,0) as weighted_item_weight,
to_decimal(weighted_item_count,30,0) as weighted_item_count,
to_decimal(item_deal_quantity,30,0) as item_deal_quantity,
to_decimal(item_sale_quantity,30,0) as item_sale_quantity,
to_decimal(item_net_amount,30,0) as item_net_amount,
to_decimal(item_gross_amount,12,2) as item_gross_amount,
return_indicator,
to_decimal(cost_dlrs,18,2) as cost_dlrs,
to_decimal(cost_adj_dlrs,18,2) as cost_adj_dlrs,
to_decimal(loyalty_cost_adj_dlrs,18,2) as loyalty_cost_adj_dlrs,
to_decimal(gross_profit,18,2) as gross_profit,
sale_ind
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.transaction_intermediate_file
group by 
(
transaction_date,
transaction_time,
transaction_number,
sales_txn_type,
src_sys_cd,
store_number,
loyalty_card_number,
selling_price,
mid,
card_id,
upc,
wic,
retailer_product_identifier,
item_list_price,
item_net_price,
item_quantity,
weighted_item_weight,
weighted_item_count,
item_deal_quantity,
item_sale_quantity,
item_net_amount,
item_gross_amount,
return_indicator,
cost_dlrs,
cost_adj_dlrs,
loyalty_cost_adj_dlrs,
gross_profit,
sale_ind
);


delete from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_dat_file_stg;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_dat_file_stg
select 
transaction_date,
transaction_time,
transaction_number,
store_number,
loyalty_card_number,
mid,
card_id,
upc,
wic,
retailer_product_identifier,
item_list_price,
item_net_price,
item_quantity,
weighted_item_weight,
weighted_item_count,
item_deal_quantity,
item_sale_quantity,
item_net_amount,
item_gross_amount,
return_indicator,
cost_dlrs,
cost_adj_dlrs,
loyalty_cost_adj_dlrs,
gross_profit,
sale_ind
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_addl_file_stg iri_stg
left outer join
(select cust_src_id 
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.ccpa_stage_optout_table_stg opt_out 
where opt_out.composite_type_cd = 'M' 
          and opt_out.msg_type_cd = '1' 
          and opt_out.src_sys_cd = 'LR'
) csi
on iri_stg.loyalty_card_number=csi.cust_src_id 
left outer join
(select 'E' || opt_out.cust_src_id as mid_1
from ${pDataBase_Staging}.${pTD_DB_retail_sales}.ccpa_stage_optout_table_stg opt_out 
where opt_out.composite_type_cd = 'A' 
          and opt_out.msg_type_cd = '2' 
          and opt_out.src_sys_cd = 'CDI'
) ecsi 
on iri_stg.mid=ecsi.mid_1
where csi.cust_src_id is null 
and ecsi.mid_1 is null;


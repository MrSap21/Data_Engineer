select
test.ad_wk,
test.str_nbr,
test.brands as str_brands,
test.ops_dept_nbr,
test.gross_sales,                  
test.gross_sales - (test.return_amount + test.wag_coup_dlr_amt + test.mfg_coup_dlr_amt) as net_sales,
case when (gross_sales is null or gross_sales = 0) then 0 else  test.units end as units,
test.return_amount,
test.wag_coup_dlr_amt as wag_coup_amt,
test.mfg_coup_dlr_amt as mfg_coup_amt
from
(
select 
to_char(t.ad_wk_end_dt,'yyyymmdd') as ad_wk,
t.store_nbr as str_nbr,
 ops_dept_nbr,
sum(case 

when ops_dept_nbr>0 and  original_price_dlrs>0 and  rx_nbr is NULL and  wag_coup_cd ='--' and mfg_coup_cd ='--' and  return_ind = 'N'  and unit_qty > 0  and item_void_cd='--'   
then original_price_dlrs

when (ops_dept_nbr is NULL  or ops_dept_nbr  <0 ) and original_price_dlrs>0 and wag_coup_cd ='--' and mfg_coup_cd ='--'  and  return_ind = 'N'  and unit_qty > 0  and item_void_cd='--'    then original_price_dlrs   
when  original_price_dlrs<=0 and selling_price_dlrs>= 0 and wag_coup_cd ='--' and mfg_coup_cd ='--'  and  return_ind = 'N'  and unit_qty > 0  and item_void_cd='--'   then selling_price_dlrs 
else 0 end) as gross_sales,

sum(case when ops_dept_nbr>0 and return_ind = 'Y'  and  rx_nbr is NULL and  wag_coup_cd ='--' and mfg_coup_cd ='--'  and unit_qty > 0  and item_void_cd='--' then selling_price_dlrs*(-1) else 0 end) as return_amount,   

sum(case  when ops_dept_nbr>0 and  wag_coup_cd <> '--' then selling_price_dlrs*(-1)
when (ops_dept_nbr is NULL  or ops_dept_nbr  <0 )  and  wag_coup_cd <> '--'  then selling_price_dlrs*(-1)
else 0 end ) as wag_coup_dlr_amt,

sum(case 
when ops_dept_nbr>0 and mfg_coup_cd <>'--'  then selling_price_dlrs*(-1)
when (ops_dept_nbr is NULL  or ops_dept_nbr  <0 )  and  mfg_coup_cd <> '--'  then selling_price_dlrs*(-1)
else 0 end) as mfg_coup_dlr_amt,

sum(case when ops_dept_nbr>0 and  original_price_dlrs>0 
		and  rx_nbr is NULL and  wag_coup_cd ='--' 
		and mfg_coup_cd ='--' and  return_ind = 'N' 
	   and unit_qty > 0  and item_void_cd='--'   
        then unit_qty

					when (ops_dept_nbr is NULL  or ops_dept_nbr  <0 ) 
					and original_price_dlrs>0 and wag_coup_cd ='--' 
					and mfg_coup_cd ='--'  and  return_ind = 'N'  
					and unit_qty > 0  and item_void_cd='--'    then unit_qty   
								when  original_price_dlrs<=0 and selling_price_dlrs>= 0 
								and wag_coup_cd ='--' and mfg_coup_cd ='--'  
								and  return_ind = 'N'  and unit_qty > 0  
								and item_void_cd='--'   then unit_qty 
								else 0 end) as units,


lstr.Store_name  as brands
from
(
Select dpp.ad_wk_end_dt,
st.*,
ops_dept_nbr as ops, 

case 
when ((ops_dept_nbr <=0 or  ops_dept_nbr is NULL) and ( wag_coup_cd <> '--' or  mfg_coup_cd <> '--' ) )then '-1'
when ((ops_dept_nbr <=0 or  ops_dept_nbr is NULL) and ( wag_coup_cd ='--' or  mfg_coup_cd ='--' ) )then '-1'
else trim(cast(pph.ops_dept_nbr as INTEGER)) end as ops_dept_nbr

from
(select * from ${pDataBase_MasterData}.${pTD_VIEW_CALENDAR}.dim_promo_period 
where ad_wk_begin_dt between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day') dpp
inner join
(select 
a.store_nbr,
a.sales_txn_id,
a.sales_txn_dt,
a.src_sys_cd,
a.sales_txn_type,
a.sales_ord_src_type,
b.prod_sk,
a.loc_store_sk,
rx_nbr,
photo_env_nbr,
wag_coup_cd,
mfg_coup_cd,
return_ind,
unit_qty,
selling_price_dlrs,
original_price_dlrs,
item_void_cd
from
${pDataBase_Retail}.${pTD_VIEW_RETAIL_SALES}.sales_transaction a
inner join ${pDataBase_Retail}.${pTD_VIEW_RETAIL_SALES}.sales_transaction_detail b
on a.sales_txn_id=b.sales_txn_id
and a.sales_txn_dt=b.sales_txn_dt
and a.sales_ord_src_type=b.sales_ord_src_type
and a.sales_txn_type=b.sales_txn_type
and a.src_sys_cd=a.src_sys_cd
where a.src_sys_cd='${pEDW_SUBJECT_AREA}'
and b.src_sys_cd='${pEDW_SUBJECT_AREA}'
and a.sales_txn_dt between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'
and b.sales_txn_dt between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'
and a.txn_type in (NULL,10, 11, 12, 13, 14, 15, 16, 25)
and  a.training_txn_ind = 'N'
and a.txn_incomplete_ind = 'N'
and a.post_void_status_cd ='--'

  ) st
on st.sales_txn_dt between dpp.ad_wk_begin_dt and dpp.ad_wk_end_dt
left outer join ${pDataBase_MasterData}.${pTD_VIEW_PRODUCT}.product_hierarchy pph
ON pph.prod_sk=st.prod_sk
and pph.src_sys_cd='${pEDW_SUBJECT_AREA}'
and st.sales_txn_dt between pph.edw_rec_begin_dt and pph.edw_rec_end_dt
) t 

left outer join ${pDataBase_MasterData}.${pTD_VIEW_LOCATION}.location_store lstr
on lstr.store_nbr=t.store_nbr 
and lstr.loc_store_sk =t.loc_store_sk
and t.sales_txn_dt between lstr.edw_rec_begin_dt and lstr.edw_rec_end_dt

group by 
ad_wk,
str_nbr,
ops_dept_nbr,
brands
) test;
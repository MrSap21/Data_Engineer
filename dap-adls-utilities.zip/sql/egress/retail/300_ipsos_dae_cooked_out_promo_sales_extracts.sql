WITH mm_stp as 
(
select min(stp.sales_txn_dt) as min_std,
max(stp.sales_txn_dt) as max_std
from 
${pTD_DATABASE_MASTER_DATA}.${pTD_DB_RETAIL_SALES_STG}.pos_str_promo_mvt_stg stp
),

stg as
(select 
AA.store,
AA.opstudy,
AA.regular_price_promo,
AA.selling_price_promo,
AA.quantity_promo
from
(select 
ou.store,
ou.opstudy,
sum(ou.regular_price_promo) as regular_price_promo,
sum(ou.selling_price_promo) as selling_price_promo,
sum(ou.quantity_promo) as quantity_promo
from 
(select 
che.store_nbr_promo as store,
che.ops_dept_nbr as opstudy,
che.regular_ext_price_dlrs_promo as regular_price_promo,
che.selling_price_dlrs_promo as selling_price_promo,
che.qty_promo as quantity_promo
from ( 
select  
ph.ops_dept_nbr,
base.regular_ext_price_dlrs_promo,
base.selling_price_dlrs_promo,
base.qty_promo,
base.sales_txn_id,
base.sales_txn_dt,
base.store_nbr_promo 
from ( 
select 
stpi.regular_ext_price_dlrs_promo,
stpi.selling_price_dlrs_promo,
stpi.qty_promo,
stpi.sales_txn_id,
stpi.sales_txn_dt,
stpi.prod_sk,
stp.store_nbr_promo
from  ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_RETAIL_SALES}.sales_transaction_promo_item stpi  inner join ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_RETAIL_SALES}.sales_transaction_promo stp
on stp.sales_txn_id=stpi.sales_txn_id
cross join mm_stp
on 1=1
where stp.sales_txn_dt between mm_stp.min_std and mm_stp.max_std
group by stpi.regular_ext_price_dlrs_promo,stpi.selling_price_dlrs_promo,stpi.qty_promo,stpi.sales_txn_id,stpi.sales_txn_dt,stpi.prod_sk,stp.store_nbr_promo
) base
inner join ${pTD_DATABASE_MASTER_DATA}.${pTD_DB_PRODUCT}.product_hierarchy ph  on base.prod_sk=ph.prod_sk  where ph.src_sys_cd ='POS'and ph.edw_rec_end_dt ='9999-12-31'
group by ph.ops_dept_nbr,base.regular_ext_price_dlrs_promo,base.selling_price_dlrs_promo,base.qty_promo,base.sales_txn_id,base.sales_txn_dt,base.store_nbr_promo )che )
ou group by ou.store,ou.opstudy
)AA)

select 
from_unixtime(unix_timestamp(mm_stp.max_std ,'yyyy-MM-dd'), 'yyyyMMdd') as ad_week,
stg.store,
stg.opstudy,
stg.regular_price_promo,
stg.selling_price_promo,
stg.quantity_promo,
stg.regular_price_promo/stg.quantity_promo as unit_regular_price from stg
cross join mm_stp
on 1=1;
delete from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg;

insert into ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_transaction_driver_stg
select 
pgm.sales_txn_id,
pgm.sales_txn_dt,
pgm.sales_ord_src_type,
pgm.sales_txn_type,
pgm.src_sys_cd,
pgm.store_nbr,
pgm.product_key,
null as wic,
pgm.prod_sk,
pgm.txn_end_dttm, 
mfg_coup_cd,
wag_coup_cd,
return_ind,
pgm.sale_ind,
item_list_price ,
item_net_price ,
item_gross_amount ,
tot_selling_price_dlrs ,
pgm.quantity,
pgm.line_item_seq_nbr,
null as prod_type_cd,
pop.cust_id as cust_id ,
null as mid,
null as loyalty_mbr_id,
null as credit_card,
NULL AS cost_dlrs,
NULL AS cost_adj_dlrs,
NULL AS loyalty_cost_adj_dlrs,
NULL AS ord_pickup_type ,
NULL AS ord_pickup_loc ,
edw_create_dttm,
'PC' as ind
from(
select 
d.sales_txn_id,
d.sales_txn_dt,
d.sales_ord_src_type,
d.sales_txn_type,
d.src_sys_cd,
d.store_nbr,
d.upc_nbr as product_key,
d.prod_sk,
d.txn_end_dttm,
d.mfg_coup_cd,
d.wag_coup_cd,
d.return_ind,
d.sale_ind,
item_list_price ,
CASE 
WHEN d.quantity is not null and d.quantity > 0 and d.mfg_coup_cd='--' and d.wag_coup_cd= '--' THEN (d.tot_selling_price_dlrs)/(d.quantity) 
ELSE d.tot_selling_price_dlrs END AS item_net_price ,
CASE 
WHEN d.return_ind = 'Y' and d.item_list_price > 0 THEN -1* ((d.item_list_price )*(d.quantity))
WHEN (d.wag_coup_cd <> '--' and d.mfg_coup_cd <> '--' ) THEN 0
ELSE ((d.item_list_price )*(d.quantity))
END AS Item_gross_amount,
tot_selling_price_dlrs ,
quantity,
d.line_item_seq_nbr,
d.edw_create_dttm
from  ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_pos_driver_stg d
)pgm
left outer join 
( select  sales_txn_id ,  txn_dt , cust_id , line_item_seq_nbr FROM ${pDataBase_RETAIL}.${pTD_DB_photo}.photo_order_sales_transaction  AS pop 
							JOIN ${pDataBase_RETAIL}.${pTD_DB_photo}.photo_order po ON po.loc_id = pop.loc_id   AND po.ord_id= pop.ord_id   AND po.photo_env_nbr = pop.photo_env_nbr    AND po.ord_dt = pop.ord_dt
WHERE txn_dt  between to_date('${pSQL_PARM_1}' ::VARCHAR(30), 'YYYY-MM-DD')-30 and '${pSQL_PARM_1}'  
)pop
on pgm.sales_txn_id=pop.sales_txn_id
and pgm.sales_txn_dt=pop.txn_dt
and pgm.line_item_seq_nbr=pop.line_item_seq_nbr;

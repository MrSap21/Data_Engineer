select
ad_wk,
store,
opstudy,
markdown_type,
markdown_description,
selling_amount,
quantity
from
(
select
to_char(dpp.ad_wk_end_dt,'YYYYMMDD') as ad_wk,
sales.store_nbr as store,
pph.ops_dept_nbr as opstudy,
sales.prod_type_cd as markdown_type,
case when prod_type_cd = -7 then 'Loyalty Markdown' else 'Markdown' end as markdown_description,
sum(selling_price_dlrs) as selling_amount,
sum(unit_qty)  as quantity
from
 (select * from ${pDataBase_MasterData}.${pTD_VIEW_CALENDAR}.dim_promo_period
  where ad_wk_begin_dt  between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day') dpp
  inner join
    (select prod.sales_txn_id,prod.store_nbr,
     prod.src_sys_cd,
     prod.sales_txn_dt,
     prod.prod_sk,
     prod.selling_price_dlrs,
     prod.unit_qty,
     prod.wag_coup_cd,
     case when (stp.BR_ind = 'Y' and prod.prod_type_cd=-7) then -7 else 7 end as prod_type_cd
     from
     (
       select distinct a.store_nbr,
       a.sales_txn_id,
       a.sales_txn_dt,
       a.src_sys_cd,
       case when b.sales_txn_type is not null then 'Y' else 'N' end as BR_ind
       from
            (
            select * 
            from  ${pDataBase_Retail}.${pTD_VIEW_RETAIL_SALES}.sales_transaction a
            where src_sys_cd='${pEDW_SUBJECT_AREA}' 
            and sales_txn_dt  between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day' )a
             LEFT OUTER JOIN
            (
            select distinct sales_txn_id,
            sales_txn_dt,
            src_sys_cd,
            sales_txn_type,
			sales_ord_src_type
            from ${pDataBase_Retail}.${pTD_VIEW_RETAIL_SALES}.sales_transaction_program b
            where src_sys_cd='${pEDW_SUBJECT_AREA}' 
            and sales_txn_dt  between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day')b
            ON a.sales_txn_id=b.sales_txn_id
            AND a.sales_txn_dt=b.sales_txn_dt
            AND a.src_sys_cd=b.src_sys_cd
            AND a.sales_txn_type = b.sales_txn_type
            AND a.sales_ord_src_type = b.sales_ord_src_type
            and a.src_sys_cd = '${pEDW_SUBJECT_AREA}'
     ) stp
      inner join
     (
     select st.sales_txn_id,
      st.sales_txn_dt,
      st.src_sys_cd,
      st.loc_store_sk,
      st.store_nbr,
      st.prod_sk,
      st.selling_price_dlrs,
      st.unit_qty,
      st.wag_coup_cd,
      pd.prod_type_cd ,
      pd.prod_type_desc
      from
        (select *
        from ${pDataBase_MasterData}.${pTD_VIEW_PRODUCT}.product_type
        where
        sales_txn_dt  between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'
        and src_sys_cd='${pEDW_SUBJECT_AREA}'
        and prod_type_cd in (-7,7)
       ) pd
        inner join
       (
       select
       a.store_nbr,
       a.sales_txn_id,
       a.sales_txn_dt,
       a.src_sys_cd,
       b.prod_sk,
       a.loc_store_sk,
       case when wag_coup_cd='--' then unit_qty else 0 end as unit_qty,
       selling_price_dlrs,
     wag_coup_cd,
       upc_nbr,
       upc_desc
       from ${pDataBase_Retail}.${pTD_VIEW_RETAIL_SALES}.sales_transaction a
       inner join ${pDataBase_Retail}.${pTD_VIEW_RETAIL_SALES}.sales_transaction_detail b
       on a.sales_txn_id=b.sales_txn_id
       and a.sales_txn_dt=b.sales_txn_dt
       and a.sales_ord_src_type=b.sales_ord_src_type
       and a.sales_txn_type=b.sales_txn_type
       and a.src_sys_cd=b.src_sys_cd
       where a.src_sys_cd='${pEDW_SUBJECT_AREA}'
       and b.src_sys_cd='${pEDW_SUBJECT_AREA}'
       and a.sales_txn_dt  between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'
       and b.sales_txn_dt  between '${pEXT_DATE_1}' and to_date('${pEXT_DATE_1}' ::VARCHAR(30), 'YYYY-MM-DD') + Interval '${pPARM_1}  day'
       and a.txn_type in (10, 11, 12, 13, 14, 15, 16, 25)
       and  a.training_txn_ind = 'N'
       and a.txn_incomplete_ind = 'N'
       and a.post_void_status_cd ='--'
       and b.rx_nbr is NULL
                and b.photo_env_nbr is NULL
                and b.mfg_coup_cd = '--'
                and b.return_ind = 'N'
                and b.unit_qty > 0
                and b.item_void_cd = '--'
       ) st
       on pd.prod_sk = st.prod_sk
       and pd.store_nbr = st.store_nbr
       and pd.sales_txn_dt  = st.sales_txn_dt
       and pd.loc_store_sk = st.loc_store_sk
    )prod
     on
     stp.sales_txn_id = prod.sales_txn_id
     and stp.sales_txn_dt = prod.sales_txn_dt
     and stp.src_sys_cd = prod.src_sys_cd
  ) sales

on sales.sales_txn_dt between dpp.ad_wk_begin_dt and dpp.ad_wk_end_dt


left outer join ${pDataBase_MasterData}.${pTD_VIEW_PRODUCT}.product_hierarchy pph
ON pph.prod_sk=sales.prod_sk
and pph.src_sys_cd='${pEDW_SUBJECT_AREA}'
and pph.edw_rec_end_dt = ${pTD_EDW_END_DATE}

group by ad_wk,store,OpStudy,Markdown_type,Markdown_Description
) tgt;
WITH dt_stp as
(
select 
max(stp.sales_txn_dt) as max_std,
min(stp.sales_txn_dt) as min_std
from
${pTD_hive_metastore}.${pTD_DB_RETAIL_SALES_STAGING}.pos_str_promo_mvt_stg stp
),



ptd as
(select
che2.store,
che2.opstudy,
che2.promo_type,
sum(che2.quantity_promo) as total_promo_qty,
sum(che2.promo_adj_dlrs) as total_promo_adjusted_dollars
from
(
select che.store_nbr_promo as store,
ph.ops_dept_nbr as opstudy,
che.promo_type,
che.qty_promo as quantity_promo,
che.promo_adj_dlrs,
che.prod_sk,
che.sales_txn_id,
che.sales_txn_dt,
che.line_seq_nbr_promo
from
(
select  
base.store_nbr_promo,
base.qty_promo,
base.sales_txn_id,
base.sales_txn_dt,
base.prod_sk,
stpd.promo_type,
stpd.promo_adj_dlrs,
stpd.line_seq_nbr_promo
from
(
select
stp.store_nbr_promo,
stpi.qty_promo,
stpi.sales_txn_id,
stpi.sales_txn_dt,
stpi.prod_sk
from  ${pTD_hive_metastore}.${pTD_DB_RETAIL_SALES}.sales_transaction_promo_item stpi  
inner join  ${pTD_hive_metastore}.${pTD_DB_RETAIL_SALES}.sales_transaction_promo stp
on stpi.sales_txn_id=stp.sales_txn_id and stpi.sales_txn_dt=stp.sales_txn_dt
cross join dt_stp
on 1=1
where stpi.sales_txn_dt between min_std and max_std
group by stp.store_nbr_promo,stpi.qty_promo,stpi.sales_txn_id,stpi.sales_txn_dt,stpi.prod_sk ) base
join ${pTD_hive_metastore}.${pTD_DB_RETAIL_SALES}.sales_transaction_promo_dtl stpd
on base.sales_txn_id=stpd.sales_txn_id and base.sales_txn_dt=stpd.sales_txn_dt
cross join dt_stp
on 1=1
where stpd.sales_txn_dt between min_std and max_std
group by base.store_nbr_promo,base.qty_promo,base.sales_txn_id,base.sales_txn_dt,base.prod_sk,stpd.promo_type,stpd.promo_adj_dlrs,stpd.line_seq_nbr_promo) che
join ${pTD_hive_metastore}.${pTD_DB_PRODUCT}.product_hierarchy ph  
on che.prod_sk=ph.prod_sk  where ph.src_sys_cd ='POS'and ph.edw_rec_end_dt ='9999-12-31' ) che2
group by  che2.store,che2.opstudy,che2.promo_type)




select
from_unixtime(unix_timestamp( dt_stp.max_std,'yyyy-MM-dd'),'yyyyMMdd') as ad_week,
store,
opstudy,
promo_type,
total_promo_qty,
total_promo_adjusted_dollars
from ptd
cross join dt_stp
on 1=1;
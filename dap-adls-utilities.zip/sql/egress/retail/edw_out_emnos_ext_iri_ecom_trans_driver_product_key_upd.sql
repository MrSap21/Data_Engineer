UPDATE ${pDataBase_Staging}.${pTD_DB_retail_sales}.iri_ecom_transaction_inc_driver_stg drv
set product_key=prd.upc, wic=prd.wic
FROM    ${pDATABASE_MASTER_DATA}.${pTD_VIEW_DB_PRODUCT}.product prd
 where drv.prod_sk=prd.prod_sk
and drv.ind=prd.src_sys_cd
and prd.edw_rec_end_dt = to_date('9999-12-31' ::VARCHAR(30), 'YYYY-MM-DD')
and prd.prod_sk not in (select prod_sk from ${pDataBase_Staging}.${pTD_DB_retail_sales}.ecom_product_nonumrc_upc_stg);
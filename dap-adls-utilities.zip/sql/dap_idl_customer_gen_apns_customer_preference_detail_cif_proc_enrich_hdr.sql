
UPDATE $db_param_staging.$pTD_DB_CIF.$pProc_table_name

SET cust_pref_prog_cd = C.cust_pref_prog_cd
,cust_pref_type_cd = C.cust_pref_type_cd
,cust_pref_prog_group_cd = C.cust_pref_prog_group_cd

FROM   $db_param_master_data.$pTD_VIEW_DB_IDL.$SQL_PARAM_1 C
WHERE $pProc_table_name.cust_pref_id = C.cust_pref_id
AND   $pProc_table_name.cust_src_id = C.cust_src_id
AND   $pProc_table_name.cust_src_cd = C.cust_src_cd
AND   $pProc_table_name.composite_type_cd = C.composite_type_cd
AND   $pProc_table_name.msg_type_cd  = C.msg_type_cd
AND   $pProc_table_name.src_sys_cd = C.src_sys_cd
AND   ($pProc_table_name.cust_pref_prog_cd is null 
OR $pProc_table_name.cust_pref_type_cd is null
OR $pProc_table_name.cust_pref_prog_group_cd is null)
AND   C.edw_rec_end_dt = $pTD_EDW_END_DATE
AND   C.src_sys_cd = '$pSRC_SYS_CD'
;

"UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_ORDER TGT
SET
        cust_sk = xref.cust_sk,
	eid_dim_cust_sk = xref.eid_dim_cust_sk,
	mid_dim_cust_sk = xref.mid_dim_cust_sk
FROM    $db_param_master_data.CUSTOMER.DIM_CUSTOMER_XREF xref
WHERE xref.cust_src_id = TGT.pat_src_id
AND xref.src_sys_cd = TGT.src_sys_cd
AND xref.composite_type_cd = TGT.composite_type_cd
AND xref.msg_type_cd = TGT.msg_type_cd
AND TGT.ord_start_dt BETWEEN xref.edw_rec_begin_dt AND xref.edw_rec_end_dt
AND TGT.src_sys_cd = 'SM'
AND TGT.EDW_BATCH_ID > $edw_batch_id
;"
----$edw_batch_id='20220220'
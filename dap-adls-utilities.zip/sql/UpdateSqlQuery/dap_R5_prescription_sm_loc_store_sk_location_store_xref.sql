
UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	dim_loc_store_sk = DL.dim_loc_store_sk
FROM    $db_param_master_data.LOCATION.DIM_LOCATION_STORE_XREF DL
WHERE
        STG.loc_store_sk  = DL.loc_store_sk  
        AND STG.src_sys_cd = 'SM'
        AND STG.rx_create_dt BETWEEN DL.edw_rec_begin_dt AND DL.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';





UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	dim_route_store_sk = LX.dim_loc_store_sk
FROM    $db_param_master_data.LOCATION.DIM_LOCATION_STORE_XREF LX
WHERE
        STG.route_store_sk  = LX.loc_store_sk
        AND STG.src_sys_cd = 'SM'
        AND STG.rx_create_dt BETWEEN LX.edw_rec_begin_dt AND LX.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';



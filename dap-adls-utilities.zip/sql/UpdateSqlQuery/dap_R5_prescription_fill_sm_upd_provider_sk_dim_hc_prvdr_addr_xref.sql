UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET

	pbr_provider_sk = H.hc_provider_sk,
	pbr_provider_addr_sk = H.hc_provider_addr_sk,
        dim_pbr_provider_addr_sk = H.dim_hc_provider_addr_sk
FROM   $db_param_misc.PROCESS.DIM_HEALTHCARE_PRVDR_ADDR_XREF H
	
WHERE
        tgt.pbr_provider_src_id = H.hc_provider_src_id 
        AND tgt.pbr_provider_addr_src_id = H.hc_provider_addr_src_id  
        AND tgt.src_sys_cd=H.src_sys_cd  
        AND tgt.src_sys_cd = 'SM' 
        AND tgt.fill_enter_dt  BETWEEN H.edw_rec_begin_dt AND H.edw_rec_end_dt
        AND tgt.EDW_BATCH_ID > '$edw_batch_id';
;



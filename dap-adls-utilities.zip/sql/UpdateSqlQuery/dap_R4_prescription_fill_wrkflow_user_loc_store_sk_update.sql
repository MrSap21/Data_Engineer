UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_FILL_WRKFLOW_USER STG
SET
STG.loc_store_sk = DIM.loc_store_sk
FROM
$db_param_master_data.LOCATION.LOCATION_STORE DIM
WHERE
STG.store_nbr = DIM.store_nbr
AND STG.src_sys_cd = 'SM'
AND STG.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt AND STG.edw_batch_id > $edw_batch_id
;
UPDATE   $db_param_master_data.CUSTOMER.PHOTO_CUSTOMER stg
SET  ecom_cust_sk = idl.cust_sk
FROM   $db_param_master_data.CUSTOMER.customer idl
WHERE stg.ecom_acct_id = idl.cust_src_id
AND   stg.ecom_src_sys_cd = idl.src_sys_cd
AND   stg.ecom_composite_type_cd = idl.composite_type_cd
AND   stg.ecom_msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = '9999-12-31'
AND   idl.src_sys_cd = 'EC'
AND   stg.src_sys_cd = 'PC'
AND idl.EDW_BATCH_ID > $edw_batch_id;
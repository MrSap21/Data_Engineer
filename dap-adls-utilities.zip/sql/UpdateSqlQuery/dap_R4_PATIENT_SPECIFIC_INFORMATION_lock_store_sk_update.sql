UPDATE $db_param_pharmacy.PATIENT.PATIENT_SPECIFIC_INFORMATION tgt 
SET 
lock_store_sk = lockstr.loc_store_sk
FROM $db_param_master_data.LOCATION.LOCATION_STORE lockstr
WHERE tgt.lock_store_nbr=lockstr.store_nbr
AND lockstr.edw_rec_end_dt=CAST('9999-12-31' AS Date)
AND tgt.lock_store_sk!=-1
AND lockstr.loc_store_sk!=-1
AND tgt.EDW_BATCH_ID > '$edw_batch_id';
update  $db_param_master_data.CUSTOMER.CUSTOMER_PREFERENCE_DETAIL stg
set cust_pref_prog_group_sk = tgt.cust_pref_prog_group_sk
from  $db_param_master_data.CUSTOMER.CUSTOMER_PREFERENCE_PROGRAM tgt
where stg.src_sys_cd = tgt.src_sys_cd
and stg.src_sys_cd = 'opv'
and tgt.edw_rec_end_dt = '9999-12-31'
and stg.cust_pref_prog_cd = tgt.cust_pref_prog_cd
and stg.cust_pref_prog_group_cd = tgt.cust_pref_prog_group_cd  AND stg.edw_batch_id > '';
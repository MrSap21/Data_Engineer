UPDATE $db_param_pharmacy.PATIENT.PATIENT_SPECIFIC_INFORMATION tgt 
SET 
hipaa_signature_store_sk =hippastr.loc_store_sk
FROM $db_param_master_data.LOCATION.LOCATION_STORE hippastr
WHERE tgt.HIPAA_SIGNATURE_STORE_NBR=hippastr.store_nbr 
and tgt.hipaa_signature_store_sk!=-1 
and hippastr.loc_store_sk!=-1
AND hippastr.edw_rec_end_dt=CAST('9999-12-31' AS Date)
AND tgt.EDW_BATCH_ID > '$edw_batch_id';
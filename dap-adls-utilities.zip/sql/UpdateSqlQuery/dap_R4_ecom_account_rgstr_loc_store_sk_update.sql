UPDATE $db_param_digital.ECOM.ECOM_ACCOUNT  stg
SET  rgstr_loc_store_sk = idl.loc_store_sk
FROM    $db_param_master_data.LOCATION.LOCATION_STORE idl
WHERE stg.rgstr_store_nbr = idl.store_nbr
AND   idl.edw_rec_end_dt = to_date('9999-12-31'::VARCHAR(30),'YYYY-MM-DD')
AND   stg.src_sys_cd = 'EC' AND stg.edw_batch_id > ''
;
UPDATE $db_param_digital.ECOM.ECOM_ACCOUNT stg
SET  pat_cust_sk = idl.cust_sk
FROM    $db_param_master_data.CUSTOMER.CUSTOMER idl
WHERE stg.pat_id = idl.cust_src_id
AND   stg.pat_src_sys_cd = idl.src_sys_cd
AND   stg.pat_composite_type_cd = idl.composite_type_cd
AND   stg.pat_msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = to_date('9999-12-31'::VARCHAR(30),'YYYY-MM-DD')
AND   idl.src_sys_cd = 'IC'
AND   stg.src_sys_cd = 'EC'
AND stg.edw_batch_id > '';
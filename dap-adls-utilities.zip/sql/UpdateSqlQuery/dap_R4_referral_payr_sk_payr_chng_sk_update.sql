"UPDATE $db_param_pharmacy.PATIENT_SERVICES.REFERRAL TGT
set 
payr_sk = coalesce (DIM.payr_sk,-1),
payr_chng_sk = coalesce (DIM.payr_chng_sk,-1)
FROM    $db_param_pharmacy.PLAN.PAYER DIM where   
 DIM.payr_sk is not null
AND  TGT.src_sys_cd = 'SM'
AND TGT.payr_src_id = DIM.payr_src_id
AND TGT.src_sys_cd = DIM.src_sys_cd
AND  
(((TGT.referral_src_create_dt IS NOT NULL) AND  (TGT.referral_src_create_dt between DIM.edw_rec_begin_dt and DIM.edw_rec_end_dt))
 OR
((TGT.referral_src_create_dt IS NULL) AND DIM.edw_rec_end_dt ='9999-12-31')) AND TGT.EDW_BATCH_ID > $edw_batch_id;"
---$edw_batch_id='20220220'
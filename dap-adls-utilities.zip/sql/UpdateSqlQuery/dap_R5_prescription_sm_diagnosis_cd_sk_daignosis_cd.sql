
UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	primary_diagnosis_cd_sk = D.diagnosis_cd_sk,
        primary_diagnosis_cd_chng_sk = D.diagnosis_cd_chng_sk
FROM    $db_param_pharmacy.PHARMACY_CODES.DIAGNOSIS_CODE D
	
WHERE
        STG.Primary_diagnosis_cd=D.Diagnosis_cd
        AND (CASE WHEN STG.primary_diagnosis_qlfr_cd='01' THEN 'ICD9' 
        WHEN STG.primary_diagnosis_qlfr_cd='02' THEN 'ICD10' 
        WHEN STG.primary_diagnosis_qlfr_cd='9' THEN 'ICD9'
        WHEN STG.primary_diagnosis_qlfr_cd='10' THEN 'ICD10' 
        WHEN STG.primary_diagnosis_qlfr_cd='#' THEN 'ICD9'
        ELSE STG.primary_diagnosis_qlfr_cd END)= D.diagnosis_qlfr_cd
        AND D.src_sys_cd = 'OPV'  
        AND STG.src_sys_cd = 'SM' 
        AND STG.rx_create_dt BETWEEN D.edw_rec_begin_dt AND D.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';


UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	scndry_diagnosis_cd_sk = D.diagnosis_cd_sk,
	scndry_diagnosis_cd_chng_sk = D.diagnosis_cd_chng_sk
FROM    $db_param_pharmacy.PHARMACY_CODES.DIAGNOSIS_CODE D
	
WHERE
        STG.scndry_diagnosis_cd=D.diagnosis_cd 
        AND (CASE WHEN STG.scndry_diagnosis_qlfr_cd='01' THEN 'ICD9' 
        WHEN STG.scndry_diagnosis_qlfr_cd='02' THEN 'ICD10' 
        WHEN STG.scndry_diagnosis_qlfr_cd='9' THEN 'ICD9'
        WHEN STG.scndry_diagnosis_qlfr_cd='10' THEN 'ICD10' 
        WHEN STG.scndry_diagnosis_qlfr_cd='#' THEN 'ICD9'
        ELSE STG.scndry_diagnosis_qlfr_cd END)= D.diagnosis_qlfr_cd
        AND D.src_sys_cd = 'OPV'  
        AND STG.src_sys_cd = 'SM' 
        AND STG.rx_create_dt BETWEEN D.edw_rec_begin_dt AND D.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';





UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	drug_sk = D.drug_sk,
	dim_drug_sk = D.dim_drug_sk
FROM    $db_param_misc.PROCESS.DIM_DRUG_XREF D
WHERE
        STG.drug_id  = D.drug_id
        AND STG.src_sys_cd = D.src_sys_cd   
        AND STG.src_sys_cd= 'SM'
        AND STG.rx_create_dt BETWEEN D.edw_rec_begin_dt AND D.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';


UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	ord_drug_sk = D.drug_sk,
	dim_ord_drug_sk = D.dim_drug_sk
FROM    $db_param_misc.PROCESS.DIM_DRUG_XREF D
WHERE
        STG.ord_drug_id  = D.drug_id
        AND STG.src_sys_cd = D.src_sys_cd
        AND STG.src_sys_cd= 'SM'
        AND STG.rx_create_dt BETWEEN D.edw_rec_begin_dt AND D.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';


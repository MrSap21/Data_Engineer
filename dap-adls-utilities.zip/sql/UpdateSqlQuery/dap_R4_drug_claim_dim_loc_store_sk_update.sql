"UPDATE $db_param_pharmacy.PATIENT_SERVICES.DRUG_CLAIM TGT
SET
        dim_loc_store_sk = DIM.dim_loc_store_sk
   FROM $db_param_master_data.LOCATION.DIM_LOCATION_STORE_XREF DIM
WHERE
        TGT.loc_store_sk = DIM.loc_store_sk
        AND UPPER(TGT.src_sys_cd) = 'SM'
        AND TGT.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
        AND TGT.EDW_BATCH_ID >$edw_batch_id;"
----$edw_batch_id='20220220'
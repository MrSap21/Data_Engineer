
UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	loc_store_sk = LS.loc_store_sk	
FROM    $db_param_master_data.LOCATION.LOCATION_STORE LS
WHERE
        STG.store_nbr = LS.store_nbr 
        AND STG.src_sys_cd = 'SM'        
        AND STG.rx_create_dt BETWEEN LS.edw_rec_begin_dt AND LS.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';




UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET	
	route_store_sk = LS.loc_store_sk
FROM    $db_param_master_data.LOCATION.LOCATION_STORE LS
WHERE
        STG.route_store_nbr = LS.store_nbr 
        AND stg.src_sys_cd = 'SM'        
        AND STG.rx_create_dt BETWEEN LS.edw_rec_begin_dt AND LS.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';





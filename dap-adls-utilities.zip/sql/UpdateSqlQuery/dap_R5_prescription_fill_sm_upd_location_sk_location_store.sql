UPDATE "DEV_PHARMACY_HEALTHCARE"."PATIENT_SERVICES"."PRESCRIPTION_FILL_SM" tgt
SET loc_store_sk = loc.loc_store_sk
FROM    "DEV_MASTER_DATA"."LOCATION"."LOCATION_STORE"  loc
WHERE
        tgt.store_nbr = loc.store_nbr         
        AND tgt.src_sys_cd = 'SM'
        AND tgt.fill_enter_dt BETWEEN loc.edw_rec_begin_dt AND loc.edw_rec_end_dt
        AND tgt.EDW_BATCH_ID > '$edw_batch_id' 
;





"UPDATE $db_param_pharmacy.PATIENT_SERVICES.DRUG_CLAIM TGT
SET
insure_plan_sk = DIM.insure_plan_sk,
insure_plan_chng_sk = DIM.insure_plan_chng_sk
FROM $db_param_pharmacy.PLAN.INSURANCE_PLAN DIM
WHERE
TGT.insure_plan_src_id = DIM.insure_plan_src_id
AND TGT.src_sys_cd = DIM.src_sys_cd
AND upper(TGT.src_sys_cd) = 'SM'
AND TGT.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
AND TGT.EDW_BATCH_ID >$edw_batch_id
;"
----$edw_batch_id='20220220'
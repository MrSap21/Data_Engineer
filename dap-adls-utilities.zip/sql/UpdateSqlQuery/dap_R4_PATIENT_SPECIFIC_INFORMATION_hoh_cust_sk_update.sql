UPDATE $db_param_pharmacy.PATIENT.PATIENT_SPECIFIC_INFORMATION tgt
SET
hoh_cust_sk = cust.cust_sk
FROM    $db_param_master_data.CUSTOMER.CUSTOMER cust
where   tgt.hoh_pat_src_id=cust.cust_src_id
AND tgt.hoh_msg_type_cd=cust.msg_type_cd
AND tgt.hoh_composite_type_cd=cust.composite_type_cd
AND tgt.src_sys_cd=cust.src_sys_cd 
AND tgt.hoh_cust_sk!=-1
AND cust.cust_sk!=-1
AND cust.edw_rec_end_dt= CAST('9999-12-31' AS DATE)
AND tgt.EDW_BATCH_ID > '$edw_batch_id';
"UPDATE $db_param_pharmacy.PATIENT_SERVICES.REFERRAL TGT
set 
cust_sk = coalesce (DIM.cust_sk,-1)
FROM $db_param_master_data.CUSTOMER.CUSTOMER DIM where   
 DIM.cust_sk is not null
AND  upper(TGT.src_sys_cd )= 'SM'
AND TGT.composite_type_cd = DIM.composite_type_cd
AND TGT.msg_type_cd = DIM.msg_type_cd
AND TGT.src_sys_cd = DIM.src_sys_cd
AND TGT.pat_src_id = DIM.cust_src_id
AND DIM.edw_rec_end_dt = CAST('9999-12-31' AS DATE)
AND TGT.EDW_BATCH_ID > $edw_batch_id
;"
----$edw_batch_id='20220220'
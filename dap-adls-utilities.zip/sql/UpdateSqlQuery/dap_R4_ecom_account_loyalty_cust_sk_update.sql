UPDATE $db_param_digital.ECOM.ECOM_ACCOUNT stg
SET  loyalty_cust_sk = idl.cust_sk
FROM    $db_param_master_data.CUSTOMER.CUSTOMER idl
WHERE stg.loyalty_mbr_id = idl.cust_src_id
AND   stg.loyalty_src_sys_cd = idl.src_sys_cd
AND   stg.loyalty_composite_type_cd = idl.composite_type_cd
AND   stg.loyalty_msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = to_date('9999-12-31'::VARCHAR(30),'YYYY-MM-DD')
AND   idl.src_sys_cd = 'LR'
AND   stg.src_sys_cd = 'EC'
AND stgedw_batch_id > '';
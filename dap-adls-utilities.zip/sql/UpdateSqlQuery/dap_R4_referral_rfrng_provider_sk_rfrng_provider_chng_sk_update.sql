"UPDATE $db_param_pharmacy.PATIENT_SERVICES.REFERRAL TGT
set 
rfrng_provider_sk = coalesce (DIM.hc_provider_sk,-1),
rfrng_provider_chng_sk = coalesce (DIM.hc_provider_chng_sk,-1)
FROM    $db_param_pharmacy.PRESCRIBER.HEALTHCARE_PROVIDER DIM where   
    ((TGT.rfrng_provider_sk = -1 AND DIM.hc_provider_sk is not null)
 OR (TGT.rfrng_provider_chng_sk = -1 AND DIM.hc_provider_chng_sk is not null))
AND  TGT.src_sys_cd = 'SM'
AND TGT.rfrng_provider_src_id = DIM.hc_provider_src_id
AND TGT.src_sys_cd = DIM.src_sys_cd
AND 
(((TGT.referral_src_create_dt IS NOT NULL) AND  (TGT.referral_src_create_dt between DIM.edw_rec_begin_dt and DIM.edw_rec_end_dt))
 OR
((TGT.referral_src_create_dt IS NULL) AND DIM.edw_rec_end_dt ='9999-12-31')) AND TGT.EDW_BATCH_ID > $edw_batch_id"
---$edw_batch_id='20220220'
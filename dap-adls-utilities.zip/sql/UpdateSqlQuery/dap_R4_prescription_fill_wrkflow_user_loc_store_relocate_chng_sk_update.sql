UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_FILL_WRKFLOW_USER 
SET
loc_store_relocate_chng_sk = -1
WHERE src_sys_cd = 'SM'
UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET
	eid_dim_fill_cust_sk = CX.eid_dim_cust_sk, 
        mid_dim_fill_cust_sk = CX.mid_dim_cust_sk,
        fill_cust_sk = CX.cust_sk      
FROM      $db_param_master_data.CUSTOMER.DIM_CUSTOMER_XREF CX
WHERE
        tgt.fill_pat_src_id = CX.cust_src_id  
        AND tgt.src_sys_cd = CX.src_sys_cd  
        AND tgt.src_sys_cd = 'SM' 
        AND tgt.fill_enter_dt BETWEEN CX.edw_rec_begin_dt AND CX.edw_rec_end_dt
        AND tgt.composite_type_cd= CX.composite_type_cd
        AND tgt.msg_type_cd = CX.msg_type_cd
        AND tgt.EDW_BATCH_ID > '$edw_batch_id'              
;              


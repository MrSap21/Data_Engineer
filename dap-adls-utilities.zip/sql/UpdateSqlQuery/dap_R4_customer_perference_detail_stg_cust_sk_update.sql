update $db_param_master_data.CUSTOMER.CUSTOMER_PREFERENCE_DETAIL stg
set stg.cust_sk = tgt.cust_sk
from $db_param_master_data.CUSTOMER.CUSTOMER_PREFERENCE tgt
where  
 stg.cust_src_id = tgt.cust_src_id
and stg.cust_src_cd = tgt.cust_src_cd
and stg.composite_type_cd = tgt.composite_type_cd
and stg.msg_type_cd = tgt.msg_type_cd
and stg.src_sys_cd = 'EC' AND stg.edw_batch_id>'';
"UPDATE $db_param_pharmacy.PATIENT_SERVICES.NOTIFICATION_TRANSACTION TGT
FROM   
       $db_param_master_data.CUSTOMER.CUSTOMER DIM

SET  cust_sk = DIM.cust_sk
WHERE TGT.cust_src_id = DIM.cust_src_id
AND   TGT.cust_src_cd = DIM.src_sys_cd
AND   TGT.composite_type_cd = DIM.composite_type_cd
AND   TGT.msg_type_cd = DIM.msg_type_cd
AND   upper(TGT.src_sys_cd) = 'OPV'
AND DIM.src_sys_cd <> 'CDI'
AND   DIM.edw_rec_end_dt = CAST('9999-12-31' AS DATE)
AND TGT.edw_batch_id  > $edw_batch_id
;"
----$edw_batch_id='20220220'
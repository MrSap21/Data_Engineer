update   $db_param_master_data.CUSTOMER.CUSTOMER_PREFERENCE_DETAIL stg
   set stg.ecom_cust_sk    = tgt.cust_sk
      
  from  $db_param_digital.ECOM.ECOM_ACCOUNT tgt
 where 
   stg.ecom_acct_id      = tgt.ecom_acct_id
   and stg.composite_type_cd = tgt.composite_type_cd
   and stg.msg_type_cd       = tgt.msg_type_cd
   and stg.ecom_acct_id     <> '#'
   and stg.ecom_src_sys_cd   = 'EC' AND  tgt.src_sys_cd   = 'EC' AND stg.edw_batch_id>'';
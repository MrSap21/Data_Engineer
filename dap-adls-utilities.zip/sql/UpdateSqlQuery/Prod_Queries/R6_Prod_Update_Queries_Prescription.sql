--1. DIM_HEALTHCARE_PRVDR_ADDR_XREF
UPDATE  PROD_MISC.PROCESS.DIM_HEALTHCARE_PRVDR_ADDR_XREF tgt
SET eid_dim_hc_provider_addr_sk = tgt_sk.hc_provider_addr_eid_sk,
    hc_provider_eid = tgt_sk.hc_provider_eid,
    hc_provider_addr_eid = tgt_sk.hc_provider_addr_eid,
    hc_provider_eid_cur = tgt_sk.hc_provider_eid,
    hc_provider_addr_eid_cur = tgt_sk.hc_provider_addr_eid
FROM    PROD_PHARMACY_HEALTHCARE.PRESCRIBER.HC_PROVIDER_LINK tgt_sk
WHERE tgt.hc_provider_src_id = tgt_sk.hc_provider_src_id
AND   tgt.hc_provider_addr_src_id = tgt_sk.hc_provider_addr_src_id
AND   UPPER(tgt.src_sys_cd) = UPPER(tgt_sk.src_sys_cd) /*(NOT CASESPECIFIC)*/
AND   tgt_sk.edw_rec_end_dt = CAST('9999-12-31' AS DATE)
AND   tgt_sk.src_sys_cd='IC' AND tgt.EDW_BATCH_ID > '$edw_batch_id';              


--2. PRESCRIPTION_FILL_SM
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET
	eid_dim_fill_cust_sk = CX.eid_dim_cust_sk, 
        mid_dim_fill_cust_sk = CX.mid_dim_cust_sk,
        fill_cust_sk = CX.cust_sk      
FROM      PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF CX
WHERE
        tgt.fill_pat_src_id = CX.cust_src_id  
        AND tgt.src_sys_cd = CX.src_sys_cd  
        AND tgt.src_sys_cd = 'SM' 
        AND tgt.fill_enter_dt BETWEEN CX.edw_rec_begin_dt AND CX.edw_rec_end_dt
        AND tgt.composite_type_cd= CX.composite_type_cd
        AND tgt.msg_type_cd = CX.msg_type_cd
        AND tgt.EDW_BATCH_ID > '$edw_batch_id';   

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET
	dim_drug_dspn_sk = DIM.dim_drug_sk,
        drug_dspn_sk = DIM.drug_sk 
FROM      PROD_MISC.PROCESS.DIM_DRUG_XREF DIM
WHERE
        tgt.drug_dspn_id = dim.drug_id  
        AND tgt.src_sys_cd=dim.src_sys_cd   
        AND tgt.src_sys_cd='SM'         
        AND tgt.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
;

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET
	dim_drug_sk = DIM.dim_drug_sk, 
        drug_sk = DIM.drug_sk    
FROM    PROD_MISC.PROCESS.DIM_DRUG_XREF  DIM
WHERE
        tgt.drug_id = dim.drug_id  
        AND tgt.src_sys_cd=dim.src_sys_cd   
        AND tgt.src_sys_cd= 'SM'         
        AND tgt.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
        AND tgt.EDW_BATCH_ID > '$edw_batch_id' 


UPDATE  PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET
	dim_loc_store_sk = loc.dim_loc_store_sk
FROM     PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF loc
WHERE
        tgt.loc_store_sk = loc.loc_store_sk 
        AND tgt.src_sys_cd = 'SM'        
        AND tgt.fill_enter_dt BETWEEN loc.edw_rec_begin_dt AND loc.edw_rec_end_dt
        AND tgt.EDW_BATCH_ID > '$edw_batch_id' ;		
		
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET loc_store_sk = loc.loc_store_sk
FROM    PROD_MASTER_DATA.LOCATION.LOCATION_STORE  loc
WHERE
        tgt.store_nbr = loc.store_nbr         
        AND tgt.src_sys_cd = 'SM'
        AND tgt.fill_enter_dt BETWEEN loc.edw_rec_begin_dt AND loc.edw_rec_end_dt
        AND tgt.EDW_BATCH_ID > '$edw_batch_id' ;
;


UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET
        dim_fill_pat_cust_sk = PX.dim_pat_cust_sk
FROM    PROD_MISC.PROCESS.DIM_PATIENT_XREF  PX
WHERE
        tgt.fill_cust_sk = PX.cust_sk        
        AND tgt.src_sys_cd = 'SM' 
        AND tgt.fill_enter_dt BETWEEN PX.edw_rec_begin_dt AND PX.edw_rec_end_dt
        AND tgt.EDW_BATCH_ID > '$edw_batch_id';

 
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET

	pbr_provider_sk = H.hc_provider_sk,
	pbr_provider_addr_sk = H.hc_provider_addr_sk,
        dim_pbr_provider_addr_sk = H.dim_hc_provider_addr_sk
FROM   PROD_MISC.PROCESS.DIM_HEALTHCARE_PRVDR_ADDR_XREF H
	
WHERE
        tgt.pbr_provider_src_id = H.hc_provider_src_id 
        AND tgt.pbr_provider_addr_src_id = H.hc_provider_addr_src_id  
        AND tgt.src_sys_cd=H.src_sys_cd  
        AND tgt.src_sys_cd = 'SM' 
        AND tgt.fill_enter_dt  BETWEEN H.edw_rec_begin_dt AND H.edw_rec_end_dt
        AND tgt.EDW_BATCH_ID > '$edw_batch_id';


-----3. PRESCRIPTION_SM
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
        eid_dim_cust_sk = CX.eid_dim_cust_sk,
        mid_dim_cust_sk = CX.mid_dim_cust_sk,
        cust_sk = CX.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF CX
WHERE
        STG.pat_src_id=CX.cust_src_id  
        AND STG.src_sys_cd=CX.src_sys_cd  
        AND STG.src_sys_cd = 'SM' 
        AND STG.composite_type_cd= CX.composite_type_cd 
        AND STG.msg_type_cd= CX.msg_type_cd  
        AND STG.rx_create_dt BETWEEN CX.edw_rec_begin_dt AND CX.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';


UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	primary_diagnosis_cd_sk = D.diagnosis_cd_sk,
        primary_diagnosis_cd_chng_sk = D.diagnosis_cd_chng_sk
FROM    PROD_PHARMACY_HEALTHCARE.PHARMACY_CODES.DIAGNOSIS_CODE D
	
WHERE
        STG.Primary_diagnosis_cd=D.Diagnosis_cd
        AND (CASE WHEN STG.primary_diagnosis_qlfr_cd='01' THEN 'ICD9' 
        WHEN STG.primary_diagnosis_qlfr_cd='02' THEN 'ICD10' 
        WHEN STG.primary_diagnosis_qlfr_cd='9' THEN 'ICD9'
        WHEN STG.primary_diagnosis_qlfr_cd='10' THEN 'ICD10' 
        WHEN STG.primary_diagnosis_qlfr_cd='#' THEN 'ICD9'
        ELSE STG.primary_diagnosis_qlfr_cd END)= D.diagnosis_qlfr_cd
        AND D.src_sys_cd = 'OPV'  
        AND STG.src_sys_cd = 'SM' 
        AND STG.rx_create_dt BETWEEN D.edw_rec_begin_dt AND D.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';


UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	scndry_diagnosis_cd_sk = D.diagnosis_cd_sk,
	scndry_diagnosis_cd_chng_sk = D.diagnosis_cd_chng_sk
FROM    PROD_PHARMACY_HEALTHCARE.PHARMACY_CODES.DIAGNOSIS_CODE D
	
WHERE
        STG.scndry_diagnosis_cd=D.diagnosis_cd 
        AND (CASE WHEN STG.scndry_diagnosis_qlfr_cd='01' THEN 'ICD9' 
        WHEN STG.scndry_diagnosis_qlfr_cd='02' THEN 'ICD10' 
        WHEN STG.scndry_diagnosis_qlfr_cd='9' THEN 'ICD9'
        WHEN STG.scndry_diagnosis_qlfr_cd='10' THEN 'ICD10' 
        WHEN STG.scndry_diagnosis_qlfr_cd='#' THEN 'ICD9'
        ELSE STG.scndry_diagnosis_qlfr_cd END)= D.diagnosis_qlfr_cd
        AND D.src_sys_cd = 'OPV'  
        AND STG.src_sys_cd = 'SM' 
        AND STG.rx_create_dt BETWEEN D.edw_rec_begin_dt AND D.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';



UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	drug_sk = D.drug_sk,
	dim_drug_sk = D.dim_drug_sk
FROM    PROD_MISC.PROCESS.DIM_DRUG_XREF D
WHERE
        STG.drug_id  = D.drug_id
        AND STG.src_sys_cd = D.src_sys_cd   
        AND STG.src_sys_cd= 'SM'
        AND STG.rx_create_dt BETWEEN D.edw_rec_begin_dt AND D.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';


UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	ord_drug_sk = D.drug_sk,
	dim_ord_drug_sk = D.dim_drug_sk
FROM    PROD_MISC.PROCESS.DIM_DRUG_XREF D
WHERE
        STG.ord_drug_id  = D.drug_id
        AND STG.src_sys_cd = D.src_sys_cd
        AND STG.src_sys_cd= 'SM'
        AND STG.rx_create_dt BETWEEN D.edw_rec_begin_dt AND D.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';



UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
       pbr_provider_sk = H.hc_provider_sk,
       pbr_provider_chng_sk = H.hc_provider_chng_sk,
       pbr_provider_addr_sk = H.hc_provider_addr_sk,
       dim_pbr_provider_addr_sk = H.dim_hc_provider_addr_sk
 
FROM    PROD_MISC.PROCESS.DIM_HEALTHCARE_PRVDR_ADDR_XREF H
 
WHERE
       STG.pbr_provider_src_id = H.hc_provider_src_id
AND    STG.pbr_provider_addr_src_id = H.hc_provider_addr_src_id
AND    STG.src_sys_cd=H.src_sys_cd
AND    STG.src_sys_cd = 'SM'
AND    STG.rx_create_dt BETWEEN H.edw_rec_begin_dt AND H.edw_rec_end_dt
AND STG.EDW_BATCH_ID > '$edw_batch_id';


UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	orig_store_crosswalk_chng_sk=LS.loc_store_crosswalk_chng_sk
FROM    PROD_PHARMACY_HEALTHCARE.SPECIALTY.LOCATION_STORE_CROSSWALK LS

WHERE
        
TRIM(STG.orig_store_src_id) = TRIM(LS.loc_store_src_id)
and UPPER(STG.src_sys_cd) = 'SM' /*(NOT CASESPECIFIC)*/
and UPPER(LS.src_sys_cd) ='SM' /*(NOT CASESPECIFIC)*/
and STG.rx_create_dt BETWEEN LS.edw_rec_begin_dt AND LS.edw_rec_end_dt
AND STG.EDW_BATCH_ID > '$edw_batch_id';



UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	store_crosswalk_chng_sk=LS.loc_store_crosswalk_chng_sk 
FROM    PROD_PHARMACY_HEALTHCARE.SPECIALTY.LOCATION_STORE_CROSSWALK LS

WHERE

TRIM(STG.store_src_id)= TRIM(LS.loc_store_src_id)
and UPPER(STG.src_sys_cd) = 'SM' /*(NOT CASESPECIFIC)*/
and UPPER(LS.src_sys_cd)='SM' /*(NOT CASESPECIFIC)*/
and STG.rx_create_dt BETWEEN LS.edw_rec_begin_dt AND LS.edw_rec_end_dt
AND STG.EDW_BATCH_ID > '$edw_batch_id';



UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	dim_loc_store_sk = DL.dim_loc_store_sk
FROM    PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF DL
WHERE
        STG.loc_store_sk  = DL.loc_store_sk  
        AND STG.src_sys_cd = 'SM'
        AND STG.rx_create_dt BETWEEN DL.edw_rec_begin_dt AND DL.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';





UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	dim_route_store_sk = LX.dim_loc_store_sk
FROM    PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF LX
WHERE
        STG.route_store_sk  = LX.loc_store_sk
        AND STG.src_sys_cd = 'SM'
        AND STG.rx_create_dt BETWEEN LX.edw_rec_begin_dt AND LX.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';



UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	loc_store_sk = LS.loc_store_sk	
FROM    PROD_MASTER_DATA.LOCATION.LOCATION_STORE LS
WHERE
        STG.store_nbr = LS.store_nbr 
        AND STG.src_sys_cd = 'SM'        
        AND STG.rx_create_dt BETWEEN LS.edw_rec_begin_dt AND LS.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';




UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET	
	route_store_sk = LS.loc_store_sk
FROM    PROD_MASTER_DATA.LOCATION.LOCATION_STORE LS
WHERE
        STG.route_store_nbr = LS.store_nbr 
        AND stg.src_sys_cd = 'SM'        
        AND STG.rx_create_dt BETWEEN LS.edw_rec_begin_dt AND LS.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';




UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
        dim_pat_cust_sk = PX.dim_pat_cust_sk
FROM    PROD_MISC.PROCESS.DIM_PATIENT_XREF PX
WHERE
        STG.cust_sk=PX.cust_sk
        AND STG.src_sys_cd = 'SM' 
        AND STG.rx_create_dt BETWEEN PX.edw_rec_begin_dt AND PX.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';







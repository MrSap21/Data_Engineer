-- Marketing


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_CALL_COMMENT a
SET 
  loyalty_cust_sk = (c.cust_sk), loyalty_dim_cust_sk = (dlc.dim_loyalty_cust_sk), l
  oyalty_eid_cust_sk = (dc_eid.cust_sk), loyalty_eid_dim_cust_sk = (dc.eid_dim_cust_sk)
, loyalty_mid_cust_sk = (dc_mid.cust_sk)
, loyalty_mid_dim_cust_sk = (dc.mid_dim_cust_sk)
FROM  PROD_MASTER_DATA.CUSTOMER.CUSTOMER AS c
INNER JOIN PROD_MISC.PROCESS.DIM_LOYALTY_CUSTOMER_XREF AS dlc ON c.cust_sk = dlc.cust_sk
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF AS dc ON dlc.cust_sk = dc.cust_sk AND dlc.dim_cust_sk = dc.dim_cust_sk
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF AS dc_eid ON dc.eid_dim_cust_sk = dc_eid.dim_cust_sk
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF AS dc_mid ON dc.mid_dim_cust_sk = dc_mid.dim_cust_sk
where a.edw_batch_id > '$edw_batch_id' and a.loyalty_mbr_id = c.cust_src_id
AND c.src_sys_cd = 'LR' AND c.composite_type_cd = 'M' AND c.msg_type_cd = '1'
AND a.postd_dt BETWEEN c.edw_rec_begin_dt AND c.edw_rec_end_dt
AND a.postd_dt BETWEEN dlc.edw_rec_begin_dt AND dlc.edw_rec_end_dt
AND a.postd_dt BETWEEN dc.edw_rec_begin_dt AND dc.edw_rec_end_dt
AND a.postd_dt BETWEEN dc_eid.edw_rec_begin_dt AND dc_eid.edw_rec_end_dt
AND a.postd_dt BETWEEN dc_mid.edw_rec_begin_dt AND dc_mid.edw_rec_end_dt;


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_MBR_PILOT_ACCRUAL_PTS AS pb
SET
  loyalty_cust_sk = (c.cust_sk)
, loyalty_dim_cust_sk = (dlc.dim_loyalty_cust_sk)
, loyalty_eid_cust_sk = (dc.eid_cust_cur_sk)
, loyalty_eid_dim_cust_sk = (dc.eid_dim_cust_sk)
, loyalty_mid_cust_sk = (dc.mid_cust_cur_sk)
, loyalty_mid_dim_cust_sk = (dc.mid_dim_cust_sk)
FROM  PROD_MASTER_DATA.CUSTOMER.CUSTOMER  AS c
INNER JOIN PROD_MISC.PROCESS.DIM_LOYALTY_CUSTOMER_XREF AS dlc ON c.cust_sk = dlc.cust_sk  
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF AS dc ON dlc.cust_sk = dc.cust_sk AND dlc.dim_cust_sk = dc.dim_cust_sk
where pb.edw_batch_id > '$edw_batch_id' AND  pb.loyalty_mbr_id = c.cust_src_id AND c.src_sys_cd = 'LR' AND c.composite_type_cd = 'M'
AND c.msg_type_cd = '1'
AND c.edw_rec_end_dt = '9999-12-31' AND pb.src_begin_dt BETWEEN dlc.edw_rec_begin_dt AND dlc.edw_rec_end_dt;

UPDATE PROD_MARKETING.LOYALTY.LOYALTY_MEMBER_ADDITIONAL_DATA AS pb
SET
  loyalty_cust_sk = (c.cust_sk)
, loyalty_dim_cust_sk = (dlc.dim_loyalty_cust_sk)
, loyalty_eid_cust_sk = (dc.eid_cust_cur_sk)
, loyalty_eid_dim_cust_sk = (dc.eid_dim_cust_sk)
, loyalty_mid_cust_sk = (dc.mid_cust_cur_sk)
, loyalty_mid_dim_cust_sk = (dc.mid_dim_cust_sk)
FROM PROD_MASTER_DATA.CUSTOMER.CUSTOMER AS c
INNER JOIN PROD_MISC.PROCESS.DIM_LOYALTY_CUSTOMER_XREF AS dlc ON c.cust_sk = dlc.cust_sk  
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF AS dc ON dlc.cust_sk = dc.cust_sk
AND dlc.dim_cust_sk = dc.dim_cust_sk
where pb.edw_batch_id > '$edw_batch_id' and pb.loyalty_mbr_id = c.cust_src_id
AND c.src_sys_cd = 'LR'
AND c.composite_type_cd = 'M'
AND c.msg_type_cd = '1'
AND c.edw_rec_end_dt = '9999-12-31' AND pb.src_begin_dt BETWEEN dlc.edw_rec_begin_dt AND dlc.edw_rec_end_dt;


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_CUSTOMER_PROGRAM stg
SET 	cust_sk = cust.cust_sk	
FROM PROD_MASTER_DATA.CUSTOMER.CUSTOMER cust
WHERE
		stg.loyalty_mbr_id = cust.cust_src_id AND
		cust.src_sys_cd = 'LR' AND
		cust.composite_type_cd = 'M' AND
		cust.msg_type_cd = '1' AND
		cust.edw_rec_end_dt = '9999-12-31' AND
		stg.EDW_BATCH_ID > '$edw_batch_id';


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_MEMBER_CONTINUITY_PROGRESS  STG         
SET    cust_sk = TGT.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.CUSTOMER  TGT
WHERE
        STG.loyalty_mbr_id = TGT.cust_src_id
AND     TGT.src_sys_cd = 'LR'
AND     TGT.composite_type_cd = 'M'
AND     TGT.msg_type_cd = '1'
AND     TGT.edw_rec_end_dt = '9999-12-31'
AND		stg.EDW_BATCH_ID > '$edw_batch_id';

UPDATE PROD_MARKETING.LOYALTY.LOYALTY_MEMBER_CONTINUITY_PROGRESS  STG         
SET    dim_loyalty_cust_sk = TGT.dim_loyalty_cust_sk, dim_cust_sk = TGT.dim_cust_sk
FROM    PROD_MISC.PROCESS.DIM_LOYALTY_CUSTOMER_XREF  TGT
WHERE
        STG.cust_sk = TGT.cust_sk
AND     STG.src_begin_dt BETWEEN TGT.edw_rec_begin_dt AND TGT.edw_rec_end_dt
AND		stg.EDW_BATCH_ID > '$edw_batch_id';


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_MEMBER_MERGE_LINK AS a
SET
  loyalty_cust_sk = (c.cust_sk)
, loyalty_dim_cust_sk = (dlc.dim_loyalty_cust_sk)
, loyalty_eid_cust_sk = (dc_eid.cust_sk)
, loyalty_eid_dim_cust_sk = (dc.eid_dim_cust_sk)
, loyalty_mid_cust_sk = (dc_mid.cust_sk)
, loyalty_mid_dim_cust_sk = (dc.mid_dim_cust_sk)
FROM PROD_MASTER_DATA.CUSTOMER.CUSTOMER AS c
INNER JOIN PROD_MISC.PROCESS.DIM_LOYALTY_CUSTOMER_XREF dlc
ON c.cust_sk = dlc.cust_sk 
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF AS dc
ON dlc.cust_sk = dc.cust_sk
AND dlc.dim_cust_sk = dc.dim_cust_sk 
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF AS dc_eid
ON dc.eid_dim_cust_sk = dc_eid.dim_cust_sk
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF as dc_mid
ON dc.mid_dim_cust_sk = dc_mid.dim_cust_sk
where a.edw_batch_id > '$edw_batch_id' AND a.loyalty_mbr_id = c.cust_src_id
AND c.src_sys_cd = 'LR' AND c.composite_type_cd = 'M' AND c.msg_type_cd = '1'
AND to_date(a.link_merge_delink_dttm) BETWEEN c.edw_rec_begin_dt AND c.edw_rec_end_dt
AND to_date(a.link_merge_delink_dttm) BETWEEN dlc.edw_rec_begin_dt AND dlc.edw_rec_end_dt
AND to_date(a.link_merge_delink_dttm) BETWEEN dc.edw_rec_begin_dt AND dc.edw_rec_end_dt
AND to_date(a.link_merge_delink_dttm) BETWEEN dc_eid.edw_rec_begin_dt AND dc_eid.edw_rec_end_dt
AND to_date(a.link_merge_delink_dttm) BETWEEN dc_mid.edw_rec_begin_dt AND dc_mid.edw_rec_end_dt; 


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_MEMBER_POINT_BALANCE AS a
SET
  loyalty_cust_sk = (c.cust_sk)
, loyalty_dim_cust_sk = (dlc.dim_loyalty_cust_sk)
, loyalty_eid_cust_sk = (dc.eid_cust_cur_sk)
, loyalty_eid_dim_cust_sk = (dc.eid_dim_cust_sk)
, loyalty_mid_cust_sk = (dc.mid_cust_cur_sk)
, loyalty_mid_dim_cust_sk = (dc.mid_dim_cust_sk)
FROM  PROD_MASTER_DATA.CUSTOMER.CUSTOMER AS c
INNER JOIN PROD_MISC.PROCESS.DIM_LOYALTY_CUSTOMER_XREF AS dlc
ON c.cust_sk = dlc.cust_sk 
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF AS dc
ON dlc.cust_sk = dc.cust_sk
AND dlc.dim_cust_sk = dc.dim_cust_sk
where a.edw_batch_id > '$edw_batch_id' AND a.loyalty_mbr_id = c.cust_src_id
AND c.src_sys_cd = 'LR'
AND c.composite_type_cd = 'M'
AND c.msg_type_cd = '1'
AND c.edw_rec_end_dt = '9999-12-31' AND a.postd_dt BETWEEN dlc.edw_rec_begin_dt AND dlc.edw_rec_end_dt;


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_POINT_ACTIVITY_DETAIL AS a
SET dim_prod_sk = (dimp.dim_prod_sk), upc_prod_sk =  (p.prod_sk)
FROM  PROD_MASTER_DATA.PRODUCT.PRODUCT AS p
    JOIN PROD_MISC.PROCESS.DIM_PRODUCT_XREF AS dimp
    ON p.prod_sk = dimp.prod_sk AND p.src_sys_cd ='POS' AND  p.edw_rec_end_dt = '9999-12-31'
WHERE a.edw_batch_id > '$edw_batch_id' AND  COALESCE(a.upc_nbr, -1) = p.upc_nbr AND 
a.sales_txn_dt BETWEEN dimp.edw_rec_begin_dt AND dimp.edw_rec_end_dt;


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_POINT_ACTIVITY AS a
SET
dim_loc_str_sk = (dl.dim_loc_store_sk)
, loyalty_cust_sk = (c.cust_sk)
, loyalty_dim_cust_sk = (dlc.dim_loyalty_cust_sk)
, loyalty_eid_cust_sk = (dc.eid_cust_cur_sk)
, loyalty_eid_dim_cust_sk = (dc.eid_dim_cust_sk)
, loyalty_mid_cust_sk = (dc.mid_cust_cur_sk)
, loyalty_mid_dim_cust_sk = (dc.mid_dim_cust_sk)
FROM  PROD_MASTER_DATA.LOCATION.LOCATION_STORE AS l
INNER JOIN PROD_MASTER_DATA.LOCATION.dim_location_store_xref AS dl
ON l.loc_store_sk = dl.loc_store_sk
INNER JOIN PROD_MASTER_DATA.CUSTOMER.CUSTOMER AS c
ON  c.src_sys_cd = 'LR'
AND c.composite_type_cd = 'M'
AND c.msg_type_cd = '1'
AND c.edw_rec_end_dt = '9999-12-31'
INNER JOIN PROD_MISC.PROCESS.DIM_LOYALTY_CUSTOMER_XREF AS dlc ON c.cust_sk = dlc.cust_sk
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF AS dc
ON dlc.cust_sk = dc.cust_sk AND dlc.dim_cust_sk = dc.dim_cust_sk
WHERE a.edw_batch_id > '$edw_batch_id' AND a.store_nbr = l.store_nbr
AND l.edw_rec_end_dt = '9999-12-31' AND a.sales_txn_dt BETWEEN dl.edw_rec_begin_dt AND dl.edw_rec_end_dt
AND a.loyalty_mbr_id = c.cust_src_id
AND a.sales_txn_dt BETWEEN dlc.edw_rec_begin_dt AND dlc.edw_rec_end_dt;


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_MEMBER_SAVINGS_BALANCE STG       
SET         cust_sk = TGT.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.CUSTOMER TGT
WHERE
        STG.loyalty_mbr_id = TGT.cust_src_id
AND     TGT.src_sys_cd = 'LR'
AND     TGT.composite_type_cd = 'M'
AND     TGT.msg_type_cd = '1'
AND     TGT.edw_rec_end_dt = '9999-12-31'
AND STG.edw_batch_id > '$edw_batch_id';


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_MEMBER_SAVINGS_BALANCE STG         
SET         dim_loyalty_cust_sk = TGT.dim_loyalty_cust_sk, dim_cust_sk = TGT.dim_cust_sk
FROM    PROD_MISC.PROCESS.DIM_LOYALTY_CUSTOMER_XREF TGT
WHERE
        STG.cust_sk = TGT.cust_sk
AND     STG.src_begin_dt BETWEEN TGT.edw_rec_begin_dt AND TGT.edw_rec_end_dt
AND    (STG.dim_cust_sk <> TGT.dim_cust_sk OR STG.dim_loyalty_cust_sk <> TGT.dim_loyalty_cust_sk)
AND STG.edw_batch_id > '$edw_batch_id';


UPDATE PROD_MARKETING.LOYALTY.LOYALTY_MSS_VENDOR_DEAL AS a
SET 
  dim_ad_evt_sk = (alp.ad_loyalty_promo_sk)
, dim_prod_sk = (dp.dim_prod_sk)
, upc_prod_sk = (p.prod_sk)
,loc_store_sk= (ls.loc_store_sk)
,dim_loc_str_sk= (lsx.dim_loc_store_sk)
FROM  PROD_MASTER_DATA.PRODUCT.PRODUCT AS p
INNER JOIN PROD_MISC.PROCESS.DIM_PRODUCT_XREF AS dp ON p.prod_sk = dp.prod_sk
INNER JOIN PROD_MASTER_DATA.LOCATION.LOCATION_STORE as ls on ls.edw_rec_end_dt = '9999-12-31' 
INNER JOIN PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF as lsx on lsx.loc_store_sk=ls.loc_store_sk
INNER JOIN (SELECT adev.ad_evt_type, adev.ad_evt_seq_nbr, adev.ad_evt_vers_type_cd, adev.ad_evt_vers_seq_nbr, 
    adlp.ad_offer_cd, adlp.ad_loyalty_promo_sk,adlp.primary_wic_nbr
    FROM PROD_RETAIL.PROMOTIONS.AD_EVENT AS adev 
    JOIN PROD_RETAIL.PROMOTIONS.AD_LOYALTY_PROMO AS adlp 
    ON  adlp.ad_evt_id = adev.ad_evt_id 
      ) alp         
WHERE a.edw_batch_id > '$edw_batch_id' AND a.upc_nbr = p.upc_nbr and p.src_sys_cd='POS'
AND  p.edw_rec_end_dt = '9999-12-31' 
AND a.sales_txn_dt BETWEEN dp.edw_rec_begin_dt AND dp.edw_rec_end_dt
AND ls.store_nbr=a.store_nbr
AND a.sales_txn_dt BETWEEN lsx.edw_rec_begin_dt AND lsx.edw_rec_end_dt
AND  a.ad_evt_type = alp.ad_evt_type AND a.ad_evt_seq_nbr = alp.ad_evt_seq_nbr AND a.ad_evt_vers_type_cd = alp.ad_evt_vers_type_cd 
AND a.ad_evt_vers_seq_nbr = alp.ad_evt_vers_seq_nbr AND a.wic = alp.primary_wic_nbr AND alp.ad_offer_cd = a.ad_offer_cd

UPDATE PROD_MARKETING.CAMPAIGN.DIGITAL_COUPON_USER_ACTIVITY stg
SET
	loyalty_cust_sk  = cust.cust_sk
FROM    PROD_master_data.customer.customer cust
Where
	cust.src_sys_cd = 'LR'
	And cust.composite_type_cd = 'M'
	And cust.msg_type_cd = '1'
	And cust.edw_rec_end_dt = '9999-12-31'
	And stg.loyalty_mbr_id = cust.cust_src_id
	And stg.edw_batch_id > '$edw_batch_id';



UPDATE PROD_MARKETING.CAMPAIGN.DIGITAL_COUPON_REDEEMED_PROD tgt 
SET
	loyalty_cust_sk = cust.cust_sk
FROM PROD_MASTER_DATA.CUSTOMER.CUSTOMER cust
WHERE
	cust.src_sys_cd = 'LR'
	And cust.composite_type_cd = 'M'
	And cust.msg_type_cd = '1'
	And cust.edw_rec_end_dt = '9999-12-31'
	And tgt.loyalty_mbr_id = cust.cust_src_id
	And tgt.edw_batch_id > '$edw_batch_id'

UPDATE PROD_MARKETING.CAMPAIGN.DIGITAL_COUPON_REDEEMED_PROD stg
SET
	upc_prod_sk =  prod.prod_sk,
	prod_id_1 = prod.src_sys_prod_id_1,
	prod_id_2 = prod.src_sys_prod_id_2,
	prod_id_3 = prod.src_sys_prod_id_3,
	prod_id_4 = prod.src_sys_prod_id_4
FROM PROD_MASTER_DATA.PRODUCT.PRODUCT prod
WHERE
	TO_VARCHAR(prod.upc_nbr) = (CASE when stg.upc IS NULL then NULL else TO_VARCHAR(substr(stg.upc, 1, length(stg.upc) -1))  END)
AND prod.edw_rec_end_dt = '9999-12-31'
AND prod.src_sys_cd     = 'POS'
AND stg.edw_batch_id > '$edw_batch_id';



UPDATE PROD_MARKETING.CAMPAIGN.DIGITAL_COUPON_REDEEMED_PROD stg
SET upc_prod_sk = prod.prod_sk,
   prod_id_1   = prod.src_sys_prod_id_1,
   prod_id_2   = prod.src_sys_prod_id_2,
   prod_id_3   = prod.src_sys_prod_id_3,
   prod_id_4   = prod.src_sys_prod_id_4
FROM PROD_MASTER_DATA.PRODUCT.PRODUCT prod,
   (select distinct upc, max(edw_rec_begin_dt) as max_dt, max(prod_chng_sk) as max_sk
          from PROD_MASTER_DATA.PRODUCT.PRODUCT
         where edw_rec_end_dt = '9999-12-31'
           and src_sys_cd     = 'EC'
        group by 1
        ) dst
   where prod.upc  = stg.upc
   and prod.upc  = dst.upc
   and prod.edw_rec_begin_dt = dst.max_dt
   and prod.prod_chng_sk     = dst.max_sk
   and prod.edw_rec_end_dt   = '9999-12-31'
   and prod.src_sys_cd       = 'EC'
   and stg.edw_batch_id > '$edw_batch_id';


UPDATE PROD_MARKETING.CAMPAIGN.PROGRAM_SEGMENT stg
SET 
    cust_sk = cust.cust_sk
FROM  
        PROD_MASTER_DATA.CUSTOMER.CUSTOMER cust
WHERE
	cust.src_sys_cd = 'LR' AND
	cust.composite_type_cd = 'M' AND
	cust.msg_type_cd = '1' AND
	cust.edw_rec_end_dt = '9999-12-31' AND
	stg.loyalty_mbr_id = cust.cust_src_id AND    
stg.src_sys_cd = cust.src_sys_cd AND    
stg.composite_type_cd = cust.composite_type_cd AND    
stg.msg_type_cd = cust.msg_type_cd AND    
stg.src_sys_cd = 'LR' AND    
stg.cust_sk IS NULL AND 
stg.EDW_BATCH_ID > '$edw_batch_id';

--Marketing Ends
--PATIENT_ACTIVITY
UPDATE PROD_DISCOVERY.PATIENT.PATIENT_ACTIVITY_STG stg
SET
        dim_pat_cust_sk = xref.dim_pat_cust_sk
FROM    DATABASE_MISC.PROCESS.dim_customer_xref xref
WHERE xref.cust_sk = stg.cust_sk
AND stg.src_create_dt BETWEEN xref.edw_rec_begin_dt AND xref.edw_rec_end_dt
AND stg.src_sys_cd = 'SM'
;

UPDATE PROD_DISCOVERY.PATIENT.PATIENT_ACTIVITY_STG
SET edw_etl_step = 'FKPAT'  
WHERE src_sys_cd = 'SM';

UPDATE PROD_DISCOVERY.PATIENT.PATIENT_ACTIVITY_STG stg
SET
        cust_sk = xref.cust_sk,
	eid_dim_cust_sk = xref.eid_dim_cust_sk,
	mid_dim_cust_sk = xref.mid_dim_cust_sk
FROM    MASTER_DATA.CUSTOMER.dim_customer_xref xref
WHERE xref.cust_src_id = stg.pat_src_id
AND xref.src_sys_cd = stg.src_sys_cd
AND xref.composite_type_cd = stg.composite_type_cd
AND xref.msg_type_cd = stg.msg_type_cd
AND stg.src_create_dt BETWEEN xref.edw_rec_begin_dt AND xref.edw_rec_end_dt
AND stg.src_sys_cd = 'SM'
;
UPDATE PROD_DISCOVERY.PATIENT.PATIENT_ACTIVITY_STG 
SET edw_etl_step = 'FKCUS'  
WHERE src_sys_cd = 'SM';

--MEMBER
UPDATE PROD_DISCOVERY.PLAN.MEMBER_STG
SET   mbr_sk = stg.mbr_sk
     ,edw_etl_step = 'PKEY1'
FROM
(
SELECT 
mbr_sk, 
mbr_src_id, 
src_sys_cd,
pat_src_id,
composite_type_cd,
msg_type_cd,
insure_plan_src_id,
plan_rank_cd
FROM PROD_DISCOVERY.PLAN.PROC_MEMBER_STG
WHERE src_sys_cd = 'IC'  group by 1,2,3,4,5,6,7,8
) as stg
WHERE MEMBER_STG.mbr_src_id = stg.mbr_src_id
AND   MEMBER_STG.src_sys_cd = stg.src_sys_cd
AND   MEMBER_STG.pat_src_id = stg.pat_src_id
AND   MEMBER_STG.composite_type_cd = stg.composite_type_cd
AND   MEMBER_STG.msg_type_cd = stg.msg_type_cd
AND   MEMBER_STG.plan_rank_cd = stg.plan_rank_cd
AND   MEMBER_STG.insure_plan_src_id = stg.insure_plan_src_id
AND   MEMBER_STG.mbr_sk IS NULL
AND   MEMBER_STG.edw_etl_step = 'CIF';  "

UPDATE PROD_DISCOVERY.PLAN.MEMBER_STG stg
FROM   PHARMACY_HEALTHCARE.PLAN.INSURANCE_PLAN tgt2
SET
insure_plan_sk=tgt2.insure_plan_sk,
edw_etl_step='FKEY1'
WHERE  stg.insure_plan_src_id = tgt2.insure_plan_src_id
AND tgt2.edw_rec_end_dt = 9999-12-31
AND stg.src_sys_cd =tgt2.src_sys_cd
AND stg.insure_plan_sk = -1
AND stg.src_sys_cd='IC'
AND tgt2.src_sys_cd='IC';"

UPDATE PROD_DISCOVERY.PLAN.MEMBER_STG stg
FROM   PHARMACY_HEALTHCARE.PLAN.INSURANCE_PLAN tgt2
SET
insure_plan_sk=tgt2.insure_plan_sk,
edw_etl_step='FKEY1'
WHERE  stg.insure_plan_src_id = tgt2.insure_plan_src_id
AND tgt2.edw_rec_end_dt = 9999-12-31
AND stg.src_sys_cd =tgt2.src_sys_cd
AND stg.insure_plan_sk = -1
AND stg.src_sys_cd='SM'
AND tgt2.src_sys_cd='SM';"

UPDATE PROD_DISCOVERY.PLAN.MEMBER_STG stg
FROM   PHARMACY_HEALTHCARE.PLAN.INSURANCE_PLAN tgt2
SET
insure_plan_sk=tgt2.insure_plan_sk,
edw_etl_step='FKEY1'
WHERE  stg.insure_plan_src_id = tgt2.insure_plan_src_id
AND tgt2.edw_rec_end_dt = 9999-12-31
AND stg.src_sys_cd =tgt2.src_sys_cd
AND stg.insure_plan_sk = -1
AND stg.src_sys_cd='SM'
AND tgt2.src_sys_cd='SM';"

UPDATE PROD_DISCOVERY.PLAN.MEMBER_STG stg
FROM   PHARMACY_HEALTHCARE.PLAN.INSURANCE_PLAN tgt2
SET
insure_plan_sk=tgt2.insure_plan_sk,
edw_etl_step='FKEY1'
WHERE  stg.insure_plan_src_id = tgt2.insure_plan_src_id
AND tgt2.edw_rec_end_dt = 9999-12-31
AND stg.src_sys_cd =tgt2.src_sys_cd
AND stg.insure_plan_sk = -1
AND stg.src_sys_cd='SM'
AND tgt2.src_sys_cd='SM';"


--MEDICAL_CLAIM
UPDATE "PROD_DISCOVERY"."DNA"."MEDICAL_CLAIM" stg
SET
        insure_plan_chng_sk = xref.insure_plan_chng_sk,
        insure_plan_sk=xref.insure_plan_sk
	
FROM    PROD_DISCOVERY.DNA.INSURANCE_PLAN xref
WHERE xref.insure_plan_src_id = stg.insure_plan_src_id
AND xref.src_sys_cd = stg.src_sys_cd
AND stg.claim_genr_dt BETWEEN xref.edw_rec_begin_dt AND xref.edw_rec_end_dt  
AND stg.src_sys_cd = 'SM'
AND stg.EDW_BATCH_ID < 20220305073440;

UPDATE "PROD_DISCOVERY"."DNA"."MEDICAL_CLAIM"
SET edw_etl_step = 'FKINS'  
WHERE src_sys_cd = 'SM'
AND EDW_BATCH_ID < 20220305073440;

UPDATE "PROD_DISCOVERY"."DNA"."MEDICAL_CLAIM" stg
SET
        insure_plan_chng_sk = xref.insure_plan_chng_sk,
        insure_plan_sk=xref.insure_plan_sk
	
FROM    PROD_DISCOVERY.DNA.INSURANCE_PLAN xref
WHERE xref.insure_plan_src_id = stg.insure_plan_src_id
AND xref.src_sys_cd = stg.src_sys_cd
AND stg.claim_genr_dt BETWEEN xref.edw_rec_begin_dt AND xref.edw_rec_end_dt  
AND stg.src_sys_cd = 'SM'
AND stg.EDW_BATCH_ID < 20220305073440;

UPDATE "PROD_DISCOVERY"."DNA"."MEDICAL_CLAIM"
SET edw_etl_step = 'FKINS'  
WHERE src_sys_cd = 'SM'
AND EDW_BATCH_ID < 20220305073440;

UPDATE "PROD_DISCOVERY"."DNA"."MEDICAL_CLAIM" stg
SET
mbr_chng_sk=xref.mbr_chng_sk,
mbr_sk=xref.mbr_sk
FROM    PROD_DISCOVERY.DNA.MEMBER.MEMBER xref
WHERE stg.mbr_src_id=xref.mbr_src_id
AND stg.claim_genr_dt BETWEEN xref.edw_rec_begin_dt AND xref.edw_rec_end_dt
AND stg.src_sys_cd = 'SM'
AND xref.src_sys_cd = 'SM'
AND stg.EDW_BATCH_ID < 20220305073440
;
UPDATE "PROD_DISCOVERY"."DNA"."MEDICAL_CLAIM"
SET edw_etl_step = 'FKMEM'  
WHERE src_sys_cd = 'SM'
AND EDW_BATCH_ID < 20220305073440;


--MEMBER_BENEFIT

UPDATE  PROD_DISCOVERY.DNA.MEMBER_BENEFIT stg 
FROM    PROD_DISCOVERY.DNA.CUSTOMER tgt3
SET cust_sk=tgt3.cust_sk,
edw_etl_step='FKEY'
WHERE stg.pat_src_id = tgt3.cust_src_id
AND stg.composite_type_cd=tgt3.composite_type_cd
AND stg.msg_type_cd=tgt3.msg_type_cd
AND tgt3.edw_rec_end_dt = '9999-12-31'
AND stg.src_sys_cd =tgt3.src_sys_cd
AND stg.cust_sk = -1
AND stg.src_sys_cd='SM'
AND tgt3.src_sys_cd='SM'
AND stg.EDW_BATCH_ID < 20220305073440;

UPDATE PROD_DISCOVERY.DNA.MEMBER_BENEFIT stg 
FROM  PROD_DISCOVERY.DNA.INSURANCE_PLAN tgt2
SET
insure_plan_sk=tgt2.insure_plan_sk,
edw_etl_step='FKEY2'
WHERE  stg.insure_plan_src_id = tgt2.insure_plan_src_id
AND tgt2.edw_rec_end_dt = '9999-12-31'
AND stg.src_sys_cd =tgt2.src_sys_cd
AND stg.insure_plan_sk = -1
AND stg.src_sys_cd='SM'
AND tgt2.src_sys_cd='SM'
AND stg.EDW_BATCH_ID < 20220305073440;

UPDATE PROD_DISCOVERY.DNA.MEMBER_BENEFIT stg
FROM   PROD_DISCOVERY.DNA.MEMBER_.MEMBER tgt1
SET
mbr_sk=tgt1.mbr_sk,
edw_etl_step='FKEY1'
WHERE stg.mbr_src_id = tgt1.mbr_src_id
AND tgt1.edw_rec_end_dt = '9999-12-31'
AND stg.src_sys_cd =tgt1.src_sys_cd
AND stg.insure_plan_src_id = tgt1.insure_plan_src_id
AND stg.plan_rank_cd =tgt1.plan_rank_cd
AND stg.pat_src_id = tgt1.pat_src_id
AND stg.composite_type_cd=tgt1.composite_type_cd
AND stg.msg_type_cd=tgt1.msg_type_cd
AND stg.mbr_sk = -1
AND stg.src_sys_cd='SM'
AND tgt1.src_sys_cd='SM'
AND stg.EDW_BATCH_ID < 20220305073440;

--MEMBER_INSURANCE_AGREEMENT
UPDATE PROD_DISCOVERY.DNA_SERVICES.MEMBER_INSURANCE_AGREEMENT stg
FROM PROD_DISCOVERY.DNA.CUSTOMER tgt3
SET cust_sk=tgt3.cust_sk,
edw_etl_step='FKEY'
WHERE stg.pat_src_id = tgt3.cust_src_id
AND stg.composite_type_cd=tgt3.composite_type_cd
AND stg.msg_type_cd=tgt3.msg_type_cd
AND tgt3.edw_rec_end_dt = '9999-12-31'
AND stg.src_sys_cd =tgt3.src_sys_cd
AND stg.cust_sk = -1
AND stg.src_sys_cd='SM'
AND tgt3.src_sys_cd='SM';

UPDATE PROD_DISCOVERY.DNA_SERVICES.MEMBER_INSURANCE_AGREEMENT stg
FROM PROD_DISCOVERY.DNA.INSURANCE_PLAN tgt2
SET
insure_plan_sk=tgt2.insure_plan_sk,
edw_etl_step='FKEY2'
WHERE stg.insure_plan_src_id = tgt2.insure_plan_src_id
AND tgt2.edw_rec_end_dt = '9999-12-31'
AND stg.src_sys_cd =tgt2.src_sys_cd
AND stg.insure_plan_sk = -1
AND stg.src_sys_cd='SM'
AND tgt2.src_sys_cd='SM';

UPDATE PROD_DISCOVERY.DNA_SERVICES.MEMBER_INSURANCE_AGREEMENT stg
FROM PROD_DISCOVERY.DNA.MEMBER tgt1
SET
mbr_sk=tgt1.mbr_sk,
edw_etl_step='FKEY1'
WHERE stg.mbr_src_id = tgt1.mbr_src_id
AND tgt1.edw_rec_end_dt ='9999-12-31'
AND stg.src_sys_cd =tgt1.src_sys_cd
AND stg.insure_plan_src_id = tgt1.insure_plan_src_id
AND stg.plan_rank_cd =tgt1.plan_rank_cd
AND stg.pat_src_id = tgt1.pat_src_id
AND stg.composite_type_cd=tgt1.composite_type_cd
AND stg.msg_type_cd=tgt1.msg_type_cd
AND stg.mbr_sk = -1
AND stg.src_sys_cd='SM'
AND tgt1.src_sys_cd='SM';


-- CUSTOMER_PREFERENCE_DETAIL

update  PROD_MASTER_DATA.CUSTOMER.CUSTOMER_PREFERENCE_DETAIL stg
set cust_pref_prog_group_sk = tgt.cust_pref_prog_group_sk
from  PROD_MASTER_DATA.CUSTOMER.CUSTOMER_PREFERENCE_PROGRAM tgt
where stg.src_sys_cd = tgt.src_sys_cd
and stg.src_sys_cd = 'opv'
and tgt.edw_rec_end_dt = '9999-12-31'
and stg.cust_pref_prog_cd = tgt.cust_pref_prog_cd
and stg.cust_pref_prog_group_cd = tgt.cust_pref_prog_group_cd  AND stg.edw_batch_id > '20220306000000';

update PROD_MASTER_DATA.CUSTOMER.CUSTOMER_PREFERENCE_DETAIL stg
set cust_sk = tgt_sk.cust_sk
from 
PROD_MASTER_DATA.CUSTOMER.CUSTOMER tgt_sk
where stg.cust_src_id = tgt_sk.cust_src_id
and stg.composite_type_cd = tgt_sk.composite_type_cd
and stg.msg_type_cd = tgt_sk.msg_type_cd
and tgt_sk.edw_rec_end_dt = '9999-12-31'
and stg.src_sys_cd = 'opv' and tgt_sk.src_sys_cd = 'opv' AND stg.edw_batch_id > '20220304000000';

update PROD_MASTER_DATA.CUSTOMER.CUSTOMER_PREFERENCE_DETAIL stg
set stg.cust_sk = tgt.cust_sk
from PROD_MASTER_DATA.CUSTOMER.CUSTOMER_PREFERENCE tgt
where  
 stg.cust_src_id = tgt.cust_src_id
and stg.cust_src_cd = tgt.cust_src_cd
and stg.composite_type_cd = tgt.composite_type_cd
and stg.msg_type_cd = tgt.msg_type_cd
and stg.src_sys_cd = 'EC' AND stg.edw_batch_id>'20220306000000';

update   PROD_MASTER_DATA.CUSTOMER.CUSTOMER_PREFERENCE_DETAIL stg
   set stg.ecom_cust_sk    = tgt.cust_sk
  from  PROD_DIGITAL.ECOM.ECOM_ACCOUNT tgt
 where 
    stg.ecom_acct_id      = tgt.ecom_acct_id
   and stg.composite_type_cd = tgt.composite_type_cd
   and stg.msg_type_cd       = tgt.msg_type_cd
   and stg.ecom_acct_id     <> '#'
   and stg.ecom_src_sys_cd   = 'EC' AND  tgt.src_sys_cd   = 'EC' AND stg.edw_batch_id>'20220306000000';

-- PHOTO_CUSTOMER

UPDATE   PROD_MASTER_DATA.CUSTOMER.PHOTO_CUSTOMER stg
SET  last_update_loc_store_sk = idl.loc_store_sk
FROM    PROD_MASTER_DATA.LOCATION.LOCATION_STORE idl
WHERE stg.last_update_store_nbr = idl.store_nbr
AND   idl.edw_rec_end_dt = '9999-12-31'
AND   stg.src_sys_cd = 'PC'
AND stg.EDW_BATCH_ID>'20220220000000';

UPDATE   PROD_MASTER_DATA.CUSTOMER.PHOTO_CUSTOMER stg
SET  cust_sk = idl.cust_sk
FROM     PROD_MASTER_DATA.CUSTOMER.CUSTOMER idl
WHERE stg.photo_cust_id = idl.cust_src_id
AND   stg.src_sys_cd = idl.src_sys_cd
AND   stg.composite_type_cd = idl.composite_type_cd
AND   stg.msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = '9999-12-31'
AND   idl.src_sys_cd = 'PC'
AND   stg.src_sys_cd = 'PC'
AND stg.EDW_BATCH_ID>'20220304000000';

UPDATE   PROD_MASTER_DATA.CUSTOMER.PHOTO_CUSTOMER stg
SET  ecom_cust_sk = idl.cust_sk
FROM   PROD_MASTER_DATA.CUSTOMER.CUSTOMER idl
WHERE stg.ecom_acct_id = idl.cust_src_id
AND   stg.ecom_src_sys_cd = idl.src_sys_cd
AND   stg.ecom_composite_type_cd = idl.composite_type_cd
AND   stg.ecom_msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = '9999-12-31'
AND   idl.src_sys_cd = 'EC'
AND   stg.src_sys_cd = 'PC'
AND stg.EDW_BATCH_ID>'20220304000000';

-- ECOM_ACCOUNT

UPDATE PROD_DIGITAL.ECOM.ECOM_ACCOUNT stg
SET  cust_sk = idl.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.CUSTOMER idl
WHERE stg.ecom_acct_id = idl.cust_src_id
AND   stg.src_sys_cd = idl.src_sys_cd
AND   stg.composite_type_cd = idl.composite_type_cd
AND   stg.msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = to_date('9999-12-31'::VARCHAR(30),'YYYY-MM-DD')
AND   idl.src_sys_cd = 'EC'
AND   stg.src_sys_cd = 'EC'
AND stg.edw_batch_id > '20220304000000'
;

UPDATE PROD_DIGITAL.ECOM.ECOM_ACCOUNT stg
SET  loyalty_cust_sk = idl.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.CUSTOMER idl
WHERE stg.loyalty_mbr_id = idl.cust_src_id
AND   stg.loyalty_src_sys_cd = idl.src_sys_cd
AND   stg.loyalty_composite_type_cd = idl.composite_type_cd
AND   stg.loyalty_msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = to_date('9999-12-31'::VARCHAR(30),'YYYY-MM-DD')
AND   idl.src_sys_cd = 'LR'
AND   stg.src_sys_cd = 'EC'
AND stgedw_batch_id > '20220304000000'
;

UPDATE PROD_DIGITAL.ECOM.ECOM_ACCOUNT stg
SET  pat_cust_sk = idl.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.CUSTOMER idl
WHERE stg.pat_id = idl.cust_src_id
AND   stg.pat_src_sys_cd = idl.src_sys_cd
AND   stg.pat_composite_type_cd = idl.composite_type_cd
AND   stg.pat_msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = to_date('9999-12-31'::VARCHAR(30),'YYYY-MM-DD')
AND   idl.src_sys_cd = 'IC'
AND   stg.src_sys_cd = 'EC'
AND stg.edw_batch_id > '20220304000000';

UPDATE PROD_DIGITAL.ECOM.ECOM_ACCOUNT  stg
SET  rgstr_loc_store_sk = idl.loc_store_sk
FROM   PROD_MASTER_DATA.LOCATION.LOCATION_STORE idl
WHERE stg.rgstr_store_nbr = idl.store_nbr
AND   idl.edw_rec_end_dt = to_date('9999-12-31'::VARCHAR(30),'YYYY-MM-DD')
AND   stg.src_sys_cd = 'EC' AND stg.edw_batch_id > '20220220000000'
;

-- PATIENT_SPECIAL_PROGRAM_INFO

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT.PATIENT_SPECIAL_PROGRAM_INFO tgt
SET
cust_sk = cust.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.CUSTOMER cust
where  tgt.pat_src_id=cust.cust_src_id
AND tgt.msg_type_cd=cust.msg_type_cd
AND tgt.composite_type_cd=cust.composite_type_cd
AND tgt.src_sys_cd=cust.src_sys_cd 
AND tgt.cust_sk != -1
AND cust.cust_sk != -1
AND cust.edw_rec_end_dt= CAST('9999-12-31' AS DATE)
AND tgt.EDW_BATCH_ID > '20220306000000';

-- DIM_PATIENT_XREF

UPDATE PROD_MISC.PROCESS.DIM_PATIENT_XREF tgt 
set cust_sk = cust.cust_sk,
dim_cust_sk = cust.dim_cust_sk
FROM PROD_PHARMACY_HEALTHCARE.PATIENT.PATIENT_SPECIFIC_INFORMATION pat 
INNER JOIN PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF cust 
ON pat.cust_sk=cust.cust_sk
where 
pat.src_sys_cd = cust.src_sys_cd
AND pat.pat_chng_sk=tgt.pat_chng_sk 
AND cust.edw_rec_end_dt=CAST('9999-12-31' AS DATE)
AND pat.edw_rec_end_dt=CAST('9999-12-31' AS DATE)
AND tgt.EDW_BATCH_ID > '20220306000000';

-- PATIENT_SPECIFIC_INFORMATION

-- 1. lock_store_sk:

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT.PATIENT_SPECIFIC_INFORMATION tgt 
SET 
lock_store_sk = lockstr.loc_store_sk
FROM    PROD_MASTER_DATA.LOCATION.LOCATION_STORE lockstr
WHERE tgt.lock_store_nbr=lockstr.store_nbr
AND lockstr.edw_rec_end_dt=CAST('9999-12-31' AS Date)
AND tgt.lock_store_sk!=-1
AND lockstr.loc_store_sk!=-1
AND tgt.EDW_BATCH_ID > '20220220000000';

-- 2. hipaa_signature_store_sk:

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT.PATIENT_SPECIFIC_INFORMATION tgt 
SET 
hipaa_signature_store_sk =hippastr.loc_store_sk
FROM    PROD_MASTER_DATA.LOCATION.LOCATION_STORE hippastr
WHERE tgt.HIPAA_SIGNATURE_STORE_NBR=hippastr.store_nbr 
and tgt.hipaa_signature_store_sk!=-1 
and hippastr.loc_store_sk!=-1
AND hippastr.edw_rec_end_dt=CAST('9999-12-31' AS Date)
AND tgt.EDW_BATCH_ID > '20220220000000';

-- 3. orig_register_store_sk:

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT.PATIENT_SPECIFIC_INFORMATION TGT 
SET 
orig_register_store_sk = orgregstr.loc_store_sk
FROM    PROD_MASTER_DATA.LOCATION.LOCATION_STORE orgregstr
WHERE tgt.orig_register_store_nbr=orgregstr.store_nbr
and tgt.orig_register_store_sk!=-1
and orgregstr.loc_store_sk!=-1
AND orgregstr.edw_rec_end_dt= CAST('9999-12-31' AS Date)
AND tgt.EDW_BATCH_ID > '20220220000000';

-- 1. hoh_cust_sk:

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT.PATIENT_SPECIFIC_INFORMATION tgt
SET
hoh_cust_sk = cust.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.CUSTOMER cust
where   tgt.hoh_pat_src_id=cust.cust_src_id
AND tgt.hoh_msg_type_cd=cust.msg_type_cd
AND tgt.hoh_composite_type_cd=cust.composite_type_cd
AND tgt.src_sys_cd=cust.src_sys_cd 
AND tgt.hoh_cust_sk!=-1
AND cust.cust_sk!=-1
AND cust.edw_rec_end_dt= CAST('9999-12-31' AS DATE)
AND tgt.EDW_BATCH_ID > '20220306000000';

-- 2. cust_sk
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT.PATIENT_SPECIAL_PROGRAM_INFO tgt
SET
cust_sk = cust.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.CUSTOMER cust
where  tgt.pat_src_id=cust.cust_src_id
AND tgt.msg_type_cd=cust.msg_type_cd
AND tgt.composite_type_cd=cust.composite_type_cd
AND tgt.src_sys_cd=cust.src_sys_cd 
AND tgt.cust_sk != -1
AND cust.cust_sk != -1
AND cust.edw_rec_end_dt= CAST('9999-12-31' AS DATE)
AND tgt.EDW_BATCH_ID > '20220306000000';

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT.PATIENT_SPECIFIC_INFORMATION tgt
SET pat_pcp_sk = hp.hc_provider_sk
FROM  PROD_PHARMACY_HEALTHCARE.PRESCRIBER.HEALTHCARE_PROVIDER hp
WHERE  
tgt.pat_pcp_src_id= hp.hc_provider_src_id
AND hp.edw_rec_end_dt= CAST('9999-12-31' AS DATE)
AND tgt.pat_pcp_sk!=-1
AND hp.hc_provider_sk!=-1
AND tgt.EDW_BATCH_ID > '20220313000000';

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT.PATIENT_SPECIFIC_INFORMATION tgt 
SET pat_pcp_addr_sk = hpa.hc_provider_addr_sk 
FROM   PROD_PHARMACY_HEALTHCARE.PRESCRIBER.HEALTHCARE_PROVIDER_ADDRESS hpa
WHERE 
tgt.pat_pcp_addr_src_id= hpa.hc_provider_addr_src_id
AND tgt.pat_pcp_src_id= hpa.hc_provider_src_id
AND hpa.edw_rec_end_dt= CAST('9999-12-31' AS DATE)
AND tgt.pat_pcp_addr_sk!=-1
AND hpa.hc_provider_addr_sk!=-1
AND tgt.EDW_BATCH_ID > '20220313000000';

-- REFERRAL_DETAIL

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.REFERRAL_DETAIL TGT1
set 
pbr_provider_sk = coalesce (tgt.hc_provider_sk,-1),
pbr_provider_chng_sk = coalesce (tgt.hc_provider_chng_sk,-1)
FROM    PROD_PHARMACY_HEALTHCARE.PRESCRIBER.HEALTHCARE_PROVIDER tgt where   
 TGT1.src_sys_cd = 'SM'
AND TGT1.pbr_provider_src_id = tgt.hc_provider_src_id
AND TGT1.src_sys_cd = tgt.src_sys_cd
AND 
(((TGT1.referral_src_create_dt IS NOT NULL) AND  (TGT1.referral_src_create_dt between tgt.edw_rec_begin_dt and tgt.edw_rec_end_dt))
 OR
((TGT1.referral_src_create_dt IS NULL) AND tgt.edw_rec_end_dt ='9999-12-31'))
AND TGT1.EDW_BATCH_ID > '20220313000000';

-- DRUG_CLAIM

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.DRUG_CLAIM TGT
SET
insure_plan_sk = DIM.insure_plan_sk,
insure_plan_chng_sk = DIM.insure_plan_chng_sk
FROM PROD_PHARMACY_HEALTHCARE.PLAN.INSURANCE_PLAN DIM
WHERE
TGT.insure_plan_src_id = DIM.insure_plan_src_id
AND TGT.src_sys_cd = DIM.src_sys_cd
AND upper(TGT.src_sys_cd) = 'SM'
AND TGT.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
AND TGT.EDW_BATCH_ID > '20220313000000'
;

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.DRUG_CLAIM TGT
SET
        eid_dim_cust_sk = CX.eid_dim_cust_sk,
        mid_dim_cust_sk = CX.mid_dim_cust_sk,
        cust_sk = CX.cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF CX
WHERE
        TGT.pat_src_id=CX.cust_src_id 
        AND TGT.src_sys_cd=CX.src_sys_cd 
        AND upper(TGT.src_sys_cd) = 'SM'
        AND upper(CX.src_sys_cd)='SM'
        AND TGT.composite_type_cd= CX.composite_type_cd
        AND TGT.msg_type_cd= CX.msg_type_cd 
        AND TGT.fill_enter_dt BETWEEN CX.edw_rec_begin_dt AND CX.edw_rec_end_dt
		AND TGT.EDW_BATCH_ID > '20220306000000';

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.DRUG_CLAIM TGT
SET
LOC_STORE_SK = DIM.LOC_STORE_SK
FROM PROD_MASTER_DATA.LOCATION.LOCATION_STORE DIM
WHERE TGT.STORE_NBR=DIM.store_nbr
AND UPPER(TGT.src_sys_cd) = 'SM'
AND   DIM.edw_rec_end_dt=CAST('9999-12-31' AS Date) 
AND DIM.loc_store_sk!=-1 
AND TGT.EDW_BATCH_ID > '20220220000000';

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.DRUG_CLAIM TGT
SET
        dim_loc_store_sk = DIM.dim_loc_store_sk
   FROM PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF DIM
WHERE
        TGT.loc_store_sk = DIM.loc_store_sk
        AND UPPER(TGT.src_sys_cd) = 'SM'
        AND TGT.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
        AND TGT.EDW_BATCH_ID > '20220220000000';

-- PRESCRIPTRION_ORDER

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_ORDER TGT
SET
LOC_STORE_SK = DIM.LOC_STORE_SK
FROM PROD_MASTER_DATA.LOCATION.LOCATION_STORE DIM
WHERE TGT.STORE_NBR=DIM.store_nbr
AND UPPER(TGT.src_sys_cd) = 'SM'
AND   DIM.edw_rec_end_dt=CAST('9999-12-31' AS Date) 
AND DIM.loc_store_sk!=-1 
AND TGT.EDW_BATCH_ID > '20220220000000';

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_ORDER TGT
SET
        dim_loc_store_sk = DIM.dim_loc_store_sk
FROM     PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF DIM
WHERE
        TGT.loc_store_sk = DIM.loc_store_sk
        AND UPPER(TGT.src_sys_cd) = 'SM'
        AND TGT.ord_start_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
        AND TGT.EDW_BATCH_ID > '20220220000000';
		
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_ORDER TGT
SET
        cust_sk = xref.cust_sk,
	eid_dim_cust_sk = xref.eid_dim_cust_sk,
	mid_dim_cust_sk = xref.mid_dim_cust_sk
FROM    PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF xref
WHERE xref.cust_src_id = TGT.pat_src_id
AND xref.src_sys_cd = TGT.src_sys_cd
AND xref.composite_type_cd = TGT.composite_type_cd
AND xref.msg_type_cd = TGT.msg_type_cd
AND TGT.ord_start_dt BETWEEN xref.edw_rec_begin_dt AND xref.edw_rec_end_dt
AND TGT.src_sys_cd = 'SM'
AND TGT.EDW_BATCH_ID > '20220306000000'
;


-- REFERRAL

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.REFERRAL TGT
set 
cust_sk = coalesce (DIM.cust_sk,-1)
FROM PROD_MASTER_DATA.CUSTOMER.CUSTOMER DIM where   
 DIM.cust_sk is not null
AND  upper(TGT.src_sys_cd )= 'SM'
AND TGT.composite_type_cd = DIM.composite_type_cd
AND TGT.msg_type_cd = DIM.msg_type_cd
AND TGT.src_sys_cd = DIM.src_sys_cd
AND TGT.pat_src_id = DIM.cust_src_id
AND DIM.edw_rec_end_dt = CAST('9999-12-31' AS DATE)
AND TGT.EDW_BATCH_ID > '20220306000000'
;

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.REFERRAL TGT
SET
LOC_STORE_SK = coalesce (DIM.LOC_STORE_SK,-1)
FROM PROD_MASTER_DATA.LOCATION.LOCATION_STORE DIM
WHERE TGT.STORE_NBR=DIM.store_nbr
AND UPPER(TGT.src_sys_cd) = 'SM'
AND   DIM.edw_rec_end_dt=CAST('9999-12-31' AS Date) 
AND DIM.loc_store_sk!=-1 
AND TGT.EDW_BATCH_ID > '20220220000000';

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.REFERRAL TGT
set 
eid_dim_cust_sk =  coalesce(DIM.eid_dim_cust_sk,-1),
mid_dim_cust_sk =  coalesce(DIM.mid_dim_cust_sk,-1)
FROM    PROD_MASTER_DATA.CUSTOMER.DIM_CUSTOMER_XREF DIM where   
    ((DIM.eid_dim_cust_sk is not null)
OR ( DIM.mid_dim_cust_sk is not null))
AND  TGT.src_sys_cd = 'SM'
AND  TGT.src_sys_cd = DIM.src_sys_cd
AND  TGT.cust_sk = DIM.cust_sk 
AND (((TGT.referral_src_create_dt IS NOT NULL) AND  (TGT.referral_src_create_dt between DIM.edw_rec_begin_dt and DIM.edw_rec_end_dt))
 OR
((TGT.referral_src_create_dt IS NULL) AND DIM.edw_rec_end_dt ='9999-12-31'))
AND TGT.EDW_BATCH_ID > '20220306000000'
;

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.REFERRAL TGT
SET
        dim_loc_store_sk = coalesce (DIM.dim_loc_store_sk,-1)
FROM     PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF DIM
WHERE
        TGT.loc_store_sk = DIM.loc_store_sk
        AND UPPER(TGT.src_sys_cd) = 'SM'
        AND TGT.referral_src_create_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
        AND TGT.EDW_BATCH_ID > '20220220000000';
		
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.REFERRAL TGT
set 
payr_sk = coalesce (DIM.payr_sk,-1),
payr_chng_sk = coalesce (DIM.payr_chng_sk,-1)
FROM    PROD_PHARMACY_HEALTHCARE.PLAN.PAYER DIM where   
 DIM.payr_sk is not null
AND  TGT.src_sys_cd = 'SM'
AND TGT.payr_src_id = DIM.payr_src_id
AND TGT.src_sys_cd = DIM.src_sys_cd
AND  
(((TGT.referral_src_create_dt IS NOT NULL) AND  (TGT.referral_src_create_dt between DIM.edw_rec_begin_dt and DIM.edw_rec_end_dt))
 OR
((TGT.referral_src_create_dt IS NULL) AND DIM.edw_rec_end_dt ='9999-12-31')) AND TGT.EDW_BATCH_ID > '20211206000000';

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.REFERRAL TGT
set 
rfrng_provider_sk = coalesce (DIM.hc_provider_sk,-1),
rfrng_provider_chng_sk = coalesce (DIM.hc_provider_chng_sk,-1)
FROM    PROD_PHARMACY_HEALTHCARE.PRESCRIBER.HEALTHCARE_PROVIDER DIM where   
    ((TGT.rfrng_provider_sk = -1 AND DIM.hc_provider_sk is not null)
 OR (TGT.rfrng_provider_chng_sk = -1 AND DIM.hc_provider_chng_sk is not null))
AND  TGT.src_sys_cd = 'SM'
AND TGT.rfrng_provider_src_id = DIM.hc_provider_src_id
AND TGT.src_sys_cd = DIM.src_sys_cd
AND 
(((TGT.referral_src_create_dt IS NOT NULL) AND  (TGT.referral_src_create_dt between DIM.edw_rec_begin_dt and DIM.edw_rec_end_dt))
 OR
((TGT.referral_src_create_dt IS NULL) AND DIM.edw_rec_end_dt ='9999-12-31')) AND TGT.EDW_BATCH_ID > '20220313000000'
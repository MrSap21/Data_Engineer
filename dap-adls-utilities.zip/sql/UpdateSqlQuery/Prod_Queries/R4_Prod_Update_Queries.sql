-- POD 1 Starts --
-- 1.1 --

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_FILL_WRKFLOW_USER STG
SET
STG.loc_store_sk = DIM.loc_store_sk
FROM
PROD_MASTER_DATA.LOCATION.LOCATION_STORE DIM
WHERE
STG.store_nbr = DIM.store_nbr
AND STG.src_sys_cd = 'SM'
AND STG.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt AND STG.edw_batch_id > '20220220000000';

-- 1.2 --

UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_FILL_WRKFLOW_USER STG
SET
STG.dim_loc_store_sk = DIM.dim_loc_store_sk
FROM
PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF DIM
WHERE
STG.loc_store_sk = DIM.loc_store_sk
AND STG.src_sys_cd = 'SM'
AND STG.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt AND stg.edw_batch_id > '20220220000000';

-- POD 1 Ends --


--POD 3 START --
--3.1--
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.DRUG_CLAIM_REJECT TGT
SET
LOC_STORE_SK = DIM.LOC_STORE_SK
FROM PROD_MASTER_DATA.LOCATION.LOCATION_STORE DIM
WHERE TGT.STORE_NBR=DIM.store_nbr
AND UPPER(TGT.src_sys_cd) = 'SM'
AND   DIM.edw_rec_end_dt=CAST('9999-12-31' AS Date)
AND DIM.loc_store_sk!=-1
AND TGT.EDW_BATCH_ID > '20220220000000' ;
--3.2--
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.DRUG_CLAIM_REJECT TGT
SET
        dim_loc_store_sk = DIM.dim_loc_store_sk
FROM     PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF DIM
WHERE
        TGT.loc_store_sk = DIM.loc_store_sk
        AND UPPER(TGT.src_sys_cd) = 'SM'
        AND TGT.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
        AND TGT.EDW_BATCH_ID > '20220220000000';	
--3.3--
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.DRUG_CLAIM_REJECT TGT
SET
insure_plan_chng_sk = dim.insure_plan_chng_sk,
insure_plan_sk = dim.insure_plan_sk
FROM PROD_PHARMACY_HEALTHCARE.PLAN.INSURANCE_PLAN dim
WHERE
TGT.insure_plan_src_id = dim.insure_plan_src_id
AND TGT.src_sys_cd = dim.src_sys_cd
AND UPPER(TGT.src_sys_cd) = 'SM'
AND TGT.fill_enter_dt BETWEEN dim.edw_rec_begin_dt AND dim.edw_rec_end_dt
AND TGT.EDW_BATCH_ID > '20220313000000';
--3.4--
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_TRANSFER_LOG TGT
SET
LOC_STORE_SK = DIM.LOC_STORE_SK
,xfer_to_store_sk = DIM.loc_store_sk
,xfer_fm_store_sk = DIM.loc_store_sk
FROM PROD_MASTER_DATA.LOCATION.LOCATION_STORE DIM
WHERE TGT.STORE_NBR=DIM.store_nbr
AND UPPER(TGT.src_sys_cd) = 'SM'
AND   DIM.edw_rec_end_dt=CAST('9999-12-31' AS Date)
AND DIM.loc_store_sk!=-1
AND TGT.EDW_BATCH_ID > '20220220000000';
--3.5--
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_TRANSFER_LOG TGT
SET
        dim_loc_store_sk = DIM.dim_loc_store_sk
       , dim_xfer_fm_store_sk = DIM.dim_loc_store_sk  
       ,dim_xfer_to_store_sk=DIM.dim_loc_store_sk
FROM     PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF DIM
WHERE
        TGT.loc_store_sk = DIM.loc_store_sk
        AND UPPER(TGT.src_sys_cd) = 'SM'
        AND TGT.RX_CREATE_DT BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
        AND TGT.EDW_BATCH_ID > '20220220000000';
--3.6--
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_ORDER_DETAIL TGT
SET
LOC_STORE_SK = DIM.LOC_STORE_SK
FROM PROD_MASTER_DATA.LOCATION.LOCATION_STORE DIM
WHERE TGT.STORE_NBR=DIM.store_nbr
AND UPPER(TGT.src_sys_cd) = 'SM'
AND   DIM.edw_rec_end_dt=CAST('9999-12-31' AS Date)
AND DIM.loc_store_sk!=-1
AND TGT.EDW_BATCH_ID > '20220220000000';
--3.7--
UPDATE PROD_PHARMACY_HEALTHCARE.PATIENT_SERVICES.PRESCRIPTION_ORDER_DETAIL TGT
SET
        dim_loc_store_sk =  DIM.dim_loc_store_sk
FROM     PROD_MASTER_DATA.LOCATION.DIM_LOCATION_STORE_XREF DIM
WHERE
        TGT.loc_store_sk = DIM.loc_store_sk
        AND UPPER(TGT.src_sys_cd) = 'SM'
        AND TGT.ord_start_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
        AND TGT.EDW_BATCH_ID > '20220220000000';
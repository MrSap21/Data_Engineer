UPDATE $db_param_pharmacy.PATIENT.PATIENT_SPECIFIC_INFORMATION tgt 
SET pat_pcp_addr_sk = hpa.hc_provider_addr_sk 
FROM   $db_param_pharmacy.PRESCRIBER.HEALTHCARE_PROVIDER_ADDRESS hpa
WHERE 
tgt.pat_pcp_addr_src_id= hpa.hc_provider_addr_src_id
AND tgt.pat_pcp_src_id= hpa.hc_provider_src_id
AND hpa.edw_rec_end_dt= CAST('9999-12-31' AS DATE)
AND tgt.pat_pcp_addr_sk!=-1
AND hpa.hc_provider_addr_sk!=-1
AND tgt.EDW_BATCH_ID > '$edw_batch_id';
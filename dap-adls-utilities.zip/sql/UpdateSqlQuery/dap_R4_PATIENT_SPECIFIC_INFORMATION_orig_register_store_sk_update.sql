UPDATE $db_param_pharmacy.PATIENT.PATIENT_SPECIFIC_INFORMATION TGT 
SET 
orig_register_store_sk = orgregstr.loc_store_sk
FROM  $db_param_master_data.LOCATION.LOCATION_STORE orgregstr
WHERE tgt.orig_register_store_nbr=orgregstr.store_nbr
and tgt.orig_register_store_sk!=-1
and orgregstr.loc_store_sk!=-1
AND orgregstr.edw_rec_end_dt= CAST('9999-12-31' AS Date)
AND tgt.EDW_BATCH_ID > '$edw_batch_id';
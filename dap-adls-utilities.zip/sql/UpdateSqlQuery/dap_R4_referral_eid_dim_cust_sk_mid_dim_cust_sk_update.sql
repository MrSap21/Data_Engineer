"UPDATE $db_param_pharmacy.PATIENT_SERVICES.REFERRAL TGT
set 
eid_dim_cust_sk =  coalesce(DIM.eid_dim_cust_sk,-1),
mid_dim_cust_sk =  coalesce(DIM.mid_dim_cust_sk,-1)
FROM    $db_param_master_data.CUSTOMER.DIM_CUSTOMER_XREF DIM where   
    ((DIM.eid_dim_cust_sk is not null)
OR ( DIM.mid_dim_cust_sk is not null))
AND  TGT.src_sys_cd = 'SM'
AND  TGT.src_sys_cd = DIM.src_sys_cd
AND  TGT.cust_sk = DIM.cust_sk 
AND (((TGT.referral_src_create_dt IS NOT NULL) AND  (TGT.referral_src_create_dt between DIM.edw_rec_begin_dt and DIM.edw_rec_end_dt))
 OR
((TGT.referral_src_create_dt IS NULL) AND DIM.edw_rec_end_dt ='9999-12-31'))
AND DIM.EDW_BATCH_ID > $edw_batch_id
;"
---$edw_batch_id='20220220'
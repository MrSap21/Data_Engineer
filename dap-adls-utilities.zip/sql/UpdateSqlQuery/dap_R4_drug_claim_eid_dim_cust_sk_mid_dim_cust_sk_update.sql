"UPDATE $db_param_pharmacy.PATIENT_SERVICES.DRUG_CLAIM TGT
SET
        eid_dim_cust_sk = CX.eid_dim_cust_sk,
        mid_dim_cust_sk = CX.mid_dim_cust_sk,
        cust_sk = CX.cust_sk
FROM    $db_param_master_data.CUSTOMER.dim_customer_xref CX
WHERE
        TGT.pat_src_id=CX.cust_src_id 
        AND TGT.src_sys_cd=CX.src_sys_cd 
        AND upper(TGT.src_sys_cd) = 'SM'
        AND upper(CX.src_sys_cd)='SM'
        AND TGT.composite_type_cd= CX.composite_type_cd
        AND TGT.msg_type_cd= CX.msg_type_cd 
        AND TGT.fill_enter_dt BETWEEN CX.edw_rec_begin_dt AND CX.edw_rec_end_dt
		AND TGT.EDW_BATCH_ID > $edw_batch_id;
"
----$edw_batch_id='20220224'
update $db_param_master_data.CUSTOMER.CUSTOMER_PREFERENCE_DETAIL stg
set cust_sk = tgt_sk.cust_sk
from 
$db_param_master_data.CUSTOMER.CUSTOMER tgt_sk
where stg.cust_src_id = tgt_sk.cust_src_id
and stg.composite_type_cd = tgt_sk.composite_type_cd
and stg.msg_type_cd = tgt_sk.msg_type_cd
and tgt_sk.edw_rec_end_dt = '9999-12-31'
and stg.src_sys_cd = 'opv' and tgt_sk.src_sys_cd = 'opv' AND stg.edw_batch_id > '';
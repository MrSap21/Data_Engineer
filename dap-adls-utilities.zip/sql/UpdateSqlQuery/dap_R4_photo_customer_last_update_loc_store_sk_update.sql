UPDATE   $db_param_master_data.CUSTOMER.PHOTO_CUSTOMER stg
SET  last_update_loc_store_sk = idl.loc_store_sk
FROM    $db_param_master_data.LOCATION.location_store idl
WHERE stg.last_update_store_nbr = idl.store_nbr
AND   idl.edw_rec_end_dt = '9999-12-31'
AND   stg.src_sys_cd = 'PC'
AND idl.EDW_BATCH_ID > $edw_batch_id
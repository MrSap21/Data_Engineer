"UPDATE $db_param_pharmacy.$db_param_pharmacy.PRESCRIPTION_ORDER_DETAIL TGT
SET
LOC_STORE_SK = DIM.LOC_STORE_SK
FROM $db_param_master_data.LOCATION.LOCATION_STORE DIM
WHERE TGT.STORE_NBR=DIM.store_nbr
AND UPPER(TGT.src_sys_cd) = 'SM'
AND   DIM.edw_rec_end_dt=CAST('9999-12-31' AS Date) 
AND DIM.loc_store_sk!=-1 
AND TGT.EDW_BATCH_ID > $edw_batch_id;"
---$edw_batch_id='20220220'

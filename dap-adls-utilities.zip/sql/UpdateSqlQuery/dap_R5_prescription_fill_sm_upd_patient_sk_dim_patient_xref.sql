UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET
        dim_fill_pat_cust_sk = PX.dim_pat_cust_sk
FROM    $db_param_misc.PROCESS.DIM_PATIENT_XREF  PX
WHERE
        tgt.fill_cust_sk = PX.cust_sk        
        AND tgt.src_sys_cd = 'SM' 
        AND tgt.fill_enter_dt BETWEEN PX.edw_rec_begin_dt AND PX.edw_rec_end_dt
        AND tgt.EDW_BATCH_ID > '$edw_batch_id';
;

 


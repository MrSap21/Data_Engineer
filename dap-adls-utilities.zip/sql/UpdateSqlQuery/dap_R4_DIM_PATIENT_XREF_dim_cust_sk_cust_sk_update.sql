update $db_param_misc.PROCESS.DIM_PATIENT_XREF tgt 
set cust_sk = cust.cust_sk,
dim_cust_sk = cust.dim_cust_sk
FROM $db_param_pharmacy.PATIENT.PATIENT_SPECIFIC_INFORMATION pat 
INNER JOIN $db_param_master_data.CUSTOMER.DIM_CUSTOMER_XREF cust 
ON pat.cust_sk=cust.cust_sk
where 
pat.src_sys_cd = cust.src_sys_cd
AND pat.pat_chng_sk=tgt.pat_chng_sk 
AND cust.edw_rec_end_dt=CAST('9999-12-31' AS DATE)
AND pat.edw_rec_end_dt=CAST('9999-12-31' AS DATE)
AND tgt.EDW_BATCH_ID > '$edw_batch_id';
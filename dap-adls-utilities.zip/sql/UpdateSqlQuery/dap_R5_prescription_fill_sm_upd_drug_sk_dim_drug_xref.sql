UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET
	dim_drug_dspn_sk = DIM.dim_drug_sk,
        drug_dspn_sk = DIM.drug_sk 
FROM      $db_param_misc.PROCESS.DIM_DRUG_XREF DIM
WHERE
        tgt.drug_dspn_id = dim.drug_id  
        AND tgt.src_sys_cd=dim.src_sys_cd   
        AND tgt.src_sys_cd='SM'         
        AND tgt.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
;

UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_FILL_SM tgt
SET
	dim_drug_sk = DIM.dim_drug_sk, 
        drug_sk = DIM.drug_sk    
FROM    $db_param_misc.PROCESS.DIM_DRUG_XREF  DIM
WHERE
        tgt.drug_id = dim.drug_id  
        AND tgt.src_sys_cd=dim.src_sys_cd   
        AND tgt.src_sys_cd= 'SM'         
        AND tgt.fill_enter_dt BETWEEN DIM.edw_rec_begin_dt AND DIM.edw_rec_end_dt
        AND tgt.EDW_BATCH_ID > '$edw_batch_id' 



"UPDATE $db_param_pharmacy.PATIENT_SERVICES.DRUG_CLAIM_REJECT TGT
SET
insure_plan_chng_sk = dim.insure_plan_chng_sk,
insure_plan_sk = dim.insure_plan_sk
FROM $db_param_pharmacy.PLAN.INSURANCE_PLAN dim
WHERE
TGT.insure_plan_src_id = dim.insure_plan_src_id
AND TGT.src_sys_cd = dim.src_sys_cd
AND UPPER(TGT.src_sys_cd) = 'SM'
AND TGT.fill_enter_dt BETWEEN dim.edw_rec_begin_dt AND dim.edw_rec_end_dt
AND TGT.EDW_BATCH_ID > $edw_batch_id
;"
----$edw_batch_id='20220220'
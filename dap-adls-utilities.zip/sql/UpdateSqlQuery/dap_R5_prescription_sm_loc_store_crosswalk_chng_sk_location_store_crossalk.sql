
UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	orig_store_crosswalk_chng_sk=LS.loc_store_crosswalk_chng_sk
FROM    $db_param_pharmacy.SPECIALTY.LOCATION_STORE_CROSSWALK LS

WHERE
        
TRIM(STG.orig_store_src_id) = TRIM(LS.loc_store_src_id)
and UPPER(STG.src_sys_cd) = 'SM' /*(NOT CASESPECIFIC)*/
and UPPER(LS.src_sys_cd) ='SM' /*(NOT CASESPECIFIC)*/
and STG.rx_create_dt BETWEEN LS.edw_rec_begin_dt AND LS.edw_rec_end_dt
AND STG.EDW_BATCH_ID > '$edw_batch_id';





UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
	store_crosswalk_chng_sk=LS.loc_store_crosswalk_chng_sk 
FROM    $db_param_pharmacy.SPECIALTY.LOCATION_STORE_CROSSWALK LS

WHERE

TRIM(STG.store_src_id)= TRIM(LS.loc_store_src_id)
and UPPER(STG.src_sys_cd) = 'SM' /*(NOT CASESPECIFIC)*/
and UPPER(LS.src_sys_cd)='SM' /*(NOT CASESPECIFIC)*/
and STG.rx_create_dt BETWEEN LS.edw_rec_begin_dt AND LS.edw_rec_end_dt
AND STG.EDW_BATCH_ID > '$edw_batch_id';




UPDATE   $db_param_master_data.CUSTOMER.PHOTO_CUSTOMER stg
SET  cust_sk = idl.cust_sk
FROM     $db_param_master_data.CUSTOMER.customer idl
WHERE stg.photo_cust_id = idl.cust_src_id
AND   stg.src_sys_cd = idl.src_sys_cd
AND   stg.composite_type_cd = idl.composite_type_cd
AND   stg.msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = '9999-12-31'
AND   idl.src_sys_cd = 'PC'
AND   stg.src_sys_cd = 'PC'
AND idl.EDW_BATCH_ID > $edw_batch_id;

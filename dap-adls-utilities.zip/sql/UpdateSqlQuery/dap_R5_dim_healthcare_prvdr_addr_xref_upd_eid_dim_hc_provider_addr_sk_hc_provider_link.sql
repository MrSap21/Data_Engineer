
UPDATE  $db_param_misc.PROCESS.DIM_HEALTHCARE_PRVDR_ADDR_XREF tgt
SET eid_dim_hc_provider_addr_sk = tgt_sk.hc_provider_addr_eid_sk,
    hc_provider_eid = tgt_sk.hc_provider_eid,
    hc_provider_addr_eid = tgt_sk.hc_provider_addr_eid,
    hc_provider_eid_cur = tgt_sk.hc_provider_eid,
    hc_provider_addr_eid_cur = tgt_sk.hc_provider_addr_eid
FROM    $db_param_pharmacy.PRESCRIBER.HC_PROVIDER_LINK tgt_sk
WHERE tgt.hc_provider_src_id = tgt_sk.hc_provider_src_id
AND   tgt.hc_provider_addr_src_id = tgt_sk.hc_provider_addr_src_id
AND   UPPER(tgt.src_sys_cd) = UPPER(tgt_sk.src_sys_cd) /*(NOT CASESPECIFIC)*/
AND   tgt_sk.edw_rec_end_dt = CAST('9999-12-31' AS DATE)
AND   tgt_sk.src_sys_cd='IC';
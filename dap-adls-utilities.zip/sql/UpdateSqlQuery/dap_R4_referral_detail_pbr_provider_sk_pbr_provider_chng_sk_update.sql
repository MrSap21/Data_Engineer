"UPDATE $db_param_pharmacy.PATIENT_SERVICES.REFERRAL_DETAIL TGT1
set 
pbr_provider_sk = coalesce (tgt.hc_provider_sk,-1),
pbr_provider_chng_sk = coalesce (tgt.hc_provider_chng_sk,-1)
FROM    $db_param_pharmacy.PRESCRIBER.HEALTHCARE_PROVIDER tgt where   
 TGT1.src_sys_cd = 'SM'
AND TGT1.pbr_provider_src_id = tgt.hc_provider_src_id
AND TGT1.src_sys_cd = tgt.src_sys_cd
AND 
(((TGT1.referral_src_create_dt IS NOT NULL) AND  (TGT1.referral_src_create_dt between tgt.edw_rec_begin_dt and tgt.edw_rec_end_dt))
 OR
((TGT1.referral_src_create_dt IS NULL) AND tgt.edw_rec_end_dt ='9999-12-31'))
AND TGT1.EDW_BATCH_ID > $edw_batch_id;"
----$edw_batch_id='20220220'
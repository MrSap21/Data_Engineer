


UPDATE $db_param_pharmacy.PATIENT_SERVICES.PRESCRIPTION_SM STG
SET
        dim_pat_cust_sk = PX.dim_pat_cust_sk
FROM    $db_param_misc.PROCESS.DIM_PATIENT_XREF PX
WHERE
        STG.cust_sk=PX.cust_sk
        AND STG.src_sys_cd = 'SM' 
        AND STG.rx_create_dt BETWEEN PX.edw_rec_begin_dt AND PX.edw_rec_end_dt
		AND STG.EDW_BATCH_ID > '$edw_batch_id';




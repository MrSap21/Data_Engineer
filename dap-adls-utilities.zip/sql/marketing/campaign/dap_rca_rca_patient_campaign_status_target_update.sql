update $pTGT_DB_NAME.$pTDDBName.$pTargetTable tgt
from $pSTG_DB_NAME.$pTDStageDB.$pSTG_TABLE_NAME stg
SET     tgt.campgn_id = stg.campgn_id,
        tgt.stat_cd = stg.stat_cd,
        tgt.src_create_dttm = stg.src_create_dttm,
        tgt.src_update_dttm = stg.src_update_dttm,
        tgt.edw_batch_id = stg.edw_batch_id
WHERE tgt.merged_fm_pat_id=stg.merged_fm_pat_id
and tgt.campgn_id = stg.campgn_id
and edw_dml_ind='U' and (tgt.stat_cd != stg.stat_cd or tgt.src_create_dttm != stg.src_create_dttm or tgt.src_update_dttm != stg.src_update_dttm)

UPDATE $pTGT_DB_NAME.${pTDDBName}.${pTargetTable} TGT

SET     service_id= stg.service_id,
        src_create_dt= stg.src_create_dt,
        src_create_tm= stg.src_create_tm,
        campgn_id= stg.campgn_id,
        campgn_component_seq_id= stg.campgn_component_seq_id,
        service_sign_ind= stg.service_sign_ind,
        service_sign_dttm = stg.service_sign_dttm,
        service_sign_party_cd = stg.service_sign_party_cd,
        create_str_nbr= stg.create_str_nbr,
        update_str_nbr= stg.update_str_nbr,
        service_app_cd = stg.service_app_cd,
        service_recommend_pat_ind = stg.service_recommend_pat_ind,
        src_create_emp_id = stg.src_create_emp_id,
        src_update_emp_id = stg.src_update_emp_id,
        src_update_dttm = stg.src_update_dttm,
        edw_batch_id = stg.edw_batch_id
from $pSTG_DB_NAME.${pTDStageDB}.${pTargetTable}_ML_STG stg
WHERE TGT.merged_fm_pat_id=stg.merged_fm_pat_id
and     TGT.service_id=stg.service_id
and     TGT.src_create_dt=stg.src_create_dt
and     TGT.src_create_tm=stg.src_create_tm
and     stg.edw_dml_ind='U'
and		(TGT.campgn_id!= stg.campgn_id or TGT.campgn_component_seq_id!= stg.campgn_component_seq_id or
		 TGT.service_sign_ind!= stg.service_sign_ind or TGT.service_sign_dttm!= stg.service_sign_dttm or
		 TGT.service_sign_party_cd!= stg.service_sign_party_cd or TGT.create_str_nbr!= stg.create_str_nbr or
		 TGT.update_str_nbr!= stg.update_str_nbr or TGT.service_app_cd!= stg.service_app_cd or
		 TGT.service_recommend_pat_ind!= stg.service_recommend_pat_ind or TGT.src_create_emp_id!= stg.src_create_emp_id or
		 TGT.src_update_emp_id!= stg.src_update_emp_id or TGT.src_update_dttm!= stg.src_update_dttm );
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM

COMMIT;


INSERT INTO $pTGT_DB_NAME.${pTDDBName}.${pTargetTable}
SELECT  merged_fm_pat_id,
        service_id,
        src_create_dt,
        src_create_tm,
        pat_id,
        campgn_id,
        campgn_component_seq_id,
        service_sign_ind,
        service_sign_dttm,
        service_sign_party_cd,
        create_str_nbr,
        update_str_nbr,
        service_app_cd,
        service_recommend_pat_ind,
        src_create_emp_id,
        src_update_emp_id,
        src_update_dttm,
        edw_create_dttm,
        edw_batch_id
FROM $pSTG_DB_NAME.${pTDStageDB}.${pTargetTable}_ML_STG 
where  $pSTG_DB_NAME.${pTDStageDB}.${pTargetTable}_ML_STG.edw_dml_ind='I';

COMMIT;


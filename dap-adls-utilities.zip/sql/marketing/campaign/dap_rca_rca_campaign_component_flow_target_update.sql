UPDATE ${pTGT_DB_NAME}.${pTDDBName}.$PTGT_TABLE_NAME tgt
SET campgn_component_flow_id= tmp_tbl.campgn_component_flow_id,
        campgn_component_seq_id= tmp_tbl.campgn_component_seq_id,
        component_seq_after_id= tmp_tbl.component_seq_after_id,
        component_outcome_optr= tmp_tbl.component_outcome_optr,
        component_outcome_rslt_val= tmp_tbl.component_outcome_rslt_val,
        edw_batch_id= tmp_tbl.edw_batch_id 
FROM ${pTGT_DB_NAME}.${pTDDBName}.$PTGT_TABLE_NAME_TMP tmp_tbl		
where tgt.campgn_component_flow_id = tmp_tbl.campgn_component_flow_id
AND ( tgt.campgn_component_seq_id != tmp_tbl.campgn_component_seq_id or tgt.component_seq_after_id != tmp_tbl.component_seq_after_id or tgt.component_outcome_optr != tmp_tbl.component_outcome_optr or tgt.component_outcome_rslt_val != tmp_tbl.component_outcome_rslt_val );

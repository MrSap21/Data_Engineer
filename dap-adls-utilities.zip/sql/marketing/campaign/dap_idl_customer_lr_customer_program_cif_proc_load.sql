INSERT INTO $pSTG_DB_NAME.$pTD_DB_CIF.$pPROC_TABLE_NAME
(
 cust_prog_chng_sk             
,cust_sk                       
,prog_cd                       
,prog_id                       
,prog_stat_cd                  
,stat_eff_dt                   
,stat_end_dt                   
,src_sys_id                    
,src_sys_cd                    
,composite_type_cd             
,msg_type_cd                   
,edw_rec_begin_dt              
,prog_start_dt                 
,prog_end_dt                   
,prog_enrl_channel_cd          
,security_class_cd             
,vndr_ref_id                   
,hipaa_stat_cd                 
,hipaa_form_name
,unsubscribe_mbr_eml_addr               
,edw_rec_end_dt                
,edw_create_dttm               
,edw_update_dttm               
,edw_batch_id                  
)
SELECT 
a.cust_prog_chng_sk             
,a.cust_sk                       
,a.prog_cd                       
,a.prog_id                       
,a.prog_stat_cd                  
,a.stat_eff_dt                   
,a.stat_end_dt                   
,a.src_sys_id                    
,a.src_sys_cd                    
,a.composite_type_cd             
,a.msg_type_cd                   
,a.edw_rec_begin_dt              
,a.prog_start_dt                 
,a.prog_end_dt                   
,a.prog_enrl_channel_cd          
,a.security_class_cd             
,a.vndr_ref_id                   
,a.hipaa_stat_cd                 
,a.hipaa_form_name
,a.unsubscribe_mbr_eml_addr               
,a.edw_rec_end_dt                
,a.edw_create_dttm               
,a.edw_update_dttm               
,a.edw_batch_id 
FROM  $pTGT_DB_NAME.$pTD_VIEW_DB_IDL.$pCUST_TABLE_NAME a
WHERE EXISTS
(
   SELECT 1
   FROM  $pSTG_DB_NAME.$pTD_DB_CIF.$pTABLE_NAME_1 b
   WHERE a.src_sys_id = b.src_sys_id
     AND a.src_sys_cd = b.src_sys_cd
     AND a.composite_type_cd = b.composite_type_cd
     AND a.msg_type_cd = b.msg_type_cd
     AND a.prog_cd = b.prog_cd
     )
AND a.edw_rec_end_dt = $pTD_EDW_END_DATE
AND a.src_sys_cd = '$pSRC_SYS_CD';


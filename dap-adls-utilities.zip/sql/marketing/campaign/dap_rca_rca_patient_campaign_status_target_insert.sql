INSERT INTO $pTGT_DB_NAME.$pTDDBName.$pTargetTable
SELECT  merged_fm_pat_id,
        campgn_id,
        pat_id,
        pat_campgn_min_start_dt,
        stat_cd,
        src_create_dttm,
        src_update_dttm,
        edw_create_dttm,
        edw_batch_id
FROM $pSTG_DB_NAME.$pTDStageDB.$pSTG_TABLE_NAME
where edw_dml_ind='I'
begin transaction;
-- TRANS_CONTROL - Convert BT to BEGIN TRANSACTION

-- LOCK TABLE $pTD_DB_CIF.stg_customer_program FOR ACCESS

UPDATE $pTGT_DB_NAME.$pTD_DB_IDL.$pTGT_TABLE_TABLE tgt

SET   stat_end_dt = stg.stat_end_dt
, prog_end_dt = stg.prog_end_dt
, edw_rec_end_dt = stg.edw_rec_end_dt
, edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
, edw_batch_id = $pEDW_BATCH_ID
FROM    $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME stg WHERE tgt.cust_prog_chng_sk = stg.cust_prog_chng_sk
AND stg.cust_sk <> -1
AND   stg.src_sys_cd = '$pSRC_SYS_CD'
;
-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
-- LOCKING - comment out locking clause
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>


-- LOCK TABLE $pTD_DB_CIF.stg_customer_program FOR ACCESS

INSERT INTO $pTGT_DB_NAME.$pTD_DB_IDL.$pTGT_TABLE_TABLE
(
       cust_prog_chng_sk             
,cust_sk                       
,prog_cd                       
,prog_id                       
,prog_stat_cd                  
,stat_eff_dt                   
,stat_end_dt                   
,src_sys_id                    
,src_sys_cd                    
,composite_type_cd             
,msg_type_cd                   
,edw_rec_begin_dt              
,prog_start_dt                 
,prog_end_dt                   
,prog_enrl_channel_cd          
,security_class_cd             
,vndr_ref_id                   
,hipaa_stat_cd                 
,hipaa_form_name
,unsubscribe_mbr_eml_addr               
,edw_rec_end_dt                
,edw_create_dttm               
,edw_update_dttm               
,edw_batch_id                  
)
SELECT
stg.cust_prog_chng_sk             
,stg.cust_sk                       
,stg.prog_cd                       
,stg.prog_id                       
,stg.prog_stat_cd                  
,stg.stat_eff_dt                   
,stg.stat_end_dt                   
,stg.src_sys_id                    
,stg.src_sys_cd                    
,stg.composite_type_cd             
,stg.msg_type_cd                   
,stg.edw_rec_begin_dt              
,stg.prog_start_dt                 
,stg.prog_end_dt                   
,stg.prog_enrl_channel_cd          
,stg.security_class_cd             
,stg.vndr_ref_id                   
,stg.hipaa_stat_cd                 
,stg.hipaa_form_name
,stg.unsubscribe_mbr_eml_addr               
,stg.edw_rec_end_dt                
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
,$pEDW_BATCH_ID as edw_batch_id
FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME stg
WHERE NOT EXISTS
(
   SELECT 1
   FROM $pTGT_DB_NAME.$pTD_VIEW_DB_IDL.$pTGT_TABLE_TABLE tgt
   WHERE tgt.cust_prog_chng_sk = stg.cust_prog_chng_sk
   AND   tgt.cust_sk = stg.cust_sk
)
AND stg.cust_prog_chng_sk IS NOT NULL
AND stg.src_sys_cd = '$pSRC_SYS_CD';
-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
-- LOCKING - comment out locking clause
-- TRANS_CONTROL - Convert END TRANSACTION/ET to COMMIT
commit;


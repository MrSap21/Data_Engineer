UPDATE $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME TGT
SET 
rca_cd_id=TMP.rca_cd_id,
catg_cd=TMP.catg_cd,
catg_desc=TMP.catg_desc,
cd_desc=TMP.cd_desc,
src_create_dttm=TMP.src_create_dttm,
src_update_dttm=TMP.src_update_dttm,
edw_batch_id=TMP.edw_batch_id
FROM $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP TMP
where TGT.rca_cd_id = TMP.rca_cd_id;

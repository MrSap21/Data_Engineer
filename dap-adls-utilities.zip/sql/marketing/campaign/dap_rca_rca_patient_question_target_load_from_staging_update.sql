UPDATE ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}
SET     campgn_id = stg.campgn_id,
        campgn_component_seq_id = stg.campgn_component_seq_id,
        ans_rslt = stg.ans_rslt,
        ans_party_cd = stg.ans_party_cd,
        create_str_nbr = stg.create_str_nbr,
        update_str_nbr = stg.update_str_nbr,
        rca_ses_cd = stg.rca_ses_cd,
        src_create_emp_id = stg.src_create_emp_id ,
        src_update_emp_id = stg.src_update_emp_id,
        src_update_dttm = stg.src_update_dttm,
        edw_batch_id = stg.edw_batch_id
from ${pSTG_DB_NAME}.${pTDStageDB}.${pTargetTable}_ML_STG stg
WHERE ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.merged_fm_pat_id=stg.merged_fm_pat_id
and ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.qstn_id= stg.qstn_id
and ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.src_create_dt = stg.src_create_dt
and ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.src_create_tm = stg.src_create_tm
and ( ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.campgn_id != stg.campgn_id 
or ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.campgn_component_seq_id != stg.campgn_component_seq_id
or ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.ans_rslt != stg.ans_rslt
or ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.ans_party_cd != stg.ans_party_cd
or ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.create_str_nbr != stg.create_str_nbr
or ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.update_str_nbr != stg.update_str_nbr
or ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.rca_ses_cd != stg.rca_ses_cd
or ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.src_create_emp_id != stg.src_create_emp_id
or ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.src_update_emp_id != stg.src_update_emp_id
or ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}.src_update_dttm != stg.src_update_dttm )
and edw_dml_ind='U';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM

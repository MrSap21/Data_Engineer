/* SQL - PROC TABLE INSERT */
INSERT INTO
	${pSTG_DATABASE_NAME}.$pTD_DB_CIF.proc_${pTABLE_NAME_1}_stg
SELECT
        idl.cust_sk,
        idl.segment_key_val,
        idl.prog_id,
        idl.prog_cd,
        idl.prog_start_dt,
        idl.loyalty_mbr_id,
        idl.src_sys_cd,
        idl.composite_type_cd,
        idl.msg_type_cd,
        idl.segment_key_val_desc,
        idl.security_class_cd,        
        idl.edw_create_dttm,
        idl.edw_update_dttm,
        idl.edw_batch_id
FROM
	${pMARKETING_DATABASE_NAME}.$pTD_VIEW_DB_IDL.${pTABLE_NAME_1} idl,
	${pSTG_DATABASE_NAME}.$pTD_DB_CIF.cif_${pTABLE_NAME_1}_stg cif
WHERE
	idl.loyalty_mbr_id = cif.loyalty_mbr_id
AND	idl.src_sys_cd = cif.src_sys_cd
AND	idl.composite_type_cd = cif.composite_type_cd
AND	idl.msg_type_cd = cif.msg_type_cd
AND     idl.prog_id = cif.prog_id
AND     idl.prog_cd = cif.prog_cd
AND     idl.segment_key_val_desc=cif.segment_key_val_desc
AND	cif.src_sys_cd = $pSRC_SYS_CD;

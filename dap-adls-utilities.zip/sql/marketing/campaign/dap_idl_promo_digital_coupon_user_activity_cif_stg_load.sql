begin transaction;
-- TRANS_CONTROL - Convert BT to BEGIN TRANSACTION

MERGE INTO $pSTG_DB_NAME.${pTD_DB_CIF}.$pSTG_TABLE_NAME2 AS stg
USING (Select * from $pSTG_DB_NAME.${pTD_DB_CIF}.$pSTG_TABLE_NAME1 ) AS cif   
     
ON
    stg.offer_cd = cif.offer_cd
    AND stg.loyalty_mbr_id = cif.loyalty_mbr_id

    WHEN MATCHED THEN
UPDATE
    SET
    coupon_clip_dttm = cif.coupon_clip_dttm ,    
    coupon_redmptn_dttm  = CASE WHEN stg.coupon_redmptn_dttm  IS NULL     AND 
                                 cif.coupon_redmptn_dttm  IS NOT NULL 
                            THEN cif.coupon_redmptn_dttm ELSE stg.coupon_redmptn_dttm END,
    rfn_value            = CASE WHEN stg.rfn_value            IS NULL     AND
                                 cif.rfn_value            IS NOT NULL
                            THEN cif.rfn_value ELSE stg.rfn_value           END,
    sales_txn_id         = CASE WHEN stg.sales_txn_id         IS NULL     AND
                                 cif.sales_txn_id         IS NOT NULL
                            THEN cif.sales_txn_id  ELSE stg.sales_txn_id       END,
    sales_txn_dt         = CASE WHEN stg.sales_txn_dt         IS NULL     AND
                                 cif.sales_txn_dt         IS NOT NULL
                            THEN cif.sales_txn_dt ELSE stg.sales_txn_dt        END,
    sales_txn_type       = CASE WHEN stg.sales_txn_type       IS NULL     AND
                                 cif.sales_txn_type       IS NOT NULL
                            THEN cif.sales_txn_type ELSE stg.sales_txn_type      END,
    sales_txn_src_sys_cd = CASE WHEN stg.sales_txn_src_sys_cd IS NULL     AND
                                 cif.sales_txn_src_sys_cd IS NOT NULL 
                            THEN cif.sales_txn_src_sys_cd ELSE stg.sales_txn_src_sys_cd END,
    sales_ord_src_type   = CASE WHEN stg.sales_ord_src_type   IS NULL     AND
                                 cif.sales_ord_src_type   IS NOT NULL 
                            THEN cif.sales_ord_src_type ELSE stg.sales_ord_src_type   END,
    coupon_actv_type_name = cif.coupon_actv_type_name,
    coupon_clip_channel_name = cif.coupon_clip_channel_name,
    edw_update_dttm = CURRENT_TIMESTAMP(0),
    edw_batch_id = ${pEDW_BATCH_ID}


WHEN NOT MATCHED THEN INSERT
(
offer_cd,
loyalty_cust_sk,
loyalty_mbr_id,
coupon_clip_dttm,
coupon_redmptn_dttm,
rfn_value,
sales_txn_id,
sales_txn_dt,
sales_txn_type,
sales_txn_src_sys_cd,
sales_ord_src_type,
coupon_actv_type_name,
coupon_clip_channel_name,
edw_create_dttm,
edw_update_dttm,
edw_batch_id

) VALUES
(
cif.offer_cd,
-1,
cif.loyalty_mbr_id,
cif.coupon_clip_dttm,
cif.coupon_redmptn_dttm,
cif.rfn_value,
cif.sales_txn_id,
cif.sales_txn_dt,
cif.sales_txn_type,
cif.sales_txn_src_sys_cd,
cif.sales_ord_src_type,
cif.coupon_actv_type_name,
cif.coupon_clip_channel_name,
current_TIMESTAMP(0),
current_TIMESTAMP(0),
${pEDW_BATCH_ID}
);


UPDATE $pSTG_DB_NAME.${pTD_DB_CIF}.$pSTG_TABLE_NAME2 stg
SET sales_txn_dt       = idl.sales_txn_dt,
       sales_ord_src_type = idl.sales_ord_src_type,
       sales_txn_type     = idl.sales_txn_type
FROM    (SELECT sales_txn_id, sales_txn_dt, src_sys_cd, sales_ord_src_type, sales_txn_type
          FROM $DB_RETAIL.${pTD_VIEW_DB_IDL}.SALES_TRANSACTION
         WHERE sales_txn_id IN (SELECT DISTINCT sales_txn_id
                                 FROM $pSTG_DB_NAME.${pTD_DB_CIF}.$pSTG_TABLE_NAME2  
                                 WHERE sales_txn_src_sys_cd = 'EC'
                                 AND sales_txn_id IS NOT NULL)
                                 AND src_sys_cd = 'EC' 
                                AND sales_ord_src_type='S' 
                                QUALIFY ROW_NUMBER() OVER(PARTITION BY sales_txn_id ORDER BY sales_txn_dt desc)=1) idl
   WHERE stg.sales_txn_id         = idl.sales_txn_id
   AND stg.sales_txn_src_sys_cd = idl.src_sys_cd
   AND stg.sales_txn_src_sys_cd = 'EC'
   AND idl.src_sys_cd           = 'EC'
;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
 
commit;
-- TRANS_CONTROL - Convert END TRANSACTION/ET to COMMIT

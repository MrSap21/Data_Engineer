Insert Into ${pDB_NAME_1}.${pTD_DB_CIF}.${pTABLE_NAME_1} 
select
offer_cd,
loyalty_mbr_id,
upc,
upc_qty,
loyalty_cust_sk
from
${pSTG_DB_NAME}.${pTD_DB_CIF}.${pSTG_TABLE_NAME}
where
loyalty_cust_sk <> -1
;

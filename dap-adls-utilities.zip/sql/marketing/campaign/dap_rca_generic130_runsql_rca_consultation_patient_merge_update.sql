update $pTGT_DB_NAME.${pTDDBName}.$pTGT_TABLE_NAME tgt
from ${pSTG_DB_NAME}.${pTDStageDB}.$pSTG_TABLE_NAME2 mpm1
set pat_id = mpm1.pat_id
where tgt.merged_fm_pat_id=mpm1.merged_fm_pat_id 
and tgt.pat_id <> mpm1.pat_id
and mpm1.edw_batch_id = (select max(mpm2.edw_batch_id)
from $pSTG_DB_NAME.${pTDStageDB}.$pSTG_TABLE_NAME2 mpm2
where mpm1.merged_fm_pat_id = mpm2.merged_fm_pat_id);

insert into ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE}
select service_id,
        seq_nbr,
        name,
        campgn_id,
        clinical_id,
         short_desc,
        full_desc,
        set_dirs,
        opt_in_ind,
        campgn_assign_ind ,
        src_create_dttm,
        src_update_dttm ,
        edw_create_dttm,
        edw_batch_id
FROM ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE_TMP} tmp_tbl
where tmp_tbl.service_id NOT IN (SELECT DISTINCT service_id FROM ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE});

DROP TABLE IF EXISTS ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE_TMP};
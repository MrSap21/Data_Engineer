UPDATE $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME TGT
SET campgn_id= TMP.campgn_id,
        campgn_relation_id= TMP.campgn_relation_id ,
        campgn_relation_type= TMP.campgn_relation_type,
        campgn_relation_optr= TMP.campgn_relation_optr,
        gap_wks= TMP.gap_wks, 
        src_create_dttm= TMP.src_create_dttm ,
        src_update_dttm= TMP.src_update_dttm ,
        edw_batch_id= TMP.edw_batch_id  
FROM $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP TMP
where TGT.campgn_id = TMP.campgn_id
and TGT.campgn_relation_id= TMP.campgn_relation_id
AND ( TGT.campgn_relation_type!= TMP.campgn_relation_type or TGT.campgn_relation_optr != TMP.campgn_relation_optr or TGT.gap_wks != TMP.gap_wks or TGT.src_create_dttm != TMP.src_create_dttm or TGT.src_update_dttm != TMP.src_update_dttm );
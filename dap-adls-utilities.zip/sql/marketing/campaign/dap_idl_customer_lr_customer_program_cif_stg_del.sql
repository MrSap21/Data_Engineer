-- LOCK TABLE $pTD_DB_CIF.$pTABLE_NAME_1 FOR ACCESS
-- LOCKING - comment out locking clause
DELETE FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME stg
WHERE stg.src_sys_cd = '$pSRC_SYS_CD'
AND ( 
        (stg.cust_sk <> -1)
	 OR (EXISTS
          (
             SELECT 1
             FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pTABLE_NAME_1 cif
             WHERE cif.src_sys_id = stg.src_sys_id
             AND   cif.src_sys_cd = stg.src_sys_cd
             AND   cif.composite_type_cd = stg.composite_type_cd
             AND   cif.msg_type_cd = stg.msg_type_cd
             AND   cif.prog_cd = stg.prog_cd
          )
         )
    );


/* SQL - UPDATE CUST_SK (FKEY) and DIM_LOCATION_STORE WITHIN STG BY JOINING TO CUSTOMER TABLE */

UPDATE ${pSTG_DATABASE_NAME}.$pTD_DB_CIF.${pTABLE_NAME_1} stg
SET 
	cust_sk = cust.cust_sk,
	edw_etl_step = 'FKEY'
FROM    (
	SELECT 
		cust_sk, 
		cust_src_id,
		src_sys_cd,
		composite_type_cd,
		msg_type_cd
	FROM
		${pMASTER_DATA_DB_NAME}.$pTD_VIEW_DB_IDL.customer
	WHERE
		src_sys_cd = $pSRC_SYS_CD AND
		composite_type_cd = 'M' AND
		msg_type_cd = '1' AND
		edw_rec_end_dt = $pTD_EDW_END_DATE
	) cust
WHERE
	stg.loyalty_mbr_id = cust.cust_src_id
AND	stg.src_sys_cd = cust.src_sys_cd
AND	stg.composite_type_cd = cust.composite_type_cd
AND	stg.msg_type_cd = cust.msg_type_cd
AND	stg.src_sys_cd = $pSRC_SYS_CD
AND	stg.cust_sk IS NULL
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>

;


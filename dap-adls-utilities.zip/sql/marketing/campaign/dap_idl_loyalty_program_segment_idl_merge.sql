/* SQL - UPSERT IDL TARGET FROM STG */
MERGE INTO ${pMARKETING_DATABASE_NAME}.$pTD_DB_IDL.${pTABLE_NAME_1} idl
USING  (select * from ${pSTG_DATABASE_NAME}.$pTD_DB_CIF.${pTABLE_NAME_1}_stg where cust_sk IS NOT NULL) as stg
ON idl.loyalty_mbr_id = stg.loyalty_mbr_id
AND idl.src_sys_cd = stg.src_sys_cd
AND idl.composite_type_cd = stg.composite_type_cd
AND idl.msg_type_cd = stg.msg_type_cd
AND idl.cust_sk = stg.cust_sk
AND idl.prog_id = stg.prog_id
AND idl.prog_cd = stg.prog_cd
AND idl.segment_key_val_desc=stg.segment_key_val_desc
WHEN MATCHED THEN
UPDATE SET
        segment_key_val = stg.segment_key_val,
        prog_id = stg.prog_id,
        prog_cd = stg.prog_cd,
        prog_start_dt = stg.prog_start_dt,        
        segment_key_val_desc = stg.segment_key_val_desc,
        security_class_cd = stg.security_class_cd,        
        edw_update_dttm = CURRENT_TIMESTAMP(0),
        edw_batch_id = stg.edw_batch_id

WHEN NOT MATCHED THEN

INSERT 
(
        cust_sk,
        segment_key_val,
        prog_id,
        prog_cd,
        prog_start_dt,
        loyalty_mbr_id,
        src_sys_cd,
        composite_type_cd,
        msg_type_cd,
        segment_key_val_desc,
        security_class_cd,
        edw_create_dttm,
        edw_update_dttm,
        edw_batch_id
)
VALUES 
(
        stg.cust_sk,
        stg.segment_key_val,
        stg.prog_id,
        stg.prog_cd,
        stg.prog_start_dt,
        stg.loyalty_mbr_id,
        stg.src_sys_cd,
        stg.composite_type_cd,
        stg.msg_type_cd,
        stg.segment_key_val_desc,
        stg.security_class_cd,
        CURRENT_TIMESTAMP(0),
        CURRENT_TIMESTAMP(0),
        stg.edw_batch_id
);
 

DELETE FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME2 stg
WHERE stg.loyalty_cust_sk <> -1;

begin transaction;
-- TRANS_CONTROL - Convert BT to BEGIN TRANSACTION
/* SQL - PROC TABLE TRUNCATE */
DELETE FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.proc_${pTABLE_NAME_1} WHERE src_sys_cd=$pSRC_SYS_CD;

/* SQL - STG TABLE TRUNCATE */
DELETE FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1} WHERE cust_sk IS NOT NULL AND src_sys_cd=$pSRC_SYS_CD;

/* SQL - DELETE RECS FROM STG WHERE EXISTS IN CIF */
delete from ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1} stg 
using ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.cif_${pTABLE_NAME_1} cif 
WHERE 
	stg.loyalty_mbr_id = cif.loyalty_mbr_id
AND	stg.src_sys_cd = cif.src_sys_cd
AND	stg.composite_type_cd = cif.composite_type_cd
AND	stg.msg_type_cd = cif.msg_type_cd
AND     stg.prog_id = cif.prog_id
AND     stg.prog_cd = cif.prog_cd
AND     stg.segment_key_val_desc=cif.segment_key_val_desc
AND	stg.src_sys_cd=$pSRC_SYS_CD;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
 
commit
-- TRANS_CONTROL - Convert END TRANSACTION/ET to COMMIT
;
-- LOCK TABLE $pTD_DB_CIF.proc_customer_program FOR ACCESS

-- LOCK TABLE $pTD_DB_CIF.$pTABLE_NAME_1 FOR ACCESS
-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
-- LOCKING - comment out locking clause
INSERT INTO $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME
( cust_prog_chng_sk             
,cust_sk                       
,prog_cd                       
,prog_id                       
,prog_stat_cd                  
,stat_eff_dt                   
,stat_end_dt                   
,src_sys_id                    
,src_sys_cd                    
,composite_type_cd             
,msg_type_cd                   
,edw_rec_begin_dt              
,prog_start_dt                 
,prog_end_dt                   
,prog_enrl_channel_cd          
,security_class_cd             
,vndr_ref_id                   
,hipaa_stat_cd                 
,hipaa_form_name
,unsubscribe_mbr_eml_addr               
,edw_rec_end_dt                
,edw_create_dttm               
,edw_update_dttm               
,edw_batch_id                  
,edw_etl_step                  
)
SELECT 
NULL as cust_prog_chng_sk
,-1 as cust_sk
,a.prog_cd                       
,a.prog_id                       
,a.prog_stat_cd                  
,a.stat_eff_dt                   
,a.stat_end_dt                   
,a.src_sys_id                    
,a.src_sys_cd                    
,a.composite_type_cd             
,a.msg_type_cd                   
,CASE WHEN (b.src_sys_id IS NULL  AND c.src_sys_id IS NULL)
       THEN $pTD_EDW_LOW_DATE
       ELSE $pTD_EDW_BATCH_DATE
       END as edw_rec_begin_dt              
,case when (a.prog_stat_cd = 'DISQUALIFIED') then a.prog_start_dt 
when (a.src_sys_id = b.src_sys_id and a.prog_stat_cd in ('NEWDLYRX','EXISTDLY','EXISTDLYRX','UNSUBSCRIBE') and b.prog_stat_cd <> 'DISQUALIFIED')then b.prog_start_dt 
when a.prog_start_dt  is not null then a.prog_start_dt else a.stat_eff_dt end as prog_start_dt
,a.prog_end_dt                   
,a.prog_enrl_channel_cd          
,a.security_class_cd             
,a.vndr_ref_id                   
,a.hipaa_stat_cd                 
,a.hipaa_form_name
,a.unsubscribe_mbr_eml_addr               
,$pTD_EDW_END_DATE as edw_rec_end_dt                
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm               
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm               
,$pEDW_BATCH_ID as edw_batch_id                  
,'CIF' as edw_etl_step                  
FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pTABLE_NAME_1 a
     LEFT OUTER JOIN $pSTG_DB_NAME.$pTD_DB_CIF.$pPROC_TABLE_NAME b
       ON  a.src_sys_id = b.src_sys_id
       AND a.src_sys_cd = b.src_sys_cd
       AND a.composite_type_cd = b.composite_type_cd
       AND a.msg_type_cd = b.msg_type_cd
       AND a.prog_cd = b.prog_cd
     LEFT OUTER JOIN $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME c
       ON  b.src_sys_id = c.src_sys_id
       AND b.src_sys_cd = c.src_sys_cd
       AND b.composite_type_cd = c.composite_type_cd
       AND b.msg_type_cd = c.msg_type_cd
       AND b.prog_cd = c.prog_cd
WHERE a.src_sys_id IS NOT NULL
AND   a.src_sys_cd IS NOT NULL
AND   a.composite_type_cd IS NOT NULL
AND   a.msg_type_cd IS NOT NULL
AND   a.prog_cd IS NOT NULL
AND   ((     c.src_sys_id IS NOT NULL
       )
       OR
       (     b.src_sys_id IS NULL
         AND c.src_sys_id IS NULL
      ));

 

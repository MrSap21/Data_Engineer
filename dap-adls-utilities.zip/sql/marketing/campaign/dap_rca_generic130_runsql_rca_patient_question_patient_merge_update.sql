UPDATE ${pTGT_DB_NAME}.${pTDDBName}.$pTargetTable tgt 
set pat_id = mpm1.pat_id
FROM  ${pSTG_DB_NAME}.${pTDStageDB}.$pSTG_TBL_NAME mpm1
where tgt.merged_fm_pat_id=mpm1.merged_fm_pat_id 
and tgt.pat_id <> mpm1.pat_id
and mpm1.edw_batch_id = (select max(mpm2.edw_batch_id)
from ${pSTG_DB_NAME}.${pTDStageDB}.$pSTG_TBL_NAME mpm2
where mpm1.merged_fm_pat_id = mpm2.merged_fm_pat_id);
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>

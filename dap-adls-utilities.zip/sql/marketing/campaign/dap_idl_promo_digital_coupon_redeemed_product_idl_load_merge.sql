MERGE INTO $pTGT_DB_NAME.$pTD_DB_IDL.$pTABLE_NAME_1 AS tgt	
USING (Select * from $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME where upc_prod_sk is not null and upc_prod_sk <> -1)  AS stg
ON
    stg.offer_cd = tgt.offer_cd
	AND stg.loyalty_cust_sk = tgt.loyalty_cust_sk
	AND stg.upc_prod_sk = tgt.upc_prod_sk
	WHEN MATCHED THEN
UPDATE
	SET
	edw_update_dttm = CURRENT_TIMESTAMP(0),
	edw_batch_id = ${pEDW_BATCH_ID}

WHEN NOT MATCHED THEN INSERT
(
offer_cd,
loyalty_cust_sk,
upc_prod_sk,
upc_qty,
loyalty_mbr_id,
upc,
prod_id_1,
prod_id_2,
prod_id_3,
prod_id_4,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
) VALUES
(
stg.offer_cd,
stg.loyalty_cust_sk,
stg.upc_prod_sk,
stg.upc_qty,
stg.loyalty_mbr_id,
stg.upc,
stg.prod_id_1,
stg.prod_id_2,
stg.prod_id_3,
stg.prod_id_4,
current_TIMESTAMP(0),
current_TIMESTAMP(0),
${pEDW_BATCH_ID}
)
;

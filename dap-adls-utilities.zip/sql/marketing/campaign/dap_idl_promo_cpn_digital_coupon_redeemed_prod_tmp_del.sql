DELETE FROM $pDB_NAME_1.$pTD_DB_CIF.$pTABLE_NAME_1 AS tmp
WHERE tmp.loyalty_cust_sk is not null
AND tmp.loyalty_cust_sk <> -1;

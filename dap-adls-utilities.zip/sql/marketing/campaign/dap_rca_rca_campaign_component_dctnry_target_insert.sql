insert into ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE} 
SELECT 
component_dctnry_id,
name,
component_dctnry_desc,
loc,
src_create_dttm,
edw_create_dttm,
edw_batch_id
FROM ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE_TMP} tmp_tbl
where tmp_tbl.component_dctnry_id NOT IN (SELECT DISTINCT component_dctnry_id FROM ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE});

DROP TABLE IF EXISTS ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE_TMP};
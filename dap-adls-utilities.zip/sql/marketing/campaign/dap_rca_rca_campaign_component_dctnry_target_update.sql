UPDATE ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE}  tgt
SET component_dctnry_id=tmp_tbl.component_dctnry_id,
        name=tmp_tbl.name,
        component_dctnry_desc=tmp_tbl.component_dctnry_desc,
        loc=tmp_tbl.loc,
        src_create_dttm=tmp_tbl.src_create_dttm,
        edw_batch_id=tmp_tbl.edw_batch_id
from ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE_TMP}  tmp_tbl		
where tgt.component_dctnry_id=tmp_tbl.component_dctnry_id;

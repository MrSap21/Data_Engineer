UPDATE ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE}  tgt
SET service_id = tmp_tbl.service_id ,
        seq_nbr = tmp_tbl.seq_nbr,
        name = tmp_tbl.name,
        campgn_id = tmp_tbl.campgn_id,
        clinical_id =  tmp_tbl.clinical_id,
         short_desc = tmp_tbl.short_desc,
        full_desc = tmp_tbl.full_desc,
        set_dirs =  tmp_tbl.set_dirs,
        opt_in_ind = tmp_tbl.opt_in_ind,
        campgn_assign_ind = tmp_tbl.campgn_assign_ind,
        src_create_dttm = tmp_tbl.src_create_dttm,
        src_update_dttm  = tmp_tbl.src_update_dttm,
        edw_batch_id = tmp_tbl.edw_batch_id
from ${pTGT_DB_NAME}.${pTDDBName}.${pTGT_TARGET_TABLE_TMP}  tmp_tbl		
where tgt.service_id =tmp_tbl.service_id and ( tgt.seq_nbr!= tmp_tbl.seq_nbr or
tgt.name!= tmp_tbl.name or
tgt.campgn_id!= tmp_tbl.campgn_id or
tgt.clinical_id!= tmp_tbl.clinical_id or
tgt.short_desc!= tmp_tbl.short_desc or
tgt.full_desc!= tmp_tbl.full_desc or
tgt.set_dirs!= tmp_tbl.set_dirs or
tgt.opt_in_ind!= tmp_tbl.opt_in_ind or
tgt.campgn_assign_ind!= tmp_tbl.campgn_assign_ind or
tgt.src_create_dttm!= tmp_tbl.src_create_dttm or
tgt.src_update_dttm!= tmp_tbl.src_update_dttm
)


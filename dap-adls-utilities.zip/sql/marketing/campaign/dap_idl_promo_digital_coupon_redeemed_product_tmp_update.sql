Update 
 ${pDB_NAME_1}.${pTD_DB_CIF}.${pTABLE_NAME_1} TMP_CPN
--${pTD_VIEW_DB_IDL}.dim_loyalty_customer_xref cust_xref
Set
loyalty_cust_sk = cust.cust_sk
FROM ${pVIEW_DB_NAME}.${pTD_VIEW_DB_IDL}.${pVIEW_TBL_NAME} cust
Where
cust.src_sys_cd = 'LR'
And cust.composite_type_cd = 'M'
And cust.msg_type_cd = '1'
And cust.edw_rec_end_dt = '9999-12-31'
And TMP_CPN.loyalty_mbr_id = cust.cust_src_id
--And cust.cust_sk = cust_xref.cust_sk
--And cust_xref.edw_rec_end_dt = '9999-12-31'
;

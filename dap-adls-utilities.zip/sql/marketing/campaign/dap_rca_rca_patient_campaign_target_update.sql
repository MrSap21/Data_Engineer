update $pTGT_DB_NAME.$pTDDBName.$pTargetTable tgt
from $pSTG_DB_NAME.$pTDStageDB.$pSTG_TABLE_NAME stg
SET  tgt.pat_exc_seq_id = stg.pat_exc_seq_id ,
         tgt.campgn_component_seq_id = stg.campgn_component_seq_id,
         tgt.campgn_id= stg.campgn_id,
         tgt.component_dctnry_id = stg.component_dctnry_id,
         tgt.pat_exc_dttm= stg.pat_exc_dttm,
         tgt.pat_exit_dttm= stg.pat_exit_dttm,
         tgt.pat_stat_ind= stg.pat_stat_ind,
         tgt.src_create_dttm= stg.src_create_dttm,
         tgt.pat_component_score= stg.pat_component_score,
         tgt.pat_enter_dttm= stg.pat_enter_dttm,
         tgt.edw_batch_id = stg.edw_batch_id
WHERE tgt.merged_fm_pat_id=stg.merged_fm_pat_id
and tgt.campgn_component_seq_id=stg.campgn_component_seq_id
and tgt.pat_exc_seq_id=stg.pat_exc_seq_id and (tgt.campgn_id!=stg.campgn_id or          
tgt.component_dctnry_id != stg.component_dctnry_id or
         tgt.pat_exc_dttm!= stg.pat_exc_dttm or
         tgt.pat_exit_dttm!= stg.pat_exit_dttm or
         tgt.pat_stat_ind!= stg.pat_stat_ind or
         tgt.src_create_dttm!= stg.src_create_dttm or
         tgt.pat_component_score!= stg.pat_component_score or
         tgt.pat_enter_dttm!= stg.pat_enter_dttm)
and edw_dml_ind='U' 
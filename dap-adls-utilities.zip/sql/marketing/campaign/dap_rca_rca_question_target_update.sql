UPDATE $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME TGT
SET 
qstn_id = TMP.qstn_id,
qstn_id_seq = TMP.qstn_id_seq,
txt = TMP.txt,
service_id = TMP.service_id,
priority_id = TMP.priority_id,
seq_cd = TMP.seq_cd,
ans_list = TMP.ans_list,
actv_ind = TMP.actv_ind,
parent_qstn_seq_cd = TMP.parent_qstn_seq_cd,
ans_weight = TMP.ans_weight,
app_cd = TMP.app_cd,
parent_qstn_condition = TMP.parent_qstn_condition,
parent_qstn_optr = TMP.parent_qstn_optr,
src_create_user_id = TMP.src_create_user_id,
src_create_dttm = TMP.src_create_dttm,
src_update_dttm = TMP.src_update_dttm,
edw_batch_id = TMP.edw_batch_id
FROM $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP TMP
where TGT.qstn_id = TMP.qstn_id;
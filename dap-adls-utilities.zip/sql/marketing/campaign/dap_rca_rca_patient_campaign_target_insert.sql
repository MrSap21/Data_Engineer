INSERT INTO $pTGT_DB_NAME.$pTDDBName.$pTargetTable
SELECT  merged_fm_pat_id,
        campgn_component_seq_id,
        pat_exc_seq_id,
        pat_id,
        campgn_id,
        pat_campgn_min_start_dt,
        component_dctnry_id,
        pat_exc_dttm,
        pat_exit_dttm,
        pat_stat_ind,
        src_create_dttm,
        pat_component_score,
        pat_enter_dttm,
        edw_create_dttm,
        edw_batch_id
FROM $pSTG_DB_NAME.$pTDStageDB.$pSTG_TABLE_NAME
where edw_dml_ind='I'
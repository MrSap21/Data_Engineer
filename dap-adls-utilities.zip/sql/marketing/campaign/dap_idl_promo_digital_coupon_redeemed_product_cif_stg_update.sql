UPDATE ${pSTG_DB_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1} stg
Set
upc_prod_sk =  prod.prod_sk,
prod_id_1 = prod.src_sys_prod_id_1,
prod_id_2 = prod.src_sys_prod_id_2,
prod_id_3 = prod.src_sys_prod_id_3,
prod_id_4 = prod.src_sys_prod_id_4
FROM  ${pVIEW_DB_NAME}.${pTD_VIEW_DB_IDL}.${pVIEW_TABLE} prod
Where
prod.upc_nbr = (CASE when stg.upc='NULL' then NULL else substr(stg.upc, 1, length(stg.upc) -1)  END)
and prod.edw_rec_end_dt = '9999-12-31'
and prod.src_sys_cd     = 'POS'
;
-- FUN_CHAR_LENGTH - Convert CHAR_LENGTH(), CHARACTER_LENGTH(), CHARACTERS(), CHARACTER(), and CHAR() to LENGTH()
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>


UPDATE ${pSTG_DB_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1} stg
set upc_prod_sk = prod.prod_sk,
       prod_id_1   = prod.src_sys_prod_id_1,
       prod_id_2   = prod.src_sys_prod_id_2,
       prod_id_3   = prod.src_sys_prod_id_3,
       prod_id_4   = prod.src_sys_prod_id_4
 FROM   ${pVIEW_DB_NAME}.${pTD_VIEW_DB_IDL}.${pVIEW_TABLE} prod,
   (select distinct upc, max(edw_rec_begin_dt) as max_dt, max(prod_chng_sk) as max_sk
          from ${pVIEW_DB_NAME}.${pTD_VIEW_DB_IDL}.${pVIEW_TABLE}
         where edw_rec_end_dt = '9999-12-31'
           and src_sys_cd     = 'EC'
        group by 1
        ) dst
   where prod.upc  = stg.upc
   and prod.upc  = dst.upc
   and prod.edw_rec_begin_dt = dst.max_dt
   and prod.prod_chng_sk     = dst.max_sk
   and prod.edw_rec_end_dt   = '9999-12-31'
   and prod.src_sys_cd       = 'EC'
;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>

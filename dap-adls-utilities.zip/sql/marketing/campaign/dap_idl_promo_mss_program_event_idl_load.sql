 update $pTGT_DB_NAME.$pTD_DB_IDL.$pTGT_TABLE_NAME3 tgt        
set 

cust_pref_prog_cd =stg.cust_pref_prog_cd,
prog_prompt_channel =stg.prog_prompt_channel, /*Added as part of ER100 Pinpad Cashier - Advertising Feed Change*/
prog_override_cd =stg.prog_override_cd, /*Added as part of ER100 Pinpad Cashier - Advertising Feed Change*/
edw_update_dttm   =stg.edw_update_dttm,
edw_batch_id      =stg.edw_batch_id
   
   FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pTABLE_NAME_1 stg
where 
tgt.src_sys_cd        =stg.src_sys_cd and
tgt.ad_evt_seq_nbr     =stg.ad_evt_seq_nbr      and 
tgt.ad_evt_vers_seq_nbr=stg.ad_evt_vers_seq_nbr and
tgt.ad_evt_type        =stg.ad_evt_type         and 
tgt.ad_evt_vers_type_cd=stg.ad_evt_vers_type_cd 
;

INSERT INTO $pTGT_DB_NAME.$pTD_DB_IDL.$pTGT_TABLE_NAME3
(
src_sys_cd,
ad_evt_seq_nbr,
ad_evt_vers_seq_nbr,
ad_evt_type,
ad_evt_vers_type_cd,
cust_pref_prog_cd,
prog_prompt_channel,
prog_override_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id

)
SELECT
stg.src_sys_cd,
stg.ad_evt_seq_nbr,
stg.ad_evt_vers_seq_nbr,
stg.ad_evt_type,
stg.ad_evt_vers_type_cd,
stg.cust_pref_prog_cd,
stg.prog_prompt_channel,
stg.prog_override_cd,
stg.edw_create_dttm,
stg.edw_update_dttm,
stg.edw_batch_id

FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pTABLE_NAME_1 stg
WHERE NOT EXISTS
(
   SELECT 1
   FROM $pTGT_DB_NAME.$pTD_DB_IDL.$pTGT_TABLE_NAME3 tgt
   WHERE 
         tgt.src_sys_cd           =stg.src_sys_cd and
         tgt.ad_evt_seq_nbr       =stg.ad_evt_seq_nbr      and 
         tgt.ad_evt_vers_seq_nbr  =stg.ad_evt_vers_seq_nbr and
         tgt.ad_evt_type          =stg.ad_evt_type         and
         tgt.ad_evt_vers_type_cd  =stg.ad_evt_vers_type_cd 
)
;

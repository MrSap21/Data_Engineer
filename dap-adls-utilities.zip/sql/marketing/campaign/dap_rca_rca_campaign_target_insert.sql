INSERT INTO $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME
SELECT
campgn_id ,
name,
campgn_desc,
priority_id,
spsnr ,
coord ,
expect_cost,
start_dttm ,
end_dttm ,
impact ,
coord_cntc,
fee_stru,
expect_rslt ,
payor_info ,
fee_info,
cost_desc ,
fee_desc ,
intrjct_ind ,
mndty_cd ,
rca_stat_cd_id , 
src_create_dttm ,
src_update_dttm ,
edw_create_dttm,
edw_batch_id 
FROM $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP TMP
where TMP.campgn_id NOT IN (SELECT DISTINCT CAMPGN_ID FROM $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME);

DROP TABLE IF EXISTS $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP;
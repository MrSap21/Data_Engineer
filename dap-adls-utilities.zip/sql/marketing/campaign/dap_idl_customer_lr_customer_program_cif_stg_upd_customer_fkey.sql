UPDATE  $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME stg
SET  cust_sk = idl.cust_sk
   , edw_etl_step = 'FKEY'

FROM     (select loyalty_mbr_id,src_sys_cd,composite_type_cd,msg_type_cd,cust_sk
from $pTGT_DB_NAME.$pTD_VIEW_DB_IDL.$pLOYALTY_TABLE_NAME 
where src_sys_cd = '${pSRC_SYS_CD}'
and prog_stat_cd = 'A'
and composite_type_cd = 'M'
and msg_type_cd = '1'
and prog_cd in ('LYCD','VCD') group by 1,2,3,4,5
)idl

WHERE stg.src_sys_id = idl.loyalty_mbr_id
AND   stg.src_sys_cd = idl.src_sys_cd
AND   stg.composite_type_cd = idl.composite_type_cd
AND   stg.msg_type_cd = idl.msg_type_cd
AND   stg.cust_sk = -1
AND   stg.src_sys_cd = '${pSRC_SYS_CD}';


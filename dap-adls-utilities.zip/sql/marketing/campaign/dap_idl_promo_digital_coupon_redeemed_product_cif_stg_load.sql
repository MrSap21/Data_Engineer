MERGE INTO ${pSTG_DB_NAME}.${pTD_DB_CIF}.${pSTG_TABLE_1} AS stg
USING (Select * from ${pSTG_DB_NAME}.${pTD_DB_CIF}.${pSTG_TABLE_2} where loyalty_cust_sk is not null and loyalty_cust_sk <> -1)  AS cif
ON
    stg.offer_cd = cif.offer_cd
	AND stg.loyalty_cust_sk = cif.loyalty_cust_sk
	AND stg.upc = cif.upc
	WHEN MATCHED THEN
UPDATE
	SET
	edw_update_dttm = CURRENT_TIMESTAMP(0),
	edw_batch_id = ${pEDW_BATCH_ID}

WHEN NOT MATCHED THEN INSERT
(
offer_cd,
loyalty_cust_sk,
upc_prod_sk,
upc_qty,
loyalty_mbr_id,
upc,
prod_id_1,
prod_id_2,
prod_id_3,
prod_id_4,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
) VALUES
(
cif.offer_cd,
cif.loyalty_cust_sk,
-1,
cif.upc_qty,
cif.loyalty_mbr_id,
cif.upc,
NULL,
NULL,
NULL,
NULL,
current_TIMESTAMP(0),
current_TIMESTAMP(0),
${pEDW_BATCH_ID}
)
;

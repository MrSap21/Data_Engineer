INSERT INTO $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME
SELECT
        campgn_id,
        campgn_relation_id ,
        campgn_relation_type,
        campgn_relation_optr,
        gap_wks,
        src_create_dttm,
        src_update_dttm ,
        edw_create_dttm,
        edw_batch_id
FROM $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP TMP
where TMP.campgn_id NOT IN (SELECT DISTINCT CAMPGN_ID FROM $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME);

DROP TABLE IF EXISTS $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP;


DELETE FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_STAGING_TABLE AS stg
WHERE stg.upc_prod_sk IS NOT NULL
AND stg.upc_prod_sk <> -1
;

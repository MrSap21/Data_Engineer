INSERT INTO $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME
SELECT
qstn_id,
qstn_id_seq,
txt,
service_id,
priority_id,
seq_cd,
ans_list,
actv_ind,
parent_qstn_seq_cd,
ans_weight,
app_cd,
parent_qstn_condition,
parent_qstn_optr,
src_create_user_id,
src_create_dttm,
src_update_dttm,
edw_create_dttm,
edw_batch_id
FROM $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP TMP
where TMP.qstn_id NOT IN (SELECT DISTINCT qstn_id FROM $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME);

DROP TABLE IF EXISTS $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP;
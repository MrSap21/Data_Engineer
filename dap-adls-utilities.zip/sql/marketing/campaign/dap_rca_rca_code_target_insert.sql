INSERT INTO $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME
SELECT
rca_cd_id,
catg_cd,
catg_desc,
cd_desc, 
src_create_dttm ,
src_update_dttm ,
edw_create_dttm,
edw_batch_id 
FROM $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP TMP
where TMP.rca_cd_id NOT IN (SELECT DISTINCT rca_cd_id FROM $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME);

DROP TABLE IF EXISTS $pDATABASE_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP;
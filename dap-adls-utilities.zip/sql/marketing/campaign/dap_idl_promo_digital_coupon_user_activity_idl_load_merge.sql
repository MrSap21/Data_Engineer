MERGE INTO $pTGT_DB_NAME.${pTD_DB_IDL}.$pTGT_TABLE_NAME3 AS tgt
USING (Select * from $pSTG_DB_NAME.${pTD_DB_CIF}.$pSTG_TABLE_NAME2 where loyalty_cust_sk <> -1)  AS stg
ON
            tgt.offer_cd = stg.offer_cd
	AND tgt.loyalty_mbr_id = stg.loyalty_mbr_id
	WHEN MATCHED THEN
UPDATE
	SET
        loyalty_cust_sk = stg.loyalty_cust_sk,
	coupon_clip_dttm = stg.coupon_clip_dttm,
	coupon_redmptn_dttm  = CASE WHEN tgt.coupon_redmptn_dttm  IS NULL     AND 
                                 stg.coupon_redmptn_dttm  IS NOT NULL 
                            THEN stg.coupon_redmptn_dttm  ELSE tgt.coupon_redmptn_dttm END,
        rfn_value            = CASE WHEN tgt.rfn_value            IS NULL     AND
                                 stg.rfn_value            IS NOT NULL
                            THEN stg.rfn_value  ELSE tgt.rfn_value          END,
        sales_txn_id         = CASE WHEN tgt.sales_txn_id         IS NULL     AND
                                 stg.sales_txn_id         IS NOT NULL
                            THEN stg.sales_txn_id  ELSE tgt.sales_txn_id       END,
        sales_txn_dt         = CASE WHEN tgt.sales_txn_dt         IS NULL     AND
                                 stg.sales_txn_dt         IS NOT NULL
                            THEN stg.sales_txn_dt ELSE tgt.sales_txn_dt        END,
        sales_txn_type       = CASE WHEN tgt.sales_txn_type       IS NULL     AND
                                 stg.sales_txn_type       IS NOT NULL
                            THEN stg.sales_txn_type ELSE tgt.sales_txn_type      END,
        sales_txn_src_sys_cd = CASE WHEN tgt.sales_txn_src_sys_cd IS NULL     AND
                                 stg.sales_txn_src_sys_cd IS NOT NULL 
                            THEN stg.sales_txn_src_sys_cd ELSE tgt.sales_txn_src_sys_cd END,
        sales_ord_src_type   = CASE WHEN tgt.sales_ord_src_type   IS NULL     AND
                                 stg.sales_ord_src_type   IS NOT NULL 
                            THEN stg.sales_ord_src_type ELSE tgt.sales_ord_src_type  END,
	coupon_actv_type_name = stg.coupon_actv_type_name,
	coupon_clip_channel_name = stg.coupon_clip_channel_name,
	edw_update_dttm = CURRENT_TIMESTAMP(0),
	edw_batch_id = ${pEDW_BATCH_ID}

WHEN NOT MATCHED THEN INSERT
(
offer_cd,
loyalty_cust_sk,
loyalty_mbr_id,
coupon_clip_dttm,
coupon_redmptn_dttm,
rfn_value,
sales_txn_id,
sales_txn_dt,
sales_txn_type,
sales_txn_src_sys_cd,
sales_ord_src_type,
coupon_actv_type_name,
coupon_clip_channel_name,
edw_create_dttm,
edw_update_dttm,
edw_batch_id

) VALUES
(
stg.offer_cd,
stg.loyalty_cust_sk,
stg.loyalty_mbr_id,
stg.coupon_clip_dttm,
stg.coupon_redmptn_dttm,
stg.rfn_value,
stg.sales_txn_id,
stg.sales_txn_dt,
stg.sales_txn_type,
stg.sales_txn_src_sys_cd,
stg.sales_ord_src_type,
stg.coupon_actv_type_name,
stg.coupon_clip_channel_name,
current_TIMESTAMP(0),
current_TIMESTAMP(0),
${pEDW_BATCH_ID}
);

UPDATE $pTGT_DB_NAME.${pTD_DB_IDL}.$pTGT_TABLE_NAME3 tbl
SET sales_txn_dt       = idl.sales_txn_dt,
       sales_ord_src_type = idl.sales_ord_src_type,
       sales_txn_type     = idl.sales_txn_type
 FROM    $DB_RETAIL.${pTD_VIEW_DB_IDL}.SALES_TRANSACTION       idl
   WHERE tbl.sales_txn_id   = idl.sales_txn_id
   AND tbl.sales_txn_src_sys_cd = idl.src_sys_cd
   AND tbl.sales_txn_src_sys_cd = 'EC'
   AND idl.src_sys_cd           = 'EC'
   AND tbl.sales_txn_dt        IS NULL
;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>

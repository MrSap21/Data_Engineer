/* -- pTD_EDW_BATCH_DT SQL - LOAD RECORDS INTO STAGE WHICH WILL END DATE EXISTING TARGET RECORDS FOR SOURCE UPDATES (ID'D THROUGH MINUS) IN CIF TABLE */
INSERT INTO ${pSTG_DATABASE_NAME}.$pTD_DB_CIF.${pTABLE_NAME_1}_stg
SELECT
        proc.cust_sk as cust_sk,
        cif.segment_key_val as segment_key_val,
        cif.prog_id as prog_id,
        cif.prog_cd as prog_cd,
        cif.prog_start_dt as prog_start_dt,
        cif.loyalty_mbr_id as loyalty_mbr_id,        
        cif.src_sys_cd as src_sys_cd,
        cif.composite_type_cd as composite_type_cd,
        cif.msg_type_cd as msg_type_cd,
        cif.segment_key_val_desc as segment_key_val_desc,
        cif.security_class_cd as security_class_cd,
        current_timestamp(0) as edw_create_dttm,
       	current_timestamp(0) as edw_update_dttm,
        $pEDW_BATCH_ID AS edw_batch_id,
        'CIF' AS edw_etl_step
FROM    ${pSTG_DATABASE_NAME}.$pTD_DB_CIF.cif_${pTABLE_NAME_1}_stg cif 
LEFT OUTER JOIN ${pSTG_DATABASE_NAME}.$pTD_DB_CIF.proc_${pTABLE_NAME_1}_stg proc
ON  		cif.loyalty_mbr_id = proc.loyalty_mbr_id
	AND	cif.src_sys_cd = proc.src_sys_cd
	AND	cif.composite_type_cd = proc.composite_type_cd
	AND	cif.msg_type_cd = proc.msg_type_cd
        AND     cif.prog_id = proc.prog_id
        AND     cif.prog_cd = proc.prog_cd
        AND     cif.segment_key_val_desc=proc.segment_key_val_desc

WHERE   
(cif.loyalty_mbr_id, cif.src_sys_cd, cif.composite_type_cd, cif.msg_type_cd) IN
(
	SELECT loyalty_mbr_id,src_sys_cd,composite_type_cd,msg_type_cd
	FROM
	(
		SELECT 
                        segment_key_val,
                        prog_id,
                        prog_cd ,
                        prog_start_dt,
                        loyalty_mbr_id,
                        src_sys_cd,
                        composite_type_cd,
                        msg_type_cd,
                        segment_key_val_desc,
                        security_class_cd 
		FROM ${pSTG_DATABASE_NAME}.$pTD_DB_CIF.cif_${pTABLE_NAME_1}_stg
		WHERE src_sys_cd = $pSRC_SYS_CD
	MINUS
		SELECT 
                        segment_key_val,
                        prog_id,
                        prog_cd,
                        prog_start_dt,
                        loyalty_mbr_id,
                        src_sys_cd,
                        composite_type_cd,
                        msg_type_cd,
                        segment_key_val_desc,
                        security_class_cd  
		FROM ${pSTG_DATABASE_NAME}.$pTD_DB_CIF.proc_${pTABLE_NAME_1}_stg
		WHERE src_sys_cd = $pSRC_SYS_CD
	) AS TMP
);

INSERT INTO ${pTGT_DB_NAME}.${pTDDBName}.${pTargetTable}
SELECT  merged_fm_pat_id,
        qstn_id,
        src_create_dt,
        src_create_tm,
        pat_id,
        campgn_id,
        pat_campgn_min_start_dt,
        campgn_component_seq_id,
        ans_rslt,
        ans_party_cd,
        create_str_nbr,
        update_str_nbr,
        rca_ses_cd,
        src_create_emp_id ,
        src_update_emp_id,
        src_update_dttm,
        edw_create_dttm,
        edw_batch_id 
FROM ${pSTG_DB_NAME}.${pTDStageDB}.${pTargetTable}_ML_STG
where edw_dml_ind='I';





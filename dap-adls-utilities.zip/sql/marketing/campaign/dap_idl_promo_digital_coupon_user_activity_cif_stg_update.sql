UPDATE $pSTG_DB_NAME.${pTD_DB_CIF}.$pSTG_TABLE_NAME2 stg
Set
loyalty_cust_sk  = cust.cust_sk
FROM    $pDB_MASTER_DATA.${pTD_VIEW_DB_IDL}.customer cust
--${pTD_VIEW_DB_IDL}.dim_loyalty_customer_xref cust_xref
Where
cust.src_sys_cd = 'LR'
And cust.composite_type_cd = 'M'
And cust.msg_type_cd = '1'
And cust.edw_rec_end_dt = '9999-12-31'
And stg.loyalty_mbr_id = cust.cust_src_id
--And cust.cust_sk = cust_xref.cust_sk
--And cust_xref.edw_rec_end_dt = '9999-12-31'
;
--And cust.cust_sk = cust_xref.cust_sk
--And cust_xref.edw_rec_end_dt = '9999-12-31'
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>

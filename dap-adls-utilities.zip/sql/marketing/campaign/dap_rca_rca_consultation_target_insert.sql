
INSERT INTO $pTGT_DB_NAME.${pTDDBName}.${pTargetTable}
SELECT  merged_fm_pat_id,
        consult_dt,
        consult_tm,
        consult_type_cd,
        pat_id,
        consult_party_cd,
        consult_accept_ind,
        rx_nbr,
        str_nbr,
        campgn_id,
        campgn_component_seq_id,
        component_dctnry_id,
        consult_cmnt,
        emp_initials,
        free_txt_ind,
        consult_rslt_cmnt,
        consult_rslt_rph_initials,
        consult_rslt_dttm,
        consult_add_type_cd,
        rca_cd_id,
        src_create_user_id,
        src_update_user_id,
        src_create_dttm,
        src_update_dttm,
        edw_create_dttm,
        edw_batch_id
FROM ${pSTG_DB_NAME}.${pTDStageDB}.${pSTG_TABLE_NAME2}_ML_STG
where  ${pSTG_DB_NAME}.${pTDStageDB}.${pSTG_TABLE_NAME2}_ML_STG.edw_dml_ind='I';

COMMIT;

begin transaction;
-- TRANS_CONTROL - Convert BT to BEGIN TRANSACTION

-- LOCK TABLE $pTD_DB_CIF.proc_customer_program FOR ACCESS

-- LOCK TABLE $pTD_DB_CIF.$pTABLE_NAME_1 FOR ACCESS

INSERT INTO $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME
( cust_prog_chng_sk             
,cust_sk                       
,prog_cd                       
,prog_id                       
,prog_stat_cd                  
,stat_eff_dt                   
,stat_end_dt                   
,src_sys_id                    
,src_sys_cd                    
,composite_type_cd             
,msg_type_cd                   
,edw_rec_begin_dt              
,prog_start_dt                 
,prog_end_dt                   
,prog_enrl_channel_cd          
,security_class_cd             
,vndr_ref_id                   
,hipaa_stat_cd                 
,hipaa_form_name
,unsubscribe_mbr_eml_addr               
,edw_rec_end_dt                
,edw_create_dttm               
,edw_update_dttm               
,edw_batch_id                  
,edw_etl_step                  
)
SELECT   
 p.cust_prog_chng_sk             
,p.cust_sk                       
,p.prog_cd                       
,p.prog_id                       
,p.prog_stat_cd                  
,p.stat_eff_dt                   
,p.stat_end_dt                   
,p.src_sys_id                    
,p.src_sys_cd                    
,p.composite_type_cd             
,p.msg_type_cd                   
,p.edw_rec_begin_dt              
,p.prog_start_dt                 
,p.prog_end_dt                   
,p.prog_enrl_channel_cd          
,p.security_class_cd             
,p.vndr_ref_id                   
,p.hipaa_stat_cd                 
,p.hipaa_form_name
,p.unsubscribe_mbr_eml_addr               
,$pTD_EDW_BATCH_DATE - 1 as edw_rec_end_dt                
,p.edw_create_dttm          
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm 
,$pEDW_BATCH_ID as edw_batch_id 
,'CIF' as edw_etl_step 
FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pPROC_TABLE_NAME p
WHERE (src_sys_id, src_sys_cd, composite_type_cd, msg_type_cd,prog_cd) IN
(
   SELECT   src_sys_id
          , src_sys_cd
          , composite_type_cd
          , msg_type_cd
          , prog_cd
   FROM
   (
      SELECT         
prog_cd                       
,prog_id                       
,prog_stat_cd                  
,src_sys_id                    
,src_sys_cd                    
,composite_type_cd             
,msg_type_cd                   
,prog_enrl_channel_cd          
,security_class_cd             
,vndr_ref_id                   
,hipaa_stat_cd                 
,hipaa_form_name
,unsubscribe_mbr_eml_addr               

      FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pPROC_TABLE_NAME
      WHERE src_sys_cd = '$pSRC_SYS_CD'

      MINUS

      SELECT  
prog_cd                       
,prog_id                       
,prog_stat_cd                  
,src_sys_id                    
,src_sys_cd                    
,composite_type_cd             
,msg_type_cd                   
,prog_enrl_channel_cd          
,security_class_cd             
,vndr_ref_id                   
,hipaa_stat_cd                 
,hipaa_form_name
,unsubscribe_mbr_eml_addr  

      FROM $pSTG_DB_NAME.$pTD_DB_CIF.$pTABLE_NAME_1
   ) as b
);
-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
-- LOCKING - comment out locking clause

UPDATE $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME AS tgt
SET   stat_end_dt = stg.stat_eff_dt -1
FROM    $pSTG_DB_NAME.$pTD_DB_CIF.$pTABLE_NAME_1 AS stg
WHERE tgt.src_sys_id = stg.src_sys_id
AND   tgt.src_sys_cd = stg.src_sys_cd 
AND   tgt.composite_type_cd = stg.composite_type_cd
AND   tgt.msg_type_cd = stg.msg_type_cd  
AND   tgt.prog_cd = stg.prog_cd  
AND   tgt.src_sys_cd = '$pSRC_SYS_CD'
;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
-- TRANS_CONTROL - Convert END TRANSACTION/ET to COMMIT
commit;



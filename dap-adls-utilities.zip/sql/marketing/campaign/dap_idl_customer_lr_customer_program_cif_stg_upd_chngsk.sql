UPDATE $pSTG_DB_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}
FROM
(
   SELECT   (SUM(1) OVER (ORDER BY 1 ROWS UNBOUNDED PRECEDING) + :pkey) as pkey
          , src_sys_id
          ,src_sys_cd
          ,composite_type_cd
          ,msg_type_cd
          ,prog_cd
          , edw_rec_begin_dt
   FROM $pSTG_DB_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}
   WHERE ${pPKEY_COLUMN_NAME} is null
   AND   src_sys_cd = '${pSRC_SYS_CD}'
) as c
SET   ${pPKEY_COLUMN_NAME} = c.pkey
    , edw_etl_step = 'PKEY'
WHERE ${pSTG_TABLE}.src_sys_id = c.src_sys_id
AND ${pSTG_TABLE}.src_sys_cd = c.src_sys_cd
AND ${pSTG_TABLE}.composite_type_cd = c.composite_type_cd
AND ${pSTG_TABLE}.msg_type_cd = c.msg_type_cd
AND ${pSTG_TABLE}.prog_cd = c.prog_cd
AND ${pSTG_TABLE}.edw_rec_begin_dt = c.edw_rec_begin_dt
AND ${pSTG_TABLE}.${pPKEY_COLUMN_NAME} is null;


INSERT INTO $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME
SELECT
campgn_component_seq_id,
campgn_id, 
name,
seq_nbr,
component_dctnry_id,
start_dttm,
end_dttm,
msg_txt,
consult_ind,
first_ind,
last_ind,
terminate_ind,
intrjct_ind,
delay_days,
src_create_dttm,
edw_create_dttm,
edw_batch_id
FROM $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP TMP
where TMP.campgn_component_seq_id NOT IN (SELECT DISTINCT campgn_component_seq_id FROM $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME);

DROP TABLE IF EXISTS $pTGT_DB_NAME.${pTDDBName}.$PTGT_TABLE_NAME_TMP;
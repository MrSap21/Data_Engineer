insert into ${pTGT_DB_NAME}.${pTDDBName}.$PTGT_TABLE_NAME
SELECT 
campgn_component_flow_id,
campgn_component_seq_id,
component_seq_after_id,
component_outcome_optr,
component_outcome_rslt_val,
edw_create_dttm,
edw_batch_id
FROM ${pTGT_DB_NAME}.${pTDDBName}.$PTGT_TABLE_NAME_TMP tmp_tbl
where tmp_tbl.campgn_component_flow_id NOT IN (SELECT DISTINCT campgn_component_flow_id FROM ${pTGT_DB_NAME}.${pTDDBName}.$PTGT_TABLE_NAME);

DROP TABLE IF EXISTS ${pTGT_DB_NAME}.${pTDDBName}.$PTGT_TABLE_NAME_TMP;
          


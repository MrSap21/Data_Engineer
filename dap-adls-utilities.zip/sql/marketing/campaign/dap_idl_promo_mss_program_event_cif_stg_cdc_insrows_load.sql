INSERT INTO $pSTG_DB_NAME.$pTD_DB_CIF.$pTABLE_NAME_1
(
src_sys_cd,
ad_evt_seq_nbr,
ad_evt_vers_seq_nbr,
ad_evt_type,
ad_evt_vers_type_cd,
cust_pref_prog_cd,
prog_prompt_channel, /*Added as part of ER100 Pinpad Cashier - Advertising Feed Change*/
prog_override_cd, /*Added as part of ER100 Pinpad Cashier - Advertising Feed Change*/
edw_create_dttm,
edw_update_dttm,
edw_batch_id,
edw_etl_step
)
select 
pe.src_sys_cd,
pe.ad_evt_seq_nbr,
pe.ad_evt_vers_seq_nbr,
pe.ad_evt_type,
pe.ad_evt_vers_type_cd,
pe.cust_pref_prog_cd,
pe.prog_prompt_channel, 
pe.prog_override_cd,
       to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm,
       to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm,
       $pEDW_BATCH_ID as edw_batch_id,
	   'CIF' as edw_etl_step
from $pSTG_DB_NAME.$pTD_DB_CIF.$pSTG_TABLE_NAME2 pe
;

DELETE FROM $db_param_staging.$schema1.$table1;

INSERT INTO $db_param_staging.$schema1.$table1
(tkt_nbr, 
tkt_open_dt, 
reqst_type_cd, 
tkt_line_seq, 
dim_loyalty_cust_sk,
cust_sk, 
edw_rec_begin_dt, 
edw_rec_end_dt, 
eid, 
mid, 
loyalty_mbr_id,
src_sys_cd, 
mbr_stat_cd, 
last_name, 
first_name, 
middle_name,
name_suffix, 
brth_dt, 
gndr_cd, 
household_id, 
permnt_addr_line_1,
permnt_addr_line_2, 
permnt_city, 
permnt_state_cd, 
permnt_zip_cd_4,
permnt_zip_cd_5, 
permnt_cntry, 
permnt_latitude, 
permnt_longitude,
permnt_dpv_ind_cd, 
permnt_dpv_footnote, 
permnt_ncoa_nixie_footnote,
work_addr_line_1, 
work_addr_line_2, 
work_city, 
work_state_cd,
work_zip_cd_4, 
work_zip_cd_5, 
work_cntry, 
work_latitude, 
work_longitude,
work_dpv_ind_cd, 
work_dpv_footnote, 
work_ncoa_nixie_footnote,
scndry_addr_line_1, 
scndry_addr_line_2, 
scndry_city, 
scndry_state_cd,
scndry_zip_cd_4, 
scndry_zip_cd_5, 
scndry_cntry, 
scndry_latitude,
scndry_longitude, 
scndry_dpv_ind_cd, 
scndry_dpv_footnote, 
scndry_ncoa_nixie_footnote,
home_phone, 
cell_phone, 
work_phone, 
eml_addr, 
primary_cntc, 
scndry_cntc,
tertiary_cntc, 
enrl_dt, 
enrl_channel, 
store_nbr, 
register_nbr,
rfn_val, 
txt_msg_ind, 
do_not_call_ind, 
do_not_mail_ind, 
do_not_eml_ind,
suspcs_mbr_ind, 
edw_create_dttm, 
edw_update_dttm, 
edw_batch_id)
SELECT
tkt_nbr, 
tkt_open_dt, 
reqst_type_cd, 
tkt_line_seq, 
dim_loyalty_cust_sk,
cust_sk, 
edw_rec_begin_dt, 
edw_rec_end_dt, 
eid, 
mid, 
loyalty_mbr_id,
src_sys_cd, 
mbr_stat_cd, 
last_name, 
first_name, 
middle_name,
name_suffix, 
brth_dt, 
gndr_cd, 
household_id, 
permnt_addr_line_1,
permnt_addr_line_2, 
permnt_city, 
permnt_state_cd, 
permnt_zip_cd_4,
permnt_zip_cd_5, 
permnt_cntry, 
permnt_latitude, 
permnt_longitude,
permnt_dpv_ind_cd, 
permnt_dpv_footnote, 
permnt_ncoa_nixie_footnote,
work_addr_line_1, 
work_addr_line_2, 
work_city, 
work_state_cd,
work_zip_cd_4, 
work_zip_cd_5, 
work_cntry, 
work_latitude, 
work_longitude,
work_dpv_ind_cd, 
work_dpv_footnote, 
work_ncoa_nixie_footnote,
scndry_addr_line_1, 
scndry_addr_line_2, 
scndry_city, 
scndry_state_cd,
scndry_zip_cd_4, 
scndry_zip_cd_5, 
scndry_cntry, 
scndry_latitude,
scndry_longitude, 
scndry_dpv_ind_cd, 
scndry_dpv_footnote, 
scndry_ncoa_nixie_footnote,
home_phone, 
cell_phone, 
work_phone, 
eml_addr, 
primary_cntc, 
scndry_cntc,
tertiary_cntc, 
enrl_dt, 
enrl_channel, 
store_nbr, 
register_nbr,
rfn_val, 
txt_msg_ind, 
do_not_call_ind, 
do_not_mail_ind, 
do_not_eml_ind,
suspcs_mbr_ind, 
edw_create_dttm, 
edw_update_dttm, 
edw_batch_id
FROM
(SELECT
tgt.tkt_nbr, 
tgt.tkt_open_dt, 
tgt.reqst_type_cd, 
tgt.tkt_line_seq, 
stg.dim_loyalty_cust_sk,
stg.cust_sk, 
stg.edw_rec_begin_dt, 
stg.edw_rec_end_dt, 
stg.eid, 
stg.mid, 
stg.loyalty_mbr_id,
stg.src_sys_cd, 
stg.mbr_stat_cd, 
stg.last_name, 
stg.first_name, 
stg.middle_name,
stg.name_suffix, 
stg.brth_dt, 
stg.gndr_cd, 
stg.household_id, 
stg.permnt_addr_line_1,
stg.permnt_addr_line_2, 
stg.permnt_city, 
stg.permnt_state_cd, 
stg.permnt_zip_cd_4,
stg.permnt_zip_cd_5, 
stg.permnt_cntry, 
stg.permnt_latitude, 
stg.permnt_longitude,
stg.permnt_dpv_ind_cd, 
stg.permnt_dpv_footnote, 
stg.permnt_ncoa_nixie_footnote,
stg.work_addr_line_1, 
stg.work_addr_line_2, 
stg.work_city, 
stg.work_state_cd,
stg.work_zip_cd_4, 
stg.work_zip_cd_5, 
stg.work_cntry, 
stg.work_latitude, 
stg.work_longitude,
stg.work_dpv_ind_cd, 
stg.work_dpv_footnote, 
stg.work_ncoa_nixie_footnote,
stg.scndry_addr_line_1, 
stg.scndry_addr_line_2, 
stg.scndry_city, 
stg.scndry_state_cd,
stg.scndry_zip_cd_4, 
stg.scndry_zip_cd_5, 
stg.scndry_cntry, 
stg.scndry_latitude,
stg.scndry_longitude, 
stg.scndry_dpv_ind_cd, 
stg.scndry_dpv_footnote, 
stg.scndry_ncoa_nixie_footnote,
stg.home_phone, 
stg.cell_phone, 
stg.work_phone, 
stg.eml_addr, 
stg.primary_cntc, 
stg.scndry_cntc,
stg.tertiary_cntc, 
stg.enrl_dt, 
stg.enrl_channel, 
stg.store_nbr, 
stg.register_nbr,
stg.rfn_val, 
stg.txt_msg_ind, 
stg.do_not_call_ind, 
stg.do_not_mail_ind, 
stg.do_not_eml_ind,
stg.suspcs_mbr_ind, 
stg.edw_create_dttm, 
stg.edw_update_dttm, 
stg.edw_batch_id
FROM $db_param_marketing.$schema2.$table2 stg
INNER JOIN $db_param_staging.$schema1.$table3 tgt 
ON stg.cust_sk=tgt.cust_sk
AND tgt.src_sys_cd='LR') BASE;

update $db_param_staging.$schema1.$table1 tgt
set mid=stg.mid
,EID=stg.EID
FROM
$db_param_staging.$schema1.$table3 stg
where tgt.cust_sk=stg.cust_sk
and stg.src_sys_cd='LR';

DELETE FROM $db_param_staging.$schema1.$table4;

INSERT INTO $db_param_staging.$schema1.$table4 
(     
tkt_nbr	,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt)
SELECT 
tkt_nbr,tkt_line_seq,tkt_open_dt,reqst_type_cd,
subject_area,db_name,tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt
FROM 
(SELECT stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,
'$schema2' as subject_area,'$db_param_marketing' as db_name,'$table2' as tbl_name,
null as after_del_cnt, count(stg.tkt_nbr) as stg_tbl_rec_count, count(stg.tkt_nbr) as before_del_cnt
from $db_param_staging.$schema1.$table1 stg JOIN $db_param_marketing.$schema2.$table2 tgt
ON  tgt.dim_loyalty_cust_sk=stg.dim_loyalty_cust_sk
AND tgt.cust_sk=stg.cust_sk
AND tgt.edw_rec_begin_dt=stg.edw_rec_begin_dt
AND tgt.edw_rec_end_dt=stg.edw_rec_end_dt
GROUP BY 1,2,3,4)a;

update $db_param_marketing.$schema2.$table2 tgt
set mid=stg.mid
,EID=stg.EID
,edw_update_dttm=current_timestamp(0)
,edw_batch_id = $EDW_BATCH_ID
FROM $db_param_staging.$schema1.$table1 stg
where tgt.dim_loyalty_cust_sk=stg.dim_loyalty_cust_sk
AND tgt.cust_sk=stg.cust_sk
AND tgt.edw_rec_begin_dt=stg.edw_rec_begin_dt
AND tgt.edw_rec_end_dt=stg.edw_rec_end_dt;

UPDATE $db_param_staging.$schema1.$table4 stg
SET AFTER_DEL_CNT=aft_rec.cnt
FROM
(
SELECT stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,count(*) as cnt FROM
$db_param_marketing.$schema2.$table2 tgt INNER JOIN $db_param_staging.$schema1.$table1 stg
ON tgt.dim_loyalty_cust_sk=stg.dim_loyalty_cust_sk
AND tgt.cust_sk=stg.cust_sk
AND tgt.edw_rec_begin_dt=stg.edw_rec_begin_dt
AND tgt.edw_rec_end_dt=stg.edw_rec_end_dt
AND tgt.edw_batch_id=$EDW_BATCH_ID
GROUP BY 1,2,3,4) aft_rec
where stg.TKT_NBR=aft_rec.TKT_NBR
AND stg.TKT_LINE_SEQ=aft_rec.TKT_LINE_SEQ
AND stg.tkt_open_dt=aft_rec.tkt_open_dt
AND stg.reqst_type_cd=aft_rec.reqst_type_cd
AND stg.DB_NAME='$db_param_marketing'
AND stg.TBL_NAME='$table2'
AND stg.SUBJECT_AREA='$schema2';

insert into $db_param_retail.$schema1.$table5
(
subject_area,  
db_name,
tbl_name, 
tkt_nbr,
tkt_line_seq,
tkt_open_dt, 
reqst_type_cd,
del_rec_cnt,
rec_del_dt,
stat_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
select
a.subject_area,
a.db_name,
a.tbl_name,
a.tkt_nbr,
a.tkt_line_seq,
a.tkt_open_dt,
a.reqst_type_cd,
a.del_rec_cnt,
a.rec_del_dt,
a.stat_cd,
a.edw_create_dttm,
a.edw_update_dttm,
a.edw_batch_id
from
(
select
stg_ccpa.subject_area as subject_area
,stg_ccpa.db_name as db_name
,stg_ccpa.tbl_name as tbl_name
,stg_ccpa.tkt_nbr as tkt_nbr
,stg_ccpa.tkt_line_seq as tkt_line_seq
,stg_ccpa.tkt_open_dt as tkt_open_dt
,stg_ccpa.reqst_type_cd as reqst_type_cd
,stg_ccpa.stg_tbl_rec_count as del_rec_cnt
,current_date as rec_del_dt
,case when (stg_ccpa.before_del_cnt = stg_ccpa.after_del_cnt) then 'S' else 'E' end as stat_cd
,current_date as edw_reqst_complete_dt
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
,$EDW_BATCH_ID as edw_batch_id
from $db_param_staging.$schema1.$table4 stg_ccpa inner join 
(select 
subject_area as subject_area
,db_name as db_name
,tbl_name as tbl_name
,sum(stg_tbl_rec_count) as del_count
from $db_param_staging.$schema1.$table4
where db_name='$db_param_marketing'
and tbl_name='$table2'
and subject_area='$schema2'
group by 1,2,3 ) del_cnt
on 
stg_ccpa.subject_area=del_cnt.subject_area
and stg_ccpa.db_name=del_cnt.db_name
and stg_ccpa.tbl_name=del_cnt.tbl_name)a;
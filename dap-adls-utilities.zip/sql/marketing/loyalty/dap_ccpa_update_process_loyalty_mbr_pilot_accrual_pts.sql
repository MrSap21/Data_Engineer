DELETE FROM ${pTD_STAGE}.${pCCPA_SCHEMA}.${pSTG_CCPA_COUNT_TABLE_NAME} ;

INSERT INTO ${pTD_STAGE}.${pCCPA_SCHEMA}.${pSTG_CCPA_COUNT_TABLE_NAME}
(     
tkt_nbr	,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt)
SELECT 
tkt_nbr,tkt_line_seq,tkt_open_dt,reqst_type_cd,
subject_area,db_name,tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt
FROM
 (SELECT stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,
 '$pSUB_AREA' as subject_area, '$pDB_NAME' as db_name,'$pTGT_TABLE' as tbl_name,
 null as after_del_cnt, count(stg.tkt_nbr) as stg_tbl_rec_count, count(stg.tkt_nbr) as before_del_cnt
 from (select * from ${pTD_STAGE}.${pCCPA_SCHEMA}.${pCUSTOMER_XREF_TABLE} where src_sys_cd='LR') stg JOIN ${pTD_TGT}.${pTGT_SCHEMA}.${pTGT_TABLE} tgt
  ON  tgt.loyalty_mbr_id=stg.cust_src_id
  GROUP BY 1,2,3,4
)a;


update ${pTD_TGT}.${pTGT_SCHEMA}.${pTGT_TABLE} tgt
FROM ${pTD_STAGE}.${pCCPA_SCHEMA}.${pCUSTOMER_XREF_TABLE} stg
set loyalty_eid_dim_cust_sk=stg.eid_dim_cust_sk
, loyalty_eid_cust_sk=stg.eid_cust_cur_sk
, loyalty_mid_dim_cust_sk=stg.mid_dim_cust_sk
, loyalty_mid_cust_sk=stg.mid_cust_cur_sk
, edw_update_dttm=current_timestamp(0)
, edw_batch_id= ${EDW_BATCH_ID}
where tgt.loyalty_mbr_id=stg.cust_src_id
and stg.eid_dim_cust_sk is not null
and stg.src_sys_cd='LR';

UPDATE ${pTD_STAGE}.${pCCPA_SCHEMA}.${pSTG_CCPA_COUNT_TABLE_NAME} stg FROM
(
SELECT stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,count(*) as cnt FROM
${pTD_TGT}.${pTGT_SCHEMA}.${pTGT_TABLE}  tgt INNER JOIN (select * from ${pTD_STAGE}.${pCCPA_SCHEMA}.${pCUSTOMER_XREF_TABLE} where src_sys_cd='LR') stg
ON  tgt.loyalty_mbr_id=stg.cust_src_id
	AND tgt.edw_batch_id=${EDW_BATCH_ID}
	GROUP BY 1,2,3,4) aft_rec
	SET AFTER_DEL_CNT=aft_rec.cnt
	where stg.TKT_NBR=aft_rec.TKT_NBR
AND stg.TKT_LINE_SEQ=aft_rec.TKT_LINE_SEQ
AND stg.tkt_open_dt=aft_rec.tkt_open_dt
AND stg.reqst_type_cd=aft_rec.reqst_type_cd
AND stg.DB_NAME='$pDB_NAME'
AND stg.TBL_NAME='$pTGT_TABLE'
AND stg.SUBJECT_AREA='$pSUB_AREA';

INSERT INTO ${pDB_NAME_LOG}.${pCCPA_SCHEMA}.${pTABLE_NAME4}
(
subject_area,  
db_name,
tbl_name, 
tkt_nbr,
tkt_line_seq,
tkt_open_dt, 
reqst_type_cd,
del_rec_cnt,
rec_del_dt,
stat_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
select
a.subject_area,
a.db_name,
a.tbl_name,
a.tkt_nbr,
a.tkt_line_seq,
a.tkt_open_dt,
a.reqst_type_cd,
a.del_rec_cnt,
a.rec_del_dt,
a.stat_cd,
a.edw_create_dttm,
a.edw_update_dttm,
a.edw_batch_id
from
(
select
stg_ccpa.subject_area as subject_area
,stg_ccpa.db_name as db_name
,stg_ccpa.tbl_name as tbl_name
,stg_ccpa.tkt_nbr as tkt_nbr
,stg_ccpa.tkt_line_seq as tkt_line_seq
,stg_ccpa.tkt_open_dt as tkt_open_dt
,stg_ccpa.reqst_type_cd as reqst_type_cd
,stg_ccpa.stg_tbl_rec_count as del_rec_cnt
,current_date as rec_del_dt
, case when (stg_ccpa.before_del_cnt = stg_ccpa.after_del_cnt) then 'S' else 'E' end as stat_cd
,current_date as edw_reqst_complete_dt
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
,$EDW_BATCH_ID as edw_batch_id
 from ${pTD_STAGE}.${pCCPA_SCHEMA}.${pSTG_CCPA_COUNT_TABLE_NAME} stg_ccpa inner join 
  (select 
subject_area as subject_area
,db_name as db_name
,tbl_name as tbl_name
,sum(stg_tbl_rec_count) as del_count
from ${pTD_STAGE}.${pCCPA_SCHEMA}.${pSTG_CCPA_COUNT_TABLE_NAME} 
where db_name = '$pDB_NAME'
AND tbl_name = '$pTGT_TABLE'
AND subject_area = '$pSUB_AREA'
group by 1,2,3 ) del_cnt
 on 
 stg_ccpa.subject_area=del_cnt.subject_area
 and stg_ccpa.db_name=del_cnt.db_name
 and stg_ccpa.tbl_name=del_cnt.tbl_name)a;
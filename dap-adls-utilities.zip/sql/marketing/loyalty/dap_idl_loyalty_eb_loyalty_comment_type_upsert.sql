MERGE INTO $pTGT_DATABASE_NAME.$schema1.$pTABLE_NAME_3
USING $pSTG_DATABASE_NAME.$schema1.$pTABLE_NAME_1 stg
ON  $pTGT_DATABASE_NAME.$schema1.$pTABLE_NAME_3.call_cmnt_type = stg.call_cmnt_type and
    $pTGT_DATABASE_NAME.$schema1.$pTABLE_NAME_3.call_cmnt_subtype = stg.call_cmnt_subtype

WHEN MATCHED THEN
UPDATE
SET 
call_cmnt_type_desc =stg.call_cmnt_type_desc,
call_cmnt_subtype_desc =stg.call_cmnt_subtype_desc ,
edw_update_dttm =stg.edw_update_dttm,
edw_batch_id = stg.edw_batch_id

WHEN NOT MATCHED THEN
INSERT 
(
call_cmnt_type ,
call_cmnt_subtype ,
call_cmnt_type_desc ,
call_cmnt_subtype_desc ,
edw_create_dttm ,
edw_update_dttm ,
edw_batch_id 
)
values
(
stg.call_cmnt_type ,
stg.call_cmnt_subtype ,
stg.call_cmnt_type_desc ,
stg.call_cmnt_subtype_desc ,
stg.edw_create_dttm ,
stg.edw_update_dttm ,
stg.edw_batch_id 
);

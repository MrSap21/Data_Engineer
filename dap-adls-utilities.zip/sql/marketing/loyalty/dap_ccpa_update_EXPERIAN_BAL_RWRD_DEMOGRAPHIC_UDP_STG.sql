delete from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1;

delete from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2;

insert into $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1
( 
tkt_nbr	
,tkt_line_seq
,tkt_open_dt
,reqst_type_cd
,loyalty_vcd_prog_id
,loyalty_cust_sk
,loyalty_src_sys_cd
,loyalty_composite_type_cd
,loyalty_msg_type_cd
,cust_sk)
select distinct stg.tkt_nbr	
,stg.tkt_line_seq
,stg.tkt_open_dt
,stg.reqst_type_cd
,tgt.loyalty_vcd_prog_id
,tgt.loyalty_cust_sk
,tgt.loyalty_src_sys_cd
,tgt.loyalty_composite_type_cd
,tgt.loyalty_msg_type_cd,stg.cust_sk  from 
(select	
     loyalty_vcd_prog_id
	,loyalty_cust_sk
	,loyalty_src_sys_cd
	,loyalty_composite_type_cd
	,loyalty_msg_type_cd
	From $pTGT_DB_NAME.$pDB_NAME.$pTGT_TABLE_NAME
	Where loyalty_src_sys_cd='LR' ) tgt
inner join 
(select cust_sk,tkt_nbr	
		,tkt_line_seq
		,tkt_open_dt
		,reqst_type_cd
		from
		(select cust_sk,cust_src_id,composite_type_cd, msg_type_cd,src_sys_cd From $pDB_MASTER.$pCCPA_TABLE_SCHEMA.$pCCPA_TABLE_CUST	
		Where src_sys_cd='LR' 
		and composite_type_cd='M'
		and msg_type_cd='1' ) tgt 
		inner join
		( select	
		tkt_nbr	
		,tkt_line_seq
		,tkt_open_dt
		,reqst_type_cd
		,cust_src_id
		,composite_type_cd
		,msg_type_cd
		,src_sys_cd
	from $pDB_RETAIL.$pCCPA_SCHEMA.$pTABLE_NAME4
	where composite_type_cd='M'
	and msg_type_cd='1'
	and src_sys_cd='LR'
	and reqst_type_cd='Delete'
	and edw_reqst_complete_dt is null) ccp
	on ccp.cust_src_id=tgt.cust_src_id
	and ccp.composite_type_cd = tgt.composite_type_cd
	and ccp.msg_type_cd = tgt.msg_type_cd
	and ccp.src_sys_cd = tgt.src_sys_cd
) stg
on stg.cust_sk = tgt.loyalty_cust_sk;
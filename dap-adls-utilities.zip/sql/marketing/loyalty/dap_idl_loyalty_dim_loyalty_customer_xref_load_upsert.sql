/* SQL - UPSERT IDL TARGET FROM STG */
BT;
UPDATE  
	idl 
FROM
	$pTD_DB_IDL.$schema1.dim_loyalty_customer_xref idl,
	$pTD_DB_CIF..$schema2.dim_loyalty_customer_xref_stg stg
SET
        edw_rec_end_dt = stg.edw_rec_end_dt,
  	edw_batch_id = stg.edw_batch_id,
  	edw_update_dttm = CURRENT_TIMESTAMP(0)
WHERE
       idl.dim_loyalty_cust_sk = stg.dim_loyalty_cust_sk
AND    stg.edw_rec_end_dt <> $pTD_EDW_END_DATE
AND    stg.dim_loyalty_cust_sk IS NOT NULL;


INSERT INTO $pTD_DB_IDL.$schema1.dim_loyalty_customer_xref
(
        dim_loyalty_cust_sk,
        dim_cust_sk,
        cust_sk,
        loyalty_cust_ref_chng_sk,
        loyalty_cust_link_acct_chng_sk,
        edw_rec_begin_dt,
        edw_rec_end_dt,
        edw_create_dttm,
        edw_update_dttm,
        edw_batch_id
)
SELECT
        dim_loyalty_cust_sk,
        dim_cust_sk,
        cust_sk,
        loyalty_cust_ref_chng_sk,
        loyalty_cust_link_acct_chng_sk,
        edw_rec_begin_dt,
        edw_rec_end_dt,
        CURRENT_TIMESTAMP(0) AS edw_create_dttm,
        CURRENT_TIMESTAMP(0) AS edw_update_dttm,
        edw_batch_id  
FROM  
	$pTD_DB_CIF..$schema2.dim_loyalty_customer_xref_stg
WHERE 
        dim_loyalty_cust_sk IS NOT NULL
AND     edw_rec_end_dt = $pTD_EDW_END_DATE;

ET;

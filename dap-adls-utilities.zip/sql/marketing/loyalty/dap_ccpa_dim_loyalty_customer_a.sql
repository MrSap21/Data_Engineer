DROP TABLE IF EXISTS CONTEXT_CCPA_STG_DB.stg_ccpa_dim_loyalty_customer_a_eidmid;

CREATE OR REPLACE table as CONTEXT_CCPA_STG_DB.stg_ccpa_dim_loyalty_customer_a_eidmid
(tkt_nbr, 
tkt_open_dt, 
reqst_type_cd, 
tkt_line_seq, 
dim_loyalty_cust_sk,
cust_sk, 
edw_rec_begin_dt, 
edw_rec_end_dt, 
eid, 
mid, 
loyalty_mbr_id,
src_sys_cd, 
mbr_stat_cd, 
last_name, 
first_name, 
middle_name,
name_suffix, 
brth_dt, 
gndr_cd, 
household_id, 
permnt_addr_line_1,
permnt_addr_line_2, 
permnt_city, 
permnt_state_cd, 
permnt_zip_cd_4,
permnt_zip_cd_5, 
permnt_cntry, 
permnt_latitude, 
permnt_longitude,
permnt_dpv_ind_cd, 
permnt_dpv_footnote, 
permnt_ncoa_nixie_footnote,
work_addr_line_1, 
work_addr_line_2, 
work_city, 
work_state_cd,
work_zip_cd_4, 
work_zip_cd_5, 
work_cntry, 
work_latitude, 
work_longitude,
work_dpv_ind_cd, 
work_dpv_footnote, 
work_ncoa_nixie_footnote,
scndry_addr_line_1, 
scndry_addr_line_2, 
scndry_city, 
scndry_state_cd,
scndry_zip_cd_4, 
scndry_zip_cd_5, 
scndry_cntry, 
scndry_latitude,
scndry_longitude, 
scndry_dpv_ind_cd, 
scndry_dpv_footnote, 
scndry_ncoa_nixie_footnote,
home_phone, 
cell_phone, 
work_phone, 
eml_addr, 
primary_cntc, 
scndry_cntc,
tertiary_cntc, 
enrl_dt, 
enrl_channel, 
store_nbr, 
register_nbr,
rfn_val, 
txt_msg_ind, 
do_not_call_ind, 
do_not_mail_ind, 
do_not_eml_ind,
suspcs_mbr_ind, 
edw_create_dttm, 
edw_update_dttm, 
edw_batch_id)
AS SELECT
tkt_nbr, 
tkt_open_dt, 
reqst_type_cd, 
tkt_line_seq, 
dim_loyalty_cust_sk,
cust_sk, 
edw_rec_begin_dt, 
edw_rec_end_dt, 
eid, 
mid, 
loyalty_mbr_id,
src_sys_cd, 
mbr_stat_cd, 
last_name, 
first_name, 
middle_name,
name_suffix, 
brth_dt, 
gndr_cd, 
household_id, 
permnt_addr_line_1,
permnt_addr_line_2, 
permnt_city, 
permnt_state_cd, 
permnt_zip_cd_4,
permnt_zip_cd_5, 
permnt_cntry, 
permnt_latitude, 
permnt_longitude,
permnt_dpv_ind_cd, 
permnt_dpv_footnote, 
permnt_ncoa_nixie_footnote,
work_addr_line_1, 
work_addr_line_2, 
work_city, 
work_state_cd,
work_zip_cd_4, 
work_zip_cd_5, 
work_cntry, 
work_latitude, 
work_longitude,
work_dpv_ind_cd, 
work_dpv_footnote, 
work_ncoa_nixie_footnote,
scndry_addr_line_1, 
scndry_addr_line_2, 
scndry_city, 
scndry_state_cd,
scndry_zip_cd_4, 
scndry_zip_cd_5, 
scndry_cntry, 
scndry_latitude,
scndry_longitude, 
scndry_dpv_ind_cd, 
scndry_dpv_footnote, 
scndry_ncoa_nixie_footnote,
home_phone, 
cell_phone, 
work_phone, 
eml_addr, 
primary_cntc, 
scndry_cntc,
tertiary_cntc, 
enrl_dt, 
enrl_channel, 
store_nbr, 
register_nbr,
rfn_val, 
txt_msg_ind, 
do_not_call_ind, 
do_not_mail_ind, 
do_not_eml_ind,
suspcs_mbr_ind, 
edw_create_dttm, 
edw_update_dttm, 
edw_batch_id
FROM
(SELECT
tgt.tkt_nbr, 
tgt.tkt_open_dt, 
tgt.reqst_type_cd, 
tgt.tkt_line_seq, 
stg.dim_loyalty_cust_sk,
stg.cust_sk, 
stg.edw_rec_begin_dt, 
stg.edw_rec_end_dt, 
stg.eid, 
stg.mid, 
stg.loyalty_mbr_id,
stg.src_sys_cd, 
stg.mbr_stat_cd, 
stg.last_name, 
stg.first_name, 
stg.middle_name,
stg.name_suffix, 
stg.brth_dt, 
stg.gndr_cd, 
stg.household_id, 
stg.permnt_addr_line_1,
stg.permnt_addr_line_2, 
stg.permnt_city, 
stg.permnt_state_cd, 
stg.permnt_zip_cd_4,
stg.permnt_zip_cd_5, 
stg.permnt_cntry, 
stg.permnt_latitude, 
stg.permnt_longitude,
stg.permnt_dpv_ind_cd, 
stg.permnt_dpv_footnote, 
stg.permnt_ncoa_nixie_footnote,
stg.work_addr_line_1, 
stg.work_addr_line_2, 
stg.work_city, 
stg.work_state_cd,
stg.work_zip_cd_4, 
stg.work_zip_cd_5, 
stg.work_cntry, 
stg.work_latitude, 
stg.work_longitude,
stg.work_dpv_ind_cd, 
stg.work_dpv_footnote, 
stg.work_ncoa_nixie_footnote,
stg.scndry_addr_line_1, 
stg.scndry_addr_line_2, 
stg.scndry_city, 
stg.scndry_state_cd,
stg.scndry_zip_cd_4, 
stg.scndry_zip_cd_5, 
stg.scndry_cntry, 
stg.scndry_latitude,
stg.scndry_longitude, 
stg.scndry_dpv_ind_cd, 
stg.scndry_dpv_footnote, 
stg.scndry_ncoa_nixie_footnote,
stg.home_phone, 
stg.cell_phone, 
stg.work_phone, 
stg.eml_addr, 
stg.primary_cntc, 
stg.scndry_cntc,
stg.tertiary_cntc, 
stg.enrl_dt, 
stg.enrl_channel, 
stg.store_nbr, 
stg.register_nbr,
stg.rfn_val, 
stg.txt_msg_ind, 
stg.do_not_call_ind, 
stg.do_not_mail_ind, 
stg.do_not_eml_ind,
stg.suspcs_mbr_ind, 
stg.edw_create_dttm, 
stg.edw_update_dttm, 
stg.edw_batch_id
FROM CONTEXT_CCPA_TRG_VB.dim_loyalty_customer_a stg
INNER JOIN CONTEXT_CCPA_STG_DB.stg_link_customer_xref_ref tgt 
ON stg.cust_sk=tgt.cust_sk
AND tgt.src_sys_cd='LR') BASE;


update tgt 
FROM CONTEXT_CCPA_STG_DB.stg_ccpa_dim_loyalty_customer_a_eidmid tgt,
CONTEXT_CCPA_STG_DB.stg_link_customer_xref_ref stg
set mid=stg.mid
,EID=stg.EID
where tgt.cust_sk=stg.cust_sk
and stg.src_sys_cd='LR';


DELETE TABLE IF EXISTS CONTEXT_CCPA_STG_DB.stg_count_dim_loyalty_customer_a_eid_ccpa;

CREATE OR REPLACE TABLE CONTEXT_CCPA_STG_DB.stg_count_dim_loyalty_customer_a_eid_ccpa 
(     
tkt_nbr	,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt)
SELECT 
tkt_nbr,tkt_line_seq,tkt_open_dt,reqst_type_cd,
subject_area,db_name,tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt
FROM
 (SELECT stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,
 'SUB_AREA' as subject_area, 'CONTEXT_CCPA_TRG_DB' as db_name,'dim_loyalty_customer_a_eid' as tbl_name,
 null as after_del_cnt, count(stg.tkt_nbr) as stg_tbl_rec_count, count(stg.tkt_nbr) as before_del_cnt
 from CONTEXT_CCPA_STG_DB.stg_ccpa_dim_loyalty_customer_a_eidmid  stg JOIN CONTEXT_CCPA_TRG_VB.dim_loyalty_customer_a tgt
  ON  tgt.dim_loyalty_cust_sk=stg.dim_loyalty_cust_sk
  AND tgt.cust_sk=stg.cust_sk
  AND tgt.edw_rec_begin_dt=stg.edw_rec_begin_dt
  AND tgt.edw_rec_end_dt=stg.edw_rec_end_dt
  GROUP BY 1,2,3,4)a;


update tgt 
FROM CONTEXT_CCPA_TRG_DB.dim_loyalty_customer_a tgt,CONTEXT_CCPA_STG_DB.stg_ccpa_dim_loyalty_customer_a_eidmid stg
set mid=stg.mid
,EID=stg.EID
,edw_update_dttm=current_timestamp(0)
,edw_batch_id=(select max(edw_batch_id) from PROC_DB.proc_cntrl_batch_detail where proj_name='edw_out_extracts' AND src_stream_name='ccpa' AND batch_status_cd='1')
where tgt.dim_loyalty_cust_sk=stg.dim_loyalty_cust_sk
  AND tgt.cust_sk=stg.cust_sk
  AND tgt.edw_rec_begin_dt=stg.edw_rec_begin_dt
  AND tgt.edw_rec_end_dt=stg.edw_rec_end_dt;
  

 UPDATE stg FROM CONTEXT_CCPA_STG_DB.stg_count_dim_loyalty_customer_a_eid_ccpa  stg,
(
SELECT stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,count(*) as cnt FROM
CONTEXT_CCPA_TRG_VB.dim_loyalty_customer_a  tgt INNER JOIN CONTEXT_CCPA_STG_DB.stg_ccpa_dim_loyalty_customer_a_eidmid stg
ON tgt.dim_loyalty_cust_sk=stg.dim_loyalty_cust_sk
  AND tgt.cust_sk=stg.cust_sk
  AND tgt.edw_rec_begin_dt=stg.edw_rec_begin_dt
  AND tgt.edw_rec_end_dt=stg.edw_rec_end_dt
  AND tgt.edw_batch_id=(select max(edw_batch_id) from PROC_DB.proc_cntrl_batch_detail where proj_name='edw_out_extracts' AND src_stream_name='ccpa' AND batch_status_cd='1')
	GROUP BY 1,2,3,4) aft_rec
	SET AFTER_DEL_CNT=aft_rec.cnt
	where stg.TKT_NBR=aft_rec.TKT_NBR
AND stg.TKT_LINE_SEQ=aft_rec.TKT_LINE_SEQ
AND stg.tkt_open_dt=aft_rec.tkt_open_dt
AND stg.reqst_type_cd=aft_rec.reqst_type_cd
AND stg.DB_NAME='CONTEXT_CCPA_TRG_DB'
AND stg.TBL_NAME='dim_loyalty_customer_a_eid'
AND stg.SUBJECT_AREA='SUB_AREA';


insert into CONTEXT_CCPA_IDL_DB.ccpa_rtd_log
(
subject_area,  
db_name,
tbl_name, 
tkt_nbr,
tkt_line_seq,
tkt_open_dt, 
reqst_type_cd,
del_rec_cnt,
rec_del_dt,
stat_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
select
a.subject_area,
a.db_name,
a.tbl_name,
a.tkt_nbr,
a.tkt_line_seq,
a.tkt_open_dt,
a.reqst_type_cd,
a.del_rec_cnt,
a.rec_del_dt,
a.stat_cd,
a.edw_create_dttm,
a.edw_update_dttm,
a.edw_batch_id
from
(
select
stg_ccpa.subject_area as subject_area
,stg_ccpa.db_name as db_name
,stg_ccpa.tbl_name as tbl_name
,stg_ccpa.tkt_nbr as tkt_nbr
,stg_ccpa.tkt_line_seq as tkt_line_seq
,stg_ccpa.tkt_open_dt as tkt_open_dt
,stg_ccpa.reqst_type_cd as reqst_type_cd
,stg_ccpa.stg_tbl_rec_count as del_rec_cnt
,current_date as rec_del_dt
, case when (stg_ccpa.before_del_cnt = stg_ccpa.after_del_cnt) then 'S' else 'E' end as stat_cd
,current_date as edw_reqst_complete_dt
,cast(current_timestamp(0) as timestamp(0) format 'yyyy-mm-ddbhh:mi:ss') as edw_create_dttm
,cast(current_timestamp(0) as timestamp(0) format 'yyyy-mm-ddbhh:mi:ss') as edw_update_dttm
,(select max(edw_batch_id) from PROC_DB.proc_cntrl_batch_detail where proj_name = 'edw_out_extracts' 
and src_stream_name = 'ccpa' and batch_status_cd = '1') as edw_batch_id
 from CONTEXT_CCPA_STG_DB.stg_count_dim_loyalty_customer_a_eid_ccpa stg_ccpa inner join 
  (select 
subject_area as subject_area
,db_name as db_name
,tbl_name as tbl_name
,sum(stg_tbl_rec_count) as del_count
from CONTEXT_CCPA_STG_DB.stg_count_dim_loyalty_customer_a_eid_ccpa
where db_name='CONTEXT_CCPA_TRG_DB'
and tbl_name='dim_loyalty_customer_a_eid'
and subject_area='SUB_AREA'
group by 1,2,3 ) del_cnt
 on 
 stg_ccpa.subject_area=del_cnt.subject_area
 and stg_ccpa.db_name=del_cnt.db_name
 and stg_ccpa.tbl_name=del_cnt.tbl_name)a;

begin transaction;

UPDATE ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}
FROM ${pTD_DB_CIF}.${pTD_DB_SCHEMA}.${pTABLE2} stg
SET 
   loyalty_cust_sk = stg.loyalty_cust_sk
,  loyalty_dim_cust_sk = stg.loyalty_dim_cust_sk
,  loyalty_eid_dim_cust_sk = stg.loyalty_eid_dim_cust_sk
,  loyalty_eid_cust_sk = stg.loyalty_eid_cust_sk
,  loyalty_mid_dim_cust_sk = stg.loyalty_mid_dim_cust_sk
,  loyalty_mid_cust_sk = stg.loyalty_mid_cust_sk
,  edw_update_dttm = stg.edw_update_dttm
,  edw_batch_id = stg.edw_batch_id
WHERE ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}.loyalty_mbr_id = stg.loyalty_mbr_id
AND ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}.src_begin_dt = stg.src_begin_dt
AND ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}.annual_pnt_cap_yr = stg.annual_pnt_cap_yr
AND  stg.edw_batch_id =$pEDW_BATCH_ID;


INSERT INTO ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}
(
loyalty_mbr_id ,               
src_begin_dt,                  
src_end_dt,                    
annual_pnt_cap_yr ,
cap_accumulated_points,                 
cap_accumulated_dlrs,
loyalty_dim_cust_sk,           
loyalty_cust_sk ,              
loyalty_eid_dim_cust_sk,       
loyalty_eid_cust_sk,           
loyalty_mid_dim_cust_sk,       
loyalty_mid_cust_sk,           
edw_create_dttm ,              
edw_update_dttm,               
edw_batch_id                  
)
SELECT
loyalty_mbr_id  ,              
src_begin_dt,             
src_end_dt ,            
annual_pnt_cap_yr ,
cap_accumulated_points,        
cap_accumulated_dlrs,
loyalty_dim_cust_sk,          
loyalty_cust_sk ,         
loyalty_eid_dim_cust_sk,
loyalty_eid_cust_sk,
loyalty_mid_dim_cust_sk,
loyalty_mid_cust_sk,
edw_create_dttm,
edw_update_dttm,
edw_batch_id                  
FROM ${pTD_DB_CIF}.${pTD_DB_SCHEMA}.${pTABLE2}  stg
WHERE NOT EXISTS 
(
	SELECT loyalty_mbr_id, src_begin_dt
	FROM ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}  tgt
	WHERE tgt.loyalty_mbr_id = stg.loyalty_mbr_id
	AND tgt.src_begin_dt = stg.src_begin_dt
        AND tgt.annual_pnt_cap_yr = stg.annual_pnt_cap_yr
);

commit;


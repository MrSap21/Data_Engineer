MERGE INTO ${pTD_DB_IDL}.${pTD_DB_CIF}.${pTD_TGT_TABLE}
USING ${pTD_STAGE}.${pTD_DB_CIF}.${pTABLE_NAME_1} stg
ON  ${pTD_DB_IDL}.${pTD_DB_CIF}.${pTD_TGT_TABLE}.call_cmnt_id = stg.call_cmnt_id

WHEN MATCHED THEN
UPDATE
SET 
loyalty_mbr_id = stg.loyalty_mbr_id
, loyalty_dim_cust_sk = stg.loyalty_dim_cust_sk
, loyalty_cust_sk = stg.loyalty_cust_sk
, loyalty_eid_dim_cust_sk = stg.loyalty_eid_dim_cust_sk
, loyalty_eid_cust_sk = stg.loyalty_eid_cust_sk
, loyalty_mid_dim_cust_sk = stg.loyalty_mid_dim_cust_sk
, loyalty_mid_cust_sk = stg.loyalty_mid_cust_sk
, call_cmnt_type = stg.call_cmnt_type
, call_cmnt_subtype = stg.call_cmnt_subtype
, call_cmnt_txt = stg.call_cmnt_txt
, postd_dt = stg.postd_dt
, edw_update_dttm = stg.edw_update_dttm
, edw_batch_id = stg.edw_batch_id

WHEN NOT MATCHED THEN
INSERT
(
call_cmnt_id
, loyalty_mbr_id
, loyalty_dim_cust_sk
, loyalty_cust_sk
, loyalty_eid_dim_cust_sk
, loyalty_eid_cust_sk
, loyalty_mid_dim_cust_sk
, loyalty_mid_cust_sk
, call_cmnt_type
, call_cmnt_subtype
, call_cmnt_txt
, postd_dt
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
VALUES
(
stg.call_cmnt_id
, stg.loyalty_mbr_id
, stg.loyalty_dim_cust_sk
, stg.loyalty_cust_sk
, stg.loyalty_eid_dim_cust_sk
, stg.loyalty_eid_cust_sk
, stg.loyalty_mid_dim_cust_sk
, stg.loyalty_mid_cust_sk
, stg.call_cmnt_type
, stg.call_cmnt_subtype
, stg.call_cmnt_txt
, stg.postd_dt
, stg.edw_create_dttm
, stg.edw_update_dttm
, stg.edw_batch_id
);

CREATE OR REPLACE temporary TABLE $db_param_staging.$schema3.LNK_TO_CUST AS
(SELECT cust_src_sk cust_sk
       ,edw_update_dttm
          ,mbr_stat_cd
FROM $db_param_master_data.$schema1.$table1
WHERE edw_rec_end_dt= CAST('9999-12-31' AS DATE)
AND cust_src_cd = 'LR'
AND cdi_msg_type_cd = '2')
;

CREATE OR REPLACE temporary TABLE $db_param_staging.$schema3.DIST_CUST_SK AS
(
select cust_sk FROM $db_param_staging.$schema2.$table2 stg1
                  WHERE stg1.edw_rec_end_dt = CAST('9999-12-31' AS DATE)
                  AND stg1.cust_sk <> -1
                  GROUP BY 1
                  UNION 
                  select cust_sk FROM $db_param_staging.$schema3.$table3 
                  WHERE cust_sk <> -1
                  GROUP BY 1
                  UNION
                  select cust_src_sk cust_sk FROM $db_param_staging.$schema1.$table4 
                        WHERE cust_src_cd = 'LR' AND edw_rec_end_dt = CAST('9999-12-31' AS DATE)
                        AND cust_src_sk <> -1
                  GROUP BY 1
)
;

CREATE OR REPLACE temporary TABLE $db_param_staging.$schema3.DIM_LOYALTY_CUST_DIM_DELTA AS
(
SELECT
        ly.dim_loyalty_cust_sk,
        ly.cust_sk AS loyalty_cust_sk,
        CASE WHEN ly.edw_rec_begin_dt IS NULL THEN to_date(NULL  ::VARCHAR(30), 'YYYYMMDD' )ELSE ly.edw_rec_begin_dt END AS "EDW_REC_BEGIN_DT",
        CASE WHEN ly.edw_rec_end_dt IS NULL THEN to_date(NULL  ::VARCHAR(30), 'YYYYMMDD' )ELSE ly.edw_rec_end_dt END AS "EDW_REC_END_DT", 
        CASE WHEN dm.eid='#' THEN NULL ELSE dm.eid END AS "EID",
        CASE WHEN dm.mid='#' THEN NULL ELSE dm.mid END AS "MID",
        CASE WHEN cust.cust_src_id='#' THEN NULL ELSE SUBSTR(cust.cust_src_id,1,20) END AS "LOYALTY_MBR_ID",  
        cust.src_sys_cd AS src_sys_cd, 
        lnk.mbr_stat_cd,
        cust.last_name,
        cust.first_name,
        cust.middle_name,
        cust.name_suffix,
        cust.brth_dt, 
        CASE WHEN cust.gndr_cd='Unknown' or cust.gndr_cd='Male' or cust.gndr_cd='Female' THEN SUBSTR(cust.gndr_cd,1,1) ELSE cust.gndr_cd END AS "GNDR_CD",
        cust.household_id,
        pr.addr_line_1 AS perm_addr_line_1 ,
        pr.addr_line_2 AS perm_addr_line_2,
        pr.city AS perm_city, 
        pr.state_cd AS perm_state_cd,
        pr.zip_cd_4 AS perm_zip_cd_4, 
        pr.zip_cd_5 AS perm_zip_cd_5,
        pr.cntry AS perm_cntry,
        pr.latitude AS perm_latitude,
        pr.longitude AS perm_longitude,
        pr.dpv_ind_cd AS permnt_dpv_ind_cd, 
        pr.dpv_footnote AS permnt_dpv_footnote,
        pr.ncoa_nixie_footnote AS permnt_ncoa_nixie_footnote,
        wr.addr_line_1 AS work_addr_line_1 ,
        wr.addr_line_2 AS work_addr_line_2,
        wr.city AS work_city, 
        wr.state_cd AS work_state_cd,
        wr.zip_cd_4 AS work_zip_cd_4, 
        wr.zip_cd_5 AS work_zip_cd_5,
        wr.cntry AS work_cntry,
        wr.latitude AS work_latitude,
        wr.longitude AS work_longitude,
        wr.dpv_ind_cd AS work_dpv_ind_cd,
        wr.dpv_footnote AS work_dpv_footnote,
        wr.ncoa_nixie_footnote AS work_ncoa_nixie_footnote,
        sn.addr_line_1 AS secn_addr_line_1 ,
        sn.addr_line_2 AS secn_addr_line_2,
        sn.city AS secn_city, 
        sn.state_cd AS secn_state_cd,
        sn.zip_cd_4 AS secn_zip_cd_4, 
        sn.zip_cd_5 AS secn_zip_cd_5,
        sn.cntry AS secn_cntry,
        sn.latitude AS secn_latitude,
        sn.longitude AS secn_longitude,
        sn.dpv_ind_cd AS scndry_dpv_ind_cd, 
        sn.dpv_footnote AS scndry_dpv_footnote,  
        sn.ncoa_nixie_footnote AS scndry_ncoa_nixie_footnote,
        hp.comm_val AS home_phone,       
        cp.comm_val AS cell_phone,
        wp.comm_val AS work_phone,
        em.comm_val AS email_address,
        NULL AS primary_cntc, 
        NULL AS scndry_cntc, 
        NULL AS tertiary_cntc,
        CASE WHEN enr.enrl_dt IS NULL THEN to_date(NULL ::VARCHAR(30), 'YYYYMMDD') ELSE enr.enrl_dt END AS "ENRL_DT",
        enr.enrl_chnnl,        
        enr.store_nbr,  
        enr.register_nbr,
        enr.rfn_val,
        lm.txt_msg_ind,
        lm.do_not_call_ind,
        lm.do_not_mail_ind,
        lm.do_not_eml_ind,
        lm.suspcs_mbr_ind,
        lm.txt_msg_ind_create_dt,
        lm.do_not_call_ind_create_dt,
        lm.do_not_mail_ind_create_dt,
        lm.do_not_eml_ind_create_dt,
        lm.min_age_ind,
        lm.min_age_ind_create_dt,
        lm.mywag_consent_ind,
        lm.mywag_consent_ind_create_dt,
        lm.sms_validat_stat,
        lm.sms_validat_stat_create_dt,
        lm.eml_validat_stat,
        lm.eml_validat_stat_create_dt,
        lm.dgtl_receipt_opt,
        lm.dgtl_receipt_opt_create_dt,
        lm.src_create_dttm,
        lm.src_update_dttm,		
        ly.edw_create_dttm,
        ly.edw_update_dttm,
        ly.edw_batch_id
FROM (SELECT lyl.* FROM $db_param_misc.$schema2.$table5 lyl
      INNER JOIN $db_param_staging.$schema3.DIST_CUST_SK stg
      ON    lyl.cust_sk = stg.cust_sk
     ) ly
INNER JOIN $db_param_master_data.$schema1.$table6 dm 
       ON  ly.dim_cust_sk =dm.dim_cust_sk 
       AND  ly.cust_sk = dm.cust_sk 
INNER JOIN $db_param_master_data.$schema1.$table7 cust
       ON dm.cust_chng_sk = cust.cust_chng_sk
   AND dm.cust_sk = cust.cust_sk
LEFT OUTER JOIN $db_param_staging.$schema3.LNK_TO_CUST lnk
          ON lnk.cust_sk=dm.cust_sk
LEFT OUTER JOIN $db_param_marketing.$schema3.$table8 enr
       ON  enr.cust_sk = ly.cust_sk
       AND cust.src_sys_cd = enr.src_sys_cd
       LEFT OUTER JOIN $db_param_master_data.$schema1.$table9 pr                    
    ON dm. cust_permnt_addr_chng_sk   = pr.cust_addr_chng_sk   
  AND dm.cust_sk = pr.cust_sk
LEFT OUTER JOIN $db_param_master_data.$schema1.$table9 wr           
    ON dm.cust_work_addr_chng_sk = wr.cust_addr_chng_sk 
  AND dm.cust_sk = wr.cust_sk   
LEFT OUTER JOIN $db_param_master_data.$schema1.$table9 sn           
    ON dm. cust_scndry_addr_chng_sk = sn.cust_addr_chng_sk 
   AND dm.cust_sk = sn.cust_sk     
LEFT OUTER JOIN $db_param_marketing.$schema3.$table01 lm
     ON  ly.loyalty_cust_ref_chng_sk = lm.loyalty_cust_ref_chng_sk 
  AND lm.cust_sk = ly.cust_sk 
LEFT OUTER JOIN $db_param_master_data.$schema1.$table02 hp           
    ON dm.cust_home_cntc_chng_sk = hp.cust_cntc_chnnl_chng_sk 
   AND dm.cust_sk = hp.cust_sk
LEFT OUTER JOIN $db_param_master_data.$schema1.$table02 wp           
    ON dm.cust_work_cntc_chng_sk = wp.cust_cntc_chnnl_chng_sk 
   AND dm.cust_sk = wp.cust_sk
LEFT OUTER JOIN $db_param_master_data.$schema1.$table02 cp           
    ON dm.cust_cell_cntc_chng_sk = cp.cust_cntc_chnnl_chng_sk 
   AND dm.cust_sk = cp.cust_sk
LEFT OUTER JOIN $db_param_master_data.$schema1.$table02 em           
 ON  dm.cust_mail_cntc_chng_sk = em.cust_cntc_chnnl_chng_sk
   AND dm.cust_sk = em.cust_sk
LEFT OUTER JOIN $db_param_marketing.$schema3.$table03 ac 
   ON ly.loyalty_cust_link_acct_chng_sk = ac.loyalty_cust_link_acct_chng_sk 
  AND ly.cust_sk = ac.cust_sk
) 
;

MERGE INTO $db_param_marketing.$schema3.$table04
USING(SELECT
dim_loyalty_cust_sk AS dim_ly_cust_sk,
loyalty_cust_sk,
edw_rec_begin_dt,
edw_rec_end_dt,
eid,
mid,
loyalty_mbr_id,
src_sys_cd,
mbr_stat_cd,
last_name,
first_name,
middle_name,
name_suffix,
brth_dt,
gndr_cd,
household_id,
perm_addr_line_1,
perm_addr_line_2,
perm_city,
perm_state_cd,
perm_zip_cd_4,
perm_zip_cd_5,
perm_cntry,
perm_latitude,
perm_longitude,
permnt_dpv_ind_cd,
permnt_dpv_footnote,
permnt_ncoa_nixie_footnote,
work_addr_line_1,
work_addr_line_2,
work_city,
work_state_cd,
work_zip_cd_4,
work_zip_cd_5,
work_cntry,
work_latitude,
work_longitude,
work_dpv_ind_cd,
work_dpv_footnote,
work_ncoa_nixie_footnote,
secn_addr_line_1,
secn_addr_line_2,
secn_city,
secn_state_cd,
secn_zip_cd_4,
secn_zip_cd_5,
secn_cntry,
secn_latitude,
secn_longitude,
scndry_dpv_ind_cd,
scndry_dpv_footnote,
scndry_ncoa_nixie_footnote,
home_phone,
cell_phone,
work_phone,
email_address,
primary_cntc,
scndry_cntc,
tertiary_cntc,
enrl_dt,
enrl_chnnl,
store_nbr,
register_nbr,
rfn_val,
txt_msg_ind,
do_not_call_ind,
do_not_mail_ind,
do_not_eml_ind,
suspcs_mbr_ind,
edw_create_dttm,
edw_update_dttm,
edw_batch_id,
txt_msg_ind_create_dt,
do_not_call_ind_create_dt,
do_not_mail_ind_create_dt,
do_not_eml_ind_create_dt,
min_age_ind,
min_age_ind_create_dt,
mywag_consent_ind,
mywag_consent_ind_create_dt,
sms_validat_stat,
sms_validat_stat_create_dt,
eml_validat_stat,
eml_validat_stat_create_dt,
dgtl_receipt_opt,
dgtl_receipt_opt_create_dt,
src_create_dttm,
src_update_dttm
FROM $db_param_staging.$schema3.DIM_LOYALTY_CUST_DIM_DELTA
)stg
ON
dim_loyalty_cust_sk=stg.dim_ly_cust_sk AND
cust_sk=stg.loyalty_cust_sk
WHEN MATCHED THEN
UPDATE
SET	
edw_rec_begin_dt=stg.edw_rec_begin_dt,
edw_rec_end_dt=stg.edw_rec_end_dt,
eid=stg.eid,
mid=stg.mid,
loyalty_mbr_id=stg.loyalty_mbr_id,
src_sys_cd=stg.src_sys_cd,
mbr_stat_cd=stg.mbr_stat_cd,
last_name=stg.last_name,
first_name=stg.first_name,
middle_name=stg.middle_name,
name_suffix=stg.name_suffix,
brth_dt=stg.brth_dt,
gndr_cd=stg.gndr_cd,
household_id=stg.household_id,
permnt_addr_line_1=stg.perm_addr_line_1,
permnt_addr_line_2=stg.perm_addr_line_2,
permnt_city=stg.perm_city,
permnt_state_cd=stg.perm_state_cd,
permnt_zip_cd_4=stg.perm_zip_cd_4,
permnt_zip_cd_5=stg.perm_zip_cd_5,
permnt_cntry=stg.perm_cntry,
permnt_latitude=stg.perm_latitude,
permnt_longitude=stg.perm_longitude,
permnt_dpv_ind_cd=stg.permnt_dpv_ind_cd,
permnt_dpv_footnote=stg.permnt_dpv_footnote,
permnt_ncoa_nixie_footnote=stg.permnt_ncoa_nixie_footnote,
work_addr_line_1=stg.work_addr_line_1,
work_addr_line_2=stg.work_addr_line_2,
work_city=stg.work_city,
work_state_cd=stg.work_state_cd,
work_zip_cd_4=stg.work_zip_cd_4,
work_zip_cd_5=stg.work_zip_cd_5,
work_cntry=stg.work_cntry,
work_latitude=stg.work_latitude,
work_longitude=stg.work_longitude,
work_dpv_ind_cd=stg.work_dpv_ind_cd,
work_dpv_footnote=stg.work_dpv_footnote,
work_ncoa_nixie_footnote=stg.work_ncoa_nixie_footnote,
scndry_addr_line_1=stg.secn_addr_line_1,
scndry_addr_line_2=stg.secn_addr_line_2,
scndry_city=stg.secn_city,
scndry_state_cd=stg.secn_state_cd,
scndry_zip_cd_4=stg.secn_zip_cd_4,
scndry_zip_cd_5=stg.secn_zip_cd_5,
scndry_cntry=stg.secn_cntry,
scndry_latitude=stg.secn_latitude,
scndry_longitude=stg.secn_longitude,
scndry_dpv_ind_cd=stg.scndry_dpv_ind_cd,
scndry_dpv_footnote=stg.scndry_dpv_footnote,
scndry_ncoa_nixie_footnote=stg.scndry_ncoa_nixie_footnote,
home_phone=stg.home_phone,
cell_phone=stg.cell_phone,
work_phone=stg.work_phone,
eml_addr=stg.email_address,
primary_cntc=stg.primary_cntc,
scndry_cntc=stg.scndry_cntc,
tertiary_cntc=stg.tertiary_cntc,
enrl_dt=stg.enrl_dt,
enrl_channel=stg.enrl_chnnl,
store_nbr=stg.store_nbr,
register_nbr=stg.register_nbr,
rfn_val=stg.rfn_val,
txt_msg_ind=stg.txt_msg_ind,
do_not_call_ind=stg.do_not_call_ind,
do_not_mail_ind=stg.do_not_mail_ind,
do_not_eml_ind=stg.do_not_eml_ind,
suspcs_mbr_ind=stg.suspcs_mbr_ind,
edw_create_dttm=stg.edw_create_dttm,
edw_update_dttm=stg.edw_update_dttm,
edw_batch_id=$pEDW_BATCH_ID,
txt_msg_ind_create_dt=stg.txt_msg_ind_create_dt,
do_not_call_ind_create_dt=stg.do_not_call_ind_create_dt,
do_not_mail_ind_create_dt=stg.do_not_mail_ind_create_dt,
do_not_eml_ind_create_dt=stg.do_not_eml_ind_create_dt,
min_age_ind=stg.min_age_ind,
min_age_ind_create_dt=stg.min_age_ind_create_dt,
mywag_consent_ind=stg.mywag_consent_ind,
mywag_consent_ind_create_dt=stg.mywag_consent_ind_create_dt,
sms_validat_stat=stg.sms_validat_stat,
sms_validat_stat_create_dt=stg.sms_validat_stat_create_dt,
eml_validat_stat=stg.eml_validat_stat,
eml_validat_stat_create_dt=stg.eml_validat_stat_create_dt,
dgtl_receipt_opt=stg.dgtl_receipt_opt,
dgtl_receipt_opt_create_dt=stg.dgtl_receipt_opt_create_dt,
src_create_dttm=stg.src_create_dttm,
src_update_dttm=stg.src_update_dttm
WHEN NOT MATCHED THEN
INSERT
(
dim_loyalty_cust_sk
,cust_sk
,edw_rec_begin_dt
,edw_rec_end_dt
,eid
,mid
,loyalty_mbr_id
,src_sys_cd
,mbr_stat_cd
,last_name
,first_name
,middle_name
,name_suffix
,brth_dt
,gndr_cd
,household_id
,permnt_addr_line_1
,permnt_addr_line_2
,permnt_city
,permnt_state_cd
,permnt_zip_cd_4
,permnt_zip_cd_5
,permnt_cntry
,permnt_latitude
,permnt_longitude
,permnt_dpv_ind_cd
,permnt_dpv_footnote
,permnt_ncoa_nixie_footnote
,work_addr_line_1
,work_addr_line_2
,work_city
,work_state_cd
,work_zip_cd_4
,work_zip_cd_5
,work_cntry
,work_latitude
,work_longitude
,work_dpv_ind_cd
,work_dpv_footnote
,work_ncoa_nixie_footnote
,scndry_addr_line_1
,scndry_addr_line_2
,scndry_city
,scndry_state_cd
,scndry_zip_cd_4
,scndry_zip_cd_5
,scndry_cntry
,scndry_latitude
,scndry_longitude
,scndry_dpv_ind_cd
,scndry_dpv_footnote
,scndry_ncoa_nixie_footnote
,home_phone
,cell_phone
,work_phone
,eml_addr
,primary_cntc
,scndry_cntc
,tertiary_cntc
,enrl_dt
,enrl_channel
,store_nbr
,register_nbr
,rfn_val
,txt_msg_ind
,do_not_call_ind
,do_not_mail_ind
,do_not_eml_ind
,suspcs_mbr_ind
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
,txt_msg_ind_create_dt
,do_not_call_ind_create_dt
,do_not_mail_ind_create_dt
,do_not_eml_ind_create_dt
,min_age_ind
,min_age_ind_create_dt
,mywag_consent_ind
,mywag_consent_ind_create_dt
,sms_validat_stat
,sms_validat_stat_create_dt
,eml_validat_stat
,eml_validat_stat_create_dt
,dgtl_receipt_opt
,dgtl_receipt_opt_create_dt
,src_create_dttm
,src_update_dttm)
VALUES
(
stg.dim_ly_cust_sk,
stg.loyalty_cust_sk,
stg.edw_rec_begin_dt,
stg.edw_rec_end_dt,
stg.eid,
stg.mid,
stg.loyalty_mbr_id,
stg.src_sys_cd,
stg.mbr_stat_cd,
stg.last_name,
stg.first_name,
stg.middle_name,
stg.name_suffix,
stg.brth_dt,
stg.gndr_cd,
stg.household_id,
stg.perm_addr_line_1,
stg.perm_addr_line_2,
stg.perm_city,
stg.perm_state_cd,
stg.perm_zip_cd_4,
stg.perm_zip_cd_5,
stg.perm_cntry,
stg.perm_latitude,
stg.perm_longitude,
stg.permnt_dpv_ind_cd,
stg.permnt_dpv_footnote,
stg.permnt_ncoa_nixie_footnote,
stg.work_addr_line_1,
stg.work_addr_line_2,
stg.work_city,
stg.work_state_cd,
stg.work_zip_cd_4,
stg.work_zip_cd_5,
stg.work_cntry,
stg.work_latitude,
stg.work_longitude,
stg.work_dpv_ind_cd,
stg.work_dpv_footnote,
stg.work_ncoa_nixie_footnote,
stg.secn_addr_line_1,
stg.secn_addr_line_2,
stg.secn_city,
stg.secn_state_cd,
stg.secn_zip_cd_4,
stg.secn_zip_cd_5,
stg.secn_cntry,
stg.secn_latitude,
stg.secn_longitude,
stg.scndry_dpv_ind_cd,
stg.scndry_dpv_footnote,
stg.scndry_ncoa_nixie_footnote,
stg.home_phone,
stg.cell_phone,
stg.work_phone,
stg.email_address,
stg.primary_cntc,
stg.scndry_cntc,
stg.tertiary_cntc,
stg.enrl_dt,
stg.enrl_chnnl,
stg.store_nbr,
stg.register_nbr,
stg.rfn_val,
stg.txt_msg_ind,
stg.do_not_call_ind,
stg.do_not_mail_ind,
stg.do_not_eml_ind,
stg.suspcs_mbr_ind,
stg.edw_create_dttm,
stg.edw_update_dttm, 
$pEDW_BATCH_ID,
stg.txt_msg_ind_create_dt,
stg.do_not_call_ind_create_dt,
stg.do_not_mail_ind_create_dt,
stg.do_not_eml_ind_create_dt,
stg.min_age_ind,
stg.min_age_ind_create_dt,
stg.mywag_consent_ind,
stg.mywag_consent_ind_create_dt,
stg.sms_validat_stat,
stg.sms_validat_stat_create_dt,
stg.eml_validat_stat,
stg.eml_validat_stat_create_dt,
stg.dgtl_receipt_opt,
stg.dgtl_receipt_opt_create_dt,
stg.src_create_dttm,
stg.src_update_dttm
);
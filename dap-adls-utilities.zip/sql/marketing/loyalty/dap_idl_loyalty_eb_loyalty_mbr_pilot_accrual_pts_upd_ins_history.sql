
UPDATE ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}
from ${pTD_DB_CIF}.${pTD_DB_SCHEMA}.${pTABLE2} as stg
SET 
      src_end_dt = stg.src_begin_dt-1 ,
      edw_update_dttm = current_timestamp(0),
      edw_batch_id = stg.edw_batch_id             
where 
    ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}.loyalty_mbr_id = stg.loyalty_mbr_id
AND ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}.annual_pnt_cap_yr = stg.annual_pnt_cap_yr 
AND ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}.src_begin_dt < stg.src_begin_dt 
AND ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTABLE1}.src_end_dt = '9999-12-31';




DELETE FROM ${db_param_consumption}.${pPRDSTGCIF_DB}.$TABLE_NAME_1;

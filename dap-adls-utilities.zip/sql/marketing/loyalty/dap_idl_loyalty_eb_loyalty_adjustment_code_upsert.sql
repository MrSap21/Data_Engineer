MERGE INTO ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTGTTable}
USING ${pTD_DB_CIF}.${pTD_DB_SCHEMA}.${pTABLE1} stg
ON  ${pTD_DB_IDL}.${pTD_DB_SCHEMA}.${pTGTTable}.loyalty_adj_type_cd = stg.loyalty_adj_type_cd

WHEN MATCHED THEN
UPDATE
SET 
loyalty_adj_cd_desc =stg.loyalty_adj_cd_desc ,
sys_adj_ind =stg.sys_adj_ind ,
edw_update_dttm =current_timestamp(0),
edw_batch_id =stg.edw_batch_id

WHEN NOT MATCHED THEN
INSERT 
(
loyalty_adj_type_cd ,
loyalty_adj_cd_desc ,
sys_adj_ind ,
edw_create_dttm ,
edw_update_dttm ,
edw_batch_id 
)
values
(
stg.loyalty_adj_type_cd ,
stg.loyalty_adj_cd_desc ,
stg.sys_adj_ind ,
stg.edw_create_dttm ,
stg.edw_update_dttm ,
stg.edw_batch_id 
);

insert into $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2
(     
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt)
select
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt
from
(
Select 
  before_rcd_cnt.tkt_nbr,
  before_rcd_cnt.tkt_line_seq,
  before_rcd_cnt.tkt_open_dt,
  before_rcd_cnt.reqst_type_cd,
  '$pSUB_AREA' as subject_area,
  '$pDB_NAME' as db_name,
  '$pTGT_TABLE_NAME' as tbl_name,
  Null as after_del_cnt,
  before_rcd_cnt.cnt as stg_tbl_rec_count,
  before_rcd_cnt.cnt as before_del_cnt from
(Select stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,count(*) as cnt
from
$pTGT_DB_NAME.$pDB_NAME.$pTGT_TABLE_NAME tgt
inner join $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 stg
on tgt.loyalty_cust_sk=stg.loyalty_cust_sk
and tgt.loyalty_src_sys_cd=stg.loyalty_src_sys_cd
and tgt.loyalty_vcd_prog_id=stg.loyalty_vcd_prog_id
and tgt.loyalty_composite_type_cd=stg.loyalty_composite_type_cd
and tgt.loyalty_msg_type_cd=stg.loyalty_msg_type_cd
group by 1,2,3,4
) before_rcd_cnt)AAA;



update $pTGT_DB_NAME.$pDB_NAME.$pTGT_TABLE_NAME tgt
set household_id=null,first_name=null,last_name=null,orig_addr_line_1=null,orig_addr_line_2=null,orig_city=null,orig_state=null, 
orig_zip_cd_5=null,orig_zip_cd_4=null,phone=null,eml_addr=null,new_addr_line_1=null,new_addr_line_2=null,new_city= null, 
new_state=null,new_zip_cd_5=null,new_zip_cd_4=null,edw_update_dttm=current_timestamp(0),
edw_batch_id=$pEDW_BATCH_ID
from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1  stg
where tgt.loyalty_cust_sk=stg.loyalty_cust_sk
and tgt.loyalty_src_sys_cd=stg.loyalty_src_sys_cd
and tgt.loyalty_vcd_prog_id=stg.loyalty_vcd_prog_id
and tgt.loyalty_composite_type_cd=stg.loyalty_composite_type_cd
and tgt.loyalty_msg_type_cd=stg.loyalty_msg_type_cd ;
		 
		 


update $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2 stg_cnt_tbl from
(Select stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,count(*) as cnt
  		from
  		$pTGT_DB_NAME.$pDB_NAME.$pTGT_TABLE_NAME tgt
  		 inner join $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 stg
  		 on tgt.loyalty_cust_sk=stg.loyalty_cust_sk
  		 and tgt.loyalty_src_sys_cd=stg.loyalty_src_sys_cd
  		 and tgt.loyalty_vcd_prog_id=stg.loyalty_vcd_prog_id
  		 and tgt.loyalty_composite_type_cd=stg.loyalty_composite_type_cd
  		 and tgt.loyalty_msg_type_cd=stg.loyalty_msg_type_cd
  		 and tgt.loyalty_src_sys_cd='LR'
  		 and edw_batch_id= $pEDW_BATCH_ID
  		 group by 1,2,3,4
) after_rcd_cnt
set after_del_cnt=after_rcd_cnt.cnt
where stg_cnt_tbl.tkt_nbr=after_rcd_cnt.tkt_nbr
and stg_cnt_tbl.tkt_line_seq=after_rcd_cnt.tkt_line_seq
AND db_name = '$pDB_NAME'
AND tbl_name = '$pTGT_TABLE_NAME'
AND subject_area = '$pSUB_AREA';





insert into $pCCPA_DB_NAME.$pCCPA_SCHEMA.$pTABLE_NAME4
(
subject_area,
db_name,
tbl_name,
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
del_rec_cnt,
rec_del_dt,
stat_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
select
a.subject_area, 
a.db_name,
a.tbl_name,
a.tkt_nbr,
a.tkt_line_seq,
a.tkt_open_dt, 
a.reqst_type_cd,
a.del_rec_cnt,
a.rec_del_dt,
a.stat_cd,
a.edw_create_dttm,
a.edw_update_dttm,
a.edw_batch_id
from
(
select
stg_ccpa.subject_area as subject_area
,stg_ccpa.db_name as db_name
,stg_ccpa.tbl_name as tbl_name
,stg_ccpa.tkt_nbr as tkt_nbr
,stg_ccpa.tkt_line_seq as tkt_line_seq
,stg_ccpa.tkt_open_dt as tkt_open_dt
,stg_ccpa.reqst_type_cd as reqst_type_cd
,stg_ccpa.stg_tbl_rec_count as del_rec_cnt
,current_date as rec_del_dt
, case when (stg_ccpa.before_del_cnt = stg_ccpa.after_del_cnt) THEN 'S' ELSE 'E' END AS stat_cd
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
,$pEDW_BATCH_ID as edw_batch_id
from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2 stg_ccpa inner join
(
select 
subject_area as subject_area
,db_name as db_name
,tbl_name as tbl_name
,sum(stg_tbl_rec_count) as del_count
from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2
where db_name = '$pDB_NAME'
AND tbl_name = '$pTGT_TABLE_NAME'
AND subject_area = '$pSUB_AREA'
group by 1,2,3 ) del_cnt
on 
stg_ccpa.subject_area=del_cnt.subject_area
and stg_ccpa.db_name=del_cnt.db_name
and stg_ccpa.tbl_name=del_cnt.tbl_name
)A;



INSERT INTO ${db_param_staging}.${pProcess_DB}.$TABLE_NAME_1 
(
       cust_sk , 
       dim_cust_sk , 
       loyalty_cust_ref_chng_sk , 
       loyalty_cust_link_acct_chng_sk , 
       edw_maxupd_dttm 
) 
SELECT 
       cust_sk , 
       COALESCE(dim_cust_sk , -1) as dim_cust_sk, 
       COALESCE(loyalty_cust_ref_chng_sk , -1) as loyalty_cust_ref_chng_sk, 
       COALESCE(loyalty_cust_link_acct_chng_sk , -1) as loyalty_cust_link_acct_chng_sk, 
       final_update_dttm 
FROM 
( 

SELECT 
       custxref.cust_sk AS cust_sk , 
       custxref.dim_cust_sk AS dim_cust_sk , 
       lylref.loyalty_cust_ref_chng_sk AS loyalty_cust_ref_chng_sk , 
       lyllink.loyalty_cust_link_acct_chng_sk AS loyalty_cust_link_acct_chng_sk , 
       COALESCE(custxref.edw_update_dttm , $pSQL_PARM_2 ) AS custxref_edw_update_dttm , 
       COALESCE(lylref.edw_update_dttm , $pSQL_PARM_2 ) AS lylref_edw_update_dttm , 
       COALESCE(lyllink.edw_update_dttm , $pSQL_PARM_2 ) AS lyllink_edw_update_dttm , 
       CASE WHEN custxref_edw_update_dttm > lylref_edw_update_dttm THEN custxref_edw_update_dttm ELSE lylref_edw_update_dttm END a , 
       CASE WHEN a > lyllink_edw_update_dttm THEN a   ELSE lyllink_edw_update_dttm END final_update_dttm 

FROM (SELECT xref.cust_sk , xref.dim_cust_sk, xref.edw_update_dttm, xref.edw_rec_end_dt 


        FROM {db_param_master_data}.${pCustomer_DB}.$TABLE_NAME_2 xref, 
              {db_param_master_data}.${pCustomer_DB}.$TABLE_NAME_3 cust 
        WHERE cust.src_sys_cd = $pSRC_SYS_CD 
        AND cust.cust_sk = xref.cust_sk 
        AND cust.edw_rec_end_dt = $pTD_EDW_END_DATE 
        AND xref.edw_rec_end_dt = $pTD_EDW_END_DATE) custxref

LEFT OUTER JOIN ${db_param_marketing}.${pLoyalty_DB}.$TABLE_NAME_4 lylref 
ON custxref.cust_sk = lylref.cust_sk 
AND custxref.edw_rec_end_dt = $pTD_EDW_END_DATE 
AND lylref.edw_rec_end_dt = $pTD_EDW_END_DATE 

LEFT OUTER JOIN {db_param_marketing}.${pLoyalty_DB}.$TABLE_NAME_5 lyllink 
ON custxref.cust_sk = lyllink.cust_sk 
AND custxref.edw_rec_end_dt = $pTD_EDW_END_DATE 
AND lyllink.edw_rec_end_dt = $pTD_EDW_END_DATE 

WHERE
( 
        custxref_edw_update_dttm > $pSQL_PARM_1 OR 
        lylref_edw_update_dttm > $pSQL_PARM_1 OR 
        lyllink_edw_update_dttm > $pSQL_PARM_1 
) 
) loyal ; 
 

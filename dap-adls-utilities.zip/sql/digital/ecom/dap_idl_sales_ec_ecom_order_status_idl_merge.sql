MERGE INTO $DB_PARAM_DIGITAL.ECOM.$TARGET_TAB tgt
USING
(
SELECT
sales_txn_id,
sales_txn_dt,
sales_txn_type,
src_sys_cd,
sales_ord_src_type,
ord_stat_cd,
stat_start_dt,
stat_start_tm,
stat_end_dt,
stat_end_tm,
ord_stat_src_cd,
stat_reason_src_cd,
stat_reason_cd,
stat_eml_sent_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id

FROM $DB_PARAM_STAGING.ECOM.$STG_TAB1
WHERE src_sys_cd='EC' AND sales_txn_dt <> CAST('0001-01-01' AS DATE)
)stg
ON
        tgt.sales_txn_id = stg.sales_txn_id
        AND tgt.sales_txn_dt = stg.sales_txn_dt
        AND tgt.ord_stat_cd = stg.ord_stat_cd
        AND tgt.sales_ord_src_type = stg.sales_ord_src_type
        AND tgt.sales_txn_type = stg.sales_txn_type
        AND tgt.src_sys_cd = stg.src_sys_cd
        AND tgt.src_sys_cd = 'EC'

WHEN MATCHED THEN UPDATE SET

stat_start_dt = stg.stat_start_dt
,stat_start_tm = stg.stat_start_tm
,stat_end_dt = stg.stat_end_dt
,stat_end_tm = stg.stat_end_tm
,ord_stat_src_cd = stg.ord_stat_src_cd
,stat_reason_src_cd=stg.stat_reason_src_cd
,stat_reason_cd  =  stg.stat_reason_cd
,stat_eml_sent_cd = stg.stat_eml_sent_cd
,edw_update_dttm = stg.edw_update_dttm
,edw_batch_id = stg.edw_batch_id

WHEN NOT MATCHED THEN INSERT
(
 sales_txn_id,
sales_txn_dt,
sales_txn_type,
src_sys_cd,
sales_ord_src_type,
ord_stat_cd,
stat_start_dt,
stat_start_tm,
stat_end_dt,
stat_end_tm,
ord_stat_src_cd,
stat_reason_src_cd,
stat_reason_cd,
stat_eml_sent_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
VALUES
(
 stg.sales_txn_id,
stg.sales_txn_dt,
stg.sales_txn_type,
stg.src_sys_cd,
stg.sales_ord_src_type,
stg.ord_stat_cd,
stg.stat_start_dt,
stg.stat_start_tm,
stg.stat_end_dt,
stg.stat_end_tm,
stg.ord_stat_src_cd,
stg.stat_reason_src_cd,
stg.stat_reason_cd,
stg.stat_eml_sent_cd,
stg.edw_create_dttm,
stg.edw_update_dttm,
stg.edw_batch_id
)
;

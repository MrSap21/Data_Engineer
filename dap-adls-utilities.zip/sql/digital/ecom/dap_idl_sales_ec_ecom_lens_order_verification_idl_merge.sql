MERGE INTO ${pDIGITAL_DATABASE_NAME}.${pTD_DB_IDL}.${pSQL_PARM_3} tgt
USING	
(
SELECT
 sales_txn_id
,sales_txn_dt
,sales_ord_src_type
,sales_txn_type
,src_sys_cd
,pbr_cntc_method_cd
,lens_vrfy_cd
,pbr_id
,fulfillment_id
,ord_expire_dt
,ord_expire_tm
,prch_dt
,prch_tm
,lens_vrfy_mod_dt
,lens_vrfy_mod_tm
,lens_vrfy_dt
,lens_vrfy_tm
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_2}
WHERE src_sys_cd='${pSRC_SYS_CD}' AND sales_txn_dt <> $pTD_EDW_LOW_DATE
)stg
ON      	
        tgt.sales_txn_id = stg.sales_txn_id	
	AND tgt.sales_txn_dt = stg.sales_txn_dt    
	AND tgt.sales_ord_src_type = stg.sales_ord_src_type
	AND tgt.sales_txn_type = stg.sales_txn_type
  	AND tgt.src_sys_cd = stg.src_sys_cd
	AND tgt.src_sys_cd = '${pSRC_SYS_CD}' 
   
WHEN MATCHED THEN UPDATE SET
pbr_cntc_method_cd = stg.pbr_cntc_method_cd
,lens_vrfy_cd = stg.lens_vrfy_cd
,pbr_id = stg.pbr_id
,fulfillment_id = stg.fulfillment_id
,ord_expire_dt = stg.ord_expire_dt	
,ord_expire_tm  =  stg.ord_expire_tm	
,prch_dt = stg.prch_dt
,prch_tm = stg.prch_tm
,lens_vrfy_mod_dt = stg.lens_vrfy_mod_dt
,lens_vrfy_mod_tm = stg.lens_vrfy_mod_tm	
,lens_vrfy_dt  =  stg.lens_vrfy_dt	
,lens_vrfy_tm = stg.lens_vrfy_tm
,edw_update_dttm = stg.edw_update_dttm
,edw_batch_id = stg.edw_batch_id

WHEN NOT MATCHED THEN INSERT	
(	
 sales_txn_id
,sales_txn_dt
,sales_ord_src_type
,sales_txn_type
,src_sys_cd
,pbr_cntc_method_cd
,lens_vrfy_cd
,pbr_id
,fulfillment_id
,ord_expire_dt
,ord_expire_tm
,prch_dt
,prch_tm
,lens_vrfy_mod_dt
,lens_vrfy_mod_tm
,lens_vrfy_dt
,lens_vrfy_tm
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
)	
VALUES	
(	
 stg.sales_txn_id
,stg.sales_txn_dt
,stg.sales_ord_src_type
,stg.sales_txn_type
,stg.src_sys_cd
,stg.pbr_cntc_method_cd
,stg.lens_vrfy_cd
,stg.pbr_id
,stg.fulfillment_id
,stg.ord_expire_dt
,stg.ord_expire_tm
,stg.prch_dt
,stg.prch_tm
,stg.lens_vrfy_mod_dt
,stg.lens_vrfy_mod_tm
,stg.lens_vrfy_dt
,stg.lens_vrfy_tm
,stg.edw_create_dttm
,stg.edw_update_dttm
,stg.edw_batch_id
);	


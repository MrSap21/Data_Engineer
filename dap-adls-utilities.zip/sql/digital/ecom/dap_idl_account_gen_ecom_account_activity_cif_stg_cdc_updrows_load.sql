INSERT INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1
(
  ecom_acct_actv_chng_sk
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, edw_rec_begin_dt
, edw_rec_end_dt
, cust_sk
, eml_stat_cd
, eml_invld_dt
, eml_invld_tm
, last_actv_dt
, last_actv_tm
, last_logn_dt
, last_logn_tm
, last_visit_store_nbr
, nbr_of_site_visit
, rx_ready_cur_mo
, rx_ready_last_mo
, rx_ready_trail_cd
, stat_update_dt
, stat_update_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
, edw_etl_step
)
SELECT
  ecom_acct_actv_chng_sk
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, edw_rec_begin_dt
, try_to_date(left($pEDW_BATCH_ID,4)||'-'||substring($pEDW_BATCH_ID,5,2)||'-'||substring($pEDW_BATCH_ID,7,2)) - 1 as edw_rec_end_dt
, cust_sk
, eml_stat_cd
, eml_invld_dt
, eml_invld_tm
, last_actv_dt
, last_actv_tm
, last_logn_dt
, last_logn_tm
, last_visit_store_nbr
, nbr_of_site_visit
, rx_ready_cur_mo
, rx_ready_last_mo
, rx_ready_trail_cd
, stat_update_dt
, stat_update_tm
, edw_create_dttm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
, $pEDW_BATCH_ID as edw_batch_id
, 'CIF' as edw_etl_step
FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_2 p
WHERE (ecom_acct_id, src_sys_cd, composite_type_cd, msg_type_cd) IN
(
   SELECT
     ecom_acct_id
   , src_sys_cd
   , composite_type_cd
   , msg_type_cd
   FROM
   (
      SELECT   
        ecom_acct_id
      , src_sys_cd
      , composite_type_cd
      , msg_type_cd
      , eml_stat_cd
      , eml_invld_dt
      , eml_invld_tm
      , last_actv_dt
      , last_actv_tm
      , last_logn_dt
      , last_logn_tm
      , last_visit_store_nbr
      , nbr_of_site_visit
      , rx_ready_cur_mo
      , rx_ready_last_mo
      , rx_ready_trail_cd
      , stat_update_dt
      , stat_update_tm
      FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_2
      WHERE src_sys_cd = '$pSRC_SYS_CD'

      MINUS

      SELECT  
        ecom_acct_id
      , src_sys_cd
      , composite_type_cd
      , msg_type_cd
      , eml_stat_cd
      , eml_invld_dt
      , eml_invld_tm
      , last_actv_dt
      , last_actv_tm
      , last_logn_dt
      , last_logn_tm
      , last_visit_store_nbr
      , nbr_of_site_visit
      , rx_ready_cur_mo
      , rx_ready_last_mo
      , rx_ready_trail_cd
      , stat_update_dt
      , stat_update_tm
      FROM $pVIEW_DATABASE_NAME.$pVIEW_SCHEMA.$pTABLE_NAME_1
   ) as b
);

DELETE FROM $DB_PARAM_STAGING.$SCHEMA1.$STG_1 stg
WHERE stg.src_sys_cd = '$pSRC_SYS_CD'
AND (
                 (stg.cust_sk is not null
       )
      OR (EXISTS
          (
             SELECT 1
             FROM $DB_PARAM_STAGING.$SCHEMA1.$CIF_1 cif
             WHERE cif.ecom_acct_id = stg.ecom_acct_id
             AND   cif.src_sys_cd = stg.src_sys_cd
             AND   cif.composite_type_cd = stg.composite_type_cd
             AND   cif.msg_type_cd = stg.msg_type_cd
             AND   cif.persnl_secured_msg_id = stg.persnl_secured_msg_id
             AND   cif.secured_msg_type_cd = stg.secured_msg_type_cd
          )
         )
    )
;

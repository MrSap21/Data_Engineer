

DELETE FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pCIF_TABLE c
WHERE NOT EXISTS
  (
     SELECT 1
     FROM   $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE p
     WHERE  c.eml_addr = p.eml_addr
     AND    c.src_sys_cd = p.src_sys_cd
  ) 
AND  COALESCE(c.store_spcl_last_optin_dttm, '<#>') = '<#>'
AND  COALESCE(c.store_spcl_last_optout_dttm, '<#>') = '<#>'
AND  COALESCE(c.wkly_ad_last_optin_dttm, '<#>') = '<#>'
AND  COALESCE(c.wkly_ad_last_optout_dttm, '<#>') = '<#>'
AND  COALESCE(c.photo_last_optin_dttm, '<#>') = '<#>'
AND  COALESCE(c.photo_last_optout_dttm, '<#>') = '<#>'
AND  COALESCE(c.newsltr_last_optin_dttm, '<#>') = '<#>'
AND  COALESCE(c.newsltr_last_optout_dttm, '<#>') = '<#>'
AND  COALESCE(c.diabetes_last_optin_dttm, '<#>') = '<#>'
AND  COALESCE(c.diabetes_last_optout_dttm, '<#>') = '<#>'
AND  COALESCE(c.steps_last_optin_dttm, '<#>') = '<#>'
AND  COALESCE(c.steps_last_optout_dttm, '<#>') = '<#>'
AND  COALESCE(c.hlth_care_last_optin_dttm, '<#>') = '<#>'
AND  COALESCE(c.hlth_care_last_optout_dttm, '<#>') = '<#>';

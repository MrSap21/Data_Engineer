INSERT INTO $db_param_staging.$schema1.$pSQL_PARM_1
(
     dim_ecom_acct_sk
   , ecom_acct_chng_sk
   , ecom_acct_actv_chng_sk
   , dim_cust_sk
   , cust_sk
   , ecom_acct_id
   , src_sys_cd
   , composite_type_cd
   , msg_type_cd
   , edw_rec_begin_dt
   , edw_rec_end_dt
   , edw_create_dttm
   , edw_update_dttm
   , edw_batch_id
   , edw_etl_step
)
SELECT 
     NULL as dim_ecom_acct_sk
   , a.ecom_acct_chng_sk
   , a.ecom_acct_actv_chng_sk
   , a.dim_cust_sk
   , a.cust_sk
   , a.ecom_acct_id
   , a.src_sys_cd
   , a.composite_type_cd
   , a.msg_type_cd
   , CASE WHEN (b.cust_sk IS NULL AND c.cust_sk IS NULL)
          THEN to_date('0001-01-01'::VARCHAR(30), 'YYYY-MM-DD')
          ELSE $pTD_EDW_BATCH_DATE
          END as edw_rec_begin_dt
   , to_date('9999-12-31'::VARCHAR(30), 'YYYY-MM-DD') as edw_rec_end_dt
   , to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
   , to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
   , $pEDW_BATCH_ID as edw_batch_id
   , 'CIF' as edw_etl_step
FROM $db_param_staging.$schema1.cif_dim_ecom_account_xref_stg a

     LEFT OUTER JOIN $db_param_staging.$schema1.$pSQL_PARM_2 b
       ON  a.cust_sk  = b.cust_sk 

     LEFT OUTER JOIN $db_param_staging.$schema1.$pSQL_PARM_1 c
       ON  b.cust_sk  = c.cust_sk 

WHERE a.cust_sk IS NOT NULL

AND   (
          (c.cust_sk IS NOT NULL)

       OR (b.cust_sk IS NULL AND c.cust_sk IS NULL)
      )
AND a.src_sys_cd = '$pSRC_SYS_CD';
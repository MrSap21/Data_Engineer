INSERT INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1
(
  ecom_acct_actv_chng_sk
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, edw_rec_begin_dt
, edw_rec_end_dt
, cust_sk
, eml_stat_cd
, eml_invld_dt
, eml_invld_tm
, last_actv_dt
, last_actv_tm
, last_logn_dt
, last_logn_tm
, last_visit_store_nbr
, nbr_of_site_visit
, rx_ready_cur_mo
, rx_ready_last_mo
, rx_ready_trail_cd
, stat_update_dt
, stat_update_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
, edw_etl_step
)
SELECT 
  NULL as ecom_acct_actv_chng_sk
, a.ecom_acct_id
, a.src_sys_cd
, a.composite_type_cd
, a.msg_type_cd
, CASE WHEN (b.ecom_acct_id IS NULL AND c.ecom_acct_id IS NULL)
       THEN $pTD_EDW_LOW_DATE
       ELSE try_to_date(left($pEDW_BATCH_ID,4)||'-'||substring($pEDW_BATCH_ID,5,2)||'-'||substring($pEDW_BATCH_ID,7,2))
       END as edw_rec_begin_dt
, $pTD_EDW_END_DATE as edw_rec_end_dt
, NULL as cust_sk
, a.eml_stat_cd
, a.eml_invld_dt
, a.eml_invld_tm
, a.last_actv_dt
, a.last_actv_tm
, a.last_logn_dt
, a.last_logn_tm
, a.last_visit_store_nbr
, a.nbr_of_site_visit
, a.rx_ready_cur_mo
, a.rx_ready_last_mo
, a.rx_ready_trail_cd
, a.stat_update_dt
, a.stat_update_tm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
, $pEDW_BATCH_ID as edw_batch_id
, 'CIF' as edw_etl_step
FROM $pVIEW_DATABASE_NAME.$pVIEW_SCHEMA.$pTABLE_NAME_1 a

     LEFT OUTER JOIN $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_2 b
       ON  a.ecom_acct_id = b.ecom_acct_id
       AND a.src_sys_cd = b.src_sys_cd
       AND a.composite_type_cd = b.composite_type_cd
       AND a.msg_type_cd = b.msg_type_cd

     LEFT OUTER JOIN $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1 c
       ON  b.ecom_acct_id = c.ecom_acct_id
       AND b.src_sys_cd = c.src_sys_cd
       AND b.composite_type_cd = c.composite_type_cd
       AND b.msg_type_cd = c.msg_type_cd

WHERE a.ecom_acct_id IS NOT NULL
AND   a.src_sys_cd IS NOT NULL
AND   a.composite_type_cd IS NOT NULL
AND   a.msg_type_cd IS NOT NULL

AND   ( 
          (c.ecom_acct_id IS NOT NULL)
       OR (b.ecom_acct_id IS NULL AND c.ecom_acct_id IS NULL)
      );
 

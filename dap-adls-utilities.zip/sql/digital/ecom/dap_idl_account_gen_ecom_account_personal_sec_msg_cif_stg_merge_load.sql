MERGE INTO $DB_PARAM_STAGING.$SCHEMA1.$STG_1
USING
(SELECT
 persnl_secured_msg_id as persnl_secured_msg_id
,ecom_acct_id as ecom_acct_id
,src_sys_cd as src_sys_cd
,composite_type_cd as composite_type_cd
,msg_type_cd as msg_type_cd
,secured_msg_type_cd as secured_msg_type_cd
,secured_msg_stat_cd as secured_msg_stat_cd
,secured_msg_rcvd_dt as secured_msg_rcvd_dt
,secured_msg_rcvd_tm as secured_msg_rcvd_tm
FROM $DB_PARAM_STAGING.$SCHEMA1.$CIF_1 c
WHERE (persnl_secured_msg_id,ecom_acct_id, src_sys_cd, composite_type_cd, msg_type_cd,secured_msg_type_cd) IN
(
   SELECT
     persnl_secured_msg_id
   , ecom_acct_id
   , src_sys_cd
   , composite_type_cd
   , msg_type_cd
   , secured_msg_type_cd
   FROM
   (
      SELECT
          persnl_secured_msg_id
        , ecom_acct_id
        , src_sys_cd
        , composite_type_cd
        , msg_type_cd
        , secured_msg_type_cd
        , secured_msg_stat_cd
        , secured_msg_rcvd_dt
        , secured_msg_rcvd_tm
      FROM $DB_PARAM_STAGING.$SCHEMA1.$CIF_1


      MINUS

      SELECT
          persnl_secured_msg_id
        , ecom_acct_id
        , src_sys_cd
        , composite_type_cd
        , msg_type_cd
        , secured_msg_type_cd
        , secured_msg_stat_cd
        , secured_msg_rcvd_dt
        , secured_msg_rcvd_tm
      FROM $DB_PARAM_STAGING.$SCHEMA1.$PROC_1
      WHERE src_sys_cd = '$pSRC_SYS_CD')AS B
 ))CIF
ON
        $DB_PARAM_STAGING.$SCHEMA1.$STG_1.persnl_secured_msg_id = CIF.persnl_secured_msg_id
        AND $DB_PARAM_STAGING.$SCHEMA1.$STG_1.ecom_acct_id = CIF.ecom_acct_id
        AND $DB_PARAM_STAGING.$SCHEMA1.$STG_1.src_sys_cd = CIF.src_sys_cd
        AND $DB_PARAM_STAGING.$SCHEMA1.$STG_1.composite_type_cd = CIF.composite_type_cd
        AND $DB_PARAM_STAGING.$SCHEMA1.$STG_1.msg_type_cd = CIF.msg_type_cd
        AND $DB_PARAM_STAGING.$SCHEMA1.$STG_1.secured_msg_type_cd = CIF.secured_msg_type_cd
        AND $DB_PARAM_STAGING.$SCHEMA1.$STG_1.src_sys_cd = '$pSRC_SYS_CD'
WHEN MATCHED THEN UPDATE SET
secured_msg_stat_cd = CIF.secured_msg_stat_cd
,secured_msg_rcvd_dt = CIF.secured_msg_rcvd_dt
,secured_msg_rcvd_tm  =  CIF.secured_msg_rcvd_tm
,edw_update_dttm = CURRENT_TIMESTAMP(0)
,edw_batch_id = ${pEDW_BATCH_ID}
WHEN NOT MATCHED THEN INSERT
(
  cust_sk
, persnl_secured_msg_id
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, secured_msg_type_cd
, secured_msg_stat_cd
, secured_msg_rcvd_dt
, secured_msg_rcvd_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
,edw_etl_step
)
VALUES
(
  NULL
, cif.persnl_secured_msg_id
, cif.ecom_acct_id
, cif.src_sys_cd
, cif.composite_type_cd
, cif.msg_type_cd
, cif.secured_msg_type_cd
, cif.secured_msg_stat_cd
, cif.secured_msg_rcvd_dt
, cif.secured_msg_rcvd_tm
, CAST(CURRENT_TIMESTAMP(0) AS TIMESTAMP(0))
, CAST(CURRENT_TIMESTAMP(0) AS TIMESTAMP(0))
, $pEDW_BATCH_ID
, 'CIF'
)
;
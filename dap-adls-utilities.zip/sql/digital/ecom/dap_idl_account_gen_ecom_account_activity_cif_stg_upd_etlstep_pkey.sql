UPDATE $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pTABLE_NAME_1
SET   edw_etl_step = 'PKEY'
WHERE edw_etl_step = 'CIF'
AND   ecom_acct_actv_chng_sk is not null
AND   src_sys_cd = '$pSRC_SYS_CD';


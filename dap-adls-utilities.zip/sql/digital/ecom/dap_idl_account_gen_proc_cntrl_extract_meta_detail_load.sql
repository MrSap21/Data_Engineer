
INSERT INTO $pMETA_DATA_DB.$pTD_DB_META.$pMETA_DATA_TABLE 
(
   proj_name 
 , src_stream_name 
 , edw_batch_id
 , pset_name
 , extract_table_name
 , extract_dttm 
 , extract_file_name
 , extract_record_cnt
 , extract_create_dt
 ) 
SELECT 
   '$pPROJ_NAME'
 , '$pSRC_STREAM_NAME'
 , '$pEDW_BATCH_ID' 
 , '$pSQL_PARM_1' 
 , '$pSQL_PARM_3'
 , cif.maxupd_dttm
 , '$pSQL_PARM_2' 
 , cif.cnt 
 , to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
FROM 
(
   SELECT 
       COUNT(1) cnt 
     , MAX(edw_maxupd_dttm) maxupd_dttm
   FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pCIF_TABLE 
   WHERE src_sys_cd = '$pSRC_SYS_CD'
) cif
WHERE cif.cnt > 0;


MERGE INTO $pTGT_DATABASE_NAME.$pTD_DB_CIF.$pTGT_TABLE as idl
USING
(select
cust_sk
, immunize_id
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, rcmd_immunization_id
, pat_age_in_mon
, additional_immunization_txt
, cmnt_txt
, doctor_clinic_name
, rcvd_dt
, rcvd_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id 
,edw_etl_step
from $db_param_staging.$pTD_DB_CIF.$pSTG_TABLE where src_sys_cd = '$pSRC_SYS_CD' and cust_sk is not null )  stg 
ON
       idl.cust_sk=stg.cust_sk
AND idl.immunize_id = stg.immunize_id 
AND idl.ecom_acct_id = stg.ecom_acct_id    
AND idl.src_sys_cd = stg.src_sys_cd
AND idl.composite_type_cd = stg.composite_type_cd
AND idl.msg_type_cd = stg.msg_type_cd

WHEN MATCHED THEN UPDATE 
SET
rcmd_immunization_id = stg.rcmd_immunization_id
,pat_age_in_mon = stg.pat_age_in_mon
,additional_immunization_txt = stg.additional_immunization_txt
,cmnt_txt = stg.cmnt_txt
,doctor_clinic_name = stg.doctor_clinic_name
,rcvd_dt = stg.rcvd_dt
,rcvd_tm = stg.rcvd_tm
,edw_update_dttm=CURRENT_TIMESTAMP(0)
,edw_batch_id=$pEDW_BATCH_ID
WHEN NOT MATCHED THEN INSERT
(
cust_sk
, immunize_id
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, rcmd_immunization_id
, pat_age_in_mon
, additional_immunization_txt
, cmnt_txt
, doctor_clinic_name
, rcvd_dt
, rcvd_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
) 
VALUES
(
stg.cust_sk
, stg.immunize_id
, stg.ecom_acct_id
, stg.src_sys_cd
, stg.composite_type_cd
, stg.msg_type_cd
, stg.rcmd_immunization_id
, stg.pat_age_in_mon
, stg.additional_immunization_txt
, stg.cmnt_txt
, stg.doctor_clinic_name
, stg.rcvd_dt
, stg.rcvd_tm
,CURRENT_TIMESTAMP(0)
,CURRENT_TIMESTAMP(0)
,$pEDW_BATCH_ID
);


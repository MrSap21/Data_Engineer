UPDATE $pSTG_DATABASE_NAME.${pTD_DB_CIF}.${pTABLE_NAME_1} stg
SET  cust_sk = idl.cust_sk
   , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
   , edw_batch_id = ${pEDW_BATCH_ID}
   , edw_etl_step = 'FKEY'

FROM $pTGT_DATABASE_NAME.${pTD_VIEW_DB_IDL}.$pREF_TABLE_NAME idl

WHERE stg.ecom_acct_id = idl.cust_src_id
AND   stg.src_sys_cd = idl.src_sys_cd
AND   stg.composite_type_cd = idl.composite_type_cd
AND   stg.msg_type_cd = idl.msg_type_cd
AND   idl.edw_rec_end_dt = ${pTD_EDW_END_DATE}
AND   idl.src_sys_cd = '${pSRC_SYS_CD}'
AND   stg.cust_sk is null
AND   stg.ecom_acct_actv_chng_sk is not null
AND   stg.src_sys_cd = '${pSRC_SYS_CD}'
;



DELETE FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pCIF_TABLE c
WHERE NOT EXISTS
  (
     SELECT 1
     FROM   $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE p
     WHERE  c.src_sys_cd = p.src_sys_cd
     AND    c.guest_pref_id = p.guest_pref_id
     AND    c.guest_src_id = p.guest_src_id
     AND    c.guest_src_cd = p.guest_src_cd
     AND    c.guest_pref_prog_cd = p.guest_pref_prog_cd
     AND    c.guest_pref_type_cd = p.guest_pref_type_cd
      ) 
AND  COALESCE(c.guest_pref_val, '<#>') = '<#>';

UPDATE ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1}  cif
SET
        card_hash_val_sk=s.card_hash_val_sk

FROM    (
SELECT  cif.card_token_val ,MAX(idl.card_hash_val_sk)as card_hash_val_sk,
                cif.sales_txn_type as sales_txn_type, cif.src_sys_cd as src_sys_cd , cif.sales_ord_src_type as sales_ord_src_type
        FROM ${pTGT_DATABASE_NAME}.${pTD_VIEW_DB_IDL}.tender_card_hash idl, ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1}  cif
        WHERE idl.card_token_val=cif.card_token_val
        AND cif.src_sys_cd='${pSRC_SYS_CD}'
        AND cif.card_hash_val_sk = -1
GROUP BY 1,3,4,5) s
WHERE s.card_token_val=cif.card_token_val
AND s.sales_txn_type=cif.sales_txn_type
AND s.sales_ord_src_type=cif.sales_ord_src_type
AND s.src_sys_cd=cif.src_sys_cd
;

UPDATE ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1}  cif
SET zip_cd_4 = 'ĉ§ÃM'
WHERE zip_cd_4 = '0000';
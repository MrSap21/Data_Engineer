DELETE FROM $pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE
 
WHERE( 
(case when COALESCE(src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_1), 40) END) ,
(case when COALESCE(src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_2), 40) END) ,
(case when COALESCE(src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_3), 40) END) ,
(case when COALESCE(src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_4), 40) END) , 
gqm_prod_id, 
photo_origin_id, 
photo_origin_prod_id,
src_sys_cd)
 in 
(SELECT 
(case when COALESCE(src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_1), 40) END) AS src_sys_prod_id_1,
(case when COALESCE(src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_2), 40) END) as src_sys_prod_id_2,
(case when COALESCE(src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_3), 40) END) as src_sys_prod_id_3,
(case when COALESCE(src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_4), 40) END) as src_sys_prod_id_4, 
gqm_prod_id, 
photo_origin_id, 
photo_origin_prod_id,
src_sys_cd 
from $pSTAGING_DATABASE.${pTD_DB_CIF}.$pCIF_TABLE
);

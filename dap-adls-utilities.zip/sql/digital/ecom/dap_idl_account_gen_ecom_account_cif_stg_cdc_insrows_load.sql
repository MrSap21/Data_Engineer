
INSERT INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1
(
  ecom_acct_chng_sk
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, edw_rec_begin_dt
, cust_sk
, loyalty_mbr_id
, loyalty_src_sys_cd
, loyalty_composite_type_cd
, loyalty_msg_type_cd
, loyalty_cust_sk
, aarp_mbr_cd
, acct_locked_cd
, actv_cd
, auto_refill_cd
, cntc_lens_cust_cd
, easy_open_cap_cd
, er_card_cd
, google_hlth_cd
, hipaa_accept_cd
, hipaa_accept_dt
, hipaa_accept_tm
, logn_id
, mail_service_id
, pat_id
, pat_src_sys_cd
, pat_composite_type_cd
, pat_msg_type_cd
, pat_cust_sk
, pat_locked_cd
, photo_cust_cd
, photo_granted_dt
, photo_granted_tm
, phrm_cust_cd
, phrm_granted_dt
, phrm_granted_tm
, pin_apply_dt
, pin_auth_cd
, pin_key
, pin_reqst_cd
, pin_sent_cd
, pin_sent_dt
, quick_rgstr_cd
, rgstr_store_nbr
, rgstr_dt
, rgstr_tm
, rgstr_loc_store_sk
, rembr_name_cd
, rfrng_url
, rx_high_volume_cd
, was_id
, whi_cd
, worksite_cust_cd
, ecom_acct_stat_cd
, edw_rec_end_dt
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
, edw_etl_step
)
SELECT 
  NULL as ecom_acct_chng_sk
, a.ecom_acct_id
, a.src_sys_cd
, a.composite_type_cd
, a.msg_type_cd
, CASE WHEN (b.ecom_acct_id IS NULL AND c.ecom_acct_id IS NULL)
       THEN $pTD_EDW_LOW_DATE
       ELSE try_to_date(left($pEDW_BATCH_ID,4)||'-'||substring($pEDW_BATCH_ID,5,2)||'-'||substring($pEDW_BATCH_ID,7,2))
       END as edw_rec_begin_dt
, NULL as cust_sk
, a.loyalty_mbr_id
, a.loyalty_src_sys_cd
, a.loyalty_composite_type_cd
, a.loyalty_msg_type_cd
, NULL as loyalty_cust_sk
, a.aarp_mbr_cd
, a.acct_locked_cd
, a.actv_cd
, a.auto_refill_cd
, a.cntc_lens_cust_cd
, a.easy_open_cap_cd
, a.er_card_cd
, a.google_hlth_cd
, a.hipaa_accept_cd
, a.hipaa_accept_dt
, a.hipaa_accept_tm
, a.logn_id
, a.mail_service_id
, a.pat_id
, a.pat_src_sys_cd
, a.pat_composite_type_cd
, a.pat_msg_type_cd
, NULL as pat_cust_sk
, a.pat_locked_cd
, a.photo_cust_cd
, a.photo_granted_dt
, a.photo_granted_tm
, a.phrm_cust_cd
, a.phrm_granted_dt
, a.phrm_granted_tm
, a.pin_apply_dt
, a.pin_auth_cd
, a.pin_key
, a.pin_reqst_cd
, a.pin_sent_cd
, a.pin_sent_dt
, a.quick_rgstr_cd
, a.rgstr_store_nbr
, a.rgstr_dt
, a.rgstr_tm
, NULL as rgstr_loc_store_sk
, a.rembr_name_cd
, a.rfrng_url
, a.rx_high_volume_cd
, a.was_id
, a.whi_cd
, a.worksite_cust_cd
, a.ecom_acct_stat_cd
, CAST('9999-12-31' AS DATE) as edw_rec_end_dt
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
, $pEDW_BATCH_ID as edw_batch_id
, 'CIF' as edw_etl_step
FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pTABLE_NAME_1 a

     LEFT OUTER JOIN $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_2 b
       ON  a.ecom_acct_id = b.ecom_acct_id
       AND a.src_sys_cd = b.src_sys_cd
       AND a.composite_type_cd = b.composite_type_cd
       AND a.msg_type_cd = b.msg_type_cd

     LEFT OUTER JOIN $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1 c
       ON  b.ecom_acct_id = c.ecom_acct_id
       AND b.src_sys_cd = c.src_sys_cd
       AND b.composite_type_cd = c.composite_type_cd
       AND b.msg_type_cd = c.msg_type_cd

WHERE a.ecom_acct_id IS NOT NULL
AND   a.src_sys_cd IS NOT NULL
AND   a.composite_type_cd IS NOT NULL
AND   a.msg_type_cd IS NOT NULL
AND   (       
          (c.ecom_acct_id IS NOT NULL)       
       OR (b.ecom_acct_id IS NULL AND c.ecom_acct_id IS NULL)
      );

 

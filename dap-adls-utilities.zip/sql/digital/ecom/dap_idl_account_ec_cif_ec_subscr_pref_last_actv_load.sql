

CREATE temporary TABLE   vt_ec_chng_key_cust_pref
(
      cust_sk BIGINT NOT NULL
)
;



begin transaction;

INSERT INTO vt_ec_chng_key_cust_pref
(
   cust_sk
)
SELECT p.cust_sk
FROM   $pMASTERDB_NAME.$pTD_MASTER_DB_IDL.$pCUST_PREF_TABLE p
WHERE  p.src_sys_cd = '$pSRC_SYS_CD'
AND    p.cust_src_cd = '$pSRC_SYS_CD'
AND    p.edw_rec_end_dt = $pTD_EDW_END_DATE
AND    p.cust_pref_type_cd IN ('str_spcl_newsltr_ind', 'shopping_wkly_ind', 'photo_ind', 'news_ltr_ind', 'diabetes_ind', 'take_care_clinic_subscribe_ind')
AND    p.edw_update_dttm > $pSQL_PARM_1;

commit;


CREATE temporary TABLE   vt_ec_chng_key_guest_pref
(
      eml_addr VARCHAR(100)  COLLATE 'en-ci'  NOT NULL
)
;

begin transaction;

INSERT INTO vt_ec_chng_key_guest_pref
(
   eml_addr
)
SELECT p.guest_src_id as eml_addr
FROM   $pIDL_DATABASE_NAME.$pTD_DB_CIF.$pGUEST_PREF_TABLE p
WHERE  p.src_sys_cd = '$pSRC_SYS_CD'
AND    p.guest_src_cd = 'NC'
AND    p.edw_rec_end_dt = $pTD_EDW_END_DATE
AND    p.guest_pref_type_cd IN ('str_spcl_newsltr_ind', 'shopping_wkly_ind', 'photo_ind', 'news_ltr_ind', 'diabetes_ind', 'take_care_clinic_subscribe_ind')
AND    p.edw_update_dttm > $pSQL_PARM_1;

commit;

CREATE temporary TABLE   vt_ec_chng_key_eml
(
      eml_addr VARCHAR(100)  COLLATE 'en-ci'  NOT NULL,
      cust_sk BIGINT NOT NULL
)
;

begin transaction;

INSERT INTO vt_ec_chng_key_eml
(
   eml_addr
 , cust_sk
)
SELECT
   eml_addr
 , cust_sk
FROM
(
   SELECT
      CAST(comm_val as VARCHAR(100)) as eml_addr
    , CAST(cust_sk as BIGINT) as cust_sk
   FROM  $pMASTERDB_NAME.$pTD_MASTER_DB_IDL.$pCUST_CONT_CHANNEL_TABLE
   WHERE src_sys_cd = '$pSRC_SYS_CD'
   AND   cntc_chnnl_type_cd = 'E'
   AND   edw_rec_end_dt = $pTD_EDW_END_DATE
   AND   comm_val <> 'invalid'
   AND   comm_val is not null
   AND   edw_update_dttm > $pSQL_PARM_1

   UNION ALL

   SELECT
      CAST(c_ccc.comm_val as VARCHAR(100)) as eml_addr
    , CAST(c_ccc.cust_sk as BIGINT) as cust_sk
   FROM vt_ec_chng_key_cust_pref c
   
   INNER JOIN $pMASTERDB_NAME.$pTD_MASTER_DB_IDL.$pCUST_CONT_CHANNEL_TABLE c_ccc
   ON  c_ccc.cust_sk = c.cust_sk
   AND c_ccc.src_sys_cd = '$pSRC_SYS_CD'
   AND c_ccc.cntc_chnnl_type_cd = 'E'
   AND c_ccc.edw_rec_end_dt = $pTD_EDW_END_DATE
   AND c_ccc.comm_val <> 'invalid'
   AND c_ccc.comm_val is not null

   UNION ALL

   SELECT
      CAST(g.eml_addr as VARCHAR(100)) as eml_addr
    , CAST(COALESCE(g_ccc.cust_sk, -1) as BIGINT) as cust_sk
   FROM vt_ec_chng_key_guest_pref g
   
   LEFT OUTER JOIN $pMASTERDB_NAME.$pTD_MASTER_DB_IDL.$pCUST_CONT_CHANNEL_TABLE g_ccc
   ON  g_ccc.comm_val = g.eml_addr
   AND g_ccc.src_sys_cd = '$pSRC_SYS_CD'
   AND g_ccc.cntc_chnnl_type_cd = 'E'
   AND g_ccc.edw_rec_end_dt = $pTD_EDW_END_DATE
   AND g_ccc.comm_val <> 'invalid'
) xref
GROUP BY eml_addr, cust_sk;

commit;


CREATE temporary TABLE   vt_ec_chng_key_sk
(
      eml_addr VARCHAR(100)  COLLATE 'en-ci'  NOT NULL,
      cust_sk BIGINT NOT NULL
)
;

begin transaction;

INSERT INTO vt_ec_chng_key_sk
(
   eml_addr
 , cust_sk
)
SELECT
   eml_addr
 , cust_sk
FROM vt_ec_chng_key_eml
WHERE cust_sk <> -1;

commit;

CREATE temporary TABLE   vt_ec_eml_pref_norm
(
      eml_addr VARCHAR(100)  COLLATE 'en-ci'  NOT NULL,
      cust_pref_type_cd VARCHAR(50)  COLLATE 'en-ci'  NOT NULL,
      cust_pref_val VARCHAR(20)  COLLATE 'en-ci' ,
      pref_create_dttm TIMESTAMP,
      edw_update_dttm TIMESTAMP NOT NULL
)
;

begin transaction;

INSERT INTO vt_ec_eml_pref_norm
(
   eml_addr
 , cust_pref_type_cd
 , cust_pref_val
 , pref_create_dttm
 , edw_update_dttm
)
SELECT
   eml_addr
 , cust_pref_type_cd
 , cust_pref_val
 , CASE WHEN (pref_create_dttm_1 >= to_char('$pSQL_PARM_2'::timestamp , 'YYYY-MM-DD HH:MI:SS')) 
   THEN pref_create_dttm_1 
   ELSE to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') 
   END as pref_create_dttm
 , edw_update_dttm
FROM
(
   SELECT
      eml_addr
    , cust_pref_type_cd
    , cust_pref_val
    , pref_create_dttm as pref_create_dttm_1
    , edw_update_dttm
    , ROW_NUMBER() OVER (PARTITION BY eml_addr, cust_pref_type_cd, cust_pref_val ORDER BY pref_create_dttm desc) as row_num
   FROM
   (
      SELECT
         eml_addr
       , cust_pref_type_cd
       , cust_pref_val
       , pref_create_dttm
       , edw_update_dttm
      FROM
      (
         SELECT
            eml_addr
          , cust_pref_type_cd
          , cust_pref_val
          , pref_create_dttm
          , edw_update_dttm
          , ROW_NUMBER() OVER (PARTITION BY eml_addr, cust_pref_type_cd, cust_pref_val ORDER BY edw_create_dttm desc, pref_create_dttm desc) as row_num
         FROM
         (
            SELECT
               ck.eml_addr
             , cp.cust_pref_type_cd
             , cp.cust_pref_val
             , cp.pref_create_dttm
             , cp.edw_create_dttm
             , cp.edw_update_dttm
            FROM  vt_ec_chng_key_sk ck

            INNER JOIN $pMASTERDB_NAME.$pTD_MASTER_DB_IDL.$pCUST_PREF_TABLE cp
            ON  cp.cust_sk = ck.cust_sk
            AND cp.src_sys_cd = '$pSRC_SYS_CD'
            AND cp.cust_src_cd = '$pSRC_SYS_CD'
            AND cp.cust_pref_type_cd IN ('str_spcl_newsltr_ind', 'shopping_wkly_ind', 'photo_ind', 'news_ltr_ind', 'diabetes_ind', 'take_care_clinic_subscribe_ind')
         ) ca
      ) cb
      WHERE row_num = 1

      UNION ALL

      SELECT
         eml_addr
       , cust_pref_type_cd
       , cust_pref_val
       , pref_create_dttm
       , edw_update_dttm
      FROM
      (
         SELECT
            eml_addr
          , cust_pref_type_cd
          , cust_pref_val
          , pref_create_dttm
          , edw_update_dttm
          , ROW_NUMBER() OVER (PARTITION BY eml_addr, cust_pref_type_cd, cust_pref_val ORDER BY edw_create_dttm desc, pref_create_dttm desc) as row_num
         FROM
         (
            SELECT
               gk.eml_addr
             , gp.guest_pref_type_cd as cust_pref_type_cd
             , gp.guest_pref_val as cust_pref_val
             , gp.pref_create_dttm
             , gp.edw_create_dttm
             , gp.edw_update_dttm
            FROM  vt_ec_chng_key_eml gk

            INNER JOIN $pIDL_DATABASE_NAME.$pTD_DB_CIF.$pGUEST_PREF_TABLE gp
            ON  gp.guest_src_id = gk.eml_addr
            AND gp.src_sys_cd = '$pSRC_SYS_CD'
            AND gp.guest_src_cd = 'NC'
            AND gp.guest_pref_type_cd IN ('str_spcl_newsltr_ind', 'shopping_wkly_ind', 'photo_ind', 'news_ltr_ind', 'diabetes_ind', 'take_care_clinic_subscribe_ind')
         ) ga
      ) gb
      WHERE row_num = 1
   ) ta
) tb
WHERE row_num = 1
AND   pref_create_dttm is not null;

commit;

begin transaction;

INSERT INTO $db_param_staging.$pTD_DB_CIF.$pTABLE_NAME_1
(
   eml_addr
 , src_sys_cd
 , store_spcl_last_optin_dttm
 , store_spcl_last_optout_dttm
 , wkly_ad_last_optin_dttm
 , wkly_ad_last_optout_dttm
 , photo_last_optin_dttm
 , photo_last_optout_dttm
 , newsltr_last_optin_dttm
 , newsltr_last_optout_dttm
 , diabetes_last_optin_dttm
 , diabetes_last_optout_dttm
 , steps_last_optin_dttm
 , steps_last_optout_dttm
 , hlth_care_last_optin_dttm
 , hlth_care_last_optout_dttm
 , edw_maxupd_dttm
)
SELECT
   eml_addr
 , '$pSRC_SYS_CD' as src_sys_cd
 , MAX(store_spcl_last_optin_dttm) as store_spcl_last_optin_dttm
 , MAX(store_spcl_last_optout_dttm) as store_spcl_last_optout_dttm
 , MAX(wkly_ad_last_optin_dttm) as wkly_ad_last_optin_dttm
 , MAX(wkly_ad_last_optout_dttm) as wkly_ad_last_optout_dttm
 , MAX(photo_last_optin_dttm) as photo_last_optin_dttm
 , MAX(photo_last_optout_dttm) as photo_last_optout_dttm
 , MAX(newsltr_last_optin_dttm) as newsltr_last_optin_dttm
 , MAX(newsltr_last_optout_dttm) as newsltr_last_optout_dttm
 , MAX(diabetes_last_optin_dttm) as diabetes_last_optin_dttm
 , MAX(diabetes_last_optout_dttm) as diabetes_last_optout_dttm
 , NULL as steps_last_optin_dttm
 , NULL as steps_last_optout_dttm
 , MAX(hlth_care_last_optin_dttm) as hlth_care_last_optin_dttm
 , MAX(hlth_care_last_optout_dttm) as hlth_care_last_optout_dttm
 , MAX(edw_update_dttm) as edw_maxupd_dttm
FROM
(
   SELECT
      eml_addr
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'str_spcl_newsltr_ind'
   AND   cust_pref_val = 'Y'
    
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'str_spcl_newsltr_ind'
   AND   cust_pref_val = 'N'
 
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'shopping_wkly_ind'
   AND   cust_pref_val = 'Y'
   
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'shopping_wkly_ind'
   AND   cust_pref_val = 'N'
   
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'photo_ind'
   AND   cust_pref_val = 'Y'
   
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'photo_ind'
   AND   cust_pref_val = 'N'
   
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'news_ltr_ind'
   AND   cust_pref_val = 'Y'
   
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'news_ltr_ind'
   AND   cust_pref_val = 'N'
   
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'diabetes_ind'
   AND   cust_pref_val = 'Y'
   
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'diabetes_ind'
   AND   cust_pref_val = 'N'
   
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'take_care_clinic_subscribe_ind'
   AND   cust_pref_val = 'Y'
   
   UNION ALL
    
   SELECT
      eml_addr
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as store_spcl_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as wkly_ad_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as photo_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as newsltr_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optin_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as diabetes_last_optout_dttm
    , to_char(NULL::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optin_dttm
    , to_char(pref_create_dttm::timestamp , 'YYYY-MM-DD HH:MI:SS') as hlth_care_last_optout_dttm
    , edw_update_dttm
   FROM vt_ec_eml_pref_norm
   WHERE cust_pref_type_cd = 'take_care_clinic_subscribe_ind'
   AND   cust_pref_val = 'N'
) a
GROUP BY eml_addr;

commit;


INSERT INTO $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE
SELECT 
NULL,
c.src_sys_cd,
c.gqm_prod_id,
c.ecom_prod_id,
c.wic,
case when (  p.src_sys_prod_id_1 is null and 
             p.src_sys_prod_id_2 is null and 
             p.src_sys_prod_id_3 is null and 
             p.src_sys_prod_id_4 is null and
             p.gqm_prod_id is null and
             p.photo_origin_id is null and
             p.photo_origin_prod_id is null and
             p.src_sys_cd is null) then 
${pTD_EDW_LOW_DATE}
else $pTD_EDW_BATCH_DATE
end as EDW_REC_BEGIN_DT,
c.src_sys_prod_id_1,
c.src_sys_prod_id_2,
c.src_sys_prod_id_3,
c.src_sys_prod_id_4,
c.sku_id,
c.photo_origin_id,
c.photo_origin_prod_id,
NULL,
${pTD_EDW_END_DATE} as EDW_END_DATE , 
CURRENT_TIMESTAMP(0),
CURRENT_TIMESTAMP(0),
$pEDW_BATCH_ID,               
'CIF'
FROM $pSTAGING_DATABASE.$pTD_DB_CIF.$pCIF_TABLE c
LEFT OUTER JOIN $pSTAGING_DATABASE.$pTD_DB_CIF.$pPROC_TABLE p ON 
        (case when COALESCE(c.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', c.src_sys_prod_id_1), 40) END) = (case when COALESCE(p.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_1), 40) END) AND
		(case when COALESCE(c.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', c.src_sys_prod_id_2), 40) END) = (case when COALESCE(p.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_2), 40) END) AND
		(case when COALESCE(c.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', c.src_sys_prod_id_3), 40) END) = (case when COALESCE(p.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_3), 40) END) AND
		(case when COALESCE(c.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', c.src_sys_prod_id_4), 40) END) = (case when COALESCE(p.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_4), 40) END) AND
        c.gqm_prod_id=p.gqm_prod_id AND
        COALESCE(c.photo_origin_id, '#')=p.photo_origin_id AND
        COALESCE(c.photo_origin_prod_id, '#')=p.photo_origin_prod_id AND
        c.src_sys_cd=p.src_sys_cd 
LEFT OUTER JOIN $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE s ON
		(case when COALESCE(p.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_1), 40) END) = (case when COALESCE(s.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_1), 40) END) AND
		(case when COALESCE(p.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_2), 40) END) = (case when COALESCE(s.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_2), 40) END) AND
		(case when COALESCE(p.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_3), 40) END) = (case when COALESCE(s.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_3), 40) END) AND
		(case when COALESCE(p.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_4), 40) END) = (case when COALESCE(s.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_4), 40) END) AND
        p.gqm_prod_id=s.gqm_prod_id AND
        COALESCE(p.photo_origin_id, '#')=s.photo_origin_id AND
        COALESCE(p.photo_origin_prod_id, '#')=s.photo_origin_prod_id AND
        p.src_sys_cd=s.src_sys_cd
WHERE
        c.src_sys_cd='$pSRC_SYS_CD' AND
        c.src_sys_prod_id_1 IS NOT NULL AND
        c.src_sys_prod_id_2 IS NOT NULL AND
        c.src_sys_prod_id_3 IS NOT NULL AND
        c.src_sys_prod_id_4 IS NOT NULL AND
        c.gqm_prod_id IS NOT NULL AND
        c.photo_origin_id IS NOT NULL AND
        c.photo_origin_prod_id IS NOT NULL AND
        c.src_sys_cd IS NOT NULL AND
       ((
         s.src_sys_prod_id_1 IS NOT NULL AND
         s.src_sys_prod_id_2 IS NOT NULL AND
         s.src_sys_prod_id_3 IS NOT NULL AND
         s.src_sys_prod_id_4 IS NOT NULL AND
         s.gqm_prod_id IS NOT NULL AND
         s.photo_origin_id IS NOT NULL AND
         s.photo_origin_prod_id IS NOT NULL AND
         s.src_sys_cd IS NOT NULL
        ) OR
        (p.src_sys_prod_id_1 IS NULL AND
         p.src_sys_prod_id_2 IS NULL AND
         p.src_sys_prod_id_3 IS NULL AND
         p.src_sys_prod_id_4 IS NULL AND
         p.gqm_prod_id IS NULL AND
         p.photo_origin_id IS NULL AND
         p.photo_origin_prod_id IS NULL AND
         p.src_sys_cd IS NULL
        )
       );

UPDATE $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE} stg

SET   ${pPKEY_COLUMN_NAME} = c.pkey
    , edw_etl_step = 'PKEY'
FROM
(
   SELECT   (SUM(1) OVER (ORDER BY 1 ROWS UNBOUNDED PRECEDING) + :pkey) as pkey
          , ecom_acct_id
          , src_sys_cd
          , composite_type_cd
          , msg_type_cd
          , edw_rec_begin_dt
   FROM $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}
   WHERE ${pPKEY_COLUMN_NAME} is null
   AND   src_sys_cd = '${pSRC_SYS_CD}' 

) as c
WHERE stg.ecom_acct_id = c.ecom_acct_id
AND   stg.src_sys_cd = c.src_sys_cd
AND   stg.composite_type_cd = c.composite_type_cd
AND   stg.msg_type_cd = c.msg_type_cd
AND   stg.edw_rec_begin_dt = c.edw_rec_begin_dt
AND   stg.${pPKEY_COLUMN_NAME} is null
AND   stg.edw_etl_step = 'CIF'
;

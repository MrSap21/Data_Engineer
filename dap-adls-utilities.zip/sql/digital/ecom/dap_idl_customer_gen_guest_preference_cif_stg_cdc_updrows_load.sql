
INSERT INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE
SELECT   
guest_pref_chng_sk
,p.guest_pref_id
,p.guest_src_id
,p.guest_src_cd
,p.guest_pref_prog_cd
,p.guest_pref_type_cd
,p.src_sys_cd
,p.edw_rec_begin_dt
,p.guest_pref_val
,p.src_pref_eff_dt
,CASE WHEN (c.guest_src_id is not null) THEN c.src_pref_eff_dt -1 ELSE p.src_pref_expire_dt END as src_pref_expire_dt
,p.pref_create_user_id
,p.pref_create_dttm
,p.pref_create_src_sys_cd
,p.pref_update_dttm
,p.pref_update_src_sys_cd
,p.last_update_pref_store_nbr
,p.rgstr_loc_store_sk
,try_to_date(left($pEDW_BATCH_ID,4)||'-'||substring($pEDW_BATCH_ID,5,2)||'-'||substring($pEDW_BATCH_ID,7,2)) - 1 as edw_rec_end_dt
,edw_create_dttm
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
,$pEDW_BATCH_ID
,'CIF'
FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE p

LEFT OUTER JOIN $pVIEW_DATABASE_NAME.$pTD_VW_CIF.$pVIEW_NAME c
ON  c.src_sys_cd = p.src_sys_cd
AND c.guest_pref_id = p.guest_pref_id
AND c.guest_src_id = p.guest_src_id
AND c.guest_src_cd = p.guest_src_cd
AND c.guest_pref_prog_cd = p.guest_pref_prog_cd
AND c.guest_pref_type_cd = p.guest_pref_type_cd

WHERE (  p.src_sys_cd
        ,p.guest_pref_id
        ,p.guest_src_id
        ,p.guest_src_cd
        ,p.guest_pref_prog_cd
        ,p.guest_pref_type_cd 
        ) IN
(
   SELECT   src_sys_cd
        ,guest_pref_id
        ,guest_src_id
        ,guest_src_cd
        ,guest_pref_prog_cd
        ,guest_pref_type_cd 
   FROM
   (
      SELECT  
        src_sys_cd
       ,guest_pref_id
       ,guest_src_id
       ,guest_src_cd
       ,guest_pref_prog_cd
       ,guest_pref_type_cd
       ,guest_pref_val

      FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE
      WHERE src_sys_cd = '$pSRC_SYS_CD'

      MINUS

      SELECT  
        src_sys_cd
       ,guest_pref_id
       ,guest_src_id
       ,guest_src_cd
       ,guest_pref_prog_cd
       ,guest_pref_type_cd
       ,guest_pref_val
       FROM $pVIEW_DATABASE_NAME.$pTD_VW_CIF.$pVIEW_NAME
   ) as b
); 




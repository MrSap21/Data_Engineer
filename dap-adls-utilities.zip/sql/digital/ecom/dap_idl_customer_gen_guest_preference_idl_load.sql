begin transaction;

UPDATE $pTGT_DATABASE_NAME.$pTD_DB_CIF.$pTGT_TABLE tgt
SET src_pref_expire_dt = stg.src_pref_expire_dt
    , rgstr_loc_store_sk = stg.rgstr_loc_store_sk
    , edw_rec_end_dt = stg.edw_rec_end_dt
    , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
    , edw_batch_id = $pEDW_BATCH_ID

FROM    $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE stg WHERE tgt.guest_pref_id = stg.guest_pref_id
     AND tgt.guest_pref_chng_sk = stg.guest_pref_chng_sk
     AND stg.src_sys_cd = '$pSRC_SYS_CD'
     AND stg.edw_batch_id = $pEDW_BATCH_ID
;

INSERT INTO $pTGT_DATABASE_NAME.$pTD_DB_CIF.$pTGT_TABLE
(
         guest_pref_chng_sk
         ,guest_pref_id
         ,guest_src_id
         ,guest_src_cd
         ,guest_pref_prog_cd
         ,guest_pref_type_cd
         ,src_sys_cd
         ,edw_rec_begin_dt
         ,guest_pref_val
         ,src_pref_eff_dt
         ,src_pref_expire_dt
         ,pref_create_user_id
         ,pref_create_dttm
         ,pref_create_src_sys_cd
         ,pref_update_dttm
         ,pref_update_src_sys_cd
         ,last_update_pref_store_nbr
         ,rgstr_loc_store_sk
         ,edw_rec_end_dt
         ,edw_create_dttm 
         ,edw_update_dttm
         ,edw_batch_id   
)
SELECT

        stg.guest_pref_chng_sk
        ,stg.guest_pref_id
        ,stg.guest_src_id
        ,stg.guest_src_cd
        ,stg.guest_pref_prog_cd
        ,stg.guest_pref_type_cd
        ,stg.src_sys_cd
        ,stg.edw_rec_begin_dt
        ,stg.guest_pref_val
        ,stg.src_pref_eff_dt
        ,stg.src_pref_expire_dt
        ,stg.pref_create_user_id
        ,stg.pref_create_dttm
        ,stg.pref_create_src_sys_cd
        ,stg.pref_update_dttm
        ,stg.pref_update_src_sys_cd
        ,stg.last_update_pref_store_nbr
        ,stg.rgstr_loc_store_sk
        ,stg.edw_rec_end_dt
        ,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') 
        ,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
        ,$pEDW_BATCH_ID

FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE stg
WHERE NOT EXISTS
(
   SELECT 1
   FROM $pTGT_DATABASE_NAME.$pTD_DB_CIF.$pTGT_TABLE tgt
   WHERE tgt.guest_pref_id = stg.guest_pref_id
     and tgt.guest_pref_chng_sk = stg.guest_pref_chng_sk
     and tgt.src_sys_cd = stg.src_sys_cd
)

AND stg.src_sys_cd = '$pSRC_SYS_CD';

commit;


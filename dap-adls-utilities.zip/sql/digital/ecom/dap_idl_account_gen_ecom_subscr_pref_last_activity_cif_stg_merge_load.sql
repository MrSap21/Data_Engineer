MERGE INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE stg
USING
(
   SELECT
      c.eml_addr
    , c.src_sys_cd
    , CASE WHEN (  (c.store_spcl_last_optin_dttm is NULL) 
                OR (c.store_spcl_last_optin_dttm >= COALESCE(p.store_spcl_last_optin_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.store_spcl_last_optin_dttm 
           ELSE p.store_spcl_last_optin_dttm 
           END as store_spcl_last_optin_dttm
    , CASE WHEN (  (c.store_spcl_last_optout_dttm is NULL) 
                OR (c.store_spcl_last_optout_dttm >= COALESCE(p.store_spcl_last_optout_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.store_spcl_last_optout_dttm 
           ELSE p.store_spcl_last_optout_dttm 
           END as store_spcl_last_optout_dttm
    , CASE WHEN (  (c.wkly_ad_last_optin_dttm is NULL) 
                OR (c.wkly_ad_last_optin_dttm >= COALESCE(p.wkly_ad_last_optin_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.wkly_ad_last_optin_dttm 
           ELSE p.wkly_ad_last_optin_dttm 
           END as wkly_ad_last_optin_dttm
    , CASE WHEN (  (c.wkly_ad_last_optout_dttm is NULL)
                OR (c.wkly_ad_last_optout_dttm >= COALESCE(p.wkly_ad_last_optout_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.wkly_ad_last_optout_dttm 
           ELSE p.wkly_ad_last_optout_dttm 
           END as wkly_ad_last_optout_dttm
    , CASE WHEN (  (c.photo_last_optin_dttm is NULL) 
                OR (c.photo_last_optin_dttm >= COALESCE(p.photo_last_optin_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.photo_last_optin_dttm 
           ELSE p.photo_last_optin_dttm 
           END as photo_last_optin_dttm
    , CASE WHEN (  (c.photo_last_optout_dttm is NULL) 
                OR (c.photo_last_optout_dttm >= COALESCE(p.photo_last_optout_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.photo_last_optout_dttm 
           ELSE p.photo_last_optout_dttm 
           END as photo_last_optout_dttm
    , CASE WHEN (  (c.newsltr_last_optin_dttm is NULL) 
                OR (c.newsltr_last_optin_dttm >= COALESCE(p.newsltr_last_optin_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.newsltr_last_optin_dttm 
           ELSE p.newsltr_last_optin_dttm 
           END as newsltr_last_optin_dttm
    , CASE WHEN (  (c.newsltr_last_optout_dttm is NULL) 
                OR (c.newsltr_last_optout_dttm >= COALESCE(p.newsltr_last_optout_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.newsltr_last_optout_dttm 
           ELSE p.newsltr_last_optout_dttm 
           END as newsltr_last_optout_dttm
    , CASE WHEN (  (c.diabetes_last_optin_dttm is NULL) 
                OR (c.diabetes_last_optin_dttm >= COALESCE(p.diabetes_last_optin_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.diabetes_last_optin_dttm 
           ELSE p.diabetes_last_optin_dttm 
           END as diabetes_last_optin_dttm
    , CASE WHEN (  (c.diabetes_last_optout_dttm is NULL) 
                OR (c.diabetes_last_optout_dttm >= COALESCE(p.diabetes_last_optout_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.diabetes_last_optout_dttm 
           ELSE p.diabetes_last_optout_dttm 
           END as diabetes_last_optout_dttm
    , CASE WHEN (  (c.steps_last_optin_dttm is NULL) 
                OR (c.steps_last_optin_dttm >= COALESCE(p.steps_last_optin_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.steps_last_optin_dttm 
           ELSE p.steps_last_optin_dttm 
           END as steps_last_optin_dttm
    , CASE WHEN (  (c.steps_last_optout_dttm is NULL) 
                OR (c.steps_last_optout_dttm >= COALESCE(p.steps_last_optout_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.steps_last_optout_dttm 
           ELSE p.steps_last_optout_dttm 
           END as steps_last_optout_dttm
    , CASE WHEN (  (c.hlth_care_last_optin_dttm is NULL) 
                OR (c.hlth_care_last_optin_dttm >= COALESCE(p.hlth_care_last_optin_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.hlth_care_last_optin_dttm 
           ELSE p.hlth_care_last_optin_dttm 
           END as hlth_care_last_optin_dttm
    , CASE WHEN (  (c.hlth_care_last_optout_dttm is NULL) 
                OR (c.hlth_care_last_optout_dttm >= COALESCE(p.hlth_care_last_optout_dttm, to_char('0001-01-01 00:00:00'::timestamp , 'YYYY-MM-DD HH:MI:SS'))))
           THEN c.hlth_care_last_optout_dttm 
           ELSE p.hlth_care_last_optout_dttm 
           END as hlth_care_last_optout_dttm
	, CASE WHEN (p.edw_create_dttm IS NOT NULL) THEN p.edw_create_dttm ELSE to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') END as edw_create_dttm
	, CASE WHEN (p.edw_update_dttm IS NOT NULL) THEN p.edw_update_dttm ELSE to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') END as edw_update_dttm
   FROM $pVW_DATABASE_NAME.$pTD_VW_CIF.$pVIEW_NAME c

   LEFT OUTER JOIN $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE p
   ON  p.eml_addr = c.eml_addr
   AND p.src_sys_cd = c.src_sys_cd

   WHERE c.src_sys_cd = '$pSRC_SYS_CD' 
) cif 
ON  stg.eml_addr = cif.eml_addr
AND stg.src_sys_cd = cif.src_sys_cd 

WHEN MATCHED 
THEN UPDATE SET
   store_spcl_last_optin_dttm = cif.store_spcl_last_optin_dttm
 , store_spcl_last_optout_dttm = cif.store_spcl_last_optout_dttm
 , wkly_ad_last_optin_dttm = cif.wkly_ad_last_optin_dttm
 , wkly_ad_last_optout_dttm = cif.wkly_ad_last_optout_dttm
 , photo_last_optin_dttm = cif.photo_last_optin_dttm
 , photo_last_optout_dttm = cif.photo_last_optout_dttm
 , newsltr_last_optin_dttm = cif.newsltr_last_optin_dttm
 , newsltr_last_optout_dttm = cif.newsltr_last_optout_dttm
 , diabetes_last_optin_dttm = cif.diabetes_last_optin_dttm
 , diabetes_last_optout_dttm = cif.diabetes_last_optout_dttm
 , steps_last_optin_dttm = cif.steps_last_optin_dttm
 , steps_last_optout_dttm = cif.steps_last_optout_dttm
 , hlth_care_last_optin_dttm = cif.hlth_care_last_optin_dttm
 , hlth_care_last_optout_dttm = cif.hlth_care_last_optout_dttm
 , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
 , edw_batch_id = $pEDW_BATCH_ID

WHEN NOT MATCHED THEN INSERT
(
   eml_addr
 , src_sys_cd
 , store_spcl_last_optin_dttm
 , store_spcl_last_optout_dttm
 , wkly_ad_last_optin_dttm
 , wkly_ad_last_optout_dttm
 , photo_last_optin_dttm
 , photo_last_optout_dttm
 , newsltr_last_optin_dttm
 , newsltr_last_optout_dttm
 , diabetes_last_optin_dttm
 , diabetes_last_optout_dttm
 , steps_last_optin_dttm
 , steps_last_optout_dttm
 , hlth_care_last_optin_dttm
 , hlth_care_last_optout_dttm
 , edw_create_dttm
 , edw_update_dttm
 , edw_batch_id
 , edw_etl_step
) 
VALUES
(
   cif.eml_addr
 , cif.src_sys_cd
 , cif.store_spcl_last_optin_dttm
 , cif.store_spcl_last_optout_dttm
 , cif.wkly_ad_last_optin_dttm
 , cif.wkly_ad_last_optout_dttm
 , cif.photo_last_optin_dttm
 , cif.photo_last_optout_dttm
 , cif.newsltr_last_optin_dttm
 , cif.newsltr_last_optout_dttm
 , cif.diabetes_last_optin_dttm
 , cif.diabetes_last_optout_dttm
 , cif.steps_last_optin_dttm
 , cif.steps_last_optout_dttm
 , cif.hlth_care_last_optin_dttm
 , cif.hlth_care_last_optout_dttm
 , cif.edw_create_dttm
 , cif.edw_update_dttm
 , $pEDW_BATCH_ID
 , 'CIF'
);


MERGE INTO $DB_PARAM_STAGING.ECOM.$STG_TAB1 stg
USING
(
SELECT
sales_txn_id,
sales_txn_dt,
sales_txn_type,
src_sys_cd,
sales_ord_src_type,
ord_stat_cd,
stat_start_dt,
stat_start_tm,
stat_end_dt,
stat_end_tm,
ord_stat_src_cd,
stat_reason_src_cd,
stat_reason_cd,
stat_eml_sent_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id

FROM $DB_PARAM_STAGING.ECOM.$CIF_TAB1
WHERE (sales_txn_id, sales_txn_dt,src_sys_cd, sales_txn_type,sales_ord_src_type, ord_stat_cd ) IN
(
   SELECT updt.sales_txn_id, updt.sales_txn_dt, updt.src_sys_cd, updt.sales_txn_type,updt.sales_ord_src_type, updt.ord_stat_cd
   FROM
     (
    SELECT
        sales_txn_id,
        sales_txn_dt,
        sales_txn_type,
        src_sys_cd,
        sales_ord_src_type,
        ord_stat_cd,
        stat_start_dt,
        stat_start_tm,
        stat_end_dt,
        stat_end_tm,
        ord_stat_src_cd,
        stat_reason_src_cd,
        stat_reason_cd,
        stat_eml_sent_cd
      FROM $DB_PARAM_STAGING.ECOM.$CIF_TAB1

MINUS

        SELECT
        sales_txn_id,
        sales_txn_dt,
        sales_txn_type,
        src_sys_cd,
        sales_ord_src_type,
        ord_stat_cd,
        stat_start_dt,
        stat_start_tm,
        stat_end_dt,
        stat_end_tm,
        ord_stat_src_cd,
        stat_reason_src_cd,
        stat_reason_cd,
        stat_eml_sent_cd
     FROM $DB_PARAM_STAGING.ECOM.$PROC_TAB1 proc
     WHERE proc.src_sys_cd='EC'
)AS updt
 ))cif
ON
        stg.sales_txn_id = cif.sales_txn_id
        AND stg.sales_txn_dt= cif.sales_txn_dt
        AND stg.sales_txn_type = cif.sales_txn_type
        AND stg.sales_ord_src_type=cif.sales_ord_src_type
        AND stg.src_sys_cd = cif.src_sys_cd
        AND stg.ord_stat_cd = cif.ord_stat_cd
        AND stg.src_sys_cd = 'EC'
WHEN MATCHED THEN UPDATE SET

stat_start_dt = cif.stat_start_dt
,stat_start_tm = cif.stat_start_tm
,stat_end_dt = cif.stat_end_dt
,stat_end_tm = cif.stat_end_tm
,ord_stat_src_cd = cif.ord_stat_src_cd
,stat_reason_src_cd=cif.stat_reason_src_cd
,stat_reason_cd = cif.stat_reason_cd
,stat_eml_sent_cd = cif.stat_eml_sent_cd
,edw_update_dttm = cif.edw_update_dttm
,edw_batch_id = cif.edw_batch_id
WHEN NOT MATCHED THEN INSERT
(
  sales_txn_id,
sales_txn_dt,
sales_txn_type,
src_sys_cd,
sales_ord_src_type,
ord_stat_cd,
stat_start_dt,
stat_start_tm,
stat_end_dt,
stat_end_tm,
ord_stat_src_cd,
stat_reason_src_cd,
stat_reason_cd,
stat_eml_sent_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id,
edw_etl_step
)
VALUES
(
  cif.sales_txn_id
,cif.sales_txn_dt
,cif.sales_txn_type
,cif.src_sys_cd
,cif.sales_ord_src_type
,cif.ord_stat_cd
,cif.stat_start_dt
,cif.stat_start_tm
,cif.stat_end_dt
,cif.stat_end_tm
,cif.ord_stat_src_cd
,cif.stat_reason_src_cd
,cif.stat_reason_cd
,cif.stat_eml_sent_cd
,cif.edw_create_dttm
,cif.edw_update_dttm
,cif.edw_batch_id
,'CIF'
)
;

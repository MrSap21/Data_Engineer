MERGE INTO $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_2 stg
USING
(
SELECT
sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
src_sys_cd,
sales_txn_type,
ship_seq_nbr,
ord_item_id,
ship_group_id,
clnt_group_id,
group_id,
clnt_line_item_id,
ord_qty,
ship_qty,
subord_lineitem_stat,
prod_id,
clnt_prod_id,
vndr_prod_id,
prod_desc,
sku_id,
upc_nbr,
upc_ck_dgt_nbr,
unit_cost_dlrs,
raw_tot_price_dlrs,
tot_dlrs,
tot_ord_discnt_share_dlrs,
tot_promo_discnt_share_dlrs,
tot_tax_dlrs,
tot_mfgr_dlrs,
src_db_sys_key,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
FROM $pSTG_DATABASE_NAME.$schema1.$pTABLE_NAME_1
WHERE sales_ord_src_type = 'S'
AND (sales_txn_id, sales_txn_dt, sales_txn_type, sales_ord_src_type, ship_group_id, src_sys_cd) IN
(
   SELECT updt.sales_txn_id, updt.sales_txn_dt, updt.sales_txn_type, updt.sales_ord_src_type, updt.ship_group_id, updt.src_sys_cd
   FROM
   (
SELECT
sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
src_sys_cd,
sales_txn_type,
ship_seq_nbr,
ord_item_id,
ship_group_id,
clnt_group_id,
group_id,
clnt_line_item_id,
ord_qty,
ship_qty,
subord_lineitem_stat,
prod_id,
clnt_prod_id,
vndr_prod_id,
prod_desc,
sku_id,
upc_nbr,
upc_ck_dgt_nbr,
unit_cost_dlrs,
raw_tot_price_dlrs,
tot_dlrs,
tot_ord_discnt_share_dlrs,
tot_promo_discnt_share_dlrs,
tot_tax_dlrs,
tot_mfgr_dlrs,
src_db_sys_key
FROM $pSTG_DATABASE_NAME.$schema1.$pTABLE_NAME_1
WHERE sales_ord_src_type = 'S'

MINUS

SELECT
sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
src_sys_cd,
sales_txn_type,
ship_seq_nbr,
ord_item_id,
ship_group_id,
clnt_group_id,
group_id,
clnt_line_item_id,
ord_qty,
ship_qty,
subord_lineitem_stat,
prod_id,
clnt_prod_id,
vndr_prod_id,
prod_desc,
sku_id,
upc_nbr,
upc_ck_dgt_nbr,
unit_cost_dlrs,
raw_tot_price_dlrs,
tot_dlrs,
tot_ord_discnt_share_dlrs,
tot_promo_discnt_share_dlrs,
tot_tax_dlrs,
tot_mfgr_dlrs,
src_db_sys_key
FROM $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_1 proc
WHERE proc.src_sys_cd = '$pSRC_SYS_CD'
AND sales_ord_src_type = 'S'
)AS updt
 ))cif
ON
        stg.sales_txn_id = cif.sales_txn_id
        AND stg.sales_txn_dt = cif.sales_txn_dt
        AND stg.sales_ord_src_type = cif.sales_ord_src_type
        AND stg.sales_txn_type = cif.sales_txn_type
        AND stg.ship_group_id = cif.ship_group_id
        AND stg.ord_item_id = cif.ord_item_id
        AND stg.src_sys_cd = cif.src_sys_cd
        AND stg.src_sys_cd = '$pSRC_SYS_CD'
WHEN MATCHED THEN UPDATE SET
 ship_seq_nbr = cif.ship_seq_nbr
,clnt_group_id = cif.clnt_group_id
,group_id = cif.group_id
,clnt_line_item_id = cif.clnt_line_item_id
,ord_qty = cif.ord_qty
,ship_qty = cif.ship_qty
,subord_lineitem_stat = cif.subord_lineitem_stat
,prod_id = cif.prod_id
,clnt_prod_id = cif.clnt_prod_id
,vndr_prod_id = cif.vndr_prod_id
,prod_desc = cif.prod_desc
,sku_id = cif.sku_id
,upc_nbr = cif.upc_nbr
,upc_ck_dgt_nbr = cif.upc_ck_dgt_nbr
,unit_cost_dlrs = cif.unit_cost_dlrs
,raw_tot_price_dlrs = cif.raw_tot_price_dlrs
,tot_dlrs = cif.tot_dlrs
,tot_ord_discnt_share_dlrs = cif.tot_ord_discnt_share_dlrs
,tot_promo_discnt_share_dlrs = cif.tot_promo_discnt_share_dlrs
,tot_tax_dlrs = cif.tot_tax_dlrs
,tot_mfgr_dlrs = cif.tot_mfgr_dlrs
,src_db_sys_key = cif.src_db_sys_key
,edw_update_dttm = cif.edw_update_dttm
,edw_batch_id = cif.edw_batch_id
WHEN NOT MATCHED THEN INSERT
(
sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
src_sys_cd,
sales_txn_type,
ship_seq_nbr,
ord_item_id,
ship_group_id,
clnt_group_id,
group_id,
clnt_line_item_id,
ord_qty,
ship_qty,
subord_lineitem_stat,
prod_id,
clnt_prod_id,
vndr_prod_id,
prod_desc,
sku_id,
upc_nbr,
upc_ck_dgt_nbr,
unit_cost_dlrs,
raw_tot_price_dlrs,
tot_dlrs,
tot_ord_discnt_share_dlrs,
tot_promo_discnt_share_dlrs,
tot_tax_dlrs,
tot_mfgr_dlrs,
src_db_sys_key,
edw_create_dttm,
edw_update_dttm,
edw_batch_id,
edw_etl_step
)
VALUES
(
cif.sales_txn_id,
cif.sales_txn_dt,
cif.sales_ord_src_type,
cif.src_sys_cd,
cif.sales_txn_type,
cif.ship_seq_nbr,
cif.ord_item_id,
cif.ship_group_id,
cif.clnt_group_id,
cif.group_id,
cif.clnt_line_item_id,
cif.ord_qty,
cif.ship_qty,
cif.subord_lineitem_stat,
cif.prod_id,
cif.clnt_prod_id,
cif.vndr_prod_id,
cif.prod_desc,
cif.sku_id,
cif.upc_nbr,
cif.upc_ck_dgt_nbr,
cif.unit_cost_dlrs,
cif.raw_tot_price_dlrs,
cif.tot_dlrs,
cif.tot_ord_discnt_share_dlrs,
cif.tot_promo_discnt_share_dlrs,
cif.tot_tax_dlrs,
cif.tot_mfgr_dlrs,
cif.src_db_sys_key,
cif.edw_create_dttm,
cif.edw_update_dttm,
cif.edw_batch_id,
  'CIF'
);


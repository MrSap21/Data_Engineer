begin transaction;

UPDATE $pTGT_DATABASE_NAME.$pTD_DB_IDL.$pTABLE_NAME_1 tgt

SET   edw_rec_end_dt = stg.edw_rec_end_dt
    , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
    , edw_batch_id = $pEDW_BATCH_ID
FROM  $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1 stg WHERE tgt.ecom_acct_actv_chng_sk = stg.ecom_acct_actv_chng_sk
AND   tgt.cust_sk = stg.cust_sk
AND   stg.src_sys_cd = '$pSRC_SYS_CD'
AND   stg.edw_batch_id = $pEDW_BATCH_ID
;

INSERT INTO $pTGT_DATABASE_NAME.$pTD_DB_IDL.$pTABLE_NAME_1
(
  ecom_acct_actv_chng_sk
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, edw_rec_begin_dt
, edw_rec_end_dt
, cust_sk
, eml_stat_cd
, eml_invld_dt
, eml_invld_tm
, last_actv_dt
, last_actv_tm
, last_logn_dt
, last_logn_tm
, last_visit_store_nbr
, nbr_of_site_visit
, rx_ready_cur_mo
, rx_ready_last_mo
, rx_ready_trail_cd
, stat_update_dt
, stat_update_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT
  stg.ecom_acct_actv_chng_sk
, stg.ecom_acct_id
, stg.src_sys_cd
, stg.composite_type_cd
, stg.msg_type_cd
, stg.edw_rec_begin_dt
, stg.edw_rec_end_dt
, stg.cust_sk
, stg.eml_stat_cd
, stg.eml_invld_dt
, stg.eml_invld_tm
, stg.last_actv_dt
, stg.last_actv_tm
, stg.last_logn_dt
, stg.last_logn_tm
, stg.last_visit_store_nbr
, stg.nbr_of_site_visit
, stg.rx_ready_cur_mo
, stg.rx_ready_last_mo
, stg.rx_ready_trail_cd
, stg.stat_update_dt
, stg.stat_update_tm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
, $pEDW_BATCH_ID as edw_batch_id
FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1 stg
WHERE NOT EXISTS
(
   SELECT 1
   FROM $pTGT_DATABASE_NAME.$pTD_DB_IDL.$pTABLE_NAME_1 tgt
   WHERE tgt.ecom_acct_actv_chng_sk = stg.ecom_acct_actv_chng_sk
   AND   tgt.cust_sk = stg.cust_sk
)
AND stg.cust_sk IS NOT NULL
AND stg.src_sys_cd = '$pSRC_SYS_CD';

commit;


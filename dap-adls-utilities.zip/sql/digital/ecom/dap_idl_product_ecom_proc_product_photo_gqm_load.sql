INSERT INTO $pSTAGING_DATABASE.$pTD_DB_CIF.$pPROC_TABLE
select distinct 
          a.ecom_photo_gqm_chng_sk,
a.src_sys_cd,
a.gqm_prod_id,
a.ecom_prod_id,
a.wic,
a.edw_rec_begin_dt,
a.src_sys_prod_id_1,
a.src_sys_prod_id_2,
a.src_sys_prod_id_3,
a.src_sys_prod_id_4,
a.sku_id,
a.photo_origin_id,
a.photo_origin_prod_id,
a.prod_sk,
a.edw_rec_end_dt,
a.edw_create_dttm,
a.edw_update_dttm,
a.edw_batch_id
from 
  $pDIGITAL.$pTD_VIEW_DB_IDL.$pTGT_TABLE a ,
  $pSTAGING_DATABASE.$pTD_DB_CIF.$pCIF_TABLE b
WHERE 
(case when COALESCE(a.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', a.src_sys_prod_id_1), 40) END) = (case when COALESCE(b.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', b.src_sys_prod_id_1), 40) END) AND
(case when COALESCE(a.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', a.src_sys_prod_id_2), 40) END) = (case when COALESCE(b.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', b.src_sys_prod_id_2), 40) END) AND
(case when COALESCE(a.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', a.src_sys_prod_id_3), 40) END) = (case when COALESCE(b.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', b.src_sys_prod_id_3), 40) END) AND
(case when COALESCE(a.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', a.src_sys_prod_id_4), 40) END) = (case when COALESCE(b.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', b.src_sys_prod_id_4), 40) END) AND
a.gqm_prod_id=b.gqm_prod_id AND 
a.photo_origin_id=b.photo_origin_id AND
a.photo_origin_prod_id=b.photo_origin_prod_id AND
a.src_sys_cd=b.src_sys_cd AND
a.src_sys_cd='$pSRC_SYS_CD' AND
a.edw_rec_end_dt = to_date($pTD_EDW_END_DATE ::VARCHAR(30), 'YYYY-MM-DD')
-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
-- SEL_STATEMENT - Replace SEL with SELECT
;

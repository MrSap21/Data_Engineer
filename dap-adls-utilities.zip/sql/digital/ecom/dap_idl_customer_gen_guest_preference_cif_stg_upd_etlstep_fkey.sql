UPDATE $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE
SET   edw_etl_step = 'FKEY'
WHERE rgstr_loc_store_sk is not null
AND   edw_etl_step = 'PKEY'
AND src_sys_cd = '$pSRC_SYS_CD';


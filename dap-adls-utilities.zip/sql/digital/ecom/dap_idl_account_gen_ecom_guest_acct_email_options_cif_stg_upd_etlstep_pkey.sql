UPDATE $db_param_staging.$pTD_DB_CIF.$pTABLE_NAME_1
SET   edw_etl_step = 'PKEY'
WHERE edw_etl_step = 'CIF'
AND    ecom_guest_acct_opts_chng_sk is not null
AND   src_sys_cd = '$pSRC_SYS_CD';


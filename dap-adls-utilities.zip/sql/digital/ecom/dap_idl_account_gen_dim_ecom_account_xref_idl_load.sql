begin transaction;

UPDATE $db_param_misc.$schema1.$pTABLE_NAME_1 tgt

SET   edw_rec_end_dt = stg.edw_rec_end_dt
    , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
    , edw_batch_id = $pEDW_BATCH_ID
FROM    $db_param_staging.$schema2.$pSQL_PARM_1 stg WHERE tgt.dim_ecom_acct_sk = stg.dim_ecom_acct_sk 
AND   tgt.cust_sk = stg.cust_sk
AND   stg.src_sys_cd = '$pSRC_SYS_CD'
;


INSERT INTO $db_param_misc.$schema1.$pTABLE_NAME_1
(
       dim_ecom_acct_sk
     , ecom_acct_chng_sk
     , ecom_acct_actv_chng_sk
     , dim_cust_sk
     , cust_sk
     , ecom_acct_id
     , src_sys_cd
     , composite_type_cd
     , msg_type_cd
     , edw_rec_begin_dt
     , edw_rec_end_dt
     , edw_create_dttm
     , edw_update_dttm
     , edw_batch_id
) 
SELECT
       stg.dim_ecom_acct_sk
     , stg.ecom_acct_chng_sk
     , stg.ecom_acct_actv_chng_sk
     , stg.dim_cust_sk
     , stg.cust_sk
     , stg.ecom_acct_id
     , stg.src_sys_cd
     , stg.composite_type_cd
     , stg.msg_type_cd
     , stg.edw_rec_begin_dt
     , stg.edw_rec_end_dt
     , to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
     , to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
     , $pEDW_BATCH_ID as edw_batch_id
FROM $db_param_staging.$schema2.$pSQL_PARM_1 stg
WHERE NOT EXISTS
(
   SELECT 1
   FROM $db_param_misc.$schema1.$pTABLE_NAME_1 tgt
   WHERE tgt.dim_ecom_acct_sk = stg.dim_ecom_acct_sk
   AND   tgt.cust_sk = stg.cust_sk
)
AND stg.dim_ecom_acct_sk is not null
AND stg.src_sys_cd = '$pSRC_SYS_CD';

commit;


UPDATE $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_2 stg
SET ship_seq_nbr = ns.new_seq_nbr
,edw_etl_step = 'SEQ'

FROM    (
 SELECT a.sales_txn_id, a.ship_group_id, a.ord_item_id, DENSE_RANK() OVER (PARTITION BY a.sales_txn_id order by a.ship_group_id)+ COALESCE(max_seq_nbr,0)  AS new_seq_nbr
 FROM
(SELECT  sales_txn_id, ship_group_id, ord_item_id FROM $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_2 WHERE src_sys_cd='$pSRC_SYS_CD' AND sales_ord_src_type = 'S' AND sales_txn_type = 'S' AND edw_etl_step <> 'SEQ' AND sales_txn_dt <> ${pTD_EDW_LOW_DATE}) a
 LEFT OUTER JOIN 
(SELECT sales_txn_id, MAX(ship_seq_nbr) AS max_seq_nbr FROM $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_1 WHERE src_sys_cd='$pSRC_SYS_CD' AND sales_ord_src_type ='S' AND sales_txn_type = 'S' GROUP BY 1) b
ON a.sales_txn_id = b.sales_txn_id
)ns

WHERE stg.sales_txn_id = ns.sales_txn_id
AND   stg.ship_group_id = ns.ship_group_id
AND   stg.ord_item_id = ns.ord_item_id
AND   stg.sales_ord_src_type = 'S'
AND   stg.sales_txn_type = 'S'
AND   stg.src_sys_cd = '$pSRC_SYS_CD'
AND   stg.edw_etl_step <> 'SEQ'
AND   stg.ship_seq_nbr = 0
AND   stg.sales_txn_dt <> ${pTD_EDW_LOW_DATE}
;
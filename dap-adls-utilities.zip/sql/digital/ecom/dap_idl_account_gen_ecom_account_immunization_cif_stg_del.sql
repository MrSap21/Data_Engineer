
DELETE FROM $db_param_staging.$pTD_DB_CIF.$pSTG_TABLE stg
WHERE stg.src_sys_cd = '$pSRC_SYS_CD'
AND (

             (stg.cust_sk is not null)                 
      OR (EXISTS
          (
             SELECT 1
             FROM $db_param_staging.$pTD_DB_CIF.$pCIF_TABLE cif
             WHERE cif.ecom_acct_id = stg.ecom_acct_id
             AND   cif.src_sys_cd = stg.src_sys_cd
             AND   cif.composite_type_cd = stg.composite_type_cd
             AND   cif.msg_type_cd = stg.msg_type_cd
             AND   cif.immunize_id = stg.immunize_id
          )
         )
    );

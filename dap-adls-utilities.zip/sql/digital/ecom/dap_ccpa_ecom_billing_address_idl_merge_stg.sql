insert into  ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_2}
(     
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt)
select
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
after_del_cnt,
stg_tbl_rec_count,
before_del_cnt
from
(
Select 
  before_rcd_cnt.tkt_nbr,
  before_rcd_cnt.tkt_line_seq,
  before_rcd_cnt.tkt_open_dt,
  before_rcd_cnt.reqst_type_cd,
  '${pSUB_AREA}' as subject_area,
  '${pSTG_DATABASE_NAME}' as db_name,
  '${pSQL_PARM_1}' as tbl_name,
  Null as after_del_cnt,
  before_rcd_cnt.cnt as stg_tbl_rec_count,
  before_rcd_cnt.cnt as before_del_cnt from
 (Select stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,count(*) as cnt
  		from
  		 ${pSTG_DATABASE_NAME}.${pTD_DB_ECOM}.${pSQL_PARM_1} tgt
  		 inner join  ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_1} stg
  		 on tgt.sales_txn_id=stg.sales_txn_id
  and tgt.sales_txn_dt=stg.sales_txn_dt
  and tgt.sales_ord_src_type=stg.sales_ord_src_type
  and tgt.sales_txn_type=stg.sales_txn_type
  and tgt.src_sys_cd=stg.src_sys_cd
  		 group by 1,2,3,4
) before_rcd_cnt)AAA;

update 
${pSTG_DATABASE_NAME}.${pTD_DB_ECOM}.${pSQL_PARM_1} tgt
   set  prefix=NULL,
        first_name =NULL,
        middle_name =NULL,
        last_name=NULL,
        suffix= NULL,
        addr_line_1=Null,
        addr_line_2 =null,
        addr_line_3=null,
        city=Null,
        state_cd=null,
        zip_cd_5=null,
        zip_cd_4=null,
        county=null,
        cntry_cd =null,
        phone_area_cd =null,
        phone_nbr=null,
        fax_nbr=null,
        job_title=null,
        company_name=null,
        eml_addr=null,
        edw_update_dttm=GETDATE(),
        edw_batch_id=${pEDW_BATCH_ID}
from ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_1}  stg		
        where  tgt.sales_txn_id=stg.sales_txn_id
  and tgt.sales_txn_dt=stg.sales_txn_dt
  and tgt.sales_ord_src_type=stg.sales_ord_src_type
  and tgt.sales_txn_type=stg.sales_txn_type
  and tgt.src_sys_cd=stg.src_sys_cd;


 update ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_2}  stg_cnt_tbl
 set after_del_cnt=after_rcd_cnt.cnt
 from
(Select stg.tkt_nbr,stg.tkt_line_seq,stg.tkt_open_dt,stg.reqst_type_cd,count(*) as cnt
          from
          ${pSTG_DATABASE_NAME}.${pTD_DB_ECOM}.${pSQL_PARM_1} tgt
  		 inner join  ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_1} stg
  		 on tgt.sales_txn_id=stg.sales_txn_id
  and tgt.sales_txn_dt=stg.sales_txn_dt
  and tgt.sales_ord_src_type=stg.sales_ord_src_type
  and tgt.sales_txn_type=stg.sales_txn_type
  and tgt.src_sys_cd=stg.src_sys_cd
  where tgt.edw_batch_id=${pEDW_BATCH_ID}
           group by 1,2,3,4
) after_rcd_cnt
where stg_cnt_tbl.tkt_nbr=after_rcd_cnt.tkt_nbr
and stg_cnt_tbl.tkt_line_seq=after_rcd_cnt.tkt_line_seq
and stg_cnt_tbl.db_name='${pSTG_DATABASE_NAME}'
and stg_cnt_tbl.tbl_name='${pSQL_PARM_1}'
and stg_cnt_tbl.subject_area='${pSUB_AREA}';

insert into ${pTGT_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_4}
(
Subject_Area,  
db_name,
tbl_name, 
tkt_nbr,
tkt_line_seq,
tkt_open_dt, 
reqst_type_cd,
del_rec_cnt,
rec_del_dt,
stat_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
select
stg_ccpa.subject_area as subject_area
,stg_ccpa.db_name as db_name
,stg_ccpa.tbl_name as tbl_name
,stg_ccpa.tkt_nbr as tkt_nbr
,stg_ccpa.tkt_line_seq as tkt_line_seq
,stg_ccpa.tkt_open_dt as tkt_open_dt
,stg_ccpa.reqst_type_cd as reqst_type_cd
,stg_ccpa.stg_tbl_rec_count as del_rec_cnt
,current_date as rec_del_dt
, case when (stg_ccpa.before_del_cnt = stg_ccpa.after_del_cnt) THEN 'S' ELSE 'E' END AS STATUS_CD
,GETDATE()
,GETDATE()
,${pEDW_BATCH_ID} as edw_batch_id
 from ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_2} stg_ccpa  inner join 
  (select 
subject_area as subject_area
,db_name as db_name
,tbl_name as tbl_name
,sum(stg_tbl_rec_count) as del_count
from ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_2}
where db_name='${pSTG_DATABASE_NAME}'
and tbl_name='${pSQL_PARM_1}'
and subject_area='${pSUB_AREA}'
group by 1,2,3 ) del_cnt
 on 
 stg_ccpa.subject_area=del_cnt.subject_area
 and stg_ccpa.db_name=del_cnt.db_name
 and stg_ccpa.tbl_name=del_cnt.tbl_name;
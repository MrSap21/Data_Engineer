INSERT INTO $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_1
(
   photo_origin_id,
   src_sys_cd,
   cntc_name,
   origin_name,
   city,
   state,
   addr,
   zip_cd_5,
   zip_cd_4,
   mobile_affiliate,
   wag_mobile_affiliate,
   actv_ind,
   sub_type_cd,
   edw_create_dttm,
   edw_update_dttm,
   edw_batch_id
)
SELECT
   tgt.photo_origin_id,
   tgt.src_sys_cd,
   tgt.cntc_name,
   tgt.origin_name,
   tgt.city,
   tgt.state,
   tgt.addr,
   tgt.zip_cd_5,
   tgt.zip_cd_4,
   tgt.mobile_affiliate,
   tgt.wag_mobile_affiliate,
   tgt.actv_ind,
   tgt.sub_type_cd,
   tgt.edw_create_dttm,
   tgt.edw_update_dttm,
   tgt.edw_batch_id
FROM $pTGT_DATABASE_NAME.$schema1.$pSQL_PARM_3 tgt
WHERE EXISTS
(
SELECT 1 FROM $pSTG_DATABASE_NAME.$schema1.$pTABLE_NAME_1 cif
WHERE tgt.src_sys_cd = '$pSRC_SYS_CD'
AND tgt.photo_origin_id = cif.photo_origin_id
);


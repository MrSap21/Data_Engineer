UPDATE $pDIGITAL.$pTD_DB_IDL.$pTGT_TABLE 

SET
  edw_rec_end_dt = STG.edw_rec_end_dt
 ,edw_batch_id = $pEDW_BATCH_ID
, edw_update_dttm = current_timestamp(0)
FROM $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE AS STG
WHERE 
$pDIGITAL.$pTD_DB_IDL.$pTGT_TABLE.ecom_photo_gqm_chng_sk = STG.ecom_photo_gqm_chng_sk
;

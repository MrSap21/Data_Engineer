UPDATE ${pRETAIL_DATABASE_NAME}.$pTD_DB_IDL.sales_transaction ST
SET
      lens_ord_ind='Y'
FROM    ${pDIGITAL_DATABASE_NAME}.$pTD_VIEW_DB_IDL.ecom_lens_order_verification EL
WHERE
      ST.sales_txn_id = EL.sales_txn_id AND
      ST.sales_ord_src_type = EL.sales_ord_src_type AND
      ST.sales_ord_src_type = 'S' AND
      ST.sales_txn_type = EL.sales_txn_type AND
      ST.sales_txn_dt = EL.sales_txn_dt AND
      ST.lens_ord_ind = 'N' AND
      ST.src_sys_cd = EL.src_sys_cd AND    
      ST.src_sys_cd = '$pSRC_SYS_CD'
;



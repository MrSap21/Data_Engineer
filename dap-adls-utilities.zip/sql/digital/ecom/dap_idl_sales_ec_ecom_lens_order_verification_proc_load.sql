INSERT INTO ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_1}
(
 sales_txn_id
,sales_txn_dt
,sales_ord_src_type
,sales_txn_type
,src_sys_cd
,pbr_cntc_method_cd
,lens_vrfy_cd
,pbr_id
,fulfillment_id
,ord_expire_dt
,ord_expire_tm
,prch_dt
,prch_tm
,lens_vrfy_mod_dt
,lens_vrfy_mod_tm
,lens_vrfy_dt
,lens_vrfy_tm
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
)
SELECT
 tgt.sales_txn_id
,tgt.sales_txn_dt
,tgt.sales_ord_src_type
,tgt.sales_txn_type
,tgt.src_sys_cd
,tgt.pbr_cntc_method_cd
,tgt.lens_vrfy_cd
,tgt.pbr_id
,tgt.fulfillment_id
,tgt.ord_expire_dt
,tgt.ord_expire_tm
,tgt.prch_dt
,tgt.prch_tm
,tgt.lens_vrfy_mod_dt
,tgt.lens_vrfy_mod_tm
,tgt.lens_vrfy_dt
,tgt.lens_vrfy_tm
,tgt.edw_create_dttm
,tgt.edw_update_dttm
,tgt.edw_batch_id
FROM ${pDIGITAL_DATABASE_NAME}.${pTD_VIEW_DB_IDL}.${pSQL_PARM_3} tgt
WHERE EXISTS
(
SELECT 1 FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1} cif
WHERE tgt.src_sys_cd = '${pSRC_SYS_CD}'
AND tgt.sales_txn_id = cif.sales_txn_id
AND tgt.sales_txn_dt = cif.sales_txn_dt
AND tgt.sales_txn_type = cif.sales_txn_type
AND tgt.sales_ord_src_type = cif.sales_ord_src_type
);


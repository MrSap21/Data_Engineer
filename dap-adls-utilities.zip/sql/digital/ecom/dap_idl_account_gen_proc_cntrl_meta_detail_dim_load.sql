INSERT INTO $db_param_etl.$pTD_DB_META.PROC_CNTRL_EXTRACT_META_DETAIL_STG 
(
   proj_name 
 , src_stream_name 
 , edw_batch_id
 , pset_name
 , extract_table_name
 , extract_dttm 
 , extract_file_name
 , extract_record_cnt
 , extract_create_dt
 ) 
SELECT 
   '$pPROJ_NAME'
 , '$pSRC_STREAM_NAME'
 , '$pEDW_BATCH_ID' 
 , '$pSQL_PARM_1' 
 , '${pTABLE_NAME_1}_${pSRC_SYS_CD}'
 , cif.maxupd_dttm
 , '$pSQL_PARM_2' 
 , cif.cnt 
 , to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
FROM 
(
   SELECT 
       COUNT(1) cnt 
     , MAX(edw_maxupd_dttm) maxupd_dttm
   FROM $db_param_staging.$schema1.$pTABLE_NAME_1 
   WHERE src_sys_cd = '${pSRC_SYS_CD}'
) cif
WHERE cif.cnt > 0;

UPDATE $db_param_staging.${pSTG_SCHEMA}.${pSTG_TABLE}

SET   ${pPKEY_COLUMN_NAME} = c.pkey
    , edw_etl_step = 'PKEY'
FROM
(
   SELECT   (SUM(1) OVER (ORDER BY 1 ROWS UNBOUNDED PRECEDING) + :pkey) as pkey
          , src_sys_eml_id
          , src_sys_cd
          , edw_rec_begin_dt
   FROM $db_param_staging.${pSTG_SCHEMA}.${pSTG_TABLE}
   WHERE ${pPKEY_COLUMN_NAME} is null
   AND   src_sys_cd = '${pSRC_SYS_CD}' 

) as c
WHERE ${pSTG_TABLE}.src_sys_eml_id = c.src_sys_eml_id
AND   ${pSTG_TABLE}.src_sys_cd = c.src_sys_cd
AND   ${pSTG_TABLE}.edw_rec_begin_dt = c.edw_rec_begin_dt
AND   ${pSTG_TABLE}.${pPKEY_COLUMN_NAME} is null
AND   ${pSTG_TABLE}.edw_etl_step = 'CIF'
;

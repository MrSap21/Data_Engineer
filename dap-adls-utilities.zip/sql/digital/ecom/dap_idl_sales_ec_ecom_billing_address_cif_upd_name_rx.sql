UPDATE ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_2} cif
SET first_name = cust.first_name
    ,last_name = cust.last_name

FROM    (SELECT b.sales_txn_id, a.first_name, a.last_name 
FROM ${pTGT_DATABASE_NAME}.${pTD_VIEW_DB_IDL}.${pSQL_PARM_3} a,
${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1} b
WHERE a.src_sys_cd = '${pSRC_SYS_CD}'
AND a.composite_type_cd = '#'
AND a.msg_type_cd = '#'
AND a.edw_rec_end_dt = ${pTD_EDW_END_DATE}
AND a.cust_src_id = b.ro_me_id
) cust

WHERE cif.src_sys_cd = '${pSRC_SYS_CD}'
AND cif.sales_ord_src_type  = 'R'
AND cif.sales_txn_id = cust.sales_txn_id;

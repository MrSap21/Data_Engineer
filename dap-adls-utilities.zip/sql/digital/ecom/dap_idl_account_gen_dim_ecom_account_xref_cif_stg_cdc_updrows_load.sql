INSERT INTO $db_param_staging.$schema1.$table1
(
     dim_ecom_acct_sk
   , ecom_acct_chng_sk
   , ecom_acct_actv_chng_sk
   , dim_cust_sk
   , cust_sk
   , ecom_acct_id
   , src_sys_cd
   , composite_type_cd
   , msg_type_cd
   , edw_rec_begin_dt
   , edw_rec_end_dt
   , edw_create_dttm
   , edw_update_dttm
   , edw_batch_id
   , edw_etl_step
)
SELECT
     dim_ecom_acct_sk
   , ecom_acct_chng_sk
   , ecom_acct_actv_chng_sk
   , dim_cust_sk
   , cust_sk
   , ecom_acct_id
   , src_sys_cd
   , composite_type_cd
   , msg_type_cd
   , edw_rec_begin_dt
   , $pTD_EDW_BATCH_DATE - 1 as edw_rec_end_dt
   , edw_create_dttm
   , to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
   , $pEDW_BATCH_ID as edw_batch_id
   , 'CIF' as edw_etl_step
FROM $db_param_staging.$schema1.$table2 p
WHERE (cust_sk) IN
(
   SELECT   cust_sk
          
   FROM
   (
      SELECT    
          ecom_acct_chng_sk
        , ecom_acct_actv_chng_sk
        , dim_cust_sk
        , cust_sk
        , ecom_acct_id
        , src_sys_cd
        , composite_type_cd
        , msg_type_cd
      FROM $db_param_staging.$schema1.$table2
      WHERE src_sys_cd = '$pSRC_SYS_CD'

      MINUS

      SELECT    
          ecom_acct_chng_sk
        , ecom_acct_actv_chng_sk
        , dim_cust_sk
        , cust_sk
        , ecom_acct_id
        , src_sys_cd
        , composite_type_cd
        , msg_type_cd
      FROM $db_param_staging.$schema1.$table3
      WHERE src_sys_cd = '$pSRC_SYS_CD'
   ) as b

)
AND src_sys_cd = '$pSRC_SYS_CD';
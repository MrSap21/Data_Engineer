INSERT INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1
(
  ecom_acct_chng_sk
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, edw_rec_begin_dt
, cust_sk
, loyalty_mbr_id
, loyalty_src_sys_cd
, loyalty_composite_type_cd
, loyalty_msg_type_cd
, loyalty_cust_sk
, aarp_mbr_cd
, acct_locked_cd
, actv_cd
, auto_refill_cd
, cntc_lens_cust_cd
, easy_open_cap_cd
, er_card_cd
, google_hlth_cd
, hipaa_accept_cd
, hipaa_accept_dt
, hipaa_accept_tm
, logn_id
, mail_service_id
, pat_id
, pat_src_sys_cd
, pat_composite_type_cd
, pat_msg_type_cd
, pat_cust_sk
, pat_locked_cd
, photo_cust_cd
, photo_granted_dt
, photo_granted_tm
, phrm_cust_cd
, phrm_granted_dt
, phrm_granted_tm
, pin_apply_dt
, pin_auth_cd
, pin_key
, pin_reqst_cd
, pin_sent_cd
, pin_sent_dt
, quick_rgstr_cd
, rgstr_store_nbr
, rgstr_dt
, rgstr_tm
, rgstr_loc_store_sk
, rembr_name_cd
, rfrng_url
, rx_high_volume_cd
, was_id
, whi_cd
, worksite_cust_cd
, ecom_acct_stat_cd
, edw_rec_end_dt
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
, edw_etl_step
)
SELECT   
  ecom_acct_chng_sk
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, edw_rec_begin_dt
, cust_sk
, loyalty_mbr_id
, loyalty_src_sys_cd
, loyalty_composite_type_cd
, loyalty_msg_type_cd
, loyalty_cust_sk
, aarp_mbr_cd
, acct_locked_cd
, actv_cd
, auto_refill_cd
, cntc_lens_cust_cd
, easy_open_cap_cd
, er_card_cd
, google_hlth_cd
, hipaa_accept_cd
, hipaa_accept_dt
, hipaa_accept_tm
, logn_id
, mail_service_id
, pat_id
, pat_src_sys_cd
, pat_composite_type_cd
, pat_msg_type_cd
, pat_cust_sk
, pat_locked_cd
, photo_cust_cd
, photo_granted_dt
, photo_granted_tm
, phrm_cust_cd
, phrm_granted_dt
, phrm_granted_tm
, pin_apply_dt
, pin_auth_cd
, pin_key
, pin_reqst_cd
, pin_sent_cd
, pin_sent_dt
, quick_rgstr_cd
, rgstr_store_nbr
, rgstr_dt
, rgstr_tm
, rgstr_loc_store_sk
, rembr_name_cd
, rfrng_url
, rx_high_volume_cd
, was_id
, whi_cd
, worksite_cust_cd
, ecom_acct_stat_cd
, try_to_date(left($pEDW_BATCH_ID,4)||'-'||substring($pEDW_BATCH_ID,5,2)||'-'||substring($pEDW_BATCH_ID,7,2)) - 1
, edw_create_dttm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
, $pEDW_BATCH_ID as edw_batch_id
, 'CIF' as edw_etl_step
FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_2 p
WHERE (ecom_acct_id, src_sys_cd, composite_type_cd, msg_type_cd) IN
(
   SELECT
     ecom_acct_id
   , src_sys_cd
   , composite_type_cd
   , msg_type_cd
   FROM
   (
      SELECT   
        ecom_acct_id
      , src_sys_cd
      , composite_type_cd
      , msg_type_cd
      , loyalty_mbr_id
      , loyalty_src_sys_cd
      , loyalty_composite_type_cd
      , loyalty_msg_type_cd
      , aarp_mbr_cd
      , acct_locked_cd
      , actv_cd
      , auto_refill_cd
      , cntc_lens_cust_cd
      , easy_open_cap_cd
      , er_card_cd
      , google_hlth_cd
      , hipaa_accept_cd
      , hipaa_accept_dt
      , hipaa_accept_tm
      , logn_id
      , mail_service_id
      , pat_id
      , pat_src_sys_cd
      , pat_composite_type_cd
      , pat_msg_type_cd
      , pat_locked_cd
      , photo_cust_cd
      , photo_granted_dt
      , photo_granted_tm
      , phrm_cust_cd
      , phrm_granted_dt
      , phrm_granted_tm
      , pin_apply_dt
      , pin_auth_cd
      , pin_key
      , pin_reqst_cd
      , pin_sent_cd
      , pin_sent_dt
      , quick_rgstr_cd
      , rgstr_store_nbr
      , rgstr_dt
      , rgstr_tm
      , rembr_name_cd
      , rfrng_url
      , rx_high_volume_cd
      , was_id
      , whi_cd
      , worksite_cust_cd
      , ecom_acct_stat_cd
      FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_2
      WHERE src_sys_cd = '$pSRC_SYS_CD'

      MINUS

      SELECT  
        ecom_acct_id
      , src_sys_cd
      , composite_type_cd
      , msg_type_cd
      , loyalty_mbr_id
      , loyalty_src_sys_cd
      , loyalty_composite_type_cd
      , loyalty_msg_type_cd
      , aarp_mbr_cd
      , acct_locked_cd
      , actv_cd
      , auto_refill_cd
      , cntc_lens_cust_cd
      , easy_open_cap_cd
      , er_card_cd
      , google_hlth_cd
      , hipaa_accept_cd
      , hipaa_accept_dt
      , hipaa_accept_tm
      , logn_id
      , mail_service_id
      , pat_id
      , pat_src_sys_cd
      , pat_composite_type_cd
      , pat_msg_type_cd
      , pat_locked_cd
      , photo_cust_cd
      , photo_granted_dt
      , photo_granted_tm
      , phrm_cust_cd
      , phrm_granted_dt
      , phrm_granted_tm
      , pin_apply_dt
      , pin_auth_cd
      , pin_key
      , pin_reqst_cd
      , pin_sent_cd
      , pin_sent_dt
      , quick_rgstr_cd
      , rgstr_store_nbr
      , rgstr_dt
      , rgstr_tm
      , rembr_name_cd
      , rfrng_url
      , rx_high_volume_cd
      , was_id
      , whi_cd
      , worksite_cust_cd
      , ecom_acct_stat_cd
      FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pTABLE_NAME_1
   ) as b
);

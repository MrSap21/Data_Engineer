INSERT INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE
SELECT 
a.guest_pref_chng_sk
,a.guest_pref_id
,a.guest_src_id
,a.guest_src_cd
,a.guest_pref_prog_cd
,a.guest_pref_type_cd
,a.src_sys_cd
,a.edw_rec_begin_dt
,a.guest_pref_val
,a.src_pref_eff_dt
,a.src_pref_expire_dt
,a.pref_create_user_id
,a.pref_create_dttm
,a.pref_create_src_sys_cd
,a.pref_update_dttm
,a.pref_update_src_sys_cd
,a.last_update_pref_store_nbr
,a.rgstr_loc_store_sk
,a.edw_rec_end_dt
,a.edw_create_dttm 
,a.edw_update_dttm
,a.edw_batch_id
FROM   $pTGT_DATABASE_NAME.$pTD_DB_CIF.$pTGT_TABLE a
WHERE EXISTS
(
   SELECT 1
   FROM  $pVIEW_DATABASE_NAME.$pTD_VW_CIF.$pVIEW_NAME b
   WHERE a.src_sys_cd = b.src_sys_cd
         AND a.guest_pref_id = b.guest_pref_id
         AND a.guest_src_id = b.guest_src_id
         AND a.guest_src_cd = b.guest_src_cd
         AND a.guest_pref_prog_cd = b.guest_pref_prog_cd
         AND a.guest_pref_type_cd = b.guest_pref_type_cd
)
AND a.edw_rec_end_dt = $pTD_EDW_END_DATE
AND a.src_sys_cd = '$pSRC_SYS_CD';


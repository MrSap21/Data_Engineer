DELETE FROM $db_param_staging.$pTD_DB_CIF.$pSQL_PARM_1 stg
WHERE stg.src_sys_cd = '$pSRC_SYS_CD'
AND (
         (    (stg.rgstr_loc_store_sk is not null 
                OR stg.rgstr_store_nbr is null)
         )
      OR (EXISTS
          (
             SELECT 1
             FROM $db_param_staging.$pTD_DB_CIF.$pTABLE_NAME_1 cif
             WHERE cif.src_sys_eml_id = stg.src_sys_eml_id
             AND   cif.src_sys_cd = stg.src_sys_cd
          )
         )
    );

DELETE FROM $db_param_staging.$pTD_DB_CIF.$pTABLE_NAME_1;


MERGE INTO $pTGT_DATABASE_NAME.$schema1.$pSQL_PARM_3 tgt
USING 	
(
SELECT
   photo_origin_id,
   src_sys_cd,
   cntc_name,
   origin_name,
   city,
   state,
   addr,
   zip_cd_5,
   zip_cd_4,
   mobile_affiliate,
   wag_mobile_affiliate,
   actv_ind,
   sub_type_cd,
   edw_create_dttm,
   edw_update_dttm,
   edw_batch_id
FROM $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_2
WHERE src_sys_cd='$pSRC_SYS_CD'
)stg
ON      	
        tgt.photo_origin_id = stg.photo_origin_id	
	AND tgt.src_sys_cd = stg.src_sys_cd
	AND tgt.src_sys_cd = '$pSRC_SYS_CD' 
   
WHEN MATCHED THEN UPDATE SET
cntc_name = stg.cntc_name
,origin_name = stg.origin_name
,city = stg.city
,state = stg.state
,addr = stg.addr
,zip_cd_5 = stg.zip_cd_5
,zip_cd_4 = stg.zip_cd_4
,mobile_affiliate = stg.mobile_affiliate
,wag_mobile_affiliate=stg.wag_mobile_affiliate
,actv_ind=stg.actv_ind
,sub_type_cd=stg.sub_type_cd
,edw_update_dttm = stg.edw_update_dttm
,edw_batch_id = stg.edw_batch_id

WHEN NOT MATCHED THEN INSERT	
(	
   photo_origin_id,
   src_sys_cd,
   cntc_name,
   origin_name,
   city,
   state,
   addr,
   zip_cd_5,
   zip_cd_4,
   mobile_affiliate,
   wag_mobile_affiliate,
   actv_ind,
   sub_type_cd,
   edw_create_dttm,
   edw_update_dttm,
   edw_batch_id
)	
VALUES	
(	
   stg.photo_origin_id,
   stg.src_sys_cd,
   stg.cntc_name,
   stg.origin_name,
   stg.city,
   stg.state,
   stg.addr,
   stg.zip_cd_5,
   stg.zip_cd_4,
   stg.mobile_affiliate,
   stg.wag_mobile_affiliate,
   stg.actv_ind,
   stg.sub_type_cd,
   stg.edw_create_dttm,
   stg.edw_update_dttm,
   stg.edw_batch_id
);	


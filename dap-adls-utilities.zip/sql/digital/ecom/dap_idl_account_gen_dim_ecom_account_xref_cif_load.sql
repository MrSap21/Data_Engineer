set pSQL_PARM_1=(SELECT coalesce(MAX(EXTRACT_DTTM) ,'0001-01-01 00:00:00') from $db_param_etl.$PPRDSTGMET_Schema.$PPROC_META_DETAIL_TBL
where src_stream_name='$pSRC_STREAM_NAME' AND proj_name='$pPROJ_NAME' AND extract_table_name='cif_dim_ecom_account_xref_stg_${pSRC_SYS_CD}');


begin transaction;

delete from $db_param_staging.$schema1.$table1;
delete from $db_param_staging.$schema1.$table5;
delete from $db_param_staging.$schema1.$table7;
delete from $db_param_staging.$schema1.$table9;

commit;

begin transaction;

INSERT INTO $db_param_staging.$schema1.$table1-- acct_xref_keys_${pSRC_SYS_CD}
(
   cust_sk
)
SELECT cust_sk
FROM   $db_param_staging.$schema6.$table2--$pTD_DB_CIF.STG_EC_ACCOUNT
WHERE  src_sys_cd = '${pSRC_SYS_CD}'
AND    edw_rec_end_dt = ${pTD_EDW_END_DATE}
AND    cust_sk is not null
AND    edw_update_dttm > $pSQL_PARM_1

UNION
                     
SELECT cust_sk
FROM   $db_param_staging.$schema6.$table3--$pTD_DB_CIF.STG_EC_ACCOUNT_ACTIVITY
WHERE  src_sys_cd = '${pSRC_SYS_CD}'
AND    edw_rec_end_dt = ${pTD_EDW_END_DATE}
AND    cust_sk is not null
AND    edw_update_dttm > $pSQL_PARM_1

UNION

SELECT cust_sk
FROM   $db_param_master_data.$schema2.$table4--$pTD_VIEW_DB_IDL.DIM_CUSTOMER_XREF
WHERE  src_sys_cd = '${pSRC_SYS_CD}'
AND    edw_rec_end_dt = ${pTD_EDW_END_DATE}
AND    edw_update_dttm > $pSQL_PARM_1;

commit;

begin transaction;

INSERT INTO $db_param_staging.$schema1.$table5--acct_xref_acct_${pSRC_SYS_CD}
(
   cust_sk
 , ecom_acct_chng_sk
 , ecom_acct_id
 , src_sys_cd
 , composite_type_cd
 , msg_type_cd
 , edw_update_dttm
)
SELECT c.cust_sk
     , c.ecom_acct_chng_sk
     , c.ecom_acct_id
     , c.src_sys_cd
     , c.composite_type_cd
     , c.msg_type_cd
     , c.edw_update_dttm
FROM $db_param_staging.$schema1.$table1 d
     INNER JOIN $db_param_digital.$schema6.$table6 c--$pTD_VIEW_DB_IDL.ECOM_ACCOUNT c
       ON  c.cust_sk = d.cust_sk
       AND c.src_sys_cd = '${pSRC_SYS_CD}'
       AND c.edw_rec_end_dt = ${pTD_EDW_END_DATE};

commit;


begin transaction;

INSERT INTO $db_param_staging.$schema1.$table7--acct_xref_acct_actv_${pSRC_SYS_CD}
(
   cust_sk
 , ecom_acct_actv_chng_sk
 , edw_update_dttm
)
SELECT c.cust_sk
     , c.ecom_acct_actv_chng_sk
     , c.edw_update_dttm
FROM $db_param_staging.$schema1.$table1 d
     INNER JOIN $db_param_digital.$schema6.$table8 c--$pTD_VIEW_DB_IDL.ECOM_ACCOUNT_ACTIVITY c
       ON  c.cust_sk = d.cust_sk
       AND c.src_sys_cd = '${pSRC_SYS_CD}'
       AND c.edw_rec_end_dt = ${pTD_EDW_END_DATE};

commit;

begin transaction;

INSERT INTO $db_param_staging.$schema1.$table9 --acct_xref_cust_xref_${pSRC_SYS_CD}
(
   cust_sk
 , dim_cust_sk
 , edw_update_dttm
)
SELECT c.cust_sk
     , c.dim_cust_sk
     , c.edw_update_dttm
FROM $db_param_staging.$schema1.$table1 d 
     INNER JOIN $db_param_master_data.$schema2.$table4 c
       ON  c.cust_sk = d.cust_sk
       AND c.src_sys_cd = '${pSRC_SYS_CD}'
       AND c.edw_rec_end_dt = ${pTD_EDW_END_DATE};

commit;

begin transaction;

INSERT INTO $db_param_staging.$schema1.cif_dim_ecom_account_xref_stg--$pTD_DB_CIF.cif_dim_ecom_account_xref
(
   ecom_acct_chng_sk
 , ecom_acct_actv_chng_sk
 , dim_cust_sk
 , cust_sk
 , ecom_acct_id
 , src_sys_cd
 , composite_type_cd
 , msg_type_cd
 , edw_maxupd_dttm
)
SELECT
   ecom_acct_chng_sk
 , ecom_acct_actv_chng_sk
 , dim_cust_sk
 , cust_sk
 , ecom_acct_id
 , src_sys_cd
 , composite_type_cd
 , msg_type_cd
 , final_update_dttm
FROM
(
   SELECT
     a.cust_sk
   , a.ecom_acct_chng_sk
   , coalesce(actv.ecom_acct_actv_chng_sk, -1) ecom_acct_actv_chng_sk
   , coalesce(cust_xref.dim_cust_sk, -1) dim_cust_sk
   , a.ecom_acct_id
   , a.src_sys_cd
   , a.composite_type_cd
   , a.msg_type_cd

   , case when coalesce(a.edw_update_dttm, $pSQL_PARM_2) > coalesce(actv.edw_update_dttm, $pSQL_PARM_2) then coalesce(a.edw_update_dttm, $pSQL_PARM_2) else coalesce(actv.edw_update_dttm, $pSQL_PARM_2) end dt1_1
   , coalesce(cust_xref.edw_update_dttm, $pSQL_PARM_2) as dt1_2
   , case when dt1_1 > dt1_2 then dt1_1 else dt1_2 end final_update_dttm

   FROM $db_param_staging.$schema1.$table5 a

   LEFT OUTER JOIN $db_param_staging.$schema1.$table7 actv
     ON  a.cust_sk = actv.cust_sk

   LEFT OUTER JOIN $db_param_staging.$schema1.$table9 cust_xref
     ON  a.cust_sk = cust_xref.cust_sk
) cif_ld;

commit;


UPDATE ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_2} stg
SET sales_txn_dt = S.sales_txn_dt
,edw_update_dttm = CURRENT_TIMESTAMP(0)
,edw_etl_step = 'FKEY'
FROM    (SELECT sales_txn_id, sales_ord_src_type, sales_txn_type, src_sys_cd, sales_txn_dt 
 FROM ${pCONSUMPTION_DATABASE_NAME}.${pTD_VIEW_DB_IDL}.sales_transaction 
  WHERE src_sys_cd = '${pSRC_SYS_CD}' AND sales_txn_type = 'S' ) S
WHERE stg.src_sys_cd = '${pSRC_SYS_CD}'
AND stg.sales_txn_id = S.sales_txn_id
AND stg.sales_ord_src_type = S.sales_ord_src_type
AND stg.sales_txn_type = S.sales_txn_type
AND stg.src_sys_cd = S.src_sys_cd
AND stg.sales_txn_dt = ${pTD_EDW_LOW_DATE}
;

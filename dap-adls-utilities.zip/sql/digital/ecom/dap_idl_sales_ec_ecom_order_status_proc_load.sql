INSERT INTO $DB_PARAM_STAGING.ECOM.$PROC_TAB1

(
        sales_txn_id,
        sales_txn_dt,
        sales_txn_type,
        src_sys_cd,
        sales_ord_src_type,
        ord_stat_cd,
        stat_start_dt,
        stat_start_tm,
        stat_end_dt,
        stat_end_tm,
        ord_stat_src_cd,
        stat_reason_src_cd,
        stat_reason_cd,
        stat_eml_sent_cd,
        edw_create_dttm,
        edw_update_dttm,
        edw_batch_id

)
SELECT
        tgt.sales_txn_id,
        tgt.sales_txn_dt,
        tgt.sales_txn_type,
        tgt.src_sys_cd,
        tgt.sales_ord_src_type,
        tgt.ord_stat_cd,
        tgt.stat_start_dt,
        tgt.stat_start_tm,
        tgt.stat_end_dt,
        tgt.stat_end_tm,
        tgt.ord_stat_src_cd,
        tgt.stat_reason_src_cd,
        tgt.stat_reason_cd,
        tgt.stat_eml_sent_cd,
        tgt.edw_create_dttm,
        tgt.edw_update_dttm,
        tgt.edw_batch_id

FROM $DB_PARAM_DIGITAL.ECOM.$TARGET_TAB tgt
WHERE EXISTS
(
SELECT 1 FROM $DB_PARAM_STAGING.ECOM.$CIF_TAB1 cif
WHERE tgt.src_sys_cd = 'EC'
AND tgt.sales_txn_id = cif.sales_txn_id
AND tgt.sales_txn_dt = cif.sales_txn_dt
AND tgt.sales_txn_type = cif.sales_txn_type
AND tgt.sales_ord_src_type = cif.sales_ord_src_type
AND tgt.ord_stat_cd = cif.ord_stat_cd
)
;

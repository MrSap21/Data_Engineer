UPDATE ${pTD_DB_CIF}.${pTABLE_NAME_1} cif
SET
        sales_txn_dt=s.sales_txn_dt
FROM    (
SELECT  cif.sales_txn_id as sales_txn_id, idl.sales_txn_dt as sales_txn_dt,
                cif.sales_txn_type as sales_txn_type, cif.src_sys_cd as src_sys_cd , cif.sales_ord_src_type as sales_ord_src_type
        FROM ${pTD_VIEW_DB_IDL}.sales_transaction idl, ${pTD_DB_CIF}.${pTABLE_NAME_1} cif
        WHERE idl.sales_txn_id=cif.sales_txn_id
        AND idl.sales_txn_type=cif.sales_txn_type
        AND idl.sales_ord_src_type=cif.sales_ord_src_type
        AND idl.src_sys_cd =cif.src_sys_cd
        AND cif.src_sys_cd='${pSRC_SYS_CD}'
        AND cif.sales_txn_dt = ${pTD_EDW_LOW_DATE}
GROUP BY 1,2,3,4,5) s
WHERE s.sales_txn_id=cif.sales_txn_id
AND s.sales_txn_type=cif.sales_txn_type
AND s.sales_ord_src_type=cif.sales_ord_src_type
AND s.src_sys_cd=cif.src_sys_cd;

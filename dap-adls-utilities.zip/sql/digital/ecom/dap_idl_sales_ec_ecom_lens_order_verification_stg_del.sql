DELETE FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_2}
WHERE src_sys_cd='${pSRC_SYS_CD}'
AND (
(sales_txn_id, sales_ord_src_type, sales_txn_type, src_sys_cd) IN
(SELECT sales_txn_id, sales_ord_src_type, sales_txn_type, src_sys_cd FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1})
OR
sales_txn_dt <> $pTD_EDW_LOW_DATE
);


MERGE INTO ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_2} stg
USING 	
(
SELECT
 sales_txn_id
,sales_txn_dt
,sales_ord_src_type
,sales_txn_type
,src_sys_cd
,pbr_cntc_method_cd
,lens_vrfy_cd
,pbr_id
,fulfillment_id
,ord_expire_dt
,ord_expire_tm
,prch_dt
,prch_tm
,lens_vrfy_mod_dt
,lens_vrfy_mod_tm
,lens_vrfy_dt
,lens_vrfy_tm
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1}
WHERE (sales_txn_id, sales_txn_dt, src_sys_cd, sales_txn_type ,sales_ord_src_type) IN
(
   SELECT updt.sales_txn_id, updt.sales_txn_dt, updt.src_sys_cd, updt.sales_txn_type, updt.sales_ord_src_type
   FROM
     (
    SELECT   
   	sales_txn_id
        ,sales_txn_dt
	,sales_ord_src_type
	,sales_txn_type
	,src_sys_cd
	,pbr_cntc_method_cd
	,lens_vrfy_cd
	,pbr_id
	,fulfillment_id
	,ord_expire_dt
	,ord_expire_tm
	,prch_dt
	,prch_tm
	,lens_vrfy_mod_dt
	,lens_vrfy_mod_tm
	,lens_vrfy_dt
	,lens_vrfy_tm
      FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1}
      
MINUS

	SELECT
   	sales_txn_id
        ,sales_txn_dt
	,sales_ord_src_type
	,sales_txn_type
	,src_sys_cd
	,pbr_cntc_method_cd
	,lens_vrfy_cd
	,pbr_id
	,fulfillment_id
	,ord_expire_dt
	,ord_expire_tm
	,prch_dt
	,prch_tm
	,lens_vrfy_mod_dt
	,lens_vrfy_mod_tm
	,lens_vrfy_dt
	,lens_vrfy_tm
     FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_1} proc
     WHERE proc.src_sys_cd='${pSRC_SYS_CD}'
)AS updt
 ))cif
ON      	
        stg.sales_txn_id = cif.sales_txn_id
        AND stg.sales_txn_dt = cif.sales_txn_dt
        AND stg.sales_txn_type = cif.sales_txn_type
        AND stg.sales_ord_src_type = cif.sales_ord_src_type
	AND stg.src_sys_cd = cif.src_sys_cd
	AND stg.src_sys_cd = '${pSRC_SYS_CD}'    
WHEN MATCHED THEN UPDATE SET
pbr_cntc_method_cd = cif.pbr_cntc_method_cd
,lens_vrfy_cd = cif.lens_vrfy_cd
,pbr_id = cif.pbr_id
,fulfillment_id = cif.fulfillment_id
,ord_expire_dt = cif.ord_expire_dt
,ord_expire_tm = cif.ord_expire_tm
,prch_dt = cif.prch_dt
,prch_tm = cif.prch_tm
,lens_vrfy_mod_dt = cif.lens_vrfy_mod_dt
,lens_vrfy_mod_tm = cif.lens_vrfy_mod_tm
,lens_vrfy_dt = cif.lens_vrfy_dt
,lens_vrfy_tm = cif.lens_vrfy_tm
,edw_update_dttm = cif.edw_update_dttm
,edw_batch_id = cif.edw_batch_id
WHEN NOT MATCHED THEN INSERT	
(	
  sales_txn_id
,sales_txn_dt
,sales_ord_src_type
,sales_txn_type
,src_sys_cd
,pbr_cntc_method_cd
,lens_vrfy_cd
,pbr_id
,fulfillment_id
,ord_expire_dt
,ord_expire_tm
,prch_dt
,prch_tm
,lens_vrfy_mod_dt
,lens_vrfy_mod_tm
,lens_vrfy_dt
,lens_vrfy_tm
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
,edw_etl_step
)	
VALUES	
(	
  cif.sales_txn_id
,cif.sales_txn_dt
,cif.sales_ord_src_type
,cif.sales_txn_type
,cif.src_sys_cd
,cif.pbr_cntc_method_cd
,cif.lens_vrfy_cd
,cif.pbr_id
,cif.fulfillment_id
,cif.ord_expire_dt
,cif.ord_expire_tm
,cif.prch_dt
,cif.prch_tm
,cif.lens_vrfy_mod_dt
,cif.lens_vrfy_mod_tm
,cif.lens_vrfy_dt
,cif.lens_vrfy_tm
,cif.edw_create_dttm
,cif.edw_update_dttm
,cif.edw_batch_id
,'CIF'
);	


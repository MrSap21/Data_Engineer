delete from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1;

insert into $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1
(
tkt_nbr
,tkt_open_dt
,reqst_type_cd
,tkt_line_seq
,eml_addr
,src_sys_cd
)
SELECT
tkt_nbr
,tkt_open_dt
,reqst_type_cd
,tkt_line_seq
,eml_addr
,src_sys_cd
FROM 
(
select Distinct 
 B.tkt_nbr
,B.tkt_open_dt
,B.reqst_type_cd
,B.tkt_line_seq
,a.eml_addr
,a.src_sys_cd
FROM 
$pDB_STAGING.$pTD_DB_CIF.$pSTG_TABLE_NAME A
inner join
$pCCPA_DB_NAME.$pCCPA_SCHEMA.$pCUST_REQUEST B
on A.eml_addr = B.cust_eml_addr
AND A.src_sys_cd = B.src_sys_cd
and B.reqst_type_cd='Delete'
and B.edw_reqst_complete_dt is null
) base;


delete from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2;

insert into $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2
(     
tkt_nbr	,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
before_del_cnt,
after_del_cnt,
stg_tbl_rec_count
)     
Select 
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
  '$pSUB_AREA' as subject_area, 
  '$pDB_NAME' as db_name,
  '$pSTG_TABLE_NAME' as tbl_name,
  ( Select cast(count(*) as bigint) from $pDB_STAGING.$pTD_DB_CIF.$pSTG_TABLE_NAME ) as before_del_cnt,
  Null as after_del_cnt,
  (select count(*) as cc from (select tkt_nbr,eml_addr,src_sys_cd,count(*) as cnt from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 group by 1,2,3) a) as del_cnt
  from
  $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 
;															


delete from $pDB_STAGING.$pTD_DB_CIF.$pSTG_TABLE_NAME tgt
where exists 
(select 1 from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 stg
where tgt.eml_addr = stg.eml_addr
  and tgt.src_sys_cd = stg.src_sys_cd );




update $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2
set after_del_cnt = (select cast(count(*) as bigint) from $pDB_STAGING.$pTD_DB_CIF.$pSTG_TABLE_NAME)
where db_name='$pDB_NAME'
and tbl_name='$pSTG_TABLE_NAME'
and subject_area='$pSUB_AREA';	


insert into $pCCPA_DB_NAME.$pCCPA_SCHEMA.$pTABLE_NAME4
(
subject_area,
db_name,
tbl_name,
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
del_rec_cnt,
rec_del_dt,
stat_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
select
a.subject_area, 
a.db_name,
a.tbl_name,
a.tkt_nbr,
a.tkt_line_seq,
a.tkt_open_dt, 
a.reqst_type_cd,
a.del_rec_cnt,
a.rec_del_dt,
a.stat_cd,
a.edw_create_dttm,
a.edw_update_dttm,
a.edw_batch_id
from
(
select
stg_ccpa.subject_area as subject_area
,stg_ccpa.db_name as db_name
,stg_ccpa.tbl_name as tbl_name
,stg_ccpa.tkt_nbr as tkt_nbr
,stg_ccpa.tkt_line_seq as tkt_line_seq
,stg_ccpa.tkt_open_dt as tkt_open_dt
,stg_ccpa.reqst_type_cd as reqst_type_cd
,stg_ccpa.stg_tbl_rec_count as del_rec_cnt
,current_date as rec_del_dt
, case when (stg_ccpa.before_del_cnt = stg_ccpa.after_del_cnt+del_cnt.del_count ) THEN 'S' ELSE 'E' END AS stat_cd
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
,$pEDW_BATCH_ID as edw_batch_id
 from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2 stg_ccpa inner join 
  (select distinct
subject_area as subject_area
,db_name as db_name
,tbl_name as tbl_name
,stg_tbl_rec_count as del_count
from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2
where db_name='$pDB_NAME'
and tbl_name='$pSTG_TABLE_NAME'
and subject_area='$pSUB_AREA'
) del_cnt
 on 
 stg_ccpa.subject_area=del_cnt.subject_area
 and stg_ccpa.db_name=del_cnt.db_name
 and stg_ccpa.tbl_name=del_cnt.tbl_name
 ) a;
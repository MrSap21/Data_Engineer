DELETE FROM $DB_PARAM_STAGING.ECOM.$STG_TAB1
WHERE src_sys_cd='EC'
AND (
(sales_txn_id, sales_ord_src_type, sales_txn_type, src_sys_cd, ord_stat_cd) IN
(SELECT sales_txn_id, sales_ord_src_type, sales_txn_type, src_sys_cd, ord_stat_cd FROM $DB_PARAM_STAGING.ECOM.$CIF_TAB1)
OR
sales_txn_dt <> CAST('0001-01-01' AS DATE)
)
;

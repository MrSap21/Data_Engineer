INSERT INTO $db_param_staging.$schema1.$table1
(
   dim_ecom_acct_sk
 , ecom_acct_chng_sk
 , ecom_acct_actv_chng_sk
 , dim_cust_sk
 , cust_sk
 , ecom_acct_id
 , src_sys_cd
 , composite_type_cd
 , msg_type_cd
 , edw_rec_begin_dt
 , edw_rec_end_dt
 , edw_create_dttm
 , edw_update_dttm
 , edw_batch_id
)
SELECT 
   a.dim_ecom_acct_sk
 , a.ecom_acct_chng_sk
 , a.ecom_acct_actv_chng_sk
 , a.dim_cust_sk
 , a.cust_sk
 , a.ecom_acct_id
 , a.src_sys_cd
 , a.composite_type_cd
 , a.msg_type_cd
 , a.edw_rec_begin_dt
 , a.edw_rec_end_dt
 , a.edw_create_dttm
 , a.edw_update_dttm
 , a.edw_batch_id
FROM $db_param_misc.$schema2.$pSQL_PARM_2 a
WHERE EXISTS
(
   SELECT 1
   FROM  $db_param_staging.$schema1.$table2 b
   WHERE a.cust_sk = b.cust_sk
   AND   b.src_sys_cd = '$pSRC_SYS_CD'
)
AND   a.edw_rec_end_dt = $pTD_EDW_END_DATE;
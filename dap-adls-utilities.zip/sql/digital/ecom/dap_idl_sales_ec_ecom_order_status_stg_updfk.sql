UPDATE 
 $DB_PARAM_STAGING.ECOM.$STG_TAB1 stg from 
(
SELECT  stg.sales_txn_id as sales_txn_id, idl.sales_txn_dt as sales_txn_dt,
                stg.sales_txn_type as sales_txn_type, stg.src_sys_cd as src_sys_cd , stg.sales_ord_src_type as sales_ord_src_type
        FROM $DB_PARAM_RETAIL.RETAIL_SALES.sales_transaction idl, $DB_PARAM_STAGING.ECOM.$STG_TAB1 stg
        WHERE idl.sales_txn_id=stg.sales_txn_id
        AND idl.sales_txn_type=stg.sales_txn_type
        AND idl.sales_ord_src_type=stg.sales_ord_src_type
        AND stg.src_sys_cd='EC'
        AND stg.sales_txn_dt = CAST('0001-01-01' AS DATE)
GROUP BY 1,2,3,4,5) s
SET
        sales_txn_dt=s.sales_txn_dt,
        edw_etl_step='FKEY'
WHERE s.sales_txn_id=stg.sales_txn_id
AND s.sales_txn_type=stg.sales_txn_type
AND s.sales_ord_src_type=stg.sales_ord_src_type
AND s.src_sys_cd=stg.src_sys_cd;

UPDATE 
 $DB_PARAM_STAGING.$SCHEMA1.$STG_1 stg from 
       $DB_PARAM_MASTER.$SCHEMA2.customer idl

SET  cust_sk = idl.cust_sk
   , edw_update_dttm = CAST(CURRENT_TIMESTAMP(0) as TIMESTAMP(0))
   , edw_batch_id = ${pEDW_BATCH_ID}
   , edw_etl_step = 'FKEY'

WHERE stg.ecom_acct_id = idl.cust_src_id
AND   stg.src_sys_cd = idl.src_sys_cd
AND   stg.composite_type_cd = idl.composite_type_cd
AND   stg.msg_type_cd = idl.msg_type_cd
AND   idl.src_sys_cd = '${pSRC_SYS_CD}'
AND   idl.edw_rec_end_dt = CAST('9999-12-31' AS DATE )
AND   stg.cust_sk is null
AND   stg.src_sys_cd = '${pSRC_SYS_CD}'
;

UPDATE ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_2} stg
SET
        sales_txn_dt=s.sales_txn_dt,
        edw_etl_step='FKEY'
FROM    (
SELECT  stg.sales_txn_id as sales_txn_id, idl.sales_txn_dt as sales_txn_dt,
                stg.sales_txn_type as sales_txn_type, stg.src_sys_cd as src_sys_cd , stg.sales_ord_src_type as sales_ord_src_type
        FROM ${pTGT_DATABASE_NAME}.${pTD_VIEW_DB_IDL}.sales_transaction idl, ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_2} stg
        WHERE idl.sales_txn_id=stg.sales_txn_id
        AND idl.sales_txn_type=stg.sales_txn_type
        AND idl.sales_ord_src_type=stg.sales_ord_src_type
        AND idl.src_sys_cd=stg.src_sys_cd
        AND stg.src_sys_cd='${pSRC_SYS_CD}'
        AND stg.sales_txn_dt = ${pTD_EDW_LOW_DATE}
GROUP BY 1,2,3,4,5) s
WHERE s.sales_txn_id=stg.sales_txn_id
AND s.sales_txn_type=stg.sales_txn_type
AND s.sales_ord_src_type=stg.sales_ord_src_type
AND s.src_sys_cd=stg.src_sys_cd;


INSERT INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1
(
  ecom_acct_actv_chng_sk
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, edw_rec_begin_dt
, edw_rec_end_dt
, cust_sk
, eml_stat_cd
, eml_invld_dt
, eml_invld_tm
, last_actv_dt
, last_actv_tm
, last_logn_dt
, last_logn_tm
, last_visit_store_nbr
, nbr_of_site_visit
, rx_ready_cur_mo
, rx_ready_last_mo
, rx_ready_trail_cd
, stat_update_dt
, stat_update_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT 
  a.ecom_acct_actv_chng_sk
, a.ecom_acct_id
, a.src_sys_cd
, a.composite_type_cd
, a.msg_type_cd
, a.edw_rec_begin_dt
, a.edw_rec_end_dt
, a.cust_sk
, a.eml_stat_cd
, a.eml_invld_dt
, a.eml_invld_tm
, a.last_actv_dt
, a.last_actv_tm
, a.last_logn_dt
, a.last_logn_tm
, a.last_visit_store_nbr
, a.nbr_of_site_visit
, a.rx_ready_cur_mo
, a.rx_ready_last_mo
, a.rx_ready_trail_cd
, a.stat_update_dt
, a.stat_update_tm
, a.edw_create_dttm
, a.edw_update_dttm
, a.edw_batch_id
FROM  $pTGT_DATABASE_NAME.$pTD_VIEW_DB_IDL.$pSQL_PARM_2 a
WHERE EXISTS
(
   SELECT 1
   FROM  $pVIEW_DATABASE_NAME.$pVIEW_SCHEMA.$pTABLE_NAME_1 b
   WHERE a.ecom_acct_id = b.ecom_acct_id
   AND   a.src_sys_cd = b.src_sys_cd
   AND   a.composite_type_cd = b.composite_type_cd
   AND   a.msg_type_cd = b.msg_type_cd
)
AND   a.edw_rec_end_dt = $pTD_EDW_END_DATE
AND   a.src_sys_cd = '$pSRC_SYS_CD';


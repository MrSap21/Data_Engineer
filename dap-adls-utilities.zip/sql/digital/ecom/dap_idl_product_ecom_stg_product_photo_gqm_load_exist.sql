INSERT INTO $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE
SELECT 
ecom_photo_gqm_chng_sk,
src_sys_cd,
gqm_prod_id,
ecom_prod_id,
wic,
edw_rec_begin_dt,
src_sys_prod_id_1,
src_sys_prod_id_2,
src_sys_prod_id_3,
src_sys_prod_id_4,
sku_id,
photo_origin_id,
photo_origin_prod_id,
prod_sk,
$pTD_EDW_BATCH_DATE -1,
edw_create_dttm,
edw_update_dttm,
edw_batch_id,
'CIF'
 FROM $pSTAGING_DATABASE.$pTD_DB_CIF.$pPROC_TABLE p
WHERE ( 
(case when COALESCE(p.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_1), 40) END),
(case when COALESCE(p.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_2), 40) END),
(case when COALESCE(p.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_3), 40) END),
(case when COALESCE(p.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', p.src_sys_prod_id_4), 40) END), 
p.gqm_prod_id,
p.photo_origin_id,
p.photo_origin_prod_id,
p.src_sys_cd)
IN (SELECT 
m.src_sys_prod_id_1,
m.src_sys_prod_id_2,
m.src_sys_prod_id_3,
m.src_sys_prod_id_4,
m.gqm_prod_id,
m.photo_origin_id,
m.photo_origin_prod_id,
m.src_sys_cd from  
(SELECT 
src_sys_cd,
gqm_prod_id,
ecom_prod_id,
wic,
(case when COALESCE(src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_1), 40) END) AS src_sys_prod_id_1,
(case when COALESCE(src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_2), 40) END) as src_sys_prod_id_2,
(case when COALESCE(src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_3), 40) END) as src_sys_prod_id_3,
(case when COALESCE(src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_4), 40) END) as src_sys_prod_id_4, 
sku_id,
photo_origin_id,
photo_origin_prod_id
FROM $pSTAGING_DATABASE.$pTD_DB_CIF.$pPROC_TABLE
MINUS
SELECT 
src_sys_cd,
gqm_prod_id,
ecom_prod_id,
wic,
(case when COALESCE(src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_1), 40) END) AS src_sys_prod_id_1,
(case when COALESCE(src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_2), 40) END) as src_sys_prod_id_2,
(case when COALESCE(src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_3), 40) END) as src_sys_prod_id_3,
(case when COALESCE(src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', src_sys_prod_id_4), 40) END) as src_sys_prod_id_4, 
sku_id,
photo_origin_id,
photo_origin_prod_id
FROM $pSTAGING_DATABASE.$pTD_DB_CIF.$pCIF_TABLE) m);

INSERT INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE
(
   eml_addr
 , src_sys_cd
 , store_spcl_last_optin_dttm
 , store_spcl_last_optout_dttm
 , wkly_ad_last_optin_dttm
 , wkly_ad_last_optout_dttm
 , photo_last_optin_dttm
 , photo_last_optout_dttm
 , newsltr_last_optin_dttm
 , newsltr_last_optout_dttm
 , diabetes_last_optin_dttm
 , diabetes_last_optout_dttm
 , steps_last_optin_dttm
 , steps_last_optout_dttm
 , hlth_care_last_optin_dttm
 , hlth_care_last_optout_dttm
 , edw_create_dttm
 , edw_update_dttm
 , edw_batch_id
)
WITH CTE AS (
SELECT 
   a.eml_addr
 , a.src_sys_cd
 , a.store_spcl_last_optin_dttm
 , a.store_spcl_last_optout_dttm
 , a.wkly_ad_last_optin_dttm
 , a.wkly_ad_last_optout_dttm
 , a.photo_last_optin_dttm
 , a.photo_last_optout_dttm
 , a.newsltr_last_optin_dttm
 , a.newsltr_last_optout_dttm
 , a.diabetes_last_optin_dttm
 , a.diabetes_last_optout_dttm
 , a.steps_last_optin_dttm
 , a.steps_last_optout_dttm
 , a.hlth_care_last_optin_dttm
 , a.hlth_care_last_optout_dttm
 , a.edw_create_dttm
 , a.edw_update_dttm
 , a.edw_batch_id
 ,ROW_NUMBER() OVER (PARTITION BY a.eml_addr,a.src_sys_cd ORDER BY a.edw_update_dttm DESC) AS r_count
FROM  $pIDL_DATABASE_NAME.$pTD_DB_CIF.$pIDL_TABLE a
WHERE EXISTS
(
   SELECT 1
   FROM  $pVW_DATABASE_NAME.$pTD_VW_CIF.$pVIEW_NAME b
   WHERE a.eml_addr = b.eml_addr
   AND   a.src_sys_cd = b.src_sys_cd
)
AND   a.src_sys_cd = '$pSRC_SYS_CD')
SELECT 
 eml_addr
 , src_sys_cd
 , store_spcl_last_optin_dttm
 , store_spcl_last_optout_dttm
 , wkly_ad_last_optin_dttm
 , wkly_ad_last_optout_dttm
 , photo_last_optin_dttm
 , photo_last_optout_dttm
 , newsltr_last_optin_dttm
 , newsltr_last_optout_dttm
 , diabetes_last_optin_dttm
 , diabetes_last_optout_dttm
 , steps_last_optin_dttm
 , steps_last_optout_dttm
 , hlth_care_last_optin_dttm
 , hlth_care_last_optout_dttm
 , edw_create_dttm
 , edw_update_dttm
 , edw_batch_id
FROM CTE WHERE r_count = 1;


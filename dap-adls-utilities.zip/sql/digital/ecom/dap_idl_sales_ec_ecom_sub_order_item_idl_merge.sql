MERGE INTO $pTGT_DATABASE_NAME.$schema1.$pSQL_PARM_3 tgt
USING
(
SELECT
sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
src_sys_cd,
sales_txn_type,
ship_seq_nbr,
ord_item_id,
ship_group_id,
clnt_group_id,
group_id,
clnt_line_item_id,
ord_qty,
ship_qty,
subord_lineitem_stat,
prod_id,
clnt_prod_id,
vndr_prod_id,
prod_desc,
sku_id,
upc_nbr,
upc_ck_dgt_nbr,
unit_cost_dlrs,
raw_tot_price_dlrs,
tot_dlrs,
tot_ord_discnt_share_dlrs,
tot_promo_discnt_share_dlrs,
tot_tax_dlrs,
tot_mfgr_dlrs,
src_db_sys_key,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
FROM $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_2
WHERE src_sys_cd = '$pSRC_SYS_CD'
AND sales_txn_dt <> ${pTD_EDW_LOW_DATE}
)stg
ON
        tgt.sales_txn_id = stg.sales_txn_id
        AND tgt.sales_txn_dt = stg.sales_txn_dt
        AND tgt.sales_ord_src_type = stg.sales_ord_src_type
        AND tgt.sales_txn_type = stg.sales_txn_type
        AND tgt.src_sys_cd = stg.src_sys_cd
        AND ((stg.sales_ord_src_type = 'S' AND tgt.ship_group_id = stg.ship_group_id AND tgt.ord_item_id = stg.ord_item_id) OR (stg.sales_ord_src_type <> 'S'))
        AND tgt.src_sys_cd = '$pSRC_SYS_CD'

WHEN MATCHED THEN UPDATE SET
ship_seq_nbr = stg.ship_seq_nbr
,ord_item_id = stg.ord_item_id
,ship_group_id = stg.ship_group_id
,clnt_group_id = stg.clnt_group_id
,group_id = stg.group_id
,clnt_line_item_id = stg.clnt_line_item_id
,ord_qty = stg.ord_qty
,ship_qty = stg.ship_qty
,subord_lineitem_stat = stg.subord_lineitem_stat
,prod_id = stg.prod_id
,clnt_prod_id = stg.clnt_prod_id
,vndr_prod_id = stg.vndr_prod_id
,prod_desc = stg.prod_desc
,sku_id = stg.sku_id
,upc_nbr = stg.upc_nbr
,upc_ck_dgt_nbr = stg.upc_ck_dgt_nbr
,unit_cost_dlrs = stg.unit_cost_dlrs
,raw_tot_price_dlrs = stg.raw_tot_price_dlrs
,tot_dlrs = stg.tot_dlrs
,tot_ord_discnt_share_dlrs = stg.tot_ord_discnt_share_dlrs
,tot_promo_discnt_share_dlrs = stg.tot_promo_discnt_share_dlrs
,tot_tax_dlrs = stg.tot_tax_dlrs
,tot_mfgr_dlrs = stg.tot_mfgr_dlrs
,src_db_sys_key = stg.src_db_sys_key
,edw_create_dttm = stg.edw_create_dttm
,edw_update_dttm = stg.edw_update_dttm
,edw_batch_id = stg.edw_batch_id

WHEN NOT MATCHED THEN INSERT
(
sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
src_sys_cd,
sales_txn_type,
ship_seq_nbr,
ord_item_id,
ship_group_id,
clnt_group_id,
group_id,
clnt_line_item_id,
ord_qty,
ship_qty,
subord_lineitem_stat,
prod_id,
clnt_prod_id,
vndr_prod_id,
prod_desc,
sku_id,
upc_nbr,
upc_ck_dgt_nbr,
unit_cost_dlrs,
raw_tot_price_dlrs,
tot_dlrs,
tot_ord_discnt_share_dlrs,
tot_promo_discnt_share_dlrs,
tot_tax_dlrs,
tot_mfgr_dlrs,
src_db_sys_key,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
VALUES
(
stg.sales_txn_id,
stg.sales_txn_dt,
stg.sales_ord_src_type,
stg.src_sys_cd,
stg.sales_txn_type,
stg.ship_seq_nbr,
stg.ord_item_id,
stg.ship_group_id,
stg.clnt_group_id,
stg.group_id,
stg.clnt_line_item_id,
stg.ord_qty,
stg.ship_qty,
stg.subord_lineitem_stat,
stg.prod_id,
stg.clnt_prod_id,
stg.vndr_prod_id,
stg.prod_desc,
stg.sku_id,
stg.upc_nbr,
stg.upc_ck_dgt_nbr,
stg.unit_cost_dlrs,
stg.raw_tot_price_dlrs,
stg.tot_dlrs,
stg.tot_ord_discnt_share_dlrs,
stg.tot_promo_discnt_share_dlrs,
stg.tot_tax_dlrs,
stg.tot_mfgr_dlrs,
stg.src_db_sys_key,
stg.edw_create_dttm,
stg.edw_update_dttm,
stg.edw_batch_id
);
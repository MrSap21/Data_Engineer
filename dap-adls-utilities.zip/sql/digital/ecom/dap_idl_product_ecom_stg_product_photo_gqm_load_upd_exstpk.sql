-- Update existing PK from PARENT table
begin transaction;
-- TRANS_CONTROL - Convert BT to BEGIN TRANSACTION
UPDATE $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE  
SET prod_sk = tgt.prd_sk , edw_etl_step = 'FKEY'
FROM
(SELECT DISTINCT s.prod_sk prd_sk 
                , COALESCE(m.src_sys_prod_id_1, '#') srcsys_prod_id_1
                , COALESCE(m.src_sys_prod_id_2, '#') srcsys_prod_id_2
                , COALESCE(m.src_sys_prod_id_3, '#') srcsys_prod_id_3
                , COALESCE(m.src_sys_prod_id_4, '#') srcsys_prod_id_4 
                , m.src_sys_cd             
FROM $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE m 
LEFT OUTER JOIN $pMASTER_DATA.${pTD_VIEW_DB_IDL}.$pIDL_TABLE s
ON (case when COALESCE(m.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', m.src_sys_prod_id_1), 40) END) = (case when COALESCE(s.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_1), 40) END) AND
		(case when COALESCE(m.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', m.src_sys_prod_id_2), 40) END) = (case when COALESCE(s.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_2), 40) END) AND
		(case when COALESCE(m.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', m.src_sys_prod_id_3), 40) END) = (case when COALESCE(s.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_3), 40) END) AND
		(case when COALESCE(m.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', m.src_sys_prod_id_4), 40) END) = (case when COALESCE(s.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_4), 40) END) 
WHERE
   m.src_sys_cd='$pSRC_SYS_CD' 
AND s.edw_rec_end_dt =$pTD_EDW_END_DATE
AND m.prod_sk is null
) tgt
WHERE 
$pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.prod_sk IS NULL AND
$pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_cd='$pSRC_SYS_CD' AND
(case when COALESCE($pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_prod_id_1), 40) END) = (case when COALESCE(tgt.srcsys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', tgt.srcsys_prod_id_1), 40) END) AND
(case when COALESCE($pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_prod_id_2), 40) END) = (case when COALESCE(tgt.srcsys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', tgt.srcsys_prod_id_2), 40) END) AND
(case when COALESCE($pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_prod_id_3), 40) END) = (case when COALESCE(tgt.srcsys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', tgt.srcsys_prod_id_3), 40) END) AND
(case when COALESCE($pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_prod_id_4), 40) END) = (case when COALESCE(tgt.srcsys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', tgt.srcsys_prod_id_4), 40) END) AND
$pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE.src_sys_cd = tgt.src_sys_cd;
-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM


update $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE
SET prod_sk =-1
where 
src_sys_prod_id_4='-1'
AND prod_sk is null
and src_sys_cd='$pSRC_SYS_CD';

commit;


DELETE FROM $db_param_staging.$schema1.$table1 stg
WHERE stg.src_sys_cd = '$pSRC_SYS_CD'
AND (
        (stg.dim_ecom_acct_sk is not null)
     OR (EXISTS
         (
            SELECT 1
            FROM $db_param_staging.$schema1.$table2 cif
            WHERE cif.src_sys_cd = stg.src_sys_cd
            AND   cif.cust_sk = stg.cust_sk
         )
        )
    );
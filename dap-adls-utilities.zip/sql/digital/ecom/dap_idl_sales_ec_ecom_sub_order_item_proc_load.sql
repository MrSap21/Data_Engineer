INSERT INTO $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_1
(
sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
src_sys_cd,
sales_txn_type,
ship_seq_nbr,
ord_item_id,
ship_group_id,
clnt_group_id,
group_id,
clnt_line_item_id,
ord_qty,
ship_qty,
subord_lineitem_stat,
prod_id,
clnt_prod_id,
vndr_prod_id,
prod_desc,
sku_id,
upc_nbr,
upc_ck_dgt_nbr,
unit_cost_dlrs,
raw_tot_price_dlrs,
tot_dlrs,
tot_ord_discnt_share_dlrs,
tot_promo_discnt_share_dlrs,
tot_tax_dlrs,
tot_mfgr_dlrs,
src_db_sys_key,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
SELECT
tgt.sales_txn_id,
tgt.sales_txn_dt,
tgt.sales_ord_src_type,
tgt.src_sys_cd,
tgt.sales_txn_type,
tgt.ship_seq_nbr,
tgt.ord_item_id,
tgt.ship_group_id,
tgt.clnt_group_id,
tgt.group_id,
tgt.clnt_line_item_id,
tgt.ord_qty,
tgt.ship_qty,
tgt.subord_lineitem_stat,
tgt.prod_id,
tgt.clnt_prod_id,
tgt.vndr_prod_id,
tgt.prod_desc,
tgt.sku_id,
tgt.upc_nbr,
tgt.upc_ck_dgt_nbr,
tgt.unit_cost_dlrs,
tgt.raw_tot_price_dlrs,
tgt.tot_dlrs,
tgt.tot_ord_discnt_share_dlrs,
tgt.tot_promo_discnt_share_dlrs,
tgt.tot_tax_dlrs,
tgt.tot_mfgr_dlrs,
tgt.src_db_sys_key,
tgt.edw_create_dttm,
tgt.edw_update_dttm,
tgt.edw_batch_id
FROM $pTGT_DATABASE_NAME.$schema1.$pSQL_PARM_3 tgt

WHERE EXISTS
(
SELECT 1 FROM $pSTG_DATABASE_NAME.$schema1.$pTABLE_NAME_1 cif
WHERE tgt.src_sys_cd = '$pSRC_SYS_CD'
AND tgt.sales_txn_id = cif.sales_txn_id
AND tgt.sales_txn_dt = cif.sales_txn_dt
AND tgt.sales_ord_src_type = cif.sales_ord_src_type
AND tgt.sales_txn_type = cif.sales_txn_type
);


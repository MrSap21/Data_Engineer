

INSERT INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE
SELECT  NULL
       ,a.guest_pref_id
       ,a.guest_src_id
       ,a.guest_src_cd
       ,a.guest_pref_prog_cd
       ,a.guest_pref_type_cd
       ,a.src_sys_cd
       ,CASE WHEN (b.guest_src_id IS NULL AND c.guest_src_id IS NULL)
        THEN $pTD_EDW_LOW_DATE
        ELSE try_to_date(left($pEDW_BATCH_ID,4)||'-'||substring($pEDW_BATCH_ID,5,2)||'-'||substring($pEDW_BATCH_ID,7,2))
        END as edw_rec_begin_dt
       ,a.guest_pref_val
       ,a.src_pref_eff_dt
       , $pTD_EDW_END_DATE as src_pref_expire_dt
       ,a.pref_create_user_id
       ,a.pref_create_dttm
       ,a.pref_create_src_sys_cd
       ,a.pref_update_dttm 
       ,a.pref_update_src_sys_cd
       ,a.last_update_pref_store_nbr
       ,-1 as rgstr_loc_store_sk
       ,$pTD_EDW_END_DATE
       ,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
       ,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
       ,$pEDW_BATCH_ID
       ,'CIF'
FROM $pVIEW_DATABASE_NAME.$pTD_VW_CIF.$pVIEW_NAME a
     LEFT OUTER JOIN $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE b
       ON   a.src_sys_cd = b.src_sys_cd
            AND a.guest_pref_id = b.guest_pref_id
            AND a.guest_src_id = b.guest_src_id
            AND a.guest_src_cd = b.guest_src_cd
            AND a.guest_pref_prog_cd = b.guest_pref_prog_cd
            AND a.guest_pref_type_cd = b.guest_pref_type_cd

     LEFT OUTER JOIN $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE c
       ON   b.src_sys_cd = c.src_sys_cd
            AND  b.guest_pref_id = c.guest_pref_id
            AND  b.guest_src_id = c.guest_src_id
            AND  b.guest_src_cd = c.guest_src_cd
            AND  b.guest_pref_prog_cd = c.guest_pref_prog_cd
            AND  b.guest_pref_type_cd = c.guest_pref_type_cd  

WHERE       
            a.src_sys_cd IS NOT NULL 
            AND  a.guest_pref_id IS NOT NULL 
            AND  a.guest_src_id IS NOT NULL
            AND  a.guest_src_cd IS NOT NULL
            AND  a.guest_pref_prog_cd IS NOT NULL
            AND  a.guest_pref_type_cd IS NOT NULL


AND   ((    c.guest_pref_id IS NOT NULL
       )
       OR
       (     b.guest_pref_id IS NULL
         AND c.guest_pref_id IS NULL
      ))
	  ;
 

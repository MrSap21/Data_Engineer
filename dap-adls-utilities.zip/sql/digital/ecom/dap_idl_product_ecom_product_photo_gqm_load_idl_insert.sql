INSERT INTO $pDIGITAL.$pTD_DB_IDL.$pTGT_TABLE
         (                           
          ecom_photo_gqm_chng_sk,
        src_sys_cd,
        gqm_prod_id,
        ecom_prod_id,
        wic,
        edw_rec_begin_dt,
        src_sys_prod_id_1,
        src_sys_prod_id_2,
        src_sys_prod_id_3,
        src_sys_prod_id_4,
        sku_id,
        photo_origin_id,
        photo_origin_prod_id,
        prod_sk,
        edw_rec_end_dt,
        edw_create_dttm,
        edw_update_dttm,
        edw_batch_id
                                                 
         )
 SELECT 
          STG.ecom_photo_gqm_chng_sk,
        STG.src_sys_cd,
        STG.gqm_prod_id,
        STG.ecom_prod_id,
        STG.wic,
        STG.edw_rec_begin_dt,
        STG.src_sys_prod_id_1,
        STG.src_sys_prod_id_2,
        STG.src_sys_prod_id_3,
        STG.src_sys_prod_id_4,
        STG.sku_id,
        STG.photo_origin_id,
        STG.photo_origin_prod_id,
        STG.prod_sk,
        STG.edw_rec_end_dt,
        current_timestamp(0),                   
        current_timestamp(0),
        $pEDW_BATCH_ID
FROM $pSTAGING_DATABASE.$pTD_DB_CIF.$pSTAGING_TABLE STG
WHERE 
STG.ecom_photo_gqm_chng_sk
NOT IN (SELECT 
ecom_photo_gqm_chng_sk
FROM $pDIGITAL.$pTD_DB_IDL.$pTGT_TABLE)
AND STG.prod_sk IS NOT NULL AND
STG.src_sys_cd='$pSRC_SYS_CD'; 


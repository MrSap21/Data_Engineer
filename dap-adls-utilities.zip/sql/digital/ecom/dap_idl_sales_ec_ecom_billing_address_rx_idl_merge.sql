MERGE INTO ${pTGT_DATABASE_NAME}.${pTD_DB_IDL}.${pSQL_PARM_3} tgt
USING 	
(
SELECT
distinct sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
src_sys_cd,
card_hash_val_sk,
prefix,
first_name,
middle_name,
last_name,
suffix,
addr_line_1,
addr_line_2,
addr_line_3,
city,
state_cd,
zip_cd_5,
zip_cd_4,
county,
cntry_cd,
phone_area_cd,
phone_nbr,
fax_nbr,
job_title,
company_name,
eml_addr,
edw_create_dttm,
edw_update_dttm,
edw_batch_id

FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_2}
WHERE src_sys_cd='${pSRC_SYS_CD}' AND sales_txn_dt <> $pTD_EDW_LOW_DATE
AND sales_ord_src_type='R'
)stg
ON      	
        tgt.sales_txn_id = stg.sales_txn_id	
	AND tgt.sales_txn_dt = stg.sales_txn_dt    
	AND tgt.sales_ord_src_type = stg.sales_ord_src_type
        AND tgt.sales_txn_type = stg.sales_txn_type
        --AND tgt.card_hash_val_sk = stg.card_hash_val_sk
  	AND tgt.src_sys_cd = stg.src_sys_cd
	AND tgt.src_sys_cd = '${pSRC_SYS_CD}' 
   
WHEN MATCHED THEN UPDATE SET
card_hash_val_sk=stg.card_hash_val_sk
,prefix=stg.prefix
,first_name=stg.first_name
,middle_name=stg.middle_name
,last_name=stg.last_name
,suffix=stg.suffix
,addr_line_1=stg.addr_line_1
,addr_line_2=stg.addr_line_2
,addr_line_3=stg.addr_line_3
,city=stg.city
,state_cd=stg.state_cd
,zip_cd_5=stg.zip_cd_5
,zip_cd_4=stg.zip_cd_4
,county=stg.county
,cntry_cd=stg.cntry_cd
,phone_area_cd=stg.phone_area_cd
,phone_nbr=stg.phone_nbr
,fax_nbr=stg.fax_nbr
,job_title=stg.job_title
,company_name=stg.company_name
,eml_addr=stg.eml_addr
,edw_update_dttm=stg.edw_update_dttm
,edw_batch_id=stg.edw_batch_id


WHEN NOT MATCHED THEN INSERT	
(	
 sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
src_sys_cd,
card_hash_val_sk,
prefix,
first_name,
middle_name,
last_name,
suffix,
addr_line_1,
addr_line_2,
addr_line_3,
city,
state_cd,
zip_cd_5,
zip_cd_4,
county,
cntry_cd,
phone_area_cd,
phone_nbr,
fax_nbr,
job_title,
company_name,
eml_addr,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)	
VALUES	
(	
 stg.sales_txn_id,
stg.sales_txn_dt,
stg.sales_ord_src_type,
stg.sales_txn_type,
stg.src_sys_cd,
stg.card_hash_val_sk,
stg.prefix,
stg.first_name,
stg.middle_name,
stg.last_name,
stg.suffix,
stg.addr_line_1,
stg.addr_line_2,
stg.addr_line_3,
stg.city,
stg.state_cd,
stg.zip_cd_5,
stg.zip_cd_4,
stg.county,
stg.cntry_cd,
stg.phone_area_cd,
stg.phone_nbr,
stg.fax_nbr,
stg.job_title,
stg.company_name,
stg.eml_addr,
stg.edw_create_dttm,
stg.edw_update_dttm,
stg.edw_batch_id
);	


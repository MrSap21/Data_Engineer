UPDATE $db_param_staging.$schema1.$table1
SET   edw_etl_step = 'PKEY'
WHERE edw_etl_step = 'CIF'
AND   dim_ecom_acct_sk is not null
AND   src_sys_cd = '$pSRC_SYS_CD';
UPDATE   $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE stg
FROM     $pMASTERDB_NAME.$pMASTER_TD_DB_CIF.$pLKP_TABLE_NAME idl

SET  rgstr_loc_store_sk = idl.loc_store_sk
   , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
   , edw_batch_id = $pEDW_BATCH_ID
   , edw_etl_step = 'FKEY'

WHERE stg.last_update_pref_store_nbr = idl.store_nbr
AND   idl.edw_rec_end_dt = $pTD_EDW_END_DATE
AND   stg.rgstr_loc_store_sk = -1
AND   stg.guest_pref_chng_sk is not null
AND   stg.src_sys_cd = '$pSRC_SYS_CD';


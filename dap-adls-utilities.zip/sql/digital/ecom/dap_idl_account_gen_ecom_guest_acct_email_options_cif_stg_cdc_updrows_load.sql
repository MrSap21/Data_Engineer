INSERT INTO $db_param_staging.$pTD_DB_CIF.$pSQL_PARM_1
(
  ecom_guest_acct_opts_chng_sk
, src_sys_cd
, src_sys_eml_id
, eml_addr
, edw_rec_begin_dt
, eml_vld_cd
, eml_actv_cd
, ecom_enrl_channel_cd
, reason_cd
, src_create_dttm
, src_update_dttm
, news_ltr_opt_in_cd
, store_spcl_newsltr_opt_in_cd
, wkly_ad_opt_in_cd
, wkly_ad_zip_cd
, photo_spcls_opt_in_cd
, diabetes_opt_in_cd
, cholesterol_opt_in_cd
, high_blood_presssure_opt_in_cd
, phrm_opt_in_cd
, whs_mail_rx_opt_in_cd
, whs_combo_opt_in_cd
, whs_pbm_opt_in_cd
, rgstr_store_nbr
, rgstr_loc_store_sk
, take_care_clinic_subscribe_cd
, edw_rec_end_dt
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
, edw_etl_step
)
SELECT   
  ecom_guest_acct_opts_chng_sk
, src_sys_cd
, src_sys_eml_id
, eml_addr
, edw_rec_begin_dt
, eml_vld_cd
, eml_actv_cd
, ecom_enrl_channel_cd
, reason_cd
, src_create_dttm
, src_update_dttm
, news_ltr_opt_in_cd
, store_spcl_newsltr_opt_in_cd
, wkly_ad_opt_in_cd
, wkly_ad_zip_cd
, photo_spcls_opt_in_cd
, diabetes_opt_in_cd
, cholesterol_opt_in_cd
, high_blood_presssure_opt_in_cd
, phrm_opt_in_cd
, whs_mail_rx_opt_in_cd
, whs_combo_opt_in_cd
, whs_pbm_opt_in_cd
, rgstr_store_nbr
, rgstr_loc_store_sk
, take_care_clinic_subscribe_cd
, $pTD_EDW_BATCH_DATE::date - 1 as edw_rec_end_dt
, edw_create_dttm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
, $pEDW_BATCH_ID as edw_batch_id
, 'CIF' as edw_etl_step
FROM $db_param_staging.$pTD_DB_CIF.$pSQL_PARM_2 p
WHERE (src_sys_eml_id, src_sys_cd) IN
(
   SELECT
     src_sys_eml_id
   , src_sys_cd
   FROM
   (
      SELECT   
	  src_sys_cd
	, src_sys_eml_id
	, eml_addr
	, eml_vld_cd
	, eml_actv_cd
	, ecom_enrl_channel_cd
	, reason_cd
	, src_create_dttm
	, src_update_dttm
	, news_ltr_opt_in_cd
	, store_spcl_newsltr_opt_in_cd
	, wkly_ad_opt_in_cd
	, wkly_ad_zip_cd
	, photo_spcls_opt_in_cd
	, diabetes_opt_in_cd
	, cholesterol_opt_in_cd
	, high_blood_presssure_opt_in_cd
	, phrm_opt_in_cd
	, whs_mail_rx_opt_in_cd
	, whs_combo_opt_in_cd
	, whs_pbm_opt_in_cd
	, rgstr_store_nbr
	, take_care_clinic_subscribe_cd
      FROM $db_param_staging.$pTD_DB_CIF.$pSQL_PARM_2
      WHERE src_sys_cd = '$pSRC_SYS_CD'

      MINUS

      SELECT  
	  src_sys_cd
	, src_sys_eml_id
	, eml_addr
	, eml_vld_cd
	, eml_actv_cd
	, ecom_enrl_channel_cd
	, reason_cd
	, src_create_dttm
	, src_update_dttm
	, news_ltr_opt_in_cd
	, store_spcl_newsltr_opt_in_cd
	, wkly_ad_opt_in_cd
	, wkly_ad_zip_cd
	, photo_spcls_opt_in_cd
	, diabetes_opt_in_cd
	, cholesterol_opt_in_cd
	, high_blood_presssure_opt_in_cd
	, phrm_opt_in_cd
	, whs_mail_rx_opt_in_cd
	, whs_combo_opt_in_cd
	, whs_pbm_opt_in_cd
	, rgstr_store_nbr
	, take_care_clinic_subscribe_cd
      FROM $db_param_staging.$pTD_DB_CIF.$pTABLE_NAME_1
   ) as b
);


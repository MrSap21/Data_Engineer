

DELETE FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE stg
WHERE stg.src_sys_cd='$pSRC_SYS_CD' and 
( 
         (  
              (stg.guest_pref_chng_sk is not null)
          AND (stg.rgstr_loc_store_sk <> -1 OR stg.last_update_pref_store_nbr is null OR stg.last_update_pref_store_nbr = 0)
         )
         OR (EXISTS
         (

             SELECT 1
             FROM $pVIEW_DATABASE_NAME.$pTD_VW_CIF.$pVIEW_NAME cif
             WHERE 
                   cif.src_sys_cd = stg.src_sys_cd AND
                   cif.guest_pref_id = stg.guest_pref_id AND
                   cif.guest_src_id = stg.guest_src_id AND
                   cif.guest_src_cd = stg.guest_src_cd AND
                   cif.guest_pref_prog_cd = stg.guest_pref_prog_cd AND
                   cif.guest_pref_type_cd = stg.guest_pref_type_cd
      )
     )
    );

MERGE INTO ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_2} stg
USING 	
(
SELECT
sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
src_sys_cd,
card_hash_val_sk,
prefix,
first_name,
middle_name,
last_name,
suffix,
addr_line_1,
addr_line_2,
addr_line_3,
city,
state_cd,
zip_cd_5,
zip_cd_4,
county,
cntry_cd,
phone_area_cd,
phone_nbr,
fax_nbr,
job_title,
company_name,
eml_addr,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1}
WHERE (sales_txn_id, sales_txn_dt,src_sys_cd, sales_txn_type,sales_ord_src_type, card_hash_val_sk ) IN
(
   SELECT updt.sales_txn_id, updt.sales_txn_dt, updt.src_sys_cd, updt.sales_txn_type,updt.sales_ord_src_type,updt.card_hash_val_sk
   FROM
     (
    SELECT   
   	sales_txn_id,
        sales_txn_dt,
        sales_ord_src_type,
        sales_txn_type,
        src_sys_cd,
        card_hash_val_sk,
        prefix,
        first_name,
        middle_name,
        last_name,
        suffix,
        addr_line_1,
        addr_line_2,
        addr_line_3,
        city,
        state_cd,
        zip_cd_5,
        zip_cd_4,
        county,
        cntry_cd,
        phone_area_cd,
        phone_nbr,
        fax_nbr,
        job_title,
        company_name,
        eml_addr
      FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1}
      
MINUS

	SELECT
   	sales_txn_id,
        sales_txn_dt,
        sales_ord_src_type,
        sales_txn_type,
        src_sys_cd,
        card_hash_val_sk,
        prefix,
        first_name,
        middle_name,
        last_name,
        suffix,
        addr_line_1,
        addr_line_2,
        addr_line_3,
        city,
        state_cd,
        zip_cd_5,
        zip_cd_4,
        county,
        cntry_cd,
        phone_area_cd,
        phone_nbr,
        fax_nbr,
        job_title,
        company_name,
        eml_addr
     FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_1} proc
     WHERE proc.src_sys_cd='${pSRC_SYS_CD}'
)AS updt
 ))cif
ON      	
        stg.sales_txn_id = cif.sales_txn_id
        AND stg.sales_txn_dt= cif.sales_txn_dt
        AND stg.sales_txn_type = cif.sales_txn_type
        AND  stg.sales_ord_src_type=cif.sales_ord_src_type
        AND stg.card_hash_val_sk =cif.card_hash_val_sk
	AND stg.src_sys_cd = cif.src_sys_cd
        AND stg.src_sys_cd = '${pSRC_SYS_CD}'    
WHEN MATCHED THEN UPDATE SET



prefix=cif.prefix
,first_name=cif.first_name
,middle_name=cif.middle_name
,last_name=cif.last_name
,suffix=cif.suffix
,addr_line_1=cif.addr_line_1
,addr_line_2=cif.addr_line_2
,addr_line_3=cif.addr_line_3
,city=cif.city
,state_cd=cif.state_cd
,zip_cd_5=cif.zip_cd_5
,zip_cd_4=cif.zip_cd_4
,county=cif.county
,cntry_cd=cif.cntry_cd
,phone_area_cd=cif.phone_area_cd
,phone_nbr=cif.phone_nbr
,fax_nbr=cif.fax_nbr
,job_title=cif.job_title
,company_name=cif.company_name
,eml_addr=cif.eml_addr
,edw_update_dttm = cif.edw_update_dttm
,edw_batch_id = cif.edw_batch_id
WHEN NOT MATCHED THEN INSERT	
(	
  sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
src_sys_cd,
card_hash_val_sk,
prefix,
first_name,
middle_name,
last_name,
suffix,
addr_line_1,
addr_line_2,
addr_line_3,
city,
state_cd,
zip_cd_5,
zip_cd_4,
county,
cntry_cd,
phone_area_cd,
phone_nbr,
fax_nbr,
job_title,
company_name,
eml_addr,
edw_create_dttm,
edw_update_dttm,
edw_batch_id,
edw_etl_step
)	
VALUES	
(	
 cif.sales_txn_id
,cif.sales_txn_dt
,cif.sales_ord_src_type
,cif.sales_txn_type
,cif.src_sys_cd
,cif.card_hash_val_sk
,cif.prefix
,cif.first_name
,cif.middle_name
,cif.last_name
,cif.suffix
,cif.addr_line_1
,cif.addr_line_2
,cif.addr_line_3
,cif.city
,cif.state_cd
,cif.zip_cd_5
,cif.zip_cd_4
,cif.county
,cif.cntry_cd
,cif.phone_area_cd
,cif.phone_nbr
,cif.fax_nbr
,cif.job_title
,cif.company_name
,cif.eml_addr
,cif.edw_create_dttm
,cif.edw_update_dttm
,cif.edw_batch_id
,'CIF'
);	


MERGE INTO
        $DB_PARAM_DIGITAL.$SCHEMA1.$TARGET_1 as idl
USING
(select
cust_sk
, persnl_secured_msg_id
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, secured_msg_type_cd
, secured_msg_stat_cd
, secured_msg_rcvd_dt
, secured_msg_rcvd_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
,edw_etl_step
from $DB_PARAM_STAGING.$SCHEMA1.$STG_1 where src_sys_cd = '$pSRC_SYS_CD' and cust_sk is not null )  stg
ON
    idl.cust_sk=stg.cust_sk
AND idl.persnl_secured_msg_id = stg.persnl_secured_msg_id
AND idl.ecom_acct_id = stg.ecom_acct_id
AND idl.src_sys_cd = stg.src_sys_cd
AND idl.composite_type_cd = stg.composite_type_cd
AND idl.msg_type_cd = stg.msg_type_cd
AND idl.secured_msg_type_cd = stg.secured_msg_type_cd
WHEN MATCHED
THEN UPDATE
SET
secured_msg_stat_cd = stg.secured_msg_stat_cd
,secured_msg_rcvd_dt = stg.secured_msg_rcvd_dt
,secured_msg_rcvd_tm = stg.secured_msg_rcvd_tm
,edw_update_dttm=CURRENT_TIMESTAMP(0)
,edw_batch_id=$pEDW_BATCH_ID
WHEN NOT MATCHED THEN INSERT
(
  cust_sk
, persnl_secured_msg_id
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, secured_msg_type_cd
, secured_msg_stat_cd
, secured_msg_rcvd_dt
, secured_msg_rcvd_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
VALUES
(
  stg.cust_sk
, stg.persnl_secured_msg_id
, stg.ecom_acct_id
, stg.src_sys_cd
, stg.composite_type_cd
, stg.msg_type_cd
, stg.secured_msg_type_cd
, stg.secured_msg_stat_cd
, stg.secured_msg_rcvd_dt
, stg.secured_msg_rcvd_tm
, CURRENT_TIMESTAMP(0)
, CURRENT_TIMESTAMP(0)
, $pEDW_BATCH_ID
)
;

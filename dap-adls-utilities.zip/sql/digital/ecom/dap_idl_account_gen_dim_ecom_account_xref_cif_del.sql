DELETE FROM  $db_param_staging.$schema1.$cif_table
where UPPER(src_sys_cd)='$pSRC_SYS_CD' ;
UPDATE $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE stg
SET   $pPKEY_COLUMN_NAME = c.pkey
    , edw_etl_step = 'PKEY'
FROM
(
   SELECT   (SUM(1) OVER (ORDER BY 1 ROWS UNBOUNDED PRECEDING) + :pkey) as pkey
          , edw_rec_begin_dt
          , src_sys_cd
          , guest_pref_id
          , guest_src_id
          , guest_src_cd
          , guest_pref_prog_cd
          , guest_pref_type_cd
   FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE
   WHERE $pPKEY_COLUMN_NAME is NULL
   AND src_sys_cd = '$pSRC_SYS_CD'
) as c
WHERE 
               stg.edw_rec_begin_dt = c.edw_rec_begin_dt           
            AND  stg.src_sys_cd = c.src_sys_cd
            AND  stg.guest_pref_id = c.guest_pref_id
            AND  stg.guest_src_id = c.guest_src_id
            AND  stg.guest_src_cd = c.guest_src_cd
            AND  stg.guest_pref_prog_cd = c.guest_pref_prog_cd
            AND  stg.guest_pref_type_cd = c.guest_pref_type_cd
            AND  stg.$pPKEY_COLUMN_NAME is NULL
            AND  edw_etl_step = 'CIF';

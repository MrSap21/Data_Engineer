DELETE FROM  $db_param_staging.$schema1.$table1
WHERE src_sys_cd = '$pSRC_SYS_CD';
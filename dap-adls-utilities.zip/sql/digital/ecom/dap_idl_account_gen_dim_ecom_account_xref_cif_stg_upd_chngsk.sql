UPDATE $db_param_staging.$schema1.$table1

SET   ${pPKEY_COLUMN_NAME} = c.pkey 
    , edw_etl_step = 'PKEY'
FROM
(
   SELECT   (SUM(1) OVER (ORDER BY 1 ROWS UNBOUNDED PRECEDING) + :pkey) as pkey
          , cust_sk
          , edw_rec_begin_dt
   FROM $db_param_staging.$schema1.$table1
   WHERE ${pPKEY_COLUMN_NAME} is NULL
   AND   src_sys_cd = '${pSRC_SYS_CD}' 

) as c
WHERE $db_param_staging.$schema1.$table1.edw_rec_begin_dt = c.edw_rec_begin_dt
AND   $db_param_staging.$schema1.$table1.cust_sk = c.cust_sk
AND   $db_param_staging.$schema1.$table1.${pPKEY_COLUMN_NAME} is NULL
AND   $db_param_staging.$schema1.$table1.edw_etl_step = 'CIF'
;

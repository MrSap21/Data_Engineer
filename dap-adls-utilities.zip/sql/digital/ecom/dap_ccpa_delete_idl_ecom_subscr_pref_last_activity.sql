DELETE FROM $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1;

DELETE FROM $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_COUNT_TABLE;

INSERT INTO $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1
(
tkt_nbr	
,tkt_line_seq
,tkt_open_dt
,reqst_type_cd
,eml_addr
,src_sys_cd
)
 SELECT 
 Distinct 
	stg.tkt_nbr	
	,stg.tkt_line_seq
	,stg.tkt_open_dt
	,stg.reqst_type_cd
	,tgt.eml_addr
	,tgt.src_sys_cd
	FROM
	 (SELECT eml_addr ,src_sys_cd from $pTGT_DB_NAME.$pTD_DB_CIF.$pTGT_TABLE_NAME 
	 	) tgt INNER JOIN
	( SELECT 
		tkt_nbr	
		,tkt_line_seq
		,tkt_open_dt
		,reqst_type_cd
		,cust_eml_addr
		,src_sys_cd
	FROM $pCCPA_DB_NAME.$pCCPA_SCHEMA.$pCUST_REQUEST
	WHERE reqst_type_cd='Delete'
	AND edw_reqst_complete_dt is null) stg
	ON stg.cust_eml_addr=tgt.eml_addr
	AND stg.src_sys_cd=tgt.src_sys_cd;
	
INSERT INTO $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_COUNT_TABLE
(     
tkt_nbr	,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
before_del_cnt,
after_del_cnt,
stg_tbl_rec_count)
      
SELECT 
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
  '$pSUB_AREA' as subject_area, 
  '$pDB_NAME' as db_name,
  '$pTGT_TABLE_NAME' as tbl_name,
  (SELECT CAST(count(*) as bigint) FROM $pTGT_DB_NAME.$pTD_DB_CIF.$pTGT_TABLE_NAME) as before_del_cnt,
  Null as after_del_cnt,
  (SELECT count(*) as cc FROM (SELECT tkt_nbr,src_sys_cd,eml_addr,count(*) as cnt FROM $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 group by 1,2,3) a) as del_cnt
  FROM
  $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1;															


DELETE FROM $pTGT_DB_NAME.$pTD_DB_CIF.$pTGT_TABLE_NAME tgt
WHERE EXISTS (select 1 FROM $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 stg
WHERE tgt.src_sys_cd=stg.src_sys_cd
AND tgt.eml_addr=stg.eml_addr);


UPDATE $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_COUNT_TABLE stg_cnt_tbl
SET after_del_cnt = (select cast(count(*) as bigint) FROM $pTGT_DB_NAME.$pTD_DB_CIF.$pTGT_TABLE_NAME)
WHERE  stg_cnt_tbl.db_name='$pDB_NAME'
AND stg_cnt_tbl.tbl_name='$pTGT_TABLE_NAME'
AND stg_cnt_tbl.subject_area='$pSUB_AREA';										
  
  

insert into $pCCPA_DB_NAME.$pCCPA_SCHEMA.$pTABLE_NAME4
(
Subject_Area,  
db_name,
tbl_name, 
tkt_nbr,
tkt_line_seq,
tkt_open_dt, 
reqst_type_cd,
del_rec_cnt,
rec_del_dt,
stat_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
SELECT
stg_ccpa.subject_area as subject_area
,stg_ccpa.db_name as db_name
,stg_ccpa.tbl_name as tbl_name
,stg_ccpa.tkt_nbr as tkt_nbr
,stg_ccpa.tkt_line_seq as tkt_line_seq
,stg_ccpa.tkt_open_dt as tkt_open_dt
,stg_ccpa.reqst_type_cd as reqst_type_cd
,stg_ccpa.stg_tbl_rec_count as del_rec_cnt
,current_date as rec_del_dt
,case when (stg_ccpa.before_del_cnt = stg_ccpa.after_del_cnt+del_cnt.del_count ) THEN 'S' ELSE 'E' END AS STATUS_CD
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
,$pEDW_BATCH_ID as edw_batch_id
 FROM $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_COUNT_TABLE stg_ccpa inner join 
  (SELECT distinct
subject_area as subject_area
,db_name as db_name
,tbl_name as tbl_name
,stg_tbl_rec_count as del_count
FROM $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_COUNT_TABLE
WHERE db_name='$pDB_NAME'
AND tbl_name='$pTGT_TABLE_NAME'
AND subject_area='$pSUB_AREA'
 ) del_cnt
 on 
 stg_ccpa.subject_area=del_cnt.subject_area
 AND stg_ccpa.db_name=del_cnt.db_name
 AND stg_ccpa.tbl_name=del_cnt.tbl_name;
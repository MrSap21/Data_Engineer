UPDATE $pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE
 
SET  ecom_photo_gqm_chng_sk  = s.pkey,  edw_etl_step = 'PKEY'
FROM 
  ( SELECT (SUM(1) OVER (ORDER BY 1 ROWS UNBOUNDED PRECEDING) + :pkey) AS pkey
    , src_sys_prod_id_1
    ,src_sys_prod_id_2
    ,src_sys_prod_id_3
    ,src_sys_prod_id_4
    ,gqm_prod_id
    ,photo_origin_id
    ,photo_origin_prod_id
    ,src_sys_cd        
     FROM $pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE

     WHERE ecom_photo_gqm_chng_sk IS NULL
  ) AS s
WHERE 
$pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.ecom_photo_gqm_chng_sk IS NULL AND
$pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_cd= '${pSRC_SYS_CD}' AND
(case when COALESCE($pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', $pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_prod_id_1), 40) END) = (case when COALESCE(s.src_sys_prod_id_1, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_1), 40) END) AND
(case when COALESCE($pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', $pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_prod_id_2), 40) END) = (case when COALESCE(s.src_sys_prod_id_2, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_2), 40) END) AND
(case when COALESCE($pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', $pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_prod_id_3), 40) END) = (case when COALESCE(s.src_sys_prod_id_3, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_3), 40) END) AND
(case when COALESCE($pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', $pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_prod_id_4), 40) END) = (case when COALESCE(s.src_sys_prod_id_4, '#') = '#' then '#' else RIGHT(CONCAT('0000000000000000000000000000000000000000', s.src_sys_prod_id_4), 40) END) AND
$pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.gqm_prod_id = s.gqm_prod_id AND
COALESCE($pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.photo_origin_id, '#') = s.photo_origin_id AND
COALESCE($pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.photo_origin_prod_id, '#') = s.photo_origin_prod_id AND
$pSTAGING_DATABASE.${pTD_DB_CIF}.$pSTAGING_TABLE.src_sys_cd = s.src_sys_cd AND
edw_etl_step = 'CIF'  
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
;
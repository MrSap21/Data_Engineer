
UPDATE $db_param_staging.${pTD_DB_CIF}.${pTABLE_NAME_1} stg
SET  rgstr_loc_store_sk = idl.loc_store_sk
   , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
   , edw_batch_id = ${pEDW_BATCH_ID}
   , edw_etl_step = 'FKEY'

FROM    $db_param_master.${pTD_VIEW_DB_IDL}.location_store idl

WHERE stg.rgstr_store_nbr = idl.store_nbr
AND   idl.edw_rec_end_dt = '9999-12-31'
AND   stg.rgstr_loc_store_sk is null
AND   stg.ecom_guest_acct_opts_chng_sk is not null
AND   stg.src_sys_cd = '${pSRC_SYS_CD}'
;

INSERT INTO $db_param_staging.$pTD_DB_CIF.$pPROC_TABLE
  (
   cust_sk,
   immunize_id,
   ecom_acct_id,
   src_sys_cd,
   composite_type_cd,
   msg_type_cd,
   rcmd_immunization_id,
   pat_age_in_mon,
   additional_immunization_txt,
   cmnt_txt,
   doctor_clinic_name,
   rcvd_dt,
   rcvd_tm,
   edw_create_dttm,
   edw_update_dttm,
   edw_batch_id
)
  SELECT 
        cust_sk,
         a.immunize_id,
         a.ecom_acct_id,
         a.src_sys_cd,
         a.composite_type_cd,
         a.msg_type_cd,
         a.rcmd_immunization_id,
         a.pat_age_in_mon,
         a.additional_immunization_txt,
         a.cmnt_txt,
         a.doctor_clinic_name,
         a.rcvd_dt,
         a.rcvd_tm,
         a.edw_create_dttm,
         a.edw_update_dttm,
         a.edw_batch_id
    FROM $pTGT_DATABASE_NAME.$pTD_DB_CIF.$pTGT_TABLE a
   WHERE EXISTS 
(
SELECT 1
            FROM $db_param_staging.$pTD_DB_CIF.$pCIF_TABLE  b
           WHERE a.immunize_id = b.immunize_id
             AND a.ecom_acct_id = b.ecom_acct_id
             AND a.src_sys_cd = b.src_sys_cd
             AND a.composite_type_cd = b.composite_type_cd
             AND a.msg_type_cd = b.msg_type_cd)
     AND a.src_sys_cd = '$pSRC_SYS_CD';


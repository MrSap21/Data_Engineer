begin transaction;

UPDATE $pTGT_DATABASE_NAME.$pTD_DB_IDL.$pTABLE_NAME_1 tgt

SET   loyalty_cust_sk = COALESCE(stg.loyalty_cust_sk, -1)
    , pat_cust_sk = COALESCE(stg.pat_cust_sk, -1)
    , rgstr_loc_store_sk = COALESCE(stg.rgstr_loc_store_sk, -1)
    , edw_rec_end_dt = stg.edw_rec_end_dt
    , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
    , edw_batch_id = $pEDW_BATCH_ID
FROM    $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1 stg WHERE tgt.ecom_acct_chng_sk = stg.ecom_acct_chng_sk
AND   tgt.cust_sk = stg.cust_sk
AND   stg.src_sys_cd = '$pSRC_SYS_CD'
AND   stg.edw_batch_id = $pEDW_BATCH_ID
;

INSERT INTO $pTGT_DATABASE_NAME.$pTD_DB_IDL.$pTABLE_NAME_1
(
  ecom_acct_chng_sk
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, edw_rec_begin_dt
, cust_sk
, loyalty_mbr_id
, loyalty_src_sys_cd
, loyalty_composite_type_cd
, loyalty_msg_type_cd
, loyalty_cust_sk
, aarp_mbr_cd
, acct_locked_cd
, actv_cd
, auto_refill_cd
, cntc_lens_cust_cd
, easy_open_cap_cd
, er_card_cd
, google_hlth_cd
, hipaa_accept_cd
, hipaa_accept_dt
, hipaa_accept_tm
, logn_id
, mail_service_id
, pat_id
, pat_src_sys_cd
, pat_composite_type_cd
, pat_msg_type_cd
, pat_cust_sk
, pat_locked_cd
, photo_cust_cd
, photo_granted_dt
, photo_granted_tm
, phrm_cust_cd
, phrm_granted_dt
, phrm_granted_tm
, pin_apply_dt
, pin_auth_cd
, pin_key
, pin_reqst_cd
, pin_sent_cd
, pin_sent_dt
, quick_rgstr_cd
, rgstr_store_nbr
, rgstr_dt
, rgstr_tm
, rgstr_loc_store_sk
, rembr_name_cd
, rfrng_url
, rx_high_volume_cd
, was_id
, whi_cd
, worksite_cust_cd
, ecom_acct_stat_cd
, edw_rec_end_dt
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT
  stg.ecom_acct_chng_sk
, stg.ecom_acct_id
, stg.src_sys_cd
, stg.composite_type_cd
, stg.msg_type_cd
, stg.edw_rec_begin_dt
, stg.cust_sk
, stg.loyalty_mbr_id
, stg.loyalty_src_sys_cd
, stg.loyalty_composite_type_cd
, stg.loyalty_msg_type_cd
, COALESCE(stg.loyalty_cust_sk, -1) as loyalty_cust_sk
, stg.aarp_mbr_cd
, stg.acct_locked_cd
, stg.actv_cd
, stg.auto_refill_cd
, stg.cntc_lens_cust_cd
, stg.easy_open_cap_cd
, stg.er_card_cd
, stg.google_hlth_cd
, stg.hipaa_accept_cd
, stg.hipaa_accept_dt
, stg.hipaa_accept_tm
, stg.logn_id
, stg.mail_service_id
, stg.pat_id
, stg.pat_src_sys_cd
, stg.pat_composite_type_cd
, stg.pat_msg_type_cd
, COALESCE(stg.pat_cust_sk, -1) as pat_cust_sk
, stg.pat_locked_cd
, stg.photo_cust_cd
, stg.photo_granted_dt
, stg.photo_granted_tm
, stg.phrm_cust_cd
, stg.phrm_granted_dt
, stg.phrm_granted_tm
, stg.pin_apply_dt
, stg.pin_auth_cd
, stg.pin_key
, stg.pin_reqst_cd
, stg.pin_sent_cd
, stg.pin_sent_dt
, stg.quick_rgstr_cd
, stg.rgstr_store_nbr
, stg.rgstr_dt
, stg.rgstr_tm
, COALESCE(stg.rgstr_loc_store_sk, -1) as rgstr_loc_store_sk
, stg.rembr_name_cd
, stg.rfrng_url
, stg.rx_high_volume_cd
, stg.was_id
, stg.whi_cd
, stg.worksite_cust_cd
, stg.ecom_acct_stat_cd
, stg.edw_rec_end_dt
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
, $pEDW_BATCH_ID as edw_batch_id
FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1 stg
WHERE NOT EXISTS
(
   SELECT 1
   FROM $pTGT_DATABASE_NAME.$pTD_DB_IDL.$pTABLE_NAME_1 tgt
   WHERE tgt.ecom_acct_chng_sk = stg.ecom_acct_chng_sk
   AND   tgt.cust_sk = stg.cust_sk
)
AND stg.cust_sk IS NOT NULL
AND stg.src_sys_cd = '$pSRC_SYS_CD';


commit;


UPDATE $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_2 stg
SET ship_seq_nbr = proc.ship_seq_nbr,
edw_etl_step ='SEQ'

FROM    ( SELECT sales_txn_id, ship_group_id, ord_item_id, ship_seq_nbr, src_sys_cd FROM $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_1 
  WHERE src_sys_cd = '$pSRC_SYS_CD' AND sales_ord_src_type = 'S' AND sales_txn_type = 'S' 
) proc

WHERE stg.sales_ord_src_type ='S'
AND   stg.sales_txn_type = 'S' 
AND   stg.src_sys_cd = '$pSRC_SYS_CD'
AND   stg.ship_seq_nbr = 0
AND   stg.src_sys_cd = proc.src_sys_cd
AND   stg.sales_txn_id = proc.sales_txn_id 
AND   stg.ship_group_id = proc.ship_group_id
AND   stg.ord_item_id = proc.ord_item_id 
AND   stg.sales_txn_dt <> ${pTD_EDW_LOW_DATE}
;

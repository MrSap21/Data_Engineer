DELETE FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1 stg
WHERE stg.src_sys_cd = '$pSRC_SYS_CD'
AND (
         (stg.cust_sk is not null)
      OR (EXISTS
          (
             SELECT 1
             FROM $pVIEW_DATABASE_NAME.$pVIEW_SCHEMA.$pTABLE_NAME_1 cif
             WHERE cif.ecom_acct_id = stg.ecom_acct_id
             AND   cif.src_sys_cd = stg.src_sys_cd
             AND   cif.composite_type_cd = stg.composite_type_cd
             AND   cif.msg_type_cd = stg.msg_type_cd
          )
         )
    );

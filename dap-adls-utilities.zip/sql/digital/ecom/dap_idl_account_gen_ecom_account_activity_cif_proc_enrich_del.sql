DELETE FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pTABLE_NAME_1 c
WHERE NOT EXISTS
  (
     SELECT 1
     FROM   $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1 p
     WHERE  c.ecom_acct_id = p.ecom_acct_id
     AND    c.src_sys_cd = p.src_sys_cd
     AND    c.composite_type_cd = p.composite_type_cd
     AND    c.msg_type_cd = p.msg_type_cd
  ) 
AND  COALESCE(c.eml_stat_cd, '<#>') = '<#>'
AND  COALESCE(c.eml_invld_dt, '<#>') = '<#>'
AND  COALESCE(c.eml_invld_tm, '<#>') = '<#>'
AND  COALESCE(c.last_actv_dt, '<#>') = '<#>'
AND  COALESCE(c.last_actv_tm, '<#>') = '<#>'
AND  COALESCE(c.last_logn_dt, '<#>') = '<#>'
AND  COALESCE(c.last_logn_tm, '<#>') = '<#>'
AND  COALESCE(c.last_visit_store_nbr, '<#>') = '<#>'
AND  COALESCE(c.nbr_of_site_visit, '<#>') = '<#>'
AND  COALESCE(c.rx_ready_cur_mo, '<#>') = '<#>'
AND  COALESCE(c.rx_ready_last_mo, '<#>') = '<#>'
AND  COALESCE(c.rx_ready_trail_cd, '<#>') = '<#>'
AND  COALESCE(c.stat_update_dt, '<#>') = '<#>'
AND  COALESCE(c.stat_update_tm, '<#>') = '<#>';

INSERT INTO ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pSQL_PARM_1}
(
sales_txn_id,
sales_txn_dt,
sales_ord_src_type,
sales_txn_type,
src_sys_cd,
card_hash_val_sk,
prefix,
first_name,
middle_name,
last_name,
suffix,
addr_line_1,
addr_line_2,
addr_line_3,
city,
state_cd,
zip_cd_5,
zip_cd_4,
county,
cntry_cd,
phone_area_cd,
phone_nbr,
fax_nbr,
job_title,
company_name,
eml_addr,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
SELECT
tgt.sales_txn_id,
tgt.sales_txn_dt,
tgt.sales_ord_src_type,
tgt.sales_txn_type,
tgt.src_sys_cd,
tgt.card_hash_val_sk,
tgt.prefix,
tgt.first_name,
tgt.middle_name,
tgt.last_name,
tgt.suffix,
tgt.addr_line_1,
tgt.addr_line_2,
tgt.addr_line_3,
tgt.city,
tgt.state_cd,
tgt.zip_cd_5,
tgt.zip_cd_4,
tgt.county,
tgt.cntry_cd,
tgt.phone_area_cd,
tgt.phone_nbr,
tgt.fax_nbr,
tgt.job_title,
tgt.company_name,
tgt.eml_addr,
tgt.edw_create_dttm,
tgt.edw_update_dttm,
tgt.edw_batch_id
FROM ${pTGT_DATABASE_NAME}.${pTD_VIEW_DB_IDL}.${pSQL_PARM_3} tgt

WHERE EXISTS
(
SELECT 1 FROM ${pSTG_DATABASE_NAME}.${pTD_DB_CIF}.${pTABLE_NAME_1} cif
WHERE tgt.src_sys_cd = '${pSRC_SYS_CD}'
AND tgt.sales_txn_id = cif.sales_txn_id
AND tgt.card_hash_val_sk = cif.card_hash_val_sk
AND tgt.sales_ord_src_type = cif.sales_ord_src_type
AND tgt.sales_txn_type = cif.sales_txn_type
);


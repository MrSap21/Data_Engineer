MERGE INTO $pIDL_DATABASE_NAME.$pTD_DB_CIF.$pIDL_TABLE as idl
USING
(
   SELECT 
      eml_addr
    , src_sys_cd
    , store_spcl_last_optin_dttm
    , store_spcl_last_optout_dttm
    , wkly_ad_last_optin_dttm
    , wkly_ad_last_optout_dttm
    , photo_last_optin_dttm
    , photo_last_optout_dttm
    , newsltr_last_optin_dttm
    , newsltr_last_optout_dttm
    , diabetes_last_optin_dttm
    , diabetes_last_optout_dttm
    , steps_last_optin_dttm
    , steps_last_optout_dttm
    , hlth_care_last_optin_dttm
    , hlth_care_last_optout_dttm
    , edw_create_dttm
    , edw_update_dttm
    , edw_batch_id
   FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE 
   WHERE src_sys_cd = '$pSRC_SYS_CD' 
) stg 
ON  idl.eml_addr = stg.eml_addr
AND idl.src_sys_cd = stg.src_sys_cd AND idl.edw_update_dttm = stg.edw_update_dttm

WHEN MATCHED 
THEN UPDATE SET
   store_spcl_last_optin_dttm = stg.store_spcl_last_optin_dttm
 , store_spcl_last_optout_dttm = stg.store_spcl_last_optout_dttm
 , wkly_ad_last_optin_dttm = stg.wkly_ad_last_optin_dttm
 , wkly_ad_last_optout_dttm = stg.wkly_ad_last_optout_dttm
 , photo_last_optin_dttm = stg.photo_last_optin_dttm
 , photo_last_optout_dttm = stg.photo_last_optout_dttm
 , newsltr_last_optin_dttm = stg.newsltr_last_optin_dttm
 , newsltr_last_optout_dttm = stg.newsltr_last_optout_dttm
 , diabetes_last_optin_dttm = stg.diabetes_last_optin_dttm
 , diabetes_last_optout_dttm = stg.diabetes_last_optout_dttm
 , steps_last_optin_dttm = stg.steps_last_optin_dttm
 , steps_last_optout_dttm = stg.steps_last_optout_dttm
 , hlth_care_last_optin_dttm = stg.hlth_care_last_optin_dttm
 , hlth_care_last_optout_dttm = stg.hlth_care_last_optout_dttm
 , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
 , edw_batch_id = $pEDW_BATCH_ID

WHEN NOT MATCHED THEN INSERT
(
   eml_addr
 , src_sys_cd
 , store_spcl_last_optin_dttm
 , store_spcl_last_optout_dttm
 , wkly_ad_last_optin_dttm
 , wkly_ad_last_optout_dttm
 , photo_last_optin_dttm
 , photo_last_optout_dttm
 , newsltr_last_optin_dttm
 , newsltr_last_optout_dttm
 , diabetes_last_optin_dttm
 , diabetes_last_optout_dttm
 , steps_last_optin_dttm
 , steps_last_optout_dttm
 , hlth_care_last_optin_dttm
 , hlth_care_last_optout_dttm
 , edw_create_dttm
 , edw_update_dttm
 , edw_batch_id
) 
VALUES
(
   stg.eml_addr
 , stg.src_sys_cd
 , stg.store_spcl_last_optin_dttm
 , stg.store_spcl_last_optout_dttm
 , stg.wkly_ad_last_optin_dttm
 , stg.wkly_ad_last_optout_dttm
 , stg.photo_last_optin_dttm
 , stg.photo_last_optout_dttm
 , stg.newsltr_last_optin_dttm
 , stg.newsltr_last_optout_dttm
 , stg.diabetes_last_optin_dttm
 , stg.diabetes_last_optout_dttm
 , stg.steps_last_optin_dttm
 , stg.steps_last_optout_dttm
 , stg.hlth_care_last_optin_dttm
 , stg.hlth_care_last_optout_dttm
 , to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
 , to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
 , $pEDW_BATCH_ID
);


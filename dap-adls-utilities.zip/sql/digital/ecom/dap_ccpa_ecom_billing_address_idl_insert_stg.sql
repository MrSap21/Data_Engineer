delete from ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_1};
delete from ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_2};
INSERT INTO ${pSTG_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_1}
(tkt_nbr
,tkt_line_seq
,tkt_open_dt
,reqst_type_cd,
sales_txn_id ,	
sales_txn_dt ,
sales_ord_src_type,
 sales_txn_type,
src_sys_cd,
 src_cust_id
)

SELECT
DISTINCT
req.tkt_nbr,
req.tkt_line_seq,
req.tkt_open_dt,
req.reqst_type_cd,
sl.sales_txn_id ,	
sl.sales_txn_dt ,
sl.sales_ord_src_type,
sl. sales_txn_type,
sl.src_sys_cd,
sl.src_cust_id
FROM 
(select         
	     	sales_txn_id
		,sales_txn_dt
		,sales_ord_src_type
		,sales_txn_type
		,src_sys_cd
		,src_cust_id 
from  ${pTGT_DATABASE_NAME}.${pTD_DB_RETAIL}.${pTABLE_NAME_3}
where  sales_ord_src_type in ('P','S'))  SL
INNER JOIN
(select 
		tkt_nbr	
		,tkt_line_seq
		,tkt_open_dt
		,reqst_type_cd
		,cust_src_id
		,composite_type_cd
		,msg_type_cd
		,src_sys_cd
from ${pTGT_DATABASE_NAME}.${pTD_DB_CCPA}.${pTABLE_NAME_4}
where reqst_type_cd='Delete'
and edw_reqst_complete_dt is null)req
ON SL.src_cust_id  = req.cust_src_id;
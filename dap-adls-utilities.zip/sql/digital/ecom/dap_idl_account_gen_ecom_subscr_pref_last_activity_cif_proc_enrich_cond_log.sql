MERGE INTO $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pCIF_TABLE cif USING 
( 
  SELECT  
     SUBSTRING(MAX(sortColumn || eml_addr),2, len(MAX(sortColumn || eml_addr)) - 2 + 1) as eml_addr
   , SUBSTRING(MAX(sortColumn || src_sys_cd),2, len(MAX(sortColumn || src_sys_cd)) - 2 + 1) as src_sys_cd
   , SUBSTRING(MAX(sortColumn || store_spcl_last_optin_dttm ),2, len(MAX(sortColumn || store_spcl_last_optin_dttm )) - 2 + 1) as store_spcl_last_optin_dttm
   , SUBSTRING(MAX(sortColumn || store_spcl_last_optout_dttm ),2, len(MAX(sortColumn || store_spcl_last_optout_dttm )) - 2 + 1) as store_spcl_last_optout_dttm
   , SUBSTRING(MAX(sortColumn || wkly_ad_last_optin_dttm ),2, len(MAX(sortColumn || wkly_ad_last_optin_dttm )) - 2 + 1) as wkly_ad_last_optin_dttm
   , SUBSTRING(MAX(sortColumn || wkly_ad_last_optout_dttm ),2, len(MAX(sortColumn || wkly_ad_last_optout_dttm )) - 2 + 1) as wkly_ad_last_optout_dttm
   , SUBSTRING(MAX(sortColumn || photo_last_optin_dttm ),2, len(MAX(sortColumn || photo_last_optin_dttm )) - 2 + 1) as photo_last_optin_dttm
   , SUBSTRING(MAX(sortColumn || photo_last_optout_dttm ),2, len(MAX(sortColumn || photo_last_optout_dttm )) - 2 + 1) as photo_last_optout_dttm
   , SUBSTRING(MAX(sortColumn || newsltr_last_optin_dttm ),2, len(MAX(sortColumn || newsltr_last_optin_dttm )) - 2 + 1) as newsltr_last_optin_dttm
   , SUBSTRING(MAX(sortColumn || newsltr_last_optout_dttm ),2, len(MAX(sortColumn || newsltr_last_optout_dttm )) - 2 + 1) as newsltr_last_optout_dttm
   , SUBSTRING(MAX(sortColumn || diabetes_last_optin_dttm ),2, len(MAX(sortColumn || diabetes_last_optin_dttm )) - 2 + 1) as diabetes_last_optin_dttm
   , SUBSTRING(MAX(sortColumn || diabetes_last_optout_dttm ),2, len(MAX(sortColumn || diabetes_last_optout_dttm )) - 2 + 1) as diabetes_last_optout_dttm
   , SUBSTRING(MAX(sortColumn || steps_last_optin_dttm ),2, len(MAX(sortColumn || steps_last_optin_dttm )) - 2 + 1) as steps_last_optin_dttm
   , SUBSTRING(MAX(sortColumn || steps_last_optout_dttm ),2, len(MAX(sortColumn || steps_last_optout_dttm )) - 2 + 1) as steps_last_optout_dttm
   , SUBSTRING(MAX(sortColumn || hlth_care_last_optin_dttm ),2, len(MAX(sortColumn || hlth_care_last_optin_dttm )) - 2 + 1) as hlth_care_last_optin_dttm
   , SUBSTRING(MAX(sortColumn || hlth_care_last_optout_dttm ),2, len(MAX(sortColumn || hlth_care_last_optout_dttm )) - 2 + 1) as hlth_care_last_optout_dttm
  FROM 
  ( 
    ( 
      SELECT 
         '0' sortColumn 
       , eml_addr
       , src_sys_cd
       , SUBSTRING(CAST(store_spcl_last_optin_dttm as VARCHAR()),1,19) as store_spcl_last_optin_dttm
       , SUBSTRING(CAST(store_spcl_last_optout_dttm as VARCHAR()),1,19) as store_spcl_last_optout_dttm
       , SUBSTRING(CAST(wkly_ad_last_optin_dttm as VARCHAR()),1,19) as wkly_ad_last_optin_dttm
       , SUBSTRING(CAST(wkly_ad_last_optout_dttm as VARCHAR()),1,19) as wkly_ad_last_optout_dttm
       , SUBSTRING(CAST(photo_last_optin_dttm as VARCHAR()),1,19) as photo_last_optin_dttm
       , SUBSTRING(CAST(photo_last_optout_dttm as VARCHAR()),1,19) as photo_last_optout_dttm
       , SUBSTRING(CAST(newsltr_last_optin_dttm as VARCHAR()),1,19) as newsltr_last_optin_dttm
       , SUBSTRING(CAST(newsltr_last_optout_dttm as VARCHAR()),1,19) as newsltr_last_optout_dttm
       , SUBSTRING(CAST(diabetes_last_optin_dttm as VARCHAR()),1,19) as diabetes_last_optin_dttm
       , SUBSTRING(CAST(diabetes_last_optout_dttm as VARCHAR()),1,19) as diabetes_last_optout_dttm
       , SUBSTRING(CAST(steps_last_optin_dttm as VARCHAR()),1,19) as steps_last_optin_dttm
       , SUBSTRING(CAST(steps_last_optout_dttm as VARCHAR()),1,19) as steps_last_optout_dttm
       , SUBSTRING(CAST(hlth_care_last_optin_dttm as VARCHAR()),1,19) as hlth_care_last_optin_dttm
       , SUBSTRING(CAST(hlth_care_last_optout_dttm as VARCHAR()),1,19) as hlth_care_last_optout_dttm
      FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE
      WHERE src_sys_cd = '$pSRC_SYS_CD'
    ) 
 
  UNION ALL 

    ( 
      SELECT 
         '1' sortColumn 
       , eml_addr
       , src_sys_cd
       , store_spcl_last_optin_dttm
       , store_spcl_last_optout_dttm
       , wkly_ad_last_optin_dttm
       , wkly_ad_last_optout_dttm
       , photo_last_optin_dttm
       , photo_last_optout_dttm
       , newsltr_last_optin_dttm
       , newsltr_last_optout_dttm
       , diabetes_last_optin_dttm
       , diabetes_last_optout_dttm
       , steps_last_optin_dttm
       , steps_last_optout_dttm
       , hlth_care_last_optin_dttm
       , hlth_care_last_optout_dttm
      FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pCIF_TABLE a 
      WHERE EXISTS 
            (
              SELECT 1 
              FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pPROC_TABLE b
              WHERE b.eml_addr = a.eml_addr 
              AND   b.src_sys_cd = a.src_sys_cd 
              AND   b.src_sys_cd = '$pSRC_SYS_CD'
            )
    ) 
  ) as a_union 
  GROUP BY eml_addr, src_sys_cd
) as proc_enrich 
ON   proc_enrich.eml_addr = cif.eml_addr
AND  proc_enrich.src_sys_cd = cif.src_sys_cd

WHEN MATCHED THEN UPDATE SET 
   cif.store_spcl_last_optin_dttm = proc_enrich.store_spcl_last_optin_dttm
 , cif.store_spcl_last_optout_dttm = proc_enrich.store_spcl_last_optout_dttm
 , cif.wkly_ad_last_optin_dttm = proc_enrich.wkly_ad_last_optin_dttm
 , cif.wkly_ad_last_optout_dttm = proc_enrich.wkly_ad_last_optout_dttm
 , cif.photo_last_optin_dttm = proc_enrich.photo_last_optin_dttm
 , cif.photo_last_optout_dttm = proc_enrich.photo_last_optout_dttm
 , cif.newsltr_last_optin_dttm = proc_enrich.newsltr_last_optin_dttm
 , cif.newsltr_last_optout_dttm = proc_enrich.newsltr_last_optout_dttm
 , cif.diabetes_last_optin_dttm = proc_enrich.diabetes_last_optin_dttm
 , cif.diabetes_last_optout_dttm = proc_enrich.diabetes_last_optout_dttm
 , cif.steps_last_optin_dttm = proc_enrich.steps_last_optin_dttm
 , cif.steps_last_optout_dttm = proc_enrich.steps_last_optout_dttm
 , cif.hlth_care_last_optin_dttm = proc_enrich.hlth_care_last_optin_dttm
 , cif.hlth_care_last_optout_dttm = proc_enrich.hlth_care_last_optout_dttm;


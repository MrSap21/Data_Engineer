
Delete from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1;

Delete from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2;

insert into $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1
(
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
guest_pref_chng_sk,
guest_pref_id,
guest_src_id,
guest_pref_prog_cd,
guest_pref_type_cd,
src_sys_cd
)
select 
	req.tkt_nbr,
	req.tkt_line_seq,
	req.tkt_open_dt,
	req.reqst_type_cd,
	stg.guest_pref_chng_sk,
	stg.guest_pref_id,
	stg.guest_src_id,
	stg.guest_pref_prog_cd,
	stg.guest_pref_type_cd,
	stg.src_sys_cd
from 
 (select guest_pref_chng_sk, guest_pref_id, guest_src_id, guest_pref_prog_cd, guest_pref_type_cd, src_sys_cd from $pTGT_DB_NAME.$pTD_DB_CIF.$pTGT_TABLE_NAME) stg
 inner join 
 (select 
    tkt_nbr,
	tkt_line_seq,
	tkt_open_dt,
	reqst_type_cd,
	cust_eml_addr,
	src_sys_cd
	from 
    $pCCPA_DB_NAME.$pCCPA_SCHEMA.$pCUST_REQUEST
    where reqst_type_cd = 'Delete'
	and edw_reqst_complete_dt is null) req
	on stg.guest_src_id = req.cust_eml_addr
	and stg.src_sys_cd = req.src_sys_cd;
	

insert into $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2
(     
tkt_nbr	,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
subject_area,
db_name,
tbl_name,
before_del_cnt,
after_del_cnt,
stg_tbl_rec_count)
      
Select 
tkt_nbr,
tkt_line_seq,
tkt_open_dt,
reqst_type_cd,
  '$pSUB_AREA' as subject_area, 
  '$pDB_NAME' as db_name,
  '$pTGT_TABLE_NAME' as tbl_name,
  (select cast(count(*) as bigint) from $pTGT_DB_NAME.$pTD_DB_CIF.$pTGT_TABLE_NAME
) as before_del_cnt,
  Null as after_del_cnt,
  (select count(*) as cc from 
	(select tkt_nbr,guest_pref_chng_sk,guest_pref_id,guest_src_id,guest_pref_prog_cd,guest_pref_type_cd,src_sys_cd,count(*) as cnt 
	from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 group by 1,2,3,4,5,6,7) a) as del_cnt
  from
  $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 
; 						


delete from $pTGT_DB_NAME.$pTD_DB_CIF.$pTGT_TABLE_NAME tgt
where exists (select 1 from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_1 stg
where  tgt.guest_pref_chng_sk = stg.guest_pref_chng_sk
  		 and tgt.guest_pref_id = stg.guest_pref_id
  		 and tgt.guest_src_id = stg.guest_src_id
  		 and tgt.guest_pref_prog_cd = stg.guest_pref_prog_cd
  		 and tgt.guest_pref_type_cd = stg.guest_pref_type_cd
  		 and tgt.src_sys_cd = stg.src_sys_cd);
		 		 
		 
update $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2 stg_cnt_tbl
set after_del_cnt = (select cast(count(*) as bigint) from $pTGT_DB_NAME.$pTD_DB_CIF.$pTGT_TABLE_NAME)
where  stg_cnt_tbl.db_name='$pDB_NAME'
and stg_cnt_tbl.tbl_name='$pTGT_TABLE_NAME'
and stg_cnt_tbl.subject_area='$pSUB_AREA';

insert into $pCCPA_DB_NAME.$pCCPA_SCHEMA.$pTABLE_NAME4
(
Subject_Area,  
db_name,
tbl_name, 
tkt_nbr,
tkt_line_seq,
tkt_open_dt, 
reqst_type_cd,
del_rec_cnt,
rec_del_dt,
stat_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
select
stg_ccpa.subject_area as subject_area
,stg_ccpa.db_name as db_name
,stg_ccpa.tbl_name as tbl_name
,stg_ccpa.tkt_nbr as tkt_nbr
,stg_ccpa.tkt_line_seq as tkt_line_seq
,stg_ccpa.tkt_open_dt as tkt_open_dt
,stg_ccpa.reqst_type_cd as reqst_type_cd
,stg_ccpa.stg_tbl_rec_count as del_rec_cnt
,current_date as rec_del_dt
, case when (stg_ccpa.before_del_cnt = stg_ccpa.after_del_cnt+del_cnt.del_count ) THEN 'S' ELSE 'E' END AS STATUS_CD
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
,to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
,$pEDW_BATCH_ID as edw_batch_id
 from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2 stg_ccpa inner join 
  (select distinct
subject_area as subject_area
,db_name as db_name
,tbl_name as tbl_name
,stg_tbl_rec_count as del_count
from $pDB_STAGING.$pCCPA_SCHEMA.$pCCPA_TABLE_2
where db_name='$pDB_NAME'
and tbl_name='$pTGT_TABLE_NAME'
and subject_area='$pSUB_AREA'
) del_cnt
 on 
 stg_ccpa.subject_area=del_cnt.subject_area
 and stg_ccpa.db_name=del_cnt.db_name
 and stg_ccpa.tbl_name=del_cnt.tbl_name;
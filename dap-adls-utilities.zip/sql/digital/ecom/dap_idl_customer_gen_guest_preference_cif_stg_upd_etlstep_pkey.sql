UPDATE $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSTG_TABLE 
SET   edw_etl_step = 'PKEY'
WHERE edw_etl_step = 'CIF'
AND   guest_pref_chng_sk is not null
AND   src_sys_cd = '$pSRC_SYS_CD';


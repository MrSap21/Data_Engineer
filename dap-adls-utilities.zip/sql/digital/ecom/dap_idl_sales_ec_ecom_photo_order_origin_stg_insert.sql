INSERT INTO $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_2
(	
   photo_origin_id,
   src_sys_cd,
   cntc_name,
   origin_name,
   city,
   state,
   addr,
   zip_cd_5,
   zip_cd_4,
   mobile_affiliate,
   wag_mobile_affiliate,
   actv_ind,
   sub_type_cd,
   edw_create_dttm,
   edw_update_dttm,
   edw_batch_id,
   edw_etl_step
)
SELECT
   photo_origin_id,
   src_sys_cd,
   cntc_name,
   origin_name,
   city,
   state,
   addr,
   zip_cd_5,
   zip_cd_4,
   mobile_affiliate,
   wag_mobile_affiliate,
   actv_ind,
   sub_type_cd,
   edw_create_dttm,
   edw_update_dttm,
   edw_batch_id,
   'CIF' as edw_etl_step
FROM $pSTG_DATABASE_NAME.$schema1.$pTABLE_NAME_1
WHERE (photo_origin_id,src_sys_cd) IN
(
   SELECT updt.photo_origin_id,updt.src_sys_cd
   FROM
   (
    SELECT   
    photo_origin_id,
    src_sys_cd,
    cntc_name,
    origin_name,
    city,
    state,
    addr,
    zip_cd_5,
    zip_cd_4,
    mobile_affiliate,
    wag_mobile_affiliate,
    actv_ind,
    sub_type_cd
    FROM $pSTG_DATABASE_NAME.$schema1.$pTABLE_NAME_1
      
MINUS

    SELECT
    photo_origin_id,
    src_sys_cd,
    cntc_name,
    origin_name,
    city,
    state,
    addr,
    zip_cd_5,
    zip_cd_4,
    mobile_affiliate,
    wag_mobile_affiliate,
    actv_ind,
    sub_type_cd
    FROM $pSTG_DATABASE_NAME.$schema1.$pSQL_PARM_1 proc
    WHERE proc.src_sys_cd='$pSRC_SYS_CD'
   )AS updt
);
	


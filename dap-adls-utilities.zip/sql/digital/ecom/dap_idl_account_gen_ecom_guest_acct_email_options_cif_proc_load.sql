INSERT INTO $db_param_staging.$pTD_DB_CIF.$pSQL_PARM_1
(
  ecom_guest_acct_opts_chng_sk
, src_sys_cd
, src_sys_eml_id
, eml_addr
, edw_rec_begin_dt
, eml_vld_cd
, eml_actv_cd
, ecom_enrl_channel_cd
, reason_cd
, src_create_dttm
, src_update_dttm
, news_ltr_opt_in_cd
, store_spcl_newsltr_opt_in_cd
, wkly_ad_opt_in_cd
, wkly_ad_zip_cd
, photo_spcls_opt_in_cd
, diabetes_opt_in_cd
, cholesterol_opt_in_cd
, high_blood_presssure_opt_in_cd
, phrm_opt_in_cd
, whs_mail_rx_opt_in_cd
, whs_combo_opt_in_cd
, whs_pbm_opt_in_cd
, rgstr_store_nbr
, rgstr_loc_store_sk
, take_care_clinic_subscribe_cd
, edw_rec_end_dt
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT 
  a.ecom_guest_acct_opts_chng_sk
, a.src_sys_cd
, a.src_sys_eml_id
, a.eml_addr
, a.edw_rec_begin_dt
, a.eml_vld_cd
, a.eml_actv_cd
, a.ecom_enrl_channel_cd
, a.reason_cd
, a.src_create_dttm
, a.src_update_dttm
, a.news_ltr_opt_in_cd
, a.store_spcl_newsltr_opt_in_cd
, a.wkly_ad_opt_in_cd
, a.wkly_ad_zip_cd
, a.photo_spcls_opt_in_cd
, a.diabetes_opt_in_cd
, a.cholesterol_opt_in_cd
, a.high_blood_presssure_opt_in_cd
, a.phrm_opt_in_cd
, a.whs_mail_rx_opt_in_cd
, a.whs_combo_opt_in_cd
, a.whs_pbm_opt_in_cd
, a.rgstr_store_nbr
, CASE WHEN (a.rgstr_loc_store_sk = -1) THEN NULL ELSE a.rgstr_loc_store_sk END as rgstr_loc_store_sk
, a.take_care_clinic_subscribe_cd
, a.edw_rec_end_dt
, a.edw_create_dttm
, a.edw_update_dttm
, a.edw_batch_id
FROM  $db_param_digital.$pTD_VIEW_DB_IDL.$pSQL_PARM_2 a
WHERE EXISTS
(
   SELECT 1
   FROM  $db_param_staging.$pTD_DB_CIF.$pTABLE_NAME_1 b
   WHERE a.src_sys_eml_id = b.src_sys_eml_id
   AND   a.src_sys_cd = b.src_sys_cd
)
AND   a.edw_rec_end_dt = '9999-12-31'
AND   a.src_sys_cd = '$pSRC_SYS_CD';


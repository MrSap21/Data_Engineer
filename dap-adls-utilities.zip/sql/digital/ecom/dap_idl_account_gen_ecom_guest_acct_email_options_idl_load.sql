begin transaction;

UPDATE $db_param_digital.$pTD_DB_IDL.$pTABLE_NAME_1 tgt

SET  rgstr_loc_store_sk = COALESCE(stg.rgstr_loc_store_sk, -1)
    , edw_rec_end_dt = stg.edw_rec_end_dt
    , edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')
    , edw_batch_id = $pEDW_BATCH_ID
FROM    $db_param_staging.$pTD_DB_CIF.$pSQL_PARM_1 stg WHERE tgt.ecom_guest_acct_opts_chng_sk = stg.ecom_guest_acct_opts_chng_sk
AND   stg.src_sys_cd = '$pSRC_SYS_CD'
AND   stg.edw_batch_id = $pEDW_BATCH_ID
;

INSERT INTO $db_param_digital.$pTD_DB_IDL.$pTABLE_NAME_1
(
  ecom_guest_acct_opts_chng_sk
, src_sys_cd
, src_sys_eml_id
, eml_addr
, edw_rec_begin_dt
, eml_vld_cd
, eml_actv_cd
, ecom_enrl_channel_cd
, reason_cd
, src_create_dttm
, src_update_dttm
, news_ltr_opt_in_cd
, store_spcl_newsltr_opt_in_cd
, wkly_ad_opt_in_cd
, wkly_ad_zip_cd
, photo_spcls_opt_in_cd
, diabetes_opt_in_cd
, cholesterol_opt_in_cd
, high_blood_presssure_opt_in_cd
, phrm_opt_in_cd
, whs_mail_rx_opt_in_cd
, whs_combo_opt_in_cd
, whs_pbm_opt_in_cd
, rgstr_store_nbr
, rgstr_loc_store_sk
, take_care_clinic_subscribe_cd
, edw_rec_end_dt
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT
  stg.ecom_guest_acct_opts_chng_sk
, stg.src_sys_cd
, stg.src_sys_eml_id
, stg.eml_addr
, stg.edw_rec_begin_dt
, stg.eml_vld_cd
, stg.eml_actv_cd
, stg.ecom_enrl_channel_cd
, stg.reason_cd
, stg.src_create_dttm
, stg.src_update_dttm
, stg.news_ltr_opt_in_cd
, stg.store_spcl_newsltr_opt_in_cd
, stg.wkly_ad_opt_in_cd
, stg.wkly_ad_zip_cd
, stg.photo_spcls_opt_in_cd
, stg.diabetes_opt_in_cd
, stg.cholesterol_opt_in_cd
, stg.high_blood_presssure_opt_in_cd
, stg.phrm_opt_in_cd
, stg.whs_mail_rx_opt_in_cd
, stg.whs_combo_opt_in_cd
, stg.whs_pbm_opt_in_cd
, stg.rgstr_store_nbr
, COALESCE(stg.rgstr_loc_store_sk, -1) as rgstr_loc_store_sk
, stg.take_care_clinic_subscribe_cd
, stg.edw_rec_end_dt
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_create_dttm
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') as edw_update_dttm
, $pEDW_BATCH_ID as edw_batch_id
FROM $db_param_staging.$pTD_DB_CIF.$pSQL_PARM_1 stg
WHERE NOT EXISTS
(
   SELECT 1
   FROM $db_param_digital.$pTD_DB_IDL.$pTABLE_NAME_1 tgt
   WHERE tgt.ecom_guest_acct_opts_chng_sk = stg.ecom_guest_acct_opts_chng_sk
)
AND stg.src_sys_cd = '$pSRC_SYS_CD';


commit;


MERGE INTO $db_param_staging.$pTD_DB_CIF.$pSTG_TABLE stg	
USING 	
(SELECT	
 immunize_id as   immunize_id
,   ecom_acct_id as   ecom_acct_id
,   src_sys_cd as   src_sys_cd
,   composite_type_cd as   composite_type_cd
,   msg_type_cd as   msg_type_cd
,   rcmd_immunization_id as   rcmd_immunization_id
,   pat_age_in_mon as   pat_age_in_mon
,   additional_immunization_txt as   additional_immunization_txt
,   cmnt_txt as   cmnt_txt
,   doctor_clinic_name as   doctor_clinic_name
,   rcvd_dt as   rcvd_dt
,   rcvd_tm as   rcvd_tm
FROM $db_param_staging.$pTD_DB_CIF.$pCIF_TABLE c
WHERE (immunize_id,ecom_acct_id, src_sys_cd, composite_type_cd, msg_type_cd) IN
(
   SELECT
     immunize_id
,    ecom_acct_id
,    src_sys_cd
,    composite_type_cd
,    msg_type_cd
   FROM
   (
      SELECT   
          immunize_id
        ,    ecom_acct_id
        ,    src_sys_cd
        ,    composite_type_cd
        ,    msg_type_cd
        ,    rcmd_immunization_id
        ,    pat_age_in_mon
        ,    additional_immunization_txt
        ,    cmnt_txt
        ,    doctor_clinic_name
        ,    rcvd_dt
        ,    rcvd_tm
      FROM $db_param_staging.$pTD_DB_CIF.$pCIF_TABLE
      

      MINUS

      SELECT  
          immunize_id
        ,    ecom_acct_id
        ,    src_sys_cd
        ,    composite_type_cd
        ,    msg_type_cd
        ,    rcmd_immunization_id
        ,    pat_age_in_mon
        ,    additional_immunization_txt
        ,    cmnt_txt
        ,    doctor_clinic_name
        ,    rcvd_dt
        ,    rcvd_tm
      FROM $db_param_staging.$pTD_DB_CIF.$pPROC_TABLE
      WHERE src_sys_cd = '$pSRC_SYS_CD')AS B
 ))CIF
ON      	
        stg.immunize_id = CIF.immunize_id	
	AND stg.ecom_acct_id = CIF.ecom_acct_id    
	AND stg.src_sys_cd = CIF.src_sys_cd
	AND stg.composite_type_cd = CIF.composite_type_cd
	AND stg.msg_type_cd = CIF.msg_type_cd
	AND stg.src_sys_cd = '$pSRC_SYS_CD'    
WHEN MATCHED THEN UPDATE SET	
rcmd_immunization_id = CIF.rcmd_immunization_id	
,pat_age_in_mon = CIF.pat_age_in_mon	
,additional_immunization_txt = CIF.additional_immunization_txt	
,cmnt_txt = CIF.cmnt_txt	
,doctor_clinic_name = CIF.doctor_clinic_name	
,rcvd_dt = CIF.rcvd_dt	
,rcvd_tm = CIF.rcvd_tm		
,edw_update_dttm = CURRENT_TIMESTAMP(0)	
,edw_batch_id = $pEDW_BATCH_ID
WHEN NOT MATCHED THEN INSERT	
(	
  cust_sk	
,    immunize_id
,    ecom_acct_id
,    src_sys_cd
,    composite_type_cd
,    msg_type_cd
,    rcmd_immunization_id
,    pat_age_in_mon
,    additional_immunization_txt
,    cmnt_txt
,    doctor_clinic_name
,    rcvd_dt
,    rcvd_tm
,    edw_create_dttm	
,    edw_update_dttm	
,    edw_batch_id	
,    edw_etl_step	
)	
VALUES	
(	
  NULL 	
, cif.immunize_id
, cif.ecom_acct_id
, cif.src_sys_cd
, cif.composite_type_cd
, cif.msg_type_cd
, cif.rcmd_immunization_id
, cif.pat_age_in_mon
, cif.additional_immunization_txt
, cif.cmnt_txt
, cif.doctor_clinic_name
, cif.rcvd_dt
, cif.rcvd_tm	
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS')	
, to_char(CURRENT_TIMESTAMP(0) , 'YYYY-MM-DD HH:MI:SS') 	
, $pEDW_BATCH_ID	
, 'CIF'	
);	

	

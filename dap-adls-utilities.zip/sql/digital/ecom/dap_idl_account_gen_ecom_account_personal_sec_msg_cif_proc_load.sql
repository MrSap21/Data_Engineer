INSERT INTO $DB_PARAM_STAGING.$SCHEMA1.$PROC_1
(
  cust_sk
, persnl_secured_msg_id
, ecom_acct_id
, src_sys_cd
, composite_type_cd
, msg_type_cd
, secured_msg_type_cd
, secured_msg_stat_cd
, secured_msg_rcvd_dt
, secured_msg_rcvd_tm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT
 cust_sk
, a.persnl_secured_msg_id
, a.ecom_acct_id
, a.src_sys_cd
, a.composite_type_cd
, a.msg_type_cd
, a.secured_msg_type_cd
, a.secured_msg_stat_cd
, a.secured_msg_rcvd_dt
, a.secured_msg_rcvd_tm
, a.edw_create_dttm
, a.edw_update_dttm
, a.edw_batch_id
FROM  $DB_PARAM_DIGITAL.$SCHEMA1.$TARGET_1 a
WHERE EXISTS
(
   SELECT 1
   FROM  $DB_PARAM_STAGING.$SCHEMA1.$CIF_1 b
   WHERE a.persnl_secured_msg_id = b.persnl_secured_msg_id
   AND   a.ecom_acct_id = b.ecom_acct_id
   AND   a.src_sys_cd = b.src_sys_cd
   AND   a.composite_type_cd = b.composite_type_cd
   AND   a.msg_type_cd = b.msg_type_cd
   AND   a.secured_msg_type_cd = b.secured_msg_type_cd
)
AND   a.src_sys_cd = '$pSRC_SYS_CD'
;

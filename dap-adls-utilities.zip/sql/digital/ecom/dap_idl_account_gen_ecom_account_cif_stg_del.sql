DELETE FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pSQL_PARM_1 stg
WHERE stg.src_sys_cd = '$pSRC_SYS_CD'
AND (  
         ((stg.cust_sk is not null)
          AND (stg.loyalty_cust_sk is not null OR stg.loyalty_mbr_id is null)
          AND (stg.pat_cust_sk is not null OR stg.pat_id is null)
          AND (stg.rgstr_loc_store_sk is not null OR stg.rgstr_store_nbr is null)
         )	  
      OR (EXISTS
          (
             SELECT 1
             FROM $pSTG_DATABASE_NAME.$pTD_DB_CIF.$pTABLE_NAME_1 cif
             WHERE cif.ecom_acct_id = stg.ecom_acct_id
             AND   cif.src_sys_cd = stg.src_sys_cd
             AND   cif.composite_type_cd = stg.composite_type_cd
             AND   cif.msg_type_cd = stg.msg_type_cd
          )
         )
    );

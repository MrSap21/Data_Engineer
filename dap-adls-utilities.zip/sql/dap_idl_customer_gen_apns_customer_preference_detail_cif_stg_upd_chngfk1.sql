update $db_param_staging.${pTD_DB_CIF}.$pTABLE_NAME_1

set cust_pref_prog_group_sk = tgt_sk.cust_pref_prog_group_sk,
edw_batch_id=${pEDW_BATCH_ID}, 
edw_etl_step='FKEY1',
edw_update_dttm = to_char(CURRENT_TIMESTAMP(0) :: timestamp, 'YYYY-MM-DD HH:MI:SS')

from ( 
sel distinct
stg.cust_pref_prog_cd,
stg.cust_pref_prog_group_cd,
stg.src_sys_cd,
tgt.cust_pref_prog_group_sk


from $db_param_staging.${pTD_DB_CIF}.$pTABLE_NAME_1 stg
left outer join $db_param_master_data.${pTD_VIEW_DB_IDL}.$pTABLE_NAME_2 tgt
on stg.cust_pref_prog_cd = tgt.cust_pref_prog_cd
and stg.cust_pref_prog_group_cd = tgt.cust_pref_prog_group_cd
and stg.src_sys_cd = '${pSRC_SYS_CD}'
and stg.src_sys_cd = tgt.src_sys_cd
and tgt.edw_rec_end_dt = ${pTD_EDW_END_DATE}
where stg.cust_pref_prog_group_sk =-1
and stg.cust_pref_detail_chng_sk is not null
and tgt.cust_pref_prog_group_sk is not null
) tgt_sk

where $db_param_staging.${pTD_DB_CIF}.$pTABLE_NAME_1.cust_pref_detail_chng_sk is not null
and $db_param_staging.${pTD_DB_CIF}.$pTABLE_NAME_1.cust_pref_prog_group_sk=-1
and $db_param_staging.${pTD_DB_CIF}.$pTABLE_NAME_1.src_sys_cd = '${pSRC_SYS_CD}'
and $db_param_staging.${pTD_DB_CIF}.$pTABLE_NAME_1.cust_pref_prog_cd = tgt_sk.cust_pref_prog_cd
and $db_param_staging.${pTD_DB_CIF}.$pTABLE_NAME_1.cust_pref_prog_group_cd = tgt_sk.cust_pref_prog_group_cd

;

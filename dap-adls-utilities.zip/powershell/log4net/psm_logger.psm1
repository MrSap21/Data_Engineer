function New-Logger
{
#Write-Host "BEGIN: New-Logger"
<#
.SYNOPSIS
      This function creates a log4net logger instance already configured
.OUTPUTS
      The log4net logger instance ready to be used
#>
     [CmdletBinding()]
     Param
     (
          
          [Alias("Dll")]
          [string]
          # Log4net dll path
          $log4netDllPath,
		  #[Alias("LogFileName")]
          [string]
          # Log file name
          $LogFile
		  
		  
     )
     Write-Verbose "[New-Logger] Logger initialization"
     $log4netDllPath = Resolve-Path $log4netDllPath -ErrorAction SilentlyContinue -ErrorVariable Err
     if ($Err)
     {
          throw "Log4net library cannot be found on the path $log4netDllPath"
     }
     else
     {
          Write-Verbose "[New-Logger] Log4net dll path is : '$log4netDllPath'"
          [Reflection.Assembly]::LoadFrom($log4netDllPath) | Out-Null
		  $Pattern = '[%date{yyyy-MM-dd HH:mm:ss.fff} [%level] [%.500message]%n'
          $PatternLayout = [log4net.Layout.ILayout](new-object log4net.Layout.PatternLayout($Pattern))
		  $AppendToFile = $True
		  $FileAppender = new-object log4net.Appender.FileAppender($PatternLayout,$LogFile,$AppendToFile);
		  $FileAppender.Threshold = [log4net.Core.Level]::All
		  [log4net.Config.BasicConfigurator]::Configure($FileAppender)
          $script:MyCommonLogger = [log4net.LogManager]::GetLogger("root")
          Write-Verbose "[New-Logger] Logger is configured"
          return $MyCommonLogger
          
     }
}
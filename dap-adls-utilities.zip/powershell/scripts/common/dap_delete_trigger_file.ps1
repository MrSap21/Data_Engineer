#! /bin/pwsh


[cmdletbinding()]
param (
	[Parameter(Mandatory=$true)][string]$AKVName,
	[Parameter(Mandatory=$true)][string]$TenantIDKey,
    [Parameter(Mandatory=$true)][string]$SQLAppIDKey,
	[Parameter(Mandatory=$true)][string]$SQLClientSecretKey,
	[Parameter(Mandatory=$true)][string]$SQLServer,
	[Parameter(Mandatory=$true)][string]$SQLDatabase,
	[Parameter(Mandatory=$true)][string]$TrgFileFolder,
	[Switch] $debugTrace
)

Connect-AzAccount -identity

# Getting Credentials
$appId = Get-AzKeyVaultSecret -VaultName $AKVName -Name $SQLAppIDKey -AsPlainText
$tenantId = Get-AzKeyVaultSecret -VaultName $AKVName -Name $TenantIDKey -AsPlainText
$password = Get-AzKeyVaultSecret -VaultName $AKVName -Name $SQLClientSecretKey -AsPlainText
$secpasswd = ConvertTo-SecureString $password -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential ($appId, $secpasswd)
$ConnectionString="Data Source=" + $SQLServer + ";Initial Catalog=" + $SQLDatabase + ";"
Connect-AzAccount -ServicePrincipal -Credential $mycreds -Tenant $tenantId

    # Getting Access Token
    $context =Get-AzContext
	
    # Some versions of PowerShell are removing this property from the account object. This is to mitigate this problem.
    if (-Not $context.Account.ExtendedProperties.ContainsKey("ServicePrincipalSecret"))
    {
	    $context.Account.ExtendedProperties.Add("ServicePrincipalSecret", $password)
    }
    $dexResourceUrl='https://database.windows.net/'
    $token = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, 
                                    $context.Environment, 
                                    $context.Tenant.Id.ToString(),
                                     $null, 
                                     [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, 
                                     $null, $dexResourceUrl).AccessToken
    $SqlConnection = New-Object System.Data.SqlClient.SqlConnection                
    $SqlCmd = New-Object System.Data.SqlClient.SqlCommand

    try 
    {
        $SqlConnection.ConnectionString = $ConnectionString
        if ($token)
        {
            $SqlConnection.AccessToken = $token
        }
		
		# Open connection to SQL
        $SqlConnection.Open()
         
        $SqlCmd.Connection = $SqlConnection 
        
		# Retrieve all assets which need their trigger files to be deleted

		$cmdSelect = "select distinct ast.AssetID from [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution] ex `
		inner join [idfwba].[AssetStatus] ast on ex.asset_id = ast.AssetID `
		where ast.StatusID = 200 `
		and ex.close_asset_dttm is null"
        $SqlCmd.CommandText = $cmdSelect
        $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
        $SqlAdapter.SelectCommand = $SqlCmd
        $DataSet = New-Object System.Data.DataSet
        $SqlAdapter.Fill($DataSet)				
		
		$SqlCmd.Transaction = $SqlConnection.BeginTransaction()
		try
		{
			$SqlCmd.CommandText = "update [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution] set close_asset_dttm = getdate() where asset_id in (" + $cmdSelect + ")"
			# Update PROC Control Table
			$SqlCmd.ExecuteNonQuery() 
			foreach ($Row in $DataSet.Tables[0].Rows)
			{
				# Deleting trigger file
				$path = $TrgFileFolder + "/*_$($Row[0]).trig"
				write-host "deleting file " + $path
				Remove-Item $path -Force
			}
			$SqlCmd.Transaction.Commit()
		}
		catch 
		{
   			$SqlCmd.Transaction.Rollback()
    		throw
		}
		
		# House keeping: Delete all files which don't have ESP dependency
		$SqlCmd.CommandText = "select distinct feed_name from [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] where file_trigger_enabled = 'Y'"
        $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
        $SqlAdapter.SelectCommand = $SqlCmd
        $DataSet = New-Object System.Data.DataSet
        $SqlAdapter.Fill($DataSet)	
		$feedsInScope = [System.Collections.ArrayList]::new()
		foreach ($Row in $DataSet.Tables[0].Rows)
		{
			[void]$feedsInScope.Add($Row[0])
		}

		$ExistingFiles = Get-ChildItem -Path $TrgFileFolder -Name
		foreach ($row in $ExistingFiles)
		{
			$feedIndex = $row.LastIndexOf('_')
			$feedName = ""
			if ($feedIndex -gt 0)
			{
				$feedName = $row.Substring(0, $feedIndex)
			}
			else
			{
				$feedName = $row
			}

			if (-Not $feedsInScope.Contains($feedName))
			{
				# Deleting files not in scope
				$path = $TrgFileFolder + "/" + $row
				write-host "deleting file out of scope " + $path
				Remove-Item $path -Force
			}
			
		}		
    }
    finally
    {
        $SqlAdapter.Dispose()
        $SqlCmd.Dispose()
        $SqlConnection.Dispose()
    }
Disconnect-AzAccount
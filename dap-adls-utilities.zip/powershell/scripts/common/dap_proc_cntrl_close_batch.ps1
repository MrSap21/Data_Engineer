#! /bin/pwsh

[cmdletbinding()]
Param(
    [Parameter(Mandatory=$true)][string] $AI_PROJECT,
    [Parameter(Mandatory=$true)][string] $SRC_STREAM,
    [Switch] $debugTrace
)

$httpClient = New-Object System.Net.Http.HttpClient
$httpClient.Timeout = 110000  # milliseconds

Disable-AzDataCollection

$ErrorActionPreference = "Stop"
if ($debugTrace) {Set-PSDebug -Trace 1}


######################### Get environment variables ###############################
/app/scripts/common/dap_environment.ps1

Connect-AzAccount -identity

$global:BaseDirectory = "/app/config/"

# JSON configuration filename to use
$global:BaseConfig = "config.json"

# Load and parse the JSON configuration file
try {
	$global:Config = Get-Content "$BaseDirectory$BaseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
	Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

# Check the configuration
if (!($Config)) {
	Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

$dataFactoryName=($Config.$env_var.dataFactoryName)
$resourceGroupName=($Config.$env_var.resourceGroupName)
$CloseBatchIdPipelineName=($Config.common.closeBatchIdPipelineName)
$PipelineJobID=($Config.common.pipelineJobID)

######################## Log4net Incorporation ############################
$logfilepath = ($Config.$env_var.logBasePath)
$LogFileName = $logfilepath + $CloseBatchIdPipelineName + '_' + $AI_PROJECT.ToUpper() + '_' + (Get-Date -format "yyyyMMdd") + '.txt'
Import-Module ($Config.$env_var.log4netBasePath+"psm_logger.psm1") -Force
$log = New-Logger -Dll  ($Config.$env_var.log4netBasePath+"log4net.dll") -LogFile $LogfileName

######################### Calling close batch script ###############################
$log.Info( "                                                                        ")
$log.Info( "------------------------Close Batch ID started--------------------------")
$log.Info( "-----AI_PROJECT:$($AI_PROJECT), SRC_STREAM:$($SRC_STREAM)---------------")
$parameters = @{
    PL_PAR_PROJ_NAME = $AI_PROJECT;
    PL_PAR_SRC_STREAM_NAME = $SRC_STREAM;
	PAR_JOB_ID = $PipelineJobID
	}
	
	
#{ 
#	"parameter_1_name": "parameter_1_value", 
#	"parameter_2_name": "parameter_2_value" 
#}

#Declaring variables

$SLEEP_SECONDS = 30
$DEBUG_PS_ADF_CALL = "True"   #Note: In case of False scenario set it to "" and not "False"
$PIPELINE_RUN_STATUS_QUEUED_INPROGRESS = @("Queued","InProgress")
$PreProcessPipelineRunDetails = $null
$PIPELINE_RUN_STATUS_SUCCEEDED = "Succeeded"

# Set to default setting
$DebugPreference = "SilentlyContinue" 

# Enable verbose logging of ADF powershell call
if($DEBUG_PS_ADF_CALL) 
{ 
	$DebugPreference = "Continue" 
}

$PipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipeline $CloseBatchIdPipelineName -Parameter $parameters


 #       $MasterpipelineRunID = $PreProcessPipelineRunDetails.RunId
        Do {
				Start-Sleep -Seconds $SLEEP_SECONDS   #Using $SLEEP_SECONDS variable instead of hardcoding
				 #Assigning the STATUS of ADF pipeline run to $PipelineRunDetails variable 
				$PreProcessPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $PipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName
        }
		While ($PreProcessPipelineRunDetails.Status -in $PIPELINE_RUN_STATUS_QUEUED_INPROGRESS )

		$logPreProcess = $PreProcessPipelineRunDetails | Out-String

		Write-Host("PreProcessPipelineRunDetails - ($logPreProcess)")



# $PreProcessPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $PipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName
		
if ($PreProcessPipelineRunDetails.Status -eq $PIPELINE_RUN_STATUS_SUCCEEDED) {
		Write-Output "Closing Batch ID Succeeded"	
		$log.Info("Closing Batch ID Succeeded")	
		$Edwbatchidetails = (Get-AzDataFactoryV2ActivityRun -PipelineRunId $PipelineRunGuid  -RunStartedAfter (get-date).AddHours(-24) -RunStartedBefore (get-date).AddHours(1) -ActivityName CloseBatchId  -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName)
		$EdwbatchID = $Edwbatchidetails.Output -split "`r`n"
		$EdwbatchID_latest=$EdwbatchID[1]
		$log.Info("EdwbatchID is $($EdwbatchID_latest)")
		$log.Info( "                                                                        ")
	
}
else {
		Write-Output "Closing Batch ID Failed"
		$log.Error("$($PreProcessPipelineRunDetails.message)")
		$log.Info( "                                                                        ")
		Exit
}

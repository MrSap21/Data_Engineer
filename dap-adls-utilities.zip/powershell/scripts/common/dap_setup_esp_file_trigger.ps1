#! /bin/pwsh

#Parameters clause
[cmdletbinding()]
param (
	[Parameter(Mandatory=$true)][string]$AKVName,
	[Parameter(Mandatory=$true)][string]$TenantIDKey,
    [Parameter(Mandatory=$true)][string]$SQLAppIDKey,
	[Parameter(Mandatory=$true)][string]$SQLClientSecretKey,
	[Parameter(Mandatory=$true)][string]$SQLServer,
	[Parameter(Mandatory=$true)][string]$SQLDatabase,
	[Parameter(Mandatory=$true)][string]$TrgFileFolder,
	[Switch] $debugTrace
)

Connect-AzAccount -identity

# Getting Credentials
$appId = Get-AzKeyVaultSecret -VaultName $AKVName -Name $SQLAppIDKey -AsPlainText
$tenantId = Get-AzKeyVaultSecret -VaultName $AKVName -Name $TenantIDKey -AsPlainText
$password = Get-AzKeyVaultSecret -VaultName $AKVName -Name $SQLClientSecretKey -AsPlainText
$secpasswd = ConvertTo-SecureString $password -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential ($appId, $secpasswd)
$ConnectionString="Data Source=" + $SQLServer + ";Initial Catalog=" + $SQLDatabase + ";"
Connect-AzAccount -ServicePrincipal -Credential $mycreds -Tenant $tenantId

    # Getting Access Token
    $context =Get-AzContext

    # Some versions of PowerShell are removing this property from the account object. This is to mitigate this problem.
    if (-Not $context.Account.ExtendedProperties.ContainsKey("ServicePrincipalSecret"))
    {
	    $context.Account.ExtendedProperties.Add("ServicePrincipalSecret", $password)
    }

    $dexResourceUrl='https://database.windows.net/'
    $token = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, 
                                    $context.Environment, 
                                    $context.Tenant.Id.ToString(),
                                     $null, 
                                     [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, 
                                     $null, $dexResourceUrl).AccessToken
    $SqlConnection = New-Object System.Data.SqlClient.SqlConnection                
    $SqlCmd = New-Object System.Data.SqlClient.SqlCommand

    try 
    {
		# Delete all files
		$ExistingFiles = Get-ChildItem -Path $TrgFileFolder -Name
		foreach ($row in $ExistingFiles)
		{
			# Deleting files not in scope
			$path = $TrgFileFolder + "/" + $row
			Remove-Item $path -Force
		}	
		
        $SqlConnection.ConnectionString = $ConnectionString
        if ($token)
        {
            $SqlConnection.AccessToken = $token
        }
		
		# Open connection to SQL
        $SqlConnection.Open()
         
        $SqlCmd.Connection = $SqlConnection 
        
		# Create files with open assets
        $SqlCmd.CommandText = "select distinct map.feed_name, a.AssetID from [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] map `
		inner join [idfwba].[Feed] f on map.feed_name = f.FeedName `                           
		inner join [idfwba].[Asset] a on a.FeedID = f.FeedID `                                 
		inner join [idfwba].[AssetStatus] ast on ast.AssetID = a.AssetID `                     
		where map.file_trigger_enabled = 'Y' `                                                 
		and ast.StatusID = 24014"
        $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
        $SqlAdapter.SelectCommand = $SqlCmd
        $DataSet = New-Object System.Data.DataSet
        $SqlAdapter.Fill($DataSet)				
		
		foreach ($Row in $DataSet.Tables[0].Rows)
		{
			echo $null >> $TrgFileFolder"/$($Row[0])_$($Row[1]).trig" --Force
		}	
    }
    finally
    {
        $SqlAdapter.Dispose()
        $SqlCmd.Dispose()
        $SqlConnection.Dispose()
    }
Disconnect-AzAccount
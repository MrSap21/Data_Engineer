#! /bin/pwsh

[cmdletbinding()]
Param(
    [Parameter(Mandatory=$true)][string] $AI_PROJECT,
    [Parameter(Mandatory=$true)][string] $SRC_STREAM,
    [Parameter(Mandatory=$true)][string] $MasterpipelineName,
	[Parameter(Mandatory=$false)][string]  $Recovery,
    [Switch] $debugTrace
)

$httpClient = New-Object System.Net.Http.HttpClient
$httpClient.Timeout = 110000  # milliseconds

Disable-AzDataCollection

$ErrorActionPreference = "Stop"
if ($debugTrace) {Set-PSDebug -Trace 1}


######################### Get environment variables ###############################
/app/scripts/common/dap_environment.ps1

Connect-AzAccount -identity

$global:BaseDirectory = "/app/config/"

# JSON configuration filename to use
$global:BaseConfig = "config.json"

# Load and parse the JSON configuration file
try {
	$global:Config = Get-Content "$BaseDirectory$BaseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
	Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

# Check the configuration
if (!($Config)) {
	Write-PoshError -Message "The Base configuration file is missing!" -Stop
}


$dataFactoryName=($Config.$env_var.dataFactoryName)
$resourceGroupName=($Config.$env_var.resourceGroupName)
$PreProcessPipelineName=($Config.common.preProcessPipelineName)
$PostProcessPipelineName=($Config.common.postProcessPipelineName)
$PipelineJobID=($Config.common.pipelineJobID)


######################## Log4net Incorporation ############################
$logfilepath = ($Config.$env_var.logBasePath)
$LogFileName = $logfilepath + $MasterPipelinename.ToUpper() + '_' + (Get-Date -format "yyyyMMdd") + '.txt'
Import-Module ($Config.$env_var.log4netBasePath+"psm_logger.psm1") -Force
$log = New-Logger -Dll  ($Config.$env_var.log4netBasePath+"log4net.dll") -LogFile $LogfileName
######################### Calling Pre-Process ###############################

$PreProcessParameters = @{
    "PAR_PL_PROJ_NAME" = $AI_PROJECT;
    "PAR_PL_SRC_STREAM_NAME" = $SRC_STREAM;
	"PAR_PL_MASTER_PIPELINE_NAME" = $MasterpipelineName;
	"PAR_JOB_ID" = $PipelineJobID
}

#Declaring variables
$SLEEP_SECONDS = 30
$DEBUG_PS_ADF_CALL = "True"   #Note: In case of False scenario set it to "" and not "False"
$PIPELINE_RUN_STATUS_QUEUED_INPROGRESS = @("Queued","InProgress")
$PIPELINE_RUN_STATUS_SUCCEEDED = "Succeeded"
$PIPELINE_RUN_STATUS_FAILED = "Failed"



Write-Output "-------- Starting Pre Process ------------"
$log.Info("---------------------- Starting Pre Process -------------------------")

# Set to default setting
$DebugPreference = "SilentlyContinue" 

# Enable verbose logging of ADF powershell call
if($DEBUG_PS_ADF_CALL) 
{ 
	$DebugPreference = "Continue" 
}

$PreProcessPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipeline $PreProcessPipelineName -Parameter $PreProcessParameters
 #       $MasterpipelineRunID = $PreProcessPipelineRunDetails.RunId
$PreProcessPipelineRunDetails = $null #Creating new variable


Do 
{ 
	Start-Sleep -Seconds $SLEEP_SECONDS     #Using $SLEEP_SECONDS variable instead of hardcoding
	
	#Assigning the STATUS of ADF pipeline run to $PreProcessPipelineRunDetails variable 
	$log.Info("Polling Azure for Pre-process pipeline completion. PreProcessPipelineRunGuid : $($PreProcessPipelineRunGuid) ");
	Write-Host("Polling Azure for Pre-process pipeline completion. PreProcessPipelineRunGuid : $($PreProcessPipelineRunGuid) ");
	$PreProcessPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $PreProcessPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName
} While ( $PreProcessPipelineRunDetails.Status -in $PIPELINE_RUN_STATUS_QUEUED_INPROGRESS )
			   
		
# Convert pipeline run details to string for logging
$logPreProcess = $PreProcessPipelineRunDetails | Out-String

$log.Info("Pre-process pipeline execution status : $($logPreProcess) " )
Write-Host("Pre-process pipeline execution status : $($logPreProcess) " )

if ($PreProcessPipelineRunDetails.Status -eq $PIPELINE_RUN_STATUS_SUCCEEDED) 
{
	# Pipeline has succeeded
	#Write-Output "RunSeqNbr check Succeeded"
	$log.Info("RunSeqNbr check Succeeded")
	Write-Host("RunSeqNbr check Succeeded")
	$Edwbatchidetails = (Get-AzDataFactoryV2ActivityRun -PipelineRunId $PreProcessPipelineRunGuid  -RunStartedAfter (get-date).AddHours(-24) -RunStartedBefore (get-date).AddHours(1) -ActivityName GetMaxBatchID  -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName)
	
	#$EdwbatchID = $Edwbatchidetails.Output -split "`r`n"
	#$EdwbatchID_latest=$EdwbatchID[1]
	#echo $Edwbatchidetails
	$EdwbatchID_latest  = (((($Edwbatchidetails.output.firstRow -split "`r'n") -split ":")[1]).split('.')[0]).Trim()
	#echo $EdwbatchID_latest
	$log.Info("EdwbatchID is $($EdwbatchID_latest)")
	Write-Host("EdwbatchID is $($EdwbatchID_latest)")
}
else 
{
	# Pipeline has failed or has been cancelled
	$log.Error("RunSeqNbr check Failed - $($PreProcessPipelineRunDetails.message)")
	Exit 1
}

# redundant call - not needed
#$pipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $PreProcessPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName | Out-String

######################### Calling MasterPipeline ###############################

Write-Output "-------- Starting Master Pipeline ------------"
$log.Info("---------------------- Starting Master Pipeline -------------------------")

$MasterParameters = @{
	"PAR_PL_BATCH_ID" = $EdwbatchID_latest   
}
$EXECUTE_FRESH_PIPELINE = '0'
$AI_PIPELINE_RUN_RC='0'

# $Recovery -eq 0  means invoking the failed master pipeline from first activity
# $Recovery -eq 1  means pipeline failed in the previous run and we are retrying after fixing the error, resume from the failed activity
# $Recovery -eq 2  means fresh run of the pipeline

 if($Recovery -eq 1 )
 {
	$log.Info("Invoking the failed master pipeline $($MasterpipelineName) from failed activity")
	Write-Host("Invoking the failed master pipeline $($MasterpipelineName) from failed activity")
	$Getupdatedbeforetime = Get-date -Format s
	$tempdate = (Get-Date).AddDays(-30)
	$Getupdatedaftertime=Get-Date $tempdate -Format s

	$GetPipelinerundetails=Get-AzDataFactoryV2PipelineRun -DataFactoryName $dataFactoryName -PipelineName $MasterpipelineName -ResourceGroupName $resourceGroupName -LastUpdatedAfter $Getupdatedaftertime -LastUpdatedBefore $Getupdatedbeforetime
	
	if($GetPipelinerundetails.RunID.Count -eq 0)
	{
		Write-Output("Recovery eq 1 - Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
		$log.Warn("Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
		$EXECUTE_FRESH_PIPELINE = '1'
	}
	else
	{
		$GetRunID=$GetPipelinerundetails.RunID[0]
		Write-Output ("Recovery eq 1 - Failed pipeline RunID is $($GetRunID)")
		if($GetPipelinerundetails.Status[0] -eq $PIPELINE_RUN_STATUS_FAILED) 
		{
			# Reinvoke the failed pipeline in recovery mode
			$failedPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipelinename $Masterpipelinename -ReferencePipelineRunId $GetRunID -Isrecovery -StartFromFailure
			
			$failedPipelineRunDetails = $null
			Do 
			{
				Start-Sleep -Seconds $SLEEP_SECONDS  
				
				# Fetch completion status of the reinvoked failed pipeline that was triggered in recovery mode
				$failedPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $failedPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName			
			}While ($failedPipelineRunDetails.Status -in $PIPELINE_RUN_STATUS_QUEUED_INPROGRESS)

			if($failedPipelineRunDetails.Status -eq $PIPELINE_RUN_STATUS_SUCCEEDED) # Using variable value for comparing status
			{
				# pipeline run success
				$log.Info("Recovery eq 1 - Master Pipeline ran Successfully when recovered..")	
				Write-Host("Recovery eq 1 - Master Pipeline ran Successfully when recovered..")
				$finish_dttm = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
				$EXECUTE_FRESH_PIPELINE = '0'
			}
			else 
			{
				# pipeline run failed or cancelled	
				$log.Error("Recovery eq 1 - Master Pipeline Failed $( $failedPipelineRunDetails | Out-String )")
				Write-Host("Recovery eq 1 - Master Pipeline Failed $( $failedPipelineRunDetails | Out-String )")
				$AI_PIPELINE_RUN_RC='1'							# $AI_PIPELINE_RUN_RC=1 can be constant as well
				$finish_dttm = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
				$EXECUTE_FRESH_PIPELINE='0'
				Exit 1
			}   
		}
		else
		{
			#write-output "This $($MasterpipelineName) already executed successfully"
			$log.Warn("Recovery eq 1 - Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
			Write-Host("Recovery eq 1 - Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
			$EXECUTE_FRESH_PIPELINE = '1'
		}
	}
		
 }
 elseif($Recovery -eq 0)
 {
	$log.Info("Invoking the failed master pipeline $($MasterpipelineName) from first activity")
	Write-Host("Invoking the failed master pipeline $($MasterpipelineName) from first activity")
	$Getupdatedbeforetime = Get-date -Format s
	$tempdate = (Get-Date).AddDays(-30)
	$Getupdatedaftertime = Get-Date $tempdate -Format s

	$GetPipelinerundetails = Get-AzDataFactoryV2PipelineRun -DataFactoryName $dataFactoryName -PipelineName $MasterpipelineName -ResourceGroupName $resourceGroupName -LastUpdatedAfter $Getupdatedaftertime -LastUpdatedBefore $Getupdatedbeforetime
	
	if($GetPipelinerundetails.RunID.Count -eq 0)
	{
		#write-output "This $($MasterpipelineName) already executed successfully"
		$log.Warn("Recovery eq 0 - Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
		Write-Host("Recovery eq 0 - Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
		$EXECUTE_FRESH_PIPELINE = '1'
	}
	else
	{
		# echo $GetPipelinerundetails.RunID[0]
		# echo $GetPipelinerundetails.Status[0]
		$GetRunID=$GetPipelinerundetails.RunID[0]
		Write-Output("Recovery eq 0 - Failed pipeline run details - start from first activity - failed pipeline runID - $($GetRunID)")
	 	if($GetPipelinerundetails.Status[0] -eq $PIPELINE_RUN_STATUS_FAILED) 
		{
		
			$failedPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipelinename $Masterpipelinename -ReferencePipelineRunId $GetRunID -Isrecovery
			
			$failedPipelineRunDetails = $null
			
			Do 
			{
				Start-Sleep -Seconds $SLEEP_SECONDS  
				
				$failedPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $failedPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName
			} While ($failedPipelineRunDetails.Status -in $PIPELINE_RUN_STATUS_QUEUED_INPROGRESS)  # Added condition to check for Queued status of ADF pipeline run
			
			if($failedPipelineRunDetails.Status -eq $PIPELINE_RUN_STATUS_SUCCEEDED)    #Using variable value for comparison
			{
				Write-Output("Recovery eq 0 - Master Pipeline ran Successfully - start from first activity of failed pipeline run")
				$AI_PIPELINE_RUN_RC='0'							# $AI_PIPELINE_RUN_RC=0 can be constant as well
				$finish_dttm=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
				$EXECUTE_FRESH_PIPELINE='0'
			}
			else 
			{
				$log.Error("Recovery eq 0 - Master Pipeline $($MasterpipelineName) Failed - start from first activity of failed pipeline run \n $($failedPipelineRunDetails | Out-String)")
				Write-Host("Recovery eq 0 - Master Pipeline $($MasterpipelineName) Failed - start from first activity of failed pipeline run \n $($failedPipelineRunDetails | Out-String)")
				$AI_PIPELINE_RUN_RC='1'							# $AI_PIPELINE_RUN_RC=1 can be constant as well
				$finish_dttm = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
				$EXECUTE_FRESH_PIPELINE = '0'
				Exit 1
			}
		}
		else
		{
		   
		   $log.Warn("Recovery eq 0 - Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
		   Write-Host("Recovery eq 0 - Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
		   $EXECUTE_FRESH_PIPELINE = '1'
		}
	}	
 }
 else
 {
	 $EXECUTE_FRESH_PIPELINE = '1'
 }


if($EXECUTE_FRESH_PIPELINE -eq '1')
{
	$log.Info("EXECUTE_FRESH_PIPELINE - $($MasterpipelineName)")
	Write-Host("EXECUTE_FRESH_PIPELINE - $($MasterpipelineName)")

	$MasterPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline  -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipeline $MasterPipelineName -Parameter $MasterParameters 
	
	$log.Info("EXECUTE_FRESH_PIPELINE - $($MasterpipelineName) MasterPipelineRunGuid is $($MasterPipelineRunGuid)")
	Write-Host("EXECUTE_FRESH_PIPELINE - $($MasterpipelineName) MasterPipelineRunGuid is $($MasterPipelineRunGuid)")

	$MasterPipelineRunDetails = $null
	
	Do 
	{			
		Write-Host("---------EXECUTE_FRESH_PIPELINE - checking execution status-----------")
		Start-Sleep -Seconds $SLEEP_SECONDS   #Using $SLEEP_SECONDS variable instead of hardcoding to 2
		
		#Assigning the STATUS of ADF pipeline run to $MasterPipelineRunDetails variable
		$MasterPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $MasterPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName
	} While ($MasterPipelineRunDetails.Status -in $PIPELINE_RUN_STATUS_QUEUED_INPROGRESS) # Added condition to check for Queued status of ADF pipeline run
       
	$logMasterPipeline = $MasterPipelineRunDetails | Out-String
	Write-host $logMasterPipeline
		
	if ($MasterPipelineRunDetails.Status -eq $PIPELINE_RUN_STATUS_SUCCEEDED) # Comparing the $MasterPipelineRunDetails.Status with variable
	{
		$log.Info("EXECUTE_FRESH_PIPELINE - New Master Pipeline $($MasterpipelineName) ran Successfully")
		Write-Host("EXECUTE_FRESH_PIPELINE - New Master Pipeline $($MasterpipelineName) ran Successfully")
		$AI_PIPELINE_RUN_RC='0'							# $AI_PIPELINE_RUN_RC=0 can be constant as well
		$finish_dttm=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
	
	}
	else 
	{
		$log.Error("EXECUTE_FRESH_PIPELINE - New Master Pipeline $($MasterpipelineName) is failed with message - $($MasterPipelineRunDetails.Message)")
		Write-Host("EXECUTE_FRESH_PIPELINE - New Master Pipeline $($MasterpipelineName) is failed with message - $($MasterPipelineRunDetails.Message)")
		$AI_PIPELINE_RUN_RC='1'							# $AI_PIPELINE_RUN_RC=1 can be constant as well
		$finish_dttm=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
		Exit 1
	}
}

#Instead of calling Get-AzDataFactoryV2PipelineRun command we are retrieving value from variable $MasterPipelineRunDetails
#$logMasterPipeline = Get-AzDataFactoryV2PipelineRun -PipelineRunId $MasterPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName | Out-String

######################### Calling Post-Process ###############################
$log.Info("------------------------Post Process Started-------------------------")
$log.Info( "-------- Updating Table after Master Pipeline Execution ------------")
$log.Info( "----FINISH DTTM:$($finish_dttm) PIPELINE_RUN_RC:$($AI_PIPELINE_RUN_RC)------")

Write-Host("------------------------Post Process Started-------------------------")
Write-Host( "-------- Updating Table after Master Pipeline Execution ------------")
Write-Host( "----FINISH DTTM:$($finish_dttm) PIPELINE_RUN_RC:$($AI_PIPELINE_RUN_RC)------")

$PostProcessParameters = @{
    "PAR_PL_PROJ_NAME" = $AI_PROJECT
    "PAR_PL_SRC_STREAM_NAME" = $SRC_STREAM
	"PAR_PL_MASTER_PIPELINE_NAME" = $MasterpipelineName
	"PAR_PL_PIPELINE_RUN_STAT_CD" = $AI_PIPELINE_RUN_RC
	"PAR_PL_FINISH_DTTM" = (Get-Date).ToString('yyy-MM-dd HH:mm:ss')
	"PAR_JOB_ID" = $PipelineJobID
	#PAR_PL_PIPELINE_RUN_STAT_CD
	#PAR_PL_FINISH_DTTM
}

#$AI_PIPELINE_RUN_RC=$?

$PostProcessPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipeline $PostProcessPipelineName -Parameter $PostProcessParameters
$PostProcessPipelineRunDetails = $null  #Defining new variable 

Do 
{
	Start-Sleep -Seconds $SLEEP_SECONDS 
	#Assigning the STATUS of ADF pipeline run to $PostProcessPipelineRunDetails variable
	$PostProcessPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $PostProcessPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName
} While ( $PostProcessPipelineRunDetails.Status -in $PIPELINE_RUN_STATUS_QUEUED_INPROGRESS ) # Added condition to check for Queued status of ADF pipeline run			   
       
	
if ($PostProcessPipelineRunDetails.Status -eq $PIPELINE_RUN_STATUS_SUCCEEDED) #Using variable value for comparison of status
{
	$log.Info("Post Audit Processing Succeeded")	
	$log.Info("                                                                     ")
	Write-Host("Post Audit Processing Succeeded")
	Write-Host("                                                                     ")
}
else 
{
	$log.Info("Post Audit Processing Failed")
	$log.Info("Error Message is $($PostProcessPipelineRunDetails.Message)")
	$log.Info("                                                                     ")
	Write-Host("Post Audit Processing Failed")
	Write-Host("Error Message is $($PostProcessPipelineRunDetails.Message)")
	Write-Host("                                                                     ")
	Exit 1
}

echo $AI_PIPELINE_RUN_RC

#Instead of calling Get-AzDataFactoryV2PipelineRun command we are retrieving value from variable $logPostProcess
#$logPostProcess = Get-AzDataFactoryV2PipelineRun -PipelineRunId $PostProcessPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName | Out-String
$logPostProcess = $PostProcessPipelineRunDetails | Out-String
Write-host $logPostProcess

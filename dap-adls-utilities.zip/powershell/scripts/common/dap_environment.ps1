#!/bin/pwsh

[cmdletbinding()]

$HOSTNAME=hostname;

Connect-AzAccount -identity

$global:BaseDirectory = "/app/config/"

# JSON configuration filename to use
$global:BaseConfig = "config.json"

# Load and parse the JSON configuration file
try {
        $global:Config = Get-Content "$BaseDirectory$BaseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
        Write-PoshError -Message "The Base configuration file is missing!" -Stop
} 

$Target_Host_dev=($Config.dev.LinuxVM)
$Target_Host_test=($Config.test.LinuxVM)
$Target_Host_uat=($Config.uat.LinuxVM)
$Target_Host_prod=($Config.prod.LinuxVM)
$Target_Host_preprod=($Config.preprod.LinuxVM)

if ( $HOSTNAME -eq $Target_Host_dev )
{ $global:env_var="dev"
echo "environment is $env_var"}

elseif ( $HOSTNAME -eq $Target_Host_test )
{ $global:env_var="test"
echo "environment is $env_var"}

elseif ( $HOSTNAME -eq $Target_Host_uat )
{ $global:env_var="uat"
echo "environment is $env_var"}

elseif ( $HOSTNAME -eq $Target_Host_prod )
{ $global:env_var="prod"
echo "environment is $env_var"}

elseif ( $HOSTNAME -eq $Target_Host_preprod )
{ $global:env_var="preprod"
echo "environment is $env_var"}

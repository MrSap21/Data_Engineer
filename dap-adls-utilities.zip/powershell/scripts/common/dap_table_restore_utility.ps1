#! /bin/pwsh

Param(
    [Parameter(Mandatory=$true)][string] $TableName,
		[Parameter(Mandatory=$true)][string] $version,
    [Switch] $debugTrace
)

######################### Get environment variables ###############################
./dap_environment.ps1

Connect-AzAccount -identity

$global:BaseDirectory = "/app/config/"

# JSON configuration filename to use
$global:BaseConfig = "config.json"

# Load and parse the JSON configuration file
try {
        $global:Config = Get-Content "$BaseDirectory$BaseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
        Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

# Check the configuration
if (!($Config)) {
        Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

$dataFactoryName=($Config.$env_var.dataFactoryName)
$resourceGroupName=($Config.$env_var.resourceGroupName)

$MasterParameters = @{
        "VERSION_NO" = $version
		"TABLE_NAME" = $TableName
}


$MasterPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipeline PL_MSTR_COMMON_TABLE_RESTORE_UTILITY -Parameter $MasterParameters

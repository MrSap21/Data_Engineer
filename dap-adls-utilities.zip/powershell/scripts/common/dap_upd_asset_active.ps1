#! /bin/pwsh

Param(
    [Parameter(Mandatory=$true)][string] $Asset,
    [Parameter(Mandatory=$false)][string] $BatchId = '99999999',
    [Switch] $debugTrace
)

######################### Get environment variables ###############################
./dap_environment.ps1

Connect-AzAccount -identity

$global:BaseDirectory = "/app/config/"

# JSON configuration filename to use
$global:BaseConfig = "config.json"

# Load and parse the JSON configuration file
try {
        $global:Config = Get-Content "$BaseDirectory$BaseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
        Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

# Check the configuration
if (!($Config)) {
        Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

$dataFactoryName=($Config.$env_var.dataFactoryName)
$resourceGroupName=($Config.$env_var.resourceGroupName)

$MasterParameters = @{
        "PL_ASSET_ID" = $Asset
        "PL_ASSET_STATUS" = 24014 
        "PL_BATCH_ID" = $BatchId
}


$MasterPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipeline PL_MSTR_COMMON_ASSET_STATUS_UPD -Parameter $MasterParameters

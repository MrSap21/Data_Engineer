#! /bin/pwsh

[cmdletbinding()]
Param(
    [Parameter(Mandatory=$true)][string] $PAR_BUSINESS_DOMAIN,
    [Parameter(Mandatory=$true)][string] $PAR_SUB_DOMAIN,
	[Parameter(Mandatory=$true)][string] $PAR_ESP_ID,
	[Parameter(Mandatory=$false)][string] $PAR_RESTART_FLAG,
    [Switch] $debugTrace
)

$httpClient = New-Object System.Net.Http.HttpClient
$httpClient.Timeout = 110000  # milliseconds

Disable-AzDataCollection


$ErrorActionPreference = "Stop"
if ($debugTrace) {Set-PSDebug -Trace 1}

######################### Get environment variables ###############################
/app/scripts/common/dap_environment.ps1

Connect-AzAccount -identity

$global:BaseDirectory = "/app/config/"

# JSON configuration filename to use
$global:BaseConfig = "config.json"

# Load and parse the JSON configuration file
try {
	$global:Config = Get-Content "$BaseDirectory$BaseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
	Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

# Check the configuration
if (!($Config)) {
	Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

$dataFactoryName=($Config.$env_var.dataFactoryName)
$resourceGroupName=($Config.$env_var.resourceGroupName)
$orchFrameworkCommonPipelineName=($Config.common.orchFrameworkCommonPipelineName)

if ($PAR_RESTART_FLAG -eq ""){
$PAR_RESTART_FLAG = 1
}

$PipelineParameters = @{
    "PAR_BUSINESS_DOMAIN" = $PAR_BUSINESS_DOMAIN
    "PAR_SUB_DOMAIN" = $PAR_SUB_DOMAIN
	"PAR_ESP_ID" = $PAR_ESP_ID
	"PAR_RESTART_FLAG" = $PAR_RESTART_FLAG
}

#Declaring variables
$SLEEP_SECONDS = 30
$DEBUG_PS_ADF_CALL = "True"   #Note: In case of False scenario set it to "" and not "False"
$PIPELINE_RUN_STATUS_QUEUED_INPROGRESS = @("Queued","InProgress")
$PipelineRunDetails = $null
$PIPELINE_RUN_STATUS_SUCCEEDED = "Succeeded"

# Set to default setting
$DebugPreference = "SilentlyContinue" 

# Enable verbose logging of ADF powershell call
if($DEBUG_PS_ADF_CALL) 
{ 
	$DebugPreference = "Continue" 
}

$PipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipelinename $orchFrameworkCommonPipelineName -Parameter $PipelineParameters

			Do {
				Start-Sleep -Seconds $SLEEP_SECONDS   #Using $SLEEP_SECONDS variable instead of hardcoding
				 #Assigning the STATUS of ADF pipeline run to $PipelineRunDetails variable 
				$PipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $PipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName
			}
			While ($PipelineRunDetails.Status -in $PIPELINE_RUN_STATUS_QUEUED_INPROGRESS)
			
			$logPreProcess = $PipelineRunDetails | Out-String

			Write-Host("PipelineRunDetails - ($logPreProcess)")
			
			if($PipelineRunDetails.Status -eq $PIPELINE_RUN_STATUS_SUCCEEDED) 
			{
				Write-Output "Master Pipeline ran Successfully"	
				
			}
			else 
			{
				Write-Output "Master Pipeline Failed"	
				Exit 1
			}
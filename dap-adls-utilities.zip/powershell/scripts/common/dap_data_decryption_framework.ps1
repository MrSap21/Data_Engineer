#! /bin/pwsh

Param(
    [Parameter(Mandatory=$true)][string] $NodeType,
	[Parameter(Mandatory=$true)][string] $NoOfNodes,
	[Parameter(Mandatory=$true)][AllowEmptyString()][string] $DatabaseName,
	[Parameter(Mandatory=$true)][string] $TableName,
	[Parameter(Mandatory=$true)][string] $Platform,
	[Parameter(Mandatory=$true)][AllowEmptyString()][string] $SNFLKWarehouse,
    [Switch] $debugTrace
)

######################### Get environment variables ###############################
./dap_environment.ps1

Connect-AzAccount -identity

$global:BaseDirectory = "/app/config/"

# JSON configuration filename to use
$global:BaseConfig = "config.json"

# Load and parse the JSON configuration file
try {
        $global:Config = Get-Content "$BaseDirectory$BaseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
        Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

# Check the configuration
if (!($Config)) {
        Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

$dataFactoryName=($Config.$env_var.dataFactoryName)
$resourceGroupName=($Config.$env_var.resourceGroupName)

$MasterParameters = @{
        "NODE_TYPE" = $NodeType
        "NO_OF_NODES" = $NoOfNodes
		"DATABASE_NAME" = $DatabaseName
		"TABLE_NAME" = $TableName
		"PLATFORM" = $Platform
		"SNFLKWAREHOUSE" = $SNFLKWarehouse
}


$MasterPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipeline PL_MSTR_GEN_DECRYPTION_FRAMEWORK -Parameter $MasterParameters

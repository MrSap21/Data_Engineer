#! /bin/pwsh

[cmdletbinding()]
Param(
    [Parameter(Mandatory=$true)][string] $DomainName,
    [Parameter(Mandatory=$true)][string] $SubDomainName,
    [Parameter(Mandatory=$true)][string] $MasterpipelineName,
	[Parameter(Mandatory=$false)][string]  $Recovery,
    [Switch] $debugTrace
)
$ErrorActionPreference = "Stop"
if ($debugTrace) {Set-PSDebug -Trace 1}

######################### Get environment variables ###############################

Connect-AzAccount -identity

$global:BaseDirectory = "/app/config/svof/"

# JSON configuration filename to use
$global:BaseConfig = "svof_config.json"

# Load and parse the JSON configuration file
try {
	$global:Config = Get-Content "$BaseDirectory$BaseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
	Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

# Check the configuration
if (!($Config)) {
	Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

<# $dataFactoryName="dapdevdata-engg01"
$resourceGroupName="rpu-nprod-dna-data-analytics-eastus2-paas-02-rg"
$PreProcessPipelineName="PL_AUDIT_PRE_PROCESS"
$PostProcessPipelineName="PL_AUDIT_POST_PROCESS" #>

$dataFactoryName=($Config.$env_var.dataFactoryName)
$resourceGroupName=($Config.$env_var.resourceGroupName)



######################## Log4net Incorporation ############################
$logfilepath = ($Config.$env_var.logBasePath)
$LogFileName = $logfilepath + $MasterPipelinename.ToUpper() + '_' + (Get-Date -format "yyyyMMdd") + '.txt'
Import-Module ($Config.$env_var.log4netBasePath+"psm_logger.psm1") -Force
$log = New-Logger -Dll  ($Config.$env_var.log4netBasePath+"log4net.dll") -LogFile $LogfileName
######################### Calling Pre-Process ###############################

$PreProcessParameters = @{
    "PAR_PL_PROJ_NAME" = $DomainName;
    "PAR_PL_SRC_STREAM_NAME" = $SubDomainName;
	"PAR_PL_MASTER_PIPELINE_NAME" = $MasterpipelineName;
	"PAR_JOB_ID" = $PipelineJobID
}

#Write-Output "-------- Starting Pre Process ------------"
$log.Info("                                                                     ")
$log.Info("---------------------- Starting Pre Process -------------------------")




######################### Calling MasterPipeline ###############################

Write-Output "-------- Starting Master Pipeline ------------"
$log.Info("---------------------- Starting Master Pipeline -------------------------")

$MasterParameters = @{
	"PAR_PL_BATCH_ID" = $EdwbatchID_latest   
}
$EXECUTE_FRESH_PIPELINE = '0'
$AI_PIPELINE_RUN_RC='0'

 if($Recovery -eq 1 )
 {
	$log.Info("Invoking the failed master pipeline $($MasterpipelineName) from failed activity") 
	$Getupdatedbeforetime =Get-date -Format s
	$tempdate= (Get-Date).AddDays(-30)
	$Getupdatedaftertime=Get-Date $tempdate -Format s
	$GetPipelinerundetails=Get-AzDataFactoryV2PipelineRun -DataFactoryName $dataFactoryName -PipelineName $MasterpipelineName -ResourceGroupName $resourceGroupName -LastUpdatedAfter $Getupdatedaftertime -LastUpdatedBefore $Getupdatedbeforetime
	if($GetPipelinerundetails.RunID.Count -eq 0)
	{
		#write-output "This $($MasterpipelineName) already executed successfully"
		$log.Warn("Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
		$EXECUTE_FRESH_PIPELINE = '1'
	}
	else
	{
		$GetRunID=$GetPipelinerundetails.RunID[0]
		# echo $GetPipelinerundetails.RunID[0]
		# echo $GetPipelinerundetails.Status[0]
     	if($GetPipelinerundetails.Status[0] -eq "Failed")
		{
			$failedPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipelinename $Masterpipelinename -ReferencePipelineRunId $GetRunID -Isrecovery -StartFromFailure
			Do {
				Start-Sleep -Seconds 2
			}
			While ((Get-AzDataFactoryV2PipelineRun -PipelineRunId $failedPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName).Status -eq "InProgress")
			$failedPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $failedPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName
			if($failedPipelineRunDetails.Status -eq "Succeeded") 
			{
			
				$log.Info("Master Pipeline ran Successfully")	
				$AI_PSET_RUN_RC='0'							# $AI_PSET_RUN_RC=0 can be constant as well
				$finish_dttm=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
				$EXECUTE_FRESH_PIPELINE='0'
			}
			else 
			{
				$log.Error("Master Pipeline Failed")
				$log.Error("Error Message is $($failedPipelineRunDetails.Message)")
				$AI_PIPELINE_RUN_RC='1'							# $AI_PIPELINE_RUN_RC=1 can be constant as well
				$finish_dttm=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
				$EXECUTE_FRESH_PIPELINE='0'
				Exit 1
			}   
		}
		else
		{
			#write-output "This $($MasterpipelineName) already executed successfully"
			$log.Warn("Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
			$EXECUTE_FRESH_PIPELINE = '1'
		}
	}
		
 }
 elseif($Recovery -eq 0)
 {
	$log.Info("Invoking the failed master pipeline $($MasterpipelineName) from first activity")
	$Getupdatedbeforetime =Get-date -Format s
	$tempdate= (Get-Date).AddDays(-30)
	$Getupdatedaftertime=Get-Date $tempdate -Format s
	$GetPipelinerundetails=Get-AzDataFactoryV2PipelineRun -DataFactoryName $dataFactoryName -PipelineName $MasterpipelineName -ResourceGroupName $resourceGroupName -LastUpdatedAfter $Getupdatedaftertime -LastUpdatedBefore $Getupdatedbeforetime
	if($GetPipelinerundetails.RunID.Count -eq 0)
	{
		#write-output "This $($MasterpipelineName) already executed successfully"
		$log.Warn("Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
		$EXECUTE_FRESH_PIPELINE = '1'
	}
	else
	{
		# echo $GetPipelinerundetails.RunID[0]
		# echo $GetPipelinerundetails.Status[0]
		$GetRunID=$GetPipelinerundetails.RunID[0]
	 	if($GetPipelinerundetails.Status[0] -eq "Failed")
		{
		
			$failedPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipelinename $Masterpipelinename -ReferencePipelineRunId $GetRunID -Isrecovery
			Do {
				Start-Sleep -Seconds 2
			}
			While ((Get-AzDataFactoryV2PipelineRun -PipelineRunId $failedPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName).Status -eq "InProgress")
			$failedPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $failedPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName
    
			if($failedPipelineRunDetails.Status -eq "Succeeded") 
			{
			Write-Output "Master Pipeline ran Successfully"	
			$AI_PIPELINE_RUN_RC='0'							# $AI_PIPELINE_RUN_RC=0 can be constant as well
			$finish_dttm=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
			$EXECUTE_FRESH_PIPELINE='0'
			}
			else 
			{
			$log.Error("Master Pipeline $($MasterpipelineName) Failed")
			$log.Error("Error Message is $($failedPipelineRunDetails.Message)")
			$AI_PIPELINE_RUN_RC='1'							# $AI_PIPELINE_RUN_RC=1 can be constant as well
			$finish_dttm=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
			$EXECUTE_FRESH_PIPELINE='0'
			Exit 1
			}
		}
		else
		{
		   #Write-Output "This $($MasterpipelineName) already executed successfully"
		   $log.Warn("Last run of $($MasterpipelineName) already executed successfully. Creating Fresh execution")
		   $EXECUTE_FRESH_PIPELINE = '1'
		}
	}	
 }
 else
 {
	 $EXECUTE_FRESH_PIPELINE = '1'
 }


if($EXECUTE_FRESH_PIPELINE -eq '1')
{
	$MasterPipelineRunGuid = Invoke-AzDataFactoryV2Pipeline -ResourceGroupName $resourceGroupName -DatafactoryName $dataFactoryName -Pipeline $MasterPipelineName -Parameter $MasterParameters

        Do {
            Start-Sleep -Seconds 2
        }
        While ((Get-AzDataFactoryV2PipelineRun -PipelineRunId $MasterPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName).Status -eq "InProgress")

	$MasterPipelineRunDetails = Get-AzDataFactoryV2PipelineRun -PipelineRunId $MasterPipelineRunGuid -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName

	
     if ($MasterPipelineRunDetails.Status -eq "Succeeded") {
		$log.Info("New Master Pipeline $($MasterpipelineName) ran Successfully")	
		$AI_PIPELINE_RUN_RC='0'							# $AI_PIPELINE_RUN_RC=0 can be constant as well
		$finish_dttm=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
		
       }
     else {
		$log.Error("New Master Pipeline $($MasterpipelineName) is failed")
		$log.Error("$($MasterPipelineRunDetails.Message)")
		$AI_PIPELINE_RUN_RC='1'							# $AI_PIPELINE_RUN_RC=1 can be constant as well
		$finish_dttm=Get-Date -Format "yyyy-MM-dd HH:mm:ss"
		
		
		Exit 1
     }
}
######################### Calling Post-Process ###############################
$log.Info("------------------------Pipeline end-------------------------")



echo $AI_PIPELINE_RUN_RC
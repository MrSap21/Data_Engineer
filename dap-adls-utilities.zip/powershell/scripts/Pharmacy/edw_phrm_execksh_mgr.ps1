#! /bin/pwsh

#Parameters clause
[cmdletbinding()]
param (
    [Parameter(Mandatory=$true)][string]$ProjectName,
	[Parameter(Mandatory=$true)][string]$Script,
	[Parameter(Mandatory=$false)][string]$InvId = 'NOINVID',
	[Parameter(Mandatory=$false)][string]$EspCycleId = '999',
	[Switch] $debugTrace
)

#Stop on any error!
$ErrorActionPreference = "Stop"
$CheckLoopTime = 30
$ProcessName = $MyInvocation.MyCommand.Name
if ($debugTrace) {Set-PSDebug -Trace 1}

######################### Get environment variables ###############################
/app/scripts/common/dap_environment.ps1

#Compose request body

$NotebookParams = '{\"PROJECT\":\"' + $ProjectName + '\",\"SCRIPT\":\"' +$Script +'\",\"INVID\":\"' + $InvId + '\",\"ESP_CYCLE_ID\":\"' +$EspCycleId +'\"}'
$ExecNotebook = "/CodeConversion/Pharmacy/edw_phrm_execksh_mgr"

$connection=Connect-AzAccount -identity

$global:BaseDirectory = "/app/config/"

# JSON configuration filename to use
$global:BaseConfig = "config.json"

# Load and parse the JSON configuration file
try {
        $global:Config = Get-Content "$BaseDirectory$BaseConfig" -Raw -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue | ConvertFrom-Json -ErrorAction:SilentlyContinue -WarningAction:SilentlyContinue
} catch {
        Write-PoshError -Message "The Base configuration file is missing!" -Stop
}

# Check the configuration
if (!($Config)) {
        Write-PoshError -Message "The Base configuration file is missing!" -Stop
}
$VaultName=($Config.$env_var.VaultName) #parameter should be set beased on env manually
$Name=($Config.$env_var.Name)
$DatabricksUrl=($Config.$env_var.DatabricksUrl)
$ClusterName=($Config.$env_var.ClusterName)


######################## Log4net Incorporation ############################
$logfilepath = ($Config.$env_var.logBasePath)+'databrickscli/'
$LogFileName = $logfilepath + $InvId.ToUpper() + '_' + (Get-Date -format "yyyyMMdd") + '.log'
Import-Module ($Config.$env_var.log4netBasePath+"psm_logger.psm1") -Force
$log = New-Logger -Dll  ($Config.$env_var.log4netBasePath+"log4net.dll") -LogFile $LogfileName

$log.Info("                                                                     ")
$log.Info("--------- Connected to Azure --------- $($connection)")
$log.Info("---------------------- Starting Databricks Connectivity ------------------------")

$secret = Get-AzKeyVaultSecret -VaultName $VaultName -Name $Name -AsPlainText
Set-DatabricksEnvironment -ApiRootUrl $DatabricksUrl -AccessToken $secret

try{
	#get cluster id
	$log.Info("Getting cluster id")
	$ClusterMeta = (databricks clusters list --output json | ConvertFrom-Json).clusters
	if($ClusterMeta.GetType().name -ne "Object[]") {
	    $log.Error("Databricks server returned an error. Error message: $($ClusterMeta)")  
		throw "Databricks server returned an error. Error message: $ClusterMeta"
	}
	$ClusterId = ($ClusterMeta | where {$_.cluster_name -eq $ClusterName} | Select cluster_id -ExpandProperty cluster_id)
	if(!$ClusterId) {
	    $log.Error("Databricks server returned an error. Error message: $($ClusterMeta)")
		throw "Cluster id has not been recieved. Error message: $ClusterMeta"
	}
	$log.Info("Cluster id $($ClusterId) has been successfully returned.")
}
Catch{
    Throw
}

$RequestPayload = '{\"run_name\":\"' +$ProcessName +'\", \"existing_cluster_id\": \"' +$ClusterId +'\", \"notebook_task\":
{\"notebook_path\": \"' +$ExecNotebook +'\", \"base_parameters\": ' +$NotebookParams +'}}'
#call job
try{
	# to add check if exists
    #submitting run-now
	$log.Info("Running databricks job: $($JobId)")
	$callback = databricks runs submit --json $RequestPayload
	
	if($callback.GetType().name -ne "Object[]") {
        $log.Error("Job wasn't submitted. Error message: $($callback)")
		throw "Job wasn't submitted. Error message: $callback"
	}
	#extract runid
	$run_id = ($callback | ConvertFrom-Json).run_id
	if(!$run_id) {
	    $log.Error("Job wasn't submitted. Error message: $($callback)") 
		throw "Job wasn't submitted. Error message: $callback"
	}
	$log.Info("Job id was submitted successfully. Run id: $($run_id)") 
	$status = "PENDING"
	While ($status -eq "PENDING" -or $status -eq "RUNNING" -or $status -eq "SKIPPED" -or $status -eq "TERMINATING")
	{
        Start-Sleep $CheckLoopTime 
		$state = (databricks runs get --run-id $run_id | ConvertFrom-Json)
		$status = $state.state.life_cycle_state		
	}
	if ($status -eq "INTERNAL_ERROR")
	{
	    $log.Error("Job has failed with error message: $($state.state.state_message)") 
		throw "Job $JobId has failed with error message: $($state.state.state_message)"
	} 
	if ($state.state.result_state -ne "SUCCESS")
	{
	    $log.Error("Job has failed with $($state.state.result_state) status. check Error by clicking generated url:`n$($state)") 
		throw "Job $JobId has failed with $state.state.result_state status. Returned message was:`n$($state.state.state_message)"
	}
	else
	{
        $log.Info("Job was executed SUCCESSFULLY. Execution details: `n$($state)")
	}
	$log.Info("Last exit code $($LASTEXITCODE)")
	exit $LASTEXITCODE
}
Catch{
    Throw
}	

######################### Delete ESP trigger files ###############################
/app/scripts/common/dap_delete_trigger_file.ps1 $Config.$env_var.VaultName `
                              $Config.$env_var.keyVaultSecret_tenantIDKey `
							  $Config.$env_var.keyVaultSecret_sqlClientIDKey `
							  $Config.$env_var.SqlDbPwd `
							  $Config.$env_var.SqlSrv `
							  $Config.$env_var.SqlDb `
							  $Config.$env_var.ESPTrgFileFolder 
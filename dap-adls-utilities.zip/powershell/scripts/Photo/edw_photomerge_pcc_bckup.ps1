#Parameters clause
param (
	[Parameter(Mandatory=$false)][string]$EspCycleId = '999'
 )

#Stop on any error!
$ErrorActionPreference = "Stop"
$CheckLoopTime = 30
$ProcessName = $MyInvocation.MyCommand.Name

#Compose request body

$NotebookParams = '{\"ESP_CYCLE_ID\":\"' +$EspCycleId +'\"}'
$ExecNotebook = "/CodeConversion/Photo/edw_photomerge_pcc"
$ClusterName = "DataEngineering01"

try{
	#get cluster id
	Write-Output "Getting cluster id"
	$ClusterMeta = (databricks clusters list --output json | ConvertFrom-Json).clusters
	if($ClusterMeta.GetType().name -ne "Object[]") {
		throw "Databricks server returned an error. Error message: $ClusterMeta"
	}
	$ClusterId = ($ClusterMeta | where {$_.cluster_name -eq $ClusterName} | Select cluster_id -ExpandProperty cluster_id)
	if(!$ClusterId) {
		throw "Cluster id has not been recieved. Error message: $ClusterMeta"
	}
	Write-Output "Cluster id has been successfully returned."
}
Catch{
    Throw
}

$RequestPayload = '{\"run_name\":\"' +$ProcessName +'\", \"existing_cluster_id\": \"' +$ClusterId +'\", \"notebook_task\":
{\"notebook_path\": \"' +$ExecNotebook +'\", \"base_parameters\": ' +$NotebookParams +'}}'

#call job
try{
	# to add check if exists
    #run submit
	Write-Output "Running databricks job: $JobId"
	$callback = databricks runs submit --json $RequestPayload
	
	if($callback.GetType().name -ne "Object[]") {
		throw "Job wasn't submitted. Error message: $callback"
	}
	#extract runid
	$run_id = ($callback | ConvertFrom-Json).run_id
	if(!$run_id) {
		throw "Job wasn't submitted. Error message: $callback"
	}
	Write-Output "Job id $JobId was submitted successfully. Run id: $run_id"
	$status = "PENDING"
	While ($status -eq "PENDING" -or $status -eq "RUNNING" -or $status -eq "SKIPPED" -or $status -eq "TERMINATING")
	{
        Start-Sleep $CheckLoopTime 
		$state = (databricks runs get --run-id $run_id | ConvertFrom-Json)
		$status = $state.state.life_cycle_state		
	}
	if ($status -eq "INTERNAL_ERROR")
	{
		throw "Job $JobId has failed with error message: $($state.state.state_message)"
	} 
	if ($state.state.result_state -ne "SUCCESS")
	{
		throw "Job $JobId has failed with $state.state.result_state status. Returned message was:`n$($state.state.state_message)"
	}
	else
	{
		Write-Output "Job $JobId was executed SUCCESSFULLY. Execution details: `n$state"
	}
}
Catch{
    Throw
}	


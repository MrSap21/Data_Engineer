UPDATE $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}
FROM
(
SELECT(SUM(1) OVER (ORDER BY 1 ROWS UNBOUNDED PRECEDING) + :pkey) as pkey,
ndc_nbr,
ndc_form_cd,
generic_ingrd_id,
edw_rec_begin_dt

   FROM $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}
   WHERE ${pPKEY_COLUMN_NAME} IS NULL
   AND src_sys_cd = '${pSRC_SYS_CD}'
) AS stg
SET   ${pPKEY_COLUMN_NAME} = stg.pkey
    , edw_etl_step = 'PKEY'
WHERE
$pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}.ndc_nbr = stg.ndc_nbr
AND   $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}.ndc_form_cd = stg.ndc_form_cd
AND   $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}.generic_ingrd_id = stg.generic_ingrd_id
AND   $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}.edw_rec_begin_dt = stg.edw_rec_begin_dt
AND   $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}.${pPKEY_COLUMN_NAME} IS NULL
AND   $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}.src_sys_cd = '${pSRC_SYS_CD}'
AND   $pSTG_DATABASE_NAME.${pSTG_SCHEMA}.${pSTG_TABLE}.edw_etl_step = 'CIF'
# WBA Azure Analysis Services Standard Template User Responsibilities

Not all security controls have automatic enforcement mechanisms available. For those that do not, it is the responsibility of the team deploying and
leveraging the service instance to account for the security control.

This document will detail the security control, and the expectation on the deployer/user to use the service properly.

Please review and understand what additional steps you must take or processes you must follow to use this resource type in a compliant way.

> If you would like to maintain a record of how you have complied with these manual controls you can take a copy of this file
> and add details about how you are accounting for them as responses to each similar to how the controls are detailed in the [SECURITY.md](./SECURITY.md)
> document.

# 1. Authentication & Authorization

# 2. Network Security

## 2.06
**TLSv1.2 shall be used and configuration requirements as presented in the WBA Cryptography & Key Management Standard MUST be followed. As stipulated above, AKV Must be used to securely store certificates.**
---
AAS requires data connections to be TLS enabled but does not provide the ability to specify which version/s of TLS is allowed/denied.  Application teams must ensure their client connections are configured to only utilize TLS 1.2.

## 2.07
**For internal WBA systems, TLS 1.2 MUST be implemented using WBA signed PKI certificates.**
---
AAS requires data connections to be TLS enabled but does not provide the ability to specify which version/s of TLS is allowed/denied.  Application teams must ensure their client connections are configured to only utilize TLS 1.2.

# 3. Data Security

## 3.02
**Where applicable, Confidential data should be encrypted at the field level using the WBA Enterprise Encryption solution, Voltage.  All Payment Card Industry (PCI), Electronic Patient Health Information (ePHI), and Personally Identifiable Information (PII) data elements MUST be encrypted or tokenized prior to database ingestion.**

> **Note: If the persistent data store (e.g. database) is encrypted with TDE, only the below list of data elements will require field level encryption (FLE):**
> * **Names (first and last)**
> * **Addresses (not including state)**
> * **Phone Numbers (e.g. home, work, cell, etc.)**
> * **Email Addresses**
> * **Rx Numbers**
> * **Free form text fields**
> * **SSN's**
> * **Driver' License Numbers**
> * **Credit Card Numbers (Tokenization Required)**
>
> **If TDE is not used all PHI and PII data elements Must be encrypted with FLE.**
---
App teams are responsible for identifying and implementing appropriate encryption controls.

# 4. Audit & Logging

# 5. PaaS Specific Security Controls

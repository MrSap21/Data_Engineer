# WBA Azure Analysis Services Standard Template Security Controls

Approved usage of a PaaS within the WBA environment is contingent on the ability for the service to be implemented and used
in accordance with the below detailed security controls.

These controls are broken down into major sections:
* [Authentication & Authorization](#1.-authentication-&-authorization)
* [Network Security](#2.-network-security)
* [Data Security](#3.-data-security)
* [Audit and Logging](#4.-audit-&-logging)
* [Service Specific Security](#5.-service-specific-security)


For each of the controls listed there are some key pieces of information we track as part of the hardening requirements

### Control Strength
Controls are rated based on the level of certainty that can be had that it is met in all cases. There are 4 different rankings

* `Hard`: 
    The Hard rating reserved for controls that are applied in a way that cannot be easily circumvented. Such as when it is native to the platform service with no open to disable it, or where Azure Policy can be used to enforce the values above the subscription level, or there is a central process that ensures it is followed. _(The desire from a security perspective is to have as many of the controls met with `Hard` enforcement as possible)_
* `Medium`:
    Medium controls are those that can be enforced in a typical scenario, but under certain situations may be able to be bypassed by the deployer/user. For instance the CCP pipeline is considered a `Medium` rating because if you gain access to the target environment that would allow you to deploy the service outside of the pipeline, the enforcement is lost.
* `Soft`:
    Soft controls are also referred to as `App Team Responsibilities`. This means that there is guidance and a requirement for the usage to conform to a security control. but there is no mechanism to enforce it as part of the deployment, or during usage. There will be a corresponding entry in the [RESPONSIBILITIES.md](./RESPONSIBILITIES.md) document that explains what the users responsibilities are related to the control when using the service.
* `N/A`:
    The control in question is not applicable for the service type and does not need to be enforced. _(You can expect the other entries to be N/A as well in this case)_


### Enforcement Mechanism
The enforcement mechanism details what is providing this security feature. This list varies, and generally refers to the strongest mechanism in place

> In some cases more than one type is applicable, such as using an Azure Policy as well as the CCP Pipeline to validate the values.
> In this case, the CCP Pipeline is providing UX enrichment and not really enforcing the control so Azure Policy is listed as the control



### Status 
Status indicates if the control is being met or not. There 5 different values you might see in the status category

* `Implemented`: 
    The enforcement mechanism is in place, and expected to be enforcing the control.
* `Needs to be Implemented`: 
    The enforcement mechanism is not in place, potentially because of an issue with implementation that has delayed it cannot be met at this time and is considered a gap in the security posture for the service. The expectation is that the control will be met as soon as possible.
* `Not Implemented`: 
    The enforcement mechanism is not in place, and the expectation is that it will not be. This may be due to a technical limitation, or because fulfillment of the control would hamper usage of the service.
* `App Team Responsibility`: 
    The control cannot be forcefully applied and it is left to the app team deploying the service to adhere to the control as specified. There will be a corresponding entry in the [RESPONSIBILITIES.md](./RESPONSIBILITIES.md) document that explains what the users responsibilities are related to the control when using the service.
* `N/A`: 
    The control does not apply for this service type.

# 1. Authentication & Authorization

## 1.01
**Authentication and authorization MUST integrate with an approved WBA centralized Identity Access Management (IAM) solution (e.g. OneID, Azure AD, LDAP directory services, etc.) that is configured to comply with the Global Security Control Framework (GSCF) password requirements.  Where possible, certificate based authentication should be used instead of passwords.**

> **Per the GSCF, Two-factor authentication must be enforced where users are accessing Confidential Information directly via the Internet.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Azure AD is integrated by default for control plane/admin and for the data plane access.   

Need to engage Identity Engineering understand/evaluate B2B authentication implications.

## 1.02
**User IDs must comply with the WBA GSCF and must be:**
* **Unique**
* **Changed from the manufacturer default**
* **Not be shared**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `ID Admins existing process/system`
* **Status:** `Implemented`

Analysis Services in integrated with Azure AD by default for all access.  The WBA ID Admin team manages User accounts and ensures their compliance with GSCF policy.

## 1.03
**Application/Service/System/etc. authentication data (e.g. tokens, passwords, certificates, API keys, and other secrets) must be protected with Azure Key Vault (AKV).  All mechanisms employed must comply with the Cryptography and Key Management Standard.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Pipeline/Policy`
* **Status:** `Implemented`

AKV will store all keys and secrets. Will not be available for BYOK.

## 1.04
**Open standards such as OpenID Connect and OAUTH 2.0 are the WBA recommended standard protocols for Federation SSO integration.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Analsys Servicess in integrated with Azure AD which supports Oauth and Open ID connect open standards.

## 1.05
**Java Web Tokens (JWT) should be used for authenticating API and/or micro-service calls.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Azure AD uses Oauth tokens to securely authorize access.

## 1.06
**Administrative accounts shall require stronger authentication levels in compliance with the GSCF administrative account requirements.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Not Implementable`

Azure AD enabled - Are there dedicated RBAC roles indicative of PIM onboarding?

## 1.07
**Root access or full administrative access requires that ALL of the following conditions be met:**
* **The requestor needs the access to perform assigned job duties.**
* **Approvals from applicable systems and data owners have been received.**
* **No other authorizations are available or can be customized to enable the required function.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `Pipeline Injected`
* **Status:** `Implemented`

Data models rights are inherited from the UID associated with AAD RBAC defintions

Model Administrator Level Permissions (Application Team) apply ONLY to a specific authorized model:
Can modify a polybase model schema, process, query all data, and manage model roles 
Can create and modify the polybase data model (semantic layer) in Visual Studio, which is deployed to AAS
Can only read from authorized data stores 
AAS Server Administrators Level Permissions (Cloud Engineering Team) apply to ALL models:
Specific to an AAS server instance 
Manage all data models
Manage all data model roles
Using Azure portal, Visual Studio, or SSMS

## 1.08
**Roles or group permissions should be utilized when assigning permissions to individual users. The principle of "least privileged" MUST be followed when assigning users to these roles to ensure they only have the necessary permissions available to perform their job function.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `HCF Access Policy`
* **Status:** `Implemented`

HCF access policy - this is inherited from the HCF controls

## 1.09
**All authorization SHALL employ a default-deny model, where access is denied unless explicitly permitted by the user's role/group membership.  A formal process SHALL be documented and followed for approving the addition of user to access groups.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Native to the platform and managed through AAD

## 1.10
**Coarse grained access controls via group assignment should be able to be managed at the divisional central account management level.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Inherited from HCF and RBAC assignment


# 2. Network Security

## 2.01
**Internet accessibility to the PaaS Must be removed/blocked unless public connectivity to/from the service is a business requirement (e.g. a WAF needs a public IP to do it's job).**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Needs to be Implemented`

This is a public service - will leverage AFW for whitelisting of Ips. 
PBI connectivity is configured in PBI interface

## 2.02
**The PaaS solution Must be configured to receive/send data using a Private IP (e.g. MS Private Link or customer VNET injection).**

---

* **Control Strength:** `Not Applicable`
* **Enforcement Mechanism:** `None`
* **Status:** `Not Implementable`

This is a public IP and is a public endpoint

## 2.03
**In situations where the service does not have a private link option available, VNET service endpoints must be used/configured to only permit traffic from approved WBA subnets and block all other traffic.**

---

* **Control Strength:** `Not Applicable`
* **Enforcement Mechanism:** `None`
* **Status:** `Not Implementable`

This will be managed by the AAS firewall through approved egress points and whitelisting

## 2.04
**When VNET service endpoints are used, VNET service endpoint policies must be used/configured to only permit traffic to the WBA instance of the service.**

> **Note: this feature is currently only available for Azure Storage.**

---

* **Control Strength:** `Not Applicable`
* **Enforcement Mechanism:** `None`
* **Status:** `Not Implementable`

AAS relies on the AAS firewall

## 2.05
**Transport layer security (encryption) is required to secure all communications to the PaaS solution.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

This is inherited from the service. TLS is supported by default

## 2.06
**TLSv1.2 shall be used and configuration requirements as presented in the WBA Cryptography & Key Management Standard MUST be followed. As stipulated above, AKV Must be used to securely store certificates.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `DB Security Standard`
* **Status:** `Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#2.06) for details on your responsibilities to meet this security control requirement.

## 2.07
**For internal WBA systems, TLS 1.2 MUST be implemented using WBA signed PKI certificates.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `DB Security Standard`
* **Status:** `Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#2.07) for details on your responsibilities to meet this security control requirement.

## 2.08
**For external PaaS or SaaS solutions commercially signed (e.g. VeriSign, Digi-Cert, etc.) certificates MUST be used to implement the TLS 1.2 connections.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Service uses MSFT CA/IA

## 2.09
**Self-signed certificates ARE NOT permitted for use.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Service uses MSFT CA/IA

## 2.10
**PaaS solutions that are injectable into the customer VNET (e.g. Application Gateway, SQL Managed PaaS, etc.) must be segmented/zoned according to their data classification and placed in the appropriate subnet tier (i.e. web, app, database tier).**

---

* **Control Strength:** `Not Applicable`
* **Enforcement Mechanism:** `None`
* **Status:** `Not Implementable`

Cannot be injected.


# 3. Data Security

## 3.01
**Data encryption at rest is required according to its data classification as specified in the GSCF, section 4.2.7. (e.g. Confidential Data must be encrypted at rest). Also, any encryption solution utilized must comply with the WBA Cryptography and Key Management Standard.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Azure Analysis Services uses Azure Blob storage to persist storage and metadata for Analysis Services databases. Data files within Blob are encrypted using Azure Blob Server Side Encryption (SSE). When using Direct Query mode, only metadata is stored. The actual data is accessed through encrypted protocol from the data source at query time.

## 3.02
**Where applicable, Confidential data should be encrypted at the field level using the WBA Enterprise Encryption solution, Voltage.  All Payment Card Industry (PCI), Electronic Patient Health Information (ePHI), and Personally Identifiable Information (PII) data elements MUST be encrypted or tokenized prior to database ingestion.**

> **Note: If the persistent data store (e.g. database) is encrypted with TDE, only the below list of data elements will require field level encryption (FLE):**
> * **Names (first and last)**
> * **Addresses (not including state)**
> * **Phone Numbers (e.g. home, work, cell, etc.)**
> * **Email Addresses**
> * **Rx Numbers**
> * **Free form text fields**
> * **SSN's**
> * **Driver' License Numbers**
> * **Credit Card Numbers (Tokenization Required)**
>
> **If TDE is not used all PHI and PII data elements Must be encrypted with FLE.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `GISP/GECF Standard`
* **Status:** `App Team Responsibility`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#3.02) for details on your responsibilities to meet this security control requirement.

## 3.03
**In cases where field level encryption is not viable, the solution MUST support native persistent data store encryption (e.g. Transparent Data Encryption (TDE)). TDE alone typically isn't sufficient and must be combined with RBACs to restrict unauthorized users/accounts from having access to confidential/personal data.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

TDE is a native capability to this platform and will be enabled by default

## 3.04
**The solution MUST NOT store unencrypted confidential data in index files, swap files, config files, audit logs, etc.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Natively it cannot transform the data from the management plane

## 3.05
**Native persistent store encryption solutions should allow for encryption keys to be controlled/managed by WBA. Key rotation must comply with requirements specified in the WBA cryptography and Key Management standard.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Microsoft Managed Keys will be used

## 3.06
**Encryption keys Must be stored in a protected location (e.g. Azure Key Vault) and not collocated with the persistent data store.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Azure Key Vault(s) - MSFT Managed


# 4. Audit & Logging

## 4.01
**Audit logs (for all data classifications) SHOULD be imported into a centralized logging solution (e.g. Event Hubs, Splunk, ELK, etc.) to facilitate collection/review/auditing of required events with a standardized solution.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `Pipeline Injected`
* **Status:** `Implemented`

Diagnostic logging will be enabled by pipeline

## 4.02
**In accordance with the WBA Security Event Logging Standard the solution MUST be configured to log these specific events:**
* **Authentication events**
* **Account creation/deletion** 
* **Privilege changes**
* **Input validation failures**
* **Output validation failures**
* **Session management failures**
* **System or process start-ups and shutdowns**
* **System changes, including device attachment/detachment and object creation/deletion**
* **Use of administrative privileges, including utilities**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `Pipeline Injected`
* **Status:** `Implemented`

Security logging will be enabled by pipeline

## 4.03
**Event logs MUST include the following attributes:**
* **Log Timestamp in international format**
* **Event Timestamp in international format (To cope with events that cannot be logged immediately)**
* **Process identifier**
* **Source system identifier (Application, endpoint or network device generating the log)**
* **Source of the event (E.g. User, ip address, and/or device identifier)**
* **User identity**
* **Event type**
* **Event severity** 
* **Event Description** 
* **Outbound connections, including source and destination ports**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `Pipeline Injected`
* **Status:** `Implemented`

Event logging will be enabled by pipeline

## 4.04
**Critical security events/alerts MUST be forwarded to the WBA SIEM solution for immediate escalation.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Security Center Enabled`
* **Status:** `Needs to be Implemented`

Advanced Threat Protection (ATP) logic must be applied to logs prior to sending them to the SIEM.  This requires Azure Security Center standard to be enabled.


# 5. PaaS Specific Security Controls

## 5.01
**AAS Firewall to be configured for "deny all" except by whitelist**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

Approved egress points
Allow access to PBI Services

## 5.02
**On Premise Data Gateway**

---

* **Control Strength:** `Not Applicable`
* **Enforcement Mechanism:** `None`
* **Status:** `Not Applicable`

Configuration and Identity


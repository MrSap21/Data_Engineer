# WBA Azure Analysis Services Standard Template Implementation

![status](https://img.shields.io/badge/Status-approved%20(2020--05--14)-success)

Azure Analysis Services (AAS) is a Microsoft Platform as a Service (PaaS) cloud-hosted management service that 
provides enterprise-grade data models in the cloud. Use advanced mashup and modeling features to combine data 
from multiple data sources (including SQL Database, SQL Data Warehouse, Cosmos DB, Storage Accounts), define 
metrics, and secure your data in a single, trusted tabular semantic data model.


[LDA Presentation](https://walgreens.sharepoint.com/sites/GlobalEnterpriseArchitecture/LEAP_DA/Lists/LEAP%20DA%20meetings/DispForm.aspx?ID=95&e=RIUoQ2)


## Common Use Cases
---

* **Allowing access to data without providing access to the data source**
* **Build Data Models for vendor access**



## Architectural Pattern
---

![](./docs/diagram.png)



## Required Prerequisites
---

### Target Subscription

All resources are deployed into an Azure subscription which must exist ahead of the deployment. In most cases a subscription will already exist and it is
just a matter of knowing its name or ID. If you already have a subscription you can retrieve its name in one of several ways.

* From the [Azure Portal](https://portal.azure.com)> view the subscription overview blade and copy either the `Subscription name` or `Subscription ID`  from there.
* From Powershell> _(once authenticated)_ run the `Get-AzSubscription` Cmdlet which will show all subscriptions you have access to. Select the entry you want from there
* From the az cli> _(once authenticated)_ run the `az account list` command which will show all subscriptions you have access to. Select the entry you want from there

> If you are new to Azure within WBA and need to learn about onboarding and selection of a target subscription please send an email to the 
> [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com) and we will help to engage the appropriate people to get your group onboarded
> so you can start leveraging the pipeline for deployments.

> If you need a new subscription created _(rare)_ please send an email to the [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com) and we will help you engage
> the appropriate people to validate and fulfill your request.

### Resource Group Name

All resources are deployed into a resource group _(which is in a subscription)_. If the resource group name given does not exist in the target subscription
it will be created as part of the deployment. If it does exist the resource(s) will be added to it.

There is a naming standard defined for resource groups that should be followed. See the 
[Resource Group Naming Standard](https://dev.azure.com/WBA/IT%20Services/_git/ccp-ent-resource-names?path=%2Fresource-group.yml) to help you select 
an appropriate name for your resource group

How you lay out resource groups is left up to you in most cases, but there are a couple of considerations to keep in mind about how they are used.
The tags you provide for the resource deployment will be applied to the resource group and all resources within the group will get the same tags.
This means you cannot mix resources that would have different tags, which are used for billing and sensitivity details.

### Tag Values

Tags are used at WBA to assign costs and specify data sensitivity. Before you begin, you will need to know your 4 billing tags for your department or project
and to know what your sensitivity classification is so you can provide the appropriate values as part of the parameters.

> If you are new to Azure within WBA and need to learn about onboarding and assignment of billing tags please send an email to the
> [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com) and we will help to engage the appropriate people to get your group onboarded
> so you can start leveraging the pipeline for deployments.


### RBAC Roles

Sometimes access to the resource level is necessary to perform work, ranging from managing a resource to accessing data from within it.

>Note: For more information see [Role Assignments](/docs/ROLE_ASSIGNMENTS.md)




## Security Guidelines
---

This service deployment and the resulting resource conforms with WBA security standards detailing how and where it is deployed as well
as how it can be used. For information about the security requirements and the controls in place to meet them please see 
the [Security Requirements](./SECURITY.md) document


## User Responsibilities
---

Not all security requirements can be met automatically. The [User Responsibilities](./RESPONSIBILITIES.md) document includes
all of the security aspects related to the usage of the deployed resource. Please review and understand what additional steps
you must take or processes you must follow to use this resource type in a compliant way.

> If you would like to maintain a record of how you have complied with these manual controls you can take a copy of this file
> and add details about how you are accounting for them as responses to each.


## Getting Started
---

1. Ensure you have set up your environment for submitting build requests detailed in the [PIPELINE_TRIGGER](../../PIPELINE_TRIGGER.md) guide
2. Make a copy of the [reference parameter file](./analysis-services-parameters-min.json) and rename it to something meaningful for your deployment
3. Follow the steps under the [Prerequisites Section](#required-prerequisites) to make sure everything is in place prior to deployment

The Analysis Services deployment can be as simple or as complex as you need it. At the core, only the following parameters are required:
* [location](./PARAMETERS.md#%60parameters.location%60)
* [serverName](./PARAMETERS.md#%60parameters.servername%60)

>NOTE: 
>Backups are turned off. They need to be managed using SAS tokens and incur additional costs of a storage account. 
>Since no actual data is stored in Analysis Services and there is no gonvernance of SAS tokens as of now, it was determined that they would not be used. 
>If the models need to be restored, they can be rebuilt in Visual Studio and republished to the server.



## Parameters
---

Resource definitions are stored as parameter files you submit to complete the build. There are two parameter files to use as starting points
for your own resources. One with the minimum required parameters, and one with all of the parameters.

You can use these parameter files as static files you fill in and submit, or build more complex deployment chains where you generate the files
with the appropriate values to build whole environments from the individual pieces, retrieving information from one to supply the information to
the next.

In addition to the two parameter file examples you can use, the full parameter reference is available that details all of the options
and information about them, when, how, and why they are used.

* [Parameters Reference](./PARAMETERS.md)
* [Minimum Parameters](./analysis-services-parameters-min.json)
* [All Parameters](./analysis-services-parameters-full.json)

### How To Build Your Parameters File

1. We recommend you start with copying the [Minimum Parameters File](./analysis-services-parameters-min.json).
2. Fill out the information for the parameters.
3. If additional features are desired, see [Parameters Reference](./PARAMETERS.md).
4. Copy additional parameters from the [All Parameters](./analysis-services-parameters-full.json) into your parameters file.
5. Fill out the necessary information in the new parameters.

## Whats Next?
---





### Firewall Rules

Firewall rules are automatically added for Azure region egress points based on the environment 
type where the resources are being deployed. Rules are also added for data center edge ranges.



### Connecting Services

* **Power BI**

  Access to the Analysis Services server through Power BI is enabled by default.






### Operational
Listed below are the logs and metrics that are being retained and sent to the global LogAnalytics workspace:
```
metrics
    - AllMetrics
logs
    - Engine
```




## Getting Help
---

It can be hard to pin down exactly what is going on when something fails or isn't working how you expected it to. These
can be broken down into a few areas handled by different groups.




### Deployment Time

* Failures during resource deployments
* Assistance with parameter values
* Requests for option support

Contact the [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com)


### Post-Deployment Time




### Additional Information




### Helpful Links


# WBA Azure Analysis Services Standard Template Parameter Reference

For each deployment type there are two reference files. A template and its accompanying parameter file.

The template/parameter combination show a minimal configuration with options required to conform with WBA standards for a deployment.
See the Parameters & Common Parameters sections below for details.

Controls are put in place to restrict the use of settings that would break design or security principles

To perform a deployment of a template, refer to the [Pipeline Trigger](/PIPELINE_TRIGGER.md) documentation

> Templates are based off of the Microsoft API reference which you can review for more insight about the options available.
>[Analysis Services Template Reference](https://docs.microsoft.com/en-us/azure/templates/microsoft.AnalysisServices/2017-08-01/servers)


## Common Parameters
---

There are a few parameters that are needed in every template that the pipeline uses to perform the deployments

### `parameters.location`
* Type: `string`
* Required: `true`
* Default Value: `NONE`

The location information is needed for the deployment that takes place ahead of the invocation of the template & parameter when
a resource group is created. the pipeline retrieves the target location from your parameter file.

### `parameters.tags`
* Type: `object`
* Required: `true`
* Default Value: `NONE`
* Example:
```js
{
    "Sensitivity": "Non-Sensitive",
    "SenType": "Not Applicable",
    "EnvType": "Non-Production",
    "LegalSubEntity": "Walgreen Co",
    "SubDivision": "Infrastructure",
    "Department": "Cloud Automation",
    "CostCenter" : "Cloud Engineering 5001"
}
```
WBA Requires the inclusion of a set of tags to identify key aspects of the resources such as billing and zoning classification.
This is required on the parent resource group that is generated as part of the deployment and is read from your parameter file

>Note: These tags are an example only!
Check the [enterprise-resource-tags](https://oneit.wba.com/versioncontrol/projects/CLOUDARCH/repos/enterprise-resource-tags/browse) project for the list of currently required tags, their data types, and acceptable values.


### `deploymentParameters.subscription`
* Type: `string`
* Required: `true`
* Default Value: `NONE`

The subscription that will be deployed is needed in a multi-subscription environment and is used ahead of the invocation of the template & parameter file.
To keep all of the deployment details required for particular resource in one place that can be tracked in a declarative way, the subscription name or id
is included in a secondary block outside of the parameters so it can be tracked in the file.

The subscription can be specified as either the name or id.

### `deploymentParameters.resourceGroup`
* Type: `string`
* Required: `true`
* Default Value: `NONE`

Resource groups are used as a means to separate resources into logical groupings based on a couple of different scenarios. The main considerations for
grouping resources into a group are:
* RBAC assignments (does a common group or person need access to all of these resources)
* Billing allocation (do all of these resources get billed to the same department)
* Lifecycle alignment (would i want to delete all of these resources at the same time)

> Follow the [resource group naming standard](https://dev.azure.com/WBA/IT%20Services/_git/ccp-ent-resource-names?path=%2Fresource-group.yml)
> when specifying the name of your resource group.

### `deploymentParameters.templateFile`
* Type: `string`
* Required: `true`
* Default Value: `NONE`

To allow for a many-to-one scenario of parameter files and templates, the name of the template file is specified in the parameter file so that
it can be selected and used for the deployment.

## Service Parameters
---

### `parameters.serverName`
* type: `string`
* required: `true`
* defaultValue: `NONE`
* minLength: `3`
* maxLength: `63`

The name of the Analysis Services server. It must be a minimum of 3 characters, and a maximum of 63.



Server name must be unique per region.


### `parameters.querypoolConnectionMode`
* type: `string`
* required: `false`
* defaultValue: `All`
* allowedValues: `['All', 'ReadOnly']`

How the read-write server's participation in the query pool is controlled.<br/>It can have the following values: <ul><li>readOnly - indicates that the read-write server is intended not to participate in query operations</li><li>all - indicates that the read-write server can participate in query operations</li></ul>Specifying readOnly when capacity is 1 results in error.



### `parameters.skuName`
* type: `string`
* required: `false`
* defaultValue: `S0`
* allowedValues: `['D1', 'B0', 'B1', 'S0', 'S1', 'S2', 'S3', 'S4', 'S8', 'S9', 'S8v2', 'S9v2']`

Name of the SKU level. A standard SKU (one that begins with S) is required for production.  S8 and S9 are only available in East US 2 and West Europe



SKU names are based on tier and processing power of the server. 
The letter is the tier and the number represents the amount of QPUs and Memory used for the server. 
The higher the number, the more processing power is used and the higher the cost of running the server. 

>NOTE: You must use a standard tier (one that starts with S) in production. 
>Developer or Basic can be used in lower environments.

Some skus are region specific. 
See [availability-by-region](https://docs.microsoft.com/en-us/azure/analysis-services/analysis-services-overview#availability-by-region) for more information.


### `parameters.skuCapacity`
* type: `int`
* required: `false`
* defaultValue: `1`
* minValue: `1`
* maxValue: `8`

The number of instances in the read only query pool.



Scale-out of more than one instance is supported on selected regions only. 
See [availability-by-region](https://docs.microsoft.com/en-us/azure/analysis-services/analysis-services-overview#availability-by-region) for more information.


### `parameters.roleAssignments`
* type: `array`
* required: `false`
* defaultValue: `[]`

A list of role assignments mapped to identities


>#### roleAssignments Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|roleDefinitionName |string |yes |Name of the RBAC role that needs to be assigned to the principal i.e. Reader, Contributor, Virtual Network Administrator, etc. |None |WBA - LEAP - Resource Deletion,Reader |
>|principalName |string |no |Azure AD name or email address of the user, group or service principal. |None | |
>|principalId |string |no |Azure AD Object ID of the user, group or service principal. |None | |
>#### Example
>````js
>{
>    "roleDefinitionName": string,
>    "principalName": string,
>    "principalId": string
>}
>````

Available Roles:
* **WBA - LEAP - Resource Deletion:** Allows access to delete the resource.
* **Reader:** Lets you view everything, but not make any changes. Please see [here](https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles#reader) for more information.


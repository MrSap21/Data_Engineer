# WBA Azure API Management Standard Template Implementation

![status](https://img.shields.io/badge/Status-approved%20(2020--01--16)-success)

Azure API Management is a way to create consistent and modern API gateways for existing back-end services.

[APIM Key Concepts](https://docs.microsoft.com/en-us/azure/api-management/api-management-key-concepts)


[LDA Presentation](https://walgreens.sharepoint.com/sites/GlobalEnterpriseArchitecture/LEAP_DA/Lists/LEAP%20DA%20meetings/DispForm.aspx?ID=39&e=DWwZCd)


## Common Use Cases
---

* **Unified API management** - Manage all your APIs from one service from grouping by product to versioning.
* **Secure APIs** - Secure APIs with keys, tokens, and IP filtering.
* **Access Delegation** - Delegate access between internal, and external APIs.



## Architectural Pattern
---

![](./docs/diagram.png)



## Required Prerequisites
---

### Target Subscription

All resources are deployed into an Azure subscription which must exist ahead of the deployment. In most cases a subscription will already exist and it is
just a matter of knowing its name or ID. If you already have a subscription you can retrieve its name in one of several ways.

* From the [Azure Portal](https://portal.azure.com)> view the subscription overview blade and copy either the `Subscription name` or `Subscription ID`  from there.
* From Powershell> _(once authenticated)_ run the `Get-AzSubscription` Cmdlet which will show all subscriptions you have access to. Select the entry you want from there
* From the az cli> _(once authenticated)_ run the `az account list` command which will show all subscriptions you have access to. Select the entry you want from there

> If you are new to Azure within WBA and need to learn about onboarding and selection of a target subscription please send an email to the 
> [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com) and we will help to engage the appropriate people to get your group onboarded
> so you can start leveraging the pipeline for deployments.

> If you need a new subscription created _(rare)_ please send an email to the [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com) and we will help you engage
> the appropriate people to validate and fulfill your request.

### Resource Group Name

All resources are deployed into a resource group _(which is in a subscription)_. If the resource group name given does not exist in the target subscription
it will be created as part of the deployment. If it does exist the resource(s) will be added to it.

There is a naming standard defined for resource groups that should be followed. See the 
[Resource Group Naming Standard](https://dev.azure.com/WBA/IT%20Services/_git/ccp-ent-resource-names?path=%2Fresource-group.yml) to help you select 
an appropriate name for your resource group

How you lay out resource groups is left up to you in most cases, but there are a couple of considerations to keep in mind about how they are used.
The tags you provide for the resource deployment will be applied to the resource group and all resources within the group will get the same tags.
This means you cannot mix resources that would have different tags, which are used for billing and sensitivity details.

### Tag Values

Tags are used at WBA to assign costs and specify data sensitivity. Before you begin, you will need to know your 4 billing tags for your department or project
and to know what your sensitivity classification is so you can provide the appropriate values as part of the parameters.

> If you are new to Azure within WBA and need to learn about onboarding and assignment of billing tags please send an email to the
> [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com) and we will help to engage the appropriate people to get your group onboarded
> so you can start leveraging the pipeline for deployments.


### RBAC Roles

Sometimes access to the resource level is necessary to perform work, ranging from managing a resource to accessing data from within it.

>Note: For more information see [Role Assignments](/docs/ROLE_ASSIGNMENTS.md)

### Subnet Limitations

When deploying an Azure API Management instance to a Resource Manager VNET, the service must be in a dedicated subnet that contains no other resources except for Azure API Management instances. If an attempt is made to deploy an Azure API Management instance to a Resource Manager VNET subnet that contains other resources, the deployment will fail.

### Subnet Size

The minimum size of the subnet an API Management service can be deployed is /29 that gives three usable IP addresses. Each additional scale unit of API Management requires two more IP addresses.

### Route Table

The route that used by the subnet must include a rule to bypass the firewall for APIM Management Plane traffic

Name: Azure-{region}-API-Management
Next Hop Type: Internet
Address Prefix: 
* **CentralUS:** 13.86.102.66
* **EastUS2:** 20.44.72.3
* **NorthEurope:** 52.142.95.35
* **WestEurope:** 23.101.67.140


### Certificates

Certificates must be passed in using a valid KeyVault using [keyVaultId](./PARAMETERS.md#%60hostnameconfigurations-object%60).




## Security Guidelines
---

This service deployment and the resulting resource conforms with WBA security standards detailing how and where it is deployed as well
as how it can be used. For information about the security requirements and the controls in place to meet them please see 
the [Security Requirements](./SECURITY.md) document


## User Responsibilities
---

Not all security requirements can be met automatically. The [User Responsibilities](./RESPONSIBILITIES.md) document includes
all of the security aspects related to the usage of the deployed resource. Please review and understand what additional steps
you must take or processes you must follow to use this resource type in a compliant way.

> If you would like to maintain a record of how you have complied with these manual controls you can take a copy of this file
> and add details about how you are accounting for them as responses to each.


## Getting Started
---

1. Ensure you have set up your environment for submitting build requests detailed in the [PIPELINE_TRIGGER](../../PIPELINE_TRIGGER.md) guide
2. Make a copy of the [reference parameter file](./apim-parameters-min.json) and rename it to something meaningful for your deployment
3. Follow the steps under the [Prerequisites Section](#required-prerequisites) to make sure everything is in place prior to deployment

The APIM deployment can be as simple or as complex as you need it. At the core, only the following parameters are required:
* [location](./PARAMETERS.md#%60parameters.location%60)
* [serviceName](./PARAMETERS.md#%60parameters.servicename%60)
* [publisherEmail](./PARAMETERS.md#%60parameters.publisheremail%60)
* [publisherName](./PARAMETERS.md#%60parameters.publishername%60)
* [virtualNetworkConfigurationSubnetResourceId](./PARAMETERS.md#%60parameters.virtualnetworkconfigurationsubnetresourceid%60)

This will create a Premium SKU resource of capacity 1. Products, APIs, Subscriptions, and Custom Hostnames will have to be configured after deployment in this case.

To configure custom [hostnames](./PARAMETERS.md#%60parameters.hostnameconfigurations%60) during deployment, certificates from a previously deployed KeyVault is required.



## Parameters
---

Resource definitions are stored as parameter files you submit to complete the build. There are two parameter files to use as starting points
for your own resources. One with the minimum required parameters, and one with all of the parameters.

You can use these parameter files as static files you fill in and submit, or build more complex deployment chains where you generate the files
with the appropriate values to build whole environments from the individual pieces, retrieving information from one to supply the information to
the next.

In addition to the two parameter file examples you can use, the full parameter reference is available that details all of the options
and information about them, when, how, and why they are used.

* [Parameters Reference](./PARAMETERS.md)
* [Minimum Parameters](./apim-parameters-min.json)
* [All Parameters](./apim-parameters-full.json)

### How To Build Your Parameters File

1. We recommend you start with copying the [Minimum Parameters File](./apim-parameters-min.json).
2. Fill out the information for the parameters.
3. If additional features are desired, see [Parameters Reference](./PARAMETERS.md).
4. Copy additional parameters from the [All Parameters](./apim-parameters-full.json) into your parameters file.
5. Fill out the necessary information in the new parameters.

## Whats Next?
---





### Firewall Rules

Traffic must be allowed to flow from the Hub Gateway in the region you are being deployed in to the Azure API Management management plane. Service tags can be utilized.

The following are rules that may be necessary depending on the types of services you are integrating with:
| Source / Destination Port(s) | Direction | Transport protocol | Service Tags (Source / Destination) | Purpose (*) |
|-|-|-|-|-|-|
| * / 3443 | Inbound | TCP | ApiManagement / VIRTUAL_NETWORK | Management endpoint for Azure portal and PowerShell |
| * / 443 | Outbound | TCP | VIRTUAL_NETWORK / Storage | Dependency on Azure Storage |
| * / 443 | Outbound | TCP | VIRTUAL_NETWORK / AzureActiveDirectory | Azure Active Directory (where applicable) |
| * / 1433 | Outbound | TCP | VIRTUAL_NETWORK / SQL | Access to Azure SQL endpoints |
| * / 5671, 5672, 443 | Outbound | TCP | VIRTUAL_NETWORK / EventHub | Dependency for Log to Event Hub policy and monitoring agent |
| * / 445 | Outbound | TCP | VIRTUAL_NETWORK / Storage | Dependency on Azure File Share for GIT |
| * / 443 | Outbound | TCP | VIRTUAL_NETWORK / AzureCloud | Health and Monitoring Extension |
| * / 1886, 443 | Outbound | TCP | VIRTUAL_NETWORK / AzureMonitor | Publish Diagnostics Logs and Metrics and Resource Health |
| * / 25, 587, 25028 | Outbound | TCP | VIRTUAL_NETWORK / INTERNET | Connect to SMTP Relay for sending e-mails |
| * / 6381 - 6383 | Inbound & Outbound | TCP | VIRTUAL_NETWORK / VIRTUAL_NETWORK | Access Redis Service for Cache policies between machines |
| * / 4290 | Inbound & Outbound | UDP | VIRTUAL_NETWORK / VIRTUAL_NETWORK | Sync Counters for Rate Limit policies between machines |
| * / * | Inbound | TCP | AZURE_LOAD_BALANCER / VIRTUAL_NETWORK | Azure Infrastructure Load Balancer |

User-defined Routes may also be necessary. Please see [here](https://docs.microsoft.com/en-us/azure/api-management/api-management-using-with-vnet#--control-plane-ip-addresses) for more details.



### Connecting Services

* **Application Gateway**

  Application Gateway is required for use of API Management, as per the approved architecture. Please see [Application Gateway](../appgateway-waf/README.md) for more information.

* **KeyVault**

  KeyVault is required for use of passing certificates to API Management. Please see [KeyVault](../keyvault/README.md) for more information.

* **Application Services**

  A common backend that can be used for hosting APIs is Azure Web Apps or Azure Function Apps. Please see [Azure Web Apps](../app-services-sites/README.md) for more information.






### Operational
Listed below are the logs and metrics that are being retained and sent to the global LogAnalytics workspace:
```
metrics
    - AllMetrics
logs
    - GatewayLogs
```




## Getting Help
---

It can be hard to pin down exactly what is going on when something fails or isn't working how you expected it to. These
can be broken down into a few areas handled by different groups.




### Deployment Time

* Failures during resource deployments
* Assistance with parameter values
* Requests for option support

Contact the [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com)


### Post-Deployment Time




### Additional Information




### Helpful Links


# WBA Azure API Management Standard Template Security Controls

Approved usage of a PaaS within the WBA environment is contingent on the ability for the service to be implemented and used
in accordance with the below detailed security controls.

These controls are broken down into major sections:
* [Authentication & Authorization](#1.-authentication-&-authorization)
* [Network Security](#2.-network-security)
* [Data Security](#3.-data-security)
* [Audit and Logging](#4.-audit-&-logging)
* [Service Specific Security](#5.-service-specific-security)


For each of the controls listed there are some key pieces of information we track as part of the hardening requirements

### Control Strength
Controls are rated based on the level of certainty that can be had that it is met in all cases. There are 4 different rankings

* `Hard`: 
    The Hard rating reserved for controls that are applied in a way that cannot be easily circumvented. Such as when it is native to the platform service with no open to disable it, or where Azure Policy can be used to enforce the values above the subscription level, or there is a central process that ensures it is followed. _(The desire from a security perspective is to have as many of the controls met with `Hard` enforcement as possible)_
* `Medium`:
    Medium controls are those that can be enforced in a typical scenario, but under certain situations may be able to be bypassed by the deployer/user. For instance the CCP pipeline is considered a `Medium` rating because if you gain access to the target environment that would allow you to deploy the service outside of the pipeline, the enforcement is lost.
* `Soft`:
    Soft controls are also referred to as `App Team Responsibilities`. This means that there is guidance and a requirement for the usage to conform to a security control. but there is no mechanism to enforce it as part of the deployment, or during usage. There will be a corresponding entry in the [RESPONSIBILITIES.md](./RESPONSIBILITIES.md) document that explains what the users responsibilities are related to the control when using the service.
* `N/A`:
    The control in question is not applicable for the service type and does not need to be enforced. _(You can expect the other entries to be N/A as well in this case)_


### Enforcement Mechanism
The enforcement mechanism details what is providing this security feature. This list varies, and generally refers to the strongest mechanism in place

> In some cases more than one type is applicable, such as using an Azure Policy as well as the CCP Pipeline to validate the values.
> In this case, the CCP Pipeline is providing UX enrichment and not really enforcing the control so Azure Policy is listed as the control



### Status 
Status indicates if the control is being met or not. There 5 different values you might see in the status category

* `Implemented`: 
    The enforcement mechanism is in place, and expected to be enforcing the control.
* `Needs to be Implemented`: 
    The enforcement mechanism is not in place, potentially because of an issue with implementation that has delayed it cannot be met at this time and is considered a gap in the security posture for the service. The expectation is that the control will be met as soon as possible.
* `Not Implemented`: 
    The enforcement mechanism is not in place, and the expectation is that it will not be. This may be due to a technical limitation, or because fulfillment of the control would hamper usage of the service.
* `App Team Responsibility`: 
    The control cannot be forcefully applied and it is left to the app team deploying the service to adhere to the control as specified. There will be a corresponding entry in the [RESPONSIBILITIES.md](./RESPONSIBILITIES.md) document that explains what the users responsibilities are related to the control when using the service.
* `N/A`: 
    The control does not apply for this service type.

# 1. Authentication & Authorization

## 1.01
**Authentication and authorization MUST integrate with an approved WBA centralized Identity Access Management (IAM) solution (e.g. OneID, Azure AD, LDAP directory services, etc.) that is configured to comply with the Global Security Control Framework (GSCF) password requirements.  Where possible, certificate based authentication should be used instead of passwords.**

> **Per the GSCF, Two-factor authentication must be enforced where users are accessing Confidential Information directly via the Internet.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

APIM utilizes Azure RBAC roles for resources, and allows for integration into Azure AD for developer accounts, which will allow for internal authentication where necessary.

## 1.02
**User IDs must comply with the WBA GSCF and must be:**
* **Unique**
* **Changed from the manufacturer default**
* **Not be shared**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

User IDs managed by Azure AD meet WBA GSCF. Anything else does not have permissions to make production changes.

## 1.03
**Application/Service/System/etc. authentication data (e.g. tokens, passwords, certificates, API keys, and other secrets) must be protected with Azure Key Vault (AKV).  All mechanisms employed must comply with the Cryptography and Key Management Standard.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

Certificates for custom hostnames must be passed using an approved KeyVault

## 1.04
**Open standards such as OpenID Connect and OAUTH 2.0 are the WBA recommended standard protocols for Federation SSO integration.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#1.04) for details on your responsibilities to meet this security control requirement.

## 1.05
**Java Web Tokens (JWT) should be used for authenticating API and/or micro-service calls.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

APIM Policy  can be used to enforce JWT by the App team

## 1.06
**Administrative accounts shall require stronger authentication levels in compliance with the GSCF administrative account requirements.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Administrative accounts are managed by Azure AD

## 1.07
**Root access or full administrative access requires that ALL of the following conditions be met:**
* **The requestor needs the access to perform assigned job duties.**
* **Approvals from applicable systems and data owners have been received.**
* **No other authorizations are available or can be customized to enable the required function.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

Administrative accounts are managed by Azure AD

## 1.08
**Roles or group permissions should be utilized when assigning permissions to individual users. The principle of "least privileged" MUST be followed when assigning users to these roles to ensure they only have the necessary permissions available to perform their job function.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#1.08) for details on your responsibilities to meet this security control requirement.

## 1.09
**All authorization SHALL employ a default-deny model, where access is denied unless explicitly permitted by the user's role/group membership.  A formal process SHALL be documented and followed for approving the addition of user to access groups.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#1.09) for details on your responsibilities to meet this security control requirement.

## 1.10
**Coarse grained access controls via group assignment should be able to be managed at the divisional central account management level.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

RBAC roles can be utilized to assign groups permissions instead of users.


# 2. Network Security

## 2.01
**Internet accessibility to the PaaS Must be removed/blocked unless public connectivity to/from the service is a business requirement (e.g. a WAF needs a public IP to do it's job).**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

APIM has a public IP address available but will only allow access to internal backend APIs based on App Team requirements

## 2.02
**The PaaS solution Must be configured to receive/send data using a Private IP (e.g. MS Private Link or customer VNET injection).**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

APIM will be required to be placed in private VNET for internal communications. Because of this, only Developer and Premium are among the allowed SKUs. 
All deployments to production subscriptions must use the Premium SKU.

## 2.03
**In situations where the service does not have a private link option available, VNET service endpoints must be used/configured to only permit traffic from approved WBA subnets and block all other traffic.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

APIM will utilize private VNET for Internal communications. 

App Teams requring public facing endpoints will need to place the endpoint behind WAF.

## 2.04
**When VNET service endpoints are used, VNET service endpoint policies must be used/configured to only permit traffic to the WBA instance of the service.**

> **Note: this feature is currently only available for Azure Storage.**

---

* **Control Strength:** `N/A`
* **Enforcement Mechanism:** `N/A`
* **Status:** `N/A`

Service Endpoints are not utilized with APIM

## 2.05
**Transport layer security (encryption) is required to secure all communications to the PaaS solution.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

TLS is enabled by default in APIM

## 2.06
**TLSv1.2 shall be used and configuration requirements as presented in the WBA Cryptography & Key Management Standard MUST be followed. As stipulated above, AKV Must be used to securely store certificates.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

TLSv1.2 is enabled by default in APIM. All other forms are disabled in template, and are disabled in Azure Policy

## 2.07
**For internal WBA systems, TLS 1.2 MUST be implemented using WBA signed PKI certificates.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#2.07) for details on your responsibilities to meet this security control requirement.

## 2.08
**For external PaaS or SaaS solutions commercially signed (e.g. VeriSign, Digi-Cert, etc.) certificates MUST be used to implement the TLS 1.2 connections.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Native`
* **Status:** `Implemented`

A commercially signed certificate is used for external communication.

## 2.09
**Self-signed certificates ARE NOT permitted for use.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

Pester test to fail if certificate common name matches issuer.

## 2.10
**PaaS solutions that are injectable into the customer VNET (e.g. Application Gateway, SQL Managed PaaS, etc.) must be segmented/zoned according to their data classification and placed in the appropriate subnet tier (i.e. web, app, database tier).**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#2.10) for details on your responsibilities to meet this security control requirement.


# 3. Data Security

## 3.01
**Data encryption at rest is required according to its data classification as specified in the GSCF, section 4.2.7. (e.g. Confidential Data must be encrypted at rest). Also, any encryption solution utilized must comply with the WBA Cryptography and Key Management Standard.**

---

* **Control Strength:** `N/A`
* **Enforcement Mechanism:** `N/A`
* **Status:** `N/A`

APIM does not store data natively. It can use a Redis Cache. See Azure Redis Cache Security Requirements for more details.
Redis must not be used to store sensitive or regulated information.

## 3.02
**Where applicable, Confidential data should be encrypted at the field level using the WBA Enterprise Encryption solution, Voltage.  All Payment Card Industry (PCI), Electronic Patient Health Information (ePHI), and Personally Identifiable Information (PII) data elements MUST be encrypted or tokenized prior to database ingestion.**

> **Note: If the persistent data store (e.g. database) is encrypted with TDE, only the below list of data elements will require field level encryption (FLE):**
> * **Names (first and last)**
> * **Addresses (not including state)**
> * **Phone Numbers (e.g. home, work, cell, etc.)**
> * **Email Addresses**
> * **Rx Numbers**
> * **Free form text fields**
> * **SSN's**
> * **Driver' License Numbers**
> * **Credit Card Numbers (Tokenization Required)**
>
> **If TDE is not used all PHI and PII data elements Must be encrypted with FLE.**

---

* **Control Strength:** `N/A`
* **Enforcement Mechanism:** `N/A`
* **Status:** `N/A`

See 3.01

## 3.03
**In cases where field level encryption is not viable, the solution MUST support native persistent data store encryption (e.g. Transparent Data Encryption (TDE)). TDE alone typically isn't sufficient and must be combined with RBACs to restrict unauthorized users/accounts from having access to confidential/personal data.**

---

* **Control Strength:** `N/A`
* **Enforcement Mechanism:** `N/A`
* **Status:** `N/A`

See 3.01

## 3.04
**The solution MUST NOT store unencrypted confidential data in index files, swap files, config files, audit logs, etc.**

---

* **Control Strength:** `N/A`
* **Enforcement Mechanism:** `N/A`
* **Status:** `N/A`

No files are saved with APIM.

## 3.05
**Native persistent store encryption solutions should allow for encryption keys to be controlled/managed by WBA. Key rotation must comply with requirements specified in the WBA cryptography and Key Management standard.**

---

* **Control Strength:** `N/A`
* **Enforcement Mechanism:** `N/A`
* **Status:** `N/A`

See 3.01

## 3.06
**Encryption keys Must be stored in a protected location (e.g. Azure Key Vault) and not collocated with the persistent data store.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

KeyVault is utilized to push secret information such as certificates and keys to APIM during deployment


# 4. Audit & Logging

## 4.01
**Audit logs (for all data classifications) SHOULD be imported into a centralized logging solution (e.g. Event Hubs, Splunk, ELK, etc.) to facilitate collection/review/auditing of required events with a standardized solution.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

All logs are sent to central LogAnalytics workspace

## 4.02
**In accordance with the WBA Security Event Logging Standard the solution MUST be configured to log these specific events:**
* **Authentication events**
* **Account creation/deletion** 
* **Privilege changes**
* **Input validation failures**
* **Output validation failures**
* **Session management failures**
* **System or process start-ups and shutdowns**
* **System changes, including device attachment/detachment and object creation/deletion**
* **Use of administrative privileges, including utilities**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

All logs are sent to central LogAnalytics workspace

## 4.03
**Event logs MUST include the following attributes:**
* **Log Timestamp in international format**
* **Event Timestamp in international format (To cope with events that cannot be logged immediately)**
* **Process identifier**
* **Source system identifier (Application, endpoint or network device generating the log)**
* **Source of the event (E.g. User, ip address, and/or device identifier)**
* **User identity**
* **Event type**
* **Event severity** 
* **Event Description** 
* **Outbound connections, including source and destination ports**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

All logs are sent to central LogAnalytics workspace

## 4.04
**Critical security events/alerts MUST be forwarded to the WBA SIEM solution for immediate escalation.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `TBD`
* **Status:** `Needs to be Implemented`

Waiting on descision to be made on how to address this


# 5. Service Specific Security

## 5.01
**Externally accesible APIs must be fronted by a WAF (e.g. Azure Front Door, App Gateway, or Incapsula) and an external APIM that is hosted in the external DMZ (see APIM Application Pattern).  This applies if the VNET setting is set to "Off" or "External".**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

The APIM is set to Internal, even for external facing APIs.  The public IP is tied to the Appgw with WAF, which points to exrternal APIM, which then points to internal APIM.

## 5.02
**If APIM is fronting an internal application for internal consumption, the virtual network setting Must be set to "Internal" (see APIM Application Pattern).**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

The internal APIM is set to Internal.

## 5.03
**Protocols - Triple DES (3DES) must be set to "Off".**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

This setting is set to Off

## 5.04
**Protocols - TLS 1.2 must be set to "On".**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

This setting is set to On

## 5.05
**Protocols - TLS 1.1 must be set to "Off".**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

This setting is set to Off

## 5.06
**Protocols - TLS 1.0 must be set to "Off".**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

This setting is set to Off

## 5.07
**Protocols - SSL 3.0 must be set to "Off".**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

This setting is set to Off

## 5.08
**Protocols - HTTP/2 must be set to "On".**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

This setting is set to On

## 5.09
**Managed Identities must be set to "On" if APIM is used to access Azure services (e.g. AKV, Storage, etc.) or is used to access other services compatible with Managed Identities.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

This setting is enabled by default in the template.

## 5.10
**Secrets or confidential data must not be included in any part of APIM configuration, including but not limited to credentials. If credentials are necessary, use Managed Identities where possible or Key Vault where Managed Identities cannot be used.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#5.10) for details on your responsibilities to meet this security control requirement.

## 5.11
**APIM must validate all JWT tokens presented to it.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#5.11) for details on your responsibilities to meet this security control requirement.

## 5.12
**Ensure logs are configured to be sent to log analytics.**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

See Audit and Logging Section

## 5.13
**APIM must not allow caching of data subject to regulatory compliance.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#5.13) for details on your responsibilities to meet this security control requirement.

## 5.14
**All client connections to APIM must utilise HTTPS.**

---

* **Control Strength:** `Hard`
* **Enforcement Mechanism:** `Azure Policy`
* **Status:** `Implemented`

Azure Policy used to enforce https protocol for APIs

## 5.15
**All APIs exposed through APIM must utilise CORS in a manner complying with least privilege (i.e. only necessary origin must be allowed).**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#5.15) for details on your responsibilities to meet this security control requirement.

## 5.16
**CORS must not use "Access-Control-Allow-Origin: \*".**

---

* **Control Strength:** `Medium`
* **Enforcement Mechanism:** `CCP Pipeline`
* **Status:** `Implemented`

APIM Policy must not have  "Access-Control-Allow-Origin: *" as part of it

## 5.17
**RESTFUL and/or SOAP based server to server API connections that transmit confidential data must use mutual TLS authentication at the transport layer to authenticate the client, in addition to the server, as is normally done in one-way TLS connections.**

---

* **Control Strength:** `Soft`
* **Enforcement Mechanism:** `App Team Responsibility`
* **Status:** `Needs to be Implemented`

Refer to the [User Responsibilities Document](./RESPONSIBILITIES.md#5.17) for details on your responsibilities to meet this security control requirement.


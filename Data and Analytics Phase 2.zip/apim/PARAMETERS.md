# WBA Azure API Management Standard Template Parameter Reference

For each deployment type there are two reference files. A template and its accompanying parameter file.

The template/parameter combination show a minimal configuration with options required to conform with WBA standards for a deployment.
See the Parameters & Common Parameters sections below for details.

Controls are put in place to restrict the use of settings that would break design or security principles

To perform a deployment of a template, refer to the [Pipeline Trigger](/PIPELINE_TRIGGER.md) documentation

> Templates are based off of the Microsoft API reference which you can review for more insight about the options available.
>* [API Management Template Reference](https://docs.microsoft.com/en-us/azure/templates/microsoft.apimanagement/2019-12-01/service)
>* [API Management Products Template Reference](https://docs.microsoft.com/en-us/azure/templates/microsoft.apimanagement/2019-12-01/service/products)
>* [API Management APIs Template Reference](https://docs.microsoft.com/en-us/azure/templates/microsoft.apimanagement/2019-12-01/service/apis)
>* [API Management Subscriptions Template Reference](https://docs.microsoft.com/en-us/azure/templates/microsoft.apimanagement/2019-12-01/service/subscriptions)
>* [API Management Named Values Template Reference](https://docs.microsoft.com/en-us/azure/templates/microsoft.apimanagement/2019-12-01/service/namedvalues)
>* [API Management Groups Template Reference](https://docs.microsoft.com/en-us/azure/templates/microsoft.apimanagement/2019-12-01/service/groups)
>* [API Management Users Template Reference](https://docs.microsoft.com/en-us/azure/templates/microsoft.apimanagement/2019-12-01/service/users)


## Common Parameters
---

There are a few parameters that are needed in every template that the pipeline uses to perform the deployments

### `parameters.location`
* Type: `string`
* Required: `true`
* Default Value: `NONE`

The location information is needed for the deployment that takes place ahead of the invocation of the template & parameter when
a resource group is created. the pipeline retrieves the target location from your parameter file.

### `parameters.tags`
* Type: `object`
* Required: `true`
* Default Value: `NONE`
* Example:
```js
{
    "Sensitivity": "Non-Sensitive",
    "SenType": "Not Applicable",
    "EnvType": "Non-Production",
    "LegalSubEntity": "Walgreen Co",
    "SubDivision": "Infrastructure",
    "Department": "Cloud Automation",
    "CostCenter" : "Cloud Engineering 5001"
}
```
WBA Requires the inclusion of a set of tags to identify key aspects of the resources such as billing and zoning classification.
This is required on the parent resource group that is generated as part of the deployment and is read from your parameter file

>Note: These tags are an example only!
Check the [enterprise-resource-tags](https://oneit.wba.com/versioncontrol/projects/CLOUDARCH/repos/enterprise-resource-tags/browse) project for the list of currently required tags, their data types, and acceptable values.


### `deploymentParameters.subscription`
* Type: `string`
* Required: `true`
* Default Value: `NONE`

The subscription that will be deployed is needed in a multi-subscription environment and is used ahead of the invocation of the template & parameter file.
To keep all of the deployment details required for particular resource in one place that can be tracked in a declarative way, the subscription name or id
is included in a secondary block outside of the parameters so it can be tracked in the file.

The subscription can be specified as either the name or id.

### `deploymentParameters.resourceGroup`
* Type: `string`
* Required: `true`
* Default Value: `NONE`

Resource groups are used as a means to separate resources into logical groupings based on a couple of different scenarios. The main considerations for
grouping resources into a group are:
* RBAC assignments (does a common group or person need access to all of these resources)
* Billing allocation (do all of these resources get billed to the same department)
* Lifecycle alignment (would i want to delete all of these resources at the same time)

> Follow the [resource group naming standard](https://dev.azure.com/WBA/IT%20Services/_git/ccp-ent-resource-names?path=%2Fresource-group.yml)
> when specifying the name of your resource group.

### `deploymentParameters.templateFile`
* Type: `string`
* Required: `true`
* Default Value: `NONE`

To allow for a many-to-one scenario of parameter files and templates, the name of the template file is specified in the parameter file so that
it can be selected and used for the deployment.

## Service Parameters
---

### `parameters.serviceName`
* type: `string`
* required: `true`
* defaultValue: `NONE`
* minLength: `1`
* maxLength: `50`

The name of the API Management service.



### `parameters.skuName`
* type: `string`
* required: `false`
* defaultValue: `Premium`
* allowedValues: `['Developer', 'Premium']`

Name of the Sku.



>Note: Premium SKU is required for deployments in production environments.


### `parameters.skuCapacity`
* type: `int`
* required: `false`
* defaultValue: `1`
* minValue: `1`
* maxValue: `10`

Capacity of the SKU (number of deployed units of the SKU). For Consumption SKU capacity must be specified as 0.



### `parameters.publisherEmail`
* type: `string`
* required: `true`
* defaultValue: `NONE`
* maxLength: `100`

Publisher email.



### `parameters.publisherName`
* type: `string`
* required: `true`
* defaultValue: `NONE`
* maxLength: `100`

Publisher name.



### `parameters.notificationSenderEmail`
* type: `string`
* required: `true`
* defaultValue: `NONE`
* maxLength: `100`

Email address from which the notification will be sent.



### `parameters.hostnameConfigurations`
* type: `array`
* required: `false`
* defaultValue: `[]`

Custom hostname configuration of the API Management service.


>#### hostnameConfigurations Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|type |string |no |Hostname type. |None |Proxy,Portal,Management,Scm,DeveloperPortal |
>|hostName |string |no |Hostname to configure on the Api Management service. |None | |
>|keyVaultId |string |no |Url to the KeyVault Secret containing the Ssl Certificate. If absolute Url containing version is provided, auto-update of ssl certificate will not work. This requires Api Management service to be configured with MSI. The secret should be of type *application/x-pkcs12* |None | |
>|encodedCertificate |string |no |Base64 Encoded certificate. |None | |
>|certificatePassword |string |no |Certificate Password. |None | |
>|defaultSslBinding |bool |no |Specify true to setup the certificate associated with this Hostname as the Default SSL Certificate. If a client does not send the SNI header, then this will be the certificate that will be challenged. The property is useful if a service has multiple custom hostname enabled and it needs to decide on the default ssl certificate. The setting only applied to Proxy Hostname Type. |None | |
>|negotiateClientCertificate |bool |no |Specify true to always negotiate client certificate on the hostname. Default Value is false. |None | |
>#### Example
>````js
>{
>    "type": string,
>    "hostName": string,
>    "keyVaultId": string,
>    "encodedCertificate": string,
>    "certificatePassword": string,
>    "defaultSslBinding": bool,
>    "negotiateClientCertificate": bool
>}
>````

### `parameters.additionalLocations`
* type: `array`
* required: `false`
* defaultValue: `[]`

Additional datacenter locations of the API Management service.


>#### additionalLocations Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|location |string |no |The location name of the additional region among Azure Data center regions. |None | |
>|virtualNetworkConfigurationSubnetResourceId |string |no |The full resource ID of a subnet in a virtual network to deploy the API Management service in. |None | |
>|disableGateway |bool |no |Property only valid for an Api Management service deployed in multiple locations. This can be used to disable the gateway in this additional location. |None | |
>#### Example
>````js
>{
>    "location": string,
>    "virtualNetworkConfigurationSubnetResourceId": string,
>    "disableGateway": bool
>}
>````

### `parameters.certificates`
* type: `array`
* required: `false`
* defaultValue: `[]`

List of Certificates that need to be installed in the API Management service. Max supported certificates that can be installed is 10.


>#### certificate Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|expiry |string |yes |Expiration date of the certificate. The date conforms to the following format: `yyyy-MM-ddTHH:mm:ssZ` as specified by the ISO 8601 standard. |None | |
>|thumbprint |string |yes |Thumbprint of the certificate. |None | |
>|subject |string |yes |Subject of the certificate. |None | |
>#### Example
>````js
>{
>    "expiry": string,
>    "thumbprint": string,
>    "subject": string
>}
>````
>#### certificates Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|encodedCertificate |string |no |Base64 Encoded certificate. |None | |
>|certificatePassword |string |no |Certificate Password. |None | |
>|storeName |string |yes |The System.Security.Cryptography.x509certificates.StoreName certificate store location. Only Root and CertificateAuthority are valid locations. |None |CertificateAuthority,Root |
>|certificate |object |no |SSL certificate information. |None | |
>#### Example
>````js
>{
>    "encodedCertificate": string,
>    "certificatePassword": string,
>    "storeName": string,
>    "certificate": object
>}
>````

### `parameters.enableClientCertificate`
* type: `bool`
* required: `false`
* defaultValue: `False`

Property only meant to be used for Consumption SKU Service. This enforces a client certificate to be presented on each request to the gateway. This also enables the ability to authenticate the certificate in the policy on the gateway.



### `parameters.disableGateway`
* type: `bool`
* required: `false`
* defaultValue: `False`

Property only valid for an Api Management service deployed in multiple locations. This can be used to disable the gateway in master region.



### `parameters.virtualNetworkConfigurationSubnetResourceId`
* type: `string`
* required: `true`
* defaultValue: `NONE`

The full resource ID of a subnet in a virtual network to deploy the API Management service in.



The following things should be considered when selecting your subnets
* The service and target subnet must be in the same region

>**NOTE**:
>As there is An Azure Policy that controls which subnets are allowed to be used, this subnet has to be whitelisted by submitting a PR to add it to the [<u>subnets.yml</u>](https://dev.azure.com/WBA/IT%20Services/_git/ccp-ent-policies?path=%2Flists%2Fsubnets.yml&version=GBmaster&_a=contents) the [<u>ccp-ent-policies</u>](https://dev.azure.com/WBA/IT%20Services/_git/ccp-ent-policies?version=GBmaster&_a=contents) repo. Make sure proper Environment Type classification (Production/Non-Production) is defined when doing so.
>
>**_Build Validations and Tests_**
>* whether the subnetId `id(s)` exists under the Virtual Network or not.
>* whether the subnetId `id(s)` is white-listed on the `ccp-ent-policies` repo.


### `parameters.apiVersionConstraintMinApiVersion`
* type: `string`
* required: `false`
* defaultValue: ``

Limit control plane API calls to API Management service with version equal to or newer than this value.



### `parameters.products`
* type: `array`
* required: `false`
* defaultValue: `[]`


>#### products Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|productName |string |yes |Product identifier. Must be unique in the current API Management service instance. |None | |
>|terms |string |no |Product terms of use. Developers trying to subscribe to the product will be presented and required to accept these terms before they can complete the subscription process. |None | |
>|description |string |no |Product description. May include HTML formatting tags. |None | |
>|approvalRequired |bool |no |whether subscription approval is required. If false, new subscriptions will be approved automatically enabling developers to call the product�s APIs immediately after subscribing. If true, administrators must manually approve the subscription before the developer can any of the product�s APIs. Can be present only if subscriptionRequired property is present and has a value of false. |None | |
>|subscriptionsLimit |int |no |Whether the number of subscriptions a user can have to this product at the same time. Set to null or omit to allow unlimited per user subscriptions. Can be present only if subscriptionRequired property is present and has a value of false. |None | |
>|state |string |no |whether product is published or not. Published products are discoverable by users of developer portal. Non published products are visible only to administrators. Default state of Product is notPublished. |None |notPublished,published |
>|subscriptionRequired |bool |no |Whether a product subscription is required for accessing APIs included in this product. If true, the product is referred to as "protected" and a valid subscription key is required for a request to an API included in the product to succeed. If false, the product is referred to as "open" and requests to an API included in the product can be made without a subscription key. If property is omitted when creating a new product it's value is assumed to be true. |None | |
>|displayName |string |yes |Product name. |None | |
>#### Example
>````js
>{
>    "productName": string,
>    "terms": string,
>    "description": string,
>    "approvalRequired": bool,
>    "subscriptionsLimit": int,
>    "state": string,
>    "subscriptionRequired": bool,
>    "displayName": string
>}
>````

### `parameters.apis`
* type: `array`
* required: `false`
* defaultValue: `[]`


>#### apiVersionSet Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|name |string |no |The display Name of the API Version Set. |None | |
>|versionQueryName |string |no |Name of query parameter that indicates the API Version if versioningScheme is set to `query`. |None | |
>|versionHeaderName |string |no |Name of HTTP header parameter that indicates the API Version if versioningScheme is set to `header`. |None | |
>|versioningScheme |string |no |An value that determines where the API Version identifer will be located in a HTTP request. |None |Segment,Query,Header |
>#### Example
>````js
>{
>    "name": string,
>    "versionQueryName": string,
>    "versionHeaderName": string,
>    "versioningScheme": string
>}
>````
>#### subscriptionKeyParameterNames Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|header |string |no |Subscription key header name. |None | |
>|query |string |no |Subscription key query string parameter name. |None | |
>#### Example
>````js
>{
>    "header": string,
>    "query": string
>}
>````
>#### authenticationSettingsOpenid Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|openidProviderId |string |no |OAuth authorization server identifier. |None | |
>|bearerTokenSendingMethods |array |no |How to send token to the server. |None | |
>#### Example
>````js
>{
>    "openidProviderId": string,
>    "bearerTokenSendingMethods": array
>}
>````
>#### authenticationSettingsOAuth2 Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|scope |string |no |operations scope. |None | |
>|authorizationServerId |string |no |OAuth authorization server identifier. |None | |
>#### Example
>````js
>{
>    "scope": string,
>    "authorizationServerId": string
>}
>````
>#### apis Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|apiName |string |yes |API revision identifier. Must be unique in the current API Management service instance. Non-current revision has ;rev=n as a suffix where n is the revision number. |None | |
>|sourceApiId |string |no |API identifier of the source API. |None | |
>|displayName |string |no |API name. Must be 1 to 300 characters long. |None | |
>|description |string |no |Description of the API. May include HTML formatting tags. |None | |
>|format |string |no |Format of the Content in which the API is getting imported. |None |wadl-xml,wadl-link-json,swagger-json,swagger-link-json,wsdl,wsdl-link,openapi,openapi+json,openapi-link,openapi+json-link |
>|apiVersionSetId |string |no |Identifier for existing API Version Set. Omit this value to create a new Version Set. |None | |
>|apiRevision |string |no |Describes the Revision of the Api. If no value is provided, default revision 1 is created |None | |
>|value |string |no |Content value when Importing an API. |None | |
>|apiType |string |no |Type of Api to create. 
 * `http` creates a SOAP to REST API 
 * `soap` creates a SOAP pass-through API . |http |http,soap |
>|apiVersionSetDescription |string |no |Description of API Version Set. |None | |
>|apiVersionSet |object |no | |OrderedDict() | |
>|subscriptionKeyParameterNames |object |no | |OrderedDict() | |
>|serviceUrl |string |no |Absolute URL of the backend service implementing this API. Cannot be more than 2000 characters long. |None | |
>|apiVersion |string |no |Indicates the Version identifier of the API if the API is versioned |None | |
>|isCurrent |bool |no |Indicates if API revision is current api revision. |None | |
>|apiVersionDescription |string |no |Description of the Api Version. |None | |
>|subscriptionRequired |bool |no |Specifies whether an API or Product subscription is required for accessing the API. |None | |
>|wsdlSelectorWsdlServiceName |string |no |Name of service to import from WSDL |None | |
>|wsdlSelectorWsdlEndpointName |string |no |Name of endpoint(port) to import from WSDL |None | |
>|path |string |yes |Relative URL uniquely identifying this API and all of its resource paths within the API Management service instance. It is appended to the API endpoint base URL specified during the service instance creation to form a public URL for this API. |None | |
>|type |string |no |Type of API. |None |http,soap |
>|apiRevisionDescription |string |no |Description of the Api Revision. |None | |
>|protocols |array |no |Describes on which protocols the operations in this API can be invoked. |['https'] |https |
>|authenticationSettingsOpenid |object |no | |OrderedDict() | |
>|authenticationSettingsOAuth2 |object |no | |OrderedDict() | |
>|policy |string |no |Contents of the Policy as defined by the format. |None | |
>|policyFormat |string |no |Format of the policyContent. |None |xml,xml-link,rawxml,rawxml-link |
>#### Example
>````js
>{
>    "apiName": string,
>    "sourceApiId": string,
>    "displayName": string,
>    "description": string,
>    "format": string,
>    "apiVersionSetId": string,
>    "apiRevision": string,
>    "value": string,
>    "apiType": string,
>    "apiVersionSetDescription": string,
>    "apiVersionSet": object,
>    "subscriptionKeyParameterNames": object,
>    "serviceUrl": string,
>    "apiVersion": string,
>    "isCurrent": bool,
>    "apiVersionDescription": string,
>    "subscriptionRequired": bool,
>    "wsdlSelectorWsdlServiceName": string,
>    "wsdlSelectorWsdlEndpointName": string,
>    "path": string,
>    "type": string,
>    "apiRevisionDescription": string,
>    "protocols": array,
>    "authenticationSettingsOpenid": object,
>    "authenticationSettingsOAuth2": object,
>    "policy": string,
>    "policyFormat": string
>}
>````

### `parameters.subscriptions`
* type: `array`
* required: `false`
* defaultValue: `[]`


>#### subscriptions Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|subscriptionName |string |yes |Subscription entity Identifier. The entity represents the association between a user and a product in API Management. |None | |
>|displayName |string |yes |Subscription name. |None | |
>|secondaryKey |string |no |Secondary subscription key. If not specified during request key will be generated automatically. |None | |
>|state |string |no |Initial subscription state. If no value is specified, subscription is created with Submitted state. Possible states are * active � the subscription is active, * suspended � the subscription is blocked, and the subscriber cannot call any APIs of the product, * submitted � the subscription request has been made by the developer, but has not yet been approved or rejected, * rejected � the subscription request has been denied by an administrator, * cancelled � the subscription has been cancelled by the developer or administrator, * expired � the subscription reached its expiration date and was deactivated. |None |suspended,active,expired,submitted,rejected,cancelled |
>|allowTracing |bool |no |Determines whether tracing can be enabled |None | |
>|scope |string |yes |Scope like /products/{productId} or /apis or /apis/{apiId}. |None | |
>|ownerId |string |no |User (user id path) for whom subscription is being created in form /users/{userId} |None | |
>|primaryKey |string |no |Primary subscription key. If not specified during request key will be generated automatically. |None | |
>#### Example
>````js
>{
>    "subscriptionName": string,
>    "displayName": string,
>    "secondaryKey": string,
>    "state": string,
>    "allowTracing": bool,
>    "scope": string,
>    "ownerId": string,
>    "primaryKey": string
>}
>````

### `parameters.namedValues`
* type: `array`
* required: `false`
* defaultValue: `[]`


>#### namedValues Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|namedValueName |string |yes |Identifier of the NamedValue. |None | |
>|secret |bool |no |Determines whether the value is a secret and should be encrypted or not. Default value is false. |False | |
>|displayName |string |yes |Unique name of NamedValue. It may contain only letters, digits, period, dash, and underscore characters. |None | |
>|value |string |yes |Value of the NamedValue. Can contain policy expressions. It may not be empty or consist only of whitespace. This property will not be filled on 'GET' operations! Use '/listSecrets' POST request to get the value. |None | |
>|tags |array |no |Optional tags that when provided can be used to filter the NamedValue list. |None | |
>#### Example
>````js
>{
>    "namedValueName": string,
>    "secret": bool,
>    "displayName": string,
>    "value": string,
>    "tags": array
>}
>````

### `parameters.users`
* type: `array`
* required: `false`
* defaultValue: `[]`


>#### users Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|userName |string |yes |User identifier. Must be unique in the current API Management service instance. |None | |
>|confirmation |string |no |Determines the type of confirmation e-mail that will be sent to the newly created user. |None |signup,invite |
>|firstName |string |yes |First name. |None | |
>|appType |string |no |Determines the type of application which send the create user request. Default is old publisher portal. |None |developerPortal |
>|lastName |string |yes |Last name. |None | |
>|note |string |no |Optional note about a user set by the administrator. |None | |
>|state |string |no |Account state. Specifies whether the user is active or not. Blocked users are unable to sign into the developer portal or call any APIs of subscribed products. Default state is Active. |None |active,blocked,pending,deleted |
>|password |string |no |User Password. If no value is provided, a default password is generated. |None | |
>|identitiesId |string |no |Identifier value within provider. |Azure | |
>|identitiesProvider |string |no |Identity provider name. |None | |
>|email |string |yes |Email address. Must not be empty and must be unique within the service instance. |None | |
>#### Example
>````js
>{
>    "userName": string,
>    "confirmation": string,
>    "firstName": string,
>    "appType": string,
>    "lastName": string,
>    "note": string,
>    "state": string,
>    "password": string,
>    "identitiesId": string,
>    "identitiesProvider": string,
>    "email": string
>}
>````

### `parameters.groups`
* type: `array`
* required: `false`
* defaultValue: `[]`


>#### groups Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|groupName |string |yes |Group identifier. Must be unique in the current API Management service instance. |None | |
>|type |string |no |Group type. |None |custom,system,external |
>|externalId |string |no |Identifier of the external groups, this property contains the id of the group from the external identity provider, e.g. for Azure Active Directory `aad://<tenant>.onmicrosoft.com/groups/<group object id>`; otherwise the value is null. |None | |
>|displayName |string |yes |Group name. |None | |
>|description |string |no |Group description. |None | |
>#### Example
>````js
>{
>    "groupName": string,
>    "type": string,
>    "externalId": string,
>    "displayName": string,
>    "description": string
>}
>````

### `parameters.authorizationServers`
* type: `array`
* required: `false`
* defaultValue: `[]`


>#### tokenBodyParameters Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|authorizationServerName |string |yes |body parameter name. |None | |
>|value |string |yes |body parameter value. |None | |
>#### Example
>````js
>{
>    "authorizationServerName": string,
>    "value": string
>}
>````
>#### authorizationServers Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|authorizationServerName |string |yes |Identifier of the authorization server. |None | |
>|tokenBodyParameters |array |no |Additional parameters required by the token endpoint of this authorization server represented as an array of JSON objects with name and value string properties, i.e. {"name" : "name value", "value": "a value"}. |None | |
>|clientSecret |string |no |Client or app secret registered with this authorization server. This property will not be filled on 'GET' operations! Use '/listSecrets' POST request to get the value. |None | |
>|displayName |string |yes |User-friendly authorization server name. |None | |
>|description |string |no |Description of the authorization server. Can contain HTML formatting tags. |None | |
>|tokenEndpoint |string |no |OAuth token endpoint. Contains absolute URI to entity being referenced. |None | |
>|clientAuthenticationMethod |array |no |Method of authentication supported by the token endpoint of this authorization server. Possible values are Basic and/or Body. When Body is specified, client credentials and other parameters are passed within the request body in the application/x-www-form-urlencoded format. |None | |
>|clientId |string |yes |Client or app id registered with this authorization server. |None | |
>|grantTypes |array |yes |Form of an authorization grant, which the client uses to request the access token. |None | |
>|resourceOwnerPassword |string |no |Can be optionally specified when resource owner password grant type is supported by this authorization server. Default resource owner password. |None | |
>|supportState |bool |no |If true, authorization server will include state parameter from the authorization request to its response. Client may use state parameter to raise protocol security. |None | |
>|authorizationEndpoint |string |yes |OAuth authorization endpoint. See http://tools.ietf.org/html/rfc6749#section-3.2. |None | |
>|bearerTokenSendingMethods |array |no |Specifies the mechanism by which access token is passed to the API.  |None | |
>|resourceOwnerUsername |string |no |Can be optionally specified when resource owner password grant type is supported by this authorization server. Default resource owner username. |None | |
>|authorizationMethods |array |no |HTTP verbs supported by the authorization endpoint. GET must be always present. POST is optional. |None | |
>|defaultScope |string |no |Access token scope that is going to be requested by default. Can be overridden at the API level. Should be provided in the form of a string containing space-delimited values. |None | |
>|clientRegistrationEndpoint |string |yes |Optional reference to a page where client or app registration for this authorization server is performed. Contains absolute URL to entity being referenced. |None | |
>#### Example
>````js
>{
>    "authorizationServerName": string,
>    "tokenBodyParameters": array,
>    "clientSecret": string,
>    "displayName": string,
>    "description": string,
>    "tokenEndpoint": string,
>    "clientAuthenticationMethod": array,
>    "clientId": string,
>    "grantTypes": array,
>    "resourceOwnerPassword": string,
>    "supportState": bool,
>    "authorizationEndpoint": string,
>    "bearerTokenSendingMethods": array,
>    "resourceOwnerUsername": string,
>    "authorizationMethods": array,
>    "defaultScope": string,
>    "clientRegistrationEndpoint": string
>}
>````

### `parameters.openidConnectProviders`
* type: `array`
* required: `false`
* defaultValue: `[]`


>#### openidConnectProviders Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|openidConnectProviderName |string |yes |Identifier of the OpenID Connect Provider. |None | |
>|metadataEndpoint |string |yes |Metadata endpoint URI. |None | |
>|displayName |string |yes |User-friendly OpenID Connect Provider name. |None | |
>|description |string |no |User-friendly description of OpenID Connect Provider. |None | |
>|clientId |string |yes |Client ID of developer console which is the client application. |None | |
>|clientSecret |string |no |Client Secret of developer console which is the client application. |None | |
>#### Example
>````js
>{
>    "openidConnectProviderName": string,
>    "metadataEndpoint": string,
>    "displayName": string,
>    "description": string,
>    "clientId": string,
>    "clientSecret": string
>}
>````

### `parameters.identityProviders`
* type: `array`
* required: `false`
* defaultValue: `[]`


>#### identityProviders Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|identityProviderName |string |yes |Identity Provider Type identifier. |None |aad |
>|clientSecret |string |yes |Client secret of the Application in external Identity Provider, used to authenticate login request. For example, it is App Secret for Facebook login, API Key for Google login, Public Key for Microsoft. This property will not be filled on 'GET' operations! Use '/listSecrets' POST request to get the value. |None | |
>|signinTenant |string |no |The TenantId to use instead of Common when logging into Active Directory |None | |
>|allowedTenants |array |no |List of Allowed Tenants when configuring Azure Active Directory login. |None | |
>|passwordResetPolicyName |string |no |Password Reset Policy Name. Only applies to AAD B2C Identity Provider. |None | |
>|authority |string |no |OpenID Connect discovery endpoint hostname for AAD or AAD B2C. |None | |
>|clientId |string |yes |Client Id of the Application in the external Identity Provider. It is App ID for Facebook login, Client ID for Google login, App ID for Microsoft. |None | |
>|profileEditingPolicyName |string |no |Profile Editing Policy Name. Only applies to AAD B2C Identity Provider. |None | |
>|signupPolicyName |string |no |Signup Policy Name. Only applies to AAD B2C Identity Provider. |None | |
>|type |string |no |Identity Provider Type identifier. |None |aad |
>|signinPolicyName |string |no |Signin Policy Name. Only applies to AAD B2C Identity Provider. |None | |
>#### Example
>````js
>{
>    "identityProviderName": string,
>    "clientSecret": string,
>    "signinTenant": string,
>    "allowedTenants": array,
>    "passwordResetPolicyName": string,
>    "authority": string,
>    "clientId": string,
>    "profileEditingPolicyName": string,
>    "signupPolicyName": string,
>    "type": string,
>    "signinPolicyName": string
>}
>````

### `parameters.roleAssignments`
* type: `array`
* required: `false`
* defaultValue: `[]`

A list of role assignments mapped to identities


>#### roleAssignments Object
>|Name |Type |Required |Description |Default |Allowed |
>|--|--|--|--|--|--|
>|roleDefinitionName |string |yes |Name of the RBAC role that needs to be assigned to the principal i.e. Reader, Contributor, Virtual Network Administrator, etc. |None |API Management Service Contributor,API Management Service Operator Role,API Management Service Reader Role,WBA - LEAP - Resource Deletion,Reader |
>|principalName |string |no |Azure AD name or email address of the user, group or service principal. |None | |
>|principalId |string |no |Azure AD Object ID of the user, group or service principal. |None | |
>#### Example
>````js
>{
>    "roleDefinitionName": string,
>    "principalName": string,
>    "principalId": string
>}
>````

Available Roles:
* **API Management Service Contributor:** Can manage service and the APIs. Please see [here](https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles#api-management-service-contributor) for more information.
* **API Management Service Operator Role:** Can manage service but not the APIs. Please see [here](https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles#api-management-service-operator-role) for more information.
* **API Management Service Reader Role:** Read-only access to service and APIs. Please see [here](https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles#api-management-service-reader-role) for more information.
* **WBA - LEAP - Resource Deletion:** Allows access to delete the resource.
* **Reader:** Lets you view everything, but not make any changes. Please see [here](https://docs.microsoft.com/en-us/azure/role-based-access-control/built-in-roles#reader) for more information.   

### `parameters.keyVaultName`
* type: `string`
* required: `false`
* defaultValue: ``

Name of KeyVault to access hostname certificates.



### `parameters.keyVaultResourceGroup`
* type: `string`
* required: `false`
* defaultValue: ``

Resource Group name of KeyVault to access hostname certificates.



### `parameters.keyVaultSubscriptionId`
* type: `string`
* required: `false`
* defaultValue: ``

Subscription ID of KeyVault to access hostname certificates.




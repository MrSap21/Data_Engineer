# WBA Azure API Management Standard Template User Responsibilities

Not all security controls have automatic enforcement mechanisms available. For those that do not, it is the responsibility of the team deploying and
leveraging the service instance to account for the security control.

This document will detail the security control, and the expectation on the deployer/user to use the service properly.

Please review and understand what additional steps you must take or processes you must follow to use this resource type in a compliant way.

> If you would like to maintain a record of how you have complied with these manual controls you can take a copy of this file
> and add details about how you are accounting for them as responses to each similar to how the controls are detailed in the [SECURITY.md](./SECURITY.md)
> document.

# 1. Authentication & Authorization

## 1.04
**Open standards such as OpenID Connect and OAUTH 2.0 are the WBA recommended standard protocols for Federation SSO integration.**
---
OpenID Connect, OAuth 2.0 are supported and are up to the App team to configure

## 1.08
**Roles or group permissions should be utilized when assigning permissions to individual users. The principle of "least privileged" MUST be followed when assigning users to these roles to ensure they only have the necessary permissions available to perform their job function.**
---
Roles and Group permissions can be assigned via RBAC roles during deployment.

## 1.09
**All authorization SHALL employ a default-deny model, where access is denied unless explicitly permitted by the user's role/group membership.  A formal process SHALL be documented and followed for approving the addition of user to access groups.**
---
Default behavior is to deny when a user/group does not have permission. App team will be responsible for delegating these permissions.

# 2. Network Security

## 2.07
**For internal WBA systems, TLS 1.2 MUST be implemented using WBA signed PKI certificates.**
---
Internal certificates can configured to be used for internal communication. 

Pester test set up to validate minimum requirements

## 2.10
**PaaS solutions that are injectable into the customer VNET (e.g. Application Gateway, SQL Managed PaaS, etc.) must be segmented/zoned according to their data classification and placed in the appropriate subnet tier (i.e. web, app, database tier).**
---
Architectural design needs to account for data classification when placing APIM into application VNETs.

# 3. Data Security

# 4. Audit & Logging

# 5. Service Specific Security

## 5.10
**Secrets or confidential data must not be included in any part of APIM configuration, including but not limited to credentials. If credentials are necessary, use Managed Identities where possible or Key Vault where Managed Identities cannot be used.**
---
AKV is used to pass AAD credentials

## 5.11
**APIM must validate all JWT tokens presented to it.**
---
APIM Policy can be used to enforce JWT use

## 5.13
**APIM must not allow caching of data subject to regulatory compliance.**
---
App teams responsibility to follow guidelines around use of caching and APIM

## 5.15
**All APIs exposed through APIM must utilise CORS in a manner complying with least privilege (i.e. only necessary origin must be allowed).**
---
Must be followed by App Team

## 5.17
**RESTFUL and/or SOAP based server to server API connections that transmit confidential data must use mutual TLS authentication at the transport layer to authenticate the client, in addition to the server, as is normally done in one-way TLS connections.**
---
App Gateway with WAF currently does not support mutual TLS.  Will need to implement it as soon as this functionality gets added to the App Gateway.

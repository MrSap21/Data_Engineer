# WBA Logic Apps standard template implementation

![status](https://img.shields.io/badge/Status-Approved%20(2020--04--15)-success)

Azure LogicApps is a cloud service that helps you schedule, automate, and orchestrate tasks, business processes, and workflows when you need to integrate apps, data, systems, and services across enterprises or organizations. Logic Apps simplifies how you design and build scalable solutions for app integration, data integration, system integration, enterprise application integration (EAI), and business-to-business (B2B) communication, whether in the cloud, on premises, or both.​ For more information on Logic Apps, please [reference](https://docs.microsoft.com/en-gb/azure/logic-apps/logic-apps-overview).

To build enterprise integration solutions with Azure Logic Apps, you can choose from a growing gallery with hundreds of ready-to-use connectors, which include services such as Azure Service Bus, Azure Functions, Azure Storage, SQL Server, Office 365, Dynamics, Salesforce, BizTalk, SAP, Oracle DB, file shares, and more. Connectors provide triggers, actions, or both for creating logic apps that securely access and process data in real time.​


## WBA opportunity statement for the service 

Logic Apps provide a low barrier to entry for repeatable tasks in WBA, either scheduled or triggered, that interact with other Azure resources.​

​Their ease of configuration, abstraction of compute allocation and automatic scale-out capabilities make them an ideal choice for re-tooling IT workflows to a cloud-native model.​

Validated connection types:​

* Azure SQL DB Single Instance​
* Logic Apps (inter-instance trigger)​
* Service Bus​
* Azure Data Factory​
* Azure CosmosDB

Validated trigger types:​

* HTTPS​
* Scheduled​
* Azure CosmosDB

### Use case 1: Scheduler

 RxI needs a scheduler to coordinate a set of distributed jobs build on top of different azure technologies like Azure Data Factory and microservices running inside AKS. The solution to address this need is based on Scheduler Agent Supervisor pattern and works as follows:​

* The scheduler service determines the next executions and the type of agent required​
* The scheduler invokes the specified agent passing it the details of the job​
* The agent holding the logic to call a remote service, trigger the job by sending an event to a message broker or triggering an Azure Data Factory Pipeline​
* The agent handles any failure​
* The Supervisor monitors periodically the status of the pending jobs and handles any failure ​

Azure Technologies Involved:​
* Azure SQL for the schedules metadata and execution status​
* Logic Apps for the Schedules, Agent and Supervisor​
* Service Bus for the message Broker​
* Data Factory for the Databricks job coordination​

Logic Apps Connectors:​

* Azure SQL​
* Logic Apps​
* Service Bus​
* Data Factory​

## Architectural Pattern

![Diagram 1](./diagrams/diagram1.png)

### Use case 2: Reactive Transactional Outbox Relay

Usually any micro-service business logic updates the state of the resources in the database and send messages, it is expected that both operations are atomic to avoid inconsistencies but unfortunately there is no viable mechanism to use a distributed transaction across cosmos DB and service bus. In order to reliably update the database and publish messages where 2PC is not available we can use the Transactional Outbox pattern that works as follows:​

Microservice inserts messages into an outbox table​

A separate relay process the outbox table periodically and publishes the message to a message broker​

Azure Technologies Involved:​ 
* Cosmos DB or Azure SQL for the outbox collection​
* Logic Apps for the Outbox Rela​
* Service Bus for the message Broker​

Logic Apps Connectors:​

* Azure SQL​
* Cosmos DB​
* Service Bus​

Sensitive data:​
Exist but can be mitigated with the usage of Claim Check Pattern to store the payload apart in Blob Storage.​

## Architectural Pattern

![Diagram 2](./diagrams/diagram2.png)

## Required Prerequisites

Here the minimal prerequisites to check in order to deploy a LogicApp.

* **logicAppWorkflowDefinition** : A working and tested LogicApp workflow definition .json. You can build it using the Logic Apps Designer, which is available in the [Azure Portal](https://portal.azure.com) through your browser and in Visual Studio.

* **logicAppWorkflowDefinitionParams** : This can include the set of already deployed Logic Apps [<u>Managed Connectors</u>](https://docs.microsoft.com/en-us/azure/connectors/apis-list#managed-api-connectors) references used by the LogicApp.

* **LogicApps Name**: Logc Apps name that meets wba standards. For more information, see [<u>parameters.connectorName</u>](###parameters.connectorName).


### Target Subscription
All resources are deployed into an Azure subscription which must exist ahead of the deployment. In most cases a subscription will already exist and it is
just a matter fo knowing its name or ID. If you already have a subscription you can retrieve its name in one of several ways.

* From the [Azure Portal](https://portal.azure.com) view the subscription overview blade and copy either the `Subscription name` or `Subscription ID`  from there.
* From Powershell> _(once authenticated)_ run the `Get-AzSubscription` Cmdlet which will show all subscriptions you have access to. Select the entry you want from there
* From the az cli> _(once authenticated)_ run the `az account list` command which will show all subscriptions you have access to. Select the entry you want from there

> If you are new to Azure within WBA and need to learn about onboarding and selection of a target subscription please send an email to the 
> [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com) and we will help to engage the appropriate people to get your group onboarded
> so you can start leveraging the pipeline for deployments.

> If you need a new subscription created _(rare)_ please send an email to the [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com) and we will help you engage
> the appropriate people to validate and fulfill your request.

### Resource Group Name
All resources are deployed into a resource group _(which is in a subscription)_. If the resource group name given does not exist in the target subscription
it will be created as part of the deployment. If it does exist the resource(s) will be added to it.

There is a naming standard defined for resource groups that should be followed. See the 
[Resource Group Naming Standard](https://dev.azure.com/WBA/IT%20Services/_git/ccp-ent-resource-names?path=%2Fresource-group.yml) to help you select 
an appropriate name for your resource group

How you lay out resource groups is left up to you in most cases, but there are a couple of considerations to keep in mind about how they are used.
The tags you provide for the resource deployment will be applied to the resource group and all resources within the group will get the same tags.
This means you cannot mix resources that would have different tags, which are used for billing and sensitivity details.

### Tag Values
Tags are used at WBA to assign costs and specify data sensitivity. Before you begin, you will need to know your 4 billing tags for your department or project
and to know what your sensitivity classification is so you can provide the appropriate values as part of the parameters.

> If you are new to Azure within WBA and need to learn about onboarding and assignment of billing tags please send an email to the
> [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com) and we will help to engage the appropriate people to get your group onboarded
> so you can start leveraging the pipeline for deployments.


[Include any prerequisites specific to the service type here in a similar format to the common ones]



## Security Guidelines

This service deployment and the resulting resource conforms with WBA security standards detailing how and where it is deployed as well
as how it can be used. For information about the security requirements and the controls in place to meet them please see 
the [Security Requirements](./SECURITY.md) document



## User Responsibilities

Not all security requirements can be met automatically. The [User Responsibilities](./RESPONSIBILITIES.md) document includes
all of the security aspects related to the usage of the deployed resource. Please review and understand what additional steps
you must take or processes you must follow to use this resource type in a compliant way.

> If you would like to maintain a record of how you have complied with these manual controls you can take a copy of this file
> and add details about how you are accounting for them as responses to each.



## Getting Started

1. Ensure you have set up your environment for submitting build requests detailed in the [PIPELINE_TRIGGER](../../PIPELINE_TRIGGER.md) guide
2. Make a copy of the [reference parameter file](./logic-apps-parameters-min.json) and rename it to something meaningful for your deployment
3. Follow the steps under the [Prerequisites Section](#required-prerequisites) to request a service account


## Parameters

Resource definitions are stored as parameter files you submit to complete the build. There are two parameter files to use as starting points
for your own resources. One with the minimum required parameters, and one with all of the parameters.

You can use these parameter files as static files you fill in and submit, or build more complex deployment chains where you generate the files
with the appropriate values to build whole environments from the individual pieces, retrieving information from one to supply the information to
the next.

In addition to the two parameter file examples you can use, the full parameter reference is available that details all of the options
and information about them, when, how, and why they are used.

* [Parameters Reference](./PARAMETERS.md)
* [Minimal Parameters](./logic-apps-parameters-min.json)
* [Full Parameters](./logic-apps-parameters-full.json)



## Whats Next?

If the LogicApps is connected with other Azure PaaS Services some addititional steps could be needed in order to assign the correct access role on the target Azure PaaS Service to the LogicApp just deployed using its assigned managed system identity.


# Getting Help

Contact us if help is needed with Azure LogicApp deployment.

[Alessandro Pio Ardizio](mailto:alessandro.ardizio.@alliance-healthcare.net)
[Carmine Perrone](mailto:carmine.perrone@alliance-healthcare.net)
[Ciro Veneruso](mailto:ciro.veneruso@alliance-healthcare.net)
[Gianluigi Crispino](mailto:gianluigi.crispino@alliance-healthcare.net)
[Luca Sommella](mailto:luca.sommella@alliance-healthcare.net)
[Mariano Severino](mailto:mariano.severino@alliance-healthcare.net)

Please provide all relevant informations like the paramter file and the azure pipeline log.


### Deployment Time

* Failures during resource deployments
* Assistance with parameter values
* Requests for option support

Contact the [Common Cloud Platform](mailto:CommonCloudPlatform@walgreens.com)

### 

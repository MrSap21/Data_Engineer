# WBA Logic Apps Standard Template Parameter Reference

For each deployment type there are two reference files. A template and its accompanying parameter file.

The template/parameter combination show a minimal configuration with options required to conform with WBA standards for a deployment.
See the Parameters & Common Parameters sections below for details.

Controls are put in place to restrict the use of settings that would break design or security principles

To perform a deployment of a template, refer to the [Pipeline Trigger](/PIPELINE_TRIGGER.md) documentation

> This templates are based off of the [Microsoft API reference for the service ](https://docs.microsoft.com/en-us/azure/templates/microsoft.keyvault/2018-02-14/vaults)
> which you can review for more insight about the options available.

## Common Parameters

There are a few parameters that are needed in every template that the pipeline uses to perform the deployments

### `parameters.location`
* Type: `string`
* Required: `true`
* Default Value: NONE

The location information is needed for the deployment that takes place ahead of the invocation of the template & parameter when
a resource group is created. the pipeline retrieves the target location from your parameter file.

### `parameters.tags`
* Type: `object`
* Required: `true`
* Default Value: NONE
* Example:
```js
{
    "Sensitivity": "Non-Sensitive",
    "SenType": "Not Applicable",
    "EnvType": "Non-Production",
    "LegalSubEntity": "Walgreen Co",
    "SubDivision": "Infrastructure",
    "Department": "Cloud Automation",
    "CostCenter" : "Cloud Engineering 5001"
}
```

WBA Requires the inclusion of a set of tags to identify key aspects of the resources such as billing and zoning classification.
This is required on the parent resource group that is generated as part of the deployment and is read from your parameter file

Check the [enterprise-resource-tags](https://oneit.wba.com/versioncontrol/projects/CLOUDARCH/repos/enterprise-resource-tags/browse) project for the list of currently required tags, their data types, and acceptable values.


### `deploymentParameters.subscription`
* Type: `string`
* Required: `true`
* Default Value: NONE

The subscription that will be deployed is needed in a multi-subscription environment and is used ahead of the invocation of the template & parameter file.
To keep all of the deployment details required for particular resource in one place that can be tracked in a declarative way, the subscription name or id
is included in a secondary block outside of the parameters so it can be tracked in the file.

The subscription can be specified as either the name or id.

### `deploymentParameters.resourceGroup`
* Type: `string`
* Required: `true`
* Default Value: NONE

Resource groups are used as a means to separate resources into logical groupings based on a couple of different scenarios. The main considerations for
grouping resources into a group are:
* RBAC assignments (does a common group or person need access to all of these resources)
* Billing allocation (do all of these resources get billed to the same department)
* Lifecycle alignment (would i want to delete all of these resources at the same time)

> Follow the [resource group naming standard](https://dev.azure.com/WBA/IT%20Services/_git/ccp-ent-resource-names?path=%2Fresource-group.yml)
> when specifying the name of your resource group.

### `deploymentParameters.templateFile`
* Type: `string`
* Required: `true`
* Default Value: NONE

To allow for a many-to-one scenario of parameter files and templates, the name of the template file is specified in the parameter file so that
it can be selected and used for the deployment.


## Azure LogicApps Parameters

#### `parameters.logicAppName`
* Type: `string`
* Required: `true`
* Default Value: NONE

The globally unique name of the Logic App resource to create.

#### `parameters.allowedOutgoingIpAddresses`
* Type: `string`
* Required: `true`
* Default Value: NONE

The range or list of access control for allowed CallerIpAddresses


#### `parameters.allowedCallerIpAddresses`
* Type: `string`
* Required: `true`
* Default Value: NONE
The range or list of access control for Outgoing allowed CallerIpAddresses

 ### `parameters.logicAppWorkflowDefinition`
* Type": `object`
* Required: `true`
* Default Value: 
```json 
{
    "value": {
			"definition": ""
		}
}
``` 
The LogicApp workflow definition object.

### `logicAppWorkflowDefinitionParam`
* Type": `object`
* Required: `true`
* Default Value: 
```json 
{
    "value": ""
}

``` 

### `deploymentParameters.appId`
* Type: `string`
* Required: `no`
* Default Value: NONE


The Azure AD Objectid of the user or service principal to which will be assigned the *Logic Apps contributor* role during Logic App deployment. Logic App Contributor role allows the users or service to manage and configure the Logic App but not to change its access permissions.

### `deploymentParameters.DLId`
* Type: `string`
* Required: `no`
* Default Value: NONE

The Azure AD Objectid of the Gruop to which will be assigned the *Logic Apps contributor* role during Logic App deployment. Logic App Contributor role allows the users or service to manage and configure the Logic App but not to change its access permissions.
# WBA Logic Apps Standard Template User Responsibilities

Not all security controls have automatic enforcement mechanisms available. For those that do not, it is the responsibility of the team deploying and
leveraging the service instance to account for the security control.

This document will detail the security control, and the expectation on the deployer/user to use the service properly.

Please review and understand what additional steps you must take or processes you must follow to use this resource type in a compliant way.

> If you would like to maintain a record of how you have complied with these manual controls you can take a copy of this file
> and add details about how you are accounting for them as responses to each similar to how the controls are detailed in the [SECURITY.md](./SECURITY.md)
> document.

# 3. Data Security
## 3.02

**Where applicable, Confidential data should be encrypted at the field level using the WBA Enterprise Encryption solution, Voltage.  All Payment Card Industry (PCI), Electronic Patient Health Information (ePHI), and Personally Identifiable Information (PII) data elements MUST be encrypted or tokenized prior to database ingestion.**

> **Note: If the persistent data store (e.g. database) is encrypted with TDE, only the below list of data elements will require field level encryption (FLE):**
> * **Names (first and last)**
> * **Addresses (not including state)**
> * **Phone Numbers (e.g. home, work, cell, etc.)**
> * **Email Addresses**
> * **Rx Numbers**
> * **Free form text fields**
> * **SSN's**
> * **Driver' License Numbers**
> * **Credit Card Numbers (Tokenization Required)**
>
> **If TDE is not used all PHI and PII data elements Must be encrypted with FLE.**

---

It is the responsibility of the application team to ensure any senstive data be encrypted or tokenized. Logic Apps will not have the ability to integrate with any encryption solution, so fields or information that is encrypted will not be actionable via logic apps


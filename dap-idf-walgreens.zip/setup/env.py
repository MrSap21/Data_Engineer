# Databricks notebook source
"""
tenandId = dbutils.secrets.get(scope="idf-secrets",key="idfwbadev")

endpoint = "https://login.microsoftonline.com/e1e992a8-e7ca-4897-aa6e-6ef00b6571c1/oauth2/token"

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": "0f68659d-746f-478f-9c93-325e90e45c31",
           "fs.azure.account.oauth2.client.secret": tenandId,
           "fs.azure.account.oauth2.client.endpoint": endpoint}"""


# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": dbutils.secrets.get(scope="idf-secrets",key="acnidfcloud-client-id"),
           "fs.azure.account.oauth2.client.secret": dbutils.secrets.get(scope="idf-secrets",key="idf-azure-sp-secret"),
           "fs.azure.account.oauth2.client.endpoint": dbutils.secrets.get(scope="idf-secrets",key="acnidfcloud-endpoint-url")}

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://wba-idf@idfwbadevworkspace.dfs.core.windows.net",
  mount_point = "/mnt/wbaidf",
  extra_configs = configs)

# COMMAND ----------


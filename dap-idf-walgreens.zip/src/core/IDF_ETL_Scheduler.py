# Databricks notebook source
config_files = [
  # 'FinalMergeSynapse.json'
  'ETL_Filter.json'
]

# COMMAND ----------

for file in config_files:
    dbutils.notebook.run("IDF_ETL_Driver", 120, {'config_file_name':file})
#for
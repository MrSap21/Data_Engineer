# Databricks notebook source
import os #line:2
import sys #line:3
import re #line:4
import json #line:5
import traceback #line:6
import uuid #line:7
from datetime import datetime ,timedelta #line:8
import pytz #line:9
from dateutil .relativedelta import relativedelta #line:10
from typing import Iterable #line:11
from itertools import *#line:12
from functools import wraps #line:13
from inspect import getcallargs ,getargspec #line:14
from collections import OrderedDict ,Iterable #line:15
import logging #line:16
import sparkclean #line:18
import boto3 #line:20
import pyspark #line:22
from pyspark .sql import SparkSession ,Row #line:23
from pyspark .sql import SQLContext ,DataFrame #line:24
from pyspark .sql .types import *#line:25
import pyspark .sql .functions as F #line:26
from pyspark .sql .window import Window #line:27
from pyspark .ml import Pipeline #line:30
from pyspark .ml .feature import StringIndexer ,VectorAssembler #line:31
from pyspark .mllib .stat import Statistics #line:32
from pyspark .ml .stat import KolmogorovSmirnovTest ,Summarizer ,Summarizer #line:33
from pyspark .mllib .util import MLUtils #line:34
RECORDER_SPARK_BASE =[]#line:38
def log_to (O0O00000OO0OOOOOO ):#line:39
    def O000000OO0000OOO0 (OOO00000OO0OO0000 ):#line:40
      @wraps (OOO00000OO0OO0000 )#line:41
      def OOO00OO0OOOOOOO0O (*OO0000OOO000O0O0O ,**OO0OO0OOO0OOO0O00 ):#line:42
        try :#line:43
          RECORDER_SPARK_BASE .append ("Function Name : {func_name} ; Time : {time} ; Arguments :  {args}".format (func_name =OOO00000OO0OO0000 .__name__ ,time =str (datetime .now ()),args =OO0000OOO000O0O0O ))#line:44
          return OOO00000OO0OO0000 (*OO0000OOO000O0O0O ,**OO0OO0OOO0OOO0O00 )#line:45
        except :#line:47
          RECORDER_SPARK_BASE .append ("IDF_Exception :  {exception} : {trace}".format (exception =sys .exc_info ()[0 ],trace =traceback .format_exc ()))#line:48
      return OOO00OO0OOOOOOO0O #line:51
    return O000000OO0000OOO0 #line:53
logdebug =log_to (logging .debug )#line:55
_OOO0OO0OOO0OO0OO0 =lambda OO0O0OOOOO0OOOO00 ,OO0000O0OO00O0O0O :list (filter (lambda O0OOOO0O00OOOO0O0 :O0OOOO0O00OOOO0O0 !=OO0000O0OO00O0O0O ,OO0O0OOOOO0OOOO00 ))#line:59
_OOO000OO000000000 ={"string":StringType (),"integer":IntegerType (),"double":DoubleType (),"date":DateType (),"timestamp":TimestampType (),"boolean":BooleanType (),'long':LongType (),'float':FloatType ()}#line:61
class RulesEngineBaseClass (object ):#line:65
  def class_type (O00O0O0OO0O00OOOO ):#line:66
    print ("RulesEngineBaseClass")#line:67
class RulesEnginePredefinedClass (RulesEngineBaseClass ):#line:73
  @logdebug #line:74
  def standardizeColumnsByPredefinedRule_fn (O00OO00OO0000OOO0 ,O0OOO0O0000OO0O0O ,O0O00OOO0OO00OO00 ,O000O000OO000OO0O ,OO0O00OOOO0000OOO ):#line:75
      ""#line:78
      try :#line:79
        O000O000OO000OO0O =[O0OO0OOOOOO00OOOO .lower ()for O0OO0OOOOOO00OOOO in O000O000OO000OO0O ]#line:80
        if "UPPER"==O0O00OOO0OO00OO00 .upper ():#line:82
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:83
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .upper (F .col (O00OOOO0O0OO0O0OO .strip ())).alias (O00OOOO0O0OO0O0OO .strip ()))#line:84
        elif "LOWER"==O0O00OOO0OO00OO00 .upper ():#line:88
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:89
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .lower (F .col (O00OOOO0O0OO0O0OO .strip ())).alias (O00OOOO0O0OO0O0OO .strip ()))#line:90
        elif "TRIM"==O0O00OOO0OO00OO00 .upper ():#line:94
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:95
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .trim (F .col (O00OOOO0O0OO0O0OO .strip ())).alias (O00OOOO0O0OO0O0OO .strip ()))#line:97
        elif "TRIM_ALL"==O0O00OOO0OO00OO00 .upper ():#line:100
            OOOO0000O0O0O0000 ={O00OO00O0O0O00O0O .name :O00OO00O0O0O00O0O .dataType .typeName ().lower ()for O00OO00O0O0O00O0O in O0OOO0O0000OO0O0O .schema .fields }#line:101
            O000O000OO000OO0O =list (filter (lambda O00OOOO0O0O0OOO00 :O00OOOO0O0O0OOO00 [1 ]=='string',OOOO0000O0O0O0000 .items ()))#line:102
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:103
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO [0 ].strip ()),F .trim (F .col (O00OOOO0O0OO0O0OO [0 ].strip ())).alias (O00OOOO0O0OO0O0OO [0 ].strip ()))#line:105
        elif "ASCII"==O0O00OOO0OO00OO00 .upper ():#line:108
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:109
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .decode (F .col (O00OOOO0O0OO0O0OO .strip ()),'ASCII').alias (O00OOOO0O0OO0O0OO .strip ()))#line:111
        elif "ASCII_ALL"==O0O00OOO0OO00OO00 .upper ():#line:114
            OOO00OOOO00O00OOO =O0OOO0O0000OO0O0O .dtypes #line:115
            O000O000OO000OO0O =list (filter (lambda O0OO0OOO0OO0O000O :O0OO0OOO0OO0O000O [1 ].lower ()=='string',OOO00OOOO00O00OOO ))#line:116
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:117
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO [0 ].strip ()),F .decode (F .col (O00OOOO0O0OO0O0OO [0 ].strip ()),'ASCII').alias (O00OOOO0O0OO0O0OO [0 ].strip ()))#line:119
        elif "CAMEL_CASE"==O0O00OOO0OO00OO00 .upper ():#line:122
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:123
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .initcap (F .col (O00OOOO0O0OO0O0OO .strip ())).alias (O00OOOO0O0OO0O0OO .strip ()))#line:125
        elif "NUMERIC_ONLY"==O0O00OOO0OO00OO00 .upper ():#line:128
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:129
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .regexp_replace (F .col (O00OOOO0O0OO0O0OO .strip ()),r"[^0-9]","").alias (O00OOOO0O0OO0O0OO .strip ()))#line:131
        elif "NUMERIC_WITH_DECIMAL_ONLY"==O0O00OOO0OO00OO00 .upper ():#line:134
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:135
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .regexp_replace (F .col (O00OOOO0O0OO0O0OO .strip ()),r"[^0-9.]","").alias (O00OOOO0O0OO0O0OO .strip ()))#line:137
        elif "NONNUMERIC_ONLY"==O0O00OOO0OO00OO00 .upper ():#line:140
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:141
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .regexp_replace (F .col (O00OOOO0O0OO0O0OO .strip ()),r"[0-9]","").alias (O00OOOO0O0OO0O0OO .strip ()))#line:143
        elif "CHARACTERS_ONLY"==O0O00OOO0OO00OO00 .upper ():#line:146
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:147
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .regexp_replace (F .col (O00OOOO0O0OO0O0OO .strip ()),r"[^a-zA-Z]","").alias (O00OOOO0O0OO0O0OO .strip ()))#line:149
        elif "WITHOUT_SPECIAL_CHARACTERS"==O0O00OOO0OO00OO00 .upper ():#line:152
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:153
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .regexp_replace (F .col (O00OOOO0O0OO0O0OO .strip ()),r"[^0-9a-zA-Z]","").alias (O00OOOO0O0OO0O0OO .strip ()))#line:155
        elif "MULTI_WHITESPACE_2_SINGLE"==O0O00OOO0OO00OO00 .upper ():#line:158
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:159
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .regexp_replace (F .col (O00OOOO0O0OO0O0OO .strip ())," {2,}"," ").alias (O00OOOO0O0OO0O0OO .strip ()))#line:161
        elif "MULTI_WHITESPACE_2_SINGLE_ALL"==O0O00OOO0OO00OO00 .upper ():#line:164
            OOO00OOOO00O00OOO =O0OOO0O0000OO0O0O .dtypes #line:165
            O000O000OO000OO0O =list (filter (lambda O0000O000O0O00O00 :O0000O000O0O00O00 [1 ].lower ()=='string',OOO00OOOO00O00OOO ))#line:166
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:167
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .regexp_replace (F .col (O00OOOO0O0OO0O0OO .strip ())," {2,}"," ").alias (O00OOOO0O0OO0O0OO .strip ()))#line:169
        elif "EPOCH_2_DATE"==O0O00OOO0OO00OO00 .upper ():#line:172
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:173
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .col (O00OOOO0O0OO0O0OO .strip ()).cast ('string').substr (1 ,10 ).cast ('long').alias (O00OOOO0O0OO0O0OO .strip ()))#line:176
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()).cast (TimestampType ())).alias (O00OOOO0O0OO0O0OO .strip ()))#line:177
        elif "DD-MM-YYYY_2_DATE"==O0O00OOO0OO00OO00 .upper ():#line:180
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:181
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()).cast ('string'),'dd-MM-yyyy').alias (O00OOOO0O0OO0O0OO .strip ()))#line:183
        elif "MM-DD-YYYY_2_DATE"==O0O00OOO0OO00OO00 .upper ():#line:186
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:187
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()).cast ('string'),'MM-dd-yyyy').alias (O00OOOO0O0OO0O0OO .strip ()))#line:189
        elif "YYYY-MM-DD_2_DATE"==O0O00OOO0OO00OO00 .upper ():#line:192
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:193
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()).cast ('string'),'yyyy-MM-dd').alias (O00OOOO0O0OO0O0OO .strip ()))#line:195
        elif "YYYYMMDD_2_DATE"==O0O00OOO0OO00OO00 .upper ():#line:198
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:199
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()).cast ('string'),'yyyyMMdd').alias (O00OOOO0O0OO0O0OO .strip ()))#line:201
        elif "MULTI_FORMAT_TS"==O0O00OOO0OO00OO00 .upper ():#line:204
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:205
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .coalesce (F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'yyyy-MM-dd HH:mm:SS'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'yyyy/MM/dd HH:mm:SS'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'yyyy/MM/dd HH:mm'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'MM/dd/yyyy HH:mm:SS'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'MM/dd/yyyy HH:mm'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'MM-dd-yyyy HH:mm:SS'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'dd/MM/yyyy HH:mm:SS'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'dd-MM-yyyy HH:mm:SS'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'dd-MM-yyyy HH:mm')).alias (O00OOOO0O0OO0O0OO .strip ()))#line:216
        elif "MULTI_FORMAT_DATE"==O0O00OOO0OO00OO00 .upper ():#line:219
            for O00OOOO0O0OO0O0OO in O000O000OO000OO0O :#line:220
                O0OOO0O0000OO0O0O =O0OOO0O0000OO0O0O .select (*_OOO0OO0OOO0OO0OO0 (OO0O00OOOO0000OOO ,O00OOOO0O0OO0O0OO .strip ()),F .coalesce (F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'yyyy-MM-dd'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'yyyy/MM/dd'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'MM/dd/yyyy'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'MM-dd-yyyy'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'dd/MM/yyyy'),F .to_timestamp (F .col (O00OOOO0O0OO0O0OO .strip ()),'dd-MM-yyyy')).alias (O00OOOO0O0OO0O0OO .strip ()))#line:228
        return O0OOO0O0000OO0O0O #line:231
      finally :#line:233
        O0OOO0O0000OO0O0O =None #line:234
class RulesEngineExpressionClass (RulesEngineBaseClass ):#line:241
  @logdebug #line:242
  def standardizeColumnsByExpressionRule_fn (OO0O0O00O0000OOO0 ,O0OOO0O00OO0OO0OO ,O00O0O0OO0000OOO0 ,O000O0000000OO0O0 ,OOO0OO00O0O0O0000 ,OOOOOOOO0OOO0OOOO ,O0OOOOOO0000O0OOO ):#line:243
    ""#line:254
    try :#line:255
      O000O0000000OO0O0 =[O0O0OOO0O0O000O00 .lower ()for O0O0OOO0O0O000O00 in O000O0000000OO0O0 ]#line:256
      def _O0OO000O00OO00O00 (O0OOOO0000O0OOO00 ,OOOOO000O00O00000 ):#line:258
          if O0OOOO0000O0OOO00 ==None :#line:259
            return O0OOOO0000O0OOO00 #line:260
          OOOOO000O00O00000 =str ("".join (OOOOO000O00O00000 [0 ]))#line:262
          return eval ("f'"+OOOOO000O00O00000 .replace ('$','O0OOOO0000O0OOO00')+"'")#line:263
      def O00000OOO0O0000OO (OO00OO0OO0O0OO0OO ):#line:266
          O0O00O0O0OOO0O0O0 ={'MM':'%m','dd':'%d','yyyy':'%Y','HH':'%H','mm':'%M','ss':'%s'}#line:275
          for OOOOO0000OO00O000 ,OO0OO000000OO0O00 in O0O00O0O0OOO0O0O0 .items ():#line:276
              OO00OO0OO0O0OO0OO =OO00OO0OO0O0OO0OO .replace (OOOOO0000OO00O000 ,OO0OO000000OO0O00 )#line:277
          return OO00OO0OO0O0OO0OO #line:280
      if O00O0O0OO0000OOO0 .lower ()=='regex_replace':#line:283
        for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:284
          O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .regexp_replace (F .col (OOO0OO0000O0OO0OO ),OOO0OO00O0O0O0000 ,OOOOOOOO0OOO0OOOO ).alias (OOO0OO0000O0OO0OO .strip ()))#line:286
      elif O00O0O0OO0000OOO0 .lower ()=='date_format':#line:289
        for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:290
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .to_timestamp (F .col (OOO0OO0000O0OO0OO .strip ()).cast ('string'),OOO0OO00O0O0O0000 ).alias (OOO0OO0000O0OO0OO .strip ()))#line:292
      elif O00O0O0OO0000OOO0 .lower ()=='date_utc_conversion':#line:295
        O0000O0OOOO0000OO =pytz .timezone (OOOOOOOO0OOO0OOOO )#line:296
        OOO0OO00O0O0O0000 =O00000OOO0O0000OO (OOO0OO00O0O0O0000 )#line:297
        _O0OO0O0OOO0OO0O00 =F .udf (lambda O0OOOO0O0OO000OO0 :str (O0000O0OOOO0000OO .localize (datetime .strptime (O0OOOO0O0OO000OO0 ,OOO0OO00O0O0O0000 ))),StringType ())#line:298
        for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:299
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),_O0OO0O0OOO0OO0O00 (F .col (OOO0OO0000O0OO0OO .strip ()).cast ('string')).alias (OOO0OO0000O0OO0OO .strip ()))#line:301
      elif O00O0O0OO0000OOO0 .lower ()=='string_format':#line:305
        O0O00000O0000O000 =F .udf (_O0OO000O00OO00O00 ,StringType ())#line:306
        OOO0OO0OOO000O00O =[]#line:308
        OOO0OO0OOO000O00O .append (OOO0OO00O0O0O0000 )#line:309
        OOO0OO0O00OOOOO00 =F .array (*[F .array (*[F .lit (O00OOO000O0OO0OOO )])for O00OOO000O0OO0OOO in OOO0OO0OOO000O00O ])#line:310
        for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:312
          O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),O0O00000O0000O000 (F .col (OOO0OO0000O0OO0OO ).cast ('string'),OOO0OO0O00OOOOO00 ).alias (OOO0OO0000O0OO0OO .strip ()))#line:314
      elif O00O0O0OO0000OOO0 .lower ()=='impute_data':#line:318
        O000O0000000OO0O0 =[OO000OO00000O0O0O [0 ]for OO000OO00000O0O0O in list (filter (lambda O00OOOO0OOOOO0O0O :O00OOOO0OOOOO0O0O [1 ]in ['double','int','decimal','float','long','short'],O0OOO0O00OO0OO0OO .select (*O000O0000000OO0O0 ).dtypes ))]#line:319
        OOO0OO00O0O0O0000 =OOO0OO00O0O0O0000 .lower ()#line:320
        for OO00O00O00OOOO000 in O000O0000000OO0O0 :#line:322
          if OOO0OO00O0O0O0000 =='avg'or OOO0OO00O0O0O0000 =='mean'or OOO0OO00O0O0O0000 =='average':#line:323
              O0O0O0O00O00OOOOO =O0OOO0O00OO0OO0OO .groupBy ().avg (OO00O00O00OOOO000 ).collect ()[0 ][0 ]#line:324
              O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OO00O00O00OOOO000 .strip ()),F .when (F .isnan (OO00O00O00OOOO000 )|F .isnull (OO00O00O00OOOO000 ),F .lit (O0O0O0O00O00OOOOO )).otherwise (F .col (OO00O00O00OOOO000 )).alias (OO00O00O00OOOO000 .strip ()))#line:326
          elif OOO0OO00O0O0O0000 =='median':#line:328
              O0000O0OOO0OO0O0O =O0OOO0O00OO0OO0OO .withColumn (OO00O00O00OOOO000 ,inputDF [OO00O00O00OOOO000 ]).approxQuantile (OO00O00O00OOOO000 ,[0.5 ],0.25 )[0 ]#line:329
              O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OO00O00O00OOOO000 .strip ()),F .when (isnan (OO00O00O00OOOO000 )|F .isnull (OO00O00O00OOOO000 ),F .lit (O0000O0OOO0OO0O0O )).otherwise (F .col (OO00O00O00OOOO000 )).alias (OO00O00O00OOOO000 .strip ()))#line:331
          elif OOO0OO00O0O0O0000 =='mode':#line:334
              OO0OOO0000O00O0OO =inputDF .stat .freqItems ([OO00O00O00OOOO000 ],0.75 ).collect ()[0 ][0 ][0 ]#line:335
              O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OO00O00O00OOOO000 .strip ()),F .when (F .isnan (OO00O00O00OOOO000 )|F .isnull (OO00O00O00OOOO000 ),F .lit (OO0OOO0000O00O0OO )).otherwise (F .col (OO00O00O00OOOO000 )).alias (OO00O00O00OOOO000 .strip ()))#line:337
          elif OOO0OO00O0O0O0000 =='constant'or OOO0OO00O0O0O0000 =='const':#line:340
              O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OO00O00O00OOOO000 .strip ()),F .when (F .isnan (OO00O00O00OOOO000 )|F .isnull (OO00O00O00OOOO000 ),F .lit (OOOOOOOO0OOO0OOOO )).otherwise (F .col (OO00O00O00OOOO000 )).alias (OO00O00O00OOOO000 .strip ()))#line:342
      elif O00O0O0OO0000OOO0 .lower ()=='anonymization'or O00O0O0OO0000OOO0 .lower ()=='anonymize':#line:347
        OOO0OO00O0O0O0000 =OOO0OO00O0O0O0000 .lower ()#line:348
        if OOO0OO00O0O0O0000 =='base64'or OOO0OO00O0O0O0000 =='base':#line:349
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:350
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .base64 (F .col (OOO0OO0000O0OO0OO )).alias (OOO0OO0000O0OO0OO .strip ()))#line:352
        elif OOO0OO00O0O0O0000 =='hex':#line:355
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:356
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .hex (F .col (OOO0OO0000O0OO0OO )).alias (OOO0OO0000O0OO0OO .strip ()))#line:358
        elif OOO0OO00O0O0O0000 =='sha1'or OOO0OO00O0O0O0000 =='sha':#line:361
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:362
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .sha1 (F .col (OOO0OO0000O0OO0OO )).alias (OOO0OO0000O0OO0OO .strip ()))#line:364
      elif O00O0O0OO0000OOO0 .lower ()=='number_format':#line:369
        for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:370
          if O0OOO0O00OO0OO0OO .select (OOO0OO0000O0OO0OO ).dtypes [0 ][1 ]in ['double','int','decimal','float','long','short']:#line:371
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .format_number (F .col (OOO0OO0000O0OO0OO ),int (OOO0OO00O0O0O0000 )).alias (OOO0OO0000O0OO0OO .strip ()))#line:373
      elif O00O0O0OO0000OOO0 .lower ()=='functional':#line:378
        OOO0OO00O0O0O0000 =OOO0OO00O0O0O0000 .lower ()#line:379
        if OOO0OO00O0O0O0000 =='base64'or OOO0OO00O0O0O0000 =='base':#line:380
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:381
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .base64 (F .col (OOO0OO0000O0OO0OO )).alias (OOO0OO0000O0OO0OO .strip ()))#line:383
        elif OOO0OO00O0O0O0000 =='substring'or OOO0OO00O0O0O0000 =='sub-string':#line:386
          OOO0O0OO00OO0OO0O =OOOOOOOO0OOO0OOOO .strip ().split (":")#line:387
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:388
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .substring (F .col (OOO0OO0000O0OO0OO ).cast ('string'),int (OOO0O0OO00OO0OO0O [0 ]),int (OOO0O0OO00OO0OO0O [1 ])).alias (OOO0OO0000O0OO0OO .strip ()))#line:390
        elif OOO0OO00O0O0O0000 =='prefix'or OOO0OO00O0O0O0000 =='pre-fix':#line:393
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:394
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .concat (F .lit (OOOOOOOO0OOO0OOOO ),F .col (OOO0OO0000O0OO0OO ).cast ("string")).alias (OOO0OO0000O0OO0OO .strip ()))#line:396
        elif OOO0OO00O0O0O0000 =='suffix':#line:399
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:400
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .concat (F .col (OOO0OO0000O0OO0OO ).cast ("string"),F .lit (OOOOOOOO0OOO0OOOO )).alias (OOO0OO0000O0OO0OO .strip ()))#line:402
        elif OOO0OO00O0O0O0000 =='removeaccent'or OOO0OO00O0O0O0000 =='accent-remove'or OOO0OO00O0O0O0000 =='accentremove':#line:405
          def _O0OO0OOOOOO0O0000 (O0OOOO000O0OOOO0O ):#line:406
            try :#line:407
                if O0OOOO000O0OOOO0O is None or str (O0OOOO000O0OOOO0O )=='nan':#line:408
                    O0OOOO000O0OOOO0O =''#line:409
                else :#line:411
                    O0OOOO000O0OOOO0O =re .sub ('\W+',' ',O0OOOO000O0OOOO0O )#line:412
                return O0OOOO000O0OOOO0O #line:414
            except :#line:416
                traceback .print_exc ()#line:417
                raise ValueError ("Error In Accent Removal")#line:418
          OOOO0O0000000OO0O =F .udf (_O0OO0OOOOOO0O0000 ,StringType ())#line:421
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:422
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),OOOO0O0000000OO0O (F .col (OOO0OO0000O0OO0OO ).cast ("string")).alias (OOO0OO0000O0OO0OO .strip ()))#line:424
        elif OOO0OO00O0O0O0000 =='rpad'or OOO0OO00O0O0O0000 =='r-pad':#line:427
          OO0OOO0OOOO0OOOO0 =OOOOOOOO0OOO0OOOO .strip ().split (",")#line:428
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:429
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .rpad (F .col (OOO0OO0000O0OO0OO ).cast ("string"),int (OO0OOO0OOOO0OOOO0 [0 ]),OO0OOO0OOOO0OOOO0 [1 ]).alias (OOO0OO0000O0OO0OO .strip ()))#line:431
        elif OOO0OO00O0O0O0000 =='lpad'or OOO0OO00O0O0O0000 =='l-pad':#line:434
          OO0OOO0OOOO0OOOO0 =OOOOOOOO0OOO0OOOO .strip ().split (",")#line:435
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:436
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .lpad (F .col (OOO0OO0000O0OO0OO ).cast ("string"),int (OO0OOO0OOOO0OOOO0 [0 ]),OO0OOO0OOOO0OOOO0 [1 ]).alias (OOO0OO0000O0OO0OO .strip ()))#line:438
        elif OOO0OO00O0O0O0000 =='rtrim'or OOO0OO00O0O0O0000 =='r-trim':#line:441
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:442
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .rtrim (F .col (OOO0OO0000O0OO0OO ).cast ("string")).alias (OOO0OO0000O0OO0OO .strip ()))#line:444
        elif OOO0OO00O0O0O0000 =='ltrim'or OOO0OO00O0O0O0000 =='l-trim':#line:447
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:448
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),F .ltrim (F .col (OOO0OO0000O0OO0OO ).cast ("string")).alias (OOO0OO0000O0OO0OO .strip ()))#line:450
        elif OOO0OO00O0O0O0000 =='trimdoublequotes'or OOO0OO00O0O0O0000 =='trimquotes'or OOO0OO00O0O0O0000 =='trim-quotes'or OOO0OO00O0O0O0000 =='trim-double-quotes':#line:453
          O0000O00OOOOOO0O0 =F .udf (lambda O00O0O000O0000O0O :O00O0O000O0000O0O .strip ('"'))#line:454
          for OOO0OO0000O0OO0OO in O000O0000000OO0O0 :#line:455
            O0OOO0O00OO0OO0OO =O0OOO0O00OO0OO0OO .select (*_OOO0OO0OOO0OO0OO0 (O0OOOOOO0000O0OOO ,OOO0OO0000O0OO0OO .strip ()),O0000O00OOOOOO0O0 (F .col (OOO0OO0000O0OO0OO )).alias (OOO0OO0000O0OO0OO .strip ()))#line:457
      return O0OOO0O00OO0OO0OO #line:462
    finally :#line:464
      O0OOO0O00OO0OO0OO =None #line:465
@logdebug #line:472
def convertAliasColumnName2RulesEngine_fn (OO0OOOO0OOO0OOO0O ,O00O0O000OOOO0O00 ):#line:473
  ""#line:476
  OO0O0OO0O0OOO00O0 ={}#line:477
  for O0O0O0OOOOO0O000O in OO0OOOO0OOO0OOO0O :#line:478
    O0O000000OO00O0OO =O0O0O0OOOOO0O000O .get ('metadata',{}).get ('alias_name',None )#line:479
    if O0O000000OO00O0OO !=None and O0O000000OO00O0OO .upper ()!='NA':#line:480
      OOO00O00O0O00O00O =O0O000000OO00O0OO .split (',')#line:481
      for O00O000O00O00OO0O in OOO00O00O0O00O00O :#line:482
        O00000OOOOO0OO0O0 =OO0O0OO0O0OOO00O0 .get (O00O000O00O00OO0O ,[])#line:483
        O00000OOOOO0OO0O0 .append (O0O0O0OOOOO0O000O .get ('name'))#line:484
        OO0O0OO0O0OOO00O0 [O00O000O00O00OO0O ]=O00000OOOOO0OO0O0 #line:485
  OOOO0OO000O00O0OO =[]#line:490
  OOOO00O0OOO0O0O00 =[]#line:491
  for O00O0O0O00O0O000O in O00O0O000OOOO0O00 :#line:492
    if 'anonymize_by_tags'in O00O0O0O00O0O000O .get ("type"):#line:493
      O0O0OO00O00O0O000 =OO0O0OO0O0OOO00O0 .get (O00O0O0O00O0O000O .get ('parameter').split (",")[0 ])#line:494
      for OO0O00O0O00O0O0OO in O0O0OO00O00O0O000 :#line:495
        OOOO00OOOOO0O000O =O00O0O0O00O0O000O .copy ()#line:496
        OOOO00OOOOO0O000O ['old_column_names']=OO0O00O0O00O0O0OO #line:497
        OOOO00OOOOO0O000O ['new_column_names']=OO0O00O0O00O0O0OO #line:498
        OOOO00OOOOO0O000O ['parameter']=O00O0O0O00O0O000O .get ('parameter').split (",")[1 ]#line:499
        OOOO0OO000O00O0OO .append (OOOO00OOOOO0O000O )#line:500
      O00O0O000OOOO0O00 .remove (O00O0O0O00O0O000O )#line:502
  O00O0O000OOOO0O00 =O00O0O000OOOO0O00 +OOOO0OO000O00O0OO #line:506
  return O00O0O000OOOO0O00 #line:508
class RulesEngineComplexClass (RulesEngineBaseClass ):#line:513
  @logdebug #line:514
  def standardizeColumnsByComplexRule_fn (O00O00OO00O000000 ,OOO0O0O0O000OO0OO ,OO0O0O0OOOO000O00 ,O0000OO0O00O0O0OO ,O0OO0OO0000O000O0 ):#line:515
    ""#line:618
    try :#line:619
      def _OOOO0O0O000OO0O0O (O0O0O0OOOO0OO0OOO ,O0OOO00O0OO0OOO00 ):#line:620
        try :#line:621
          if O0O0O0OOOO0OO0OOO is None or str (O0O0O0OOOO0OO0OOO )=='nan':#line:622
            return None #line:623
          OOO00000OOOO00OOO =str ("".join (O0OOO00O0OO0OOO00 [0 ])).split ("#")#line:625
          O0O00O00OO0O00000 =re .compile (OOO00000OOOO00OOO [1 ],re .I |re .M )#line:626
          OOOO00O000O0O0000 =re .sub (O0O00O00OO0O00000 ,"\g<"+str (OOO00000OOOO00OOO [2 ])+">",O0O0O0OOOO0OO0OOO )#line:627
          if int (OOO00000OOOO00OOO [2 ])==1 :#line:628
              return OOOO00O000O0O0000 +str (OOO00000OOOO00OOO [0 ])#line:629
          else :#line:631
              return str (OOO00000OOOO00OOO [0 ])+OOOO00O000O0O0000 #line:632
        except :#line:635
          return None #line:636
      def _O0O0OOOOOO00OO00O (OO0OOO0OOOOOOO0O0 ,O00OO0O0OO00OOOOO ):#line:640
        try :#line:641
          if OO0OOO0OOOOOOO0O0 ==None or len (OO0OOO0OOOOOOO0O0 )==0 :#line:642
            return None #line:643
          O000OO0OO00O0O00O ={'MM':'%m','dd':'%d','yyyy':'%Y','HH':'%H','I':'%I','II':'%I','mm':'%M','ss':'%S','yy':'%y','a':'%a','p':'%p',}#line:658
          for O0O00000O000O0000 ,OO000000O0OOO0OOO in O000OO0OO00O0O00O .items ():#line:659
            O00OO0O0OO00OOOOO =O00OO0O0OO00OOOOO .replace (O0O00000O000O0000 ,OO000000O0OOO0OOO )#line:660
          O0O0OOOOO00O00OO0 =datetime .strptime (OO0OOO0OOOOOOO0O0 ,O00OO0O0OO00OOOOO )#line:663
          return str (O0O0OOOOO00O00OO0 )#line:664
        except :#line:666
          return None #line:667
      def _O00OOO0OOOOO000O0 (O0OOOOO00OOO0000O ,OOOO00OOOO0O00O0O ):#line:671
        try :#line:672
          if O0OOOOO00OOO0000O ==None or len (O0OOOOO00OOO0000O )==0 :#line:673
            return None #line:674
          OOOOOOO000O0O00O0 ={'MM':'%m','dd':'%d','yyyy':'%Y','HH':'%H','mm':'%M','ss':'%S'}#line:684
          for O0OOO0O0O0000000O ,OO0O0OO0O0000O0OO in OOOOOOO000O0O00O0 .items ():#line:685
            OOOO00OOOO0O00O0O =OOOO00OOOO0O00O0O .replace (O0OOO0O0O0000000O ,OO0O0OO0O0000O0OO )#line:686
          O0OO0OOOO00OO00O0 =datetime .strptime (O0OOOOO00OOO0000O ,OOOO00OOOO0O00O0O ).date ()#line:689
          return str (O0OO0OOOO00OO00O0 )#line:690
        except :#line:692
          return None #line:693
      def _O0000000O000O00O0 (O00O00OOO0O0000O0 ):#line:698
        try :#line:699
          if O00O00OOO0O0000O0 ==None :#line:700
            return None #line:701
          O00O00OOO0O0000O0 =re .sub (' +',' ',O00O00OOO0O0000O0 )#line:703
          OOOO00O00O00O00OO =re .sub (r'[0-9a-zA-Z]','x',O00O00OOO0O0000O0 )#line:704
          if OOOO00O00O00O00OO =='xxxx-xx-xx':#line:706
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y-%m-%d')#line:707
          elif OOOO00O00O00O00OO =='xxxx-x-xx':#line:708
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y-%m-%d')#line:709
          elif OOOO00O00O00O00OO =='xxxx-xx-x':#line:710
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y-%m-%d')#line:711
          elif OOOO00O00O00O00OO =='xxxx-x-x':#line:712
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y-%m-%d')#line:713
          elif OOOO00O00O00O00OO =='xx-xx-xx':#line:714
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m-%d-%y')#line:715
          elif OOOO00O00O00O00OO =='xx-x-x':#line:716
              return datetime .strptime (O00O00OOO0O0000O0 ,'%y-%m-%d')#line:717
          elif OOOO00O00O00O00OO =='xx-xx-x':#line:718
              return datetime .strptime (O00O00OOO0O0000O0 ,'%y-%m-%d')#line:719
          elif OOOO00O00O00O00OO =='xx-x-xx':#line:720
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m-%d-%y')#line:721
          elif OOOO00O00O00O00OO =='x-x-xx':#line:722
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m-%d-%y')#line:723
          elif OOOO00O00O00O00OO in ['x-x-xx x:xx','x-x-xx x:xx']:#line:724
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m-%d-%y %H:%M')#line:725
          elif OOOO00O00O00O00OO =='xx-xxx-xxxx':#line:726
              return datetime .strptime (O00O00OOO0O0000O0 ,'%d-%b-%Y')#line:727
          elif OOOO00O00O00O00OO =='xx-xxx-xxxx xx:xx:xx':#line:728
              return datetime .strptime (O00O00OOO0O0000O0 ,'%d-%b-%Y %H:%M:%S')#line:729
          elif OOOO00O00O00O00OO =='xx-xxx-xx xx:xx:xx':#line:730
              return datetime .strptime (O00O00OOO0O0000O0 ,'%d-%b-%y %H:%M:%S')#line:731
          elif OOOO00O00O00O00OO in ['xx-xx-xx xx:xx:xx xx','xx-xx-xx x:xx:xx xx','xx-xx-xx xx:x:xx xx','xx-xx-xx x:x:x xx','xx-xx-xx xx:xx:x xx','x-x-xxxx xx:xx:xx xx','x-x-xxxx x:xx:xx xx','x-x-xxxx x:x:xx xx','x-x-xxxx x:x:x xx','x-xx-xxxx xx:xx:xx xx','x-xx-xxxx x:xx:xx xx','x-xx-xxxx x:x:xx xx','x-xx-xxxx x:x:x xx' 'xx-x-xxxx xx:xx:xx xx','xx-x-xxxx x:xx:xx xx','xx-x-xxxx x:x:xx xx','xx-x-xxxx x:x:x xx']:#line:732
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m-%d-%Y %I:%M:%S %p')#line:733
          elif OOOO00O00O00O00OO =='xxxx/xx/xx':#line:734
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y/%m/%d')#line:735
          elif OOOO00O00O00O00OO =='xx/xx/xx':#line:736
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%y')#line:737
          elif OOOO00O00O00O00OO =='xx/x/x':#line:738
              return datetime .strptime (O00O00OOO0O0000O0 ,'%y/%m/%d')#line:739
          elif OOOO00O00O00O00OO =='xx/xx/x':#line:740
              return datetime .strptime (O00O00OOO0O0000O0 ,'%y/%m/%d')#line:741
          elif OOOO00O00O00O00OO =='x/x/xx':#line:742
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%y')#line:743
          elif OOOO00O00O00O00OO in ['x/x/xx x:xx','x/x/xx x:xx']:#line:744
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%y %H:%M')#line:745
          elif OOOO00O00O00O00OO =='x/xx/xx':#line:746
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%y')#line:747
          elif OOOO00O00O00O00OO =='xx/x/xx':#line:748
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%y')#line:749
          elif OOOO00O00O00O00OO =='xx/xx/xxxx':#line:750
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%Y')#line:751
          elif OOOO00O00O00O00OO =='x/xx/xxxx':#line:752
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%Y')#line:753
          elif OOOO00O00O00O00OO =='xx/x/xxxx':#line:754
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%Y')#line:755
          elif OOOO00O00O00O00OO =='x/x/xxxx':#line:756
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%Y')#line:757
          elif OOOO00O00O00O00OO in ['xx/xx/xx xx:xx:xx xx','xx/xx/xx x:xx:xx xx','xx/xx/xx xx:x:xx xx','xx/xx/xx x:x:x xx','xx/xx/xx xx:xx:x xx','x/x/xxxx xx:xx:xx xx','x/x/xxxx x:xx:xx xx','x/x/xxxx x:x:xx xx','x/x/xxxx x:x:x xx','x/xx/xxxx xx:xx:xx xx','x/xx/xxxx x:xx:xx xx','x/xx/xxxx x:x:xx xx','x/xx/xxxx x:x:x xx' 'xx/x/xxxx xx:xx:xx xx','xx/x/xxxx x:xx:xx xx','xx/x/xxxx x:x:xx xx','xx/x/xxxx x:x:x xx']:#line:758
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%Y %I:%M:%S %p')#line:759
          elif OOOO00O00O00O00OO =='xx/xxx/xxxx':#line:760
              return datetime .strptime (O00O00OOO0O0000O0 ,'%d/%b/%Y')#line:761
          elif OOOO00O00O00O00OO =='xx/xxx/xxxx xx:xx:xx':#line:762
              return datetime .strptime (O00O00OOO0O0000O0 ,'%d/%b/%Y %H:%M:%S')#line:763
          elif OOOO00O00O00O00OO =='xx/xxx/xx xx:xx:xx':#line:764
              return datetime .strptime (O00O00OOO0O0000O0 ,'%d/%b/%y %H:%M:%S')#line:765
          elif OOOO00O00O00O00OO in ['xxxx/xx/xx x:xx','xxxx/xx/xx xx:xx']:#line:767
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y/%m/%d %H:%M')#line:768
          elif OOOO00O00O00O00OO in ['xx/xx/xxxx x:xx','xx/xx/xxxx xx:xx']:#line:769
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%Y %H:%M')#line:770
          elif OOOO00O00O00O00OO in ['xxxx-xx-xx x:xx','xxxx-xx-xx xx:xx']:#line:771
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y-%m-%d %H:%M')#line:772
          elif OOOO00O00O00O00OO in ['xx-xx-xxxx x:xx','xx-xx-xxxx xx:xx']:#line:773
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m-%d-%Y %H:%M')#line:774
          elif OOOO00O00O00O00OO in ['xxxx/xx/xx x:xx:xx','xxxx/xx/xx xx:xx:xx']:#line:775
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y/%m/%d %H:%M:%S')#line:776
          elif OOOO00O00O00O00OO in ['xx/xx/xxxx x:xx:xx','xx/xx/xxxx xx:xx:xx']:#line:777
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%Y %H:%M:%S')#line:778
          elif OOOO00O00O00O00OO in ['xxxx-xx-xx x:xx:xx','xxxx-xx-xx xx:xx:xx']:#line:779
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y-%m-%d %H:%M:%S')#line:780
          elif OOOO00O00O00O00OO in ['xx/xx/xxxx x:xx:xx xx','xx/xx/xxxx xx:xx:xx xx','x/xx/xxxx xx:xx:xx xx','x/xx/xxxx x:xx:xx xx']:#line:781
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m/%d/%Y %I:%M:%S %p')#line:782
          elif OOOO00O00O00O00OO in ['xx-xx-xxxx x:xx:xx xx','xx-xx-xxxx xx:xx:xx xx','x-xx-xxxx xx:xx:xx xx','x-xx-xxxx x:xx:xx xx']:#line:783
              return datetime .strptime (O00O00OOO0O0000O0 ,'%m-%d-%Y %I:%M:%S %p')#line:784
          elif OOOO00O00O00O00OO =='xxxxxxxx':#line:786
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y%d%m')#line:787
          elif OOOO00O00O00O00OO in ['xxxxxxxxxxxxxx']:#line:788
              return datetime .strptime (O00O00OOO0O0000O0 ,'%Y%d%m%H%M%S')#line:789
          return None #line:792
        except :#line:794
          return str (traceback .print_exc ())#line:795
      def _O0O000000OO000O0O (O0O000O0O0OOO00OO ):#line:800
        OOO00OOO00OOO000O ,OOO000OO0000OO0O0 =os .path .split (O0O000O0O0OOO00OO )#line:801
        return OOO000OO0000OO0O0 #line:802
      if O0000OO0O00O0O0OO .get ('type','').lower ()=='regex_extract':#line:807
        O00000O0OO0O0O000 =O0000OO0O00O0O0OO .get ('parameter','')#line:808
        O000OO000OOO00OO0 =O0000OO0O00O0O0OO .get ('selection_group')#line:809
        O0O0O0OOO0OOO0000 =[OO00O0O0OO0O0O00O .lower ()for OO00O0O0OO0O0O00O in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:810
        O0O0OOO00000O000O =[OOOOOO0OOOO00OOO0 .lower ()for OOOOOO0OOOO00OOO0 in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:811
        for OOO00OO0OOO00OOOO ,O0OOOO00OOOOO0OOO in zip (O0O0O0OOO0OOO0000 ,O0O0OOO00000O000O ):#line:813
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0OOOO00OOOOO0OOO ),F .regexp_extract (F .col (OOO00OO0OOO00OOOO ),O00000O0OO0O0O000 ,int (O000OO000OOO00OO0 )).alias (O0OOOO00OOOOO0OOO ))#line:814
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='regex_replace':#line:819
        O00000O0OO0O0O000 =O0000OO0O00O0O0OO .get ('parameter','')#line:820
        O0O0O0OOO0OOO0000 =[O00O000OOOOO00OOO .lower ()for O00O000OOOOO00OOO in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:821
        O0O0OOO00000O000O =[O0OOOO000O0OO000O .lower ()for O0OOOO000O0OO000O in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:822
        O000OO000OOOOOO00 =O0000OO0O00O0O0OO .get ('replace_value','')#line:823
        for OOO00OO0OOO00OOOO ,O0OOOO00OOOOO0OOO in zip (O0O0O0OOO0OOO0000 ,O0O0OOO00000O000O ):#line:825
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0OOOO00OOOOO0OOO ),F .regexp_replace (F .col (OOO00OO0OOO00OOOO .strip ()),O00000O0OO0O0O000 ,O000OO000OOOOOO00 ).alias (O0OOOO00OOOOO0OOO ))#line:826
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='regex_replace_partial':#line:831
        _O0O0OOOOO00O00OOO =F .udf (_OOOO0O0O000OO0O0O ,StringType ())#line:832
        O00000O0OO0O0O000 =O0000OO0O00O0O0OO .get ('parameter','')#line:834
        O000OO000OOO00OO0 =O0000OO0O00O0O0OO .get ('selection_group')#line:835
        O0O0O0OOO0OOO0000 =[O0OOO00OO0O0OO0O0 .lower ()for O0OOO00OO0O0OO0O0 in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:836
        O0O0OOO00000O000O =[O0OO0OOOO0000OOOO .lower ()for O0OO0OOOO0000OOOO in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:837
        O000OO000OOOOOO00 =O0000OO0O00O0O0OO .get ('replace_value','')#line:838
        for OOO00OO0OOO00OOOO ,O0OOOO00OOOOO0OOO in zip (O0O0O0OOO0OOO0000 ,O0O0OOO00000O000O ):#line:840
          OO000O00OOO00OO0O =[]#line:841
          OO000O00OOO00OO0O .append (O000OO000OOOOOO00 +"#"+O00000O0OO0O0O000 +"#"+str (O000OO000OOO00OO0 ))#line:842
          OO0000O00O0OOOOOO =F .array (*[F .array (*[F .lit (O00OOOOO0OO00OOO0 )])for O00OOOOO0OO00OOO0 in OO000O00OOO00OO0O ])#line:843
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0OOOO00OOOOO0OOO ),_O0O0OOOOO00O00OOO (F .col (OOO00OO0OOO00OOOO .strip ()).cast ('string'),OO0000O00O0OOOOOO ).alias (O0OOOO00OOOOO0OOO .strip ()))#line:844
      elif O0000OO0O00O0O0OO .get ('type','').lower ()in ['replace_value','replace_map']:#line:849
        O0O0O0OOO0OOO0000 =[OO000O00OO00O00O0 .lower ()for OO000O00OO00O00O0 in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:850
        O0O0OOO00000O000O =[O00O0O0OO0OO00000 .lower ()for O00O0O0OO0OO00000 in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:851
        OO0OOO0O00O0O000O =O0000OO0O00O0O0OO .get ('parameter',{})#line:852
        for OOO00OO0OOO00OOOO ,O0OOOO00OOOOO0OOO in zip (O0O0O0OOO0OOO0000 ,O0O0OOO00000O000O ):#line:854
          if OOO00OO0OOO00OOOO !=O0OOOO00OOOOO0OOO :#line:855
            OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select ("*",F .col (OOO00OO0OOO00OOOO ).alias (O0OOOO00OOOOO0OOO ))#line:856
            OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .replace (OO0OOO0O00O0O000O ,O0OOOO00OOOOO0OOO )#line:857
          else :#line:859
            OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .replace (OO0OOO0O00O0O000O ,OOO00OO0OOO00OOOO )#line:860
      elif O0000OO0O00O0O0OO .get ('type','').lower ()in ['file_lookup_csv']:#line:866
        O0O0O0OOO0OOO0000 =O0000OO0O00O0O0OO .get ('old_column_names','').lower ()#line:869
        O0O0OOO00000O000O =[OO0O00OOO0O000000 .lower ()for OO0O00OOO0O000000 in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:870
        OO0OOO0O00O0O000O =O0000OO0O00O0O0OO .get ('parameter',"")#line:871
        OOOO0O00OO00000OO =OOO0O0O0O000OO0OO .read .format ('csv').option ('sep',',').option ('quote','"').option ('escape','"').option ('header',"true").load (OO0OOO0O00O0O000O )#line:873
        OOOO0O00OO00000OO =OOOO0O00OO00000OO .toDF (*(O000O00000O00OOOO .lower ().replace ('\t','_').replace ("/","_").replace ("-","_").replace ("(","_").replace (")","_").replace ("__","_").replace ("$","_").replace (".","_").replace ('&','_').replace (":","").replace ("@","").strip ()for O000O00000O00OOOO in OOOO0O00OO00000OO .columns ))#line:874
        OOOO0O00OO00000OO =OOOO0O00OO00000OO .withColumnRenamed (O0O0OOO00000O000O [1 ],O0O0O0OOO0OOO0000 )#line:875
        O0OOO00O000O00OOO ={OO0O0O0O0000OO00O [0 ]:OO0O0O0O0000OO00O [1 ]for OO0O0O0O0000OO00O in OOOO0O00OO00000OO .collect ()}#line:876
        OOO0O0O00O0OOO0OO =OOO0O0O0O000OO0OO .sparkContext .broadcast (O0OOO00O000O00OOO )#line:878
        _O0O000O00OO0OO00O =F .udf (lambda OO00OOO00O0O0O00O :OOO0O0O00O0OOO0OO .value [OO00OOO00O0O0O00O ]if OO00OOO00O0O0O00O in OOO0O0O00O0OOO0OO .value else '',StringType ())#line:880
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .withColumn (O0O0OOO00000O000O [0 ],_O0O000O00OO0OO00O (O0O0O0OOO0OOO0000 ))#line:881
        OOO0O0O00O0OOO0OO .unpersist (blocking =True )#line:883
        OOOO0O00OO00000OO =None #line:884
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='replace_character_mapping':#line:889
        O0000O0O00OO000O0 ,OOO0OO0000O00OOO0 =O0000OO0O00O0O0OO .get ('parameter','').split (",")#line:890
        O0O0O0OOO0OOO0000 =[O0OOO0O0O00OO00O0 .lower ()for O0OOO0O0O00OO00O0 in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:891
        O0O0OOO00000O000O =[O00OO0O000O00O000 .lower ()for O00OO0O000O00O000 in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:892
        for OOO00OO0OOO00OOOO ,O0OOOO00OOOOO0OOO in zip (O0O0O0OOO0OOO0000 ,O0O0OOO00000O000O ):#line:894
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0OOOO00OOOOO0OOO ),F .translate (OOO00OO0OOO00OOOO ,O0000O0O00OO000O0 ,OOO0OO0000O00OOO0 ).alias (O0OOOO00OOOOO0OOO ))#line:895
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='convert_type':#line:900
        O00000O0OO0O0O000 =O0000OO0O00O0O0OO .get ('parameter')#line:901
        O0O0O0OOO0OOO0000 =[OOOOO0OOOO0000O0O .lower ()for OOOOO0OOOO0000O0O in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:902
        O0O0OOO00000O000O =[OOOOOO0OO0OO0000O .lower ()for OOOOOO0OO0OO0000O in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:903
        for OOO00OO0OOO00OOOO ,O0OOOO00OOOOO0OOO in zip (O0O0O0OOO0OOO0000 ,O0O0OOO00000O000O ):#line:905
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0OOOO00OOOOO0OOO ),F .col (OOO00OO0OOO00OOOO ).cast (O00000O0OO0O0O000 ).alias (O0OOOO00OOOOO0OOO .strip ()))#line:906
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='convert_boolean':#line:910
        O0O0O0OOO0OOO0000 =[OOO0000OO0OO00OO0 .lower ()for OOO0000OO0OO00OO0 in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:911
        O0O0OOO00000O000O =[OO0O00OOOOOO0OO0O .lower ()for OO0O00OOOOOO0OO0O in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:912
        OOO0O0OO0OO0OOO0O =F .udf (lambda OOOO0OO0O000O0OO0 :True if OOOO0OO0O000O0OO0 in [True ,'Yes','YES','1',1 ,'yes','Y','y','T','true','True','TRUE']else False ,BooleanType ())#line:914
        for OOO00OO0OOO00OOOO ,O0OOOO00OOOOO0OOO in zip (O0O0O0OOO0OOO0000 ,O0O0OOO00000O000O ):#line:916
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .withColumn (O0OOOO00OOOOO0OOO ,OOO0O0OO0OO0OOO0O (OOO00OO0OOO00OOOO .strip ()))#line:917
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='select_specific_columns':#line:921
        O0O0O0OOO0OOO0000 =O0000OO0O00O0O0OO .get ('old_column_names','').lower ()#line:922
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*O0O0O0OOO0OOO0000 .split (","))#line:923
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='filename_as_column':#line:927
        _O00OO0O0O0OOOOO00 =F .udf (_O0O000000OO000O0O ,F .StringType ())#line:928
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .withColumn (O0000OO0O00O0O0OO .get ('new_column_names','').lower (),_O00OO0O0O0OOOOO00 (F .input_file_name ()))#line:929
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='remove_duplicates':#line:933
        OOOOOOOOOOO0OOOOO =O0000OO0O00O0O0OO .get ('old_column_names','*').lower ()#line:934
        if OOOOOOOOOOO0OOOOO =='*':#line:936
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .drop_duplicates ()#line:937
        else :#line:939
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .drop_duplicates (subset =OOOOOOOOOOO0OOOOO .split (","))#line:940
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='lead_value':#line:944
        O0O0O00OOO0O0OO0O =O0000OO0O00O0O0OO .get ('partition_column_names','')#line:946
        O0000O000O0OOO000 =O0000OO0O00O0O0OO .get ('order_column_list','NA')#line:947
        O0OOO000O0000OO0O =O0000OO0O00O0O0OO .get ('old_column_names','NA').lower ()#line:948
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names','NA').lower ()#line:949
        OO000OO00OO00O000 =Window .partitionBy (*O0O0O00OOO0O0OO0O .split (',')).orderBy (*O0000O000O0OOO000 .split (","))#line:951
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .repartition (*O0O0O00OOO0O0OO0O .split (','))#line:952
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .lead (O0OOO000O0000OO0O ).over (OO000OO00OO00O000 ).alias (OOO0OO00000000OOO ))#line:953
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='lag_value':#line:956
        O0O0O00OOO0O0OO0O =O0000OO0O00O0O0OO .get ('partition_column_names','')#line:958
        O0000O000O0OOO000 =O0000OO0O00O0O0OO .get ('order_column_list','NA')#line:959
        O0OOO000O0000OO0O =O0000OO0O00O0O0OO .get ('old_column_names','NA').lower ()#line:960
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names','NA').lower ()#line:961
        OO000OO00OO00O000 =Window .partitionBy (*O0O0O00OOO0O0OO0O .split (',')).orderBy (*O0000O000O0OOO000 .split (","))#line:963
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .repartition (*O0O0O00OOO0O0OO0O .split (','))#line:964
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .lag (O0OOO000O0000OO0O ).over (OO000OO00OO00O000 ).alias (OOO0OO00000000OOO ))#line:965
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='extract_currency_value':#line:969
        OOOOOOOOOOO0OOOOO =O0000OO0O00O0O0OO .get ('old_column_names','NA').lower ().split (",")#line:971
        O0O000OOO0OO0OO0O =O0000OO0O00O0O0OO .get ('new_column_names','NA').lower ().split (",")#line:972
        for OOO00OO0OOO00OOOO ,O0OOOO00OOOOO0OOO in zip (OOOOOOOOOOO0OOOOO ,O0O000OOO0OO0OO0O ):#line:974
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0OOOO00OOOOO0OOO ),F .regexp_replace (F .col (OOO00OO0OOO00OOOO .strip ()),"[^0-9\.]","").alias (O0OOOO00OOOOO0OOO )).select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0OOOO00OOOOO0OOO ),F .col (O0OOOO00OOOOO0OOO .strip ()).cast ("double").alias (O0OOOO00OOOOO0OOO )).select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0OOOO00OOOOO0OOO ),F .format_number (F .col (O0OOOO00OOOOO0OOO ),2 ).alias (O0OOOO00OOOOO0OOO ))#line:975
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='substring'or O0000OO0O00O0O0OO .get ('type','').lower ()=='sub-string':#line:981
        OOOOOOOOOOO0OOOOO =[O00O000O0O0000OO0 .lower ()for O00O000O0O0000OO0 in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:982
        O0O000OOO0OO0OO0O =[OO00OOO00OO0O0O00 .lower ()for OO00OOO00OO0O0O00 in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:983
        O0OOOO00OO0OO0O00 =O0000OO0O00O0O0OO .get ("parameter",'').strip ().split (":")#line:984
        for O0OO00O00O0000O0O ,O0000O0OO000O00O0 in zip (OOOOOOOOOOO0OOOOO ,O0O000OOO0OO0OO0O ):#line:985
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0000O0OO000O00O0 ),F .substring (F .col (O0OO00O00O0000O0O ).cast ('string'),int (O0OOOO00OO0OO0O00 [0 ]),int (O0OOOO00OO0OO0O00 [1 ])).alias (O0000O0OO000O00O0 ))#line:986
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='concat_columns'or O0000OO0O00O0O0OO .get ('type','').lower ()=='concatcolumns':#line:991
        OOOOOOOOOOO0OOOOO =[OO0O0O0O0OO0OOO0O .lower ()for OO0O0O0O0OO0OOO0O in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:992
        O0O000OOO0OO0OO0O =O0000OO0O00O0O0OO .get ('new_column_names','').lower ()#line:993
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select ("*",F .concat (*OOOOOOOOOOO0OOOOO ).alias (O0O000OOO0OO0OO0O ))#line:994
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='number_format':#line:998
        OOOOOOOOOOO0OOOOO =[O0O0OO00OOO0OOO0O .lower ()for O0O0OO00OOO0OOO0O in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:999
        O0O000OOO0OO0OO0O =[O0000OO0O000O00OO .lower ()for O0000OO0O000O00OO in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:1000
        O0OOOO00OO0OO0O00 =O0000OO0O00O0O0OO .get ("parameter",'')#line:1001
        for O0OO00O00O0000O0O ,O0000O0OO000O00O0 in zip (OOOOOOOOOOO0OOOOO ,O0O000OOO0OO0OO0O ):#line:1002
          if OO0O0O0OOOO000O00 .select (O0OO00O00O0000O0O ).dtypes [0 ][1 ]in ['double','int','decimal','float','long','short']:#line:1003
            OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0000O0OO000O00O0 ),F .format_number (F .col (O0OO00O00O0000O0O ),int (O0OOOO00OO0OO0O00 )).alias (O0000O0OO000O00O0 ))#line:1004
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='filter_rows'or O0000OO0O00O0O0OO .get ('type','').lower ()=='filterrows':#line:1009
        O0OOOO00OO0OO0O00 =O0000OO0O00O0O0OO .get ("parameter",[])#line:1010
        for O0000OO0O00O0O0OO in O0OOOO00OO0OO0O00 :#line:1012
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .filter (O0000OO0O00O0O0OO )#line:1013
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='time_interval':#line:1019
        O00000O0OO0O0O000 =O0000OO0O00O0O0OO .get ('parameter')#line:1020
        O0O0O0OOO0OOO0000 =[O00OO0OOOOO0OO00O .lower ()for O00OO0OOOOO0OO00O in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:1021
        O0O0OOO00000O000O =[O00O00OO00000000O .lower ()for O00O00OO00000000O in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:1022
        for OOO00OO0OOO00OOOO ,O0OOOO00OOOOO0OOO in zip (O0O0O0OOO0OOO0000 ,O0O0OOO00000O000O ):#line:1024
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0OOOO00OOOOO0OOO ),F .expr (f"{OOO00OO0OOO00OOOO} {O00000O0OO0O0O000}").alias (O0OOOO00OOOOO0OOO ))#line:1025
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='date_truncate':#line:1029
        OOOOOOOOOOO0OOOOO =[OOO0OOO0O00OO0O00 .lower ()for OOO0OOO0O00OO0O00 in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:1030
        O0O000OOO0OO0OO0O =[O0OO0OOO0OO0O0O0O .lower ()for O0OO0OOO0OO0O0O0O in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:1031
        O0OOOO00OO0OO0O00 =O0000OO0O00O0O0OO .get ("parameter",'')#line:1032
        for O0OO00O00O0000O0O ,O0000O0OO000O00O0 in zip (OOOOOOOOOOO0OOOOO ,O0O000OOO0OO0OO0O ):#line:1033
          if OO0O0O0OOOO000O00 .select (O0OO00O00O0000O0O ).dtypes [0 ][1 ]in ['string','date','timestamp']:#line:1034
            OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0000O0OO000O00O0 ),F .date_trunc (O0OOOO00OO0OO0O00 ,F .col (O0OO00O00O0000O0O ).cast ('timestamp')).alias (O0000O0OO000O00O0 ))#line:1035
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='convert_to_time':#line:1040
        _O0O0O0000O0O0OOO0 =F .udf (_O0O0OOOOOO00OO00O ,StringType ())#line:1041
        OOOOOOOOOOO0OOOOO =[OO0OOOO0OOOOO0OO0 .lower ()for OO0OOOO0OOOOO0OO0 in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:1043
        O0O000OOO0OO0OO0O =[O0OO0O0OOO00OOOOO .lower ()for O0OO0O0OOO00OOOOO in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:1044
        O0OOOO00OO0OO0O00 =O0000OO0O00O0O0OO .get ("parameter",'yyyy-MM-dd HH:mm:ss')#line:1045
        for O0OO00O00O0000O0O ,O0000O0OO000O00O0 in zip (OOOOOOOOOOO0OOOOO ,O0O000OOO0OO0OO0O ):#line:1046
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0000O0OO000O00O0 ),F .to_timestamp (O0OO00O00O0000O0O .strip (),O0OOOO00OO0OO0O00 ).alias (O0000O0OO000O00O0 ))#line:1048
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='convert_to_date':#line:1052
        _O0O0O0000O0O0OOO0 =F .udf (_O00OOO0OOOOO000O0 ,StringType ())#line:1053
        OOOOOOOOOOO0OOOOO =[OOOOO00O00O0O00O0 .lower ()for OOOOO00O00O0O00O0 in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:1055
        O0O000OOO0OO0OO0O =[O00OOO00O0O00OOOO .lower ()for O00OOO00O0O00OOOO in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:1056
        O0OOOO00OO0OO0O00 =O0000OO0O00O0O0OO .get ("parameter",'yyyy-MM-dd HH:mm:ss')#line:1057
        for O0OO00O00O0000O0O ,O0000O0OO000O00O0 in zip (OOOOOOOOOOO0OOOOO ,O0O000OOO0OO0OO0O ):#line:1058
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0000O0OO000O00O0 ),_O0O0O0000O0O0OOO0 (O0OO00O00O0000O0O ,F .lit (O0OOOO00OO0OO0O00 )).alias (O0000O0OO000O00O0 ))#line:1059
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='multi_date_to_ts':#line:1064
        _OO00000O0O0OO0OOO =F .udf (_O0000000O000O00O0 ,TimestampType ())#line:1065
        OOOOOOOOOOO0OOOOO =[OO000OOO00OOO00OO .lower ()for OO000OOO00OOO00OO in O0000OO0O00O0O0OO .get ('old_column_names','').split (',')]#line:1067
        O0O000OOO0OO0OO0O =[OO0O00000OOOO0O00 .lower ()for OO0O00000OOOO0O00 in O0000OO0O00O0O0OO .get ('new_column_names','').split (',')]#line:1068
        for O0OO00O00O0000O0O ,O0000O0OO000O00O0 in zip (OOOOOOOOOOO0OOOOO ,O0O000OOO0OO0OO0O ):#line:1069
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O0000O0OO000O00O0 ),_OO00000O0O0OO0OOO (F .col (O0OO00O00O0000O0O ).cast ("string")).alias (O0000O0OO000O00O0 ))#line:1070
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='add_hour_column':#line:1075
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names','').strip ()#line:1076
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .expr ("hour(to_timestamp(date_trunc('HOUR', current_timestamp()),'yyyy-MM-dd HH'))").alias (OOO0OO00000000OOO ))#line:1077
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='add_dayofweek_column':#line:1080
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names','').strip ()#line:1081
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .expr ("weekofyear(date_trunc('WEEK', current_date()))").alias (OOO0OO00000000OOO ))#line:1082
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='add_day_column':#line:1085
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names','').strip ()#line:1086
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .expr ("dayofyear(date_trunc('DAY', current_date()))").alias (OOO0OO00000000OOO ))#line:1087
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='add_dayofmonth_column':#line:1090
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names','').strip ()#line:1091
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .expr ("day(date_trunc('DAY', current_date()))").alias (OOO0OO00000000OOO ))#line:1092
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='add_quarter_column':#line:1095
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names','').strip ()#line:1096
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .expr ("quarter(date_trunc('QUARTER', current_date()))").alias (OOO0OO00000000OOO ))#line:1097
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='add_month_column':#line:1100
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names','').strip ()#line:1101
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .expr ("month(date_trunc('MONTH', current_date()))").alias (OOO0OO00000000OOO ))#line:1102
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='add_year_column':#line:1105
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names','').strip ()#line:1106
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .expr ("year(date_trunc('YEAR', current_date()))").alias (OOO0OO00000000OOO ))#line:1107
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='bulk_updates':#line:1114
        O0OOOO00OO0OO0O00 =O0000OO0O00O0O0OO .get ('parameter')#line:1115
        for O0O0O0OOO0O0O000O in O0000OO0O00O0O0OO .get ('column_values',[]):#line:1116
          OOOOOOO0O0000OOO0 =O0O0O0OOO0O0O000O .get ('value')#line:1117
          O000OO00OOOO00OOO =O0O0O0OOO0O0O000O .get ('old_column_names').lower ()#line:1118
          OOO0OO00000000OOO =O0O0O0OOO0O0O000O .get ('new_column_names').lower ()#line:1119
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .expr (f"CASE {O0OOOO00OO0OO0O00} THEN {OOOOOOO0O0000OOO0}  END").alias (OOO0OO00000000OOO ))#line:1120
          O0OO0OO0000O000O0 .append (OOO0OO00000000OOO )#line:1121
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='sql_cases':#line:1126
        O0OOOO00OO0OO0O00 =O0000OO0O00O0O0OO .get ('parameter')#line:1127
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names').strip ()#line:1128
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0OO00000000OOO ),F .expr (O0OOOO00OO0OO0O00 ).alias (OOO0OO00000000OOO ))#line:1129
        O0OO0OO0000O000O0 .append (OOO0OO00000000OOO )#line:1130
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='window_operation':#line:1134
        OO00O000O00OOOO00 ,O0000OO0000OOOO0O =O0000OO0O00O0O0OO .get ('new_column_names').strip ().split (",")#line:1135
        OOOOOOO0O0OO00O0O =O0000OO0O00O0O0OO .get ('old_column_names')#line:1136
        O0OOOO00OO0OO0O00 =O0000OO0O00O0O0OO .get ('parameter')#line:1137
        if O0000OO0000OOOO0O ==None or O0000OO0000OOOO0O .upper ()=='NA':#line:1139
          OO0OO0000OO0OOOOO =Window ().partitionBy (*OOOOOOO0O0OO00O0O .split (","))#line:1140
        else :#line:1142
          OO0OO0000OO0OOOOO =Window ().partitionBy (*OOOOOOO0O0OO00O0O .split (",")).orderBy (O0000OO0000OOOO0O )#line:1143
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (OO0O0O0OOOO000O00 .columns ,OO00O000O00OOOO00 .strip ()),F .expr (O0OOOO00OO0OO0O00 ).over (OO0OO0000OO0OOOOO ).alias (OO00O000O00OOOO00 ))#line:1146
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='convert_string_to_multiple_columns':#line:1149
        O00000O0OO0O0O000 =O0000OO0O00O0O0OO .get ('parameter')#line:1150
        O000OO00OOOO00OOO =(O0000OO0O00O0O0OO .get ('column_values',[])[0 ]).get ('old_column_names','NA')#line:1151
        _OO0O0OOO00OO0OOO0 =F .split (O000OO00OOOO00OOO ,O00000O0OO0O0O000 )#line:1152
        for OOOOOOOO00000O0OO ,O0O0O0OOO0O0O000O in zip (range (len (O0000OO0O00O0O0OO .get ('column_values',[]))),O0000OO0O00O0O0OO .get ('column_values',[])):#line:1154
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select ("*",F .regexp_extract (_OO0O0OOO00OO0OOO0 .getItem (OOOOOOOO00000O0OO ),O0O0O0OOO0O0O000O .get ('value'),int (O0O0O0OOO0O0O000O .get ('additional_params'))).alias (O0O0O0OOO0O0O000O .get ('new_column_names'))).withColumn (O0O0O0OOO0O0O000O .get ('new_column_names'),F .trim (F .col (O0O0O0OOO0O0O000O .get ('new_column_names'))))#line:1155
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='convert_json_to_multiple_columns':#line:1160
        O00000O0OO0O0O000 =O0000OO0O00O0O0OO .get ('parameter').lower ()#line:1161
        OO000OO0OOO0OOOO0 =[]#line:1162
        for O0O0O0OOO0O0O000O in O0000OO0O00O0O0OO .get ("column_values"):#line:1163
          OO000OO0OOO0OOOO0 .append (StructField (O0O0O0OOO0O0O000O .get ('old_column_names'),_OOO000OO000000000 .get (O0O0O0OOO0O0O000O .get ('value').lower ()),False ))#line:1164
        O00OO0OOO0O00O00O =StructType (OO000OO0OOO0OOOO0 )#line:1166
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .withColumn ("__idf_data",F .from_json (O00000O0OO0O0O000 ,O00OO0OOO0O00O00O )).select (*O0OO0OO0000O000O0 ,F .col ('__idf_data.*'))#line:1167
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='pivot_tables_with_group':#line:1171
        O000O0OO00OOOOOOO =O0000OO0O00O0O0OO .get ("group_by_columns","").split (",")#line:1173
        O000OOO00000OO0O0 =O0000OO0O00O0O0OO .get ("pivot_column","")#line:1174
        OOOO00O000O0OO0O0 =O0000OO0O00O0O0OO .get ("new_column_name","")#line:1175
        OO0OO0OO000O0O000 =O0000OO0O00O0O0OO .get ("new_column_aggregation","")#line:1176
        O0O0OOO0O000OO0O0 =O0000OO0O00O0O0OO .get ("pivot_distinct_column_names","")#line:1177
        O00000OO0OOO0000O ={OOOO00O000O0OO0O0 :OO0OO0OO000O0O000 }#line:1178
        OOOO0OO0O0OOOOO00 =list (map (lambda O00OOO0000O0OOO00 :F .expr (O00OOO0000O0OOO00 [1 ]).alias (O00OOO0000O0OOO00 [0 ]),O00000OO0OOO0000O .items ()))#line:1180
        if O0O0OOO0O000OO0O0 ==None or O0O0OOO0O000OO0O0 .upper ()=="NA":#line:1182
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .groupby (*O000O0OO00OOOOOOO ).pivot (O000OOO00000OO0O0 ).agg (*OOOO0OO0O0OOOOO00 )#line:1183
        else :#line:1185
          O0O0OOO0O000OO0O0 =O0000OO0O00O0O0OO .get ("pivot_distinct_column_names","").split (",")#line:1186
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .groupby (*O000O0OO00OOOOOOO ).pivot (O000OOO00000OO0O0 ,O0O0OOO0O000OO0O0 ).agg (*OOOO0OO0O0OOOOO00 )#line:1187
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='melt_data_wide_to_narrow':#line:1193
        OO00000OOOO00000O =O0000OO0O00O0O0OO .get ("index_columns","").split (",")#line:1195
        OOO00O00OO00000OO =O0000OO0O00O0O0OO .get ("columns_to_melt","").split (",")#line:1196
        OO0O00O00OOOOOO00 =O0000OO0O00O0O0OO .get ("key_column_name","")#line:1197
        OOOOO0O00OOOO00OO =O0000OO0O00O0O0OO .get ("value_column_name","")#line:1198
        OO00OO000O000OO0O =F .create_map (list (chain .from_iterable ([[F .lit (O00OO00OOO000OO00 ),F .col (O00OO00OOO000OO00 )]for O00OO00OOO000OO00 in OOO00O00OO00000OO ])))#line:1204
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*OO00000OOOO00000O ,F .explode (OO00OO000O000OO0O )).withColumnRenamed ('key',OO0O00O00OOOOOO00 ).withColumnRenamed ('value',OOOOO0O00OOOO00OO )#line:1206
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='impute_last_nonnull_within_group':#line:1210
        {"type":"impute_last_nonnull_within_group","old_column_names":"value column","new_column_names":"partition columns separated by comma","parameter":"order column, format of order column"}#line:1212
        OOO0O0OO00OO0OOOO =O0000OO0O00O0O0OO .get ("old_column_names",'NA').lower ()#line:1214
        O0O0O00OOO0O0OO0O =O0000OO0O00O0O0OO .get ("partition_column_names","NA").lower ().split (",")#line:1215
        O00O0OO00O0O00O0O ,OO000000O00000OOO =O0000OO0O00O0O0OO .get ("parameter","NA").lower ().split (',')#line:1216
        OO0OO0000OO0OOOOO =Window .partitionBy (*O0O0O00OOO0O0OO0O ).orderBy (O00O0OO00O0O00O0O )#line:1218
        OO0OOOO00OOO00O0O =Window .partitionBy (*(O0O0O00OOO0O0OO0O +['__idf_rank1'])).orderBy (O00O0OO00O0O00O0O )#line:1219
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0O0OO00OO0OOOO ),F .when (F .col (OOO0O0OO00OO0OOOO ).isNull (),F .lit (0 )).otherwise (F .col (OOO0O0OO00OO0OOOO )).alias (OOO0O0OO00OO0OOOO )).select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,O00O0OO00O0O00O0O ),F .to_date (F .col (O00O0OO00O0O00O0O ).cast ('string'),OO000000O00000OOO ).alias (O00O0OO00O0O00O0O ))#line:1221
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select ("*",F .when (F .col (OOO0O0OO00OO0OOOO )!=0 ,F .rank ().over (OO0OO0000OO0OOOOO )).otherwise (F .lit (0 )).alias ("__idf_rank1")).select (*_OOO0OO0OOO0OO0OO0 (OO0O0O0OOOO000O00 .columns ,'__idf_rank1'),F .sum ('__idf_rank1').over (OO0OO0000OO0OOOOO ).alias ('__idf_rank1')).select (*_OOO0OO0OOO0OO0OO0 (OO0O0O0OOOO000O00 .columns ,OOO0O0OO00OO0OOOO ),F .sum (OOO0O0OO00OO0OOOO ).over (OO0OOOO00OOO00O0O ).alias (OOO0O0OO00OO0OOOO ))#line:1223
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='greedy_correction':#line:1230
        OO00OO00000000OOO =[OOOO00O0000O00O00 .lower ()for OOOO00O0000O00O00 in O0000OO0O00O0O0OO .get ('partition_column_names',"").split (",")]#line:1231
        OOO0O0OO00OO0OOOO =O0000OO0O00O0O0OO .get ('column_to_correct',"")#line:1232
        OO0OO0000OO0OOOOO =Window ().partitionBy (*(OO00OO00000000OOO +[OOO0O0OO00OO0OOOO ]))#line:1234
        OO0OOOO00OOO00O0O =Window ().partitionBy (*OO00OO00000000OOO ).orderBy (F .desc ('__idf_overall_count1'))#line:1235
        OOO00000O0000O000 =Window ().partitionBy (*OO00OO00000000OOO ).orderBy ('__idf_overall_count2')#line:1236
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select ("*",F .count (OOO0O0OO00OO0OOOO ).over (OO0OO0000OO0OOOOO ).alias ('__idf_overall_count1')).select ("*",F .rank ().over (OO0OOOO00OOO00O0O ).alias ('__idf_overall_count2')).select ("*",F .when (F .col ("__idf_overall_count2")==F .lit (1 ),F .col (OOO0O0OO00OO0OOOO )).otherwise (F .lit (None )).alias ('__idf_overall_count3')).select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0O0OO00OO0OOOO ),F .when (F .col ('__idf_overall_count3').isNull (),F .lag ('__idf_overall_count3').over (OOO00000O0000O000 )).otherwise (F .col ('__idf_overall_count3')).alias (OOO0O0OO00OO0OOOO ))#line:1238
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='clustering_correction':#line:1242
        OOO0O0OO00OO0OOOO =O0000OO0O00O0O0OO .get ('column_to_correct',"").lower ()#line:1243
        OO0000O0OOOOO0000 =sparkclean .DataFrameDeduplicator (OO0O0O0OOOO000O00 )#line:1245
        OOO0O0OO0000O0O00 ,O000O0OOOOO000O0O =OO0000O0OOOOO0000 .keyCollisionClustering (OOO0O0OO00OO0OOOO )#line:1246
        O0OOO00OO0OOOOO0O =OO0000O0OOOOO0000 .preview (OOO0O0OO0000O0O00 ,O000O0OOOOO000O0O )#line:1247
        try :#line:1248
          OO0000O0OOOOO0000 .resolve (OOO0O0OO0000O0O00 ,O000O0OOOOO000O0O )#line:1249
          OO0O0O0OOOO000O00 =OO0000O0OOOOO0000 .get_dataframe ()#line:1250
        except :#line:1252
          pass #line:1253
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='similarity_correction':#line:1258
        OOO0O0OO00OO0OOOO =O0000OO0O00O0O0OO .get ('column_to_correct',"").lower ()#line:1261
        OOO0O00OO00OO0O0O =int (O0000OO0O00O0O0OO .get ('parameter',"").split (",")[0 ])#line:1262
        O000O00OOOOO00O00 =float (O0000OO0O00O0O0OO .get ('parameter',"").split (",")[1 ])#line:1263
        OO0000O0OOOOO0000 =sparkclean .DataFrameDeduplicator (OO0O0O0OOOO000O00 )#line:1265
        OOO0O0OO0000O0O00 ,O000O0OOOOO000O0O =OO0000O0OOOOO0000 .localitySensitiveHashing (OOO0O0OO00OO0OOOO ,blockSize =OOO0O00OO00OO0O0O ,method ="levenshtein",threshold =O000O00OOOOO00O00 )#line:1266
        try :#line:1268
          OO0000O0OOOOO0000 .resolve (OOO0O0OO0000O0O00 ,O000O0OOOOO000O0O )#line:1269
          OO0O0O0OOOO000O00 =OO0000O0OOOOO0000 .get_dataframe ()#line:1270
        except :#line:1272
          pass #line:1273
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='record_match_correction':#line:1278
        OOO0O0OO00OO0OOOO =O0000OO0O00O0O0OO .get ('column_to_correct',"").lower ().split (",")#line:1281
        O0OOO0O00O00O0O0O =[O000O00OOO00O0O0O .lower ()for O000O00OOO00O0O0O in O0000OO0O00O0O0OO .get ('partition_column_names',"").split (",")]#line:1282
        OO0000O0OOOOO0000 =sparkclean .DataFrameDeduplicator (OO0O0O0OOOO000O00 )#line:1284
        OOO0O0OO0000O0O00 ,O000O0OOOOO000O0O =OO0000O0OOOOO0000 .recordMatching (matchColNames =O0OOO0O00O00O0O0O ,fixColNames =OOO0O0OO00OO0OOOO )#line:1285
        try :#line:1286
          OO0000O0OOOOO0000 .resolveRecords (OOO0O0OO0000O0O00 ,O000O0OOOOO000O0O )#line:1287
          OO0O0O0OOOO000O00 =OO0000O0OOOOO0000 .get_dataframe ()#line:1288
        except :#line:1290
          pass #line:1291
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='fuzzy_match':#line:1296
        """
        getBestFuzzyMatch_fn(input_df, 'country',3)
        Works with column length of 3 or more
        Ensure standardization is taken care of 
        max_distance_threshold = number of character diff. e.g in integers
        """#line:1302
        OO00O000O00OOOO00 =O0000OO0O00O0O0OO .get ('old_column_names').lower ()#line:1304
        OOO0OO00000000OOO =O0000OO0O00O0O0OO .get ('new_column_names').lower ()#line:1305
        OOOO00OOOOOOOO00O =int (O0000OO0O00O0O0OO .get ('parameter'))#line:1306
        def _O0OO0OOOOO000O00O (OOO000OOO00OOOOO0 ):#line:1308
          OO0OO0000OOO000O0 =OOO0O0O00O0OOO0OO .value #line:1309
          O0000OOO00O000000 =-1 #line:1310
          O0O00OO0O00O00O0O =None #line:1311
          for O0OO0OO0OO00O0O00 in OOO000OOO00OOOOO0 :#line:1313
            O0OO0OO0000O0O0OO =OO0OO0000OOO000O0 .get (O0OO0OO0OO00O0O00 )#line:1314
            if O0OO0OO0000O0O0OO >O0000OOO00O000000 :#line:1315
              O0O00OO0O00O00O0O =O0OO0OO0OO00O0O00 #line:1316
              O0000OOO00O000000 =O0OO0OO0000O0O0OO #line:1317
          return O0O00OO0O00O00O0O #line:1321
        _OOOOOOO0O000OO000 =F .udf (_O0OO0OOOOO000O00O ,StringType ())#line:1323
        OOO0O0000OOOO00OO =[(O000O0O00OOO0OO00 [0 ],O000O0O00OOO0OO00 [1 ])for O000O0O00OOO0OO00 in list (map (lambda OOO0O0OO00O0O0O00 :(OOO0O0OO00O0O0O00 .get (OO00O000O00OOOO00 ),OOO0O0OO00O0O0O00 .get ('count')),[O0O0OO0OOOOO0OO00 .asDict ()for O0O0OO0OOOOO0OO00 in OO0O0O0OOOO000O00 .groupby (OO00O000O00OOOO00 ).count ().collect ()]))]#line:1325
        O0O0000000OO0O0O0 ={}#line:1326
        O0O0000000OO0O0O0 .update (OOO0O0000OOOO00OO )#line:1327
        if None in O0O0000000OO0O0O0 :#line:1329
          del O0O0000000OO0O0O0 [None ]#line:1330
        OOO0O0O00O0OOO0OO =OOO0O0O0O000OO0OO .sparkContext .broadcast (O0O0000000OO0O0O0 )#line:1333
        O00O0OOO00OO0OO0O ="{column_name}_first3".format (column_name =OO00O000O00OOOO00 )#line:1335
        O0O0O0OO0OO000O00 =OO0O0O0OOOO000O00 .withColumn (O00O0OOO00OO0OO0O ,F .soundex (F .col (OO00O000O00OOOO00 )))#line:1336
        O0O0O0OO0OO000O00 =O0O0O0OO0OO000O00 .alias ('l').join (O0O0O0OO0OO000O00 .alias ('r'),O0O0O0OO0OO000O00 [O00O0OOO00OO0OO0O ]==O0O0O0OO0OO000O00 [O00O0OOO00OO0OO0O ],how ='inner').select ('l.{column_name}'.format (column_name =OO00O000O00OOOO00 ),'l.{first3_col_name}'.format (first3_col_name =O00O0OOO00OO0OO0O ),'r.{column_name}'.format (column_name =OO00O000O00OOOO00 )).drop_duplicates ().filter ("l.{column_name} != r.{column_name}".format (column_name =OO00O000O00OOOO00 ))#line:1338
        O0O0O0OO0OO000O00 =O0O0O0OO0OO000O00 .withColumn ('distance',F .levenshtein (F .col ("l.{column_name}".format (column_name =OO00O000O00OOOO00 )),F .col ("r.{column_name}".format (column_name =OO00O000O00OOOO00 )))).withColumn ('distance',F .when (F .col ('distance')<=F .lit (OOOO00OOOOOOOO00O ),0 )).groupby (*[O00O0OOO00OO0OO0O ,'distance']).agg (F .collect_list ("r.{column_name}".format (column_name =OO00O000O00OOOO00 )).alias ('original_{column_name}'.format (column_name =OO00O000O00OOOO00 )))#line:1340
        O0O0O0OO0OO000O00 =O0O0O0OO0OO000O00 .withColumn ('{column_name}_best_match'.format (column_name =OO00O000O00OOOO00 ),_OOOOOOO0O000OO000 ('original_{column_name}'.format (column_name =OO00O000O00OOOO00 ))).select ('{column_name}_best_match'.format (column_name =OO00O000O00OOOO00 ),F .explode ('original_{column_name}'.format (column_name =OO00O000O00OOOO00 )).alias ('original_{column_name}'.format (column_name =OO00O000O00OOOO00 )))#line:1342
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .join (O0O0O0OO0OO000O00 ,OO0O0O0OOOO000O00 [OO00O000O00OOOO00 ]==O0O0O0OO0OO000O00 ['original_{column_name}'.format (column_name =OO00O000O00OOOO00 )],how ='left').select (OO0O0O0OOOO000O00 ['*'],O0O0O0OO0OO000O00 ['{column_name}_best_match'.format (column_name =OO00O000O00OOOO00 )]).withColumn ('{column_name}_best_match'.format (column_name =OO00O000O00OOOO00 ),F .when (F .col ('{column_name}_best_match'.format (column_name =OO00O000O00OOOO00 )).isNull (),F .col (OO00O000O00OOOO00 )).otherwise (F .col ('{column_name}_best_match'.format (column_name =OO00O000O00OOOO00 ))))#line:1344
        OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .withColumnRenamed ('{column_name}_best_match'.format (column_name =OO00O000O00OOOO00 ),OOO0OO00000000OOO )#line:1345
        OOO0O0O00O0OOO0OO .unpersist (blocking =True )#line:1347
        O0O0O0OO0OO000O00 =None #line:1349
      elif O0000OO0O00O0O0OO .get ('type','').lower ()=='anonymize_by_tags':#line:1352
        OOOOOOOOOOO0OOOOO =O0000OO0O00O0O0OO .get ('old_column_names','NA').lower ()#line:1353
        O0O000OOO0OO0OO0O =O0000OO0O00O0O0OO .get ('new_column_names','NA').lower ()#line:1354
        O00000O0OO0O0O000 =O0000OO0O00O0O0OO .get ('parameter','NA').lower ()#line:1355
        if O00000O0OO0O0O000 .lower ()=='base64'or O00000O0OO0O0O000 .lower ()=='base':#line:1357
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOOOOOOOOOO0OOOOO .strip ()),F .base64 (F .col (O0O000OOO0OO0OO0O )).alias (O0O000OOO0OO0OO0O .strip ()))#line:1358
        elif O00000O0OO0O0O000 .lower ()=='hex':#line:1360
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOOOOOOOOOO0OOOOO .strip ()),F .hex (F .col (O0O000OOO0OO0OO0O )).alias (O0O000OOO0OO0OO0O .strip ()))#line:1361
        elif O00000O0OO0O0O000 .lower ()=='sha1':#line:1363
          OO0O0O0OOOO000O00 =OO0O0O0OOOO000O00 .select (*_OOO0OO0OOO0OO0OO0 (O0OO0OO0000O000O0 ,OOO0O0OO0000O0O00 .strip ()),F .sha1 (F .col (O0O000OOO0OO0OO0O )).alias (O0O000OOO0OO0OO0O .strip ()))#line:1364
      return OO0O0O0OOOO000O00 #line:1370
    finally :#line:1372
      OO0O0O0OOOO000O00 =None #line:1373

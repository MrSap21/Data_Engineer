# Databricks notebook source
# Databricks notebook source
#JPM#import sys
import re

classificationMap = {}

# COMMAND ----------

#######COMMON
#EMAIL
classificationMap[re.compile(r'^[_A-Za-z0-9-\\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$',re.I|re.M)] =  "PII"
#SSN
classificationMap[re.compile(r'^(?!000|666)[0-9]{3}([ -]?)(?!00)[0-9]{2}\1(?!0000)[0-9]{4}$',re.I|re.M)] =  "PII"
#CREDIT CARD
classificationMap[re.compile(r'^(4[0-9]{12}(?:[0-9]{3})?)|((?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|(6(?:011|5[0-9]{2})[0-9]{12})|((?:2131|1800|35\d{3})\d{11})$',re.I|re.M)] = "PII"


# Databricks notebook source
import os #line:2
import sys #line:3
import re #line:4
#JPM#import json #line:5
import traceback #line:6
#JPM#import uuid #line:7
from datetime import datetime #JPM#,timedelta #line:8
import pytz #line:9
from dateutil .relativedelta import relativedelta #line:10
#JPM#from typing import Iterable #line:11
from itertools import *#line:12
from functools import wraps #line:13
#JPM#from inspect import getcallargs ,getargspec #line:14
#JPM#from collections import OrderedDict ,Iterable #line:15
import logging #line:16
#JPM#import boto3 #line:18
#JPM#import pyspark #line:20
#JPM#from pyspark .sql import SparkSession ,Row #line:21
#JPM#from pyspark .sql import SQLContext ,DataFrame #line:22
#JPM#from pyspark .sql .types import *#line:23
import pyspark .sql .functions as F #line:24
from pyspark .sql .window import Window #line:25
#from CommonBase import *#line:27
RECORDER_SPARK_BASE1 =[]#line:31
def log_to (OOO0O0OO00O0OOO0O ):#line:32
    def OOO0OOOO0OO0O000O (O00OOOO00OO0O00O0 ):#line:33
      @wraps (O00OOOO00OO0O00O0 )#line:34
      def O0OO00O000OO00000 (*O0O000O0O0O0OOOOO ,**O0O0O0OOO00O00O0O ):#line:35
        try :#line:36
          RECORDER_SPARK_BASE1 .append ("Function Name : {func_name} ; Time : {time} ; Arguments :  {args}".format (func_name =O00OOOO00OO0O00O0 .__name__ ,time =str (datetime .now ()),args =O0O000O0O0O0OOOOO ))#line:37
          return O00OOOO00OO0O00O0 (*O0O000O0O0O0OOOOO ,**O0O0O0OOO00O00O0O )#line:38
        except :#line:40
          RECORDER_SPARK_BASE1 .append ("IDF_Exception :  {exception} : {trace}".format (exception =sys .exc_info ()[0 ],trace =traceback .format_exc ()))#line:41
      return O0OO00O000OO00000 #line:44
    return OOO0OOOO0OO0O000O #line:46
logdebug =log_to (logging .debug )#line:48

class RulesEngineBaseClass (object ):#line:52
  def class_type (OO00OOO0O0O0O00OO ):#line:53
    print ("RulesEngineBaseClass")#line:54
class RulesEnginePredefinedClass (RulesEngineBaseClass ):#line:60
  @logdebug #line:61
  def standardizeColumnsByPredefinedRule_fn (O0OOOOO00O0OOOO00 ,OO0OOOOOO00O0OOOO ,OO000OOO000O0O00O ,OO0OO0O0O0OOOO0OO ,OO00O0OOO0OO0O00O ):#line:62
      ""#line:65
      try :#line:66
        OO0OO0O0O0OOOO0OO =[O0O0000OOOOO0O000 .lower ()for O0O0000OOOOO0O000 in OO0OO0O0O0OOOO0OO ]#line:67
        if "UPPER"==OO000OOO000O0O00O .upper ():#line:69
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:70
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .upper (F .col (O0OOO0O00000OOOO0 .strip ())).alias (O0OOO0O00000OOOO0 .strip ()))#line:71
        elif "LOWER"==OO000OOO000O0O00O .upper ():#line:75
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:76
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .lower (F .col (O0OOO0O00000OOOO0 .strip ())).alias (O0OOO0O00000OOOO0 .strip ()))#line:77
        elif "TRIM"==OO000OOO000O0O00O .upper ():#line:81
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:82
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .trim (F .col (O0OOO0O00000OOOO0 .strip ())).alias (O0OOO0O00000OOOO0 .strip ()))#line:84
        elif "TRIM_ALL"==OO000OOO000O0O00O .upper ():#line:87
            OO0O0OO0O00OO0OOO ={OO00000O0OO0OO00O .name :OO00000O0OO0OO00O .dataType .typeName ().lower ()for OO00000O0OO0OO00O in OO0OOOOOO00O0OOOO .schema .fields }#line:88
            OO0OO0O0O0OOOO0OO =list (filter (lambda OOO000OO0O0O00O00 :OOO000OO0O0O00O00 [1 ]=='string',OO0O0OO0O00OO0OOO .items ()))#line:89
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:90
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 [0 ].strip ()),F .trim (F .col (O0OOO0O00000OOOO0 [0 ].strip ())).alias (O0OOO0O00000OOOO0 [0 ].strip ()))#line:92
        elif "ASCII"==OO000OOO000O0O00O .upper ():#line:95
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:96
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .decode (F .col (O0OOO0O00000OOOO0 .strip ()),'ASCII').alias (O0OOO0O00000OOOO0 .strip ()))#line:98
        elif "ASCII_ALL"==OO000OOO000O0O00O .upper ():#line:101
            OOO000OO00O00OOO0 =OO0OOOOOO00O0OOOO .dtypes #line:102
            OO0OO0O0O0OOOO0OO =list (filter (lambda O0O0OOO00000000O0 :O0O0OOO00000000O0 [1 ].lower ()=='string',OOO000OO00O00OOO0 ))#line:103
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:104
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 [0 ].strip ()),F .decode (F .col (O0OOO0O00000OOOO0 [0 ].strip ()),'ASCII').alias (O0OOO0O00000OOOO0 [0 ].strip ()))#line:106
        elif "CAMEL_CASE"==OO000OOO000O0O00O .upper ():#line:109
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:110
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .initcap (F .col (O0OOO0O00000OOOO0 .strip ())).alias (O0OOO0O00000OOOO0 .strip ()))#line:112
        elif "NUMERIC_ONLY"==OO000OOO000O0O00O .upper ():#line:115
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:116
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .regexp_replace (F .col (O0OOO0O00000OOOO0 .strip ()),r"[^0-9]","").alias (O0OOO0O00000OOOO0 .strip ()))#line:118
        elif "NUMERIC_WITH_DECIMAL_ONLY"==OO000OOO000O0O00O .upper ():#line:121
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:122
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .regexp_replace (F .col (O0OOO0O00000OOOO0 .strip ()),r"[^0-9.]","").alias (O0OOO0O00000OOOO0 .strip ()))#line:124
        elif "NONNUMERIC_ONLY"==OO000OOO000O0O00O .upper ():#line:127
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:128
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .regexp_replace (F .col (O0OOO0O00000OOOO0 .strip ()),r"[0-9]","").alias (O0OOO0O00000OOOO0 .strip ()))#line:130
        elif "CHARACTERS_ONLY"==OO000OOO000O0O00O .upper ():#line:133
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:134
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .regexp_replace (F .col (O0OOO0O00000OOOO0 .strip ()),r"[^a-zA-Z]","").alias (O0OOO0O00000OOOO0 .strip ()))#line:136
        elif "WITHOUT_SPECIAL_CHARACTERS"==OO000OOO000O0O00O .upper ():#line:139
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:140
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .regexp_replace (F .col (O0OOO0O00000OOOO0 .strip ()),r"[^0-9a-zA-Z]","").alias (O0OOO0O00000OOOO0 .strip ()))#line:142
        elif "MULTI_WHITESPACE_2_SINGLE"==OO000OOO000O0O00O .upper ():#line:145
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:146
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .regexp_replace (F .col (O0OOO0O00000OOOO0 .strip ())," {2,}"," ").alias (O0OOO0O00000OOOO0 .strip ()))#line:148
        elif "MULTI_WHITESPACE_2_SINGLE_ALL"==OO000OOO000O0O00O .upper ():#line:151
            OOO000OO00O00OOO0 =OO0OOOOOO00O0OOOO .dtypes #line:152
            OO0OO0O0O0OOOO0OO =list (filter (lambda O00OO0OO0O0O0000O :O00OO0OO0O0O0000O [1 ].lower ()=='string',OOO000OO00O00OOO0 ))#line:153
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:154
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .regexp_replace (F .col (O0OOO0O00000OOOO0 .strip ())," {2,}"," ").alias (O0OOO0O00000OOOO0 .strip ()))#line:156
        elif "EPOCH_2_DATE"==OO000OOO000O0O00O .upper ():#line:159
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:160
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .col (O0OOO0O00000OOOO0 .strip ()).cast ('string').substr (1 ,10 ).cast ('long').alias (O0OOO0O00000OOOO0 .strip ()))#line:163
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()).cast (TimestampType ())).alias (O0OOO0O00000OOOO0 .strip ()))#line:164
        elif "DD-MM-YYYY_2_DATE"==OO000OOO000O0O00O .upper ():#line:167
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:168
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()).cast ('string'),'dd-MM-yyyy').alias (O0OOO0O00000OOOO0 .strip ()))#line:170
        elif "MM-DD-YYYY_2_DATE"==OO000OOO000O0O00O .upper ():#line:173
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:174
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()).cast ('string'),'MM-dd-yyyy').alias (O0OOO0O00000OOOO0 .strip ()))#line:176
        elif "YYYY-MM-DD_2_DATE"==OO000OOO000O0O00O .upper ():#line:179
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:180
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()).cast ('string'),'yyyy-MM-dd').alias (O0OOO0O00000OOOO0 .strip ()))#line:182
        elif "YYYYMMDD_2_DATE"==OO000OOO000O0O00O .upper ():#line:185
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:186
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()).cast ('string'),'yyyyMMdd').alias (O0OOO0O00000OOOO0 .strip ()))#line:188
        elif "MULTI_FORMAT_TS"==OO000OOO000O0O00O .upper ():#line:191
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:192
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .coalesce (F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'yyyy-MM-dd HH:mm:SS'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'yyyy/MM/dd HH:mm:SS'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'yyyy/MM/dd HH:mm'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'MM/dd/yyyy HH:mm:SS'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'MM/dd/yyyy HH:mm'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'MM-dd-yyyy HH:mm:SS'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'dd/MM/yyyy HH:mm:SS'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'dd-MM-yyyy HH:mm:SS'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'dd-MM-yyyy HH:mm')).alias (O0OOO0O00000OOOO0 .strip ()))#line:203
        elif "MULTI_FORMAT_DATE"==OO000OOO000O0O00O .upper ():#line:206
            for O0OOO0O00000OOOO0 in OO0OO0O0O0OOOO0OO :#line:207
                OO0OOOOOO00O0OOOO =OO0OOOOOO00O0OOOO .select (*filter_column_names (OO00O0OOO0OO0O00O ,O0OOO0O00000OOOO0 .strip ()),F .coalesce (F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'yyyy-MM-dd'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'yyyy/MM/dd'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'MM/dd/yyyy'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'MM-dd-yyyy'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'dd/MM/yyyy'),F .to_timestamp (F .col (O0OOO0O00000OOOO0 .strip ()),'dd-MM-yyyy')).alias (O0OOO0O00000OOOO0 .strip ()))#line:215
        return OO0OOOOOO00O0OOOO #line:218
      finally :#line:220
        OO0OOOOOO00O0OOOO =None #line:221
class RulesEngineExpressionClass (RulesEngineBaseClass ):#line:228
  @logdebug #line:229
  def standardizeColumnsByExpressionRule_fn (O0OO0OO0OOO0000O0 ,O0OOOO0000OOO0O00 ,O0OOOOO0000000OO0 ,O00O0OOO0OO00OOOO ,OO000OOO0OO00O0O0 ,OOOO0O0O000000OO0 ,O0O0O00000O0O00OO ):#line:230
    ""#line:241
    try :#line:242
      O00O0OOO0OO00OOOO =[OO00O0O0OO00OOOO0 .lower ()for OO00O0O0OO00OOOO0 in O00O0OOO0OO00OOOO ]#line:243
      def _OOOO0OOO0OOO0O0O0 (O0O0O00000OO00OOO ,OO0OO0OO0OO000000 ):#line:245
          if O0O0O00000OO00OOO ==None :#line:246
            return O0O0O00000OO00OOO #line:247
          OO0OO0OO0OO000000 =str ("".join (OO0OO0OO0OO000000 [0 ]))#line:249
          return eval ("f'"+OO0OO0OO0OO000000 .replace ('$','O0O0O00000OO00OOO')+"'")#line:250
      def O00O0OOO0O0OOOOOO (OOO000O0OOO00O00O ):#line:253
          OOO0OOOO0OO000OOO ={'MM':'%m','dd':'%d','yyyy':'%Y','HH':'%H','mm':'%M','ss':'%s'}#line:262
          for O00OO00O00OO00O0O ,O00000OO0OOO0O000 in OOO0OOOO0OO000OOO .items ():#line:263
              OOO000O0OOO00O00O =OOO000O0OOO00O00O .replace (O00OO00O00OO00O0O ,O00000OO0OOO0O000 )#line:264
          return OOO000O0OOO00O00O #line:267
      if O0OOOOO0000000OO0 .lower ()=='regex_replace':#line:270
        for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:271
          O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .regexp_replace (F .col (OO0O0O0OOO00OO00O ),OO000OOO0OO00O0O0 ,OOOO0O0O000000OO0 ).alias (OO0O0O0OOO00OO00O .strip ()))#line:273
      elif O0OOOOO0000000OO0 .lower ()=='date_format':#line:276
        for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:277
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .to_timestamp (F .col (OO0O0O0OOO00OO00O .strip ()).cast ('string'),OO000OOO0OO00O0O0 ).alias (OO0O0O0OOO00OO00O .strip ()))#line:279
      elif O0OOOOO0000000OO0 .lower ()=='date_utc_conversion':#line:282
        OO0OOOOOOOOO00O0O =pytz .timezone (OOOO0O0O000000OO0 )#line:283
        OO000OOO0OO00O0O0 =O00O0OOO0O0OOOOOO (OO000OOO0OO00O0O0 )#line:284
        _O0OOOO0OO000O0OOO =F .udf (lambda O0OO00OOOOOO0O0OO :str (OO0OOOOOOOOO00O0O .localize (datetime .strptime (O0OO00OOOOOO0O0OO ,OO000OOO0OO00O0O0 ))),StringType ())#line:285
        for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:286
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),_O0OOOO0OO000O0OOO (F .col (OO0O0O0OOO00OO00O .strip ()).cast ('string')).alias (OO0O0O0OOO00OO00O .strip ()))#line:288
      elif O0OOOOO0000000OO0 .lower ()=='string_format':#line:292
        OOO0OO00O0O0O0O0O =F .udf (_OOOO0OOO0OOO0O0O0 ,StringType ())#line:293
        OO0OOOO000O0O0OO0 =[]#line:295
        OO0OOOO000O0O0OO0 .append (OO000OOO0OO00O0O0 )#line:296
        O0000OOO0O000O00O =F .array (*[F .array (*[F .lit (O0000OO00O000OO0O )])for O0000OO00O000OO0O in OO0OOOO000O0O0OO0 ])#line:297
        for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:299
          O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),OOO0OO00O0O0O0O0O (F .col (OO0O0O0OOO00OO00O ).cast ('string'),O0000OOO0O000O00O ).alias (OO0O0O0OOO00OO00O .strip ()))#line:301
      elif O0OOOOO0000000OO0 .lower ()=='impute_data':#line:305
        O00O0OOO0OO00OOOO =[OO0O0OOO0O000O00O [0 ]for OO0O0OOO0O000O00O in list (filter (lambda O0OOO00OOO0OOO000 :O0OOO00OOO0OOO000 [1 ]in ['double','int','decimal','float','long','short'],O0OOOO0000OOO0O00 .select (*O00O0OOO0OO00OOOO ).dtypes ))]#line:306
        OO000OOO0OO00O0O0 =OO000OOO0OO00O0O0 .lower ()#line:307
        for O000O00O00O0O0O0O in O00O0OOO0OO00OOOO :#line:309
          if OO000OOO0OO00O0O0 =='avg'or OO000OOO0OO00O0O0 =='mean'or OO000OOO0OO00O0O0 =='average':#line:310
              OO00000O000000O00 =O0OOOO0000OOO0O00 .groupBy ().avg (O000O00O00O0O0O0O ).collect ()[0 ][0 ]#line:311
              O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,O000O00O00O0O0O0O .strip ()),F .when (F .isnan (O000O00O00O0O0O0O )|F .isnull (O000O00O00O0O0O0O ),F .lit (OO00000O000000O00 )).otherwise (F .col (O000O00O00O0O0O0O )).alias (O000O00O00O0O0O0O .strip ()))#line:313
          elif OO000OOO0OO00O0O0 =='median':#line:315
              OOOO0O0O0OO0O0000 =O0OOOO0000OOO0O00 .withColumn (O000O00O00O0O0O0O ,inputDF [O000O00O00O0O0O0O ]).approxQuantile (O000O00O00O0O0O0O ,[0.5 ],0.25 )[0 ]#line:316
              O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,O000O00O00O0O0O0O .strip ()),F .when (isnan (O000O00O00O0O0O0O )|F .isnull (O000O00O00O0O0O0O ),F .lit (OOOO0O0O0OO0O0000 )).otherwise (F .col (O000O00O00O0O0O0O )).alias (O000O00O00O0O0O0O .strip ()))#line:318
          elif OO000OOO0OO00O0O0 =='mode':#line:321
              OOOOO0O0OO0O000O0 =inputDF .stat .freqItems ([O000O00O00O0O0O0O ],0.75 ).collect ()[0 ][0 ][0 ]#line:322
              O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,O000O00O00O0O0O0O .strip ()),F .when (F .isnan (O000O00O00O0O0O0O )|F .isnull (O000O00O00O0O0O0O ),F .lit (OOOOO0O0OO0O000O0 )).otherwise (F .col (O000O00O00O0O0O0O )).alias (O000O00O00O0O0O0O .strip ()))#line:324
          elif OO000OOO0OO00O0O0 =='constant'or OO000OOO0OO00O0O0 =='const':#line:327
              O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,O000O00O00O0O0O0O .strip ()),F .when (F .isnan (O000O00O00O0O0O0O )|F .isnull (O000O00O00O0O0O0O ),F .lit (OOOO0O0O000000OO0 )).otherwise (F .col (O000O00O00O0O0O0O )).alias (O000O00O00O0O0O0O .strip ()))#line:329
      elif O0OOOOO0000000OO0 .lower ()=='anonymization'or O0OOOOO0000000OO0 .lower ()=='anonymize':#line:334
        OO000OOO0OO00O0O0 =OO000OOO0OO00O0O0 .lower ()#line:335
        if OO000OOO0OO00O0O0 =='base64'or OO000OOO0OO00O0O0 =='base':#line:336
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:337
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .base64 (F .col (OO0O0O0OOO00OO00O )).alias (OO0O0O0OOO00OO00O .strip ()))#line:339
        elif OO000OOO0OO00O0O0 =='hex':#line:342
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:343
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .hex (F .col (OO0O0O0OOO00OO00O )).alias (OO0O0O0OOO00OO00O .strip ()))#line:345
        elif OO000OOO0OO00O0O0 =='sha1'or OO000OOO0OO00O0O0 =='sha':#line:348
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:349
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .sha1 (F .col (OO0O0O0OOO00OO00O )).alias (OO0O0O0OOO00OO00O .strip ()))#line:351
      elif O0OOOOO0000000OO0 .lower ()=='number_format':#line:356
        for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:357
          if O0OOOO0000OOO0O00 .select (OO0O0O0OOO00OO00O ).dtypes [0 ][1 ]in ['double','int','decimal','float','long','short']:#line:358
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .format_number (F .col (OO0O0O0OOO00OO00O ),int (OO000OOO0OO00O0O0 )).alias (OO0O0O0OOO00OO00O .strip ()))#line:360
      elif O0OOOOO0000000OO0 .lower ()=='functional':#line:365
        OO000OOO0OO00O0O0 =OO000OOO0OO00O0O0 .lower ()#line:366
        if OO000OOO0OO00O0O0 =='base64'or OO000OOO0OO00O0O0 =='base':#line:367
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:368
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .base64 (F .col (OO0O0O0OOO00OO00O )).alias (OO0O0O0OOO00OO00O .strip ()))#line:370
        elif OO000OOO0OO00O0O0 =='substring'or OO000OOO0OO00O0O0 =='sub-string':#line:373
          OO00O0000O0000O0O =OOOO0O0O000000OO0 .strip ().split (":")#line:374
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:375
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .substring (F .col (OO0O0O0OOO00OO00O ).cast ('string'),int (OO00O0000O0000O0O [0 ]),int (OO00O0000O0000O0O [1 ])).alias (OO0O0O0OOO00OO00O .strip ()))#line:377
        elif OO000OOO0OO00O0O0 =='prefix'or OO000OOO0OO00O0O0 =='pre-fix':#line:380
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:381
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .concat (F .lit (OOOO0O0O000000OO0 ),F .col (OO0O0O0OOO00OO00O ).cast ("string")).alias (OO0O0O0OOO00OO00O .strip ()))#line:383
        elif OO000OOO0OO00O0O0 =='suffix':#line:386
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:387
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .concat (F .col (OO0O0O0OOO00OO00O ).cast ("string"),F .lit (OOOO0O0O000000OO0 )).alias (OO0O0O0OOO00OO00O .strip ()))#line:389
        elif OO000OOO0OO00O0O0 =='removeaccent'or OO000OOO0OO00O0O0 =='accent-remove'or OO000OOO0OO00O0O0 =='accentremove':#line:392
          def _OOO00OOO00OO0OO00 (OO0OO000000000OOO ):#line:393
            try :#line:394
                if OO0OO000000000OOO is None or str (OO0OO000000000OOO )=='nan':#line:395
                    OO0OO000000000OOO =''#line:396
                else :#line:398
                    OO0OO000000000OOO =re .sub ('\W+',' ',OO0OO000000000OOO )#line:399
                return OO0OO000000000OOO #line:401
            except :#line:403
                traceback .print_exc ()#line:404
                raise ValueError ("Error In Accent Removal")#line:405
          O0O00000OO0OO0O00 =F .udf (_OOO00OOO00OO0OO00 ,StringType ())#line:408
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:409
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),O0O00000OO0OO0O00 (F .col (OO0O0O0OOO00OO00O ).cast ("string")).alias (OO0O0O0OOO00OO00O .strip ()))#line:411
        elif OO000OOO0OO00O0O0 =='rpad'or OO000OOO0OO00O0O0 =='r-pad':#line:414
          OO000000000OO0OOO =OOOO0O0O000000OO0 .strip ().split (",")#line:415
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:416
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .rpad (F .col (OO0O0O0OOO00OO00O ).cast ("string"),int (OO000000000OO0OOO [0 ]),OO000000000OO0OOO [1 ]).alias (OO0O0O0OOO00OO00O .strip ()))#line:418
        elif OO000OOO0OO00O0O0 =='lpad'or OO000OOO0OO00O0O0 =='l-pad':#line:421
          OO000000000OO0OOO =OOOO0O0O000000OO0 .strip ().split (",")#line:422
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:423
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .lpad (F .col (OO0O0O0OOO00OO00O ).cast ("string"),int (OO000000000OO0OOO [0 ]),OO000000000OO0OOO [1 ]).alias (OO0O0O0OOO00OO00O .strip ()))#line:425
        elif OO000OOO0OO00O0O0 =='rtrim'or OO000OOO0OO00O0O0 =='r-trim':#line:428
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:429
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .rtrim (F .col (OO0O0O0OOO00OO00O ).cast ("string")).alias (OO0O0O0OOO00OO00O .strip ()))#line:431
        elif OO000OOO0OO00O0O0 =='ltrim'or OO000OOO0OO00O0O0 =='l-trim':#line:434
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:435
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),F .ltrim (F .col (OO0O0O0OOO00OO00O ).cast ("string")).alias (OO0O0O0OOO00OO00O .strip ()))#line:437
        elif OO000OOO0OO00O0O0 =='trimdoublequotes'or OO000OOO0OO00O0O0 =='trimquotes'or OO000OOO0OO00O0O0 =='trim-quotes'or OO000OOO0OO00O0O0 =='trim-double-quotes':#line:440
          O000OO00OO0OO0O00 =F .udf (lambda O00O0OO0O00OO0O0O :O00O0OO0O00OO0O0O .strip ('"'))#line:441
          for OO0O0O0OOO00OO00O in O00O0OOO0OO00OOOO :#line:442
            O0OOOO0000OOO0O00 =O0OOOO0000OOO0O00 .select (*filter_column_names (O0O0O00000O0O00OO ,OO0O0O0OOO00OO00O .strip ()),O000OO00OO0OO0O00 (F .col (OO0O0O0OOO00OO00O )).alias (OO0O0O0OOO00OO00O .strip ()))#line:444
      return O0OOOO0000OOO0O00 #line:448
    finally :#line:450
      O0OOOO0000OOO0O00 =None #line:451
@logdebug #line:458
def convertAliasColumnName2RulesEngine_fn (OO00OOO00000O00OO ,OO0OOO0O0OO0O0OOO ):#line:459
  ""#line:462
  O00OO00OOOO00O00O ={}#line:463
  for OOO0OO0O000OO0O00 in OO00OOO00000O00OO :#line:464
    O0O00OO000000O0OO =OOO0OO0O000OO0O00 .get ('metadata',{}).get ('alias_name',None )#line:465
    if O0O00OO000000O0OO !=None and O0O00OO000000O0OO .upper ()!='NA':#line:466
      OOO00OOO0OO0OOO0O =O0O00OO000000O0OO .split (',')#line:467
      for OOO00O0O0OO0O0000 in OOO00OOO0OO0OOO0O :#line:468
        OOO000O0OOO0O00OO =O00OO00OOOO00O00O .get (OOO00O0O0OO0O0000 ,[])#line:469
        OOO000O0OOO0O00OO .append (OOO0OO0O000OO0O00 .get ('name'))#line:470
        O00OO00OOOO00O00O [OOO00O0O0OO0O0000 ]=OOO000O0OOO0O00OO #line:471
  OOO000O0OOOOOOOOO =[]#line:476
  O0OOOO0O0O0OO0O0O =[]#line:477
  for O0O000O0O00O0OO0O in OO0OOO0O0OO0O0OOO :#line:478
    if 'anonymize_by_tags'in O0O000O0O00O0OO0O .get ("type"):#line:479
      OO0OO00O0OOOOOO00 =O00OO00OOOO00O00O .get (O0O000O0O00O0OO0O .get ('parameter').split (",")[0 ])#line:480
      for O0OO0O0000OOOO0OO in OO0OO00O0OOOOOO00 :#line:481
        O0OO00O0O0O0O0OO0 =O0O000O0O00O0OO0O .copy ()#line:482
        O0OO00O0O0O0O0OO0 ['old_column_names']=O0OO0O0000OOOO0OO #line:483
        O0OO00O0O0O0O0OO0 ['new_column_names']=O0OO0O0000OOOO0OO #line:484
        O0OO00O0O0O0O0OO0 ['parameter']=O0O000O0O00O0OO0O .get ('parameter').split (",")[1 ]#line:485
        OOO000O0OOOOOOOOO .append (O0OO00O0O0O0O0OO0 )#line:486
      OO0OOO0O0OO0O0OOO .remove (O0O000O0O00O0OO0O )#line:488
  OO0OOO0O0OO0O0OOO =OO0OOO0O0OO0O0OOO +OOO000O0OOOOOOOOO #line:492
  return OO0OOO0O0OO0O0OOO #line:494
class RulesEngineComplexClass (RulesEngineBaseClass ):#line:499
  @logdebug #line:500
  def standardizeColumnsByComplexRule_fn (OOOO000O00OOO000O ,O0000OO0OOO0OO0O0 ,O0000OOOO00O00OO0 ,O00000OOOO00O00OO ,OO00OO0000000O0OO ):#line:501
    ""#line:613
    try :#line:614
      def _OOOOO0O0OOOO0000O (O000OO0OOO00O0O0O ,O0OO0OO00OO0000OO ):#line:615
        try :#line:616
          if O000OO0OOO00O0O0O is None or str (O000OO0OOO00O0O0O )=='nan':#line:617
            return None #line:618
          O000O0OO0O00OOOOO =str ("".join (O0OO0OO00OO0000OO [0 ])).split ("#")#line:620
          OOO0O00O00000O00O =re .compile (O000O0OO0O00OOOOO [1 ],re .I |re .M )#line:621
          O00O0O0O0OOOO0O00 =re .sub (OOO0O00O00000O00O ,"\g<"+str (O000O0OO0O00OOOOO [2 ])+">",O000OO0OOO00O0O0O )#line:622
          if int (O000O0OO0O00OOOOO [2 ])==1 :#line:623
              return O00O0O0O0OOOO0O00 +str (O000O0OO0O00OOOOO [0 ])#line:624
          else :#line:626
              return str (O000O0OO0O00OOOOO [0 ])+O00O0O0O0OOOO0O00 #line:627
        except :#line:630
          return None #line:631
      def _OO0OOOO0OOO0OOO0O (O000O00OOOOO0OOO0 ,O000000O00OOO00OO ):#line:635
        try :#line:636
          if O000O00OOOOO0OOO0 ==None or len (O000O00OOOOO0OOO0 )==0 :#line:637
            return None #line:638
          OO0O0O000OO000O0O ={'MM':'%m','dd':'%d','yyyy':'%Y','HH':'%H','I':'%I','II':'%I','mm':'%M','ss':'%S','yy':'%y','a':'%a','p':'%p','b':'%b','MMM':'%b','mmm':'%b','T':'T','Z':'Z','z':'Z'}#line:659
          for O000000OOOOO00OO0 ,OOO00OOO0O0000O00 in OO0O0O000OO000O0O .items ():#line:660
            O000000O00OOO00OO =O000000O00OOO00OO .replace (O000000OOOOO00OO0 ,OOO00OOO0O0000O00 )#line:661
          OO0OO00000O000O0O =datetime .strptime (O000O00OOOOO0OOO0 ,O000000O00OOO00OO )#line:664
          return str (OO0OO00000O000O0O )#line:665
        except :#line:667
          return None #line:668
      def _OOOOO0O0OO00O00O0 (O0OOO00O00000000O ,OOO0OO0OOO0O000OO ):#line:672
        try :#line:673
          if O0OOO00O00000000O ==None or len (O0OOO00O00000000O )==0 :#line:674
            return None #line:675
          OOOO0OO00OO000O0O ={'MM':'%m','dd':'%d','yyyy':'%Y','HH':'%H','mm':'%M','ss':'%S'}#line:685
          for OO0OO0OOO0OO0OO0O ,OO00OOO00OO0OOO00 in OOOO0OO00OO000O0O .items ():#line:686
            OOO0OO0OOO0O000OO =OOO0OO0OOO0O000OO .replace (OO0OO0OOO0OO0OO0O ,OO00OOO00OO0OOO00 )#line:687
          O0O0OO00O000OO00O =datetime .strptime (O0OOO00O00000000O ,OOO0OO0OOO0O000OO ).date ()#line:690
          return str (O0O0OO00O000OO00O )#line:691
        except :#line:693
          return None #line:694
      def _O0000OOOO00O0OOO0 (OO00OO0OOO000O000 ):#line:699
        try :#line:700
          if OO00OO0OOO000O000 ==None :#line:701
            return None #line:702
          OO00OO0OOO000O000 =re .sub (' +',' ',OO00OO0OOO000O000 )#line:704
          O0O000O0O000O0OOO =re .sub (r'[0-9a-zA-Z]','x',OO00OO0OOO000O000 )#line:705
          if O0O000O0O000O0OOO =='xxxx-xx-xx':#line:707
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y-%m-%d')#line:708
          elif O0O000O0O000O0OOO =='xxxx-x-xx':#line:709
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y-%m-%d')#line:710
          elif O0O000O0O000O0OOO =='xxxx-xx-x':#line:711
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y-%m-%d')#line:712
          elif O0O000O0O000O0OOO =='xxxx-x-x':#line:713
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y-%m-%d')#line:714
          elif O0O000O0O000O0OOO =='xx-xx-xx':#line:715
              return datetime .strptime (OO00OO0OOO000O000 ,'%m-%d-%y')#line:716
          elif O0O000O0O000O0OOO =='xx-x-x':#line:717
              return datetime .strptime (OO00OO0OOO000O000 ,'%y-%m-%d')#line:718
          elif O0O000O0O000O0OOO =='xx-xx-x':#line:719
              return datetime .strptime (OO00OO0OOO000O000 ,'%y-%m-%d')#line:720
          elif O0O000O0O000O0OOO =='xx-x-xx':#line:721
              return datetime .strptime (OO00OO0OOO000O000 ,'%m-%d-%y')#line:722
          elif O0O000O0O000O0OOO =='x-x-xx':#line:723
              return datetime .strptime (OO00OO0OOO000O000 ,'%m-%d-%y')#line:724
          elif O0O000O0O000O0OOO in ['x-xx-xxxx','xx-xx-xxxx']:#line:725
              return datetime .strptime (OO00OO0OOO000O000 ,'%m-%d-%Y')#line:726
          elif O0O000O0O000O0OOO in ['x-x-xx x:xx','x-x-xx x:xx']:#line:727
              return datetime .strptime (OO00OO0OOO000O000 ,'%m-%d-%y %H:%M')#line:728
          elif O0O000O0O000O0OOO =='xx-xxx-xxxx':#line:729
              return datetime .strptime (OO00OO0OOO000O000 ,'%d-%b-%Y')#line:730
          elif O0O000O0O000O0OOO =='xx-xxx-xxxx xx:xx:xx':#line:731
              return datetime .strptime (OO00OO0OOO000O000 ,'%d-%b-%Y %H:%M:%S')#line:732
          elif O0O000O0O000O0OOO =='xx-xxx-xx xx:xx:xx':#line:733
              return datetime .strptime (OO00OO0OOO000O000 ,'%d-%b-%y %H:%M:%S')#line:734
          elif O0O000O0O000O0OOO in ['xx-xx-xx xx:xx:xx xx','xx-xx-xx x:xx:xx xx','xx-xx-xx xx:x:xx xx','xx-xx-xx x:x:x xx','xx-xx-xx xx:xx:x xx','x-x-xxxx xx:xx:xx xx','x-x-xxxx x:xx:xx xx','x-x-xxxx x:x:xx xx','x-x-xxxx x:x:x xx','x-xx-xxxx xx:xx:xx xx','x-xx-xxxx x:xx:xx xx','x-xx-xxxx x:x:xx xx','x-xx-xxxx x:x:x xx' 'xx-x-xxxx xx:xx:xx xx','xx-x-xxxx x:xx:xx xx','xx-x-xxxx x:x:xx xx','xx-x-xxxx x:x:x xx']:#line:735
              return datetime .strptime (OO00OO0OOO000O000 ,'%m-%d-%Y %I:%M:%S %p')#line:736
          elif O0O000O0O000O0OOO =='xxxx/xx/xx':#line:737
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y/%m/%d')#line:738
          elif O0O000O0O000O0OOO =='xx/xx/xx':#line:739
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%y')#line:740
          elif O0O000O0O000O0OOO =='xx/x/x':#line:741
              return datetime .strptime (OO00OO0OOO000O000 ,'%y/%m/%d')#line:742
          elif O0O000O0O000O0OOO =='xx/xx/x':#line:743
              return datetime .strptime (OO00OO0OOO000O000 ,'%y/%m/%d')#line:744
          elif O0O000O0O000O0OOO =='x/x/xx':#line:745
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%y')#line:746
          elif O0O000O0O000O0OOO in ['x/x/xx x:xx','x/x/xx x:xx']:#line:747
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%y %H:%M')#line:748
          elif O0O000O0O000O0OOO =='x/xx/xx':#line:749
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%y')#line:750
          elif O0O000O0O000O0OOO =='xx/x/xx':#line:751
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%y')#line:752
          elif O0O000O0O000O0OOO =='xx/xx/xxxx':#line:753
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%Y')#line:754
          elif O0O000O0O000O0OOO =='x/xx/xxxx':#line:755
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%Y')#line:756
          elif O0O000O0O000O0OOO =='xx/x/xxxx':#line:757
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%Y')#line:758
          elif O0O000O0O000O0OOO =='x/x/xxxx':#line:759
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%Y')#line:760
          elif O0O000O0O000O0OOO in ['xx/xx/xx xx:xx:xx xx','xx/xx/xx x:xx:xx xx','xx/xx/xx xx:x:xx xx','xx/xx/xx x:x:x xx','xx/xx/xx xx:xx:x xx','x/x/xxxx xx:xx:xx xx','x/x/xxxx x:xx:xx xx','x/x/xxxx x:x:xx xx','x/x/xxxx x:x:x xx','x/xx/xxxx xx:xx:xx xx','x/xx/xxxx x:xx:xx xx','x/xx/xxxx x:x:xx xx','x/xx/xxxx x:x:x xx' 'xx/x/xxxx xx:xx:xx xx','xx/x/xxxx x:xx:xx xx','xx/x/xxxx x:x:xx xx','xx/x/xxxx x:x:x xx']:#line:761
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%Y %I:%M:%S %p')#line:762
          elif O0O000O0O000O0OOO =='xx/xxx/xxxx':#line:763
              return datetime .strptime (OO00OO0OOO000O000 ,'%d/%b/%Y')#line:764
          elif O0O000O0O000O0OOO =='xx/xxx/xxxx xx:xx:xx':#line:765
              return datetime .strptime (OO00OO0OOO000O000 ,'%d/%b/%Y %H:%M:%S')#line:766
          elif O0O000O0O000O0OOO =='xx/xxx/xx xx:xx:xx':#line:767
              return datetime .strptime (OO00OO0OOO000O000 ,'%d/%b/%y %H:%M:%S')#line:768
          elif O0O000O0O000O0OOO in ['xxxx/xx/xx x:xx','xxxx/xx/xx xx:xx']:#line:770
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y/%m/%d %H:%M')#line:771
          elif O0O000O0O000O0OOO in ['xx/xx/xxxx x:xx','xx/xx/xxxx xx:xx']:#line:772
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%Y %H:%M')#line:773
          elif O0O000O0O000O0OOO in ['xxxx-xx-xx x:xx','xxxx-xx-xx xx:xx']:#line:774
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y-%m-%d %H:%M')#line:775
          elif O0O000O0O000O0OOO in ['xx-xx-xxxx x:xx','xx-xx-xxxx xx:xx']:#line:776
              return datetime .strptime (OO00OO0OOO000O000 ,'%m-%d-%Y %H:%M')#line:777
          elif O0O000O0O000O0OOO in ['xxxx/xx/xx x:xx:xx','xxxx/xx/xx xx:xx:xx']:#line:778
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y/%m/%d %H:%M:%S')#line:779
          elif O0O000O0O000O0OOO in ['xx/xx/xxxx x:xx:xx','xx/xx/xxxx xx:xx:xx']:#line:780
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%Y %H:%M:%S')#line:781
          elif O0O000O0O000O0OOO in ['xxxx-xx-xx x:xx:xx','xxxx-xx-xx xx:xx:xx']:#line:782
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y-%m-%d %H:%M:%S')#line:783
          elif O0O000O0O000O0OOO in ['xx/xx/xxxx x:xx:xx xx','xx/xx/xxxx xx:xx:xx xx','x/xx/xxxx xx:xx:xx xx','x/xx/xxxx x:xx:xx xx']:#line:784
              return datetime .strptime (OO00OO0OOO000O000 ,'%m/%d/%Y %I:%M:%S %p')#line:785
          elif O0O000O0O000O0OOO in ['xx-xx-xxxx x:xx:xx xx','xx-xx-xxxx xx:xx:xx xx','x-xx-xxxx xx:xx:xx xx','x-xx-xxxx x:xx:xx xx']:#line:786
              return datetime .strptime (OO00OO0OOO000O000 ,'%m-%d-%Y %I:%M:%S %p')#line:787
          elif O0O000O0O000O0OOO =='xxxxxxxx':#line:789
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y%d%m')#line:790
          elif O0O000O0O000O0OOO in ['xxxxxxxxxxxxxx']:#line:791
              return datetime .strptime (OO00OO0OOO000O000 ,'%Y%d%m%H%M%S')#line:792
          return None #line:795
        except :#line:797
          return str (traceback .print_exc ())#line:798
      def _OOOOO0O0O000O0OO0 (OO0OO0OOO0000OO00 ):#line:803
        OO00O0O000O0OOOO0 ,O0O00OO0O0O0OOOOO =os .path .split (OO0OO0OOO0000OO00 )#line:804
        return O0O00OO0O0O0OOOOO #line:805
      if O00000OOOO00O00OO .get ('type','').lower ()=='regex_extract':#line:810
        O0O00O0000O0OO0O0 =O00000OOOO00O00OO .get ('parameter','')#line:811
        O0OO0OOOO00O0OOOO =O00000OOOO00O00OO .get ('selection_group')#line:812
        O0O0OOOOOOOOOO000 =[OO0OOO0O0O00O0O0O .lower ()for OO0OOO0O0O00O0O0O in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:813
        O0O0O0OO000O0O0OO =[OOO0OOOOOO0OOOOOO .lower ()for OOO0OOOOOO0OOOOOO in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:814
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:816
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .regexp_extract (F .col (OOOOOO0OO00O00OO0 ),O0O00O0000O0OO0O0 ,int (O0OO0OOOO00O0OOOO )).alias (OO000O00OOOOOOO0O ))#line:817
      elif O00000OOOO00O00OO .get ('type','').lower ()=='regex_replace':#line:822
        O0O00O0000O0OO0O0 =O00000OOOO00O00OO .get ('parameter','')#line:823
        O0O0OOOOOOOOOO000 =[OO0O0OO0O00000O0O .lower ()for OO0O0OO0O00000O0O in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:824
        O0O0O0OO000O0O0OO =[OO000O0O0O0OO00OO .lower ()for OO000O0O0O0OO00OO in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:825
        O00O0OOOOO0000000 =O00000OOOO00O00OO .get ('replace_value','')#line:826
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:828
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .regexp_replace (F .col (OOOOOO0OO00O00OO0 .strip ()),O0O00O0000O0OO0O0 ,O00O0OOOOO0000000 ).alias (OO000O00OOOOOOO0O ))#line:829
      elif O00000OOOO00O00OO .get ('type','').lower ()=='regex_replace_partial':#line:834
        _O0OOOO0OOOOOOO00O =F .udf (_OOOOO0O0OOOO0000O ,StringType ())#line:835
        O0O00O0000O0OO0O0 =O00000OOOO00O00OO .get ('parameter','')#line:837
        O0OO0OOOO00O0OOOO =O00000OOOO00O00OO .get ('selection_group')#line:838
        O0O0OOOOOOOOOO000 =[O0OO00O00O0O0OOOO .lower ()for O0OO00O00O0O0OOOO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:839
        O0O0O0OO000O0O0OO =[O00O00O0OOOOOO0O0 .lower ()for O00O00O0OOOOOO0O0 in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:840
        O00O0OOOOO0000000 =O00000OOOO00O00OO .get ('replace_value','')#line:841
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:843
          O00O0O0O0O0OOOOOO =[]#line:844
          O00O0O0O0O0OOOOOO .append (O00O0OOOOO0000000 +"#"+O0O00O0000O0OO0O0 +"#"+str (O0OO0OOOO00O0OOOO ))#line:845
          O0000O0O0OOO0O0OO =F .array (*[F .array (*[F .lit (O0O0O0O0OO0OO0O00 )])for O0O0O0O0OO0OO0O00 in O00O0O0O0O0OOOOOO ])#line:846
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),_O0OOOO0OOOOOOO00O (F .col (OOOOOO0OO00O00OO0 .strip ()).cast ('string'),O0000O0O0OOO0O0OO ).alias (OO000O00OOOOOOO0O .strip ()))#line:847
      elif O00000OOOO00O00OO .get ('type','').lower ()in ['replace_value','replace_map']:#line:852
        O0O0OOOOOOOOOO000 =[OO0000000000O000O .lower ()for OO0000000000O000O in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:853
        O0O0O0OO000O0O0OO =[OOO000O0OO0000O00 .lower ()for OOO000O0OO0000O00 in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:854
        O0O0O0000OOOO00O0 =O00000OOOO00O00OO .get ('parameter',{})#line:855
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:857
          if OOOOOO0OO00O00OO0 !=OO000O00OOOOOOO0O :#line:858
            O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select ("*",F .col (OOOOOO0OO00O00OO0 ).alias (OO000O00OOOOOOO0O ))#line:859
            O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .replace (O0O0O0000OOOO00O0 ,OO000O00OOOOOOO0O )#line:860
          else :#line:862
            O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .replace (O0O0O0000OOOO00O0 ,OOOOOO0OO00O00OO0 )#line:863
      elif O00000OOOO00O00OO .get ('type','').lower ()in ['file_lookup_csv']:#line:869
        O0O0OOOOOOOOOO000 =O00000OOOO00O00OO .get ('old_column_names','').lower ()#line:872
        O0O0O0OO000O0O0OO =[O000OOO0000OO0OOO .lower ()for O000OOO0000OO0OOO in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:873
        O0O0O0000OOOO00O0 =O00000OOOO00O00OO .get ('parameter',"")#line:874
        O0OO0OO00O0O0OO00 =O0000OO0OOO0OO0O0 .read .format ('csv').option ('sep',',').option ('quote','"').option ('escape','"').option ('header',"true").load (O0O0O0000OOOO00O0 )#line:876
        O0OO0OO00O0O0OO00 =O0OO0OO00O0O0OO00 .toDF (*(O0OO00O0OO00O0OO0 .lower ().replace ('\t','_').replace ("/","_").replace ("-","_").replace ("(","_").replace (")","_").replace ("__","_").replace ("$","_").replace (".","_").replace ('&','_').replace (":","").replace ("@","").strip ()for O0OO00O0OO00O0OO0 in O0OO0OO00O0O0OO00 .columns ))#line:877
        O0OO0OO00O0O0OO00 =O0OO0OO00O0O0OO00 .withColumnRenamed (O0O0O0OO000O0O0OO [1 ],O0O0OOOOOOOOOO000 )#line:878
        OO000O00OOOO0000O ={O0000OO00OOOOO00O [0 ]:O0000OO00OOOOO00O [1 ]for O0000OO00OOOOO00O in O0OO0OO00O0O0OO00 .collect ()}#line:879
        O0OO000OO00000000 =O0000OO0OOO0OO0O0 .sparkContext .broadcast (OO000O00OOOO0000O )#line:881
        _OO000O00O0O0O0O0O =F .udf (lambda O0O00O000O0000O00 :O0OO000OO00000000 .value [O0O00O000O0000O00 ]if O0O00O000O0000O00 in O0OO000OO00000000 .value else '',StringType ())#line:883
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .withColumn (O0O0O0OO000O0O0OO [0 ],_OO000O00O0O0O0O0O (O0O0OOOOOOOOOO000 ))#line:884
        O0OO000OO00000000 .unpersist (blocking =True )#line:886
        O0OO0OO00O0O0OO00 =None #line:887
      elif O00000OOOO00O00OO .get ('type','').lower ()=='replace_character_mapping':#line:892
        O00000OOO0OO0000O ,OO000OO00O000O000 =O00000OOOO00O00OO .get ('parameter','').split (",")#line:893
        O0O0OOOOOOOOOO000 =[O0OO0O0O00000O0OO .lower ()for O0OO0O0O00000O0OO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:894
        O0O0O0OO000O0O0OO =[O0OOO000OOO00OO0O .lower ()for O0OOO000OOO00OO0O in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:895
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:897
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .translate (OOOOOO0OO00O00OO0 ,O00000OOO0OO0000O ,OO000OO00O000O000 ).alias (OO000O00OOOOOOO0O ))#line:898
      elif O00000OOOO00O00OO .get ('type','').lower ()in ['replace_spanish_char_mapping','replace_diacritics_char_mapping']:#line:902
        O00000OOO0OO0000O ="ÁĂẮẶẰẲẴǍÂẤẬẦẨẪÄẠÀẢĀĄÅǺÃÆǼḄƁʚɞĆČÇĈĊƆʗĎḒḌƊḎǲǅĐÐǱǄÉĔĚÊẾỆỀỂỄËĖẸÈẺĒĘẼƐƏƑǴĞǦĢĜĠḠʛḪĤḤĦÍĬǏÎÏİỊÌỈĪĮĨĲĴĶḲƘḴĹȽĽĻḼḶḸḺĿǈŁǇḾṀṂŃŇŅṊṄṆǸƝṈǋÑǊÓŎǑÔỐỘỒỔỖÖỌŐÒỎƠỚỢỜỞỠŌƟǪØǾÕŒɶÞŔŘŖṘṚṜṞʁŚŠŞŜȘṠṢẞŤŢṰȚṬṮŦÞÐÚŬǓÛÜǗǙǛǕỤŰÙỦƯỨỰỪỬỮŪŲŮŨẂŴẄẀʬÝŶŸẎỴỲƳỶȲỸŹŽŻẒẔƵáăắặằẳẵǎâấậầẩẫäạàảāąåǻãæǽɑɐɒḅɓßćčçĉɕċďḓḍɗḏđɖʤǳʣʥǆðéĕěêếệềểễëėẹèẻēęẽʒǯʓɘɜɝəɚʚɞƒſʩﬁﬂʃʆʅɟʄǵğǧģĝġɠḡɡɣḫĥḥɦẖħɧɥʮʯųíĭǐîïịìỉīįɨĩɩıĳɟǰĵʝȷɟʄķḳƙḵĸʞĺƚɬľļḽḷḹḻŀɫɭłƛɮǉʪʫḿṁṃɱɯɰŉńňņṋṅṇǹɲṉɳñǌŋŊóŏǒôốộồổỗöọőòỏơớợờởỡōǫøǿõɛɔɵʘœɸþʠŕřŗṙṛṝɾṟɼɽɿɹɻɺśšşŝșṡṣʂſʃʆßʅťţṱțẗṭṯʈŧʨʧþðʦʇʉúŭǔûüǘǚǜǖụűùủưứựừửữūųůũʊʋʌẃŵẅẁʍýŷÿẏỵỳƴỷȳỹʎźžʑżẓẕʐƶ"#line:903
        OO000OO00O000O000 ="AAAAAAAAAAAAAAAAAAAAAAAAABBBBCCCCCCCDDDDDDDDDDDEEEEEEEEEEEEEEEEEEEFGGGGGGGGHHHHIIIIIIIIIIIIIJKKKKLLLLLLLLLLLLMMMNNNNNNNNNNNNOOOOOOOOOOOOOOOOOOOOOOOOOOOOPRRRRRRRRSSSSSSSSTTTTTTTTTUUUUUUUUUUUUUUUUUUUUUUUWWWWWYYYYYYYYYYZZZZZZaaaaaaaaaaaaaaaaaaaaaaaaaaaabbbccccccdddddddddddddeeeeeeeeeeeeeeeeeeeeeeeeeeeffffffffffgggggggggghhhhhhhhhhhiiiiiiiiiiiiiiiijjjjjjkkkkkkllllllllllllllllllmmmmmmnnnnnnnnnnnnnnnooooooooooooooooooooooooooooooppqrrrrrrrrrrrrrrssssssssssssstttttttttttttttuuuuuuuuuuuuuuuuuuuuuuuuuvvwwwwwyyyyyyyyyyyzzzzzzzz"#line:904
        O0O0OOOOOOOOOO000 =[OO0OO0OOOO0OO00OO .lower ()for OO0OO0OOOO0OO00OO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:905
        O0O0O0OO000O0O0OO =[OO0OOOOOO00OO00O0 .lower ()for OO0OOOOOO00OO00O0 in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:906
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:908
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .translate (OOOOOO0OO00O00OO0 ,O00000OOO0OO0000O ,OO000OO00O000O000 ).alias (OO000O00OOOOOOO0O ))#line:909
      elif O00000OOOO00O00OO .get ('type','').lower ()=='convert_type':#line:914
        O0O00O0000O0OO0O0 =O00000OOOO00O00OO .get ('parameter')#line:915
        O0O0OOOOOOOOOO000 =[OO00OOO000OO00O0O .lower ()for OO00OOO000OO00O0O in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:916
        O0O0O0OO000O0O0OO =[O0O0000O000O0OO00 .lower ()for O0O0000O000O0OO00 in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:917
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:919
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .col (OOOOOO0OO00O00OO0 ).cast (O0O00O0000O0OO0O0 ).alias (OO000O00OOOOOOO0O .strip ()))#line:920
      elif O00000OOOO00O00OO .get ('type','').lower ()=='convert_boolean':#line:924
        O0O0OOOOOOOOOO000 =[OO0O00O00O00OOO00 .lower ()for OO0O00O00O00OOO00 in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:925
        O0O0O0OO000O0O0OO =[O000O000O000000OO .lower ()for O000O000O000000OO in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:926
        O0O00OO0OO000000O =F .udf (lambda O0O0O0O0OO00O0O00 :True if O0O0O0O0OO00O0O00 in [True ,'Yes','YES','1',1 ,'yes','Y','y','T','true','True','TRUE']else False ,BooleanType ())#line:928
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:930
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .withColumn (OO000O00OOOOOOO0O ,O0O00OO0OO000000O (OOOOOO0OO00O00OO0 .strip ()))#line:931
      elif O00000OOOO00O00OO .get ('type','').lower ()=='select_specific_columns':#line:935
        O0O0OOOOOOOOOO000 =O00000OOOO00O00OO .get ('old_column_names','').lower ()#line:936
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*O0O0OOOOOOOOOO000 .split (","))#line:937
      elif O00000OOOO00O00OO .get ('type','').lower ()=='filename_as_column':#line:941
        _O0O000OOOO00000OO =F .udf (_OOOOO0O0O000O0OO0 ,F .StringType ())#line:942
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .withColumn (O00000OOOO00O00OO .get ('new_column_names','').lower (),_O0O000OOOO00000OO (F .input_file_name ()))#line:943
      elif O00000OOOO00O00OO .get ('type','').lower ()=='remove_duplicates':#line:947
        O00OO00O000O0OOO0 =O00000OOOO00O00OO .get ('old_column_names','*').lower ()#line:948
        if O00OO00O000O0OOO0 =='*':#line:950
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .drop_duplicates ()#line:951
        else :#line:953
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .drop_duplicates (subset =O00OO00O000O0OOO0 .split (","))#line:954
      elif O00000OOOO00O00OO .get ('type','').lower ()=='lead_value':#line:958
        OOOO0OOO0OO00OOO0 =O00000OOOO00O00OO .get ('partition_column_names','')#line:960
        OO0OO0O000O0OOOO0 =O00000OOOO00O00OO .get ('order_column_list','NA')#line:961
        OOOO0000000O0O00O =O00000OOOO00O00OO .get ('old_column_names','NA').lower ()#line:962
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names','NA').lower ()#line:963
        O0OOO0OO0OOOO0000 =Window .partitionBy (*OOOO0OOO0OO00OOO0 .split (',')).orderBy (*OO0OO0O000O0OOOO0 .split (","))#line:965
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .repartition (*OOOO0OOO0OO00OOO0 .split (','))#line:966
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .lead (OOOO0000000O0O00O ).over (O0OOO0OO0OOOO0000 ).alias (OO000O00O00OOOO00 ))#line:967
      elif O00000OOOO00O00OO .get ('type','').lower ()=='lag_value':#line:970
        OOOO0OOO0OO00OOO0 =O00000OOOO00O00OO .get ('partition_column_names','')#line:972
        OO0OO0O000O0OOOO0 =O00000OOOO00O00OO .get ('order_column_list','NA')#line:973
        OOOO0000000O0O00O =O00000OOOO00O00OO .get ('old_column_names','NA').lower ()#line:974
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names','NA').lower ()#line:975
        O0OOO0OO0OOOO0000 =Window .partitionBy (*OOOO0OOO0OO00OOO0 .split (',')).orderBy (*OO0OO0O000O0OOOO0 .split (","))#line:977
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .repartition (*OOOO0OOO0OO00OOO0 .split (','))#line:978
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .lag (OOOO0000000O0O00O ).over (O0OOO0OO0OOOO0000 ).alias (OO000O00O00OOOO00 ))#line:979
      elif O00000OOOO00O00OO .get ('type','').lower ()=='extract_currency_value':#line:983
        O00OO00O000O0OOO0 =O00000OOOO00O00OO .get ('old_column_names','NA').lower ().split (",")#line:985
        O00O0O00OOOO00OO0 =O00000OOOO00O00OO .get ('new_column_names','NA').lower ().split (",")#line:986
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O00OO00O000O0OOO0 ,O00O0O00OOOO00OO0 ):#line:988
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .regexp_replace (F .col (OOOOOO0OO00O00OO0 .strip ()),"[^0-9\.]","").alias (OO000O00OOOOOOO0O )).select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .col (OO000O00OOOOOOO0O .strip ()).cast ("double").alias (OO000O00OOOOOOO0O )).select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .format_number (F .col (OO000O00OOOOOOO0O ),2 ).alias (OO000O00OOOOOOO0O ))#line:989
      elif O00000OOOO00O00OO .get ('type','').lower ()=='substring'or O00000OOOO00O00OO .get ('type','').lower ()=='sub-string':#line:995
        O00OO00O000O0OOO0 =[OOOOOOOO000O000OO .lower ()for OOOOOOOO000O000OO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:996
        O00O0O00OOOO00OO0 =[OOO00OO0O000O0OOO .lower ()for OOO00OO0O000O0OOO in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:997
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ("parameter",'').strip ().split (":")#line:998
        for O00O0OOO0OO0O00O0 ,O0000OOO0OO00OOO0 in zip (O00OO00O000O0OOO0 ,O00O0O00OOOO00OO0 ):#line:999
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O0000OOO0OO00OOO0 ),F .substring (F .col (O00O0OOO0OO0O00O0 ).cast ('string'),int (OO0O000OOO00OO0O0 [0 ]),int (OO0O000OOO00OO0O0 [1 ])).alias (O0000OOO0OO00OOO0 ))#line:1000
      elif O00000OOOO00O00OO .get ('type','').lower ()=='concat_columns'or O00000OOOO00O00OO .get ('type','').lower ()=='concatcolumns':#line:1005
        O00OO00O000O0OOO0 =[OOO00OO0O00O00OOO .lower ()for OOO00OO0O00O00OOO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1006
        O00O0O00OOOO00OO0 =O00000OOOO00O00OO .get ('new_column_names','').lower ()#line:1007
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select ("*",F .concat (*O00OO00O000O0OOO0 ).alias (O00O0O00OOOO00OO0 ))#line:1008
      elif O00000OOOO00O00OO .get ('type','').lower ()=='number_format':#line:1012
        O00OO00O000O0OOO0 =[O0000OO000000OOOO .lower ()for O0000OO000000OOOO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1013
        O00O0O00OOOO00OO0 =[OO0O0OOOO00OO0OOO .lower ()for OO0O0OOOO00OO0OOO in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:1014
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ("parameter",'')#line:1015
        for O00O0OOO0OO0O00O0 ,O0000OOO0OO00OOO0 in zip (O00OO00O000O0OOO0 ,O00O0O00OOOO00OO0 ):#line:1016
          if O0000OOOO00O00OO0 .select (O00O0OOO0OO0O00O0 ).dtypes [0 ][1 ]in ['double','int','decimal','float','long','short']:#line:1017
            O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O0000OOO0OO00OOO0 ),F .format_number (F .col (O00O0OOO0OO0O00O0 ),int (OO0O000OOO00OO0O0 )).alias (O0000OOO0OO00OOO0 ))#line:1018
      elif O00000OOOO00O00OO .get ('type','').lower ()=='filter_rows'or O00000OOOO00O00OO .get ('type','').lower ()=='filterrows':#line:1023
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ("parameter",[])#line:1024
        for O00000OOOO00O00OO in OO0O000OOO00OO0O0 :#line:1026
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .filter (O00000OOOO00O00OO )#line:1027
      elif O00000OOOO00O00OO .get ('type','').lower ()=='time_interval':#line:1033
        O0O00O0000O0OO0O0 =O00000OOOO00O00OO .get ('parameter')#line:1034
        O0O0OOOOOOOOOO000 =[O000OOO0OOOOOO0OO .lower ()for O000OOO0OOOOOO0OO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1035
        O0O0O0OO000O0O0OO =[O0OO00O0O00000O0O .lower ()for O0OO00O0O00000O0O in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:1036
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:1038
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .expr (f"{OOOOOO0OO00O00OO0} {O0O00O0000O0OO0O0}").alias (OO000O00OOOOOOO0O ))#line:1039
      elif O00000OOOO00O00OO .get ('type','').lower ()=='date_truncate':#line:1043
        O00OO00O000O0OOO0 =[OO0OOO0O0OOO00000 .lower ()for OO0OOO0O0OOO00000 in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1044
        O00O0O00OOOO00OO0 =[OOOO00O0OOO0O0000 .lower ()for OOOO00O0OOO0O0000 in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:1045
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ("parameter",'')#line:1046
        for O00O0OOO0OO0O00O0 ,O0000OOO0OO00OOO0 in zip (O00OO00O000O0OOO0 ,O00O0O00OOOO00OO0 ):#line:1047
          if O0000OOOO00O00OO0 .select (O00O0OOO0OO0O00O0 ).dtypes [0 ][1 ]in ['string','date','timestamp']:#line:1048
            O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O0000OOO0OO00OOO0 ),F .date_trunc (OO0O000OOO00OO0O0 ,F .col (O00O0OOO0OO0O00O0 ).cast ('timestamp')).alias (O0000OOO0OO00OOO0 ))#line:1049
      elif O00000OOOO00O00OO .get ('type','').lower ()=='convert_to_time':#line:1054
        _O0O0O0OO0OOOOO00O =F .udf (_OO0OOOO0OOO0OOO0O ,StringType ())#line:1055
        O00OO00O000O0OOO0 =[OO000O0O000OO0OOO .lower ()for OO000O0O000OO0OOO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1057
        O00O0O00OOOO00OO0 =[O00OOOOO000O00OO0 .lower ()for O00OOOOO000O00OO0 in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:1058
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ("parameter",'yyyy-MM-dd HH:mm:ss')#line:1059
        for O00O0OOO0OO0O00O0 ,O0000OOO0OO00OOO0 in zip (O00OO00O000O0OOO0 ,O00O0O00OOOO00OO0 ):#line:1060
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O0000OOO0OO00OOO0 ),F .to_timestamp (O00O0OOO0OO0O00O0 .strip (),OO0O000OOO00OO0O0 ).alias (O0000OOO0OO00OOO0 ))#line:1062
      elif O00000OOOO00O00OO .get ('type','').lower ()=='convert_to_date':#line:1066
        _O0O0O0OO0OOOOO00O =F .udf (_OOOOO0O0OO00O00O0 ,StringType ())#line:1067
        O00OO00O000O0OOO0 =[O00O0O000O0O0OOO0 .lower ()for O00O0O000O0O0OOO0 in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1069
        O00O0O00OOOO00OO0 =[O000OOO00OOO00OOO .lower ()for O000OOO00OOO00OOO in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:1070
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ("parameter",'yyyy-MM-dd HH:mm:ss')#line:1071
        for O00O0OOO0OO0O00O0 ,O0000OOO0OO00OOO0 in zip (O00OO00O000O0OOO0 ,O00O0O00OOOO00OO0 ):#line:1072
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O0000OOO0OO00OOO0 ),_O0O0O0OO0OOOOO00O (O00O0OOO0OO0O00O0 ,F .lit (OO0O000OOO00OO0O0 )).alias (O0000OOO0OO00OOO0 ))#line:1073
      elif O00000OOOO00O00OO .get ('type','').lower ()=='convert_to_date_spark':#line:1077
        O00OO00O000O0OOO0 =[O00O000O0OOOOO0OO .lower ()for O00O000O0OOOOO0OO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1078
        O00O0O00OOOO00OO0 =[O00000O0O0000O000 .lower ()for O00000O0O0000O000 in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:1079
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ("parameter",'yyyy-MM-dd HH:mm:ss')#line:1080
        for O00O0OOO0OO0O00O0 ,O0000OOO0OO00OOO0 in zip (O00OO00O000O0OOO0 ,O00O0O00OOOO00OO0 ):#line:1081
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O0000OOO0OO00OOO0 ),F .to_date (F .col (O00O0OOO0OO0O00O0 ),OO0O000OOO00OO0O0 ).alias (O0000OOO0OO00OOO0 ))#line:1082
      elif O00000OOOO00O00OO .get ('type','').lower ()=='convert_to_ts_spark':#line:1087
        O00OO00O000O0OOO0 =[OO000O000O0O0OO0O .lower ()for OO000O000O0O0OO0O in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1088
        O00O0O00OOOO00OO0 =[O00O0000OOO0O0OO0 .lower ()for O00O0000OOO0O0OO0 in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:1089
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ("parameter",'yyyy-MM-dd HH:mm:ss')#line:1090
        for O00O0OOO0OO0O00O0 ,O0000OOO0OO00OOO0 in zip (O00OO00O000O0OOO0 ,O00O0O00OOOO00OO0 ):#line:1091
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O0000OOO0OO00OOO0 ),F .to_timestamp (F .col (O00O0OOO0OO0O00O0 ),OO0O000OOO00OO0O0 ).alias (O0000OOO0OO00OOO0 ))#line:1092
      elif O00000OOOO00O00OO .get ('type','').lower ()=='multi_date_to_ts':#line:1097
        _OOOOOOO0000OO000O =F .udf (_O0000OOOO00O0OOO0 ,TimestampType ())#line:1098
        O00OO00O000O0OOO0 =[O0OO00O00OO000OO0 .lower ()for O0OO00O00OO000OO0 in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1100
        O00O0O00OOOO00OO0 =[OOO0O00OOOO0O0O0O .lower ()for OOO0O00OOOO0O0O0O in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:1101
        for O00O0OOO0OO0O00O0 ,O0000OOO0OO00OOO0 in zip (O00OO00O000O0OOO0 ,O00O0O00OOOO00OO0 ):#line:1102
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O0000OOO0OO00OOO0 ),_OOOOOOO0000OO000O (F .col (O00O0OOO0OO0O00O0 ).cast ("string")).alias (O0000OOO0OO00OOO0 ))#line:1103
      elif O00000OOOO00O00OO .get ('type','').lower ()=='add_hour_column':#line:1108
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names','').strip ()#line:1109
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .expr ("hour(to_timestamp(date_trunc('HOUR', current_timestamp()),'yyyy-MM-dd HH'))").alias (OO000O00O00OOOO00 ))#line:1110
      elif O00000OOOO00O00OO .get ('type','').lower ()=='add_dayofweek_column':#line:1113
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names','').strip ()#line:1114
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .expr ("weekofyear(date_trunc('WEEK', current_date()))").alias (OO000O00O00OOOO00 ))#line:1115
      elif O00000OOOO00O00OO .get ('type','').lower ()=='add_day_column':#line:1118
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names','').strip ()#line:1119
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .expr ("dayofyear(date_trunc('DAY', current_date()))").alias (OO000O00O00OOOO00 ))#line:1120
      elif O00000OOOO00O00OO .get ('type','').lower ()=='add_dayofmonth_column':#line:1123
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names','').strip ()#line:1124
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .expr ("day(date_trunc('DAY', current_date()))").alias (OO000O00O00OOOO00 ))#line:1125
      elif O00000OOOO00O00OO .get ('type','').lower ()=='add_quarter_column':#line:1128
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names','').strip ()#line:1129
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .expr ("quarter(date_trunc('QUARTER', current_date()))").alias (OO000O00O00OOOO00 ))#line:1130
      elif O00000OOOO00O00OO .get ('type','').lower ()=='add_month_column':#line:1133
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names','').strip ()#line:1134
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .expr ("month(date_trunc('MONTH', current_date()))").alias (OO000O00O00OOOO00 ))#line:1135
      elif O00000OOOO00O00OO .get ('type','').lower ()=='add_year_column':#line:1138
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names','').strip ()#line:1139
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .expr ("year(date_trunc('YEAR', current_date()))").alias (OO000O00O00OOOO00 ))#line:1140
      elif O00000OOOO00O00OO .get ('type','').lower ()=='epoc_2_timestamp':#line:1143
        O0O0OOOOOOOOOO000 =[O00O00OO0O0O0OOOO .lower ()for O00O00OO0O0O0OOOO in O00000OOOO00O00OO .get ('old_column_names','').split (',')]#line:1144
        O0O0O0OO000O0O0OO =[OO0O0O0O00O00000O .lower ()for OO0O0O0O00O00000O in O00000OOOO00O00OO .get ('new_column_names','').split (',')]#line:1145
        for OOOOOO0OO00O00OO0 ,OO000O00OOOOOOO0O in zip (O0O0OOOOOOOOOO000 ,O0O0O0OO000O0O0OO ):#line:1147
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00OOOOOOO0O ),F .expr (" from_unixtime ({val})".format (val =OOOOOO0OO00O00OO0 )).alias (OO000O00OOOOOOO0O ))#line:1148
      elif O00000OOOO00O00OO .get ('type','').lower ()=='bulk_updates':#line:1156
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ('parameter')#line:1157
        for OO00O00000OO0O0O0 in O00000OOOO00O00OO .get ('column_values',[]):#line:1158
          OOOO00OO0OOOOO0OO =OO00O00000OO0O0O0 .get ('value')#line:1159
          O0O0O00O0O0000O00 =OO00O00000OO0O0O0 .get ('old_column_names').lower ()#line:1160
          OO000O00O00OOOO00 =OO00O00000OO0O0O0 .get ('new_column_names').lower ()#line:1161
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .expr (f"CASE {OO0O000OOO00OO0O0} THEN {OOOO00OO0OOOOO0OO}  END").alias (OO000O00O00OOOO00 ))#line:1162
          OO00OO0000000O0OO .append (OO000O00O00OOOO00 )#line:1163
      elif O00000OOOO00O00OO .get ('type','').lower ()=='sql_cases':#line:1168
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ('parameter')#line:1169
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names').strip ()#line:1170
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OO000O00O00OOOO00 ),F .expr (OO0O000OOO00OO0O0 ).alias (OO000O00O00OOOO00 ))#line:1171
        OO00OO0000000O0OO .append (OO000O00O00OOOO00 )#line:1172
      elif O00000OOOO00O00OO .get ('type','').lower ()=='window_operation':#line:1176
        O000OO0OOOO000OOO ,OO00000OOO000O0O0 =O00000OOOO00O00OO .get ('new_column_names').strip ().split (",")#line:1177
        O00O000OO0000O000 =O00000OOOO00O00OO .get ('old_column_names')#line:1178
        OO0O000OOO00OO0O0 =O00000OOOO00O00OO .get ('parameter')#line:1179
        if OO00000OOO000O0O0 ==None or OO00000OOO000O0O0 .upper ()=='NA':#line:1181
          OO000OOO0OOO00O0O =Window ().partitionBy (*O00O000OO0000O000 .split (","))#line:1182
        else :#line:1184
          OO000OOO0OOO00O0O =Window ().partitionBy (*O00O000OO0000O000 .split (",")).orderBy (OO00000OOO000O0O0 )#line:1185
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (O0000OOOO00O00OO0 .columns ,O000OO0OOOO000OOO .strip ()),F .expr (OO0O000OOO00OO0O0 ).over (OO000OOO0OOO00O0O ).alias (O000OO0OOOO000OOO ))#line:1188
      elif O00000OOOO00O00OO .get ('type','').lower ()=='convert_string_to_multiple_columns':#line:1191
        O0O00O0000O0OO0O0 =O00000OOOO00O00OO .get ('parameter')#line:1192
        O0O0O00O0O0000O00 =(O00000OOOO00O00OO .get ('column_values',[])[0 ]).get ('old_column_names','NA')#line:1193
        _OO0OOO0OO0OOO000O =F .split (O0O0O00O0O0000O00 ,O0O00O0000O0OO0O0 )#line:1194
        for OOOO000000000OO0O ,OO00O00000OO0O0O0 in zip (range (len (O00000OOOO00O00OO .get ('column_values',[]))),O00000OOOO00O00OO .get ('column_values',[])):#line:1196
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select ("*",F .regexp_extract (_OO0OOO0OO0OOO000O .getItem (OOOO000000000OO0O ),OO00O00000OO0O0O0 .get ('value'),int (OO00O00000OO0O0O0 .get ('additional_params'))).alias (OO00O00000OO0O0O0 .get ('new_column_names'))).withColumn (OO00O00000OO0O0O0 .get ('new_column_names'),F .trim (F .col (OO00O00000OO0O0O0 .get ('new_column_names'))))#line:1197
      elif O00000OOOO00O00OO .get ('type','').lower ()=='convert_json_to_multiple_columns':#line:1202
        O0O00O0000O0OO0O0 =O00000OOOO00O00OO .get ('parameter').lower ()#line:1203
        OO000000O0000OOO0 =[]#line:1204
        for OO00O00000OO0O0O0 in O00000OOOO00O00OO .get ("column_values"):#line:1205
          OO000000O0000OOO0 .append (StructField (OO00O00000OO0O0O0 .get ('old_column_names'),data_type_mapping .get (OO00O00000OO0O0O0 .get ('value').lower ()),False ))#line:1206
        OO0OO0O0O0O00O0OO =StructType (OO000000O0000OOO0 )#line:1208
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .withColumn ("__idf_data",F .from_json (O0O00O0000O0OO0O0 ,OO0OO0O0O0O00O0OO )).select (*OO00OO0000000O0OO ,F .col ('__idf_data.*'))#line:1209
      elif O00000OOOO00O00OO .get ('type','').lower ()=='pivot_tables_with_group':#line:1213
        O00OOOO0000OOOOO0 =O00000OOOO00O00OO .get ("group_by_columns","").split (",")#line:1215
        OOOO0OO0000OOOO0O =O00000OOOO00O00OO .get ("pivot_column","")#line:1216
        OOO000OOOO0O0OOOO =O00000OOOO00O00OO .get ("new_column_name","")#line:1217
        OO0OO0O00OO0OO0OO =O00000OOOO00O00OO .get ("new_column_aggregation","")#line:1218
        O0OOO00O000O0O0O0 =O00000OOOO00O00OO .get ("pivot_distinct_column_names","")#line:1219
        O00O0OO0OO00000O0 ={OOO000OOOO0O0OOOO :OO0OO0O00OO0OO0OO }#line:1220
        O0O0000O00O000000 =list (map (lambda OOO00OOOOOO0O0000 :F .expr (OOO00OOOOOO0O0000 [1 ]).alias (OOO00OOOOOO0O0000 [0 ]),O00O0OO0OO00000O0 .items ()))#line:1222
        if O0OOO00O000O0O0O0 ==None or O0OOO00O000O0O0O0 .upper ()=="NA":#line:1224
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .groupby (*O00OOOO0000OOOOO0 ).pivot (OOOO0OO0000OOOO0O ).agg (*O0O0000O00O000000 )#line:1225
        else :#line:1227
          O0OOO00O000O0O0O0 =O00000OOOO00O00OO .get ("pivot_distinct_column_names","").split (",")#line:1228
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .groupby (*O00OOOO0000OOOOO0 ).pivot (OOOO0OO0000OOOO0O ,O0OOO00O000O0O0O0 ).agg (*O0O0000O00O000000 )#line:1229
      elif O00000OOOO00O00OO .get ('type','').lower ()=='melt_data_wide_to_narrow':#line:1235
        OOOO0O0OO00O0OO0O =O00000OOOO00O00OO .get ("index_columns","").split (",")#line:1237
        O00000000O00O0O0O =O00000OOOO00O00OO .get ("columns_to_melt","").split (",")#line:1238
        O000OOO000OOOOOO0 =O00000OOOO00O00OO .get ("key_column_name","")#line:1239
        O00OOO0OO0O00O0OO =O00000OOOO00O00OO .get ("value_column_name","")#line:1240
        O00O0O00OOOO000O0 =F .create_map (list (chain .from_iterable ([[F .lit (OO0OOO0OOO00OOOOO ),F .col (OO0OOO0OOO00OOOOO )]for OO0OOO0OOO00OOOOO in O00000000O00O0O0O ])))#line:1246
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*OOOO0O0OO00O0OO0O ,F .explode (O00O0O00OOOO000O0 )).withColumnRenamed ('key',O000OOO000OOOOOO0 ).withColumnRenamed ('value',O00OOO0OO0O00O0OO )#line:1248
      elif O00000OOOO00O00OO .get ('type','').lower ()=='impute_last_nonnull_within_group':#line:1252
        {"type":"impute_last_nonnull_within_group","old_column_names":"value column","new_column_names":"partition columns separated by comma","parameter":"order column, format of order column"}#line:1254
        O00O00OOO00000OO0 =O00000OOOO00O00OO .get ("old_column_names",'NA').lower ()#line:1256
        OOOO0OOO0OO00OOO0 =O00000OOOO00O00OO .get ("partition_column_names","NA").lower ().split (",")#line:1257
        OO0O000O0OOO0000O ,O0O0OO0OOO00O0OOO =O00000OOOO00O00OO .get ("parameter","NA").lower ().split (',')#line:1258
        OO000OOO0OOO00O0O =Window .partitionBy (*OOOO0OOO0OO00OOO0 ).orderBy (OO0O000O0OOO0000O )#line:1260
        OOO00OO0O0OO000O0 =Window .partitionBy (*(OOOO0OOO0OO00OOO0 +['__idf_rank1'])).orderBy (OO0O000O0OOO0000O )#line:1261
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O00O00OOO00000OO0 ),F .when (F .col (O00O00OOO00000OO0 ).isNull (),F .lit (0 )).otherwise (F .col (O00O00OOO00000OO0 )).alias (O00O00OOO00000OO0 )).select (*filter_column_names (OO00OO0000000O0OO ,OO0O000O0OOO0000O ),F .to_date (F .col (OO0O000O0OOO0000O ).cast ('string'),O0O0OO0OOO00O0OOO ).alias (OO0O000O0OOO0000O ))#line:1263
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select ("*",F .when (F .col (O00O00OOO00000OO0 )!=0 ,F .rank ().over (OO000OOO0OOO00O0O )).otherwise (F .lit (0 )).alias ("__idf_rank1")).select (*filter_column_names (O0000OOOO00O00OO0 .columns ,'__idf_rank1'),F .sum ('__idf_rank1').over (OO000OOO0OOO00O0O ).alias ('__idf_rank1')).select (*filter_column_names (O0000OOOO00O00OO0 .columns ,O00O00OOO00000OO0 ),F .sum (O00O00OOO00000OO0 ).over (OOO00OO0O0OO000O0 ).alias (O00O00OOO00000OO0 ))#line:1265
      elif O00000OOOO00O00OO .get ('type','').lower ()=='greedy_correction':#line:1272
        import sparkclean #line:1273
        O000O00O000O0O000 =[OOO0000OO00000OOO .lower ()for OOO0000OO00000OOO in O00000OOOO00O00OO .get ('partition_column_names',"").split (",")]#line:1274
        O00O00OOO00000OO0 =O00000OOOO00O00OO .get ('column_to_correct',"")#line:1275
        OO000OOO0OOO00O0O =Window ().partitionBy (*(O000O00O000O0O000 +[O00O00OOO00000OO0 ]))#line:1277
        OOO00OO0O0OO000O0 =Window ().partitionBy (*O000O00O000O0O000 ).orderBy (F .desc ('__idf_overall_count1'))#line:1278
        OO0OO0O0OOOOO0000 =Window ().partitionBy (*O000O00O000O0O000 ).orderBy ('__idf_overall_count2')#line:1279
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select ("*",F .count (O00O00OOO00000OO0 ).over (OO000OOO0OOO00O0O ).alias ('__idf_overall_count1')).select ("*",F .rank ().over (OOO00OO0O0OO000O0 ).alias ('__idf_overall_count2')).select ("*",F .when (F .col ("__idf_overall_count2")==F .lit (1 ),F .col (O00O00OOO00000OO0 )).otherwise (F .lit (None )).alias ('__idf_overall_count3')).select (*filter_column_names (OO00OO0000000O0OO ,O00O00OOO00000OO0 ),F .when (F .col ('__idf_overall_count3').isNull (),F .lag ('__idf_overall_count3').over (OO0OO0O0OOOOO0000 )).otherwise (F .col ('__idf_overall_count3')).alias (O00O00OOO00000OO0 ))#line:1281
      elif O00000OOOO00O00OO .get ('type','').lower ()=='clustering_correction':#line:1285
        import sparkclean #line:1286
        O00O00OOO00000OO0 =O00000OOOO00O00OO .get ('column_to_correct',"").lower ()#line:1287
        OO00O00O00OOO0O0O =sparkclean .DataFrameDeduplicator (O0000OOOO00O00OO0 )#line:1289
        OOO000OO0O00O000O ,O00O00000OO0000OO =OO00O00O00OOO0O0O .keyCollisionClustering (O00O00OOO00000OO0 )#line:1290
        O0OOOO0OOO00O000O =OO00O00O00OOO0O0O .preview (OOO000OO0O00O000O ,O00O00000OO0000OO )#line:1291
        try :#line:1292
          OO00O00O00OOO0O0O .resolve (OOO000OO0O00O000O ,O00O00000OO0000OO )#line:1293
          O0000OOOO00O00OO0 =OO00O00O00OOO0O0O .get_dataframe ()#line:1294
        except :#line:1296
          pass #line:1297
      elif O00000OOOO00O00OO .get ('type','').lower ()=='similarity_correction':#line:1302
        import sparkclean #line:1303
        O00O00OOO00000OO0 =O00000OOOO00O00OO .get ('column_to_correct',"").lower ()#line:1306
        OOO00O000O0O00000 =int (O00000OOOO00O00OO .get ('parameter',"").split (",")[0 ])#line:1307
        OO0O0O00OOO0OOOOO =float (O00000OOOO00O00OO .get ('parameter',"").split (",")[1 ])#line:1308
        OO00O00O00OOO0O0O =sparkclean .DataFrameDeduplicator (O0000OOOO00O00OO0 )#line:1310
        OOO000OO0O00O000O ,O00O00000OO0000OO =OO00O00O00OOO0O0O .localitySensitiveHashing (O00O00OOO00000OO0 ,blockSize =OOO00O000O0O00000 ,method ="levenshtein",threshold =OO0O0O00OOO0OOOOO )#line:1311
        try :#line:1313
          OO00O00O00OOO0O0O .resolve (OOO000OO0O00O000O ,O00O00000OO0000OO )#line:1314
          O0000OOOO00O00OO0 =OO00O00O00OOO0O0O .get_dataframe ()#line:1315
        except :#line:1317
          pass #line:1318
      elif O00000OOOO00O00OO .get ('type','').lower ()=='record_match_correction':#line:1323
        import sparkclean #line:1325
        O00O00OOO00000OO0 =O00000OOOO00O00OO .get ('column_to_correct',"").lower ().split (",")#line:1326
        OOOO0O0000OOO000O =[O0O00O0OO00000OOO .lower ()for O0O00O0OO00000OOO in O00000OOOO00O00OO .get ('partition_column_names',"").split (",")]#line:1327
        OO00O00O00OOO0O0O =sparkclean .DataFrameDeduplicator (O0000OOOO00O00OO0 )#line:1329
        OOO000OO0O00O000O ,O00O00000OO0000OO =OO00O00O00OOO0O0O .recordMatching (matchColNames =OOOO0O0000OOO000O ,fixColNames =O00O00OOO00000OO0 )#line:1330
        try :#line:1331
          OO00O00O00OOO0O0O .resolveRecords (OOO000OO0O00O000O ,O00O00000OO0000OO )#line:1332
          O0000OOOO00O00OO0 =OO00O00O00OOO0O0O .get_dataframe ()#line:1333
        except :#line:1335
          pass #line:1336
      elif O00000OOOO00O00OO .get ('type','').lower ()=='fuzzy_match':#line:1341
        """
        getBestFuzzyMatch_fn(input_df, 'country',3)
        Works with column length of 3 or more
        Ensure standardization is taken care of 
        max_distance_threshold = number of character diff. e.g in integers
        """#line:1347
        O000OO0OOOO000OOO =O00000OOOO00O00OO .get ('old_column_names').lower ()#line:1349
        OO000O00O00OOOO00 =O00000OOOO00O00OO .get ('new_column_names').lower ()#line:1350
        OOOO00OO00OOOOO00 =int (O00000OOOO00O00OO .get ('parameter'))#line:1351
        def _O000OOO0OOOOO0OO0 (OOOOO000OO0O00000 ):#line:1353
          OOOO00OO000O00OO0 =O0OO000OO00000000 .value #line:1354
          OO00O000O0OO00000 =-1 #line:1355
          O0OOOO0OO0O00O000 =None #line:1356
          for O00OOOO0OO00OOO00 in OOOOO000OO0O00000 :#line:1358
            O000OOOO0O0O0OO0O =OOOO00OO000O00OO0 .get (O00OOOO0OO00OOO00 )#line:1359
            if O000OOOO0O0O0OO0O >OO00O000O0OO00000 :#line:1360
              O0OOOO0OO0O00O000 =O00OOOO0OO00OOO00 #line:1361
              OO00O000O0OO00000 =O000OOOO0O0O0OO0O #line:1362
          return O0OOOO0OO0O00O000 #line:1366
        _OOOO0OO0O00000000 =F .udf (_O000OOO0OOOOO0OO0 ,StringType ())#line:1368
        O00O0O0OOOOOO000O =[(O00OOO000OO0OO000 [0 ],O00OOO000OO0OO000 [1 ])for O00OOO000OO0OO000 in list (map (lambda OO0OO00O000OO000O :(OO0OO00O000OO000O .get (O000OO0OOOO000OOO ),OO0OO00O000OO000O .get ('count')),[OO00OO0OOOOOOO0O0 .asDict ()for OO00OO0OOOOOOO0O0 in O0000OOOO00O00OO0 .groupby (O000OO0OOOO000OOO ).count ().collect ()]))]#line:1370
        O00OOOO000O0O0000 ={}#line:1371
        O00OOOO000O0O0000 .update (O00O0O0OOOOOO000O )#line:1372
        if None in O00OOOO000O0O0000 :#line:1374
          del O00OOOO000O0O0000 [None ]#line:1375
        O0OO000OO00000000 =O0000OO0OOO0OO0O0 .sparkContext .broadcast (O00OOOO000O0O0000 )#line:1378
        O0OOOO00O0OOO00OO ="{column_name}_first3".format (column_name =O000OO0OOOO000OOO )#line:1380
        OO0O0O0O0000OOO00 =O0000OOOO00O00OO0 .withColumn (O0OOOO00O0OOO00OO ,F .soundex (F .col (O000OO0OOOO000OOO )))#line:1381
        OO0O0O0O0000OOO00 =OO0O0O0O0000OOO00 .alias ('l').join (OO0O0O0O0000OOO00 .alias ('r'),OO0O0O0O0000OOO00 [O0OOOO00O0OOO00OO ]==OO0O0O0O0000OOO00 [O0OOOO00O0OOO00OO ],how ='inner').select ('l.{column_name}'.format (column_name =O000OO0OOOO000OOO ),'l.{first3_col_name}'.format (first3_col_name =O0OOOO00O0OOO00OO ),'r.{column_name}'.format (column_name =O000OO0OOOO000OOO )).drop_duplicates ().filter ("l.{column_name} != r.{column_name}".format (column_name =O000OO0OOOO000OOO ))#line:1383
        OO0O0O0O0000OOO00 =OO0O0O0O0000OOO00 .withColumn ('distance',F .levenshtein (F .col ("l.{column_name}".format (column_name =O000OO0OOOO000OOO )),F .col ("r.{column_name}".format (column_name =O000OO0OOOO000OOO )))).withColumn ('distance',F .when (F .col ('distance')<=F .lit (OOOO00OO00OOOOO00 ),0 )).groupby (*[O0OOOO00O0OOO00OO ,'distance']).agg (F .collect_list ("r.{column_name}".format (column_name =O000OO0OOOO000OOO )).alias ('original_{column_name}'.format (column_name =O000OO0OOOO000OOO )))#line:1385
        OO0O0O0O0000OOO00 =OO0O0O0O0000OOO00 .withColumn ('{column_name}_best_match'.format (column_name =O000OO0OOOO000OOO ),_OOOO0OO0O00000000 ('original_{column_name}'.format (column_name =O000OO0OOOO000OOO ))).select ('{column_name}_best_match'.format (column_name =O000OO0OOOO000OOO ),F .explode ('original_{column_name}'.format (column_name =O000OO0OOOO000OOO )).alias ('original_{column_name}'.format (column_name =O000OO0OOOO000OOO )))#line:1387
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .join (OO0O0O0O0000OOO00 ,O0000OOOO00O00OO0 [O000OO0OOOO000OOO ]==OO0O0O0O0000OOO00 ['original_{column_name}'.format (column_name =O000OO0OOOO000OOO )],how ='left').select (O0000OOOO00O00OO0 ['*'],OO0O0O0O0000OOO00 ['{column_name}_best_match'.format (column_name =O000OO0OOOO000OOO )]).withColumn ('{column_name}_best_match'.format (column_name =O000OO0OOOO000OOO ),F .when (F .col ('{column_name}_best_match'.format (column_name =O000OO0OOOO000OOO )).isNull (),F .col (O000OO0OOOO000OOO )).otherwise (F .col ('{column_name}_best_match'.format (column_name =O000OO0OOOO000OOO ))))#line:1389
        O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .withColumnRenamed ('{column_name}_best_match'.format (column_name =O000OO0OOOO000OOO ),OO000O00O00OOOO00 )#line:1390
        O0OO000OO00000000 .unpersist (blocking =True )#line:1392
        OO0O0O0O0000OOO00 =None #line:1394
      elif O00000OOOO00O00OO .get ('type','').lower ()=='anonymize_by_tags':#line:1397
        O00OO00O000O0OOO0 =O00000OOOO00O00OO .get ('old_column_names','NA').lower ()#line:1398
        O00O0O00OOOO00OO0 =O00000OOOO00O00OO .get ('new_column_names','NA').lower ()#line:1399
        O0O00O0000O0OO0O0 =O00000OOOO00O00OO .get ('parameter','NA').lower ()#line:1400
        if O0O00O0000O0OO0O0 .lower ()=='base64'or O0O00O0000O0OO0O0 .lower ()=='base':#line:1402
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O00OO00O000O0OOO0 .strip ()),F .base64 (F .col (O00O0O00OOOO00OO0 )).alias (O00O0O00OOOO00OO0 .strip ()))#line:1403
        elif O0O00O0000O0OO0O0 .lower ()=='hex':#line:1405
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,O00OO00O000O0OOO0 .strip ()),F .hex (F .col (O00O0O00OOOO00OO0 )).alias (O00O0O00OOOO00OO0 .strip ()))#line:1406
        elif O0O00O0000O0OO0O0 .lower ()=='sha1':#line:1408
          O0000OOOO00O00OO0 =O0000OOOO00O00OO0 .select (*filter_column_names (OO00OO0000000O0OO ,OOO000OO0O00O000O .strip ()),F .sha1 (F .col (O00O0O00OOOO00OO0 )).alias (O00O0O00OOOO00OO0 .strip ()))#line:1409
      return O0000OOOO00O00OO0 #line:1415
    finally :#line:1417
      O0000OOOO00O00OO0 =None #line:1418

# Databricks notebook source
import sys #line:2
import re #line:3
#JPM#import json #line:4
import traceback #line:5
#JPM#import uuid #line:6
from datetime import datetime #JPM#,timedelta #line:7
#JPM#import pytz #line:8
#JPM#from dateutil .relativedelta import relativedelta #line:9
#JPM#from typing import Iterable #line:10
#JPM#from itertools import *#line:11
from functools import wraps #line:12
#JPM#from inspect import getcallargs ,getargspec #line:13
#JPM#from collections import OrderedDict ,Iterable #line:14
import logging #line:15
import numpy as np #line:17
#JPM#import boto3 #line:18
#JPM#import pyspark #line:20
#JPM#from pyspark .sql import SparkSession ,Row #line:21
#JPM#from pyspark .sql import SQLContext ,DataFrame #line:22
#JPM#from pyspark .sql .types import *#line:23
import pyspark .sql .functions as F #line:24
from pyspark .sql .window import Window #line:25
#from IDF_PySpark_Common_Module import *#line:27
RECORDER_SPARK_BASE2 =[]#line:31
def log_to (O00000OO0OOO000O0 ):#line:32
    def OO000O000O0000O0O (OO0O000OO0OOO00O0 ):#line:33
      @wraps (OO0O000OO0OOO00O0 )#line:34
      def OO00O000O0O00OOOO (*O00OO0OO0000OOOO0 ,**O00O00O0000OO0O00 ):#line:35
        try :#line:36
          RECORDER_SPARK_BASE2 .append ("Function Name : {func_name} ; Time : {time} ; Arguments :  {args}".format (func_name =OO0O000OO0OOO00O0 .__name__ ,time =str (datetime .now ()),args =O00OO0OO0000OOOO0 ))#line:37
          return OO0O000OO0OOO00O0 (*O00OO0OO0000OOOO0 ,**O00O00O0000OO0O00 )#line:38
        except :#line:40
          RECORDER_SPARK_BASE2 .append ("IDF_Exception :  {exception} : {trace}".format (exception =sys .exc_info ()[0 ],trace =traceback .format_exc ()))#line:41
      return OO00O000O0O00OOOO #line:44
    return OO000O000O0000O0O #line:46
logdebug =log_to (logging .debug )#line:48
_OO0O0O00OOO0O0O00 =lambda O0O0OOOOOO0OOOOOO ,OOO00O0O0O000OO00 :list (filter (lambda O000OO0O00OOO0OO0 :O000OO0O00OOO0OO0 !=OOO00O0O0O000OO00 ,O0O0OOOOOO0OOOOOO ))#line:52
def _O00OOOOO0O0OOOO00 (OO0OOOOO00OOO0O00 ,OOO00O0O000OO0OO0 ):#line:53
  if isinstance (OO0OOOOO00OOO0O00 ,list ):#line:54
    return [OOOO0O0O0OOOO0OOO for OOOO0O0O0OOOO0OOO in OO0OOOOO00OOO0O00 if OOOO0O0O0OOOO0OOO in OOO00O0O000OO0OO0 ]#line:55
  elif isinstance (OO0OOOOO00OOO0O00 ,dict ):#line:57
    return {O00OO0O0OO0OO0OOO :O0000O0OOOOO0O000 for O00OO0O0OO0OO0OOO ,O0000O0OOOOO0O000 in OO0OOOOO00OOO0O00 .items ()if O00OO0O0OO0OO0OOO in OOO00O0O000OO0OO0 }#line:58
  elif isinstance (OO0OOOOO00OOO0O00 ,str ):#line:60
    if OO0OOOOO00OOO0O00 in OOO00O0O000OO0OO0 :#line:61
      return OO0OOOOO00OOO0O00 #line:62
    else :#line:64
      return None #line:65
class DataQualityBaseClass (object ):#line:72
  def class_type (O0000OOO0O000OO0O ):#line:73
    print ("DataQualityBaseClass")#line:74
class RowBasedDataQualityClass (DataQualityBaseClass ):#line:80
  @logdebug #line:82
  def rowBasedRulesCheck_fn (OO0OOO00O0OOO00OO ,O0O00O0000OO0OOOO ,OOOO0000O0OO0OO00 ,OOO000000OO00000O ,O00OOOO00O0O0OOO0 ,OO000OOO0OOO000O0 ,OO000O0OO00OO0O0O ):#line:83
    ""#line:171
    try :#line:172
      OOOOOO0O0O0000O00 =O00OOOO00O0O0OOO0 .get ("rule_type","NA")#line:179
      OOOO0OOO0OO00OO00 =O00OOOO00O0O0OOO0 .get ("description","NA")#line:180
      O00OOO0OOOOO00000 =[]#line:182
      if OOOOOO0O0O0000O00 .upper ()=="SQL":#line:184
        O00O00O0O000OO000 =O00OOOO00O0O0OOO0 .get ('rule','')#line:185
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:187
        O0OOO00OOO0O000O0 ={}#line:189
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:190
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:191
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','NA')#line:192
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:193
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:194
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:196
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:198
      elif OOOOOO0O0O0000O00 .upper ()=="INTEGRITY_MASTER_LIST_LOOKUP":#line:201
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:203
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:204
        if O0000OO0000OO0OOO ==None :#line:205
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:206
        if OOOO0000O0OO0OO00 .select (O0000OO0000OO0OOO ).dtypes [0 ][1 ]in ['string']:#line:209
          OOOOO0O00000OO0O0 =', '.join ('"'+OO000O0OOO0O00OOO +'"'for OO000O0OOO0O00OOO in O00OOOO00O0O0OOO0 .get ("column_values",[]))#line:210
        else :#line:212
          OOOOO0O00000OO0O0 =', '.join (O00OOOO00O0O0OOO0 .get ("column_values",[]))#line:213
        O00O00O0O000OO000 =f"CASE WHEN {O0000OO0000OO0OOO} NOT IN ({OOOOO0O00000OO0O0}) THEN 0 ELSE 1 END"#line:216
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:217
        O0OOO00OOO0O000O0 ={}#line:219
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:220
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:221
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:222
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:223
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:224
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:226
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:228
      elif OOOOOO0O0O0000O00 .upper ()=="INTEGRITY_MASTER_SQL_LOOKUP":#line:231
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:233
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:234
        if O0000OO0000OO0OOO ==None :#line:235
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:236
        OOO0O0000OO0OOOO0 =re .sub (r'select (.*?) from (.*)',lambda O00O000OO00OO0O00 :O00O000OO00OO0O00 .group (1 ),O00OOOO00O0O0OOO0 .get ("column_values",'NA'),flags =re .I |re .M )#line:239
        OO00000OO0OOOO00O =O0O00O0000OO0OOOO .sql (O00OOOO00O0O0OOO0 .get ("column_values",'NA')).withColumnRenamed (OOO0O0000OO0OOOO0 ,"idf_lookup_column_name").repartition ("idf_lookup_column_name")#line:240
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .repartition (O0000OO0000OO0OOO ).join (OO00000OO0OOOO00O ,OOOO0000O0OO0OO00 [O0000OO0000OO0OOO ]==OO00000OO0OOOO00O ['idf_lookup_column_name'],how ='left')#line:241
        O00O00O0O000OO000 =f"CASE WHEN {O0000OO0000OO0OOO} == idf_lookup_column_name THEN 1 ELSE 0 END"#line:244
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:245
        O0OOO00OOO0O000O0 ={}#line:247
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:248
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:249
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:250
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:251
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:252
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:254
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}')).drop ("idf_lookup_column_name")#line:256
        OO00000OO0OOOO00O =None #line:257
      elif OOOOOO0O0O0000O00 .upper ()=="INTEGRITY_MASTER_CSVFILE_LOOKUP":#line:261
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').lower ()#line:263
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:264
        if O0000OO0000OO0OOO ==None :#line:265
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:266
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values","NA").lower ().split (",")#line:269
        OO00000OO0OOOO00O =O0O00O0000OO0OOOO .read .format ('csv').option ('sep',',').option ('quote','"').option ('escape','"').option ("escape","\\").option ('header',"true").load (OOOOO0O00000OO0O0 [1 ])#line:271
        OO00000OO0OOOO00O =OO00000OO0OOOO00O .toDF (*(O00O0OOO0OOO0OO00 .lower ().replace ('\t','_').replace ("/","_").replace ("-","_").replace ("(","_").replace (")","_").replace ("__","_").replace ("$","_").replace (".","_").replace ('&','_').replace (":","").replace ("@","").strip ()for O00O0OOO0OOO0OO00 in OO00000OO0OOOO00O .columns ))#line:272
        OOOOOO00O0OOOO0O0 =OO00000OO0OOOO00O .select (OOOOO0O00000OO0O0 [0 ]).collect ()#line:274
        OOOOOO00O0OOOO0O0 =', '.join ('"'+O0OO0O000000O0O00 [0 ]+'"'for O0OO0O000000O0O00 in OOOOOO00O0OOOO0O0 )#line:275
        O00O00O0O000OO000 ="CASE WHEN {column_name} in ({lookup}) THEN 1 ELSE 0 END".format (column_name =O0000OO0000OO0OOO ,lookup =OOOOOO00O0OOOO0O0 )#line:277
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:278
        O0OOO00OOO0O000O0 ={}#line:280
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:281
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:282
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:283
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:284
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:285
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:287
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}')).drop ("idf_lookup_column_name")#line:289
        OO00000OO0OOOO00O =None #line:291
      elif OOOOOO0O0O0000O00 .upper ()=="INTEGRITY_MASTER_SQL_MATCH":#line:296
        O00O000O000000O0O ,O0O0OO00OO00O0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').split (",")#line:298
        O00O000O000000O0O =_O00OOOOO0O0OOOO00 (O00O000O000000O0O ,OO000OOO0OOO000O0 )#line:299
        if O00O000O000000O0O ==None :#line:300
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:301
        O0O0OO00OO00O0OOO =_O00OOOOO0O0OOOO00 (O0O0OO00OO00O0OOO ,OO000OOO0OOO000O0 )#line:304
        if O0O0OO00OO00O0OOO ==None :#line:305
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:306
        O000O0OO000OOOO0O ,O000OO000O00000O0 =re .sub (r'select (.*?),\s?(.*?) from (.*)',lambda OOOO0O0000OO00O0O :OOOO0O0000OO00O0O .group (1 )+"^^"+OOOO0O0000OO00O0O .group (2 ),O00OOOO00O0O0OOO0 .get ("column_values",'NA'),flags =re .I |re .M ).split ("^^")#line:309
        OO00000OO0OOOO00O =O0O00O0000OO0OOOO .sql (O00OOOO00O0O0OOO0 .get ("column_values",'NA')).withColumnRenamed (O000O0OO000OOOO0O ,"idf_lookup_column_name1").withColumnRenamed (O000OO000O00000O0 ,"idf_lookup_column_name2").repartition ("idf_lookup_column_name1","idf_lookup_column_name2")#line:310
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .repartition (O00O000O000000O0O ,O0O0OO00OO00O0OOO ).join (OO00000OO0OOOO00O ,OOOO0000O0OO0OO00 [O00O000O000000O0O ]==OO00000OO0OOOO00O ['idf_lookup_column_name1'],how ='left')#line:311
        O00O00O0O000OO000 =f"CASE WHEN {O00O000O000000O0O} == idf_lookup_column_name1  AND {O0O0OO00OO00O0OOO} <> idf_lookup_column_name2 THEN 0 ELSE 1 END"#line:313
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:314
        O0OOO00OOO0O000O0 ={}#line:316
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:317
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:318
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:319
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:320
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:321
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:323
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}')).drop ("idf_lookup_column_name1").drop ("idf_lookup_column_name2")#line:325
        OO00000OO0OOOO00O =None #line:326
      elif OOOOOO0O0O0000O00 .upper ()=="MINIMUM_LENGTH":#line:335
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:337
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:338
        if O0000OO0000OO0OOO ==None :#line:339
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:340
        OOOOO0O00000OO0O0 =int (O00OOOO00O0O0OOO0 .get ("column_values","0"))#line:343
        O00O00O0O000OO000 =f"CASE WHEN LENGTH({O0000OO0000OO0OOO}) < {OOOOO0O00000OO0O0} THEN 0 ELSE 1 END"#line:345
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:346
        O0OOO00OOO0O000O0 ={}#line:348
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:349
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:350
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:351
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:352
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:353
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:355
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:357
      elif OOOOOO0O0O0000O00 .upper ()=="MAXIMUM_LENGTH":#line:360
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:362
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:363
        if O0000OO0000OO0OOO ==None :#line:364
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:365
        OOOOO0O00000OO0O0 =int (O00OOOO00O0O0OOO0 .get ("column_values","0"))#line:367
        O00O00O0O000OO000 =f"CASE WHEN LENGTH({O0000OO0000OO0OOO}) > {OOOOO0O00000OO0O0} THEN 0 ELSE 1 END"#line:369
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:370
        O0OOO00OOO0O000O0 ={}#line:372
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:373
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:374
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:375
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:376
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:377
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:379
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:381
      elif OOOOOO0O0O0000O00 .upper ()=="RANGE_LENGTH_CHECK":#line:384
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').lower ()#line:385
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:386
        if O0000OO0000OO0OOO ==None :#line:388
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:389
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values","").split (",")#line:391
        O00O00O0O000OO000 ="CASE WHEN length(cast({column_name1} as string))  >= {min_range} AND length(cast({column_name2} as string)) <= {max_range} THEN 1 ELSE 0 END".format (column_name1 =O0000OO0000OO0OOO ,column_name2 =O0000OO0000OO0OOO ,min_range =float (OOOOO0O00000OO0O0 [0 ]),max_range =float (OOOOO0O00000OO0O0 [1 ]))#line:393
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:396
        O0OOO00OOO0O000O0 ={}#line:398
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:399
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:400
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:401
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:402
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:403
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:405
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:407
      elif OOOOOO0O0O0000O00 .upper ()=="RANGE_AGGREGATE_CHECK":#line:412
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').lower ()#line:413
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:414
        if O0000OO0000OO0OOO ==None :#line:416
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:417
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values","").split (",")#line:419
        O00O00O0O000OO000 ="CASE WHEN {agg_type}({column_name})  >= {min_range} AND {agg_type}({column_name}) <= {max_range} THEN 1 ELSE 0 END".format (column_name =O0000OO0000OO0OOO ,agg_type =OOOOO0O00000OO0O0 [0 ],min_range =float (OOOOO0O00000OO0O0 [1 ]),max_range =float (OOOOO0O00000OO0O0 [2 ]))#line:421
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:422
        O0OOO00OOO0O000O0 ={}#line:424
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:425
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:426
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:427
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:428
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:429
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:431
        OOO0O000OOOOOO000 =OOOO0000O0OO0OO00 .select (F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).collect ()[0 ].asDict ().get (f'__idf__dq_{OOO000000OO00000O}')#line:433
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .lit (OOO0O000OOOOOO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:435
      elif OOOOOO0O0O0000O00 .upper ()=="DATE_RANGE_CHECK":#line:447
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:449
        OOO00OOOO00OO0O0O =O00OOOO00O0O0OOO0 .get ("column_values","yyyy-MM-dd,2019-01-01,2020-01-01")#line:450
        OOOOO0O00000OO0O0 =OOO00OOOO00OO0O0O .split (',')#line:451
        OOOO0O000OO0OO000 =OOOOO0O00000OO0O0 [0 ]#line:452
        O0OOO0O00O0O000O0 ,OO000OOO00O0OOOOO =(str (datetime .date (datetime .now ())),'yyyy-MM-dd')if OOOOO0O00000OO0O0 [1 ]=='current'else (OOOOO0O00000OO0O0 [1 ],OOOO0O000OO0OO000 )#line:454
        OOOO0000O00OOO0O0 ,OO0OO0O000O00000O =(str (datetime .date (datetime .now ())),'yyyy-MM-dd')if OOOOO0O00000OO0O0 [2 ]=='current'else (OOOOO0O00000OO0O0 [2 ],OOOO0O000OO0OO000 )#line:455
        O00O00O0O000OO000 ="CASE WHEN (to_date({column_name},'{dt_format}')  >= to_date(date_format(cast(from_unixtime(unix_timestamp('{beg_date}', '{beg_fmt}')) as date), '{dt_format}'),'{dt_format}') AND to_date({column_name},'{dt_format}')  <= to_date(date_format(cast(from_unixtime(unix_timestamp('{end_date}', '{end_fmt}')) as date), '{dt_format}'),'{dt_format}')) OR ({column_name} is NULL) THEN 1 ELSE 0 END".format (column_name =O0000OO0000OO0OOO ,beg_date =O0OOO0O00O0O000O0 ,end_date =OOOO0000O00OOO0O0 ,dt_format =OOOO0O000OO0OO000 ,beg_fmt =OO000OOO00O0OOOOO ,end_fmt =OO0OO0O000O00000O )#line:457
        O00OO0O0OOOO0O00O ='__idf__dq_{rule_id}'.format (rule_id =str (OOO000000OO00000O ))#line:458
        O0OOO00OOO0O000O0 ={}#line:460
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:461
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:462
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:463
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:464
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:465
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:467
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__idf__dq_'+str (OOO000000OO00000O ),F .expr (O00O00O0O000OO000 ))#line:469
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__rule__id_'+str (OOO000000OO00000O ),F .when (F .col ('__idf__dq_'+str (OOO000000OO00000O ))==F .lit (0 ),OOOO0OOO0OO00OO00 ))#line:470
      elif OOOOOO0O0O0000O00 .upper ()=="DATE_FORMAT":#line:473
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:475
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:476
        if O0000OO0000OO0OOO ==None :#line:477
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:478
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'yyyy-MM-dd')#line:480
        O00O00O0O000OO000 =F .when (F .expr ("to_date(cast({column_name} as string),'{date_format}')".format (column_name =O0000OO0000OO0OOO ,date_format =OOOOO0O00000OO0O0 )).isNull (),F .lit (0 )).otherwise (1 )#line:482
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:483
        O0OOO00OOO0O000O0 ={}#line:485
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:486
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:487
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:488
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:489
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:490
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:492
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",O00O00O0O000OO000 .alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:494
      elif OOOOOO0O0O0000O00 .upper ()=="DATE_DIFFERENCE_CHECK_LESSTHAN":#line:497
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').split (",")#line:499
        for OOOO0O0OO0O0O00O0 in O0000OO0000OO0OOO :#line:500
          OOOO0O0OO0O0O00O0 =_O00OOOOO0O0OOOO00 (OOOO0O0OO0O0O00O0 ,OO000OOO0OOO000O0 )#line:501
          if OOOO0O0OO0O0O00O0 ==None :#line:502
            return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:503
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'1')#line:506
        O00O00O0O000OO000 =" if(abs(datediff({column_name1},{column_name2})) < {column_values}, 1,0)".format (column_name1 =O0000OO0000OO0OOO [0 ],column_name2 =O0000OO0000OO0OOO [1 ],column_values =OOOOO0O00000OO0O0 )#line:508
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:509
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:510
        O0OOO00OOO0O000O0 ={}#line:512
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:513
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:514
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:515
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:516
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:517
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:519
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:521
      elif OOOOOO0O0O0000O00 .upper ()=="DATE_DIFFERENCE_CHECK_GREATERTHAN":#line:524
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').split (",")#line:526
        for OOOO0O0OO0O0O00O0 in O0000OO0000OO0OOO :#line:527
          OOOO0O0OO0O0O00O0 =_O00OOOOO0O0OOOO00 (OOOO0O0OO0O0O00O0 ,OO000OOO0OOO000O0 )#line:528
          if OOOO0O0OO0O0O00O0 ==None :#line:529
            return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:530
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'1')#line:533
        O00O00O0O000OO000 =" if(abs(datediff({column_name1},{column_name2})) > {column_values}, 1,0)".format (column_name1 =O0000OO0000OO0OOO [0 ],column_name2 =O0000OO0000OO0OOO [1 ],column_values =OOOOO0O00000OO0O0 )#line:535
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:536
        O0OOO00OOO0O000O0 ={}#line:538
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:539
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:540
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:541
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:542
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:543
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:545
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:547
      elif OOOOOO0O0O0000O00 .upper ()=="CONTINUOUS_DATE_CHECK":#line:550
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:552
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values","NA,yyyy-MM-dd")#line:553
        OO00O0000OOOOO0O0 ,OOOO0O000OO0OO000 =OOOOO0O00000OO0O0 .split (',')#line:554
        O00O00O0O000OO000 ="CASE WHEN datediff(to_date({column_name},'{dt_format}'), (CASE WHEN lag(to_date({column_name},'{dt_format}')) over (partition by {column_value} order by to_date({column_name},'{dt_format}')) is NULL Then date ELSE lag(to_date({column_name},'{dt_format}')) over (partition by {column_value} order by to_date({column_name},'{dt_format}')) END)) <= 1 THEN 1 ELSE 0 END".format (column_name =O0000OO0000OO0OOO ,column_value =OO00O0000OOOOO0O0 ,dt_format =OOOO0O000OO0OO000 )#line:556
        O00OO0O0OOOO0O00O ='__idf__dq_{rule_id}'.format (rule_id =str (OOO000000OO00000O ))#line:557
        O0OOO00OOO0O000O0 ={}#line:559
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:560
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:561
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:562
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:563
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:564
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:566
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__idf__dq_'+str (OOO000000OO00000O ),F .expr (O00O00O0O000OO000 ))#line:568
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__rule__id_'+str (OOO000000OO00000O ),F .when (F .col ('__idf__dq_'+str (OOO000000OO00000O ))==F .lit (0 ),OOOO0OOO0OO00OO00 ))#line:569
      elif OOOOOO0O0O0000O00 .upper ()=="CONTINUOUS_NONWEEKEND_DATE_CHECK":#line:572
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:574
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values","NA,yyyy-MM-dd")#line:575
        OO00O0000OOOOO0O0 ,OOOO0O000OO0OO000 =OOOOO0O00000OO0O0 .split (',')#line:576
        O00O00O0O000OO000 ="""CASE WHEN 
                 ((datediff(to_date({column_name},'{dt_format}'), (CASE WHEN lag(to_date({column_name},'{dt_format}')) over (partition by {column_value} order by to_date({column_name},'{dt_format}')) is NULL Then to_date({column_name},'{dt_format}') ELSE lag(to_date({column_name},'{dt_format}')) over (partition by {column_value} order by to_date({column_name},'{dt_format}')) END)) <= 1)
                  AND
                  (dayofweek(to_date({column_name},'{dt_format}')) != 2))
                  OR
                 ((datediff(to_date({column_name},'{dt_format}'), (CASE WHEN lag(to_date({column_name},'{dt_format}')) over (partition by {column_value} order by to_date({column_name},'{dt_format}')) is NULL Then to_date({column_name},'{dt_format}') ELSE lag(to_date({column_name},'{dt_format}')) over (partition by {column_value} order by to_date({column_name},'{dt_format}')) END)) <= 3)
                  AND
                  (dayofweek(to_date({column_name},'{dt_format}')) = 2))
                THEN 1 ELSE 0 END""".format (column_name =O0000OO0000OO0OOO ,column_value =OO00O0000OOOOO0O0 ,dt_format =OOOO0O000OO0OO000 )#line:586
        O00OO0O0OOOO0O00O ='__idf__dq_{rule_id}'.format (rule_id =str (OOO000000OO00000O ))#line:587
        O0OOO00OOO0O000O0 ={}#line:589
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:590
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:591
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:592
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:593
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:594
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:596
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__idf__dq_'+str (OOO000000OO00000O ),F .expr (O00O00O0O000OO000 ))#line:598
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__rule__id_'+str (OOO000000OO00000O ),F .when (F .col ('__idf__dq_'+str (OOO000000OO00000O ))==F .lit (0 ),OOOO0OOO0OO00OO00 ))#line:599
      elif OOOOOO0O0O0000O00 .upper ()=="RANGE_VALUE":#line:608
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:609
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:610
        if O0000OO0000OO0OOO ==None :#line:611
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:612
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'').split (",")#line:614
        O00O00O0O000OO000 ="CASE WHEN cast({column_name1} as double)  >= {min_value} AND cast({column_name2} as double)  <= {max_value} THEN 1 ELSE 0 END".format (column_name1 =O0000OO0000OO0OOO ,min_value =float (OOOOO0O00000OO0O0 [0 ]),max_value =float (OOOOO0O00000OO0O0 [1 ]),column_name2 =O0000OO0000OO0OOO )#line:616
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:617
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:620
        O0OOO00OOO0O000O0 ={}#line:622
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:623
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:624
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:625
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:626
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:627
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:629
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:631
      elif OOOOOO0O0O0000O00 .upper ()=="CONSTANT_VALUE":#line:634
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:636
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:637
        if O0000OO0000OO0OOO ==None :#line:638
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:639
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'NA')#line:641
        if OOOO0000O0OO0OO00 .select (O0000OO0000OO0OOO ).dtypes [0 ][1 ]in ['string']:#line:642
          OOOOO0O00000OO0O0 =f'"{OOOOO0O00000OO0O0}"'#line:643
        O00O00O0O000OO000 =f"CASE WHEN {O0000OO0000OO0OOO}  <> {OOOOO0O00000OO0O0} THEN 0 ELSE 1 END"#line:646
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:647
        O0OOO00OOO0O000O0 ={}#line:649
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:650
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:651
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:652
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:653
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:654
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:656
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:658
      elif OOOOOO0O0O0000O00 .upper ()=="NONNEGATIVE_VALUE":#line:661
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:663
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:664
        if O0000OO0000OO0OOO ==None :#line:665
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:666
        O00O00O0O000OO000 =f"CASE WHEN {O0000OO0000OO0OOO}  < 0 THEN 0 ELSE 1 END"#line:669
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:670
        O0OOO00OOO0O000O0 ={}#line:672
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:673
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:674
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:675
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:676
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:677
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:679
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:681
      elif OOOOOO0O0O0000O00 .upper ()=="MINIMUM_VALUE":#line:684
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:686
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:687
        if O0000OO0000OO0OOO ==None :#line:688
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:689
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'NA')#line:692
        if OOOO0000O0OO0OO00 .select (O0000OO0000OO0OOO ).dtypes [0 ][1 ]in ['string']:#line:694
          OOOOO0O00000OO0O0 =f'"{OOOOO0O00000OO0O0}"'#line:695
        O00O00O0O000OO000 =f"CASE WHEN {O0000OO0000OO0OOO}  < {OOOOO0O00000OO0O0} THEN 0 ELSE 1 END"#line:698
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:699
        O0OOO00OOO0O000O0 ={}#line:701
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:702
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:703
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:704
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:705
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:706
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:708
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:710
      elif OOOOOO0O0O0000O00 .upper ()=="MAXIMUM_VALUE":#line:713
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:715
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:716
        if O0000OO0000OO0OOO ==None :#line:717
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:718
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'NA')#line:720
        if OOOO0000O0OO0OO00 .select (O0000OO0000OO0OOO ).dtypes [0 ][1 ]in ['string']:#line:722
          OOOOO0O00000OO0O0 =f'"{OOOOO0O00000OO0O0}"'#line:723
        O00O00O0O000OO000 =f"CASE WHEN {O0000OO0000OO0OOO}  > {OOOOO0O00000OO0O0} THEN 0 ELSE 1 END"#line:726
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:727
        O0OOO00OOO0O000O0 ={}#line:729
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:730
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:731
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:732
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:733
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:734
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:736
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:738
      elif OOOOOO0O0O0000O00 .upper ()=="NOTNULL_VALUE":#line:741
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:743
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:744
        if O0000OO0000OO0OOO ==None :#line:745
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:746
        O00O00O0O000OO000 =f"CASE WHEN {O0000OO0000OO0OOO}  IS NULL THEN 0 ELSE 1 END"#line:749
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:750
        O0OOO00OOO0O000O0 ={}#line:752
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:753
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:754
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:755
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:756
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:757
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:759
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:761
      elif OOOOOO0O0O0000O00 .upper ()=="CONTAINS_VALUE":#line:764
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:766
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:767
        if O0000OO0000OO0OOO ==None :#line:768
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:769
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'')#line:771
        O00O00O0O000OO000 =f"CASE WHEN {O0000OO0000OO0OOO} like  '%{OOOOO0O00000OO0O0}%' THEN 1 ELSE 0 END"#line:773
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:774
        O0OOO00OOO0O000O0 ={}#line:776
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:777
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:778
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:779
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:780
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:781
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:783
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:785
      elif OOOOOO0O0O0000O00 .upper ()=="CONDITIONAL_THRESHOLD_CHECK":#line:788
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:790
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'')#line:791
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:794
        OO00000OO0OOOO00O =OOOO0000O0OO0OO00 .filter ("{column_name}".format (column_name =O0000OO0000OO0OOO ,column_values =OOOOO0O00000OO0O0 ))#line:795
        O00OOO000OOO00000 =OO00000OO0OOOO00O .select (F .expr ("if(count(*) < {column_values}, 0, 1)".format (column_values =OOOOO0O00000OO0O0 ))).collect ()[0 ][0 ]#line:796
        O0OOO00OOO0O000O0 ={}#line:798
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:799
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:800
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:801
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:802
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:803
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:805
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .lit (O00OOO000OOO00000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:808
      elif OOOOOO0O0O0000O00 .upper ()=="CONDITIONAL_THRESHOLD_PERCENT_CHECK":#line:812
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:814
        OOOOO0O00000OO0O0 =OO000O0OO00OO0O0O *float (O00OOOO00O0O0OOO0 .get ("column_values",''))#line:815
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:818
        OO00000OO0OOOO00O =OOOO0000O0OO0OO00 .filter ("{column_name}".format (column_name =O0000OO0000OO0OOO ))#line:819
        O00OOO000OOO00000 =OO00000OO0OOOO00O .select (F .expr ("if(count(*) < {column_values}, 0, 1)".format (column_values =OOOOO0O00000OO0O0 ))).collect ()[0 ][0 ]#line:820
        O0OOO00OOO0O000O0 ={}#line:822
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:823
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:824
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:825
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:826
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:827
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:829
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .lit (O00OOO000OOO00000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:832
        OO00000OO0OOOO00O =None #line:833
      elif OOOOOO0O0O0000O00 .upper ()=="SIMPLE_CONDITIONAL_CHECK":#line:837
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').lower ()#line:839
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'')#line:840
        O00O00O0O000OO000 =f"if ({OOOOO0O00000OO0O0}, 1, 0)"#line:842
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:843
        O0OOO00OOO0O000O0 ={}#line:845
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:846
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:847
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:848
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:849
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:850
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:852
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:854
      elif OOOOOO0O0O0000O00 .upper ()=="ALPHANUMERIC_CHECK":#line:859
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').lower ()#line:860
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:861
        if O0000OO0000OO0OOO ==None :#line:862
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:863
        O00O00O0O000OO000 ="CASE WHEN "+str (O0000OO0000OO0OOO )+"  rlike '[^0-9A-Za-z]+' THEN 0 ELSE 1 END"#line:866
        O00OO0O0OOOO0O00O ='__idf__dq_'+str (OOO000000OO00000O )#line:867
        O0OOO00OOO0O000O0 ={}#line:869
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:870
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:871
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:872
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:873
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:874
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:876
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:878
      elif OOOOOO0O0O0000O00 .upper ()=="NUMERIC_ONLY_CHECK":#line:882
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').lower ()#line:883
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:884
        if O0000OO0000OO0OOO ==None :#line:885
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:886
        O00O00O0O000OO000 ="CASE WHEN "+str (O0000OO0000OO0OOO )+"  rlike '^[0-9]+$' THEN 1 ELSE 0 END"#line:889
        O00OO0O0OOOO0O00O ='__idf__dq_'+str (OOO000000OO00000O )#line:890
        O0OOO00OOO0O000O0 ={}#line:892
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:893
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:894
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:895
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:896
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:897
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:899
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:901
      elif OOOOOO0O0O0000O00 .upper ()=="IS_DECIMAL_CHECK":#line:905
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').lower ()#line:906
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:907
        if O0000OO0000OO0OOO ==None :#line:908
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:909
        O00O00O0O000OO000 ="CASE WHEN "+str (O0000OO0000OO0OOO )+"  rlike '^[0-9]+\.[0-9]+$' THEN 1 ELSE 0 END"#line:912
        O00OO0O0OOOO0O00O ='__idf__dq_'+str (OOO000000OO00000O )#line:913
        O0OOO00OOO0O000O0 ={}#line:915
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:916
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:917
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:918
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:919
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:920
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:922
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:924
      elif OOOOOO0O0O0000O00 .upper ()=="IS_DECIMAL_WITH_PRECISION_CHECK":#line:928
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA').lower ()#line:929
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:930
        if O0000OO0000OO0OOO ==None :#line:931
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:932
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'').split (",")#line:935
        O00O00O0O000OO000 ="CASE WHEN "+str (O0000OO0000OO0OOO )+"  rlike '^[0-9]{val1}.[0-9]{val2}$' THEN 1 ELSE 0 END".format (val1 ="{"+str (OOOOO0O00000OO0O0 [0 ])+"}",val2 ="{"+str (OOOOO0O00000OO0O0 [1 ])+"}")#line:936
        O00OO0O0OOOO0O00O ='__idf__dq_'+str (OOO000000OO00000O )#line:937
        O0OOO00OOO0O000O0 ={}#line:939
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:940
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:941
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:942
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:943
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:944
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:946
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:948
      elif OOOOOO0O0O0000O00 .upper ()=="UNIQUE_CHECK":#line:952
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:954
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:955
        if O0000OO0000OO0OOO ==None :#line:956
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:957
        O00O00O0O000OO000 =OOOO0000O0OO0OO00 .selectExpr (f"CASE WHEN count(distinct ({str(O0000OO0000OO0OOO)})) = {OO000O0OO00OO0O0O} THEN 1 ELSE 0 END").collect ()[0 ][0 ]#line:960
        O00OO0O0OOOO0O00O ='__idf__dq_'+str (OOO000000OO00000O )#line:961
        O0OOO00OOO0O000O0 ={}#line:963
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:964
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:965
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:966
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:967
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:968
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:970
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .lit (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:972
      elif OOOOOO0O0O0000O00 .upper ()=="MULTICOLUMN_SUM_EQUAL":#line:976
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:979
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values","col1,col2,col3")#line:980
        OO0OO00OOO00O0OOO =OOOOO0O00000OO0O0 .replace (',',' + ')#line:981
        O00O00O0O000OO000 ="CASE WHEN {column_name} = {cols} THEN 1 ELSE 0 END".format (column_name =O0000OO0000OO0OOO ,cols =OO0OO00OOO00O0OOO )#line:984
        O00OO0O0OOOO0O00O ='__idf__dq_{rule_id}'.format (rule_id =str (OOO000000OO00000O ))#line:985
        O0OOO00OOO0O000O0 ={}#line:987
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:988
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:989
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:990
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:991
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:992
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:994
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__idf__dq_'+str (OOO000000OO00000O ),F .expr (O00O00O0O000OO000 ))#line:996
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__rule__id_'+str (OOO000000OO00000O ),F .when (F .col ('__idf__dq_'+str (OOO000000OO00000O ))==F .lit (0 ),OOOO0OOO0OO00OO00 ))#line:997
      elif OOOOOO0O0O0000O00 .upper ()=="COLUMN_VALUE_INCREASING":#line:1000
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1003
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values","col1,col2")#line:1004
        OOOOO0O00000OO0O0 =OOOOO0O00000OO0O0 .split (',')#line:1005
        O00O00O0O000OO000 ="CASE WHEN {column_name} > lag_col THEN 1 ELSE 0 END".format (column_name =O0000OO0000OO0OOO )#line:1007
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('lag_col',F .lag (OOOOO0O00000OO0O0 [1 ]).over (Window .partitionBy (OOOOO0O00000OO0O0 [0 ]).orderBy (OOOOO0O00000OO0O0 [1 ])))#line:1008
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('lag_col',F .when (F .col ('lag_col').isNull (),F .lit (np .NINF )).otherwise (F .col ('lag_col')))#line:1009
        O00OO0O0OOOO0O00O ='__idf__dq_{rule_id}'.format (rule_id =str (OOO000000OO00000O ))#line:1011
        O0OOO00OOO0O000O0 ={}#line:1013
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1014
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1015
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1016
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1017
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1018
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1020
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__idf__dq_'+str (OOO000000OO00000O ),F .expr (O00O00O0O000OO000 ))#line:1022
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__rule__id_'+str (OOO000000OO00000O ),F .when (F .col ('__idf__dq_'+str (OOO000000OO00000O ))==F .lit (0 ),OOOO0OOO0OO00OO00 ))#line:1023
      elif OOOOOO0O0O0000O00 .upper ()=="COLUMN_VALUE_DECREASING":#line:1026
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1029
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values","col1,col2")#line:1030
        OOOOO0O00000OO0O0 =OOOOO0O00000OO0O0 .split (',')#line:1031
        O00O00O0O000OO000 ="CASE WHEN {column_name} > lag_col THEN 0 ELSE 1 END".format (column_name =O0000OO0000OO0OOO )#line:1033
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('lag_col',F .lag (OOOOO0O00000OO0O0 [1 ]).over (Window .partitionBy (OOOOO0O00000OO0O0 [0 ]).orderBy (OOOOO0O00000OO0O0 [1 ])))#line:1034
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('lag_col',F .when (F .col ('lag_col').isNull (),F .lit (np .inf )).otherwise (F .col ('lag_col')))#line:1035
        O00OO0O0OOOO0O00O ='__idf__dq_{rule_id}'.format (rule_id =str (OOO000000OO00000O ))#line:1037
        O0OOO00OOO0O000O0 ={}#line:1039
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1040
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1041
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1042
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1043
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1044
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1046
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__idf__dq_'+str (OOO000000OO00000O ),F .expr (O00O00O0O000OO000 ))#line:1048
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__rule__id_'+str (OOO000000OO00000O ),F .when (F .col ('__idf__dq_'+str (OOO000000OO00000O ))==F .lit (0 ),OOOO0OOO0OO00OO00 ))#line:1049
      elif OOOOOO0O0O0000O00 .upper ()=="REGEX_EXPRESSION":#line:1058
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1060
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:1061
        if O0000OO0000OO0OOO ==None :#line:1062
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1063
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'(.*)')#line:1065
        O00O00O0O000OO000 =f"CASE WHEN rlike ({O0000OO0000OO0OOO}, '^{OOOOO0O00000OO0O0}$') THEN 1 ELSE 0 END"#line:1067
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1068
        O0OOO00OOO0O000O0 ={}#line:1070
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1071
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1072
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1073
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1074
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1075
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1077
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:1079
      elif OOOOOO0O0O0000O00 .upper ()=="REGEX_LIBRARY":#line:1082
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1084
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:1085
        if O0000OO0000OO0OOO ==None :#line:1086
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1087
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'(.*)')#line:1089
        O00O00O0O000OO000 =f"CASE WHEN rlike ({O0000OO0000OO0OOO}, '{OOOOO0O00000OO0O0}') THEN 1 ELSE 0 END"#line:1091
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1092
        O0OOO00OOO0O000O0 ={}#line:1094
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1095
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1096
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1097
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1098
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1099
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1101
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:1103
      elif OOOOOO0O0O0000O00 .upper ()=="WILDCARD_CHECK":#line:1106
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1108
        O0000OO0000OO0OOO =_O00OOOOO0O0OOOO00 (O0000OO0000OO0OOO ,OO000OOO0OOO000O0 )#line:1109
        if O0000OO0000OO0OOO ==None :#line:1110
          return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1111
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'')#line:1113
        O00O00O0O000OO000 =f"CASE WHEN {O0000OO0000OO0OOO} like  '{OOOOO0O00000OO0O0}' THEN 1 ELSE 0 END"#line:1115
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1116
        O0OOO00OOO0O000O0 ={}#line:1118
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1119
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1120
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1121
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1122
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1123
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1125
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O00O00O0O000OO000 ).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:1127
      elif OOOOOO0O0O0000O00 .upper ()=="IS_COMPOUND_COLS_UNIQUE":#line:1130
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1134
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values","col1,col2,col3")#line:1135
        OOOOO0O00000OO0O0 =OOOOO0O00000OO0O0 .split (',')#line:1136
        O0OOO0O0O0O0O0OO0 =""#line:1138
        for OO00O00OO0OOO000O in OOOOO0O00000OO0O0 :#line:1139
          O0OOO0O0O0O0O0OO0 +="cast({each} as string),".format (each =OO00O00OO0OOO000O )#line:1140
        O0OOO0O0O0O0O0OO0 =O0OOO0O0O0O0O0OO0 [:-1 ]#line:1141
        OOO0OOOOO00OO0O0O ="concat({vals})".format (vals =O0OOO0O0O0O0O0OO0 )#line:1142
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('compound',F .expr (OOO0OOOOO00OO0O0O ))#line:1144
        O00O00O0O000OO000 =OOOO0000O0OO0OO00 .selectExpr ("CASE WHEN count(distinct (compound)) = count(compound) THEN 1 ELSE 0 END").collect ()[0 ][0 ]#line:1146
        O00OO0O0OOOO0O00O ='__idf__dq_'+str (OOO000000OO00000O )#line:1147
        O0OOO00OOO0O000O0 ={}#line:1149
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1150
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1151
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1152
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1153
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1154
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1156
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__idf__dq_'+str (OOO000000OO00000O ),F .lit (O00O00O0O000OO000 ))#line:1158
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .withColumn ('__rule__id_'+str (OOO000000OO00000O ),F .when (F .col ('__idf__dq_'+str (OOO000000OO00000O ))==F .lit (0 ),OOOO0OOO0OO00OO00 )).drop ("compound")#line:1159
      elif OOOOOO0O0O0000O00 .upper ()=="GROUP_ATLEAST1_NOTNULL":#line:1169
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1171
        for OOOO0O0OO0O0O00O0 in O0000OO0000OO0OOO .split (","):#line:1172
          OOOO0O0OO0O0O00O0 =_O00OOOOO0O0OOOO00 (OOOO0O0OO0O0O00O0 ,OO000OOO0OOO000O0 )#line:1173
          if OOOO0O0OO0O0O00O0 ==None :#line:1174
            return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1175
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'')#line:1178
        O00O00O0O000OO000 =F .array_max (F .expr (f"collect_list(if({OOOOO0O00000OO0O0} is NOT NULL,1,0)) OVER (partition by {O0000OO0000OO0OOO}) "))#line:1180
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1181
        O0OOO00OOO0O000O0 ={}#line:1183
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1184
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1185
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1186
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1187
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1188
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1190
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",O00O00O0O000OO000 .alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:1192
      elif OOOOOO0O0O0000O00 .upper ()=="GROUP_ATLEAST1_EVAL_THRESHOLD":#line:1195
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1197
        for OOOO0O0OO0O0O00O0 in O0000OO0000OO0OOO .split (","):#line:1198
          OOOO0O0OO0O0O00O0 =_O00OOOOO0O0OOOO00 (OOOO0O0OO0O0O00O0 ,OO000OOO0OOO000O0 )#line:1199
          if OOOO0O0OO0O0O00O0 ==None :#line:1200
            return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1201
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'')#line:1204
        O00O00O0O000OO000 =F .array_max (F .expr (f"collect_list(if({OOOOO0O00000OO0O0},1,0)) OVER (partition by {O0000OO0000OO0OOO}) "))#line:1206
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1207
        O0OOO00OOO0O000O0 ={}#line:1209
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1210
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1211
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1212
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1213
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1214
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1216
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",O00O00O0O000OO000 .alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:1218
      elif OOOOOO0O0O0000O00 .upper ()=="GROUP_CONDITIONAL_EVAL_THRESHOLD":#line:1221
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1223
        for OOOO0O0OO0O0O00O0 in O0000OO0000OO0OOO .split (","):#line:1224
          OOOO0O0OO0O0O00O0 =_O00OOOOO0O0OOOO00 (OOOO0O0OO0O0O00O0 ,OO000OOO0OOO000O0 )#line:1225
          if OOOO0O0OO0O0O00O0 ==None :#line:1226
            return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1227
        OOOOO0O00000OO0O0 ,OOOOO0O0000O0O00O =O00OOOO00O0O0OOO0 .get ("column_values",'').split (",")#line:1230
        O00O00O0O000OO000 =F .expr (f"count_if({OOOOO0O00000OO0O0}) OVER (partition by {O0000OO0000OO0OOO}) ")#line:1232
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1233
        O0OOO00OOO0O000O0 ={}#line:1235
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1236
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1237
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1238
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1239
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1240
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1242
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",O00O00O0O000OO000 .alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} < {OOOOO0O0000O0O00O} THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:1244
      elif OOOOOO0O0O0000O00 .upper ()=="GROUP_CONDITIONAL_UNIQUE_CHECK":#line:1247
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1249
        for OOOO0O0OO0O0O00O0 in O0000OO0000OO0OOO .split (","):#line:1250
          OOOO0O0OO0O0O00O0 =_O00OOOOO0O0OOOO00 (OOOO0O0OO0O0O00O0 ,OO000OOO0OOO000O0 )#line:1251
          if OOOO0O0OO0O0O00O0 ==None :#line:1252
            return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1253
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'')#line:1257
        OOO0O00OO0O00OO0O =Window ().partitionBy (*OOOOO0O00000OO0O0 .split (","))#line:1258
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .when (F .count ("*").over (OOO0O00OO0O00OO0O )>F .lit (1 ),F .lit (0 )).otherwise (F .lit (1 )).alias (f'__idf__dq_{OOO000000OO00000O}'))#line:1259
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1260
        O0OOO00OOO0O000O0 ={}#line:1262
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1263
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1264
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1265
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1266
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1267
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1269
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} > 1 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:1271
      elif OOOOOO0O0O0000O00 .upper ()=="GROUP_CONDITIONAL_AGG_CHECK":#line:1274
        O0000OO0000OO0OOO ,O0OOOO0OOOOOO0O0O =O00OOOO00O0O0OOO0 .get ("column_name",'NA').split (",")#line:1276
        for OOOO0O0OO0O0O00O0 in O0000OO0000OO0OOO .split (","):#line:1277
          OOOO0O0OO0O0O00O0 =_O00OOOOO0O0OOOO00 (OOOO0O0OO0O0O00O0 ,OO000OOO0OOO000O0 )#line:1278
          if OOOO0O0OO0O0O00O0 ==None :#line:1279
            return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1280
          break #line:1282
        if "=="in O0OOOO0OOOOOO0O0O :#line:1285
          O0OOOO0OOOOOO0O0O ,OO0O00000000OO0O0 =O0OOOO0OOOOOO0O0O .split ("==")#line:1286
          OOO000000O00O0OOO ="=="#line:1287
        elif '>='in O0OOOO0OOOOOO0O0O :#line:1289
          O0OOOO0OOOOOO0O0O ,OO0O00000000OO0O0 =O0OOOO0OOOOOO0O0O .split (">=")#line:1290
          OOO000000O00O0OOO =">="#line:1291
        elif '>'in O0OOOO0OOOOOO0O0O :#line:1293
          O0OOOO0OOOOOO0O0O ,OO0O00000000OO0O0 =O0OOOO0OOOOOO0O0O .split (">")#line:1294
          OOO000000O00O0OOO =">"#line:1295
        elif '<='in O0OOOO0OOOOOO0O0O :#line:1297
          O0OOOO0OOOOOO0O0O ,OO0O00000000OO0O0 =O0OOOO0OOOOOO0O0O .split ("<=")#line:1298
          OOO000000O00O0OOO ="<="#line:1299
        elif '<'in O0OOOO0OOOOOO0O0O :#line:1301
          O0OOOO0OOOOOO0O0O ,OO0O00000000OO0O0 =O0OOOO0OOOOOO0O0O .split ("<")#line:1302
          OOO000000O00O0OOO ="<"#line:1303
        elif "!="in O0OOOO0OOOOOO0O0O :#line:1305
          O0OOOO0OOOOOO0O0O ,OO0O00000000OO0O0 =O0OOOO0OOOOOO0O0O .split ("!=")#line:1306
          OOO000000O00O0OOO ="!="#line:1307
        elif "="in O0OOOO0OOOOOO0O0O :#line:1309
          O0OOOO0OOOOOO0O0O ,OO0O00000000OO0O0 =O0OOOO0OOOOOO0O0O .split ("=")#line:1310
          OOO000000O00O0OOO ="="#line:1311
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'')#line:1314
        OOO0O00OO0O00OO0O =Window ().partitionBy (*OOOOO0O00000OO0O0 .split (","))#line:1315
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .expr (O0OOOO0OOOOOO0O0O ).over (OOO0O00OO0O00OO0O ).alias ('__idf__dq_check'))#line:1316
        O00O00O0O000OO000 =F .expr ("CASE WHEN __idf__dq_check {agg_op} {agg_eval} THEN 1 ELSE 0 END".format (agg_op =OOO000000O00O0OOO ,agg_eval =OO0O00000000OO0O0 ))#line:1318
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1319
        O0OOO00OOO0O000O0 ={}#line:1321
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1322
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1323
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1324
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1325
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1326
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1328
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",O00O00O0O000OO000 .alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} ==0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}'))#line:1330
      elif OOOOOO0O0O0000O00 .upper ()=="ATLEAST_1NULL_WITHIN_GROUP_CHECK":#line:1334
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1336
        for OOOO0O0OO0O0O00O0 in O0000OO0000OO0OOO .split (","):#line:1337
          OOOO0O0OO0O0O00O0 =_O00OOOOO0O0OOOO00 (OOOO0O0OO0O0O00O0 ,OO000OOO0OOO000O0 )#line:1338
          if OOOO0O0OO0O0O00O0 ==None :#line:1339
            return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1340
        OOOOO0O00000OO0O0 =O00OOOO00O0O0OOO0 .get ("column_values",'')#line:1343
        O00O00O0O000OO000 =F .expr (f"count_if({OOOOO0O00000OO0O0} IS NULL ) OVER (partition by {O0000OO0000OO0OOO}) ")#line:1344
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1345
        O0OOO00OOO0O000O0 ={}#line:1347
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1348
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1349
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1350
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1351
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1352
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1354
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",O00O00O0O000OO000 .alias ('__idf__dq_test')).select ("*",F .expr ("if(__idf__dq_test == 0,1,0)").alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} == 0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}')).drop ('__idf__dq_test')#line:1356
      elif OOOOOO0O0O0000O00 .upper ()=="UNIQUE_WITHIN_GROUP_CHECK":#line:1359
        O0000OO0000OO0OOO =O00OOOO00O0O0OOO0 .get ("column_name",'NA')#line:1361
        for OOOO0O0OO0O0O00O0 in O0000OO0000OO0OOO .split (","):#line:1362
          OOOO0O0OO0O0O00O0 =_O00OOOOO0O0OOOO00 (OOOO0O0OO0O0O00O0 ,OO000OOO0OOO000O0 )#line:1363
          if OOOO0O0OO0O0O00O0 ==None :#line:1364
            return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1365
        O00OO0O0OOOO0O00O =f'__idf__dq_{str(OOO000000OO00000O)}'#line:1369
        O0OOO00OOO0O000O0 ={}#line:1370
        O0OOO00OOO0O000O0 ['rule_id']=OOO000000OO00000O #line:1371
        O0OOO00OOO0O000O0 ['column_id']=O00OO0O0OOOO0O00O #line:1372
        O0OOO00OOO0O000O0 ['column_name']=O00OOOO00O0O0OOO0 .get ('column_name','')#line:1373
        O0OOO00OOO0O000O0 ['description']=O00OOOO00O0O0OOO0 .get ("description")#line:1374
        O0OOO00OOO0O000O0 ['check_type']=O00OOOO00O0O0OOO0 .get ("check_type")#line:1375
        O00OOO0OOOOO00000 .append (O0OOO00OOO0O000O0 )#line:1377
        OOO0O00OO0O00OO0O =Window ().partitionBy (*O0000OO0000OO0OOO .split (",")).orderBy (*O0000OO0000OO0OOO .split (","))#line:1379
        OOOO0000O0OO0OO00 =OOOO0000O0OO0OO00 .select ("*",F .dense_rank ().over (OOO0O00OO0O00OO0O ).alias ("__idf_tmp_col1"),F .row_number ().over (OOO0O00OO0O00OO0O ).alias ("__idf_tmp_col2")).select ("*",F .max ("__idf_tmp_col2").over (OOO0O00OO0O00OO0O ).alias ('__idf_tmp_col3')).select ("*",F .when (F .col ('__idf_tmp_col3')!=F .col ("__idf_tmp_col1"),F .lit (0 )).otherwise (F .lit (1 )).alias (f'__idf__dq_{OOO000000OO00000O}')).select ("*",F .expr (f" CASE WHEN __idf__dq_{OOO000000OO00000O} == 0 THEN '{OOOO0OOO0OO00OO00}' END ").alias (f'__rule__id_{OOO000000OO00000O}')).drop ('__idf_tmp_col1','__idf_tmp_col2','__idf_tmp_col3')#line:1381
      for O000O0OOO0O0OOOOO in O00OOO0OOOOO00000 :#line:1385
        O0OOO00OOO0O000O0 ={}#line:1386
        O0000OO0000OO0OOO =O000O0OOO0O0OOOOO .get ("column_id")#line:1387
        O000O0OOO0O0OOOOO ['rule_rejected_rows']=OOOO0000O0OO0OO00 .where (F .col (O0000OO0000OO0OOO )==F .lit (0 )).count ()#line:1388
        O000O0OOO0O0OOOOO ['rule_validated_rows']=OO000O0OO00OO0O0O -O000O0OOO0O0OOOOO ['rule_rejected_rows']#line:1389
      return (O00OOO0OOOOO00000 ,OOOO0000O0OO0OO00 )#line:1393
    finally :#line:1395
      return ([],OOOO0000O0OO0OO00 )#line:1396
      OOOO0000O0OO0OO00 =None #line:1397
@logdebug #line:1404
def consolidateRowBasedDQConditionRows_fn (OOO00O0O000OOOOOO ):#line:1405
    ""#line:1407
    try :#line:1408
      O00O0OOO0OO0OO0OO =re .compile ("__idf__dq_*")#line:1409
      OO00O0O00O000OOO0 =list (filter (O00O0OOO0OO0OO0OO .match ,OOO00O0O000OOOOOO .columns ))#line:1410
      O0000OO00OOO00O00 =""#line:1412
      for OOOOO00OO0OOOOOOO in OO00O0O00O000OOO0 :#line:1413
        O0000OO00OOO00O00 =O0000OO00OOO00O00 +f"IFNULL({OOOOO00OO0OOOOOOO},1) *"#line:1414
      O0000OO00OOO00O00 =O0000OO00OOO00O00 [:-1 ]#line:1416
      return OOO00O0O000OOOOOO .select ("*",F .expr (O0000OO00OOO00O00 ).alias ('__idf__dq_final')).drop (*OO00O0O00O000OOO0 )#line:1418
    finally :#line:1420
      OOO00O0O000OOOOOO =None #line:1421
@logdebug #line:1425
def consolidateRowBasedDQErrorDescription_fn (O0O000O0OO0000OO0 ):#line:1426
  ""#line:1428
  try :#line:1429
    OO000O000OO0O0O00 =re .compile ("__rule__id_*")#line:1430
    OO00OO0OOO000O0OO =list (filter (OO000O000OO0O0O00 .match ,O0O000O0OO0000OO0 .columns ))#line:1431
    return O0O000O0OO0000OO0 .select ("*",F .array (*OO00OO0OOO000O0OO ).alias ('_error_condition_analysis_tmp')).select ("*",F .array_except ('_error_condition_analysis_tmp',F .array (F .lit (None ).cast ('string'))).alias ('_error_condition_analysis1')).drop (*OO00OO0OOO000O0OO ).drop ('_error_condition_analysis_tmp').select ("*",F .concat_ws (";",F .col ('_error_condition_analysis1')).alias ("_error_condition_analysis")).drop ("_error_condition_analysis1")#line:1433
  finally :#line:1435
    O0O000O0OO0000OO0 =None #line:1436
@logdebug #line:1440
def removeExtraColumnsFromDFWithRegex_fn (O00000OOOO00OOOO0 ):#line:1441
  ""#line:1443
  try :#line:1444
    OOO00OOO0O0000OO0 =re .compile ("__rule__id_*")#line:1445
    OO0O00OO000000O0O =list (filter (OOO00OOO0O0000OO0 .match ,O00000OOOO00OOOO0 .columns ))#line:1446
    return O00000OOOO00OOOO0 .drop (*OO0O00OO000000O0O )#line:1448
  finally :#line:1450
    O00000OOOO00OOOO0 =None #line:1451

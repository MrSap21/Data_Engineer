# Databricks notebook source
# Databricks notebook source
#JPM#import sys
import re

regexMap = {}

# COMMAND ----------

#######COMMON
regexMap['MONEY_PATTERN'] =  re.compile(r'^(-?[0-9]\d{0,7}(?:\.\d{2}))$',re.I|re.M)
regexMap['EMAIL'] = re.compile(r'^[_A-Za-z0-9-\\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$',re.I|re.M)
regexMap['TIMESTAMP_PATTERN'] = re.compile(r'^\d{4}-([1-9]|0[1-9]|1[0-2])-([1-9]|0[1-9]|1\d|2\d|3[01])\s?(\d{2}:\d{2}:\d{2})?$',re.I|re.M)
regexMap['DATE_YYYYMMDD'] = re.compile(r'^\d{4}\/([1-9]|0[1-9]|1[0-2])\/([1-9]|0[1-9]|1\d|2\d|3[01])$',re.I|re.M)
regexMap['DATE_MMDDYYYY'] = re.compile(r'^([1-9]|0[1-9]|1[0-2])\/([1-9]|0[1-9]|1\d|2\d|3[01])\/\d{4}$',re.I|re.M)
regexMap['CURRENCY_TYPE'] =  re.compile(r'^((USD)|(EUR)|(CAD)|(INR)|(AUD)|(EURO)|(GBP))$',re.I|re.M)
regexMap['LAT_LON'] = re.compile(r'^(\(?)[-+]?([1-8]?\d(\.\d+)?|90(\.0+)?),\s*[-+]?(180(\.0+)?|((1[0-7]\d)|([1-9]?\d))(\.\d+)?(\)?))$',re.I|re.M)
regexMap['CREDIT_CARD'] = re.compile(r'^(4[0-9]{12}(?:[0-9]{3})?)|((?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|(6(?:011|5[0-9]{2})[0-9]{12})|((?:2131|1800|35\d{3})\d{11})$',re.I|re.M)
regexMap['GENDER'] = re.compile(r'^(?:m|M|male|Male|f|F|female|Female)$',re.I|re.M)
regexMap['COUNTRY_CODE'] = re.compile(r'\b(AF|AX|AL|DZ|AS|AD|AO|AI|AQ|AG|AR|AM|AW|AU|AT|BS|BH|BD|BB|BY|BE|BZ|BJ|BM|BT|BO|BQ|BA|BW|BV|BR|IO|BN|BG|BF|BI|KH|CM|CA|CV|KY|CF|TD|CL|CN|CX|CC|CO|KM|CG|CD|CK|CR|CI|HR|CU|CW|CY|CZ|DK|DJ|DM|DO|EC|EG|SV|GQ|ER|EE|ET|FK|FO|FJ|FI|FR|GF|PF|TF|GA|GM|GE|DE|GH|GI|GR|GL|GD|GP|GU|GT|GG|GN|GW|GY|HT|HM|VA|HN|HK|HU|IS|IN|ID|IR|IQ|IE|IM|IL|IT|JM|JP|JE|JO|KZ|KE|KI|KP|KR|KW|KG|LA|LV|LB|LS|LR|LY|LI|LT|LU|MO|MK|MG|MW|MY|MV|ML|MT|MH|MQ|MR|MU|YT|MX|FM|MD|MC|MN|ME|MS|MA|MZ|MM|NA|NR|NP|NL|NC|NZ|NI|NE|NG|NU|NF|MP|NO|OM|PK|PW|PS|PA|PG|PY|PE|PH|PN|PL|PT|PR|QA|RE|RO|RU|RW|BL|SH|KN|LC|MF|PM|VC|WS|SM|ST|SA|SN|RS|SC|SL|SG|SX|SK|SI|SB|SO|ZA|GS|SS|ES|LK|SD|SR|SJ|SZ|SE|CH|SY|TW|TJ|TZ|TH|TL|TG|TK|TO|TT|TN|TR|TM|TC|TV|UG|UA|AE|GB|US|UM|UY|UZ|VU|VE|VN|VG|VI|WF|EH|YE|ZM|ZW|AFG|ALB|DZA|ASM|AND|AGO|AIA|ATA|ATG|ARG|ARM|ABW|AUS|AUT|AZE|BHS|BHR|BGD|BRB|BLR|BEL|BLZ|BEN|BMU|BTN|BOL|BIH|BWA|BVT|BRA|IOT|VGB|BRN|BGR|BFA|BDI|KHM|CMR|CAN|CPV|CYM|CAF|TCD|CHL|CHN|CXR|CCK|COL|COM|COD|COG|COK|CRI|CIV|CUB|CYP|CZE|DNK|DJI|DMA|DOM|ECU|EGY|SLV|GNQ|ERI|EST|ETH|FRO|FLK|FJI|FIN|FRA|GUF|PYF|ATF|GAB|GMB|GEO|DEU|GHA|GIB|GRC|GRL|GRD|GLP|GUM|GTM|GIN|GNB|GUY|HTI|HMD|VAT|HND|HKG|HRV|HUN|ISL|IND|IDN|IRN|IRQ|IRL|ISR|ITA|JAM|JPN|JOR|KAZ|KEN|KIR|PRK|KOR|KWT|KGZ|LAO|LVA|LBN|LSO|LBR|LBY|LIE|LTU|LUX|MAC|MKD|MDG|MWI|MYS|MDV|MLI|MLT|MHL|MTQ|MRT|MUS|MYT|MEX|FSM|MDA|MCO|MNG|MSR|MAR|MOZ|MMR|NAM|NRU|NPL|ANT|NLD|NCL|NZL|NIC|NER|NGA|NIU|NFK|MNP|NOR|OMN|PAK|PLW|PSE|PAN|PNG|PRY|PER|PHL|PCN|POL|PRT|PRI|QAT|REU|ROU|RUS|RWA|SHN|KNA|LCA|SPM|VCT|WSM|SMR|STP|SAU|SEN|SCG|SYC|SLE|SGP|SVK|SVN|SLB|SOM|ZAF|SGS|ESP|LKA|SDN|SUR|SJM|SWZ|SWE|CHE|SYR|TWN|TJK|TZA|THA|TLS|TGO|TKL|TON|TTO|TUN|TUR|TKM|TCA|TUV|VIR|UGA|UKR|ARE|GBR|UMI|USA|URY|UZB|VUT|VEN|VNM|WLF|ESH|YEM|ZMB|ZWE)\b',re.I|re.M)
regexMap['COUNTRY_NAME'] = re.compile(r'\b(Afghanistan|Albania|Algeria|Andorra|Angola|Antigua and Barbuda|Argentina|Armenia|Australia|Austria|Azerbaijan|The Bahamas|Bahrain|Bangladesh|Barbados|Belarus|Belgium|Belize|Benin|Bhutan|Bolivia|Bosnia and Herzegovina|Botswana|Brazil|Brunei|Bulgaria|Burkina Faso|Burundi|Cabo Verde|Cambodia|Cameroon|Canada|Central African Republic|Chad|Chile|China|Colombia|Comoros|Congo| Democratic Republic of the|Congo| Republic of the|Costa Rica|Côte d’Ivoire|Croatia|Cuba|Cyprus|Czech Republic|Denmark|Djibouti|Dominica|Dominican Republic|East Timor (Timor-Leste)|Ecuador|Egypt|El Salvador|Equatorial Guinea|Eritrea|Estonia|Eswatini|Ethiopia|Fiji|Finland|France|Gabon|The Gambia|Georgia|Germany|Ghana|Greece|Grenada|Guatemala|Guinea|Guinea-Bissau|Guyana|Haiti|Honduras|Hungary|Iceland|India|Indonesia|Iran|Iraq|Ireland|Israel|Italy|Jamaica|Japan|Jordan|Kazakhstan|Kenya|Kiribati|Korea| North|Korea| South|Kosovo|Kuwait|Kyrgyzstan|Laos|Latvia|Lebanon|Lesotho|Liberia|Libya|Liechtenstein|Lithuania|Luxembourg|Madagascar|Malawi|Malaysia|Maldives|Mali|Malta|Marshall Islands|Mauritania|Mauritius|Mexico|Micronesia| Federated States of|Moldova|Monaco|Mongolia|Montenegro|Morocco|Mozambique|Myanmar|Burma|Namibia|Nauru|Nepal|Netherlands|New Zealand|Nicaragua|Niger|Nigeria|North Macedonia|Norway|Oman|Pakistan|Palau|Panama|Papua New Guinea|Paraguay|Peru|Philippines|Poland|Portugal|Qatar|Romania|Russia|Rwanda|Saint Kitts and Nevis|Saint Lucia|Saint Vincent and the Grenadines|Samoa|San Marino|Sao Tome and Principe|Saudi Arabia|Senegal|Serbia|Seychelles|Sierra Leone|Singapore|Slovakia|Slovenia|Solomon Islands|Somalia|South Africa|Spain|Sri Lanka|Sudan|Sudan| South|Suriname|Sweden|Switzerland|Syria|Taiwan|Tajikistan|Tanzania|Thailand|Togo|Tonga|Trinidad and Tobago|Tunisia|Turkey|Turkmenistan|Tuvalu|Uganda|Ukraine|United Arab Emirates|United Kingdom|United States|Uruguay|Uzbekistan|Vanuatu|Vatican City|Venezuela|Vietnam|Yemen|Zambia|Zimbabwe)\b',re.I|re.M)
regexMap['URL'] = re.compile(r'^((?:ht|f)tps?)\:\/\/([a-zA-Z0-9\-\._]+:[a-zA-Z0-9\-\._]+@)?((?:[a-zA-Z0-9\-\._]+(?:\.[a-zA-Z0-9\-\._]+)+)|localhost)(\/?)([a-zA-Z0-9\-\.\,\'\/\+\&%\$_\\]*)?([\d\w\.\/\%\+\-\=\&\?\:\"\'\,\|\~\;#\\]*)$',re.I|re.M)
regexMap['COLOR_HEX_CODE'] = re.compile(r'^\#[A-Fa-f0-9]{3}([A-Fa-f0-9]{3})?$',re.IGNORECASE)
regexMap['DATA_URL'] = re.compile(r'^(?:data)\:([a-z]+\/[a-z]+)?(;charset=([\w-])*)?(;base64)?,([\w\!\$\&\'\,\(\)\*\+\,\;\=\-\.\_\~\:\@\/\?\%\s]+)$',re.IGNORECASE)
regexMap['FILE_URL'] = re.compile(r'^(?:file)\:(?:\/){2,3}((?:[a-zA-Z0-9\-\._]+(?:[a-zA-Z0-9\-\.\:\|_]+)+)|localhost)\/([a-zA-Z0-9\-\.\/\+\&\%\$_\|\:]*)?$',re.IGNORECASE)
regexMap['GPS_DECIMAL_FORMAT'] = re.compile(r'^(\d{1,3}[\.]\d*)[, ]+-?(\d{1,3}[\.]\d*)$',re.IGNORECASE)
regexMap['LAT_LON_DEGREE'] = re.compile(r'^[NS] \d{1,}(\:[0-5]\d){2}.{0,1}\d{0,},[EW] \d{1,}(\:[0-5]\d){2}.{0,1}\d{0,}$',re.IGNORECASE)
regexMap['HDFS_URL'] = re.compile(r'^(?:hdfs)\:\/\/((?:[a-zA-Z0-9\-\._]+(?:\.[a-zA-Z0-9\-\._]+)+)|localhost)\/([a-zA-Z0-9\-\.\/\+\&\%\$_\\]*)?([\d\w\.\/\%\+\-\=\&\#\~]*)$',re.IGNORECASE)
regexMap['IBAN'] = re.compile(r'^[a-zA-Z]{2}[0-9]{2}\ ?([a-zA-Z0-9]{4}\ ?){2,6}([a-zA-Z0-9]{4}\ ?|[a-zA-Z0-9])?[a-zA-Z0-9]{0,2}$',re.IGNORECASE)
regexMap['ISBN-10'] = re.compile(r'^ISBN(?:-10)?:?\ *((?=\d{1,5}([ -]?)\d{1,7}\2?\d{1,6}\2?\d)(?:\d\2*){9}[\dX])$',re.IGNORECASE)
regexMap['ISBN-13'] = re.compile(r'^ISBN(?:-13)?:?\ *(97(?:8|9)([ -]?)(?=\d{1,5}\2?\d{1,7}\2?\d{1,6}\2?\d)(?:\d\2*){9}\d)$',re.IGNORECASE)
regexMap['MAC_ADDRESS'] = re.compile(r'^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$',re.IGNORECASE)
regexMap['MAILTO_URL'] = re.compile(r'^(?:mailto)\:([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}(,)?)*((?:\?)((subject|to|body|cc)=(([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4})|([\d\w\.\/\%\+\-\=\&\?\:\"\'\,\|\~\;#\\])*)+(\&)?)*)*$',re.IGNORECASE)
regexMap['WEB_DOMAIN'] = re.compile(r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,24}$',re.IGNORECASE)
regexMap['IPv4_ADDRESS'] = re.compile(r'^([01]?[\d][\d]?|2[0-4][\d]|25[0-5])\.([01]?[\d][\d]?|2[0-4][\d]|25[0-5])\.([01]?[\d][\d]?|2[0-4][\d]|25[0-5])\.([01]?[\d][\d]?|2[0-4][\d]|25[0-5])$',re.IGNORECASE)
regexMap['IPv6_ADDRESS'] = re.compile(r'^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$',re.IGNORECASE)
regexMap['MARITAL_STATUS'] = re.compile(r'^((Married)|(Single)|(Divorced)|(Widowed))$',re.IGNORECASE)
regexMap['PHONE_NUMBER'] = re.compile(r'^(\+?([0-9]{1,4})?\-?\s?(\d{3}\-\d{3}\-\d{4})|(\+?([0-9]{1,4})?\-?\s?\(\d{3}\)\s?\d{3}\-\d{4})|(\+?([0-9]{1,4})?\-?\s?\(\d{3}\)\s?\d{3}\s\d{4})|(\+?([0-9]{1,4})?\-?\s?\d{3}\s\d{3}\s\d{4})|(\+?([0-9]{1,4})?\-?\s?\(\d{3}\)\-\d{3}\-\d{4}))$',re.IGNORECASE)
#regexMap['PASSWORD'] = re.compile(r'^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\S+$).{8,}$',re.I|re.M)
regexMap['HTML_TAGS'] = re.compile(r"<(\"[^\"]*\"|'[^']*'|[^'\">])*>",re.I|re.M)
regexMap['LINUX_PATH'] = re.compile(r'^(\/\w+)+$',re.I|re.M)


#######USA
regexMap['US_SSN'] = re.compile(r'^(?!000|666)[0-9]{3}([ -]?)(?!00)[0-9]{2}\1(?!0000)[0-9]{4}$',re.I|re.M)
regexMap['US_STATE_CODE'] = re.compile(r'\b(AZ|SC|LA|MN|NJ|DC|OR|VA|None|RI|KY|WY|NH|MI|NV|WI|ID|CA|NE|CT|MT|NC|MD|DE|MO|IL|ME|ND|WA|MS|AL|IN|OH|TN|IA|NM|PA|SD|NY|TX|WV|GA|MA|KS|FL|CO|AK|AR|OK|PR|UT|HI|VT)\b',re.I|re.M)
regexMap['US_STATE_NAME'] = re.compile(r'\b(Alabama|Alaska|Arizona|Arkansas|California|Colorado|Connecticut|Delaware|Florida|Georgia|Hawaii|Idaho|Illinois|Indiana|Iowa|Kansas|Kentucky|Louisiana|Maine|Maryland|Massachusetts|Michigan|Minnesota|Mississippi|Missouri|Montana|Nebraska|Nevada|New Hampshire|New Jersey|New Mexico|New York|North Carolina|North Dakota|Ohio|Oklahoma|Oregon|Pennsylvania|Rhode Island|South Carolina|South Dakota|Tennessee|Texas|Utah|Vermont|Virginia|Washington|West Virginia|Wisconsin|Wyoming)\b',re.I|re.M)
regexMap['US_POSTAL_CODE'] = re.compile(r'^[0-9]{5}(?:-[0-9]{4})?$',re.I|re.M)



#######UK
regexMap['UK_DRIVING_LICENCE_NUMBER'] = re.compile(r'^(?:[A-Z]{1}[9]{4}|[A-Z]{2}[9]{3}|[A-Z]{3}[9]{2}|[A-Z]{4}[9]{1}|[A-Z]{5})[0-9]{6}(?:[A-Z]{1}[9]{1}|[A-Z]{2})[0-9]{5}$',re.I|re.M)
regexMap['UK_PASSPORT_NUMBER'] = re.compile(r'^([0-9]{10}GBR[0-9]{7}[U,M,F]{1}[0-9]{9})|([A-Z]{1}-[0-9]{7})$',re.I|re.M)
regexMap['UK_VAT'] = re.compile(r'^(GB)([0-9]{9}([0-9]{3})?|[A-Z]{2}[0-9]{3})$',re.I|re.M)


#######INDIA
regexMap['INDIAN_PASSPORT_NUMBER'] = re.compile(r'^(?![QXZ])[A-Z]{1}-?\s?[1-9]{1}[0-9]{2}\s?[0-9]{3}[1-9]{1}$',re.I|re.M)
regexMap['INDIA_DRIVING_LICENCE_NUMBER'] = re.compile(r'^[A-Z]{2}\s?\-?[0-9]{13}$',re.I|re.M)
regexMap['INDIA_GST'] = re.compile(r'^([0][1-9]|[1-2][0-9]|[3][0-5])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$',re.I|re.M)
regexMap['INDIA_PAN'] = re.compile(r'^[A-Z]{3}[ABCFGHLJPT][A-Z][0-9]{4}[A-Z]$',re.I|re.M)


#######GERMANY
regexMap['GERMAN_PASSPORT_NUMBER'] = re.compile(r'^(?![ABDEIOQSU])(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]{9})$',re.I|re.M)
regexMap['GERMANY_VAT'] = re.compile(r'^(DE)[0-9]{9}$',re.I|re.M)


#####FRANCE 
regexMap['FRANCE_VAT'] = re.compile(r'^(FR)[0-9A-Z]{2}[0-9]{9}$',re.I|re.M)


####Health-Care Domain
regexMap['ICD_CODE'] = re.compile(r'^[A-Z]{1}\d{2}\-[A-Z]{1}\d{2}$',re.I|re.M)
regexMap['OPS_TAXONOMY'] = re.compile(r'^\d{3}.{6}\w{1}$',re.I|re.M)


#####Banking Domain 
regexMap['BANK_IDENTIFIER_CODE'] = re.compile(r'^[A-Z]{4}\s[A-Z]{2}\s[a-zA-Z0-9]{2}\s[a-zA-Z0-9]{3}$',re.I|re.M)
regexMap['IFS_CODE'] = re.compile(r'^[A-Z]{4}[0][0-9]{6}$',re.I|re.M)



####CLIENT
# Databricks notebook source
import sys #line:2
#JPM#import re #line:3
#JPM#import json #line:4
import traceback #line:5
#JPM#import uuid #line:6
from datetime import datetime #JPM#,timedelta #line:7
#JPM#import pytz #line:8
#JPM#from dateutil .relativedelta import relativedelta #line:9
#JPM#from typing import Iterable #line:10
#JPM#from itertools import *#line:11
from functools import wraps #line:12
#JPM#from inspect import getcallargs ,getargspec #line:13
#JPM#from collections import OrderedDict ,Iterable #line:14
import logging #line:15
#JPM#import pyspark #line:17
#JPM#from pyspark .sql import SparkSession ,Row #line:18
#JPM#from pyspark .sql import SQLContext ,DataFrame #line:19
from pyspark .sql .types import *#line:20
import pyspark .sql .functions as F #line:21
from pyspark .sql .window import Window #line:22
RECORDER_SPARK_BASE3 =[]#line:27
def log_to (O00O0000000O00O0O ):#line:28
    def OOOO0O0000OOOOO0O (OO0O0000O000O0O00 ):#line:29
      @wraps (OO0O0000O000O0O00 )#line:30
      def OO0OO000000O00OOO (*OOO00000OO0OOO00O ,**O00O00000OO0OO00O ):#line:31
        try :#line:32
          if "password"in str (OOO00000OO0OOO00O ):#line:33
            for OO00OO0O00OOO0OO0 in range (len (OOO00000OO0OOO00O )):#line:34
              if isinstance (OOO00000OO0OOO00O [OO00OO0O00OOO0OO0 ],dict ):#line:35
                OO0OO000000OO0OO0 =OOO00000OO0OOO00O [OO00OO0O00OOO0OO0 ].copy ()#line:36
                OO0OO000000OO0OO0 ['password']="XXXXXXXXX"#line:37
                RECORDER_SPARK_BASE3 .append ("Function Name : {func_name} ; Time : {time} ; Arguments :  {args}".format (func_name =OO0O0000O000O0O00 .__name__ ,time =str (datetime .now ()),args =OO0OO000000OO0OO0 ))#line:38
          else :#line:42
            RECORDER_SPARK_BASE3 .append ("Function Name : {func_name} ; Time : {time} ; Arguments :  {args}".format (func_name =OO0O0000O000O0O00 .__name__ ,time =str (datetime .now ()),args =OOO00000OO0OOO00O ))#line:43
          return OO0O0000O000O0O00 (*OOO00000OO0OOO00O ,**O00O00000OO0OO00O )#line:45
        except :#line:47
          RECORDER_SPARK_BASE3 .append ("IDF_Exception :  {exception} : {trace}".format (exception =sys .exc_info ()[0 ],trace =traceback .format_exc ()))#line:48
      return OO0OO000000O00OOO #line:50
    return OOOO0O0000OOOOO0O #line:52
logdebug =log_to (logging .debug )#line:54
_O0OO00O000OO0O00O =lambda OOO0OO0O000O00OO0 ,O0O0OOO0000O0OO0O :list (filter (lambda OOO0O000OO00O0O0O :OOO0O000OO00O0O0O !=O0O0OOO0000O0OO0O ,OOO0OO0O000O00OO0 ))#line:58
def buildTreeDependencyGraph_fn (O0OO0O0O00000OO0O ):#line:63
    ""#line:67
    OO00OOO0OOO000OOO ={OO0OOO00OOO00O000 .get ("card_id"):OO0OOO00OOO00O000 .get ("card_dependencies")for OO0OOO00OOO00O000 in O0OO0O0O00000OO0O }#line:68
    OO00OOO0OOO000OOO .update ({OO000O0O0O0O00OOO :''for OO000O0O0O0O00OOO ,OO000OOOO000O0000 in OO00OOO0OOO000OOO .items ()if isinstance (OO000OOOO000O0000 ,list )and len (OO000OOOO000O0000 )==0 })#line:70
    OO00OOO0OOO000OOO .update ({O000O0OOOO0OOOO0O :set ([O0000000000OO0000 ])for O000O0OOOO0OOOO0O ,O0000000000OO0000 in OO00OOO0OOO000OOO .items ()if isinstance (O0000000000OO0000 ,str )and O0000000000OO0000 !=''})#line:71
    OOO00OO00OOO0O00O =dict ((OOOOO0OOO00000O00 ,set (OO00OOO0OOO000OOO [OOOOO0OOO00000O00 ]))for OOOOO0OOO00000O00 in OO00OOO0OOO000OOO )#line:72
    O0OO00OO0O000OOOO =[]#line:73
    while OOO00OO00OOO0O00O :#line:75
        OO0O0OOO0OOO00OOO =set (O00000OOO0O0OOO00 for O00O00O000000OO00 in OOO00OO00OOO0O00O .values ()for O00000OOO0O0OOO00 in O00O00O000000OO00 )-set (OOO00OO00OOO0O00O .keys ())#line:76
        OO0O0OOO0OOO00OOO .update (OOOOO0O0000OO00OO for OOOOO0O0000OO00OO ,O0OOOO0O0O0O000OO in OOO00OO00OOO0O00O .items ()if not O0OOOO0O0O0O000OO )#line:77
        O0OO00OO0O000OOOO .append (OO0O0OOO0OOO00OOO )#line:78
        OOO00OO00OOO0O00O =dict (((OO0O0OO000OOOO000 ,O0000OO0OO0OO00OO -OO0O0OOO0OOO00OOO )for OO0O0OO000OOOO000 ,O0000OO0OO0OO00OO in OOO00OO00OOO0O00O .items ()if O0000OO0OO0OO00OO ))#line:79
    return O0OO00OO0O000OOOO #line:81
@logdebug #line:87
def applyStandardizationRule_fn (OOOO0OO00O00OOO00 ,O00OOOO00000OO000 ,OOO00O000O000000O ,O00OOOO0OO0O0OOO0 ,OOOOO0OO0OOO0OO0O ):#line:88
  OO000000OO0000000 =OOOO0OO00O00OOO00 .sql (f"select * from {OOO00O000O000000O}")#line:89
  OO0OO00O0OOO0OOOO =OO000000OO0000000 .columns #line:91
  for OO00OOOOOOOO000O0 ,O000OO000O0000OOO in OOOOO0OO0OOO0OO0O .items ():#line:93
    OO000000OO0000000 =O00OOOO00000OO000 .standardizeColumnsByPredefinedRule_fn (OO000000OO0000000 ,OO00OOOOOOOO000O0 ,O000OO000O0000OOO .split (','),OO0OO00O0OOO0OOOO )#line:94
  OO000000OO0000000 .createOrReplaceTempView (O00OOOO0OO0O0OOO0 )#line:98
  OO000000OO0000000 =None #line:99
@logdebug #line:104
def calculateYTDValue_fn (O0O00OOOOO0O0O00O ,OO0OO00OO000OOOOO ,O0OO0OOO00O0OOO0O ,OO0O00000O000OO00 ,OOOOOOO000O0O0OOO ,OO0OO0OO0O00O0O0O ,OOOOOOOOO00OO0O0O ,ordering_column_format ='yyyy-MM-dd'):#line:105
  ""#line:112
  try :#line:113
    OO0OOOO00OOO00O00 =O0O00OOOOO0O0O00O .sql (f"select * from {OO0OO00OO000OOOOO}")#line:114
    O000O000OOOOO0OO0 =OO0OOOO00OOO00O00 .columns #line:115
    O0OO0OOO0000OOO00 =Window ().partitionBy ("__idf_year","__idf_month","__idf_day")#line:117
    OOO0OOO00OO00O0O0 =Window ().partitionBy ("__idf_year","__idf_month","__idf_day").orderBy ("__idf_day")#line:118
    O00OO00O0O0OOO00O =Window ().partitionBy ("__idf_year","__idf_month").orderBy ("__idf_day")#line:119
    OO0OOOO00OOO00O00 =OO0OOOO00OOO00O00 .select (*_O0OO00O000OO0O00O (O000O000OOOOO0OO0 ,OO0O00000O000OO00 ),F .to_date (F .col (OO0O00000O000OO00 ).cast ('string'),ordering_column_format ).alias (OO0O00000O000OO00 )).select ("*",F .expr (f"extract (YEAR from {OO0O00000O000OO00})").alias ("__idf_year"),F .expr (f"extract (MONTH from {OO0O00000O000OO00})").alias ("__idf_month"),F .expr (f"extract (DAY from {OO0O00000O000OO00})").alias ("__idf_day"))#line:121
    OO0OOOO00OOO00O00 =OO0OOOO00OOO00O00 .select ("*",F .sum (OOOOOOO000O0O0OOO ).over (O0OO0OOO0000OOO00 ).alias (OO0OO0OO0O00O0O0O )).select ("*",F .row_number ().over (OOO0OOO00OO00O0O0 ).alias ('__idf_row_num')).select (*_O0OO00O000OO0O00O (OO0OOOO00OOO00O00 .columns ,OO0OO0OO0O00O0O0O ),F .when (F .col ("__idf_row_num")!=1 ,F .lit (0 )).otherwise (F .col (OO0OO0OO0O00O0O0O )).alias (OO0OO0OO0O00O0O0O )).select (*_O0OO00O000OO0O00O (OO0OOOO00OOO00O00 .columns ,OO0OO0OO0O00O0O0O ),F .sum (OO0OO0OO0O00O0O0O ).over (O00OO00O0O0OOO00O ).alias (OO0OO0OO0O00O0O0O )).drop ("__idf_year","__idf_month","__idf_day","__idf_row_num")#line:123
    OO0OOOO00OOO00O00 .createOrReplaceTempView (OOOOOOOOO00OO0O0O )#line:125
  finally :#line:127
    OO0OOOO00OOO00O00 =None #line:128
@logdebug #line:134
def imputeLastNotNullValueInGroup_fn (O000O0000OO000OO0 ,O00OOOO0O0OO0O000 ,OO0O00000O000OOO0 ,OOOO0000OO00000O0 ,O0OOOO00OOO000O00 ,OOO0000OO0OOO00OO ,ordering_column_format ='yyyy-MM-dd'):#line:135
  ""#line:141
  try :#line:142
    O0OOOO0OOOO000O0O =O000O0000OO000OO0 .sql (f"select * from {O00OOOO0O0OO0O000}")#line:143
    OO0O0000OO0O0O0OO =O0OOOO0OOOO000O0O .columns #line:144
    OO0OOOOO0OO0OO00O =Window .partitionBy (*OO0O00000O000OOO0 ).orderBy (OOOO0000OO00000O0 )#line:146
    O0O000O0OO00OO000 =Window .partitionBy (*(OO0O00000O000OOO0 +['__idf_rank1'])).orderBy (OOOO0000OO00000O0 )#line:147
    O0OOOO0OOOO000O0O =O0OOOO0OOOO000O0O .select (*_O0OO00O000OO0O00O (OO0O0000OO0O0O0OO ,O0OOOO00OOO000O00 ),F .when (F .col (O0OOOO00OOO000O00 ).isNull (),F .lit (0 )).otherwise (F .col (O0OOOO00OOO000O00 )).alias (O0OOOO00OOO000O00 )).select (*_O0OO00O000OO0O00O (OO0O0000OO0O0O0OO ,OOOO0000OO00000O0 ),F .to_date (F .col (OOOO0000OO00000O0 ).cast ('string'),ordering_column_format ).alias (OOOO0000OO00000O0 ))#line:149
    O0OOOO0OOOO000O0O =O0OOOO0OOOO000O0O .select ("*",F .when (F .col (O0OOOO00OOO000O00 )!=0 ,F .rank ().over (OO0OOOOO0OO0OO00O )).otherwise (F .lit (0 )).alias ("__idf_rank1")).select (*_O0OO00O000OO0O00O (O0OOOO0OOOO000O0O .columns ,'__idf_rank1'),F .sum ('__idf_rank1').over (OO0OOOOO0OO0OO00O ).alias ('__idf_rank1')).select (*_O0OO00O000OO0O00O (O0OOOO0OOOO000O0O .columns ,O0OOOO00OOO000O00 ),F .sum (O0OOOO00OOO000O00 ).over (O0O000O0OO00OO000 ).alias (O0OOOO00OOO000O00 ))#line:151
    O0OOOO0OOOO000O0O .createOrReplaceTempView (OOO0000OO0OOO00OO )#line:153
  finally :#line:155
    O0OOOO0OOOO000O0O =None #line:156
@logdebug #line:162
def runningEntryExitCount_fn (OOO00O0OO0O0OO00O ,OOOO000OO000OO0O0 ,OO0O0OO0O00O0O0OO ,O0OO0OO00O0OOO00O ,O00O0OO00OOOO0O00 ,OOOOO00O0O0000O00 ,OOO000OO000OO000O ,ordering_column_format ='yyyy-MM-dd'):#line:163
  ""#line:171
  try :#line:172
    O00O00O0O0O00O000 =OOO00O0OO0O0OO00O .sql (f"select * from {OOOO000OO000OO0O0}")#line:173
    OO0OOO000OO0OO0O0 =O00O00O0O0O00O000 .columns #line:174
    OOO00OOO000OO0OOO =Window .partitionBy ().orderBy (OO0O0OO0O00O0O0OO )#line:175
    O00O00O0O0O00O000 =O00O00O0O0O00O000 .select (*_O0OO00O000OO0O00O (OO0OOO000OO0OO0O0 ,OO0O0OO0O00O0O0OO ),F .to_date (F .col (OO0O0OO0O00O0O0OO ).cast ('string'),ordering_column_format ).alias (OO0O0OO0O00O0O0OO ))#line:177
    O00O00O0O0O00O000 =O00O00O0O0O00O000 .select ("*",(F .col (O0OO0OO00O0OOO00O )-F .lag (O0OO0OO00O0OOO00O ).over (OOO00OOO000OO0OOO )).alias ("__idf_value_col1")).select ("*",F .when (F .col ('__idf_value_col1')>0 ,F .lit (0 )).otherwise (F .col ('__idf_value_col1')*-1 ).alias ('__idf_value_col2')).select ("*",F .when (F .col ('__idf_value_col1')<0 ,F .lit (0 )).otherwise (F .col ("__idf_value_col1")).alias ("__idf_value_col3"))#line:179
    O00O00O0O0O00O000 =O00O00O0O0O00O000 .select ("*",F .when (F .col ('__idf_value_col1').isNull (),F .col (O0OO0OO00O0OOO00O )).otherwise (F .col ("__idf_value_col3")).alias (O00O0OO00OOOO0O00 )).select ("*",F .when (F .col ('__idf_value_col2').isNull (),F .lit (0 )).otherwise (F .col ('__idf_value_col2')).alias (OOOOO00O0O0000O00 )).drop ('__idf_value_col1','__idf_value_col2','__idf_value_col3')#line:181
    O00O00O0O0O00O000 .createOrReplaceTempView (OOO000OO000OO000O )#line:183
  finally :#line:185
    O00O00O0O0O00O000 =None #line:186
@logdebug #line:192
def preProcessData4ML_fn (*,spark ,dataframe ,output_table ,target_column ,sampling_ratio ,missing_values_percent_threshold ,minimum_variance_percent_threshold ,categorical_percent_threshold ,depth_of_ml_hierechy =5 ,numerical_scaling_algorithm ='MinMaxScaler'):#line:193
  ""#line:207
  from pyspark .ml import Pipeline #line:208
  #JPM#from pyspark .ml .feature import PCA ,VectorAssembler ,VectorIndexer ,OneHotEncoder ,StringIndexer ,MinMaxScaler ,StandardScaler #line:209
  from pyspark .ml .feature import VectorAssembler ,OneHotEncoder ,StringIndexer ,MinMaxScaler ,StandardScaler #line:209
  #JPM#from pyspark .ml .regression import LinearRegression #line:210
  #JPM#import pandas as pd #line:211
  try :#line:213
    O00OO00O0000OO0O0 =dataframe .sample (False ,float (sampling_ratio ))#line:214
    OOOOOO0O0O0O000OO =O00OO00O0000OO0O0 .count ()#line:215
    O000O000OO0000O00 =[target_column ]#line:216
    OOOOOO000OOO00OO0 =list (filter (lambda OO00O00OOOOOO000O :OO00O00OOOOOO000O [1 ].lower ()=='string',dataframe .dtypes ))#line:217
    OO00OO0OOO0000O0O =O00OO00O0000OO0O0 .select ([(F .count (F .when (F .isnan (O0OOOO0OO0O00OOO0 )|F .col (O0OOOO0OO0O00OOO0 ).isNull (),O0OOOO0OO0O00OOO0 ))/OOOOOO0O0O0O000OO ).alias (O0OOOO0OO0O00OOO0 )for O0OOOO0OO0O00OOO0 ,O0OOOOO0O00O0OO0O in OOOOOO000OOO00OO0 ]).collect ()[0 ]#line:219
    for OOO0O00O0O0OOOO00 ,OOO00OO0OO0OOO00O in OOOOOO000OOO00OO0 :#line:220
        OOO0O00OO0O0O00O0 =OO00OO0OOO0000O0O [OOO0O00O0O0OOOO00 ]#line:221
        if OOO0O00OO0O0O00O0 >float (missing_values_percent_threshold )and OOO0O00O0O0OOOO00 not in O000O000OO0000O00 :#line:222
            dataframe =dataframe .drop (OOO0O00O0O0OOOO00 .lower ())#line:223
    OO00OO0OOO0000O0O =None #line:226
    OO00OO0OOO0000O0O =O00OO00O0000OO0O0 .select ([(F .approx_count_distinct (O0O000OO0O0OOO00O )/OOOOOO0O0O0O000OO ).alias (O0O000OO0O0OOO00O )for O0O000OO0O0OOO00O ,O0000O0OO000O00OO in OOOOOO000OOO00OO0 ]).collect ()[0 ]#line:228
    for OOO0O00O0O0OOOO00 ,OOO00OO0OO0OOO00O in OOOOOO000OOO00OO0 :#line:229
        O00O0O00O0O0OO0OO =OO00OO0OOO0000O0O [OOO0O00O0O0OOOO00 ]#line:230
        if float (minimum_variance_percent_threshold )<O00O0O00O0O0OO0OO and OOO0O00O0O0OOOO00 not in O000O000OO0000O00 :#line:231
            dataframe =dataframe .drop (OOO0O00O0O0OOOO00 )#line:232
    OO00OO0OOO0000O0O =None #line:235
    O000000OOOO0OOOOO =O00OO00O0000OO0O0 .columns #line:237
    O000000OOOO0OOOOO .remove (target_column .lower ())#line:238
    O0O0000O0OOOOO0OO =[]#line:240
    OO0O00O000O000O00 =[]#line:241
    OOOO000O000000O0O =[]#line:242
    OO0O00O00O0O0000O =[]#line:243
    for OOO0O00O0O0OOOO00 in O000000OOOO0OOOOO :#line:245
        O000O0O0O0OOOOO00 =dataframe .select (OOO0O00O0O0OOOO00 ).distinct ().count ()#line:246
        if O000O0O0O0OOOOO00 ==1 :#line:247
            OO0O00O00O0O0000O .append (OOO0O00O0O0OOOO00 )#line:248
            continue #line:249
        OO0O00OO0OOOO0O00 =dataframe .schema [OOO0O00O0O0OOOO00 ].dataType .typeName ()#line:252
        if "timestamp"==OO0O00OO0OOOO0O00 :#line:254
            OO0O00O00O0O0000O .append (OOO0O00O0O0OOOO00 )#line:255
            continue #line:256
        if "string"==OO0O00OO0OOOO0O00 :#line:259
            OOOO000O000000O0O .append (OOO0O00O0O0OOOO00 )#line:260
            dataframe =dataframe .withColumn (OOO0O00O0O0OOOO00 ,F .when (F .isnull (F .col (OOO0O00O0O0OOOO00 ))|F .isnan (F .col (OOO0O00O0O0OOOO00 )),"NA").otherwise (F .col (OOO0O00O0O0OOOO00 )))#line:261
        else :#line:263
            O0000OO0O00OOO0OO =float (O000O0O0O0OOOOO00 )/OOOOOO0O0O0O000OO #line:264
            if O0000OO0O00OOO0OO <float (categorical_percent_threshold ):#line:265
                OO0O00O000O000O00 .append (OOO0O00O0O0OOOO00 )#line:266
                dataframe =dataframe .withColumn (OOO0O00O0O0OOOO00 ,F .when (F .isnull (F .col (OOO0O00O0O0OOOO00 ))|F .isnan (F .col (OOO0O00O0O0OOOO00 )),"NA").otherwise (F .col (OOO0O00O0O0OOOO00 )))#line:267
            else :#line:269
                O0O0000O0OOOOO0OO .append (OOO0O00O0O0OOOO00 )#line:270
                dataframe =dataframe .withColumn (OOO0O00O0O0OOOO00 ,F .when (F .isnull (F .col (OOO0O00O0O0OOOO00 ))|F .isnan (F .col (OOO0O00O0O0OOOO00 )),0 ).otherwise (F .col (OOO0O00O0O0OOOO00 )))#line:271
    dataframe =dataframe .drop (*OO0O00O00O0O0000O )#line:275
    OO0O00OO0OOOO0O00 =dataframe .schema [target_column ].dataType .typeName ()#line:277
    dataframe =dataframe .withColumn (target_column ,F .col (target_column ).cast ("double"))#line:280
    dataframe =dataframe .na .fill ('NA')#line:283
    dataframe =dataframe .na .fill (0 )#line:284
    OOO000OOOOO00OO0O =[]#line:285
    OOO0O000OO0O00000 =[StringIndexer (inputCol =OOOO0OOOOOOO00O0O ,outputCol =OOOO0OOOOOOO00O0O +"$si")for OOOO0OOOOOOO00O0O in OO0O00O000O000O00 ]#line:287
    O000OO000OO000000 =[OneHotEncoder (inputCol =OO0O0OO0OOO0OO0O0 +"$si",outputCol =OO0O0OO0OOO0OO0O0 +"$index")for OO0O0OO0OOO0OO0O0 in OO0O00O000O000O00 ]#line:288
    OOO000OOOOO00OO0O =OOO0O000OO0O00000 +O000OO000OO000000 #line:289
    OO0O0OOO00OO000O0 =[StringIndexer (inputCol =OO0O0O00O00OO0O0O ,outputCol =OO0O0O00O00OO0O0O +"$si")for OO0O0O00O00OO0O0O in OOOO000O000000O0O ]#line:291
    OO0OOOOOOO0OO0O0O =[OneHotEncoder (inputCol =O0000OO0O0000O0O0 +"$si",outputCol =O0000OO0O0000O0O0 +"$index")for O0000OO0O0000O0O0 in OOOO000O000000O0O ]#line:292
    OOO000OOOOO00OO0O =OOO000OOOOO00OO0O +OO0O0OOO00OO000O0 +OO0OOOOOOO0OO0O0O #line:293
    OO0O000OOOO0OO000 =[OO0OO0O00O00O00O0 +"$index"for OO0OO0O00O00O00O0 in OO0O00O000O000O00 ]+[O00O00OOO000OO0O0 +"$index"for O00O00OOO000OO0O0 in OOOO000O000000O0O ]+O0O0000O0OOOOO0OO #line:295
    OO0OO000OO000OO0O =VectorAssembler (inputCols =OO0O000OOOO0OO000 ,outputCol ="raw_features")#line:296
    OOO000OOOOO00OO0O .append (OO0OO000OO000OO0O )#line:297
    O0O000OO0O0O00O00 =numerical_scaling_algorithm #line:299
    if "MinMaxScaler"==O0O000OO0O0O00O00 :#line:300
        O0OOO0OOO000O0OOO =MinMaxScaler (inputCol ="raw_features",outputCol ="features")#line:301
    else :#line:303
        O0OOO0OOO000O0OOO =StandardScaler (inputCol ="raw_features",outputCol ="features",withStd =True ,withMean =False )#line:304
    OOO000OOOOO00OO0O .append (O0OOO0OOO000O0OOO )#line:306
    O00OOOO00O0OO0OO0 =Pipeline (stages =OOO000OOOOO00OO0O )#line:308
    O00O0OOO000OOO0OO =O00OOOO00O0OO0OO0 .fit (dataframe )#line:309
    OOOOO0OOO0OO000O0 =O00O0OOO000OOO0OO .transform (dataframe )#line:310
    OO0000OO0OOOOOOO0 ={OO0OO0OO0OOO000OO :1 for OO0OO0OO0OOO000OO in O0O0000O0OOOOO0OO }#line:313
    O0O0O00OOO0OOOO00 =OOOOO0OOO0OO000O0 .select ([O00O00OO00OO0OO00 for O00O00OO00OO0OO00 in OOOOO0OOO0OO000O0 .columns if '$index'in O00O00OO00OO0OO00 in O00O00OO00OO0OO00 ]).first ().asDict ()#line:314
    for OO0O00O000000OO00 ,OOO0000O0O00OO00O in O0O0O00OOO0OOOO00 .items ():#line:315
      OO0000OO0OOOOOOO0 .update ({OO0O00O000000OO00 .split ("$")[0 ]:OOO0000O0O00OO00O .size })#line:316
    O0OOO0OO00O000OOO =[]#line:319
    for OO0O00OOO0O000000 in O00OO00O0000OO0O0 .columns :#line:320
      if OO0O00OOO0O000000 in OO0000OO0OOOOOOO0 :#line:321
        for OO0O000OOOO0OOO00 in range (OO0000OO0OOOOOOO0 .get (OO0O00OOO0O000000 )):#line:322
          O0OOO0OO00O000OOO .append (OO0O00OOO0O000000 +"_"+str (OO0O000OOOO0OOO00 ))#line:323
    dataframe .createOrReplaceTempView (OOOOO0OOO0OO000O0 ['features',target_column ])#line:328
    return O0OOO0OO00O000OOO #line:329
  finally :#line:331
    dataframe =None #line:332
    OOO000OOOOO00OO0O =None #line:333
    O00OO00O0000OO0O0 =None #line:334
    OOOOO0OOO0OO000O0 =None #line:335
    O00O0OOO000OOO0OO =None #line:336
    O00OOOO00O0OO0OO0 =None #line:337
@logdebug #line:343
def rowInclusionBasedOnTimeRange_fn (*,spark ,output_table ,input_table ,single_primary_key ,range_start_column ,range_end_column ):#line:344
  ""#line:347
  try :#line:348
    O0OO0000O0OO00O00 ="""
    SELECT
      s1.{single_primary_key}
      , (CASE WHEN s2.{single_primary_key} IS NOT NULL THEN 1 ELSE 0 END) AS overlap_y_n
  FROM {source} AS s1
  LEFT JOIN {source} AS s2
      ON s1.{single_primary_key} != s2.{single_primary_key}
          AND s1.{range_start_column} <= s2.{range_end_column}
          AND s1.{range_end_column} >= s2.{range_start_column}
  GROUP BY s1.{single_primary_key}, s2.{single_primary_key}
    """.format (source =input_table ,single_primary_key =single_primary_key ,range_start_column =range_start_column ,range_end_column =range_end_column )#line:359
    spark .sql (O0OO0000O0OO00O00 ).dropDuplicates ().registerTempTable ("tmp1")#line:360
    spark .sql (" SELECT a.*, b.overlap_y_n from input_table a, tmp1 b where a.{single_primary_key} = b.{single_primary_key}".format (single_primary_key =single_primary_key )).registerTempTable (output_table )#line:362
  finally :#line:365
    spark .catalog .uncacheTable ("tmp1")#line:366
    spark .catalog .uncacheTable (input_table )#line:367
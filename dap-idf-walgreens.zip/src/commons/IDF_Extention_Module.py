# Databricks notebook source
# Databricks notebook source
#JPM#import re
#JPM#import json
import traceback
#JPM#import uuid
from datetime import datetime,timedelta
#JPM#import pytz
#JPM#from dateutil.relativedelta import relativedelta
#JPM#from typing import Iterable 
from itertools import * 
#JPM#from functools import wraps
#JPM#from inspect import getcallargs, getargspec
#JPM#from collections import OrderedDict, Iterable
#JPM#import logging

#JPM#import sparkclean

#JPM#import boto3

#JPM#import pyspark
#JPM#from pyspark.sql import SparkSession, Row
#JPM#from pyspark.sql import SQLContext, DataFrame
from pyspark.sql.types import *
import pyspark.sql.functions as F
#JPM#from pyspark.sql.window import Window


# COMMAND ----------

class RulesEnginePredefinedExtClass(RulesEnginePredefinedClass):
  def standardizeColumnsByPredefinedRule_fn(self, dataframe, rule_type, column_list, df_column_list):
    return RulesEnginePredefinedClass.standardizeColumnsByPredefinedRule_fn(self, dataframe, rule_type, column_list, df_column_list)
  #def
  
#class

# COMMAND ----------

class RulesEngineExpressionExtClass(RulesEngineExpressionClass):
  def standardizeColumnsByExpressionRule_fn(self, dataframe, rule_type, column_list, expression, replace_value, df_column_list):
    return RulesEngineExpressionClass.standardizeColumnsByExpressionRule_fn(self, dataframe, rule_type, column_list, expression, replace_value, df_column_list)
  #def
#class

# COMMAND ----------

class RulesEngineComplexExtClass (RulesEngineComplexClass):
  def standardizeColumnsByComplexRule_fn(self, spark, dataframe, rule, df_column_list):
    return RulesEngineComplexClass.standardizeColumnsByComplexRule_fn(self, spark, dataframe, rule, df_column_list)
  #def
#class

# COMMAND ----------

class RowBasedDataQualityExtClass (RowBasedDataQualityClass):
  def rowBasedRulesCheck_fn(self, spark, dataframe, rule_id, rule_condition_map, df_column_list, total_row_count):
    #Write my own code
    return RowBasedDataQualityClass.rowBasedRulesCheck_fn(self, spark, dataframe, rule_id, rule_condition_map, df_column_list, total_row_count)
  #def
#class


# COMMAND ----------

def getListOfDateWisePartitionWith000000_fn(*, extraction_range, base_path, date_format="YYYYMMDD"):
  """
  """
 
  partition_list = []

  if extraction_range.upper() in ['LAST_DAY','YESTERDAY']:
    yesterday  = (datetime.today() - timedelta(days=1))
    if date_format == 'YYYYMMDD':
      partition_list =  [yesterday.strftime('%Y%m%d')+"000000"]
    #if
  #if
 
  elif extraction_range.upper() == 'LAST_WEEK':
    start_of_week = datetime.today() - timedelta(days=datetime.today() .weekday())
    end_of_week = start_of_week + timedelta(days=6)
    if date_format == 'YYYYMMDD':
      last_week = [start_of_week + timedelta(days=x) for x in range((end_of_week-start_of_week).days + 1)]
      last_week = [item.strftime('%Y%m%d')+"000000"  for item in last_week]
      partition_list =  last_week
    #if
  #elif
 
  elif extraction_range.upper() == 'LAST_MONTH':
    first_day_of_current_month = datetime.today().replace(day=1)
    first_day_previous_month  = (first_day_of_current_month - timedelta(days=1)).replace(day=1)
    last_day_of_previous_month = first_day_of_current_month - timedelta(days=1)
    if date_format == 'YYYYMMDD':
      last_month = [first_day_previous_month + timedelta(days=x) for x in range((last_day_of_previous_month-first_day_previous_month).days + 1)]
      last_month = [item.strftime('%Y%m%d')+"000000"  for item in last_month]
      partition_list =  last_month
    #if
  #elif
 
  elif extraction_range.upper() == 'TODAY':
    today  = (datetime.today())
    if date_format == 'YYYYMMDD':
      partition_list =  [today.strftime('%Y%m%d')+"000000"]
    #if
  #if
  
  elif "," in extraction_range:
    
    if "FROM" in extraction_range and date_format == 'YYYYMMDD':
      today  = (datetime.today())
      from_command, from_date = extraction_range.split(",")
      from_date  = datetime.strptime(from_date, '%Y%m%d')
      ddd = [from_date + timedelta(days=x) for x in range((today-from_date).days + 1)]
      return [item.strftime('%Y%m%d')+"000000"  for item in ddd]
    #if
    
    elif date_format == 'YYYYMMDD':
      from_date, to_date = extraction_range.split(",")
      from_date  = datetime.strptime(from_date, '%Y%m%d')
      to_date  = datetime.strptime(to_date, '%Y%m%d')
      ddd = [from_date + timedelta(days=x) for x in range((to_date-from_date).days + 1)]
      partition_list =  [item.strftime('%Y%m%d')+"000000"  for item in ddd]
    #if
  #if
  
  else:
    partition_list = [extraction_range+"000000"]
  #else
  
  final_list = []

  if partition_list:
    for item in partition_list:
      try:
        dbutils.fs.ls("{base_path}/{item}".format(base_path = base_path, item = item))
        final_list.append(item)
      #try
      except:
        pass
      #except
    #for
  #if
  else:
    final_list = None
  #else
  return final_list
#def

# COMMAND ----------

def getListOfDateWisePartitionWithHH0000_fn(*, extraction_range, extraction_time, base_path, date_format="YYYYMMDD"):
  """
  """
 
  partition_list = []

  if extraction_range.upper() in ['LAST_DAY','YESTERDAY']:
    yesterday  = (datetime.today() - timedelta(days=1))
    if date_format == 'YYYYMMDD':
      partition_list =  [yesterday.strftime('%Y%m%d')]
    #if
  #if
 
  elif extraction_range.upper() == 'LAST_WEEK':
    start_of_week = datetime.today() - timedelta(days=datetime.today() .weekday())
    end_of_week = start_of_week + timedelta(days=6)
    if date_format == 'YYYYMMDD':
      last_week = [start_of_week + timedelta(days=x) for x in range((end_of_week-start_of_week).days + 1)]
      last_week = [item.strftime('%Y%m%d')  for item in last_week]
      partition_list =  last_week
    #if
  #elif
 
  elif extraction_range.upper() == 'LAST_MONTH':
    first_day_of_current_month = datetime.today().replace(day=1)
    first_day_previous_month  = (first_day_of_current_month - timedelta(days=1)).replace(day=1)
    last_day_of_previous_month = first_day_of_current_month - timedelta(days=1)
    if date_format == 'YYYYMMDD':
      last_month = [first_day_previous_month + timedelta(days=x) for x in range((last_day_of_previous_month-first_day_previous_month).days + 1)]
      last_month = [item.strftime('%Y%m%d')  for item in last_month]
      partition_list =  last_month
    #if
  #elif
 
  elif extraction_range.upper() == 'TODAY':
    today  = (datetime.today())
    if date_format == 'YYYYMMDD':
      partition_list =  [today.strftime('%Y%m%d')]
    #if
  #if
  
  elif "," in extraction_range:
    
    if "FROM" in extraction_range and date_format == 'YYYYMMDD':
      today  = (datetime.today())
      from_command, from_date = extraction_range.split(",")
      from_date  = datetime.strptime(from_date, '%Y%m%d')
      ddd = [from_date + timedelta(days=x) for x in range((today-from_date).days + 1)]
      return [item.strftime('%Y%m%d')  for item in ddd]
    #if
    
    elif date_format == 'YYYYMMDD':
      from_date, to_date = extraction_range.split(",")
      from_date  = datetime.strptime(from_date, '%Y%m%d')
      to_date  = datetime.strptime(to_date, '%Y%m%d')
      ddd = [from_date + timedelta(days=x) for x in range((to_date-from_date).days + 1)]
      partition_list =  [item.strftime('%Y%m%d')  for item in ddd]
    #if
  #if
  
  else:
    partition_list = [extraction_range]
  #else
  
  final_list = []
  if partition_list:
    for item in partition_list:
      try:
        if ',' in extraction_time:
          for i in range(int(extraction_time.split(",")[0][0:2]), int(extraction_time.split(",")[1][0:2])+1):
            try:
              dbutils.fs.ls("{base_path}/{item}{time:02d}0000".format(base_path = base_path, item = item, time= i))
              final_list.append("{item}{time:02d}0000".format(item = item, time= i))
              #final_list.append("{base_path}/{item}{time}".format(base_path = base_path, item = item, time= str(i)))
            except:
              pass
            #except
          #for
        #if
        else:
          try:
            dbutils.fs.ls("{base_path}/{item}{time}".format(base_path = base_path, item = item, time= extraction_time))
            final_list.append("{item}{time}".format(item = item, time= extraction_time))
            #final_list.append("{base_path}/{item}{time}".format(base_path = base_path, item = item, time= extraction_time))
            #try
          except:
            pass
          #except
        #else
      #try
      except:
        traceback.print_exc()
        pass
      #except
    #for
  #if
  else:
    final_list = None
  #else
  return final_list
#def

# COMMAND ----------

def userDefinedFunctionsExample(spark, dataframe, params):
  for k,v in params.items():
    #dataframe = dataframe.withColumn(k, F.lit(v))
    if v == 'current_year':
      dataframe = dataframe.withColumn(k, F.lit(datetime.now().year))
    else:
      dataframe = dataframe.withColumn(k, F.lit(v))

  return dataframe

# COMMAND ----------

def is_last_card_fn(card_id,cards):
  last = True
  for f in cards:
    for p in f.get("card_dependencies"):
      if card_id == p:
        last = False
      #if
    #for
  #for
  return last
#def

# COMMAND ----------

def applySparkMergeCount_fn(spark, new_data_table, dim_data_table, merge_data_table, primaryKeyColumn, dim_type = 'SCD2', partition_new_data = None, partition_dim_data = None,  active_column_name = None, column_list_to_identify_changes = None, start_date_column_name = None, end_date_column_name = None, active_column_true_value = 'y', active_column_false_value = 'n'):
  """

  """
  try:
    
    df_old_count, df_new_count, df_chg_count, df_n_chg_count, df_chg_old_count, df_chg_new_count = 0, 0, 0, 0, 0, 0


    # validate arguments primaryKeyColumn
    if len(primaryKeyColumn) == 0:
      raise Exception("{primaryKeyColumn} must to be defined".format(primaryKeyColumn = primaryKeyColumn))
    #fi  
    
    # test dim table
    if len(dim_data_table) != 0:
      
      df_new = spark.sql("select * from " + new_data_table)
      df_dim = spark.sql("select * from " + dim_data_table)

      # repartioning
    
      if len(partition_new_data) != 0:
        df_new.repartition(partition_new_data)
      #if
      
      if len(partition_dim_data) != 0:
        df_dim.repartition(partition_dim_data)
      #if
      
      df_new.createOrReplaceTempView(new_data_table)
      df_dim.createOrReplaceTempView(dim_data_table)

      # Build where condition
      condition = ""
      if len(column_list_to_identify_changes) != 0:
        for item in column_list_to_identify_changes.split(","):
          condition = condition + "nvl({dim}.{c1},'') <> nvl({new}.{c1},'') OR ".format(c1 = item, dim = dim_data_table, new = new_data_table)
        #for
      #if
      else:
        for item in df_new.columns:
          if item != primaryKeyColumn:
            condition = condition + "nvl({dim}.{c1},'') <> nvl({new}.{c1},'') OR ".format(c1 = item, dim = dim_data_table, new = new_data_table)
          #if
        #for
      #else

      condition = condition[:-3]
      
      # SCD1
      if dim_type.upper() == "SCD1":

        
        # identify Old Data
        df_old = spark.sql("select {dim_table}.* from {dim_table} left outer join {new_table} on {dim_table}.{primaryKey} = {new_table}.{primaryKey} where {new_table}.{primaryKey} is null" \
                           .format(dim_table = dim_data_table, new_table = new_data_table, primaryKey = primaryKeyColumn))
        df_old_count = df_old.count()
        
        # identify New Data
        df_new = spark.sql("select {new_table}.* from {new_table} left outer join {dim_table} on {new_table}.{primaryKey} = {dim_table}.{primaryKey} where {dim_table}.{primaryKey} is null" \
                           .format(dim_table = dim_data_table, new_table = new_data_table, primaryKey = primaryKeyColumn))
        df_new_count = df_new.count()
        
        # identify Changed Data
        df_chg = spark.sql("select {new_table}.* from {new_table} inner join {dim_table} on {new_table}.{primaryKey} = {dim_table}.{primaryKey} where {where_condition}" \
                           .format(dim_table = dim_data_table, new_table = new_data_table, primaryKey = primaryKeyColumn, where_condition = condition))
        df_chg_count = df_chg.count()
        
        # identify no Changed Data
        df_n_chg = spark.sql("select {dim_table}.* from {dim_table} inner join {new_table} on {dim_table}.{primaryKey} = {new_table}.{primaryKey} where not ({where_condition})" \
                           .format(dim_table = dim_data_table, new_table = new_data_table, primaryKey = primaryKeyColumn, where_condition = condition))
        df_n_chg_count = df_n_chg.count()
        
        df_final = df_old.unionAll(df_new).unionAll(df_chg).unionAll(df_n_chg)

      #if
      # SCD2
      elif dim_type.upper() == "SCD2":
        
        # Build where condition
        if len(active_column_name) == 0:
          condition_active = "1=1"
        #if
        else:
          condition_active = dim_data_table + "." + active_column_name + " = '" + active_column_true_value + "'"
        #else
     
        # Build Previous life columns & Current life columns
        old_tab_columns = ""
        new_tab_columns = ""
        
        for item in df_dim.columns:
          if item == active_column_name:
            old_tab_columns = old_tab_columns + "'" + active_column_false_value + "' as " + item + ","
            new_tab_columns = new_tab_columns + "'" + active_column_true_value + "' as " + item + ","
          #if
          elif item == end_date_column_name:
            old_tab_columns = old_tab_columns + new_data_table + "." + start_date_column_name + " as " + item + ","
            new_tab_columns = new_tab_columns + new_data_table + "." + item + ","
          #elif
          else:
            old_tab_columns = old_tab_columns + dim_data_table + "." + item + ","
            new_tab_columns = new_tab_columns + new_data_table + "." + item + ","
          #else
        #for
        old_tab_columns = old_tab_columns[:-1]
        new_tab_columns = new_tab_columns[:-1]
        
        # identify Old Data
        df_old = spark.sql("select {dim_table}.* from {dim_table} left outer join {new_table} on {dim_table}.{primaryKey} = {new_table}.{primaryKey} where {new_table}.{primaryKey} is null" \
                           .format(dim_table = dim_data_table, new_table = new_data_table, primaryKey = primaryKeyColumn))    
        df_old_count = df_old.count()

        # identify New Data
        df_new = spark.sql("select {new_table}.* from {new_table} left outer join {dim_table} on {new_table}.{primaryKey} = {dim_table}.{primaryKey} where {dim_table}.{primaryKey} is null" \
                           .format(dim_table = dim_data_table, new_table = new_data_table, primaryKey = primaryKeyColumn))    
        df_new_count = df_new.count()

        # identify Changed Data - Previous life
        df_chg_old = spark.sql("select {tab_columns} from {new_table} inner join {dim_table} on {new_table}.{primaryKey} = {dim_table}.{primaryKey} where {where_condition}" \
                           .format(dim_table = dim_data_table, new_table = new_data_table, primaryKey = primaryKeyColumn, tab_columns = old_tab_columns, where_condition =  condition_active + " AND (" + condition + ")"))
        df_chg_old_count = df_chg_old.count()

        # identify Changed Data - Current life
        df_chg_new = spark.sql("select {tab_columns} from {new_table} inner join {dim_table} on {new_table}.{primaryKey} = {dim_table}.{primaryKey} where {where_condition}" \
                           .format(dim_table = dim_data_table, new_table = new_data_table, primaryKey = primaryKeyColumn, tab_columns = new_tab_columns, where_condition = condition_active + " AND (" + condition + ")"))
        df_chg_new_count = df_chg_new.count()
        
        # identify No Changed Data
        df_n_chg = spark.sql("select {dim_table}.* from {dim_table} inner join {new_table} on {dim_table}.{primaryKey} = {new_table}.{primaryKey} where not({where_condition})" \
                           .format(dim_table = dim_data_table, new_table = new_data_table, primaryKey = primaryKeyColumn, where_condition = condition))    
        df_n_chg_count = df_n_chg.count()

        df_final = df_old.unionAll(df_new).unionAll(df_chg_old).unionAll(df_chg_new).unionAll(df_n_chg)
    
      # Other
      else:
        raise Exception("{dim_type} not supported".format(dim_type = dim_type))
      #else

    else:

      df_new = spark.sql("select * from " + new_data_table)

      if len(partition_new_data) != 0:
        df_new.repartition(partition_new_data)
      #if

      df_new.createOrReplaceTempView(new_data_table)
      df_final = df_new
      df_new_count = df_new.count()
      
    #else

   
    df_final.createOrReplaceTempView(merge_data_table)
    df_final = None
    
    return df_new_count + df_chg_count + df_chg_new_count
  
  #try:
  except Exception as e:
    raise e
  #except
  finally:
    df_old = None
    df_new = None
    df_chg = None
    df_n_chg = None
    df_chg_old = None
    df_chg_new = None
  #finally

#def
def concatColumnsMd5(spark, dataframe, params):
  col = params.get('columns').split(',')
  dataframe = dataframe.withColumn(params.get('name_new_column'), F.concat_ws(params.get('delimiter'), *col))
  dataframe = dataframe.withColumn(params.get('name_new_column'), F.md5(params.get('name_new_column')))
  return dataframe
# Databricks notebook source
# ooO1OO10ooOO0Oo00O00O o01o01oO11O00O01O10oO o011oooO011ooOo0OOO0O
import traceback
import re
import json
from decimal import Decimal
from datetime import datetime, timedelta
import time
from io import StringIO
from io import BytesIO
import uuid

# o100o0O10o1O0o11o0oOO ----------

def formatJSON2HTMLTable_fn(o0O0OO10001Oo01O001Oo):
  o1O0Ooo1OOO1O11oo0oO0 = """<o1001OOO10oooO1O1OOoO o11o1o0o1O0oOO0oO0O1O="background-o1Oo0oO1100o01111oOOO:#FFFFE0" oO1o11o00OO0Oo1o0O11o ="100%">"""          
  for o001001oOO1o01ooO1O0O,oo0OoO1o0O00o0Ooo100o in o0O0OO10001Oo01O001Oo.items():
    o1O0Ooo1OOO1O11oo0oO0 = o1O0Ooo1OOO1O11oo0oO0 + """<oO0oOO0O100O1111O010O><o010111O10OOo11O01Oo0 o11o1o0o1O0oOO0oO0O1O="text-oO0OOOO1oOOOOO1OOo001:o0oO0Oo1oo11o0O10O1O0; oo10ooo1oO001110O101o-oO0OOOO1oOOOOO1OOo001:oO100OO001o1oOO1OO1Oo; oO1o11o00OO0Oo1o0O11o:50%">""" + str(o001001oOO1o01ooO1O0O) + """</o010111O10OOo11O01Oo0><o010111O10OOo11O01Oo0 o11o1o0o1O0oOO0oO0O1O="text-oO0OOOO1oOOOOO1OOo001:o0oO0Oo1oo11o0O10O1O0; oo10ooo1oO001110O101o-oO0OOOO1oOOOOO1OOo001:oO100OO001o1oOO1OO1Oo; oO1o11o00OO0Oo1o0O11o:50%">""" + str(oo0OoO1o0O00o0Ooo100o) + """</o010111O10OOo11O01Oo0></oO0oOO0O100O1111O010O>"""
  #for

  o1O0Ooo1OOO1O11oo0oO0 = o1O0Ooo1OOO1O11oo0oO0 + """</o1001OOO10oooO1O1OOoO>"""
  return o1O0Ooo1OOO1O11oo0oO0
#def

def convertJSON2HTML_fn(oO0o1O01o010O101oOOo1):
  data = """<o1001OOO10oooO1O1OOoO oo1OoOO001OOoO10O0O1O="5" oO1o11o00OO0Oo1o0O11o ="100%">"""
  for o001001oOO1o01ooO1O0O,oo0OoO1o0O00o0Ooo100o in oO0o1O01o010O101oOOo1.items():
    data = data + """<oO0oOO0O100O1111O010O o11o1o0o1O0oOO0oO0O1O="background-o1Oo0oO1100o01111oOOO:#FFFFE0"><o010111O10OOo11O01Oo0>{o001001oOO1o01ooO1O0O}</o010111O10OOo11O01Oo0><o010111O10OOo11O01Oo0>{oo0OoO1o0O00o0Ooo100o}</o010111O10OOo11O01Oo0></oO0oOO0O100O1111O010O>""".format(o001001oOO1o01ooO1O0O=o001001oOO1o01ooO1O0O,oo0OoO1o0O00o0Ooo100o=oo0OoO1o0O00o0Ooo100o)
  #for
  data = data + """</o1001OOO10oooO1O1OOoO>"""
  return data
#def

# o100o0O10o1O0o11o0oOO ----------

"""def callPOSTAPI_fn( o00OOo0OO1o1O000OOo01, o0010O0OOOO11001O0OoO, oOo101O0O00Oooo0O110O, o10oOo01OOoo000o1O0oo, oo0o1OO10O00oo11oO11O, o1Oo101OOo0OOoOoo1011):
  import requests

  o1o10OO1Oo0101Oo00O1O = {'Content-Type': 'application/json', 'Accept': 'application/json'}
  oo100O10OO10oo0Ooo101 = o0010O0OOOO11001O0OoO + 'rest/2.0{oo0o1OO10O00oo11oO11O}'.format(oo0o1OO10O00oo11oO11O=oo0o1OO10O00oo11oO11O)
  print(oo100O10OO10oo0Ooo101)
  print(o1Oo101OOo0OOoOoo1011)
  oOoO100O1o11OO000OOO0 = requests.post(oo100O10OO10oo0Ooo101, auth=(oOo101O0O00Oooo0O110O, o10oOo01OOoo000o1O0oo), headers = o1o10OO1Oo0101Oo00O1O, data= json.dumps(o1Oo101OOo0OOoOoo1011), verify=False)
  oOoO100O1o11OO000OOO0 = oOoO100O1o11OO000OOO0.json()
  if oo0o1OO10O00oo11oO11O == '/assets':
    o00OOo0OO1o1O000OOo01[oOoO100O1o11OO000OOO0.get('name')] = oOoO100O1o11OO000OOO0.get('id',None)
  #if
  return o00OOo0OO1o1O000OOo01"""
#def
def callPOSTAPI_fn( ASSET_REGISTRY, collibra_hostname, collibra_username, collibra_password, function_name, json_payload):
  """
  """
  import requests

  header = {'Content-Type': 'application/json', 'Accept': 'application/json'}
  urlImportJsonAPI = collibra_hostname + 'rest/2.0{function_name}'.format(function_name=function_name)
  print(urlImportJsonAPI)
  print(json_payload)
  response_payload = requests.post(urlImportJsonAPI, auth=(collibra_username, collibra_password), headers = header, data= json.dumps(json_payload), verify=False)
  response_payload = response_payload.json()
  if function_name == '/assets':
    ASSET_REGISTRY[response_payload.get('name')] = response_payload.get('id',None)
  #if
  return ASSET_REGISTRY

def callPutAPI_fn( o00OOo0OO1o1O000OOo01, o0010O0OOOO11001O0OoO, oOo101O0O00Oooo0O110O, o10oOo01OOoo000o1O0oo, oo0o1OO10O00oo11oO11O, o1Oo101OOo0OOoOoo1011):
  """
  """
  import requests
  o1o10OO1Oo0101Oo00O1O = {'Content-Type': 'application/json', 'Accept': 'application/json'}
  oo100O10OO10oo0Ooo101 = o0010O0OOOO11001O0OoO + 'rest/2.0{oo0o1OO10O00oo11oO11O}'.format(oo0o1OO10O00oo11oO11O=oo0o1OO10O00oo11oO11O)
  print('URL = ',oo100O10OO10oo0Ooo101)
  oOoO100O1o11OO000OOO0 = requests.put(oo100O10OO10oo0Ooo101, auth=(oOo101O0O00Oooo0O110O, o10oOo01OOoo000o1O0oo), headers = o1o10OO1Oo0101Oo00O1O, data= json.dumps(o1Oo101OOo0OOoOoo1011), verify=False)
  #print ("callPutAPI_fn o00010o10OO1o100o0O01 : ", oOoO100O1o11OO000OOO0.json())
#def

"""def callGETAPI_fn (o00OOo0OO1o1O000OOo01, o0010O0OOOO11001O0OoO, oOo101O0O00Oooo0O110O, o10oOo01OOoo000o1O0oo, oo0o1OO10O00oo11oO11O, o1o1OO0o00oo1011o0111, oO0O0OOoO011o0O10Oooo):
  import requests
 
  o1o10OO1Oo0101Oo00O1O = {'Content-Type': 'application/json', 'Accept': 'application/json'}
  oo100O10OO10oo0Ooo101 = o0010O0OOOO11001O0OoO + 'rest/2.0{oo0o1OO10O00oo11oO11O}?ooo01o011Oo0OOo0oo0O1 -o010o001o10OoOOOOo0o1 oo100000oO0oO0oO10o1O "{o0010O0OOOO11001O0OoO}/ooo0O0o00o1o1o0o0011O/2.0/o10OO0o110o0100O1oooo?oo1oOO0100Ooo1111oOOo=0&oo0011OO1oo0oOOO0o1O0=0&ooo10o01OOO00001o0Oo1={o1o1OO0o00oo1011o0111}&o0o0010o11oo1o1o00O0o=oO1o1o0o101OOo000o0oo&oOo111o0ooO0oOO1101O1=o0o1011oo10OOOO0ooO0O&oo0o01o1oO10100ooO1O1=o0o1011oo10OOOO0ooO0O&o10oo1111Oo0O01100oo0=o110o000O0oooo00OOo01&o10Ooo0OO011O0oo001oO=o11oo100OOOo0O0o0O100&o0Oo1Oo1o010O100Oo1Oo={o0Oo1Oo1o010O100Oo1Oo}'.format(oo0o1OO10O00oo11oO11O=oo0o1OO10O00oo11oO11O, o1o1OO0o00oo1011o0111= o1o1OO0o00oo1011o0111, o0Oo1Oo1o010O100Oo1Oo= oO0O0OOoO011o0O10Oooo,o0010O0OOOO11001O0OoO=o0010O0OOOO11001O0OoO)
  oOoO100O1o11OO000OOO0 = requests.get(oo100O10OO10oo0Ooo101, auth=(oOo101O0O00Oooo0O110O, o10oOo01OOoo000o1O0oo), headers = o1o10OO1Oo0101Oo00O1O, verify=False)
  o00OOo0OO1o1O000OOo01[o1o1OO0o00oo1011o0111] = (oOoO100O1o11OO000OOO0.json()).get("results",[])[0].get("id", None)
  return o00OOo0OO1o1O000OOo01"""
#def
def callGETAPI_fn (ASSET_REGISTRY, collibra_hostname, collibra_username, collibra_password, function_name, asset_name, domain_id):
  """
  """
  import requests
 
  header = {'Content-Type': 'application/json', 'Accept': 'application/json'}
  urlImportJsonAPI = collibra_hostname + 'rest/2.0{function_name}?curl -X GET "{collibra_hostname}/rest/2.0/assets?offset=0&limit=0&name={asset_name}&nameMatchMode=EXACT&typeInheritance=true&excludeMeta=true&sortField=NAME&sortOrder=ASC&domainId={domainId}'.format(function_name=function_name, asset_name= asset_name, domainId= domain_id,collibra_hostname=collibra_hostname)
  response_payload = requests.get(urlImportJsonAPI, auth=(collibra_username, collibra_password), headers = header, verify=False)
  ASSET_REGISTRY[asset_name] = (response_payload.json()).get("results",[])[0].get("id", None)
  return ASSET_REGISTRY

# o100o0O10o1O0o11o0oOO ----------

'''def callGETAPI_ASSET_DETAIL_fn(o00OOo0OO1o1O000OOo01, o0010O0OOOO11001O0OoO, oOo101O0O00Oooo0O110O, o10oOo01OOoo000o1O0oo, oo0o1OO10O00oo11oO11O, oO0O0OOoO011o0O10Oooo):
  import requests
  o1o10OO1Oo0101Oo00O1O = {'Content-Type': 'application/json', 'Accept': 'application/json'}
  o11o0ooOo11O0o1OO0o1O = o0010O0OOOO11001O0OoO+'rest/2.0{oo0o1OO10O00oo11oO11O}?o0Oo1Oo1o010O100Oo1Oo={o0Oo1Oo1o010O100Oo1Oo}'.format(oo0o1OO10O00oo11oO11O=oo0o1OO10O00oo11oO11O, o0Oo1Oo1o010O100Oo1Oo= oO0O0OOoO011o0O10Oooo)
  o1oooo1111O1O10oOo000=requests.get(o11o0ooOo11O0o1OO0o1O,auth=(oOo101O0O00Oooo0O110O, o10oOo01OOoo000o1O0oo), headers = o1o10OO1Oo0101Oo00O1O, verify=False)
  data=o1oooo1111O1O10oOo000.json().get("results",[])
  for oo0O0O1o101101O01o100 in data:
       #oOOOO1oo01o1o10O0o010={oo0O0O1o101101O01o100.get('name'):oo0O0O1o101101O01o100.get('id')}
    o00OOo0OO1o1O000OOo01[oo0O0O1o101101O01o100.get('name')]=oo0O0O1o101101O01o100.get('id')
  return o00OOo0OO1o1O000OOo01
'''
def callGETAPI_ASSET_DETAIL_fn(ASSET_REGISTRY, collibra_hostname, collibra_username, collibra_password, function_name, domain_id):
  import requests
  header = {'Content-Type': 'application/json', 'Accept': 'application/json'}
  url = collibra_hostname+'rest/2.0{function_name}?domainId={domainId}'.format(function_name=function_name, domainId= domain_id)
  req=requests.get(url,auth=(collibra_username, collibra_password), headers = header, verify=False)
  data=req.json().get("results",[])
  for i in data:
       #temp={i.get('name'):i.get('id')}
    ASSET_REGISTRY[i.get('name')]=i.get('id')
  return ASSET_REGISTRY

# o100o0O10o1O0o11o0oOO ----------

def createAssetsInCollibraETL_fn(oO0O0OOoO011o0O10Oooo, oO1000oO01o1oo1Oo0100, o10oo1oOO0o1OO010O1Oo, o10oO001o000oOO0oOOoO):
  """
  /o10OO0o110o0100O1oooo
  """
  o1Oo101OOo0OOoOoo1011 = [
    {
      "name": "{o10oo1oOO0o1OO010O1Oo}".format(o10oo1oOO0o1OO010O1Oo = o10oo1oOO0o1OO010O1Oo),
      "displayName": o10oo1oOO0o1OO010O1Oo,
      "domainId": oO0O0OOoO011o0O10Oooo,
      "typeId": database_type
    },
    {
      "name": "{o10oo1oOO0o1OO010O1Oo} > {o10oO001o000oOO0oOOoO}".format(o10oo1oOO0o1OO010O1Oo = o10oo1oOO0o1OO010O1Oo, o10oO001o000oOO0oOOoO = o10oO001o000oOO0oOOoO),
      "displayName": o10oO001o000oOO0oOOoO,
      "domainId": oO0O0OOoO011o0O10Oooo,
      "typeId": table_type
    }
  ]
  return o1Oo101OOo0OOoOoo1011
#def
def createAssetsInCollibraETL_fn_new(oO0O0OOoO011o0O10Oooo, oO1000oO01o1oo1Oo0100, o10oo1oOO0o1OO010O1Oo, o10oO001o000oOO0oOOoO,df_column):
  """
  /o10OO0o110o0100O1oooo
  """
  o1Oo101OOo0OOoOoo1011 = [
    {
      "name": "{o10oo1oOO0o1OO010O1Oo}".format(o10oo1oOO0o1OO010O1Oo = o10oo1oOO0o1OO010O1Oo),
      "displayName": o10oo1oOO0o1OO010O1Oo,
      "domainId": oO0O0OOoO011o0O10Oooo,
      "typeId": database_type
    },
    {
      "name": "{o10oo1oOO0o1OO010O1Oo} > {o10oO001o000oOO0oOOoO}".format(o10oo1oOO0o1OO010O1Oo = o10oo1oOO0o1OO010O1Oo, o10oO001o000oOO0oOOoO = o10oO001o000oOO0oOOoO),
      "displayName": o10oO001o000oOO0oOOoO,
      "domainId": oO0O0OOoO011o0O10Oooo,
      "typeId": table_type
    }
  ]
  for o0111oO1o0o1o11o1Ooo1 in df_column:
    o01o0oo1010O100OO1o0o = {
      "name": "{oO1000oO01o1oo1Oo0100} > {oOOO1OOoO110O1O0O1Ooo}".format(oO1000oO01o1oo1Oo0100 = oO1000oO01o1oo1Oo0100, oOOO1OOoO110O1O0O1Ooo = o0111oO1o0o1o11o1Ooo1),
      "displayName": o0111oO1o0o1o11o1Ooo1,
      "domainId": oO0O0OOoO011o0O10Oooo,
      "typeId": col_type
    }
    o1Oo101OOo0OOoOoo1011.append(o01o0oo1010O100OO1o0o) 
  return o1Oo101OOo0OOoOoo1011


def createAssetsInCollibra_fn(oO0O0OOoO011o0O10Oooo, oO1000oO01o1oo1Oo0100, o10oo1oOO0o1OO010O1Oo, o10oO001o000oOO0oOOoO, oOo0Oo11oOOO11o01o0O0):
  """
  /o10OO0o110o0100O1oooo
  """
  o1Oo101OOo0OOoOoo1011 = [
      {
        "name": "{o10oo1oOO0o1OO010O1Oo}".format(o10oo1oOO0o1OO010O1Oo = o10oo1oOO0o1OO010O1Oo),
        "displayName": o10oo1oOO0o1OO010O1Oo,
        "domainId": oO0O0OOoO011o0O10Oooo,
        "typeId": database_type
      },
      {
        "name": "{o10oo1oOO0o1OO010O1Oo} > {o10oO001o000oOO0oOOoO}".format(o10oo1oOO0o1OO010O1Oo = o10oo1oOO0o1OO010O1Oo, o10oO001o000oOO0oOOoO = o10oO001o000oOO0oOOoO),
        "displayName": o10oO001o000oOO0oOOoO,
        "domainId": oO0O0OOoO011o0O10Oooo,
        "typeId": table_type
      }
    ]

  for o0111oO1o0o1o11o1Ooo1 in oOo0Oo11oOOO11o01o0O0:
    o01o0oo1010O100OO1o0o = {
      "name": "{oO1000oO01o1oo1Oo0100} > {oOOO1OOoO110O1O0O1Ooo}".format(oO1000oO01o1oo1Oo0100 = oO1000oO01o1oo1Oo0100, oOOO1OOoO110O1O0O1Ooo = o0111oO1o0o1o11o1Ooo1.get("name")),
      "displayName": o0111oO1o0o1o11o1Ooo1.get("name"),
      "domainId": oO0O0OOoO011o0O10Oooo,
      "typeId": col_type
    }
    o1Oo101OOo0OOoOoo1011.append(o01o0oo1010O100OO1o0o)
#===========================    
  for o0111oO1o0o1o11o1Ooo1 in derived_col:
    for oO1o01O0O11O1O1OO0OOO in o0111oO1o0o1o11o1Ooo1:
      oo1o01oO1O1110001101O = {
        "name": "{oO1000oO01o1oo1Oo0100} > {oOOO1OOoO110O1O0O1Ooo}".format(oO1000oO01o1oo1Oo0100 = oO1000oO01o1oo1Oo0100, oOOO1OOoO110O1O0O1Ooo = oO1o01O0O11O1O1OO0OOO),
        "displayName": oO1o01O0O11O1O1OO0OOO,
        "domainId": oO0O0OOoO011o0O10Oooo,
        "typeId": col_type
      }
    o1Oo101OOo0OOoOoo1011.append(oo1o01oO1O1110001101O)
#=============================    
  #for
  return o1Oo101OOo0OOoOoo1011
#def
def createAssetsInCollibra_fn_new(oO0O0OOoO011o0O10Oooo, oO1000oO01o1oo1Oo0100, o10oo1oOO0o1OO010O1Oo, o10oO001o000oOO0oOOoO, oOo0Oo11oOOO11o01o0O0):
  """
  /o10OO0o110o0100O1oooo
  """
  o1Oo101OOo0OOoOoo1011 = [
      {
        "name": "{o10oo1oOO0o1OO010O1Oo}".format(o10oo1oOO0o1OO010O1Oo = o10oo1oOO0o1OO010O1Oo),
        "displayName": o10oo1oOO0o1OO010O1Oo,
        "domainId": oO0O0OOoO011o0O10Oooo,
        "typeId": database_type
      },
      {
        "name": "{o10oo1oOO0o1OO010O1Oo} > {o10oO001o000oOO0oOOoO}".format(o10oo1oOO0o1OO010O1Oo = o10oo1oOO0o1OO010O1Oo, o10oO001o000oOO0oOOoO = o10oO001o000oOO0oOOoO),
        "displayName": o10oO001o000oOO0oOOoO,
        "domainId": oO0O0OOoO011o0O10Oooo,
        "typeId": table_type
      }
    ]

  for o0111oO1o0o1o11o1Ooo1 in df_column:
    o01o0oo1010O100OO1o0o = {
      "name": "{oO1000oO01o1oo1Oo0100} > {oOOO1OOoO110O1O0O1Ooo}".format(oO1000oO01o1oo1Oo0100 = oO1000oO01o1oo1Oo0100, oOOO1OOoO110O1O0O1Ooo = o0111oO1o0o1o11o1Ooo1),
      "displayName": o0111oO1o0o1o11o1Ooo1,
      "domainId": oO0O0OOoO011o0O10Oooo,
      "typeId": col_type
    }
    o1Oo101OOo0OOoOoo1011.append(o01o0oo1010O100OO1o0o)
#===========================    
  #for o0111oO1o0o1o11o1Ooo1 in derived_col:
   # for oO1o01O0O11O1O1OO0OOO in o0111oO1o0o1o11o1Ooo1:
    #  oo1o01oO1O1110001101O = {
     #   "name": "{oO1000oO01o1oo1Oo0100} > {oOOO1OOoO110O1O0O1Ooo}".format(oO1000oO01o1oo1Oo0100 = oO1000oO01o1oo1Oo0100, oOOO1OOoO110O1O0O1Ooo = oO1o01O0O11O1O1OO0OOO),
      #  "displayName": oO1o01O0O11O1O1OO0OOO,
       # "domainId": oO0O0OOoO011o0O10Oooo,
        #"typeId": col_type
      #}
   # o1Oo101OOo0OOoOoo1011.append(oo1o01oO1O1110001101O)
#=============================    
  #for
  return o1Oo101OOo0OOoOoo1011

# o100o0O10o1O0o11o0oOO ----------

def createIndivisualAssetInCollibra_fn(oO0O0OOoO011o0O10Oooo, oO1000oO01o1oo1Oo0100, o1o1OO0o00oo1011o0111):
  """
  /o10OO0o110o0100O1oooo
  """
  return {
    "name": "{oO1000oO01o1oo1Oo0100} > {oOOO1OOoO110O1O0O1Ooo}".format(oO1000oO01o1oo1Oo0100 = oO1000oO01o1oo1Oo0100, oOOO1OOoO110O1O0O1Ooo = o1o1OO0o00oo1011o0111),
    "displayName": o1o1OO0o00oo1011o0111,
    "domainId": oO0O0OOoO011o0O10Oooo,
    "typeId": col_type
  }
#def

def createAttributes4AssetsInCollibra_fn(o00OOo0OO1o1O000OOo01, oO1000oO01o1oo1Oo0100, oOo0Oo11oOOO11o01o0O0):
  """
  /o10OO0o110o0100O1oooo
  """

  o1Oo101OOo0OOoOoo1011 = [
  ]

  for o0111oO1o0o1o11o1Ooo1 in oOo0Oo11oOOO11o01o0O0: 
    ooOO10OO0oO101OOo01O1 = o00OOo0OO1o1O000OOo01.get("{oO1000oO01o1oo1Oo0100} > {oOOO1OOoO110O1O0O1Ooo}".format(oO1000oO01o1oo1Oo0100 = oO1000oO01o1oo1Oo0100, oOOO1OOoO110O1O0O1Ooo = o0111oO1o0o1o11o1Ooo1.get("name")))
    o01o0oo1010O100OO1o0o = {
      "assetId": ooOO10OO0oO101OOo01O1,
      "typeId": collibra_setup.get('attribute_type_description'),
      "value": o0111oO1o0o1o11o1Ooo1.get("metadata",{}).get("description",'N/A')
    }
    o1Oo101OOo0OOoOoo1011.append(o01o0oo1010O100OO1o0o)
    o01o0oo1010O100OO1o0o = {
      "assetId": ooOO10OO0oO101OOo01O1,
      "typeId": collibra_setup.get('attribute_type_defination'),
      "value": o0111oO1o0o1o11o1Ooo1.get("metadata",{}).get("business_glossery",'N/A')
    }
    o1Oo101OOo0OOoOoo1011.append(o01o0oo1010O100OO1o0o)
    o01o0oo1010O100OO1o0o = {
      "assetId": ooOO10OO0oO101OOo01O1,
      "typeId": collibra_setup.get('attribute_technical_datatype'),
      "value": o0111oO1o0o1o11o1Ooo1.get("type",'N/A')
    }
    o1Oo101OOo0OOoOoo1011.append(o01o0oo1010O100OO1o0o)
    o01o0oo1010O100OO1o0o = {
      "assetId": ooOO10OO0oO101OOo01O1,
      "typeId": collibra_setup.get('attribute_note'),
      "value": """<o1001OOO10oooO1O1OOoO oo1OoOO001OOoO10O0O1O="1" oO1o11o00OO0Oo1o0O11o ="100%"><oO0oOO0O100O1111O010O o11o1o0o1O0oOO0oO0O1O="background-o1Oo0oO1100o01111oOOO:#FFFFE0"><o010111O10OOo11O01Oo0>oOOOOo0o0O1oo11ooOOOO</o010111O10OOo11O01Oo0><o010111O10OOo11O01Oo0>{oOOOOo0o0O1oo11ooOOOO}</o010111O10OOo11O01Oo0></oO0oOO0O100O1111O010O><oO0oOO0O100O1111O010O o11o1o0o1O0oOO0oO0O1O="background-o1Oo0oO1100o01111oOOO:#FFFFE0"><o010111O10OOo11O01Oo0>oooO0oOoOoOOoOo0001o0</o010111O10OOo11O01Oo0><o010111O10OOo11O01Oo0>{oooO0oOoOoOOoOo0001o0}</o010111O10OOo11O01Oo0></oO0oOO0O100O1111O010O><oO0oOO0O100O1111O010O o11o1o0o1O0oOO0oO0O1O="background-o1Oo0oO1100o01111oOOO:#FFFFE0"><o010111O10OOo11O01Oo0>oOoo0ooo100001101OO10</o010111O10OOo11O01Oo0><o010111O10OOo11O01Oo0>{oOoo0ooo100001101OO10}</o010111O10OOo11O01Oo0></oO0oOO0O100O1111O010O><oO0oOO0O100O1111O010O o11o1o0o1O0oOO0oO0O1O="background-o1Oo0oO1100o01111oOOO:#FFFFE0"><o010111O10OOo11O01Oo0>o11oo1oO1o01o1001O0oo</o010111O10OOo11O01Oo0><o010111O10OOo11O01Oo0>{oOOO000oO0ooOOOOO0ooo}</o010111O10OOo11O01Oo0></oO0oOO0O100O1111O010O></o1001OOO10oooO1O1OOoO>""".format(oOOOOo0o0O1oo11ooOOOO=o0111oO1o0o1o11o1Ooo1.get("metadata",{}).get("iskey",'N/A'), oooO0oOoOoOOoOo0001o0=o0111oO1o0o1o11o1Ooo1.get("nullable",'N/A'), oOoo0ooo100001101OO10= o0111oO1o0o1o11o1Ooo1.get("metadata",{}).get("sensitivity",'N/A'), oOOO000oO0ooOOOOO0ooo= o0111oO1o0o1o11o1Ooo1.get("metadata",{}).get("alias_name",'N/A'))
    }
    o1Oo101OOo0OOoOoo1011.append(o01o0oo1010O100OO1o0o)
  #for

  return o1Oo101OOo0OOoOoo1011
#def

def createIndivisualAttributes4AssetsInCollibra_fn(o00OOo0OO1o1O000OOo01, oO1000oO01o1oo1Oo0100, oOOO1OOoO110O1O0O1Ooo, o011O1Oo011O10O1OOo0o, oO0O01OoO0O1o00ooo10o):
  """
  /o10OO0o110o0100O1oooo
  """

  ooOO10OO0oO101OOo01O1 = o00OOo0OO1o1O000OOo01.get("{oO1000oO01o1oo1Oo0100} > {oOOO1OOoO110O1O0O1Ooo}".format(oO1000oO01o1oo1Oo0100 = oO1000oO01o1oo1Oo0100, oOOO1OOoO110O1O0O1Ooo = oOOO1OOoO110O1O0O1Ooo))
  return {
    "assetId": ooOO10OO0oO101OOo01O1,
    "typeId": collibra_setup.get(o011O1Oo011O10O1OOo0o),
    "value": oO0O01OoO0O1o00ooo10o
  }
#def

def createRelations4AssetsInCollibra_fn(oo010o0o0oOo1Oo111o1O, oOOO00oOo0o0ooOo1OooO):
  """
  """

  return {
    "relatedAssetIds": oo010o0o0oOo1Oo111o1O,
    "typeId": oOOO00oOo0o0ooOo1OooO,
    "relationDirection": "TO_TARGET"
  }

def createRelations4AssetsInCollibra_fn_reverse(oo010o0o0oOo1Oo111o1O, oOOO00oOo0o0ooOo1OooO):
  """
  """

  return {
    "relatedAssetIds": oo010o0o0oOo1Oo111o1O,
    "typeId": oOOO00oOo0o0ooOo1OooO,
    "relationDirection": "TO_SOURCE"
  }
#def

def assignDatabaseName(ooOOo1OOo00O0oo11OO00):
  if "snowflake" in ooOOo1OOo00O0oo11OO00.lower() or "synapse" in ooOOo1OOo00O0oo11OO00.lower():
    for o011oooO011ooOo0OOO0O in o0OOOO101010O1oO11ooo.get("data_source",{}):
      o1011oOoOO1OoOO0o01O0 = o011oooO011ooOo0OOO0O.get("type_specific_details",{})
      return o1011oOoOO1OoOO0o01O0.get("database_name")
  elif "delta" in ooOOo1OOo00O0oo11OO00.lower() or "dataset" in ooOOo1OOo00O0oo11OO00.lower():
    return "_".join(o1oO1oOOoo001OOoo001o['data_path'].split("/")[2:4])
#def

def assignTableName(ooOOo1OOo00O0oo11OO00):
  if "snowflake" in ooOOo1OOo00O0oo11OO00.lower():
    return o1oO1oOOoo001OOoo001o['table_name']
  elif "synapse" in ooOOo1OOo00O0oo11OO00.lower():
    return o1oO1oOOoo001OOoo001o['output_table']
  elif "delta" in ooOOo1OOo00O0oo11OO00.lower() or "dataset" in ooOOo1OOo00O0oo11OO00.lower():
    return "_".join(o1oO1oOOoo001OOoo001o['data_path'].split("/")[4:])
#def

def assignMasterAssetId(ooOOo1OOo00O0oo11OO00, o10oo1oOO0o1OO010O1Oo, o10oO001o000oOO0oOOoO):
  if "snowflake" in ooOOo1OOo00O0oo11OO00.lower() or "synapse" in ooOOo1OOo00O0oo11OO00.lower():
    return (o10oo1oOO0o1OO010O1Oo + "_" + o10oO001o000oOO0oOOoO)
  elif "delta" in ooOOo1OOo00O0oo11OO00.lower() or "dataset" in ooOOo1OOo00O0oo11OO00.lower():
    return o1oO1oOOoo001OOoo001o['data_path'].replace("/","_").replace("s3://","")
#def

#oo010001o0o0o0o00oOO0 oO1110o11101O0oO1O0O1 o1OO1010OOoOo1oo011o0 oO0O0OOoO011o0O10Oooo for o1oO001o0Oo11O10o10O0 (oOOo1o1Oo01OO10001OOo o000O1O0OO0oOo1Oo0o0o oOoOo1O01O0OoO0oOO10o o101o0o1OoOOoOOooOOo1 oO1101Oo010oOO0ooooo0 ooO0O11011OO0O0OO1O11)
def determineDomainId(ooOOo1OOo00O0oo11OO00):
  if "snowflake" in ooOOo1OOo00O0oo11OO00.lower():
    return collibra_setup.get("snowflake_domain_id")
  elif "synapse" in ooOOo1OOo00O0oo11OO00.lower():
    return collibra_setup.get("synapse_domain_id")
  elif "delta" in ooOOo1OOo00O0oo11OO00.lower() or "dataset" in ooOOo1OOo00O0oo11OO00.lower():
    return collibra_setup.get("adls_curated_domain_id")
#def

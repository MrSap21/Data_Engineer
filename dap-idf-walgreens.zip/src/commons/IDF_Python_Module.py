# Databricks notebook source
import traceback #line:2
import re #line:3
import json #line:4
from decimal import Decimal #line:5
from datetime import datetime ,timedelta #line:6
import time #line:7
from io import StringIO #line:8
from io import BytesIO #line:9
import uuid #line:10
import boto3 #line:12
class Encoder (json .JSONEncoder ):#line:17
    def default (O0O00O0OOO000000O ,OO0OO000OOOOO00O0 ):#line:18
        if isinstance (OO0OO000OOOOO00O0 ,Decimal ):#line:19
            return float (OO0OO000OOOOO00O0 )#line:20
        elif isinstance (OO0OO000OOOOO00O0 ,datetime ):#line:21
            return OO0OO000OOOOO00O0 .isoformat ()#line:22
        return super (Encoder ,O0O00O0OOO000000O ).default (OO0OO000OOOOO00O0 )#line:23
get_tablename_from_sql_query =lambda OO0O0O0000OOOOO0O :re .sub (r"^(.*?)\sfrom\s+([a-zA-Z0-9_.]+)(.*)?",lambda OO00OO000O0O0O00O :OO00OO000O0O0O00O .group (2 ),OO0O0O0000OOOOO0O )#line:28
def parseAndReturnJson_fn (OO00O0O000OOOO0OO ):#line:32
    ""#line:33
    return json .dumps (OO00O0O000OOOO0OO ,cls =Encoder )#line:35
def convertListOfDict2Dict_fn (OOO00OOO0000O0O00 ):#line:41
  return {OO0OO0OO00O000O0O :OO00OO00000O0O000 for OOOOO00OOO0OOOOO0 in OOO00OOO0000O0O00 for OO0OO0OO00O000O0O ,OO00OO00000O0O000 in OOOOO00OOO0OOOOO0 .items ()}#line:42
def getBucketAndKeyNameFromS3Path_fn (O0O0OO000O00OO000 ):#line:47
    O0OO0OOO0O0OO0O00 =re .search (r's3://(.*?)/(.*)',O0O0OO000O00OO000 ,re .IGNORECASE )#line:48
    return (O0OO0OOO0O0OO0O00 .group (1 ),O0OO0OOO0O0OO0O00 .group (2 ))#line:49
def generateCurrentDate_fn():
    """ 
    """
    try:
        currentTime = datetime.utcnow()
        return str(currentTime.year)+str(currentTime.month).zfill(2)+str(currentTime.day).zfill(2)
    #try
    except:
        traceback.print_exc()
        raise
    #except
#def

# COMMAND ----------

def generateCurrentDatetime_fn():
    """ 
    """
    try:
        currentTime = datetime.utcnow()
        return str(currentTime.year)+str(currentTime.month).zfill(2)+str(currentTime.day).zfill(2)+str(currentTime.hour).zfill(2)+str(currentTime.minute).zfill(2)+str(currentTime.second).zfill(2)
    #try
    except:
        traceback.print_exc()
        raise
    #except
#def

# COMMAND ----------

def getListOfDateWisePartition_fn(extraction_range, date_format="YYYYMMDD", from_date=None):
  """
  """
 
  if extraction_range.upper() == 'LAST_DAY':
    yesterday  = (datetime.today() - timedelta(days=1))
    if date_format == 'YYYYMMDD':
      return [yesterday.strftime('%Y%m%d')]
    #if
  #if
 
  elif extraction_range.upper() == 'LAST_WEEK':
    start_of_week = datetime.today() - timedelta(days=datetime.today() .weekday())
    end_of_week = start_of_week + timedelta(days=6)
    if date_format == 'YYYYMMDD':
      last_week = [start_of_week + timedelta(days=x) for x in range((end_of_week-start_of_week).days + 1)]
      last_week = [item.strftime('%Y%m%d')  for item in last_week]
      return last_week
    #if
  #elif
 
  elif extraction_range.upper() == 'LAST_MONTH':
    first_day_of_current_month = datetime.today().replace(day=1)
    first_day_previous_month  = (first_day_of_current_month - timedelta(days=1)).replace(day=1)
    last_day_of_previous_month = first_day_of_current_month - timedelta(days=1)
    if date_format == 'YYYYMMDD':
      last_month = [first_day_previous_month + timedelta(days=x) for x in range((last_day_of_previous_month-first_day_previous_month).days + 1)]
      last_month = [item.strftime('%Y%m%d')  for item in last_month]
      return last_month
    #if
  #elif
 
  elif extraction_range.upper() == 'TODAY':
    today  = (datetime.today())
    if date_format == 'YYYYMMDD':
      return [today.strftime('%Y%m%d')]
    #if
  #if
  
  elif extraction_range.upper() == 'FROM_DATE':
    
    if date_format == 'YYYYMMDD':
      today  = (datetime.today())
      from_date  = datetime.strptime(from_date, '%Y%m%d')
      ddd = [from_date + timedelta(days=x) for x in range((today-from_date).days + 1)]
      return [item.strftime('%Y%m%d')  for item in ddd]
    #if
  #if
  
  elif extraction_range.upper() == 'EXACT_DATE':
    
    if date_format == 'YYYYMMDD':
      from_date  = datetime.strptime(from_date, '%Y%m%d')
      ddd = [from_date ]
      return [item.strftime('%Y%m%d')  for item in ddd]
    #if
  #if
  
  else:
    return None
  #else
#def

# COMMAND ----------

def validateSchema_fn(col_schema):
  
  column_name = col_schema.get('name','')
  column_type = col_schema.get('type','').upper()
  optional = str(col_schema.get('nullable',False)).upper()

  _derived_fn = None

  if optional == 'TRUE':
      column_name = Optional(column_name)
  #if

  if column_type == 'INT' or column_type == 'INTEGER':
      column_type = Use(int)
      permissible_numeric_range = col_schema.get('metadata',{}).get("permissible_values",'').split(",")
      if len(permissible_numeric_range) == 2:
          _derived_fn = lambda l: int(permissible_numeric_range[0]) <= l <= int(permissible_numeric_range[1])
      #if
  #if
  elif column_type == 'FLOAT' or column_type == 'DOUBLE' or column_type == 'DECIMAL':
      column_type = Use(float)
      permissible_numeric_range = col_schema.get('metadata',{}).get("permissible_values",'').split(",")
      if len(permissible_numeric_range) == 2:
          _derived_fn = lambda l: float(permissible_numeric_range[0]) <= l <= float(permissible_numeric_range[1])
      #if
  #if
  elif column_type == 'STR' or column_type == 'STRING':
      column_type = str
      #permissible_string_values = col_schema.get('metadata',{}).get("permissible_values",'')
      #if permissible_string_values.upper() != 'NA' :
          #_derived_fn = lambda l: l in permissible_string_values.split(",")
      #if
  #if
  else :
      return {}
  #else

  if _derived_fn != None:
      column_checks = And(column_type, _derived_fn)
  #if
  else:
      column_checks = column_type
  #else

  return {column_name :  column_checks}
#def

# COMMAND ----------

def moveFilesBetweenFolders_fn(source, destination):
  """
  """
  dir_path = f"{destination}/_success.csv"
  os.makedirs(os.path.dirname(dir_path), exist_ok=True)
  files_list = os.listdir(source)
  for files in files_list:
      shutil.move(f"{source}/{files}", f"{destination}/")
#def


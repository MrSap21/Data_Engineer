# Databricks notebook source
import os
import sys
import re
import json
import traceback
import uuid
from datetime import datetime,timedelta
import pytz
from dateutil.relativedelta import relativedelta
from decimal import Decimal
from typing import Iterable 
from itertools import * 
from functools import wraps
from inspect import getcallargs, getargspec
from collections import OrderedDict, Iterable
import logging
import importlib
import inspect
from io import StringIO, BytesIO

import boto3

import pyspark
from pyspark.sql import SparkSession, Row
from pyspark.sql import SQLContext, DataFrame
from pyspark.sql.types import *
import pyspark.sql.functions as F
from pyspark.sql.window import Window


# COMMAND ----------

get_function_args = lambda l: inspect.getargspec(l).args

# COMMAND ----------

filter_column_names = lambda x,y: list(filter(lambda l: l!=y,x))

data_type_mapping = {"string":StringType(), "integer" : IntegerType(), "double": DoubleType(), "date": DateType(), "timestamp": TimestampType(), "boolean": BooleanType(), 'long': LongType(), 'float': FloatType(), "decimal": DecimalType()}

check_part_of_item_in_list_fn = lambda l, m: True if any(s in l for s in m) else False

# COMMAND ----------

class CommonBaseClass(object):

  #logdebug = log_to(logging.debug)
  
  def __init__ (self):
    self.RECORDER_BASE = []
    #logdebug = log_to(logging.debug)
  #def

  def run(self, plugins:list=[]):
    if plugins != []:
      self._plugins = [importlib.import_module(plugin,".").Plugin() for plugin in plugins]
    #if
    
    else:
      self._plugins = [importlib.import_module('default',".") .Plugin()]
    #else
  #def

  #@logdebug
  def process(self, spark, dataframe, params,  plugins = ()):
    try:
      for plugin in plugins:
          dataframe = plugin().process(spark, dataframe, params)
              
      self.RECORDER_BASE.append("Object Name : {func_name} ; Time : {time} ; Arguments :  {args}".format(func_name = plugins, time = str(datetime.now()) , args = params, ))
      return dataframe
    #try
    except:
      traceback.print_exc()
      self.RECORDER_BASE.append("IDF_Exception : {func_name} ; Time : {time} ; Arguments :  {args} ;  {exception} : {trace}".format(func_name = plugins, time = str(datetime.now()) , args = params, exception =sys .exc_info ()[0 ], trace = traceback.format_exc()))
    #except
    finally:
      for plugin in plugins:
        plugin = None
    #finally
  #def

  @classmethod
  def plugin(cls,plugin):
    return plugin
  #def

#class

# COMMAND ----------

class DataGovernanceBaseClass (object):
    def class_type(self):
      print("RulesEngineBaseClass")
    #def

    def process(self, spark, ASSET_REGISTRY, params):
      try:
        return ASSET_REGISTRY
      #try
      finally:
        pass
      #finally
    #def
#class

# COMMAND ----------

class DataObfuscationBaseClass (object):
  def class_type(self):
    print("RulesEngineBaseClass")
  #def
  
  def execute(self,  params):
    return get_function_args(params.get("function_name"))
  #def
#class

# COMMAND ----------

#idf_binary_obj = CommonBaseClass()
#idf_binary_obj.process(spark = spark, dataframe = None, params={"rule":{"type":"convert_type"}, "df_column_list": "d"}, plugins=(RulesEngineComplexExtClass,))

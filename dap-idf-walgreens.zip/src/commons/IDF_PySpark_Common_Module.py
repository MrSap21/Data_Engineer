# Databricks notebook source
import os #line:2
import sys #line:3
import re #line:4
import json #line:5
import traceback #line:6
import uuid #line:7
from datetime import datetime #JPM#,timedelta #line:8
#JPM#import pytz #line:9
from dateutil .relativedelta import relativedelta #line:10
#JPM#from typing import Iterable #line:11
from itertools import *#line:12
from functools import wraps #line:13
#JPM#from inspect import getcallargs ,getargspec #line:14
#JPM#from collections import OrderedDict ,Iterable #line:15
import logging #line:16
import boto3 #line:18
#JPM#import pyspark #line:20
#JPM#from pyspark .sql import SparkSession ,Row #line:21
from pyspark .sql import SQLContext ,DataFrame #line:22
from pyspark .sql .types import *#line:23
import pyspark .sql .functions as F #line:24
from pyspark .sql .window import Window #line:25
#JPM#from pyspark .ml import Pipeline #line:28
#JPM#from pyspark .ml .feature import StringIndexer ,VectorAssembler #line:29
#JPM#from pyspark .mllib .stat import Statistics #line:30
#JPM#from pyspark .ml .stat import KolmogorovSmirnovTest ,Summarizer ,Summarizer #line:31
#JPM#from pyspark .mllib .util import MLUtils #line:32
#from CommonBase import *#line:34
RECORDER_SPARK_COMMON =[]#line:38
def log_to (O00O0O000O0000O0O ):#line:39
    def O0OOOO0OO0000OO0O (O0O0OOO0OO000OO00 ):#line:40
      @wraps (O0O0OOO0OO000OO00 )#line:41
      def O0O0O0O00OO0O000O (*O0O00OOO00OO0O000 ,**O0O0O0OOOO0OOOO0O ):#line:42
        try :#line:43
          RECORDER_SPARK_COMMON .append ("Function Name : {func_name} ; Time : {time} ; Arguments :  {args}".format (func_name =O0O0OOO0OO000OO00 .__name__ ,time =str (datetime .now ()),args =O0O00OOO00OO0O000 ))#line:44
          return O0O0OOO0OO000OO00 (*O0O00OOO00OO0O000 ,**O0O0O0OOOO0OOOO0O )#line:45
        except :#line:47
          RECORDER_SPARK_COMMON .append ("IDF_Exception :  {exception} : {trace}".format (exception =sys .exc_info ()[0 ],trace =traceback .format_exc ()))#line:48
      return O0O0O0O00OO0O000O #line:51
    return O0OOOO0OO0000OO0O #line:53
logdebug =log_to (logging .debug )#line:55
def schemaEqualityCheck (O00OOOOO00OOOO0O0 ,O00O00OO000OO0O00 ):#line:59
    def OO0O0000O0O00O00O (O0O0OO0OOO0O00O00 ,OO0OOOOO00O00O0O0 ):#line:61
        OOO00O000OOOOOOOO =[]#line:63
        O0O00OOOOO000O00O =[]#line:64
        OOO0OOO000O0OO0OO =[]#line:66
        O0OOO00OO0OO00O0O =[]#line:67
        for O0OOO0OO00OOO0O00 in O0O0OO0OOO0O00O00 :#line:69
            OOO00O000OOOOOOOO .append (O0OOO0OO00OOO0O00 [0 ].lower ())#line:70
        for O0OOO0OO00OOO0O00 in OO0OOOOO00O00O0O0 :#line:72
            O0O00OOOOO000O00O .append (O0OOO0OO00OOO0O00 [0 ].lower ())#line:73
        OOO00O000OOOOOOOO .sort ()#line:75
        O0O00OOOOO000O00O .sort ()#line:76
        if (OOO00O000OOOOOOOO !=O0O00OOOOO000O00O ):#line:78
            OOO0OOO000O0OO0OO =list (set (OOO00O000OOOOOOOO )-set (O0O00OOOOO000O00O ))#line:79
            O0OOO00OO0OO00O0O =list (set (O0O00OOOOO000O00O )-set (OOO00O000OOOOOOOO ))#line:80
            return (False ,{'mismatchedColumn_names_from_default_schema':OOO0OOO000O0OO0OO ,'mismatchedColumn_names_from_evaluated_schema':O0OOO00OO0OO00O0O })#line:82
        else :#line:84
            return (True ,{'mismatchedColumn_names_from_default_schema':OOO0OOO000O0OO0OO ,'mismatchedColumn_names_from_evaluated_schema':O0OOO00OO0OO00O0O })#line:85
    def OO00OOOOOO0OOOOOO (OOOO0OOO000O0000O ,OO00O0O00O0OOOOO0 ):#line:87
        OO0000OOOO0OOOO0O =[]#line:89
        for O00O0O0OOOO00OOOO in OOOO0OOO000O0000O :#line:91
            for O000000O0OOOO0OOO in OO00O0O00O0OOOOO0 :#line:92
                if (O00O0O0OOOO00OOOO [0 ]==O000000O0OOOO0OOO [0 ]and O00O0O0OOOO00OOOO [1 ]!=O000000O0OOOO0OOO [1 ]):#line:93
                    OO0000OOOO0OOOO0O .append ((O00O0O0OOOO00OOOO [0 ],O00O0O0OOOO00OOOO [1 ],O000000O0OOOO0OOO [1 ]))#line:94
        return OO0000OOOO0OOOO0O #line:96
    def OOO0OO00OOOO0OO00 (OO000OO0OO0O0000O ):#line:98
        def OO0OO000O00O0O0OO (OO00000O00OOOO0OO ):#line:101
            O00O0OO0O00O0OOO0 =['float','double']#line:102
            O0O0OO0O00O00O000 =[]#line:104
            for OOOOO0OOOOOOO00O0 in OO00000O00OOOO0OO :#line:106
                if (OOOOO0OOOOOOO00O0 [1 ]in O00O0OO0O00O0OOO0 and OOOOO0OOOOOOO00O0 [2 ]in O00O0OO0O00O0OOO0 ):#line:107
                    O0O0OO0O00O00O000 .append (OOOOO0OOOOOOO00O0 )#line:108
            return list (set (OO00000O00OOOO0OO )-set (O0O0OO0O00O00O000 ))#line:110
        OO0000O0000O0OOO0 =OO0OO000O00O0O0OO (OO000OO0OO0O0000O )#line:112
        OO0O00O00O0O0OO00 =[]#line:114
        for OO0OOOO000OOO0000 in OO0000O0000O0OOO0 :#line:116
            OO0OO0O0000000O0O ={}#line:117
            OO0OO0O0000000O0O ['column_name']=OO0OOOO000OOO0000 [0 ]#line:118
            OO0OO0O0000000O0O ['inferred_column_datatype']=OO0OOOO000OOO0000 [1 ]#line:119
            OO0OO0O0000000O0O ['externally_provided_column_datatype']=OO0OOOO000OOO0000 [2 ]#line:120
            OO0O00O00O0O0OO00 .append (OO0OO0O0000000O0O )#line:121
        return OO0O00O00O0O0OO00 #line:123
    O000O00O00000OO00 =OO00OOOOOO0OOOOOO (O00OOOOO00OOOO0O0 ,O00O00OO000OO0O00 )#line:125
    O0O0000OOOO0O0000 =OOO0OO00OOOO0OO00 (O000O00O00000OO00 )#line:127
    OOO000OOO00O0O0OO =OO0O0000O0O00O00O (O00OOOOO00OOOO0O0 ,O00O00OO000OO0O00 )#line:128
    O0OOO00O0OO0OOOOO ={}#line:130
    O0OOO00O0OO0OOOOO ['dataType_mismatches']=O0O0000OOOO0O0000 #line:132
    O0OOO00O0OO0OOOOO ['columnName_mismatches']=OOO000OOO00O0O0OO #line:133
    return O0OOO00O0OO0OOOOO #line:135
def normalizeDataframeColumns_fn (OO0OOO0OOO00OO00O ,O0O0O00O0OOOO0000 ):#line:140
  try :#line:141
    return O0O0O00O0OOOO0000 .toDF (*(re .sub (r'(.*)_$',lambda OO00000O00000OO00 :OO00000O00000OO00 .group (1 ),re .sub (r'^(_)(.*)',lambda O0O0OOOO0000O0OOO :O0O0OOOO0000O0OOO .group (2 ),re .sub (r'[__+]','_',re .sub (r'[^a-zA-Z0-9]+','_',O00O0O0O00O0000OO .lower ().strip ()))))for O00O0O0O00O0000OO in O0O0O00O0OOOO0000 .columns ))#line:143
  finally :#line:145
    O0O0O00O0OOOO0000 =None #line:146
@logdebug #line:152
def readCSVFilesWithFilterPartitionAndSchema_fn (OO0000O0OOO0OOO0O ,OOO0O0OO000000O0O ,partition_list =None ,schema =None ,header =False ,seperator =",",escape_character ='"',validate_schema =False ,distinct =False ,ignoreTrailingWhiteSpace ="true",ignoreLeadingWhiteSpace ="true", mergeSchema = "true"):#line:155
    ""#line:157
    if escape_character !="\\":#line:158
        escape_character ='"'#line:159
    if partition_list ==None :#line:161
        OO00000O00OO0000O =OOO0O0OO000000O0O #line:162
    else :#line:164
        OO00000O00OO0000O =list (map (lambda O0OO0000O0O000000 :f"{OOO0O0OO000000O0O}/{O0OO0000O0O000000}",partition_list ))#line:165
    if schema !=None and validate_schema :#line:168
        O0O000O0O0000OOO0 =OO0000O0OOO0OOO0O .read .format ('csv').option ('sep',seperator ).option ('quote','"').option ('escape',escape_character ).option ("multiline","true").option ("ignoreTrailingWhiteSpace",ignoreTrailingWhiteSpace ).option ("ignoreLeadingWhiteSpace",ignoreLeadingWhiteSpace ).option ('header',header ).option ('inferSchema','true').option ('mergeSchema',mergeSchema).option ("nanValue",None ).load (OO00000O00OO0000O ).limit (10 )#line:170
        OO0OOOO000O0O00O0 =[(re .sub (r'(.*)_$',lambda OOOOO000OO0OO0OO0 :OOOOO000OO0OO0OO0 .group (1 ),re .sub (r'^(_)(.*)',lambda O000O0000OOOOOO0O :O000O0000OOOOOO0O .group (2 ),re .sub (r'[__+]','_',re .sub (r'[^a-zA-Z0-9]+','_',O0O000OOO0O0O0OOO .lower ().strip ())))))for O0O000OOO0O0O0OOO in O0O000O0O0000OOO0 .dtypes ]#line:172
        O00OO000OO0OOOO0O =[(O000O0OOO0O0OOO0O ["name"].lower (),O000O0OOO0O0OOO0O ["type"].replace ('integer','int').replace ('boolean','bool').replace ('decimal','double'))for O000O0OOO0O0OOO0O in schema ]#line:174
        OO00O0OO0OO0OOOO0 =schemaEqualityCheck (OO0OOOO000O0O00O0 ,O00OO000OO0OOOO0O )['dataType_mismatches']#line:175
        O0OO0O0O00O0000OO =schemaEqualityCheck (OO0OOOO000O0O00O0 ,O00OO000OO0OOOO0O )['columnName_mismatches']#line:176
        if validate_schema and (len (OO00O0OO0OO0OOOO0 )!=0 or O0OO0O0O00O0000OO [0 ]==False ):#line:178
            raise ValueError ("Error In Schema validation, (default_schema, evaluated_schema, columns_with_datatype_issues, columns_with_name_issues) :: ",OO0OOOO000O0O00O0 ,O00OO000OO0OOOO0O ,OO00O0OO0OO0OOOO0 ,O0OO0O0O00O0000OO [1 ])#line:180
        if OO0OOOO000O0O00O0 !=O00OO000OO0OOOO0O :#line:183
          raise ValueError ("Error in Schema validation, column order does not match: ",OO0OOOO000O0O00O0 ,O00OO000OO0OOOO0O )#line:184
        O0O00O00O0OO0OO0O =OO0000O0OOO0OOO0O .read .format ('csv').option ('sep',seperator ).option ('quote','"').option ('escape',escape_character ).option ("multiline","true").option ("ignoreTrailingWhiteSpace",ignoreTrailingWhiteSpace ).option ('ignoreLeadingWhiteSpace',ignoreLeadingWhiteSpace ).option ('header',header ).option ('mergeSchema',mergeSchema).option ("nanValue",None ).load (OO00000O00OO0000O )#line:189
        O0O00O00O0OO0OO0O =O0O00O00O0OO0OO0O .toDF (*(re .sub (r'(.*)_$',lambda O00OOO0000O0OO0O0 :O00OOO0000O0OO0O0 .group (1 ),re .sub (r'^(_)(.*)',lambda OO0O00O0O0O00O0OO :OO0O00O0O0O00O0OO .group (2 ),re .sub (r'[__+]','_',re .sub (r'[^a-zA-Z0-9]+','_',OO0O00O00000OOO0O .lower ().strip ()))))for OO0O00O00000OOO0O in O0O00O00O0OO0OO0O .columns ))#line:191
    elif schema !=None and not validate_schema :#line:195
        O0O00O00O0OO0OO0O =OO0000O0OOO0OOO0O .read .format ('csv').option ('sep',seperator ).option ('quote','"').option ('escape',escape_character ).option ("multiline","true").option ("ignoreTrailingWhiteSpace",ignoreTrailingWhiteSpace ).option ('ignoreLeadingWhiteSpace',ignoreLeadingWhiteSpace ).option ('header',header ).option ('mergeSchema',mergeSchema).option ("nanValue",None ).schema (StructType .fromJson ({"fields":schema })).load (OO00000O00OO0000O )#line:198
        O0O00O00O0OO0OO0O =O0O00O00O0OO0OO0O .toDF (*(re .sub (r'(.*)_$',lambda O0OOO00OO00O00000 :O0OOO00OO00O00000 .group (1 ),re .sub (r'^(_)(.*)',lambda O0O00OO0O0OO00000 :O0O00OO0O0OO00000 .group (2 ),re .sub (r'[__+]','_',re .sub (r'[^a-zA-Z0-9]+','_',O0000OOOOO00O00OO .lower ().strip ()))))for O0000OOOOO00O00OO in O0O00O00O0OO0OO0O .columns ))#line:200
    else :#line:204
      O0O00O00O0OO0OO0O =OO0000O0OOO0OOO0O .read .format ('csv').option ('sep',seperator ).option ('quote','"').option ('escape',escape_character ).option ("multiline","true").option ("ignoreTrailingWhiteSpace",ignoreTrailingWhiteSpace ).option ('ignoreLeadingWhiteSpace',ignoreLeadingWhiteSpace ).option ('header',header ).option ('mergeSchema',mergeSchema).option ("nanValue",None ).load (OO00000O00OO0000O )#line:207
      O0O00O00O0OO0OO0O =O0O00O00O0OO0OO0O .toDF (*(re .sub (r'(.*)_$',lambda O0OOO000OO0OO0000 :O0OOO000OO0OO0000 .group (1 ),re .sub (r'^(_)(.*)',lambda O000O0O00OOOO0O00 :O000O0O00OOOO0O00 .group (2 ),re .sub (r'[__+]','_',re .sub (r'[^a-zA-Z0-9]+','_',O0OOOO000OO0O000O .lower ().strip ()))))for O0OOOO000OO0O000O in O0O00O00O0OO0OO0O .columns ))#line:210
    if distinct :#line:214
        return O0O00O00O0OO0OO0O .distinct ()#line:215
    return O0O00O00O0OO0OO0O #line:218
@logdebug #line:224
def readParquetFilesFromFolder_fn (O00OOO0OOO0OO000O ,O0000O0OO0O00O00O ,partition_list =None ,distinct_flag =False ):#line:225
    if partition_list ==None :#line:226
        OO0OO00O0O00O0000 =O0000O0OO0O00O00O #line:227
    else :#line:229
      OO0OO00O0O00O0000 =list (map (lambda OO00OOOOO00O0O00O :f"{O0000O0OO0O00O00O}/{OO00OOOOO00O0O00O}",partition_list ))#line:230
    if False ==distinct_flag :#line:233
        return O00OOO0OOO0OO000O .read .format ('parquet').option ('inferSchema','true').option ('mergeSchema','true').load (OO0OO00O0O00O0000 )#line:234
    else :#line:236
        return O00OOO0OOO0OO000O .read .format ('parquet').option ('inferSchema','true').option ('mergeSchema','true').load (OO0OO00O0O00O0000 ).distinct ()#line:237
@logdebug #line:243
def extendedReadCSVDataSets2Dataframe_fn (*,spark ,base_path ,params =None ,partitions =None ,schema =None ):#line:244
  ""#line:257
  try :#line:258
    if partitions ==None :#line:259
        OOOOO0O0OOOOOO0O0 =base_path #line:260
    else :#line:262
        OOOOO0O0OOOOOO0O0 =list (map (lambda OOO0OOOOO0O0OO0O0 :f"{base_path}/{OOO0OOOOO0O0OO0O0}",partitions ))#line:263
    if schema !=None :#line:266
      O00O0O00OOO0OO0OO =spark .read .options (**params ).schema (StructType .fromJson ({"fields":schema })).csv (OOOOO0O0OOOOOO0O0 )#line:267
    else :#line:269
      O00O0O00OOO0OO0OO =spark .read .options (**params ).csv (OOOOO0O0OOOOOO0O0 )#line:270
    return O00O0O00OOO0OO0OO .toDF (*(re .sub (r'(.*)_$',lambda O0OOO000O0OO00OOO :O0OOO000O0OO00OOO .group (1 ),re .sub (r'^(_)(.*)',lambda O0O000O0O0OOO00O0 :O0O000O0O0OOO00O0 .group (2 ),re .sub (r'[__+]','_',re .sub (r'[^a-zA-Z0-9]+','_',O0OO00OOO000O00OO .lower ().strip ()))))for O0OO00OOO000O00OO in O00O0O00OOO0OO0OO .columns ))#line:275
  finally :#line:277
    O00O0O00OOO0OO0OO =None #line:278
@logdebug #line:284
def readParquetWithDecimal4Databricks_fn (O000O0OOO0O0O0OO0 ,OO0OO00OO00OOO0O0 ,partition_list =None ,distinct_flag =False ):#line:285
  ""#line:287
  if partition_list ==None :#line:288
      O0OO000O0OOO00OOO =OO0OO00OO00OOO0O0 #line:289
  else :#line:291
    O0OO000O0OOO00OOO =list (map (lambda OO0O0O0OOO00OOO0O :f"{OO0OO00OO00OOO0O0}/{OO0O0O0OOO00OOO0O}",partition_list ))#line:292
  OOO0O000O00O0O0O0 =0 #line:295
  for OOOO00OO0OO0OO000 in O0OO000O0OOO00OOO :#line:296
    O0O0OO0O00OO0O00O ="/dbfs"#line:297
    for O00OO000O0O0OOOOO in os .listdir (O0O0OO0O00OO0O00O +OOOO00OO0OO0OO000 ):#line:299
      OO0OO0O00OOOOO0O0 =O000O0OOO0O0O0OO0 .read .parquet (OOOO00OO0OO0OO000 +"/"+O00OO000O0O0OOOOO )#line:300
      if OOO0O000O00O0O0O0 ==0 :#line:302
        O0O000OO0O0000OO0 =OO0OO0O00OOOOO0O0 .toJSON ()#line:303
      else :#line:304
        O0O000OO0O0000OO0 =O0O000OO0O0000OO0 .union (OO0OO0O00OOOOO0O0 .toJSON ())#line:305
      OOO0O000O00O0O0O0 =OOO0O000O00O0O0O0 +1 #line:306
  if distinct_flag ==False :#line:309
    return O000O0OOO0O0O0OO0 .read .json (O0O000OO0O0000OO0 )#line:310
  else :#line:312
    return O000O0OOO0O0O0OO0 .read .json (O0O000OO0O0000OO0 ).distinct ()#line:313
  return O000O0OOO0O0O0OO0 .read .json (O0O000OO0O0000OO0 )#line:316
@logdebug #line:322
def readJSONFilesFromFolder_fn (OOOO0OO0OOO0000O0 ,OOOOOOO0000O00OOO ,sampling_ratio =1.0 ):#line:323
  ""#line:326
  def _O00O0000OO0O0000O (OO000O0OO0OO0OOOO ):#line:328
    O000OO0OO00O0OO0O =OO000O0OO0OO0OOOO .schema .fields #line:329
    OO0O0O0OOOOO000OO ={}#line:330
    for O000O0OOOOO00O0O0 in O000OO0OO00O0OO0O :#line:331
        OO0O0O0OOOOO000OO [O000O0OOOOO00O0O0 .name ]=O000O0OOOOO00O0O0 .dataType #line:332
    return OO0O0O0OOOOO000OO #line:334
  def _OOOOOOO0OOOO0O0OO (OOOOO00OO000OOOO0 ,O0OO0O0O000OOO0O0 ,OO0000OOO0OO0000O ):#line:337
    O0000OOO0O000O000 =OOOOO00OO000OOOO0 .columns #line:338
    OO0000O000OO000OO =OO0000OOO0OO0000O .get (O0OO0O0O000OOO0O0 )#line:339
    OO0000000O00OO0O0 =OO0000O000OO000OO .names #line:340
    OO0OOOOO0O0O0000O =[O0OO0O0O000OOO0O0 +'.'+OO00OOO000O0O0000 for OO00OOO000O0O0000 in OO0000000O00OO0O0 ]#line:341
    OO0OOO0OO0000OO00 =O0000OOO0O000O000 +OO0OOOOO0O0O0000O #line:342
    O00O0O0OO000O00OO =[]#line:343
    for OO000O000OO0OO000 in OO0OOO0OO0000OO00 :#line:345
        if OO000O000OO0OO000 in OO0OOOOO0O0O0000O :#line:346
            O00O0O0OO000O00OO .append (F .col (OO000O000OO0OO000 ).alias (OO000O000OO0OO000 .replace ('.','_')))#line:347
        elif OO000O000OO0OO000 in O0000OOO0O000O000 :#line:348
            O00O0O0OO000O00OO .append ((F .col (OO000O000OO0OO000 )))#line:349
    return OOOOO00OO000OOOO0 .select (O00O0O0OO000O00OO ).drop (O0OO0O0O000OOO0O0 )#line:351
  def _O0OO00OO000O000OO (O0O0OOOO0000OOO00 ,O0OO0OO0O0OO0OOOO ):#line:354
    O00O000OOOO000O00 =O0OO0OO0O0OO0OOOO +'_exploded'#line:355
    return O0O0OOOO0000OOO00 .withColumn (O00O000OOOO000O00 ,F .explode_outer (F .col (O0OO0OO0O0OO0OOOO ))).drop (O0OO0OO0O0OO0OOOO ).withColumnRenamed (O00O000OOOO000O00 ,O0OO0OO0O0OO0OOOO )#line:359
  def _O00OOO0OO000O0OOO (OOOO00OOO0000O0OO ):#line:363
    O000OO0OO0OOOO0OO =_O00O0000OO0O0000O (OOOO00OOO0000O0OO )#line:364
    OO0OOO00OO0O0OO00 =False #line:365
    for O0000O0OO0O00OO00 in O000OO0OO0OOOO0OO :#line:367
        if (issubclass (type (O000OO0OO0OOOO0OO [O0000O0OO0O00OO00 ]),ArrayType )or issubclass (type (O000OO0OO0OOOO0OO [O0000O0OO0O00OO00 ]),StructType )):#line:368
            OO0OOO00OO0O0OO00 =True #line:369
            break #line:370
    while (OO0OOO00OO0O0OO00 ):#line:372
        for O0000O0OO0O00OO00 in O000OO0OO0OOOO0OO :#line:373
            if (issubclass (type (O000OO0OO0OOOO0OO [O0000O0OO0O00OO00 ]),ArrayType )):#line:374
                OOOO00OOO0000O0OO =_O0OO00OO000O000OO (OOOO00OOO0000O0OO ,O0000O0OO0O00OO00 )#line:375
            elif (issubclass (type (O000OO0OO0OOOO0OO [O0000O0OO0O00OO00 ]),StructType )):#line:376
                OOOO00OOO0000O0OO =_OOOOOOO0OOOO0O0OO (OOOO00OOO0000O0OO ,O0000O0OO0O00OO00 ,O000OO0OO0OOOO0OO )#line:377
        O000OO0OO0OOOO0OO =_O00O0000OO0O0000O (OOOO00OOO0000O0OO )#line:379
        for O0000O0OO0O00OO00 in O000OO0OO0OOOO0OO :#line:381
            if (issubclass (type (O000OO0OO0OOOO0OO [O0000O0OO0O00OO00 ]),ArrayType )or issubclass (type (O000OO0OO0OOOO0OO [O0000O0OO0O00OO00 ]),StructType )):#line:382
                OO0OOO00OO0O0OO00 =True #line:383
                break #line:384
            else :#line:385
                OO0OOO00OO0O0OO00 =False #line:386
    return OOOO00OOO0000O0OO #line:388
  OO0OOO0O0OOO000OO =OOOO0OO0OOO0000O0 .read .options (samplingRatio =float (sampling_ratio )).option ("multiline","true").option ('mergeSchema','true').option ("inferTimestamp","false").option ("prefersDecimal","false").option ('samplingRatio',sampling_ratio ).json (OOOOOOO0000O00OOO )#line:391
  OO0OOO0O0OOO000OO =_O00OOO0OO000O0OOO (OO0OOO0O0OOO000OO )#line:393
  return OO0OOO0O0OOO000OO .toDF (*(OO00OOOO0O0000O00 .lower ().replace ('\t','_').replace ("/","_").replace ("-","_").replace ("(","_").replace (")","_").replace ("__","_").replace ("$","_").replace (".","_").replace ('&','_').replace (":","").replace ("@","").strip ()for OO00OOOO0O0000O00 in OO0OOO0O0OOO000OO .columns ))#line:394
@logdebug #line:400
def readXMLFilesFromFolder_fn (O0O00OOOO000OOO0O ,OOOOO0O000OO0OOO0 ,O0000OOOOOOO0000O ,O00OO0O0O00O0O0O0 ,sampling_ratio =1.0 ):#line:401
    ""#line:403
    def _OOOO0000OOOO0O0OO (O0OOOOO0OO000OOO0 ):#line:405
        O00O0OO0OOO0O0O0O =O0OOOOO0OO000OOO0 .schema .fields #line:406
        O0OOOOOO000O0OO00 ={}#line:407
        for OOO00000OOOO0OO0O in O00O0OO0OOO0O0O0O :#line:408
            O0OOOOOO000O0OO00 [OOO00000OOOO0OO0O .name ]=OOO00000OOOO0OO0O .dataType #line:409
        return O0OOOOOO000O0OO00 #line:411
    def _OO0OO0O0O0000OO00 (OO000OOO000000O0O ,OOOO000OOO0OO00OO ,OO00O0000O0OO0OO0 ):#line:415
        OOO0OOOO00O00O000 =OO000OOO000000O0O .columns #line:416
        OO0000O0OOO000OOO =OO00O0000O0OO0OO0 .get (OOOO000OOO0OO00OO )#line:417
        O0OO00OOO0OO0O00O =OO0000O0OOO000OOO .names #line:418
        OOO000OOOOOOOO00O =[OOOO000OOO0OO00OO +'.'+OOO0O0000O000O0OO for OOO0O0000O000O0OO in O0OO00OOO0OO0O00O ]#line:420
        OO00OOO000000O0O0 =OOO0OOOO00O00O000 +OOO000OOOOOOOO00O #line:421
        O0OO0O0O0000000OO =[]#line:422
        for OO00000O00O0O0O00 in OO00OOO000000O0O0 :#line:424
            if OO00000O00O0O0O00 in OOO000OOOOOOOO00O :#line:425
                O0OO0O0O0000000OO .append (F .col (OO00000O00O0O0O00 ).alias (OO00000O00O0O0O00 .replace ('.','_')))#line:426
            elif OO00000O00O0O0O00 in OOO0OOOO00O00O000 :#line:427
                O0OO0O0O0000000OO .append ((F .col (OO00000O00O0O0O00 )))#line:428
        return OO000OOO000000O0O .select (O0OO0O0O0000000OO ).drop (OOOO000OOO0OO00OO )#line:430
    def _O0000O0OO0O00O0O0 (OO00O0OOO0OOOOO0O ,OO0000000O0OO0O0O ):#line:434
        O0O00OOOOOO00O0OO =OO0000000O0OO0O0O +'_exploded'#line:435
        return OO00O0OOO0OOOOO0O .withColumn (O0O00OOOOOO00O0OO ,F .explode_outer (F .col (OO0000000O0OO0O0O ))).drop (OO0000000O0OO0O0O ).withColumnRenamed (O0O00OOOOOO00O0OO ,OO0000000O0OO0O0O )#line:439
    def _OOOO00O00O0OOOOOO (OO0OO0OOO0OOO0OOO ):#line:443
        O000O00OOOO0OOO0O =_OOOO0000OOOO0O0OO (OO0OO0OOO0OOO0OOO )#line:444
        OOO0O00O0000000OO =False #line:445
        for O00O0OO0OO000OO0O in O000O00OOOO0OOO0O :#line:447
            if (issubclass (type (O000O00OOOO0OOO0O [O00O0OO0OO000OO0O ]),ArrayType )or issubclass (type (O000O00OOOO0OOO0O [O00O0OO0OO000OO0O ]),StructType )):#line:448
                OOO0O00O0000000OO =True #line:449
                break #line:450
        while (OOO0O00O0000000OO ):#line:452
            for O00O0OO0OO000OO0O in O000O00OOOO0OOO0O :#line:453
                if (issubclass (type (O000O00OOOO0OOO0O [O00O0OO0OO000OO0O ]),ArrayType )):#line:454
                    OO0OO0OOO0OOO0OOO =_O0000O0OO0O00O0O0 (OO0OO0OOO0OOO0OOO ,O00O0OO0OO000OO0O )#line:455
                elif (issubclass (type (O000O00OOOO0OOO0O [O00O0OO0OO000OO0O ]),StructType )):#line:456
                    OO0OO0OOO0OOO0OOO =_OO0OO0O0O0000OO00 (OO0OO0OOO0OOO0OOO ,O00O0OO0OO000OO0O ,O000O00OOOO0OOO0O )#line:457
            O000O00OOOO0OOO0O =_OOOO0000OOOO0O0OO (OO0OO0OOO0OOO0OOO )#line:459
            for O00O0OO0OO000OO0O in O000O00OOOO0OOO0O :#line:461
                if (issubclass (type (O000O00OOOO0OOO0O [O00O0OO0OO000OO0O ]),ArrayType )or issubclass (type (O000O00OOOO0OOO0O [O00O0OO0OO000OO0O ]),StructType )):#line:462
                    OOO0O00O0000000OO =True #line:463
                    break #line:464
                else :#line:465
                    OOO0O00O0000000OO =False #line:466
        return OO0OO0OOO0OOO0OOO #line:468
    def _O0OOO00O00O0OO00O (O0O0O0OOO00OOO0OO ,O0OOO0000O0OOO0OO ):#line:472
        O0O0000OO0O0O0O0O =O0O0O0OOO00OOO0OO .schema .fields #line:473
        for O0OOOO0O0OOO0OO0O in O0O0000OO0O0O0O0O :#line:474
            O0O0O0OOO00OOO0OO =O0O0O0OOO00OOO0OO .withColumnRenamed (O0OOOO0O0OOO0OO0O .name ,O0OOO0000O0OOO0OO +'_'+O0OOOO0O0OOO0OO0O .name )#line:475
        return O0O0O0OOO00OOO0OO #line:476
    O00OO0OO00OO0OO00 =O0O00OOOO000OOO0O .read .format ("com.databricks.spark.xml").options (samplingRatio =float (sampling_ratio )).option ("rowTag",O00OO0O0O00O0O0O0 ).option ("nullValue","").option ('mergeSchema','true').load (OOOOO0O000OO0OOO0 )#line:481
    O00OO0OO00OO0OO00 =_O0OOO00O00O0OO00O (O00OO0OO00OO0OO00 ,O00OO0O0O00O0O0O0 )#line:483
    if O00OO0O0O00O0O0O0 !=O0000OOOOOOO0000O :#line:485
        O00OO0OO00OO0OO00 =_O0OOO00O00O0OO00O (O00OO0OO00OO0OO00 ,O0000OOOOOOO0000O )#line:486
    O00OO0OO00OO0OO00 =_OOOO00O00O0OOOOOO (O00OO0OO00OO0OO00 )#line:489
    return O00OO0OO00OO0OO00 .toDF (*(O0O0O0O0O0O00OO0O .lower ().replace ('\t','_').replace ("/","_").replace ("-","_").replace ("(","_").replace (")","_").replace ("__","_").replace ("$","_").replace (".","_").replace ('&','_').replace (":","").replace ("@","").strip ()for O0O0O0O0O0O00OO0O in O00OO0OO00OO0OO00 .columns ))#line:495
@logdebug #line:501
def readEBCIDICFilesFromFolder_fn (O00000O0O00O0O0OO ,O0OOO0O00O0O0O000 ,O0O0O0O0O0O00000O ):#line:502
  ""#line:505
  def _OO00OOO00000OO00O (OO00O0O0000OOOOOO ,OO000O0O00000OO0O ,OOO0O0000O0O0000O ):#line:506
        try :#line:507
            OOOOOO00OOO00OOO0 =OO00O0O0000OOOOOO .read .format ("cobol").option ("copybook",OO000O0O00000OO0O ).option ("debug_ignore_file_size","true").option ("is_record_sequence","true").load (O0O0O0O0O0O00000O )#line:508
            return OOOOOO00OOO00OOO0 #line:509
        except :#line:511
            traceback .print_exc ()#line:512
            raise #line:513
  def _OOOOO0O0O000OOOOO (O0OOO0000OOOO0O00 ,O0O0OO000O00OO0O0 ):#line:516
      try :#line:517
          OOOOO000O0OOOO00O =SQLContext (O0OOO0000OOOO0O00 )#line:518
          OOOO0OOOO00OOOO0O =DataFrame (O0OOO0000OOOO0O00 ._jvm .za .co .absa .cobrix .spark .cobol .utils .SparkUtils .flattenSchema (O0O0OO000O00OO0O0 ._jdf ,True ),OOOOO000O0OOOO00O )#line:519
          return OOOO0OOOO00OOOO0O #line:520
      except :#line:522
          traceback .print_exc ()#line:523
          raise #line:524
  OOOO0O0OOOOO0O00O =_OO00OOO00000OO00O (O00000O0O00O0O0OO ,O0OOO0O00O0O0O000 ,O0O0O0O0O0O00000O )#line:527
  return _OOOOO0O0O000OOOOO (O00000O0O00O0O0OO ,OOOO0O0OOOOO0O00O )#line:529
@logdebug #line:534
def readFixedWidthFilesWithPartitionAndSchema_fn (OO00OO0O000000000 ,OO0O0OOOOOO0O0000 ,partition_list =None ,schema =None ,schema_parsing_details =None ,schema_parsing_delimiter =None ,seperator =",",special_row_filter =[],distinct =False ):#line:535
  ""#line:539
  OO0O00O00000OO0OO =OO00OO0O000000000 .sparkContext .binaryFiles (OO0O0OOOOOO0O0000 )#line:543
  def O00OOOOO00000OO00 (O0O00O0O0OO0O000O ):#line:544
    return O0O00O0O0OO0O000O [1 ].decode ("utf-8")#line:545
  OO0O00O00000OO0OO =OO0O00O00000OO0OO .map (lambda OO0OO0000OOOO0OOO :O00OOOOO00000OO00 (OO0OO0000OOOO0OOO ))#line:548
  OO0O00O00000OO0OO =OO00OO0O000000000 .createDataFrame (OO0O00O00000OO0OO ,StringType ()).toDF ("content").select (F .split (F .col ("content"),seperator ).alias ("content")).select (F .explode_outer ("content").alias ("content"))#line:549
  for O000000O0OOO00000 in special_row_filter :#line:551
    OO0O00O00000OO0OO =OO0O00O00000OO0OO .filter (~F .col ("content").contains (F .lit (O000000O0OOO00000 )))#line:552
  OO00000OOOO0O0O00 =[F .substring (F .col ("content"),int (OOO0O0OOO00O0O00O .split ("-")[0 ]),int (OOO0O0OOO00O0O00O .split ("-")[1 ])-int (OOO0O0OOO00O0O00O .split ("-")[0 ]))for OOO0O0OOO00O0O00O in schema_parsing_details .split (schema_parsing_delimiter )]#line:555
  OO0O00O00000OO0OO =OO0O00O00000OO0OO .select (*OO00000OOOO0O0O00 )#line:557
  OO00000OOOO0O0O00 =[F .col (OOO000000O0OOOOOO ).cast (OOO000O0O00O0OO0O .get ('type')).alias (OOO000O0O00O0OO0O .get ('name'))for OOO000000O0OOOOOO ,OOO000O0O00O0OO0O in zip (OO0O00O00000OO0OO .columns ,schema )]#line:559
  return OO0O00O00000OO0OO .select (*OO00000OOOO0O0O00 )#line:561
@logdebug #line:566
def readMultiDelimitedTextFile_fn (*,spark ,basepath ,schema =None ,validate_schema_flag =False ,row_delimiter =None ,header =False ):#line:567
  O0000O00OOO00OOO0 =spark .read .format ("text").load (basepath )#line:568
  if header ==True :#line:570
    OOOO000OOOOO0OO00 =O0000O00OOO00OOO0 .first ()[0 ]#line:571
    OO0OO000O0O0O0O0O =OOOO000OOOOO0OO00 .split (row_delimiter )#line:572
    O0000O00OOO00OOO0 =O0000O00OOO00OOO0 .filter (F .col ('value')!=OOOO000OOOOO0OO00 ).rdd .map (lambda OOO0OOO0OOO00OOO0 :OOO0OOO0OOO00OOO0 [0 ].split (row_delimiter )).toDF (OO0OO000O0O0O0O0O )#line:573
  else :#line:575
    OO0OO000O0O0O0O0O =[OOOO00000OOOO0OOO .get ("name")for OOOO00000OOOO0OOO in schema ]#line:576
    O0000O00OOO00OOO0 =O0000O00OOO00OOO0 .rdd .map (lambda OO0OOOOOOO0O0OO0O :OO0OOOOOOO0O0OO0O [0 ].split (row_delimiter )).toDF (OO0OO000O0O0O0O0O )#line:577
  return O0000O00OOO00OOO0 #line:579
@logdebug #line:584
def readDB2JDBCTable_fn (O000OOO0OO0OOOOO0 ,O0O0O00OO0O0O0O00 ,OOO0O0000OOO0OOO0 ,OO0O000OOOO0OOO00 ,OOO0O0O000OO0O0O0 ,OO0O00OO000O00O0O ,OOOOOOO00OOOO0000 ,OOOO0OO0000000OOO ,port =5432 ,numOfPartitions =10 ):#line:585
    ""#line:605
    def OO00OO0O00000OO00 ():#line:607
        ""#line:609
        OO0OO00O0O0OOOO00 =datetime .utcnow ().replace (hour =0 ,minute =0 ,second =0 )#line:611
        O00OOO0O0OOO0OOOO =OO0OO00O0O0OOOO00 +relativedelta (days =-1 )#line:612
        OO00OO00O0O0000O0 =OO0OO00O0O0OOOO00 #line:613
        O00OOO0O0OOO0OOOO =O00OOO0O0OOO0OOOO .strftime ('%Y-%m-%d')#line:615
        OO00OO00O0O0000O0 =OO00OO00O0O0000O0 .strftime ('%Y-%m-%d %H:%M:%S')#line:616
        return (O00OOO0O0OOO0OOOO ,OO00OO00O0O0000O0 )#line:618
    OOO00O0OO0000000O ='jdbc:db2://{serverInstanceName}:{port}/{sqlDatabaseName}'.format (serverInstanceName =O0O0O00OO0O0O0O00 ,port =port ,sqlDatabaseName =OOO0O0000OOO0OOO0 )#line:621
    if OO0O000OOOO0OOO00 !='NA':#line:628
        O00O0O00O00OO0OOO =O000OOO0OO0OOOOO0 .read .format ("jdbc").option ("url",OOO00O0OO0000000O ).option ("driver",'com.ibm.db2.jcc.DB2Driver').option ("numPartitions",numOfPartitions ).option ("dbtable",OO0O000OOOO0OOO00 ).option ("user",OO0O00OO000O00O0O ).option ("password",OOOOOOO00OOOO0000 ).load ()#line:636
    else :#line:638
        OOO0O0O000OO0O0O0 =OOO0O0O000OO0O0O0 .replace ("{{RUN_DATE}}",OOOO0OO0000000OOO )#line:639
        O00O0O00O00OO0OOO =O000OOO0OO0OOOOO0 .read .format ("jdbc").option ("url",OOO00O0OO0000000O ).option ("driver",'com.ibm.db2.jcc.DB2Driver').option ("numPartitions",numOfPartitions ).option ("query",OOO0O0O000OO0O0O0 ).option ("user",OO0O00OO000O00O0O ).option ("password",OOOOOOO00OOOO0000 ).load ()#line:647
    return O00O0O00O00OO0OOO #line:650
@logdebug #line:655
def readPOSTGRESJDBCTable_fn (OOOO00000OOO000O0 ,O0O0OO00000OOO00O ,OO00O0000OOOOOOO0 ,OO00OOO00O0O00000 ,OOO0O0OO0000OOO00 ,O0OO000000OO00000 ,O00OO0OO0000OOO0O ,O00O00OOOO0O0000O ,port =5432 ,numOfPartitions =10 ):#line:657
    OOO00OOO00OO0OO0O ='jdbc:postgresql://{serverInstanceName}:{port}/{sqlDatabaseName}'.format (serverInstanceName =O0O0OO00000OOO00O ,port =port ,sqlDatabaseName =OO00O0000OOOOOOO0 )#line:659
    if OO00OOO00O0O00000 not in [None ,'NA','TBD','']:#line:661
        print ("Execute Table")#line:662
        O000OOOOOO000OO0O =OOOO00000OOO000O0 .read .format ("jdbc").option ("url",OOO00OOO00OO0OO0O ).option ("driver",'org.postgresql.Driver').option ("numPartitions",numOfPartitions ).option ("dbtable",OO00OOO00O0O00000 ).option ("user",O0OO000000OO00000 ).option ("password",O00OO0OO0000OOO0O ).load ()#line:670
    else :#line:672
        OOO0O0OO0000OOO00 =OOO0O0OO0000OOO00 .replace ("{{RUN_DATE}}",O00O00OOOO0O0000O )#line:673
        print ("Execute Query",f"({OOO0O0OO0000OOO00}) tmp")#line:674
        O000OOOOOO000OO0O =OOOO00000OOO000O0 .read .format ("jdbc").option ("url",OOO00OOO00OO0OO0O ).option ("driver",'org.postgresql.Driver').option ("numPartitions",numOfPartitions ).option ("dbtable",f"({OOO0O0OO0000OOO00}) tmp").option ("user",O0OO000000OO00000 ).option ("password",O00OO0OO0000OOO0O ).load ()#line:682
    return O000OOOOOO000OO0O #line:685
@logdebug #line:690
def readMongoDB_fn (OOOOOO0OO00OOOO0O ,O0O0O000O0O0O00O0 ,OO0OO0OOO000OOO0O ,O0OO0OO0OOOO0O0O0 ,OOOOOO000O00O00O0 ,OO0000OOOOOO00O00 ,OOO00OO0OO00O0O00 ,OO0O00O000O0OO00O ,O0O0OOOO000O00000 ,number_of_partitions =10 ):#line:691
  if OO0000OOOOOO00O00 !='NA':#line:692
      O0000OOO0O0OO0OOO =OOOOOO0OO00OOOO0O .read .format ("com.mongodb.spark.sql.DefaultSource").option ("database",OOOOOO000O00O00O0 ).option ("collection",OO0000OOOOOO00O00 ).load ()#line:693
  else :#line:696
    O00O000OOOOO0OO00 =O0O0OOOO000O00000 .split ('WHERE')[0 ]#line:698
    O00O000OOOOO0OO00 =O00O000OOOOO0OO00 .split ("FROM")[1 ]#line:699
    O00O000OOOOO0OO00 =O00O000OOOOO0OO00 .strip (' ')#line:700
    O0000OOO0O0OO0OOO =OOOOOO0OO00OOOO0O .read .format ("com.mongodb.spark.sql.DefaultSource").option ("database",OOOOOO000O00O00O0 ).option ("collection",O00O000OOOOO0OO00 ).load ()#line:703
    O0000OOO0O0OO0OOO .createOrReplaceTempView (f"{O00O000OOOOO0OO00}")#line:704
    O0000OOO0O0OO0OOO =OOOOOO0OO00OOOO0O .sql (O0O0OOOO000O00000 .replace ('{{RUN_DATE}}',OO0O00O000O0OO00O ))#line:705
  return O0000OOO0O0OO0OOO #line:710
@logdebug #line:715
def readMSSQLJDBCTable_fn (OOOO0OOO0OOOOO0O0 ,O00000OO0OOOO000O ,OO0OO0000O0000O00 ,OO0000OO00000000O ,OO0OO00000OOOOOO0 ,O0000OOO0OO0OO00O ,OO00O00000O00O0OO ,O0O00O000OO0OOO0O ,O00OO000O0OO0OO00 ,port =1433 ,numOfPartitions =10 ):#line:716
    O0OO0OOOOO00O000O =f'jdbc:sqlserver://{O00000OO0OOOO000O}:{port};databaseName={OO0OO0000O0000O00}'#line:717
    OOOOOO0OOO0000OO0 ='com.microsoft.sqlserver.jdbc.SQLServerDriver'#line:724
    if OO0000OO00000000O !='NA':#line:725
        OOO0O000OOO00O0OO =OOOO0OOO0OOOOO0O0 .read .format ("jdbc").option ("url",O0OO0OOOOO00O000O ).option ("driver",OOOOOO0OOO0000OO0 ).option ("numPartitions",numOfPartitions ).option ("dbtable",OO0000OO00000000O ).option ("user",OO00O00000O00O0OO ).option ("password",O00OO000O0OO0OO00 ).load ()#line:733
    else :#line:735
        OO0OO00000OOOOOO0 =OO0OO00000OOOOOO0 .replace ("{{RUN_DATE}}",O0O00O000OO0OOO0O )#line:736
        OOO0O000OOO00O0OO =OOOO0OOO0OOOOO0O0 .read .format ("jdbc").option ("url",O0OO0OOOOO00O000O ).option ("dbtable",f"({OO0OO00000OOOOOO0}) tmp").option ("user",OO00O00000O00O0OO ).option ("password",O00OO000O0OO0OO00 ).option ("driver",OOOOOO0OOO0000OO0 ).load ()#line:743
    return OOO0O000OOO00O0OO #line:746
@logdebug #line:752
def castDataframe2Schema_fn (O0OOOO0O000O00OOO ,O00O0OO0OO0OO0O00 ,OOO0OO00OOOOO00O0 ):#line:753
  ""#line:756
  try :#line:757
    for O0O0OO00OOO0O0O0O in OOO0OO00OOOOO00O0 :#line:758
      OO0O0O0O0000OO0OO =O0O0OO00OOO0O0O0O .get ("type")#line:759
      if OO0O0O0O0000OO0OO in ['time','timestamp']:#line:760
        OOO000000O000000O =O0O0OO00OOO0O0O0O .get ("metadata").get ("format")#line:761
        O00O0OO0OO0OO0O00 =O00O0OO0OO0OO0O00 .withColumn (O0O0OO00OOO0O0O0O .get ("name"),F .to_timestamp (F .col (O0O0OO00OOO0O0O0O .get ("name")).cast ('string'),OOO000000O000000O ))#line:762
      elif OO0O0O0O0000OO0OO in ['date']:#line:764
        OOO000000O000000O =O0O0OO00OOO0O0O0O .get ("metadata").get ("format")#line:765
        O00O0OO0OO0OO0O00 =O00O0OO0OO0OO0O00 .withColumn (O0O0OO00OOO0O0O0O .get ("name"),F .to_date (F .col (O0O0OO00OOO0O0O0O .get ("name")).cast ('string'),OOO000000O000000O ))#line:766
      else :#line:768
        OO0O0O0O0000OO0OO =OO0O0O0O0000OO0OO if _data_type_mapping .get (OO0O0O0O0000OO0OO )==None else _data_type_mapping .get (OO0O0O0O0000OO0OO )#line:769
        O00O0OO0OO0OO0O00 =O00O0OO0OO0OO0O00 .withColumn (O0O0OO00OOO0O0O0O .get ("name"),F .col (O0O0OO00OOO0O0O0O .get ("name")).cast (OO0O0O0O0000OO0OO ))#line:770
    return O00O0OO0OO0OO0O00 #line:773
  finally :#line:775
    O00O0OO0OO0OO0O00 =None #line:776
@logdebug #line:782
def readSAPHanaJDBCTable_fn (OOO0OOOOO0O0O0OO0 ,O0O0OO0OOO0OOO0O0 ,O0O000OO0OOO0OO00 ,OO000OOO0O0OOOO0O ,OOOOOOOOO0OO0000O ,O0OOOOO0OO00O0O00 ,OO0O000O00O000OOO ,OOOOOOO000000O000 ,OOO0O00000OO00OO0 ,port =38315 ,numOfPartitions =10 ):#line:784
    ""#line:788
    O0OOOO0OOOO0O0OOO =f'jdbc:sap://{O0O0OO0OOO0OOO0O0}:{port}/?databaseName={O0O000OO0OOO0OO00}&useSSL=false'#line:791
    OOOOOOOOO0OO0000O =f"{OOOOOOOOO0OO0000O} {O0OOOOO0OO00O0O00}"#line:793
    if OO000OOO0O0OOOO0O !='NA':#line:795
        O0OO00O0O0OOOOO00 =OOO0OOOOO0O0O0OO0 .read .format ("jdbc").option ("driver","com.sap.db.jdbc.Driver").option ("url",O0OOOO0OOOO0O0OOO ).option ("numPartitions",numOfPartitions ).option ("dbtable",OO000OOO0O0OOOO0O ).option ("user",OO0O000O00O000OOO ).option ("password",OOOOOOO000000O000 ).load ()#line:803
    else :#line:805
        OOOOOOOOO0OO0000O =OOOOOOOOO0OO0000O .replace ("{{RUN_DATE}}",OOO0O00000OO00OO0 )#line:806
        O0OO00O0O0OOOOO00 =OOO0OOOOO0O0O0OO0 .read .format ("jdbc").option ("driver","com.sap.db.jdbc.Driver").option ("url",O0OOOO0OOOO0O0OOO ).option ("numPartitions",numOfPartitions ).option ("query",OOOOOOOOO0OO0000O ).option ("user",OO0O000O00O000OOO ).option ("password",OOOOOOO000000O000 ).load ()#line:814
    return O0OO00O0O0OOOOO00 #line:817
@logdebug #line:2131
def generateNewColumnBasedOnCaseExpression_fn (OOO000O0OOOO0O0O0 ,OO000O0O0OOO0O0OO ):#line:2132
    ""#line:2142
    try :#line:2143
      OO000O0OOOO000O0O =OOO000O0OOOO0O0O0 .columns #line:2144
      for O0O0OO0000O0000O0 ,OOOO000O0O0O0000O in OO000O0O0OOO0O0OO .items ():#line:2145
          OOO000O0OOOO0O0O0 =OOO000O0OOOO0O0O0 .select (*filter_column_names (OO000O0OOOO000O0O ,O0O0OO0000O0000O0 ),F .expr (OOOO000O0O0O0000O ).alias (O0O0OO0000O0000O0 ))#line:2147
      return OOO000O0OOOO0O0O0 #line:2149
    finally :#line:2151
      OOO000O0OOOO0O0O0 =None #line:2152
@logdebug #line:2158
def renameColumnName_fn (OO00O000OOOOOOOOO ,OOOO00000O00O0O0O ):#line:2159
  ""#line:2161
  try :#line:2162
    for O0OO00OO0O0000OO0 ,O000O0O00O000O000 in OOOO00000O00O0O0O .items ():#line:2163
      OO00O000OOOOOOOOO =OO00O000OOOOOOOOO .withColumnRenamed (O0OO00OO0O0000OO0 ,O000O0O00O000O000 )#line:2164
    return OO00O000OOOOOOOOO #line:2167
  finally :#line:2169
    OO00O000OOOOOOOOO =None #line:2170
@logdebug #line:2176
def filterDataFrame_fn (OOOO0OOO00OOOOOOO ,O0O0O0O00000000O0 ):#line:2177
    ""#line:2179
    try :#line:2180
      for OO0O0OOO0OOOOOOO0 in O0O0O0O00000000O0 :#line:2181
          OOOO0OOO00OOOOOOO =OOOO0OOO00OOOOOOO .filter (OO0O0OOO0OOOOOOO0 )#line:2182
      return OOOO0OOO00OOOOOOO #line:2184
    finally :#line:2186
      OOOO0OOO00OOOOOOO =None #line:2187
@logdebug #line:2191
def rangeRowsFilterDataFrame (OOOOO00O0O0000O00 ,O00O000O0O00O0OO0 ,OO00O0OOO00O0000O ,OOOO000OO00OOO0O0 ,O0O0O0O0000O0O0O0 ):#line:2192
  ""#line:2197
  try :#line:2198
    O00O0000OO0OO00OO =Window ().partitionBy (O00O000O0O00O0OO0 ).orderBy (OO00O0OOO00O0000O )#line:2199
    OOOOO00O0O0000O00 =OOOOO00O0O0000O00 .withColumn ("idf_index",F .row_number ().over (O00O0000OO0OO00OO ))#line:2200
    return OOOOO00O0O0000O00 .filter (F .col ('idf_index'),F .between (*O0O0O0O0000O0O0O0 ))#line:2202
  finally :#line:2204
    OOOOO00O0O0000O00 =None #line:2205
@logdebug #line:2211
def generateUniqueIdPerRow_fn (O0O0OO0OO0000O0O0 ,OOOOO0O000O00O00O ):#line:2212
    ""#line:2214
    try :#line:2215
      O0O00O0OO00000OO0 =O0O0OO0OO0000O0O0 .columns #line:2216
      return O0O0OO0OO0000O0O0 .withColumn (OOOOO0O000O00O00O ,F .udf (lambda O000O0O000OOO00O0 :str (uuid .uuid4 ()),StringType ())(O0O00O0OO00000OO0 [0 ]))#line:2217
    finally :#line:2219
      O0O0OO0OO0000O0O0 =None #line:2220
@logdebug #line:2224
def dropEmptyRows_fn (OOO0OOOOO0OO000O0 ):#line:2225
  try :#line:2226
    return OOO0OOOOO0OO000O0 .na .drop (how ="all")#line:2227
  finally :#line:2229
    OOO0OOOOO0OO000O0 =None #line:2230
@logdebug #line:2234
def generateNewColumnBasedOnConstants_fn (O0OOOO0O0OO0O000O ,OO0000000000O0000 ):#line:2235
  try :#line:2236
    for OO0OOOOO00O0O000O ,OO00OOO0000O0OOOO in OO0000000000O0000 .items ():#line:2237
        O0000O00OO00O0000 =O0OOOO0O0OO0O000O .columns #line:2238
        O0OOOO0O0OO0O000O =O0OOOO0O0OO0O000O .select (*filter_column_names (O0000O00OO00O0000 ,OO0OOOOO00O0O000O ),F .lit (OO00OOO0000O0OOOO ).alias (OO0OOOOO00O0O000O ))#line:2239
    return O0OOOO0O0OO0O000O #line:2241
  finally :#line:2243
    O0OOOO0O0OO0O000O =None #line:2244
@logdebug #line:2250
def generateNewColumnBasedOnLead_fn (OO0O00O0OOOO00O0O ,O0OO0O0OO00O0OO00 ,O0OO0OOO0O00O000O ,O0000000O0O0OOOO0 ,OO0OO000OO00O00O0 ,OOO00000000O00OO0 ):#line:2251
  ""#line:2254
  try :#line:2255
    if O0OO0OOO0O00O000O ==None or O0OO0OOO0O00O000O .upper ()=='NA':#line:2256
      OOOO000O0OOO0OO00 =Window .partitionBy (*O0OO0O0OO00O0OO00 .split (','))#line:2257
    else :#line:2259
      OOOO000O0OOO0OO00 =Window .partitionBy (*O0OO0O0OO00O0OO00 .split (',')).orderBy (*O0OO0OOO0O00O000O )#line:2260
    OO0O00O0OOOO00O0O =OO0O00O0OOOO00O0O .repartition (*O0OO0O0OO00O0OO00 .split (','))#line:2263
    return OO0O00O0OOOO00O0O .select (*filter_column_names (OOO00000000O00OO0 ,OO0OO000OO00O00O0 ),F .lead (O0000000O0O0OOOO0 ).over (OOOO000O0OOO0OO00 ).alias (OO0OO000OO00O00O0 ))#line:2264
  finally :#line:2266
    OO0O00O0OOOO00O0O =None #line:2267
@logdebug #line:2271
def generateNewColumnBasedOnLag_fn (O00000OOOOO0OO0O0 ,O0O00O00O00OOO000 ,OO0OOO0OO0OOOOO0O ,O0OOO0O0O000OOO0O ,OOO00OO0000OO00O0 ,O00000OOOO0OO0OO0 ):#line:2272
  ""#line:2274
  try :#line:2275
    if OO0OOO0OO0OOOOO0O ==None or OO0OOO0OO0OOOOO0O .upper ()=='NA':#line:2276
      O00O0000O0O00O00O =Window .partitionBy (*O0O00O00O00OOO000 .split (','))#line:2277
    else :#line:2279
      O00O0000O0O00O00O =Window .partitionBy (*O0O00O00O00OOO000 .split (',')).orderBy (*OO0OOO0OO0OOOOO0O )#line:2280
    O00000OOOOO0OO0O0 =O00000OOOOO0OO0O0 .repartition (*O0O00O00O00OOO000 .split (','))#line:2283
    return O00000OOOOO0OO0O0 .select (*filter_column_names (O00000OOOO0OO0OO0 ,OOO00OO0000OO00O0 ),F .lag (O0OOO0O0O000OOO0O ).over (O00O0000O0O00O00O ).alias (OOO00OO0000OO00O0 ))#line:2284
  finally :#line:2286
    O00000OOOOO0OO0O0 =None #line:2287
@logdebug #line:2294
def extractAndGenerateSparkStructuredMetadata_fn2 (OOOOOO0O000O0OO0O ,OOOO00OO00O0OOO00 ,OOO00000OOO00O0O0 ,OO0OO0O0000O0O0O0 ,O0OO0OO00000OOO0O ,request_type ='structure',sampling_ratio =.5 ):#line:2295
  ""#line:2298
  try :#line:2299
    import textdistance #line:2300
    O00000000OO0O000O =lambda O0OOO0O00O0O00O00 ,OOOOOOOOOO0OOO00O :F .sum (F .when (O0OOO0O00O0O00O00 ,1 ).otherwise (0 )).alias ('bound_count_{}'.format (OOOOOOOOOO0OOO00O ))#line:2302
    _O00OOO0O00O0OO0OO ={}#line:2304
    _O00OOO0O00O0OO0OO ['applicationid']=str (OOOOOO0O000O0OO0O .sparkContext .applicationId )#line:2305
    if O0OO0OO00000OOO0O >1000 :#line:2306
      sampling_ratio =float (1000 /O0OO0OO00000OOO0O )#line:2307
    O0OO000O0O00000O0 =OOOO00OO00O0OOO00 .sample (float (sampling_ratio )).cache ()#line:2309
    O000OO00000000OO0 =O0OO000O0O00000O0 .count ()#line:2312
    O0OO0O000000OO000 ={}#line:2314
    OO000O0OO000O0000 =[OO0O0OO00O00O0OOO [0 ]for OO0O0OO00O00O0OOO in list (filter (lambda O0O0O00OO000OO0O0 :O0O0O00OO000OO0O0 [1 ]in ['double','int','decimal','decimal(38,9)','float','long','short','bigint'],O0OO000O0O00000O0 .dtypes ))]#line:2315
    OO000OO00OO0O000O =[O00O00OOO0OOOO00O [0 ]for O00O00OOO0OOOO00O in list (filter (lambda O0OO00O0O000O00OO :O0OO00O0O000O00OO [1 ]in ['string'],O0OO000O0O00000O0 .dtypes ))]#line:2316
    OO0000O00OOO0O0OO =[OO000O00O000000OO [0 ]for OO000O00O000000OO in list (filter (lambda OO00O00OOO0O00O0O :OO00O00OOO0O00O0O [1 ]in ['date','timestamp'],O0OO000O0O00000O0 .dtypes ))]#line:2317
    _O00OOO0O00O0OO0OO ['numerical_columns']=OO000O0OO000O0000 #line:2319
    _O00OOO0O00O0OO0OO ['categorical_columns']=OO000OO00OO0O000O #line:2320
    _O00OOO0O00O0OO0OO ['datetime_columns']=OO0000O00OOO0O0OO #line:2321
    _O00OOO0O00O0OO0OO ['totalrowcount']=O0OO0OO00000OOO0O #line:2325
    _O00OOO0O00O0OO0OO ['schema_type']={O0OOOOOO00OO0O0OO [0 ]:O0OOOOOO00OO0O0OO [1 ]for O0OOOOOO00OO0O0OO in O0OO000O0O00000O0 .dtypes }#line:2327
    _O00OOO0O00O0OO0OO ['user']=OOOOOO0O000O0OO0O .sparkContext .sparkUser ()#line:2328
    if request_type .lower ()=="basic":#line:2331
      return _O00OOO0O00O0OO0OO #line:2332
    else :#line:2335
      O0OO000O0O00000O0 =O0OO000O0O00000O0 .fillna (0 ,subset =OO000O0OO000O0000 )#line:2336
      _O00OOO0O00O0OO0OO ['count_null_columns']=OOOO00OO00O0OOO00 .select ([F .count (F .when (F .isnull (OOO00OO0O00000O0O ),OOO00OO0O00000O0O )).alias (OOO00OO0O00000O0O )for OOO00OO0O00000O0O in OOOO00OO00O0OOO00 .columns ]).collect ()[0 ].asDict ()#line:2337
      O000O0OO0000O0OOO ={}#line:2339
      OOOO000OOOOO00O00 =[]#line:2340
      for O00O0OOO0OOO00OO0 in OOOO00OO00O0OOO00 .columns :#line:2342
        O0000OO0O0OOO0O00 ={}#line:2343
        OO0O00O00OOO0OOO0 =OOOO00OO00O0OOO00 .select (O00O0OOO0OOO00OO0 ).distinct ().count ()#line:2344
        O0O000000O0OOO00O =OOOO00OO00O0OOO00 .filter ((OOOO00OO00O0OOO00 [O00O0OOO0OOO00OO0 ]=="")|(OOOO00OO00O0OOO00 [O00O0OOO0OOO00OO0 ]==" ")|(OOOO00OO00O0OOO00 [O00O0OOO0OOO00OO0 ]==None )|(OOOO00OO00O0OOO00 [O00O0OOO0OOO00OO0 ]=='NA')).count ()#line:2345
        if O00O0OOO0OOO00OO0 in OO000O0OO000O0000 :#line:2347
          OO00OO00OOOO0OOO0 =O0OO000O0O00000O0 .select (O00O0OOO0OOO00OO0 ).describe ().collect ()#line:2348
          for OO00OO0OO0O000000 in OO00OO00OOOO0OOO0 :#line:2349
            if OO00OO0OO0O000000 ['summary']in ["stddev","mean","max","min"]:#line:2351
                pass #line:2352
            elif OO00OO0OO0O000000 ['summary']=="count":#line:2353
                O0000OO0O0OOO0O00 [OO00OO0OO0O000000 ['summary']]=int (OO00OO0OO0O000000 [O00O0OOO0OOO00OO0 ])#line:2354
            else :#line:2355
                O0000OO0O0OOO0O00 [OO00OO0OO0O000000 ['summary']]=OO00OO0OO0O000000 [O00O0OOO0OOO00OO0 ]#line:2356
          O0000OO0O0OOO0O00 ['sample_count']=O0000OO0O0OOO0O00 .pop ('count')#line:2360
          O0OOO00OOO00O0000 =O0OO000O0O00000O0 .select (F .mean (F .col (O00O0OOO0OOO00OO0 )).alias ('mean'),F .stddev (F .col (O00O0OOO0OOO00OO0 )).alias ('std')).collect ()#line:2362
          O0000OO0O0OOO0O00 ['sample_mean']=round (O0OOO00OOO00O0000 [0 ]['mean'],2 )#line:2363
          O0000OO0O0OOO0O00 ['sample_std']=round (O0OOO00OOO00O0000 [0 ]['std'],2 )#line:2364
          O0000OO0O0OOO0O00 ['count_nan_columns']=list (OOOO00OO00O0OOO00 .select (F .count (F .when (F .isnan (O00O0OOO0OOO00OO0 ),O00O0OOO0OOO00OO0 ))).collect ()[0 ].asDict ().values ())[0 ]#line:2366
          OO000OO000000OO00 =O0OO000O0O00000O0 .agg (F .max (F .col (O00O0OOO0OOO00OO0 )),F .min (F .col (O00O0OOO0OOO00OO0 ))).collect ()[0 ]#line:2367
          O0000OO0O0OOO0O00 ['sample_max']=round (OO000OO000000OO00 [0 ],2 )#line:2368
          O0000OO0O0OOO0O00 ['sample_min']=round (OO000OO000000OO00 [1 ],2 )#line:2369
        """
        elif colName in string_column_list:
          if uniqueCount < .1 * dataframe_count:
            tmp['sample_distinct_groups'] = {item[0]:item[1] for item in metadata_df.groupby(F.col(colName)).count().orderBy(F.desc("count"), F.desc(colName)).alias(colName).collect()[:10]}
          #if
        #if
        """#line:2378
        O0000OO0O0OOO0O00 ['null_count']=_O00OOO0O00O0OO0OO ['count_null_columns'][O00O0OOO0OOO00OO0 ]#line:2381
        O0000OO0O0OOO0O00 ['distinct_count']=OO0O00O00OOO0OOO0 #line:2382
        O0000OO0O0OOO0O00 ['empty_count']=O0O000000O0OOO00O #line:2383
        if OO0O00O00OOO0OOO0 /O0OO0OO00000OOO0O <.25 :#line:2386
          O0000OO0O0OOO0O00 ['sample_distribution']=O0OO000O0O00000O0 .select (O00O0OOO0OOO00OO0 ).groupby (O00O0OOO0OOO00OO0 ).count ().orderBy (F .desc ("count"),F .desc (O00O0OOO0OOO00OO0 )).withColumn ("frequency",F .round (((F .col ("count")/O000OO00000000OO0 )*100 ).cast ("float"),2 )).toJSON ().map (lambda OOOOOOOO0O0OO0O0O :json .loads (OOOOOOOO0O0OO0O0O )).collect ()[:10 ]#line:2387
          """
          frequency_percent_distribution = {}
          for col_item in metadata_df.select(colName).groupby(colName).count().orderBy(F.desc("count"), F.desc(colName)).toJSON().collect()[:10]:
            local_dict = json.loads(col_item)
            frequency_percent_distribution[local_dict.get(colName)] = round(float((local_dict.get('count')/metadata_df_count) * 100), 2)
          #for
          tmp['sample_frequency_percent_distribution'] = frequency_percent_distribution
          """#line:2396
        O000O0OO0000O0OOO [O00O0OOO0OOO00OO0 ]=O0000OO0O0OOO0O00 #line:2416
      OO0O00O00OOO0OOO0 =None #line:2419
      O0O000000O0OOO00O =None #line:2420
      OO00OO00OOOO0OOO0 =None #line:2421
      O0OOO00OOO00O0000 =None #line:2422
      OO000OO000000OO00 =None #line:2423
      O0000OO0O0OOO0O00 =None #line:2424
      _O00OOO0O00O0OO0OO ['column_statistics']=O000O0OO0000O0OOO #line:2426
      O0O00OO0OOO00O000 =OOOOOO0O000O0OO0O .sparkContext .broadcast (OOO00000OOO00O0O0 )#line:2436
      def _OO0O0OOOOOO00OOOO (OO000OOOO000O0O0O ):#line:2437
        OOO0O0O0O0OO000OO =None #line:2438
        try :#line:2439
          if OO000OOOO000O0O0O is None or str (OO000OOOO000O0O0O )=='nan':#line:2440
              return 'BLANK'#line:2441
          if OO000OOOO000O0O0O ==''or OO000OOOO000O0O0O =='null':#line:2443
              return 'BLANK'#line:2444
          OO00O0O0OO0OO0O0O =O0O00OO0OOO00O000 .value #line:2446
          for OOOO0000O00OO0O00 ,O0O0000OO00OO0O00 in OO00O0O0OO0OO0O0O .items ():#line:2447
            OOO0O0O0O0OO000OO =OOOO0000O00OO0O00 #line:2448
            O000OOOOO0OO00OO0 =O0O0000OO00OO0O00 .match (str (OO000OOOO000O0O0O ).strip ())#line:2449
            if O000OOOOO0OO00OO0 is not None :#line:2450
                return OOOO0000O00OO0O00 #line:2451
          return 'NA'#line:2453
        except :#line:2455
          return "ERROR in REGEX "+str (OOO0O0O0O0OO000OO )#line:2456
      O0O0O00O0OO0O0OOO =F .udf (_OO0O0OOOOOO00OOOO ,StringType ())#line:2459
      O00O00000000O0OOO =[]#line:2461
      O00OO0OO0OOOOO00O ={}#line:2462
      O0O0O0O00OOOO0OO0 =O0OO000O0O00000O0 .limit (5 )#line:2463
      O0O0O0OOOO0OO00O0 =0 #line:2464
      for O000O000OO0000O00 in OO000OO00OO0O000O :#line:2465
        O0O0O0O00OOOO0OO0 =O0O0O0O00OOOO0OO0 .withColumn (O000O000OO0000O00 +"_str",F .col (O000O000OO0000O00 ))#line:2466
        O0O0O0OOOO0OO00O0 =O0O0O0OOOO0OO00O0 +1 #line:2467
        O0OOO00O00000OOOO =O0O0O0O00OOOO0OO0 .where (F .col (O000O000OO0000O00 +'_str').isNotNull ()).withColumn (O000O000OO0000O00 +"_str",O0O0O00O0OO0O0OOO (F .col (O000O000OO0000O00 +"_str"))).select (F .col (O000O000OO0000O00 +"_str")).where (F .col (O000O000OO0000O00 +"_str")!=F .lit ('BLANK')).distinct ()#line:2468
        OOOOO000OO0OOOO00 =O0OOO00O00000OOOO .count ()#line:2469
        if OOOOO000OO0OOOO00 ==1 :#line:2470
            O0O000OO00O0000O0 =O0OOO00O00000OOOO .collect ()[0 ][0 ]if (O0OOO00O00000OOOO is not None and O0OOO00O00000OOOO .collect ()is not None and len (O0OOO00O00000OOOO .collect ())>0 )else "NA"#line:2471
            if "NA"!=O0O000OO00O0000O0 :#line:2472
                O00O00000000O0OOO .append (O0O000OO00O0000O0 )#line:2473
                O00OO0OO0OOOOO00O [O000O000OO0000O00 ]=O0O000OO00O0000O0 #line:2474
        O0OOO00O00000OOOO =None #line:2477
      _O00OOO0O00O0OO0OO ['column_alias']=O00OO0OO0OOOOO00O #line:2479
      _O00OOO0O00O0OO0OO ['business_tags']=O00O00000000O0OOO #line:2480
      def _O000OOOOO0OOOOOO0 (OOO0O00O00O00OO0O ):#line:2482
        OOOO0OO000O0O000O =None #line:2483
        try :#line:2484
          if OOO0O00O00O00OO0O is None or str (OOO0O00O00O00OO0O )=='nan':#line:2485
              return 'NA'#line:2486
          if OOO0O00O00O00OO0O ==''or OOO0O00O00O00OO0O =='null':#line:2488
              return 'NA'#line:2489
          O000O0000OO00O000 =O00O0OO0O0OO0O00O .value #line:2491
          for O0O000O0OOO0O0O00 ,OO000O000OO00OOO0 in O000O0000OO00O000 .items ():#line:2492
            O0O0O00OO00000OOO =O0O000O0OOO0O0O00 .match (str (OOO0O00O00O00OO0O ).strip ())#line:2493
            if O0O0O00OO00000OOO is not None :#line:2494
                return OO000O000OO00OOO0 #line:2495
          return 'NA'#line:2497
        except :#line:2499
          return "NA"#line:2500
      OO00O0000OO00O0O0 ={}#line:2504
      O0O00OOO0OO000OOO =['credit card','date of birth','dob','credit card','first name','last name','address','zip','postal code']#line:2505
      for O00OOO0O000OO00O0 in OO000OO00OO0O000O :#line:2507
        for O0000O00O0OOO0O0O in O0O00OOO0OO000OOO :#line:2508
          if textdistance .hamming .normalized_similarity (O0000O00O0OOO0O0O ,O00OOO0O000OO00O0 )>.55 :#line:2509
            OO00O0000OO00O0O0 [O00OOO0O000OO00O0 ]="PII"#line:2510
      O00O0OO0O0OO0O00O =OOOOOO0O000O0OO0O .sparkContext .broadcast (OO0OO0O0000O0O0O0 )#line:2515
      O0O0000O0OO0O0OOO =F .udf (_O000OOOOO0OOOOOO0 ,StringType ())#line:2516
      for O000O000OO0000O00 in OO000OO00OO0O000O :#line:2517
        OOOO0OO0000OO00OO =O0O0O0O00OOOO0OO0 .select (O000O000OO0000O00 ).withColumn ("__idf_classification",O0O0000O0OO0O0OOO (O000O000OO0000O00 )).collect ()#line:2518
        OOOO0OO0000OO00OO =[O0OOO000O0O00OOOO [1 ]for O0OOO000O0O00OOOO in OOOO0OO0000OO00OO ]#line:2519
        if 'PII'in OOOO0OO0000OO00OO :#line:2520
          OO00O0000OO00O0O0 [O000O000OO0000O00 ]="PII"#line:2521
        OOOO0OO0000OO00OO =None #line:2523
      _O00OOO0O00O0OO0OO ['column_level_classification']=OO00O0000OO00O0O0 #line:2525
      O00O0OO0O0OO0O00O .unpersist (blocking =True )#line:2543
      O0O00OO0OOO00O000 .unpersist (blocking =True )#line:2544
      O0OO000O0O00000O0 =None #line:2545
      return _O00OOO0O00O0OO0OO #line:2546
  finally :#line:2550
    OOOO00OO00O0OOO00 =None #line:2551
    O0OO000O0O00000O0 =None #line:2552
    O0O0O0O00OOOO0OO0 =None #line:2553
@logdebug #line:2559
def dataProfileAndMetadataMgt_fn (OOOOO00OO000O000O ,O00O00O00000OO000 ):#line:2560
    import pandas as pd #line:2561
    """
    """#line:2563
    try :#line:2564
        _O0000OO0OO00OOO00 ={}#line:2565
        _O00OOO0O0OO0O0O00 =[]#line:2566
        OO0O00OOOO0O00O0O ={O0O0O0O0O0O00OO00 [0 ]:{"type":"NUMERICAL"}for O0O0O0O0O0O00OO00 in list (filter (lambda O000000OOOOOO0000 :O000000OOOOOO0000 [1 ]in ['double','int','decimal','float','long','short','bigint'],O00O00O00000OO000 .dtypes ))}#line:2570
        OOO0OOOO00O0O0O0O ={O00O0O0O0O00O0O00 [0 ]:{"type":"CATEGORICAL"}for O00O0O0O0O00O0O00 in list (filter (lambda OOO00OO00OOOOOO00 :OOO00OO00OOOOOO00 [1 ]in ['string'],O00O00O00000OO000 .dtypes ))}#line:2572
        OOO0000O00OOOO00O ={O00O00000O0000O0O [0 ]:{"type":"DATETIME"}for O00O00000O0000O0O in list (filter (lambda O00OOO0O0OO0O0O00 :O00OOO0O0OO0O0O00 [1 ]in ['date','timestamp'],O00O00O00000OO000 .dtypes ))}#line:2574
        OO0O000OO000OOO00 =O00O00O00000OO000 .schema .names #line:2576
        for OOOO0000OO0OO000O ,OOOO0O00O0000OO0O in OO0O00OOOO0O00O0O .items ():#line:2578
            O00000OOOO0O000OO =O00O00O00000OO000 .select (OOOO0000OO0OO000O ).describe ().collect ()#line:2579
            OO0OOO0000OOO0O0O ={}#line:2580
            for OOO000OOO00OO0OO0 in O00000OOOO0O000OO :#line:2581
                OO0OOO0000OOO0O0O [OOO000OOO00OO0OO0 [0 ]]=OOO000OOO00OO0OO0 [1 ]#line:2582
            OO0OOO0000OOO0O0O ['column_name']=OOOO0000OO0OO000O #line:2584
            OO0OOO0000OOO0O0O ['distinct_count']=O00O00O00000OO000 .select (OOOO0000OO0OO000O ).distinct ().count ()#line:2585
            OO0OOO0000OOO0O0O ['empty_count']=O00O00O00000OO000 .filter (F .isnull (OOOO0000OO0OO000O )|F .isnan (OOOO0000OO0OO000O )|(F .col (OOOO0000OO0OO000O )==F .lit (""))|(F .col (OOOO0000OO0OO000O )==F .lit (" "))|(F .col (OOOO0000OO0OO000O )==F .lit (""))|(F .col (OOOO0000OO0OO000O )==None )).count ()#line:2587
            OO00OOO0O0O00O0O0 =O00O00O00000OO000 .groupBy (OOOO0000OO0OO000O ).count ().sort ("count",ascending =False ).limit (1 ).collect ()[0 ]#line:2588
            OO0OOO0000OOO0O0O ['most_frequent_value_count']=OO00OOO0O0O00O0O0 [1 ]#line:2589
            OO0OOO0000OOO0O0O ['most_frequent_value']=OO00OOO0O0O00O0O0 [0 ]#line:2590
            OO00O00OO000O00O0 =O00O00O00000OO000 .groupBy (OOOO0000OO0OO000O ).count ().sort ("count",ascending =True ).limit (1 ).collect ()[0 ]#line:2591
            OO0OOO0000OOO0O0O ['least_frequent_value_count']=OO00O00OO000O00O0 [1 ]#line:2592
            OO0OOO0000OOO0O0O ['least_frequent_value']=OO00O00OO000O00O0 [0 ]#line:2593
            O000O00OOOOOO000O =O00O00O00000OO000 .select (F .bround (F .mean (OOOO0000OO0OO000O ),2 )).take (1 )#line:2596
            OO00O0OO00O0O00O0 =O000O00OOOOOO000O [0 ][0 ]#line:2597
            OO0OOO0000OOO0O0O ['mean_val']=OO00O0OO00O0O00O0 #line:2598
            for OOO00000O000O0O0O in OO0O000OO000OOO00 :#line:2599
                OO0OOO0000OOO0O0O ['count_val']=O00O00O00000OO000 .select (OOO00000O000O0O0O ).count ()#line:2600
                OO0OOO0000OOO0O0O ['zeros_val']=O00O00O00000OO000 .filter ((F .col (OOO00000O000O0O0O )==F .lit (0 ))).count ()#line:2601
            OO0O00OOOO0O00O0O [OOOO0000OO0OO000O ].update (OO0OOO0000OOO0O0O )#line:2602
        for OOOO0000OO0OO000O ,OOOO0O00O0000OO0O in OOO0OOOO00O0O0O0O .items ():#line:2605
            OO0OOO0000OOO0O0O ={}#line:2606
            OO0OOO0000OOO0O0O ['column_name']=OOOO0000OO0OO000O #line:2607
            OO0OOO0000OOO0O0O ['distinct_count']=O00O00O00000OO000 .select (OOOO0000OO0OO000O ).distinct ().count ()#line:2608
            OO0OOO0000OOO0O0O ['empty_count']=O00O00O00000OO000 .filter (F .isnull (OOOO0000OO0OO000O )|F .isnan (OOOO0000OO0OO000O )|(F .col (OOOO0000OO0OO000O )==F .lit (""))|(F .col (OOOO0000OO0OO000O )==F .lit (" "))|(F .col (OOOO0000OO0OO000O )==F .lit (""))|(F .col (OOOO0000OO0OO000O )==None )).count ()#line:2609
            OO00OOO0O0O00O0O0 =O00O00O00000OO000 .groupBy (OOOO0000OO0OO000O ).count ().sort ("count",ascending =False ).limit (1 ).collect ()[0 ]#line:2610
            OO0OOO0000OOO0O0O ['most_frequent_value_count']=OO00OOO0O0O00O0O0 [1 ]#line:2611
            OO0OOO0000OOO0O0O ['most_frequent_value']=OO00OOO0O0O00O0O0 [0 ]#line:2612
            OO00O00OO000O00O0 =O00O00O00000OO000 .groupBy (OOOO0000OO0OO000O ).count ().sort ("count",ascending =True ).limit (1 ).collect ()[0 ]#line:2613
            OO0OOO0000OOO0O0O ['least_frequent_value_count']=OO00O00OO000O00O0 [1 ]#line:2614
            OO0OOO0000OOO0O0O ['least_frequent_value']=OO00O00OO000O00O0 [0 ]#line:2615
            O000O00OOOOOO000O =O00O00O00000OO000 .select (F .bround (F .mean (OOOO0000OO0OO000O ),2 )).take (1 )#line:2616
            OO00O0OO00O0O00O0 =O000O00OOOOOO000O [0 ][0 ]#line:2617
            OO0OOO0000OOO0O0O ['mean_val']=OO00O0OO00O0O00O0 #line:2618
            OOO0OOOO00O0O0O0O [OOOO0000OO0OO000O ].update (OO0OOO0000OOO0O0O )#line:2619
        for OOOO0000OO0OO000O ,OOOO0O00O0000OO0O in OOO0000O00OOOO00O .items ():#line:2622
            OO0OOO0000OOO0O0O ={}#line:2623
            OO0OOO0000OOO0O0O ['column_name']=OOOO0000OO0OO000O #line:2624
            OO0OOO0000OOO0O0O ['distinct_count']=O00O00O00000OO000 .select (OOOO0000OO0OO000O ).distinct ().count ()#line:2625
            OOO0000O00OOOO00O [OOOO0000OO0OO000O ].update (OO0OOO0000OOO0O0O )#line:2626
        _O0000OO0OO00OOO00 .update (OO0O00OOOO0O00O0O )#line:2629
        _O0000OO0OO00OOO00 .update (OOO0OOOO00O0O0O0O )#line:2630
        _O0000OO0OO00OOO00 .update (OOO0000O00OOOO00O )#line:2631
        O0O00O000000000O0 =pd .DataFrame ([O0O0OO000OO0OOO0O [1 ]for O0O0OO000OO0OOO0O in _O0000OO0OO00OOO00 .items ()])#line:2632
        return O0O00O000000000O0 #line:2639
    finally :#line:2641
        O00O00O00000OO000 =None #line:2642
@logdebug #line:2648
def spark_df_sample_profiling_glue (O00O0000O0O00O0O0 ,OOOO00000OO0OOOOO ):#line:2649
  from facets_overview .generic_feature_statistics_generator import GenericFeatureStatisticsGenerator #line:2650
  import base64 #line:2651
  OO000000OO00O0O0O =GenericFeatureStatisticsGenerator ()#line:2654
  OO0O0000OOOO0OO00 =OO000000OO00O0O0O .ProtoFromDataFrames ([{'name':'pandas_result','table':O00O0000O0O00O0O0 }])#line:2655
  OO0O00OOOOOOOO000 =base64 .b64encode (OO0O0000OOOO0OO00 .SerializeToString ()).decode ("utf-8")#line:2656
  OOO00O00OOO0000O0 =datetime .now ().timestamp ()#line:2658
  OO000OO00000O0O0O ="""
          <script src="https://cdnjs.cloudflare.com/ajax/libs/webcomponentsjs/1.3.3/webcomponents-lite.js"></script>
          <link rel="import" href="https://raw.githubusercontent.com/PAIR-code/facets/1.0.0/facets-dist/facets-jupyter.html" >
          <facets-overview id="elem"></facets-overview>
          <script>
            document.querySelector("#elem").protoInput = "{protostr}";
          </script>"""#line:2665
  OOOO000O000OOOOO0 =OO000OO00000O0O0O .format (protostr =OO0O00OOOOOOOO000 )#line:2666
  return OOOO000O000OOOOO0 #line:2667
@logdebug #line:2672
def compareAndContrastPandasDF_fn (O000000OOOO000OOO ,O00O0O0OO0O000000 ):#line:2673
  ""#line:2675
  _O000OOO0O0OO00O00 ={}#line:2676
  def OO0O00OOOOO00O00O ():#line:2678
    OOOO0OOO0OOO0000O =[]#line:2679
    O0OOO0O0OOO000000 =O000000OOOO000OOO [O000000OOOO000OOO ['type']=='NUMERICAL']['type'].count ()#line:2681
    OO0O00000000O0OO0 =O000000OOOO000OOO [O000000OOOO000OOO ['type']=='CATEGORICAL']['type'].count ()#line:2682
    O0O0O00O0OO0O0OO0 =O000000OOOO000OOO [O000000OOOO000OOO ['type']=='TIMESTAMP']['type'].count ()#line:2683
    OO000O0O00OO0000O =O00O0O0OO0O000000 [O00O0O0OO0O000000 ['type']=='NUMERICAL']['type'].count ()#line:2685
    O0O0OO0O0OOO000O0 =O00O0O0OO0O000000 [O00O0O0OO0O000000 ['type']=='CATEGORICAL']['type'].count ()#line:2686
    OO0O00OO0O0OO0O0O =O00O0O0OO0O000000 [O00O0O0OO0O000000 ['type']=='TIMESTAMP']['type'].count ()#line:2687
    if O0OOO0O0OOO000000 !=OO000O0O00OO0000O :#line:2689
      OOOO0OOO0OOO0000O .append ("Error in number of NUMERICAL columns from previous run")#line:2690
    if OO0O00000000O0OO0 !=O0O0OO0O0OOO000O0 :#line:2692
      OOOO0OOO0OOO0000O .append ("Error in number of CATEGORICAL columns from previous run")#line:2693
    if O0O0O00O0OO0O0OO0 !=OO0O00OO0O0OO0O0O :#line:2695
      OOOO0OOO0OOO0000O .append ("Error in number of TIMESTAMP columns from previous run")#line:2696
    _O000OOO0O0OO00O00 ['column_type_validation']=OOOO0OOO0OOO0000O #line:2698
  def O000OO0O0O0000OO0 ():#line:2701
    OO00O0000OOO0OOOO ={}#line:2702
    O00OOO00OOOO00000 =O000000OOOO000OOO [O000000OOOO000OOO ['type']=='NUMERICAL']#line:2703
    O00OO00O000OOO0O0 =O00O0O0OO0O000000 [O00O0O0OO0O000000 ['type']=='NUMERICAL']#line:2704
    O00OO0000O00OOO0O =O000000OOOO000OOO [O000000OOOO000OOO ['type']=='NUMERICAL']['column_name'].values #line:2706
    for O00OO0O0O00O00O0O in O00OO0000O00OOO0O :#line:2708
      OOO0O0O0O0O000OO0 =float (O00OOO00OOOO00000 [O00OOO00OOOO00000 ['column_name']==O00OO0O0O00O00O0O ]['stddev'].values [0 ])#line:2709
      OO0000OO00OOOO0O0 =float (O00OO00O000OOO0O0 [O00OO00O000OOO0O0 ['column_name']==O00OO0O0O00O00O0O ]['stddev'].values [0 ])#line:2710
      O0OOOOO0OOOOO0OOO =abs (OOO0O0O0O0O000OO0 -OO0000OO00OOOO0O0 )/(OOO0O0O0O0O000OO0 +OO0000OO00OOOO0O0 )/2 *100 #line:2712
      if O0OOOOO0OOOOO0OOO >5 :#line:2713
        OO00O0000OOO0OOOO [O00OO0O0O00O00O0O ]=f"Percent Difference between STDDEV is {O0OOOOO0OOOOO0OOO}"#line:2714
    _O000OOO0O0OO00O00 ['stddev_percent_difference']=OO00O0000OOO0OOOO #line:2717
  OO0O00OOOOO00O00O ()#line:2720
  O000OO0O0O0000OO0 ()#line:2721
  return _O000OOO0O0OO00O00 #line:2722
@logdebug #line:2727
def loadDataFrameFromMetastore_fn (O0OOOO0O0O00000O0 ,O0O0OO00O00O0O000 ,O0OOOO0O00O0OO0O0 ,O0OO00O0OOOO0OO00 ):#line:2728
  ""#line:2730
  if "where"not in O0OOOO0O00O0OO0O0 and O0OO00O0OOOO0OO00 !=None and len (O0OO00O0OOOO0OO00 )!=0 and O0OO00O0OOOO0OO00 .upper ()!='NA':#line:2731
    O0OOOO0O00O0OO0O0 =f"{O0OOOO0O00O0OO0O0} {O0OO00O0OOOO0OO00}"#line:2732
  O0O0OO00OOO0OOOO0 =O0OOOO0O0O00000O0 .sql (O0OOOO0O00O0OO0O0 )#line:2735
  O0O0OO00OOO0OOOO0 .createOrReplaceTempView (O0O0OO00O00O0O000 .replace (".","_"))#line:2736
  return O0O0OO00OOO0OOOO0 #line:2738
@logdebug #line:2741
def executeReconRules_fn (O0000O0OOO00OO000 ,O0OO0OO000OOO0O00 ,O0OO0O0OOO0OO00O0 ,OO00OO0O00O000O00 ,O0O0O000OOOO00OOO ,OO0OO00O00OO00000 ,OO000OOO000000O00 ):#line:2742
  ""#line:2744
  O00OO000OOOO0OOOO =[]#line:2745
  for OOO0OO00O00000000 in OO000OOO000000O00 :#line:2747
      OOO00O0000O00OO0O ={}#line:2748
      OOO00O0000O00OO0O ['rule_name']=OOO0OO00O00000000 .get ("rule_name")#line:2749
      O0OO00000O0000000 =OOO0OO00O00000000 .get ("left_expression").replace (O0OO0O0OOO0OO00O0 ,O0OO0O0OOO0OO00O0 .replace (".","_"))#line:2751
      OOOOO0O0000O0OO0O =O0000O0OOO00OO000 .sql (O0OO00000O0000000 ).collect ()[0 ][0 ]#line:2752
      if OOO0OO00O00000000 .get ('right_expression',1 )!=1 :#line:2754
          OOOO0OO0O00O00OO0 =OOO0OO00O00000000 .get ("right_expression").replace (O0O0O000OOOO00OOO ,O0O0O000OOOO00OOO .replace (".","_"))#line:2755
          O0O00O0O00OOOOOOO =O0000O0OOO00OO000 .sql (OOOO0OO0O00O00OO0 ).collect ()[0 ][0 ]#line:2756
      else :#line:2758
          O0O00O0O00OOOOOOO =''#line:2759
      if OOO0OO00O00000000 .get ('operator').lower ()=='range':#line:2763
        OOOOO0000O0O00OO0 ='100 - '+str (OOO0OO00O00000000 .get ("threshold_percentage",0 ))+'*0.01*'+str (OOOOO0O0000O0OO0O )+' <= '+str (O0O00O0O00OOOOOOO )+' <= '+'100 + '+str (OOO0OO00O00000000 .get ("threshold_percentage",0 ))+'*0.01*'+str (OOOOO0O0000O0OO0O )#line:2764
        OOO00O0000O00OO0O ['left_value']=str (OOOOO0O0000O0OO0O )#line:2765
        OOO00O0000O00OO0O ['right_value']=str (O0O00O0O00OOOOOOO )#line:2766
        OOO00O0000O00OO0O ['threshold']="\u00B1 "+str (OOO0OO00O00000000 .get ("threshold_percentage"))+'%'#line:2767
        OOO00O0000O00OO0O ['operator']=OOO0OO00O00000000 .get ('operator')#line:2768
      elif OOO0OO00O00000000 .get ('right_expression',1 )==1 :#line:2769
        OOOOO0000O0O00OO0 =[]#line:2770
        OOOOO0000O0O00OO0 =OOO0OO00O00000000 .get ('operator').replace ("$1",str (OOOOO0O0000O0OO0O ))#line:2771
        print (OOOOO0000O0O00OO0 )#line:2772
        OOO00O0000O00OO0O ['left_value']=str (OOOOO0O0000O0OO0O )#line:2773
        OOO00O0000O00OO0O ['right_value']='CONSTANT'#line:2774
        OOO00O0000O00OO0O ['threshold']='NA'#line:2775
        OOO00O0000O00OO0O ['operator']=OOOOO0000O0O00OO0 #line:2776
      else :#line:2777
        OOOOO0000O0O00OO0 =OOO0OO00O00000000 .get ("left_threshold",1 )+'*'+str (OOOOO0O0000O0OO0O )+' '+OOO0OO00O00000000 .get ('operator')+' '+OOO0OO00O00000000 .get ("right_threshold",1 )+'*'+str (O0O00O0O00OOOOOOO )#line:2778
        OOO00O0000O00OO0O ['left_value']=round (eval (OOO0OO00O00000000 .get ("left_threshold",1 )+'*'+str (OOOOO0O0000O0OO0O )),2 )#line:2779
        OOO00O0000O00OO0O ['right_value']=round (eval (OOO0OO00O00000000 .get ("right_threshold",1 )+'*'+str (O0O00O0O00OOOOOOO )),2 )#line:2780
        OOO00O0000O00OO0O ['threshold']="left:"+str (OOO0OO00O00000000 .get ("left_threshold",1 ))+"\n right:"+str (OOO0OO00O00000000 .get ("right_threshold",1 ))#line:2781
        OOO00O0000O00OO0O ['operator']=OOO0OO00O00000000 .get ('operator')#line:2782
      O00OOOOOO0O0000OO =eval (OOOOO0000O0O00OO0 )#line:2783
      OOOOO00OOOOOOO000 ="Passed"if O00OOOOOO0O0000OO ==True else "Failed"#line:2784
      OOO00O0000O00OO0O ['rule_result']=OOOOO00OOOOOOO000 #line:2785
      OOO00O0000O00OO0O ['description']=OOO0OO00O00000000 .get ('description')#line:2786
      O00OO000OOOO0OOOO .append (OOO00O0000O00OO0O )#line:2788
  O0000O0OOO00OO000 .catalog .dropTempView (O0OO0O0OOO0OO00O0 .replace (".","_"))#line:2792
  if OOO0OO00O00000000 .get ('right_expression',1 )!=1 :#line:2794
      O0000O0OOO00OO000 .catalog .dropTempView (O0O0O000OOOO00OOO .replace (".","_"))#line:2795
  OO00OO0O00O000O00 =None #line:2798
  OO0OO00O00OO00000 =None #line:2799
  return O00OO000OOOO0OOOO #line:2801
@logdebug #line:2808
def selectColumnOrderInDF_fn (O00OOO000000OO0OO ,OO0OOO0OO0O0O00OO ):#line:2809
    ""#line:2811
    try :#line:2812
      return O00OOO000000OO0OO .select (*OO0OOO0OO0O0O00OO )#line:2813
    finally :#line:2815
      O00OOO000000OO0OO =None #line:2816
@logdebug #line:2822
def selectOrderedColumnFromDF_fn (O0O00OO0OOOOOO0OO ):#line:2823
  try :#line:2824
    return O0O00OO0OOOOOO0OO .select (sorted (O0O00OO0OOOOOO0OO .columns ))#line:2825
  finally :#line:2827
    O0O00OO0OOOOOO0OO =None #line:2828
@logdebug #line:2834
def writeToS3WithFilter_fn (OOO0OOOO0OO000O00 ,O000OOOO00000O00O ,OO0OO0000O0OO000O ,OO00OO0OO0OOO0OOO ,O0OOO0OOO0OOO0OO0 ,output_format ='PARQUET',mode ='overwrite',condition =None ):#line:2835
    ""#line:2838
    if mode .lower ()=='append'and output_format .upper ()!='DELTA':#line:2840
      OO0OO0000O0OO000O =f"{OO0OO0000O0OO000O}/{OO00OO0OO0OOO0OOO}"#line:2841
    if output_format .upper ()=='DELTA':#line:2844
      if O0OOO0OOO0OOO0OO0 not in [None ,'','none','na']:#line:2845
        O000OOOO00000O00O .write .format ("delta").partitionBy (*O0OOO0OOO0OOO0OO0 .split (",")).option ("overwriteSchema","true").mode (mode ).save (OO0OO0000O0OO000O )#line:2846
      else :#line:2848
        O000OOOO00000O00O .write .format ("delta").option ("overwriteSchema","true").mode (mode ).save (OO0OO0000O0OO000O )#line:2849
    elif output_format .upper ()=='JSON':#line:2854
      if condition ==None :#line:2855
        O000OOOO00000O00O .write .format ("json").option ("overwriteSchema","true").mode (mode ).save (OO0OO0000O0OO000O )#line:2856
      else :#line:2858
        O000OOOO00000O00O .write .format ("json").option ("overwriteSchema","true").mode (mode ).save (OO0OO0000O0OO000O )#line:2859
    elif output_format .upper ()=='CSV':#line:2865
      if condition ==None :#line:2866
        O000OOOO00000O00O .write .format ("csv").option ("overwriteSchema","true").option ('header','true').mode (mode ).save (OO0OO0000O0OO000O )#line:2867
      else :#line:2869
        O000OOOO00000O00O .write .format ("csv").option ("overwriteSchema","true").option ('header','true').mode (mode ).save (OO0OO0000O0OO000O )#line:2870
    else :#line:2875
      if O0OOO0OOO0OOO0OO0 not in [None ,'','none','na']and condition ==None :#line:2876
        O000OOOO00000O00O .write .partitionBy (*O0OOO0OOO0OOO0OO0 .split (",")).parquet (f"{OO0OO0000O0OO000O}",mode =mode )#line:2877
      elif condition ==None :#line:2879
        O000OOOO00000O00O .write .parquet (f"{OO0OO0000O0OO000O}",mode =mode )#line:2880
      else :#line:2882
        O000OOOO00000O00O .filter (condition ).write .parquet (f"{OO0OO0000O0OO000O}",mode =mode )#line:2883
@logdebug #line:2891
def writeDataWithHudiSCD1Format_fn (O000OOOO0000OO00O ,O0O00OO0OOOOOO0O0 ,OO0OO000O0OO0OOO0 ,OO0O0OO00O00O00O0 ,O0OOO0O00OO000O0O ,OOO0OOO00000O0OOO ,O0OO0OO0OOOOOOO0O ,parallelism =20 ):#line:2892
    ""#line:2897
    try :#line:2898
      if O0OO0OO0OOOOOOO0O :#line:2899
        OO0OO000O0OO0OOO0 .write .format ("org.apache.hudi").option ("hoodie.table.name",O0O00OO0OOOOOO0O0 ).option ("hoodie.datasource.write.storage.type","COPY_ON_WRITE").option ("hoodie.datasource.write.operation","upsert").option ("hoodie.upsert.shuffle.parallelism",parallelism ).option ("hoodie.datasource.write.recordkey.field",O0OOO0O00OO000O0O ).option ("hoodie.datasource.write.precombine.field",OOO0OOO00000O0OOO ).mode ("append").save (OO0O0OO00O00O00O0 )#line:2908
      else :#line:2911
          OO0OO000O0OO0OOO0 .write .format ("org.apache.hudi").option ("hoodie.table.name",O0O00OO0OOOOOO0O0 ).option ("hoodie.datasource.write.storage.type","COPY_ON_WRITE").option ("hoodie.datasource.write.operation","bulk_insert").option ("hoodie.datasource.write.recordkey.field",O0OOO0O00OO000O0O ).option ("hoodie.upsert.shuffle.parallelism",parallelism ).option ("hoodie.datasource.write.precombine.field",OOO0OOO00000O0OOO ).mode ("overwrite").save (OO0O0OO00O00O00O0 )#line:2920
    finally :#line:2923
      OO0OO000O0OO0OOO0 =None #line:2924
@logdebug #line:2930
def readDataWithHudiFormat_fn (OOOOOO00OO0OOO0O0 ,OOO0O00OOOO0OOOOO ,O000O0OO0000O0O00 ,OOO0O0O0O0OOO0OO0 ):#line:2931
    ""#line:2935
    O0OOO000OO0OOO0O0 =OOOOOO00OO0OOO0O0 .read .format ("org.apache.hudi").load (f"{O000O0OO0000O0O00}/default/*.parquet")#line:2936
    if OOO0O0O0O0OOO0OO0 !=None and OOO0O0O0O0OOO0OO0 !="":#line:2937
      O0OOO000OO0OOO0O0 =O0OOO000OO0OOO0O0 .repartition (*OOO0O0O0O0OOO0OO0 .split (","))#line:2938
    O0OOO000OO0OOO0O0 .registerTempTable (OOO0O00OOOO0OOOOO )#line:2940
@logdebug #line:2946
def mergeDataWithHudiFormat_fn (O00O000OO00O0O0OO ,O00OO0OOO000O0O0O ,OOO0O000O0OO0OO00 ,OOO00OOOOOO0OO0O0 ,O00000O00O00O0OO0 ,OO0O0O0000O00O0OO ,O000O0OO00000O00O ,OOO0OO0OO000O0OOO ,O0O0OO000O0O0O0OO ):#line:2947
  ""#line:2950
  try :#line:2951
    O00O0000OO0000OO0 =OOO0O000O0OO0OO00 .split ('.')#line:2952
    O00O0O0O0O00OO00O =O00O0000OO0000OO0 [-1 ].replace ('-',"_")#line:2953
    O0O0OOOOO00OOO00O ={'hoodie.table.name':O00O0O0O0O00OO00O ,'hoodie.datasource.write.recordkey.field':re .sub (r'\s+','',O000O0OO00000O00O ),'hoodie.datasource.write.partitionpath.field':OO0O0O0000O00O0OO ,'hoodie.datasource.write.precombine.field':OOO0OO0OO000O0OOO }#line:2960
    O00OO0O0O0O0O0O0O =O00OO0OOO000O0O0O .select (OO0O0O0000O00O0OO ).distinct ()#line:2962
    OO00000OOOOO0OO00 =O00000O00O00O0OO0 #line:2963
    writeToS3WithFilter_fn (O00O000OO00O0O0OO ,O00OO0O0O0O0O0O0O ,f"{OO00000OOOOO0OO00}/audit_table_hudi/{O0O0OO000O0O0O0OO}","PARQUET",mode ='overwrite')#line:2964
    OO0OOOOO00OO0OOOO =OOO00OOOOOO0OO0O0 #line:2966
    O00OO0OOO000O0O0O .write .format ("hudi").options (**O0O0OOOOO00OOO00O ).mode ("append").save (OO0OOOOO00OO0OOOO )#line:2970
    return O00OO0OOO000O0O0O #line:2972
  finally :#line:2974
    O00OO0OOO000O0O0O =None #line:2975
@logdebug #line:2981
def createHudiAthenaTable_fn (OOO0OOOO000000O00 ,O000000OOO0OO00O0 ,O0OO0O0OO00OO0O0O ,OO0OOOO00000000O0 ):#line:2982
  try :#line:2983
    O0O0OOOO0O00OOO0O ={"IntegerType":"INT","StringType":"STRING","DateType":"DATE","TimestampType":"TIMESTAMP","LongType":"BIGINT","DoubleType":"DOUBLE","BooleanType":"BOOLEAN","BinaryType":"BINARY","DecimalType(10,0)":"DECIMAL"}#line:2984
    O00O0O000OOOOO00O =O000000OOO0OO00O0 .split ('.')#line:2985
    O0O00000OO0O000OO ="_".join (O00O0O000OOOOO00O [:3 ]).replace ('-',"_")#line:2986
    O0OO0O0O00O0O0OOO =O00O0O000OOOOO00O [-1 ].replace ('-',"_")#line:2987
    O0OO00OO0O000OO0O =O0OO0O0OO00OO0O0O #line:2989
    O000OOO000OOO0000 =boto3 .client ('athena')#line:2990
    O00000O0OO0O00O00 =dict (OOO0OOOO000000O00 .dtypes )[OO0OOOO00000000O0 ]#line:2991
    O0OOO0OO000OOOO00 ="CREATE EXTERNAL TABLE IF NOT EXISTS  "+O0O00000OO0O000OO +"."+O0OO0O0O00O0O0OOO +" ("#line:2993
    OOO0O0OOOOOOO0OOO =[O000000OO000O00OO .dataType for O000000OO000O00OO in OOO0OOOO000000O00 .drop (F .col (OO0OOOO00000000O0 )).schema .fields ]#line:2994
    for OOOOOOOOOOO0O0OO0 ,O0OO0O0OOO0O000O0 in zip (OOO0O0OOOOOOO0OOO ,OOO0OOOO000000O00 .drop (F .col (OO0OOOO00000000O0 )).columns ):#line:2995
        O0OOO0OO000OOOO00 +=O0OO0O0OOO0O000O0 +" "+O0O0OOOO0O00OOO0O .get (str (OOOOOOOOOOO0O0OO0 ))+","#line:2996
    O0OOO0OO000OOOO00 =O0OOO0OO000OOOO00 [:-1 ]+" ) PARTITIONED BY ("+OO0OOOO00000000O0 +" "+O00000O0OO0O00O00 +") \
    ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'  \
    STORED AS INPUTFORMAT 'org.apache.hudi.hadoop.HoodieParquetInputFormat' \
    OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat' \
    LOCATION '"+O0OO00OO0O000OO0O +"'"#line:3002
    O000OOO000OOO0000 .start_query_execution (QueryString ="CREATE DATABASE IF NOT EXISTS "+O0O00000OO0O000OO )#line:3004
    O000OOO000OOO0000 .start_query_execution (QueryString =O0OOO0OO000OOOO00 )#line:3006
    O00000OO000OO0OOO =OOO0OOOO000000O00 .select (OO0OOOO00000000O0 ).distinct ().rdd .flatMap (lambda OOOOO0OOO0000000O :OOOOO0OOO0000000O ).collect ()#line:3008
    for O0OO00O000OO0O0O0 in O00000OO000OO0OOO :#line:3009
        OO0O00O0OO0O0OO0O ="ALTER TABLE "+O0O00000OO0O000OO +"."+O0OO0O0O00O0O0OOO +" ADD IF NOT EXISTS" " PARTITION ("+OO0OOOO00000000O0 +" = '"+O0OO00O000OO0O0O0 +"') LOCATION '"+O0OO00OO0O000OO0O +"/"+O0OO00O000OO0O0O0 +"'"#line:3011
        O000OOO000OOO0000 .start_query_execution (QueryString =OO0O00O0OO0O0OO0O )#line:3012
  finally :#line:3015
    OOO0OOOO000000O00 =None #line:3016
@logdebug #line:3022
def readDataWithDeltaFormat_fn (OO00000OO000O0000 ,O0OO00O00O00OO000 ,OOO0O000O00O0OOO0 ):#line:3023
    ""#line:3025
    OOO000OOO0O0OOOO0 =OO00000OO000O0000 .read .format ("delta").load (O0OO00O00O00OO000 )#line:3026
    OOO000OOO0O0OOOO0 .registerTempTable (OOO0O000O00O0OOO0 )#line:3027
    OOO000OOO0O0OOOO0 =None #line:3028
@logdebug #line:3034
def writeDataWithDeltaSCD1Format_fn (O0OO0OOOO00O00OO0 ,O0OO0000OOOO0O000 ,OO00O00O00000OOOO ,O000OOOO0OOO0OOO0 ,OOO00OO0O0OOO0000 ,OOOOO000OOO000OOO ,OOOOO0O000O0O00OO ):#line:3035
    ""#line:3038
    try :#line:3039
      from delta .tables import DeltaTable #line:3040
      if OOOOO0O000O0O00OO :#line:3041
        O0OO000O0O000O0O0 =DeltaTable .forPath (O0OO0OOOO00O00OO0 ,O000OOOO0OOO0OOO0 )#line:3042
        O0OO000O0O000O0O0 .vacuum ()#line:3043
        OO000O00O0O00O00O ={}#line:3045
        OOO0O00000O00OO0O ={}#line:3046
        for OO0OO0OO0OOOOO0O0 in OO00O00O00000OOOO .columns :#line:3047
          OOO0O00000O00OO0O [OO0OO0OO0OOOOO0O0 ]="updates.{item}".format (item =OO0OO0OO0OOOOO0O0 )#line:3048
          if OO0OO0OO0OOOOO0O0 !=OOO00OO0O0OOO0000 :#line:3049
            OO000O00O0O00O00O [OO0OO0OO0OOOOO0O0 ]="updates.{item}".format (item =OO0OO0OO0OOOOO0O0 )#line:3050
        O0OO000O0O000O0O0 .alias ("original_table").merge (OO00O00O00000OOOO .alias ("updates"),"updates.{primaryKeyColumn} = original_table.{primaryKeyColumn}".format (primaryKeyColumn =OOO00OO0O0OOO0000 )).whenMatchedUpdate (set =OO000O00O0O00O00O ).whenNotMatchedInsert (values =OOO0O00000O00OO0O ).execute ()#line:3058
      else :#line:3073
        if OOOOO000OOO000OOO ==None or OOOOO000OOO000OOO .lower ()=='none'or OOOOO000OOO000OOO =="":#line:3074
          OO00O00O00000OOOO .write .format ("delta").save (O000OOOO0OOO0OOO0 )#line:3075
        else :#line:3077
          OO00O00O00000OOOO .write .format ("delta").partitionBy (*OOOOO000OOO000OOO .split (",")).save (O000OOOO0OOO0OOO0 )#line:3078
    finally :#line:3086
      OO00O00O00000OOOO =None #line:3087
@logdebug #line:3093
def writeDataWithDeltaSCD2Format_fn (O0O0O0000000O000O ,OOO0OO00OO00O0000 ,O00O0OOOOO0OO0O00 ,O000OOO0O000O0O0O ,OOO0O000000OOOOO0 ,OOO00O000OOO0OOO0 ,OOO0000O000O0O000 ,active_column_name =None ,column_list_to_identify_changes =None ,start_date_column_name =None ,end_date_column_name =None ,active_column_true_value ='y',active_column_false_value ='n'):#line:3094
  ""#line:3117
  try :#line:3118
    from delta .tables import DeltaTable #line:3119
    if OOO0000O000O0O000 :#line:3121
      active_column_true_value ="'{active_column_true_value}'".format (active_column_true_value =active_column_true_value )if type (active_column_true_value )!=bool else active_column_true_value #line:3123
      active_column_false_value ="'{active_column_false_value}'".format (active_column_false_value =active_column_false_value )if type (active_column_false_value )!=bool else active_column_false_value #line:3124
      O0O0O0OOOO0O0O00O =DeltaTable .forPath (O0O0O0000000O000O ,O000OOO0O000O0O0O )#line:3126
      O0O0O0OOOO0O0O00O .vacuum ()#line:3127
      OO00OO00OO0OO0OOO ={}#line:3129
      OO0O000OOOOO0000O ={}#line:3130
      OO00OO00OO0OO0OOO [active_column_name ]=active_column_false_value #line:3134
      OO00OO00OO0OO0OOO [end_date_column_name ]="updates.{item}".format (item =start_date_column_name )#line:3135
      for OO0O0O00O000O0000 in O00O0OOOOO0OO0O00 .columns :#line:3136
        if OO0O0O00O000O0000 ==active_column_name :#line:3137
          OO0O000OOOOO0000O [OO0O0O00O000O0000 ]=active_column_true_value #line:3138
        else :#line:3140
          OO0O000OOOOO0000O [OO0O0O00O000O0000 ]="updates.{item}".format (item =OO0O0O00O000O0000 )#line:3141
      O0O0O0OOOO0O0O00O .alias (OOO0OO00OO00O0000 ).merge (O00O0OOOOO0OO0O00 .alias ("updates"),"updates.{primaryKeyColumn} = {table_name}.{primaryKeyColumn} AND {table_name}.{active_column_name} = {active_column_true_value} ".format (primaryKeyColumn =OOO0O000000OOOOO0 ,table_name =OOO0OO00OO00O0000 ,active_column_name =active_column_name ,active_column_true_value =active_column_true_value )).whenMatchedUpdate (set =OO00OO00OO0OO0OOO ).execute ()#line:3148
      O0O0O0OOOO0O0O00O .alias (OOO0OO00OO00O0000 ).merge (O00O0OOOOO0OO0O00 .alias ("updates"),"updates.{primaryKeyColumn} = {table_name}.{primaryKeyColumn} AND updates.{active_column_name} != {active_column_true_value}".format (primaryKeyColumn =OOO0O000000OOOOO0 ,table_name =OOO0OO00OO00O0000 ,active_column_name =active_column_name ,active_column_true_value =active_column_true_value )).whenNotMatchedInsert (values =OO0O000OOOOO0000O ).execute ()#line:3154
    else :#line:3157
      if OOO00O000OOO0OOO0 not in [None ,'','none','na']:#line:3158
        O00O0OOOOO0OO0O00 .write .format ("delta").partitionBy (*OOO00O000OOO0OOO0 .split (",")).save (O000OOO0O000O0O0O )#line:3159
      else :#line:3161
        O00O0OOOOO0OO0O00 .write .format ("delta").save (O000OOO0O000O0O0O )#line:3162
  finally :#line:3170
    O00O0OOOOO0OO0O00 =None #line:3171
@logdebug #line:3178
def writeDataWithDeltaDatabricksSCD2Format_fn (OO00OO0O0OO0O0OO0 ,OOOOOO00O0O0000OO ,O0O0OOO0OOO000O00 ,OO0OOOO0000OO00O0 ,O0O0OO000O0000O0O ,OO00000O0OO0O0OO0 ,O0OOOO0OOO0OO0OOO ,active_column_name =None ,column_list_to_identify_changes =None ,start_date_column_name =None ,end_date_column_name =None ,active_column_true_value ='y',active_column_false_value ='n'):#line:3179
  ""#line:3202
  try :#line:3203
    from delta .tables import DeltaTable #line:3204
    if len (O0O0OO000O0000O0O )==0 :#line:3208
      raise Exception ("{primaryKeyColumn} must to be defined".format (primaryKeyColumn =O0O0OO000O0000O0O ))#line:3209
    if O0OOOO0OOO0OO0OOO :#line:3212
      active_column_true_value ="'{active_column_true_value}'".format (active_column_true_value =active_column_true_value )if type (active_column_true_value )!=bool else active_column_true_value #line:3214
      active_column_false_value ="'{active_column_false_value}'".format (active_column_false_value =active_column_false_value )if type (active_column_false_value )!=bool else active_column_false_value #line:3215
      OO00O000OOOO0O0O0 =DeltaTable .forPath (OO00OO0O0OO0O0OO0 ,OO0OOOO0000OO00O0 )#line:3217
      OO0000O0OO0O00OOO =O0O0OOO0OOO000O00 #line:3219
      OOO00OO0OO0O00O0O ={}#line:3221
      O00O0O00OO00O0000 ={}#line:3222
      if active_column_name ==None :#line:3224
        O0000OOOOOOOOO0OO ="1=1 AND ( "#line:3225
      else :#line:3226
        O0000OOOOOOOOO0OO ="SCD2."+active_column_name +" = "+active_column_true_value +" AND ( "#line:3227
      O0OOOOOO0O0OOOO00 ="( "#line:3229
      if column_list_to_identify_changes !=None :#line:3231
        for OO0OO00OO000O00OO in column_list_to_identify_changes .split (","):#line:3232
          O0000OOOOOOOOO0OO =O0000OOOOOOOOO0OO +" NewData.{c1} <> SCD2.{c2}".format (c1 =OO0OO00OO000O00OO ,c2 =OO0OO00OO000O00OO ,table_name =OOOOOO00O0O0000OO )+" OR "#line:3233
          O0OOOOOO0O0OOOO00 =O0OOOOOO0O0OOOO00 +" SCD2.{c1} <> staged_updates.{c2}".format (c1 =OO0OO00OO000O00OO ,c2 =OO0OO00OO000O00OO ,table_name =OOOOOO00O0O0000OO )+" OR "#line:3234
      else :#line:3237
        O0000OOOOOOOOO0OO =O0000OOOOOOOOO0OO +" 1=1 OR "#line:3238
        O0OOOOOO0O0OOOO00 =O0OOOOOO0O0OOOO00 +" 1=1 OR "#line:3239
      O0000OOOOOOOOO0OO =O0000OOOOOOOOO0OO [:-3 ]+" )"#line:3242
      O0OOOOOO0O0OOOO00 =O0OOOOOO0O0OOOO00 [:-3 ]+" )"#line:3243
      active_column_true_value ="'y'"if active_column_true_value .lower ()=='y'else active_column_true_value #line:3245
      active_column_false_value ="'n'"if active_column_false_value .lower ()=='n'else active_column_false_value #line:3246
      OOO0O0000OOOO00OO ={}#line:3248
      if active_column_name !=None :#line:3249
        OO000OO000OOO0000 =active_column_name #line:3250
        OOO0O0000OOOO00OO [OO000OO000OOO0000 ]=active_column_false_value #line:3251
        O0OOOOOO0O0OOOO00 =O0OOOOOO0O0OOOO00 +" AND SCD2."+active_column_name +"="+active_column_true_value #line:3252
      if start_date_column_name !=None :#line:3255
        O0OOOOOO00OO0O0O0 =end_date_column_name #line:3256
        OOO0O0000OOOO00OO [O0OOOOOO00OO0O0O0 ]="staged_updates."+start_date_column_name #line:3257
      OO0000O00OOOO0O0O =OO0000O0OO0O00OOO .alias ("NewData").join (OO00O000OOOO0O0O0 .toDF ().alias ("SCD2"),str (O0O0OO000O0000O0O )).where (str (O0000OOOOOOOOO0OO ))#line:3263
      O00OO00O00OO0OOO0 =(OO0000O00OOOO0O0O .selectExpr ("NULL as mergeKey","NewData.*").union (OO0000O0OO0O00OOO .selectExpr ("{primaryKeyColumn} as mergeKey".format (primaryKeyColumn =O0O0OO000O0000O0O ),"*")))#line:3269
      OO00O000OOOO0O0O0 .alias ("SCD2").merge (O00OO00O00OO0OOO0 .alias ("staged_updates"),"SCD2."+str (O0O0OO000O0000O0O )+"= mergeKey").whenMatchedUpdate (condition =O0OOOOOO0O0OOOO00 ,set =OOO0O0000OOOO00OO ).whenNotMatchedInsertAll ().execute ()#line:3275
    else :#line:3278
      if OO00000O0OO0O0OO0 not in [None ,'','none','na']:#line:3279
        O0O0OOO0OOO000O00 .write .format ("delta").partitionBy (*OO00000O0OO0O0OO0 .split (",")).save (OO0OOOO0000OO00O0 )#line:3280
      else :#line:3282
        O0O0OOO0OOO000O00 .write .format ("delta").save (OO0OOOO0000OO00O0 )#line:3283
  except Exception as OO0OO00OO00OOOO0O :#line:3288
    raise OO0OO00OO00OOOO0O #line:3289
  finally :#line:3291
    OO00O000OOOO0O0O0 =None #line:3292
    OO0000O0OO0O00OOO =None #line:3293
@logdebug #line:3301
def upsertWithDeltaFormat_fn (O0OOO0OOOOO00000O ,O0O00000O0000OO00 ,OOOOO0OO0OOOOOOOO ,OOOO0O0O000OO00O0 ,OOOOO00O0O000OOOO ,timestamp_ordering_column =None ,timestamp_ordering_column_format ="yyyy-mm-dd"):#line:3302
  ""#line:3325
  try :#line:3326
    from delta .tables import DeltaTable #line:3327
    O00OO0000O00O00OO =Window .partitionBy (OOOOO00O0O000OOOO ).orderBy ('__idf_ud_ts_order')#line:3329
    OOOOO0OO0OOOOOOOO =OOOOO0OO0OOOOOOOO .select ("*",F .to_timestamp (F .col (timestamp_ordering_column ).cast ('string'),timestamp_ordering_column_format ).alias ("__idf_ud_ts_order")).select ("*",F .row_number ().over (O00OO0000O00O00OO ).alias ("__idf_ud_rank")).select ("*",F .max ('__idf_ud_rank').over (O00OO0000O00O00OO ).alias ("__idf_ud_max_rank")).select ("*",F .expr ("case when __idf_ud_rank == __idf_ud_max_rank then 'y' else 'n' end").alias ("is_active")).drop ("__idf_ud_ts_order","__idf_ud_rank","__idf_ud_max_rank")#line:3331
    if DeltaTable .isDeltaTable (O0OOO0OOOOO00000O ,OOOO0O0O000OO00O0 ):#line:3333
      OO00OOO000O000OOO =DeltaTable .forPath (O0OOO0OOOOO00000O ,OOOO0O0O000OO00O0 )#line:3335
      OO00OOO000O000OOO .vacuum ()#line:3336
      O00O0OO000O00OOO0 ={}#line:3338
      OOOO000O0O00O0O00 ={}#line:3339
      O00O0OO000O00OOO0 ["is_active"]="'n'"#line:3341
      for OOOO0000OO00OO000 in OOOOO0OO0OOOOOOOO .columns :#line:3342
        OOOO000O0O00O0O00 [OOOO0000OO00OO000 ]="updates.{item}".format (item =OOOO0000OO00OO000 )#line:3343
      OO00OOO000O000OOO .alias (O0O00000O0000OO00 ).merge (OOOOO0OO0OOOOOOOO .alias ("updates"),"updates.{primaryKeyColumn} = {table_name}.{primaryKeyColumn} AND {table_name}.is_active = 'y' ".format (primaryKeyColumn =OOOOO00O0O000OOOO ,table_name =O0O00000O0000OO00 )).whenMatchedUpdate (set =O00O0OO000O00OOO0 ).execute ()#line:3349
      OO00OOO000O000OOO .alias (O0O00000O0000OO00 ).merge (OOOOO0OO0OOOOOOOO .alias ("updates"),"updates.{primaryKeyColumn} = {table_name}.{primaryKeyColumn} AND updates.is_active != 'y'".format (primaryKeyColumn =OOOOO00O0O000OOOO ,table_name =O0O00000O0000OO00 )).whenNotMatchedInsert (values =OOOO000O0O00O0O00 ).execute ()#line:3354
    else :#line:3356
      OOOOO0OO0OOOOOOOO .write .format ("delta").save (OOOO0O0O000OO00O0 )#line:3357
  finally :#line:3361
    OOOOO0OO0OOOOOOOO =None #line:3362
@logdebug #line:3369
def deleteDeltaData_fn (O00OOO0OOO0OO00OO ,OOO00000OO0000O00 ,O0O0OO0O000OOOO00 ,OOO0OOO0000O0000O ,O0OO00O0O0O0O0OO0 ):#line:3370
    ""#line:3375
    from delta .tables import DeltaTable #line:3376
    try :#line:3377
      O00000OOOOO0OO00O =DeltaTable .forPath (O00OOO0OOO0OO00OO ,OOO0OOO0000O0000O )#line:3378
      O00000OOOOO0OO00O .vacuum ()#line:3379
      if O0O0OO0O000OOOO00 ==None :#line:3381
        O0O0OO0O000OOOO00 =O00OOO0OOO0OO00OO .sql ("select * from other_table")#line:3382
      O00000OOOOO0OO00O .alias (OOO00000OO0000O00 ).merge (O0O0OO0O000OOOO00 .alias ("other_table"),O0OO00O0O0O0O0OO0 ).whenMatchedDelete ().execute ()#line:3388
    finally :#line:3390
      O0O0OO0O000OOOO00 =None #line:3391
@logdebug #line:3397
def mergeDataWithDeltaFormat_fn (OOOOO0000OOO00000 ,OOOOO0OO0OOO00O0O ,O000OOO0O0OOO00O0 ,OO00O0O000OO0OO0O ,O000OOO000O0O0000 ,O0OOOO0O000000O0O ,OO00OO00OOOOO00OO ):#line:3398
    from delta .tables import DeltaTable #line:3399
    try :#line:3400
      O0O00OOOOOOOOO0O0 =O000OOO0O0OOO00O0 #line:3402
      OO0O000000OOOO0OO =re .search (r's3://(.*?)/(.*)',O0O00OOOOOOOOO0O0 ,re .IGNORECASE )#line:3404
      O0OO0OO00O0OOOOOO =OO0O000000OOOO0OO .group (1 )#line:3405
      O0O0OOO000OOO000O =OO0O000000OOOO0OO .group (2 )#line:3406
      O0OO0O0000OO00O0O =boto3 .client ('s3')#line:3408
      O0000O0OOO00000OO =O0OO0O0000OO00O0O .list_objects (Bucket =O0OO0OO00O0OOOOOO ,Prefix =O0O0OOO000OOO000O )#line:3409
      OO00O0OOO0O00OOOO =False #line:3410
      if O0000O0OOO00000OO .get ('Contents'):#line:3411
          OO00O0OOO0O00OOOO =True #line:3412
      OOOO00O0OO0OOO0O0 =O0OOOO0O000000O0O .split (',')#line:3414
      O0OOO0000O00000O0 =''#line:3415
      for OOO00OOOOO0000OO0 in OOOO00O0OO0OOO0O0 :#line:3416
          O0OOO0000O00000O0 =O0OOO0000O00000O0 +" AND newData."+OOO00OOOOO0000OO0 +" = oldData."+OOO00OOOOO0000OO0 #line:3417
      OOOOOOO0OO0O000OO =OOOOO0OO0OOO00O0O .select (O000OOO000O0O0000 ).distinct ()#line:3419
      OOOOOOOOOOO00OOOO =OO00O0O000OO0OO0O #line:3420
      writeToS3WithFilter_fn (OOOOO0000OOO00000 ,OOOOOOO0OO0O000OO ,f"{OOOOOOOOOOO00OOOO}/audit_table/{OO00OO00OOOOO00OO}","PARQUET",mode ='overwrite')#line:3421
      if OO00O0OOO0O00OOOO :#line:3423
          OO0OOOO000O0000O0 =DeltaTable .forPath (OOOOO0000OOO00000 ,O0O00OOOOOOOOO0O0 )#line:3424
          OO0OOOO000O0000O0 .alias ("oldData").merge (OOOOO0OO0OOO00O0O .alias ("newData"),"(newData."+O000OOO000O0O0000 +" = oldData."+O000OOO000O0O0000 +")"+O0OOO0000O00000O0 ).whenMatchedUpdateAll ().whenNotMatchedInsertAll ().execute ()#line:3427
      else :#line:3428
          OOOOO0OO0OOO00O0O .write .format ("delta").partitionBy (O000OOO000O0O0000 ).save (O0O00OOOOOOOOO0O0 )#line:3429
      return OOOOO0OO0OOO00O0O #line:3431
    finally :#line:3433
      OOOOO0OO0OOO00O0O =None #line:3434
@logdebug #line:3438
def createDeltaAthenaTable_fn (O00OOO0OO00OO0000 ,O0O0000O0O0OO0O00 ,OOOO0O00O0O0OOOOO ,O00OO0000O0O00OO0 ,OO00OO0OO00OOO000 ):#line:3439
  from delta .tables import DeltaTable #line:3440
  try :#line:3441
    OO000OOOO0OOO0OOO =O00OO0000O0O00OO0 #line:3442
    O0O0O0OOO000OOO00 =DeltaTable .forPath (O00OOO0OO00OO0000 ,OO000OOOO0OOO0OOO )#line:3443
    O0O0O0OOO000OOO00 .generate ("symlink_format_manifest")#line:3444
    OOOOO00OO00O0OO0O ={"IntegerType":"INT","StringType":"STRING","DateType":"DATE","TimestampType":"TIMESTAMP","LongType":"BIGINT","DoubleType":"DOUBLE","BooleanType":"BOOLEAN","BinaryType":"BINARY","DecimalType(10,0)":"DECIMAL"}#line:3446
    O000O00OOO0O0O0OO =OOOO0O00O0O0OOOOO .split ('.')#line:3448
    O0O00OO00O0OO0000 ="_".join (O000O00OOO0O0O0OO [:3 ]).replace ('-',"_")#line:3449
    O0OOOO000O0O0OOO0 =O000O00OOO0O0O0OO [-1 ].replace ('-',"_")#line:3450
    O000O0OO0O0OO00OO =boto3 .client ('athena')#line:3452
    OOOOO0O00OO000OOO =dict (O0O0000O0O0OO0O00 .dtypes )[OO00OO0OO00OOO000 ]#line:3453
    O0OOOO00000000OOO ="CREATE EXTERNAL TABLE IF NOT EXISTS  "+O0O00OO00O0OO0000 +"."+O0OOOO000O0O0OOO0 +" ("#line:3455
    OOOOO0O0O00O00O00 =[OOOOOOOOO0000O00O .dataType for OOOOOOOOO0000O00O in O0O0000O0O0OO0O00 .drop (F .col (OO00OO0OO00OOO000 )).schema .fields ]#line:3456
    for OOO00O0O00O0OO0O0 ,O0OO0O000000OOO00 in zip (OOOOO0O0O00O00O00 ,O0O0000O0O0OO0O00 .drop (F .col (OO00OO0OO00OOO000 )).columns ):#line:3457
        O0OOOO00000000OOO +=O0OO0O000000OOO00 +" "+OOOOO00OO00O0OO0O .get (str (OOO00O0O00O0OO0O0 ))+","#line:3458
    O0OOOO00000000OOO =O0OOOO00000000OOO [:-1 ]+" ) PARTITIONED BY ("+OO00OO0OO00OOO000 +" "+OOOOO0O00OO000OOO +") \
    ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'  \
    STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.SymlinkTextInputFormat' \
    OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' \
    LOCATION '"+OO000OOOO0OOO0OOO +"/_symlink_format_manifest/'"#line:3464
    O000O0OO0O0OO00OO .start_query_execution (QueryString ="CREATE DATABASE IF NOT EXISTS "+O0O00OO00O0OO0000 )#line:3466
    O000O0OO0O0OO00OO .start_query_execution (QueryString =O0OOOO00000000OOO )#line:3468
    O000O0OO0O0OO00OO .start_query_execution (QueryString ="MSCK REPAIR TABLE "+O0O00OO00O0OO0000 +"."+O0OOOO000O0O0OOO0 )#line:3470
  finally :#line:3472
    O0O0000O0O0OO0O00 =None #line:3473

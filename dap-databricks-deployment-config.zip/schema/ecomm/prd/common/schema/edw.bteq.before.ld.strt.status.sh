#!/bin/ksh
#DIR="$(cd "$(dirname "$0")" && pwd)"
#. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Chirag Patel & Hal Hale
#  File name:        edw.bteq.before.ld.strt.status.sh 
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-05-2008
#         |                                           |  C Patel   |
#---------+-------------------------------------------+------------+-----------
#   1.1   |  Modified for JOB EXECUTION CONTROL.      |  C Patel   | 07-11-2008
#---------+-------------------------------------------+------------+-----------

DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

## SET SCRIPT PARAMETERS

SQSERVER=${1}
SQUSER=${2}
SQPWD=${3}
SQDB=${4}
JOBEXECTABLE=${5}
JOBLOGTABLE=${6}
JOBSTAGETABLE=${7}
JOBLINKTABLE=${8}
EDWBATCHID=${9}
DSPROJECT=${10}
DSJOBNAME=${11}
DSJOBINVOCNAME=${12}
BTEQOUTDIR=${13}
LOGFILE=${14}

JOBSTARTDTTM=`date +"%C%y-%m-%d %H:%M:%S"`
JOBFINISHDTTM="1800-01-01 00:00:00"
BTEQOUTFILE=$BTEQOUTDIR/$DSJOBNAME.$DSJOBINVOCNAME.bteq.out.`date +%m%d%H%M%S`

RUNSTATUS=0

echo "*==================================================================" 
echo "| BEFORE JOB EXECUTION BTEQ SCRIPT.#####                          *" 
echo "| `date +'%D %r'` START edw.bteq.before.ld.strt.status.sh           *" 
echo "*==================================================================" 
echo " "                                                                   
echo "*=================================================================*" 
echo "| Initiate the DataStage job by enterint a record into the        *" 
echo "| Process Control table ( Job ecxecutuion Details).               *" 
echo "*=================================================================*" 
echo "|                                                                 *" 
echo "*************************************************************"       
echo "*  => DataStage Job Name= "$DSJOBNAME                                
echo "*  => Job Invocation ID = "$DSJOBINVOCNAME                           
echo "*************************************************************"                                        
echo "*  =>SQDB           = "$SQDB                                         
echo "*  =>JOBEXECTABLE   = "$JOBEXECTABLE                                 
echo "*  =>JOBLOGTABLE    = "$JOBLOGTABLE                                  
echo "*  =>JOBSTAGETABLE  = "$JOBSTAGETABLE                                
echo "*  =>JOBLINKTABLE   = "$JOBLINKTABLE                                 
echo "*  =>EDWBATCHID     = "$EDWBATCHID                                   
echo "*  =>DSPROJECT      = "$DSPROJECT   
echo "*  =>DSJOBNAME      = "$DSJOBNAME   
echo "*  =>DSJOBINVOCNAME = "$DSJOBINVOCNAME   
echo "*  =>BTEQOUT        = "$BTEQOUT                                      
echo "*  =>LOGFILE        = "$LOGFILE                                      
echo "*  =>JOBSTARTDTTM   = "$JOBSTARTDTTM                                 
echo "*  =>JOBFINISHDTTM  = "$JOBFINISHDTTM                                
echo "*  =>LOGFILE        = "$LOGFILE                                      
echo "*  =>BTEQOUTFILE    = "$BTEQOUTFILE                                  
echo "*************************************************************"       

## INITIATE BTEQ SESSION AND INSERT A JOB RUNNING STATUS RECORD FOR THE CURRENT JOB.

python3 << EOF 
import os
import sys
import pyodbc
from npjet import *


def main():
  #-- LOCKING ROW FOR ACCESS
  global cnxn
  cnxn = getDBConnectionSQLServer(Action.quietLevel)
  cursor = cnxn.cursor()

  try:
    cursor.execute("SELECT convert(varchar(10), status_cd)​ FROM $SQDB.$JOBEXECTABLE WHERE edw_batch_id=$EDWBATCHID AND proj_name='$DSPROJECT' AND pipeLine_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME';")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  global BTEQOUTFILE
  BTEQOUTFILE = cursor.fetchone()

  if (BTEQOUTFILE is None):
    BTEQOUTFILE=''
  else:
    BTEQOUTFILE = BTEQOUTFILE[0]


  with open('$BTEQOUTFILE', 'w') as f:
    f.write(str(BTEQOUTFILE))

  try:
    cursor.execute("SELECT count(status_cd​) FROM $SQDB.$JOBEXECTABLE WHERE edw_batch_id='$EDWBATCHID' AND proj_name='$DSPROJECT' AND pipeLine_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME';")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  activityCount = cursor.fetchone()
  activityCount = activityCount[0]

  print("activityCount: " + str(activityCount))

  if (activityCount > 0):
    CHCKSTAT()
    return

  try:
    cursor.execute("INSERT INTO $SQDB.$JOBEXECTABLE (proj_name,src_stream_name,edw_batch_id,pipeLine_name,run_seq_nbr,job_invocation_id,status_cd​,start_dttm,finish_dttm) VALUES ('$DSPROJECT','NA','$EDWBATCHID','$DSJOBNAME',-1,'$DSJOBINVOCNAME','$RUNSTATUS','$JOBSTARTDTTM','$JOBFINISHDTTM');")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  if (errorCode == 0):
    INSERTOK()
    return
  print("""INSERT OF JOB EXECUTION STATUS UNSUCCESSFUL""")
  Action.errorCodeOverride = 100
  cursor.close()
  cnxn.close()
  return

def INSERTOK():
  cnxn.commit()
  Action.errorCodeOverride = 0
  return
  CHCKSTAT()
def CHCKSTAT():
  Action.errorCodeOverride = 200
  return

main()
cleanup()
done()
EOF
BTEQ1_RC=$?
echo "BTEQ1_RC ="$BTEQ1_RC 

if [ $BTEQ1_RC -eq 1 ]
 then
  echo "*============================================================================" 
  echo "edw.bteq.before.ld.strt.status.sh JOB FAILED. PLEASE CHECK."                                                                             
  echo "*============================================================================" 
  exit 1
fi

if [ $BTEQ1_RC -eq 0 ]
 then
  echo "*============================================================================" 
  echo "JOB HAS NOT BEEN EXECUTED FOR CURRENT BATCH "                                   
  echo "INSERTED JOB RUNNING STATUS RECORD"                                            
  echo "RETURNING CONTROL TO JOB SEQUENCE"                                             
  echo "*============================================================================" 
  exit 0
fi
if [ $BTEQ1_RC -eq 100 ]
 then
  echo "*============================================================================" 
  echo "JOB HAS NOT BEEN EXECUTED FOR CURRENT BATCH "                                  
  echo "FAILURE UPON INSERTING JOB RUNNING STATUS RECORD"                              
  echo "RETURNING CONTROL TO JOB SEQUENCE"                                             
  echo "*============================================================================" 
  exit 1
fi


# echo "teststat = |"$teststat"|"

#if [ `cat $BTEQOUTFILE | tr -d ' '` = 3 ]
if [ `cat $BTEQOUTFILE | tr -d ' '` -ne 1 ] && [ `cat $BTEQOUTFILE | tr -d ' '` -ne 2 ]
  then
  echo "*============================================================================" 
  echo "JOB HAS BEEN EXECUTED FOR CURRENT BATCH "                                      
  echo "JOB ABORTED LAST RUN FOR CURRENT BATCH AND REQUIRES RERUN"                     
  echo "UPDATING JOB STATUS TO RUNNING STATUS"                                         
  echo "RETURNING CONTROL TO JOB SEQUENCE"                                             
  echo "*============================================================================" 


         python3 << EOF 

import os
import sys
import pyodbc
from npjet import *

def main():
  global cnxn
  cnxn = getDBConnectionSQLServer(Action.quietLevel)
  global cursor
  cursor = cnxn.cursor()

  try:
    cursor.execute("UPDATE $SQDB.$JOBEXECTABLE SET status_cd​='$RUNSTATUS', start_dttm='$JOBSTARTDTTM',finish_dttm='$JOBFINISHDTTM' WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND pipeLine_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME';")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  if (errorCode == 0):
    UPDATEOK()
    return
  print("""UPDATE OF JOB EXECUTION STATUS UNSUCCESSFUL""")
  Action.errorCodeOverride = 1
  return
def UPDATEOK():
  print("""UPDATE OF JOB EXECUTION STATUS SUCCESSFUL""")
  cnxn.commit()
  try:
    cursor.execute("DELETE FROM $SQDB.$JOBLOGTABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME';")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  if (errorCode == 0):
    DELLOGOK()
    return
  print("""DELETE FROM LOG TABLE UNSUCCESSFUL""")
  Action.errorCodeOverride = 1
  return
def DELLOGOK():
  print("""DELETE FROM LOG TABLE SUCCESSFUL""")
  cnxn.commit()
  try:
    cursor.execute("DELETE FROM $SQDB.$JOBSTAGETABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME';")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  if (errorCode == 0):
    DELSTAGEOK()
    return
  print("""DELETE FROM STAGE TABLE UNSUCCESSFUL""")
  Action.errorCodeOverride = 1
  return
def DELSTAGEOK():
  print("""DELETE FROM STAGE TABLE SUCCESSFUL""")
  cnxn.commit()
  try:
    cursor.execute("DELETE FROM $SQDB.$JOBLINKTABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME';")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  if (errorCode == 0):
    DELLINKOK()
    return
  print("""DELETE FROM LINK TABLE UNSUCCESSFUL""")
  Action.errorCodeOverride = 1
  return
def DELLINKOK():
  print("""DELETE FROM LINK TABLE SUCCESSFUL""")
  Action.errorCodeOverride = 0
  return

  cursor.close()
  cnxn.close()

main()
EOF
  BTEQ2_RC=$?
  echo "BTEQ2_RC: $BTEQ2_RC"
  exit $BTEQ2_RC 

else
  echo "*============================================================================" 
  echo "JOB HAS BEEN EXECUTED FOR CURRENT BATCH "                                      
  echo "JOB FINISHED SUCCESSFUL LAST RUN FOR CURRENT BATCH "                           
  echo "JOB EXECUTION WILL BE BYPASSED "                                               
  echo "RETURNING CONTROL TO JOB SEQUENCE"                                             
  echo "*============================================================================" 
  exit 2
fi 

rm $BTEQOUTFILE
echo "*==================================================================" 
echo "| BEFORE JOB EXECUTION BTEQ SCRIPT.#########                      *" 
echo "| `date +'%D %r'` END edw.bteq.before.ld.strt.status.sh           *" 
echo "*==================================================================" 

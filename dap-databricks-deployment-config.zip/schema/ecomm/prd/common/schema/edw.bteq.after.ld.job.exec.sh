#!/bin/ksh
#DIR="$(cd "$(dirname "$0")" && pwd)"
#. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Chirag Patel & Hal Hale
#  File name:        edw.bteq.after.ld.job.exec.sh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-05-2008
#         |                                           |  C Patel   |
#---------+-------------------------------------------+------------+-----------

DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

## SET SCRIPT PARAMETERS

SQSERVER=${1}
SQUSER=${2}
SQPWD=${3}
SQDB=${4}
EXECFILENAME=${5}
EXECTABLE=${6}
EDWBATCHID=${7}
DSPROJECT=${8}
DSJOBNAME=${9}
DSJOBINVOCATION=${10}
EXECBTEQOUT=${11}
LOGFILE=${12}

echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******                                                       *****" 
echo "*******       JOB Execution   Level logging to                *****" 
echo "*******                Process Control                        *****" 
echo "*******                                                       *****" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*==================================================================" 
echo "|                                                                 *" 
echo "| `date +'%D %r'` Start edw.bteq.after.ld.job.exec.sh       *" 
echo "|                                                                 *" 
echo "*==================================================================" 
echo " " 
echo "*=================================================================*" 
echo "| An attempt at executing  the job is complete.  The appropriate  *" 
echo "| job status will be recorded in the  Process Control table       *" 
echo "| (Job execution   Details).                                      *" 
echo "|                                                                 *" 
echo "*=================================================================*" 
echo "*************************************************************" 
echo "*  => DataStage Job Name= "$DSJOBNAME 
echo "*  => Job Invocation ID = "$DSJOBINVOCATION 
echo "*************************************************************" 
echo "*  =>SQDB           = "$SQDB 
echo "*  =>EXECFILENAME   = "$EXECFILENAME 
echo "*  =>EXECTABLE      = "$EXECTABLE 
echo "*  =>EDWBATCHID     = "$EDWBATCHID 
echo "*  =>DSPROJECT      = "$DSPROJECT 
echo "*  =>EXECBTEQOUT    = "$EXECBTEQOUT 
echo "*  =>LOGFILE        = "$LOGFILE 
echo "*************************************************************" 

## INITIATE BTEQ SESSION AND INSERT JOB EXEC DETAILS  FOR THE CURRENT JOB.



  python3 << EOF 
import os
import sys
import pyodbc
import pandas as pd
from IPython.display import display
from npjet import *


def main():

  global cnxn
  cnxn = getDBConnectionSQLServer(Action.quietLevel)
  global cursor
  cursor = cnxn.cursor()

  # Import CSV
  EXECFILEDATA = pd.read_csv ('$EXECFILENAME', sep='|', names=["projname", "batchid", "jobname", "jobinvocation", "jobstatus", "jobstartdttm", "jobfinishdttm"])   
  DF_EXECFILEDATA = pd.DataFrame(EXECFILEDATA)
  display(DF_EXECFILEDATA)

  # FormatOptions.echoReqLevel = EchoReqLevel.OFF
  # FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  # Action.exportFileName = "$EXECBTEQOUT"
  # ExportOptions.colLimit = 100
  # Action.charSet = "ISO-8859-1"
  # Action.importFileName = "$EXECFILENAME"
  # ImportOptions.type = "VARTEXT"
  # ImportOptions.separator ="|"
  # Action.repeatCount = None

  for row in DF_EXECFILEDATA.itertuples():
    cursor.execute("""
                UPDATE $SQDB.$EXECTABLE
                SET
                 proj_name=?,
                 edw_batch_id=?,
                 pipeLine_name=?,
                 job_invocation_id=?,
                 status_cd=?,
                 start_dttm=cast(? as datetime2),
                 finish_dttm=cast(? as datetime2)
                WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND pipeLine_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCATION'
                """,
                row.projname, 
                row.batchid,
                row.jobname,
                row.jobinvocation,
                row.jobstatus,
                row.jobstartdttm,
                row.jobfinishdttm
                )
  cnxn.commit()

  #-- LOCKING ROW FOR ACCESS 

  try:
    cursor.execute("SELECT count(*) FROM $SQDB.$EXECTABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND pipeLine_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCATION';")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  EXECBTEQOUT = cursor.fetchone()
  if (EXECBTEQOUT is None):
    EXECBTEQOUT=''
  else: 
    EXECBTEQOUT = EXECBTEQOUT[0]


  with open('$EXECBTEQOUT', 'w') as f:
    f.write(str(EXECBTEQOUT))
  return

  cursor.close()
  cnxn.close()
main()
EOF

BTEQ1_RC=$?
echo "BTEQ1_RC ="$BTEQ1_RC 

if [ $BTEQ1_RC -eq 1 ]
 then
  echo "*============================================================================" 
  echo "edw.bteq.after.ld.job.exec.sh JOB FAILED. PLEASE CHECK."                                                                             
  echo "*============================================================================" 
  exit 1
fi


## VERIFY JOB EXECUTION DETAILS HAVE BEEN INSERTED TO DATABASE
  if [ `cat $EXECBTEQOUT | tr -d ' '` = `cat $EXECFILENAME | wc -l | tr -d ' '` ]
    then
## CLEANUP
rm $EXECBTEQOUT;
rm $EXECFILENAME;
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******                                                       *****" 
echo "*******       JOB Execution   Level logging to                *****" 
echo "*******                Process Control                        *****" 
echo "*******                                                       *****" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*==================================================================" 
      echo "*==================================================================" 
      echo "|                          (Success)                               *" 
      echo "| `date +'%D %r'` Start edw.bteq.after.ld.job.exec.sh       *" 
      echo "|                                                                  *" 
      echo "*==================================================================" 
      exit 0;
    else
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******                                                       *****" 
echo "*******       JOB Execution   Level logging to                *****" 
echo "*******                Process Control                        *****" 
echo "*******                                                       *****" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*==================================================================" 
      echo "*==================================================================" 
      echo "|                          (Failed)                                *" 
      echo "| `date +'%D %r'` Start edw.bteq.after.ld.job.exec.sh       *" 
      echo "|                                                                  *" 
      echo "*==================================================================" 
      exit 1;
  fi


#!/bin/ksh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Hal Hale & Chirag Patel
#  File name:        edw.bteq.wrapper.get.parms.sh
#  Date:             04-18-2008
#  Description:      Execute generic DataStage sequence
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-01-2008
#         |                                           |  C Patel   |
#---------+-------------------------------------------+------------+-----------
#   1.1   |  Clean up conditional processing for      |  C Patel   | 07-14-2008
#         |  bad parateter return                     |            |
#---------+-------------------------------------------+------------+-----------
set -x
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
## SET SCRIPT PARAMETERS

SQCLIENTID=${1}
SQCLIENTSECRET=${2}
SQDB=${3}
PARMTABLE=${4}
DSPROJECT=${5}
DSJOBNAME=${6}
DSJOBINVOCATION=${7}
ENVIRONMENT=${8}
PARMBTEQOUT=${9}
LOGFILE=${10}


echo "*==================================================================" 
echo "| RETRIEVE PARAMETER LIST STARTED                                 *"  
echo "| `date +'%D %r'` STARTED edw.bteq.wrapper.get.parms.sh           *"  
echo "*=================================================================="  
echo " "  
echo "*=================================================================*"  
echo "| Retrieve the parameter name / parameter values pairs for a      *"  
echo "| DataStage Job.Invocation, within a DataStage project.           *"  
echo "|                                                                 *"  
echo "| If no parameter pairs are available for the specified job, an   *"  
echo "| empty string will be returned.                                  *"  
echo "|                                                                 *"  
echo "| For parameter pairs where the parameter name begins with a      *"  
echo "| dollar sign, the entire parameter pair will be put in double    *"  
echo "| quotes.                                                         *"  
echo "|                                                                 *"  
echo "| Note: the parameter name pEdwBatchId is a reserved name.  The   *"  
echo "|       parameter value will be replaced with the current Batch   *"  
echo "|       ID in the calling wrapper script.                         *"  
echo "*=================================================================*"  
echo "**************************************************"  
echo "* Application Specific Parameters                *"  
echo "**************************************************"  
echo "| TDDB               =$SQDB"  
echo "| PARMTABLE          =$PARMTABLE"  
echo "| DSPROJECT          =$DSPROJECT"  
echo "| DSJOBNAME          =$DSJOBNAME"  
echo "| DSJOBINVOCATION    =$DSJOBINVOCATION"  
echo "| ENVIRONMENT        =$ENVIRONMENT"  
echo "| PARMBTEQOUT        =$PARMBTEQOUT"  
echo "*=================================================================*"  
echo "| Retrieve the parameter name and parameter value pairs.          *"  
echo "*=================================================================*"  
echo "|"  
# INITIATE BTEQ SESSION AND INSERT SELECT LATEST BATCH ID AND BATCH STATUS DETAILS.

export SQDB
export PARMTABLE
export DSPROJECT
export DSJOBNAME
export DSJOBINVOCATION
export ENVIRONMENT
export PARMBTEQOUT


  python3 << EOF #>>$LOGFILE
import os
import sys
import pyodbc
from npjet import *


def sqlconn():
    cnxn = pyodbc.connect('Driver=$SQL_SERVER_DRIVER;'
                      'Server=$SQL_SERVER_NAME;'
                      'Database=$SQL_SERVER_DB;'
                      'UID=$SQCLIENTID;'
                      'PWD=$SQCLIENTSECRET;'
                      'Authentication=ActiveDirectoryServicePrincipal'
                     )
    return cnxn

def main():
  #-- LOCKING ROW FOR ACCESS 
  cnxn = sqlconn()
  cursor = cnxn.cursor()
  try:
    print("SELECT TRIM(parm_name)  as 'parm_name', parm_val  as 'param_val' FROM $TDDB.$PARMTABLE WHERE proj_name='$DSPROJECT' AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCATION' AND envrt='$ENVIRONMENT'")
    cursor.execute("SELECT TRIM(parm_name)  as 'parm_name', parm_val  as 'param_val' FROM $TDDB.$PARMTABLE WHERE proj_name='$DSPROJECT' AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCATION' AND envrt='$ENVIRONMENT' ORDER BY parm_name;") 
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]
  global PARMBTEQOUT
  global PARMBTEQOUTLIST
  PARMBTEQOUT = cursor.fetchall()
  if (PARMBTEQOUT is None):
    PARMBTEQOUTFILE=['']
  else:
    PARMBTEQOUTLIST = ['|'.join(val) for val in PARMBTEQOUT]
  print(PARMBTEQOUTLIST)
  #-- LOCKING - comment out locking clause
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (errorCode == 0):
   SELECTOK()
   return
  print("""SELECT JOB PARAMETERS FAILURE""")
  Action.errorCodeOverride = 1
  cursor.close()
  cnxn.close()
  return
def SELECTOK():
  print("""SELECT JOB PARAMETERS SUCCESS""")
  PARMBTEQOUTFILE = open('$PARMBTEQOUT', 'w')
  PARMBTEQOUTFILE.writelines("%s\n" % val for val in PARMBTEQOUTLIST)
  PARMBTEQOUTFILE.close()
  Action.errorCodeOverride = 0
  return

main()
EOF

RC=$?
if [ $RC -ne 0 ]
then
  echo "*==========================================================*"  
  echo "| *** PARAMETER RETRIEVAL FAILURE : RC=$RC                 *"  
  echo "*==========================================================*"  
  exit 1
else
  echo "*==========================================================*"  
  echo "| *** PARAMETER RETRIEVAL SUCCESS : RC=$RC                 *"  
  echo "*==========================================================*"  
fi

echo "*=================================================================="  
echo "| RETRIEVE PARMETER LIST FINISHED                                 *"  
echo "| `date +'%D %r'` FINISHED edw.bteq.wrapper.get.parms.sh          *"  
echo "*=================================================================="  
echo "|"
exit 0
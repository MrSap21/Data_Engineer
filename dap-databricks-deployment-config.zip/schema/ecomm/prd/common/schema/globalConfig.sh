#!/bin/ksh

# global environment variable, should be called in each shell script

# key vault
export KEY_VAULT_SECRET=true
export KEY_VAULT_SCOPE=dapdevdataenggscope
export KEY_VAULT_SQSCOPE=dapadbscope
export KEY_VAULT_SECRET_SFPASSWORD=dapdevsnowflakesecret
export KEYVAULTSECRET_SQLSERVERCLIENTID=sqldbapplicationid
export KEYVAULTSECRET_SQLSERVERCLIENTSECRET=devdnasqldb

# snowflake
export SF_USER_NAME=dev_rpu_dna_snowflake_1496
export SF_USER_PWD=dummy
export SF_ACCOUNT_NAME=wba_rpu_nprod_datainsight_01.east-us-2.privatelink
export SF_WAREHOUSE_NAME=WBADEVDBENGINEER_WH
export SF_DATABASE_NAME=dapdevdwh01
export SF_SCHEMA_NAME=prdetl
export SF_CONNECTION_STRING="jdbc:snowflake://wba_rpu_nprod_datainsight_01.east-us-2.privatelink.snowflakecomputing.com/"

# Sql Server
export SQL_SERVER_DRIVER="{ODBC Driver 17 for SQL Server}"
export SQL_SERVER_NAME=dapdevsqlsrv01.database.windows.net
export SQL_SERVER_DB=dapdevsqldb01


# path to storage
export EDWPROJ=ecomm
export EDWROOT=/dbfs/mnt/wrangled
export SCRIPTROOT=/dbfs/mnt/utility_main
#export EDWROOT=
export ENVR=prod

# path to dbfs
export DBFSROOT=/dbfs/FileStore/apps

export DATABRICKS_INSTANCE="https://adb-5346339970823458.18.azuredatabricks.net/api/2.0"
export GET_STAT_TIMEOUT=600
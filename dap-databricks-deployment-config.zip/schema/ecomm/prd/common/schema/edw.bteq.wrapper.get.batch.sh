#!/bin/ksh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Hal Hale & Chirag Patel
#  File name:        edw.bteq.wrapper.get.batch.sh
#  Date:             04-18-2008
#  Description:      Execute generic DataStage sequence
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-01-2008
#         |                                           |  C Patel   | 
#---------+-------------------------------------------+------------+-----------
#   1.1   |  Dedup log records                        |  C Patel   | 07-14-2008
#---------+-------------------------------------------+------------+-----------
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

SQCLIENTID=${1}
SQCLIENTSECRET=${2}
SQDB=${3}
BTCHTABLE=${4}
DSPROJECT=${5}
BTCHBTEQOUT=${6}

## SET SCRIPT PARAMETERS
echo "*=================================================================="
echo "| Get Batch ID Start                                              *" 
echo "|                                                                 *"
echo "| `date +'%D %r'` Start of edw.bteq.wrapper.get.batch.sh          *"
echo "|                                                                 *"
echo "*=================================================================="
echo " "
echo "*=================================================================*"
echo "| Retrieve the Cycle batch ID from the process control BATCH      *"
echo "| table.                                                          *"
echo "|                                                                 *"
echo "| If the last batch ID in the table is still active, the cycle    *"
echo "| will use this batch ID.                                         *"
echo "|                                                                 *"
echo "| If all batch IDs are closed, then create a new batch ID and     *"
echo "| insert it into the BATCH table.  This will be the batch ID      *"
echo "| used for the processing cycle.                                  *"
echo "*=================================================================*"
echo "**************************************************" 
echo "* Application Specific Parameters                *"
echo "**************************************************"
echo "| SQDB               =$SQDB"
echo "| BTCHTABLE          =$BTCHTABLE"
echo "| DSPROJECT          =$DSPROJECT"
echo "| BTCHBTEQOUT        =$BTCHBTEQOUT"
echo "*=================================================================*"
echo "| Retrieve the Cycle batch ID from the process control BATCH      *"
echo "| table.                                                          *"
echo "*=================================================================*"
echo "|"

export SQDB
export BTCHTABLE
export DSPROJECT
export BTCHBTEQOUT
## INITIATE BTEQ SESSION AND INSERT SELECT LATEST BATCH ID AND BATCH STATUS DETAILS.

python3 << EOF
import os
import sys
import pyodbc
from npjet import *

def sqlconn():
    cnxn = pyodbc.connect('Driver=$SQL_SERVER_DRIVER;'
                      'Server=$SQL_SERVER_NAME;'
                      'Database=$SQL_SERVER_DB;'
                      'UID=$SQCLIENTID;'
                      'PWD=$SQCLIENTSECRET;'
                      'Authentication=ActiveDirectoryServicePrincipal'
                     )
    return cnxn



def main():
  
  #-- LOCKING ROW FOR ACCESS
  cnxn = sqlconn()
  cursor = cnxn.cursor()
  try:
    cursor.execute("SELECT cast(edw_batch_id as varchar(100)) as 'edw_batch_id', batch_status_cd​ as 'batch_status_cd​' FROM $TDDB.$BTCHTABLE WHERE edw_batch_id=(SELECT MAX(edw_batch_id) FROM $TDDB.$BTCHTABLE WHERE proj_name='$DSPROJECT') AND proj_name='$DSPROJECT';") 
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]
  global BTCHBTEQOUT 
  BTCHBTEQOUT = cursor.fetchone()
  if (BTCHBTEQOUT is None):
    BTCHBTEQOUT=''
  else:
    BTCHBTEQOUT = '|'.join(map(str,BTCHBTEQOUT))
  if (errorCode == 0):
    SELECTOK()
    return
  print("""SELECT BATCH ID FAILURE""")
  Action.errorCodeOverride = 1
  cursor.close()
  cnxn.close()
  return

def SELECTOK():
  print("""SELECT BATCH ID SUCCESS""")
  with open('$BTCHBTEQOUT', 'w') as f:
    f.write(str(BTCHBTEQOUT))
  Action.errorCodeOverride = 0
  return
main()
EOF

RC=$?
if [ $RC -ne 0 ]
then
  echo "*======================================================*" 
  echo "| *** BATCH RETRIEVAL FAILURE : RC=$RC                 *" 
  echo "*======================================================*" 
  exit 1
else
  echo "*======================================================*" 
  echo "| *** BATCH RETRIEVAL SUCCESS : RC=$RC                 *" 
  echo "*======================================================*" 
fi

#------------------------------------------------------------------------------
## IF THE BATCH IS COMPLETE CREATE A NEW BATCH ID AND INSERT THE NEW RECORD ##
#------------------------------------------------------------------------------

BTCHSTAT=`cut -f2 -d'|' $BTCHBTEQOUT | tr -d ' '`

echo "BTCHSTAT: $BTCHSTAT"

if [ "$BTCHSTAT" = "0" ]
  then
  echo "*=================================================================*"
  echo "| ALL BATCH IDs HAVE BEEN COMPLETED                               *"
  echo "| CREATING A NEW BATCH ID AND INSERTING IT INTO THE PROCESS       *"
  echo "| CONTROL BATCH TABLE.                                            *"
  echo "*=================================================================*"
  echo "|"

  EDWBTCHID=`date +"%C%y%m%d%H%M%S"`;
  BTCHINCOMPLETE="1";
  export EDWBTCHID
  export BTCHINCOMPLETE

  python3 << EOF
import os
import sys
import pyodbc
from npjet import *

def sqlconn():
    cnxn = pyodbc.connect('Driver=$SQL_SERVER_DRIVER;'
                      'Server=$SQL_SERVER_NAME;'
                      'Database=$SQL_SERVER_DB;'
                      'UID=$SQCLIENTID;'
                      'PWD=$SQCLIENTSECRET;'
                      'Authentication=ActiveDirectoryServicePrincipal'
                     )
    return cnxn

def main():
  global cnxn 
  cnxn = sqlconn()
  cursor = cnxn.cursor()
  try:
    cursor.execute("INSERT INTO $SQDB.$BTCHTABLE (proj_name, src_stream_name, edw_batch_id, batch_status_cd​) VALUES ('$DSPROJECT', 'NA' ,'$EDWBTCHID', '$BTCHINCOMPLETE');") 
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  if (errorCode == 0):
    INSERTOK()
    return
  print("""INSERT BATCH ID FAILURE""")
  Action.errorCodeOverride = 1
  return
def INSERTOK():
  print("""INSERT BATCH ID SUCCESS""")
  cnxn.commit()
  Action.errorCodeOverride = 0
  return

main()
EOF

  RC=$?
  if [ $RC -ne 0 ]
  then
    echo "*======================================================*" 
    echo "| *** BATCH INSERT FAILURE : RC=$RC                    *" 
    echo "*======================================================*" 
    exit 1
  else
    echo "*======================================================*" 
    echo "| *** BATCH INSERT SUCCESS : RC=$RC                    *" 
    echo "*======================================================*" 
  fi

  print $EDWBTCHID > $BTCHBTEQOUT;
    
  echo "*=================================================================*"
  echo "| WRITE BATCH ID OUT TO A TEMPORARY FILE.                         *"
  echo "| USING BATCH ID = $EDWBTCHID                                     *"
  echo "*=================================================================*"
  echo "|"
  exit 0;
fi

if [ -f $BTCHBTEQOUT ] && [ -s $BTCHBTEQOUT ]
then
  echo "*=================================================================*"
  echo "| INCOMPLETE BATCH ID EXISTS.                                     *"
  echo "| USING AN ACTIVE BATCH ID.                                       *"
  echo "*=================================================================*"
  echo "|"

      EDWBTCHID=`cut -f1 -d"|" $BTCHBTEQOUT | tr -d ' '`;
      echo $EDWBTCHID > $BTCHBTEQOUT;

  echo "*=================================================================*"
  echo "| WRITE BATCH ID OUT TO A TEMPORARY FILE.                         *"
  echo "| USING BATCH ID = $EDWBTCHID                                     *"
  echo "*=================================================================*"
  echo "|"

else
  echo "*=================================================================*"
  echo "| BATCH ID NOT FOUND FOR THIS PROJECT.                            *"
  echo "| CREATING A NEW BATCH ID                                         *"
  echo "| INSERTING BATCH ID INTO THE BATCH PROCESS CONTROL TABLE.        *" 
  echo "*=================================================================*"
  echo "|"
  
  EDWBTCHID=`date +"%C%y%m%d%H%M%S"`;
  BTCHINCOMPLETE="1";
  export EDWBTCHID
  export BTCHINCOMPLETE

  python << EOF
import os
import sys
import pyodbc
from npjet import *

def sqlconn():
    cnxn = pyodbc.connect('Driver=$SQL_SERVER_DRIVER;'
                      'Server=$SQL_SERVER_NAME;'
                      'Database=$SQL_SERVER_DB;'
                      'UID=$SQCLIENTID;'
                      'PWD=$SQCLIENTSECRET;'
                      'Authentication=ActiveDirectoryServicePrincipal'
                     )
    return cnxn


def main(): 
  global cnxn 
  cnxn = sqlconn()
  cursor = cnxn.cursor()
  try:
    cursor.execute("INSERT INTO $SQDB.$BTCHTABLE (proj_name, src_stream_name, edw_batch_id, batch_status_cd​) VALUES ('$DSPROJECT', 'NA' , '$EDWBTCHID', '$BTCHINCOMPLETE')") 
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]
  if (errorCode == 0):
    INSERTOK()
    return
  print("""INSERT BATCH ID FAILURE""")
  Action.errorCodeOverride = 1
  return
def INSERTOK():
  print("""INSERT BATCH ID SUCCESS""")
  cnxn.commit()
  Action.errorCodeOverride = 0
  return

main()
EOF

    RC=$?
    if [ $RC -ne 0 ]
    then
        echo "*======================================================*" 
        echo "| *** BATCH INSERT FAILURE : RC=$RC                    *" 
        echo "*======================================================*" 
        exit 1
    else
        echo "*======================================================*" 
        echo "| *** BATCH INSERT SUCCESS : RC=$RC                    *" 
        echo "*======================================================*" 
    fi

      echo $EDWBTCHID > $BTCHBTEQOUT;

    echo "*=================================================================*"
    echo "| WRITE BATCH ID OUT TO A TEMPORARY FILE.                         *"
    echo "| USING BATCH ID = $EDWBTCHID                                     *"
    echo "*=================================================================*"
    echo "|"
fi

echo "*=================================================================="
echo "| RETRIEVE BATCH ID FINISHED"
echo "| `date +'%D %r'` FINISHED edw.bteq.wrapper.get.batch.sh"
echo "*=================================================================="
exit 0

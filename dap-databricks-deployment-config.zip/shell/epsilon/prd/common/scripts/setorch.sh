#----------------------------------------------------------------------------
#
# Script:	setorch.sh
# Syntax:	setorch.sh
# Date:         2009-08-11
# Author:       Vamshi Merugu 
# Description:	Set the necessary environmental variables and paths to have
#		access to the DataStage "orchadmin" utility.            
#
# Input Parms:	None.
# Output:	DataStage Orchestrate environment
# Limitations:	Users should not have an interactive login shell
#               ( no prompting ).
#
#----------------------------------------------------------------------------
# Date	   CR#		Name	       Description of Change
#----------------------------------------------------------------------------
#20090811      		Vamshi Merugu  Initial development.		
# 
#----------------------------------------------------------------------------
#set -xv					# Verbose Trace
# Do not overload as login performance will be slower.
#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

export DSHOME=/opt/IBM/InformationServer/Server/DSEngine
export APT_ORCHHOME=/opt/IBM/InformationServer/Server/PXEngine
. $DSHOME/dsenv

export LIBPATH=$LIBPATH:$APT_ORCHHOME/lib
export PATH=/opt/IBM/InformationServer/Server/DSEngine/bin:/opt/IBM/InformationServer/Server/PXEngine/bin:/usr/local/oracle/product/10.2/bin:/bin:/usr/bin:/etc:/usr/sbin:/usr/ucb:/usr/bin/X11:/sbin:/usr/local/bin:/home/dsadm/bin:/usr/local/Ascential/DataStage/DSEngine/scripts:.:$PATH
export APT_CONFIG_FILE=/opt/IBM/InformationServer/Server/Configurations/config4x4_edweps.apt
#export APT_CONFIG_FILE=/opt/IBM/InformationServer/Server/Configurations/default.apt
#clear
echo "================================================================="
echo "DataStage Engine ="$DSHOME
echo "Current APT_CONFIG ="$APT_CONFIG_FILE
echo "Orchestrate home ="$APT_ORCHHOME
echo "================================================================="

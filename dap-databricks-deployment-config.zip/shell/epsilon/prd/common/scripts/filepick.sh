#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

GetFiles()
{

	echo "GetFiles Function.." >> $LOG_FILE

	if [ ! -e ${DataFileDir}/${InsUpdFilePrefix}*${InsUpdFileSuffix} ];then

        echo "ERROR: Insert Update Files do not exist" >> $LOG_FILE
        exit 1
    fi



	NoOfMonths=`ls  ${DataFileDir}/${InsUpdFilePrefix}*${InsUpdFileSuffix}| cut -d"_" -f3 | sort -u | wc -l`

	echo "NoOfMonths=$NoOfMonths" >> $LOG_FILE

	if [ ${NoOfMonths} != 1 ];then
		echo "Error: Data directory ${DataFileDir} contains data files for more number of months" >> $LOG_FILE
		exit 1
	else
		EpsDataFileMonth=`ls  ${DataFileDir}/${InsUpdFilePrefix}*${InsUpdFileSuffix}| cut -d"_" -f3 | sort -u` 
		echo "Eps File Date is $EpsDataFileMonth"  >> $LOG_FILE
	fi


	NoOfFiles=`ls  ${DataFileDir}/${InsUpdFilePrefix}${EpsDataFileMonth}_*${InsUpdFileSuffix} | wc -l`
	if [ ${NoOfFiles} -ne 10 ];then
		echo "ERROR: Number of Insert/Update Data Files is ${NoOfFiles}. Should be 10." >> $LOG_FILE
		exit 1
	fi

	Year=`echo ${EpsDataFileMonth} | cut -c1-4`

	Month=`echo ${EpsDataFileMonth} | cut -c5-6`

	Day=`echo ${EpsDataFileMonth} | cut -c7-8`

	if [[ (${Year} -lt 2009) || (${Month} -gt 12) || (${Day} -gt 31) \
      		|| ((${Year}%4 -eq 0) && (${Month} -eq 2) && (${Day} -gt 29)) \
      		|| ((${Year}%4 -ne 0) && (${Month} -eq 2) && (${Day} -gt 28)) \
      		|| (((${Month} -eq 4) || (${Month} -eq 6) || (${Month} -eq 9) || (${Month} -eq 11)) && (${Day} -gt 30)) ]];then

        	echo "Error: Invalid Data in the file"
        	exit 1
	fi


	for FileNumber in  01 02 03 04 05 06 07 08 09 10 
	do
	
		FileToCheck=${DataFileDir}/${InsUpdFilePrefix}${EpsDataFileMonth}_${FileNumber}${InsUpdFileSuffix}

		if [[ ! -e $FileToCheck ]]; then
			echo "File ${FileToCheck} Doesn't Exist" >> $LOG_FILE
			exit 1
		fi
		
		#(( FileNumber = ${FileNumber}+1 ))

		
	done

	if  [ ! -e ${LastRunFileWithPath} ]; then
		echo "LAST RUN FILE ${LastRunFileWithPath} not found" >> $LOG_FILE
		exit 1
	fi

	for DatFile in `ls  ${DataFileDir}/${InsUpdFilePrefix}*${InsUpdFileSuffix} | awk -F"/" '{print $NF}'`
	do

		echo "DatFile=$DatFile" >> $LOG_FILE
		Junk=`grep -i $DatFile ${LastRunFileWithPath}`

		RC_GREP=$?

		if [ ${RC_GREP} -eq 0 ];then
			echo "ERROR: DatFile $DatFile was already loaded." >> $LOG_FILE
			exit 1
		elif [ ${RC_GREP} -ne 1 ];then
			echo "ERROR: grep failed while checking for Data File in ${LastRunFileWithPath}." >> $LOG_FILE
			exit 1
		fi

	done

	if [ ! -e ${DataFileDir}/${DeleteFilePrefix}*${DeleteFileSuffix} ];then

		echo "ERROR: Delete File doesn't exist" >> $LOG_FILE
		exit 1
	fi

	NoOfDelFiles=`ls  ${DataFileDir}/${DeleteFilePrefix}*${DeleteFileSuffix} | wc -l`


	if [ $NoOfDelFiles -ne 1 ];then

		echo "ERROR: Number of delete files is not equal to 1" >> $LOG_FILE
		exit 1

	fi


	DeleteFile=`ls  ${DataFileDir}/${DeleteFilePrefix}*${DeleteFileSuffix} | awk -F/ '{print $NF}'`
	echo "Delete File is $DeleteFile" >> $LOG_FILE

	JunkDel=`grep -i ${DeleteFile}  ${LastRunFileWithPath}`

	RC_GREP2=$?
	if [ ${RC_GREP2} -eq 0 ];then
		echo "ERROR: DeleteFile ${DeleteFile} was already loaded." >> $LOG_FILE
		exit 1
	elif [ ${RC_GREP2} -ne 1 ];then
		echo "ERROR: grep failed while checking for DeleteFile in ${LastRunFileWithPath}." >> $LOG_FILE
		exit 1
	fi

# Writing the Deletes Data File and Month of Insert/update Files to a temporary file.

	echo "$DeleteFile" > ${DeleteFileDat}
	echo "$EpsDataFileMonth" > ${InsUpdMonthFileDat}
}

##################################
# 		MAIN		 #
##################################

LOG_FILE=$1
DataFileDir=$2
LastRunFileWithPath=$3
InsUpdFilePrefix=$4
InsUpdFileSuffix=$5
DeleteFilePrefix=$6
DeleteFileSuffix=$7
DeleteFileDat=$8
InsUpdMonthFileDat=$9


#DataFileDir="/usr/local/cdi/cdixedw/ref"
#DataFileDir="/usr/local/edw/epsilon/tst/temp/DataDir"
#LastRunFileWithPath="/usr/local/edw/epsilon/${ENVR}/common/config/LASTRUNFILE.DAT"
#FilePattern="walgreens_install_????????_??.csv"
#InsUpdFilePrefix="walgreens_install_"
#InsUpdFileSuffix=".csv"
#DeleteFilePrefix="ref_escons_delete_toedw"
#DeleteFileSuffix=".dat"


GetFiles

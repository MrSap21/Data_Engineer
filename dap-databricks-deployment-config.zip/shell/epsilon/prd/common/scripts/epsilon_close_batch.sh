#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Hal Hale & Chirag Patel
#  File name:        edw.bteq.wrapper.close.batch.sh
#  Date:             04-18-2008
#  Modified By:      Suraj( For EDW CDI)
#  Date:             02-26-2009 
#  Description:      Update the batch status for the current / latest batch id
#                    to be of COMPLETED status from INCOMPLETED status
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-01-2008
#         |                                           |  C Patel   | 
#---------+-------------------------------------------+------------+-----------

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDStageDB=${4}
TDDBVW=${5}
TDDB=${6}
LOGFILE=${7}
BATCHID=${8}
CREATEDTTM=${9}
RUNDTTM=${10}
RECYCLEFLAG=${11}


DS_PROJECT="Edw_eps_prd"
ESP_CYCLE_ID=$2

#BADLOG_FILE=$APP_ROOT/audit/NOPROJECT.CloseBatch.log.`date +%m%d%H%M`
#BADERR_FILE=$APP_ROOT/audit/NOPROJECT.CloseBatch.err.`date +%m%d%H%M`

if [ "X"$DS_PROJECT = "X" ]
then
        DS_PROJECT="MISSING"
fi

if [ $DS_PROJECT = "MISSING" ]
then
        echo "***********************************************************" >> $BADLOG_FILE
        echo "* `date +'%D %r'` Missing project name argumant, RC=$RC" >> $BADLOG_FILE
        echo "***********************************************************" >> $BADLOG_FILE
        exit 1;
fi

#------------------------------------------------------------------#
# Set up the environment.                                          #
#     Read the parameter file and export the necessary             #
#     environmental variables.                                     #
#                                                                  #
#     Once the environmental variables are set up, delete the      #
#     temporary file used in the process (PARMRUN).                #
#------------------------------------------------------------------#

if [[ `uname -n` == "da1sia-pfa008" ]]
then
        ENVR="tst02"
else
        ENVR="prd"
fi

. /usr/local/edw/epsilon/${ENVR}/common/scripts/edw_epsilon_config.ksh $DS_PROJECT

LOG_FILE=$APP_ROOT/audit/$DS_PROJECT.CloseBatch.log.`date +%m%d%H%M`
ERR_FILE=$APP_ROOT/audit/$DS_PROJECT.CloseBatch.err.`date +%m%d%H%M`

echo "*==================================================================" >> $LOG_FILE
echo "| CLOSE Batch ID Status                                            *" >> $LOG_FILE
echo "|                                                                 *" >> $LOG_FILE
echo "| `date +'%D %r'` STARTED edw.bteq.wrapper.close.batch.sh          *" >> $LOG_FILE
echo "|                                                                 *" >> $LOG_FILE
echo "*==================================================================" >> $LOG_FILE
echo " " >> $LOG_FILE


echo "**************************************************" >> $LOG_FILE
echo "* edw.bteq.wrapper.close.batch.sh Specific Parameters " >> $LOG_FILE
echo "**************************************************" >> $LOG_FILE
echo "| TD_SERVER          =$TD_SERVER" >> $LOG_FILE
echo "| TD_USER            =$TD_USER" >> $LOG_FILE
echo "| TD_PASSWORD        =xxxxxxxx" >> $LOG_FILE
echo "| TD_PROCCTL_DATABASE=$TD_PROCCTL_DATABASE" >> $LOG_FILE
echo "| TD_BATCHTABLE      =$TD_BATCHTABLE" >> $LOG_FILE
echo "| DS_PROJECT         =$DS_PROJECT" >> $LOG_FILE

## INITIATE BTEQ SESSION AND INSERT SELECT LATEST BATCH ID AND BATCH STATUS DETAILS.

  python3 << EOF >> $LOG_FILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.ON
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  executeSql([], [
    ("""begin transaction""",
    [])
  ])
  #-- TRANS_CONTROL - Convert BT to BEGIN TRANSACTION
  executeSql([], [
    ("""UPDATE $TD_PROCCTL_DATABASE.$TD_BATCHTABLE SET btch_stat='0' WHERE edw_batch_id=(SELECT MAX(edw_batch_id) 
  FROM $TD_PROCCTL_DATABASE.$TD_BATCHTABLE where btch_stat='1' AND proj_name='$DS_PROJECT') and proj_name='$DS_PROJECT'""",
    [])
  ])
  executeSql([], [
    ("""commit""",
    [])
  ])
  #-- TRANS_CONTROL - Convert END TRANSACTION/ET to COMMIT
  if (Action.activityCount != 1):
    UPDFAILED()
    return
  Action.errorCodeOverride = 0
  return
  UPDFAILED()
def UPDFAILED():
  Action.errorCodeOverride = 1
  return

main()
cleanup()
done()
EOF

echo "*==================================================================" >> $LOG_FILE
echo "| CLOSE Batch ID Status                                              *" >> $LOG_FILE
echo "|                                                                 *" >> $LOG_FILE
echo "| `date +'%D %r'` FINISHED edw.bteq.wrapper.close.batch.sh          *" >> $LOG_FILE
echo "|                                                                 *" >> $LOG_FILE
echo "*==================================================================" >> $LOG_FILE
echo " " >> $LOG_FILE
exit 0

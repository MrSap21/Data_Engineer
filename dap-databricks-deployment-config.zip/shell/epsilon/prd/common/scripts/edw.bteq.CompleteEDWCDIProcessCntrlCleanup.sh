#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Suraj K        
#  File name:        edw.bteq.cleanup.sh
#  Date:             07162008
#  Description:      Clean up Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#  
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------
#  
#---------+-------------------------------------------+------------+-----------

## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDDB=${4}
DSPROJECT=${5}
LOGPATH=${6}

## Initializing Process Log file
touch ${LOGPATH}/${DSPROJECT}_CompletePrcsCntrlCleanUp.log
LOGFILE=${LOGPATH}/${DSPROJECT}_CompletePrcsCntrlCleanUp.log
>$LOGFILE

echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Complete Clean up process starting for         *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "| `date +'%D %r'` STARTED CompleteEDWPhotoProcessCntrlCleanup.sh  *" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo " "                                                                   >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  => DataStage Project Name= "$DSPROJECT                            >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  =>TDSERVER       = "$TDSERVER                                     >> $LOGFILE
echo "*  =>TDUSER         = "$TDUSER                                       >> $LOGFILE
echo "*  =>TDPWD          = "$TDPWD                                        >> $LOGFILE
echo "*  =>TDDB           = "$TDDB                                         >> $LOGFILE
echo "*  =>DSPROJECT      = "$DSPROJECT                                    >> $LOGFILE
echo "*  =>LOGFILE        = "$LOGFILE                                      >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE


## INITIATE BTEQ SESSION

python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.ON
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  executeSql([], [
    ("""delete from $TDDB.proc_cntrl_job_exec_detail
where 
proj_name='$DSPROJECT'""",
    [])
  ])
  if (Action.errorCode == 0):
    Step2()
    return
  print("""Deletion of data from proc_cntrl_job_exec_detail unsuccessful""")
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  Step2()
def Step2():
  executeSql([], [
    ("""delete from $TDDB.proc_cntrl_job_link_detail
where 
proj_name='$DSPROJECT'""",
    [])
  ])
  if (Action.errorCode == 0):
    Step3()
    return
  print("""Deletion of data from proc_cntrl_job_link_detail unsuccessful""")
  Action.exportFileName = None
  Action.errorCodeOverride = 2
  return
  Step3()
def Step3():
  executeSql([], [
    ("""delete from $TDDB.proc_cntrl_job_log_detail
where 
proj_name='$DSPROJECT'""",
    [])
  ])
  if (Action.errorCode == 0):
    Step4()
    return
  print("""Deletion of data from proc_cntrl_job_log_detail unsuccessful""")
  Action.exportFileName = None
  Action.errorCodeOverride = 3
  return
  Step4()
def Step4():
  executeSql([], [
    ("""delete from $TDDB.proc_cntrl_job_stage_detail
where 
proj_name='$DSPROJECT'""",
    [])
  ])
  if (Action.errorCode == 0):
    Success()
    return
  print("""Deletion of data from proc_cntrl_job_stage_detail unsuccessful""")
  Action.exportFileName = None
  Action.errorCodeOverride = 4
  return
  Success()
def Success():
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

RC=${?}

if [ ${RC} == 0 ]
then
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******              Clean up process for                     *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                        ( SUCCESS )                              *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED edw.bteq.cleanup.sh                    *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
exit 0
else 
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******              Clean up process for                     *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                      (FAILED)                                   *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED edw.bteq.cleanup.sh                    *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
ech0 "|                                                                 *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
exit 1;
fi
  



#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
LOGFILE="/usr/local/edw/epsilon/prd/common/scripts/eps_table_correction.log"
  
python3 << EOF > $LOGFILE 2>&1
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.ON
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  executeSql([], [
    ("""Update
 prdedwdb.external_epsilon
Set end_dt = '9999-12-31',
update_batch_id = NULL,
update_dttm = NULL
Where   update_batch_id = 20100202104747""",
    [])
  ])
  if (Action.errorCode != 0):
    Failure()
    return
  Success()
def Success():
  print("""BTEQ has completed successfully""")
  Action.exportFileName = None
  return
  Failure()
def Failure():
  print("""BTEQ has terminated abnormally""")
  Action.exportFileName = None
  return

main()
cleanup()
done()
EOF

RC=${?}

if [ ${RC} == 0 ]
then
echo "Updated" >> $LOGFILE
exit 0
else 
echo "Failedi" >> $LOGFILE
exit 1;
fi
  



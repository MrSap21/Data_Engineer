# Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           VAMSHI M 
#  File name:        MLOAD
#  Date:             
#  Description:      MLOAD INITIAL INSERT EPSILON TABLE
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y   
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |            | 
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------
# 
#---------+-------------------------------------------+------------+-----------

## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDDB=${4}
EDWBATCHID=${5}
LOGFILE=${6}
TABLENAME=${7}
WORKDB=${8}
SOURCEDIR=${9}
SOURCEFILE=${10}
EFF_DT=${11}

export EDWBATCHID
echo $EDWBATCHID >$LOGFILE
echo $TABLENAME >>$LOGFILE
echo $FILENAME >>$LOGFILE

echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  => DataStage Job Name= "$DSJOBNAME                                >> $LOGFILE
echo "*  => Job Invocation ID = "DSJOBINVOCATION                           >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  =>TDSERVER       = "$TDSERVER                                     >> $LOGFILE
echo "*  =>TDUSER         = "$TDUSER                                       >> $LOGFILE
echo "*  =>TDPWD          = xxxxxxxx"                                      >> $LOGFILE
echo "*  =>TDDB           = "$TDDB                                         >> $LOGFILE
echo "*  =>LOGDTLFILENAME = "$LOGDTLFILENAME                               >> $LOGFILE
echo "*  =>LOGDTLTABLE    = "$LOGDTLTABLE                                  >> $LOGFILE
echo "*  =>EDWBATCHID     = "$EDWBATCHID                                   >> $LOGFILE
echo "*  =>DSPROJECT      = "$DSPROJECT                                    >> $LOGFILE
echo "*  =>LOGBTEQOUT     = "$LOGBTEQOUT                                   >> $LOGFILE
echo "*  =>LOGFILE        = "$LOGFILE                                      >> $LOGFILE
echo "*  =>SOURCEFILE     = "$SOURCEFILE                                   >> $LOGFILE
echo "*  =>EFF_DT         = "$EFF_DT                                       >> $LOGFILE

## INITIATE MLOAD SESSION AND INSERT ##

python3 << EOF >> $LOGFILE
#!/usr/bin/python3

from npjet import *

def main():
  # Missing multiset configuration, for table: $TABLENAME, will default to no duplicates
  LoadOptions.ignoreMissingUpdate = "FIXME"
  LoadOptions.importFileName = "${SOURCEDIR}/${SOURCEFILE}"
  LoadOptions.delimiter = "|"
  LoadOptions.targetTableName = "$TDDB.$TABLENAME"
  LoadOptions.uploadTableName = "$WORKDB.Eps_insert_err2"
  LoadOptions.stageName = "DIRECT_UPLOAD_$TDDB_$TABLENAME"
  runSql("""CREATE TEMPORARY STAGE IF NOT EXISTS """ + LoadOptions.stageName)
  if Action.errorCode != 0:
    return
  runSql("""PUT 'file://""" + LoadOptions.importFileName + """' '@""" + LoadOptions.stageName + """' parallel=10 overwrite=true""")
  if Action.errorCode != 0:
    return
  runSql("""CREATE TABLE """ + getTable(LoadOptions.uploadTableName) + """ LIKE """ + getTable(LoadOptions.targetTableName) + """""")
  if Action.errorCode != 0:
    return
  # featureNotSupported(Expecting field reference, found expression: stringLiteral('${EFF_DT}'))

if __name__ == '__main__':
  main()
  cleanup()
  done()

EOF
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                        ( SUCCESS )                              *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED MLOAD                                  *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
exit 0;
    else
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                      (FAILED)                                   *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED MLOAD                                  *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|  Process will continue to the next step.  Notice that records   *" >> $LOGFILE
ech0 "|  may have been dropped due to duplicate records in source data. *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
      exit 1;
  fi
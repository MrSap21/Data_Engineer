#!/bin/ksh

#---------+-------------------------------------------+------------+-----------
# Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:
#  File name:        MLOAD
#  Date:
#  Description:      MLOAD SCRIPT TO LOAD THE INSERTS/UPDATES.
#                    UPSERT IS PERFORMED.
#
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |VR MADIRAJU |05-MAR-2010
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------
#
#---------+-------------------------------------------+------------+-----------

# ref_escons_delete_toedw.20100212.7.dat
TDServer=$1
TDUser=$2
TDPass=$3
TDStage=$4
TDDb=$5
LogFile=$6
EdwBatchId=$7
DataFileDir=$8
LastRunFileWithPath=$9
InsUpdFilePrefix=${10}
InsUpdFileSuffix=${11}
DeleteFilePrefix=${12}
DeleteFileSuffix=${13}
DeleteFileDat=${14}
InsUpdMonthFileDat=${15}


echo "TD-Server                 =$TDServer"             >> $LogFile
echo "TD-User                   =$TDUser"               >> $LogFile
echo "TDStage                   =$TDStage"              >> $LogFile
echo "TDDb                      =$TDDb"                 >> $LogFile
echo "LogFile                   =$LogFile"              >> $LogFile
echo "EdwBatchId                =$EdwBatchId"           >> $LogFile
echo "DataFileDir               =$DataFileDir"          >> $LogFile
echo "LastRunFileWithPath       =$LastRunFileWithPath"  >> $LogFile
echo "InsUpdFilePrefix          =$InsUpdFilePrefix"     >> $LogFile
echo "InsUpdFileSuffix          =$InsUpdFileSuffix"     >> $LogFile
echo "DeleteFilePrefix          =$DeleteFilePrefix"     >> $LogFile
echo "DeleteFileSuffix          =$DeleteFileSuffix"     >> $LogFile
echo "DeleteFileDat             =$DeleteFileDat"        >> $LogFile
echo "InsUpdMonthFileDat        =$InsUpdMonthFileDat"   >> $LogFile


python3 << EOF >> $LogFile
#!/usr/bin/python3

from npjet import *

def main():
  DBASE_ETTABLE = "$TDStage"
  DBASE_TARGETTABLE = "$TDDb"
  DBASE_WORKTABLE = "$TDStage"
  DBASE_UVTABLE = "$TDStage"
  TARGETTABLE = "external_epsilon"
  # Missing multiset configuration, for table: TARGETTABLE, will default to no duplicates
  LoadOptions.ignoreMissingUpdate = "FIXME"
  LoadOptions.importFileName = "${DataFileDir}/${DeleteFileDat}"
  LoadOptions.delimiter = ","
  LoadOptions.workTableName = f"{DBASE_WORKTABLE}..WT_DEL_{TARGETTABLE}"
  runSql(f"""CREATE TABLE {DBASE_WORKTABLE}..WT_DEL_{TARGETTABLE} (
  agility_key_indv VARCHAR(50),
  agility_key_indv_raw VARCHAR(50),
  "$__ID__$" BIGINT IDENTITY
)
""")
  if Action.errorCode != 0:
    return
  runSql("""CREATE TEMPORARY STAGE IF NOT EXISTS """ + LoadOptions.workTableName)
  if Action.errorCode != 0:
    return
  runSql("""PUT 'file://""" + LoadOptions.importFileName + """' '@""" + LoadOptions.workTableName + """' parallel=10 overwrite=true""")
  if Action.errorCode != 0:
    return
  runSql("""COPY INTO """ + getTable(LoadOptions.workTableName) + " (agility_key_indv)" + """
FROM(
  SELECT
    $1
  FROM @""" + LoadOptions.workTableName + """
) FILE_FORMAT = (
  TYPE=CSV
  ENCODING='""" + LoadOptions.inputCharset + """'
  FIELD_DELIMITER='""" + LoadOptions.delimiter + """'
  TRIM_SPACE=TRUE
 """ + getFieldQuote() + """
)
 """ + LoadOptions.sfErrorHandler + """
  ENFORCE_LENGTH=FALSE""")
  if Action.errorCode != 0:
    return
  runSql("""select * from table(validate(""" + getTable(LoadOptions.workTableName) + """, job_id => '_last'))""")
  if Action.errorCode != 0:
    return
  if Action.activityCount >= LoadOptions.maxErrorCount:
    nprint("maxErrorCount reached. Raising error ", Action.quietLevel)
    setErrorCode(3706)
  runSql(""" DROP STAGE """ + LoadOptions.workTableName)
  if Action.errorCode != 0:
    return
  runSql(f"""DELETE FROM {DBASE_WORKTABLE}..WT_DEL_{TARGETTABLE}
WHERE "$__ID__$" NOT IN (
  SELECT MIN("$__ID__$")
  FROM {DBASE_WORKTABLE}..WT_DEL_{TARGETTABLE}
  GROUP BY agility_key_indv
)""")
  if Action.errorCode != 0:
    return
  runSql(f"""MERGE INTO {DBASE_TARGETTABLE}..{TARGETTABLE} AS d
 USING {DBASE_WORKTABLE}..WT_DEL_{TARGETTABLE} AS s
 ON d.agility_key_indv = s.agility_key_indv
WHEN MATCHED THEN UPDATE SET
  end_dt = CURRENT_DATE-1,
  update_dttm = CURRENT_TIMESTAMP(0),
  update_batch_id = d.${EdwBatchId}
""")
  if Action.errorCode != 0:
    return
  runSql(f"""DROP TABLE {DBASE_WORKTABLE}..WT_DEL_{TARGETTABLE}""")
  if Action.errorCode != 0:
    return

if __name__ == '__main__':
  main()
  cleanup()
  done()

EOF

MLOAD2_RC=$?

if [ $MLOAD2_RC -eq 0 ];then

    echo ${DeleteFileDat} " " ${EdwBatchId} >> ${LastRunFileWithPath}

fi
exit $MLOAD2_RC



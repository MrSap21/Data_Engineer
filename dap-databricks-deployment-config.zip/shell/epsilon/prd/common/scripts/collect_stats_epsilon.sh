#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.                        #
#           Licensed Material - Program - Property of Walgreen Co.             #
#                             All Rights Reserved                              #
#------------------------------------------------------------------------------#
#  Author:           Dawn Issac Sam                                            #
#  File name:        edw.bteq.table.partitioning.ksh                           #
#  Date:             07-28-2008                                                #
#  Description:      Passes parameter for Wag_Batch_DDL to collect statistics  #
#                    all EDW CDI PROJECT tables.                               #
#------------------------------------------------------------------------------#
#                      M A I N T E N A N C E   H I S T O R Y                   #
#------------------------------------------------------------------------------#
# Revision|                Description                |    Name    | Date      #
#---------+-------------------------------------------+------------+-----------#
#   1.0   |  Initial release.                         |  D Sam     | 07-28-2008#
#---------+-------------------------------------------+------------+-----------#

#---------------------------------------------------#
#         Parameters used in the job                #
#---------------------------------------------------#
 
DS_PROJECT=$1
ESP_CYCLE_ID=$2
STATISTICSTABLE=statistics_tables
PARTITIONTABLES=partition_tables
#------------------------------------------------------------------#
# SET UP THE ENVIRONMENT.                                          #
#     Read the parameter file and EXPORT the necessary             #
#     environmental variables.                                     #
#                                                                  #
#     Once the environmental variables are set up, delete the      #
#     temporary file used in the process (PARMRUN).                #
#------------------------------------------------------------------#
				
if [[ `uname -n` == "da1sia-pfa008" ]]
then
        ENVR="tst02"
else
        ENVR="prd"
fi
. /usr/local/edw/epsilon/${ENVR}/common/scripts/edw_epsilon_config.ksh $DS_PROJECT    

echo $XX_DB_SQLCONNECT
LOGDIRECTORY=$APP_ROOT/audit
echo $APP_ROOT/audit
LOGFILE=$LOGDIRECTORY/weekly.partitioning.`date +%m%d%H%M%S`.log


######################################################################################
###   Collecting Statistics on EDW CDI tables                                     ##
######################################################################################
echo "*=================================================================*" >> $LOGFILE
echo "| Initiating Bteq session....                                     *" >> $LOGFILE
echo "| The Bteq queries populates a file with the list of tables       *" >> $LOGFILE
echo "|for which statistics are to be collected.                        *" >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE

$WAG_BATCH_DDL -t external_epsilon -f table_stats >>$LOGFILE 2>> $LOGFILE 
STAT_RC1=$?
echo "*Collected statistics for external_epsilon with Return Code= $STAT_RC1 *" >>$LOGFILE 

$WAG_BATCH_DDL -t external_aarp  -f table_stats >>$LOGFILE 2>> $LOGFILE 
STAT_RC4=$?
echo "*Collected statistics for external_aarp with Return Code= $STAT_RC4 *" >>$LOGFILE
#exit 0

$WAG_BATCH_DDL -t epsilon_closest_competitor_str -f table_stats >>$LOGFILE 2>> $LOGFILE 
STAT_RC2=$?
echo "*Collected statistics for epsilon_closest_competitor_str with Return Code= $STAT_RC2 *" >>$LOGFILE  

$WAG_BATCH_DDL -t epsilon_closest_wag_store  -f table_stats >>$LOGFILE 2>> $LOGFILE 
STAT_RC3=$?
echo "*Collected statistics for epsilon_closest_wag_store with Return Code= $STAT_RC3 *" >>$LOGFILE  


#echo "*Collected statistics for $STAT_TBL_NM with Return Code= $STAT_RC *" >>$LOGFILE  
echo "*                                                                 *" >>$LOGFILE
echo "*=================================================================*" >> $LOGFILE
echo "|       Script completed successfully!!                           *" >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE

exit 0

#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

#---------+-------------------------------------------+------------+-----------
# Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:
#  File name:        EPS_DIST_FILE_GEN.sh
#  Date:
#  Description:      FAST EXPORT SCRIPT TO EXPORT THE ACTIVE RECORDS
#                    
#
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |VR MADIRAJU |15-MAR-2010
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------
#
#---------+-------------------------------------------+------------+-----------

## SET SCRIPT PARAMETERS

TDServer=$1
TDUser=$2
TDPass=$3
TDStage=$4
TDDb=$5
LogFile=$6
EdwBatchId=$7
ExpDistFileWithPath=$8


echo "TD-Server					=$TDServer" 			>> $LogFile
echo "TD-User					=$TDUser" 				>> $LogFile
echo "TDStage					=$TDStage" 				>> $LogFile
echo "TDDb						=$TDDb" 				>> $LogFile
echo "LogFile					=$LogFile" 				>> $LogFile
echo "EdwBatchId				=$EdwBatchId" 			>> $LogFile
echo "ExpDistFileWithPath		=$ExpDistFileWithPath" 	>> $LogFile

python3 << EOF >> $LogFile
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  sql = """SELECT		trim(agility_key_indv) || '|' || translate(to_char(latitude , '00000.000000'), ' ', '')  || '|' ||  translate(to_char(longitude , 'MI00000.000000'), ' ', '')  ::char(40)
FROM 		${TDDb}.external_epsilon
WHERE		latitude is not null
and			longitude is not null
and			end_dt='9999-12-31'"""
  cursor = executeFStmt(sql, [])
  exportResult = executeFExport(f"""${ExpDistFileWithPath}""", cursor)
  if exportResult != True:
    return
  #-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
  #-- FUN_CAST_OPTR - Reformat casting
  FormatOptions.format = "OFF"
  return

main()
cleanup()
done()
EOF

FEXP_RC2=$?

exit $FEXP_RC2

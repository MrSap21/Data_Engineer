#!/bin/ksh
cleanup() {
  [[ -f $LOG_FILE ]] && cp $LOG_FILE $AUDIT_DIR && rm $LOG_FILE
}
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------------------
# Author:               Manish Garg
# File Name:            edw_InputFileMovement.sh
# Parameters:           EDWBatchId.
# Called from:  None
# Purpose:              This Script will Move files from Inbound to ftp directory.
#---------------------------------------------------------------------------------------------
#                       MAINTENANCE HISTORY
#---------------------------------------------------------------------------------------------
#       Revision                Description             Name                            Date
#---------------------------------------------------------------------------------------------
#        1.0                  Initial Version                 Manish Garg          19-Jun-2009
#        2.0               GQM Phase 2 Changes(POMS)          Lakshmi Narayana     05-May-2017
#                                                             Sathiyaprathiba N
#                                                             Krishnakarthik K
#        3.0                  Backup Src Files                Rakesh Andotra       20-Sep-2018
#        4.0              SS MicroServices Extract Changes    Naresh Nuvula        15-Mar-2019
#                                                             Prakash M
#                                                             Manohar P
#        5.0              POMS Mail order Migration          Sathiyaprathiba N      17-Jul-2019
#        6.0              Master Feed MS File Rename Changes  Naresh Nuvula         20-Aug-2019
#                                                             Prakash M
#----------------------------------------------------------------------------------------------

# if [[ $(uname -n) == "da1nia-pfa003" ]]; then
#   export APP_ENV="dev"
# else
#   export APP_ENV="prd"
# fi

export APP_ENV="prd"
EDWBatchId="$1"
DS_PROJECT="$2"
NoOfParm="$#"
. $EDWROOT/usr/local/edw/ecomm/${APP_ENV}/common/scripts/edw_ecomm_config.ksh $DS_PROJECT
AUDIT_DIR=$EDWROOT$APP_ROOT/audit
FTP_DIR=$EDWROOT$APP_ROOT/ftp
ARCH_DIR=$EDWROOT$APP_ROOT/archive
BKUP_DIR=$EDWROOT$APP_ROOT/archive/src_daily_bkup
INBOUND_DIR=$EDWROOT$APP_ROOT/inbound
LOG_FILE=/tmp/${EDWBatchId}_InpFileMov_LOGFile.log
exec >$LOG_FILE 2>&1
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************edw_ecomm_InputFileMovement.sh initiated***************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE
echo "Batch Id used is " $EDWBatchId >>$LOG_FILE
echo "Project Name is " $DS_PROJECT >>$LOG_FILE
echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "*********************To Check the number of Parameters passed******************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE
if [ $NoOfParm -ne 2 ]; then
  echo "--------USAGE-------------------------------------" >>$LOG_FILE
  echo "  $0  <EDWBatchId> <DS Project Name>" >>$LOG_FILE
  echo "---------------------------------------------------" >>$LOG_FILE
  echo " Wrong Number of Parameters passed. No File is Copied. Exiting the Script " >>$LOG_FILE
  cleanup
  exit 1
fi

echo "Parameter Validation is Successful" >>$LOG_FILE

cd $APP_DIR_INPUT

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "****************To Get The Least Date Pattern from POMS MAIL Trigger File********************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

filecount=$(ls -l POMS_MAIL_*.trg | wc -l)
if [ $filecount -ne 0 ]; then
  PATSTR=$(ls -1 POMS_MAIL_*.trg | awk '{ FS="_" ; print $3 }' | awk '{ FS="." ; print $1}' | sort -n | head -1)
  echo "Least Date Pattern identified from POMS Mail trigger file is " $PATSTR >>$LOG_FILE
else
  echo "POMS Mail trigger file is not present. Exiting the Script." >>$LOG_FILE
  cleanup
  exit 1
fi

echo "**************************************************************************************" >>$LOG_FILE
#-------------- GQM Phase 2 Changes - New source for Photo files POMS is added here ----------------#
echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************To Move the Least Date POMS Extract********************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

filecount=$(ls -l POMS_$PATSTR.trg | wc -l)
if [ $filecount -ne 0 ]; then
  filecount_POMS=$(ls -l POMS_$PATSTR.zip | wc -l)
  echo "Number of POMS Data zip file matching least date pattern is: " $filecount_POMS >>$LOG_FILE
  if [ $filecount_POMS -ne 0 ]; then
    cp POMS_$PATSTR.zip $BKUP_DIR
    cp POMS_$PATSTR.zip $FTP_DIR
    CpPOMSSt=$?
    if [ CpPOMSSt -eq 0 ]; then
      echo "Photo Extracts $(ls -1 POMS_$PATSTR.zip) copied successfully" >>$LOG_FILE
    else
      echo "Photo Extract Copying Failed" >>$LOG_FILE
      cleanup
      exit 1
    fi

    rm -f POMS_$PATSTR.zip POMS_$PATSTR.trg
    rmPOMSSt=$?
    if [ rmPOMSSt -eq 0 ]; then
      echo "Photo Extracts POMS_$PATSTR.zip and POMS_$PATSTR.trg removed successfully from inbound directory" >>$LOG_FILE
    else
      echo "Photo Extract removal from inbound directory Failed" >>$LOG_FILE
      cleanup
      exit 1
    fi
  else
    echo "There is no Photo POMS zip file matching pattern $PATSTR to be copied." >>$LOG_FILE
  fi
else
  #----------- Modifications as per the GQM Phase-2 (POMS source Team delay) : Starts here ----------#

  #echo "There is no POMS trigger file present matching pattern $PATSTR. No Photo POMS Zip file is copied." >> $LOG_FILE
  #cleanup
exit 1
  echo "**************************************************************************************" >>$LOG_FILE
  echo " The POMS files are not available, hence creating zero byte files and proceeding with the flow. " >>$LOG_FILE
  echo "**************************************************************************************" >>$LOG_FILE
  echo "" >>$LOG_FILE

  cd $FTP_DIR
  DATESTR=$(date +"%Y%m%d%H%M%S")
  touch PHEXT001_POMS.dat.$DATESTR
  touch PHEXT003_POMS.dat.$DATESTR
  touch PHEXT005_POMS.dat.$DATESTR
  touch PHEXT006_POMS.dat.$DATESTR
  touch PHEXT007_POMS.dat.$DATESTR
  touch PHEXT011_POMS.dat.$DATESTR
  touch PHEXT016_POMS.dat.$DATESTR
  touch PHEXT022_POMS.dat.$DATESTR

  echo "List of  POMS Files created : " >>$LOG_FILE
  echo "$(ls -l *_POMS.*) " >>$LOG_FILE

fi

#------------- Modifications as per the GQM Phase-2 (POMS source Team delay) : Ends here -------------#

echo "" >>$LOG_FILE
echo "" >>$LOG_FILE

#-------------- GQM Phase 3 Changes - GQM mail order files migrated to POMS system ----------------#
echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************To Move the Least Date POMS Mail order Extract********************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

filecount=$(ls -l POMS_MAIL_$PATSTR.trg | wc -l)
if [ $filecount -ne 0 ]; then
  filecount_POMS_MAIL=$(ls -l POMS_MAIL_$PATSTR.zip | wc -l)
  echo "Number of POMS Mail order Data zip file matching least date pattern is: " $filecount_POMS_MAIL >>$LOG_FILE
  if [ $filecount_POMS_MAIL -ne 0 ]; then
    cp POMS_MAIL_$PATSTR.zip $BKUP_DIR
    cp POMS_MAIL_$PATSTR.zip $FTP_DIR
    CpPOMSSt=$?
    if [ CpPOMSSt -eq 0 ]; then
      echo "Photo Extracts $(ls -1 POMS_MAIL_$PATSTR.zip) copied successfully" >>$LOG_FILE
    else
      echo "Photo Extract Copying Failed" >>$LOG_FILE
      cleanup
      exit 1
    fi

    rm -f POMS_MAIL_$PATSTR.zip POMS_MAIL_$PATSTR.trg
    rmPOMSSt=$?
    if [ rmPOMSSt -eq 0 ]; then
      echo "Photo Extracts POMS_MAIL_$PATSTR.zip and POMS_MAIL_$PATSTR.trg removed successfully from inbound directory" >>$LOG_FILE
    else
      echo "Photo Extract removal from inbound directory Failed" >>$LOG_FILE
      cleanup
      exit 1
    fi
  else
    echo "There is no Photo POMS Mail order zip file matching pattern $PATSTR to be copied." >>$LOG_FILE
  fi
else
  #----------- Modifications as per the GQM Phase-III (POMS source Team delay) : Starts here ----------#

  #echo "There is no Mail order POMS trigger file present matching pattern $PATSTR. No Photo POMS Zip file is copied." >> $LOG_FILE
  #cleanup
exit 1
  echo "**************************************************************************************" >>$LOG_FILE
  echo " The Mail order POMS files are not available, hence creating zero byte files and proceeding with the flow. " >>$LOG_FILE
  echo "**************************************************************************************" >>$LOG_FILE
  echo "" >>$LOG_FILE

  cd $FTP_DIR
  DATESTR=$(date +"%Y%m%d%H%M%S")
  touch PHEXT003_POMS_MAILORDER.dat.$DATESTR
  touch PHEXT004_POMS_MAILORDER.dat.$DATESTR
  touch PHEXT006_POMS_MAILORDER.dat.$DATESTR
  touch PHEXT007_POMS_MAILORDER.dat.$DATESTR
  touch PHEXT008_POMS_MAILORDER.dat.$DATESTR
  touch PHEXT016_POMS_MAILORDER.dat.$DATESTR
  touch PHEXT017_POMS_MAILORDER.dat.$DATESTR
  touch PHEXT019_POMS_MAILORDER.dat.$DATESTR
  touch MPHEXT012_POMS.dat.$DATESTR

  echo "List of  mail order POMS Files created : " >>$LOG_FILE
  echo "$(ls -l *_POMS_MAILORDER.*) " >>$LOG_FILE

fi

#------------- Modifications as per the GQM Phase-3 (POMS source Team delay) : Ends here -------------#

echo "" >>$LOG_FILE
echo "" >>$LOG_FILE
#-------Moditfication as per the ecom shipt to store changes --------------#

echo "**************************************************************************************" >>$LOG_FILE
echo "*********************Copy to archive and move POMS PHEXT023 file to FTP Directory*******" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE

cd $APP_DIR_INPUT
filecount=$(ls -l PHEXT023.dat.* | wc -l)

if [ $filecount -ne 0 ]; then
  echo "Number of PHEXT023* file  is: " $filecount >>$LOG_FILE
  cp PHEXT023.dat.* $BKUP_DIR
  cp PHEXT023.dat.* $ARCH_DIR
  echo "PHEXT023* file  is copied to archive directory " >>$LOG_FILE
  echo "Renaming the PHEXT023 to PHEXT023_POMS " >>$LOG_FILE
  for filename in $(ls -1 PHEXT023.dat.*); do
    tmstmp=$(echo $filename | cut -f3 -d'.')
    mv $filename $FTP_DIR/PHEXT023_POMS.dat.$tmstmp
    CpPOMS2S=$?
    if [ CpPOMS2S -eq 0 ]; then
      echo "PHEXT023_POMS.dat copied successfully" >>$LOG_FILE
    else
      echo "PHEXT023_POMS.dat Copying Failed" >>$LOG_FILE
      cleanup
      exit 1
    fi
  done
else
  echo "There is no Photo file PHEXT023_POMS to be  copied." >>$LOG_FILE
  echo "**************************************************************************************" >>$LOG_FILE
  echo " The PHEXT023_POMS  files is  not available, hence creating zero byte files and proceeding with the flow. " >>$LOG_FILE
  echo "**************************************************************************************" >>$LOG_FILE
  echo "" >>$LOG_FILE

  cd $FTP_DIR
  DATESTR=$(date +"%Y%m%d%H%M%S")
  touch PHEXT023_POMS.dat.$DATESTR
  echo " PHEXT023_POMS  File created : " >>$LOG_FILE
  echo "$(ls -l PHEXT023_POMS.*) " >>$LOG_FILE

fi

#-------Moditfication as per the ecom shipt to store changes ------Ends Here------------------------#

echo "" >>$LOG_FILE
echo "" >>$LOG_FILE

cd $FTP_DIR

echo "List of  Zip Files copied : " >>$LOG_FILE
echo "$(ls -l *_$PATSTR.zip) " >>$LOG_FILE

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************To Unzip the File Moved******************************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

for filename in *_$PATSTR.zip; do
  unzip -jo $filename >>$LOG_FILE
  CpPhSt=$?
  if [ CpPhSt -eq 0 ]; then
    echo "Unzip happened successfully for $filename " >>$LOG_FILE
  else
    echo " Unzip failed for $filename" >>$LOG_FILE
    cleanup
    exit 1
  fi
done

### As part of mail order migration ,fields CHANNEL_CD,CHANNEL_DETAIL_CD,FUNCTIONALITY_CD are availbale in PHEXT003 feed itself#############
### No need to copy from PHEXt003_01 to PHEXT003#############
#echo "" >> $LOG_FILE
#echo "**************************************************************************************" >> $LOG_FILE
#echo "****To Handle missing fields and Copying contents of PHEXT003-01 in to PHEXT003*******" >> $LOG_FILE
#echo "**************************************************************************************" >> $LOG_FILE
#echo "" >> $LOG_FILE

#mv PHEXT003_????????.dat $ARCH_DIR
#SFX_003=`ls -1 PHEXT003_01_????????.dat |awk -F_ '{print $NF}'`

#Handling the two missing fields(i.e. CUSTOMER_ID and TOKEN_ID) in the PHEXT003_01 file and writing to PHEXT003 file #
#one more added as part of ship to store
#sed 's/$/^|^|-1^|/g' PHEXT003_01_????????.dat > PHEXT003.tmp

#mv PHEXT003.tmp PHEXT003_${SFX_003}
#mv PHEXT003_01_????????.dat $ARCH_DIR

echo "$(ls -1 *_*.dat*) " >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************To Move the Least Date RX Microservices Extract********************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

MS_DATA_DIR=$EDWROOT/usr/local/edw/ecomm/${APP_ENV}/inbound/edw_micro_services
cd $MS_DATA_DIR

filecount=$(ls -l RXEXT_ms_$PATSTR.trg | wc -l)
if [ $filecount -ne 0 ]; then
  echo "Least Date Pattern identified from MS RXEXT trigger file is " $PATSTR >>$LOG_FILE
  filecount_RX=$(ls -l RXEXT*_ms_$PATSTR.dat | wc -l)
  echo "Number of RX Data file matching least date pattern is: " $filecount_RX >>$LOG_FILE
  if [ $filecount_RX -ne 0 ]; then
    cp RXEXT*_ms_$PATSTR.dat $BKUP_DIR
    cp RXEXT*_ms_$PATSTR.dat $FTP_DIR
    CpPhSt=$?
    if [ CpPhSt -eq 0 ]; then
      echo "Microservices RX Extracts $(ls -1 RXEXT*_ms_$PATSTR.dat) copied successfully" >>$LOG_FILE
    else
      echo "RX Extract copying failed " >>$LOG_FILE
      cleanup
      exit 1
    fi

    rm -f RXEXT*_ms_$PATSTR.dat RXEXT_ms_$PATSTR.trg
    rmSSSt=$?
    if [ rmSSSt -eq 0 ]; then
      echo "Microservices RX Extracts RXEXT*_ms_$PATSTR.dat and RXEXT_ms_$PATSTR.trg removed successfully from inbound MS directory" >>$LOG_FILE
    else
      echo "Microservices RX Extract removal from inbound directory Failed" >>$LOG_FILE
      cleanup
      exit 1
    fi
  else
    echo "There are no Microservices RX file matching pattern $PATSTR to be copied." >>$LOG_FILE
  fi
else
  echo "There is no Microservices RX trigger file present. No RX data file is copied." >>$LOG_FILE
  cleanup
  exit 1
fi
echo "***************************** Renaming RX MS files Started ****************************************" >>$LOG_FILE
cd $FTP_DIR
for f in $(ls -1 RXEXT0??_ms_$PATSTR.dat | awk -F/ '{print $NF}'); do
  fnm=$(echo $f | awk -F_ '{print $1}')
  fts=$(echo $f | awk -F_ '{print $3}')
  #fts1=$(echo $fts | awk -F. '{print $1}')
  echo $fnm >>$LOG_FILE
  echo $fts >>$LOG_FILE
  #echo $fts1 >> $LOG_FILE
  mv $f ${fnm}_${fts}
done
for f in $(ls -1 RXEXT0??_??_ms_????????.dat | awk -F/ '{print $NF}'); do
  fnm=$(echo $f | awk -F_ '{print $1}')
  fts=$(echo $f | awk -F_ '{print $2}')
  fts1=$(echo $f | awk -F_ '{print $4}')

  echo $fnm >>$LOG_FILE
  echo $fts >>$LOG_FILE
  echo $fts1 >>$LOG_FILE
  mv $f ${fnm}_${fts}_${fts1}
done
echo "***************************** Renaming RX MS files Completed ****************************************" >>$LOG_FILE
############################ Tokenisation project Changes ###################
####### RXEXT004,RXEXT005,RXEXT006 Files will no longer be supplied #########
####### from Source systems, Hence we are using RXEXT004_01,RXEXT005_01, ####
####### RXEXT006_01 files to generate the same for Datastage processing. ####

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "****To delete the last 3 columns from RXEXT*_01 files and write into RXEXT* files ****" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

cd $FTP_DIR
#cp RXEXT005_01_????????.dat RXEXT005_$PATSTR.dat
cp RXEXT005_????????.dat RXEXT005_01_$PATSTR.dat
OutRx5St=$?
if [ OutRx5St -eq 0 ]; then
  ################## Changed script to avoid reject records due to field RO_ORDER_NUM in RXEXT* files. ##################

  awk 'BEGIN{FS="\\^|"
        OFS="^|"}{
        if ($2==NULL)
        print $1,"",$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35;
        else
        print $0;
        }' RXEXT005_$PATSTR.dat >RX_EXT005_$PATSTR.dat
  cp RX_EXT005_$PATSTR.dat RXEXT005_$PATSTR.dat
  OutRx5St1=$?
  if [ OutRx5St1 -eq 0 ]; then
    echo "RO_ORDER_NUM field has been updated as "" {blank} in RXEXT005_*.dat " >>$LOG_FILE
  else
    echo "RO_ORDER_NUM field has been not updated as "" {blank} in RXEXT005_*.dat " >>$LOG_FILE
  fi
  echo "RXEXT005_*.dat has been successfully created from RXEXT005_01_*.dat " >>$LOG_FILE
  rm -f RX_EXT005_$PATSTR.dat
else
  echo "RXEXT005_*.dat file creation from RXEXT005_01_*.dat has been Failed" >>$LOG_FILE
  cleanup
  exit 1
fi

cp RXEXT004_????????.dat RXEXT004_01_$PATSTR.dat
cp RXEXT006_????????.dat RXEXT006_01_$PATSTR.dat

for InpRxFile in RXEXT004_01_????????.dat RXEXT006_01_????????.dat; do
  NF=$(awk -F "|" 'END{print NF}' $InpRxFile)
  NNF=$(expr $NF - 3)
  OutRxFile=$(echo $InpRxFile | sed 's/_01//')
  cut -d "^|" -f1-$NNF $InpRxFile >$OutRxFile
  OutRxSt=$?
  if [ OutRxSt -eq 0 ]; then
    if [ $OutRxFile == RXEXT004_????????.dat ]; then
      awk 'BEGIN{FS="\\^|"
        OFS="^|"}{

        if ($2==NULL)
        print $1,"",$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40;
        else
        print $0;
        }' RXEXT004_????????.dat >RX_EXT004_$PATSTR.dat
      cp RX_EXT004_$PATSTR.dat RXEXT004_$PATSTR.dat
      OutRxSt1=$?
      if [ OutRxSt1 -eq 0 ]; then
        echo "RO_ORDER_NUM field has been updated as "" {blank} in RXEXT004_*.dat " >>$LOG_FILE
      else
        echo "RO_ORDER_NUM field has been not updated as "" {blank} in RXEXT004_*.dat " >>$LOG_FILE
      fi
    else
      awk 'BEGIN{FS="\\^|"
        OFS="^|"}{
        if ($2==NULL)
        print $1,"",$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34;
        else
        print $0;
        }' RXEXT006_????????.dat >RX_EXT006_$PATSTR.dat
      cp RX_EXT006_$PATSTR.dat RXEXT006_$PATSTR.dat
      OutRxSt2=$?
      if [ OutRxSt2 -eq 0 ]; then
        echo "RO_ORDER_NUM field has been updated as "" {blank} in RXEXT006_*.dat " >>$LOG_FILE
      else
        echo "RO_ORDER_NUM field has been not updated as "" {blank} in RXEXT006_*.dat " >>$LOG_FILE
      fi
    fi

    echo "$OutRxFile has been successfully created from $InpRxFile " >>$LOG_FILE
    rm -f RX_EXT004_$PATSTR.dat
    rm -f RX_EXT006_$PATSTR.dat
  else
    echo "$OutRxFile file creation from $InpRxFile has been Failed" >>$LOG_FILE
    cleanup
    exit 1
  fi
done

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************To Delete the Zip files from FTP Directory***********************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

cd $FTP_DIR
echo "List of  Zip Files candidate for removal from FTP Directory are : " >>$LOG_FILE
echo "$(ls -l *_$PATSTR.zip) " >>$LOG_FILE
echo "" >>$LOG_FILE
rm -f *_$PATSTR.zip
rmSt=$?
if [ rmSt -eq 0 ]; then
  echo "Zip files removed successfully from FTP directory" >>$LOG_FILE
else
  echo "Zip files removal from FTP directory Failed" >>$LOG_FILE
  cleanup
  exit 1
fi

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "********* Added- As part of mail order migration****************************************" >>$LOG_FILE
echo "*********************Copy to archive and move POMS mail order PHEXT019 and PHEXT003 files to FTP Directory*******" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE

cp $INBOUND_DIR/PHEXT019_POMS_MAILORDER.dat.?????????????? $ARCH_DIR

mv $INBOUND_DIR/PHEXT019_POMS_MAILORDER.dat.?????????????? $FTP_DIR

cp $INBOUND_DIR/PHEXT003_POMS_MAILORDER.dat.?????????????? $ARCH_DIR

mv $INBOUND_DIR/PHEXT003_POMS_MAILORDER.dat.?????????????? $FTP_DIR

echo "**************************************************************************************" >>$LOG_FILE
echo "*********************Copy to archive and move POMS PHEXT003 file to FTP Directory*******" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE

cp $INBOUND_DIR/PHEXT003_POMS.dat.?????????????? $ARCH_DIR

mv $INBOUND_DIR/PHEXT003_POMS.dat.?????????????? $FTP_DIR

#Adding # in place of token ID if it is null#
echo "**************************Adding # in place of token ID*****************************" >>$LOG_FILE
cd $FTP_DIR
for file in $(ls -1 PHEXT003_POMS.dat.??????????????); do
  awk -F'\\^|' '{if(length($50)==0) $50="#" ; OFS="^|"; print}' $file >temp.$file
  mv temp.$file $file
done
echo "**************************Adding # in place of token ID DONE************************" >>$LOG_FILE

echo "**************************POMS PHEXT003 to FTP moved********************************" >>$LOG_FILE

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "********Added- as part of mail migration****************************************" >>$LOG_FILE
echo "*******Checking if PHEXT009,PHEXT010 and PHEXT018 ATG(GQM) files are decomissioned*********" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

if [ ! -f PHEXT009_$PATSTR.dat ]; then
  touch PHEXT009_$PATSTR.dat
fi

if [ ! -f PHEXT002_$PATSTR.dat ]; then
  touch PHEXT002_$PATSTR.dat
fi

if [ ! -f PHEXT010_$PATSTR.dat ]; then
  touch PHEXT010_$PATSTR.dat
fi

if [ ! -f PHEXT018_$PATSTR.dat ]; then
  touch PHEXT018_$PATSTR.dat
fi

echo "" >>$LOG_FILE
echo "List of Dat Files unzipped in ftp directory is:" >>$LOG_FILE
#echo "`ls -1 *_$PATSTR.dat` " >> $LOG_FILE

echo "*********************Script files count******************************************" >>$LOG_FILE

echo "$(ls -1 *_*.dat*) " >>$LOG_FILE

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*******Checking if SSEXT001,SSEXT003 and SSEXT015 ATG files are decomissioned*********" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

if [ ! -f SSEXT001_$PATSTR.dat ]; then
  touch SSEXT001_$PATSTR.dat
fi

if [ ! -f SSEXT003_$PATSTR.dat ]; then
  touch SSEXT003_$PATSTR.dat
fi

if [ ! -f SSEXT015_$PATSTR.dat ]; then
  touch SSEXT015_$PATSTR.dat
fi

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*******Checking if RXEXT003,RXEXT007,RXEXT008,RXEXT010,RXEXT011,RXEXT015 and RXEXT017 ATG files are decomissioned*********" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

if [ ! -f RXEXT003_$PATSTR.dat ]; then
  touch RXEXT003_$PATSTR.dat
fi

if [ ! -f RXEXT007_$PATSTR.dat ]; then
  touch RXEXT007_$PATSTR.dat
fi

if [ ! -f RXEXT008_$PATSTR.dat ]; then
  touch RXEXT008_$PATSTR.dat
fi

if [ ! -f RXEXT010_$PATSTR.dat ]; then
  touch RXEXT010_$PATSTR.dat
fi

if [ ! -f RXEXT011_$PATSTR.dat ]; then
  touch RXEXT011_$PATSTR.dat
fi

if [ ! -f RXEXT015_$PATSTR.dat ]; then
  touch RXEXT015_$PATSTR.dat
fi

if [ ! -f RXEXT017_$PATSTR.dat ]; then
  touch RXEXT017_$PATSTR.dat
fi

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*******Checking if SSEXT020,SSEXT020_01 Master files are decomissioned*********" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

if [ ! -f SSEXT020_$PATSTR.dat ]; then
  touch SSEXT020_$PATSTR.dat
fi

if [ ! -f SSEXT020_01_$PATSTR.dat ]; then
  touch SSEXT020_01_$PATSTR.dat
fi

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************To Move the Least Date SS Microservices Extract********************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

MS_DATA_DIR=/usr/local/edw/ecomm/${APP_ENV}/inbound/edw_micro_services
cd $MS_DATA_DIR

filecount=$(ls -l SSEXT_ms_$PATSTR.trg | wc -l)
if [ $filecount -ne 0 ]; then
  echo "Least Date Pattern identified from MS SSEXT trigger file is " $PATSTR >>$LOG_FILE
  filecount_SS=$(ls -l SSEXT*_ms_$PATSTR.dat | wc -l)
  echo "Number of SS Data file matching least date pattern is: " $filecount_SS >>$LOG_FILE
  if [ $filecount_SS -ne 0 ]; then
    cp SSEXT*_ms_$PATSTR.dat $BKUP_DIR
    cp SSEXT*_ms_$PATSTR.dat $FTP_DIR
    CpPhSt=$?
    if [ CpPhSt -eq 0 ]; then
      echo "Microservices SS Extracts $(ls -1 SSEXT*_ms_$PATSTR.dat) copied successfully" >>$LOG_FILE
    else
      echo "SS Extract copying failed " >>$LOG_FILE
      cleanup
      exit 1
    fi

    rm -f SSEXT*_ms_$PATSTR.dat SSEXT_ms_$PATSTR.trg
    rmSSSt=$?
    if [ rmSSSt -eq 0 ]; then
      echo "Microservices SS Extracts SSEXT*_ms_$PATSTR.dat and SSEXT_ms_$PATSTR.trg removed successfully from inbound MS directory" >>$LOG_FILE
    else
      echo "Microservices SS Extract removal from inbound directory Failed" >>$LOG_FILE
      cleanup
      exit 1
    fi
  else
    echo "There are no Microservices SS file matching pattern $PATSTR to be copied." >>$LOG_FILE
  fi
else
  echo "There is no Microservices SS trigger file present. No SS data file is copied." >>$LOG_FILE
  cleanup
  exit 1
fi

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************To Move the Least Date Master Feeds of PH Microservices Extract********************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

filecount=$(ls -l PHEXT_ms_$PATSTR.trg | wc -l)
if [ $filecount -ne 0 ]; then
  echo "Least Date Pattern identified from MS Master Feed trigger file is " $PATSTR >>$LOG_FILE
  filecount_PH=$(ls -l PHEXT*_ms_$PATSTR.dat | wc -l)
  echo "Number of PH Master Data file matching least date pattern is: " $filecount_PH >>$LOG_FILE
  if [ $filecount_PH -ne 0 ]; then
    cp PHEXT*_ms_$PATSTR.dat $BKUP_DIR
    cp PHEXT*_ms_$PATSTR.dat $FTP_DIR
    CpPhSt=$?
    if [ CpPhSt -eq 0 ]; then
      echo "Microservices Master Feed PH Extracts $(ls -1 PHEXT*_ms_$PATSTR.dat) copied successfully" >>$LOG_FILE
    else
      echo "Master Feed PH Extract copying failed " >>$LOG_FILE
      cleanup
      exit 1
    fi

    cd $FTP_DIR
    awk -F '|' -v OFS='|' '{if(length($11) > 2) $11=substr($11,1,1) substr($11,length($11),1); print}' PHEXT013_ms_*.dat >temp.dat
    mv temp.dat PHEXT013_ms_$PATSTR.dat
    chmod 777 PHEXT013_ms_$PATSTR.dat

    cd $MS_DATA_DIR

    rm -f PHEXT*_ms_$PATSTR.dat PHEXT_ms_$PATSTR.trg
    rmSSSt=$?
    if [ rmSSSt -eq 0 ]; then
      echo "Microservices Master Feed PH Extracts PHEXT*_ms_$PATSTR.dat and PHEXT_ms_$PATSTR.trg removed successfully from inbound MS directory" >>$LOG_FILE
    else
      echo "Microservices Master Feed PH Extract removal from inbound directory Failed" >>$LOG_FILE
      cleanup
      exit 1
    fi
  else
    echo "There are no Microservices Master Feed PH file matching pattern $PATSTR to be copied." >>$LOG_FILE
  fi
else
  echo "There is no Microservices Master Feed trigger file present. No Master Feed data file is copied." >>$LOG_FILE
  cleanup
  exit 1
fi

# Moving file as a part of EDW Microservices Project
cd $FTP_DIR
if [ -f SSEXT007_$PATSTR.dat ]; then
  mv SSEXT007_$PATSTR.dat $BKUP_DIR
fi

echo "" >>$LOG_FILE

cd $FTP_DIR

awk -F '|' -v OFS='|' '{gsub(",","",$36)}1' RXEXT004_$PATSTR.dat >RXEXT004_temp.dat
awk -F '|' 'length($38) < 11 {print}' RXEXT004_temp.dat >RXEXT004_$PATSTR.dat
rm RXEXT004_temp.dat

awk -F '|' -v OFS='|' '{gsub(",","",$36)}1' RXEXT004_01_$PATSTR.dat >RXEXT004_temp.dat
awk -F '|' 'length($38) < 11 {print}' RXEXT004_temp.dat >RXEXT004_01_$PATSTR.dat
rm RXEXT004_temp.dat

awk -F '|' '{ gsub(/[^0-9]/,"",$34) }1' OFS='|' RXEXT006_$PATSTR.dat >RXEXT006_temp.dat
mv RXEXT006_temp.dat RXEXT006_$PATSTR.dat

awk -F '|' '{ gsub(/[^0-9]/,"",$34) }1' OFS='|' RXEXT006_01_$PATSTR.dat >RXEXT006_temp.dat
mv RXEXT006_temp.dat RXEXT006_01_$PATSTR.dat

awk -F '|' 'length($2) < 3 {print}' RXEXT012_$PATSTR.dat >rx_main.dat
mv rx_main.dat RXEXT012_$PATSTR.dat

echo "" >>$LOG_FILE

echo "**************************************************************************************" >>$LOG_FILE
echo "*********************Script Ended Successfully******************************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE
cleanup
exit 0

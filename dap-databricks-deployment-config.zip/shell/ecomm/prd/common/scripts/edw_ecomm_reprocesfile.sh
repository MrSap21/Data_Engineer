#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------------------
# Author:		Manish Garg
# File Name:		edw_ecomm_reprocesfile.sh
# Parameters:		Project_Name
# Called from:	None
# Purpose:		This Script will create the reprocessing files to be Processed by ETL.
#-----------------------------------------------------------------------------------------
#			MAINTENANCE HISTORY
#------------------------------------------------------------------------------------------
#	Revision		Description		Name				Date
#------------------------------------------------------------------------------------------
#	1.0		Initial Version	   Manish Garg		23-Mar-2010
#------------------------------------------------------------------------------------------

# if [[ `uname -n` == "dedwbt01" ]]
#  then
# 		export APP_ENV="tst"
#  else
# 		export APP_ENV="prd"
#  fi

APP_ENV="prd"

NoOfParm="$#"
DS_PROJECT="$1"

. $EDWROOT/usr/local/edw/ecomm/${APP_ENV}/common/scripts/edw_ecomm_config.ksh $DS_PROJECT

AUDIT_DIR=$EDWROOT$APP_ROOT/audit
FTP_DIR=$EDWROOT$APP_ROOT/ftp
CONFIG_DIR=$EDWROOT$APP_ROOT/common/config
EDWBatchId=$(date +"%Y%m%d%H%M%S")
CUSTFILE="REPROCESSING_CUSTOMER.DAT"
# LOG_FILE=$EDWROOT$APP_DIR_ARCHIVE/${EDWBatchId}_Ecomm_reprocess_LOGFile.log
LOG_FILE=/tmp/${EDWBatchId}_Ecomm_reprocess_LOGFile.log
exec >$LOG_FILE 2>&1

echo "*******************************************************************************************" >>$LOG_FILE
echo "************************edw_ecomm_reprocesfile.sh initiated*********************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE
echo "Batch Id used is " $EDWBatchId >>$LOG_FILE
echo "Project Name is " $DS_PROJECT >>$LOG_FILE

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "*********************To Check the number of Parameters passed******************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

if [ $NoOfParm -ne 1 ]; then
  echo "--------USAGE-------------------------------------"
  echo "  $0  <DS_PROJECT>"
  echo "---------------------------------------------------"
  echo " Wrong Number of Parameters passed. No File is Copied. Exiting the Script " >>$LOG_FILE
  cp $LOG_FILE $EDWROOT$APP_DIR_ARCHIVE && rm $LOG_FILE
  exit 1
fi

echo "Parameter Validation is Successful" >>$LOG_FILE

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "*************************To Remove the existing customer file******************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

cd $FTP_DIR
if [ -f "$CUSTFILE" ]; then
  rm $CUSTFILE
  echo "Existing $CUSTFILE file in $FTP_DIR has been removed." >>$LOG_FILE
else
  echo "No Existing $CUSTFILE file in $FTP_DIR to be removed." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "***************************Count Non Zero Byte Files **************************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

cd $EDWROOT$APP_DIR_REJECT
filecount=$(find . -type f ! -size 0k | awk -F"/" '{print $2}' | wc -l | awk '{print $1}')
echo "Number of files having size more than zero byte in $EDWROOT$APP_DIR_REJECT is: " $filecount >>$LOG_FILE

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************Generating Reprocessing Files**************************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

if [ $filecount -ne 0 ]; then
  echo "List of Files having size more than zero byte is : \n $(find . -type f ! -size 0k | awk -F"/" '{print $2}')" >>$LOG_FILE
  echo "\n" >>$LOG_FILE
  for filename in $(find . -type f ! -size 0k | awk -F"/" '{print $2}'); do
    filelength=${#filename}
    if [ $filelength -gt 15 ]; then
      lkpfile=$(echo $filename | cut -c 16-100)
      keypos=$(grep $lkpfile $CONFIG_DIR/reprocess_cust.txt | awk -F'|' '{print $2}')
      srcfile=$(grep $lkpfile $CONFIG_DIR/reprocess_cust.txt | awk -F'|' '{print $3}')
      srckeypos=$(grep $lkpfile $CONFIG_DIR/reprocess_cust.txt | awk -F'|' '{print $4}')
      if [ "X"$keypos = "X" ]; then
        echo "$filename is not a customer RI check file. \n" >>$LOG_FILE
      else
        echo "processing $filename started" >>$LOG_FILE
        awk -v position=$keypos -F'\\^|' '{print $position}' $filename > tmp_cust.DAT
        nawk -v custpos=$srckeypos -F'\\^|' -v OFS='\\^|' 'FNR==NR {f1[$0]; next} $custpos in f1' tmp_cust.DAT $FTP_DIR/$srcfile* > $FTP_DIR/$srcfile.DAT
        cp tmp_cust.DAT $FTP_DIR/$CUSTFILE && rm tmp_cust.DAT
        echo "creation of reprocessing file for $filename has been completed successfully \n" >>$LOG_FILE
      fi
    fi
  done
else
  echo "There is no file having size more than zero byte in $EDWROOT$APP_DIR_REJECT." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "********************************Cleanup Extract Files**************************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

cd $FTP_DIR
rm *.dat
CmdOut=$?
if [ CmdOut -eq 0 ]; then
  echo "Files with extension *.dat Present in $FTP_DIR removed successfully " >>$LOG_FILE
else
  echo "There is no file with extension *.dat Present in $FTP_DIR to be removed. " >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************Script Ended Successfully******************************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

cp $LOG_FILE $EDWROOT$APP_DIR_ARCHIVE && rm $LOG_FILE
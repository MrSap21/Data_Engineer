#!/bin/ksh

# global environment variable, should be called in each shell script 

# key vault
export KEY_VAULT_SECRET=true
export KEY_VAULT_SCOPE=<keyVaultScope>
export KEY_VAULT_SQSCOPE=<keyVaultScope>
export KEY_VAULT_SECRET_SFPASSWORD=<keyVaultSecret_sfPassword>

# snowflake
export SF_USER_NAME=<sfUser>
export SF_USER_PWD=dummy
export SF_ACCOUNT_NAME=<sfAccount>
export SF_WAREHOUSE_NAME=<sfWarehouse>
export SF_DATABASE_NAME=<sfDatabase>
export SF_SCHEMA_NAME=<sfSchema>
export SF_CONNECTION_STRING=<sfConnectionString>
export SF_ROLE_NAME=<sfRoleName>

# path to storage
export EDWPROJ=ecomm
export EDWROOT=/dbfs/mnt/wrangled
export SCRIPTROOT=/dbfs/mnt/utility_main

#export EDWROOT based on env
export ENVR=prd

# path to dbfs
export DBFSROOT=/dbfs/FileStore/apps
# jet 2.0
#export PYTHONPATH=$PYTHONPATH:$DBFSROOT/libs/Jet.2.0:$JETHOME

# databricks REST API
export DATABRICKS_INSTANCE=<databricks_instance>
export GET_STAT_TIMEOUT=21600

#sqlConnection JOB URL
export SQL_JOB_URL=<databricks_job_run_url>

#sql keyvault and connection parameters
export SQL_SERVER_DRIVER="{ODBC Driver 17 for SQL Server}"
export keyVaultSecret_tenantIDKey=<keyVaultSecret_tenantIDKey>
export keyVaultSecret_sqlClientIDKey=<keyVaultSecret_sqlClientIDKey>
export KEYVAULTSECRET_SQLSERVERCLIENTID=<keyVaultSecret_sqlClientIDKey>
export keyVaultSecret_sqlClientSecretKey=<keyVaultSecret_sqlClientSecretKey>
export KEYVAULTSECRET_SQLSERVERCLIENTSECRET=<keyVaultSecret_sqlClientSecretKey>
export sqlServerName=<sqlServerName>
export SQL_SERVER_NAME=<sqlServerName>
export sqlDBName=<sqlDBName>
export SQL_SERVER_DB=<sqlDBName>
export DP_DB_MASTER_DATA=<DP_DB_MASTER_DATA>
export DP_DB_STAGING=<DP_DB_STAGING>

#asset status update
export WRITE_API_URL=<WRITE_API_URL>
export pUpdateAssetAPI=<pUpdateAssetAPI>


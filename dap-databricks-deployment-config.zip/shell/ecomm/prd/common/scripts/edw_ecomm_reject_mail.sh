#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
RejectDir=$1
SchemaFile=$2
EDWBATCHID=$3
pADMINEMAILADDR="niket.agarwal@walgreens.com,lakshmi.k.narayana@walgreens.com,mahesh.singh@walgreens.com,aditya.jain@walgreens.com"
Filename=${SchemaFile}_lengthexceeds.rej.${EDWBATCHID}
cd $RejectDir

mail_to ()
{
read message
 echo "Hi Team,\n\n Rejected records captured from POMS file $Filename.\n\n kindly check the ${Filename} \n\n Thanks."|mailx -s "$message" $pADMINEMAILADDR 
}


if [ -s $Filename ]
 then
   echo "*==================================================================" >> $LOG_FILE
   echo "    ${Filename} has rejected records                                " >> $LOG_FILE
   echo "*==================================================================" >> $LOG_FILE
   echo "Rejected records captured from POMS file ${Filename}" | mail_to >> $LOG_FILE
   fi








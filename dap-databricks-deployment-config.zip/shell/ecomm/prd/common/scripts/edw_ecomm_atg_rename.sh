 #!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------------------
# Author:               EDW Team
# File Name:            edw_ecomm_atg_rename.sh
# Parameters:           FTP Dir/ATG ecom Filenames.
# Purpose:              This Script will rename the ATG files for preprocessing.
#---------------------------------------------------------------------------------------------
#                       MAINTENANCE HISTORY
#---------------------------------------------------------------------------------------------
#       Revision                Description             Name                            Date
#---------------------------------------------------------------------------------------------
#        1.0                  Initial Version                 Manohar P          6-Feb-2019
#                                                             Prakash M
#----------------------------------------------------------------------------------------------

FtptDir=$1
Filename=$2

cd $FtptDir

file=$(echo ${Filename} | awk -F'_' '{print NF }')

if [ $file == 1 ]
then
#------- As part of  ATG and MS Changes, This script renames ATG input files in such a way they will be processed in downstream Merge jobs.---------#
for f in `ls -1 ${Filename}_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}')
     fts=$(echo $f | awk -F_ '{print $2}')
     fts1=$(echo $fts | awk -F. '{print $1}')
echo $fnm
echo $fts
echo $fts1
mv $f ${fnm}_atg_${fts1}.dat
done

else
for f in `ls -1 ${Filename}_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}')
         fts=$(echo $f | awk -F_ '{print $2}')
         fts1=$(echo $f | awk -F_ '{print $3}')

echo $fnm
echo $fts
echo $fts1
	
        if [ ${fnm}_${fts} == "SSEXT007_01" ]
	then
	cp $f ${fnm}_${fts}_atg_${fts1}
	else
        mv $f ${fnm}_${fts}_atg_${fts1}
        fi

done
fi

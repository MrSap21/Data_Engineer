#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------------------
# Author:		Manish Garg
# File Name:		ecom_edw_mvdashboard.sh
# Parameters:		edw batch ID
# Called from:	None
# Purpose:		This Script will copy the Ecomm Files to DashBoard Directory.
#-----------------------------------------------------------------------------------------
#			MAINTENANCE HISTORY
#------------------------------------------------------------------------------------------
#	Revision		Description		Name				Date
#------------------------------------------------------------------------------------------
#	1.0		Initial Version	   Manish Garg		12-Jan-2010
#------------------------------------------------------------------------------------------

NoOfParm="$#"

#---------------------------------------------------------------------------------------------------
#                         CHECKING THE NUMBER OF PARAMETERS PASSED
#---------------------------------------------------------------------------------------------------

 if [[ $NoOfParm -lt 1 ]]
 then
                echo " wrong number of parameters passed. Exiting the Script.. "
              exit 1
 fi


#---------------------------------------------------------------------------------------------------
#                        Initializing The Parameters
#---------------------------------------------------------------------------------------------------

EDWBatchId=$1

if [[ 'uname -n' == "DEDWBT01" ]]
 then
		export APP_ENV="tst"
 else
		export APP_ENV="prd"
 fi


AUDIT_DIR=/usr/local/edw/ecomm/${APP_ENV}/audit
LOG_FILE=$AUDIT_DIR/${EDWBatchId}_LOGFile.log

echo "             starting logging           " >$LOG_FILE
echo "********************************************************************" >>$LOG_FILE
echo "             initializing the parameters          " >>$LOG_FILE
echo "********************************************************************" >>$LOG_FILE

InpFile=/usr/local/edw/ecomm/$APP_ENV/common/config/dashboard_filelist.dat
TargetDir=/usr/local/edw/ecomm/$APP_ENV/dashboard
SourceDir=/usr/local/edw/ecomm/$APP_ENV/ftp

#---------------------------------------------------------------------------------------------------
#                        To Check the Parameter passed for Input File Name
#---------------------------------------------------------------------------------------------------

echo "       checking whether the input file is valid or not   " >>$LOG_FILE
echo "********************************************************************" >>$LOG_FILE


 if [ -a "$InpFile" ]
 then
                echo "File Exist" >>$LOG_FILE
 else
                echo " Not a valid Input file name "
                exit 1
 fi


echo "       fetching the filename from the input file   " >>$LOG_FILE
echo "********************************************************************" >>$LOG_FILE


#---------------------------------------------------------------------------------------------------
#                         Calculating The Number Of Lines In The Input File
#---------------------------------------------------------------------------------------------------

n=`wc -l "$InpFile"`
N1=`echo $n | cut -d" " -f1`

#---------------------------------------------------------------------------------------------------
#                         Moving The Files From The FTP Directory To Outbound Directory
#---------------------------------------------------------------------------------------------------

cd $SourceDir 

x=1
while [ "$x" -le "$N1" ]
do
b=`head -"$x" "$InpFile" | tail -1`
cp *$b* $TargetDir
echo "       copying file  :: $b " >>$LOG_FILE
x=`expr $x "+" 1`
done

echo "       files moved from the ftp directory to the outbound directory  " >>$LOG_FILE
echo "********************************************************************" >>$LOG_FILE

cd $TargetDir
zip -j all_dashborad_files_${EDWBatchId}.zip *.dat >> $LOG_FILE
rm *.dat


echo "*******************************************************************************************" >> $LOG_FILE
echo "************************Cleanup the 7 days older Archive Directory Files************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

filecount=`find . -mtime +7 -exec ls -1 {} \; | wc -l | awk '{print $1}'`
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >> $LOG_FILE
if [ $filecount -ne 0 ]
then
echo "List of Files candidate for clean up is: \n `find . -mtime +7 -exec ls -1 {} \;`" >> $LOG_FILE
for  filename in `find . -mtime +7 -exec ls -1 {} \;`
do
rm -f $filename  
CmdOut=$?
        if [ CmdOut -eq 0 ]
        then
        echo "File $filename removed successfully " >> $LOG_FILE
        else
        echo " cleanup of File $filename failed. Exiting the Script " >> $LOG_FILE
        exit 1
        fi  
done
else
     echo "There is no file present to be cleanup." >> $LOG_FILE
fi


echo "********************************************************************" >>$LOG_FILE
echo "       files removed from the outbound directory   " >>$LOG_FILE
echo "********************************************************************" >>$LOG_FILE


echo "       FINISHED  SUCCESSFULLY    " >>$LOG_FILE
echo "********************************************************************" >>$LOG_FILE
echo "********************************************************************" >>$LOG_FILE

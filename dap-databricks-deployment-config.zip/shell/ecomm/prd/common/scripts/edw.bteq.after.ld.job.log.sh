#!/bin/ksh
#DIR="$(cd "$(dirname "$0")" && pwd)"
#. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Chirag Patel & Hal Hale
#  File name:        edw.bteq.after.ld.job.log.sh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-05-2008
#         |                                           |  C Patel   |
#---------+-------------------------------------------+------------+-----------
#   1.1   |  Modified - Remove Duplicates from source |  C Patel   | 07-14-2008
#---------+-------------------------------------------+------------+-----------

DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

## SET SCRIPT PARAMETERS

SQSERVER=${1}
SQUSER=${2}
SQPWD=${3}
SQDB=${4}
LOGDTLFILENAME=${5}
LOGDTLTABLE=${6}
EDWBATCHID=${7}
DSPROJECT=${8}
DSJOBNAME=${9}
DSJOBINVOCATION=${10}
LOGBTEQOUT=${11}
LOGFILE=${12}

echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******                                                       *****" 
echo "*******        Log Events   Level logging to                  *****" 
echo "*******                Process Control                        *****" 
echo "*******                                                       *****" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*==================================================================" 
echo "|                                                                 *" 
echo "| `date +'%D %r'` STARTED edw.bteq.after.ld.job.log.sh            *" 
echo "|                                                                 *" 
echo "*==================================================================" 
echo " "                                                                   
echo "*************************************************************"       
echo "*  => DataStage Job Name= "$DSJOBNAME                                
echo "*  => Job Invocation ID = "$DSJOBINVOCATION                          
echo "*************************************************************"                                         
echo "*  =>TDDB           = "$SQDB                                         
echo "*  =>LOGDTLFILENAME = "$LOGDTLFILENAME                               
echo "*  =>LOGDTLTABLE    = "$LOGDTLTABLE                                  
echo "*  =>EDWBATCHID     = "$EDWBATCHID                                   
echo "*  =>DSPROJECT      = "$DSPROJECT                                    
echo "*  =>LOGBTEQOUT     = "$LOGBTEQOUT                                   
echo "*  =>LOGFILE        = "$LOGFILE                                      

#*************************************************************
#           REMOVE DUPLICATES FROM SOURCE DATA              #

REMDUPLOGDTLFILENAME=${LOGDTLFILENAME}_REMDUP
sort -d -u $LOGDTLFILENAME > $REMDUPLOGDTLFILENAME

#                                                           #
#*************************************************************

## INITIATE BTEQ SESSION AND INSERT JOB LOG DETAILS FOR THE CURRENT JOB.


 python3 << EOF 
import os
import sys
import pyodbc
import pandas as pd
from IPython.display import display
from npjet import *


def main():

  global cnxn
  cnxn = getDBConnectionSQLServer(Action.quietLevel)
  global cursor
  cursor = cnxn.cursor()
  # Import CSV
  REMDUPLOGDTLDATA = pd.read_csv ('$REMDUPLOGDTLFILENAME', sep='|', names=["projname", "batchid", "jobname", "jobinvocation", "eventmsg", "eventuser", "eventtype", "eventdttm"])   
  DF_REMDUPLOGDTLDATA = pd.DataFrame(REMDUPLOGDTLDATA)
  display(DF_REMDUPLOGDTLDATA)

  # FormatOptions.echoReqLevel = EchoReqLevel.OFF
  # FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  # Action.exportFileName = "$LOGBTEQOUT"
  # ExportOptions.colLimit = 100
  # Action.charSet = "ISO-8859-1"
  # Action.importFileName = "$REMDUPLOGDTLFILENAME"
  # ImportOptions.type = "VARTEXT"
  # ImportOptions.separator ="|"
  # Action.repeatCount = None

  for row in DF_REMDUPLOGDTLDATA.itertuples():
    cursor.execute("""
                INSERT INTO $SQDB.$LOGDTLTABLE (proj_name,edw_batch_id,job_name,job_invocation_id,evt_msg,evt_user,evt_type_cd,evt_dttm)
                 VALUES
                  (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                  cast(? as datetime2)
                  )""",
                row.projname, 
                row.batchid,
                row.jobname,
                row.jobinvocation,
                row.eventmsg,
                row.eventuser,
                row.eventtype,
                row.eventdttm,
                )
  cnxn.commit()


  #-- LOCKING ROW FOR ACCESS 
  try:
    cursor.execute("SELECT count(*) FROM $SQDB.$LOGDTLTABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCATION';")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  LOGBTEQOUT = cursor.fetchone()
  LOGBTEQOUT = LOGBTEQOUT[0]

  if (LOGBTEQOUT is None):
    LOGBTEQOUT=''  
  with open('$LOGBTEQOUT', 'w') as f:
    f.write(str(LOGBTEQOUT))

  return

  cursor.close()
  cnxn.close()

main()
EOF

BTEQ1_RC=$?
echo "BTEQ1_RC ="$BTEQ1_RC 

if [ $BTEQ1_RC -eq 1 ]
 then
  echo "*============================================================================" 
  echo "edw.bteq.after.ld.job.log.sh JOB FAILED. PLEASE CHECK."                                                                             
  echo "*============================================================================" 
  exit 1
fi


## VERIFY JOB LOG DETAILS HAVE BEEN INSERTED TO DATABASE ##

  if [ `cat $LOGBTEQOUT | tr -d ' '` = `cat $REMDUPLOGDTLFILENAME | wc -l | tr -d ' '` ]
    then
rm $LOGBTEQOUT;
rm $LOGDTLFILENAME;
rm $REMDUPLOGDTLFILENAME;
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******                                                       *****" 
echo "*******        Log Events   Level logging to                  *****" 
echo "*******                Process Control                        *****" 
echo "*******                                                       *****" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*==================================================================" 
echo "|                        ( SUCCESS )                              *" 
echo "| `date +'%D %r'` FINISHED edw.bteq.after.ld.job.log.sh           *" 
echo "*==================================================================" 
exit 0;
    else
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******                                                       *****" 
echo "*******        Log Events   Level logging to                  *****" 
echo "*******                Process Control                        *****" 
echo "*******                                                       *****" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*******************************************************************" 
echo "*==================================================================" 
echo "|                      (FAILED)                                   *" 
echo "| `date +'%D %r'` FINISHED edw.bteq.after.ld.job.log.sh           *" 
echo "*==================================================================" 
echo "*==================================================================" 
echo "|  Process will continue to the next step.  Notice that records   *" 
echo "|  may have been dropped due to duplicate records in source data. *" 
echo "*==================================================================" 
      exit 1;
  fi

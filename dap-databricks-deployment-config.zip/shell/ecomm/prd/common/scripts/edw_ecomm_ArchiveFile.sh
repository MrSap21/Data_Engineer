#!/bin/ksh

cleanup() {
  [[ -f $LOG_FILE ]] && cp $LOG_FILE $EDWROOT$APP_DIR_ARCHIVE && rm $LOG_FILE
}

DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------------------
# Author:		Manish Garg
# File Name:		edw_ecomm_ArchiveFile.sh
# Parameters:		EDW_BatchId.
# Called from:	None
# Purpose:		This Script will Archive the Files Processed by ETL.
#-----------------------------------------------------------------------------------------
#			MAINTENANCE HISTORY
#------------------------------------------------------------------------------------------
#	Revision		Description		Name				Date
#------------------------------------------------------------------------------------------
#	1.0		Initial Version	   Manish Garg		20-Jun-2009
#------------------------------------------------------------------------------------------

# if [[ `uname -n` == "dedwbt01" ]]
#  then
# 		export APP_ENV="tst"
#  else
# 		export APP_ENV="prd"
#  fi

NoOfParm="$#"
EDWBatchId="$1"
DS_PROJECT="$2"

. $EDWROOT/usr/local/edw/ecomm/${APP_ENV}/common/scripts/edw_ecomm_config.ksh $DS_PROJECT

AUDIT_DIR=$EDWROOT$APP_ROOT/audit
FTP_DIR=$EDWROOT$APP_ROOT/ftp
OUTBOUND_DIR=$EDWROOT$APP_ROOT/outbound
# LOG_FILE=$EDWROOT$APP_DIR_ARCHIVE/${EDWBatchId}_Ecomm_archive_LOGFile.log
LOG_FILE=/tmp/${EDWBatchId}_Ecomm_archive_LOGFile.log
exec >$LOG_FILE 2>&1

echo "*******************************************************************************************" >>$LOG_FILE
echo "************************edw_ecomm_ArchiveFile.sh initiated*********************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE
echo "Batch Id used is " $EDWBatchId >>$LOG_FILE
echo "Project Name is " $DS_PROJECT >>$LOG_FILE

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "*********************To Check the number of Parameters passed******************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

if [ $NoOfParm -ne 2 ]; then
  echo "--------USAGE-------------------------------------"
  echo "  $0  <EDWBatchId>  <DS_PROJECT>"
  echo "---------------------------------------------------"
  echo " Wrong Number of Parameters passed. No File is Copied. Exiting the Script " >>$LOG_FILE
  cleanup
  exit 1
fi

echo "Parameter Validation is Successful" >>$LOG_FILE

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "********Archiving the FTP Directory Files and Moving to the Archive Directory**************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$FTP_DIR"
TargetDir="$EDWROOT$APP_DIR_ARCHIVE"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for archiving in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  zip -j InpFile_$EDWBatchId $SourceDir/* >>$LOG_FILE
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir zipped successfully " >>$LOG_FILE
  else
    echo " Archival of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi

  mv InpFile_$EDWBatchId.zip $TargetDir
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir moved to Archive Folder successfully" >>$LOG_FILE
  else
    echo "Movement of Files Present in $SourceDir to Archival Directory Failed. Exiting the Script" >>$LOG_FILE
    cleanup
    exit 1
  fi

else
  echo "There is no file present in $SourceDir to be archived." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "**********Archiving the Output Directory Files and Moving to the Archive Directory*********" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$EDWROOT$APP_DIR_OUTPUT"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for archiving in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  zip -j OutFile_$EDWBatchId $SourceDir/* >>$LOG_FILE
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir zipped successfully " >>$LOG_FILE
  else
    echo " Archival of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi

  mv OutFile_$EDWBatchId.zip $TargetDir
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir moved to Archive Folder successfully" >>$LOG_FILE
  else
    echo "Movement of Files Present in $SourceDir to Archival Directory Failed. Exiting the Script" >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be archived." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "*********Archiving the Reject Directory Files and Moving to the Archive Directory**********" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$EDWROOT$APP_DIR_REJECT"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for archiving in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  zip -j RejFile_$EDWBatchId $SourceDir/* >>$LOG_FILE
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir zipped successfully " >>$LOG_FILE
  else
    echo " Archival of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi

  mv RejFile_$EDWBatchId.zip $TargetDir
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir moved to Archive Folder successfully" >>$LOG_FILE
  else
    echo "Movement of Files Present in $SourceDir to Archival Directory Failed. Exiting the Script" >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be archived." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "**********Archiving the Audit Directory Files and Moving to the Archive Directory**********" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$AUDIT_DIR"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for archiving in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  zip -j AuditFile_$EDWBatchId $SourceDir/* >>$LOG_FILE
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir zipped successfully " >>$LOG_FILE
  else
    echo " Archival of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi

  mv AuditFile_$EDWBatchId.zip $TargetDir
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir moved to Archive Folder successfully" >>$LOG_FILE
  else
    echo "Movement of Files Present in $SourceDir to Archival Directory Failed. Exiting the Script" >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be archived." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "********Archiving the Outbound Directory Files and Moving to the Archive Directory*********" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$OUTBOUND_DIR"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for archiving in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  zip -j DimCardFile_$EDWBatchId $SourceDir/* >>$LOG_FILE
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir zipped successfully " >>$LOG_FILE
  else
    echo " Archival of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi

  mv DimCardFile_$EDWBatchId.zip $TargetDir
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir moved to Archive Folder successfully" >>$LOG_FILE
  else
    echo "Movement of Files Present in $SourceDir to Archival Directory Failed. Exiting the Script" >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be archived." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
cd $TargetDir
echo "List of  Zip Files moved to Archive Directory is : " >>$LOG_FILE
echo "$(ls -l *_$EDWBatchId.zip) " >>$LOG_FILE

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************Script Ended Successfully******************************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE
cleanup
exit 0
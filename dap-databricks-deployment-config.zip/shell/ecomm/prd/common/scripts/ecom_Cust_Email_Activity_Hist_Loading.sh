#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Rajeev Kumar
#  File name:        ecom_Cust_Email_Activity_Hist_Loading.sh
#  Date:             05-15-2011
#  Description:      This BTEQ fetches data from STG_ECOM_CUST_ACTIVITY and Email Campaign Vendor Tables and Populates cust_email_activity_hist table.
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  Rajeev Kumar | 05-15-2011
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------



## INITIATE BTEQ SESSION AND TAKE COUNT
TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDStageDB=${4}
TDDB=${5}
LOGFILE=${6}
BATCHID=${7}




## INITIATE BTEQ SESSION AND TAKE COUNT

 

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  #-- .set sessions 24
  #-- .set echoreq off;
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 15
    return
  #/* This sql is for fetching data from STG_ECOM_CUST_ACTIVITY and Email Campaign Vendor Tables and Populate Cust_Email_Activity_Hist table. */
  executeSql([], [
    ("""Insert Into $TDDB.cust_email_activity_hist
(
        eml_addr
        ,actv_dt 
        ,edw_campgn_vndr_id
        ,sent_cnt
        ,open_cnt
        ,click_cnt
        ,edw_create_dttm
	,edw_batch_id 
)

SELECT	
     PTD.EMAIL_ADDR,
    CAST(to_char(PTD.ACTION_TM , 'YYYYMMDDBHH:MI:SS' ) AS DATE) as ACTION_TM ,
    PT.edw_campgn_vndr_id,
    Sum(case PTD.SOURCE_CODE when 'SEND' Then (case PTD.ACTION_CODE when 'S' Then 1 else 0 END) Else 0 END)   "sent_cnt",
    Sum(case PTD.SOURCE_CODE when 'HVWB' Then (case PTD.ACTION_CODE when 'G' Then 1 else 0 END) Else 0 END)  "open_cnt",
    Sum(case PTD.SOURCE_CODE when 'HVWB' Then (case PTD.ACTION_CODE when 'R' Then 1 else 0 END) Else 0 END)  "click_cnt",
    current_timestamp(0) "edw_create_dttm",	
    $BATCHID "edw_batch_id"
             	
FROM	
           	 $TDDB.email_campaign_vendor PT

INNER JOIN 	 $TDStageDB.STG_ECOM_CUST_ACTIVITY PTD
	ON	
           	 PT.campgn_id=PTD.CAMPAIGN_ID
	AND     PT.campgn_NAME=PTD.CAMPAIGN_NAME

WHERE	PTD.SOURCE_CODE In ('SEND','HVWB')
And PTD.ACTION_CODE In ('S','G','R')
Group By   PTD.EMAIL_ADDR,
PTD.ACTION_TM,PT.edw_campgn_vndr_id""",
    [])
  ])
  #-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
  #-- FUN_CAST_OPTR - add alias for select expression with FORMAT and/or CAST Operator
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 15
    return
  if (Action.activityCount == 0):
    Action.errorCodeOverride = 20
    return
  executeSql([], [
    ("""Delete from $TDStageDB.STG_ECOM_CUST_CRT""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 15
    return
  executeSql([], [
    ("""INSERT INTO $TDStageDB.STG_ECOM_CUST_CRT  (EMAIL_ADDR, CREATE_DT) 
SELECT eml_addr, MIN(actv_dt) AS create_dt FROM $TDDB.cust_email_activity_hist GROUP BY eml_addr""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 15
    return
  if (Action.activityCount == 0):
    Action.errorCodeOverride = 20
    return
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

 BTEQ2_RC=$?

if  [ $BTEQ2_RC -eq 0 ]
 then 


echo "*                                                                 *" >>$LOGFILE
echo "*=================================================================*" >> $LOGFILE
echo "|       Script completed successfully!!                           *" >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE
exit 0;
else 

echo "*                                                                 *" >>$LOGFILE
echo "*=================================================================*" >> $LOGFILE
echo "|       Script failed  successfully!!                           *" >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE
exit 1;
fi




  
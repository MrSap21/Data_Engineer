#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
RejectDir=$1
SchemaFile=$2
EDWBATCHID=$3
pADMINEMAILADDR="hcdss.support@walgreens.com"
Filename=${SchemaFile}_ms_lengthexceeds.rej.${EDWBATCHID}
cd $RejectDir

mail_to ()
{
read message
 echo "Hi Team,\n\n Rejected records captured from MS file $Filename.\n\n kindly check the ${Filename}\n Path: ${RejectDir} \n\n Thanks."|mailx -s "$message" $pADMINEMAILADDR 
}


if [ -s $Filename ]
 then
   echo "*==================================================================" >> $LOG_FILE
   echo "    ${Filename} has rejected records                                " >> $LOG_FILE
   echo "*==================================================================" >> $LOG_FILE
   echo "Rejected records captured from MS file ${Filename}" | mail_to >> $LOG_FILE
   fi








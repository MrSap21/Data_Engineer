#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------------------
# Author:               Manish Garg
# File Name:            edw_InputFileMovement.sh
# Parameters:           EDWBatchId.
# Called from:  None
# Purpose:              This Script will Move files from Inbound to ftp directory.
#-----------------------------------------------------------------------------------------
#                       MAINTENANCE HISTORY
#------------------------------------------------------------------------------------------
#       Revision                Description             Name                            Date
#------------------------------------------------------------------------------------------
#       1.0             Initial Version                 Manish Garg          19-Jun-2009
#        2.0               GQM Phase 2 Changes(POMS)    Lakshmi Narayana     05-May-2017
#                                                       Sathiyaprathiba N
#                                                       Krishnakarthik K
#------------------------------------------------------------------------------------------

if [[ `uname -n` == "da1nia-pfa003" ]]
 then
                export APP_ENV="dev"
 else
                export APP_ENV="prd"
 fi

EDWBatchId="$1"
DS_PROJECT="$2"
NoOfParm="$#"
. /usr/local/edw/ecomm/${APP_ENV}/common/scripts/edw_ecomm_config.ksh $DS_PROJECT
AUDIT_DIR=$APP_ROOT/audit
FTP_DIR=$APP_ROOT/ftp
ARCH_DIR=$APP_ROOT/archive
LOG_FILE=$AUDIT_DIR/${EDWBatchId}_InpFileMov_LOGFile.log
exec > $LOG_FILE 2>&1
echo "*******************************************************************************************" >> $LOG_FILE
echo "************************edw_ecomm_InputFileMovement.sh initiated***************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE
echo "Batch Id used is " $EDWBatchId >> $LOG_FILE
echo "Project Name is " $DS_PROJECT >> $LOG_FILE
echo "" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "*********************To Check the number of Parameters passed******************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE
if [ $NoOfParm -ne 2 ]
then
echo "--------USAGE-------------------------------------" >> $LOG_FILE
echo "  $0  <EDWBatchId> <DS Project Name>" >> $LOG_FILE
echo "---------------------------------------------------">> $LOG_FILE
echo " Wrong Number of Parameters passed. No File is Copied. Exiting the Script " >> $LOG_FILE
exit 1
fi

echo "Parameter Validation is Successful"  >> $LOG_FILE

cd $APP_DIR_INPUT

echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "****************To Get The Least Date Pattern from MD Trigegr File********************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

filecount=`ls -l MD_*.trg | wc -l`
if [ $filecount -ne 0 ]
then
PATSTR=`ls -1 MD_*.trg | awk '{ FS="_" ; print $2 }' | awk '{ FS="." ; print $1}'| sort -n | head -1`
echo "Least Date Pattern identified from MD trigger file is " $PATSTR >> $LOG_FILE
else
echo "MD trigger file is not present. Exiting the Script." >> $LOG_FILE
exit 1
fi

echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************To Copy the Least Date Master Data*******************************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

filecount=`ls -l MD_$PATSTR.zip | wc -l`
echo "Number of Master Data zip file matching least date pattern is: " $filecount >> $LOG_FILE
if [ $filecount -ne 0 ]
  then
     cp MD_$PATSTR.zip $FTP_DIR
     CpPhSt=$?
        if [ CpPhSt -eq 0 ]
        then
        echo "Master Data Extracts `ls -1 MD_$PATSTR.zip` copied successfully " >> $LOG_FILE
        else
        echo " MD Extract copying failed " >> $LOG_FILE
        exit 1
        fi
else
     echo "There is no MD zip file to be copied. Exiting the Script." >> $LOG_FILE
     exit 1
fi


echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************To Move the Least Date PH Extract********************************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

filecount=`ls -l PH_$PATSTR.trg | wc -l`
if [ $filecount -ne 0 ]
then
filecount_PH=`ls -l PH_$PATSTR.zip | wc -l`
echo "Number of PH Data zip file matching least date pattern is: " $filecount_PH >> $LOG_FILE
if [ $filecount_PH -ne 0 ]
  then
     cp PH_$PATSTR.zip $FTP_DIR
     CpPhSt=$?
        if [ CpPhSt -eq 0 ]
        then
        echo "Photo Extracts `ls -1 PH_$PATSTR.zip` copied successfully" >> $LOG_FILE
        else
        echo "Photo Extract Copying Failed" >> $LOG_FILE
         exit 1
        fi

     rm -f PH_$PATSTR.zip PH_$PATSTR.trg
     rmPhSt=$?
        if [ rmPhSt -eq 0 ]
        then
        echo "Photo Extracts PH_$PATSTR.zip and PH_$PATSTR.trg removed successfully from inbound directory" >> $LOG_FILE
        else
        echo "Photo Extract removal from inbound directory Failed" >> $LOG_FILE
         exit 1
        fi
else
     echo "There is no Photo zip file matching pattern $PATSTR to be copied." >> $LOG_FILE
fi
else
echo "There is no PH trigger file present matching pattern $PATSTR. No Photo Zip file is copied." >> $LOG_FILE
exit 1
fi


echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************To Move the Least Date RX Extract********************************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

filecount=`ls -l RX_$PATSTR.trg | wc -l`
if [ $filecount -ne 0 ]
then
filecount_RX=`ls -l RX_$PATSTR.zip | wc -l`
echo "Number of RX Data zip file matching least date pattern is: " $filecount_RX >> $LOG_FILE
if [ $filecount_RX -ne 0 ]
  then
     cp RX_$PATSTR.zip $FTP_DIR
     CpPhSt=$?
        if [ CpPhSt -eq 0 ]
        then
        echo "RX Extracts `ls -1 RX_$PATSTR.zip` copied successfully" >> $LOG_FILE
        else
        echo "RX Extract Copying Failed" >> $LOG_FILE
        exit 1
        fi

     rm -f RX_$PATSTR.zip RX_$PATSTR.trg
     rmRXSt=$?
        if [ rmRXSt -eq 0 ]
        then
        echo "RX Extracts RX_$PATSTR.zip and RX_$PATSTR.trg removed successfully from inbound directory" >> $LOG_FILE
        else
        echo "RX Extract removal from inbound directory Failed" >> $LOG_FILE
         exit 1
        fi
else
 echo "There is no RX zip file matching pattern $PATSTR to be copied." >> $LOG_FILE
fi
else
echo "There is no RX trigger file present matching pattern $PATSTR. No RX Zip file is copied." >> $LOG_FILE
exit 1
fi

echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************To Move the Least Date SS Extract********************************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

filecount=`ls -l SS_$PATSTR.trg | wc -l`
if [ $filecount -ne 0 ]
then
filecount_SS=`ls -l SS_$PATSTR.tar.gz | wc -l`
echo "Number of SS Data zip file matching least date pattern is: " $filecount_SS >> $LOG_FILE
if [ $filecount_SS -ne 0 ]
  then
     cp SS_$PATSTR.tar.gz $FTP_DIR
     CpPhSt=$?
        if [ CpPhSt -eq 0 ]
        then
        echo "SS Extracts `ls -1 SS_$PATSTR.tar.gz` copied successfully" >> $LOG_FILE
        else
        echo "SS Extract copying failed " >> $LOG_FILE
        exit 1
        fi

     rm -f SS_$PATSTR.tar.gz SS_$PATSTR.trg
     rmSSSt=$?
        if [ rmSSSt -eq 0 ]
        then
        echo "SS Extracts SS_$PATSTR.tar.gz and SS_$PATSTR.trg removed successfully from inbound directory" >> $LOG_FILE
        else
        echo "SS Extract removal from inbound directory Failed" >> $LOG_FILE
         exit 1
        fi
else
 echo "There is no SS zip file matching pattern $PATSTR to be copied." >> $LOG_FILE
fi
else
echo "There is no SS trigger file present matching pattern $PATSTR. No SS Zip file is copied." >> $LOG_FILE
exit 1
fi

#-------------- GQM Phase 2 Changes - New source for Photo files POMS is added here ----------------#
echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************To Move the Least Date POMS Extract********************************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

filecount=`ls -l POMS_$PATSTR.trg | wc -l`
if [ $filecount -ne 0 ]
then
filecount_POMS=`ls -l POMS_$PATSTR.zip | wc -l`
echo "Number of POMS Data zip file matching least date pattern is: " $filecount_POMS >> $LOG_FILE
if [ $filecount_POMS -ne 0 ]
  then
     cp POMS_$PATSTR.zip $FTP_DIR
     CpPOMSSt=$?
        if [ CpPOMSSt -eq 0 ]
        then
        echo "Photo Extracts `ls -1 POMS_$PATSTR.zip` copied successfully" >> $LOG_FILE
        else
        echo "Photo Extract Copying Failed" >> $LOG_FILE
         exit 1
        fi

     rm -f POMS_$PATSTR.zip POMS_$PATSTR.trg
     rmPOMSSt=$?
        if [ rmPOMSSt -eq 0 ]
        then
        echo "Photo Extracts POMS_$PATSTR.zip and POMS_$PATSTR.trg removed successfully from inbound directory" >> $LOG_FILE
        else
        echo "Photo Extract removal from inbound directory Failed" >> $LOG_FILE
         exit 1
        fi
else
     echo "There is no Photo POMS zip file matching pattern $PATSTR to be copied." >> $LOG_FILE
fi
else
#----------- Modifications as per the GQM Phase-2 (POMS source Team delay) : Starts here ----------#

#echo "There is no POMS trigger file present matching pattern $PATSTR. No Photo POMS Zip file is copied." >> $LOG_FILE
#exit 1
echo "**************************************************************************************" >> $LOG_FILE
echo " The POMS files are not available, hence creating zero byte files and proceeding with the flow. " >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

cd $FTP_DIR
DATESTR=`date +"%Y%m%d%H%M%S`
touch PHEXT001_POMS.dat.$DATESTR
touch PHEXT003_POMS.dat.$DATESTR
touch PHEXT005_POMS.dat.$DATESTR
touch PHEXT006_POMS.dat.$DATESTR
touch PHEXT007_POMS.dat.$DATESTR
touch PHEXT011_POMS.dat.$DATESTR
touch PHEXT016_POMS.dat.$DATESTR
touch PHEXT022_POMS.dat.$DATESTR

 echo "List of  POMS Files created : " >> $LOG_FILE
 echo "`ls -l *_POMS.*` " >> $LOG_FILE

fi


#------------- Modifications as per the GQM Phase-2 (POMS source Team delay) : Ends here -------------#

echo "" >> $LOG_FILE
echo "" >> $LOG_FILE


#-------Moditfication as per the ecom shipt to store changes --------------#


echo "**************************************************************************************" >> $LOG_FILE
echo "*********************Copy to archive and move POMS PHEXT023 file to FTP Directory*******" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE

cd $APP_DIR_INPUT
filecount=`ls -l PHEXT023_POMS.dat.* | wc -l`

if [ $filecount -ne 0 ]
then
echo "Number of PHEXT023_POMS* file  is: " $filecount >> $LOG_FILE


    cp PHEXT023_POMS.dat.* $ARCH_DIR

echo " PHEXT023_POMS* file  is copied to archive directory " >> $LOG_FILE

     mv PHEXT023_POMS.dat.* $FTP_DIR

     CpPOMS2S=$?
        if [ CpPOMS2S -eq 0 ]
        then
        echo "PHEXT023_POMS.dat copied successfully" >> $LOG_FILE
        else
        echo "PHEXT023_POMS.dat Copying Failed" >> $LOG_FILE
         exit 1
        fi

else
     echo "There is no Photo file PHEXT023_POMS to be  copied." >> $LOG_FILE

echo "**************************************************************************************" >> $LOG_FILE
echo " The PHEXT023_POMS  files is  not available, hence creating zero byte files and proceeding with the flow. " >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

cd $FTP_DIR
DATESTR=`date +"%Y%m%d%H%M%S`
touch PHEXT023_POMS.dat.$DATESTR
echo " PHEXT023_POMS  File created : " >> $LOG_FILE
echo "`ls -l PHEXT023_POMS.*` " >> $LOG_FILE

fi


#-------Moditfication as per the ecom shipt to store changes ------Ends Here------------------------#



echo "" >> $LOG_FILE
echo "" >> $LOG_FILE



cd $FTP_DIR

 echo "List of  Zip Files copied : " >> $LOG_FILE
 echo "`ls -l *_$PATSTR.zip` " >> $LOG_FILE
 echo "`ls -l *_$PATSTR.tar.gz` " >> $LOG_FILE


echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************To Unzip the File Moved******************************************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

for filename in *_$PATSTR.zip;
do
unzip -jo $filename >> $LOG_FILE
CpPhSt=$?
        if [ CpPhSt -eq 0 ]
        then
        echo "Unzip happened successfully for $filename " >> $LOG_FILE
        else
        echo " Unzip failed for $filename" >> $LOG_FILE
        exit 1
        fi
done

for filename in *_$PATSTR.tar.gz;
do
gzip -d $filename >> $LOG_FILE
tar -xvf *_$PATSTR.tar >> $LOG_FILE

CpPhSt=$?
        if [ CpPhSt -eq 0 ]
        then
        echo "Unzip happened successfully for $filename " >> $LOG_FILE
        else
        echo " Unzip failed for $filename" >> $LOG_FILE
        exit 1
        fi
done

echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "****To Handle missing fields and Copying contents of PHEXT003-01 in to PHEXT003*******" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

mv PHEXT003_????????.dat $ARCH_DIR
SFX_003=`ls -1 PHEXT003_01_????????.dat |awk -F_ '{print $NF}'`

#Handling the two missing fields(i.e. CUSTOMER_ID and TOKEN_ID) in the PHEXT003_01 file and writing to PHEXT003 file #
sed 's/$/^|^|-1/g' PHEXT003_01_????????.dat > PHEXT003.tmp

mv PHEXT003.tmp PHEXT003_${SFX_003}
rm -f PHEXT003_01_????????.dat

############################ Tokenisation project Changes ###################
####### RXEXT004,RXEXT005,RXEXT006 Files will no longer be supplied #########
####### from Source systems, Hence we are using RXEXT004_01,RXEXT005_01, ####
####### RXEXT006_01 files to generate the same for Datastage processing. ####

echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "****To delete the last 3 columns from RXEXT*_01 files and write into RXEXT* files ****" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

cd $FTP_DIR
cp RXEXT005_01_????????.dat RXEXT005_$PATSTR.dat
OutRx5St=$?
        if [ OutRx5St -eq 0 ]
        then
        echo "RXEXT005_*.dat has been successfully created from RXEXT005_01_*.dat " >> $LOG_FILE
        else
        echo "RXEXT005_*.dat file creation from RXEXT005_01_*.dat has been Failed" >> $LOG_FILE
        exit 1
        fi

for InpRxFile in RXEXT004_01_????????.dat RXEXT006_01_????????.dat
do
NF=`awk -F "|" 'END{print NF}' $InpRxFile`
NNF=`expr $NF - 3`
OutRxFile=`echo $InpRxFile | sed 's/_01//'`
cut -d "^|" -f1-$NNF $InpRxFile > $OutRxFile
OutRxSt=$?
        if [ OutRxSt -eq 0 ]
        then
        echo "$OutRxFile has been successfully created from $InpRxFile " >> $LOG_FILE
        else
        echo "$OutRxFile file creation from $InpRxFile has been Failed" >> $LOG_FILE
        exit 1
        fi
done


echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************To Delete the MD files copied************************************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

cd $APP_DIR_INPUT
rm -f MD_$PATSTR.zip MD_$PATSTR.trg
     rmMDSt=$?
        if [ rmMDSt -eq 0 ]
        then
        echo "MD Extracts MD_$PATSTR.zip and MD_$PATSTR.trg removed successfully from inbound directory" >> $LOG_FILE
        else
        echo "MD Extract removal from inbound directory Failed" >> $LOG_FILE
         exit 1
        fi


echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************To Delete the Zip files from FTP Directory***********************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

cd $FTP_DIR
echo "List of  Zip Files candidate for removal from FTP Directory are : " >> $LOG_FILE
echo "`ls -l *_$PATSTR.zip` " >> $LOG_FILE
echo "" >> $LOG_FILE
rm -f *_$PATSTR.zip
rmSt=$?
        if [ rmSt -eq 0 ]
        then
        echo "Zip files removed successfully from FTP directory" >> $LOG_FILE
        else
        echo "Zip files removal from FTP directory Failed" >> $LOG_FILE
         exit 1
        fi



echo "" >> $LOG_FILE
rm -f *_$PATSTR.tar
rmSt=$?
        if [ rmSt -eq 0 ]
        then
        echo "tar file removed successfully from FTP directory" >> $LOG_FILE
        else
        echo "tar file removal from FTP directory Failed" >> $LOG_FILE
         exit 1
        fi


echo "" >> $LOG_FILE
echo "List of Dat Files unzipped in ftp directory is:" >> $LOG_FILE
echo "`ls -1 *_$PATSTR.dat` " >> $LOG_FILE

echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************Script Ended Successfully******************************************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE


#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------------------
# Author:		Manish Garg
# File Name:		edw_ArchiveRem.sh
# Parameters:		EDW_BatchId.
# Called from:	None
# Purpose:		This Script will Remove the Files Processed by ETL.
#-----------------------------------------------------------------------------------------
#			MAINTENANCE HISTORY
#------------------------------------------------------------------------------------------
#	Revision		Description		Name				Date
#------------------------------------------------------------------------------------------
#	1.0		Initial Version	   Manish Garg		20-Jun-2009
#------------------------------------------------------------------------------------------


if [[ `uname -n` == "dedwbt01" ]]
 then
		export APP_ENV="tst"
 else
		export APP_ENV="prd"
 fi

NoOfParm="$#"
EDWBatchId="$1"
DS_PROJECT="$2"

. /usr/local/edw/ecomm/${APP_ENV}/common/scripts/edw_ecomm_config.ksh $DS_PROJECT

AUDIT_DIR=$APP_ROOT/audit
FTP_DIR=$APP_ROOT/ftp
LOG_FILE=$APP_DIR_ARCHIVE/${EDWBatchId}_Ecomm_cleanup_LOGFile.log
exec > $LOG_FILE 2>&1

echo "*******************************************************************************************" >> $LOG_FILE
echo "************************edw_ecomm_ArchiveFile.sh initiated*********************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE
echo "Batch Id used is " $EDWBatchId >> $LOG_FILE
echo "Project Name is " $DS_PROJECT >> $LOG_FILE

echo "" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "*********************To Check the number of Parameters passed******************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

if [ $NoOfParm -ne 2   ]
then
echo "--------USAGE-------------------------------------" 
echo "  $0  <EDWBatchId>  <DS_PROJECT>" 
echo "---------------------------------------------------"
echo " Wrong Number of Parameters passed. No File is Copied. Exiting the Script " >> $LOG_FILE
exit 1
fi

echo "Parameter Validation is Successful"  >> $LOG_FILE

echo "" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "************************Cleanup the Output Directory Files*********************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

SourceDir="$APP_DIR_OUTPUT"
cd $SourceDir

filecount=`ls -l $SourceDir/* | wc -l`
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >> $LOG_FILE
if [ $filecount -ne 0 ]
then
echo "List of Files candidate for clean up is: \n `ls -l $SourceDir/*`" >> $LOG_FILE
rm $SourceDir/*  
CmdOut=$?
        if [ CmdOut -eq 0 ]
        then
        echo "Files Present in $SourceDir removed successfully " >> $LOG_FILE
        else
        echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >> $LOG_FILE
        exit 1
        fi  
else
     echo "There is no file present in $SourceDir to be cleanup." >> $LOG_FILE
fi 


echo "" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "************************Cleanup the Reject Directory Files*********************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

SourceDir="$APP_DIR_REJECT"
cd $SourceDir

filecount=`ls -l $SourceDir/* | wc -l`
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >> $LOG_FILE
if [ $filecount -ne 0 ]
then
echo "List of Files candidate for clean up is: \n `ls -l $SourceDir/*`" >> $LOG_FILE
rm $SourceDir/*  
CmdOut=$?
        if [ CmdOut -eq 0 ]
        then
        echo "Files Present in $SourceDir removed successfully " >> $LOG_FILE
        else
        echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >> $LOG_FILE
        exit 1
        fi  
else
     echo "There is no file present in $SourceDir to be cleanup." >> $LOG_FILE
fi 


echo "" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "************************Cleanup the Audit Directory Files*********************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

SourceDir="$AUDIT_DIR"
cd $SourceDir

filecount=`ls -l $SourceDir/* | wc -l`
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >> $LOG_FILE
if [ $filecount -ne 0 ]
then
echo "List of Files candidate for clean up is: \n `ls -l $SourceDir/*`" >> $LOG_FILE
rm $SourceDir/*  
CmdOut=$?
        if [ CmdOut -eq 0 ]
        then
        echo "Files Present in $SourceDir removed successfully " >> $LOG_FILE
        else
        echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >> $LOG_FILE
        exit 1
        fi  
else
     echo "There is no file present in $SourceDir to be cleanup." >> $LOG_FILE
fi 


echo "" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "************************Cleanup the Teralog Directory Files*********************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

SourceDir="$APP_DIR_TERALOG"
cd $SourceDir

filecount=`ls -l $SourceDir/* | wc -l`
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >> $LOG_FILE
if [ $filecount -ne 0 ]
then
echo "List of Files candidate for clean up is: \n `ls -l $SourceDir/*`" >> $LOG_FILE
rm $SourceDir/*  
CmdOut=$?
        if [ CmdOut -eq 0 ]
        then
        echo "Files Present in $SourceDir removed successfully " >> $LOG_FILE
        else
        echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >> $LOG_FILE
        exit 1
        fi  
else
     echo "There is no file present in $SourceDir to be cleanup." >> $LOG_FILE
fi 


echo "" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "************************Cleanup the Process Control Directory Files************************" >> $LOG_FILE
echo "*******************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE

Control_DIR=$APP_ROOT/process/controlfile
SourceDir="$Control_DIR"
cd $SourceDir

filecount=`ls -l $SourceDir/* | wc -l`
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >> $LOG_FILE
if [ $filecount -ne 0 ]
then
echo "List of Files candidate for clean up is: \n `ls -l $SourceDir/*`" >> $LOG_FILE
rm $SourceDir/*  
CmdOut=$?
        if [ CmdOut -eq 0 ]
        then
        echo "Files Present in $SourceDir removed successfully " >> $LOG_FILE
        else
        echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >> $LOG_FILE
        exit 1
        fi  
else
     echo "There is no file present in $SourceDir to be cleanup." >> $LOG_FILE
fi 

echo "" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "*********************Script Ended Successfully******************************************" >> $LOG_FILE
echo "**************************************************************************************" >> $LOG_FILE
echo "" >> $LOG_FILE






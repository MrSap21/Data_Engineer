#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

FtptDir=$1
EDWBATCHID=$2
FTParch=$3

#--- Moving ATG & MS files to Archive directory ---#
cd $EDWROOT$FtptDir
date=`ls -1 SSEXT013_01_merge_atg_ms_${EDWBATCHID}.dat | awk -F_ '{print $6}'|cut -c 1-8`

mv SSEXT010_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat        $EDWROOT$FTParch
mv SSEXT013_01_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat    $EDWROOT$FTParch
mv SSEXT013_01_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat     $EDWROOT$FTParch
mv SSEXT013_02_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat    $EDWROOT$FTParch
mv SSEXT013_02_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat     $EDWROOT$FTParch
mv SSEXT014_01_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat    $EDWROOT$FTParch
mv SSEXT014_01_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat     $EDWROOT$FTParch
mv SSEXT014_02_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat    $EDWROOT$FTParch
mv SSEXT014_02_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat     $EDWROOT$FTParch
mv SSEXT005_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat        $EDWROOT$FTParch
mv SSEXT005_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat       $EDWROOT$FTParch
mv SSEXT006_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat       $EDWROOT$FTParch
mv SSEXT006_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat        $EDWROOT$FTParch
mv SSEXT009_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat       $EDWROOT$FTParch
mv SSEXT009_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat        $EDWROOT$FTParch
mv SSEXT008_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat       $EDWROOT$FTParch
mv SSEXT008_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat        $EDWROOT$FTParch
mv SSEXT004_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat       $EDWROOT$FTParch
mv SSEXT004_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat        $EDWROOT$FTParch
mv SSEXT007_01_atg_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat    $EDWROOT$FTParch
mv SSEXT007_ms_[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9].dat        $EDWROOT$FTParch

#mv PHEXT003_GQM_${EDWBATCHID}.dat $EDWROOT$FTParch

#date=`ls -1 SSEXT0??_????????.dat | awk -F_ '{print $3}'| awk -F. '{print $1}'`
#date=`ls -1 SSEXT013_01_merge_atg_ms_20190128011719.dat | awk -F_ '{print $6}'|cut -c 1-8`
#--- renaming remaining ATG & MS merged files according to successor EDW load jobs ---#
for f in `ls -1 SSEXT0??_??_merge_atg_ms_??????????????.dat | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}')
	 fnm1=$(echo $f | awk -F_ '{print $2}')
     #fts=$(echo $f | awk -F. '{print $3}')
echo $fnm
echo $fnm1
#echo $fts
mv $f ${fnm}_${fnm1}_${date}.dat
done

#--- renaming remaining ATG & MS merged files according to successor EDW load jobs ---#
for f in `ls -1 SSEXT0??_merge_atg_ms_??????????????.dat | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}')

echo $fnm
mv $f ${fnm}_${date}.dat
done

#--- renaming SSEXT026 & Master SSEXT files according to successor EDW load jobs ---#
for f in `ls -1 SSEXT0??_ms_????????.dat | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}') 
	 fts=$(echo $f | awk -F_ '{print $3}') 
echo $fnm
mv $f ${fnm}_${fts}
done

#--- renaming Master PHEXT files according to successor EDW load jobs ---#
for f in `ls -1 PHEXT0??_ms_????????.dat | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}') 
	 fts=$(echo $f | awk -F_ '{print $3}') 
echo $fnm
mv $f ${fnm}_${fts}
done

#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

FtptDir=$1
EDWBATCHID=$2
FTParch=$3

#--- Moving Phase-2 files to Archive directory ---#
cd $FtptDir

mv PHEXT001_gqm.dat* $FTParch
mv PHEXT003_gqm.dat* $FTParch
mv PHEXT005_gqm.dat* $FTParch
mv PHEXT006_gqm.dat* $FTParch
mv PHEXT007_gqm.dat* $FTParch
mv PHEXT011_gqm.dat* $FTParch
mv PHEXT016_gqm.dat* $FTParch
mv PHEXT001_POMS.dat* $FTParch
mv PHEXT003_POMS.dat* $FTParch
mv PHEXT005_POMS.dat* $FTParch
mv PHEXT006_POMS.dat* $FTParch
mv PHEXT007_POMS.dat* $FTParch
mv PHEXT011_POMS.dat* $FTParch
mv PHEXT016_POMS.dat* $FTParch
mv PHEXT022_POMS.dat* $FTParch
mv PHEXT022_POMS_clns.dat* $FTParch
mv PHEXT003_POMS_clns.dat* $FTParch
mv PHEXT003_GQM_${EDWBATCHID}.dat $FTParch
mv PHEXT023_POMS.dat* $FTParch


date=`ls -1 PHEXT002_gqm.dat.???????? | awk -F_ '{print $2}' | awk -F. '{print $3}'`
#--- renaming remaining GQM files according to successor jobs ---#
for f in `ls -1 PHEXT0??_gqm.dat.???????? | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}')
     fts=$(echo $f | awk -F. '{print $3}')
echo $fnm
echo $fts
mv $f ${fnm}_${date}.dat
done

#--- renaming remaining GQM merged files according to successor EDW load jobs ---#
for f in `ls -1 PHEXT0??_GP_$EDWBATCHID.dat | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}')

echo $fnm
mv $f ${fnm}_${date}.dat
done

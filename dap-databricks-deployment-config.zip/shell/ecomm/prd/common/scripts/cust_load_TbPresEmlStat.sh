#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Mahesh
#  File name:        cust_load_TbPresEmlStat.ksh
#  Date:             10-Jan-2014
#  Description:      This script would load ecom_prescription_email_status table.
#-------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#-------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+------------
#   1.0   |  Initial release.                         |EDW Offshore| 10-Jan-2014
#         |                                           |            |
#---------+-------------------------------------------+------------+------------

## SET SCRIPT PARAMETERS


if [[ `uname -n` == "dedwbt01" ]]
then
ENVR="dev"
DS_PROJECT="edw_ecommerce_dev"
else
ENVR="prd"
DS_PROJECT="edw_ecommerce_prd"
fi

## SET SCRIPT PARAMETERS


TDSERVER=$1
TDUSER=$2
TDPWD=$3
TDDB=$4
TDSTG=$5
TDLOGDIR=$6

LOGFILE=$TDLOGDIR/cust_load_TbPresEmlStat.log.`date +%Y%m%d%H%M`

echo "*************************************************************">> $LOGFILE
echo "*  =>TDSERVER      = $TDSERVER "                              >> $LOGFILE
echo "*  =>TDUSER        = $TDUSER   "                              >> $LOGFILE
echo "*  =>TDPWD         = ********  "                              >> $LOGFILE
echo "*  =>TDDB  	 = $TDDB     "                              >> $LOGFILE
echo "*  =>TDLOGDIR  	 = $TDLOGDIR "                              >> $LOGFILE
echo "*************************************************************">> $LOGFILE


python3 <<EOF>>$LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  executeSql([], [
    ("""insert into $TDDB.ecom_prescription_email_status
select * from $TDSTG.PresEmlStat_stg  where 
(
rx_eml_stat_id,
rx_nbr,
str_nbr,
eml_incmg_dt,
est_pickup_dt,
pat_id,
partial_fill_ind,
qty,
price_dlrs,
eml_incmg_tm,
est_pickup_tm
)
not in (
select 
rx_eml_stat_id,
rx_nbr,
str_nbr,
eml_incmg_dt,
est_pickup_dt,
pat_id,
partial_fill_ind,
qty,
price_dlrs,
eml_incmg_tm,
est_pickup_tm
from $TDDB.ecom_prescription_email_status)""",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode == 0):
    SUCCESS()
    return
  Action.exportFileName = None
  Action.errorCodeOverride = 3
  return
  SUCCESS()
def SUCCESS():
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ]
then
	echo "*==================================================================" >> $LOGFILE
	echo "|                      (FAILED)                                   *" >> $LOGFILE
	echo "| `date +'%D %r'` cust_load_TbPresEmlStat.ksh                     *" >> $LOGFILE
	echo "*==================================================================" >> $LOGFILE
	exit 1
else
	echo "*==================================================================" >> $LOGFILE
	echo "|                        ( SUCCESS )                              *" >> $LOGFILE
	echo "| `date +'%D %r'` cust_load_TbPresEmlStat.ksh                     *" >> $LOGFILE
	echo "*==================================================================" >> $LOGFILE
	exit 0
fi



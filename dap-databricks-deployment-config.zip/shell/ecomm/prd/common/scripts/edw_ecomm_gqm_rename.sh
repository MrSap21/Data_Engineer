#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

FtptDir=$1
ArchDir=$2

cd $FtptDir

#------- As part of  GQM Phase 2 Changes, This script renames input GQM photo files in such a way they will be processed in downstream Merge jobs.---------#
for f in `ls -1 PHEXT0??_????????.dat | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}')
     fts1=$(echo $f | awk -F_ '{print $2}')
     fts=$(echo $fts1 | awk -F. '{print $1}')
echo $fnm
echo $fts

mv $f ${fnm}_gqm.dat.${fts}


done 
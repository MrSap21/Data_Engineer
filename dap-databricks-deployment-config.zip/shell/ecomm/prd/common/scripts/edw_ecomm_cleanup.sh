#!/bin/ksh

cleanup() {
  [[ -f $LOG_FILE ]] && cp $LOG_FILE $EDWROOT$APP_DIR_ARCHIVE && rm $LOG_FILE
}

DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------------------
# Author:		Manish Garg
# File Name:		edw_ArchiveRem.sh
# Parameters:		EDW_BatchId.
# Called from:	None
# Purpose:		This Script will Remove the Files Processed by ETL.
#-----------------------------------------------------------------------------------------
#			MAINTENANCE HISTORY
#------------------------------------------------------------------------------------------
#	Revision		Description		Name				Date
#------------------------------------------------------------------------------------------
#	1.0		Initial Version	   		Manish Garg		20-Jun-2009
#	2.0		   GQM Phase 2 Changes(POMS)	Lakshmi Narayana     05-May-2017
#                                                       Sathiyaprathiba N
#                                                       Krishnakarthik K
#------------------------------------------------------------------------------------------

# if [[ `uname -n` == "da1nia-pfa003" ]]
#  then
# 		export APP_ENV="dev"
#  else
# 		export APP_ENV="prd"
#  fi

export APP_ENV="prd"

NoOfParm="$#"
EDWBatchId="$1"
DS_PROJECT="$2"

. $EDWROOT/usr/local/edw/ecomm/${APP_ENV}/common/scripts/edw_ecomm_config.ksh $DS_PROJECT

AUDIT_DIR=$EDWROOT$APP_ROOT/audit
FTP_DIR=$EDWROOT$APP_ROOT/ftp
# LOG_FILE=$EDWROOT$APP_DIR_ARCHIVE/${EDWBatchId}_Ecomm_cleanup_LOGFile.log
LOG_FILE=/tmp/${EDWBatchId}_Ecomm_cleanup_LOGFile.log
exec >$LOG_FILE 2>&1

echo "*******************************************************************************************" >>$LOG_FILE
echo "************************edw_ecomm_ArchiveFile.sh initiated*********************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE
echo "Batch Id used is " $EDWBatchId >>$LOG_FILE
echo "Project Name is " $DS_PROJECT >>$LOG_FILE

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "*********************To Check the number of Parameters passed******************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

if [ $NoOfParm -ne 2 ]; then
  echo "--------USAGE-------------------------------------"
  echo "  $0  <EDWBatchId>  <DS_PROJECT>"
  echo "---------------------------------------------------"
  echo " Wrong Number of Parameters passed. No File is Copied. Exiting the Script " >>$LOG_FILE
  cleanup
  exit 1
fi

echo "Parameter Validation is Successful" >>$LOG_FILE

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************Cleanup the Output Directory Files*********************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$EDWROOT$APP_DIR_OUTPUT"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  echo "List of Files candidate for clean up is: \n $(ls -l $SourceDir/*)" >>$LOG_FILE
  rm $SourceDir/*
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir removed successfully " >>$LOG_FILE
  else
    echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be cleanup." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************Cleanup the FTP Directory Files*********************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$FTP_DIR"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  echo "List of Files candidate for clean up is: \n $(ls -l $SourceDir/*)" >>$LOG_FILE
  rm $SourceDir/*
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir removed successfully " >>$LOG_FILE
  else
    echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be cleanup." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************Cleanup the Dataset Directory Files*********************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

Dataset_DIR=$EDWROOT$APP_ROOT/dataset
SourceDir="$Dataset_DIR"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  echo "List of Files candidate for clean up is: \n $(ls -l $SourceDir/*)" >>$LOG_FILE
  rm $SourceDir/*
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir removed successfully " >>$LOG_FILE
  else
    echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be cleanup." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************Cleanup the Reject Directory Files*********************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$EDWROOT$APP_DIR_REJECT"
cd $SourceDir
#------------- GQM Phase 2 Changes - Start here --------------#
#----------- Added Exception for PHEXT003 file during cleanup of reject directory , so that Reprocessing will be happening --------#
filecount=$(ls -l $SourceDir/* | grep -v 'PHEXT003' | wc -l)
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  echo "List of Files candidate for clean up is: \n $(ls -l $SourceDir/*)" >>$LOG_FILE
  find . -type f ! -name "Reprocess_PHEXT003.rej" -exec rm -rf {} \;
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir removed successfully " >>$LOG_FILE
  else
    echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be cleanup." >>$LOG_FILE
fi

#------------- GQM Phase 2 Changes - end here --------------#
echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************Cleanup the Audit Directory Files*********************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$AUDIT_DIR"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  echo "List of Files candidate for clean up is: \n $(ls -l $SourceDir/*)" >>$LOG_FILE
  rm $SourceDir/*
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir removed successfully " >>$LOG_FILE
  else
    echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be cleanup." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************Cleanup the Teralog Directory Files*********************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$EDWROOT$APP_DIR_TERALOG"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  echo "List of Files candidate for clean up is: \n $(ls -l $SourceDir/*)" >>$LOG_FILE
  rm $SourceDir/*
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir removed successfully " >>$LOG_FILE
  else
    echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be cleanup." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************Cleanup the Process Control Directory Files************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

Control_DIR=$EDWROOT$APP_ROOT/process/controlfile
SourceDir="$Control_DIR"
cd $SourceDir

filecount=$(ls -l $SourceDir/* | wc -l)
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  echo "List of Files candidate for clean up is: \n $(ls -l $SourceDir/*)" >>$LOG_FILE
  rm $SourceDir/*
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SourceDir removed successfully " >>$LOG_FILE
  else
    echo " cleanup of Files Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
    cleanup
    exit 1
  fi
else
  echo "There is no file present in $SourceDir to be cleanup." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "************************Cleanup the 7 days older Archive Directory Files************************" >>$LOG_FILE
echo "*******************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE

SourceDir="$EDWROOT$APP_DIR_ARCHIVE"
cd $SourceDir

filecount=$(find $SourceDir -type f -mtime +7 -exec ls -1 {} \; | wc -l | awk '{print $1}')
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >>$LOG_FILE
if [ $filecount -ne 0 ]; then
  echo "List of Files candidate for clean up is: \n $(find $SourceDir -type f -mtime +7 -exec ls -1 {} \;)" >>$LOG_FILE
  for filename in $(find $SourceDir -type f -mtime +7 -exec ls -1 {} \;); do
    rm $filename
    CmdOut=$?
    if [ CmdOut -eq 0 ]; then
      echo "File $filename Present in $SourceDir removed successfully " >>$LOG_FILE
    else
      echo " cleanup of File $filename Present in $SourceDir failed. Exiting the Script " >>$LOG_FILE
      cleanup
      exit 1
    fi
  done
else
  echo "There is no file present in $SourceDir to be cleanup." >>$LOG_FILE
fi

echo "" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "*********************Script Ended Successfully******************************************" >>$LOG_FILE
echo "**************************************************************************************" >>$LOG_FILE
echo "" >>$LOG_FILE
cleanup
exit 0

#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------------------
# Author:		Saurabh jain
# File Name:		ecom_edw_rej_analysis.Ksh
# Parameters:		Input FileName , Column Number , Header value and Output FileName
# Called from:	None
# Purpose:		This script will fetch all the unique values for that column number.
#-----------------------------------------------------------------------------------------
#			MAINTENANCE HISTORY
#------------------------------------------------------------------------------------------
#	Revision		Description		Name				Date
#------------------------------------------------------------------------------------------
#	1.0		Initial Version	   Saurabh jain		01-Oct-2009
#------------------------------------------------------------------------------------------

NoOfParm="$#" 

#---------------------------------------------------------------------------------------------------
#                         CHECKING THE NUMBER OF PARAMETERS PASSED
#---------------------------------------------------------------------------------------------------

 if [[ $NoOfParm -ne 4 ]]
 then
		echo " wrong number of parameters passed. Exiting the Script.. "
              exit 1
 fi


InputFileName="$1"
ColumnNo="$2"
HeaderValue="$3"
OutputFileName="$4"

REJECT_DIR=/usr/local/edw/ecomm/prd/reject
cd $REJECT_DIR

#---------------------------------------------------------------------------------------------------
#                        To Check the Parameter passed for Input File Name
#---------------------------------------------------------------------------------------------------

 if [ -a "$InputFileName" ]
 then 
		echo ""
 else 
		echo " Not a valid Input file name "
		exit 1
 fi

#---------------------------------------------------------------------------------------------------
#                        To Check Parameter Passed for Column Number  
#---------------------------------------------------------------------------------------------------

if [[ $ColumnNo -eq 0 ]]
 then
		echo " Column Number is Invalid "
              echo " Exiting the Script"
		exit 1
fi


#---------------------------------------------------------------------------------------------------
#                         CALCULATING THE NUMBER OF LINES IN THE INPUT FILE
#---------------------------------------------------------------------------------------------------

n=`wc -l $InputFileName`
N=`echo $n | cut -d" " -f1`

#---------------------------------------------------------------------------------------------------
#                 CUTTING THE REQUIRED COLUMN AND STORING IT IN A TEMPORARY FILE
#---------------------------------------------------------------------------------------------------
echo " Extracting the Required Column from the Input File...."
x=1
y=0
while [ "$x" -le "$N" ]
do
a=`head -"$x" $InputFileName | tail -1`
FldSep='\\^|'
TotNoOfColmns=`echo $a | awk -F"${FldSep}" '{print NF}'`
if [[ $TotNoOfColmns -lt $ColumnNo ]]
 then
	echo $a >> RejectFile.dat
	y=`expr $y "+" 1`
else
echo $a | awk -v awkvar=${ColumnNo} -F'\\^|' '{print $awkvar}' >> OutputFile.dat
fi
x=`expr $x "+" 1`
done
echo " total number of metadata mismatch records are : $y"
#---------------------------------------------------------------------------------------------------
#                                ADDING THE HEADER
#--------------------------------------------------------------------------------------------------

echo " Adding the Header to the Output File.... "
echo "$HeaderValue" > $OutputFileName

#---------------------------------------------------------------------------------------------------
#                                REMOVING THE DUPLICATES
#---------------------------------------------------------------------------------------------------

echo " Removing the Duplicates.... "
sort OutputFile.dat | uniq >> $OutputFileName

#---------------------------------------------------------------------------------------------------
#                                REMOVING THE TEMPORARY FILE
#---------------------------------------------------------------------------------------------------

rm -f OutputFile.dat


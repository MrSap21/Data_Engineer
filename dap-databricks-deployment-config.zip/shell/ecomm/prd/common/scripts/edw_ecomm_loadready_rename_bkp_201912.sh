#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

FtptDir=$1
EDWBATCHID=$2
FTParch=$3

#--- Moving Phase-2 files to Archive directory ---#
cd $FtptDir


mv PHEXT001_POMS.dat* $FTParch
mv PHEXT003_POMS.dat* $FTParch
mv PHEXT003_POMS_MAILORDER.dat* $FTParch
mv PHEXT004_POMS_MAILORDER.dat* $FTParch
mv PHEXT005_POMS.dat* $FTParch
mv PHEXT006_POMS.dat* $FTParch
mv PHEXT006_POMS_MAILORDER.dat* $FTParch
mv PHEXT007_POMS.dat* $FTParch
mv PHEXT007_POMS_MAILORDER.dat* $FTParch
mv PHEXT008_POMS_MAILORDER.dat* $FTParch
mv PHEXT011_POMS.dat* $FTParch
mv MPHEXT012_POMS.dat* $FTParch
mv PHEXT016_POMS.dat* $FTParch
mv PHEXT016_POMS_MAILORDER.dat* $FTParch
mv PHEXT017_POMS_MAILORDER.dat* $FTParch
mv PHEXT019_POMS_MAILORDER.dat* $FTParch
mv PHEXT023_POMS.dat* $FTParch



date=`ls -1 PHEXT003_GP_${EDWBATCHID}.dat | awk -F_ '{print $3}'|cut -c 1-8`
#--- renaming remaining GQM files according to successor jobs ---#
#for f in `ls -1 PHEXT0??_gqm.dat.???????? | awk -F/ '{print $NF}'`
#do
#     fnm=$(echo $f | awk -F_ '{print $1}')
#     fts=$(echo $f | awk -F. '{print $3}')
#echo $fnm
#echo $fts
#mv $f ${fnm}_${date}.dat
#done

#--- renaming remaining GQM merged files according to successor EDW load jobs ---#
for f in `ls -1 PHEXT0??_GP_$EDWBATCHID.dat | awk -F/ '{print $NF}'`
do
     fnm=$(echo $f | awk -F_ '{print $1}')

echo $fnm
mv $f ${fnm}_${date}.dat
done

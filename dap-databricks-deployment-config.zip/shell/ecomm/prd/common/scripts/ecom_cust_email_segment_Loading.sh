#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Rajeev Kumar
#  File name:        ecom_Cust_Email_Segnment Loading.sh
#  Date:             05-15-2011
#  Description:      This BTEQ fetches data from Email_Campaign_Vendor and cust_email_activity_hist Tables and Populate cust_email_segment table.
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  Rajeev Kumar | 05-15-2011
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------



## INITIATE BTEQ SESSION AND TAKE COUNT
TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDStageDB=${4}
TDDB=${5}
LOGFILE=${6}
BATCHID=${7}
SEGMENT_YR=${9}
SEGMENT_MN=${8}

RUNDTTM=$SEGMENT_YR-$SEGMENT_MN-01

## INITIATE BTEQ SESSION AND TAKE COUNT

 

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  #-- .set sessions 24
  #-- .set echoreq off;
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 15
    return
  #/* This sql is for fetching data from cust_email_activity_hist Table and Populate ccust_email_segment "River data" */
  executeSql([], [
    ("""Insert Into $TDDB.cust_email_segment

	Select 
	eml_addr
      ,'$RUNDTTM'
	, 'R' 
	,current_timestamp(0)
	,$BATCHID  

From

(Select
	a.eml_addr "eml_addr"
	,Sum (a.open_cnt) "tot_open_cnt"
	,Sum(a.sent_cnt) "tot_sent_cnt"
	,Sum(a.click_cnt) "tot_click_cnt"

From $TDDB.cust_email_activity_hist a,
$TDStageDB.STG_ECOM_CUST_CRT b
Where 
a.eml_addr = b.EMAIL_ADDR
AND b.CREATE_DT >= ADD_MONTHS('$RUNDTTM',-2)
group by a.eml_addr ) GRP
Where GRP.tot_open_cnt = 0 And GRP.tot_click_cnt =0
AND GRP.tot_sent_cnt<>0""",
    [])
  ])
  #/* .IF ACTIVITYCOUNT = 0 THEN .QUIT 20 */
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 15
    return
  #/* This sql is for fetching data from cust_email_activity_hist Table and Populate cust_email_segment "Lake data" */
  executeSql([], [
    ("""Insert Into $TDDB.cust_email_segment

	Select 
	eml_addr
      ,'$RUNDTTM'
	, 'L'
	,current_timestamp(0)
	,$BATCHID Qualify(Row_number() Over( partition by eml_addr  Order by actv_dt)=1)
From $TDDB.cust_email_activity_hist
Where actv_dt >= ADD_MONTHS('$RUNDTTM',-3)
And  (open_cnt<>'0'
Or click_cnt<>'0')
And eml_addr not in 
( Select eml_addr from $TDDB.cust_email_segment where segment_catg_cd_type='R' and segment_dt='$RUNDTTM')""",
    [])
  ])
  #/* .IF ACTIVITYCOUNT = 0 THEN .QUIT 20 */
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 15
    return
  #/* This sql is for fetching data from Populate cust_email_activity_hist Table and Populate cust_email_segment "Marsh data" */
  executeSql([], [
    ("""Insert Into $TDDB.cust_email_segment

	Select 
	eml_addr
      ,'$RUNDTTM'
	, 'M'
	,current_timestamp(0)
	,$BATCHID Qualify(Row_number() Over( partition by eml_addr  Order by actv_dt)=1)
From $TDDB.cust_email_activity_hist
Where actv_dt >= ADD_MONTHS('$RUNDTTM',-12)
and actv_dt < ADD_MONTHS('$RUNDTTM',-3)
And  (open_cnt<>'0'
Or click_cnt<>'0') And eml_addr not in 
( Select eml_addr from $TDDB.cust_email_segment where segment_catg_cd_type in ('R','L') and segment_dt='$RUNDTTM')""",
    [])
  ])
  #/* .IF ACTIVITYCOUNT = 0 THEN .QUIT 20 */
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 15
    return
  #/* This sql is for fetching data from Populate cust_email_activity_hist Table and Populate cust_email_segment "Swamp data" */
  executeSql([], [
    ("""Insert Into $TDDB.cust_email_segment

	Select 
	eml_addr
      ,'$RUNDTTM'
	, 'S'
	,current_timestamp(0)
	,$BATCHID Qualify(Row_number() Over( partition by eml_addr  Order by actv_dt)=1)
From
( Select eml_addr,actv_dt
From $TDDB.cust_email_activity_hist
Where actv_dt < ADD_MONTHS('$RUNDTTM',-12)
And  (open_cnt <>'0'
Or click_cnt <>'0')
And eml_addr not in 
( Select eml_addr from $TDDB.cust_email_segment where segment_catg_cd_type in ('R','L','M') and segment_dt='$RUNDTTM')

Union 

Select eml_addr, actv_dt
From $TDDB.cust_email_activity_hist
Where open_cnt='0'
And click_cnt='0'
And eml_addr not in 
( Select eml_addr from $TDDB.cust_email_segment where segment_catg_cd_type in ('R','L','M') and segment_dt='$RUNDTTM')
) A""",
    [])
  ])
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

 BTEQ2_RC=$?

if  [ $BTEQ2_RC -eq 0 ]
 then 
echo "*                                                                 *" >>$LOGFILE
echo "*=================================================================*" >> $LOGFILE
echo "|       Script completed successfully!!                           *" >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE
exit 0;
else 

echo "*                                                                 *" >>$LOGFILE
echo "*=================================================================*" >> $LOGFILE
echo "|       Script failed !!                                          *" >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE
exit 1;
fi




  
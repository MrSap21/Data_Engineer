#!/bin/sh
#------------------------------------------------------------------------------
#                      (C) Copyright 2009, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------
#  AUTHOR:           Satish 
#  FILE NAME:        EDW_POWERREPORTS_data_feed_postproc_v01.sh
#  DATE:             02-03-2012
#  DESCRIPTION:      THIS SCRIPT WILL SFTP EDW POWERREPORTS  DATA FEED FILE TO THE
#                    10.246.0.133  SERVER.
#------------------------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------------------------
# Revision|                Description                		      |    Name    |  Date
#---------+--------------------------------------------------------+-----------------------------
#   1.0   |  Initial release.                                      |  CHIRAG P  | 04-29-2010
#---------+--------------------------------------------------------+-----------------------------
#   2.0   | Modified for EDW POWERREPORT data extract              |  Satish N  | 02-03-2012
#------------------------------------------------------------------------------------------------
FTPSERVER=10.246.0.133
FTPUSER=powerreports
DIRLOADREADY=/usr/local/edw/pharmacy/prod/output/loadready
#EDWBATCHID=$1
LOG_FILE=/usr/local/edw/pharmacy/prod/audit/EDW_POWERREPORTS_`date +%m%d%H%M%S`.log

EDWRXEMLADDR=mahesh.singh@walgreens.com,niket.agarwal@walgreens.com
#EDWBATCHDT=`print $EDWBATCHID | cut -c1-8`
#WKFILE01=WK_data_feed_01_$EDWBATCHID.dat
#WKFILE02=WK_data_feed_02_$EDWBATCHID.dat
#SFTPWKFILE01=WK_data_feed_01_${EDWBATCHDT}.dat
#SFTPWKFILE02=WK_data_feed_02_${EDWBATCHDT}.dat

python3<<EOF 1>>${LOG_FILE} 2>&1
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  mainErrorLevel = Action.errorLevel
  Action.errorLevel = 0
  mainErrorCodeOverride = Action.errorCodeOverride
  Action.errorCodeOverride = None
  Action.exportFileName = "/usr/local/edw/pharmacy/prod/audit/EDW_POWERREPORTS_DATA_FILE1"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  Action.recordMode = False
  FormatOptions.format = "OFF"
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  FormatOptions.separator = "|"
  FormatOptions.heading = ""
  FormatOptions.width = 10000
  executeSql([], [
    ("""select (to_char(current_date(current_date) ,'yyyymmdd') ) as """"",
    [])
  ])
  #-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  Action.exportFileName = None
  return

main()
cleanup()
done()
EOF

python3<<EOF 1>>${LOG_FILE} 2>&1
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  sys.path.append("/usr/local/edwphrm")
  import _logon
  mainErrorLevel = Action.errorLevel
  Action.errorLevel = 0
  mainErrorCodeOverride = Action.errorCodeOverride
  Action.errorCodeOverride = None
  _logon.main()
  if(Action.errorLevel != 0 or Action.errorCodeOverride != None):
    return
  else:
    Action.errorLevel = mainErrorLevel
    Action.errorCodeOverride = mainErrorCodeOverride
  Action.exportFileName = "/usr/local/edw/pharmacy/prod/audit/EDW_POWERREPORTS_DATA_FILE2"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  Action.recordMode = False
  FormatOptions.format = "OFF"
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  FormatOptions.separator = "|"
  FormatOptions.heading = ""
  FormatOptions.width = 10000
  executeSql([], [
    ("""select MAX(edw_batch_id) as "" FROM prdedwvw.proc_cntrl_batch_detail WHERE proj_name ='edw_phrmrtn_prd' AND btch_stat='1'""",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  Action.exportFileName = None
  return

main()
cleanup()
done()
EOF
CURR_BATCH=$(cat /usr/local/edw/pharmacy/prod/audit/EDW_POWERREPORTS_DATA_FILE2 | tr -d ' ' | tr -d '.')
WKFILE01=$DIRLOADREADY/${CURR_BATCH}_EDW_service_type_Extract.txt
CURR_BATCH2=$(cat /usr/local/edw/pharmacy/prod/audit/EDW_POWERREPORTS_DATA_FILE1 | tr -d ' ' | tr -d '.')
SFTPWKFILE01=store_scorecard_${CURR_BATCH2}.txt


echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "--------------- STARTING SCRIPT WK_data_feed_postproc_v01.sh ----------------" >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "FTPSERVER        = " $FTPSERVER                                                >> $LOG_FILE
echo "FTPUSER          = " $FTPUSER                                                  >> $LOG_FILE
echo "DIRLOADREADY     = " $DIRLOADREADY                                             >> $LOG_FILE
echo "EDWBATCHID       = " $EDWBATCHID                                               >> $LOG_FILE
echo "LOG_FILE         = " $LOG_FILE                                                 >> $LOG_FILE
echo "EMAILTOADDR      = " $EMAILTOADDR                                              >> $LOG_FILE
echo "EDWBATCHDT       = " $EDWBATCHDT                                               >> $LOG_FILE
echo "WKFILE01         = " $WKFILE01                                                 >> $LOG_FILE
echo "WKFILE02         = " $WKFILE02                                                 >> $LOG_FILE
echo "SFTPWKFILE01     = " $SFTPWKFILE01                                             >> $LOG_FILE
echo "SFTPWKFILE02     = " $SFTPWKFILE02                                             >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "                                                                             " >> $LOG_FILE

###################################################################################
##### FTP NYCFILE01 AS LONG AS THE FILE EXISTS                                 #####
###################################################################################
if [ -s $WKFILE01 ]
then
  echo "------------------------------------" >> $LOG_FILE
  echo "GZIPPING / SENDING WK FILE 01       " >> $LOG_FILE
  echo "------------------------------------" >> $LOG_FILE
#tr -cd '[:print:]\012\011\000' < $DIRLOADREADY/$WKFILE01 > $DIRLOADREADY/$WKFILE01.v2
#gzip $DIRLOADREADY/$WKFILE01.v2
print "put $WKFILE01 '/home/powerreports/$SFTPWKFILE01'" > $DIRLOADREADY/EDW_POWERREPORTS_FILE01_SFTP_PUT_CMD.dat 
sftp -b $DIRLOADREADY/EDW_POWERREPORTS_FILE01_SFTP_PUT_CMD.dat $FTPUSER@$FTPSERVER
RC=$?
if [ $RC -ne 0 ]
then
  echo "-------------------------" >> $LOG_FILE
  echo "EDW POWERREPORTS FILE 01 SFTP FAILURE  " >> $LOG_FILE
  echo "-------------------------" >> $LOG_FILE
  uuencode $LOG_FILE $LOG_FILE | mail -s "EDW POWERREPORTS FILE 01 SFTP FAILURE - REQUIRES INVESTIGATION" $EDWRXEMLADDR
  rm $DIRLOADREADY/EDW_POWERREPORTS_FILE01_SFTP_PUT_CMD.dat
  rm /usr/local/edw/pharmacy/prod/audit/DATA_FILE2
  rm /usr/local/edw/pharmacy/prod/audit/DATA_FILE1
  exit 1
else
  echo "-------------------------" >> $LOG_FILE
  echo "EDW_POWERREPORTS FILE 01 SFTP SUCCESS  " >> $LOG_FILE
  echo "-------------------------" >> $LOG_FILE
  rm $DIRLOADREADY/EDW_POWERREPORTS_FILE01_SFTP_PUT_CMD.dat
  rm /usr/local/edw/pharmacy/prod/audit/EDW_POWERREPORTS_DATA_FILE2
  rm /usr/local/edw/pharmacy/prod/audit/EDW_POWERREPORTS_DATA_FILE1
fi

else
  echo "-------------------------" >> $LOG_FILE
  echo "EDW_POWERREPORTS  FILE 01 DOES NOT EXIST" >> $LOG_FILE
  echo "-------------------------" >> $LOG_FILE
  uuencode $LOG_FILE $LOG_FILE | mail -s "EDW_POWERREPORTS  FILE 01 DOES NOT EXIST - REQUIRES INVESTIGATION" $EDWRXEMLADDR
  exit 1
fi
exit 0;

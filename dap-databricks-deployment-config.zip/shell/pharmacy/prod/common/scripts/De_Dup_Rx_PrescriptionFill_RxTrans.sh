#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
APT_TERA_SYNC_DATABASE=$7
pTDDBName1=$8

TRGFILE=/usr/local/edw/pharmacy/prod/output/loadready/triggerfiles/etl_tbf0_rx_transaction_M_stg_load_completed.trig  

python3 << EOF
#!/usr/bin/python3

from npjet import *

def main():
  #/*================================================================**#** PERFORM STORE RELO UPDATES FOR TARGET TABLES                   **#**================================================================*/
  runSql("""UPDATE $pTDDBName.prescription_fill
 
set    str_nbr = R.relocate_to_str_nbr
 from   $pTDDBName1.location_store_relocation  R
 where  $pTDDBName.prescription_fill.str_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""UPDATE $pTDDBName.prescription_fill
 
set    fill_enter_str_nbr = R.relocate_to_str_nbr
 from   $pTDDBName1.location_store_relocation  R
 where  $pTDDBName.prescription_fill.fill_enter_str_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""UPDATE $pTDDBName.prescription_fill
 
set    fill_review_str_nbr = R.relocate_to_str_nbr
 from   $pTDDBName1.location_store_relocation  R
 where  $pTDDBName.prescription_fill.fill_review_str_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/*================================================================**#** PERFORM STORE RELO UPDATES FOR DEDUP TABLES                    **#**================================================================*/
  runSql("""UPDATE $pTDStageDB.etl_proc_dup_rx_tran_stg
 
set    store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName1.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_rx_tran_stg.store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""UPDATE $pTDStageDB.etl_proc_dup_rx_tran_stg
 
set    entered_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName1.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_rx_tran_stg.entered_store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""UPDATE $pTDStageDB.etl_proc_dup_rx_tran_stg
 
set    reviewed_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName1.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_rx_tran_stg.reviewed_store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/*================================================================**#** REMOVE PK UPDATES FOR STORE RELOS IN STAGE TABLES              **#**================================================================*/
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg txn 
using $pTDStageDB.etl_tbf0_rx_transaction_stg BFR, $pTDStageDB.etl_tbf0_rx_transaction_stg AFT, $pTDDBName1.location_store_relocation  SR 
where BFR.cdc_txn_commit_dttm = AFT.cdc_txn_commit_dttm
  and  BFR.cdc_seq_nbr = AFT.cdc_seq_nbr
  and  BFR.cdc_rba_nbr = AFT.cdc_rba_nbr
  and SR.relocate_fm_str_nbr = BFR.store_nbr
  and SR.relocate_to_str_nbr = AFT.store_nbr
  and  BFR.cdc_before_after_cd = 'BEFORE'
  and  AFT.cdc_before_after_cd = 'AFTER'
  and  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
  and  AFT.cdc_operation_type_cd = 'PK UPDATE'
  and BFR.store_nbr <> AFT.store_nbr
  and BFR.rx_nbr = AFT.rx_nbr
  and BFR.fill_nbr = AFT.fill_nbr
  and BFR.fill_partial_nbr = AFT.fill_partial_nbr
  and txn.cdc_txn_commit_dttm =  bfr.cdc_txn_commit_dttm
  and txn.cdc_seq_nbr =   bfr.cdc_seq_nbr
  and txn.cdc_rba_nbr =   bfr.cdc_rba_nbr
  and txn.cdc_operation_type_cd in ( 'PK UPDATE', 'SQL COMPUPDATE');
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/*==================================================**#**   DELETING  0 --> 9 PK UPDATES FROM STAGE#**=================================================**/
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg txn 
using $pTDStageDB.etl_tbf0_rx_transaction_stg BFR, $pTDStageDB.etl_tbf0_rx_transaction_stg AFT 
where BFR.cdc_txn_commit_dttm = AFT.cdc_txn_commit_dttm
  and  BFR.cdc_seq_nbr = AFT.cdc_seq_nbr
  and  BFR.cdc_rba_nbr = AFT.cdc_rba_nbr
  and  BFR.fill_partial_nbr=0
  and  AFT.fill_partial_nbr=9
  and  BFR.cdc_before_after_cd = 'BEFORE'
  and  AFT.cdc_before_after_cd = 'AFTER'
  and  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
  and  AFT.cdc_operation_type_cd = 'PK UPDATE'
  and BFR.store_nbr = AFT.store_nbr
  and BFR.rx_nbr = AFT.rx_nbr
  and BFR.fill_nbr = AFT.fill_nbr
  and BFR.fill_partial_nbr <> AFT.fill_partial_nbr
  and txn.cdc_txn_commit_dttm =  bfr.cdc_txn_commit_dttm
  and txn.cdc_seq_nbr =   bfr.cdc_seq_nbr
  and txn.cdc_rba_nbr =   bfr.cdc_rba_nbr
  and txn.cdc_operation_type_cd in ( 'PK UPDATE', 'SQL COMPUPDATE');
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/*================================================================**#** UPDATE STORE NUMBERS FOR STORE RELOS IN STAGE TABLES           **#**================================================================*/
  runSql("""UPDATE $pTDStageDB.etl_tbf0_rx_transaction_stg
 
set store_nbr = SR.relocate_to_str_nbr
 from  $pTDDBName1.location_store_relocation  SR
 where store_nbr = SR.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""UPDATE $pTDStageDB.etl_tbf0_rx_transaction_stg
 
set    entered_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName1.location_store_relocation  R
 where  $pTDStageDB.etl_tbf0_rx_transaction_stg.entered_store_nbr = R.relocate_fm_str_nbr
  and   $pTDStageDB.etl_tbf0_rx_transaction_stg.cdc_operation_type_cd='INSERT';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""UPDATE $pTDStageDB.etl_tbf0_rx_transaction_stg
 
set    reviewed_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName1.location_store_relocation  R
 where  $pTDStageDB.etl_tbf0_rx_transaction_stg.reviewed_store_nbr = R.relocate_fm_str_nbr
  and   $pTDStageDB.etl_tbf0_rx_transaction_stg.cdc_operation_type_cd='INSERT';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/*================================================================**#** PERFORM UPDATES FOR CHANGES TO RX CREATE DT IN TARGET TABLES   **#**================================================================*/
  runSql("""UPDATE $pTDDBName.prescription_fill Fill
    
set    rx_create_dt = STG.to_create_dt 
 FROM    (Select str_nbr ,rx_nbr ,cast(frm_create_dttm as date) frm_create_dt, cast(to_create_dttm as date) to_create_dt, change_prcs_ind
		FROM    $pTDStageDB.rx_create_dttm_change_stg
WHERE frm_create_dt <> to_create_dt
	
	GROUP BY 1,2,3,4,5
	
	)  STG
 where  Fill.str_nbr = STG.str_nbr
  AND Fill.rx_nbr = STG.rx_nbr
  AND Fill.rx_create_dt =  STG.frm_create_dt
  AND Fill.rx_create_dt IS NOT NULL
  AND STG.change_prcs_ind = 'N'
/*============================================================================================**
** ADDED THE BELOW STEP AS PART OF PHARMACY BATCH OPTIMIZATION ON 10/17/2017 BY SUPPORT TEAM. **
** THIS LOGIC WILL ALSO CAPTURE THE FILL SOLD Rx DATA FOR WHICH THE FILL Rx CREATE DATE IS    **
** GREATER THAN THE FILL Rx SOLD DATE                                                         **
**============================================================================================*/   
  AND (Fill.fill_sold_dt >= (select MIN(CAST(FRM_CREATE_DTTM AS DATE))-180 FROM $pTDStageDB.rx_create_dttm_change_stg) OR Fill.fill_sold_dt IS NULL);
-- SEL_BODY_CLAUSES_ORDER - change the order of all the clauses of a select statement
-- SEL_STATEMENT - Replace SEL with SELECT
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/*================================================================**#** PATIENT MERGE FIX LOGIC                                        **#**================================================================*/
  runSql("""DELETE FROM $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_M_stg;""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""INSERT INTO $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_M_stg
SELECT * from $pTDStageDB.etl_tbf0_rx_transaction_stg
WHERE rx_daw_ind='M'
AND CDC_OPERATION_TYPE_CD='INSERT';""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""DELETE FROM $pTDStageDB.etl_tbf0_rx_transaction_stg
WHERE rx_daw_ind='M'
AND CDC_OPERATION_TYPE_CD='INSERT';""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""DELETE FROM $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_M_stg
WHERE SRC_PARTITION_NBR <> (PAT_ID % 4) + 1;
-- EXPR_MOD - Change expression MOD to %
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""CREATE /*SET*/ temporary TABLE etl_tbf0_rx_transaction_M_stg1
     (
      cdc_txn_commit_dttm TIMESTAMP,
      cdc_seq_nbr INTEGER,
      cdc_rba_nbr DECIMAL(18,0),
      store_nbr DECIMAL(5,0) NOT NULL,
      rx_nbr DECIMAL(7,0) NOT NULL,
      fill_nbr DECIMAL(3,0),
      fill_partial_nbr DECIMAL(1,0),
      fill_entered_dttm TIMESTAMP,      
      src_partition_nbr BYTEINT,
	  edw_rank INTEGER)
ON COMMIT PRESERVE ROWS;
-- CREATE_SET_OPTION - Remove SET create table option, please review in insert statement!
-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- TABLE_INDEX - Remove table index options
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""insert into etl_tbf0_rx_transaction_M_stg1
select cdc_txn_commit_dttm ,cdc_seq_nbr , cdc_rba_nbr , store_nbr,rx_nbr,fill_nbr, fill_partial_nbr, fill_entered_dttm, src_partition_nbr, 
rank() over(partition by store_nbr,rx_nbr,fill_nbr, fill_partial_nbr, fill_entered_dttm 
order by cdc_txn_commit_dttm desc,cdc_seq_nbr desc, cdc_rba_nbr desc) edw_rank
from $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_M_stg
qualify edw_rank>=2;""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""DELETE FROM $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_M_stg
WHERE (cdc_txn_commit_dttm ,cdc_seq_nbr , cdc_rba_nbr , store_nbr,rx_nbr,fill_nbr, fill_partial_nbr, fill_entered_dttm, src_partition_nbr)
IN
(SELECT cdc_txn_commit_dttm ,cdc_seq_nbr , cdc_rba_nbr , store_nbr,rx_nbr,fill_nbr, fill_partial_nbr, fill_entered_dttm, src_partition_nbr
FROM etl_tbf0_rx_transaction_M_stg1);""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #Action.exportFileName = "${TRGFILE}"
  #ExportOptions.colLimit = 100
  #Action.charSet = "ISO-8859-1"
  runSql("""select ' ';""")
  #Action.exportFileName = None
  runSql("""UPDATE $pTDDBName.PRESCRIPTION_FILL TGT

SET PAT_ID = M.PAT_ID,
TGT.edw_batch_id = M.edw_batch_id
,SRC_PARTITION_NBR = M.SRC_PARTITION_NBR
FROM    $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_M_stg M
WHERE TGT.STR_NBR = M.STORE_NBR
AND TGT.RX_NBR = M.RX_NBR
AND TGT.RX_FILL_NBR = M.FILL_NBR
AND TGT.RX_PARTIAL_FILL_NBR = M.FILL_PARTIAL_NBR
AND TGT.FILL_ENTER_DT = CAST(M.FILL_ENTERED_DTTM AS DATE)
AND TGT.FILL_ENTER_TM = CAST(M.FILL_ENTERED_DTTM AS TIME(0))
AND TGT.PAT_ID <> M.PAT_ID;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""DROP TABLE if exists etl_tbf0_rx_transaction_M_stg1;
-- DROP_TBL: Add if exists in drop table
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/*================================================================**#** STARTING THE DEDUP LOGIC FROM HERE ON                          **#**================================================================*/
  #------------------------------------------------------
  #-- IDENTIFYING MUTLIPLE INSERTS IN THE SAME BATCH FOR FILL ENTER DTTM
  #------------------------------------------------------
  runSql("""insert into $pTDStageDB.etl_proc_dup_rx_tran_stg
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg 
,cob_dl_proc_msg 
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
, delivery_ind
, delivery_comments
, sold_local_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, routing_store_rph_inits
, source_system_name
, source_sys_trans_id
, sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
, gen_recip_nbr_returnd
, ntwk_reimb_id_returnd
, plan_returnd_grp_nbr
, plan_id_returnd
, general_pbr_nbr
, cob_general_pbr_nbr
, general_rph_nbr_qlfr
, prior_auth_cd
, prior_auth_nbr
, additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg 
,cob_dl_proc_msg 
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
, delivery_ind
, delivery_comments
, sold_local_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, routing_store_rph_inits
, source_system_name
, source_sys_trans_id
, sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
, gen_recip_nbr_returnd
, ntwk_reimb_id_returnd
, plan_returnd_grp_nbr
, plan_id_returnd
, general_pbr_nbr
, cob_general_pbr_nbr
, general_rph_nbr_qlfr
, prior_auth_cd
, prior_auth_nbr
, additional_mfgr_coupon_w1_msg
, wo_correlation_id
, wo_rx_count
, short_fill_ind
,db_cob_proc_ctrl_nbr


from $pTDStageDB.etl_tbf0_rx_transaction_stg
where (rx_nbr, store_nbr, fill_nbr, fill_partial_nbr)
in
( select rx_nbr, store_nbr, fill_nbr, fill_partial_nbr
from $pTDStageDB.etl_tbf0_rx_transaction_stg
where cdc_operation_type_cd = 'INSERT'
group by rx_nbr, store_nbr, fill_nbr, fill_partial_nbr
having count(distinct fill_entered_dttm) > 1 );
-- SYN_HAVING - Reformat syntax HAVING
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING THE MULTIPLE INSERTS IN SAME BATCH FOR FILL ENTER DTTM
  #------------------------------------------------------
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg
where (rx_nbr, store_nbr, fill_nbr, fill_partial_nbr)
in
( select rx_nbr, store_nbr, fill_nbr, fill_partial_nbr
from $pTDStageDB.etl_tbf0_rx_transaction_stg
where cdc_operation_type_cd = 'INSERT'
group by rx_nbr, store_nbr, fill_nbr, fill_partial_nbr
having count(distinct fill_entered_dttm) > 1 );
-- SYN_HAVING - Reformat syntax HAVING
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING TEST STORES
  #------------------------------------------------------
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg
 where store_nbr in
   (select store_nbr from $pTDStageDB.etl_proc_test_store_stg);""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- CREATING PERFORMANCE TABLE. SELECTS ALL THE KEYS FROM TGT.
  #-- THIS STEP WAS MOVED FROM BPT JOB TO HERE 2010-03-25
  #------------------------------------------------------
  runSql("""DELETE FROM $pTDStageDB.ETL_PROC_TRANS_FILL_STG; 
-- DEL_ALL - Remove ALL keyword from DELETE statement
""")
  if (Action.errorCode != 0):
    return
  runSql("""INSERT INTO $pTDStageDB.ETL_PROC_TRANS_FILL_STG
(
	 RX_NBR
	,STR_NBR
	,RX_CREATE_DT
	,RX_FILL_NBR
	,RX_PARTIAL_FILL_NBR
	,DSPN_FILL_NBR
	,PARTIAL_FILL_CD
	,PAT_ID
	,PBR_ID
	,PBR_LOC_ID
	,FILL_SOLD_DT
	,FILL_SOLD_TM
	,FILL_SOLD_DLRS
	,FILL_STAT_CD
	,FILL_QTY_DSPN
	,FILL_PAY_METHOD_CD
	,FILL_DAYS_SUPPLY
	,FILL_AWP_COST_DLRS
	,FILL_DISCNT_CD
	,FILL_DISCNT_DLRS
	,FILL_RTL_PRICE_DLRS
	,FILL_LABEL_PRICE_DLRS
	,FILL_VRFY_USER_ID
	,FILL_VRFY_DT
	,FILL_VRFY_TM
	,FILL_TYPE_CD
	,FILL_DEL_DT
	,FILL_DEL_TM
	,FILL_DATA_REVIEW_USER_ID
	,FILL_DATA_REVIEW_DT
	,FILL_DATA_REVIEW_TM
	,FILL_ENTER_USER_ID
	,FILL_ENTER_DT
	,FILL_ENTER_TM
	,FILL_SRC_CD
	,FILL_WAC_DLRS
	,FILLING_USER_ID
	,FILLING_DT
	,FILLING_TM
	,FILL_ENTER_STR_NBR
	,FILL_REVIEW_STR_NBR
	,DRUG_ID
	,DRUG_NAME
	,DEA_CLASS_CD
	,REFILLS_REMAIN_CNT
	,ORIG_REFILLS_REMAIN_WHEN_ENTER
	,TOT_AMT_PAID_IND
	,SIMS_UPC
	,OVERRIDE_USER_ID
	,OVERRIDE_DT
	,OVERRIDE_TM
	,RELOCATE_FM_STR_NBR
	,CREATE_USER_ID
	,CREATE_DTTM
	,EDW_BATCH_ID
	,UPDATE_USER_ID
	,UPDATE_DTTM
	,SRC_PARTITION_NBR
	,accept_consult_ind            
	,cash_disc_sav_dlrs            
	,data_rev_spec_dttm            
	,data_rev_spec_id              
	,data_rev_spec_str_nbr         
	,fax_image_id                  
	,fill_price_override_dlrs      
	,fill_rph_of_rec_id            
	,route_str_tech_inits          
	,drug_whse_ind                 
	,lvl_of_svc_cd                 
	,rx_daw_ind                    
	,sourcing_ind                  
	,tip_rsn_for_svc_cd            
	,fill_est_pick_up_dttm     
	,cost_plus_fee_cd
        ,celgene_md_auth_nbr
        ,celgene_conf_nbr
     ,fill_print_dt
     ,fill_print_tm
     ,pat_language_pref_cd
     ,fill_rebill_dt
     ,fill_rebill_tm
     ,fill_90day_ind
     ,fill_90day_stat_cd
	,pat_pickup_id
	,pickup_id
	,pickup_first_name
	,pickup_last_name
	,pickup_id_state
	,pickup_id_cntry
	,pickup_id_qlfr
	,pickup_rel_cd
	,dspn_ndc
	,overstock_ind
	,medicare_d_nte_ind
	,medicare_d_print_dttm
       ,partial_fill_tot_intended_qty
       ,triplicate_ser_nbr
	
	, delivery_cd
	, delivery_cmnts
	, fill_sold_local_dttm
	, orig_enter_dttm
	, pat_pickup_gov_auth
	, pat_pickup_id_qlfr
	, pat_pickup_relation_cd
	, route_str_rph_initials
	, src_sys_name
	, src_sys_txn_id
	, sys_stat_when_enter
,wo_correlation_id
                ,wo_rx_count
                ,short_fill_ind,
				/*Added as part of CR765300*/
				filling_store_nbr,
fill_verified_store_nbr,
mult_prod_review_ind,
pat_selct_user_id,
pbr_selct_user_id,
pat_selct_dttm,
pbr_selct_dttm,
pat_selct_str_nbr,
pbr_selct_str_nbr,
ntt_ind,
fill_sold_yr,
fill_enter_mnth

)
SELECT	TFILL.RX_NBR
	,TFILL.STR_NBR
	,TFILL.RX_CREATE_DT
	,TFILL.RX_FILL_NBR
	,TFILL.RX_PARTIAL_FILL_NBR
	,TFILL.DSPN_FILL_NBR
	,TFILL.PARTIAL_FILL_CD
	,TFILL.PAT_ID
	,TFILL.PBR_ID
	,TFILL.PBR_LOC_ID
	,TFILL.FILL_SOLD_DT
	,TFILL.FILL_SOLD_TM
	,TFILL.FILL_SOLD_DLRS
	,TFILL.FILL_STAT_CD
	,TFILL.FILL_QTY_DSPN
	,TFILL.FILL_PAY_METHOD_CD
	,TFILL.FILL_DAYS_SUPPLY
	,TFILL.FILL_AWP_COST_DLRS
	,TFILL.FILL_DISCNT_CD
	,TFILL.FILL_DISCNT_DLRS
	,TFILL.FILL_RTL_PRICE_DLRS
	,TFILL.FILL_LABEL_PRICE_DLRS
	,TFILL.FILL_VRFY_USER_ID
	,TFILL.FILL_VRFY_DT
	,TFILL.FILL_VRFY_TM
	,TFILL.FILL_TYPE_CD
	,TFILL.FILL_DEL_DT
	,TFILL.FILL_DEL_TM
	,TFILL.FILL_DATA_REVIEW_USER_ID
	,TFILL.FILL_DATA_REVIEW_DT
	,TFILL.FILL_DATA_REVIEW_TM
	,TFILL.FILL_ENTER_USER_ID
	,TFILL.FILL_ENTER_DT
	,TFILL.FILL_ENTER_TM
	,TFILL.FILL_SRC_CD
	,TFILL.FILL_WAC_DLRS
	,TFILL.FILLING_USER_ID
	,TFILL.FILLING_DT
	,TFILL.FILLING_TM
	,TFILL.FILL_ENTER_STR_NBR
	,TFILL.FILL_REVIEW_STR_NBR
	,TFILL.DRUG_ID
	,TFILL.DRUG_NAME
	,TFILL.DEA_CLASS_CD
	,TFILL.REFILLS_REMAIN_CNT
	,TFILL.ORIG_REFILLS_REMAIN_WHEN_ENTER
	,TFILL.TOT_AMT_PAID_IND
	,TFILL.SIMS_UPC
	,TFILL.OVERRIDE_USER_ID
	,TFILL.OVERRIDE_DT
	,TFILL.OVERRIDE_TM
	,TFILL.RELOCATE_FM_STR_NBR
	,TFILL.CREATE_USER_ID
	,TFILL.CREATE_DTTM
	,TFILL.EDW_BATCH_ID
	,TFILL.UPDATE_USER_ID
	,TFILL.UPDATE_DTTM
	,TFILL.SRC_PARTITION_NBR
	,TFILL.accept_consult_ind            
	,TFILL.cash_disc_sav_dlrs            
	,TFILL.data_rev_spec_dttm            
	,TFILL.data_rev_spec_id              
	,TFILL.data_rev_spec_str_nbr         
	,TFILL.fax_image_id                  
	,TFILL.fill_price_override_dlrs      
	,TFILL.fill_rph_of_rec_id            
	,TFILL.route_str_tech_inits          
	,TFILL.drug_whse_ind                 
	,TFILL.lvl_of_svc_cd                 
	,TFILL.rx_daw_ind                    
	,TFILL.sourcing_ind                  
	,TFILL.tip_rsn_for_svc_cd            
	,TFILL.fill_est_pick_up_dttm
	,TFILL.cost_plus_fee_cd
        ,TFILL.celgene_md_auth_nbr
        ,TFILL.celgene_conf_nbr
     ,TFILL.fill_print_dt
     ,TFILL.fill_print_tm
     ,TFILL.pat_language_pref_cd
     ,TFILL.fill_rebill_dt
     ,TFILL.fill_rebill_tm
     ,TFILL.fill_90day_ind
     ,TFILL.fill_90day_stat_cd
	,TFILL.pat_pickup_id
	,TFILL.pickup_id
	,TFILL.pickup_first_name
	,TFILL.pickup_last_name
	,TFILL.pickup_id_state
	,TFILL.pickup_id_cntry
	,TFILL.pickup_id_qlfr
	,TFILL.pickup_rel_cd
	,TFILL.dspn_ndc
	,TFILL.overstock_ind
	,TFILL.medicare_d_nte_ind
	,TFILL.medicare_d_print_dttm
       ,TFILL.partial_fill_tot_intended_qty
       ,TFILL.triplicate_ser_nbr
	
	, TFILL.delivery_cd
	, TFILL.delivery_cmnts
	, TFILL.fill_sold_local_dttm
	, TFILL.orig_enter_dttm
	, TFILL.pat_pickup_gov_auth
	, TFILL.pat_pickup_id_qlfr
	, TFILL.pat_pickup_relation_cd
	, TFILL.route_str_rph_initials
	, TFILL.src_sys_name
	, TFILL.src_sys_txn_id
	, TFILL.sys_stat_when_enter
,TFILL.wo_correlation_id
    ,TFILL.wo_rx_count
	,TFILL.short_fill_ind,
	/*Added as part of CR765300*/
	TFILL.filling_store_nbr,
TFILL.fill_verified_store_nbr,
TFILL.mult_prod_review_ind,
TFILL.pat_selct_user_id,
TFILL.pbr_selct_user_id,
TFILL.pat_selct_dttm,
TFILL.pbr_selct_dttm,
TFILL.pat_selct_str_nbr,
TFILL.pbr_selct_str_nbr,
TFILL.ntt_ind,
TFILL.fill_sold_yr,
TFILL.fill_enter_mnth
FROM	$pTDViewDBName.prescription_fill TFILL,
                    (
					 SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTERED_DTTM
					 FROM $pTDStageDB.etl_tbf0_rx_transaction_stg 
					 GROUP BY RX_NBR, STORE_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTERED_DTTM
					) B
WHERE TFILL.RX_NBR = B.RX_NBR
AND     TFILL.STR_NBR = B.STORE_NBR
AND     TFILL.RX_FILL_NBR = B.FILL_NBR
AND     TFILL.RX_PARTIAL_FILL_NBR = B.FILL_PARTIAL_NBR;
-- Below clause is commented so that this tables can be used for 730 day check as well
-- AND     TFILL.fill_enter_dt  = CAST ( B.fill_entered_dttm AS DATE )
-- AND     TFILL.fill_enter_tm  = CAST ( B.fill_entered_dttm AS TIME(0))""")
  if (Action.errorCode != 0):
    return
  #--call PRDUTIL.TABLE_STATS('$pTDStageDB', 'ETL_PROC_TRANS_FILL_STG');
  #if (Action.errorCode != 0):
  #  return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM RX DUPS TABLE
  #------------------------------------------------------
  runSql("""insert into $pTDStageDB.etl_proc_dup_rx_tran_stg
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg 
,cob_dl_proc_msg 
,proc_ctrl_nbr 
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
, delivery_ind
, delivery_comments
, sold_local_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, routing_store_rph_inits
, source_system_name
, source_sys_trans_id
, sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
, gen_recip_nbr_returnd
, ntwk_reimb_id_returnd
, plan_returnd_grp_nbr
, plan_id_returnd
, general_pbr_nbr
, cob_general_pbr_nbr
, general_rph_nbr_qlfr
, prior_auth_cd
, prior_auth_nbr
, additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
)
select 
RXT.cdc_txn_commit_dttm           
,RXT.cdc_seq_nbr                   
,RXT.cdc_rba_nbr                   
,RXT.cdc_operation_type_cd         
,RXT.cdc_before_after_cd           
,RXT.cdc_txn_position_cd           
,RXT.edw_batch_id                  
,RXT.store_nbr                     
,RXT.rx_nbr                        
,RXT.fill_nbr                      
,RXT.fill_partial_nbr              
,RXT.refills_remaining             
,RXT.fill_wac_cost_amt             
,RXT.plan_returnd_cost_amt         
,RXT.plan_returnd_fee_amt          
,RXT.plan_submtd_copay_amt         
,RXT.pbr_id                        
,RXT.fill_source_cd                
,RXT.refills_remain_when_ent       
,RXT.cob_plan_rtrnd_fee_amt        
,RXT.tot_amt_paid_ind              
,RXT.drug_class                    
,RXT.drug_name                     
,RXT.drug_id                       
,RXT.plan_returnd_copay_amt        
,RXT.plan_total_paid_amt           
,RXT.plan_returnd_tax_amt          
,RXT.plan_submtd_cost_amt          
,RXT.plan_submtd_fee_amt           
,RXT.plan_submtd_tax_amt           
,RXT.pat_id                        
,RXT.sims_upc                      
,RXT.pbr_loc_id                    
,RXT.create_user_id                
,RXT.create_dttm                   
,RXT.cob_plan_rtrnd_copay_amt      
,RXT.cob_plan_total_paid_amt       
,RXT.cob_plan_rtrnd_cost_amt       
,RXT.cob_plan_rtrnd_tax_amt        
,RXT.cob_plan_sbmtd_copay_amt      
,RXT.cob_plan_sbmtd_cost_amt       
,RXT.cob_plan_sbmtd_fee_amt        
,RXT.cob_plan_sbmtd_tax_amt        
,RXT.src_partition_nbr             
,RXT.fill_adjudication_cd          
,RXT.fill_awp_cost_amt             
,RXT.fill_days_supply              
,RXT.fill_entered_dttm             
,RXT.fill_label_price_amt          
,RXT.fill_qty_dispensed            
,RXT.fill_retail_price_amt         
,RXT.claim_reference_nbr           
,RXT.fill_nbr_dispensed            
,RXT.plan_id                       
,RXT.fill_status_cd                
,RXT.fill_entered_user_id          
,RXT.fill_verified_user_id         
,RXT.fill_verified_dttm            
,RXT.fill_sold_dttm                
,RXT.fill_deleted_dttm             
,RXT.fill_discount_cd              
,RXT.fill_pay_method_cd            
,RXT.fill_discount_amt             
,RXT.fill_sold_amt                 
,RXT.fill_type_cd                  
,RXT.update_user_id                
,RXT.update_dttm                   
,RXT.partial_fill_cd               
,RXT.fill_adjudication_dttm        
,RXT.cob_fill_adjudication_cd      
,RXT.cob_claim_ref_nbr             
,RXT.cob_plan_id                   
,RXT.cob_fill_adj_dttm             
,RXT.fill_data_rev_id              
,RXT.fill_data_rev_dttm            
,RXT.filling_user_id               
,RXT.filling_dttm                  
,RXT.override_user_id              
,RXT.override_dttm                 
,RXT.entered_store_nbr             
,RXT.reviewed_store_nbr            
,RXT.plan_gross_due_amt            
,RXT.cob_plan_gross_due_amt        
,RXT.DL_REJECT_CD_01               
,RXT.DL_REJECT_CD_02               
,RXT.DL_REJECT_CD_03               
,RXT.DL_REJECT_CD_04               
,RXT.DL_REJECT_CD_05               
,RXT.FILL_DEL_ADJUDICATION_CD      
,RXT.FILL_PRICE_OVERRIDE_AMT       
,RXT.PLAN_INCENTIVE_PAID_AMT       
,RXT.GENERAL_RECIPIENT_NBR         
,RXT.BIN_NBR                       
,RXT.PLAN_GROUP_NBR                
,RXT.DRUG_WAREHOUSE_IND            
,RXT.GENERAL_PHRM_NBR              
,RXT.REIMBURS_LOSS_AMT             
,RXT.COST_PLUS_FEE_CD              
,RXT.ACCEPT_CONSULT_IND            
,RXT.BASIS_OF_REIMB_DETERM         
,RXT.PLAN_OTHER_AMT_PAID           
,RXT.AMT_ATTRIBUTED_TO_TAX         
,RXT.PLAN_INCENT_AMT_SUBMTD        
,RXT.PLAN_OTHER_AMT_SUBMTD         
,RXT.LVL_OF_SVC_CD                 
,RXT.COB_DL_REJECT_CD_01           
,RXT.COB_DL_REJECT_CD_02           
,RXT.COB_DL_REJECT_CD_03           
,RXT.COB_DL_REJECT_CD_04           
,RXT.COB_DL_REJECT_CD_05           
,RXT.COB_FILL_DEL_ADJ_CD           
,RXT.COB_BIN_NBR                   
,RXT.COB_PLAN_GROUP_NBR            
,RXT.COB_GENERAL_PHRM_NBR          
,RXT.COB_BASIS_OF_REIMB_DETRM      
,RXT.COB_AMT_ATTRIB_TO_TAX         
,RXT.COB_PLN_OTHR_AMT_PD           
,RXT.CASH_DISC_SAV_AMT             
,RXT.GENERAL_RPH_NBR               
,RXT.ROUTING_STORE_TECH_INITS      
,RXT.SOURCING_IND                  
,RXT.MAJ_MED_PRIOR_AUTH_NBR        
,RXT.TIP_RSN_FOR_SVC_CD            
,RXT.DATA_REV_SPEC_ID              
,RXT.DATA_REV_SPEC_STORE_NBR       
,RXT.FILL_RPH_OF_RECORD_ID         
,RXT.COB_PLAN_INCNTV_PAID_AMT      
,RXT.COB_PLN_INCNT_AMT_SBMTD       
,RXT.fill_est_pick_up_dttm         
,RXT.data_rev_spec_dttm            
,RXT.rx_daw_ind                    
,RXT.relocate_fm_str_nbr           
,RXT.cob_gen_recipient_nbr
,RXT.celgene_md_auth_nbr
,RXT.celgene_conf_nbr
,RXT.plan_other_amt_paid_type
,RXT.plan_other_amt_subm_type
,RXT.plan_returnd_coins_amt
,RXT.plan_rtrnd_coins_amt
,RXT.plan_other_amt_paid_2
,RXT.plan_other_amt_paid_typ2
,RXT.plan_other_amt_paid_3
,RXT.plan_other_amt_paid_typ3
,RXT.fill_print_dttm
,RXT.pat_lang_pref_cd
,RXT.rebilling_dttm
,RXT.fill_90day_pref_ind
,RXT.fill_90day_pref_stat_cd
,RXT.pat_pickup_id
,RXT.pickup_id
,RXT.pickup_first_name
,RXT.pickup_last_name
,RXT.pickup_id_state
,RXT.pickup_id_country
,RXT.pickup_id_qlfr
,RXT.pickup_rel_cd
,RXT.dl_proc_msg 
,RXT.cob_dl_proc_msg 
,RXT.proc_ctrl_nbr 
,RXT.dispensed_ndc
,RXT.overstock_ind
,RXT.med_partd_notice_ind
,RXT.med_partd_print_dttm
,RXT.ben_stg_qualifier_1
,RXT.ben_stg_qualifier_2
,RXT.ben_stg_qualifier_3
,RXT.ben_stg_qualifier_4
,RXT.ben_stg_amount_1
,RXT.ben_stg_amount_2
,RXT.ben_stg_amount_3
,RXT.ben_stg_amount_4
,RXT.coupon_drug_id
,RXT.cob_coupon_drug_id
,RXT.coupon_ind
,RXT.cob_coupon_ind
,RXT.other_coverage_cd
,RXT.cob_other_coverage_cd
,RXT.partial_fil_intnded_qty
,RXT.triplicate_serial_nbr
,  RXT.delivery_ind
,  RXT.delivery_comments
,  RXT.sold_local_dttm
,  RXT.pat_pickup_gov_auth_id
,  RXT.pat_pickup_id_qlfr
,  RXT.pat_pickup_rel_cd
,  RXT.routing_store_rph_inits
,  RXT.source_system_name
,  RXT.source_sys_trans_id
,  RXT.sys_status_when_ent
, RXT.additional_msg_qlfr_w1_cd
, RXT.approved_msg_cd
, RXT.cob_approved_msg_cd
, RXT.approved_msg_cd_2
, RXT.cob_approved_msg_cd_2
, RXT.approved_msg_cd_3
, RXT.cob_approved_msg_cd_3
, RXT.approved_msg_cd_4
, RXT.cob_approved_msg_cd_4
, RXT.approved_msg_cd_5
, RXT.cob_approved_msg_cd_5
,  RXT.gen_recip_nbr_returnd
,  RXT.ntwk_reimb_id_returnd
,  RXT.plan_returnd_grp_nbr
,  RXT.plan_id_returnd
,  RXT.general_pbr_nbr
,  RXT.cob_general_pbr_nbr
,  RXT.general_rph_nbr_qlfr
,  RXT.prior_auth_cd
,  RXT.prior_auth_nbr
, RXT.additional_mfgr_coupon_w1_msg
, RXT.wo_correlation_id
, RXT.wo_rx_count
, RXT.short_fill_ind
, RXT.db_cob_proc_ctrl_nbr


from $pTDStageDB.etl_tbf0_rx_transaction_stg RXT,
  (SELECT store_nbr, rx_nbr, MAX(create_dttm) create_dttm FROM $pTDStageDB.etl_proc_dup_rx_stg
  GROUP BY store_nbr, rx_nbr ) DUP
 where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
AND CAST( RXT.fill_entered_dttm AS DATE) <= 
(case when RXT.store_nbr = 3397 then CAST( DUP.create_dttm AS DATE) + 365
else CAST( DUP.create_dttm AS DATE) + 730 END);""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--------------------------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM ETL PROC DUPS TABLE /*2019-05-03 fix
  #--------------------------------------------------------------------------
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg RXT
 where (store_nbr, rx_nbr, fill_entered_dttm) IN
 (
 SELECT  TRANS_tbl.store_nbr, TRANS_tbl.rx_nbr, TRANS_tbl.fill_entered_dttm
from (select * from  $pTDStageDB.etl_tbf0_rx_transaction_stg where store_nbr =3397)TRANS_tbl,
   (SELECT store_nbr, rx_nbr, MAX(create_dttm) create_dttm FROM $pTDStageDB.etl_proc_dup_rx_stg
  GROUP BY store_nbr, rx_nbr ) DUP
where TRANS_tbl.store_nbr = DUP.store_nbr
 and TRANS_tbl.rx_nbr = DUP.rx_nbr
AND CAST( TRANS_tbl.fill_entered_dttm AS DATE) <= CAST( DUP.create_dttm AS DATE) + 365
);""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg RXT
 where (store_nbr, rx_nbr, fill_entered_dttm) IN
 (
 SELECT  TRANS_tbl.store_nbr, TRANS_tbl.rx_nbr, TRANS_tbl.fill_entered_dttm
from (select * from  $pTDStageDB.etl_tbf0_rx_transaction_stg where store_nbr <>3397)TRANS_tbl,
   (SELECT store_nbr, rx_nbr, MAX(create_dttm) create_dttm FROM $pTDStageDB.etl_proc_dup_rx_stg
  GROUP BY store_nbr, rx_nbr ) DUP
where TRANS_tbl.store_nbr = DUP.store_nbr
 and TRANS_tbl.rx_nbr = DUP.rx_nbr
AND CAST( TRANS_tbl.fill_entered_dttm AS DATE) <= CAST( DUP.create_dttm AS DATE) + 730
);""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM FILL DUPS TABLE
  #------------------------------------------------------
  runSql("""insert into $pTDStageDB.etl_proc_dup_rx_tran_stg
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg 
,cob_dl_proc_msg 
,proc_ctrl_nbr 
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
)
select 
RXT.cdc_txn_commit_dttm           
,RXT.cdc_seq_nbr                   
,RXT.cdc_rba_nbr                   
,RXT.cdc_operation_type_cd         
,RXT.cdc_before_after_cd           
,RXT.cdc_txn_position_cd           
,RXT.edw_batch_id                  
,RXT.store_nbr                     
,RXT.rx_nbr                        
,RXT.fill_nbr                      
,RXT.fill_partial_nbr              
,RXT.refills_remaining             
,RXT.fill_wac_cost_amt             
,RXT.plan_returnd_cost_amt         
,RXT.plan_returnd_fee_amt          
,RXT.plan_submtd_copay_amt         
,RXT.pbr_id                        
,RXT.fill_source_cd                
,RXT.refills_remain_when_ent       
,RXT.cob_plan_rtrnd_fee_amt        
,RXT.tot_amt_paid_ind              
,RXT.drug_class                    
,RXT.drug_name                     
,RXT.drug_id                       
,RXT.plan_returnd_copay_amt        
,RXT.plan_total_paid_amt           
,RXT.plan_returnd_tax_amt          
,RXT.plan_submtd_cost_amt          
,RXT.plan_submtd_fee_amt           
,RXT.plan_submtd_tax_amt           
,RXT.pat_id                        
,RXT.sims_upc                      
,RXT.pbr_loc_id                    
,RXT.create_user_id                
,RXT.create_dttm                   
,RXT.cob_plan_rtrnd_copay_amt      
,RXT.cob_plan_total_paid_amt       
,RXT.cob_plan_rtrnd_cost_amt       
,RXT.cob_plan_rtrnd_tax_amt        
,RXT.cob_plan_sbmtd_copay_amt      
,RXT.cob_plan_sbmtd_cost_amt       
,RXT.cob_plan_sbmtd_fee_amt        
,RXT.cob_plan_sbmtd_tax_amt        
,RXT.src_partition_nbr             
,RXT.fill_adjudication_cd          
,RXT.fill_awp_cost_amt             
,RXT.fill_days_supply              
,RXT.fill_entered_dttm             
,RXT.fill_label_price_amt          
,RXT.fill_qty_dispensed            
,RXT.fill_retail_price_amt         
,RXT.claim_reference_nbr           
,RXT.fill_nbr_dispensed            
,RXT.plan_id                       
,RXT.fill_status_cd                
,RXT.fill_entered_user_id          
,RXT.fill_verified_user_id         
,RXT.fill_verified_dttm            
,RXT.fill_sold_dttm                
,RXT.fill_deleted_dttm             
,RXT.fill_discount_cd              
,RXT.fill_pay_method_cd            
,RXT.fill_discount_amt             
,RXT.fill_sold_amt                 
,RXT.fill_type_cd                  
,RXT.update_user_id                
,RXT.update_dttm                   
,RXT.partial_fill_cd               
,RXT.fill_adjudication_dttm        
,RXT.cob_fill_adjudication_cd      
,RXT.cob_claim_ref_nbr             
,RXT.cob_plan_id                   
,RXT.cob_fill_adj_dttm             
,RXT.fill_data_rev_id              
,RXT.fill_data_rev_dttm            
,RXT.filling_user_id               
,RXT.filling_dttm                  
,RXT.override_user_id              
,RXT.override_dttm                 
,RXT.entered_store_nbr             
,RXT.reviewed_store_nbr            
,RXT.plan_gross_due_amt            
,RXT.cob_plan_gross_due_amt        
,RXT.DL_REJECT_CD_01               
,RXT.DL_REJECT_CD_02               
,RXT.DL_REJECT_CD_03               
,RXT.DL_REJECT_CD_04               
,RXT.DL_REJECT_CD_05               
,RXT.FILL_DEL_ADJUDICATION_CD      
,RXT.FILL_PRICE_OVERRIDE_AMT       
,RXT.PLAN_INCENTIVE_PAID_AMT       
,RXT.GENERAL_RECIPIENT_NBR         
,RXT.BIN_NBR                       
,RXT.PLAN_GROUP_NBR                
,RXT.DRUG_WAREHOUSE_IND            
,RXT.GENERAL_PHRM_NBR              
,RXT.REIMBURS_LOSS_AMT             
,RXT.COST_PLUS_FEE_CD              
,RXT.ACCEPT_CONSULT_IND            
,RXT.BASIS_OF_REIMB_DETERM         
,RXT.PLAN_OTHER_AMT_PAID           
,RXT.AMT_ATTRIBUTED_TO_TAX         
,RXT.PLAN_INCENT_AMT_SUBMTD        
,RXT.PLAN_OTHER_AMT_SUBMTD         
,RXT.LVL_OF_SVC_CD                 
,RXT.COB_DL_REJECT_CD_01           
,RXT.COB_DL_REJECT_CD_02           
,RXT.COB_DL_REJECT_CD_03           
,RXT.COB_DL_REJECT_CD_04           
,RXT.COB_DL_REJECT_CD_05           
,RXT.COB_FILL_DEL_ADJ_CD           
,RXT.COB_BIN_NBR                   
,RXT.COB_PLAN_GROUP_NBR            
,RXT.COB_GENERAL_PHRM_NBR          
,RXT.COB_BASIS_OF_REIMB_DETRM      
,RXT.COB_AMT_ATTRIB_TO_TAX         
,RXT.COB_PLN_OTHR_AMT_PD           
,RXT.CASH_DISC_SAV_AMT             
,RXT.GENERAL_RPH_NBR               
,RXT.ROUTING_STORE_TECH_INITS      
,RXT.SOURCING_IND                  
,RXT.MAJ_MED_PRIOR_AUTH_NBR        
,RXT.TIP_RSN_FOR_SVC_CD            
,RXT.DATA_REV_SPEC_ID              
,RXT.DATA_REV_SPEC_STORE_NBR       
,RXT.FILL_RPH_OF_RECORD_ID         
,RXT.COB_PLAN_INCNTV_PAID_AMT      
,RXT.COB_PLN_INCNT_AMT_SBMTD       
,RXT.fill_est_pick_up_dttm         
,RXT.data_rev_spec_dttm            
,RXT.rx_daw_ind                    
,RXT.relocate_fm_str_nbr           
,RXT.cob_gen_recipient_nbr
,RXT.celgene_md_auth_nbr
,RXT.celgene_conf_nbr
,RXT.plan_other_amt_paid_type
,RXT.plan_other_amt_subm_type
,RXT.plan_returnd_coins_amt
,RXT.plan_rtrnd_coins_amt
,RXT.plan_other_amt_paid_2
,RXT.plan_other_amt_paid_typ2
,RXT.plan_other_amt_paid_3
,RXT.plan_other_amt_paid_typ3
,RXT.fill_print_dttm
,RXT.pat_lang_pref_cd
,RXT.rebilling_dttm
,RXT.fill_90day_pref_ind
,RXT.fill_90day_pref_stat_cd
,RXT.pat_pickup_id
,RXT.pickup_id
,RXT.pickup_first_name
,RXT.pickup_last_name
,RXT.pickup_id_state
,RXT.pickup_id_country
,RXT.pickup_id_qlfr
,RXT.pickup_rel_cd
,RXT.dl_proc_msg 
,RXT.cob_dl_proc_msg 
,RXT.proc_ctrl_nbr 
,RXT.dispensed_ndc
,RXT.overstock_ind
,RXT.med_partd_notice_ind
,RXT.med_partd_print_dttm
,RXT.ben_stg_qualifier_1
,RXT.ben_stg_qualifier_2
,RXT.ben_stg_qualifier_3
,RXT.ben_stg_qualifier_4
,RXT.ben_stg_amount_1
,RXT.ben_stg_amount_2
,RXT.ben_stg_amount_3
,RXT.ben_stg_amount_4
,RXT.coupon_drug_id
,RXT.cob_coupon_drug_id
,RXT.coupon_ind
,RXT.cob_coupon_ind
,RXT.other_coverage_cd
,RXT.cob_other_coverage_cd
,RXT.partial_fil_intnded_qty
,RXT.triplicate_serial_nbr
,  RXT.delivery_ind
,  RXT.delivery_comments
,  RXT.sold_local_dttm
,  RXT.pat_pickup_gov_auth_id
,  RXT.pat_pickup_id_qlfr
,  RXT.pat_pickup_rel_cd
,  RXT.routing_store_rph_inits
,  RXT.source_system_name
,  RXT.source_sys_trans_id
,  RXT.sys_status_when_ent
, RXT.additional_msg_qlfr_w1_cd
, RXT.approved_msg_cd
, RXT.cob_approved_msg_cd
, RXT.approved_msg_cd_2
, RXT.cob_approved_msg_cd_2
, RXT.approved_msg_cd_3
, RXT.cob_approved_msg_cd_3
, RXT.approved_msg_cd_4
, RXT.cob_approved_msg_cd_4
, RXT.approved_msg_cd_5
, RXT.cob_approved_msg_cd_5
,  RXT.gen_recip_nbr_returnd
,  RXT.ntwk_reimb_id_returnd
,  RXT.plan_returnd_grp_nbr
,  RXT.plan_id_returnd
,  RXT.general_pbr_nbr
,  RXT.cob_general_pbr_nbr
,  RXT.general_rph_nbr_qlfr
,  RXT.prior_auth_cd
,  RXT.prior_auth_nbr
,  RXT.additional_mfgr_coupon_w1_msg
, RXT.wo_correlation_id
, RXT.wo_rx_count
, RXT.short_fill_ind
, RXT.db_cob_proc_ctrl_nbr

from $pTDStageDB.etl_tbf0_rx_transaction_stg RXT,
  $pTDStageDB.etl_proc_dup_fill_stg DUP
 where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
 and RXT.fill_entered_dttm = DUP.fill_enter_dttm;""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg RXT 
using $pTDStageDB.etl_proc_dup_fill_stg DUP 
where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
 and RXT.fill_entered_dttm = DUP.fill_enter_dttm;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM TRANS DUPS TABLE
  #------------------------------------------------------
  runSql("""insert into $pTDStageDB.etl_proc_dup_rx_tran_stg
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm 
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
, wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
)
select 
RXT.cdc_txn_commit_dttm           
,RXT.cdc_seq_nbr                   
,RXT.cdc_rba_nbr                   
,RXT.cdc_operation_type_cd         
,RXT.cdc_before_after_cd           
,RXT.cdc_txn_position_cd           
,RXT.edw_batch_id                  
,RXT.store_nbr                     
,RXT.rx_nbr                        
,RXT.fill_nbr                      
,RXT.fill_partial_nbr              
,RXT.refills_remaining             
,RXT.fill_wac_cost_amt             
,RXT.plan_returnd_cost_amt         
,RXT.plan_returnd_fee_amt          
,RXT.plan_submtd_copay_amt         
,RXT.pbr_id                        
,RXT.fill_source_cd                
,RXT.refills_remain_when_ent       
,RXT.cob_plan_rtrnd_fee_amt        
,RXT.tot_amt_paid_ind              
,RXT.drug_class                    
,RXT.drug_name                     
,RXT.drug_id                       
,RXT.plan_returnd_copay_amt        
,RXT.plan_total_paid_amt           
,RXT.plan_returnd_tax_amt          
,RXT.plan_submtd_cost_amt          
,RXT.plan_submtd_fee_amt           
,RXT.plan_submtd_tax_amt           
,RXT.pat_id                        
,RXT.sims_upc                      
,RXT.pbr_loc_id                    
,RXT.create_user_id                
,RXT.create_dttm                   
,RXT.cob_plan_rtrnd_copay_amt      
,RXT.cob_plan_total_paid_amt       
,RXT.cob_plan_rtrnd_cost_amt       
,RXT.cob_plan_rtrnd_tax_amt        
,RXT.cob_plan_sbmtd_copay_amt      
,RXT.cob_plan_sbmtd_cost_amt       
,RXT.cob_plan_sbmtd_fee_amt        
,RXT.cob_plan_sbmtd_tax_amt        
,RXT.src_partition_nbr             
,RXT.fill_adjudication_cd          
,RXT.fill_awp_cost_amt             
,RXT.fill_days_supply              
,RXT.fill_entered_dttm             
,RXT.fill_label_price_amt          
,RXT.fill_qty_dispensed            
,RXT.fill_retail_price_amt         
,RXT.claim_reference_nbr           
,RXT.fill_nbr_dispensed            
,RXT.plan_id                       
,RXT.fill_status_cd                
,RXT.fill_entered_user_id          
,RXT.fill_verified_user_id         
,RXT.fill_verified_dttm            
,RXT.fill_sold_dttm                
,RXT.fill_deleted_dttm             
,RXT.fill_discount_cd              
,RXT.fill_pay_method_cd            
,RXT.fill_discount_amt             
,RXT.fill_sold_amt                 
,RXT.fill_type_cd                  
,RXT.update_user_id                
,RXT.update_dttm                   
,RXT.partial_fill_cd               
,RXT.fill_adjudication_dttm        
,RXT.cob_fill_adjudication_cd      
,RXT.cob_claim_ref_nbr             
,RXT.cob_plan_id                   
,RXT.cob_fill_adj_dttm             
,RXT.fill_data_rev_id              
,RXT.fill_data_rev_dttm            
,RXT.filling_user_id               
,RXT.filling_dttm                  
,RXT.override_user_id              
,RXT.override_dttm                 
,RXT.entered_store_nbr             
,RXT.reviewed_store_nbr            
,RXT.plan_gross_due_amt            
,RXT.cob_plan_gross_due_amt        
,RXT.DL_REJECT_CD_01               
,RXT.DL_REJECT_CD_02               
,RXT.DL_REJECT_CD_03               
,RXT.DL_REJECT_CD_04               
,RXT.DL_REJECT_CD_05               
,RXT.FILL_DEL_ADJUDICATION_CD      
,RXT.FILL_PRICE_OVERRIDE_AMT       
,RXT.PLAN_INCENTIVE_PAID_AMT       
,RXT.GENERAL_RECIPIENT_NBR         
,RXT.BIN_NBR                       
,RXT.PLAN_GROUP_NBR                
,RXT.DRUG_WAREHOUSE_IND            
,RXT.GENERAL_PHRM_NBR              
,RXT.REIMBURS_LOSS_AMT             
,RXT.COST_PLUS_FEE_CD              
,RXT.ACCEPT_CONSULT_IND            
,RXT.BASIS_OF_REIMB_DETERM         
,RXT.PLAN_OTHER_AMT_PAID           
,RXT.AMT_ATTRIBUTED_TO_TAX         
,RXT.PLAN_INCENT_AMT_SUBMTD        
,RXT.PLAN_OTHER_AMT_SUBMTD         
,RXT.LVL_OF_SVC_CD                 
,RXT.COB_DL_REJECT_CD_01           
,RXT.COB_DL_REJECT_CD_02           
,RXT.COB_DL_REJECT_CD_03           
,RXT.COB_DL_REJECT_CD_04           
,RXT.COB_DL_REJECT_CD_05           
,RXT.COB_FILL_DEL_ADJ_CD           
,RXT.COB_BIN_NBR                   
,RXT.COB_PLAN_GROUP_NBR            
,RXT.COB_GENERAL_PHRM_NBR          
,RXT.COB_BASIS_OF_REIMB_DETRM      
,RXT.COB_AMT_ATTRIB_TO_TAX         
,RXT.COB_PLN_OTHR_AMT_PD           
,RXT.CASH_DISC_SAV_AMT             
,RXT.GENERAL_RPH_NBR               
,RXT.ROUTING_STORE_TECH_INITS      
,RXT.SOURCING_IND                  
,RXT.MAJ_MED_PRIOR_AUTH_NBR        
,RXT.TIP_RSN_FOR_SVC_CD            
,RXT.DATA_REV_SPEC_ID              
,RXT.DATA_REV_SPEC_STORE_NBR       
,RXT.FILL_RPH_OF_RECORD_ID         
,RXT.COB_PLAN_INCNTV_PAID_AMT      
,RXT.COB_PLN_INCNT_AMT_SBMTD       
,RXT.fill_est_pick_up_dttm         
,RXT.data_rev_spec_dttm            
,RXT.rx_daw_ind                    
,RXT.relocate_fm_str_nbr           
,RXT.cob_gen_recipient_nbr          
,RXT.celgene_md_auth_nbr
,RXT.celgene_conf_nbr
,RXT.plan_other_amt_paid_type
,RXT.plan_other_amt_subm_type
,RXT.plan_returnd_coins_amt
,RXT.plan_rtrnd_coins_amt
,RXT.plan_other_amt_paid_2
,RXT.plan_other_amt_paid_typ2
,RXT.plan_other_amt_paid_3
,RXT.plan_other_amt_paid_typ3
,RXT.fill_print_dttm
,RXT.pat_lang_pref_cd
,RXT.rebilling_dttm
,RXT.fill_90day_pref_ind
,RXT.fill_90day_pref_stat_cd
,RXT.pat_pickup_id
,RXT.pickup_id
,RXT.pickup_first_name
,RXT.pickup_last_name
,RXT.pickup_id_state
,RXt.pickup_id_country
,RXT.pickup_id_qlfr
,RXT.pickup_rel_cd
,RXT.dl_proc_msg
,RXT.cob_dl_proc_msg
,RXT.proc_ctrl_nbr
,RXT.dispensed_ndc
,RXT.overstock_ind
,RXT.med_partd_notice_ind
,RXT.med_partd_print_dttm
,RXT.ben_stg_qualifier_1
,RXT.ben_stg_qualifier_2
,RXT.ben_stg_qualifier_3
,RXT.ben_stg_qualifier_4
,RXT.ben_stg_amount_1
,RXT.ben_stg_amount_2
,RXT.ben_stg_amount_3
,RXT.ben_stg_amount_4
,RXT.coupon_drug_id
,RXT.cob_coupon_drug_id
,RXT.coupon_ind
,RXT.cob_coupon_ind
,RXT.other_coverage_cd
,RXT.cob_other_coverage_cd
,RXT.partial_fil_intnded_qty
,RXT.triplicate_serial_nbr
,  RXT.delivery_ind
,  RXT.delivery_comments
,  RXT.sold_local_dttm
,  RXT.pat_pickup_gov_auth_id
,  RXT.pat_pickup_id_qlfr
,  RXT.pat_pickup_rel_cd
,  RXT.routing_store_rph_inits
,  RXT.source_system_name
,  RXT.source_sys_trans_id
,  RXT.sys_status_when_ent
, RXT.additional_msg_qlfr_w1_cd
, RXT.approved_msg_cd
, RXT.cob_approved_msg_cd
, RXT.approved_msg_cd_2
, RXT.cob_approved_msg_cd_2
, RXT.approved_msg_cd_3
, RXT.cob_approved_msg_cd_3
, RXT.approved_msg_cd_4
, RXT.cob_approved_msg_cd_4
, RXT.approved_msg_cd_5
, RXT.cob_approved_msg_cd_5
,  RXT.gen_recip_nbr_returnd
,  RXT.ntwk_reimb_id_returnd
,  RXT.plan_returnd_grp_nbr
,  RXT.plan_id_returnd
,  RXT.general_pbr_nbr
,  RXT.cob_general_pbr_nbr
,  RXT.general_rph_nbr_qlfr
,  RXT.prior_auth_cd
,  RXT.prior_auth_nbr
,  RXT.additional_mfgr_coupon_w1_msg
,  RXT.wo_correlation_id
, RXT.wo_rx_count
, RXT.short_fill_ind
, RXT.db_cob_proc_ctrl_nbr

from $pTDStageDB.etl_tbf0_rx_transaction_stg RXT,
  $pTDStageDB.etl_proc_dup_rx_tran_stg DUP
 where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
 and RXT.fill_entered_dttm = DUP.fill_entered_dttm;""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg RXT 
using $pTDStageDB.etl_proc_dup_rx_tran_stg DUP 
where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
 and RXT.fill_entered_dttm = DUP.fill_entered_dttm;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- CREATING TEMP TABLE TO STORE TEMP DATA
  #------------------------------------------------------
  runSql("""CREATE temporary TABLE V_dup_rx_fill 
     (
      rx_nbr INTEGER NOT NULL,
      store_nbr INTEGER NOT NULL,
      fill_nbr SMALLINT,
      fill_partial_nbr BYTEINT,
      fill_entered_dttm TIMESTAMP)
ON COMMIT PRESERVE ROWS;
-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- TABLE_INDEX - Remove table index options
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING DUPLICATES BETWEEN ETL STAGE AND TARGET
  #------------------------------------------------------
  runSql("""insert into V_dup_rx_fill 
select STG.rx_nbr,
       STG.store_nbr,
       STG.fill_nbr,
       STG.fill_partial_nbr,
       STG.fill_entered_dttm
  from $pTDStageDB.etl_tbf0_rx_transaction_stg STG,
       $pTDStageDB.ETL_PROC_TRANS_FILL_STG TGT
 where STG.rx_nbr = TGT.rx_nbr
   and STG.store_nbr = TGT.str_nbr
   and STG.fill_nbr = TGT.rx_fill_nbr
   and STG.fill_partial_nbr = TGT.rx_partial_fill_nbr
   and coalesce( STG.fill_entered_dttm, cast( '1900-01-01 01:01:01' as timestamp(0)) ) <> CAST ( CAST ( TGT.fill_enter_dt AS CHAR(10 ) ) || ' ' || CAST ( TGT.fill_enter_tm AS CHAR(08 ) ) AS TIMESTAMP(0) ) 
   and TGT.fill_enter_dt >= 
(case when STG.store_nbr = 3397 then CAST(STG.fill_entered_dttm AS DATE) - 365
else CAST(STG.fill_entered_dttm AS DATE) - 730 END)
   and cdc_operation_type_cd='INSERT'
 group by STG.rx_nbr,
          STG.store_nbr,
          STG.fill_nbr,
          STG.fill_partial_nbr,
          STG.fill_entered_dttm;""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- PUTTING THE RECORDS IN THE TRANS DUPS TABLE FOR THE DUPLICATE INSERTS
  #------------------------------------------------------ 
  runSql("""insert into $pTDStageDB.etl_proc_dup_rx_tran_stg
(
 cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg 
, wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
)
select
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
 from $pTDStageDB.etl_tbf0_rx_transaction_stg
 where (rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_entered_dttm)
    in (select rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_entered_dttm
          from V_dup_rx_fill )
   and cdc_operation_type_cd = 'INSERT';""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING THE DUP INSERTS FROM ETL STAGE
  #------------------------------------------------------
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg
 where (rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_entered_dttm)
    in (select rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_entered_dttm
          from V_dup_rx_fill )
   and cdc_operation_type_cd = 'INSERT';""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND PUTTING THE MATCHING PKS FOR A PK UPDATE ROWS INTO THE DUPS TABLE
  #------------------------------------------------------
  #-----------------------------------------------------
  #-- THIS SQL IS RUN AGAIN TO REMOVE ALL THE REMAINING KEYS RELATED WITH THE PK UPDATE BEFORE/AFTER
  #------------------------------------------------------
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM TRANS DUPS TABLE
  #------------------------------------------------------
  runSql("""insert into $pTDStageDB.etl_proc_dup_rx_tran_stg
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
, wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
)
select 
 RXT.cdc_txn_commit_dttm           
,RXT.cdc_seq_nbr                   
,RXT.cdc_rba_nbr                   
,RXT.cdc_operation_type_cd         
,RXT.cdc_before_after_cd           
,RXT.cdc_txn_position_cd           
,RXT.edw_batch_id                  
,RXT.store_nbr                     
,RXT.rx_nbr                        
,RXT.fill_nbr                      
,RXT.fill_partial_nbr              
,RXT.refills_remaining             
,RXT.fill_wac_cost_amt             
,RXT.plan_returnd_cost_amt         
,RXT.plan_returnd_fee_amt          
,RXT.plan_submtd_copay_amt         
,RXT.pbr_id                        
,RXT.fill_source_cd                
,RXT.refills_remain_when_ent       
,RXT.cob_plan_rtrnd_fee_amt        
,RXT.tot_amt_paid_ind              
,RXT.drug_class                    
,RXT.drug_name                     
,RXT.drug_id                       
,RXT.plan_returnd_copay_amt        
,RXT.plan_total_paid_amt           
,RXT.plan_returnd_tax_amt          
,RXT.plan_submtd_cost_amt          
,RXT.plan_submtd_fee_amt           
,RXT.plan_submtd_tax_amt           
,RXT.pat_id                        
,RXT.sims_upc                      
,RXT.pbr_loc_id                    
,RXT.create_user_id                
,RXT.create_dttm                   
,RXT.cob_plan_rtrnd_copay_amt      
,RXT.cob_plan_total_paid_amt       
,RXT.cob_plan_rtrnd_cost_amt       
,RXT.cob_plan_rtrnd_tax_amt        
,RXT.cob_plan_sbmtd_copay_amt      
,RXT.cob_plan_sbmtd_cost_amt       
,RXT.cob_plan_sbmtd_fee_amt        
,RXT.cob_plan_sbmtd_tax_amt        
,RXT.src_partition_nbr             
,RXT.fill_adjudication_cd          
,RXT.fill_awp_cost_amt             
,RXT.fill_days_supply              
,RXT.fill_entered_dttm             
,RXT.fill_label_price_amt          
,RXT.fill_qty_dispensed            
,RXT.fill_retail_price_amt         
,RXT.claim_reference_nbr           
,RXT.fill_nbr_dispensed            
,RXT.plan_id                       
,RXT.fill_status_cd                
,RXT.fill_entered_user_id          
,RXT.fill_verified_user_id         
,RXT.fill_verified_dttm            
,RXT.fill_sold_dttm                
,RXT.fill_deleted_dttm             
,RXT.fill_discount_cd              
,RXT.fill_pay_method_cd            
,RXT.fill_discount_amt             
,RXT.fill_sold_amt                 
,RXT.fill_type_cd                  
,RXT.update_user_id                
,RXT.update_dttm                   
,RXT.partial_fill_cd               
,RXT.fill_adjudication_dttm        
,RXT.cob_fill_adjudication_cd      
,RXT.cob_claim_ref_nbr             
,RXT.cob_plan_id                   
,RXT.cob_fill_adj_dttm             
,RXT.fill_data_rev_id              
,RXT.fill_data_rev_dttm            
,RXT.filling_user_id               
,RXT.filling_dttm                  
,RXT.override_user_id              
,RXT.override_dttm                 
,RXT.entered_store_nbr             
,RXT.reviewed_store_nbr            
,RXT.plan_gross_due_amt            
,RXT.cob_plan_gross_due_amt        
,RXT.DL_REJECT_CD_01               
,RXT.DL_REJECT_CD_02               
,RXT.DL_REJECT_CD_03               
,RXT.DL_REJECT_CD_04               
,RXT.DL_REJECT_CD_05               
,RXT.FILL_DEL_ADJUDICATION_CD      
,RXT.FILL_PRICE_OVERRIDE_AMT       
,RXT.PLAN_INCENTIVE_PAID_AMT       
,RXT.GENERAL_RECIPIENT_NBR         
,RXT.BIN_NBR                       
,RXT.PLAN_GROUP_NBR                
,RXT.DRUG_WAREHOUSE_IND            
,RXT.GENERAL_PHRM_NBR              
,RXT.REIMBURS_LOSS_AMT             
,RXT.COST_PLUS_FEE_CD              
,RXT.ACCEPT_CONSULT_IND            
,RXT.BASIS_OF_REIMB_DETERM         
,RXT.PLAN_OTHER_AMT_PAID           
,RXT.AMT_ATTRIBUTED_TO_TAX         
,RXT.PLAN_INCENT_AMT_SUBMTD        
,RXT.PLAN_OTHER_AMT_SUBMTD         
,RXT.LVL_OF_SVC_CD                 
,RXT.COB_DL_REJECT_CD_01           
,RXT.COB_DL_REJECT_CD_02           
,RXT.COB_DL_REJECT_CD_03           
,RXT.COB_DL_REJECT_CD_04           
,RXT.COB_DL_REJECT_CD_05           
,RXT.COB_FILL_DEL_ADJ_CD           
,RXT.COB_BIN_NBR                   
,RXT.COB_PLAN_GROUP_NBR            
,RXT.COB_GENERAL_PHRM_NBR          
,RXT.COB_BASIS_OF_REIMB_DETRM      
,RXT.COB_AMT_ATTRIB_TO_TAX         
,RXT.COB_PLN_OTHR_AMT_PD           
,RXT.CASH_DISC_SAV_AMT             
,RXT.GENERAL_RPH_NBR               
,RXT.ROUTING_STORE_TECH_INITS      
,RXT.SOURCING_IND                  
,RXT.MAJ_MED_PRIOR_AUTH_NBR        
,RXT.TIP_RSN_FOR_SVC_CD            
,RXT.DATA_REV_SPEC_ID              
,RXT.DATA_REV_SPEC_STORE_NBR       
,RXT.FILL_RPH_OF_RECORD_ID         
,RXT.COB_PLAN_INCNTV_PAID_AMT      
,RXT.COB_PLN_INCNT_AMT_SBMTD       
,RXT.fill_est_pick_up_dttm         
,RXT.data_rev_spec_dttm            
,RXT.rx_daw_ind                    
,RXT.relocate_fm_str_nbr           
,RXT.cob_gen_recipient_nbr          
,RXT.celgene_md_auth_nbr
,RXT.celgene_conf_nbr
,RXT.plan_other_amt_paid_type
,RXT.plan_other_amt_subm_type
,RXT.plan_returnd_coins_amt
,RXT.plan_rtrnd_coins_amt
,RXT.plan_other_amt_paid_2
,RXT.plan_other_amt_paid_typ2
,RXT.plan_other_amt_paid_3
,RXT.plan_other_amt_paid_typ3
,RXT.fill_print_dttm
,RXT.pat_lang_pref_cd
,RXT.rebilling_dttm
,RXT.fill_90day_pref_ind
,RXT.fill_90day_pref_stat_cd
,RXT.pat_pickup_id
,RXT.pickup_id
,RXT.pickup_first_name
,RXT.pickup_last_name
,RXT.pickup_id_state
,RXT.pickup_id_country
,RXT.pickup_id_qlfr
,RXT.pickup_rel_cd
,RXT.dl_proc_msg
,RXT.cob_dl_proc_msg
,RXT.proc_ctrl_nbr
,RXT.dispensed_ndc
,RXT.overstock_ind
,RXT.med_partd_notice_ind
,RXT.med_partd_print_dttm
,RXT.ben_stg_qualifier_1
,RXT.ben_stg_qualifier_2
,RXT.ben_stg_qualifier_3
,RXT.ben_stg_qualifier_4
,RXT.ben_stg_amount_1
,RXT.ben_stg_amount_2
,RXT.ben_stg_amount_3
,RXT.ben_stg_amount_4
,RXT.coupon_drug_id
,RXT.cob_coupon_drug_id
,RXT.coupon_ind
,RXT.cob_coupon_ind
,RXT.other_coverage_cd
,RXT.cob_other_coverage_cd
,RXT.partial_fil_intnded_qty
,RXT.triplicate_serial_nbr
,  RXT.delivery_ind
,  RXT.delivery_comments
,  RXT.sold_local_dttm
,  RXT.pat_pickup_gov_auth_id
,  RXT.pat_pickup_id_qlfr
,  RXT.pat_pickup_rel_cd
,  RXT.routing_store_rph_inits
,  RXT.source_system_name
,  RXT.source_sys_trans_id
,  RXT.sys_status_when_ent
, RXT.additional_msg_qlfr_w1_cd
, RXT.approved_msg_cd
, RXT.cob_approved_msg_cd
, RXT.approved_msg_cd_2
, RXT.cob_approved_msg_cd_2
, RXT.approved_msg_cd_3
, RXT.cob_approved_msg_cd_3
, RXT.approved_msg_cd_4
, RXT.cob_approved_msg_cd_4
, RXT.approved_msg_cd_5
, RXT.cob_approved_msg_cd_5
,  RXT.gen_recip_nbr_returnd
,  RXT.ntwk_reimb_id_returnd
,  RXT.plan_returnd_grp_nbr
,  RXT.plan_id_returnd
,  RXT.general_pbr_nbr
,  RXT.cob_general_pbr_nbr
,  RXT.general_rph_nbr_qlfr
,  RXT.prior_auth_cd
,  RXT.prior_auth_nbr
,  RXT.additional_mfgr_coupon_w1_msg
, RXT.wo_correlation_id
, RXT.wo_rx_count
, RXT.short_fill_ind
, RXT.db_cob_proc_ctrl_nbr

  from $pTDStageDB.etl_tbf0_rx_transaction_stg RXT,
       $pTDStageDB.etl_proc_dup_rx_tran_stg DUP
 where RXT.store_nbr = DUP.store_nbr
   and RXT.rx_nbr = DUP.rx_nbr
   and RXT.fill_nbr = DUP.fill_nbr
   and RXT.fill_partial_nbr = DUP.fill_partial_nbr
   and RXT.fill_entered_dttm = DUP.fill_entered_dttm;""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg RXT 
using $pTDStageDB.etl_proc_dup_rx_tran_stg DUP 
where RXT.store_nbr = DUP.store_nbr
   and RXT.rx_nbr = DUP.rx_nbr
   and RXT.fill_nbr = DUP.fill_nbr
   and RXT.fill_partial_nbr = DUP.fill_partial_nbr
   and RXT.fill_entered_dttm = DUP.fill_entered_dttm;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------ 
  #-- CHECKING FOR UPDATES NOT EXISTING IN THE TARGET TABLE
  #------------------------------------------------------ 
  runSql("""INSERT INTO  $APT_TERA_SYNC_DATABASE.ETL_TRAN_MISSING_UPDATES_STG  
(
 cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
)
SELECT 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr

  FROM $pTDStageDB.etl_tbf0_rx_transaction_stg
 WHERE (STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTERED_DTTM)
    IN (SELECT STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTERED_DTTM
          FROM $pTDStageDB.etl_tbf0_rx_transaction_stg 
         WHERE CDC_OPERATION_TYPE_CD='SQL COMPUPDATE'
        MINUS
        SELECT STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTERED_DTTM
          FROM $pTDStageDB.etl_tbf0_rx_transaction_stg 
         WHERE CDC_OPERATION_TYPE_CD='INSERT'
        MINUS
        SELECT STR_NBR, RX_NBR, RX_FILL_NBR, RX_PARTIAL_FILL_NBR, CAST ( CAST ( fill_enter_dt AS CHAR(10 ) ) || ' ' || CAST ( fill_enter_tm AS CHAR(08 ) ) AS TIMESTAMP(0) ) 
          FROM $pTDStageDB.ETL_PROC_TRANS_FILL_STG);""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""DELETE FROM $pTDStageDB.etl_tbf0_rx_transaction_stg
 WHERE (STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTERED_DTTM,
        CDC_TXN_COMMIT_DTTM, CDC_SEQ_NBR, CDC_RBA_NBR)
    IN (SELECT STORE_NBR, RX_NBR,FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTERED_DTTM,
               CDC_TXN_COMMIT_DTTM, CDC_SEQ_NBR, CDC_RBA_NBR
          FROM $APT_TERA_SYNC_DATABASE.ETL_TRAN_MISSING_UPDATES_STG);""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--------------------------------------------------------------------
  #-- FILL DUMMY DELETE FIX LOGIC
  #--------------------------------------------------------------------
  runSql("""DELETE FROM $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_D_stg;""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""INSERT INTO $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_D_stg
SELECT *
  FROM $pTDStageDB.etl_tbf0_rx_transaction_stg
 WHERE FILL_TYPE_CD = 'D'
   AND CDC_OPERATION_TYPE_CD = 'INSERT';""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""DELETE FROM $pTDStageDB.etl_tbf0_rx_transaction_stg
 WHERE FILL_TYPE_CD = 'D'
   AND CDC_OPERATION_TYPE_CD = 'INSERT';""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------------------------------------
  #-- REMOVE THE DUP RECORDS FROM etl_tbf0_rx_transaction_D_stg WHICH ARE BEFORE A REINSERT
  #------------------------------------------------------------------------------------
  runSql("""delete from $APT_TERA_SYNC_DATABASE.dup_etl_tbf0_rx_transaction_D_stg;
-- DEL_ALL - Add FROM clause
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""INSERT INTO $APT_TERA_SYNC_DATABASE.dup_etl_tbf0_rx_transaction_D_stg
(
cdc_txn_commit_dttm,
cdc_seq_nbr,
cdc_rba_nbr,
cdc_operation_type_cd,
cdc_before_after_cd,
cdc_txn_position_cd,
edw_batch_id,
store_nbr,
rx_nbr,
fill_nbr,
fill_partial_nbr,
refills_remaining,
fill_wac_cost_amt,
plan_returnd_cost_amt,
plan_returnd_fee_amt,
plan_submtd_copay_amt,
pbr_id,
fill_source_cd,
refills_remain_when_ent,
cob_plan_rtrnd_fee_amt,
tot_amt_paid_ind,
drug_class,
drug_name,
drug_id,
plan_returnd_copay_amt,
plan_total_paid_amt,
plan_returnd_tax_amt,
plan_submtd_cost_amt,
plan_submtd_fee_amt,
plan_submtd_tax_amt,
pat_id,
sims_upc,
pbr_loc_id,
create_user_id,
create_dttm,
cob_plan_rtrnd_copay_amt,
cob_plan_total_paid_amt,
cob_plan_rtrnd_cost_amt,
cob_plan_rtrnd_tax_amt,
cob_plan_sbmtd_copay_amt,
cob_plan_sbmtd_cost_amt,
cob_plan_sbmtd_fee_amt,
cob_plan_sbmtd_tax_amt,
src_partition_nbr,
fill_adjudication_cd,
fill_awp_cost_amt,
fill_days_supply,
fill_entered_dttm,
fill_label_price_amt,
fill_qty_dispensed,
fill_retail_price_amt,
claim_reference_nbr,
fill_nbr_dispensed,
plan_id,
fill_status_cd,
fill_entered_user_id,
fill_verified_user_id,
fill_verified_dttm,
fill_sold_dttm,
fill_deleted_dttm,
fill_discount_cd,
fill_pay_method_cd,
fill_discount_amt,
fill_sold_amt,
fill_type_cd,
update_user_id,
update_dttm,
partial_fill_cd,
fill_adjudication_dttm,
cob_fill_adjudication_cd,
cob_claim_ref_nbr,
cob_plan_id,
cob_fill_adj_dttm,
fill_data_rev_id,
fill_data_rev_dttm,
filling_user_id,
filling_dttm,
override_user_id,
override_dttm,
entered_store_nbr,
reviewed_store_nbr,
plan_gross_due_amt,
cob_plan_gross_due_amt,
dl_reject_cd_01,
dl_reject_cd_02,
dl_reject_cd_03,
dl_reject_cd_04,
dl_reject_cd_05,
FILL_DEL_ADJUDICATION_CD,
FILL_PRICE_OVERRIDE_AMT,
PLAN_INCENTIVE_PAID_AMT,
GENERAL_RECIPIENT_NBR,
BIN_NBR,
PLAN_GROUP_NBR,
DRUG_WAREHOUSE_IND,
GENERAL_PHRM_NBR,
REIMBURS_LOSS_AMT,
COST_PLUS_FEE_CD,
ACCEPT_CONSULT_IND,
BASIS_OF_REIMB_DETERM,
PLAN_OTHER_AMT_PAID,
AMT_ATTRIBUTED_TO_TAX,
PLAN_INCENT_AMT_SUBMTD,
PLAN_OTHER_AMT_SUBMTD,
LVL_OF_SVC_CD,
cob_dl_reject_cd_01,
cob_dl_reject_cd_02,
cob_dl_reject_cd_03,
cob_dl_reject_cd_04,
cob_dl_reject_cd_05,
COB_FILL_DEL_ADJ_CD,
COB_BIN_NBR,
COB_PLAN_GROUP_NBR,
COB_GENERAL_PHRM_NBR,
COB_BASIS_OF_REIMB_DETRM,
COB_AMT_ATTRIB_TO_TAX,
COB_PLN_OTHR_AMT_PD,
CASH_DISC_SAV_AMT,
GENERAL_RPH_NBR,
ROUTING_STORE_TECH_INITS,
SOURCING_IND,
MAJ_MED_PRIOR_AUTH_NBR,
TIP_RSN_FOR_SVC_CD,
DATA_REV_SPEC_ID,
DATA_REV_SPEC_STORE_NBR,
FILL_RPH_OF_RECORD_ID,
COB_PLAN_INCNTV_PAID_AMT,
COB_PLN_INCNT_AMT_SBMTD,
fill_est_pick_up_dttm,
data_rev_spec_dttm,
rx_daw_ind,
relocate_fm_str_nbr,
COB_GEN_RECIPIENT_NBR,
celgene_md_auth_nbr,
celgene_conf_nbr,
plan_other_amt_paid_type,
plan_other_amt_subm_type,
plan_returnd_coins_amt,
plan_rtrnd_coins_amt,
plan_other_amt_paid_2,
plan_other_amt_paid_typ2,
plan_other_amt_paid_3,
plan_other_amt_paid_typ3,
fill_print_dttm,
pat_lang_pref_cd,
rebilling_dttm,
fill_90day_pref_ind,
fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
)
SELECT 
D.cdc_txn_commit_dttm,
D.cdc_seq_nbr,
D.cdc_rba_nbr,
D.cdc_operation_type_cd,
D.cdc_before_after_cd,
D.cdc_txn_position_cd,
D.edw_batch_id,
D.store_nbr,
D.rx_nbr,
D.fill_nbr,
D.fill_partial_nbr,
D.refills_remaining,
D.fill_wac_cost_amt,
D.plan_returnd_cost_amt,
D.plan_returnd_fee_amt,
D.plan_submtd_copay_amt,
D.pbr_id,
D.fill_source_cd,
D.refills_remain_when_ent,
D.cob_plan_rtrnd_fee_amt,
D.tot_amt_paid_ind,
D.drug_class,
D.drug_name,
D.drug_id,
D.plan_returnd_copay_amt,
D.plan_total_paid_amt,
D.plan_returnd_tax_amt,
D.plan_submtd_cost_amt,
D.plan_submtd_fee_amt,
D.plan_submtd_tax_amt,
D.pat_id,
D.sims_upc,
D.pbr_loc_id,
D.create_user_id,
D.create_dttm,
D.cob_plan_rtrnd_copay_amt,
D.cob_plan_total_paid_amt,
D.cob_plan_rtrnd_cost_amt,
D.cob_plan_rtrnd_tax_amt,
D.cob_plan_sbmtd_copay_amt,
D.cob_plan_sbmtd_cost_amt,
D.cob_plan_sbmtd_fee_amt,
D.cob_plan_sbmtd_tax_amt,
D.src_partition_nbr,
D.fill_adjudication_cd,
D.fill_awp_cost_amt,
D.fill_days_supply,
D.fill_entered_dttm,
D.fill_label_price_amt,
D.fill_qty_dispensed,
D.fill_retail_price_amt,
D.claim_reference_nbr,
D.fill_nbr_dispensed,
D.plan_id,
D.fill_status_cd,
D.fill_entered_user_id,
D.fill_verified_user_id,
D.fill_verified_dttm,
D.fill_sold_dttm,
D.fill_deleted_dttm,
D.fill_discount_cd,
D.fill_pay_method_cd,
D.fill_discount_amt,
D.fill_sold_amt,
D.fill_type_cd,
D.update_user_id,
D.update_dttm,
D.partial_fill_cd,
D.fill_adjudication_dttm,
D.cob_fill_adjudication_cd,
D.cob_claim_ref_nbr,
D.cob_plan_id,
D.cob_fill_adj_dttm,
D.fill_data_rev_id,
D.fill_data_rev_dttm,
D.filling_user_id,
D.filling_dttm,
D.override_user_id,
D.override_dttm,
D.entered_store_nbr,
D.reviewed_store_nbr,
D.plan_gross_due_amt,
D.cob_plan_gross_due_amt,
D.dl_reject_cd_01,
D.dl_reject_cd_02,
D.dl_reject_cd_03,
D.dl_reject_cd_04,
D.dl_reject_cd_05,
D.FILL_DEL_ADJUDICATION_CD,
D.FILL_PRICE_OVERRIDE_AMT,
D.PLAN_INCENTIVE_PAID_AMT,
D.GENERAL_RECIPIENT_NBR,
D.BIN_NBR,
D.PLAN_GROUP_NBR,
D.DRUG_WAREHOUSE_IND,
D.GENERAL_PHRM_NBR,
D.REIMBURS_LOSS_AMT,
D.COST_PLUS_FEE_CD,
D.ACCEPT_CONSULT_IND,
D.BASIS_OF_REIMB_DETERM,
D.PLAN_OTHER_AMT_PAID,
D.AMT_ATTRIBUTED_TO_TAX,
D.PLAN_INCENT_AMT_SUBMTD,
D.PLAN_OTHER_AMT_SUBMTD,
D.LVL_OF_SVC_CD,
D.cob_dl_reject_cd_01,
D.cob_dl_reject_cd_02,
D.cob_dl_reject_cd_03,
D.cob_dl_reject_cd_04,
D.cob_dl_reject_cd_05,
D.COB_FILL_DEL_ADJ_CD,
D.COB_BIN_NBR,
D.COB_PLAN_GROUP_NBR,
D.COB_GENERAL_PHRM_NBR,
D.COB_BASIS_OF_REIMB_DETRM,
D.COB_AMT_ATTRIB_TO_TAX,
D.COB_PLN_OTHR_AMT_PD,
D.CASH_DISC_SAV_AMT,
D.GENERAL_RPH_NBR,
D.ROUTING_STORE_TECH_INITS,
D.SOURCING_IND,
D.MAJ_MED_PRIOR_AUTH_NBR,
D.TIP_RSN_FOR_SVC_CD,
D.DATA_REV_SPEC_ID,
D.DATA_REV_SPEC_STORE_NBR,
D.FILL_RPH_OF_RECORD_ID,
D.COB_PLAN_INCNTV_PAID_AMT,
D.COB_PLN_INCNT_AMT_SBMTD,
D.fill_est_pick_up_dttm,
D.data_rev_spec_dttm,
D.rx_daw_ind,
D.relocate_fm_str_nbr,
D.COB_GEN_RECIPIENT_NBR,
D.celgene_md_auth_nbr,
D.celgene_conf_nbr,
D.plan_other_amt_paid_type,
D.plan_other_amt_subm_type,
D.plan_returnd_coins_amt,
D.plan_rtrnd_coins_amt,
D.plan_other_amt_paid_2,
D.plan_other_amt_paid_typ2,
D.plan_other_amt_paid_3,
D.plan_other_amt_paid_typ3,
D.fill_print_dttm,
D.pat_lang_pref_cd,
D.rebilling_dttm,
D.fill_90day_pref_ind,
D.fill_90day_pref_stat_cd,
D.pat_pickup_id,
D.pickup_id,
D.pickup_first_name,
D.pickup_last_name,
D.pickup_id_state,
D.pickup_id_country,
D.pickup_id_qlfr,
D.pickup_rel_cd,
D.dl_proc_msg,
D.cob_dl_proc_msg,
D.proc_ctrl_nbr,
D.dispensed_ndc,
D.overstock_ind,
D.med_partd_notice_ind,
D.med_partd_print_dttm,
D.ben_stg_qualifier_1,
D.ben_stg_qualifier_2,
D.ben_stg_qualifier_3,
D.ben_stg_qualifier_4,
D.ben_stg_amount_1,
D.ben_stg_amount_2,
D.ben_stg_amount_3,
D.ben_stg_amount_4,
D.coupon_drug_id,
D.cob_coupon_drug_id,
D.coupon_ind,
D.cob_coupon_ind,
D.other_coverage_cd,
D.cob_other_coverage_cd,
D.partial_fil_intnded_qty,
D.triplicate_serial_nbr,
D.delivery_ind, 
D.delivery_comments, 
D.sold_local_dttm, 
D.pat_pickup_gov_auth_id, 
D.pat_pickup_id_qlfr, 
D.pat_pickup_rel_cd, 
D.routing_store_rph_inits, 
D.source_system_name, 
D.source_sys_trans_id, 
D.sys_status_when_ent, 
D.additional_msg_qlfr_w1_cd, 
D.approved_msg_cd, 
D.cob_approved_msg_cd, 
D.approved_msg_cd_2, 
D.cob_approved_msg_cd_2, 
D.approved_msg_cd_3, 
D.cob_approved_msg_cd_3, 
D.approved_msg_cd_4, 
D.cob_approved_msg_cd_4, 
D.approved_msg_cd_5, 
D.cob_approved_msg_cd_5, 
D.gen_recip_nbr_returnd, 
D.ntwk_reimb_id_returnd, 
D.plan_returnd_grp_nbr, 
D.plan_id_returnd, 
D.general_pbr_nbr, 
D.cob_general_pbr_nbr, 
D.general_rph_nbr_qlfr, 
D.prior_auth_cd, 
D.prior_auth_nbr, 
D.additional_mfgr_coupon_w1_msg,
D.wo_correlation_id,
D.wo_rx_count,
D.short_fill_ind,
D.db_cob_proc_ctrl_nbr

FROM (SELECT rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_entered_dttm,
               max(cdc_txn_commit_dttm) max_cdc_dttm
          FROM $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_D_stg
         WHERE cdc_operation_type_cd='INSERT'
         GROUP BY 1,2,3,4,5) MX_INS,
       $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_D_stg D
 WHERE D.STORE_NBR=MX_INS.STORE_NBR
   AND D.RX_NBR=MX_INS.RX_NBR
   AND D.FILL_NBR=MX_INS.FILL_NBR
   AND D.FILL_PARTIAL_NBR=MX_INS.FILL_PARTIAL_NBR
   AND D.FILL_ENTERED_DTTM=MX_INS.FILL_ENTERED_DTTM
   AND D.cdc_txn_commit_dttm < MX_INS.max_cdc_dttm;""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""delete from $APT_TERA_SYNC_DATABASE.etl_tbf0_rx_transaction_D_stg D 
using $APT_TERA_SYNC_DATABASE.dup_etl_tbf0_rx_transaction_D_stg PROC 
WHERE D.STORE_NBR=PROC.STORE_NBR
   AND D.RX_NBR=PROC.RX_NBR
   AND D.FILL_NBR=PROC.FILL_NBR
   AND D.FILL_PARTIAL_NBR=PROC.FILL_PARTIAL_NBR
   AND D.FILL_ENTERED_DTTM=PROC.FILL_ENTERED_DTTM
   AND D.CDC_TXN_COMMIT_DTTM = PROC.CDC_TXN_COMMIT_DTTM
   AND D.CDC_SEQ_NBR = PROC.CDC_SEQ_NBR
   AND D.CDC_RBA_NBR = PROC.CDC_RBA_NBR
   AND D.CDC_BEFORE_AFTER_CD = PROC.CDC_BEFORE_AFTER_CD
   AND D.CDC_OPERATION_TYPE_CD = PROC.CDC_OPERATION_TYPE_CD
   AND D.CDC_TXN_POSITION_CD = PROC.CDC_TXN_POSITION_CD;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--------------------------------------------------------------------
  #-- REMOVE THE RECORDS FROM ETL STAGE WHICH ARE BEFORE A REINSERT
  #--------------------------------------------------------------------
  runSql("""delete from $APT_TERA_SYNC_DATABASE.ETL_TBF0_TRANS_CHANGE_ANALYSIS_STG;
-- DEL_ALL - Add FROM clause
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""INSERT INTO $APT_TERA_SYNC_DATABASE.ETL_TBF0_TRANS_CHANGE_ANALYSIS_STG
(
 cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,refills_remaining             
,fill_wac_cost_amt             
,plan_returnd_cost_amt         
,plan_returnd_fee_amt          
,plan_submtd_copay_amt         
,pbr_id                        
,fill_source_cd                
,refills_remain_when_ent       
,cob_plan_rtrnd_fee_amt        
,tot_amt_paid_ind              
,drug_class                    
,drug_name                     
,drug_id                       
,plan_returnd_copay_amt        
,plan_total_paid_amt           
,plan_returnd_tax_amt          
,plan_submtd_cost_amt          
,plan_submtd_fee_amt           
,plan_submtd_tax_amt           
,pat_id                        
,sims_upc                      
,pbr_loc_id                    
,create_user_id                
,create_dttm                   
,cob_plan_rtrnd_copay_amt      
,cob_plan_total_paid_amt       
,cob_plan_rtrnd_cost_amt       
,cob_plan_rtrnd_tax_amt        
,cob_plan_sbmtd_copay_amt      
,cob_plan_sbmtd_cost_amt       
,cob_plan_sbmtd_fee_amt        
,cob_plan_sbmtd_tax_amt        
,src_partition_nbr             
,fill_adjudication_cd          
,fill_awp_cost_amt             
,fill_days_supply              
,fill_entered_dttm             
,fill_label_price_amt          
,fill_qty_dispensed            
,fill_retail_price_amt         
,claim_reference_nbr           
,fill_nbr_dispensed            
,plan_id                       
,fill_status_cd                
,fill_entered_user_id          
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,fill_deleted_dttm             
,fill_discount_cd              
,fill_pay_method_cd            
,fill_discount_amt             
,fill_sold_amt                 
,fill_type_cd                  
,update_user_id                
,update_dttm                   
,partial_fill_cd               
,fill_adjudication_dttm        
,cob_fill_adjudication_cd      
,cob_claim_ref_nbr             
,cob_plan_id                   
,cob_fill_adj_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,override_user_id              
,override_dttm                 
,entered_store_nbr             
,reviewed_store_nbr            
,plan_gross_due_amt            
,cob_plan_gross_due_amt        
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,FILL_DEL_ADJUDICATION_CD      
,FILL_PRICE_OVERRIDE_AMT       
,PLAN_INCENTIVE_PAID_AMT       
,GENERAL_RECIPIENT_NBR         
,BIN_NBR                       
,PLAN_GROUP_NBR                
,DRUG_WAREHOUSE_IND            
,GENERAL_PHRM_NBR              
,REIMBURS_LOSS_AMT             
,COST_PLUS_FEE_CD              
,ACCEPT_CONSULT_IND            
,BASIS_OF_REIMB_DETERM         
,PLAN_OTHER_AMT_PAID           
,AMT_ATTRIBUTED_TO_TAX         
,PLAN_INCENT_AMT_SUBMTD        
,PLAN_OTHER_AMT_SUBMTD         
,LVL_OF_SVC_CD                 
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,COB_FILL_DEL_ADJ_CD           
,COB_BIN_NBR                   
,COB_PLAN_GROUP_NBR            
,COB_GENERAL_PHRM_NBR          
,COB_BASIS_OF_REIMB_DETRM      
,COB_AMT_ATTRIB_TO_TAX         
,COB_PLN_OTHR_AMT_PD           
,CASH_DISC_SAV_AMT             
,GENERAL_RPH_NBR               
,ROUTING_STORE_TECH_INITS      
,SOURCING_IND                  
,MAJ_MED_PRIOR_AUTH_NBR        
,TIP_RSN_FOR_SVC_CD            
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,COB_PLAN_INCNTV_PAID_AMT      
,COB_PLN_INCNT_AMT_SBMTD       
,fill_est_pick_up_dttm         
,data_rev_spec_dttm            
,rx_daw_ind                    
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr
)
SELECT 
 STG.cdc_txn_commit_dttm           
,STG.cdc_seq_nbr                   
,STG.cdc_rba_nbr                   
,STG.cdc_operation_type_cd         
,STG.cdc_before_after_cd           
,STG.cdc_txn_position_cd           
,STG.edw_batch_id                  
,STG.store_nbr                     
,STG.rx_nbr                        
,STG.fill_nbr                      
,STG.fill_partial_nbr              
,STG.refills_remaining             
,STG.fill_wac_cost_amt             
,STG.plan_returnd_cost_amt         
,STG.plan_returnd_fee_amt          
,STG.plan_submtd_copay_amt         
,STG.pbr_id                        
,STG.fill_source_cd                
,STG.refills_remain_when_ent       
,STG.cob_plan_rtrnd_fee_amt        
,STG.tot_amt_paid_ind              
,STG.drug_class                    
,STG.drug_name                     
,STG.drug_id                       
,STG.plan_returnd_copay_amt        
,STG.plan_total_paid_amt           
,STG.plan_returnd_tax_amt          
,STG.plan_submtd_cost_amt          
,STG.plan_submtd_fee_amt           
,STG.plan_submtd_tax_amt           
,STG.pat_id                        
,STG.sims_upc                      
,STG.pbr_loc_id                    
,STG.create_user_id                
,STG.create_dttm                   
,STG.cob_plan_rtrnd_copay_amt      
,STG.cob_plan_total_paid_amt       
,STG.cob_plan_rtrnd_cost_amt       
,STG.cob_plan_rtrnd_tax_amt        
,STG.cob_plan_sbmtd_copay_amt      
,STG.cob_plan_sbmtd_cost_amt       
,STG.cob_plan_sbmtd_fee_amt        
,STG.cob_plan_sbmtd_tax_amt        
,STG.src_partition_nbr             
,STG.fill_adjudication_cd          
,STG.fill_awp_cost_amt             
,STG.fill_days_supply              
,STG.fill_entered_dttm             
,STG.fill_label_price_amt          
,STG.fill_qty_dispensed            
,STG.fill_retail_price_amt         
,STG.claim_reference_nbr           
,STG.fill_nbr_dispensed            
,STG.plan_id                       
,STG.fill_status_cd                
,STG.fill_entered_user_id          
,STG.fill_verified_user_id         
,STG.fill_verified_dttm            
,STG.fill_sold_dttm                
,STG.fill_deleted_dttm             
,STG.fill_discount_cd              
,STG.fill_pay_method_cd            
,STG.fill_discount_amt             
,STG.fill_sold_amt                 
,STG.fill_type_cd                  
,STG.update_user_id                
,STG.update_dttm                   
,STG.partial_fill_cd               
,STG.fill_adjudication_dttm        
,STG.cob_fill_adjudication_cd      
,STG.cob_claim_ref_nbr             
,STG.cob_plan_id                   
,STG.cob_fill_adj_dttm             
,STG.fill_data_rev_id              
,STG.fill_data_rev_dttm            
,STG.filling_user_id               
,STG.filling_dttm                  
,STG.override_user_id              
,STG.override_dttm                 
,STG.entered_store_nbr             
,STG.reviewed_store_nbr            
,STG.plan_gross_due_amt            
,STG.cob_plan_gross_due_amt        
,STG.DL_REJECT_CD_01               
,STG.DL_REJECT_CD_02               
,STG.DL_REJECT_CD_03               
,STG.DL_REJECT_CD_04               
,STG.DL_REJECT_CD_05               
,STG.FILL_DEL_ADJUDICATION_CD      
,STG.FILL_PRICE_OVERRIDE_AMT       
,STG.PLAN_INCENTIVE_PAID_AMT       
,STG.GENERAL_RECIPIENT_NBR         
,STG.BIN_NBR                       
,STG.PLAN_GROUP_NBR                
,STG.DRUG_WAREHOUSE_IND            
,STG.GENERAL_PHRM_NBR              
,STG.REIMBURS_LOSS_AMT             
,STG.COST_PLUS_FEE_CD              
,STG.ACCEPT_CONSULT_IND            
,STG.BASIS_OF_REIMB_DETERM         
,STG.PLAN_OTHER_AMT_PAID           
,STG.AMT_ATTRIBUTED_TO_TAX         
,STG.PLAN_INCENT_AMT_SUBMTD        
,STG.PLAN_OTHER_AMT_SUBMTD         
,STG.LVL_OF_SVC_CD                 
,STG.COB_DL_REJECT_CD_01           
,STG.COB_DL_REJECT_CD_02           
,STG.COB_DL_REJECT_CD_03           
,STG.COB_DL_REJECT_CD_04           
,STG.COB_DL_REJECT_CD_05           
,STG.COB_FILL_DEL_ADJ_CD           
,STG.COB_BIN_NBR                   
,STG.COB_PLAN_GROUP_NBR            
,STG.COB_GENERAL_PHRM_NBR          
,STG.COB_BASIS_OF_REIMB_DETRM      
,STG.COB_AMT_ATTRIB_TO_TAX         
,STG.COB_PLN_OTHR_AMT_PD           
,STG.CASH_DISC_SAV_AMT             
,STG.GENERAL_RPH_NBR               
,STG.ROUTING_STORE_TECH_INITS      
,STG.SOURCING_IND                  
,STG.MAJ_MED_PRIOR_AUTH_NBR        
,STG.TIP_RSN_FOR_SVC_CD            
,STG.DATA_REV_SPEC_ID              
,STG.DATA_REV_SPEC_STORE_NBR       
,STG.FILL_RPH_OF_RECORD_ID         
,STG.COB_PLAN_INCNTV_PAID_AMT      
,STG.COB_PLN_INCNT_AMT_SBMTD       
,STG.fill_est_pick_up_dttm         
,STG.data_rev_spec_dttm            
,STG.rx_daw_ind                    
,STG.relocate_fm_str_nbr           
,STG.cob_gen_recipient_nbr          
,STG.celgene_md_auth_nbr
,STG.celgene_conf_nbr
,STG.plan_other_amt_paid_type
,STG.plan_other_amt_subm_type
,STG.plan_returnd_coins_amt
,STG.plan_rtrnd_coins_amt
,STG.plan_other_amt_paid_2
,STG.plan_other_amt_paid_typ2
,STG.plan_other_amt_paid_3
,STG.plan_other_amt_paid_typ3
,STG.fill_print_dttm
,STG.pat_lang_pref_cd
,STG.rebilling_dttm
,STG.fill_90day_pref_ind
,STG.fill_90day_pref_stat_cd
,STG.pat_pickup_id
,STG.pickup_id
,STG.pickup_first_name
,STG.pickup_last_name
,STG.pickup_id_state
,STG.pickup_id_country
,STG.pickup_id_qlfr
,STG.pickup_rel_cd
,STG.dl_proc_msg
,STG.cob_dl_proc_msg
,STG.proc_ctrl_nbr
,STG.dispensed_ndc
,STG.overstock_ind
,STG.med_partd_notice_ind
,STG.med_partd_print_dttm
,STG.ben_stg_qualifier_1
,STG.ben_stg_qualifier_2
,STG.ben_stg_qualifier_3
,STG.ben_stg_qualifier_4
,STG.ben_stg_amount_1
,STG.ben_stg_amount_2
,STG.ben_stg_amount_3
,STG.ben_stg_amount_4
,STG.coupon_drug_id
,STG.cob_coupon_drug_id
,STG.coupon_ind
,STG.cob_coupon_ind
,STG.other_coverage_cd
,STG.cob_other_coverage_cd
,STG.partial_fil_intnded_qty
,STG.triplicate_serial_nbr
,  STG.delivery_ind
,  STG.delivery_comments
,  STG.sold_local_dttm
,  STG.pat_pickup_gov_auth_id
,  STG.pat_pickup_id_qlfr
,  STG.pat_pickup_rel_cd
,  STG.routing_store_rph_inits
,  STG.source_system_name
,  STG.source_sys_trans_id
,  STG.sys_status_when_ent
, STG.additional_msg_qlfr_w1_cd
, STG.approved_msg_cd
, STG.cob_approved_msg_cd
, STG.approved_msg_cd_2
, STG.cob_approved_msg_cd_2
, STG.approved_msg_cd_3
, STG.cob_approved_msg_cd_3
, STG.approved_msg_cd_4
, STG.cob_approved_msg_cd_4
, STG.approved_msg_cd_5
, STG.cob_approved_msg_cd_5
,  STG.gen_recip_nbr_returnd
,  STG.ntwk_reimb_id_returnd
,  STG.plan_returnd_grp_nbr
,  STG.plan_id_returnd
,  STG.general_pbr_nbr
,  STG.cob_general_pbr_nbr
,  STG.general_rph_nbr_qlfr
,  STG.prior_auth_cd
,  STG.prior_auth_nbr
,  STG.additional_mfgr_coupon_w1_msg
,STG.wo_correlation_id
,STG.wo_rx_count
,STG.short_fill_ind
,STG.db_cob_proc_ctrl_nbr

  FROM (SELECT rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_entered_dttm,
               max(cdc_txn_commit_dttm) max_cdc_dttm 
          FROM $pTDStageDB.etl_tbf0_rx_transaction_stg 
         WHERE cdc_operation_type_cd='INSERT' 
         GROUP BY 1,2,3,4,5) MX_INS, 
       $pTDStageDB.etl_tbf0_rx_transaction_stg STG
 WHERE STG.STORE_NBR=MX_INS.STORE_NBR 
   AND STG.RX_NBR=MX_INS.RX_NBR 
   AND STG.FILL_NBR=MX_INS.FILL_NBR
   AND STG.FILL_PARTIAL_NBR=MX_INS.FILL_PARTIAL_NBR
   AND STG.FILL_ENTERED_DTTM=MX_INS.FILL_ENTERED_DTTM
   AND STG.cdc_txn_commit_dttm < MX_INS.max_cdc_dttm;""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  runSql("""delete from $pTDStageDB.etl_tbf0_rx_transaction_stg STG 
using $APT_TERA_SYNC_DATABASE.ETL_TBF0_TRANS_CHANGE_ANALYSIS_STG PROC 
WHERE STG.STORE_NBR=PROC.STORE_NBR
   AND STG.RX_NBR=PROC.RX_NBR
   AND STG.FILL_NBR=PROC.FILL_NBR
   AND STG.FILL_PARTIAL_NBR=PROC.FILL_PARTIAL_NBR
   AND STG.FILL_ENTERED_DTTM=PROC.FILL_ENTERED_DTTM
   AND STG.CDC_TXN_COMMIT_DTTM = PROC.CDC_TXN_COMMIT_DTTM
   AND STG.CDC_SEQ_NBR = PROC.CDC_SEQ_NBR
   AND STG.CDC_RBA_NBR = PROC.CDC_RBA_NBR
   AND STG.CDC_BEFORE_AFTER_CD = PROC.CDC_BEFORE_AFTER_CD
   AND STG.CDC_OPERATION_TYPE_CD = PROC.CDC_OPERATION_TYPE_CD
   AND STG.CDC_TXN_POSITION_CD = PROC.CDC_TXN_POSITION_CD;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""")
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/*================================================================**#** Build Performance Tables                                       **#**================================================================*/
  runSql("""DELETE FROM $pTDStageDB.ETL_PROC_TRANS_PRESC_STG; 
-- DEL_ALL - Remove ALL keyword from DELETE statement
""")
  if (Action.errorCode != 0):
    return
  runSql("""insert into $pTDStageDB.ETL_PROC_TRANS_PRESC_STG
(
        RX_NBR
        ,STR_NBR
        ,RX_CREATE_DT
)
SELECT TRX.RX_NBR
 ,TRX.STR_NBR
 ,CASE WHEN  TRX.Rx_Create_dt  =  '2099-12-31'::DATE then null ELSE  TRX. Rx_Create_dt END
 from

 (SELECT Z.rx_nbr,Z.str_nbr, max(coalesce (Rx_Create_dt , '2099-12-31'::DATE)) Rx_Create_dt
    FROM  $pTDViewDBName.PRESCRIPTION Z,
                     (SELECT RX_NBR, STORE_NBR
                        FROM $pTDStageDB.etl_tbf0_rx_transaction_stg
                        GROUP BY RX_NBR, STORE_NBR ) Y
   WHERE Z.RX_NBR = Y.RX_NBR
          AND Z.STR_NBR = Y.STORE_NBR
        group by 1,2)  TRX;
-- FUN_DATE_CAST - Reformat STRING-to-DATE casting
""")
  if (Action.errorCode != 0):
    return
  #--call PRDUTIL.TABLE_STATS('$pTDStageDB', 'ETL_PROC_TRANS_PRESC_STG');
  #if (Action.errorCode != 0):
  #  return
  runSql("""DELETE FROM $pTDStageDB.ETL_OUTER_RX_TRANSACTION_STG; 
-- DEL_ALL - Remove ALL keyword from DELETE statement
""")
  if (Action.errorCode != 0):
    return
  runSql("""INSERT  INTO $pTDStageDB.ETL_OUTER_RX_TRANSACTION_STG
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,fill_partial_nbr
,refills_remaining
,fill_wac_cost_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_submtd_copay_amt
,pbr_id
,fill_source_cd
,refills_remain_when_ent
,cob_plan_rtrnd_fee_amt
,tot_amt_paid_ind
,drug_class
,drug_name
,drug_id
,plan_returnd_copay_amt
,plan_total_paid_amt
,plan_returnd_tax_amt
,plan_submtd_cost_amt
,plan_submtd_fee_amt
,plan_submtd_tax_amt
,pat_id
,sims_upc
,pbr_loc_id
,create_user_id
,create_dttm
,cob_plan_rtrnd_copay_amt
,cob_plan_total_paid_amt
,cob_plan_rtrnd_cost_amt
,cob_plan_rtrnd_tax_amt
,cob_plan_sbmtd_copay_amt
,cob_plan_sbmtd_cost_amt
,cob_plan_sbmtd_fee_amt
,cob_plan_sbmtd_tax_amt
,src_partition_nbr
,fill_adjudication_cd
,fill_awp_cost_amt
,fill_days_supply
,fill_entered_dttm
,fill_label_price_amt
,fill_qty_dispensed
,fill_retail_price_amt
,claim_reference_nbr
,fill_nbr_dispensed
,plan_id
,fill_status_cd
,fill_entered_user_id
,fill_verified_user_id
,fill_verified_dttm
,fill_sold_dttm
,fill_deleted_dttm
,fill_discount_cd
,fill_pay_method_cd
,fill_discount_amt
,fill_sold_amt
,fill_type_cd
,update_user_id
,update_dttm
,partial_fill_cd
,fill_adjudication_dttm
,cob_fill_adjudication_cd
,cob_claim_ref_nbr
,cob_plan_id
,cob_fill_adj_dttm
,fill_data_rev_id
,fill_data_rev_dttm
,filling_user_id
,filling_dttm
,override_user_id
,override_dttm
,entered_store_nbr
,reviewed_store_nbr
,plan_gross_due_amt
,cob_plan_gross_due_amt
,DL_REJECT_CD_01
,DL_REJECT_CD_02
,DL_REJECT_CD_03
,DL_REJECT_CD_04
,DL_REJECT_CD_05
,FILL_DEL_ADJUDICATION_CD
,FILL_PRICE_OVERRIDE_AMT
,PLAN_INCENTIVE_PAID_AMT
,GENERAL_RECIPIENT_NBR
,BIN_NBR
,PLAN_GROUP_NBR
,DRUG_WAREHOUSE_IND
,GENERAL_PHRM_NBR
,REIMBURS_LOSS_AMT
,COST_PLUS_FEE_CD
,ACCEPT_CONSULT_IND
,BASIS_OF_REIMB_DETERM
,PLAN_OTHER_AMT_PAID
,AMT_ATTRIBUTED_TO_TAX
,PLAN_INCENT_AMT_SUBMTD
,PLAN_OTHER_AMT_SUBMTD
,LVL_OF_SVC_CD
,COB_DL_REJECT_CD_01
,COB_DL_REJECT_CD_02
,COB_DL_REJECT_CD_03
,COB_DL_REJECT_CD_04
,COB_DL_REJECT_CD_05
,COB_FILL_DEL_ADJ_CD
,COB_BIN_NBR
,COB_PLAN_GROUP_NBR
,COB_GENERAL_PHRM_NBR
,COB_BASIS_OF_REIMB_DETRM
,COB_AMT_ATTRIB_TO_TAX
,COB_PLN_OTHR_AMT_PD
,CASH_DISC_SAV_AMT
,GENERAL_RPH_NBR
,ROUTING_STORE_TECH_INITS
,SOURCING_IND
,MAJ_MED_PRIOR_AUTH_NBR
,TIP_RSN_FOR_SVC_CD
,DATA_REV_SPEC_ID
,DATA_REV_SPEC_STORE_NBR
,FILL_RPH_OF_RECORD_ID
,COB_PLAN_INCNTV_PAID_AMT
,COB_PLN_INCNT_AMT_SBMTD
,fill_est_pick_up_dttm
,data_rev_spec_dttm
,rx_daw_ind
,relocate_fm_str_nbr
,cob_gen_recipient_nbr
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr,
				/*Added as part of CR765300*/
				filling_store_nbr,
fill_verified_store_nbr,
mult_prod_review_ind,
pat_selct_user_id,
pbr_selct_user_id,
pat_selct_dttm,
pbr_selct_dttm,
pat_selct_str_nbr,
pbr_selct_str_nbr,
ntt_ind,
fill_sold_yr,
fill_enter_mnth

)
SELECT
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,fill_partial_nbr
,refills_remaining
,fill_wac_cost_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_submtd_copay_amt
,pbr_id
,fill_source_cd
,refills_remain_when_ent
,cob_plan_rtrnd_fee_amt
,tot_amt_paid_ind
,drug_class
,drug_name
,drug_id
,plan_returnd_copay_amt
,plan_total_paid_amt
,plan_returnd_tax_amt
,plan_submtd_cost_amt
,plan_submtd_fee_amt
,plan_submtd_tax_amt
,pat_id
,sims_upc
,pbr_loc_id
,create_user_id
,create_dttm
,cob_plan_rtrnd_copay_amt
,cob_plan_total_paid_amt
,cob_plan_rtrnd_cost_amt
,cob_plan_rtrnd_tax_amt
,cob_plan_sbmtd_copay_amt
,cob_plan_sbmtd_cost_amt
,cob_plan_sbmtd_fee_amt
,cob_plan_sbmtd_tax_amt
,src_partition_nbr
,fill_adjudication_cd
,fill_awp_cost_amt
,fill_days_supply
,fill_entered_dttm
,fill_label_price_amt
,fill_qty_dispensed
,fill_retail_price_amt
,claim_reference_nbr
,fill_nbr_dispensed
,plan_id
,fill_status_cd
,fill_entered_user_id
,fill_verified_user_id
,fill_verified_dttm
,fill_sold_dttm
,fill_deleted_dttm
,fill_discount_cd
,fill_pay_method_cd
,fill_discount_amt
,fill_sold_amt
,fill_type_cd
,update_user_id
,update_dttm
,partial_fill_cd
,fill_adjudication_dttm
,cob_fill_adjudication_cd
,cob_claim_ref_nbr
,cob_plan_id
,cob_fill_adj_dttm
,fill_data_rev_id
,fill_data_rev_dttm
,filling_user_id
,filling_dttm
,override_user_id
,override_dttm
,entered_store_nbr
,reviewed_store_nbr
,plan_gross_due_amt
,cob_plan_gross_due_amt
,DL_REJECT_CD_01
,DL_REJECT_CD_02
,DL_REJECT_CD_03
,DL_REJECT_CD_04
,DL_REJECT_CD_05
,FILL_DEL_ADJUDICATION_CD
,FILL_PRICE_OVERRIDE_AMT
,PLAN_INCENTIVE_PAID_AMT
,GENERAL_RECIPIENT_NBR
,BIN_NBR
,PLAN_GROUP_NBR
,DRUG_WAREHOUSE_IND
,GENERAL_PHRM_NBR
,REIMBURS_LOSS_AMT
,COST_PLUS_FEE_CD
,ACCEPT_CONSULT_IND
,BASIS_OF_REIMB_DETERM
,PLAN_OTHER_AMT_PAID
,AMT_ATTRIBUTED_TO_TAX
,PLAN_INCENT_AMT_SUBMTD
,PLAN_OTHER_AMT_SUBMTD
,LVL_OF_SVC_CD
,COB_DL_REJECT_CD_01
,COB_DL_REJECT_CD_02
,COB_DL_REJECT_CD_03
,COB_DL_REJECT_CD_04
,COB_DL_REJECT_CD_05
,COB_FILL_DEL_ADJ_CD
,COB_BIN_NBR
,COB_PLAN_GROUP_NBR
,COB_GENERAL_PHRM_NBR
,COB_BASIS_OF_REIMB_DETRM
,COB_AMT_ATTRIB_TO_TAX
,COB_PLN_OTHR_AMT_PD
,CASH_DISC_SAV_AMT
,GENERAL_RPH_NBR
,ROUTING_STORE_TECH_INITS
,SOURCING_IND
,MAJ_MED_PRIOR_AUTH_NBR
,TIP_RSN_FOR_SVC_CD
,DATA_REV_SPEC_ID
,DATA_REV_SPEC_STORE_NBR
,FILL_RPH_OF_RECORD_ID
,COB_PLAN_INCNTV_PAID_AMT
,COB_PLN_INCNT_AMT_SBMTD
,fill_est_pick_up_dttm
,data_rev_spec_dttm
,rx_daw_ind
,relocate_fm_str_nbr
,cob_gen_recipient_nbr
,celgene_md_auth_nbr
,celgene_conf_nbr
,plan_other_amt_paid_type
,plan_other_amt_subm_type
,plan_returnd_coins_amt
,plan_rtrnd_coins_amt
,plan_other_amt_paid_2
,plan_other_amt_paid_typ2
,plan_other_amt_paid_3
,plan_other_amt_paid_typ3
,fill_print_dttm
,pat_lang_pref_cd
,rebilling_dttm
,fill_90day_pref_ind
,fill_90day_pref_stat_cd
,pat_pickup_id
,pickup_id
,pickup_first_name
,pickup_last_name
,pickup_id_state
,pickup_id_country
,pickup_id_qlfr
,pickup_rel_cd
,dl_proc_msg
,cob_dl_proc_msg
,proc_ctrl_nbr
,dispensed_ndc
,overstock_ind
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
,partial_fil_intnded_qty
,triplicate_serial_nbr
,  delivery_ind
,  delivery_comments
,  sold_local_dttm
,  pat_pickup_gov_auth_id
,  pat_pickup_id_qlfr
,  pat_pickup_rel_cd
,  routing_store_rph_inits
,  source_system_name
,  source_sys_trans_id
,  sys_status_when_ent
, additional_msg_qlfr_w1_cd
, approved_msg_cd
, cob_approved_msg_cd
, approved_msg_cd_2
, cob_approved_msg_cd_2
, approved_msg_cd_3
, cob_approved_msg_cd_3
, approved_msg_cd_4
, cob_approved_msg_cd_4
, approved_msg_cd_5
, cob_approved_msg_cd_5
,  gen_recip_nbr_returnd
,  ntwk_reimb_id_returnd
,  plan_returnd_grp_nbr
,  plan_id_returnd
,  general_pbr_nbr
,  cob_general_pbr_nbr
,  general_rph_nbr_qlfr
,  prior_auth_cd
,  prior_auth_nbr
,  additional_mfgr_coupon_w1_msg
,wo_correlation_id
,wo_rx_count
,short_fill_ind
,db_cob_proc_ctrl_nbr,
				/*Added as part of CR765300*/
				filling_store_nbr,
fill_verified_store_nbr,
mult_prod_review_ind,
pat_selct_user_id,
pbr_selct_user_id,
pat_selct_dttm,
pbr_selct_dttm,
pat_selct_str_nbr,
pbr_selct_str_nbr,
ntt_ind,
fill_sold_yr,
fill_enter_mnth
FROM    $pTDStageDB.etl_tbf0_rx_transaction_stg
WHERE   (STORE_NBR,RX_NBR,FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTERED_DTTM, CDC_TXN_COMMIT_DTTM,CDC_SEQ_NBR,CDC_RBA_NBR)
IN
(
SELECT  BFR.STORE_NBR,
        BFR.RX_NBR,
        BFR.FILL_NBR,
        BFR.FILL_PARTIAL_NBR,
        BFR.FILL_ENTERED_DTTM,
        BFR.CDC_TXN_COMMIT_DTTM,
        BFR.CDC_SEQ_NBR,
        BFR.CDC_RBA_NBR
FROM    $pTDStageDB.etl_tbf0_rx_transaction_stg BFR
INNER   JOIN  $pTDStageDB.etl_tbf0_rx_transaction_stg AFT
ON      AFT.CDC_TXN_COMMIT_DTTM         = BFR.CDC_TXN_COMMIT_DTTM
AND     AFT.CDC_SEQ_NBR                 = BFR.CDC_SEQ_NBR
AND     AFT.CDC_RBA_NBR                 = BFR.CDC_RBA_NBR
AND     AFT.CDC_OPERATION_TYPE_CD       IN ('SQL COMPUPDATE','PK UPDATE')
AND     AFT.CDC_BEFORE_AFTER_CD         = 'AFTER'
AND     BFR.CDC_OPERATION_TYPE_CD       = 'SQL COMPUPDATE'
AND     BFR.CDC_BEFORE_AFTER_CD         = 'BEFORE'
AND
(
   (BFR.fill_source_cd          IS NOT NULL AND AFT.fill_source_cd              IS NULL )
OR (BFR.fill_wac_cost_amt       IS NOT NULL AND AFT.fill_wac_cost_amt           IS NULL )
OR (BFR.drug_id                 IS NOT NULL AND AFT.drug_id                     IS NULL )
OR (BFR.drug_name               IS NOT NULL AND AFT.drug_name                   IS NULL )
OR (BFR.drug_class              IS NOT NULL AND AFT.drug_class                  IS NULL )
OR (BFR.refills_remaining       IS NOT NULL AND AFT.refills_remaining           IS NULL )
OR (BFR.refills_remain_when_ent IS NOT NULL AND AFT.refills_remain_when_ent     IS NULL )
OR (BFR.tot_amt_paid_ind        IS NOT NULL AND AFT.tot_amt_paid_ind            IS NULL )
OR (BFR.sims_upc                IS NOT NULL AND AFT.sims_upc                    IS NULL )
OR (BFR.pat_id                    IS NOT NULL AND    AFT.pat_id                 IS NULL )
OR (BFR.pbr_id                    IS NOT NULL AND    AFT.pbr_id                 IS NULL )
OR (BFR.pbr_loc_id                IS NOT NULL AND    AFT.pbr_loc_id             IS NULL )
OR (BFR.entered_store_nbr         IS NOT NULL AND    AFT.entered_store_nbr      IS NULL )
OR (BFR.fill_awp_cost_amt         IS NOT NULL AND    AFT.fill_awp_cost_amt      IS NULL )
OR (BFR.fill_data_rev_dttm        IS NOT NULL AND    AFT.fill_data_rev_dttm     IS NULL )
OR (BFR.fill_data_rev_id          IS NOT NULL AND    AFT.fill_data_rev_id       IS NULL )
OR (BFR.fill_days_supply          IS NOT NULL AND    AFT.fill_days_supply       IS NULL )
OR (BFR.fill_deleted_dttm         IS NOT NULL AND    AFT.fill_deleted_dttm      IS NULL )
OR (BFR.fill_discount_amt         IS NOT NULL AND    AFT.fill_discount_amt      IS NULL )
OR (BFR.fill_discount_cd          IS NOT NULL AND    AFT.fill_discount_cd       IS NULL )
OR (BFR.fill_entered_dttm         IS NOT NULL AND    AFT.fill_entered_dttm      IS NULL )
OR (BFR.fill_entered_user_id      IS NOT NULL AND    AFT.fill_entered_user_id   IS NULL )
OR (BFR.fill_label_price_amt      IS NOT NULL AND    AFT.fill_label_price_amt   IS NULL )
OR (BFR.fill_nbr_dispensed        IS NOT NULL AND    AFT.fill_nbr_dispensed     IS NULL )
OR (BFR.fill_pay_method_cd        IS NOT NULL AND    AFT.fill_pay_method_cd     IS NULL )
OR (BFR.fill_qty_dispensed        IS NOT NULL AND    AFT.fill_qty_dispensed     IS NULL )
OR (BFR.fill_retail_price_amt     IS NOT NULL AND    AFT.fill_retail_price_amt  IS NULL )
OR (BFR.fill_sold_amt             IS NOT NULL AND    AFT.fill_sold_amt          IS NULL )
OR (BFR.fill_sold_dttm            IS NOT NULL AND    AFT.fill_sold_dttm         IS NULL )
OR (BFR.fill_status_cd            IS NOT NULL AND    AFT.fill_status_cd         IS NULL )
OR (BFR.fill_type_cd              IS NOT NULL AND    AFT.fill_type_cd           IS NULL )
OR (BFR.fill_verified_dttm        IS NOT NULL AND    AFT.fill_verified_dttm     IS NULL )
OR (BFR.fill_verified_user_id     IS NOT NULL AND    AFT.fill_verified_user_id  IS NULL )
OR (BFR.filling_dttm              IS NOT NULL AND    AFT.filling_dttm           IS NULL )
OR (BFR.filling_user_id           IS NOT NULL AND    AFT.filling_user_id        IS NULL )
OR (BFR.override_dttm             IS NOT NULL AND    AFT.override_dttm          IS NULL )
OR (BFR.override_user_id          IS NOT NULL AND    AFT.override_user_id       IS NULL )
OR (BFR.partial_fill_cd           IS NOT NULL AND    AFT.partial_fill_cd        IS NULL )
OR (BFR.reviewed_store_nbr        IS NOT NULL AND    AFT.reviewed_store_nbr     IS NULL )
OR (BFR.ACCEPT_CONSULT_IND        IS NOT NULL AND    AFT.ACCEPT_CONSULT_IND       IS NULL )
OR (BFR.CASH_DISC_SAV_AMT         IS NOT NULL AND    AFT.CASH_DISC_SAV_AMT        IS NULL )
OR (BFR.data_rev_spec_dttm        IS NOT NULL AND    AFT.data_rev_spec_dttm       IS NULL )
OR (BFR.DATA_REV_SPEC_ID          IS NOT NULL AND    AFT.DATA_REV_SPEC_ID         IS NULL )
OR (BFR.DATA_REV_SPEC_STORE_NBR   IS NOT NULL AND    AFT.DATA_REV_SPEC_STORE_NBR  IS NULL )
OR (BFR.FILL_PRICE_OVERRIDE_AMT   IS NOT NULL AND    AFT.FILL_PRICE_OVERRIDE_AMT  IS NULL )
OR (BFR.FILL_RPH_OF_RECORD_ID     IS NOT NULL AND    AFT.FILL_RPH_OF_RECORD_ID    IS NULL )
OR (BFR.ROUTING_STORE_TECH_INITS  IS NOT NULL AND    AFT.ROUTING_STORE_TECH_INITS IS NULL )
OR (BFR.DRUG_WAREHOUSE_IND        IS NOT NULL AND    AFT.DRUG_WAREHOUSE_IND       IS NULL )
OR (BFR.LVL_OF_SVC_CD             IS NOT NULL AND    AFT.LVL_OF_SVC_CD            IS NULL )
OR (BFR.rx_daw_ind                IS NOT NULL AND    AFT.rx_daw_ind               IS NULL )
OR (BFR.SOURCING_IND              IS NOT NULL AND    AFT.SOURCING_IND             IS NULL )
OR (BFR.TIP_RSN_FOR_SVC_CD        IS NOT NULL AND    AFT.TIP_RSN_FOR_SVC_CD       IS NULL )
OR (BFR.fill_est_pick_up_dttm     IS NOT NULL AND    AFT.fill_est_pick_up_dttm    IS NULL )
OR (BFR.COST_PLUS_FEE_CD          IS NOT NULL AND    AFT.COST_PLUS_FEE_CD         IS NULL )
OR (BFR.PLAN_ID                         IS NOT NULL AND AFT.PLAN_ID                     IS NULL )
OR (BFR.COB_PLAN_ID                     IS NOT NULL AND AFT.COB_PLAN_ID                 IS NULL )
OR (BFR.PLAN_TOTAL_PAID_AMT             IS NOT NULL AND AFT.PLAN_TOTAL_PAID_AMT         IS NULL )
OR (BFR.COB_PLAN_TOTAL_PAID_AMT         IS NOT NULL AND AFT.COB_PLAN_TOTAL_PAID_AMT     IS NULL )
OR (BFR.PLAN_RETURND_COST_AMT           IS NOT NULL AND AFT.PLAN_RETURND_COST_AMT       IS NULL )
OR (BFR.COB_PLAN_RTRND_COST_AMT         IS NOT NULL AND AFT.COB_PLAN_RTRND_COST_AMT     IS NULL )
OR (BFR.PLAN_RETURND_FEE_AMT            IS NOT NULL AND AFT.PLAN_RETURND_FEE_AMT        IS NULL )
OR (BFR.COB_PLAN_RTRND_FEE_AMT          IS NOT NULL AND AFT.COB_PLAN_RTRND_FEE_AMT      IS NULL )
OR (BFR.PLAN_RETURND_COPAY_AMT          IS NOT NULL AND AFT.PLAN_RETURND_COPAY_AMT      IS NULL )
OR (BFR.COB_PLAN_RTRND_COPAY_AMT        IS NOT NULL AND AFT.COB_PLAN_RTRND_COPAY_AMT    IS NULL )
OR (BFR.PLAN_RETURND_TAX_AMT            IS NOT NULL AND AFT.PLAN_RETURND_TAX_AMT        IS NULL )
OR (BFR.COB_PLAN_RTRND_TAX_AMT          IS NOT NULL AND AFT.COB_PLAN_RTRND_TAX_AMT      IS NULL )
OR (BFR.PLAN_SUBMTD_COPAY_AMT           IS NOT NULL AND AFT.PLAN_SUBMTD_COPAY_AMT       IS NULL )
OR (BFR.COB_PLAN_SBMTD_COPAY_AMT        IS NOT NULL AND AFT.COB_PLAN_SBMTD_COPAY_AMT    IS NULL )
OR (BFR.PLAN_SUBMTD_COST_AMT            IS NOT NULL AND AFT.PLAN_SUBMTD_COST_AMT        IS NULL )
OR (BFR.COB_PLAN_SBMTD_COST_AMT         IS NOT NULL AND AFT.COB_PLAN_SBMTD_COST_AMT     IS NULL )
OR (BFR.PLAN_SUBMTD_FEE_AMT             IS NOT NULL AND AFT.PLAN_SUBMTD_FEE_AMT         IS NULL )
OR (BFR.COB_PLAN_SBMTD_FEE_AMT          IS NOT NULL AND AFT.COB_PLAN_SBMTD_FEE_AMT      IS NULL )
OR (BFR.PLAN_SUBMTD_TAX_AMT             IS NOT NULL AND AFT.PLAN_SUBMTD_TAX_AMT         IS NULL )
OR (BFR.COB_PLAN_SBMTD_TAX_AMT          IS NOT NULL AND AFT.COB_PLAN_SBMTD_TAX_AMT      IS NULL )
OR (BFR.plan_gross_due_amt              IS NOT NULL AND AFT.plan_gross_due_amt          IS NULL )
OR (BFR.cob_plan_gross_due_amt          IS NOT NULL AND AFT.cob_plan_gross_due_amt      IS NULL )
OR (BFR.claim_reference_nbr         IS NOT NULL AND AFT.claim_reference_nbr       IS NULL )
OR (BFR.cob_claim_ref_nbr           IS NOT NULL AND AFT.cob_claim_ref_nbr         IS NULL )
OR (BFR.fill_adjudication_cd        IS NOT NULL AND AFT.fill_adjudication_cd      IS NULL )
OR (BFR.cob_fill_adj_dttm           IS NOT NULL AND AFT.cob_fill_adj_dttm         IS NULL )
OR (BFR.cob_fill_adjudication_cd    IS NOT NULL AND AFT.cob_fill_adjudication_cd  IS NULL )
OR (BFR.fill_adjudication_dttm      IS NOT NULL AND AFT.fill_adjudication_dttm    IS NULL )
OR (BFR.BASIS_OF_REIMB_DETERM       IS NOT NULL AND AFT.BASIS_OF_REIMB_DETERM     IS NULL )
OR (BFR.BIN_NBR                     IS NOT NULL AND AFT.BIN_NBR                   IS NULL )
OR (BFR.PLAN_GROUP_NBR              IS NOT NULL AND AFT.PLAN_GROUP_NBR            IS NULL )
OR (BFR.COB_BASIS_OF_REIMB_DETRM    IS NOT NULL AND AFT.COB_BASIS_OF_REIMB_DETRM  IS NULL )
OR (BFR.COB_BIN_NBR                 IS NOT NULL AND AFT.COB_BIN_NBR               IS NULL )
OR (BFR.COB_PLAN_GROUP_NBR          IS NOT NULL AND AFT.COB_PLAN_GROUP_NBR        IS NULL )
OR (BFR.FILL_DEL_ADJUDICATION_CD    IS NOT NULL AND AFT.FILL_DEL_ADJUDICATION_CD  IS NULL )
OR (BFR.GENERAL_PHRM_NBR            IS NOT NULL AND AFT.GENERAL_PHRM_NBR          IS NULL )
OR (BFR.GENERAL_RECIPIENT_NBR       IS NOT NULL AND AFT.GENERAL_RECIPIENT_NBR     IS NULL )
OR (BFR.GENERAL_RPH_NBR             IS NOT NULL AND AFT.GENERAL_RPH_NBR           IS NULL )
OR (BFR.MAJ_MED_PRIOR_AUTH_NBR      IS NOT NULL AND AFT.MAJ_MED_PRIOR_AUTH_NBR    IS NULL )
OR (BFR.PLAN_INCENT_AMT_SUBMTD      IS NOT NULL AND AFT.PLAN_INCENT_AMT_SUBMTD    IS NULL )
OR (BFR.PLAN_INCENTIVE_PAID_AMT     IS NOT NULL AND AFT.PLAN_INCENTIVE_PAID_AMT   IS NULL )
OR (BFR.PLAN_OTHER_AMT_PAID         IS NOT NULL AND AFT.PLAN_OTHER_AMT_PAID       IS NULL )
OR (BFR.PLAN_OTHER_AMT_SUBMTD       IS NOT NULL AND AFT.PLAN_OTHER_AMT_SUBMTD     IS NULL )
OR (BFR.AMT_ATTRIBUTED_TO_TAX       IS NOT NULL AND AFT.AMT_ATTRIBUTED_TO_TAX     IS NULL )
OR (BFR.REIMBURS_LOSS_AMT           IS NOT NULL AND AFT.REIMBURS_LOSS_AMT         IS NULL )
OR (BFR.COB_FILL_DEL_ADJ_CD         IS NOT NULL AND AFT.COB_FILL_DEL_ADJ_CD       IS NULL )
OR (BFR.COB_GENERAL_PHRM_NBR        IS NOT NULL AND AFT.COB_GENERAL_PHRM_NBR      IS NULL )
OR (BFR.COB_GEN_RECIPIENT_NBR        IS NOT NULL AND AFT.COB_GEN_RECIPIENT_NBR    IS NULL )
OR (BFR.COB_PLN_INCNT_AMT_SBMTD     IS NOT NULL AND AFT.COB_PLN_INCNT_AMT_SBMTD   IS NULL )
OR (BFR.COB_PLAN_INCNTV_PAID_AMT    IS NOT NULL AND AFT.COB_PLAN_INCNTV_PAID_AMT  IS NULL )
OR (BFR.COB_PLN_OTHR_AMT_PD         IS NOT NULL AND AFT.COB_PLN_OTHR_AMT_PD       IS NULL )
OR (BFR.COB_AMT_ATTRIB_TO_TAX       IS NOT NULL AND AFT.COB_AMT_ATTRIB_TO_TAX     IS NULL )
OR (BFR.fill_sold_dttm              IS NOT NULL AND AFT.fill_sold_dttm            IS NULL )
OR (BFR.celgene_md_auth_nbr         IS NOT NULL AND AFT.celgene_md_auth_nbr       IS NULL )
OR (BFR.celgene_conf_nbr            IS NOT NULL AND AFT.celgene_conf_nbr          IS NULL )
OR (BFR.plan_other_amt_paid_type    IS NOT NULL AND AFT.plan_other_amt_paid_type  IS NULL )
OR (BFR.plan_other_amt_subm_type    IS NOT NULL AND AFT.plan_other_amt_subm_type  IS NULL )
OR (BFR.plan_returnd_coins_amt      IS NOT NULL AND AFT.plan_returnd_coins_amt    IS NULL )
OR (BFR.plan_rtrnd_coins_amt        IS NOT NULL AND AFT.plan_rtrnd_coins_amt      IS NULL )
OR (BFR.plan_other_amt_paid_2       IS NOT NULL AND AFT.plan_other_amt_paid_2     IS NULL )
OR (BFR.plan_other_amt_paid_typ2    IS NOT NULL AND AFT.plan_other_amt_paid_typ2  IS NULL )
OR (BFR.plan_other_amt_paid_3       IS NOT NULL AND AFT.plan_other_amt_paid_3     IS NULL )
OR (BFR.plan_other_amt_paid_typ3    IS NOT NULL AND AFT.plan_other_amt_paid_typ3  IS NULL )
OR (BFR.fill_print_dttm             IS NOT NULL AND AFT.fill_print_dttm           IS NULL )
OR (BFR.pat_lang_pref_cd            IS NOT NULL AND AFT.pat_lang_pref_cd          IS NULL )
OR (BFR.rebilling_dttm              IS NOT NULL AND AFT.rebilling_dttm            IS NULL )
OR (BFR.fill_90day_pref_ind              IS NOT NULL AND AFT.fill_90day_pref_ind            IS NULL )
OR (BFR.fill_90day_pref_stat_cd          IS NOT NULL AND AFT.fill_90day_pref_stat_cd        IS NULL )
OR (BFR.pat_pickup_id          IS NOT NULL AND AFT.pat_pickup_id        IS NULL )
OR (BFR.pickup_id          IS NOT NULL AND AFT.pickup_id        IS NULL )
OR (BFR.pickup_first_name          IS NOT NULL AND AFT.pickup_first_name        IS NULL )
OR (BFR.pickup_last_name          IS NOT NULL AND AFT.pickup_last_name        IS NULL )
OR (BFR.pickup_id_state          IS NOT NULL AND AFT.pickup_id_state        IS NULL )
OR (BFR.pickup_id_country          IS NOT NULL AND AFT.pickup_id_country        IS NULL )
OR (BFR.pickup_id_qlfr         IS NOT NULL AND AFT.pickup_id_qlfr        IS NULL )
OR (BFR.pickup_rel_cd          IS NOT NULL AND AFT.pickup_rel_cd        IS NULL )
OR (BFR.dl_proc_msg            IS NOT NULL AND AFT.dl_proc_msg          IS NULL )
OR (BFR.cob_dl_proc_msg        IS NOT NULL AND AFT.cob_dl_proc_msg      IS NULL )
OR (BFR.proc_ctrl_nbr          IS NOT NULL AND AFT.proc_ctrl_nbr        IS NULL )
OR (BFR.dispensed_ndc          IS NOT NULL AND AFT.dispensed_ndc        IS NULL )
OR (BFR.overstock_ind          IS NOT NULL AND AFT.overstock_ind        IS NULL )
OR (BFR.med_partd_notice_ind   IS NOT NULL AND AFT.med_partd_notice_ind IS NULL )
OR (BFR.med_partd_print_dttm   IS NOT NULL AND AFT.med_partd_print_dttm IS NULL )
OR (BFR.ben_stg_qualifier_1            IS NOT NULL AND AFT.ben_stg_qualifier_1          IS NULL )
OR (BFR.ben_stg_qualifier_2            IS NOT NULL AND AFT.ben_stg_qualifier_2          IS NULL )
OR (BFR.ben_stg_qualifier_3            IS NOT NULL AND AFT.ben_stg_qualifier_3          IS NULL )
OR (BFR.ben_stg_qualifier_4            IS NOT NULL AND AFT.ben_stg_qualifier_4          IS NULL )
OR (BFR.ben_stg_amount_1            IS NOT NULL AND AFT.ben_stg_amount_1          IS NULL )
OR (BFR.ben_stg_amount_2            IS NOT NULL AND AFT.ben_stg_amount_2          IS NULL )
OR (BFR.ben_stg_amount_3            IS NOT NULL AND AFT.ben_stg_amount_3          IS NULL )
OR (BFR.ben_stg_amount_4            IS NOT NULL AND AFT.ben_stg_amount_4          IS NULL )
OR (BFR.coupon_drug_id            IS NOT NULL AND AFT.coupon_drug_id          IS NULL )
OR (BFR.cob_coupon_drug_id            IS NOT NULL AND AFT.cob_coupon_drug_id          IS NULL )
OR (BFR.coupon_ind            IS NOT NULL AND AFT.coupon_ind          IS NULL )
OR (BFR.cob_coupon_ind            IS NOT NULL AND AFT.cob_coupon_ind          IS NULL )
OR (BFR.other_coverage_cd            IS NOT NULL AND AFT.other_coverage_cd          IS NULL )
OR (BFR.cob_other_coverage_cd            IS NOT NULL AND AFT.cob_other_coverage_cd          IS NULL )
OR (BFR.partial_fil_intnded_qty            IS NOT NULL AND AFT.partial_fil_intnded_qty          IS NULL )
OR (BFR.triplicate_serial_nbr            IS NOT NULL AND AFT.triplicate_serial_nbr          IS NULL )
OR (BFR.delivery_ind            IS NOT NULL AND AFT.delivery_ind          IS NULL )
OR (BFR.delivery_comments            IS NOT NULL AND AFT.delivery_comments          IS NULL )
OR (BFR.sold_local_dttm            IS NOT NULL AND AFT.sold_local_dttm          IS NULL )
OR (BFR.pat_pickup_gov_auth_id            IS NOT NULL AND AFT.pat_pickup_gov_auth_id          IS NULL )
OR (BFR.pat_pickup_id_qlfr            IS NOT NULL AND AFT.pat_pickup_id_qlfr          IS NULL )
OR (BFR.pat_pickup_rel_cd            IS NOT NULL AND AFT.pat_pickup_rel_cd          IS NULL )
OR (BFR.routing_store_rph_inits            IS NOT NULL AND AFT.routing_store_rph_inits          IS NULL )
OR (BFR.source_system_name            IS NOT NULL AND AFT.source_system_name          IS NULL )
OR (BFR.source_sys_trans_id            IS NOT NULL AND AFT.source_sys_trans_id          IS NULL )
OR (BFR.sys_status_when_ent            IS NOT NULL AND AFT.sys_status_when_ent          IS NULL )
OR (BFR.additional_msg_qlfr_w1_cd           IS NOT NULL AND AFT.additional_msg_qlfr_w1_cd          IS NULL )  
OR (BFR.approved_msg_cd           IS NOT NULL AND AFT.approved_msg_cd          IS NULL )  
OR (BFR.cob_approved_msg_cd           IS NOT NULL AND AFT.cob_approved_msg_cd          IS NULL )  
OR (BFR.approved_msg_cd_2           IS NOT NULL AND AFT.approved_msg_cd_2          IS NULL )  
OR (BFR.cob_approved_msg_cd_2           IS NOT NULL AND AFT.cob_approved_msg_cd_2          IS NULL )  
OR (BFR.approved_msg_cd_3           IS NOT NULL AND AFT.approved_msg_cd_3          IS NULL )  
OR (BFR.cob_approved_msg_cd_3           IS NOT NULL AND AFT.cob_approved_msg_cd_3          IS NULL )  
OR (BFR.approved_msg_cd_4           IS NOT NULL AND AFT.approved_msg_cd_4          IS NULL )  
OR (BFR.cob_approved_msg_cd_4           IS NOT NULL AND AFT.cob_approved_msg_cd_4          IS NULL )  
OR (BFR.approved_msg_cd_5           IS NOT NULL AND AFT.approved_msg_cd_5          IS NULL )  
OR (BFR.cob_approved_msg_cd_5           IS NOT NULL AND AFT.cob_approved_msg_cd_5          IS NULL ) 
OR (BFR.gen_recip_nbr_returnd            IS NOT NULL AND AFT.gen_recip_nbr_returnd          IS NULL )
OR (BFR.ntwk_reimb_id_returnd            IS NOT NULL AND AFT.ntwk_reimb_id_returnd          IS NULL )
OR (BFR.plan_returnd_grp_nbr            IS NOT NULL AND AFT.plan_returnd_grp_nbr          IS NULL )
OR (BFR.plan_id_returnd            IS NOT NULL AND AFT.plan_id_returnd          IS NULL )
OR (BFR.general_pbr_nbr            IS NOT NULL AND AFT.general_pbr_nbr          IS NULL )
OR (BFR.cob_general_pbr_nbr            IS NOT NULL AND AFT.cob_general_pbr_nbr          IS NULL )
OR (BFR.general_rph_nbr_qlfr            IS NOT NULL AND AFT.general_rph_nbr_qlfr          IS NULL )
OR (BFR.prior_auth_cd            IS NOT NULL AND AFT.prior_auth_cd          IS NULL )
OR (BFR.prior_auth_nbr            IS NOT NULL AND AFT.prior_auth_nbr          IS NULL )
OR (BFR.additional_mfgr_coupon_w1_msg            IS NOT NULL AND AFT.additional_mfgr_coupon_w1_msg          IS NULL )
OR (BFR.wo_correlation_id 		IS NOT NULL   AND 	AFT.wo_correlation_id 	IS NULL )
OR (BFR.wo_rx_count		IS NOT NULL   AND 	AFT.wo_rx_count 		IS NULL )
OR (BFR.short_fill_ind 		IS NOT NULL    AND 	AFT.short_fill_ind 		IS NULL )
OR (BFR.db_cob_proc_ctrl_nbr 	IS NOT NULL   AND 	AFT.db_cob_proc_ctrl_nbr 	IS NULL )

));""")
  if (Action.errorCode != 0):
    return
  #--CALL PRDUTIL.TABLE_STATS('$pTDStageDB','ETL_OUTER_RX_TRANSACTION_STG');
  #if (Action.errorCode != 0):
  #  return
  return

if __name__ == '__main__':
  main()
  cleanup()
  done()

EOF

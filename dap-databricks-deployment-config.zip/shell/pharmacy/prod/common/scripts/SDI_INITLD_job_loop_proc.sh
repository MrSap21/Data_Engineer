#!/bin/sh
set -x

ENV=prod
APP_USER=edwphrm
APP_PASSWORD=phrmbt1101
DOMAIN=pa1sia-pfa001
DOMAIN_PORT=9080
SERVER=pa1sia-pfa001
SERVER_PORT=31542
DS_JOB1=EDW_SDI_INITLD_Fill_FillPlan_Extract_seq
DS_JOB2=EDW_GenExtr_030_fill_fkeys_rx_pat_patplan_pbr_seq
DS_JOB3=SDI_xform_daily_extract_seq_IL
DS_JOBINV=NOINVID
DS_PROJECT_PHRMRTN=edw_phrmrtn_prd
DS_PROJECT_PHRMACY=edw_pharmacy_prd
DS_CONNECT="$DOMAIN:$DOMAIN_PORT $SERVER:$SERVER_PORT"
CREDENTIAL_FILE=/usr/local/edw/pharmacy/${ENV}/common/config/sdi_ds_credentials.dat
touch $CREDENTIAL_FILE
print "$DOMAIN:$DOMAIN_PORT,$SERVER:$SERVER_PORT,$APP_USER,$APP_PASSWORD" > $CREDENTIAL_FILE
chmod 770 $CREDENTIAL_FILE


while read linevar
do
TIME_HR=`date +%k`

pEMAILADDR=edw-rx-batch\@walgreens.com
#pSUPPORTPHN=chirag.patel\@walgreens.com
pSUPPORTPHN=2246452684\@messaging.sprintpcs.com
pFILLENTERMIN=`print "$linevar" | cut -f1 -d"|"`
pFILLENTERMAX=`print "$linevar" | cut -f2 -d"|"`
pFILLENTERMAXnm=`print "$linevar" | cut -f2 -d"|" | tr -d "-"`
pEdwBatchId=${pFILLENTERMAXnm}115959
LOG_FILE=/usr/local/edw/pharmacy/${ENV}/audit/SDI_INITLD_${pFILLENTERMAXnm}.log
pLogFile=/usr/local/edw/pharmacy/${ENV}/audit/SDI_INITLD_${pFILLENTERMAXnm}.log
print "$pFILLENTERMIN | $pFILLENTERMAX" >> $LOG_FILE


if [ ! -f /usr/local/edw/pharmacy/${ENV}/audit/SDI_run_audit_${pFILLENTERMAXnm}.dat ]
then

print "#########################################################################################" >> $LOG_FILE
print "-----------------------------------------------------------------------------------------" >> $LOG_FILE
print "SEQ 1 - EXECUTING SDI INITLD FILL/FILL PLAN EXTRACT FOR WEEK ENDING $pFILLENTERMAX"        >> $LOG_FILE
print "-----------------------------------------------------------------------------------------" >> $LOG_FILE
print "#########################################################################################" >> $LOG_FILE

PARMLIST1="-param \$APT_CONFIG_FILE=/usr/local/edw/pharmacy/${ENV}/common/apt/edw_phrm_config_4x4.apt -param pEdwBatchId=$pEdwBatchId -param pLogFile=$pLogFile -param pFillEnterDtMin=$pFILLENTERMIN -param pFillEnterDtMax=$pFILLENTERMAX"

dsjob -file $CREDENTIAL_FILE $DS_CONNECT \
        -run -wait -jobstatus \
        $PARMLIST1 \
        $DS_PROJECT_PHRMRTN $DS_JOB1.$DS_JOBINV \
        >> $LOG_FILE 2>> $ERR_FILE
RC=$?
if [ $RC -ne 1 ] &&  [ $RC -ne 2 ]
then
  echo "SDI FILL/FILL PLAN GENEXTR FAILURE" >> $LOG_FILE
  echo "SDI FILL/FILL PLAN GENEXTR FAILURE AT $pFILLENTERMAX" | mail -s "SDI FILL/FILL PLAN GENEXTR FAILURE AT $pFILLENTERMAX" $pEMAILADDR,$pSUPPORTPHN
  exit 1
else
  echo "SDI FILL/FILL PLAN GENEXTR SUCCESS" >> $LOG_FILE
fi


print "#########################################################################################" >> $LOG_FILE
print "-----------------------------------------------------------------------------------------" >> $LOG_FILE
print "SEQ 2 - EXECUTING DIMENSION EXTRACTS 030 FOR WEEK ENDING $pFILLENTERMAX"                   >> $LOG_FILE
print "-----------------------------------------------------------------------------------------" >> $LOG_FILE
print "#########################################################################################" >> $LOG_FILE

PARMLIST2="-param \$APT_CONFIG_FILE=/usr/local/edw/pharmacy/${ENV}/common/apt/edw_phrm_config_4x4.apt -param pEdwBatchId=$pEdwBatchId -param pLogFile=$pLogFile"

dsjob -file $CREDENTIAL_FILE $DS_CONNECT \
        -run -wait -jobstatus \
        $PARMLIST2 \
        $DS_PROJECT_PHRMRTN $DS_JOB2.$DS_JOBINV \
        >> $LOG_FILE 2>> $ERR_FILE
RC=$?
if [ $RC -ne 1 ] &&  [ $RC -ne 2 ]
then
  echo "GENEXTR 030 FAILURE" >> $LOG_FILE
  echo "GENEXTR 030 FAILURE AT $pFILLENTERMAX" | mail -s "GENEXTR 030 FAILURE AT $pFILLENTERMAX" $pEMAILADDR,$pSUPPORTPHN
  exit 1
else
  echo "GENEXTR 030 SUCCESS" >> $LOG_FILE
fi


print "#########################################################################################" >> $LOG_FILE
print "-----------------------------------------------------------------------------------------" >> $LOG_FILE
print "SEQ 3 - EXECUTING SDI XFORM FOR WEEK ENDING $pFILLENTERMAX"                                >> $LOG_FILE
print "-----------------------------------------------------------------------------------------" >> $LOG_FILE
print "#########################################################################################" >> $LOG_FILE

PARMLIST3="-param \$APT_CONFIG_FILE=/usr/local/edw/pharmacy/${ENV}/common/apt/edw_phrm_config_4x4.apt -param pEdwBatchId=$pEdwBatchId -param pLogFile=$pLogFile -param pFillEnterDtMax=$pFILLENTERMAX"

dsjob -file $CREDENTIAL_FILE $DS_CONNECT \
        -run -wait -jobstatus \
        $PARMLIST3 \
        $DS_PROJECT_PHRMACY $DS_JOB3.$DS_JOBINV \
        >> $LOG_FILE 2>> $ERR_FILE
RC=$?
if [ $RC -ne 1 ] &&  [ $RC -ne 2 ]
then
  echo "SDI XFORM FAILURE" >> $LOG_FILE
  echo "SDI XFORM FAILURE AT $pFILLENTERMAX" | mail -s "SDI XFORM FAILURE AT $pFILLENTERMAX" $pEMAILADDR,$pSUPPORTPHN
  exit 1
else
  echo "SDI XFORM SUCCESS" >> $LOG_FILE
  echo "SDI FILES FOR WEEK ENDING $pFILLENTERMAX PROCESSED SUCCESSFULLY" | mail -s "SDI FILES FOR WEEK ENDING $pFILLENTERMAX PROCESSED SUCCESSFULLY" $pEMAILADDR
  touch /usr/local/edw/pharmacy/${ENV}/audit/SDI_run_audit_${pFILLENTERMAXnm}.dat
  echo date >> /usr/local/edw/pharmacy/${ENV}/audit/SDI_run_audit_${pFILLENTERMAXnm}.dat
fi


print "#########################################################################################" >> $LOG_FILE
print "-----------------------------------------------------------------------------------------" >> $LOG_FILE
print "ALL SDI JOBS FOR WEEK ENDING $pFILLENTERMAX COMPLETED SUCCESSFULLY-CONTINUE TO NEXT WEEK " >> $LOG_FILE
print "-----------------------------------------------------------------------------------------" >> $LOG_FILE
print "#########################################################################################" >> $LOG_FILE

else
  echo "SKIPPING FILL_ENTER_DT_MIN=$pFILLENTERMIN | FILL_ENTER_DT_MAX=$pFILLENTERMAX - ALREADY PROCESSED" >> $LOG_FILE
fi

done < SDI_INITLD_fill_enter_dts_loop.dat

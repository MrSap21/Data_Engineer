#!/bin/sh

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
APT_TERA_SYNC_DATABASE=$6

python3 <<ZZ
#!/usr/bin/python3

#import os
#import sys

#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():

  #/* PERFORM STORE RELO UPDATES FOR TARGET TABLES */
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_dur_interaction

set str_nbr = R.relocate_to_str_nbr
from $pTDDBName.location_store_relocation R
where $pTDDBName.prescription_dur_interaction.str_nbr =
R.relocate_fm_str_nbr
and R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* PERFORM STORE RELO UPDATES FOR DEDUP TABLES */
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_dur_history

set store_nbr = R.relocate_to_str_nbr
from $pTDDBName.location_store_relocation R
where $pTDStageDB.etl_proc_dup_dur_history.store_nbr =
R.relocate_fm_str_nbr
and R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* REMOVE PK UPDATES FOR STORE RELOS IN STAGE TABLES */
  executeSql([], [
    ("""delete from
$pTDStageDB.etl_tbf0_dur_history
where
( cdc_txn_commit_dttm,
cdc_seq_nbr,
cdc_rba_nbr )
IN
(select bfr.cdc_txn_commit_dttm,
bfr.cdc_seq_nbr,
bfr.cdc_rba_nbr
from $pTDStageDB.etl_tbf0_dur_history BFR,
$pTDStageDB.etl_tbf0_dur_history AFT,
$pTDDBName.location_store_relocation SR
where BFR.cdc_txn_commit_dttm = AFT.cdc_txn_commit_dttm
and BFR.cdc_seq_nbr = AFT.cdc_seq_nbr
and BFR.cdc_rba_nbr = AFT.cdc_rba_nbr

and SR.relocate_fm_str_nbr = BFR.store_nbr
and SR.relocate_to_str_nbr = AFT.store_nbr

and BFR.cdc_before_after_cd = 'BEFORE'
and AFT.cdc_before_after_cd = 'AFTER'
and BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
and AFT.cdc_operation_type_cd = 'PK UPDATE'

and BFR.store_nbr <> AFT.store_nbr
and BFR.rx_nbr = AFT.rx_nbr
and BFR.fill_nbr = AFT.fill_nbr
and BFR.fill_partial_nbr = AFT.fill_partial_nbr
and BFR.dur_interaction_nbr = AFT.dur_interaction_nbr
);""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* UPDATE STORE NUMBERS FOR STORE RELOS IN STAGE TABLES */
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_tbf0_dur_history

set store_nbr = SR.relocate_to_str_nbr
from $pTDDBName.location_store_relocation SR
where store_nbr = SR.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* DEDUP STARTS FROM HERE */
  #-----------------------------------------------------------------------
  #/* delete Test Stores if any */
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_dur_history
where store_nbr in
(select store_nbr from $pTDStageDB.etl_proc_test_store);""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #-------------------------------------------------------------------------------------
  executeSql([], [
    ("""DELETE FROM $APT_TERA_SYNC_DATABASE.ETL_TBF0_DUR_INTER_CHG_ANLYS;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $APT_TERA_SYNC_DATABASE.ETL_TBF0_DUR_INTER_CHG_ANLYS
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,dur_interaction_nbr           
,dur_type_cd                   
,dur_severity_cd               
,dur_overridden_ind            
,dur_comment                   
,dur_override_dttm             
,dur_comment_cd                
,dur_intervention_cd           
,dur_outcome_cd                
,src_partition_nbr             
,DUR_SOURCE_CD                 
,DUR_OVERRIDE_USER_ID          
,relocate_fm_str_nbr           
)
SELECT 
STG.cdc_txn_commit_dttm           
,STG.cdc_seq_nbr                   
,STG.cdc_rba_nbr                   
,STG.cdc_operation_type_cd         
,STG.cdc_before_after_cd           
,STG.cdc_txn_position_cd           
,STG.edw_batch_id                  
,STG.store_nbr                     
,STG.rx_nbr                        
,STG.fill_nbr                      
,STG.fill_partial_nbr              
,STG.dur_interaction_nbr           
,STG.dur_type_cd                   
,STG.dur_severity_cd               
,STG.dur_overridden_ind            
,STG.dur_comment                   
,STG.dur_override_dttm             
,STG.dur_comment_cd                
,STG.dur_intervention_cd           
,STG.dur_outcome_cd                
,STG.src_partition_nbr             
,STG.DUR_SOURCE_CD                 
,STG.DUR_OVERRIDE_USER_ID          
,STG.relocate_fm_str_nbr           
FROM
(
SELECT rx_nbr,store_nbr, fill_nbr, fill_partial_nbr,dur_interaction_nbr, max(cdc_txn_commit_dttm) max_cdc_dttm
FROM $pTDStageDB.etl_tbf0_dur_history
WHERE cdc_operation_type_cd='INSERT'
GROUP BY 1,2,3,4,5) MX_INS,
$pTDStageDB.etl_tbf0_dur_history STG
WHERE STG.STORE_NBR=MX_INS.STORE_NBR
AND STG.RX_NBR=MX_INS.RX_NBR
AND STG.FILL_NBR=MX_INS.FILL_NBR
AND STG.FILL_PARTIAL_NBR=MX_INS.FILL_PARTIAL_NBR
AND STG.DUR_INTERACTION_NBR=MX_INS.DUR_INTERACTION_NBR
AND STG.CDC_TXN_COMMIT_DTTM < MX_INS.max_CDC_DTTM;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_dur_history STG 
using $APT_TERA_SYNC_DATABASE.ETL_TBF0_DUR_INTER_CHG_ANLYS PROC 
WHERE STG.STORE_NBR=PROC.STORE_NBR
AND STG.RX_NBR=PROC.RX_NBR
AND STG.fill_nbr=PROC.fill_nbr
AND STG.fill_partial_nbr=PROC.fill_partial_nbr
AND STG.dur_interaction_nbr= PROC.dur_interaction_nbr
AND STG.CDC_TXN_COMMIT_DTTM = PROC.CDC_TXN_COMMIT_DTTM
AND STG.CDC_RBA_NBR = PROC.CDC_RBA_NBR
AND STG.CDC_BEFORE_AFTER_CD = PROC.CDC_BEFORE_AFTER_CD
AND STG.CDC_OPERATION_TYPE_CD = PROC.CDC_OPERATION_TYPE_CD
AND STG.CDC_TXN_POSITION_CD = PROC.CDC_TXN_POSITION_CD;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #-----------------------------------------------------------------------------
  #/* remove rx_dupes from etl stage table */
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_dur_history
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,dur_interaction_nbr           
,dur_type_cd                   
,dur_severity_cd               
,dur_overridden_ind            
,dur_comment                   
,dur_override_dttm             
,dur_comment_cd                
,dur_intervention_cd           
,dur_outcome_cd                
,src_partition_nbr             
,DUR_SOURCE_CD                 
,DUR_OVERRIDE_USER_ID          
,relocate_fm_str_nbr           
)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,dur_interaction_nbr           
,dur_type_cd                   
,dur_severity_cd               
,dur_overridden_ind            
,dur_comment                   
,dur_override_dttm             
,dur_comment_cd                
,dur_intervention_cd           
,dur_outcome_cd                
,src_partition_nbr             
,DUR_SOURCE_CD                 
,DUR_OVERRIDE_USER_ID          
,relocate_fm_str_nbr           
from $pTDStageDB.etl_tbf0_dur_history
where
(store_nbr,rx_nbr)
in
(select store_nbr, rx_nbr From $pTDStageDB.etl_proc_dup_rx group by 1,2);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete
from $pTDStageDB.etl_tbf0_dur_history
where
(store_nbr,rx_nbr)
in
(select store_nbr, rx_nbr From $pTDStageDB.etl_proc_dup_rx group by 1,2);
-- DEL_STATEMENT - Replace DEL with DELETE
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------------------------------------
  #/* remove dupes from Trans Dupes table */
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_dur_history
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,dur_interaction_nbr           
,dur_type_cd                   
,dur_severity_cd               
,dur_overridden_ind            
,dur_comment                   
,dur_override_dttm             
,dur_comment_cd                
,dur_intervention_cd           
,dur_outcome_cd                
,src_partition_nbr             
,DUR_SOURCE_CD                 
,DUR_OVERRIDE_USER_ID          
,relocate_fm_str_nbr           
)
select 
ETL.cdc_txn_commit_dttm           
,ETL.cdc_seq_nbr                   
,ETL.cdc_rba_nbr                   
,ETL.cdc_operation_type_cd         
,ETL.cdc_before_after_cd           
,ETL.cdc_txn_position_cd           
,ETL.edw_batch_id                  
,ETL.store_nbr                     
,ETL.rx_nbr                        
,ETL.fill_nbr                      
,ETL.fill_partial_nbr              
,ETL.dur_interaction_nbr           
,ETL.dur_type_cd                   
,ETL.dur_severity_cd               
,ETL.dur_overridden_ind            
,ETL.dur_comment                   
,ETL.dur_override_dttm             
,ETL.dur_comment_cd                
,ETL.dur_intervention_cd           
,ETL.dur_outcome_cd                
,ETL.src_partition_nbr             
,ETL.DUR_SOURCE_CD                 
,ETL.DUR_OVERRIDE_USER_ID          
,ETL.relocate_fm_str_nbr           
from $pTDStageDB.etl_tbf0_dur_history ETL,
$pTDStageDB.etl_proc_dup_rx_tran DUP
where ETL.store_nbr = DUP.store_nbr
and ETL.rx_nbr = DUP.rx_nbr
and ETL.fill_nbr= DUP.fill_nbr
and ETL.fill_partial_nbr= DUP.fill_partial_nbr;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_dur_history ETL 
using $pTDStageDB.etl_proc_dup_rx_tran DUP 
where ETL.store_nbr = DUP.store_nbr
and ETL.rx_nbr = DUP.rx_nbr
and ETL.fill_nbr= DUP.fill_nbr
and ETL.fill_partial_nbr= DUP.fill_partial_nbr;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------------------------------------
  #/* remove dupes from Fill Dupes table */
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_dur_history
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,dur_interaction_nbr           
,dur_type_cd                   
,dur_severity_cd               
,dur_overridden_ind            
,dur_comment                   
,dur_override_dttm             
,dur_comment_cd                
,dur_intervention_cd           
,dur_outcome_cd                
,src_partition_nbr             
,DUR_SOURCE_CD                 
,DUR_OVERRIDE_USER_ID          
,relocate_fm_str_nbr           
)
select 
ETL.cdc_txn_commit_dttm           
,ETL.cdc_seq_nbr                   
,ETL.cdc_rba_nbr                   
,ETL.cdc_operation_type_cd         
,ETL.cdc_before_after_cd           
,ETL.cdc_txn_position_cd           
,ETL.edw_batch_id                  
,ETL.store_nbr                     
,ETL.rx_nbr                        
,ETL.fill_nbr                      
,ETL.fill_partial_nbr              
,ETL.dur_interaction_nbr           
,ETL.dur_type_cd                   
,ETL.dur_severity_cd               
,ETL.dur_overridden_ind            
,ETL.dur_comment                   
,ETL.dur_override_dttm             
,ETL.dur_comment_cd                
,ETL.dur_intervention_cd           
,ETL.dur_outcome_cd                
,ETL.src_partition_nbr             
,ETL.DUR_SOURCE_CD                 
,ETL.DUR_OVERRIDE_USER_ID          
,ETL.relocate_fm_str_nbr           
from $pTDStageDB.etl_tbf0_dur_history ETL,
$pTDStageDB.etl_proc_dup_fill DUP
where ETL.store_nbr = DUP.store_nbr
and ETL.rx_nbr = DUP.rx_nbr
and ETL.fill_nbr= DUP.fill_nbr
and ETL.fill_partial_nbr= DUP.fill_partial_nbr;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_dur_history ETL 
using $pTDStageDB.etl_proc_dup_fill DUP 
where ETL.store_nbr = DUP.store_nbr
and ETL.rx_nbr = DUP.rx_nbr
and ETL.fill_nbr= DUP.fill_nbr
and ETL.fill_partial_nbr= DUP.fill_partial_nbr;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #----------------------------------------------------------------------------------------------------------------------------------
  #/* remove dupes from dup_rx_cntrl_sub */
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_dur_history
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,dur_interaction_nbr           
,dur_type_cd                   
,dur_severity_cd               
,dur_overridden_ind            
,dur_comment                   
,dur_override_dttm             
,dur_comment_cd                
,dur_intervention_cd           
,dur_outcome_cd                
,src_partition_nbr             
,DUR_SOURCE_CD                 
,DUR_OVERRIDE_USER_ID          
,relocate_fm_str_nbr           
)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,dur_interaction_nbr           
,dur_type_cd                   
,dur_severity_cd               
,dur_overridden_ind            
,dur_comment                   
,dur_override_dttm             
,dur_comment_cd                
,dur_intervention_cd           
,dur_outcome_cd                
,src_partition_nbr             
,DUR_SOURCE_CD                 
,DUR_OVERRIDE_USER_ID          
,relocate_fm_str_nbr           
from
$pTDStageDB.etl_tbf0_dur_history
where
(store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,dur_interaction_nbr )
in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,dur_interaction_nbr
From $pTDStageDB.etl_proc_dup_dur_history group by 1,2,3,4,5);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete
from $pTDStageDB.etl_tbf0_dur_history
where
( store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,dur_interaction_nbr )
in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,dur_interaction_nbr
From $pTDStageDB.etl_proc_dup_dur_history group by 1,2,3,4,5);
-- DEL_STATEMENT - Replace DEL with DELETE
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* PERFORM UPDATES FOR CHANGES TO RX CREATE DT IN TARGET TABLES   */
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_dur_interaction dur
    
set    rx_create_dt = STG.to_create_dt
 FROM    (Select str_nbr ,rx_nbr ,cast(frm_create_dttm as date) frm_create_dt, cast(to_create_dttm as date) to_create_dt, change_prcs_ind
                FROM    $pTDStageDB.rx_create_dttm_change
WHERE frm_create_dt <> to_create_dt
        
        GROUP BY 1,2,3,4,5
        
        )  STG
 where  dur.str_nbr = STG.str_nbr
  AND dur.rx_nbr = STG.rx_nbr
  AND dur.rx_create_dt =  STG.frm_create_dt
  AND dur.rx_create_dt IS NOT NULL
  AND STG.change_prcs_ind = 'N';
-- SEL_BODY_CLAUSES_ORDER - change the order of all the clauses of a select statement
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  return

if __name__ == '__main__':
  main()
  cleanup()
  done()

ZZ
#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
pTDServer=$1
pTDUserid=$2
pTDPassword=$3
DP_DB_PHARMACY_HEALTHCARE=$4
DP_DB_STAGING=$5 
DP_DB_MASTER_DATA=$6
pTargetTableParam=$7


python3 <<ZZ
#import os
#import sys

#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():

  #/*================================================================**
#** PERFORM STORE RELO UPDATES FOR TARGET TABLES                   **
#**================================================================*/
  executeSql([], [
    ("""update  $DP_DB_PHARMACY_HEALTHCARE.$pTargetTableParam
 from   $DP_DB_MASTER_DATA.LOCATION.location_store_relocation  R
 set    str_nbr = R.relocate_to_str_nbr
 where  str_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
#/*================================================================**
#** PERFORM UPDATES FOR CHANGES TO RX CREATE DT IN TARGET TABLES   **
#**================================================================*/
  executeSql([], [
    ("""update $DP_DB_PHARMACY_HEALTHCARE.$pTargetTableParam Fill
    set    Fill.rx_create_dt = STG.to_create_dt
    from (Select str_nbr ,rx_nbr ,cast(frm_create_dttm as date) frm_create_dt, cast(to_create_dttm as date) to_create_dt, change_prcs_ind
                FROM    $DP_DB_STAGING.patient_services.rx_create_dttm_change_STG
        WHERE frm_create_dt <> to_create_dt
        GROUP BY 1,2,3,4,5
        )  STG
 where  Fill.str_nbr = STG.str_nbr
  AND Fill.rx_nbr = STG.rx_nbr
  AND Fill.rx_create_dt =  STG.frm_create_dt
  AND Fill.rx_create_dt IS NOT NULL
  AND STG.change_prcs_ind = 'N'""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
#/*================================================================**
#** DELETE PREVIOUS DAY'S DATA FROM THE PERFORMANCE TABLE   **
#**================================================================*/
  executeSql([], [
    ("DELETE FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG",
    [])
  ])
  if (Action.errorCode != 0):
    return
#/*================================================================**
#**  INSERT DATA INTO THE PERFORMANCE TABLE - FROM THE TARGET FOR KEYS PRESENT IN ETL STAGE   **
#**  TRANS & FILL KEYS BOTH USING A UNION CLAUSE
#**================================================================*/
  executeSql([], [
    ("""INSERT INTO $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG
(rx_nbr                        
,str_nbr                       
,rx_create_dt                  
,rx_fill_nbr                   
,rx_partial_fill_nbr           
,third_party_plan_id           
,cob_ind                       
,fill_enter_dt                 
,fill_enter_tm                 
,reject_nbr                    
,fill_sold_dt                  
,dl_reject_cd                  
,create_user_id                
,edw_batch_id                  
,relocate_fm_str_nbr           
,update_user_id                
,update_dttm                   
,src_partition_nbr
,edw_src_ind
)
SELECT
TFPREJ.rx_nbr                        
,TFPREJ.str_nbr                       
,TFPREJ.rx_create_dt                  
,TFPREJ.rx_fill_nbr                   
,TFPREJ.rx_partial_fill_nbr           
,TFPREJ.third_party_plan_id           
,TFPREJ.cob_ind                       
,TFPREJ.fill_enter_dt                 
,TFPREJ.fill_enter_tm                 
,TFPREJ.reject_nbr                    
,TFPREJ.fill_sold_dt                  
,TFPREJ.dl_reject_cd                  
,TFPREJ.create_user_id                
,TFPREJ.edw_batch_id                  
,TFPREJ.relocate_fm_str_nbr           
,TFPREJ.update_user_id                
,TFPREJ.update_dttm                   
,TFPREJ.src_partition_nbr
,TFPREJ.edw_src_ind
FROM    $DP_DB_PHARMACY_HEALTHCARE.$pTargetTableParam TFPREJ,
                  (SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTERED_DTTM
                     FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG
                     WHERE CDC_OPERATION_TYPE_CD IN ('PK UPDATE','SQL COMPUPDATE')
                     GROUP BY RX_NBR, STORE_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTERED_DTTM
                     MINUS
                     SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTERED_DTTM
                                 FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG
                                 WHERE CDC_OPERATION_TYPE_CD='INSERT') TRANS
WHERE TFPREJ.RX_NBR = TRANS.RX_NBR
AND     TFPREJ.STR_NBR = TRANS.STORE_NBR
AND     TFPREJ.RX_FILL_NBR = TRANS.FILL_NBR
AND     TFPREJ.RX_PARTIAL_FILL_NBR = TRANS.FILL_PARTIAL_NBR
AND     TFPREJ.FILL_ENTER_DT = CAST ( TRANS.FILL_ENTERED_DTTM AS DATE )
AND     TFPREJ.FILL_ENTER_TM = CAST ( TRANS.FILL_ENTERED_DTTM AS TIME(0))
UNION
SELECT
TFPREJ.rx_nbr                        
,TFPREJ.str_nbr                       
,TFPREJ.rx_create_dt                  
,TFPREJ.rx_fill_nbr                   
,TFPREJ.rx_partial_fill_nbr           
,TFPREJ.third_party_plan_id           
,TFPREJ.cob_ind                       
,TFPREJ.fill_enter_dt                 
,TFPREJ.fill_enter_tm                 
,TFPREJ.reject_nbr                    
,TFPREJ.fill_sold_dt                  
,TFPREJ.dl_reject_cd                  
,TFPREJ.create_user_id                
,TFPREJ.edw_batch_id                  
,TFPREJ.relocate_fm_str_nbr           
,TFPREJ.update_user_id                
,TFPREJ.update_dttm                   
,TFPREJ.src_partition_nbr
,TFPREJ.edw_src_ind
FROM    $DP_DB_PHARMACY_HEALTHCARE.$pTargetTableParam TFPREJ,
                  (SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTER_DTTM
                     FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG
                     WHERE CDC_OPERATION_TYPE_CD IN ('PK UPDATE','SQL COMPUPDATE')
                     GROUP BY RX_NBR, STORE_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM
                     MINUS
                     SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTER_DTTM
                                 FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG
                                 WHERE CDC_OPERATION_TYPE_CD='INSERT') FILL
WHERE TFPREJ.RX_NBR = FILL.RX_NBR
AND     TFPREJ.STR_NBR = FILL.STORE_NBR
AND     TFPREJ.RX_FILL_NBR = FILL.FILL_NBR
AND     TFPREJ.RX_PARTIAL_FILL_NBR = FILL.FILL_PARTIAL_NBR
AND     TFPREJ.FILL_ENTER_DT = CAST ( FILL.FILL_ENTER_DTTM AS DATE )
AND     TFPREJ.FILL_ENTER_TM = CAST ( FILL.FILL_ENTER_DTTM AS TIME(0))""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("CALL PRDUTIL.TABLE_STATS('$DP_DB_STAGING', 'patient_services.ETL_PROC_FP_REJECT_STG' )",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  #/*================================================================**
#** DELETE PREVIOUS DAY'S DATA FROM THE PERFORMANCE TABLE   **
#**================================================================*/
  executeSql([], [
    ("DELETE FROM $DP_DB_STAGING.patient_services.ETL_PROC_ENDATED_FP_REJECT_STG",
    [])
  ])
  if (Action.errorCode != 0):
    return
  #/*================================================================**
#** INSERT INTO THE END-DATED TABLE FROM TRANS   **
#** THIS CHECKS FOR UPDATES/INSERTS FOR THE 5 CODES FROM TRANS ETL STAGE **
#** IT WOULD SORT THE DATA BASED ON THE CDC FIELDS **
#** THIS WOULD LEFT OUTER JOIN TO THE patient_services.etl_proc_trans_presc_STG TO GET THE RX CREATE DATE **
#** THIS IS A COMBINATION OF THE BASE + SORTED + ENDATED VIEWS **
#**================================================================*/
  executeSql([], [
    ("""INSERT INTO $DP_DB_STAGING.patient_services.ETL_PROC_ENDATED_FP_REJECT_STG
(	  rx_nbr 
	, str_nbr 
	, rx_create_dt 
	, rx_fill_nbr 
	, rx_partial_fill_nbr 
	, third_party_plan_id 
	, cob_ind 
	, fill_enter_dt
	, fill_enter_tm
	, reject_nbr
	, fill_sold_dt 
	, dl_reject_cd
	, create_user_id 
	, edw_batch_id 
	, relocate_fm_str_nbr 
	, update_user_id 
	, update_dttm 
	, src_partition_nbr 
	, edw_dml_ind
	,edw_rank
	,cdc_txn_commit_dttm
	,cdc_seq_nbr
	,cdc_rba_nbr
	,edw_src_ind
)	
SELECT	 
	  A.rx_nbr 
	, A.str_nbr 
	, P.rx_create_dt 
	, A.rx_fill_nbr 
	, A.rx_partial_fill_nbr 
	, A.third_party_plan_id 
	, A.cob_ind 
	, A.fill_enter_dt
	, A.fill_enter_tm
	, A.reject_nbr
	, A.fill_sold_dt 
	, A.dl_reject_cd
	, A.create_user_id 
	, A.edw_batch_id 
	, A.relocate_fm_str_nbr 
	, A.update_user_id 
	, A.update_dttm 
	, A.src_partition_nbr 
	, A.edw_dml_ind
	, RANK() OVER (PARTITION BY 	A.rx_nbr, A.str_nbr, A.rx_fill_nbr , A.rx_partial_fill_nbr, A.cob_ind , A.fill_enter_dt, A.fill_enter_tm, A.reject_nbr 	 
ORDER	 BY  A.cdc_txn_commit_dttm , A.cdc_seq_nbr,A.cdc_rba_nbr ) edw_rank 
	,A.cdc_txn_commit_dttm
	,A.cdc_seq_nbr
	,A.cdc_rba_nbr
    ,A.edw_src_ind
FROM	
(
SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 1 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_01 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.DL_REJECT_CD_01 <> BFR.DL_REJECT_CD_01
OR AFT.DL_REJECT_CD_01 IS NULL AND BFR.DL_REJECT_CD_01 IS NOT NULL
OR AFT.DL_REJECT_CD_01 IS NOT NULL AND BFR.DL_REJECT_CD_01 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL)
	)

UNION

SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 2 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_02 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.DL_REJECT_CD_02 <> BFR.DL_REJECT_CD_02
OR AFT.DL_REJECT_CD_02 IS NULL AND BFR.DL_REJECT_CD_02 IS NOT NULL
OR AFT.DL_REJECT_CD_02 IS NOT NULL AND BFR.DL_REJECT_CD_02 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL)
	)
UNION

SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 3 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_03 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.DL_REJECT_CD_03 <> BFR.DL_REJECT_CD_03
OR AFT.DL_REJECT_CD_03 IS NULL AND BFR.DL_REJECT_CD_03 IS NOT NULL
OR AFT.DL_REJECT_CD_03 IS NOT NULL AND BFR.DL_REJECT_CD_03 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL)
	)
UNION

SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR (AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 4 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_04 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.DL_REJECT_CD_04 <> BFR.DL_REJECT_CD_04
OR AFT.DL_REJECT_CD_04 IS NULL AND BFR.DL_REJECT_CD_04 IS NOT NULL
OR AFT.DL_REJECT_CD_04 IS NOT NULL AND BFR.DL_REJECT_CD_04 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL)
	)
	
UNION

SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 5 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_05 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.DL_REJECT_CD_05 <> BFR.DL_REJECT_CD_05
OR AFT.DL_REJECT_CD_05 IS NULL AND BFR.DL_REJECT_CD_05 IS NOT NULL
OR AFT.DL_REJECT_CD_05 IS NOT NULL AND BFR.DL_REJECT_CD_05 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL)
	)
	
	
UNION	
	
SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 1 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_01 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.COB_DL_REJECT_CD_01 <> BFR.COB_DL_REJECT_CD_01
OR AFT.COB_DL_REJECT_CD_01 IS NULL AND BFR.COB_DL_REJECT_CD_01 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_01 IS NOT NULL AND BFR.COB_DL_REJECT_CD_01 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
	)

UNION

SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 2 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_02 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.COB_DL_REJECT_CD_02 <> BFR.COB_DL_REJECT_CD_02
OR AFT.COB_DL_REJECT_CD_02 IS NULL AND BFR.COB_DL_REJECT_CD_02 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_02 IS NOT NULL AND BFR.COB_DL_REJECT_CD_02 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
	)
UNION

SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 3 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_03 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.COB_DL_REJECT_CD_03 <> BFR.COB_DL_REJECT_CD_03
OR AFT.COB_DL_REJECT_CD_03 IS NULL AND BFR.COB_DL_REJECT_CD_03 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_03 IS NOT NULL AND BFR.COB_DL_REJECT_CD_03 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
	)
UNION

SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 4 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_04 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.COB_DL_REJECT_CD_04 <> BFR.COB_DL_REJECT_CD_04
OR AFT.COB_DL_REJECT_CD_04 IS NULL AND BFR.COB_DL_REJECT_CD_04 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_04 IS NOT NULL AND BFR.COB_DL_REJECT_CD_04 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
	)
	
UNION

SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 5 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_05 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.COB_DL_REJECT_CD_05 <> BFR.COB_DL_REJECT_CD_05
OR AFT.COB_DL_REJECT_CD_05 IS NULL AND BFR.COB_DL_REJECT_CD_05 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_05 IS NOT NULL AND BFR.COB_DL_REJECT_CD_05 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
	)
	
UNION
	
SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 1 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_01 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.DL_REJECT_CD_01 IS NOT NULL OR AFT.DL_REJECT_CD_01 <> '' )

UNION

SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 2 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_02 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.DL_REJECT_CD_02 IS NOT NULL OR AFT.DL_REJECT_CD_02 <> '' )

UNION

SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 3 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_03 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.DL_REJECT_CD_03 IS NOT NULL OR AFT.DL_REJECT_CD_03 <> '' )

UNION

SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 4 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_04 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.DL_REJECT_CD_04 IS NOT NULL OR AFT.DL_REJECT_CD_04 <> '' )
	
UNION

SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 5 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_05 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.DL_REJECT_CD_05 IS NOT NULL OR AFT.DL_REJECT_CD_05 <> '' )
	
UNION	
	
SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 1 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_01 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_01 IS NOT NULL OR AFT.COB_DL_REJECT_CD_01 <> '' )


UNION

SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 2 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_02 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_02 IS NOT NULL OR AFT.COB_DL_REJECT_CD_02 <> '' )

UNION

SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 3 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_03 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_03 IS NOT NULL OR AFT.COB_DL_REJECT_CD_03 <> '' )

UNION

SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 4 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_04 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_04 IS NOT NULL OR AFT.COB_DL_REJECT_CD_04 <> '' )

	
UNION

SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_entered_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_entered_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 5 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_05 AS CHAR(3)) dl_reject_cd
, CAST ( AFT.create_user_id   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'T' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_05 IS NOT NULL OR AFT.COB_DL_REJECT_CD_05 <> '' )

UNION

SELECT
'U'
,T.rx_nbr                        
,T.str_nbr                       
,T.rx_create_dt                  
,T.rx_fill_nbr                   
,T.rx_partial_fill_nbr           
,T.third_party_plan_id           
,T.cob_ind                       
,T.fill_enter_dt                 
,T.fill_enter_tm                 
,T.reject_nbr                    
,T.fill_sold_dt                  
,T.dl_reject_cd                  
,T.create_user_id                
,T.edw_batch_id                  
,T.relocate_fm_str_nbr           
,T.update_user_id                
,T.update_dttm                   
,T.src_partition_nbr    
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr 
,T.edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr 
AND  T.rx_fill_nbr = BFR.fill_nbr 
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr 
AND T.fill_enter_dt = CAST ( BFR.fill_entered_dttm AS DATE )  
AND T.fill_enter_tm = CAST(BFR.fill_entered_dttm AS TIME(0)) 
AND T.reject_nbr=1
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr 
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 

WHERE 
( 
	( T.cob_ind='N' AND 
((AFT.DL_REJECT_CD_01 <> BFR.DL_REJECT_CD_01
OR AFT.DL_REJECT_CD_01 IS NULL AND BFR.DL_REJECT_CD_01 IS NOT NULL
OR AFT.DL_REJECT_CD_01 IS NOT NULL AND BFR.DL_REJECT_CD_01 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL))
	)
OR ( T.cob_ind='Y' AND 
((AFT.COB_DL_REJECT_CD_01 <> BFR.COB_DL_REJECT_CD_01
OR AFT.COB_DL_REJECT_CD_01 IS NULL AND BFR.COB_DL_REJECT_CD_01 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_01 IS NOT NULL AND BFR.COB_DL_REJECT_CD_01 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
	) 
)

UNION

SELECT
'U'
,T.rx_nbr                        
,T.str_nbr                       
,T.rx_create_dt                  
,T.rx_fill_nbr                   
,T.rx_partial_fill_nbr           
,T.third_party_plan_id           
,T.cob_ind                       
,T.fill_enter_dt                 
,T.fill_enter_tm                 
,T.reject_nbr                    
,T.fill_sold_dt                  
,T.dl_reject_cd                  
,T.create_user_id                
,T.edw_batch_id                  
,T.relocate_fm_str_nbr           
,T.update_user_id                
,T.update_dttm                   
,T.src_partition_nbr    
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr 
,T.edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr 
AND  T.rx_fill_nbr = BFR.fill_nbr 
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr 
AND T.fill_enter_dt = CAST ( BFR.fill_entered_dttm AS DATE )  
AND T.fill_enter_tm = CAST(BFR.fill_entered_dttm AS TIME(0)) 
AND T.reject_nbr=2
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr 
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 

WHERE 
( 
	( T.cob_ind='N' AND 
((AFT.DL_REJECT_CD_02 <> BFR.DL_REJECT_CD_02
OR AFT.DL_REJECT_CD_02 IS NULL AND BFR.DL_REJECT_CD_02 IS NOT NULL
OR AFT.DL_REJECT_CD_02 IS NOT NULL AND BFR.DL_REJECT_CD_02 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL))
	)
OR ( T.cob_ind='Y' AND 
((AFT.COB_DL_REJECT_CD_02 <> BFR.COB_DL_REJECT_CD_02
OR AFT.COB_DL_REJECT_CD_02 IS NULL AND BFR.COB_DL_REJECT_CD_02 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_02 IS NOT NULL AND BFR.COB_DL_REJECT_CD_02 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
	) 
)

UNION

SELECT
'U'
,T.rx_nbr                        
,T.str_nbr                       
,T.rx_create_dt                  
,T.rx_fill_nbr                   
,T.rx_partial_fill_nbr           
,T.third_party_plan_id           
,T.cob_ind                       
,T.fill_enter_dt                 
,T.fill_enter_tm                 
,T.reject_nbr                    
,T.fill_sold_dt                  
,T.dl_reject_cd                  
,T.create_user_id                
,T.edw_batch_id                  
,T.relocate_fm_str_nbr           
,T.update_user_id                
,T.update_dttm                   
,T.src_partition_nbr    
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr 
,T.edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr 
AND  T.rx_fill_nbr = BFR.fill_nbr 
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr 
AND T.fill_enter_dt = CAST ( BFR.fill_entered_dttm AS DATE )  
AND T.fill_enter_tm = CAST(BFR.fill_entered_dttm AS TIME(0)) 
AND T.reject_nbr=3
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr 
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 

WHERE 
( 
	( T.cob_ind='N' AND 
((AFT.DL_REJECT_CD_03 <> BFR.DL_REJECT_CD_03
OR AFT.DL_REJECT_CD_03 IS NULL AND BFR.DL_REJECT_CD_03 IS NOT NULL
OR AFT.DL_REJECT_CD_03 IS NOT NULL AND BFR.DL_REJECT_CD_03 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL))
	)
OR ( T.cob_ind='Y' AND 
((AFT.COB_DL_REJECT_CD_03 <> BFR.COB_DL_REJECT_CD_03
OR AFT.COB_DL_REJECT_CD_03 IS NULL AND BFR.COB_DL_REJECT_CD_03 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_03 IS NOT NULL AND BFR.COB_DL_REJECT_CD_03 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
	) 
)

UNION

SELECT
'U'
,T.rx_nbr                        
,T.str_nbr                       
,T.rx_create_dt                  
,T.rx_fill_nbr                   
,T.rx_partial_fill_nbr           
,T.third_party_plan_id           
,T.cob_ind                       
,T.fill_enter_dt                 
,T.fill_enter_tm                 
,T.reject_nbr                    
,T.fill_sold_dt                  
,T.dl_reject_cd                  
,T.create_user_id                
,T.edw_batch_id                  
,T.relocate_fm_str_nbr           
,T.update_user_id                
,T.update_dttm                   
,T.src_partition_nbr    
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr 
,T.edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr 
AND  T.rx_fill_nbr = BFR.fill_nbr 
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr 
AND T.fill_enter_dt = CAST ( BFR.fill_entered_dttm AS DATE )  
AND T.fill_enter_tm = CAST(BFR.fill_entered_dttm AS TIME(0)) 
AND T.reject_nbr=4
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr 
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 

WHERE 
( 
	( T.cob_ind='N' AND 
((AFT.DL_REJECT_CD_04 <> BFR.DL_REJECT_CD_04
OR AFT.DL_REJECT_CD_04 IS NULL AND BFR.DL_REJECT_CD_04 IS NOT NULL
OR AFT.DL_REJECT_CD_04 IS NOT NULL AND BFR.DL_REJECT_CD_04 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL))
	)
OR ( T.cob_ind='Y' AND 
((AFT.COB_DL_REJECT_CD_04 <> BFR.COB_DL_REJECT_CD_04
OR AFT.COB_DL_REJECT_CD_04 IS NULL AND BFR.COB_DL_REJECT_CD_04 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_04 IS NOT NULL AND BFR.COB_DL_REJECT_CD_04 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
	) 
)

UNION

SELECT
'U'
,T.rx_nbr                        
,T.str_nbr                       
,T.rx_create_dt                  
,T.rx_fill_nbr                   
,T.rx_partial_fill_nbr           
,T.third_party_plan_id           
,T.cob_ind                       
,T.fill_enter_dt                 
,T.fill_enter_tm                 
,T.reject_nbr                    
,T.fill_sold_dt                  
,T.dl_reject_cd                  
,T.create_user_id                
,T.edw_batch_id                  
,T.relocate_fm_str_nbr           
,T.update_user_id                
,T.update_dttm                   
,T.src_partition_nbr    
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr 
,T.edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr 
AND  T.rx_fill_nbr = BFR.fill_nbr 
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr 
AND T.fill_enter_dt = CAST ( BFR.fill_entered_dttm AS DATE )  
AND T.fill_enter_tm = CAST(BFR.fill_entered_dttm AS TIME(0)) 
AND T.reject_nbr=5
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr 
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_entered_dttm = BFR.fill_entered_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 

WHERE 
( 
	( T.cob_ind='N' AND 
((AFT.DL_REJECT_CD_05 <> BFR.DL_REJECT_CD_05
OR AFT.DL_REJECT_CD_05 IS NULL AND BFR.DL_REJECT_CD_05 IS NOT NULL
OR AFT.DL_REJECT_CD_05 IS NOT NULL AND BFR.DL_REJECT_CD_05 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL))
	)
OR ( T.cob_ind='Y' AND 
((AFT.COB_DL_REJECT_CD_05 <> BFR.COB_DL_REJECT_CD_05
OR AFT.COB_DL_REJECT_CD_05 IS NULL AND BFR.COB_DL_REJECT_CD_05 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_05 IS NOT NULL AND BFR.COB_DL_REJECT_CD_05 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
	) 
	)
UNION

SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 1 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_01 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'F' AS CHAR(1) ) edw_src_ind  
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.DL_REJECT_CD_01 <> BFR.DL_REJECT_CD_01
OR AFT.DL_REJECT_CD_01 IS NULL AND BFR.DL_REJECT_CD_01 IS NOT NULL
OR AFT.DL_REJECT_CD_01 IS NOT NULL AND BFR.DL_REJECT_CD_01 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL)
	)
	
	
	
UNION	
	
SELECT  
CAST ( 'I' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 1 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_01 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'F' AS CHAR(1) ) edw_src_ind 
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR 
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT 
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr    
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
AND  AFT.cdc_before_after_cd = 'AFTER' 
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  BFR.cdc_before_after_cd = 'BEFORE' 
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 

AND (
(AFT.COB_DL_REJECT_CD_01 <> BFR.COB_DL_REJECT_CD_01
OR AFT.COB_DL_REJECT_CD_01 IS NULL AND BFR.COB_DL_REJECT_CD_01 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_01 IS NOT NULL AND BFR.COB_DL_REJECT_CD_01 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
	)

UNION

SELECT
CAST ( 'I' AS CHAR(1) ) edw_dml_ind
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr
, CAST ( NULL   AS DATE )   rx_create_dt
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 2 AS BYTEINT ) reject_nbr
, CAST ( AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt
, CAST ( AFT.COB_DL_REJECT_CD_02 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr
, CAST ( 'F' AS CHAR(1) ) edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr
AND  AFT.fill_nbr = BFR.fill_nbr
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE'
AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'

AND (
(AFT.COB_DL_REJECT_CD_02 <> BFR.COB_DL_REJECT_CD_02
OR AFT.COB_DL_REJECT_CD_02 IS NULL AND BFR.COB_DL_REJECT_CD_02 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_02 IS NOT NULL AND BFR.COB_DL_REJECT_CD_02 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
        )

UNION

SELECT
CAST ( 'I' AS CHAR(1) ) edw_dml_ind
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr
, CAST ( NULL   AS DATE )   rx_create_dt
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 3 AS BYTEINT ) reject_nbr
, CAST ( AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt
, CAST ( AFT.COB_DL_REJECT_CD_03 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr
, CAST ( 'F' AS CHAR(1) ) edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr
AND  AFT.fill_nbr = BFR.fill_nbr
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE'
AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'

AND (
(AFT.COB_DL_REJECT_CD_03 <> BFR.COB_DL_REJECT_CD_03
OR AFT.COB_DL_REJECT_CD_03 IS NULL AND BFR.COB_DL_REJECT_CD_03 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_03 IS NOT NULL AND BFR.COB_DL_REJECT_CD_03 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
        )

UNION

SELECT
CAST ( 'I' AS CHAR(1) ) edw_dml_ind
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr
, CAST ( NULL   AS DATE )   rx_create_dt
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 4 AS BYTEINT ) reject_nbr
, CAST ( AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt
, CAST ( AFT.COB_DL_REJECT_CD_04 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr
, CAST ( 'F' AS CHAR(1) ) edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr
AND  AFT.fill_nbr = BFR.fill_nbr
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE'
AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'

AND (
(AFT.COB_DL_REJECT_CD_04 <> BFR.COB_DL_REJECT_CD_04
OR AFT.COB_DL_REJECT_CD_04 IS NULL AND BFR.COB_DL_REJECT_CD_04 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_04 IS NOT NULL AND BFR.COB_DL_REJECT_CD_04 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
        )

UNION

SELECT
CAST ( 'I' AS CHAR(1) ) edw_dml_ind
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr
, CAST ( NULL   AS DATE )   rx_create_dt
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 5 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt
, CAST ( AFT.COB_DL_REJECT_CD_05 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr
, CAST ( 'F' AS CHAR(1) ) edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON   AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr
AND  AFT.fill_nbr = BFR.fill_nbr
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE'
AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'

AND (
(AFT.COB_DL_REJECT_CD_05 <> BFR.COB_DL_REJECT_CD_05
OR AFT.COB_DL_REJECT_CD_05 IS NULL AND BFR.COB_DL_REJECT_CD_05 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_05 IS NOT NULL AND BFR.COB_DL_REJECT_CD_05 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL)
        )
	
UNION
	
SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'N' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 1 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.DL_REJECT_CD_01 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'F' AS CHAR(1) ) edw_src_ind 
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.DL_REJECT_CD_01 IS NOT NULL OR AFT.DL_REJECT_CD_01 <> '' )


UNION	
	
SELECT  
CAST ( 'J' AS CHAR(1) ) edw_dml_ind 
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr  
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr 
, CAST ( NULL   AS DATE )   rx_create_dt 
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr  
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr 
, CAST ( AFT.cob_plan_id                AS CHAR(8)   )   third_party_plan_id  
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind 
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 1 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt 
, CAST ( AFT.COB_DL_REJECT_CD_01 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id 
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id 
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr 
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id 
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm 
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr 
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr  
, CAST ( 'F' AS CHAR(1) ) edw_src_ind 
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG            AFT 
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_01 IS NOT NULL OR AFT.COB_DL_REJECT_CD_01 <> '' )

UNION

SELECT
CAST ( 'J' AS CHAR(1) ) edw_dml_ind
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr
, CAST ( NULL   AS DATE )   rx_create_dt
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr
, CAST ( AFT.cob_plan_id  AS CHAR(8)   )   third_party_plan_id
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 2 AS BYTEINT ) reject_nbr
, CAST ( AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt
, CAST ( AFT.COB_DL_REJECT_CD_02 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr
, CAST ( 'F' AS CHAR(1) ) edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG            AFT
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_02 IS NOT NULL OR AFT.COB_DL_REJECT_CD_02 <> '' )

UNION

SELECT
CAST ( 'J' AS CHAR(1) ) edw_dml_ind
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr
, CAST ( NULL   AS DATE )   rx_create_dt
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr
, CAST ( AFT.cob_plan_id  AS CHAR(8)   )   third_party_plan_id
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 3 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt
, CAST ( AFT.COB_DL_REJECT_CD_03 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr
, CAST ( 'F' AS CHAR(1) ) edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG            AFT
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_03 IS NOT NULL OR AFT.COB_DL_REJECT_CD_03 <> '' )

UNION

SELECT
CAST ( 'J' AS CHAR(1) ) edw_dml_ind
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr
, CAST ( NULL   AS DATE )   rx_create_dt
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr
, CAST ( AFT.cob_plan_id  AS CHAR(8)   )   third_party_plan_id
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 4 AS BYTEINT ) reject_nbr
, CAST ( AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt
, CAST ( AFT.COB_DL_REJECT_CD_04 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr
, CAST ( 'F' AS CHAR(1) ) edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG            AFT
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_04 IS NOT NULL OR AFT.COB_DL_REJECT_CD_04 <> '' )

UNION

SELECT
CAST ( 'J' AS CHAR(1) ) edw_dml_ind
, CAST ( AFT.rx_nbr AS  INTEGER  )   rx_nbr
, CAST ( AFT.store_nbr AS  INTEGER  )   str_nbr
, CAST ( NULL   AS DATE )   rx_create_dt
, CAST ( AFT.fill_nbr AS  INTEGER  ) rx_fill_nbr
, CAST ( AFT.fill_partial_nbr AS  INTEGER  )   rx_partial_fill_nbr
, CAST ( AFT.cob_plan_id  AS CHAR(8)   )   third_party_plan_id
, CAST ( 'Y' AS  CHAR(1)  )   cob_ind
, TO_DATE ( TO_CHAR ( AFT.fill_enter_dttm::date, 'yyyy-mm-dd' ) ) fill_enter_dt
, CAST ( AFT.fill_enter_dttm AS TIME(0) )  fill_enter_tm
, CAST ( 5 AS BYTEINT ) reject_nbr
, CAST (  AFT.fill_sold_dttm   AS  DATE  )   fill_sold_dt
, CAST ( AFT.COB_DL_REJECT_CD_05 AS CHAR(3)) dl_reject_cd
, CAST ( NULL   AS  DECIMAL(9,0)  )   create_user_id
, CAST ( AFT.edw_batch_id  AS  DECIMAL(18,0)  )   edw_batch_id
, CAST ( AFT.relocate_fm_str_nbr  AS  INTEGER  )   relocate_fm_str_nbr
, CAST ( AFT.update_user_id AS  DECIMAL(9,0)  )   update_user_id
, CAST ( AFT.update_dttm AS  TIMESTAMP(0)  )   update_dttm
, CAST ( AFT.src_partition_nbr AS BYTEINT) src_partition_nbr
, CAST ( AFT.cdc_txn_commit_dttm AS TIMESTAMP(0)) cdc_txn_commit_dttm
, CAST ( AFT.cdc_rba_nbr AS DECIMAL(18,0) ) cdc_rba_nbr
, CAST ( AFT.cdc_seq_nbr AS DECIMAL(18,0) ) cdc_seq_nbr
, CAST ( 'F' AS CHAR(1) ) edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG            AFT
WHERE   AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'INSERT'
AND ( AFT.COB_DL_REJECT_CD_05  IS NOT NULL OR AFT.COB_DL_REJECT_CD_05 <> '' )


UNION

SELECT
'U'
,T.rx_nbr                        
,T.str_nbr                       
,T.rx_create_dt                  
,T.rx_fill_nbr                   
,T.rx_partial_fill_nbr           
,T.third_party_plan_id           
,T.cob_ind                       
,T.fill_enter_dt                 
,T.fill_enter_tm                 
,T.reject_nbr                    
,T.fill_sold_dt                  
,T.dl_reject_cd                  
,T.create_user_id                
,T.edw_batch_id                  
,T.relocate_fm_str_nbr           
,T.update_user_id                
,T.update_dttm                   
,T.src_partition_nbr    
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr 
, T.edw_src_ind 
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr 
AND  T.rx_fill_nbr = BFR.fill_nbr 
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr 
AND T.fill_enter_dt = CAST ( BFR.fill_enter_dttm AS DATE )  
AND T.fill_enter_tm = CAST(BFR.fill_enter_dttm AS TIME(0)) 
AND T.reject_nbr=1
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr 
AND  AFT.fill_nbr = BFR.fill_nbr 
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr 
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 

WHERE 
( 
	( T.cob_ind='N' AND 
((AFT.DL_REJECT_CD_01 <> BFR.DL_REJECT_CD_01
OR AFT.DL_REJECT_CD_01 IS NULL AND BFR.DL_REJECT_CD_01 IS NOT NULL
OR AFT.DL_REJECT_CD_01 IS NOT NULL AND BFR.DL_REJECT_CD_01 IS NULL)
OR
(AFT.plan_id <> BFR.plan_id
OR AFT.plan_id IS NULL AND BFR.plan_id IS NOT NULL
OR AFT.plan_id IS NOT NULL AND BFR.plan_id IS NULL))
	)
OR ( T.cob_ind='Y' AND 
((AFT.COB_DL_REJECT_CD_01 <> BFR.COB_DL_REJECT_CD_01
OR AFT.COB_DL_REJECT_CD_01 IS NULL AND BFR.COB_DL_REJECT_CD_01 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_01 IS NOT NULL AND BFR.COB_DL_REJECT_CD_01 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
	) 
)

UNION

SELECT
'U'
,T.rx_nbr
,T.str_nbr
,T.rx_create_dt
,T.rx_fill_nbr
,T.rx_partial_fill_nbr
,T.third_party_plan_id
,T.cob_ind
,T.fill_enter_dt
,T.fill_enter_tm
,T.reject_nbr
,T.fill_sold_dt
,T.dl_reject_cd
,T.create_user_id
,T.edw_batch_id
,T.relocate_fm_str_nbr
,T.update_user_id
,T.update_dttm
,T.src_partition_nbr
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr
, T.edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr
AND  T.rx_fill_nbr = BFR.fill_nbr
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr
AND T.fill_enter_dt = CAST ( BFR.fill_enter_dttm AS DATE )
AND T.fill_enter_tm = CAST(BFR.fill_enter_dttm AS TIME(0))
AND T.reject_nbr=2
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr
AND  AFT.fill_nbr = BFR.fill_nbr
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE'

WHERE
(
       ( T.cob_ind='Y' AND
((AFT.COB_DL_REJECT_CD_02 <> BFR.COB_DL_REJECT_CD_02
OR AFT.COB_DL_REJECT_CD_02 IS NULL AND BFR.COB_DL_REJECT_CD_02 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_02 IS NOT NULL AND BFR.COB_DL_REJECT_CD_02 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
        )
)

UNION

SELECT
'U'
,T.rx_nbr
,T.str_nbr
,T.rx_create_dt
,T.rx_fill_nbr
,T.rx_partial_fill_nbr
,T.third_party_plan_id
,T.cob_ind
,T.fill_enter_dt
,T.fill_enter_tm
,T.reject_nbr
,T.fill_sold_dt
,T.dl_reject_cd
,T.create_user_id
,T.edw_batch_id
,T.relocate_fm_str_nbr
,T.update_user_id
,T.update_dttm
,T.src_partition_nbr
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr
, T.edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr
AND  T.rx_fill_nbr = BFR.fill_nbr
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr
AND T.fill_enter_dt = CAST ( BFR.fill_enter_dttm AS DATE )
AND T.fill_enter_tm = CAST(BFR.fill_enter_dttm AS TIME(0))
AND T.reject_nbr=3
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr
AND  AFT.fill_nbr = BFR.fill_nbr
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE'

WHERE
(
       ( T.cob_ind='Y' AND
((AFT.COB_DL_REJECT_CD_03 <> BFR.COB_DL_REJECT_CD_03
OR AFT.COB_DL_REJECT_CD_03 IS NULL AND BFR.COB_DL_REJECT_CD_03 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_03 IS NOT NULL AND BFR.COB_DL_REJECT_CD_03 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
        )
)

UNION

SELECT
'U'
,T.rx_nbr
,T.str_nbr
,T.rx_create_dt
,T.rx_fill_nbr
,T.rx_partial_fill_nbr
,T.third_party_plan_id
,T.cob_ind
,T.fill_enter_dt
,T.fill_enter_tm
,T.reject_nbr
,T.fill_sold_dt
,T.dl_reject_cd
,T.create_user_id
,T.edw_batch_id
,T.relocate_fm_str_nbr
,T.update_user_id
,T.update_dttm
,T.src_partition_nbr
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr
, T.edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr
AND  T.rx_fill_nbr = BFR.fill_nbr
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr
AND T.fill_enter_dt = CAST ( BFR.fill_enter_dttm AS DATE )
AND T.fill_enter_tm = CAST(BFR.fill_enter_dttm AS TIME(0))
AND T.reject_nbr=4
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr
AND  AFT.fill_nbr = BFR.fill_nbr
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE'

WHERE
(
       ( T.cob_ind='Y' AND
((AFT.COB_DL_REJECT_CD_04 <> BFR.COB_DL_REJECT_CD_04
OR AFT.COB_DL_REJECT_CD_04 IS NULL AND BFR.COB_DL_REJECT_CD_04 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_04 IS NOT NULL AND BFR.COB_DL_REJECT_CD_04 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
        )
)

UNION

SELECT
'U'
,T.rx_nbr
,T.str_nbr
,T.rx_create_dt
,T.rx_fill_nbr
,T.rx_partial_fill_nbr
,T.third_party_plan_id
,T.cob_ind
,T.fill_enter_dt
,T.fill_enter_tm
,T.reject_nbr
,T.fill_sold_dt
,T.dl_reject_cd
,T.create_user_id
,T.edw_batch_id
,T.relocate_fm_str_nbr
,T.update_user_id
,T.update_dttm
,T.src_partition_nbr
, AFT.cdc_txn_commit_dttm
, 0 cdc_rba_nbr
, 0 cdc_seq_nbr
, T.edw_src_ind
FROM $DP_DB_STAGING.patient_services.ETL_PROC_FP_REJECT_STG T
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
ON  T.rx_nbr = BFR.rx_nbr
AND  T.str_nbr = BFR.store_nbr
AND  T.rx_fill_nbr = BFR.fill_nbr
AND  T.rx_partial_fill_nbr = BFR.fill_partial_nbr
AND T.fill_enter_dt = CAST ( BFR.fill_enter_dttm AS DATE )
AND T.fill_enter_tm = CAST(BFR.fill_enter_dttm AS TIME(0))
AND T.reject_nbr=5
JOIN $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON  AFT.rx_nbr = BFR.rx_nbr
AND  AFT.store_nbr = BFR.store_nbr
AND  AFT.fill_nbr = BFR.fill_nbr
AND  AFT.fill_partial_nbr = BFR.fill_partial_nbr
AND  AFT.fill_enter_dttm = BFR.fill_enter_dttm

AND  BFR.cdc_before_after_cd = 'BEFORE'
AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
AND  AFT.cdc_txn_commit_dttm  =  BFR.cdc_txn_commit_dttm
AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr
AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr
AND  AFT.cdc_before_after_cd = 'AFTER'
AND  AFT.cdc_operation_type_cd = 'SQL COMPUPDATE'

WHERE
(
       ( T.cob_ind='Y' AND
((AFT.COB_DL_REJECT_CD_05 <> BFR.COB_DL_REJECT_CD_05
OR AFT.COB_DL_REJECT_CD_05 IS NULL AND BFR.COB_DL_REJECT_CD_05 IS NOT NULL
OR AFT.COB_DL_REJECT_CD_05 IS NOT NULL AND BFR.COB_DL_REJECT_CD_05 IS NULL)
OR
(AFT.cob_plan_id <> BFR.cob_plan_id
OR AFT.cob_plan_id IS NULL AND BFR.cob_plan_id IS NOT NULL
OR AFT.cob_plan_id IS NOT NULL AND BFR.cob_plan_id IS NULL))
        )
)

) A
LEFT OUTER JOIN 
(SELECT str_nbr, rx_nbr, rx_create_dt from $DP_DB_STAGING.patient_services.etl_proc_trans_presc_STG
UNION
SELECT str_nbr, rx_nbr, rx_create_dt from $DP_DB_STAGING.patient_services.etl_proc_fill_presc_STG
) P
ON A.str_nbr=P.str_nbr
AND A.rx_nbr=P.rx_nbr""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("CALL PRDUTIL.TABLE_STATS('$DP_DB_STAGING', 'patient_services.ETL_PROC_ENDATED_FP_REJECT_STG' )",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  #/*================================================================**
#** DELETE THE PREVIOUS DATA FROM TH OUTER TABLE **
#**================================================================*/
  executeSql([], [
    ("DELETE FROM $DP_DB_STAGING.patient_services.ETL_OUTER_FP_REJECT_STG",
    [])
  ])
  if (Action.errorCode != 0):
    return
  #/*================================================================**
#** INSERT INTO THE OUTER TABLE FROM TRANS   **
#** THIS TABLE HOLDS THE DATA WHERE THE VALUE IN THE CODE FIELDS CHANGES FROM VALUE TO A NULL **
#**================================================================*/
  executeSql([], [
    ("""INSERT INTO $DP_DB_STAGING.patient_services.ETL_OUTER_FP_REJECT_STG
(cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_entered_dttm             
,plan_id                       
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,cob_plan_id                   
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,fill_sold_dttm
,edw_src_ind    
)
SELECT
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_entered_dttm             
,plan_id                       
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,cob_plan_id                   
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,fill_sold_dttm      
,'T'          
FROM    $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG
WHERE   (STORE_NBR,RX_NBR,FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTERED_DTTM, CDC_TXN_COMMIT_DTTM,CDC_SEQ_NBR,CDC_RBA_NBR)
IN
(
SELECT  BFR.STORE_NBR,
        BFR.RX_NBR,
        BFR.FILL_NBR,
        BFR.FILL_PARTIAL_NBR,
        BFR.FILL_ENTERED_DTTM,
        BFR.CDC_TXN_COMMIT_DTTM,
        BFR.CDC_SEQ_NBR,
        BFR.CDC_RBA_NBR
FROM    $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG BFR
INNER   JOIN  $DP_DB_STAGING.patient_services.ETL_TBF0_RX_TRANSACTION_STG AFT
ON      AFT.CDC_TXN_COMMIT_DTTM         = BFR.CDC_TXN_COMMIT_DTTM
AND     AFT.CDC_SEQ_NBR                 = BFR.CDC_SEQ_NBR
AND     AFT.CDC_RBA_NBR                 = BFR.CDC_RBA_NBR
AND     AFT.CDC_OPERATION_TYPE_CD       IN ('SQL COMPUPDATE','PK UPDATE')
AND     AFT.CDC_BEFORE_AFTER_CD         = 'AFTER'
AND     BFR.CDC_OPERATION_TYPE_CD       = 'SQL COMPUPDATE'
AND     BFR.CDC_BEFORE_AFTER_CD         = 'BEFORE'
AND
(
	( BFR.plan_id                 IS NOT NULL AND AFT.plan_id               IS NULL )     
OR	( BFR.DL_REJECT_CD_01         IS NOT NULL AND AFT.DL_REJECT_CD_01       IS NULL )    
OR	( BFR.DL_REJECT_CD_02         IS NOT NULL AND AFT.DL_REJECT_CD_02       IS NULL )    
OR	( BFR.DL_REJECT_CD_03         IS NOT NULL AND AFT.DL_REJECT_CD_03       IS NULL )    
OR	( BFR.DL_REJECT_CD_04         IS NOT NULL AND AFT.DL_REJECT_CD_04       IS NULL )    
OR	( BFR.DL_REJECT_CD_05         IS NOT NULL AND AFT.DL_REJECT_CD_05       IS NULL )    
OR	( BFR.cob_plan_id             IS NOT NULL AND AFT.cob_plan_id           IS NULL )    
OR	( BFR.COB_DL_REJECT_CD_01     IS NOT NULL AND AFT.COB_DL_REJECT_CD_01   IS NULL )    
OR	( BFR.COB_DL_REJECT_CD_02     IS NOT NULL AND AFT.COB_DL_REJECT_CD_02   IS NULL )    
OR	( BFR.COB_DL_REJECT_CD_03     IS NOT NULL AND AFT.COB_DL_REJECT_CD_03   IS NULL )    
OR	( BFR.COB_DL_REJECT_CD_04     IS NOT NULL AND AFT.COB_DL_REJECT_CD_04   IS NULL )    
OR	( BFR.COB_DL_REJECT_CD_05     IS NOT NULL AND AFT.COB_DL_REJECT_CD_05   IS NULL )    
))""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#/*================================================================**
#** INSERT INTO THE OUTER TABLE FROM FILL   **
#** THIS TABLE HOLDS THE DATA WHERE THE VALUE IN THE CODE FIELDS CHANGES FROM VALUE TO A NULL **
#**================================================================*/
  executeSql([], [
    ("""INSERT INTO $DP_DB_STAGING.patient_services.ETL_OUTER_FP_REJECT_STG
(cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_entered_dttm             
,plan_id                       
,DL_REJECT_CD_01               
,DL_REJECT_CD_02               
,DL_REJECT_CD_03               
,DL_REJECT_CD_04               
,DL_REJECT_CD_05               
,cob_plan_id                   
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02           
,COB_DL_REJECT_CD_03           
,COB_DL_REJECT_CD_04           
,COB_DL_REJECT_CD_05           
,fill_sold_dttm
,edw_src_ind      
)
SELECT
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_enter_dttm             
,plan_id                       
,DL_REJECT_CD_01               
,NULL               
,NULL               
,NULL               
,NULL               
,cob_plan_id                   
,COB_DL_REJECT_CD_01           
,COB_DL_REJECT_CD_02
,COB_DL_REJECT_CD_03
,COB_DL_REJECT_CD_04
,COB_DL_REJECT_CD_05
,fill_sold_dttm
,'F'                
FROM    $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG
WHERE   (STORE_NBR,RX_NBR,FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTER_DTTM, CDC_TXN_COMMIT_DTTM,CDC_SEQ_NBR,CDC_RBA_NBR)
IN
(
SELECT  BFR.STORE_NBR,
        BFR.RX_NBR,
        BFR.FILL_NBR,
        BFR.FILL_PARTIAL_NBR,
        BFR.FILL_ENTER_DTTM,
        BFR.CDC_TXN_COMMIT_DTTM,
        BFR.CDC_SEQ_NBR,
        BFR.CDC_RBA_NBR
FROM    $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG BFR
INNER   JOIN  $DP_DB_STAGING.patient_services.ETL_TBF0_FILL_STG AFT
ON      AFT.CDC_TXN_COMMIT_DTTM         = BFR.CDC_TXN_COMMIT_DTTM
AND     AFT.CDC_SEQ_NBR                 = BFR.CDC_SEQ_NBR
AND     AFT.CDC_RBA_NBR                 = BFR.CDC_RBA_NBR
AND     AFT.CDC_OPERATION_TYPE_CD       IN ('SQL COMPUPDATE','PK UPDATE')
AND     AFT.CDC_BEFORE_AFTER_CD         = 'AFTER'
AND     BFR.CDC_OPERATION_TYPE_CD       = 'SQL COMPUPDATE'
AND     BFR.CDC_BEFORE_AFTER_CD         = 'BEFORE'
AND
(
	( BFR.plan_id                 IS NOT NULL AND AFT.plan_id               IS NULL )     
OR	( BFR.DL_REJECT_CD_01         IS NOT NULL AND AFT.DL_REJECT_CD_01       IS NULL )    
OR	( BFR.cob_plan_id             IS NOT NULL AND AFT.cob_plan_id           IS NULL )    
OR	( BFR.COB_DL_REJECT_CD_01     IS NOT NULL AND AFT.COB_DL_REJECT_CD_01   IS NULL )    
OR      ( BFR.COB_DL_REJECT_CD_02     IS NOT NULL AND AFT.COB_DL_REJECT_CD_02   IS NULL )
OR      ( BFR.COB_DL_REJECT_CD_03     IS NOT NULL AND AFT.COB_DL_REJECT_CD_03   IS NULL )
OR      ( BFR.COB_DL_REJECT_CD_04     IS NOT NULL AND AFT.COB_DL_REJECT_CD_04   IS NULL )
OR      ( BFR.COB_DL_REJECT_CD_05     IS NOT NULL AND AFT.COB_DL_REJECT_CD_05   IS NULL )
))""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("CALL PRDUTIL.TABLE_STATS('$DP_DB_STAGING', 'patient_services.ETL_OUTER_FP_REJECT_STG' )",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  return

if __name__ == '__main__':
  main()
  cleanup()
  done()

ZZ

#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDTargetTable=$5
pTDStageDB=$6
pTDRXChangeDttmTable=$7
pTDTargetRXFillTable=$8
pTDETLFillTable=$9
pTDMASTERDB=${10}
pEdwBatchId=${11}

if [ $pTDDBName = devedwdb01 ]
then
  TDWORKDB=devetl01
fi

if [ $pTDDBName = intedwdb01 ]
then
  TDWORKDB=intetl01
fi

if [ $pTDDBName = prdedwdb ]
then
  TDWORKDB=prdetl
fi



python3 <<ZZ
#!/usr/bin/python3

from npjet import *

def main():
  runSql("""UPDATE $pTDDBName.$pTDTargetTable TGT
SET     fill_enter_dt = CAST(TRX.fill_enter_dttm AS DATE),
        fill_enter_tm = CAST(TRX.fill_enter_dttm AS TIME(0)),
	rx_create_dt = CASE WHEN TRX.rx_create_dt IS NULL THEN CAST('1900-01-01' AS DATE) ELSE TRX.rx_create_dt END,
        fill_sold_dt = TRX.fill_sold_dt,
		edw_batch_id = $pEdwBatchId
FROM    $pTDStageDB.V_rx_fill_for_child_post_stg TRX
WHERE
        TGT.rx_nbr = TRX.rx_nbr
AND     TGT.str_nbr = TRX.str_nbr
AND     TGT.rx_fill_nbr = TRX.rx_fill_nbr
AND     TGT.rx_partial_fill_nbr = TRX.rx_partial_fill_nbr
AND     (TRX.rx_nbr, TRX.str_nbr, TRX.rx_fill_nbr, TRX.rx_partial_fill_nbr)
        IN
       (
         SELECT rx_nbr, COALESCE(relo.relocate_to_str_nbr,STORE_NBR) as store_nbr, FILL_NBR, FILL_PARTIAL_NBR
         FROM
            $pTDStageDB.etl_tbf0_exception_stg etl
         LEFT OUTER JOIN
            $pTDMASTERDB.location_store_relocation relo
         ON
            etl.store_nbr = relo.relocate_fm_str_nbr
         GROUP BY 1, 2, 3 ,4
       )
AND    to_date(TGT.create_dttm) -  to_date(TRX.fill_enter_dttm) < case when TGT.str_nbr=3397 then 365 else 730 end
AND	to_date(TGT.create_dttm) >= to_date(TRX.fill_enter_dttm);
-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""")
  if (Action.errorCode != 0):
    return
  runSql("""UPDATE $pTDDBName.$pTDTargetTable TGT
SET
	rx_create_dt 	= RXCHNG.to_create_dt
FROM    (
	SELECT 
	str_nbr ,
	rx_nbr ,
	CAST(frm_create_dttm AS DATE) frm_create_dt, 
	CAST(to_create_dttm AS DATE) to_create_dt, 
	change_prcs_ind
	FROM	$pTDStageDB.$pTDRXChangeDttmTable
WHERE frm_create_dt <> to_create_dt
	 
	GROUP BY 1,2,3,4,5
	
	) RXCHNG
WHERE
 	 	TGT.rx_nbr 		= RXCHNG.rx_nbr
 	AND 	TGT.str_nbr 		= RXCHNG.str_nbr
 	AND 	TGT.rx_create_dt 	= RXCHNG.frm_create_dt
 	AND 	TGT.rx_create_dt 	<> '1900-01-01'
 	AND 	RXCHNG.change_prcs_ind	= 'N';
-- SEL_BODY_CLAUSES_ORDER - change the order of all the clauses of a select statement
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""")
  if (Action.errorCode != 0):
    return
  runSql("""UPDATE $pTDDBName.$pTDTargetTable TGT
SET 
	fill_sold_dt=FL.fill_sold_dt, 
  TGT.edw_batch_id = FL.edw_batch_id
FROM    $pTDStageDB.fill_sold_dttm_change_stg FL
WHERE 
 	TGT.rx_nbr=FL.rx_nbr                        
AND	TGT.str_nbr=FL.str_nbr                     
AND 	TGT.rx_fill_nbr=FL.rx_fill_nbr                      
AND 	TGT.rx_partial_fill_nbr=FL.rx_partial_fill_nbr              
AND 	TGT.fill_enter_dt=FL.fill_enter_dt;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""")
  if (Action.errorCode != 0):
    return
  runSql("""delete from $pTDDBName.$pTDTargetTable  a
using (    select rx_nbr, str_nbr, rx_fill_nbr, rx_partial_fill_nbr, exc_nbr, fill_enter_dt, fill_enter_tm, min(update_user_dttm) as min_update
    from $pTDDBName.$pTDTargetTable 
    where fill_enter_dt <> '1900-01-01'    group by rx_nbr, str_nbr, rx_fill_nbr, rx_partial_fill_nbr,exc_nbr, fill_enter_dt, fill_enter_tm
    having count(*) > 1 and min(update_user_dttm) <> max(update_user_dttm)) as filter_with_min
    where a.rx_nbr = filter_with_min.rx_nbr
    and a.str_nbr = filter_with_min.str_nbr
    and a.rx_fill_nbr = filter_with_min.rx_fill_nbr
    and a.rx_partial_fill_nbr = filter_with_min.rx_partial_fill_nbr
    and a.exc_nbr = filter_with_min.exc_nbr
    and a.fill_enter_dt = filter_with_min.fill_enter_dt
    and a.fill_enter_tm = filter_with_min.fill_enter_tm
    and a.update_user_dttm = filter_with_min.min_update
-- DELETE_STATEMENT - DELETE DUPLICATESBASED ON MIN UPDATE_USER_DTTM
""")
  if (Action.errorCode != 0):
    return
  return

if __name__ == '__main__':
  main()
  cleanup()
  done()

ZZ

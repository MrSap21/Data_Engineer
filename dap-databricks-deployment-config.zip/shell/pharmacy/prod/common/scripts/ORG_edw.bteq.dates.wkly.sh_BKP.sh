#!/bin/ksh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw.bteq.dates.sh
#  Date:             06-11-2009
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 06-11-2009
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------


## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
LOGBTEQOUT=${4}
LOGFILE=${5}
LOGBTEQOUTPRM=${6}


## INITIATE BTEQ SESSION AND TAKE COUNT

  > $LOGBTEQOUT

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "$LOGBTEQOUT"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    ("""select cast( cast(to_date(calendar_date ::VARCHAR(30), 'yyyy-mm-dd')||' 22:00:00' as timestamp(0)) as varchar(19))||'|'||
cast( cast(to_date(calendar_date-7 ::VARCHAR(30), 'yyyy-mm-dd')||' 22:00:00' as timestamp(0)) as varchar(19))||'|'   as ""
from 
sys_calendar.calendar where 
calendar_date=current_date and day_of_week=3""",
    [])
  ])
  #-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (Action.errorCode == 0):
    SELECTOK()
    return
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  SELECTOK()
def SELECTOK():
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ] 
 then
    exit 1
else
cat $LOGBTEQOUT|read dates
rm $LOGBTEQOUT
RC=$?
if [ $RC -ne 0 ] 
then
exit 1
else
if [ -f $LOGBTEQOUTPRM ] 
then
cat $LOGBTEQOUTPRM|read xyz
else 
xyz=' '
fi
print "$xyz^$dates^";
exit 0
fi
fi







   

#!/bin/ksh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Sahil Malhotra
#  File name:        Ftp_File_Date_Chk.sh 
#  Date:             07-22-2009
#  Description:      FTP output extract
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         | S Malhotra | 11-12-2009
#---------+-------------------------------------------+------------+-----------


##   THIS SCRIPT CHECKS IF THE FILE TO BE FTP TO THE DESTINATION IS OF CURRENT DATE OR NOT



flnm=$1
LOGFL=$2

if [ ! -f  ./$flnm ]
        then
                echo "File Does not exist " >>$LOGFL
exit -10
fi
d1=`date +%b" "%d`
flmkdt=`ls -l $flnm | tr -s ' '|awk -F" " ' { print $6" "$7 } '`

if [ "$flmkdt" != "$d1" ]
    then
      echo  "Exiting as: File " $flnm " was not Generated Today, it was generated on" $flmkdt >>$LOGFL
exit -10
fi
#!/bin/sh
#------------------------------------------------------------------------------#
#   (C) Copyright 2011, Walgreen Co.
#       Licensed Material
#       All Rights Reserved
#------------------------------------------------------------------------------#
#  Author: Vinay Puttalingaiah
#  File name:  edw_phrm_adhoc_cut_off_dttm_report.sh
#  Date: 12/01/2011
#  Description:  Generate report on cut off dttm for tran catch-up process

##------------------------------------------------------------------
## -- SET SCRIPT PARAMETERS
##------------------------------------------------------------------
set -x
PROCNAME=${0}
pEDWBATCHID=${1}
pDSPROJECT=${2}
pDSJOBNAME=${3}
pDSJOBINVOCATION=${4}
pLOGFILE=${5}

# Parameters in the process control job parameter table
pADMINEMAILADDR='EDW-Rx-Batch@Walgreens.com'
pADMINEMAILADDR='Vinay.Puttalingaiah@walgreens.com'

cd /usr/local/edw/pharmacy/prod/common/scripts

REPORT_FILE=$(dirname $pLOGFILE)/${pDSJOBNAME}.${pEDWBATCHID}.txt
cat /dev/null > $REPORT_FILE

python3 << EOF >> $pLOGFILE
#!/usr/bin/python3

from npjet import *

def main():

  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  FormatOptions.width = 60000
  FormatOptions.sidetitles = False
  FormatOptions.heading = ""
  Action.exportFileName = "$REPORT_FILE"
  ExportOptions.colLimit = 100
  Action.charSet = "UTF-8"
  executeSql([], [
    ("""SELECT '-------------------------------------------------------------------------------------------------'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '--- Max dttms from all partitions ---'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '-------------------------------------------------------------------------------------------------'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT '--- Partition 1 MAX  cdc_txn_commit_dttm---'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT 1 src_partition_nbr, MAX(cdc_txn_commit_dttm) cdc_txn_commit_dttm FROM prdrx2stage.gg_tbf0_rx_transaction_1
WHERE cdc_txn_commit_dttm < (SELECT cut_off_dttm FROM prdrx2stage.etl_batch_rx_cutoff_dttm WHERE edw_batch_id="$pEDWBATCHID" AND process_ind='SO');
-- OBJ_NAME - double quote object name which include special characters or keyword.
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '--- Partition 2 MAX  cdc_txn_commit_dttm---'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT 2 src_partition_nbr, MAX(cdc_txn_commit_dttm) cdc_txn_commit_dttm FROM prdrx2stage.gg_tbf0_rx_transaction_2
WHERE cdc_txn_commit_dttm < (SELECT cut_off_dttm FROM prdrx2stage.etl_batch_rx_cutoff_dttm WHERE edw_batch_id="$pEDWBATCHID" AND process_ind='SO');
-- OBJ_NAME - double quote object name which include special characters or keyword.
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '--- Partition 3 MAX  cdc_txn_commit_dttm---'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT 3 src_partition_nbr, MAX(cdc_txn_commit_dttm) cdc_txn_commit_dttm FROM prdrx2stage.gg_tbf0_rx_transaction_3
WHERE cdc_txn_commit_dttm < (SELECT cut_off_dttm FROM prdrx2stage.etl_batch_rx_cutoff_dttm WHERE edw_batch_id="$pEDWBATCHID" AND process_ind='SO');
-- OBJ_NAME - double quote object name which include special characters or keyword.
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '--- Partition 4 MAX  cdc_txn_commit_dttm---'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT 4 src_partition_nbr, MAX(cdc_txn_commit_dttm) cdc_txn_commit_dttm FROM prdrx2stage.gg_tbf0_rx_transaction_4
WHERE cdc_txn_commit_dttm < (SELECT cut_off_dttm FROM prdrx2stage.etl_batch_rx_cutoff_dttm WHERE edw_batch_id="$pEDWBATCHID" AND process_ind='SO');
-- OBJ_NAME - double quote object name which include special characters or keyword.
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT '-------------------------------------------------------------------------------------------------'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '--- Tran cut off dttm report for catch-up process ---'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '-------------------------------------------------------------------------------------------------'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT TGT.cut_off_dttm AS rx_cut_off_dttm, TGT.rx_tran_cut_off_dttm AS curr_tran_cut_off_dttm ,TMP.min_rx_tran_commit_dttm new_tran_cut_off_dttm
FROM prdrx2stage.etl_batch_rx_cutoff_dttm TGT,
(SELECT MIN(a.cdc_txn_commit_dttm) min_rx_tran_commit_dttm FROM
                (
                SELECT 1 src_partition_nbr, MAX(cdc_txn_commit_dttm) cdc_txn_commit_dttm FROM prdrx2stage.gg_tbf0_rx_transaction_1
                WHERE cdc_txn_commit_dttm < (SELECT cut_off_dttm FROM prdrx2stage.etl_batch_rx_cutoff_dttm WHERE edw_batch_id="$pEDWBATCHID" AND process_ind='SO')
                UNION
                SELECT 2 src_partition_nbr,
                CASE
                WHEN  MAX(cdc_txn_commit_dttm)<= (MIN(cdc_txn_commit_dttm)  + INTERVAL '48  HOUR')
                        THEN MAX(cdc_txn_commit_dttm)
                ELSE MIN(cdc_txn_commit_dttm)  + INTERVAL '48  HOUR'
                END AS cdc_txn_commit_dttm FROM prdrx2stage.gg_tbf0_rx_transaction_2
                WHERE cdc_txn_commit_dttm < (SELECT cut_off_dttm FROM prdrx2stage.etl_batch_rx_cutoff_dttm WHERE edw_batch_id="$pEDWBATCHID" AND process_ind='SO')
                UNION
                SELECT 3 src_partition_nbr, MAX(cdc_txn_commit_dttm) cdc_txn_commit_dttm FROM prdrx2stage.gg_tbf0_rx_transaction_3
                WHERE cdc_txn_commit_dttm < (SELECT cut_off_dttm FROM prdrx2stage.etl_batch_rx_cutoff_dttm WHERE edw_batch_id="$pEDWBATCHID" AND process_ind='SO')
                UNION
                SELECT 4 src_partition_nbr, MAX(cdc_txn_commit_dttm) cdc_txn_commit_dttm FROM prdrx2stage.gg_tbf0_rx_transaction_4
                WHERE cdc_txn_commit_dttm < (SELECT cut_off_dttm FROM prdrx2stage.etl_batch_rx_cutoff_dttm WHERE edw_batch_id="$pEDWBATCHID" AND process_ind='SO')
                ) a
) TMP
WHERE TGT.proj_name='$pDSPROJECT'
AND  TGT.edw_batch_id="$pEDWBATCHID"
AND  TGT.process_ind='SO';
-- EXPR_INTERVAL - Moving QUALIFIER as a part of STRING LITERAL
-- OBJ_NAME - double quote object name which include special characters or keyword.
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  Action.exportFileName = None
  #------------------------------------------------------UPDATE
  #------------------------------------------------------UPDATE
  #------------------------------------------------------UPDATE
  #------------------------------------------------------UPDATE
  #------------------------------------------------------UPDATE
  Action.exportFileName = "$REPORT_FILE"
  ExportOptions.colLimit = 100
  Action.charSet = "UTF-8"
  executeSql([], [
    ("""SELECT '-------------------------------------------------------------------------------------------------'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '--- etl_batch_rx_cutoff_dttm after update  ---'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '-------------------------------------------------------------------------------------------------'  as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT * FROM prdrx2stage.etl_batch_rx_cutoff_dttm TGT
WHERE TGT.proj_name='$pDSPROJECT'
AND  TGT.edw_batch_id="$pEDWBATCHID"
AND  TGT.process_ind='SO';
-- OBJ_NAME - double quote object name which include special characters or keyword.
""",
    [])
  ])
  if (Action.errorCode != 0):
    GENERIC_ERR()
    return
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  executeSql([], [
    ("""SELECT '' as "";
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return
  #/*-------------------*/
  GENERIC_ERR()
def GENERIC_ERR():
  #/*-------------------*/
  executeSql([], [
    ("""SELECT current_date,current_time;
-- FUN_DATE - Replace DATE function with CURRENT_DATE
-- FUN_TIME - Replace TIME function with CURRENT_TIME
""",
    [])
  ])
  Action.errorCodeOverride = 2
  return

if __name__ == '__main__':
  main()
  cleanup()
  done()

EOF

RC=$?

if [ $RC -eq 0 ]; then
        echo "`date +'%D %r'` $PROCNAME completed succesfully" >> $pLOGFILE
        mail -s "Report genrated for the cut off dttm process-  $pEDWBATCHID"  $pADMINEMAILADDR < $REPORT_FILE
        exit $RC
else
        echo "`date +'%D %r'` ERROR!:$PROCNAME failed" >> $pLOGFILE
        mail -s "$PROCNAME failed -  $pEDWBATCHID"  $pADMINEMAILADDR < $pLOGFILE
        exit $RC
fi

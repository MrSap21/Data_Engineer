#!/bin/sh

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
APT_TERA_SYNC_DATABASE=$7

python3 <<ZZ 
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  #--BC /*================================================================**
  #--BC ** PERFORM STORE RELO UPDATES FOR DEDUP TABLES                    **
  #--BC **================================================================*/
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_fill
 
set    store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_fill.store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_fill
 
set    entered_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_fill.entered_store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_fill
 
set    reviewed_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_fill.reviewed_store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** REMOVE PK UPDATES FOR STORE RELOS IN STAGE TABLES              **
  #--BC **================================================================*/
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_fill txn 
using $pTDStageDB.etl_tbf0_fill BFR, $pTDStageDB.etl_tbf0_fill AFT, $pTDDBName.location_store_relocation  SR 
where BFR.cdc_txn_commit_dttm = AFT.cdc_txn_commit_dttm
  and  BFR.cdc_seq_nbr = AFT.cdc_seq_nbr
  and  BFR.cdc_rba_nbr = AFT.cdc_rba_nbr
  and SR.relocate_fm_str_nbr = BFR.store_nbr
  and SR.relocate_to_str_nbr = AFT.store_nbr
  and  BFR.cdc_before_after_cd = 'BEFORE'
  and  AFT.cdc_before_after_cd = 'AFTER'
  and  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
  and  AFT.cdc_operation_type_cd = 'PK UPDATE'
  and BFR.store_nbr <> AFT.store_nbr
  and BFR.rx_nbr = AFT.rx_nbr
  and BFR.fill_nbr = AFT.fill_nbr
  and BFR.fill_partial_nbr = AFT.fill_partial_nbr
  and txn.cdc_txn_commit_dttm =  bfr.cdc_txn_commit_dttm
  and txn.cdc_seq_nbr =   bfr.cdc_seq_nbr
  and txn.cdc_rba_nbr =   bfr.cdc_rba_nbr
  and txn.cdc_operation_type_cd in ( 'PK UPDATE', 'SQL COMPUPDATE')""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** UPDATE STORE NUMBERS FOR STORE RELOS IN STAGE TABLES           **
  #--BC **================================================================*/
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_tbf0_fill
 
set store_nbr = SR.relocate_to_str_nbr
 from  $pTDDBName.location_store_relocation  SR
 where store_nbr = SR.relocate_fm_str_nbr""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_tbf0_fill
 
set    entered_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName.location_store_relocation  R
 where  $pTDStageDB.etl_tbf0_fill.entered_store_nbr = R.relocate_fm_str_nbr
  and   $pTDStageDB.etl_tbf0_fill.cdc_operation_type_cd='INSERT'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_tbf0_fill
 
set    reviewed_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName.location_store_relocation  R
 where  $pTDStageDB.etl_tbf0_fill.reviewed_store_nbr = R.relocate_fm_str_nbr
  and   $pTDStageDB.etl_tbf0_fill.cdc_operation_type_cd='INSERT'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** DEDUP LOGIC                                                    **
  #--BC **================================================================*/
  #------------------------------------------------------
  #-- CHECKING DUPLICATES WITHIN THE SAME BATCH
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_fill
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr
)
select
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr

from $pTDStageDB.etl_tbf0_fill
where (rx_nbr, store_nbr, fill_nbr, fill_partial_nbr)
in
( select rx_nbr, store_nbr, fill_nbr, fill_partial_nbr
from $pTDStageDB.etl_tbf0_fill
where cdc_operation_type_cd = 'INSERT'
group by rx_nbr, store_nbr, fill_nbr, fill_partial_nbr
having count(distinct fill_enter_dttm) > 1 )""",
    [])
  ])
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING DUPLICATES WITHIN THE SAME BATCH
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_fill
where (rx_nbr, store_nbr, fill_nbr, fill_partial_nbr)
in
( select rx_nbr, store_nbr, fill_nbr, fill_partial_nbr
from $pTDStageDB.etl_tbf0_fill
where cdc_operation_type_cd = 'INSERT'
group by rx_nbr, store_nbr, fill_nbr, fill_partial_nbr
having count(distinct fill_enter_dttm) > 1 )""",
    [])
  ])
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #----------------------------------------------------
  #-- THESE SQLS ARE USED TO REMOVE THE RECORDS FROM ETL STAGE WHICH ARE UPDATES/PK UPDATES BEFORE AN INSERT
  #----------------------------------------------------
  executeSql([], [
    ("""delete from $APT_TERA_SYNC_DATABASE.ETL_TBF0_FILL_CHANGE_ANALYSIS""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $APT_TERA_SYNC_DATABASE.ETL_TBF0_FILL_CHANGE_ANALYSIS
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type          
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr
)
SELECT  
STG.cdc_txn_commit_dttm           
,STG.cdc_seq_nbr                   
,STG.cdc_rba_nbr                   
,STG.cdc_operation_type_cd         
,STG.cdc_before_after_cd           
,STG.cdc_txn_position_cd           
,STG.edw_batch_id                  
,STG.store_nbr                     
,STG.rx_nbr                        
,STG.fill_nbr                      
,STG.fill_partial_nbr              
,STG.fill_status_cd                
,STG.fill_qty_dispensed            
,STG.fill_awp_cost_amt             
,STG.fill_discount_cd              
,STG.fill_discount_amt             
,STG.fill_retail_price_amt         
,STG.fill_sold_amt                 
,STG.fill_enter_user_id            
,STG.fill_enter_dttm               
,STG.fill_verified_user_id         
,STG.fill_verified_dttm            
,STG.fill_sold_dttm                
,STG.plan_id                       
,STG.fill_type_cd                  
,STG.partial_fill_cd               
,STG.fill_deleted_dttm             
,STG.fill_data_rev_id              
,STG.fill_data_rev_dttm            
,STG.filling_user_id               
,STG.filling_dttm                  
,STG.entered_store_nbr             
,STG.reviewed_store_nbr            
,STG.fill_nbr_dispensed            
,STG.fill_adjudication_dttm        
,STG.fill_adjudication_cd          
,STG.cob_claim_ref_nbr             
,STG.claim_reference_nbr           
,STG.update_user_id                
,STG.update_dttm                   
,STG.cob_fill_adjudication_cd      
,STG.cob_plan_id                   
,STG.override_user_id              
,STG.override_dttm                 
,STG.cob_fill_adj_dttm             
,STG.src_partition_nbr             
,STG.fill_days_supply              
,STG.fill_label_price_amt          
,STG.fill_pay_method_cd            
,STG.plan_ar_amt                   
,STG.plan_copay_amt                
,STG.plan_tax_amt                  
,STG.cob_plan_ar_amt               
,STG.cob_plan_copay_amt            
,STG.cob_plan_tax_amt              
,STG.FILL_PRICE_OVERRIDE_AMT       
,STG.GENERAL_RECIPIENT_NBR         
,STG.ACCEPT_CONSULT_IND            
,STG.PLAN_OTHER_AMT                
,STG.CASH_DISC_SAV_AMT             
,STG.ROUTING_STORE_TECH_INITS      
,STG.FAX_IMAGE_ID                  
,STG.DL_REJECT_CD_01               
,STG.COB_DL_REJECT_CD_01           
,STG.DATA_REV_SPEC_ID              
,STG.DATA_REV_SPEC_STORE_NBR       
,STG.FILL_RPH_OF_RECORD_ID         
,STG.data_rev_spec_dttm            
,STG.relocate_fm_str_nbr           
,STG.cob_gen_recipient_nbr
,STG.cob_dl_reject_cd_02
,STG.cob_dl_reject_cd_03
,STG.cob_dl_reject_cd_04
,STG.cob_dl_reject_cd_05
,STG.amt_attributed_to_tax
,STG.cob_plan_gross_due_amt
,STG.cob_pln_incnt_amt_submtd
,STG.plan_gross_due_amt
,STG.plan_incent_amt_submtd
,STG.plan_incentive_paid_amt
,STG.plan_other_amt_paid
,STG.plan_returnd_coins_amt
,STG.plan_returnd_copay_amt
,STG.plan_returnd_cost_amt
,STG.plan_returnd_fee_amt
,STG.plan_returnd_tax_amt
,STG.plan_rtrnd_coins_amt
,STG.plan_total_paid_amt
,STG.plan_other_amt_paid_type          
,STG.med_partd_notice_ind
,STG.med_partd_print_dttm
,STG.ben_stg_qualifier_1
,STG.ben_stg_qualifier_2
,STG.ben_stg_qualifier_3
,STG.ben_stg_qualifier_4
,STG.ben_stg_amount_1
,STG.ben_stg_amount_2
,STG.ben_stg_amount_3
,STG.ben_stg_amount_4
,STG.coupon_drug_id
,STG.cob_coupon_drug_id
,STG.coupon_ind
,STG.cob_coupon_ind
,STG.other_coverage_cd
,STG.cob_other_coverage_cd
, STG.org_entered_dttm
, STG.pat_pickup_gov_auth_id
, STG.pat_pickup_id_qlfr
, STG.pat_pickup_rel_cd
, STG.source_system_name
, STG.source_sys_trans_id
, STG.prior_auth_cd
, STG.prior_auth_nbr

FROM  
( 
SELECT rx_nbr,store_nbr, fill_nbr, fill_partial_nbr, fill_enter_dttm, max(cdc_txn_commit_dttm) max_cdc_dttm 
FROM $pTDStageDB.ETL_TBF0_FILL 
WHERE cdc_operation_type_cd='INSERT' 
GROUP BY 1,2,3,4,5) MX_INS, 
$pTDStageDB.ETL_TBF0_FILL stg 
WHERE STG.STORE_NBR=MX_INS.STORE_NBR 
AND STG.RX_NBR=MX_INS.RX_NBR 
AND STG.FILL_NBR=MX_INS.FILL_NBR
AND STG.FILL_PARTIAL_NBR=MX_INS.FILL_PARTIAL_NBR
AND STG.FILL_ENTER_DTTM=MX_INS.FILL_ENTER_DTTM
AND STG.CDC_TXN_COMMIT_DTTM < MX_INS.max_CDC_DTTM""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.ETL_TBF0_FILL STG 
using $APT_TERA_SYNC_DATABASE.ETL_TBF0_FILL_CHANGE_ANALYSIS PROC 
WHERE STG.STORE_NBR=PROC.STORE_NBR
AND STG.RX_NBR=PROC.RX_NBR
AND STG.FILL_NBR=PROC.FILL_NBR
AND STG.FILL_PARTIAL_NBR=PROC.FILL_PARTIAL_NBR
AND STG.FILL_ENTER_DTTM=PROC.FILL_ENTER_DTTM
AND STG.CDC_TXN_COMMIT_DTTM = PROC.CDC_TXN_COMMIT_DTTM
AND STG.CDC_RBA_NBR = PROC.CDC_RBA_NBR
AND STG.CDC_SEQ_NBR = PROC.CDC_SEQ_NBR
AND STG.CDC_BEFORE_AFTER_CD = PROC.CDC_BEFORE_AFTER_CD
AND STG.CDC_OPERATION_TYPE_CD = PROC.CDC_OPERATION_TYPE_CD
AND STG.CDC_TXN_POSITION_CD = PROC.CDC_TXN_POSITION_CD""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #------------------------------------------------------
  #-- STARTING THE DUP LOGIC FROM HERE ON
  #------------------------------------------------------
  #------------------------------------------------------
  #------------------------------------------------------
  #-- DELETING TEST STORES
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_fill
 where store_nbr in
   (select store_nbr from $pTDStageDB.etl_proc_test_store)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM RX DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_fill
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type          
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr
)
select 
RXT.cdc_txn_commit_dttm           
,RXT.cdc_seq_nbr                   
,RXT.cdc_rba_nbr                   
,RXT.cdc_operation_type_cd         
,RXT.cdc_before_after_cd           
,RXT.cdc_txn_position_cd           
,RXT.edw_batch_id                  
,RXT.store_nbr                     
,RXT.rx_nbr                        
,RXT.fill_nbr                      
,RXT.fill_partial_nbr              
,RXT.fill_status_cd                
,RXT.fill_qty_dispensed            
,RXT.fill_awp_cost_amt             
,RXT.fill_discount_cd              
,RXT.fill_discount_amt             
,RXT.fill_retail_price_amt         
,RXT.fill_sold_amt                 
,RXT.fill_enter_user_id            
,RXT.fill_enter_dttm               
,RXT.fill_verified_user_id         
,RXT.fill_verified_dttm            
,RXT.fill_sold_dttm                
,RXT.plan_id                       
,RXT.fill_type_cd                  
,RXT.partial_fill_cd               
,RXT.fill_deleted_dttm             
,RXT.fill_data_rev_id              
,RXT.fill_data_rev_dttm            
,RXT.filling_user_id               
,RXT.filling_dttm                  
,RXT.entered_store_nbr             
,RXT.reviewed_store_nbr            
,RXT.fill_nbr_dispensed            
,RXT.fill_adjudication_dttm        
,RXT.fill_adjudication_cd          
,RXT.cob_claim_ref_nbr             
,RXT.claim_reference_nbr           
,RXT.update_user_id                
,RXT.update_dttm                   
,RXT.cob_fill_adjudication_cd      
,RXT.cob_plan_id                   
,RXT.override_user_id              
,RXT.override_dttm                 
,RXT.cob_fill_adj_dttm             
,RXT.src_partition_nbr             
,RXT.fill_days_supply              
,RXT.fill_label_price_amt          
,RXT.fill_pay_method_cd            
,RXT.plan_ar_amt                   
,RXT.plan_copay_amt                
,RXT.plan_tax_amt                  
,RXT.cob_plan_ar_amt               
,RXT.cob_plan_copay_amt            
,RXT.cob_plan_tax_amt              
,RXT.FILL_PRICE_OVERRIDE_AMT       
,RXT.GENERAL_RECIPIENT_NBR         
,RXT.ACCEPT_CONSULT_IND            
,RXT.PLAN_OTHER_AMT                
,RXT.CASH_DISC_SAV_AMT             
,RXT.ROUTING_STORE_TECH_INITS      
,RXT.FAX_IMAGE_ID                  
,RXT.DL_REJECT_CD_01               
,RXT.COB_DL_REJECT_CD_01           
,RXT.DATA_REV_SPEC_ID              
,RXT.DATA_REV_SPEC_STORE_NBR       
,RXT.FILL_RPH_OF_RECORD_ID         
,RXT.data_rev_spec_dttm            
,RXT.relocate_fm_str_nbr           
,RXT.cob_gen_recipient_nbr
,RXT.cob_dl_reject_cd_02
,RXT.cob_dl_reject_cd_03
,RXT.cob_dl_reject_cd_04
,RXT.cob_dl_reject_cd_05
,RXT.amt_attributed_to_tax
,RXT.cob_plan_gross_due_amt
,RXT.cob_pln_incnt_amt_submtd
,RXT.plan_gross_due_amt
,RXT.plan_incent_amt_submtd
,RXT.plan_incentive_paid_amt
,RXT.plan_other_amt_paid
,RXT.plan_returnd_coins_amt
,RXT.plan_returnd_copay_amt
,RXT.plan_returnd_cost_amt
,RXT.plan_returnd_fee_amt
,RXT.plan_returnd_tax_amt
,RXT.plan_rtrnd_coins_amt
,RXT.plan_total_paid_amt
,RXT.plan_other_amt_paid_type          
,RXT.med_partd_notice_ind
,RXT.med_partd_print_dttm
,RXT.ben_stg_qualifier_1
,RXT.ben_stg_qualifier_2
,RXT.ben_stg_qualifier_3
,RXT.ben_stg_qualifier_4
,RXT.ben_stg_amount_1
,RXT.ben_stg_amount_2
,RXT.ben_stg_amount_3
,RXT.ben_stg_amount_4
,RXT.coupon_drug_id
,RXT.cob_coupon_drug_id
,RXT.coupon_ind
,RXT.cob_coupon_ind
,RXT.other_coverage_cd
,RXT.cob_other_coverage_cd
, RXT.org_entered_dttm
, RXT.pat_pickup_gov_auth_id
, RXT.pat_pickup_id_qlfr
, RXT.pat_pickup_rel_cd
, RXT.source_system_name
, RXT.source_sys_trans_id
, RXT.prior_auth_cd
, RXT.prior_auth_nbr

from $pTDStageDB.etl_tbf0_fill RXT,
   (SELECT store_nbr, rx_nbr, MAX(create_dttm) create_dttm FROM $pTDStageDB.etl_proc_dup_rx
  GROUP BY store_nbr, rx_nbr ) DUP
where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
AND CAST( RXT.fill_enter_dttm AS DATE) <= CAST( DUP.create_dttm AS DATE) + 730""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING DUPS PRESENT IN THE RX DUPS TABLE
  #------------------------------------------------------  
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_fill RXT 
where (store_nbr, rx_nbr, fill_enter_dttm) IN
 (SELECT FILL.store_nbr, FILL.rx_nbr, FILL.fill_enter_dttm
from $pTDStageDB.etl_tbf0_fill FILL,
   (SELECT store_nbr, rx_nbr, MAX(create_dttm) create_dttm FROM $pTDStageDB.etl_proc_dup_rx
  GROUP BY store_nbr, rx_nbr ) DUP
where FILL.store_nbr = DUP.store_nbr
 and FILL.rx_nbr = DUP.rx_nbr
AND CAST( FILL.fill_enter_dttm AS DATE) <= CAST( DUP.create_dttm AS DATE) + 730
)""",
    [])
  ])
  #-- DEL_WITH_JOIN - reformat only because there is no join in delete statement
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM FILL DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_fill
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type          
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr
)
select 
RXT.cdc_txn_commit_dttm           
,RXT.cdc_seq_nbr                   
,RXT.cdc_rba_nbr                   
,RXT.cdc_operation_type_cd         
,RXT.cdc_before_after_cd           
,RXT.cdc_txn_position_cd           
,RXT.edw_batch_id                  
,RXT.store_nbr                     
,RXT.rx_nbr                        
,RXT.fill_nbr                      
,RXT.fill_partial_nbr              
,RXT.fill_status_cd                
,RXT.fill_qty_dispensed            
,RXT.fill_awp_cost_amt             
,RXT.fill_discount_cd              
,RXT.fill_discount_amt             
,RXT.fill_retail_price_amt         
,RXT.fill_sold_amt                 
,RXT.fill_enter_user_id            
,RXT.fill_enter_dttm               
,RXT.fill_verified_user_id         
,RXT.fill_verified_dttm            
,RXT.fill_sold_dttm                
,RXT.plan_id                       
,RXT.fill_type_cd                  
,RXT.partial_fill_cd               
,RXT.fill_deleted_dttm             
,RXT.fill_data_rev_id              
,RXT.fill_data_rev_dttm            
,RXT.filling_user_id               
,RXT.filling_dttm                  
,RXT.entered_store_nbr             
,RXT.reviewed_store_nbr            
,RXT.fill_nbr_dispensed            
,RXT.fill_adjudication_dttm        
,RXT.fill_adjudication_cd          
,RXT.cob_claim_ref_nbr             
,RXT.claim_reference_nbr           
,RXT.update_user_id                
,RXT.update_dttm                   
,RXT.cob_fill_adjudication_cd      
,RXT.cob_plan_id                   
,RXT.override_user_id              
,RXT.override_dttm                 
,RXT.cob_fill_adj_dttm             
,RXT.src_partition_nbr             
,RXT.fill_days_supply              
,RXT.fill_label_price_amt          
,RXT.fill_pay_method_cd            
,RXT.plan_ar_amt                   
,RXT.plan_copay_amt                
,RXT.plan_tax_amt                  
,RXT.cob_plan_ar_amt               
,RXT.cob_plan_copay_amt            
,RXT.cob_plan_tax_amt              
,RXT.FILL_PRICE_OVERRIDE_AMT       
,RXT.GENERAL_RECIPIENT_NBR         
,RXT.ACCEPT_CONSULT_IND            
,RXT.PLAN_OTHER_AMT                
,RXT.CASH_DISC_SAV_AMT             
,RXT.ROUTING_STORE_TECH_INITS      
,RXT.FAX_IMAGE_ID                  
,RXT.DL_REJECT_CD_01               
,RXT.COB_DL_REJECT_CD_01           
,RXT.DATA_REV_SPEC_ID              
,RXT.DATA_REV_SPEC_STORE_NBR       
,RXT.FILL_RPH_OF_RECORD_ID         
,RXT.data_rev_spec_dttm            
,RXT.relocate_fm_str_nbr           
,RXT.cob_gen_recipient_nbr
,RXT.cob_dl_reject_cd_02
,RXT.cob_dl_reject_cd_03
,RXT.cob_dl_reject_cd_04
,RXT.cob_dl_reject_cd_05
,RXT.amt_attributed_to_tax
,RXT.cob_plan_gross_due_amt
,RXT.cob_pln_incnt_amt_submtd
,RXT.plan_gross_due_amt
,RXT.plan_incent_amt_submtd
,RXT.plan_incentive_paid_amt
,RXT.plan_other_amt_paid
,RXT.plan_returnd_coins_amt
,RXT.plan_returnd_copay_amt
,RXT.plan_returnd_cost_amt
,RXT.plan_returnd_fee_amt
,RXT.plan_returnd_tax_amt
,RXT.plan_rtrnd_coins_amt
,RXT.plan_total_paid_amt
,RXT.plan_other_amt_paid_type          
,RXT.med_partd_notice_ind
,RXT.med_partd_print_dttm
,RXT.ben_stg_qualifier_1
,RXT.ben_stg_qualifier_2
,RXT.ben_stg_qualifier_3
,RXT.ben_stg_qualifier_4
,RXT.ben_stg_amount_1
,RXT.ben_stg_amount_2
,RXT.ben_stg_amount_3
,RXT.ben_stg_amount_4
,RXT.coupon_drug_id
,RXT.cob_coupon_drug_id
,RXT.coupon_ind
,RXT.cob_coupon_ind
,RXT.other_coverage_cd
,RXT.cob_other_coverage_cd
, RXT.org_entered_dttm
, RXT.pat_pickup_gov_auth_id
, RXT.pat_pickup_id_qlfr
, RXT.pat_pickup_rel_cd
, RXT.source_system_name
, RXT.source_sys_trans_id
, RXT.prior_auth_cd
, RXT.prior_auth_nbr

from $pTDStageDB.etl_tbf0_fill RXT,
  $pTDStageDB.etl_proc_dup_fill DUP
 where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
 and RXT.fill_enter_dttm = DUP.fill_enter_dttm""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM FILL DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_fill RXT 
using $pTDStageDB.etl_proc_dup_fill DUP 
where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
 and RXT.fill_enter_dttm = DUP.fill_enter_dttm""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM TRANS DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_fill
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type          
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr
)
select 
RXT.cdc_txn_commit_dttm           
,RXT.cdc_seq_nbr                   
,RXT.cdc_rba_nbr                   
,RXT.cdc_operation_type_cd         
,RXT.cdc_before_after_cd           
,RXT.cdc_txn_position_cd           
,RXT.edw_batch_id                  
,RXT.store_nbr                     
,RXT.rx_nbr                        
,RXT.fill_nbr                      
,RXT.fill_partial_nbr              
,RXT.fill_status_cd                
,RXT.fill_qty_dispensed            
,RXT.fill_awp_cost_amt             
,RXT.fill_discount_cd              
,RXT.fill_discount_amt             
,RXT.fill_retail_price_amt         
,RXT.fill_sold_amt                 
,RXT.fill_enter_user_id            
,RXT.fill_enter_dttm               
,RXT.fill_verified_user_id         
,RXT.fill_verified_dttm            
,RXT.fill_sold_dttm                
,RXT.plan_id                       
,RXT.fill_type_cd                  
,RXT.partial_fill_cd               
,RXT.fill_deleted_dttm             
,RXT.fill_data_rev_id              
,RXT.fill_data_rev_dttm            
,RXT.filling_user_id               
,RXT.filling_dttm                  
,RXT.entered_store_nbr             
,RXT.reviewed_store_nbr            
,RXT.fill_nbr_dispensed            
,RXT.fill_adjudication_dttm        
,RXT.fill_adjudication_cd          
,RXT.cob_claim_ref_nbr             
,RXT.claim_reference_nbr           
,RXT.update_user_id                
,RXT.update_dttm                   
,RXT.cob_fill_adjudication_cd      
,RXT.cob_plan_id                   
,RXT.override_user_id              
,RXT.override_dttm                 
,RXT.cob_fill_adj_dttm             
,RXT.src_partition_nbr             
,RXT.fill_days_supply              
,RXT.fill_label_price_amt          
,RXT.fill_pay_method_cd            
,RXT.plan_ar_amt                   
,RXT.plan_copay_amt                
,RXT.plan_tax_amt                  
,RXT.cob_plan_ar_amt               
,RXT.cob_plan_copay_amt            
,RXT.cob_plan_tax_amt              
,RXT.FILL_PRICE_OVERRIDE_AMT       
,RXT.GENERAL_RECIPIENT_NBR         
,RXT.ACCEPT_CONSULT_IND            
,RXT.PLAN_OTHER_AMT                
,RXT.CASH_DISC_SAV_AMT             
,RXT.ROUTING_STORE_TECH_INITS      
,RXT.FAX_IMAGE_ID                  
,RXT.DL_REJECT_CD_01               
,RXT.COB_DL_REJECT_CD_01           
,RXT.DATA_REV_SPEC_ID              
,RXT.DATA_REV_SPEC_STORE_NBR       
,RXT.FILL_RPH_OF_RECORD_ID         
,RXT.data_rev_spec_dttm            
,RXT.relocate_fm_str_nbr           
,RXT.cob_gen_recipient_nbr
,RXT.cob_dl_reject_cd_02
,RXT.cob_dl_reject_cd_03
,RXT.cob_dl_reject_cd_04
,RXT.cob_dl_reject_cd_05
,RXT.amt_attributed_to_tax
,RXT.cob_plan_gross_due_amt
,RXT.cob_pln_incnt_amt_submtd
,RXT.plan_gross_due_amt
,RXT.plan_incent_amt_submtd
,RXT.plan_incentive_paid_amt
,RXT.plan_other_amt_paid
,RXT.plan_returnd_coins_amt
,RXT.plan_returnd_copay_amt
,RXT.plan_returnd_cost_amt
,RXT.plan_returnd_fee_amt
,RXT.plan_returnd_tax_amt
,RXT.plan_rtrnd_coins_amt
,RXT.plan_total_paid_amt
,RXT.plan_other_amt_paid_type          
,RXT.med_partd_notice_ind
,RXT.med_partd_print_dttm
,RXT.ben_stg_qualifier_1
,RXT.ben_stg_qualifier_2
,RXT.ben_stg_qualifier_3
,RXT.ben_stg_qualifier_4
,RXT.ben_stg_amount_1
,RXT.ben_stg_amount_2
,RXT.ben_stg_amount_3
,RXT.ben_stg_amount_4
,RXT.coupon_drug_id
,RXT.cob_coupon_drug_id
,RXT.coupon_ind
,RXT.cob_coupon_ind
,RXT.other_coverage_cd
,RXT.cob_other_coverage_cd
, RXT.org_entered_dttm
, RXT.pat_pickup_gov_auth_id
, RXT.pat_pickup_id_qlfr
, RXT.pat_pickup_rel_cd
, RXT.source_system_name
, RXT.source_sys_trans_id
, RXT.prior_auth_cd
, RXT.prior_auth_nbr

from $pTDStageDB.etl_tbf0_fill RXT,
  $pTDStageDB.etl_proc_dup_rx_tran DUP
 where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
 and RXT.fill_enter_dttm = DUP.fill_entered_dttm""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM TRANS DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_fill RXT 
using $pTDStageDB.etl_proc_dup_rx_tran DUP 
where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
  and RXT.fill_enter_dttm = DUP.fill_entered_dttm""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #-------------------------------------------
  #-- Creating performance table. This would be referred in all other processes instead of target table when applicable
  #-------------------------------------------
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.ETL_PROC_FILL_FILL""",
    [])
  ])
  #-- DEL_ALL - Remove ALL keyword from DELETE statement
  if (Action.errorCode != 0):
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.ETL_PROC_FILL_FILL
(
	RX_NBR
	,STR_NBR
	,RX_CREATE_DT
	,RX_FILL_NBR
	,RX_PARTIAL_FILL_NBR
	,DSPN_FILL_NBR
	,PARTIAL_FILL_CD
	,PAT_ID
	,PBR_ID
	,PBR_LOC_ID
	,FILL_SOLD_DT
	,FILL_SOLD_TM
	,FILL_SOLD_DLRS
	,FILL_STAT_CD
	,FILL_QTY_DSPN
	,FILL_PAY_METHOD_CD
	,FILL_DAYS_SUPPLY
	,FILL_AWP_COST_DLRS
	,FILL_DISCNT_CD
	,FILL_DISCNT_DLRS
	,FILL_RTL_PRICE_DLRS
	,FILL_LABEL_PRICE_DLRS
	,FILL_VRFY_USER_ID
	,FILL_VRFY_DT
	,FILL_VRFY_TM
	,FILL_TYPE_CD
	,FILL_DEL_DT
	,FILL_DEL_TM
	,FILL_DATA_REVIEW_USER_ID
	,FILL_DATA_REVIEW_DT
	,FILL_DATA_REVIEW_TM
	,FILL_ENTER_USER_ID
	,FILL_ENTER_DT
	,FILL_ENTER_TM
	,FILL_SRC_CD
	,FILL_WAC_DLRS
	,FILLING_USER_ID
	,FILLING_DT
	,FILLING_TM
	,FILL_ENTER_STR_NBR
	,FILL_REVIEW_STR_NBR
	,DRUG_ID
	,DRUG_NAME
	,DEA_CLASS_CD
	,REFILLS_REMAIN_CNT
	,ORIG_REFILLS_REMAIN_WHEN_ENTER
	,TOT_AMT_PAID_IND
	,SIMS_UPC
	,OVERRIDE_USER_ID
	,OVERRIDE_DT
	,OVERRIDE_TM
	,RELOCATE_FM_STR_NBR
	,CREATE_USER_ID
	,CREATE_DTTM
	,EDW_BATCH_ID
	,UPDATE_USER_ID
	,UPDATE_DTTM
	,SRC_PARTITION_NBR
	,accept_consult_ind
	,cash_disc_sav_dlrs
	,data_rev_spec_dttm
	,data_rev_spec_id
	,data_rev_spec_str_nbr
	,fax_image_id
	,fill_price_override_dlrs
	,fill_rph_of_rec_id
	,route_str_tech_inits
	,drug_whse_ind
	,lvl_of_svc_cd
	,rx_daw_ind
	,sourcing_ind
	,tip_rsn_for_svc_cd
	,fill_est_pick_up_dttm
	,cost_plus_fee_cd
	,fill_print_dt
	,fill_print_tm
	,pat_language_pref_cd
	,fill_rebill_dt
	,fill_rebill_tm
	,medicare_d_nte_ind
	,medicare_d_print_dttm
	, partial_fill_tot_intended_qty
	, triplicate_ser_nbr
	, delivery_cd
	, delivery_cmnts
	, fill_sold_local_dttm
	, orig_enter_dttm
	, pat_pickup_gov_auth
	, pat_pickup_id_qlfr
	, pat_pickup_relation_cd
	, route_str_rph_initials
	, src_sys_name
	, src_sys_txn_id
	, sys_stat_when_enter
)
SELECT  
	TFILL.RX_NBR
	,TFILL.STR_NBR
	,TFILL.RX_CREATE_DT
	,TFILL.RX_FILL_NBR
	,TFILL.RX_PARTIAL_FILL_NBR
	,TFILL.DSPN_FILL_NBR
	,TFILL.PARTIAL_FILL_CD
	,TFILL.PAT_ID
	,TFILL.PBR_ID
	,TFILL.PBR_LOC_ID
	,TFILL.FILL_SOLD_DT
	,TFILL.FILL_SOLD_TM
	,TFILL.FILL_SOLD_DLRS
	,TFILL.FILL_STAT_CD
	,TFILL.FILL_QTY_DSPN
	,TFILL.FILL_PAY_METHOD_CD
	,TFILL.FILL_DAYS_SUPPLY
	,TFILL.FILL_AWP_COST_DLRS
	,TFILL.FILL_DISCNT_CD
	,TFILL.FILL_DISCNT_DLRS
	,TFILL.FILL_RTL_PRICE_DLRS
	,TFILL.FILL_LABEL_PRICE_DLRS
	,TFILL.FILL_VRFY_USER_ID
	,TFILL.FILL_VRFY_DT
	,TFILL.FILL_VRFY_TM
	,TFILL.FILL_TYPE_CD
	,TFILL.FILL_DEL_DT
	,TFILL.FILL_DEL_TM
	,TFILL.FILL_DATA_REVIEW_USER_ID
	,TFILL.FILL_DATA_REVIEW_DT
	,TFILL.FILL_DATA_REVIEW_TM
	,TFILL.FILL_ENTER_USER_ID
	,TFILL.FILL_ENTER_DT
	,TFILL.FILL_ENTER_TM
	,TFILL.FILL_SRC_CD
	,TFILL.FILL_WAC_DLRS
	,TFILL.FILLING_USER_ID
	,TFILL.FILLING_DT
	,TFILL.FILLING_TM
	,TFILL.FILL_ENTER_STR_NBR
	,TFILL.FILL_REVIEW_STR_NBR
	,TFILL.DRUG_ID
	,TFILL.DRUG_NAME
	,TFILL.DEA_CLASS_CD
	,TFILL.REFILLS_REMAIN_CNT
	,TFILL.ORIG_REFILLS_REMAIN_WHEN_ENTER
	,TFILL.TOT_AMT_PAID_IND
	,TFILL.SIMS_UPC
	,TFILL.OVERRIDE_USER_ID
	,TFILL.OVERRIDE_DT
	,TFILL.OVERRIDE_TM
	,TFILL.RELOCATE_FM_STR_NBR
	,TFILL.CREATE_USER_ID
	,TFILL.CREATE_DTTM
	,TFILL.EDW_BATCH_ID
	,TFILL.UPDATE_USER_ID
	,TFILL.UPDATE_DTTM
	,TFILL.SRC_PARTITION_NBR
	,TFILL.accept_consult_ind
	,TFILL.cash_disc_sav_dlrs
	,TFILL.data_rev_spec_dttm
	,TFILL.data_rev_spec_id
	,TFILL.data_rev_spec_str_nbr
	,TFILL.fax_image_id
	,TFILL.fill_price_override_dlrs
	,TFILL.fill_rph_of_rec_id
	,TFILL.route_str_tech_inits
	,TFILL.drug_whse_ind
	,TFILL.lvl_of_svc_cd
	,TFILL.rx_daw_ind
	,TFILL.sourcing_ind
	,TFILL.tip_rsn_for_svc_cd
	,TFILL.fill_est_pick_up_dttm
	,TFILL.cost_plus_fee_cd
	,TFILL.fill_print_dt
	,TFILL.fill_print_tm
	,TFILL.pat_language_pref_cd
	,TFILL.fill_rebill_dt
	,TFILL.fill_rebill_tm
	,TFILL.medicare_d_nte_ind 
	,TFILL.medicare_d_print_dttm
	, TFILL.partial_fill_tot_intended_qty
	, TFILL.triplicate_ser_nbr
	, TFILL.delivery_cd
	, TFILL.delivery_cmnts
	, TFILL.fill_sold_local_dttm
	, TFILL.orig_enter_dttm
	, TFILL.pat_pickup_gov_auth
	, TFILL.pat_pickup_id_qlfr
	, TFILL.pat_pickup_relation_cd
	, TFILL.route_str_rph_initials
	, TFILL.src_sys_name
	, TFILL.src_sys_txn_id
	, TFILL.sys_stat_when_enter  
     
FROM    $pTDViewDBName.prescription_fill TFILL,
                  (SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTER_DTTM
                     FROM $pTDStageDB.ETL_TBF0_FILL
                     GROUP BY RX_NBR, STORE_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM
 ) B
WHERE TFILL.RX_NBR = B.RX_NBR
AND     TFILL.STR_NBR = B.STORE_NBR
AND     TFILL.RX_FILL_NBR = B.FILL_NBR
AND     TFILL.RX_PARTIAL_FILL_NBR = B.FILL_PARTIAL_NBR""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("""call PRDUTIL.TABLE_STATS('$pTDStageDB', 'ETL_PROC_FILL_FILL')""",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  #-------------------------------------
  #----Creating temp table
  #------------------------------------
  executeSql([], [
    ("""CREATE temporary TABLE $pTDStageDB.V_dup_rx_fill
     (
      rx_nbr INTEGER NOT NULL,
      store_nbr INTEGER NOT NULL,
      fill_nbr SMALLINT,
      fill_partial_nbr BYTEINT,
      fill_enter_dttm TIMESTAMP)
ON COMMIT PRESERVE ROWS""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
  #-- TABLE_INDEX - Remove table index options
  #------------------------------------------------------
  #-- IDENTIFYING DUPLICATES BETWEEN ETL STAGE AND TARGET
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.V_dup_rx_fill 
 select STG.rx_nbr,
   STG.store_nbr,
   STG.fill_nbr,
   STG.fill_partial_nbr,
   STG.fill_enter_dttm
from $pTDStageDB.etl_tbf0_fill STG,
   $pTDStageDB.ETL_PROC_FILL_FILL TGT
 where STG.rx_nbr = TGT.rx_nbr
  and STG.store_nbr = TGT.str_nbr
  and STG.fill_nbr = TGT.rx_fill_nbr
  and STG.fill_partial_nbr = TGT.rx_partial_fill_nbr
and coalesce( STG.fill_enter_dttm  , cast( '1900-01-01 01:01:01' as timestamp(0)) ) <> CAST ( CAST ( TGT.fill_enter_dt AS CHAR(10 ) ) || ' ' || CAST ( TGT.fill_enter_tm AS CHAR(08 ) ) AS TIMESTAMP(0) ) 
  and TGT.fill_enter_dt >= CAST(STG.fill_enter_dttm AS DATE) - 730
and cdc_operation_type_cd='INSERT'
 group by STG.rx_nbr, STG.store_nbr,STG.fill_nbr, STG.fill_partial_nbr, STG.fill_enter_dttm""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- PUTTING THE RECORDS IN THE FILL DUPS TABLE FOR THE DUPLICATE INSERTS
  #------------------------------------------------------ 
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_fill
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type          
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr
)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr          
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr

from $pTDStageDB.etl_tbf0_fill
where (rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_enter_dttm)
in
( select rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_enter_dttm
from $pTDStageDB.V_dup_rx_fill )
and cdc_operation_type_cd = 'INSERT'""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING THE DUP INSERTS FROM ETL STAGE
  #------------------------------------------------------
  executeSql([], [
    ("""delete
from $pTDStageDB.etl_tbf0_fill
where (rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_enter_dttm)
in
( select rx_nbr, store_nbr, fill_nbr, fill_partial_nbr, fill_enter_dttm
from $pTDStageDB.V_dup_rx_fill )
and cdc_operation_type_cd = 'INSERT'""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #-----------------------------------------------------
  #-- THIS SQL IS RUN AGAIN TO REMOVE ALL THE REMAINING KEYS RELATED WITH THE PK UPDATE BEFORE/AFTER
  #------------------------------------------------------
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM FILL DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_fill
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type          
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr

)
select 
RXT.cdc_txn_commit_dttm           
,RXT.cdc_seq_nbr                   
,RXT.cdc_rba_nbr                   
,RXT.cdc_operation_type_cd         
,RXT.cdc_before_after_cd           
,RXT.cdc_txn_position_cd           
,RXT.edw_batch_id                  
,RXT.store_nbr                     
,RXT.rx_nbr                        
,RXT.fill_nbr                      
,RXT.fill_partial_nbr              
,RXT.fill_status_cd                
,RXT.fill_qty_dispensed            
,RXT.fill_awp_cost_amt             
,RXT.fill_discount_cd              
,RXT.fill_discount_amt             
,RXT.fill_retail_price_amt         
,RXT.fill_sold_amt                 
,RXT.fill_enter_user_id            
,RXT.fill_enter_dttm               
,RXT.fill_verified_user_id         
,RXT.fill_verified_dttm            
,RXT.fill_sold_dttm                
,RXT.plan_id                       
,RXT.fill_type_cd                  
,RXT.partial_fill_cd               
,RXT.fill_deleted_dttm             
,RXT.fill_data_rev_id              
,RXT.fill_data_rev_dttm            
,RXT.filling_user_id               
,RXT.filling_dttm                  
,RXT.entered_store_nbr             
,RXT.reviewed_store_nbr            
,RXT.fill_nbr_dispensed            
,RXT.fill_adjudication_dttm        
,RXT.fill_adjudication_cd          
,RXT.cob_claim_ref_nbr             
,RXT.claim_reference_nbr           
,RXT.update_user_id                
,RXT.update_dttm                   
,RXT.cob_fill_adjudication_cd      
,RXT.cob_plan_id                   
,RXT.override_user_id              
,RXT.override_dttm                 
,RXT.cob_fill_adj_dttm             
,RXT.src_partition_nbr             
,RXT.fill_days_supply              
,RXT.fill_label_price_amt          
,RXT.fill_pay_method_cd            
,RXT.plan_ar_amt                   
,RXT.plan_copay_amt                
,RXT.plan_tax_amt                  
,RXT.cob_plan_ar_amt               
,RXT.cob_plan_copay_amt            
,RXT.cob_plan_tax_amt              
,RXT.FILL_PRICE_OVERRIDE_AMT       
,RXT.GENERAL_RECIPIENT_NBR         
,RXT.ACCEPT_CONSULT_IND            
,RXT.PLAN_OTHER_AMT                
,RXT.CASH_DISC_SAV_AMT             
,RXT.ROUTING_STORE_TECH_INITS      
,RXT.FAX_IMAGE_ID                  
,RXT.DL_REJECT_CD_01               
,RXT.COB_DL_REJECT_CD_01           
,RXT.DATA_REV_SPEC_ID              
,RXT.DATA_REV_SPEC_STORE_NBR       
,RXT.FILL_RPH_OF_RECORD_ID         
,RXT.data_rev_spec_dttm            
,RXT.relocate_fm_str_nbr           
,RXT.cob_gen_recipient_nbr 
,RXT.cob_dl_reject_cd_02
,RXT.cob_dl_reject_cd_03
,RXT.cob_dl_reject_cd_04
,RXT.cob_dl_reject_cd_05
,RXT.amt_attributed_to_tax
,RXT.cob_plan_gross_due_amt
,RXT.cob_pln_incnt_amt_submtd
,RXT.plan_gross_due_amt
,RXT.plan_incent_amt_submtd
,RXT.plan_incentive_paid_amt
,RXT.plan_other_amt_paid
,RXT.plan_returnd_coins_amt
,RXT.plan_returnd_copay_amt
,RXT.plan_returnd_cost_amt
,RXT.plan_returnd_fee_amt
,RXT.plan_returnd_tax_amt
,RXT.plan_rtrnd_coins_amt
,RXT.plan_total_paid_amt
,RXT.plan_other_amt_paid_type         
,RXT.med_partd_notice_ind
,RXT.med_partd_print_dttm
,RXT.ben_stg_qualifier_1
,RXT.ben_stg_qualifier_2
,RXT.ben_stg_qualifier_3
,RXT.ben_stg_qualifier_4
,RXT.ben_stg_amount_1
,RXT.ben_stg_amount_2
,RXT.ben_stg_amount_3
,RXT.ben_stg_amount_4
,RXT.coupon_drug_id
,RXT.cob_coupon_drug_id
,RXT.coupon_ind
,RXT.cob_coupon_ind
,RXT.other_coverage_cd
,RXT.cob_other_coverage_cd
, RXT.org_entered_dttm
, RXT.pat_pickup_gov_auth_id
, RXT.pat_pickup_id_qlfr
, RXT.pat_pickup_rel_cd
, RXT.source_system_name
, RXT.source_sys_trans_id
, RXT.prior_auth_cd
, RXT.prior_auth_nbr

from $pTDStageDB.etl_tbf0_fill RXT,
  $pTDStageDB.etl_proc_dup_fill DUP
 where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
 and RXT.fill_enter_dttm = DUP.fill_enter_dttm""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM FILL DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_fill RXT 
using $pTDStageDB.etl_proc_dup_fill DUP 
where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr
  and RXT.fill_nbr = DUP.fill_nbr
 and RXT.fill_partial_nbr = DUP.fill_partial_nbr
  and RXT.fill_enter_dttm = DUP.fill_enter_dttm""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #----------------------------------------------------- 
  #-- CHECKING FOR UPDATES NOT EXISTING IN THE TARGET TABLE
  #------------------------------------------------------ 
  executeSql([], [
    ("""INSERT INTO $APT_TERA_SYNC_DATABASE.ETL_FILL_MISSING_UPDATES  
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type          
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr

)
SELECT 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_status_cd                
,fill_qty_dispensed            
,fill_awp_cost_amt             
,fill_discount_cd              
,fill_discount_amt             
,fill_retail_price_amt         
,fill_sold_amt                 
,fill_enter_user_id            
,fill_enter_dttm               
,fill_verified_user_id         
,fill_verified_dttm            
,fill_sold_dttm                
,plan_id                       
,fill_type_cd                  
,partial_fill_cd               
,fill_deleted_dttm             
,fill_data_rev_id              
,fill_data_rev_dttm            
,filling_user_id               
,filling_dttm                  
,entered_store_nbr             
,reviewed_store_nbr            
,fill_nbr_dispensed            
,fill_adjudication_dttm        
,fill_adjudication_cd          
,cob_claim_ref_nbr             
,claim_reference_nbr           
,update_user_id                
,update_dttm                   
,cob_fill_adjudication_cd      
,cob_plan_id                   
,override_user_id              
,override_dttm                 
,cob_fill_adj_dttm             
,src_partition_nbr             
,fill_days_supply              
,fill_label_price_amt          
,fill_pay_method_cd            
,plan_ar_amt                   
,plan_copay_amt                
,plan_tax_amt                  
,cob_plan_ar_amt               
,cob_plan_copay_amt            
,cob_plan_tax_amt              
,FILL_PRICE_OVERRIDE_AMT       
,GENERAL_RECIPIENT_NBR         
,ACCEPT_CONSULT_IND            
,PLAN_OTHER_AMT                
,CASH_DISC_SAV_AMT             
,ROUTING_STORE_TECH_INITS      
,FAX_IMAGE_ID                  
,DL_REJECT_CD_01               
,COB_DL_REJECT_CD_01           
,DATA_REV_SPEC_ID              
,DATA_REV_SPEC_STORE_NBR       
,FILL_RPH_OF_RECORD_ID         
,data_rev_spec_dttm            
,relocate_fm_str_nbr           
,cob_gen_recipient_nbr
,cob_dl_reject_cd_02
,cob_dl_reject_cd_03
,cob_dl_reject_cd_04
,cob_dl_reject_cd_05
,amt_attributed_to_tax
,cob_plan_gross_due_amt
,cob_pln_incnt_amt_submtd
,plan_gross_due_amt
,plan_incent_amt_submtd
,plan_incentive_paid_amt
,plan_other_amt_paid
,plan_returnd_coins_amt
,plan_returnd_copay_amt
,plan_returnd_cost_amt
,plan_returnd_fee_amt
,plan_returnd_tax_amt
,plan_rtrnd_coins_amt
,plan_total_paid_amt
,plan_other_amt_paid_type          
,med_partd_notice_ind
,med_partd_print_dttm
,ben_stg_qualifier_1
,ben_stg_qualifier_2
,ben_stg_qualifier_3
,ben_stg_qualifier_4
,ben_stg_amount_1
,ben_stg_amount_2
,ben_stg_amount_3
,ben_stg_amount_4
,coupon_drug_id
,cob_coupon_drug_id
,coupon_ind
,cob_coupon_ind
,other_coverage_cd
,cob_other_coverage_cd
, org_entered_dttm
, pat_pickup_gov_auth_id
, pat_pickup_id_qlfr
, pat_pickup_rel_cd
, source_system_name
, source_sys_trans_id
, prior_auth_cd
, prior_auth_nbr

 FROM $pTDStageDB.ETL_TBF0_FILL
WHERE (STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM) IN (
select STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM FROM
 (
SELECT STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM FROM $pTDStageDB.ETL_TBF0_FILL 
WHERE CDC_OPERATION_TYPE_CD='SQL COMPUPDATE'
MINUS
SELECT STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM FROM $pTDStageDB.ETL_TBF0_FILL 
WHERE CDC_OPERATION_TYPE_CD='INSERT'
)A
WHERE (STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM) NOT IN (
SELECT STR_NBR, RX_NBR,RX_FILL_NBR,RX_PARTIAL_FILL_NBR, COALESCE(CAST(fill_enter_dt||' '||CAST(fill_enter_tm AS CHAR(08)) AS TIMESTAMP(0) ), cast('2899-12-30 10:10:10' as timestamp(0))) 
FROM $pTDStageDB.ETL_PROC_FILL_FILL)
)""",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------ 
  #-- CHECKING FOR PK UPDATES(BEFORE AND AFTER) NOT EXISTING IN THE TARGET TABLE
  #------------------------------------------------------ 
  #/* This step is not required with unconditional logging#DELETE FROM $pTDStageDB.ETL_TBF0_FILL#WHERE (STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM,CDC_TXN_COMMIT_DTTM, CDC_SEQ_NBR,CDC_RBA_NBR) IN#(SELECT STORE_NBR, RX_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM,CDC_TXN_COMMIT_DTTM, CDC_SEQ_NBR,CDC_RBA_NBR FROM $APT_TERA_SYNC_DATABASE.ETL_FILL_MISSING_UPDATES)#;#--BC /*#--BC .if errorcode <> 0  then .quit 8#--BC #--BC /******* Build the Performance Tables ***********/
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.ETL_PROC_FILL_PRESC""",
    [])
  ])
  #-- DEL_ALL - Remove ALL keyword from DELETE statement
  if (Action.errorCode != 0):
    return
  executeSql([], [
    ("""insert into $pTDStageDB.ETL_PROC_FILL_PRESC
(
        RX_NBR
        ,STR_NBR
        ,RX_CREATE_DT
)
SELECT TRX.RX_NBR
 ,TRX.STR_NBR
 ,CASE WHEN  TRX.Rx_Create_dt  =  '2099-12-31'::DATE then null ELSE  TRX. Rx_Create_dt END
 from

 (SELECT Z.rx_nbr,Z.str_nbr, max(coalesce (Rx_Create_dt , '2099-12-31'::DATE)) Rx_Create_dt
    FROM  $pTDViewDBName.PRESCRIPTION Z,
                     (SELECT RX_NBR, STORE_NBR
                        FROM $pTDStageDB.ETL_TBF0_FILL
                        GROUP BY RX_NBR, STORE_NBR ) Y
   WHERE Z.RX_NBR = Y.RX_NBR
          AND Z.STR_NBR = Y.STORE_NBR
        group by 1,2 )  TRX""",
    [])
  ])
  #-- FUN_DATE_CAST - Reformat STRING-to-DATE casting
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("""call PRDUTIL.TABLE_STATS('$pTDStageDB', 'ETL_PROC_FILL_PRESC')""",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  return

main()
cleanup()
done()
ZZ


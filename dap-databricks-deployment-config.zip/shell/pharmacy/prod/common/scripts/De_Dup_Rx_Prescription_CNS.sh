#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
APT_TERA_SYNC_DATABASE=$7

python3 <<ZZ 
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  #--BC /*================================================================**
  #--BC ** PERFORM STORE RELO UPDATES FOR DEDUP TABLES                    **
  #--BC **================================================================*/
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg
 
set    store_nbr = R.relocate_to_str_nbr
 from   $pTDDBName.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg.store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** REMOVE PK UPDATES FOR STORE RELOS IN STAGE TABLES              **
  #--BC **================================================================*/
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg txn 
using $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg BFR, $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg AFT, $pTDDBName.location_store_relocation  SR 
where BFR.cdc_txn_commit_dttm = AFT.cdc_txn_commit_dttm
  and  BFR.cdc_seq_nbr = AFT.cdc_seq_nbr
  and  BFR.cdc_rba_nbr = AFT.cdc_rba_nbr
  and SR.relocate_fm_str_nbr = BFR.store_nbr
  and SR.relocate_to_str_nbr = AFT.store_nbr
  and  BFR.cdc_before_after_cd = 'BEFORE'
  and  AFT.cdc_before_after_cd = 'AFTER'
  and  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
  and  AFT.cdc_operation_type_cd = 'PK UPDATE'
  and BFR.store_nbr <> AFT.store_nbr
  and BFR.rx_nbr = AFT.rx_nbr
 
  and txn.cdc_txn_commit_dttm =  bfr.cdc_txn_commit_dttm
  and txn.cdc_seq_nbr =   bfr.cdc_seq_nbr
  and txn.cdc_rba_nbr =   bfr.cdc_rba_nbr
  and txn.cdc_operation_type_cd in ( 'PK UPDATE', 'SQL COMPUPDATE')""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** UPDATE STORE NUMBERS FOR STORE RELOS IN STAGE TABLES           **
  #--BC **================================================================*/
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
 
set store_nbr = SR.relocate_to_str_nbr
 from  $pTDDBName.location_store_relocation  SR
 where store_nbr = SR.relocate_fm_str_nbr""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** DEDUP LOGIC                                                    **
  #--BC **================================================================*/
  #------------------------------------------------------
  #-- IDENTIFYING MUTLIPLE INSERTS IN THE SAME BATCH 
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
)
select 
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
where (rx_nbr, store_nbr)
in
( select rx_nbr, store_nbr
from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
where cdc_operation_type_cd = 'INSERT'
group by rx_nbr, store_nbr
having count( distinct drug_non_system_name ) > 1 )""",
    [])
  ])
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETE MUTLIPLE INSERTS IN THE SAME BATCH
  #------------------------------------------------------
  executeSql([], [
    ("""delete
from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
where (rx_nbr, store_nbr)
in
( select rx_nbr, store_nbr
from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
where cdc_operation_type_cd = 'INSERT'
group by rx_nbr, store_nbr
having count( distinct drug_non_system_name ) > 1 )""",
    [])
  ])
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #----------------------------------------------------
  #-- THESE SQLS ARE USED TO REMOVE THE RECORDS FROM ETL STAGE WHICH ARE UPDATES/PK UPDATES BEFORE AN INSERT
  #----------------------------------------------------
  executeSql([], [
    ("""delete from $APT_TERA_SYNC_DATABASE.ETL_TBF0_CNS_CHANGE_ANALYSIS_STG""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $APT_TERA_SYNC_DATABASE.ETL_TBF0_CNS_CHANGE_ANALYSIS_STG
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
)
SELECT 
STG.cdc_txn_commit_dttm
,STG.cdc_seq_nbr
,STG.cdc_rba_nbr
,STG.cdc_operation_type_cd
,STG.cdc_before_after_cd
,STG.cdc_txn_position_cd
,STG.edw_batch_id
,STG.store_nbr
,STG.rx_nbr
,STG.drug_non_system_name
,STG.drug_assigned_ndc
,STG.drug_non_system_mfg_nm
,STG.priced_as_nonsys_ind
,STG.wic_nbr
,STG.src_partition_nbr
,STG.compound_type
,STG.dosage_form_cd
 FROM $pTDStageDB.ETL_TBF0_RX_CMPND_NONSYS_STG STG, 
( 
SELECT rx_nbr,store_nbr, max(cdc_txn_commit_dttm) max_cdc_dttm 
FROM $pTDStageDB.ETL_TBF0_RX_CMPND_NONSYS_STG 
WHERE cdc_operation_type_cd='INSERT' 
GROUP BY 1,2) MX_INS
WHERE STG.STORE_NBR=MX_INS.STORE_NBR 
AND STG.RX_NBR=MX_INS.RX_NBR 
AND STG.CDC_TXN_COMMIT_DTTM < MX_INS.max_CDC_DTTM""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.ETL_TBF0_RX_CMPND_NONSYS_STG STG 
using $APT_TERA_SYNC_DATABASE.ETL_TBF0_CNS_CHANGE_ANALYSIS_STG PROC 
WHERE STG.STORE_NBR=PROC.STORE_NBR
AND STG.RX_NBR=PROC.RX_NBR
AND STG.CDC_TXN_COMMIT_DTTM = PROC.CDC_TXN_COMMIT_DTTM
AND STG.CDC_RBA_NBR = PROC.CDC_RBA_NBR
AND STG.CDC_SEQ_NBR = PROC.CDC_SEQ_NBR
AND STG.CDC_BEFORE_AFTER_CD = PROC.CDC_BEFORE_AFTER_CD
AND STG.CDC_OPERATION_TYPE_CD = PROC.CDC_OPERATION_TYPE_CD
AND STG.CDC_TXN_POSITION_CD = PROC.CDC_TXN_POSITION_CD""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #------------------------------------------------------
  #-- STARTING THE DUP LOGIC FROM HERE ON
  #------------------------------------------------------
  #------------------------------------------------------
  #------------------------------------------------------
  #-- DELETING TEST STORES
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
 where store_nbr in
   (select store_nbr from $pTDStageDB.etl_proc_test_store_stg)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING AND REMOVING DUPS FROM RX DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
)
select 
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
 from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
where (store_nbr,rx_nbr) IN
(select store_nbr ,rx_nbr FROM $pTDStageDB.etl_proc_dup_rx_stg)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING DUPS PRESENT IN THE RX DUPS TABLE
  #------------------------------------------------------ 
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
where (store_nbr,rx_nbr) IN
(select store_nbr ,rx_nbr FROM $pTDStageDB.etl_proc_dup_rx_stg)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- CREATING TEMP TABLE TO STORE TEMP DATA
  #------------------------------------------------------
  executeSql([], [
    ("""create temporary table $pTDStageDB.V_dup_rx_inserts
(store_nbr    integer not null,
 rx_nbr       integer not null)
on commit preserve rows""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- TABLE_INDEX - Remove table index options
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- IDENTIFYING DUPLICATES BETWEEN ETL STAGE AND TARGET
  #------------------------------------------------------
  #--BC /*
  #--BC =================================================================================
  #--BC CHANGED THE LOGIC AS PART OF PHARMACY SQL OPTIMIZATION ON 2018-03-20 BY SUPPORT TEAM.
  #--BC BELOW SQL HAS BEEN MODIFIED TO INCLUDE OLAP FUNCTION TO REMOVE SUB-QUERY WHICH WAS DOING FTS ON PRESCRIPTION TABLE TWICE. 
  #--BC NOW IT IS ACCESSING TABLE PRESCRIPTION ONLY ONCE.
  #--BC ==================================================================================
  #--BC */
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.V_dup_rx_inserts
SELECT  stg1.STORE_NBR, stg1.RX_NBR 
FROM
(
SELECT DISTINCT tgt.STR_NBR, tgt.RX_NBR, tgt.drug_non_sys_name
FROM $pTDViewDBName.PRESCRIPTION TGT
JOIN $pTDStageDB.ETL_TBF0_RX_CMPND_NONSYS_STG STG
ON STG.rx_nbr = TGT.rx_nbr
AND STG.store_nbr = TGT.str_nbr
QUALIFY ROW_NUMBER() OVER (PARTITION BY tgt.STR_NBR, tgt.RX_NBR ORDER BY COALESCE(tgt.Rx_Create_dt, '2099-12-31'::DATE) DESC) = 1
)tgt1,
$pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg stg1
WHERE  stg1.rx_nbr = tgt1.rx_nbr
AND stg1.store_nbr = tgt1.str_nbr
AND stg1.cdc_operation_type_cd = 'INSERT'
AND (tgt1.drug_non_sys_name IS NOT NULL AND tgt1.drug_non_sys_name <> stg1.drug_non_system_name)""",
    [])
  ])
  #-- FUN_DATE_CAST - Reformat STRING-to-DATE casting
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- MOVE THE RECORDS INTO DUPS TABLE THAT ARE IDENTIFIED AS DUP INSERT FROM TGT
  #------------------------------------------------------ 
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
)
select 
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
where (rx_nbr, store_nbr)
in
( select rx_nbr, store_nbr
 from $pTDStageDB.V_dup_rx_inserts )
and cdc_operation_type_cd = 'INSERT'""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETE THOSE RECORDS FROM ETL STAGE
  #------------------------------------------------------
  executeSql([], [
    ("""delete
from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
where (rx_nbr, store_nbr)
in
( select rx_nbr, store_nbr
 from $pTDStageDB.V_dup_rx_inserts )
and cdc_operation_type_cd = 'INSERT'""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- CHECKING AND MOVING DATA IN THE DUPS TABLE FROM ETL STAGE TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
)
select 
RXT.cdc_txn_commit_dttm
,RXT.cdc_seq_nbr
,RXT.cdc_rba_nbr
,RXT.cdc_operation_type_cd
,RXT.cdc_before_after_cd
,RXT.cdc_txn_position_cd
,RXT.edw_batch_id
,RXT.store_nbr
,RXT.rx_nbr
,RXT.drug_non_system_name
,RXT.drug_assigned_ndc
,RXT.drug_non_system_mfg_nm
,RXT.priced_as_nonsys_ind
,RXT.wic_nbr
,RXT.src_partition_nbr
,RXT.compound_type
,RXT.dosage_form_cd
from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg RXT,
  $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg DUP
 where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING THE DUPS FROM ETL STAGE TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg RXT 
using $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg DUP 
where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- CHECKING AND MOVING DATA IN THE DUPS TABLE FROM ETL STAGE TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd)
select 
RXT.cdc_txn_commit_dttm
,RXT.cdc_seq_nbr
,RXT.cdc_rba_nbr
,RXT.cdc_operation_type_cd
,RXT.cdc_before_after_cd
,RXT.cdc_txn_position_cd
,RXT.edw_batch_id
,RXT.store_nbr
,RXT.rx_nbr
,RXT.drug_non_system_name
,RXT.drug_assigned_ndc
,RXT.drug_non_system_mfg_nm
,RXT.priced_as_nonsys_ind
,RXT.wic_nbr
,RXT.src_partition_nbr
,RXT.compound_type
,RXT.dosage_form_cd
from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg RXT,
  $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg DUP
 where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING THE DUPS FROM ETL STAGE TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg RXT 
using $pTDStageDB.etl_proc_dup_rx_cmpnd_nonsys_stg DUP 
where RXT.store_nbr = DUP.store_nbr
 and RXT.rx_nbr = DUP.rx_nbr""",
    [])
  ])
  #-- DEL_STATEMENT - Replace DEL with DELETE
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------ 
  #-------------------------------------------------------------------------
  #---- insert missing updates (pure updates and before iamages of PK UPDATES)
  #------------------------------------------------------------------------
  executeSql([], [
    ("""INSERT into $APT_TERA_SYNC_DATABASE.ETL_CNS_MISSING_UPDATES_STG  
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
)
SELECT 
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,src_partition_nbr
,compound_type
,dosage_form_cd
 FROM $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
WHERE (STORE_NBR, RX_NBR) IN (
SELECT STORE_NBR, RX_NBR FROM 
(SELECT STORE_NBR, RX_NBR FROM 
$pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg 
WHERE CDC_OPERATION_TYPE_CD='SQL COMPUPDATE'
  
minus
SELECT STORE_NBR, RX_NBR FROM $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg 
WHERE CDC_OPERATION_TYPE_CD='INSERT'
)A
WHERE (STORE_NBR, RX_NBR) NOT IN (
SELECT STR_NBR, RX_NBR FROM $pTDViewDBName.PRESCRIPTION)
)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------------------------
  #--- delete  from stage missing pure and PK updates
  #-----------------------------------------------------------------------
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.etl_tbf0_rx_cmpnd_nonsys_stg
WHERE ( rx_nbr,store_nbr, cdc_txn_commit_dttm, CDC_SEQ_NBR, CDC_RBA_NBR) IN
(SELECT rx_nbr,store_nbr,cdc_txn_commit_dttm, CDC_SEQ_NBR, CDC_RBA_NBR FROM $APT_TERA_SYNC_DATABASE.ETL_CNS_MISSING_UPDATES_STG)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  return

main()
cleanup()
done()
ZZ


#!/bin/sh

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5

pTDETLProcDupTable=$6
APT_TERA_SYNC_DATABASE=$7
pTDETLTempIdntfyDupTable=$8
pTDEDWTargetTable=$9

python3 <<ZZ
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.$pTDETLProcDupTable_stg
(
  cdc_txn_commit_dttm,
  cdc_seq_nbr,
  cdc_rba_nbr,
  cdc_operation_type_cd,
  cdc_before_after_cd,
  cdc_txn_position_cd,
  edw_batch_id,
  src_partition_nbr,
  sdl_msg_id,
  pat_id,
  store_nbr,
  rx_nbr,
  fill_nbr,
  fill_qty_dispensed,
  fill_days_supply,
  fill_enter_dttm,
  fill_nbr_dispensed,
  drug_name,
  drug_ndc_nbr,
  rx_written_dttm,
  general_pbr_nbr,
  submitted_user_id,
  submitted_dttm,
  plan_id,
  plan_group_nbr,
  general_recipient_nbr,
  prior_auth_cd,
  prior_auth_nbr,
  rx_denial_override_cd,
  eligibility_override_cd,
  diagnosis_cd,
  pay_cd,
  dl_reject_cd_01,
  dl_reject_reason_01,
  dl_reject_cd_02,
  dl_reject_reason_02,
  dl_reject_cd_03,
  dl_reject_reason_03,
  dl_reject_cd_04,
  dl_reject_reason_04,
  dl_reject_cd_05,
  dl_reject_reason_05,
  dl_proc_msg,
  dl_additional_msg,
  dur_conflict_cd,
  dur_intervention_cd,
  dur_outcome_cd,
  other_payer_reject_cd,
  other_coverage_cd,
  other_payer_cvrg_type,
  plan_other_amt_paid_type,
  plan_other_amt_paid,
  other_payer_id,
  other_payer_id_qualifier,
  first_provider_paid_amt,
  plan_total_paid_amt,
  plan_returnd_cost_amt,
  plan_returnd_fee_amt,
  plan_incentive_paid_amt,
  fill_retail_price_amt,
  pat_rem_ded_amt,
  pat_rem_ben_amt,
  pat_acc_ded_amt,
  pat_ded_applied_amt,
  fill_del_adjudication_cd,
  fill_adjudication_cd,
  claim_reference_nbr,
  plan_returnd_copay_amt,
  plan_returnd_tax_amt,
  fill_sold_amt,
  sales_adj_cd,
  rx_daw_ind,
  claim_reversal_ind,
place_of_service,
rx_denial_override_cd_2,
rx_denial_override_cd_3,
delay_reason_cd,
plan_returnd_grp_nbr,
plan_id_returnd,
ntwk_reimb_id_returnd,
proc_fee_amt,
prvd_ntwk_amt,
prd_brnd_drug_amt,
npref_prd_form_amt,
cov_gap_amt,
plan_fund_assist_amt,
ingrd_cost_contract_amt	,
disp_fee_contract_amt,
plan_sales_tax_amt,
pat_sales_tax_amt,
other_payer_recognzd_amt,
ben_stg_ded_amt,
ben_stg_init_cov_amt,
ben_stg_cov_gap_amt,
ben_stg_cat_amt,
plan_returnd_coins_amt,
plan_other_amt_paid_typ2,
plan_other_amt_paid_typ3,
plan_other_amt_paid_2,
plan_other_amt_paid_3,
phrm_svc_type_cd,
npref_brnd_prd_amt,
basis_of_reimb_determ,
plan_rtrnd_coins_amt,
plan_incent_amt_submtd,
plan_gross_due_amt,
ben_stg_qualifier_1,
ben_stg_qualifier_2,
ben_stg_qualifier_3,
ben_stg_qualifier_4,
ben_stg_amount_1,
ben_stg_amount_2,
ben_stg_amount_3,
ben_stg_amount_4,
ws_pipe_id,
coupon_drug_id,
coupon_ind
)
SELECT
  cdc_txn_commit_dttm,
  cdc_seq_nbr,
  cdc_rba_nbr,
  cdc_operation_type_cd,
  cdc_before_after_cd,
  cdc_txn_position_cd,
  edw_batch_id,
  src_partition_nbr,
  sdl_msg_id,
  pat_id,
  store_nbr,
  rx_nbr,
  fill_nbr,
  fill_qty_dispensed,
  fill_days_supply,
  fill_enter_dttm,
  fill_nbr_dispensed,
  drug_name,
  drug_ndc_nbr,
  rx_written_dttm,
  general_pbr_nbr,
  submitted_user_id,
  submitted_dttm,
  plan_id,
  plan_group_nbr,
  general_recipient_nbr,
  prior_auth_cd,
  prior_auth_nbr,
  rx_denial_override_cd,
  eligibility_override_cd,
  diagnosis_cd,
  pay_cd,
  dl_reject_cd_01,
  dl_reject_reason_01,
  dl_reject_cd_02,
  dl_reject_reason_02,
  dl_reject_cd_03,
  dl_reject_reason_03,
  dl_reject_cd_04,
  dl_reject_reason_04,
  dl_reject_cd_05,
  dl_reject_reason_05,
  dl_proc_msg,
  dl_additional_msg,
  dur_conflict_cd,
  dur_intervention_cd,
  dur_outcome_cd,
  other_payer_reject_cd,
  other_coverage_cd,
  other_payer_cvrg_type,
  plan_other_amt_paid_type,
  plan_other_amt_paid,
  other_payer_id,
  other_payer_id_qualifier,
  first_provider_paid_amt,
  plan_total_paid_amt,
  plan_returnd_cost_amt,
  plan_returnd_fee_amt,
  plan_incentive_paid_amt,
  fill_retail_price_amt,
  pat_rem_ded_amt,
  pat_rem_ben_amt,
  pat_acc_ded_amt,
  pat_ded_applied_amt,
  fill_del_adjudication_cd,
  fill_adjudication_cd,
  claim_reference_nbr,
  plan_returnd_copay_amt,
  plan_returnd_tax_amt,
  fill_sold_amt,
  sales_adj_cd,
  rx_daw_ind,
  claim_reversal_ind,
place_of_service,
rx_denial_override_cd_2,
rx_denial_override_cd_3,
delay_reason_cd,
plan_returnd_grp_nbr,
plan_id_returnd,
ntwk_reimb_id_returnd,
proc_fee_amt,
prvd_ntwk_amt,
prd_brnd_drug_amt,
npref_prd_form_amt,
cov_gap_amt,
plan_fund_assist_amt,
ingrd_cost_contract_amt ,
disp_fee_contract_amt,
plan_sales_tax_amt,
pat_sales_tax_amt,
other_payer_recognzd_amt,
ben_stg_ded_amt,
ben_stg_init_cov_amt,
ben_stg_cov_gap_amt,
ben_stg_cat_amt,
plan_returnd_coins_amt,
plan_other_amt_paid_typ2,
plan_other_amt_paid_typ3,
plan_other_amt_paid_2,
plan_other_amt_paid_3,
phrm_svc_type_cd,
npref_brnd_prd_amt,
basis_of_reimb_determ,
plan_rtrnd_coins_amt,
plan_incent_amt_submtd,
plan_gross_due_amt,
ben_stg_qualifier_1,
ben_stg_qualifier_2,
ben_stg_qualifier_3,
ben_stg_qualifier_4,
ben_stg_amount_1,
ben_stg_amount_2,
ben_stg_amount_3,
ben_stg_amount_4,
ws_pipe_id,
coupon_drug_id,
coupon_ind
FROM $APT_TERA_SYNC_DATABASE.$pTDETLTempIdntfyDupTable_stg
WHERE
(rx_nbr, store_nbr, fill_nbr, sdl_msg_id)
IN
( 
SELECT rx_nbr, store_nbr, fill_nbr, sdl_msg_id
FROM $APT_TERA_SYNC_DATABASE.$pTDETLTempIdntfyDupTable_stg
WHERE cdc_operation_type_cd = 'INSERT'
GROUP BY rx_nbr, store_nbr, fill_nbr, sdl_msg_id
HAVING COUNT(distinct fill_enter_dttm) > 1 
)""",
    [])
  ])
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""DELETE FROM $APT_TERA_SYNC_DATABASE.$pTDETLTempIdntfyDupTable_stg
WHERE
(rx_nbr, store_nbr, fill_nbr, sdl_msg_id)
IN
( 
SELECT rx_nbr, store_nbr, fill_nbr, sdl_msg_id
FROM $APT_TERA_SYNC_DATABASE.$pTDETLTempIdntfyDupTable_stg
WHERE cdc_operation_type_cd = 'INSERT'
GROUP BY rx_nbr, store_nbr, fill_nbr, sdl_msg_id
HAVING COUNT(distinct fill_enter_dttm) > 1 
)""",
    [])
  ])
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""CREATE temporary TABLE $pTDStageDB.V_dup_rx_sdl
     (
      rx_nbr INTEGER NOT NULL,
      store_nbr INTEGER NOT NULL,
      fill_nbr SMALLINT,
      sdl_msg_id CHAR(6),
      fill_enter_dttm TIMESTAMP)
ON COMMIT PRESERVE ROWS""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
  #-- TABLE_INDEX - Remove table index options
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.V_dup_rx_sdl
SELECT
   STG.rx_nbr,
   STG.store_nbr,
   STG.fill_nbr,
   STG.sdl_msg_id,
   STG.fill_enter_dttm
FROM
   $APT_TERA_SYNC_DATABASE.$pTDETLTempIdntfyDupTable_stg STG,
   $pTDDBName.$pTDEDWTargetTable TGT
 WHERE
  STG.rx_nbr = TGT.rx_nbr
  AND STG.store_nbr = TGT.str_nbr
  AND STG.fill_nbr = TGT.rx_fill_nbr
  AND STG.sdl_msg_id = TGT.sdl_msg_id
  AND COALESCE( STG.fill_enter_dttm , CAST( '1900-01-01 01:01:01' AS TIMESTAMP(0)) ) <> CAST ( CAST ( TGT.fill_enter_dt AS CHAR(10 ) ) || ' ' || CAST ( TGT.fill_enter_tm AS CHAR(08 ) ) AS TIMESTAMP(0) )
  AND TGT.fill_enter_dt >= case when STG.store_nbr=3397 then (CAST(STG.fill_enter_dttm AS DATE) - 365) else (CAST(STG.fill_enter_dttm AS DATE) - 730) end 
  AND cdc_operation_type_cd='INSERT'
GROUP BY STG.rx_nbr, STG.store_nbr,STG.fill_nbr, STG.sdl_msg_id, STG.fill_enter_dttm""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.$pTDETLProcDupTable_stg
(
  cdc_txn_commit_dttm,
  cdc_seq_nbr,
  cdc_rba_nbr,
  cdc_operation_type_cd,
  cdc_before_after_cd,
  cdc_txn_position_cd,
  edw_batch_id,
  src_partition_nbr,
  sdl_msg_id,
  pat_id,
  store_nbr,
  rx_nbr,
  fill_nbr,
  fill_qty_dispensed,
  fill_days_supply,
  fill_enter_dttm,
  fill_nbr_dispensed,
  drug_name,
  drug_ndc_nbr,
  rx_written_dttm,
  general_pbr_nbr,
  submitted_user_id,
  submitted_dttm,
  plan_id,
  plan_group_nbr,
  general_recipient_nbr,
  prior_auth_cd,
  prior_auth_nbr,
  rx_denial_override_cd,
  eligibility_override_cd,
  diagnosis_cd,
  pay_cd,
  dl_reject_cd_01,
  dl_reject_reason_01,
  dl_reject_cd_02,
  dl_reject_reason_02,
  dl_reject_cd_03,
  dl_reject_reason_03,
  dl_reject_cd_04,
  dl_reject_reason_04,
  dl_reject_cd_05,
  dl_reject_reason_05,
  dl_proc_msg,
  dl_additional_msg,
  dur_conflict_cd,
  dur_intervention_cd,
  dur_outcome_cd,
  other_payer_reject_cd,
  other_coverage_cd,
  other_payer_cvrg_type,
  plan_other_amt_paid_type,
  plan_other_amt_paid,
  other_payer_id,
  other_payer_id_qualifier,
  first_provider_paid_amt,
  plan_total_paid_amt,
  plan_returnd_cost_amt,
  plan_returnd_fee_amt,
  plan_incentive_paid_amt,
  fill_retail_price_amt,
  pat_rem_ded_amt,
  pat_rem_ben_amt,
  pat_acc_ded_amt,
  pat_ded_applied_amt,
  fill_del_adjudication_cd,
  fill_adjudication_cd,
  claim_reference_nbr,
  plan_returnd_copay_amt,
  plan_returnd_tax_amt,
  fill_sold_amt,
  sales_adj_cd,
  rx_daw_ind,
  claim_reversal_ind,
place_of_service,
rx_denial_override_cd_2,
rx_denial_override_cd_3,
delay_reason_cd,
plan_returnd_grp_nbr,
plan_id_returnd,
ntwk_reimb_id_returnd,
proc_fee_amt,
prvd_ntwk_amt,
prd_brnd_drug_amt,
npref_prd_form_amt,
cov_gap_amt,
plan_fund_assist_amt,
ingrd_cost_contract_amt ,
disp_fee_contract_amt,
plan_sales_tax_amt,
pat_sales_tax_amt,
other_payer_recognzd_amt,
ben_stg_ded_amt,
ben_stg_init_cov_amt,
ben_stg_cov_gap_amt,
ben_stg_cat_amt,
plan_returnd_coins_amt,
plan_other_amt_paid_typ2,
plan_other_amt_paid_typ3,
plan_other_amt_paid_2,
plan_other_amt_paid_3,
phrm_svc_type_cd,
npref_brnd_prd_amt,
basis_of_reimb_determ,
plan_rtrnd_coins_amt,
plan_incent_amt_submtd,
plan_gross_due_amt,
ben_stg_qualifier_1,
ben_stg_qualifier_2,
ben_stg_qualifier_3,
ben_stg_qualifier_4,
ben_stg_amount_1,
ben_stg_amount_2,
ben_stg_amount_3,
ben_stg_amount_4,
ws_pipe_id,
coupon_drug_id,
coupon_ind
)
SELECT
  cdc_txn_commit_dttm,
  cdc_seq_nbr,
  cdc_rba_nbr,
  cdc_operation_type_cd,
  cdc_before_after_cd,
  cdc_txn_position_cd,
  edw_batch_id,
  src_partition_nbr,
  sdl_msg_id,
  pat_id,
  store_nbr,
  rx_nbr,
  fill_nbr,
  fill_qty_dispensed,
  fill_days_supply,
  fill_enter_dttm,
  fill_nbr_dispensed,
  drug_name,
  drug_ndc_nbr,
  rx_written_dttm,
  general_pbr_nbr,
  submitted_user_id,
  submitted_dttm,
  plan_id,
  plan_group_nbr,
  general_recipient_nbr,
  prior_auth_cd,
  prior_auth_nbr,
  rx_denial_override_cd,
  eligibility_override_cd,
  diagnosis_cd,
  pay_cd,
  dl_reject_cd_01,
  dl_reject_reason_01,
  dl_reject_cd_02,
  dl_reject_reason_02,
  dl_reject_cd_03,
  dl_reject_reason_03,
  dl_reject_cd_04,
  dl_reject_reason_04,
  dl_reject_cd_05,
  dl_reject_reason_05,
  dl_proc_msg,
  dl_additional_msg,
  dur_conflict_cd,
  dur_intervention_cd,
  dur_outcome_cd,
  other_payer_reject_cd,
  other_coverage_cd,
  other_payer_cvrg_type,
  plan_other_amt_paid_type,
  plan_other_amt_paid,
  other_payer_id,
  other_payer_id_qualifier,
  first_provider_paid_amt,
  plan_total_paid_amt,
  plan_returnd_cost_amt,
  plan_returnd_fee_amt,
  plan_incentive_paid_amt,
  fill_retail_price_amt,
  pat_rem_ded_amt,
  pat_rem_ben_amt,
  pat_acc_ded_amt,
  pat_ded_applied_amt,
  fill_del_adjudication_cd,
  fill_adjudication_cd,
  claim_reference_nbr,
  plan_returnd_copay_amt,
  plan_returnd_tax_amt,
  fill_sold_amt,
  sales_adj_cd,
  rx_daw_ind,
  claim_reversal_ind,
place_of_service,
rx_denial_override_cd_2,
rx_denial_override_cd_3,
delay_reason_cd,
plan_returnd_grp_nbr,
plan_id_returnd,
ntwk_reimb_id_returnd,
proc_fee_amt,
prvd_ntwk_amt,
prd_brnd_drug_amt,
npref_prd_form_amt,
cov_gap_amt,
plan_fund_assist_amt,
ingrd_cost_contract_amt ,
disp_fee_contract_amt,
plan_sales_tax_amt,
pat_sales_tax_amt,
other_payer_recognzd_amt,
ben_stg_ded_amt,
ben_stg_init_cov_amt,
ben_stg_cov_gap_amt,
ben_stg_cat_amt,
plan_returnd_coins_amt,
plan_other_amt_paid_typ2,
plan_other_amt_paid_typ3,
plan_other_amt_paid_2,
plan_other_amt_paid_3,
phrm_svc_type_cd,
npref_brnd_prd_amt,
basis_of_reimb_determ,
plan_rtrnd_coins_amt,
plan_incent_amt_submtd,
plan_gross_due_amt,
ben_stg_qualifier_1,
ben_stg_qualifier_2,
ben_stg_qualifier_3,
ben_stg_qualifier_4,
ben_stg_amount_1,
ben_stg_amount_2,
ben_stg_amount_3,
ben_stg_amount_4,
ws_pipe_id,
coupon_drug_id,
coupon_ind
FROM $APT_TERA_SYNC_DATABASE.$pTDETLTempIdntfyDupTable_stg
WHERE
(rx_nbr, store_nbr, fill_nbr, sdl_msg_id, fill_enter_dttm)
IN
(
SELECT rx_nbr, store_nbr, fill_nbr, sdl_msg_id, fill_enter_dttm
FROM $pTDStageDB.V_dup_rx_sdl 
)
AND cdc_operation_type_cd = 'INSERT'""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""DELETE
FROM $APT_TERA_SYNC_DATABASE.$pTDETLTempIdntfyDupTable_stg
WHERE
(rx_nbr, store_nbr, fill_nbr, sdl_msg_id, fill_enter_dttm)
IN
(
SELECT rx_nbr, store_nbr, fill_nbr, sdl_msg_id, fill_enter_dttm
FROM $pTDStageDB.V_dup_rx_sdl 
)
AND cdc_operation_type_cd = 'INSERT'""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  return

main()
cleanup()
done()
ZZ

#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
unset KEY_VAULT_SECRET

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
APT_TERA_SYNC_DATABASE=$7
pTDDBNameOth=$8
pTDStageDBLoc=$9

TRGFILE=/usr/local/edw/pharmacy/prod/output/loadready/triggerfiles/Rx_create_dttm_change_load_completed.trig


python3 <<ZZ 
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  executeSql([], [
    ("""UPDATE $APT_TERA_SYNC_DATABASE.etl_rx_missing_updates_stg msng
 
set edw_batch_id=stg.edw_batch_id FROM    (select edw_batch_id from $pTDStageDBLoc.etl_tbf0_rx_stg group by 1)stg""",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""insert into $pTDStageDBLoc.etl_tbf0_rx_stg
 (cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,pat_id
,drug_id
,drug_class
,drug_non_system_cd
,pbr_id
,fill_qty_dispensed
,fill_days_supply
,rx_daw_ind
,rx_written_dttm
,rx_original_fill_dttm
,rx_added_qty
,rx_sig
,rx_refills_by_dttm
,fill_nbr_prescribed
,fill_nbr_dispensed
,fill_nbr_added
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm
,image_id
,scanned_user_id
,scanned_dttm
,scanned_store_nbr
,tip_rx_ind
,pbr_order_nbr
,drug_sub_cd
,pbr_loc_id
,pay_cd
,rx_comment
,rx_status_cd
,fill_unlimited_ind
,ordered_drug_id
,create_user_id
,create_dttm
,update_user_id
,update_dttm
,generic_subs_pref
,routing_store_nbr
,rx_original_qty_disp
,rx_original_days_supply
,src_partition_nbr
,rx_total_dispensed_qty
,rx_original_qty
,diagnosis_cd
,diagnosis_cd_qualifier
,origin_cd
,diagnosis_cd_2
,diagnosis_cd_3
,diagnosis_cd_4
,rx_pad_program_ind
,rx_pad_barcode
,rx_vacc_manuf_lot_nbr 
,rx_vacc_exp_dttm 
,rx_vacc_area_of_admin 
,rx_vacc_consent_ind 
,rx_vacc_pnl_ent_dttm 
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
)
select
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,pat_id
,drug_id
,drug_class
,drug_non_system_cd
,pbr_id
,fill_qty_dispensed
,fill_days_supply
,rx_daw_ind
,rx_written_dttm
,rx_original_fill_dttm
,rx_added_qty
,rx_sig
,rx_refills_by_dttm
,fill_nbr_prescribed
,fill_nbr_dispensed
,fill_nbr_added
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm
,image_id
,scanned_user_id
,scanned_dttm
,scanned_store_nbr
,tip_rx_ind
,pbr_order_nbr
,drug_sub_cd
,pbr_loc_id
,pay_cd
,rx_comment
,rx_status_cd
,fill_unlimited_ind
,ordered_drug_id
,create_user_id
,create_dttm
,update_user_id
,update_dttm
,generic_subs_pref
,routing_store_nbr
,rx_original_qty_disp
,rx_original_days_supply
,src_partition_nbr
,rx_total_dispensed_qty
,rx_original_qty
,diagnosis_cd
,diagnosis_cd_qualifier
,origin_cd
,diagnosis_cd_2
,diagnosis_cd_3
,diagnosis_cd_4
,rx_pad_program_ind
,rx_pad_barcode
,rx_vacc_manuf_lot_nbr 
,rx_vacc_exp_dttm 
,rx_vacc_area_of_admin 
,rx_vacc_consent_ind 
,rx_vacc_pnl_ent_dttm 
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
from 
$APT_TERA_SYNC_DATABASE.etl_rx_missing_updates_stg""",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $APT_TERA_SYNC_DATABASE.etl_rx_missing_updates_stg""",
    [])
  ])
  #-- DEL_STATEMENT - Replace DEL with DELETE
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription
 
set    str_nbr = R.relocate_to_str_nbr
 from   $pTDDBNameOth.location_store_relocation  R
 where  $pTDDBName.prescription.str_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription
 
set    route_str_nbr = R.relocate_to_str_nbr
 from   $pTDDBNameOth.location_store_relocation  R
 where  $pTDDBName.prescription.route_str_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription
 
set    scan_str_nbr = R.relocate_to_str_nbr
 from   $pTDDBNameOth.location_store_relocation  R
 where  $pTDDBName.prescription.scan_str_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** PERFORM STORE RELO UPDATES FOR DEDUP TABLES                    **
  #--BC **================================================================*/
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_rx_stg
 
set    store_nbr = R.relocate_to_str_nbr
 from   $pTDDBNameOth.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_rx_stg.store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_rx_stg
 
set    routing_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBNameOth.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_rx_stg.routing_store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_rx_stg
 
set    scanned_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBNameOth.location_store_relocation  R
 where  $pTDStageDB.etl_proc_dup_rx_stg.scanned_store_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** REMOVE PK UPDATES FOR STORE RELOS IN STAGE TABLES              **
  #--BC **================================================================*/
  executeSql([], [
    ("""delete from $pTDStageDBLoc.etl_tbf0_rx_stg txn 
using $pTDStageDBLoc.etl_tbf0_rx_stg BFR, $pTDStageDBLoc.etl_tbf0_rx_stg AFT, $pTDDBNameOth.location_store_relocation  SR 
where BFR.cdc_txn_commit_dttm = AFT.cdc_txn_commit_dttm
  and  BFR.cdc_seq_nbr = AFT.cdc_seq_nbr
  and  BFR.cdc_rba_nbr = AFT.cdc_rba_nbr
  and SR.relocate_fm_str_nbr = BFR.store_nbr
  and SR.relocate_to_str_nbr = AFT.store_nbr
  and  BFR.cdc_before_after_cd = 'BEFORE'
  and  AFT.cdc_before_after_cd = 'AFTER'
  and  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
  and  AFT.cdc_operation_type_cd = 'PK UPDATE'
  and BFR.store_nbr <> AFT.store_nbr
  and BFR.rx_nbr = AFT.rx_nbr
 
  and txn.cdc_txn_commit_dttm =  bfr.cdc_txn_commit_dttm
  and txn.cdc_seq_nbr =   bfr.cdc_seq_nbr
  and txn.cdc_rba_nbr =   bfr.cdc_rba_nbr
  and txn.cdc_operation_type_cd in ( 'PK UPDATE', 'SQL COMPUPDATE')""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** UPDATE STORE NUMBERS FOR STORE RELOS IN STAGE TABLES           **
  #--BC **================================================================*/
  executeSql([], [
    ("""UPDATE $pTDStageDBLoc.etl_tbf0_rx_stg
 
set store_nbr = SR.relocate_to_str_nbr
 from  $pTDDBNameOth.location_store_relocation  SR
 where store_nbr = SR.relocate_fm_str_nbr""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDBLoc.etl_tbf0_rx_stg
 
set    routing_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBNameOth.location_store_relocation  R
 where  $pTDStageDBLoc.etl_tbf0_rx_stg.routing_store_nbr = R.relocate_fm_str_nbr
  and   $pTDStageDBLoc.etl_tbf0_rx_stg.cdc_operation_type_cd='INSERT'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDBLoc.etl_tbf0_rx_stg
 
set    scanned_store_nbr = R.relocate_to_str_nbr
 from   $pTDDBNameOth.location_store_relocation  R
 where  $pTDStageDBLoc.etl_tbf0_rx_stg.scanned_store_nbr = R.relocate_fm_str_nbr
  and   $pTDStageDBLoc.etl_tbf0_rx_stg.cdc_operation_type_cd='INSERT'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** PERFORM RX CREATE DATE UPDATES TABLES                          **
  #--BC **================================================================*/
  #--- INSERT THE NEW CHANGED CREATE_DTTM AND UPDATE TO_CREATE_DTTM FOR OLD BATCH
  executeSql([], [
    ("""CREATE temporary TABLE $pTDStageDB.VT_batch_rank
(
   edw_batch_id DECIMAL(18,0),
   edw_rank INTEGER
)
ON COMMIT PRESERVE ROWS""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- TABLE_INDEX - Remove table index options
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.VT_batch_rank
SELECT edw_batch_id,
       RANK() OVER (ORDER BY edw_batch_id desc) edw_rank
  FROM $pTDStageDB.rx_create_dttm_change_stg
 group by edw_batch_id""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.rx_create_dttm_change_stg
 WHERE edw_batch_id NOT IN (select edw_batch_id
                              from $pTDStageDB.VT_batch_rank
                             where edw_rank in (1, 2, 3, 4, 5)
                           )""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDB.rx_create_dttm_change_stg
  
SET str_nbr = SR.relocate_to_str_nbr
 FROM $pTDDBNameOth.location_store_relocation SR
   WHERE str_nbr = SR.relocate_fm_str_nbr""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""CREATE temporary TABLE $pTDStageDB.VT_CreateDttm_Changes
     (
      cdc_txn_commit_dttm TIMESTAMP,
      cdc_seq_nbr INTEGER,
      cdc_rba_nbr DECIMAL(18,0),
      cdc_operation_type_cd CHAR(20),
      cdc_before_after_cd CHAR(10),
      store_nbr DECIMAL(5,0) NOT NULL,
      rx_nbr DECIMAL(7,0) NOT NULL,
      create_dttm TIMESTAMP,
      edw_rank INTEGER
)
ON COMMIT PRESERVE ROWS""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
  #-- TABLE_INDEX - Remove table index options
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.VT_CreateDttm_Changes
Select   
aft.cdc_txn_commit_dttm
,aft.cdc_seq_nbr
,aft.cdc_rba_nbr
,aft.cdc_operation_type_cd
,aft.cdc_before_after_cd
,aft.store_nbr
,aft.rx_nbr
,aft.create_dttm
,RANK() OVER (PARTITION BY aft.store_nbr, aft.rx_nbr ORDER BY aft.cdc_txn_commit_dttm, aft.cdc_seq_nbr, aft.cdc_rba_nbr) edw_rank
from    $pTDStageDBLoc.etl_tbf0_rx_stg    bfr,
        $pTDStageDBLoc.etl_tbf0_rx_stg    aft 
WHERE   AFT.cdc_seq_nbr      =  BFR.cdc_seq_nbr
  AND   AFT.cdc_rba_nbr      =  BFR.cdc_rba_nbr
  AND   AFT.cdc_txn_commit_dttm = BFR.cdc_txn_commit_dttm
  AND   BFR.cdc_before_after_cd    = 'BEFORE'
  AND   BFR.cdc_operation_type_cd  = 'SQL COMPUPDATE'
  AND   AFT.cdc_before_after_cd    = 'AFTER'
  AND   AFT.cdc_operation_type_cd  = 'SQL COMPUPDATE'
  AND   bfr.store_nbr= aft.store_nbr
  AND   bfr.rx_nbr = aft.rx_nbr
  AND   bfr.create_dttm <> aft.create_dttm""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""insert into $pTDStageDB.rx_create_dttm_change_stg
Select   bfr.store_nbr,
         bfr.rx_nbr,
         bfr.create_dttm frm_create_dttm,
         Mx.create_dttm to_create_dttm,
         'N',
         bfr.edw_batch_id
from    $pTDStageDBLoc.etl_tbf0_rx_stg    bfr,
        $pTDStageDBLoc.etl_tbf0_rx_stg    aft,
(select store_nbr, rx_nbr, create_dttm from $pTDStageDB.VT_CreateDttm_Changes
where (store_nbr, rx_nbr, edw_rank) IN
(Select  store_nbr, rx_nbr, max(edw_rank) FROM $pTDStageDB.VT_CreateDttm_Changes
GROUP BY store_nbr, rx_nbr)
) MX 
WHERE   AFT.cdc_seq_nbr      =  BFR.cdc_seq_nbr
  AND   AFT.cdc_rba_nbr      =  BFR.cdc_rba_nbr
  AND   AFT.cdc_txn_commit_dttm = BFR.cdc_txn_commit_dttm
  AND   BFR.cdc_before_after_cd    = 'BEFORE'
  AND   BFR.cdc_operation_type_cd  = 'SQL COMPUPDATE'
  AND   AFT.cdc_before_after_cd    = 'AFTER'
  AND   AFT.cdc_operation_type_cd  = 'SQL COMPUPDATE'
  AND   bfr.store_nbr= aft.store_nbr
  AND   bfr.rx_nbr = aft.rx_nbr
  AND   bfr.create_dttm <> aft.create_dttm
  AND   bfr.store_nbr = mx.store_nbr
  AND   bfr.rx_nbr = mx.rx_nbr""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDStageDB.rx_create_dttm_change_stg Y
SET to_create_dttm = T.to_create_dttm
 FROM    (select str_nbr, rx_nbr, to_create_dttm
          from $pTDStageDB.rx_create_dttm_change_stg
         where edw_batch_id = (select max(edw_batch_id)
                                 from $pTDStageDB.rx_create_dttm_change_stg
                              )
         group by str_nbr, rx_nbr, to_create_dttm
       ) T
   WHERE Y.str_nbr = T.str_nbr
   AND Y.rx_nbr = T.rx_nbr
   AND Y.to_create_dttm <> T.to_create_dttm
   AND Y.edw_batch_id <> (select max(edw_batch_id)
                            from $pTDStageDB.rx_create_dttm_change_stg
                         )""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.rx_create_dttm_change_stg
WHERE	(str_nbr, rx_nbr, frm_create_dttm, to_create_dttm,  edw_batch_id) IN
(
	SELECT	str_nbr, rx_nbr, frm_create_dttm, to_create_dttm,  MIN(edw_batch_id)
	FROM	$pTDStageDB.rx_create_dttm_change_stg
	WHERE	(str_nbr, rx_nbr, frm_create_dttm, to_create_dttm ) IN
	( 
		SELECT	str_nbr, rx_nbr, frm_create_dttm, to_create_dttm 
		FROM	$pTDStageDB.rx_create_dttm_change_stg
GROUP BY	1,2,3,4
HAVING	COUNT(*) > 1
	)
	GROUP BY	1,2,3,4
)""",
    [])
  ])
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #executeSql([], [
  #  ("""CALL PRDUTIL.TABLE_STATS('$pTDStageDB','rx_create_dttm_change_stg')""",
  #  [])
  #])
  #if (Action.errorCode != 0):
  #  Action.errorCodeOverride = 8
  #  return
  #Action.exportFileName = f"""${TRGFILE}"""
  #ExportOptions.colLimit = 100
  #Action.charSet = "ISO-8859-1"
  #executeSql([], [
  #  ("""select ' '""",
  #  [])
  #])
  #Action.exportFileName = None
  #--- UPDATE THE TARGET TABLE WITH THE NEW CHANGED CREATE_DTTM
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription RX
    
set    rx_create_dt = CAST( STG.to_create_dttm AS DATE)
       ,rx_create_tm = CAST( STG.to_create_dttm AS TIME(0))
       ,edw_batch_id = STG.edw_batch_id
 FROM    $pTDStageDB.rx_create_dttm_change_stg  STG
 where  RX.str_nbr = STG.str_nbr
 	AND RX.rx_nbr = STG.rx_nbr
 	AND RX.rx_create_dt =  CAST( STG.frm_create_dttm AS DATE)   
 	AND RX.rx_create_tm =  CAST( STG.frm_create_dttm AS TIME(0)) 	 
    AND   STG.change_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--- UPDATE THE DUPS TABLE WITH THE NEW CHANGED CREATE_DTTM
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_rx_stg RX
    
set    create_dttm = STG.to_create_dttm
        ,edw_batch_id = STG.edw_batch_id 
FROM    $pTDStageDB.rx_create_dttm_change_stg  STG
 where  RX.store_nbr = STG.str_nbr
 	AND RX.rx_nbr = STG.rx_nbr
 	AND RX.create_dttm =  STG.frm_create_dttm 	 
        AND   STG.change_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #---- UPDATE THE ETL STAGE TABLE WITH THE NEW CHANGED CREATE_DTTM
  executeSql([], [
    ("""UPDATE $pTDStageDBLoc.etl_tbf0_rx_stg RX
    
set    create_dttm = STG.to_create_dttm
 FROM    $pTDStageDB.rx_create_dttm_change_stg  STG
 where  RX.store_nbr = STG.str_nbr
 	AND RX.rx_nbr = STG.rx_nbr
 	AND RX.create_dttm =  STG.frm_create_dttm 	 
    AND   STG.change_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** DEDUP LOGIC                                                    **
  #--BC **================================================================*/
  executeSql([], [
    ("""create temporary table $pTDStageDB.V_dup_rx_inserts
(store_nbr    integer not null,
 rx_nbr       integer not null)
on commit preserve rows""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- TABLE_INDEX - Remove table index options
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- CHECKING DUPLICATES WITHIN THE SAME BATCH
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.V_dup_rx_inserts
select store_nbr, rx_nbr
from
( select store_nbr, rx_nbr, count( distinct create_dttm ) kount
   from $pTDStageDBLoc.etl_tbf0_rx_stg
where cdc_operation_type_cd = 'INSERT'
group by store_nbr, rx_nbr
having count( distinct create_dttm ) > 1 ) A""",
    [])
  ])
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- PUT THE DUP INSERTS WITHING SAME BATCH IN THE DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_stg
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,pat_id
,drug_id
,drug_class
,drug_non_system_cd
,pbr_id
,fill_qty_dispensed
,fill_days_supply
,rx_daw_ind
,rx_written_dttm
,rx_original_fill_dttm
,rx_added_qty
,rx_sig
,rx_refills_by_dttm
,fill_nbr_prescribed
,fill_nbr_dispensed
,fill_nbr_added
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm
,image_id
,scanned_user_id
,scanned_dttm
,scanned_store_nbr
,tip_rx_ind
,pbr_order_nbr
,drug_sub_cd
,pbr_loc_id
,pay_cd
,rx_comment
,rx_status_cd
,fill_unlimited_ind
,ordered_drug_id
,create_user_id
,create_dttm
,update_user_id
,update_dttm
,generic_subs_pref
,routing_store_nbr
,rx_original_qty_disp
,rx_original_days_supply
,src_partition_nbr
,rx_total_dispensed_qty
,rx_original_qty
,DIAGNOSIS_CD                  
,DIAGNOSIS_CD_QUALIFIER        
,ORIGIN_CD                     
,DIAGNOSIS_CD_2                
,DIAGNOSIS_CD_3                
,DIAGNOSIS_CD_4                
,RX_PAD_PROGRAM_IND            
,RX_PAD_BARCODE                
,rx_vacc_manuf_lot_nbr           
,rx_vacc_exp_dttm              
,rx_vacc_area_of_admin         
,rx_vacc_consent_ind           
,rx_vacc_pnl_ent_dttm          
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
)
select cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,pat_id
,drug_id
,drug_class
,drug_non_system_cd
,pbr_id
,fill_qty_dispensed
,fill_days_supply
,rx_daw_ind
,rx_written_dttm
,rx_original_fill_dttm
,rx_added_qty
,rx_sig
,rx_refills_by_dttm
,fill_nbr_prescribed
,fill_nbr_dispensed
,fill_nbr_added
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm
,image_id
,scanned_user_id
,scanned_dttm
,scanned_store_nbr
,tip_rx_ind
,pbr_order_nbr
,drug_sub_cd
,pbr_loc_id
,pay_cd
,rx_comment
,rx_status_cd
,fill_unlimited_ind
,ordered_drug_id
,create_user_id
,create_dttm
,update_user_id
,update_dttm
,generic_subs_pref
,routing_store_nbr
,rx_original_qty_disp
,rx_original_days_supply
,src_partition_nbr
,rx_total_dispensed_qty
,rx_original_qty
,DIAGNOSIS_CD                  
,DIAGNOSIS_CD_QUALIFIER        
,ORIGIN_CD                     
,DIAGNOSIS_CD_2                
,DIAGNOSIS_CD_3                
,DIAGNOSIS_CD_4                
,RX_PAD_PROGRAM_IND            
,RX_PAD_BARCODE
,rx_vacc_manuf_lot_nbr
,rx_vacc_exp_dttm
,rx_vacc_area_of_admin
,rx_vacc_consent_ind
,rx_vacc_pnl_ent_dttm
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
from $pTDStageDBLoc.etl_tbf0_rx_stg a
where (store_nbr, rx_nbr) IN
 (select store_nbr, rx_nbr from $pTDStageDB.V_dup_rx_inserts)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETE DUPS INSERTS WITHING SAME BATCH FROM THE ETL STAGE TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""delete
from $pTDStageDBLoc.etl_tbf0_rx_stg
where (store_nbr, rx_nbr) IN
 (select store_nbr, rx_nbr from $pTDStageDB.V_dup_rx_inserts)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETE THE TEMP TABLE TO STORE DIFFERENT INFO
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDB.V_dup_rx_inserts""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #----------------------------------------------------
  #-- THESE SQLS ARE USED TO REMOVE THE RECORDS FROM ETL STAGE WHICH ARE UPDATES/PK UPDATES BEFORE AN INSERT
  #----------------------------------------------------
  executeSql([], [
    ("""DELETE FROM $APT_TERA_SYNC_DATABASE.ETL_TBF0_RX_CHANGE_ANALYSIS_STG""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $APT_TERA_SYNC_DATABASE.ETL_TBF0_RX_CHANGE_ANALYSIS_STG
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,pat_id
,drug_id
,drug_class
,drug_non_system_cd
,pbr_id
,fill_qty_dispensed
,fill_days_supply
,rx_daw_ind
,rx_written_dttm
,rx_original_fill_dttm
,rx_added_qty
,rx_sig
,rx_refills_by_dttm
,fill_nbr_prescribed
,fill_nbr_dispensed
,fill_nbr_added
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm
,image_id
,scanned_user_id
,scanned_dttm
,scanned_store_nbr
,tip_rx_ind
,pbr_order_nbr
,drug_sub_cd
,pbr_loc_id
,pay_cd
,rx_comment
,rx_status_cd
,fill_unlimited_ind
,ordered_drug_id
,create_user_id
,create_dttm
,update_user_id
,update_dttm
,generic_subs_pref
,routing_store_nbr
,rx_original_qty_disp
,rx_original_days_supply
,src_partition_nbr
,rx_total_dispensed_qty
,rx_original_qty
,DIAGNOSIS_CD                  
,DIAGNOSIS_CD_QUALIFIER        
,ORIGIN_CD                     
,DIAGNOSIS_CD_2                
,DIAGNOSIS_CD_3                
,DIAGNOSIS_CD_4                
,RX_PAD_PROGRAM_IND            
,RX_PAD_BARCODE
,rx_vacc_manuf_lot_nbr
,rx_vacc_exp_dttm
,rx_vacc_area_of_admin
,rx_vacc_consent_ind
,rx_vacc_pnl_ent_dttm
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
)

SELECT 
STG.cdc_txn_commit_dttm
,STG.cdc_seq_nbr
,STG.cdc_rba_nbr
,STG.cdc_operation_type_cd
,STG.cdc_before_after_cd
,STG.cdc_txn_position_cd
,STG.edw_batch_id
,STG.store_nbr
,STG.rx_nbr
,STG.pat_id
,STG.drug_id
,STG.drug_class
,STG.drug_non_system_cd
,STG.pbr_id
,STG.fill_qty_dispensed
,STG.fill_days_supply
,STG.rx_daw_ind
,STG.rx_written_dttm
,STG.rx_original_fill_dttm
,STG.rx_added_qty
,STG.rx_sig
,STG.rx_refills_by_dttm
,STG.fill_nbr_prescribed
,STG.fill_nbr_dispensed
,STG.fill_nbr_added
,STG.fill_auto_ind
,STG.fill_nbr_last_disp
,STG.fill_entered_dttm
,STG.image_id
,STG.scanned_user_id
,STG.scanned_dttm
,STG.scanned_store_nbr
,STG.tip_rx_ind
,STG.pbr_order_nbr
,STG.drug_sub_cd
,STG.pbr_loc_id
,STG.pay_cd
,STG.rx_comment
,STG.rx_status_cd
,STG.fill_unlimited_ind
,STG.ordered_drug_id
,STG.create_user_id
,STG.create_dttm
,STG.update_user_id
,STG.update_dttm
,STG.generic_subs_pref
,STG.routing_store_nbr
,STG.rx_original_qty_disp
,STG.rx_original_days_supply
,STG.src_partition_nbr
,STG.rx_total_dispensed_qty
,STG.rx_original_qty
,STG.DIAGNOSIS_CD                  
,STG.DIAGNOSIS_CD_QUALIFIER        
,STG.ORIGIN_CD                     
,STG.DIAGNOSIS_CD_2                
,STG.DIAGNOSIS_CD_3                
,STG.DIAGNOSIS_CD_4                
,STG.RX_PAD_PROGRAM_IND            
,STG.RX_PAD_BARCODE
,STG.rx_vacc_manuf_lot_nbr
,STG.rx_vacc_exp_dttm
,STG.rx_vacc_area_of_admin
,STG.rx_vacc_consent_ind
,STG.rx_vacc_pnl_ent_dttm
,STG.rx_vacc_pnl_status_cd
,STG.rx_90day_pref_ind
,STG.rx_90day_pref_dttm
,STG.rx_90day_pref_stat_cd
,STG.rx_90day_pref_stat_dttm
,STG.pbr_dea_nbr
,STG.pbr_dea_suf
,STG.buyout_rx_ind
,STG.diagnosis_cd_5
,STG.diagnosis_cd_qualifier_2
,STG.diagnosis_cd_qualifier_3
,STG.diagnosis_cd_qualifier_4
,STG.diagnosis_cd_qualifier_5
,STG.trmt_type_cd
FROM $pTDStageDBLoc.etl_tbf0_rx_stg STG, 
( SELECT rx_nbr,store_nbr,create_dttm, max(cdc_txn_commit_dttm) max_cdc_dttm,
max(cdc_seq_nbr) max_cdc_seq, max(cdc_rba_nbr) max_rba_nbr
FROM $pTDStageDBLoc.etl_tbf0_rx_stg 
WHERE cdc_operation_type_cd='INSERT' 
GROUP BY 1,2,3) MX_INS
WHERE STG.STORE_NBR=MX_INS.STORE_NBR 
AND STG.RX_NBR=MX_INS.RX_NBR 
AND STG.CREATE_DTTM=MX_INS.CREATE_DTTM
AND (STG.CDC_TXN_COMMIT_DTTM < MX_INS.max_CDC_DTTM
  OR (STG.CDC_TXN_COMMIT_DTTM=MX_INS.max_CDC_DTTM
        AND STG.CDC_SEQ_NBR <= MX_INS.max_cdc_seq
        AND STG.CDC_RBA_NBR < MX_INS.max_rba_nbr))""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDBLoc.etl_tbf0_rx_stg STG 
using $APT_TERA_SYNC_DATABASE.ETL_TBF0_RX_CHANGE_ANALYSIS_STG PROC 
WHERE STG.STORE_NBR=PROC.STORE_NBR
AND STG.RX_NBR=PROC.RX_NBR
AND STG.CREATE_DTTM=PROC.CREATE_DTTM
AND STG.CDC_TXN_COMMIT_DTTM = PROC.CDC_TXN_COMMIT_DTTM
AND STG.CDC_RBA_NBR = PROC.CDC_RBA_NBR
AND STG.CDC_SEQ_NBR = PROC.CDC_SEQ_NBR
AND STG.CDC_BEFORE_AFTER_CD = PROC.CDC_BEFORE_AFTER_CD
AND STG.CDC_OPERATION_TYPE_CD = PROC.CDC_OPERATION_TYPE_CD
AND STG.CDC_TXN_POSITION_CD = PROC.CDC_TXN_POSITION_CD""",
    [])
  ])
  #-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #------------------------------------------------------
  #-- STARTING THE DUP LOGIC FROM HERE ON
  #------------------------------------------------------
  #------------------------------------------------------
  #------------------------------------------------------
  #-- DELETING TEST STORES
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDBLoc.etl_tbf0_rx_stg
 where store_nbr in
   (select store_nbr from $pTDStageDB.etl_proc_test_store_stg)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- CREATING PERFOMANCE TABLE TO SELECT TARGET RECS
  #------------------------------------------------------
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.ETL_PROC_RX_PRESC_STG""",
    [])
  ])
  #-- DEL_ALL - Remove ALL keyword from DELETE statement
  if (Action.errorCode != 0):
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.ETL_PROC_RX_PRESC_STG
(
  CDC_TXN_COMMIT_DTTM
 ,RX_NBR
 ,STR_NBR
 ,RX_CREATE_DT
 ,RX_CREATE_TM
 ,PAT_ID
 ,PBR_ID
 ,PBR_LOC_ID
 ,PBR_ORD_NBR
 ,DRUG_ID
 ,DEA_CLASS_CD
 ,DRUG_NON_SYS_CD
 ,DRUG_NON_SYS_NAME
 ,DRUG_NON_SYS_ASSIGN_NDC
 ,DRUG_NON_SYS_MFGR_NAME
 ,DRUG_SUB_CD
 ,ORD_DRUG_ID
 ,GENERIC_SUBSTN_PREF_IND
 ,FILL_UNLIMITED_IND
 ,FILL_QTY_DISPENSED
 ,FILL_DAYS_SUPPLY
 ,RX_DAW_CD
 ,RX_DAW_IND
 ,RX_SIG
 ,RX_STAT_CD
 ,RX_TOT_DSPN_QTY
 ,RX_WRITTEN_DT
 ,RX_WRITTEN_TM
 ,RX_ORIG_FILL_DTTM
 ,RX_ADDED_QTY
 ,RX_REFILL_EXPIRE_DT
 ,RX_REFILL_EXPIRE_TM
 ,RX_CMNT
 ,FILL_NBR_PRESCRIBED
 ,FILL_NBR_DSPN
 ,FILL_NBR_ADDED
 ,FILL_AUTO_IND
 ,FILL_NBR_LAST_DISP
 ,FILL_ENTERED_DTTM
 ,IMAGE_ID
 ,SCAN_USER_ID
 ,SCAN_DT
 ,SCAN_TM
 ,SCAN_STR_NBR
 ,TIP_RX_IND
 ,ROUTE_STR_NBR
 ,PRICED_AS_NONSYS_IND
 ,WAG_INV_CTRL_NBR
 ,RELOCATE_FM_STR_NBR
 ,CREATE_USER_ID
 ,EDW_BATCH_ID
 ,UPDATE_USER_ID
 ,UPDATE_DTTM
 ,RX_ORIG_QTY_DSPN
 ,RX_ORIG_DAYS_SUPPLY
 ,RX_ORIG_QTY
 ,SRC_PARTITION_NBR
 ,diagnosis_cd_1
 ,diagnosis_cd_2
 ,diagnosis_cd_3
 ,diagnosis_cd_4
 ,diagnosis_cd_qlfr
 ,origin_cd
 ,rx_pad_barcode
 ,rx_pad_prgm_ind
 ,rx_vacc_manuf_lot_nbr
 ,rx_vacc_exp_dttm
 ,rx_vacc_area_of_admin
 ,rx_vacc_consent_ind
 ,rx_vacc_pnl_ent_dttm
 ,rx_vacc_pnl_status_cd
,rx_90day_ind
,rx_90day_dttm
,rx_90day_stat_cd
,rx_90day_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
,fill_adv_rfl_opt_ind    
,fill_adv_rfl_opt_dttm 
,rx_vacc_info_race
,rx_vacc_info_ethnicity
,rx_vacc_info_comorbidity
,rx_create_yr
,rx_create_mnth
)
SELECT P.CDC_TXN_COMMIT_DTTM
 ,P.RX_NBR
 ,P.STR_NBR
 ,P.RX_CREATE_DT
 ,P.RX_CREATE_TM
 ,P.PAT_ID
 ,P.PBR_ID
 ,P.PBR_LOC_ID
 ,P.PBR_ORD_NBR
 ,P.DRUG_ID
 ,P.DEA_CLASS_CD
 ,P.DRUG_NON_SYS_CD
 ,P.DRUG_NON_SYS_NAME
 ,P.DRUG_NON_SYS_ASSIGN_NDC
 ,P.DRUG_NON_SYS_MFGR_NAME
 ,P.DRUG_SUB_CD
 ,P.ORD_DRUG_ID
 ,P.GENERIC_SUBSTN_PREF_IND
 ,P.FILL_UNLIMITED_IND
 ,P.FILL_QTY_DISPENSED
 ,P.FILL_DAYS_SUPPLY
 ,P.RX_DAW_CD
 ,P.RX_DAW_IND
 ,P.RX_SIG
 ,P.RX_STAT_CD
 ,P.RX_TOT_DSPN_QTY
 ,P.RX_WRITTEN_DT
 ,P.RX_WRITTEN_TM
 ,P.RX_ORIG_FILL_DTTM
 ,P.RX_ADDED_QTY
 ,P.RX_REFILL_EXPIRE_DT
 ,P.RX_REFILL_EXPIRE_TM
 ,P.RX_CMNT
 ,P.FILL_NBR_PRESCRIBED
 ,P.FILL_NBR_DSPN
 ,P.FILL_NBR_ADDED
 ,P.FILL_AUTO_IND
 ,P.FILL_NBR_LAST_DISP
 ,P.FILL_ENTERED_DTTM 
 ,P.IMAGE_ID
 ,P.SCAN_USER_ID
 ,P.SCAN_DT
 ,P.SCAN_TM
 ,P.SCAN_STR_NBR
 ,P.TIP_RX_IND
 ,P.ROUTE_STR_NBR
 ,P.PRICED_AS_NONSYS_IND
 ,P.WAG_INV_CTRL_NBR
 ,P.RELOCATE_FM_STR_NBR
 ,P.CREATE_USER_ID
 ,P.EDW_BATCH_ID
 ,P.UPDATE_USER_ID
 ,P.UPDATE_DTTM
 ,P.RX_ORIG_QTY_DSPN
 ,P.RX_ORIG_DAYS_SUPPLY
 ,P.RX_ORIG_QTY
 ,P.SRC_PARTITION_NBR
 ,P.diagnosis_cd_1
 ,P.diagnosis_cd_2
 ,P.diagnosis_cd_3
 ,P.diagnosis_cd_4
 ,P.diagnosis_cd_qlfr
 ,P.origin_cd
 ,P.rx_pad_barcode
 ,P.rx_pad_prgm_ind
 ,P.rx_vacc_mfg_lot_nbr 
 ,P.rx_vacc_exp_dttm 
 ,P.rx_vacc_area_of_admin 
 ,P.rx_vacc_consent_ind 
 ,P.rx_vacc_pnl_ent_dttm 
 ,P.rx_vacc_pnl_status_cd
 ,P.rx_90day_ind
 ,P.rx_90day_dttm
 ,P.rx_90day_stat_cd
 ,P.rx_90day_stat_dttm
 ,P.pbr_dea_nbr
 ,P.pbr_dea_suffix
 ,P.buyout_rx_cd
,P.diagnosis_cd_5
,P.diagnosis_cd_qlfr_2
,P.diagnosis_cd_qlfr_3
,P.diagnosis_cd_qlfr_4
,P.diagnosis_cd_qlfr_5
,P.trmt_type_cd
,P.fill_adv_rfl_opt_ind    
,P.fill_adv_rfl_opt_dttm 
,P.rx_vacc_info_race
,P.rx_vacc_info_ethnicity
,P.rx_vacc_info_comorbidity
,P.rx_create_yr
,P.rx_create_mnth
FROM $pTDDBName.prescription P,
(
SELECT RX_NBR, STORE_NBR, CREATE_DTTM
FROM $pTDStageDBLoc.etl_tbf0_rx_stg 
GROUP BY RX_NBR, STORE_NBR, CREATE_DTTM
) B  
WHERE P.RX_NBR = B.RX_NBR
 AND     P.STR_NBR = B.STORE_NBR""",
    [])
  ])
  #-- Below clause is commented so that this tables can be used for 730 day check as well
  #-- AND     P.RX_CREATE_DT = CAST(B.CREATE_DTTM AS DATE)
  #-- AND     P.RX_CREATE_TM = CAST(B.CREATE_DTTM AS TIME(0))
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("""call PRDUTIL.TABLE_STATS( '$pTDStageDB','ETL_PROC_RX_PRESC_STG')""",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  #------------------------------------------------------
  #-- IDENTIFY DUP INSERTS BY MATCHING TO THE TARGET WHERE TGT RX_CREATE_DT IS WITH THE 730 DAYS RANGE OF THE INCOMING CREATE_DTTM
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.V_dup_rx_inserts
select STG.store_nbr, STG.rx_nbr
 from $pTDStageDBLoc.etl_tbf0_rx_stg  STG,
   $pTDStageDB.ETL_PROC_RX_PRESC_STG  TGT
 where STG.store_nbr = TGT.str_nbr
 and STG.rx_nbr = TGT.rx_nbr
 and STG.cdc_operation_type_cd = 'INSERT'
 and TGT.rx_create_dt >= case when stg.store_nbr=3397 then (CAST(STG.create_dttm as date) - 365 ) else (CAST(STG.create_dttm as date) - 730) end 
and CAST ( CAST ( TGT.rx_create_dt AS CHAR(10 ) ) || ' ' || CAST ( TGT.rx_create_tm AS CHAR(08 ) ) AS TIMESTAMP(0) )  <> STG.create_dttm
group by STG.rx_nbr, STG.store_nbr""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- MOVE THE RECORDS INTO DUPS TABLE THAT ARE IDENTIFIED AS DUP INSERT FROM TGT
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_stg
(cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,pat_id                        
,drug_id                       
,drug_class                    
,drug_non_system_cd            
,pbr_id
,fill_qty_dispensed
,fill_days_supply                        
,rx_daw_ind                    
,rx_written_dttm               
,rx_original_fill_dttm
,rx_added_qty         
,rx_sig                        
,rx_refills_by_dttm            
,fill_nbr_prescribed           
,fill_nbr_dispensed            
,fill_nbr_added                
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm                 
,image_id                      
,scanned_user_id               
,scanned_dttm                  
,scanned_store_nbr             
,tip_rx_ind                    
,pbr_order_nbr                 
,drug_sub_cd                   
,pbr_loc_id                    
,pay_cd                        
,rx_comment                    
,rx_status_cd                  
,fill_unlimited_ind            
,ordered_drug_id               
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,generic_subs_pref             
,routing_store_nbr             
,rx_original_qty_disp          
,rx_original_days_supply       
,src_partition_nbr             
,rx_total_dispensed_qty        
,rx_original_qty
,DIAGNOSIS_CD                  
,DIAGNOSIS_CD_QUALIFIER        
,ORIGIN_CD                     
,DIAGNOSIS_CD_2                
,DIAGNOSIS_CD_3                
,DIAGNOSIS_CD_4                
,RX_PAD_PROGRAM_IND            
,RX_PAD_BARCODE
,rx_vacc_manuf_lot_nbr
,rx_vacc_exp_dttm
,rx_vacc_area_of_admin
,rx_vacc_consent_ind
,rx_vacc_pnl_ent_dttm
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,pat_id                        
,drug_id                       
,drug_class                    
,drug_non_system_cd            
,pbr_id
,fill_qty_dispensed
,fill_days_supply                        
,rx_daw_ind                    
,rx_written_dttm               
,rx_original_fill_dttm
,rx_added_qty         
,rx_sig                        
,rx_refills_by_dttm            
,fill_nbr_prescribed           
,fill_nbr_dispensed            
,fill_nbr_added                
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm                 
,image_id                      
,scanned_user_id               
,scanned_dttm                  
,scanned_store_nbr             
,tip_rx_ind                    
,pbr_order_nbr                 
,drug_sub_cd                   
,pbr_loc_id                    
,pay_cd                        
,rx_comment                    
,rx_status_cd                  
,fill_unlimited_ind            
,ordered_drug_id               
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,generic_subs_pref             
,routing_store_nbr             
,rx_original_qty_disp          
,rx_original_days_supply       
,src_partition_nbr             
,rx_total_dispensed_qty        
,rx_original_qty   
,DIAGNOSIS_CD                  
,DIAGNOSIS_CD_QUALIFIER        
,ORIGIN_CD                     
,DIAGNOSIS_CD_2                
,DIAGNOSIS_CD_3                
,DIAGNOSIS_CD_4                
,RX_PAD_PROGRAM_IND            
,RX_PAD_BARCODE
,rx_vacc_manuf_lot_nbr
,rx_vacc_exp_dttm
,rx_vacc_area_of_admin
,rx_vacc_consent_ind
,rx_vacc_pnl_ent_dttm
,rx_vacc_pnl_status_cd 
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
from $pTDStageDBLoc.etl_tbf0_rx_stg
where (store_nbr, rx_nbr) IN
 (select store_nbr, rx_nbr from $pTDStageDB.V_dup_rx_inserts)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETE THOSE RECORDS FROM ETL STAGE
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDBLoc.etl_tbf0_rx_stg
where (store_nbr, rx_nbr) IN
 (select store_nbr, rx_nbr from $pTDStageDB.V_dup_rx_inserts)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- CHECKING AND MOVING DATA IN THE DUPS TABLE FROM ETL STAGE TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_stg
(cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,pat_id                        
,drug_id                       
,drug_class                    
,drug_non_system_cd            
,pbr_id
,fill_qty_dispensed
,fill_days_supply                        
,rx_daw_ind                    
,rx_written_dttm               
,rx_original_fill_dttm
,rx_added_qty         
,rx_sig                        
,rx_refills_by_dttm            
,fill_nbr_prescribed           
,fill_nbr_dispensed            
,fill_nbr_added                
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm                 
,image_id                      
,scanned_user_id               
,scanned_dttm                  
,scanned_store_nbr             
,tip_rx_ind                    
,pbr_order_nbr                 
,drug_sub_cd                   
,pbr_loc_id                    
,pay_cd                        
,rx_comment                    
,rx_status_cd                  
,fill_unlimited_ind            
,ordered_drug_id               
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,generic_subs_pref             
,routing_store_nbr             
,rx_original_qty_disp          
,rx_original_days_supply       
,src_partition_nbr             
,rx_total_dispensed_qty        
,rx_original_qty             
,DIAGNOSIS_CD                  
,DIAGNOSIS_CD_QUALIFIER        
,ORIGIN_CD                     
,DIAGNOSIS_CD_2                
,DIAGNOSIS_CD_3                
,DIAGNOSIS_CD_4                
,RX_PAD_PROGRAM_IND            
,RX_PAD_BARCODE
,rx_vacc_manuf_lot_nbr
,rx_vacc_exp_dttm
,rx_vacc_area_of_admin
,rx_vacc_consent_ind
,rx_vacc_pnl_ent_dttm
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,pat_id                        
,drug_id                       
,drug_class                    
,drug_non_system_cd            
,pbr_id
,fill_qty_dispensed
,fill_days_supply                        
,rx_daw_ind                    
,rx_written_dttm               
,rx_original_fill_dttm
,rx_added_qty         
,rx_sig                        
,rx_refills_by_dttm            
,fill_nbr_prescribed           
,fill_nbr_dispensed            
,fill_nbr_added                
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm                 
,image_id                      
,scanned_user_id               
,scanned_dttm                  
,scanned_store_nbr             
,tip_rx_ind                    
,pbr_order_nbr                 
,drug_sub_cd                   
,pbr_loc_id                    
,pay_cd                        
,rx_comment                    
,rx_status_cd                  
,fill_unlimited_ind            
,ordered_drug_id               
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,generic_subs_pref             
,routing_store_nbr             
,rx_original_qty_disp          
,rx_original_days_supply       
,src_partition_nbr             
,rx_total_dispensed_qty        
,rx_original_qty     
,DIAGNOSIS_CD                  
,DIAGNOSIS_CD_QUALIFIER        
,ORIGIN_CD                     
,DIAGNOSIS_CD_2                
,DIAGNOSIS_CD_3                
,DIAGNOSIS_CD_4                
,RX_PAD_PROGRAM_IND            
,RX_PAD_BARCODE
,rx_vacc_manuf_lot_nbr
,rx_vacc_exp_dttm
,rx_vacc_area_of_admin
,rx_vacc_consent_ind
,rx_vacc_pnl_ent_dttm
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
from $pTDStageDBLoc.etl_tbf0_rx_stg
where (store_nbr, rx_nbr,create_dttm) IN
 (select store_nbr, rx_nbr, create_dttm
  from $pTDStageDB.etl_proc_dup_rx_stg)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------
  #-- DELETING DATA IN THE ETL STAGE TABLE WHICH IS PRESENT IN DUPS TABLE
  #------------------------------------------------------
  executeSql([], [
    ("""delete from $pTDStageDBLoc.etl_tbf0_rx_stg
where (store_nbr, rx_nbr, create_dttm) IN
 (select store_nbr, rx_nbr, create_dttm
  from $pTDStageDB.etl_proc_dup_rx_stg)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------ 
  #-- CHECKING FOR UPDATES NOT EXISTING IN THE TARGET TABLE
  #------------------------------------------------------ 
  executeSql([], [
    ("""INSERT INTO $APT_TERA_SYNC_DATABASE.etl_rx_missing_updates_stg  
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,pat_id                        
,drug_id                       
,drug_class                    
,drug_non_system_cd            
,pbr_id
,fill_qty_dispensed
,fill_days_supply                        
,rx_daw_ind                    
,rx_written_dttm               
,rx_original_fill_dttm
,rx_added_qty         
,rx_sig                        
,rx_refills_by_dttm            
,fill_nbr_prescribed           
,fill_nbr_dispensed            
,fill_nbr_added                
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm                 
,image_id                      
,scanned_user_id               
,scanned_dttm                  
,scanned_store_nbr             
,tip_rx_ind                    
,pbr_order_nbr                 
,drug_sub_cd                   
,pbr_loc_id                    
,pay_cd                        
,rx_comment                    
,rx_status_cd                  
,fill_unlimited_ind            
,ordered_drug_id               
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,generic_subs_pref             
,routing_store_nbr             
,rx_original_qty_disp          
,rx_original_days_supply       
,src_partition_nbr             
,rx_total_dispensed_qty        
,rx_original_qty         
,DIAGNOSIS_CD                  
,DIAGNOSIS_CD_QUALIFIER        
,ORIGIN_CD                     
,DIAGNOSIS_CD_2                
,DIAGNOSIS_CD_3                
,DIAGNOSIS_CD_4                
,RX_PAD_PROGRAM_IND            
,RX_PAD_BARCODE
,rx_vacc_manuf_lot_nbr
,rx_vacc_exp_dttm
,rx_vacc_area_of_admin
,rx_vacc_consent_ind
,rx_vacc_pnl_ent_dttm
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
)
SELECT 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,pat_id                        
,drug_id                       
,drug_class                    
,drug_non_system_cd            
,pbr_id
,fill_qty_dispensed
,fill_days_supply                        
,rx_daw_ind                    
,rx_written_dttm               
,rx_original_fill_dttm
,rx_added_qty         
,rx_sig                        
,rx_refills_by_dttm            
,fill_nbr_prescribed           
,fill_nbr_dispensed            
,fill_nbr_added                
,fill_auto_ind
,fill_nbr_last_disp
,fill_entered_dttm                 
,image_id                      
,scanned_user_id               
,scanned_dttm                  
,scanned_store_nbr             
,tip_rx_ind                    
,pbr_order_nbr                 
,drug_sub_cd                   
,pbr_loc_id                    
,pay_cd                        
,rx_comment                    
,rx_status_cd                  
,fill_unlimited_ind            
,ordered_drug_id               
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,generic_subs_pref             
,routing_store_nbr             
,rx_original_qty_disp          
,rx_original_days_supply       
,src_partition_nbr             
,rx_total_dispensed_qty        
,rx_original_qty          
,DIAGNOSIS_CD                  
,DIAGNOSIS_CD_QUALIFIER        
,ORIGIN_CD                     
,DIAGNOSIS_CD_2                
,DIAGNOSIS_CD_3                
,DIAGNOSIS_CD_4                
,RX_PAD_PROGRAM_IND            
,RX_PAD_BARCODE
,rx_vacc_manuf_lot_nbr
,rx_vacc_exp_dttm
,rx_vacc_area_of_admin
,rx_vacc_consent_ind
,rx_vacc_pnl_ent_dttm
,rx_vacc_pnl_status_cd
,rx_90day_pref_ind
,rx_90day_pref_dttm
,rx_90day_pref_stat_cd
,rx_90day_pref_stat_dttm
,pbr_dea_nbr
,pbr_dea_suf
,buyout_rx_ind
,diagnosis_cd_5
,diagnosis_cd_qualifier_2
,diagnosis_cd_qualifier_3
,diagnosis_cd_qualifier_4
,diagnosis_cd_qualifier_5
,trmt_type_cd
 FROM $pTDStageDBLoc.etl_tbf0_rx_stg
WHERE (STORE_NBR, RX_NBR, CREATE_DTTM) IN (
SELECT STORE_NBR, RX_NBR, CREATE_DTTM FROM $pTDStageDBLoc.etl_tbf0_rx_stg 
WHERE CDC_OPERATION_TYPE_CD='SQL COMPUPDATE'
MINUS
SELECT STORE_NBR, RX_NBR, CREATE_DTTM FROM $pTDStageDBLoc.etl_tbf0_rx_stg 
WHERE CDC_OPERATION_TYPE_CD='INSERT'
MINUS
SELECT STR_NBR, RX_NBR,CAST ( CAST ( rx_create_dt AS CHAR(10 ) ) || ' ' || CAST ( rx_create_tm AS CHAR(08 ) ) AS TIMESTAMP(0) ) RX_CREATE_DTTM  FROM $pTDStageDB.ETL_PROC_RX_PRESC_STG)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--- delete  from stage
  executeSql([], [
    ("""DELETE FROM $pTDStageDBLoc.etl_tbf0_rx_stg
WHERE (STORE_NBR, RX_NBR,CREATE_DTTM, CDC_TXN_COMMIT_DTTM, CDC_SEQ_NBR, CDC_RBA_NBR) IN
(SELECT STORE_NBR, RX_NBR,CREATE_DTTM, CDC_TXN_COMMIT_DTTM, CDC_SEQ_NBR, CDC_RBA_NBR FROM $APT_TERA_SYNC_DATABASE.etl_rx_missing_updates_stg)""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*==================================================================================**
  #--BC ** APPLY PAT_ID FIX IN PRESCRIPTION_FILL DUE TO PATIENT MERGE IN THE SAME PARTITION **
  #--BC **===================================================================================*/
  #--------------------------------------------------
  #--- GET ALL THE 'AFTER' RECORDS FROM ETL_TBF0_RX
  #--------------------------------------------------
  executeSql([], [
    ("""CREATE temporary TABLE $pTDStageDB.vt_etl_tbf0_rx
(
      cdc_txn_commit_dttm TIMESTAMP,
      cdc_seq_nbr INTEGER,
      cdc_rba_nbr DECIMAL(18,0),
      cdc_operation_type_cd CHAR(20),
      cdc_before_after_cd CHAR(10),
      store_nbr DECIMAL(5,0) NOT NULL,
      rx_nbr DECIMAL(7,0) NOT NULL,
      create_dttm TIMESTAMP,
      pat_id DECIMAL(13,0),
      edw_rank INTEGER
)
ON COMMIT PRESERVE ROWS""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
  #-- TABLE_INDEX - Remove table index options
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.vt_etl_tbf0_rx
SELECT
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,store_nbr
,rx_nbr
,create_dttm
,pat_id
,RANK() OVER (PARTITION BY store_nbr, rx_nbr, create_dttm, pat_id ORDER BY cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr) edw_rank
FROM $pTDStageDBLoc.etl_tbf0_rx_stg
WHERE cdc_before_after_cd  = 'AFTER'
  AND cdc_operation_type_cd  IN ('SQL COMPUPDATE','INSERT')""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------------------
  #--- CREATE TEMP TABLE FOR THE Rx KEYS FROM THE ETL_TBF0_RX TABLE
  #--- OF THE PREVIOUS AND CURRENT BATCH
  #------------------------------------------------------------------
  executeSql([], [
    ("""CREATE temporary TABLE $pTDStageDB.vt_prev_curr_etl_tbf0_rx
(
      cdc_txn_commit_dttm TIMESTAMP,
      cdc_seq_nbr INTEGER,
      cdc_rba_nbr DECIMAL(18,0),
      cdc_operation_type_cd CHAR(20),
      cdc_before_after_cd CHAR(10),
      store_nbr DECIMAL(5,0) NOT NULL,
      rx_nbr DECIMAL(7,0) NOT NULL,
      create_dttm TIMESTAMP,
      pat_id DECIMAL(13,0),
      edw_rank INTEGER
)
ON COMMIT PRESERVE ROWS""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
  #-- TABLE_INDEX - Remove table index options
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #----------------------------------------------------------------------
  #--- APPLY STORE RELO TO THE PREVIOUS Rx KEYS FROM THE PREVIOUS BATCH
  #----------------------------------------------------------------------
  executeSql([], [
    ("""UPDATE $pTDStageDB.prev_batch_etl_tbf0_rx_keys_stg

SET store_nbr = SR.relocate_to_str_nbr
 FROM $pTDDBNameOth.location_store_relocation SR
   WHERE store_nbr = SR.relocate_fm_str_nbr""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #-----------------------------------------------------------------
  #---  POPULATE THE vt_prev_curr_etl_tbf0_rx TEMP TABLE BY GETTING
  #---  THE CDC, Rx KEYS and PAT_ID FROM ETL_TBF0_RX TABLE OF THE
  #---  PREVIOUS AND CURRENT BATCH
  #-----------------------------------------------------------------
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.vt_prev_curr_etl_tbf0_rx
SELECT
    cdc_txn_commit_dttm,
    cdc_seq_nbr,
    cdc_rba_nbr,
    cdc_operation_type_cd,
    cdc_before_after_cd,
    store_nbr,
    rx_nbr,
    create_dttm,
    pat_id,
    RANK() OVER (PARTITION BY store_nbr, rx_nbr
        ORDER BY cdc_txn_commit_dttm, cdc_seq_nbr, cdc_rba_nbr) edw_rank
FROM
(
     SELECT
         ETL.cdc_txn_commit_dttm,
         ETL.cdc_seq_nbr,
         ETL.cdc_rba_nbr,
         ETL.cdc_operation_type_cd,
         ETL.cdc_before_after_cd,
         ETL.store_nbr,
         ETL.rx_nbr,
         ETL.create_dttm,
         ETL.pat_id
    FROM    $pTDStageDBLoc.etl_tbf0_rx_stg  ETL,
         (SELECT store_nbr, rx_nbr, create_dttm, pat_id
          FROM $pTDStageDB.vt_etl_tbf0_rx
          WHERE (store_nbr, rx_nbr, create_dttm, pat_id, edw_rank) IN
             (SELECT  store_nbr, rx_nbr, create_dttm, pat_id, MAX(edw_rank)
              FROM $pTDStageDB.vt_etl_tbf0_rx
              GROUP BY 1,2,3,4)
         ) MX
   WHERE
       cdc_before_after_cd  = 'AFTER'
       AND  cdc_operation_type_cd  IN
           ('SQL COMPUPDATE','INSERT')
       AND  ETL.store_nbr = MX.store_nbr
       AND  ETL.rx_nbr = MX.rx_nbr
       AND  ETL.create_dttm = MX.create_dttm
       AND  ETL.pat_id = MX.pat_id

   UNION

   SELECT
       cdc_txn_commit_dttm,
       cdc_seq_nbr,
       cdc_rba_nbr,
       cdc_operation_type_cd,
       cdc_before_after_cd,
       store_nbr,
       rx_nbr,
       create_dttm,
       pat_id
   FROM  $pTDStageDB.prev_batch_etl_tbf0_rx_keys_stg
) a""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #---------------------------------------------------------------------------
  #--- Populate $pTDStageDB.pat_id_merge_change_stg to update PRESCRIPTION_FILL
  #---------------------------------------------------------------------------
  executeSql([], [
    ("""CREATE temporary TABLE $pTDStageDB.VT_batch_rnk
(
   edw_batch_id DECIMAL(18,0),
   edw_rank INTEGER
)
ON COMMIT PRESERVE ROWS""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- TABLE_INDEX - Remove table index options
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.VT_batch_rnk
SELECT edw_batch_id,
       RANK() OVER (ORDER BY edw_batch_id DESC) edw_rank
  FROM $pTDViewDBName.patient_merge
 GROUP BY edw_batch_id""",
    [])
  ])
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.pat_id_merge_change_stg""",
    [])
  ])
  #-- DEL_ALL - Remove ALL keyword from DELETE statement
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.pat_id_merge_change_stg
 SELECT
    VT.store_nbr,
    VT.rx_nbr,
    VT.create_dttm,
    PM.merged_fm_pat_id  frm_pat_id,
    MX.pat_id   to_pat_id,
    'N' change_prcs_ind,
    0 edw_batch_id
 FROM  $pTDStageDB.vt_prev_curr_etl_tbf0_rx  VT,
         (SELECT store_nbr, rx_nbr, create_dttm, pat_id
          FROM $pTDStageDB.vt_prev_curr_etl_tbf0_rx
          WHERE (store_nbr, rx_nbr, edw_rank) IN
              (SELECT  store_nbr, rx_nbr, MAX(edw_rank)
               FROM $pTDStageDB.vt_prev_curr_etl_tbf0_rx
               GROUP BY store_nbr, rx_nbr)
          ) MX,
          $pTDViewDBName.patient_merge PM
 WHERE
        VT.pat_id = PM.pat_id
        AND VT.store_nbr = MX.store_nbr
        AND VT.rx_nbr = MX.rx_nbr
        AND (PM.edw_batch_id) IN
            (select edw_batch_id
             from $pTDStageDB.VT_batch_rnk
             where edw_rank < 5)
 GROUP BY 1,2,3,4,5,6,7""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--CALL PRDUTIL.TABLE_STATS('$pTDStageDB', 'pat_id_merge_change_stg');
  #--------------------------------------------------------
  #-- Prescription_Fill is updated in Rx_Fill post process
  #--------------------------------------------------------
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  return

main()
cleanup()
done()
ZZ

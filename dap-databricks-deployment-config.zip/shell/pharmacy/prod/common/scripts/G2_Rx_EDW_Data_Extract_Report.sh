#!/bin/sh
set -x

ENV=prod
APP_USER=edwphrm
APP_PASSWORD=phrmbt1101
DOMAIN=pa1sia-pfa001
DOMAIN_PORT=9080
SERVER=pa1sia-pfa001
SERVER_PORT=31542
DS_JOB1=Seq_rx_G2_feed
##DS_JOB2=EDW_GenExtr_030_fill_fkeys_rx_pat_patplan_pbr_seq
##DS_JOB3=SDI_xform_daily_extract_seq_IL
##DS_JOBINV=NOINVID
##DS_PROJECT_PHRMRTN=edw_phrmrtn_prd
DS_PROJECT_PHRMACY=edw_pharmacy_prd
DS_CONNECT="$DOMAIN:$DOMAIN_PORT $SERVER:$SERVER_PORT"
CREDENTIAL_FILE=/usr/local/edw/pharmacy/${ENV}/common/config/Rx_G2_ds_credentials.dat
touch $CREDENTIAL_FILE
print "$DOMAIN:$DOMAIN_PORT,$SERVER:$SERVER_PORT,$APP_USER,$APP_PASSWORD" > $CREDENTIAL_FILE
chmod 770 $CREDENTIAL_FILE
TIME_HR=`date +%Y%m%d`

LOG_FILE=/usr/local/edw/pharmacy/${ENV}/audit/Rx_G2_${TIME_HR}.log
pEMAILADDR=Satish.nallamothu@walgreens.com


dsjob -file $CREDENTIAL_FILE $DS_CONNECT \
        -run -wait -jobstatus \
        $DS_PROJECT_PHRMACY $DS_JOB1 \
        >> $LOG_FILE 2>> $ERR_FILE

RC=$?
if [ $RC -ne 1 ] &&  [ $RC -ne 2 ]
then
  echo "Rx_G2  GENEXTR FAILURE" >> $LOG_FILE
  echo "Rx_G2 GENEXTR FAILURE " | mail -s "Rx_G2  GENEXTR FAILURE " $pEMAILADDR,$pSUPPORTPHN
  exit 1
else
  echo "Rx_G2 GENEXTR SUCCESS" >> $LOG_FILE
fi
exit 0; 


#!/bin/sh


LC_ALL=en_US
export LC_ALL

FTPSERVER=wag1l
FTPUSER=xfer125
DIRLOADREADY=$3
EDWBATCHID=$4
LOG_FILE=$5
MAXFILLENTERDT=$6
EDWRXEMLADDR=$7
EDWBATCHDT=`print $EDWBATCHID | cut -c1-8`

MAXFILLENTERDT=`echo $MAXFILLENTERDT | tr -d '-'`

echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "--------------- STARTING SCRIPT SDI_data_feed_postproc_v01.sh ---------------" >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "FTPSERVER        = " $FTPSERVER                                                >> $LOG_FILE
echo "FTPUSER          = " $FTPUSER                                                  >> $LOG_FILE
echo "DIRLOADREADY     = " $DIRLOADREADY                                             >> $LOG_FILE
echo "EDWBATCHID       = " $EDWBATCHID                                               >> $LOG_FILE
echo "LOG_FILE         = " $LOG_FILE                                                 >> $LOG_FILE
echo "EMAILTOADDR      = " $EMAILTOADDR                                              >> $LOG_FILE
echo "EDWBATCHDT       = " $EDWBATCHDT                                               >> $LOG_FILE
echo "MAXFILLENTERDT   = " $MAXFILLENTERDT                                           >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE


##################################################################################
# READ EACH LINE OF THE UNIQUE FILL ENTER DATE FILE LIST CREATED IN DATASTAGE    #
# ASSIGN THAT FILL ENTER DATE TO ITS OWN PARAMETER NAME                          #
# PARSE EACH RECORD OF THE WEEKLY DATA FILE FOR THE FILL_ENTER_DT                #
# REDIRECT THE OUTPUT OF THAT RECORD TO ITS CORRESPONDING FILLENTERDT DAILY FILE #
##################################################################################

FILLENTERDT_1=00000000
FILLENTERDT_2=00000000
FILLENTERDT_3=00000000
FILLENTERDT_4=00000000
FILLENTERDT_5=00000000
FILLENTERDT_6=00000000
FILLENTERDT_7=00000000
FILLENTERDT_8=00000000
FILLENTERDT_9=00000000
FILLENTERDT_10=00000000
FILLENTERDT_11=00000000
FILLENTERDT_12=00000000
FILLENTERDT_13=00000000
FILLENTERDT_14=00000000
FILLENTERDT_15=00000000

i=0
while read line
do
   i=`expr $i + 1`
   export FILLENTERDT_${i}=${line}
   export SDIFILE_${i}=$DIRLOADREADY/WAG_125_${line}_01.dat
done < $DIRLOADREADY/SDI_data_feed_01_IL_unique_fillenterdts.dat

SDIREJECTFILE=$DIRLOADREADY/SDI_data_feed_IL_19000101115959.rej

awk '                                                                           \
{                                                                               \
inrecFILLENTER = substr($0,22,8);                                               \
if ( inrecFILLENTER == '$FILLENTERDT_1' ) {print $0 > "'$SDIFILE_1'"}           \
   else if ( inrecFILLENTER == '$FILLENTERDT_2' ) {print $0 > "'$SDIFILE_2'"}   \
   else if ( inrecFILLENTER == '$FILLENTERDT_3' ) {print $0 > "'$SDIFILE_3'"}   \
   else if ( inrecFILLENTER == '$FILLENTERDT_4' ) {print $0 > "'$SDIFILE_4'"}   \
   else if ( inrecFILLENTER == '$FILLENTERDT_5' ) {print $0 > "'$SDIFILE_5'"}   \
   else if ( inrecFILLENTER == '$FILLENTERDT_6' ) {print $0 > "'$SDIFILE_6'"}   \
   else if ( inrecFILLENTER == '$FILLENTERDT_7' ) {print $0 > "'$SDIFILE_7'"}   \
   else if ( inrecFILLENTER == '$FILLENTERDT_8' ) {print $0 > "'$SDIFILE_8'"}   \
   else if ( inrecFILLENTER == '$FILLENTERDT_9' ) {print $0 > "'$SDIFILE_9'"}   \
   else if ( inrecFILLENTER == '$FILLENTERDT_10' ) {print $0 > "'$SDIFILE_10'"} \
   else if ( inrecFILLENTER == '$FILLENTERDT_11' ) {print $0 > "'$SDIFILE_11'"} \
   else if ( inrecFILLENTER == '$FILLENTERDT_12' ) {print $0 > "'$SDIFILE_12'"} \
   else if ( inrecFILLENTER == '$FILLENTERDT_13' ) {print $0 > "'$SDIFILE_13'"} \
   else if ( inrecFILLENTER == '$FILLENTERDT_14' ) {print $0 > "'$SDIFILE_14'"} \
   else if ( inrecFILLENTER == '$FILLENTERDT_15' ) {print $0 > "'$SDIFILE_15'"} \
else {print $0 > "'$SDIREJECTFILE'"}                                            \
}'                                                                              \
$DIRLOADREADY/SDI_data_feed_01_IL_${MAXFILLENTERDT}115959.dat

if [ -s $SDIREJECTFILE ]
then
   echo "*--------------------------------------------------------------------------------*" >> $LOG_FILE
   echo "FILL_ENTER_DT FOUND IN DATA FILE WHICH DOES NOT EXIST IN UNIQUE FILL_ENTER_DT LIST" >> $LOG_FILE
   echo "*--------------------------------------------------------------------------------*" >> $LOG_FILE
   exit 1
fi


###################################################################################
##### FTP SDIFILES AS LONG AS THE FILES EXISTS                                #####
###################################################################################

###################################################################################
# Exiting the script as we do not need to ftp the files
###################################################################################
exit 0
 
for i in $SDIFILE_1 $SDIFILE_2 $SDIFILE_3 $SDIFILE_4 $SDIFILE_5 $SDIFILE_6 $SDIFILE_7 $SDIFILE_8 $SDIFILE_9 $SDIFILE_10 $SDIFILE_11 $SDIFILE_12 $SDIFILE_13 $SDIFILE_14 $SDIFILE_15
do
   if [ -s ${i} ]
   then
      echo "------------------------------------" >> $LOG_FILE
      echo "GZIPPING / SENDING SDI FILE $i      " >> $LOG_FILE
      echo "------------------------------------" >> $LOG_FILE
      SFTPi=`basename ${i}.gz | sed 's/.gz$//'`
      gzip ${i}
      print "put ${i}.gz '/data02/xfer125/in/${SFTPi}.tmp.gz'" > $DIRLOADREADY/SDI_FILE_SFTP_PUT_CMD1_IL
      sftp -b $DIRLOADREADY/SDI_FILE_SFTP_PUT_CMD1_IL $FTPUSER@$FTPSERVER
      RC=$?
      if [ $RC -ne 0 ]
      then
         echo "-------------------------" >> $LOG_FILE
         echo "SDI FILE $i SFTP FAILURE " >> $LOG_FILE
         echo "-------------------------" >> $LOG_FILE
         uuencode $LOG_FILE $LOG_FILE | mail -s "SDI FILE 01 SFTP FAILURE - REQUIRES INVESTIGATION" $EDWRXEMLADDR
         exit 1
      else
         echo "-------------------------" >> $LOG_FILE
         echo "SDI FILE $i SFTP SUCCESS " >> $LOG_FILE
         echo "-------------------------" >> $LOG_FILE
         rm $DIRLOADREADY/SDI_FILE_SFTP_PUT_CMD1_IL
      fi

      echo "------------------------------------" >> $LOG_FILE
      echo "RENAMING SDI FILE $i                " >> $LOG_FILE
      echo "------------------------------------" >> $LOG_FILE
      print "rename /data02/xfer125/in/${SFTPi}.tmp.gz '/data02/xfer125/in/${SFTPi}.gz'" > $DIRLOADREADY/SDI_FILE_SFTP_PUT_CMD2_IL
      sftp -b $DIRLOADREADY/SDI_FILE_SFTP_PUT_CMD2_IL $FTPUSER@$FTPSERVER
      RC=$?
      if [ $RC -ne 0 ]
      then
         echo "-------------------------" >> $LOG_FILE
         echo "RENAME FILE $i FAILURE   " >> $LOG_FILE
         echo "-------------------------" >> $LOG_FILE
         uuencode $LOG_FILE $LOG_FILE | mail -s "SDI FILE $i FAILURE - REQUIRES INVESTIGATION" $EDWRXEMLADDR
         exit 1
      else
         echo "-------------------------" >> $LOG_FILE
         echo "RENAME FILE $i SUCCESS   " >> $LOG_FILE
         echo "-------------------------" >> $LOG_FILE
         rm $DIRLOADREADY/SDI_FILE_SFTP_PUT_CMD2_IL
      fi

   else
      echo "--------------------------" >> $LOG_FILE
      echo "SDI FILE $i DOES NOT EXIST" >> $LOG_FILE
      echo "--------------------------" >> $LOG_FILE
   fi
done
RC=$?

#!/bin/sh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
###################################################################################
##### THIS SCRIPT WILL RETRIEVE THE CNT OF FILLS BY STR BY MONTH FOR THE      #####
##### 90 DAY FILL ACTIVITIES                                                  #####
##### AUTHOR = CHIRAG PATEL (chirag.patel@walgreens.com)                      #####
##### DATE CREATED    = 20091208 CHIRAG PATEL                                 #####
##### DATE MODIFIED   =                                                       #####
##### DATE MODIFIED   =                                                       #####
###################################################################################
SQ_SERVER=$1
SQ_USER=$2
SQ_PASSWORD=$3
PROCDTRNGOUT=$4
LOG_FILE=$5

echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "------------ STARTING SCRIPT EDW_90_day_fills_get_date_ranges.sh ------------" >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "SQ_SERVER        = " $SQ_SERVER                                                >> $LOG_FILE
echo "TD_USER          = " $SQ_USER                                                  >> $LOG_FILE
echo "LOG_FILE         = " $LOG_FILE                                                 >> $LOG_FILE
echo "PROCDTRNGOUT     = " $PROCDTRNGOUT                                             >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "                                                                             " >> $LOG_FILE

###################################################################################
##### RETRIEVE THE FOLLOWING COLUMNS FOR USE IN LIMITING QUERY TO PREV MONTH  #####
##### CURRENT_DT - (DAY FROM CURRENT_DT)                                      #####
#####                               = PREVIOUS MONTH END DT                   #####
##### PREVIOUS MONTH END DT - (DAY FROM (PREV MONTH END DT)) - 1              #####
#####                               = PREVIOUS MONTH BEGIN DATE               #####
##### LOGIC SHOWN ABOVE IS FOR RETRIEVING ONLY THE PREV MONTH END/BEGIN DTs   #####
##### LOGIC FOR RETRIEVING THE PREV-PREV MONTH END/BEGIN DTs -> ANALYZE CODE  #####
###################################################################################
  python3 << EOF >> $LOG_FILE
import os
import sys
import pyodbc
from npjet import *

def main():
  global cnxn
  cnxn = getDBConnectionSQLServer(Action.quietLevel)
  global cursor
  cursor = cnxn.cursor()

  try:
    cursor.execute("""SELECT CONVERT(VARCHAR, DATEADD(DAY, -(DAY(GETDATE())), GETDATE()), 23) + '|' 
+ CONVERT(VARCHAR, DATEADD(mm, DATEDIFF(mm, 0, GETDATE()) - 1, 0), 23)  + '|' 
+ CONVERT(VARCHAR, DATEADD(mm, DATEDIFF(mm, 0, GETDATE()) - 1, -1), 23) + '|' 
+ CONVERT(VARCHAR, DATEADD(mm, DATEDIFF(mm, 0, GETDATE()) - 1 -1, 0), 23) as PROCDTRNGOUT;""")
    errorCode=0
  except pyodbc.Error as ex:
    errorCode=ex.args[0]

  if (errorCode == 0):
    SELSUCCESS()
    return
  Action.errorCodeOverride = 1
  return
  SELSUCCESS()
def SELSUCCESS():
  PROCDTRNGOUT = cursor.fetchone()
  if (PROCDTRNGOUT is None):
    PROCDTRNGOUT=''
  else: 
    PROCDTRNGOUT = PROCDTRNGOUT[0]
  with open('$PROCDTRNGOUT', 'w') as f:
    f.write(str(PROCDTRNGOUT))
  Action.errorCodeOverride = 0
  cursor.close()
  cnxn.close()
  return
main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ]
then
  echo "---------------------------------" >> $LOG_FILE
  echo "FILL SOLD DT RANGES QUERY FAILURE" >> $LOG_FILE
  echo "---------------------------------" >> $LOG_FILE
  uuencode $LOG_FILE $LOG_FILE | mail -s "FILL SOLD DATE RANGE QUERY FAILURE" $EDWRXEMLADDR
  exit 1
else
  echo "---------------------------------" >> $LOG_FILE
  echo "FILL SOLD DT RANGES QUERY SUCCESS" >> $LOG_FILE
  echo "---------------------------------" >> $LOG_FILE
  CURRFILLSDDT_MAX=`cut -f1 -d"|" $PROCDTRNGOUT | tr -d ' '`
  CURRFILLSDDT_MIN=`cut -f2 -d"|" $PROCDTRNGOUT | tr -d ' '`
  PREVFILLSDDT_MAX=`cut -f3 -d"|" $PROCDTRNGOUT | tr -d ' '`
  PREVFILLSDDT_MIN=`cut -f4 -d"|" $PROCDTRNGOUT | tr -d ' '`
  echo "CURRFILLSDDT_MAX = " $CURRFILLSDDT_MAX    >> $LOG_FILE
  echo "CURRFILLSDDT_MIN = " $CURRFILLSDDT_MIN    >> $LOG_FILE
  echo "PREVFILLSDDT_MAX = " $PREVFILLSDDT_MAX    >> $LOG_FILE
  echo "PREVFILLSDDT_MIN = " $PREVFILLSDDT_MIN    >> $LOG_FILE
  echo "                                        " >> $LOG_FILE
fi

#!/bin/sh

###################################################################################
##### THIS SCRIPT WILL RETRIEVE THE CNT OF FILLS BY STR BY MONTH FOR THE      #####
##### 90 DAY FILL ACTIVITIES                                                  #####
##### AUTHOR = CHIRAG PATEL (chirag.patel@walgreens.com)                      #####
##### DATE CREATED    = 20091208 CHIRAG PATEL                                 #####
##### DATE MODIFIED   =                                                       #####
###################################################################################

FTP_SERVER=$1
FTP_USER=$2
FTP_PASSWORD=$3
DIRLOADREADY=$4
CURRENTREPORTMNTH=$5
EDW90DAYFILLFFW=$6
CONTROLRECCNT=$7
LOG_FILE=$8
EDWRXEMLADDR=$9
##REQUESTOREMLADDR=chirag.patel@walgreens.com

echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "-------------- STARTING SCRIPT TCRx_nonRx_nonPSE_daily_feed.sh --------------" >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "FTP_SERVER       = " $FTP_SERVER                                               >> $LOG_FILE
echo "FTP_USER         = " $FTP_USER                                                 >> $LOG_FILE
echo "FTP_PASSWORD     = " $FTP_PASSWORD                                             >> $LOG_FILE
echo "LOG_FILE         = " $LOG_FILE                                                 >> $LOG_FILE
echo "CURRENTREPORTMNTH= " $CURRENTREPORTMNTH                                        >> $LOG_FILE
echo "EDW90DAYFILLFFW  = " $EDW90DAYFILLFFW                                          >> $LOG_FILE
echo "CONTROLRECCNT    = " $CONTROLRECCNT                                            >> $LOG_FILE
echo "DIRLOADREADY     = " $DIRLOADREADY                                             >> $LOG_FILE
echo "EDWRXEMLADDR     = " $EDWRXEMLADDR                                             >> $LOG_FILE
echo "REQUESTOREMLADDR = " $REQUESTOREMLADDR                                         >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "                                                                             " >> $LOG_FILE

###################################################################################
##### CREATE AN FTP FILENAME BASED ON THE CURRENT REPORTING MONTH             #####
###################################################################################
#FTPFILENAME=`echo $CURRENTREPORTMNTH | tr -d "-"`.EDW90DAY
FTPFILENAME=FI.MF210000.SCRIPT90.DAY
echo "FTPFILENAME      = " $FTPFILENAME                                              >> $LOG_FILE


###################################################################################
##### TRANSFORM DS OUTPUT FILE BY REMOVING SPACES AND PERIODS                 #####
##### ADD CONTROL RECORD TO END OF FILE BY SUMMING 3rd COLUMN IN OUTPUT FILE  #####
###################################################################################
cd $DIRLOADREADY
rm $FTPFILENAME.tmp1
awk -F"." '{sum+=$3} END {printf("$$$$$190001%09d\n",sum)}' $EDW90DAYFILLFFW > $CONTROLRECCNT 
cat $EDW90DAYFILLFFW | tr -d " ." >> $FTPFILENAME.tmp1
cat $CONTROLRECCNT >> $FTPFILENAME.tmp1
#exit 0

###################################################################################
##### FTP THE ADHOC QUERY OUTPUT TO VM15RSCS IF ROWS ARE RETURNED             #####
##### ALSO EMAIL EDW90DAYFILLSOUTPUT TO EDW-RX EMAIL ADDR FOR CONFIRMATION    #####
##### ALSO RETRIEVE THE FTP'd FILE IN ORDER TO VERIFY FTP SUCCESS             #####
###################################################################################
if [ -s $FTPFILENAME.tmp1 ]
then
  echo "-------------------------" >> $LOG_FILE
  echo "SENDING QUERY OUTPUT FILE" >> $LOG_FILE
  echo "-------------------------" >> $LOG_FILE
  uuencode $FTPFILENAME.tmp1 $FTPFILENAME.tmp1 | mail -s "EDW_90_DAY_FILLS_BY_STR_BY_MNTH FOR $CURRENTREPORTMNTH" $REQUESTOREMLADDR

ftp -inv $FTP_SERVER <<END_FTP
user $FTP_USER $FTP_PASSWORD
put $DIRLOADREADY/$FTPFILENAME.tmp1 '$FTPFILENAME'
get '$FTPFILENAME' $DIRLOADREADY/$FTPFILENAME
quit
END_FTP

if [ -f $DIRLOADREADY/$FTPFILENAME ]
then
  echo "-----------" >> $LOG_FILE
  echo "FTP SUCCESS" >> $LOG_FILE
  echo "-----------" >> $LOG_FILE
  rm -f $DIRLOADREADY/$FTPFILENAME
else
  echo "-----------" >> $LOG_FILE
  echo "FTP FAILURE" >> $LOG_FILE
  echo "-----------" >> $LOG_FILE
  uuencode $LOG_FILE $LOG_FILE | mail -s "FTP FAILURE" $EDWRXEMLADDR
  exit 1
fi

else
  echo "----------------------------------------------------------" >> $LOG_FILE
  echo "NO ROWS RETURNED FOR 90 DAY FILLS - REQUIRES INVESTIGATION" >> $LOG_FILE
  echo "----------------------------------------------------------" >> $LOG_FILE
  uuencode $LOG_FILE $LOG_FILE | mail -s "NO ROWS RETURNED FOR 90 DAY FILLS - INVESTIGATE" $EDWRXEMLADDR
fi

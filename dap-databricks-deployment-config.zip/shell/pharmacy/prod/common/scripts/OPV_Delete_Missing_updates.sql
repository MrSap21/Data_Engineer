#!/usr/bin/python3

from npjet import *

def main():

  executeSql([], [
    ("""Insert into prdetl.etl_rx_missing_updates_bkp Select * from prdetl.etl_rx_missing_updates;""",
    [])
  ])
  executeSql([], [
    ("""Delete from prdetl.etl_rx_missing_updates;""",
    [])
  ])

if __name__ == '__main__':
  main()
  cleanup()
  done()

#!/bin/sh
pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
APT_TERA_SYNC_DATABASE=$7

python3 <<ZZ
#!/usr/bin/python3

#import os
#import sys

#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():

  #/* Post Load Update for Child Dates (from header)                 */
  executeSql([], [
    ("""CREATE TABLE $APT_TERA_SYNC_DATABASE.V_rx_cntrl_post 
     (
      str_nbr INTEGER NOT NULL,
      rx_nbr INTEGER NOT NULL,
      rx_fill_nbr INTEGER NOT NULL ,
      rx_partial_fill_nbr INTEGER NOT NULL,
      fill_enter_dttm TIMESTAMP
      );
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- TABLE_INDEX - Remove table index options
""",
    [])
  ])
  executeSql([], [
    ("""insert into $APT_TERA_SYNC_DATABASE.V_rx_cntrl_post
(
      str_nbr,
      rx_nbr,      
      rx_fill_nbr,
      rx_partial_fill_nbr,
      fill_enter_dttm
)      
select 
      F.str_nbr,
      F.rx_nbr,      
      F.rx_fill_nbr,
      F.rx_partial_fill_nbr,
      max(case when fill_enter_dt is null then cast('2099-12-31 12:12:12' as timestamp(0)) else cast(fill_enter_dt||' ' || cast(fill_enter_tm as varchar(8)) as timestamp(0)) end )as fill_enter_dttm
from $pTDViewDBName.prescription_fill F, $pTDViewDBName.prescription_control_substance T
where  
 F.str_nbr=T.str_nbr
and F.rx_nbr=T.rx_nbr
and F.rx_fill_nbr=T.rx_fill_nbr
and F.rx_partial_fill_nbr=T.rx_partial_fill_nbr
and (cast(fill_enter_dt||' ' ||cast(fill_enter_tm as varchar(8)) as timestamp(0))  <= T.create_dttm Or fill_enter_dt is null)
and T.rx_create_dt is null
group by 1,2,3,4;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_control_substance T
set rx_create_dt = F.rx_create_dt
       ,fill_sold_dt=F.fill_sold_dt
FROM    $APT_TERA_SYNC_DATABASE.V_rx_cntrl_post TRX,
   $pTDViewDBName.prescription_fill F
where 
T.rx_nbr = TRX.rx_nbr
and T.str_nbr = TRX.str_nbr
and T.rx_fill_nbr = TRX.rx_fill_nbr
and T.rx_partial_fill_nbr = TRX.rx_partial_fill_nbr
and TRX.rx_nbr=F.rx_nbr
and TRX.str_nbr=F.str_nbr
and TRX.rx_fill_nbr=F.rx_fill_nbr
and TRX.rx_partial_fill_nbr=F.rx_partial_fill_nbr
and TRX.fill_enter_dttm=case when F.fill_enter_dt is null then cast('2099-12-31 12:12:12' as timestamp(0)) else cast(F.fill_enter_dt||' ' ||cast(F.fill_enter_tm as varchar(8)) as timestamp(0))  end
and T.rx_create_dt IS NULL;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""drop table if exists $APT_TERA_SYNC_DATABASE.V_rx_cntrl_post;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  return

if __name__ == '__main__':
  main()
  cleanup()
  done()

ZZ


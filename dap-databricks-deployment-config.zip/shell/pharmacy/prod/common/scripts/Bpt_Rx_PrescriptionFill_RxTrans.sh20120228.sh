#!/bin/sh

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
pTDEDWTargetTable=$7

python3 <<ZZ
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.ETL_ENDATED_FILL_RX_TRANS""",
    [])
  ])
  #-- DEL_ALL - Remove ALL keyword from DELETE statement
  if (Action.errorCode != 0):
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.ETL_ENDATED_FILL_RX_TRANS
(rx_nbr                        
,str_nbr                       
,rx_create_dt                  
,rx_fill_nbr                   
,rx_partial_fill_nbr           
,dspn_fill_nbr                 
,partial_fill_cd               
,pat_id                        
,pbr_id                        
,pbr_loc_id                    
,fill_sold_dt                  
,fill_sold_tm                  
,fill_sold_dlrs                
,fill_stat_cd                  
,fill_qty_dspn                 
,fill_pay_method_cd            
,fill_day_supply               
,fill_awp_cost_dlrs            
,fill_discnt_cd                
,fill_discnt_dlrs              
,fill_rtl_price_dlrs           
,fill_label_price_dlrs         
,fill_vrfy_user_id             
,fill_vrfy_dt                  
,fill_vrfy_tm                  
,fill_type_cd                  
,fill_del_dt                   
,fill_del_tm                   
,fill_data_review_user_id      
,fill_data_review_dt           
,fill_data_review_tm           
,fill_enter_user_id            
,fill_enter_dt                 
,fill_enter_tm                 
,fill_src_cd                   
,fill_wac_dlrs                 
,filling_user_id               
,filling_dt                    
,filling_tm                    
,fill_enter_str_nbr            
,fill_review_str_nbr           
,drug_id                       
,drug_name                     
,dea_class_cd                  
,refills_remain_cnt            
,orig_refills_remain_when_enter
,tot_amt_paid_ind              
,sims_upc                      
,override_user_id              
,override_dt                   
,override_tm                   
,relocate_fm_str_nbr           
,create_user_id                
,create_dttm                   
,edw_batch_id                  
,update_user_id                
,update_dttm                   
,src_partition_nbr             
,accept_consult_ind            
,cash_disc_sav_dlrs            
,data_rev_spec_dttm            
,data_rev_spec_id              
,data_rev_spec_str_nbr         
,fax_image_id                  
,fill_price_override_dlrs      
,fill_rph_of_rec_id            
,route_str_tech_inits          
,drug_whse_ind                 
,lvl_of_svc_cd                 
,rx_daw_ind                    
,sourcing_ind                  
,tip_rsn_for_svc_cd            
,fill_est_pick_up_dttm       
,cost_plus_fee_cd
,celgene_md_auth_nbr
,celgene_conf_nbr
,fill_print_dt
,fill_print_tm
,pat_lang_pref_cd
,rebilling_dt 
,rebilling_tm 
,src_eff_dt                    
,src_eff_tm                    
,src_end_dt                    
,src_end_tm                    
,cdc_rba_nbr                   
,edw_dml_ind                   
,edw_rank
,fill_90day_ind
,fill_90day_stat_cd
,pat_pickup_id				
,pickup_id				
,pickup_first_name				
,pickup_last_name				
,pickup_id_state				
,pickup_id_cntry				
,pickup_id_qlfr				
,pickup_rel_cd	
) 
SELECT 
rx_nbr                        
,str_nbr                       
,rx_create_dt                  
,rx_fill_nbr                   
,rx_partial_fill_nbr           
,dspn_fill_nbr                 
,partial_fill_cd               
,pat_id                        
,pbr_id                        
,pbr_loc_id                    
,fill_sold_dt                  
,fill_sold_tm                  
,fill_sold_dlrs                
,fill_stat_cd                  
,fill_qty_dspn                 
,fill_pay_method_cd            
,fill_day_supply               
,fill_awp_cost_dlrs            
,fill_discnt_cd                
,fill_discnt_dlrs              
,fill_rtl_price_dlrs           
,fill_label_price_dlrs         
,fill_vrfy_user_id             
,fill_vrfy_dt                  
,fill_vrfy_tm                  
,fill_type_cd                  
,fill_del_dt                   
,fill_del_tm                   
,fill_data_review_user_id      
,fill_data_review_dt           
,fill_data_review_tm           
,fill_enter_user_id            
,fill_enter_dt                 
,fill_enter_tm                 
,fill_src_cd                   
,fill_wac_dlrs                 
,filling_user_id               
,filling_dt                    
,filling_tm                    
,fill_enter_str_nbr            
,fill_review_str_nbr           
,drug_id                       
,drug_name                     
,dea_class_cd                  
,refills_remain_cnt            
,orig_refills_remain_when_enter
,tot_amt_paid_ind              
,sims_upc                      
,override_user_id              
,override_dt                   
,override_tm                   
,relocate_fm_str_nbr           
,create_user_id                
,create_dttm                   
,edw_batch_id                  
,update_user_id                
,update_dttm                   
,src_partition_nbr             
,accept_consult_ind            
,cash_disc_sav_dlrs            
,data_rev_spec_dttm            
,data_rev_spec_id              
,data_rev_spec_str_nbr         
,fax_image_id                  
,fill_price_override_dlrs      
,fill_rph_of_rec_id            
,route_str_tech_inits          
,drug_whse_ind                 
,lvl_of_svc_cd                 
,rx_daw_ind                    
,sourcing_ind                  
,tip_rsn_for_svc_cd            
,fill_est_pick_up_dttm
,cost_plus_fee_cd
,celgene_md_auth_nbr
,celgene_conf_nbr
,fill_print_dt
,fill_print_tm
,pat_lang_pref_cd
,rebilling_dt
,rebilling_tm         
,src_eff_dt                    
,src_eff_tm                    
,src_end_dt                    
,src_end_tm                    
,cdc_rba_nbr                   
,edw_dml_ind                   
,edw_rank
,fill_90day_ind
,fill_90day_stat_cd
,pat_pickup_id				
,pickup_id				
,pickup_first_name				
,pickup_last_name				
,pickup_id_state				
,pickup_id_cntry				
,pickup_id_qlfr				
,pickup_rel_cd			

FROM $pTDStageDB.V_FILL_RX_TRANS_ENDATED""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("""CALL PRDUTIL.TABLE_STATS('$pTDStageDB','ETL_ENDATED_FILL_RX_TRANS')""",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  return

main()
cleanup()
done()
ZZ


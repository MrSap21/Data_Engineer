#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""insert into
 prdetl.consult_hist_keys_icp
 select store_nbr
,rx_nbr
,fill_nbr_dispensed
,create_dttm
,src_partition_nbr
from prdrx2icp.icp_tbf0_rx_consult_hist_1
group by 1,2,3,4,5
having count(*) >1;
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  executeSql([], [
    ("""insert into
 prdetl.consult_hist_keys_icp
 select store_nbr
,rx_nbr
,fill_nbr_dispensed
,create_dttm
,src_partition_nbr
from prdrx2icp.icp_tbf0_rx_consult_hist_2
group by 1,2,3,4,5
having count(*) >1;
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  executeSql([], [
    ("""insert into
 prdetl.consult_hist_keys_icp
 select store_nbr
,rx_nbr
,fill_nbr_dispensed
,create_dttm
,src_partition_nbr
from prdrx2icp.icp_tbf0_rx_consult_hist_3
group by 1,2,3,4,5
having count(*) >1;
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  executeSql([], [
    ("""insert into
 prdetl.consult_hist_keys_icp
 select store_nbr
,rx_nbr
,fill_nbr_dispensed
,create_dttm
,src_partition_nbr
from prdrx2icp.icp_tbf0_rx_consult_hist_4
group by 1,2,3,4,5
having count(*) >1;
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

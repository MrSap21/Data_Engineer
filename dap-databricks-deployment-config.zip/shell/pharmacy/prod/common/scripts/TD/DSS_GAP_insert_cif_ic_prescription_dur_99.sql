#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescription_dur_99
(
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,dur_interact_nbr
,src_sys_cd
,fill_sold_dt
,dur_interact_type_cd
,dur_interact_src_cd
,dur_interact_outcome_cd
,dur_intervention_cd
,dur_severe_cd
,dur_cmnt_cd
,dur_cmnt_txt
,dur_override_cd
,dur_override_dttm
,dur_clinic_review_store_nbr
,dur_user_override_src_id
,src_update_dttm
,dur_desc
,dur_opv_src_cd
)
select
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,dur_interact_nbr
,src_sys_cd
,fill_sold_dt
,dur_interact_type_cd
,dur_interact_src_cd
,dur_interact_outcome_cd
,dur_intervention_cd
,dur_severe_cd
,dur_cmnt_cd
,dur_cmnt_txt
,dur_override_cd
,dur_override_dttm
,dur_clinic_review_store_nbr
,dur_user_override_src_id
,src_update_dttm
,dur_desc
,dur_opv_src_cd
FROM prdstgcif.cif_ic_prescription_dur;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_dur;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescription_dur_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

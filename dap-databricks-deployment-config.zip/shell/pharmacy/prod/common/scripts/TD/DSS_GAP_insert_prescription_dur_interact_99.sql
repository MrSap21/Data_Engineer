#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_dur_interact_99
(
store_nbr,
rx_src_id,
rx_nbr,
rx_create_dt,
rx_create_tm,
src_partition_nbr,
rx_fill_nbr,
rx_partial_fill_nbr,
fill_enter_dt,
fill_enter_tm,
dur_interact_nbr,
src_sys_cd,
fill_sold_dt,
dur_interact_type_cd,
dur_interact_src_cd,
dur_interact_outcome_cd,
dur_intervention_cd,
dur_severe_cd,
dur_cmnt_cd,
dur_cmnt_txt,
dur_override_cd,
dur_override_dttm,
loc_store_sk,
dim_loc_store_sk,
loc_store_relocate_chng_sk,
dur_clinic_review_store_sk,
dur_clinic_review_store_nbr,
dim_dur_clinic_review_store_sk,
dur_user_override_sk,
dur_user_override_chng_sk,
dur_user_override_src_id,
src_update_dttm,
dur_desc,
dur_opv_src_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
SELECT
store_nbr,
rx_src_id,
rx_nbr,
rx_create_dt,
rx_create_tm,
src_partition_nbr,
rx_fill_nbr,
rx_partial_fill_nbr,
fill_enter_dt,
fill_enter_tm,
dur_interact_nbr,
src_sys_cd,
fill_sold_dt,
dur_interact_type_cd,
dur_interact_src_cd,
dur_interact_outcome_cd,
dur_intervention_cd,
dur_severe_cd,
dur_cmnt_cd,
dur_cmnt_txt,
dur_override_cd,
dur_override_dttm,
loc_store_sk,
dim_loc_store_sk,
loc_store_relocate_chng_sk,
dur_clinic_review_store_sk,
dur_clinic_review_store_nbr,
dim_dur_clinic_review_store_sk,
dur_user_override_sk,
dur_user_override_chng_sk,
dur_user_override_src_id,
src_update_dttm,
dur_desc,
dur_opv_src_cd,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
FROM prdidldb.prescription_dur_interaction;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_dur_interaction;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_dur_interact_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

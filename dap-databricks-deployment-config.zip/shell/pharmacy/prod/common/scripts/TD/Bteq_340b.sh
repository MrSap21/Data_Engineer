#!/bin/ksh
cd /usr/local/edw/pharmacy/prod/common/scripts/TD
python3<<EOF 1>${1}.log 2>&1
#!/usr/bin/python3

#import os
#import sys

#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():

  sys.path.append("/usr/local/edwphrm")
  import _logon
  mainErrorLevel = Action.errorLevel
  Action.errorLevel = 0
  mainErrorCodeOverride = Action.errorCodeOverride
  Action.errorCodeOverride = None
  _logon.main()
  if Action.errorLevel != 0 or Action.errorCodeOverride != None:
    return
  else:
    Action.errorLevel = mainErrorLevel
    Action.errorCodeOverride = mainErrorCodeOverride
  FormatOptions.width = 1000
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "/usr/local/edw/pharmacy/prod/output/loadready/340B/debug_pbr_keys.dat"
  ExportOptions.colLimit = 100
  Action.charSet = "UTF-8"
  executeSql([], [
    ("""SELECT p.pbr_id || '�' || p.pbr_loc_id  as ""
FROM prdedwvw.prescriber p
WHERE pbr_id = 2486054035
AND p.history_seq_cd = 'C';
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])
  Action.exportFileName = "/usr/local/edw/pharmacy/prod/output/loadready/340B/debug_fill_keys.dat"
  ExportOptions.colLimit = 100
  Action.charSet = "UTF-8"
  executeSql([], [
    ("""SELECT f.pbr_id || '�' || f.pbr_loc_id  as ""
FROM prdedwvw.prescription_fill f
WHERE f.rx_nbr = 1810242
AND f.str_nbr = 5829
AND f.rx_fill_nbr = 1
AND f.fill_enter_dt = '2010-07-14';
-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
""",
    [])
  ])

if __name__ == '__main__':
  main()
  cleanup()
  done()

EOF

#/usr/bin/python3
from npjet import *
def main():

  #/*** identifying the rx_dups ***/
  executeSql([], [
    ("""insert into prdrx2stage.etl_proc_dup_rx_consult_hist
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,pat_id
,consult_req_ind
,update_user_id
,update_dttm
,consult_rph_inits
,consult_dttm
,fill_nbr_dispensed
,fill_partial_nbr
,create_user_id
,create_dttm
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_respons_cd
,relocate_fm_str_nbr
)
select 
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,pat_id
,consult_req_ind
,update_user_id
,update_dttm
,consult_rph_inits
,consult_dttm
,fill_nbr_dispensed
,fill_partial_nbr
,create_user_id
,create_dttm
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_respons_cd
,relocate_fm_str_nbr
from prdrx2stage.etl_tbf0_rx_consult_hist where
(store_nbr,rx_nbr) in
(select store_nbr,rx_nbr from prdrx2stage.etl_proc_dup_rx);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  #/*** identifying the trans_dups ***/
  executeSql([], [
    ("""insert into prdrx2stage.etl_proc_dup_rx_consult_hist
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,pat_id
,consult_req_ind
,update_user_id
,update_dttm
,consult_rph_inits
,consult_dttm
,fill_nbr_dispensed
,fill_partial_nbr
,create_user_id
,create_dttm
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_respons_cd
,relocate_fm_str_nbr
)
select 
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,pat_id
,consult_req_ind
,update_user_id
,update_dttm
,consult_rph_inits
,consult_dttm
,fill_nbr_dispensed
,fill_partial_nbr
,create_user_id
,create_dttm
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_respons_cd
,relocate_fm_str_nbr
from prdrx2stage.etl_tbf0_rx_consult_hist where
(store_nbr,rx_nbr,fill_nbr,fill_partial_nbr) in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr from prdrx2stage.etl_proc_dup_rx_tran);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  #/*** identifying the fill_dups ***/
  executeSql([], [
    ("""insert into prdrx2stage.etl_proc_dup_rx_consult_hist
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,pat_id
,consult_req_ind
,update_user_id
,update_dttm
,consult_rph_inits
,consult_dttm
,fill_nbr_dispensed
,fill_partial_nbr
,create_user_id
,create_dttm
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_respons_cd
,relocate_fm_str_nbr
)
select 
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,pat_id
,consult_req_ind
,update_user_id
,update_dttm
,consult_rph_inits
,consult_dttm
,fill_nbr_dispensed
,fill_partial_nbr
,create_user_id
,create_dttm
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_respons_cd
,relocate_fm_str_nbr
from prdrx2stage.etl_tbf0_rx_consult_hist where
(store_nbr,rx_nbr,fill_nbr,fill_partial_nbr) in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr from prdrx2stage.etl_proc_dup_fill);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  #/*** identifying the consult_hist_dups ***/
  executeSql([], [
    ("""insert into prdrx2stage.etl_proc_dup_rx_consult_hist
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,pat_id
,consult_req_ind
,update_user_id
,update_dttm
,consult_rph_inits
,consult_dttm
,fill_nbr_dispensed
,fill_partial_nbr
,create_user_id
,create_dttm
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_respons_cd
,relocate_fm_str_nbr
)
select 
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,pat_id
,consult_req_ind
,update_user_id
,update_dttm
,consult_rph_inits
,consult_dttm
,fill_nbr_dispensed
,fill_partial_nbr
,create_user_id
,create_dttm
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_respons_cd
,relocate_fm_str_nbr
from prdrx2stage.etl_tbf0_rx_consult_hist where
(store_nbr,rx_nbr,fill_nbr_dispensed,create_dttm) in
(select store_nbr,rx_nbr,fill_nbr_dispensed,create_dttm from prdrx2stage.etl_proc_dup_rx_consult_hist);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  #/*** deleting the dups identified ***/
  executeSql([], [
    ("""delete from prdrx2stage.etl_tbf0_rx_consult_hist where
(store_nbr,rx_nbr,fill_nbr_dispensed,create_dttm) in
(select store_nbr,rx_nbr,fill_nbr_dispensed,create_dttm from prdrx2stage.etl_proc_dup_rx_consult_hist);
-- DEL_STATEMENT - Replace DEL with DELETE
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""UPDATE prdedwdb.Prescription_Consultation Consult
set rx_create_dt=Fill.rx_create_dt
,fill_sold_dt=Fill.fill_sold_dt
FROM    (select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,rx_create_dt,fill_sold_dt 
from prdedwvw.Prescription_Fill where
(rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,cast(fill_enter_dt||' '||cast(fill_enter_tm as char(8)) as timestamp(0))) in
(select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,
max(cast(fill_enter_dt||' '||cast(fill_enter_tm as char(8)) as timestamp(0)))
from prdedwvw.Prescription_Fill 
where fill_sold_dt<='2007-05-31'
group by 1,2,3,4)
and fill_sold_dt<='2007-05-31') Fill
where Consult.rx_nbr=Fill.rx_nbr
and Consult.str_nbr=Fill.str_nbr
and Consult.rx_fill_nbr=Fill.rx_fill_nbr
and Consult.rx_partial_fill_nbr=Fill.rx_partial_fill_nbr;
-- SEL_STATEMENT - Replace SEL with SELECT
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE prdedwdb.Prescription_Consultation Consult
set rx_create_dt=Fill.rx_create_dt
,fill_sold_dt=Fill.fill_sold_dt
FROM    (select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,rx_create_dt,fill_sold_dt 
from prdedwvw.Prescription_Fill where
(rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,cast(fill_enter_dt||' '||cast(fill_enter_tm as char(8)) as timestamp(0))) in
(select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,
max(cast(fill_enter_dt||' '||cast(fill_enter_tm as char(8)) as timestamp(0)))
from prdedwvw.Prescription_Fill 
where fill_sold_dt between '2007-06-01' and '2008-05-31'
group by 1,2,3,4)
and fill_sold_dt between '2007-06-01' and '2008-05-31') Fill
where Consult.rx_nbr=Fill.rx_nbr
and Consult.str_nbr=Fill.str_nbr
and Consult.rx_fill_nbr=Fill.rx_fill_nbr
and Consult.rx_partial_fill_nbr=Fill.rx_partial_fill_nbr;
-- SEL_STATEMENT - Replace SEL with SELECT
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE prdedwdb.Prescription_Consultation Consult
set rx_create_dt=Fill.rx_create_dt
,fill_sold_dt=Fill.fill_sold_dt
FROM    (select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,rx_create_dt,fill_sold_dt 
from prdedwvw.Prescription_Fill where
(rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,cast(fill_enter_dt||' '||cast(fill_enter_tm as char(8)) as timestamp(0))) in
(select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,
max(cast(fill_enter_dt||' '||cast(fill_enter_tm as char(8)) as timestamp(0)))
from prdedwvw.Prescription_Fill 
where fill_sold_dt>='2008-06-01'
group by 1,2,3,4)
and fill_sold_dt>='2008-06-01') Fill
where Consult.rx_nbr=Fill.rx_nbr
and Consult.str_nbr=Fill.str_nbr
and Consult.rx_fill_nbr=Fill.rx_fill_nbr
and Consult.rx_partial_fill_nbr=Fill.rx_partial_fill_nbr;
-- SEL_STATEMENT - Replace SEL with SELECT
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE prdedwdb.Prescription_Consultation Consult
set rx_create_dt=Fill.rx_create_dt
FROM    (select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,rx_create_dt,fill_sold_dt
from prdedwvw.Prescription_Fill where
(rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,cast(fill_enter_dt||' '||cast(fill_enter_tm as char(8)) as timestamp(0))) in
(select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,
max(cast(fill_enter_dt||' '||cast(fill_enter_tm as char(8)) as timestamp(0)))
from prdedwvw.Prescription_Fill
where (rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr) in
(select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr from prdedwdb.Prescription_Consultation
where  fill_sold_dt is null)
and fill_sold_dt is null
group by 1,2,3,4)
 and fill_sold_dt is null) Fill
where Consult.rx_nbr=Fill.rx_nbr
and Consult.str_nbr=Fill.str_nbr
and Consult.rx_fill_nbr=Fill.rx_fill_nbr
and Consult.rx_partial_fill_nbr=Fill.rx_partial_fill_nbr
and Consult.Fill_Sold_Dt is null;
-- SEL_STATEMENT - Replace SEL with SELECT
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

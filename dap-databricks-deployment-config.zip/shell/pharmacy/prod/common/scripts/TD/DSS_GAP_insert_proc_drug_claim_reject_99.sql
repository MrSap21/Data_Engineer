#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.proc_drug_claim_reject_99
(
store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, insure_plan_src_id
, plan_rank_cd
, reject_seq_nbr
, src_sys_cd
, insure_plan_chng_sk
, insure_plan_sk
, loc_store_sk
, dim_loc_store_sk
, loc_store_relocate_chng_sk
, src_update_user_id
, src_update_user_chng_sk
, src_update_user_sk
, src_create_user_id
, src_create_user_chng_sk
, src_create_user_sk
, reject_cd
, fill_sold_dt
, src_update_dttm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT
store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, insure_plan_src_id
, plan_rank_cd
, reject_nbr_seq
, src_sys_cd
, insure_plan_chng_sk
, insure_plan_sk
, loc_store_sk
, dim_loc_store_sk
, loc_store_relocate_chng_sk
, src_update_user_id
, src_update_user_chng_sk
, src_update_user_sk
, src_create_user_id
, src_create_user_chng_sk
, src_create_user_sk
, reject_cd
, fill_sold_dt
, src_update_dttm
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
FROM prdstgcif.proc_drug_claim_reject;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.proc_drug_claim_reject;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.proc_drug_claim_reject_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

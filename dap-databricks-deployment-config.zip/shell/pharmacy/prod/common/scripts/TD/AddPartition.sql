#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""call prdutil.wag_batch_ddl('ADD_PART', 'prescription_fill', '2009-04-12');""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

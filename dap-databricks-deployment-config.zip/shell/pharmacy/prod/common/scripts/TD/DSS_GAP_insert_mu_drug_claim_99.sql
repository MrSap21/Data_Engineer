#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.mu_drug_claim_99
(
cdc_txn_commit_dttm
, change_cd
, store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, insure_plan_src_id
, plan_rank_cd
, claim_audit_id
, claim_response_id
, src_sys_cd
, mbr_src_id
, pat_src_id
, composite_type_cd
, msg_type_cd
, src_update_user_id
, claim_ref_nbr
, src_create_user_id
, adjud_cd
, adjud_dt
, adjud_tm
, fill_sold_dt
, plan_gross_due_amt
, gov_funded_cd
, plan_return_copay_amt
, plan_return_fee_amt
, plan_submit_copay_amt
, plan_tax_amt
, plan_tot_paid_amt
, pat_tax_amt
, basis_of_remb_cd
, general_phrm_nbr
, general_recipient_nbr
, general_rph_nbr
, major_medical_prior_auth_nbr
, plan_acct_receivable_amt
, pat_copay_amt
, plan_submit_incentive_amt
, plan_return_incentive_amt
, plan_return_cost_amt
, plan_return_tax_amt
, plan_return_coinsure1_amt
, plan_return_coinsure2_amt
, plan_submit_cost_amt
, plan_submit_fee_amt
, plan_submit_tax_amt
, remb_loss_amt
, src_update_dttm
, response_receive_dt
, benefit_stg_1_qlfr_cd
, benefit_stg_2_qlfr_cd
, benefit_stg_3_qlfr_cd
, benefit_stg_4_qlfr_cd
, benefit_stg_1_amt
, benefit_stg_2_amt
, benefit_stg_3_amt
, benefit_stg_4_amt
, coupon_drug_id
, coupon_cd
, other_payr_coverage_cd
, plan_other_amt
, plan_other_paid_amt_qlfr_cd
, plan_other_paid_amt
, plan_other_paid_2_amt_qlfr_cd
, plan_other_paid_2_amt
, plan_other_paid_3_amt_qlfr_cd
, plan_other_paid_3_amt
, plan_other_submit_amt_qlfr_cd
, plan_other_submit_amt
, plan_bank_id_nbr
, processor_ctrl_id
)
SELECT
cdc_txn_commit_dttm
, change_cd
, store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, insure_plan_src_id
, plan_rank_cd
, claim_audit_id
, claim_response_id
, src_sys_cd
, mbr_src_id
, pat_src_id
, composite_type_cd
, msg_type_cd
, src_update_user_id
, claim_ref_nbr
, src_create_user_id
, adjud_cd
, adjud_dt
, adjud_tm
, fill_sold_dt
, plan_gross_due_amt
, gov_funded_cd
, plan_return_copay_amt
, plan_return_fee_amt
, plan_submit_copay_amt
, plan_tax_amt
, plan_tot_paid_amt
, pat_tax_amt
, basis_of_remb_cd
, general_phrm_nbr
, general_recipient_nbr
, general_rph_nbr
, major_medical_prior_auth_nbr
, plan_acct_receivable_amt
, pat_copay_amt
, plan_submit_incentive_amt
, plan_return_incentive_amt
, plan_return_cost_amt
, plan_return_tax_amt
, plan_return_coinsure1_amt
, plan_return_coinsure2_amt
, plan_submit_cost_amt
, plan_submit_fee_amt
, plan_submit_tax_amt
, remb_loss_amt
, src_update_dttm
, response_receive_dt
, benefit_stg_1_qlfr_cd
, benefit_stg_2_qlfr_cd
, benefit_stg_3_qlfr_cd
, benefit_stg_4_qlfr_cd
, benefit_stg_1_amt
, benefit_stg_2_amt
, benefit_stg_3_amt
, benefit_stg_4_amt
, coupon_drug_id
, coupon_cd
, other_payr_coverage_cd
, plan_other_amt
, plan_other_paid_amt_qlfr_cd
, plan_other_paid_amt
, plan_other_paid_2_amt_qlfr_cd
, plan_other_paid_2_amt
, plan_other_paid_3_amt_qlfr_cd
, plan_other_paid_3_amt
, plan_other_submit_amt_qlfr_cd
, plan_other_submit_amt
, plan_bank_id_nbr
, processor_ctrl_id
FROM prdstgcif.mu_drug_claim;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.mu_drug_claim;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.mu_drug_claim_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

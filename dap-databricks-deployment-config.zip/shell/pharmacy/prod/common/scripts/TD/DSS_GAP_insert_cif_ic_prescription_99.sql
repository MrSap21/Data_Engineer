#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescription_99
( 
cdc_txn_commit_dttm
, change_cd
, store_nbr
, rx_src_id
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, src_sys_cd
, rx_nbr
, rx_create_dt_cur
, rx_create_tm_cur
, route_store_nbr
, drug_id
, ord_drug_id
, dea_class_cd
, drug_cmpnd_non_sys_cd
, drug_substn_cd
, rx_90day_reqst_cd
, rx_90day_reqst_dttm
, rx_90day_reqst_stat_cd
, rx_90day_reqst_stat_dttm
, rx_orig_fill_dttm
, rx_refill_expire_dttm
, rx_orig_days_supply_nbr
, pat_generic_substn_pref_cd
, rx_daw_ind_cd
, rx_daw_cd
, rx_written_dttm
, rx_sig_txt
, fill_prescribed_cnt
, added_fill_cnt
, fill_unlimit_cd
, rx_orig_qty
, rx_orig_dspn_qty
, rx_added_qty
, rx_auto_fill_cd
, rx_tot_fill_dspn_cnt
, rx_tot_dspn_qty
, rx_pad_barcode_val
, rx_pad_prog_cd
, rx_stat_cd
, rx_origin_cd
, pbr_provider_ord_nbr
, rx_cmnt_txt
, image_id
, pat_src_id
, composite_type_cd
, msg_type_cd
, primary_diagnosis_cd
, primary_diagnosis_qlfr_cd
, scndry_diagnosis_cd
, scndry_diagnosis_qlfr_cd
, anatomic_loc_cd
, pbr_provider_src_id
, pbr_provider_addr_src_id
, orig_store_src_id
, store_src_id
, rx_rnw_cd
, inj_dt
, rx_discont_dt
, rx_disease_state_catg_cd
, rx_discont_desc
, internal_xfer_rx_nbr
, fill_last_days_supply_nbr
, fill_last_enter_dttm
, fill_last_dspn_nbr
, fill_last_dspn_qty
, pbr_dea_nbr
, pbr_dea_suffix
)
SELECT
cdc_txn_commit_dttm
, change_cd
, store_nbr
, rx_src_id
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, src_sys_cd
, rx_nbr
, rx_create_dt_cur
, rx_create_tm_cur
, route_store_nbr
, drug_id
, ord_drug_id
, dea_class_cd
, drug_cmpnd_non_sys_cd
, drug_substn_cd
, rx_90day_reqst_cd
, rx_90day_reqst_dttm
, rx_90day_reqst_stat_cd
, rx_90day_reqst_stat_dttm
, rx_orig_fill_dttm
, rx_refill_expire_dttm
, rx_orig_days_supply_nbr
, pat_generic_substn_pref_cd
, rx_daw_ind_cd
, rx_daw_cd
, rx_written_dttm
, rx_sig_txt
, fill_prescribed_cnt
, added_fill_cnt
, fill_unlimit_cd
, rx_orig_qty
, rx_orig_dspn_qty
, rx_added_qty
, rx_auto_fill_cd
, rx_tot_fill_dspn_cnt
, rx_tot_dspn_qty
, rx_pad_barcode_val
, rx_pad_prog_cd
, rx_stat_cd
, rx_origin_cd
, pbr_provider_ord_nbr
, rx_cmnt_txt
, image_id
, pat_src_id
, composite_type_cd
, msg_type_cd
, primary_diagnosis_cd
, primary_diagnosis_qlfr_cd
, scndry_diagnosis_cd
, scndry_diagnosis_qlfr_cd
, anatomic_loc_cd
, pbr_provider_src_id
, pbr_provider_addr_src_id
, orig_store_src_id
, store_src_id
, rx_rnw_cd
, inj_dt
, rx_discont_dt
, rx_disease_state_catg_cd
, rx_discont_desc
, internal_xfer_rx_nbr
, fill_last_days_supply_nbr
, fill_last_enter_dttm
, fill_last_dspn_nbr
, fill_last_dspn_qty
, pbr_dea_nbr
, pbr_dea_suffix
FROM prdstgcif.cif_ic_prescription;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescription_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

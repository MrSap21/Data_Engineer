#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_prepay_99
(
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,fill_sold_dt
,loc_store_sk
,dim_loc_store_sk
,loc_store_relocate_chng_sk
,prpd_store_nbr
,prpd_loc_store_sk
,prpd_dim_loc_store_sk
,prpd_loc_store_reloc_chng_sk
,rfn_nbr
,prpd_amt
,prpd_dttm
,prpd_stat_cd
,prpd_tax_amt
,mail_payment_apply_cd
,src_create_dttm
,src_update_dttm
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
)
SELECT
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,fill_sold_dt
,loc_store_sk
,dim_loc_store_sk
,loc_store_relocate_chng_sk
,prpd_store_nbr
,prpd_loc_store_sk
,prpd_dim_loc_store_sk
,prpd_loc_store_reloc_chng_sk
,rfn_nbr
,prpd_amt
,prpd_dttm
,prpd_stat_cd
,prpd_tax_amt
,mail_payment_apply_cd
,src_create_dttm
,src_update_dttm
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
FROM prdidldb.prescription_prepay;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_prepay;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_prepay_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

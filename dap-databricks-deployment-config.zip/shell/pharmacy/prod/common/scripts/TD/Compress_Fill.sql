#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'fill_wac_dlrs' as XCOL, 
  fill_wac_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'filling_user_id' as XCOL, 
  filling_user_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'lvl_of_svc_cd' as XCOL, 
  lvl_of_svc_cd as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'orig_refills_remain_when_enter' as XCOL, 
  orig_refills_remain_when_enter as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'override_user_id' as XCOL, 
  override_user_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'partial_fill_cd' as XCOL, 
  partial_fill_cd as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'pat_id' as XCOL, 
  pat_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'pbr_id' as XCOL, 
  pbr_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'pbr_loc_id' as XCOL, 
  pbr_loc_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'refills_remain_cnt' as XCOL, 
  refills_remain_cnt as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'relocate_fm_str_nbr' as XCOL, 
  relocate_fm_str_nbr as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'rx_daw_ind' as XCOL, 
  rx_daw_ind as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'rx_fill_nbr' as XCOL, 
  rx_fill_nbr as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'rx_partial_fill_nbr' as XCOL, 
  rx_partial_fill_nbr as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'sims_upc' as XCOL, 
  sims_upc as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'sourcing_ind' as XCOL, 
  sourcing_ind as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'src_partition_nbr' as XCOL, 
  src_partition_nbr as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'tip_rsn_for_svc_cd' as XCOL, 
  tip_rsn_for_svc_cd as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'tot_amt_paid_ind' as XCOL, 
  tot_amt_paid_ind as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill' as XTBL, 
  'update_user_id' as XCOL, 
  update_user_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
if __name__ == '__main__':
  main()
  cleanup()
  done()

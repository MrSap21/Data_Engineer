#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO PRDEDWDB.PRESCRIPTION_FILL
SELECT * FROM PRDETL.FILL_340B_new;""",
    [])
  ])
if __name__ == '__main__':
  main()
  cleanup()
  done()

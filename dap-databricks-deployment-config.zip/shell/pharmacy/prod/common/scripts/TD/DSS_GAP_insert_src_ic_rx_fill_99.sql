#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.src_ic_rx_fill_99
(
change_cd
, cdc_txn_commit_dttm
, edw_batch_id
, store_nbr
, rx_nbr
, fill_nbr
, fill_partial_nbr
, fill_status_cd
, fill_qty_dispensed
, fill_awp_cost_amt
, fill_discount_cd
, fill_discount_amt
, fill_retail_price_amt
, fill_sold_amt
, fill_enter_user_id
, fill_enter_dttm
, fill_verified_user_id
, fill_verified_dttm
, fill_sold_dttm
, plan_id
, fill_type_cd
, partial_fill_cd
, fill_deleted_dttm
, fill_data_rev_id
, fill_data_rev_dttm
, filling_user_id
, filling_dttm
, entered_store_nbr
, reviewed_store_nbr
, fill_nbr_dispensed
, fill_adjudication_dttm
, fill_adjudication_cd
, cob_claim_ref_nbr
, claim_reference_nbr
, update_user_id
, update_dttm
, cob_fill_adjudication_cd
, cob_plan_id
, override_user_id
, override_dttm
, cob_fill_adj_dttm
, src_partition_nbr
, fill_days_supply
, fill_label_price_amt
, fill_pay_method_cd
, plan_ar_amt
, plan_copay_amt
, plan_tax_amt
, cob_plan_ar_amt
, cob_plan_copay_amt
, cob_plan_tax_amt
, fill_price_override_amt
, general_recipient_nbr
, accept_consult_ind
, plan_other_amt
, cash_disc_sav_amt
, routing_store_tech_inits
, fax_image_id
, dl_reject_cd_01
, cob_dl_reject_cd_01
, data_rev_spec_id
, data_rev_spec_dttm
, data_rev_spec_store_nbr
, fill_rph_of_record_id
, cob_gen_recipient_nbr
, cob_dl_reject_cd_02
, cob_dl_reject_cd_03
, cob_dl_reject_cd_04
, cob_dl_reject_cd_05
, amt_attributed_to_tax
, cob_plan_gross_due_amt
, cob_pln_incnt_amt_submtd
, plan_gross_due_amt
, plan_incent_amt_submtd
, plan_incentive_paid_amt
, plan_other_amt_paid
, plan_returnd_coins_amt
, plan_returnd_copay_amt
, plan_returnd_cost_amt
, plan_returnd_fee_amt
, plan_returnd_tax_amt
, plan_rtrnd_coins_amt
, plan_total_paid_amt
, plan_other_amt_paid_type
, med_partd_notice_ind
, med_partd_print_dttm
, ben_stg_qualifier_1
, ben_stg_qualifier_2
, ben_stg_qualifier_3
, ben_stg_qualifier_4
, ben_stg_amount_1
, ben_stg_amount_2
, ben_stg_amount_3
, ben_stg_amount_4
, coupon_drug_id
, cob_coupon_drug_id
, coupon_ind
, cob_coupon_ind
, other_coverage_cd
, cob_other_coverage_cd
)
SELECT
change_cd
, cdc_txn_commit_dttm
, edw_batch_id
, store_nbr
, rx_nbr
, fill_nbr
, fill_partial_nbr
, fill_status_cd
, fill_qty_dispensed
, fill_awp_cost_amt
, fill_discount_cd
, fill_discount_amt
, fill_retail_price_amt
, fill_sold_amt
, fill_enter_user_id
, fill_enter_dttm
, fill_verified_user_id
, fill_verified_dttm
, fill_sold_dttm
, plan_id
, fill_type_cd
, partial_fill_cd
, fill_deleted_dttm
, fill_data_rev_id
, fill_data_rev_dttm
, filling_user_id
, filling_dttm
, entered_store_nbr
, reviewed_store_nbr
, fill_nbr_dispensed
, fill_adjudication_dttm
, fill_adjudication_cd
, cob_claim_ref_nbr
, claim_reference_nbr
, update_user_id
, update_dttm
, cob_fill_adjudication_cd
, cob_plan_id
, override_user_id
, override_dttm
, cob_fill_adj_dttm
, src_partition_nbr
, fill_days_supply
, fill_label_price_amt
, fill_pay_method_cd
, plan_ar_amt
, plan_copay_amt
, plan_tax_amt
, cob_plan_ar_amt
, cob_plan_copay_amt
, cob_plan_tax_amt
, fill_price_override_amt
, general_recipient_nbr
, accept_consult_ind
, plan_other_amt
, cash_disc_sav_amt
, routing_store_tech_inits
, fax_image_id
, dl_reject_cd_01
, cob_dl_reject_cd_01
, data_rev_spec_id
, data_rev_spec_dttm
, data_rev_spec_store_nbr
, fill_rph_of_record_id
, cob_gen_recipient_nbr
, cob_dl_reject_cd_02
, cob_dl_reject_cd_03
, cob_dl_reject_cd_04
, cob_dl_reject_cd_05
, amt_attributed_to_tax
, cob_plan_gross_due_amt
, cob_pln_incnt_amt_submtd
, plan_gross_due_amt
, plan_incent_amt_submtd
, plan_incentive_paid_amt
, plan_other_amt_paid
, plan_returnd_coins_amt
, plan_returnd_copay_amt
, plan_returnd_cost_amt
, plan_returnd_fee_amt
, plan_returnd_tax_amt
, plan_rtrnd_coins_amt
, plan_total_paid_amt
, plan_other_amt_paid_type
, med_partd_notice_ind
, med_partd_print_dttm
, ben_stg_qualifier_1
, ben_stg_qualifier_2
, ben_stg_qualifier_3
, ben_stg_qualifier_4
, ben_stg_amount_1
, ben_stg_amount_2
, ben_stg_amount_3
, ben_stg_amount_4
, coupon_drug_id
, cob_coupon_drug_id
, coupon_ind
, cob_coupon_ind
, other_coverage_cd
, cob_other_coverage_cd
FROM prdstgcif.src_ic_rx_fill;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.src_ic_rx_fill;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.src_ic_rx_fill_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

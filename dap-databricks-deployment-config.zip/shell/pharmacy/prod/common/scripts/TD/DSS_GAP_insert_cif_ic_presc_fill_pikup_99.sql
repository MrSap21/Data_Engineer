#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_presc_fill_pikup_99
(
cdc_txn_commit_dttm
, change_cd
, store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, src_sys_cd
, fill_sold_dt
, pat_pickup_id
, pickup_id
, pickup_first_name
, pickup_last_name
, pickup_id_qlfr
, pickup_id_state_cd
, pickup_id_cntry_cd
, pickup_relation_cd
)
SELECT
cdc_txn_commit_dttm
, change_cd
, store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, src_sys_cd
, fill_sold_dt
, pat_pickup_id
, pickup_id
, pickup_first_name
, pickup_last_name
, pickup_id_qlfr
, pickup_id_state_cd
, pickup_id_cntry_cd
, pickup_relation_cd
FROM prdstgcif.cif_ic_prescription_fill_pikup;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_fill_pikup;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescription_fill_pikup_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""insert into prdetl.consultation_dups
select * from prdedwdb.prescription_consultation
where (str_nbr,rx_nbr,rx_fill_nbr,rx_partial_fill_nbr) in
(select str_nbr,rx_nbr,rx_fill_nbr,rx_partial_fill_nbr from  prdedwdb.prescription_consultation
group by 1,2,3,4
having count(*) >1);
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

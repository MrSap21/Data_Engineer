#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescrip_cntrl_subs_99
(
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,txn_cd
,src_partition_nbr
,fill_sold_dt
,drug_id
,drug_non_sys_name
,fill_vrfy_user_initials
,src_create_dttm
,src_create_user_id
,src_update_dttm
,src_update_user_id
)
select
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,txn_cd
,src_partition_nbr
,fill_sold_dt
,drug_id
,drug_non_sys_name
,fill_vrfy_user_initials
,src_create_dttm
,src_create_user_id
,src_update_dttm
,src_update_user_id
FROM prdstgcif.cif_ic_prescription_cntrl_subs;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_cntrl_subs;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescrip_cntrl_subs_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

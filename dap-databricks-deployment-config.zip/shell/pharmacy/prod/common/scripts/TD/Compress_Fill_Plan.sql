#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'attributed_to_tax_dlrs' as XCOL, 
  attributed_to_tax_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'basis_of_reimb_detrm' as XCOL, 
  basis_of_reimb_detrm as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'bin_nbr' as XCOL, 
  bin_nbr as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'cob_ind' as XCOL, 
  cob_ind as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'create_user_id' as XCOL, 
  create_user_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'del_adjud_cd' as XCOL, 
  del_adjud_cd as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'edw_batch_id' as XCOL, 
  edw_batch_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'fill_adjud_cd' as XCOL, 
  fill_adjud_cd as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_ar_dlrs' as XCOL, 
  plan_ar_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_copay_dlrs' as XCOL, 
  plan_copay_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_gross_due_dlrs' as XCOL, 
  plan_gross_due_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_incent_submtd_dlrs' as XCOL, 
  plan_incent_submtd_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_incentive_paid_dlrs' as XCOL, 
  plan_incentive_paid_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_other_dlrs' as XCOL, 
  plan_other_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_other_paid_dlrs' as XCOL, 
  plan_other_paid_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_other_submtd_dlrs' as XCOL, 
  plan_other_submtd_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_return_copay_dlrs' as XCOL, 
  plan_return_copay_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_return_cost_dlrs' as XCOL, 
  plan_return_cost_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_return_fee_dlrs' as XCOL, 
  plan_return_fee_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_return_tax_dlrs' as XCOL, 
  plan_return_tax_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_submit_copay_dlrs' as XCOL, 
  plan_submit_copay_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_submit_cost_dlrs' as XCOL, 
  plan_submit_cost_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_submit_fee_dlrs' as XCOL, 
  plan_submit_fee_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_submit_tax_dlrs' as XCOL, 
  plan_submit_tax_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_tax_dlrs' as XCOL, 
  plan_tax_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'plan_tot_paid_dlrs' as XCOL, 
  plan_tot_paid_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'reimburs_loss_dlrs' as XCOL, 
  reimburs_loss_dlrs as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'relocate_fm_str_nbr' as XCOL, 
  relocate_fm_str_nbr as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'rx_fill_nbr' as XCOL, 
  rx_fill_nbr as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'rx_partial_fill_nbr' as XCOL, 
  rx_partial_fill_nbr as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'src_partition_nbr' as XCOL, 
  src_partition_nbr as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'third_party_plan_id' as XCOL, 
  third_party_plan_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO PRDETL.COMPRESSION_FNDGS SELECT TRIM(XTBL),TRIM(XCOL),TRIM(XVAL),COLUMNCOUNT,rank() over(order by COLUMNCOUNT DESC) FROM (SELECT 'prescription_fill_plan' as XTBL, 
  'update_user_id' as XCOL, 
  update_user_id as XVAL, 
  COUNT(*) (float)  as COLUMNCOUNT FROM prdedwdb.prescription_fill_plan GROUP BY 1,2,3) AS T1  QUALIFY rank() over(order by COLUMNCOUNT DESC)<=25;
-- FUN_CAST_OPTR - Reformat casting
-- FUN_RANK - Convert Teradata RANK() to Analytical Rank()
-- QUALIFY - change the non-analytic function to analytic function
-- QUERY_EXPR_COL_NAMES - replace subquery select column alias with query expression alias column names
""",
    [])
  ])
if __name__ == '__main__':
  main()
  cleanup()
  done()

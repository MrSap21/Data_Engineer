#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_consult_actv_99
(
store_nbr,
rx_src_id,
rx_nbr,
rx_create_dt,
rx_create_tm,
src_partition_nbr,
rx_fill_nbr,
rx_partial_fill_nbr,
fill_enter_dt,
fill_enter_tm,
src_sys_cd,
consult_actv_type_cd,
consult_campgn_id,
fill_sold_dt,
loc_store_sk,
dim_loc_store_sk,
loc_store_relocate_chng_sk,
remote_loc_store_sk,
remote_store_nbr,
remote_dim_loc_store_sk,
consult_actv_stat_cd,
fill_dspn_nbr,
consult_reqst_cmnts,
consult_reqst_dttm,
consult_reqst_rph_initials,
consult_reqst_rph_user_sk,
consult_reqst_rph_user_chng_sk,
consult_reqst_rph_src_user_id,
consult_rph_barcode_supv_sk,
consult_rph_barcd_supv_chng_sk,
consult_rph_barcd_supv_src_id,
consult_rslvd_cmnts,
consult_rslvd_dttm,
consult_rslvd_rph_initials,
consult_rslvd_rph_user_sk,
consult_rslvd_rph_user_chng_sk,
consult_rslvd_rph_src_user_id,
src_create_dttm,
src_update_dttm,
src_create_user_sk,
src_create_user_chng_sk,
src_create_user_id,
src_update_user_sk,
src_update_user_chng_sk,
src_update_user_id,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
SELECT
store_nbr,
rx_src_id,
rx_nbr,
rx_create_dt,
rx_create_tm,
src_partition_nbr,
rx_fill_nbr,
rx_partial_fill_nbr,
fill_enter_dt,
fill_enter_tm,
src_sys_cd,
consult_actv_type_cd,
consult_campgn_id,
fill_sold_dt,
loc_store_sk,
dim_loc_store_sk,
loc_store_relocate_chng_sk,
remote_loc_store_sk,
remote_store_nbr,
remote_dim_loc_store_sk,
consult_actv_stat_cd,
fill_dspn_nbr,
consult_reqst_cmnts,
consult_reqst_dttm,
consult_reqst_rph_initials,
consult_reqst_rph_user_sk,
consult_reqst_rph_user_chng_sk,
consult_reqst_rph_src_user_id,
consult_rph_barcode_supv_sk,
consult_rph_barcd_supv_chng_sk,
consult_rph_barcd_supv_src_id,
consult_rslvd_cmnts,
consult_rslvd_dttm,
consult_rslvd_rph_initials,
consult_rslvd_rph_user_sk,
consult_rslvd_rph_user_chng_sk,
consult_rslvd_rph_src_user_id,
src_create_dttm,
src_update_dttm,
src_create_user_sk,
src_create_user_chng_sk,
src_create_user_id,
src_update_user_sk,
src_update_user_chng_sk,
src_update_user_id,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
FROM prdidldb.prescription_consult_activity;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_consult_activity;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_consult_actv_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""delete from prdedwdb.prescription_consultation
  where edw_batch_id in(20090404150015
	,20090403192515
	,20090404150514
	,20090403193016
);
-- DEL_STATEMENT - Replace DEL with DELETE
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

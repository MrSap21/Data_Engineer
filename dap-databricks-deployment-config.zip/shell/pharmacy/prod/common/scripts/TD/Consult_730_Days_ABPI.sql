#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""insert into prdetl.consult_hist_730_dups_abpi
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,store_nbr
,rx_nbr
,fill_nbr
,pat_id
,consult_req_ind
,update_user_id
,update_dttm
,consult_rph_inits
,consult_dttm
,fill_nbr_dispensed
,fill_partial_nbr
,create_user_id
,create_dttm
,src_partition_nbr
,relocate_fm_str_nbr
,consult_rph_user_id           
,pat_pregnancy_respons_cd      
)
select 
STG.cdc_txn_commit_dttm
,STG.cdc_seq_nbr
,STG.cdc_rba_nbr
,STG.cdc_operation_type_cd
,STG.cdc_before_after_cd
,STG.cdc_txn_position_cd
,STG.edw_batch_id
,STG.store_nbr
,STG.rx_nbr
,STG.fill_nbr
,STG.pat_id
,STG.consult_req_ind
,STG.update_user_id
,STG.update_dttm
,STG.consult_rph_inits
,STG.consult_dttm
,STG.fill_nbr_dispensed
,STG.fill_partial_nbr
,STG.create_user_id
,STG.create_dttm
,STG.src_partition_nbr
,STG.relocate_fm_str_nbr
,STG.consult_rph_user_id           
,STG.pat_pregnancy_respons_cd      
from prdrx2stage.etl_tbf0_rx_consult_hist STG
,prdedwdb.prescription_consultation TGT
where TGT.str_nbr=STG.store_nbr
and TGT.rx_nbr=STG.rx_nbr
and TGT.fill_nbr_dspn=STG.fill_nbr_dispensed
and cast(TGT.create_dt||' '||cast(TGT.create_tm as char(8)) as timestamp(0))<> STG.create_dttm
and TGT.create_dt >= cast(STG.create_dttm as date) + 730;""",
    [])
  ])
  executeSql([], [
    ("""delete from prdrx2stage.etl_tbf0_rx_consult_hist STG 
using prdetl.consult_hist_730_dups_abpi DUPS 
where STG.rx_nbr=DUPS.rx_nbr
and STG.store_nbr=DUPS.store_nbr
and STG.fill_nbr_dispensed=DUPS.fill_nbr_dispensed
and STG.create_dttm=DUPS.create_dttm;
-- DEL_STATEMENT - Replace DEL with DELETE
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

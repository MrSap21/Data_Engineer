#/usr/bin/python3
from npjet import *
def main():

  #--1
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'stg_prescription_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    stg1()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.stg_prescription_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  stg1()
def stg1():
  executeSql([], [
    ("""alter table prdstgcif.stg_prescription rename to prdstgcif.stg_prescription_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.stg_prescription 
     (
      store_nbr INTEGER  NOT NULL comment  'Store Number',
      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
      rx_create_dt_cur DATE   comment  'Prescription Create Date Current''{"FORMAT":"YYYY/MM/DD" }'  ,
      rx_create_tm_cur TIME(0)   comment  'Prescription Create Time Current' ,
      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
      route_store_nbr INTEGER  NOT NULL comment  'Route Store Number',
      route_store_sk BIGINT  NOT NULL comment  'Route Store Surrogate Key'  ,
      dim_route_store_sk BIGINT  NOT NULL comment  'dim route store sk'  ,
      drug_sk BIGINT  NOT NULL comment  'drug sk'  ,
      drug_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'drug identifier',
      dim_drug_sk BIGINT  NOT NULL comment  'dim drug sk'  ,
      ord_drug_sk BIGINT  NOT NULL comment  'Ordered Drug Surrogate Key'  ,
      ord_drug_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Ordered Drug Identifier',
      dea_class_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'DEA Class Code',
      dim_ord_drug_sk BIGINT  NOT NULL comment  'Dim Ordered Drug Sk'  ,
      drug_cmpnd_non_sys_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Drug Compound Non System Code',
      drug_substn_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Drug Substitution Code',
      rx_90day_reqst_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription 90Day Request Code',
      rx_90day_reqst_dttm TIMESTAMP   comment  'Prescription 90Day Request Datetime' ,
      rx_90day_reqst_stat_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription 90Day Request Status Code',
      rx_90day_reqst_stat_dttm TIMESTAMP   comment  'Prescription 90Day Request Status Datetime' ,
      rx_orig_fill_dttm TIMESTAMP   comment  'Prescription Original Fill Datetime' ,
      rx_refill_expire_dttm TIMESTAMP   comment  'Prescription Refill Expiration Datetime' ,
      rx_orig_days_supply_nbr SMALLINT   comment  'Prescription Original Days Supply Number' ,
      pat_generic_substn_pref_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Patient Generic Substitution Preference Code',
      rx_daw_ind_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Dispense As Written Indicator Code',
      rx_daw_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Dispense As Written Code',
      rx_written_dttm TIMESTAMP   comment  'Prescription Written Datetime' ,
      rx_sig_txt VARCHAR(224)  COLLATE 'en-ci'  comment 'Prescription SIG Text',
      fill_prescribed_cnt DECIMAL(15,5)   comment  'Fill Prescribed Count' ,
      added_fill_cnt SMALLINT   comment  'Added Fill Count' ,
      fill_unlimit_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Unlimited Code',
      rx_orig_qty DECIMAL(12,4)   comment  'Prescription Original Quantity' ,
      rx_orig_dspn_qty DECIMAL(10,3)   comment  'Prescription Original Dispensed Quantity' ,
      rx_added_qty DECIMAL(8,3)   comment  'Prescription Added Quantity' ,
      rx_auto_fill_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Automatic Fill Code',
      rx_tot_fill_dspn_cnt SMALLINT   comment  'Prescription Total Fill Dispensed Count' ,
      rx_tot_dspn_qty DECIMAL(12,5)   comment  'Prescription Total Dispensed Quantity' ,
      rx_pad_barcode_val VARCHAR(14)  COLLATE 'en-ci'  comment 'Prescription Pad Barcode Value',
      rx_pad_prog_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Pad Program Code',
      rx_stat_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Status Code',
      rx_origin_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Origin Code',
      pbr_provider_ord_nbr VARCHAR(35)  COLLATE 'en-ci'  comment 'Prescriber Provider Order Number',
      rx_cmnt_txt VARCHAR(1000)  COLLATE 'en-ci'  comment 'Prescription Comment Text',
      image_id VARCHAR(19)  COLLATE 'en-ci'  comment 'Image Identifier',
      pat_src_id VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Patient Source Identifier',
      composite_type_cd CHAR(2)  COLLATE 'en-ci'   NOT NULL comment  'Composite Type Code' ,
      msg_type_cd CHAR(1)  COLLATE 'en-ci'   NOT NULL comment  'Message Type Code' ,
      eid_dim_cust_sk BIGINT  NOT NULL comment  'EID DIM Customer Surrogate Key'  ,
      mid_dim_cust_sk BIGINT  NOT NULL comment  'MID DIM Customer Surrogate Key'  ,
      dim_pat_cust_sk BIGINT  NOT NULL comment  'DIM Patient/Customer Surrogate Key'  ,
      cust_sk BIGINT  NOT NULL comment  'Customer Surrogate Key'  ,
      primary_diagnosis_cd_sk BIGINT  NOT NULL comment  'Primary Diagnosis Code Surrogate Key'  ,
      primary_diagnosis_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Primary Diagnosis Code',
      primary_diagnosis_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Primary Diagnosis Qualifier Code',
      primary_diagnosis_cd_chng_sk BIGINT  NOT NULL comment  'Primary Diagnosis Code Change Surrogate Key'  ,
      scndry_diagnosis_cd_sk BIGINT  NOT NULL comment  'Secondary Diagnosis Code Surrogate Key'  ,
      scndry_diagnosis_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Secondary Diagnosis Code',
      scndry_diagnosis_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Secondary Diagnosis Qualifier Code',
      scndry_diagnosis_cd_chng_sk BIGINT  NOT NULL comment  'Secondary Diagnosis Code Change Surrogate key'  ,
      anatomic_loc_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Anatomic Location Code',
      pbr_provider_sk BIGINT  NOT NULL comment  'Prescriber Provider Surrogate Key'  ,
      pbr_provider_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescriber Provider Source Identifier',
      pbr_provider_chng_sk BIGINT  NOT NULL comment  'Prescriber Provider Change Surrogate Key'  ,
      pbr_provider_addr_sk BIGINT  NOT NULL comment  'Prescriber Provider Address Surrogate Key'  ,
      pbr_provider_addr_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescriber Provider Address Source Identifier',
      dim_pbr_provider_addr_sk BIGINT  NOT NULL comment  'DIM Prescriber Provider Address Surrogate Key'  ,
      orig_store_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Original Store Source Identifier',
      orig_store_crosswalk_chng_sk BIGINT  NOT NULL comment  'Original Store Crosswalk Change Surrogate Key'  ,
      store_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Store Source Identifier',
      store_crosswalk_chng_sk BIGINT  NOT NULL comment  'Store Crosswalk Change Surrogate Key'  ,
      rx_rnw_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Renew Code',
      inj_dt DATE   comment  'Injury Date''{"FORMAT":"YYYY/MM/DD" }'  ,
      rx_discont_dt DATE   comment  'Prescription Discontinuation Date''{"FORMAT":"YYYY/MM/DD" }'  ,
      rx_disease_state_catg_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Disease State Category Code',
      rx_discont_desc VARCHAR(250)  COLLATE 'en-ci'  comment 'Prescription Discontinuation Description',
      internal_xfer_rx_nbr DECIMAL(13,0)   comment  'Internal Transfer Prescription Number' ,
      fill_last_days_supply_nbr SMALLINT   comment  'Fill Last Days Supply Number' ,
      fill_last_enter_dttm TIMESTAMP   comment  'Fill Last Entered Datetime' ,
      fill_last_dspn_nbr SMALLINT   comment  'Fill Last Dispensed Number' ,
      fill_last_dspn_qty DECIMAL(8,3)   comment  'Fill Last Dispensed Quantity' ,
      pbr_dea_nbr CHAR(9)  COLLATE 'en-ci'  comment  'Prescriber DEA Number'   ,
      pbr_dea_suffix VARCHAR(6)  COLLATE 'en-ci'  comment 'Prescriber DEA Suffix',
      buyout_rx_cd VARCHAR(20)  COLLATE 'en-ci' ,
      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier',
      edw_etl_step VARCHAR(5)  COLLATE 'en-ci' ) COMMENT = '{"multiset": true}' ;
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.stg_prescription 
SELECT	* 
FROM	prdstgcif.stg_prescription_99;""",
    [])
  ])
  #--2
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'stg_prescription_cmpind_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    stg2()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.stg_prescription_cmpind_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  stg2()
def stg2():
  executeSql([], [
    ("""alter table prdstgcif.stg_prescription_cmpnd_ingrd rename to prdstgcif.stg_prescription_cmpind_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.stg_prescription_cmpnd_ingrd 
     (
      store_nbr INTEGER  NOT NULL comment  'Store Number',
      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
      ingrd_nbr DECIMAL(5,0)  NOT NULL comment  'Ingredient Number',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
      ingrd_name VARCHAR(50)  COLLATE 'en-ci'  comment 'Ingredient Name',
      ingrd_qty VARCHAR(20)  COLLATE 'en-ci'  comment 'Ingredient Quantity',
      ingrd_cost_amt DECIMAL(12,2) comment 'Ingredient Cost Amount',
      ingrd_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Ingredient Qualifier Code',
      ingrd_ndc VARCHAR(11)  COLLATE 'en-ci'  comment 'Ingredient National Drug Code',
      dea_class_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'DEA Class Code',
      mfgr_abbr_name VARCHAR(20)  COLLATE 'en-ci'  comment 'Manufacturer Abbreviation Name',
      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key',
      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk',
      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key',
      src_create_dttm TIMESTAMP comment 'Source Create Datetime',
      src_update_dttm TIMESTAMP comment 'Source Update Datetime',
      src_create_user_sk BIGINT  NOT NULL comment  'Source Create User Surrogate Key',
      src_create_user_chng_sk BIGINT  NOT NULL comment  'Source Create User Change Surrogate Key',
      src_create_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Create User Identifier',
      src_update_user_sk BIGINT  NOT NULL comment  'Source Update User Surrogate Key',
      src_update_user_chng_sk BIGINT  NOT NULL comment  'Source Update User Change Surrogate Key',
      src_update_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Update User Identifier',
      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier',
      edw_etl_step VARCHAR(5)  COLLATE 'en-ci' ) COMMENT = '{"multiset": true}' ;
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.stg_prescription_cmpnd_ingrd 
SELECT	* 
FROM	prdstgcif.stg_prescription_cmpind_99;""",
    [])
  ])
  #--3
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'stg_prescription_diagnosis_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    stg3()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.stg_prescription_diagnosis_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  stg3()
def stg3():
  executeSql([], [
    ("""alter table prdstgcif.stg_prescription_diagnosis rename to prdstgcif.stg_prescription_diagnosis_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.stg_prescription_diagnosis 
     (
      store_nbr INTEGER  NOT NULL comment  'Store Number',
      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
      diagnosis_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Diagnosis Code',
      diagnosis_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Diagnosis Qualifier Code',
      diagnosis_seq_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Diagnosis Sequence Code',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
      diagnosis_cd_sk BIGINT  NOT NULL comment  'Diagnosis Code SK'  ,
      diagnosis_cd_chng_sk BIGINT  NOT NULL comment  'Diagnosis Code Change Surrogate Key'  ,
      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier',
      edw_etl_step VARCHAR(5)  COLLATE 'en-ci' ) COMMENT = '{"multiset": true}' ;
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.stg_prescription_diagnosis 
SELECT	* 
FROM	prdstgcif.stg_prescription_diagnosis_99;""",
    [])
  ])
  #--4
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'stg_prescription_erx_msg_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    stg4()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.stg_prescription_erx_msg_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  stg4()
def stg4():
  executeSql([], [
    ("""alter table prdstgcif.stg_prescription_erx_message rename to prdstgcif.stg_prescription_erx_msg_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.stg_prescription_erx_message 
     (
      icp_erx_msg_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'ICP ERX Message Source Identifier',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
      store_nbr INTEGER  NOT NULL comment  'Store Number',
      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
      dgtl_signature_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Digital Signature Code',
      drug_coverage_stat_array_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Drug Coverage Status Array Code',
      drug_sched_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Drug Schedule Code',
      epbr_erx_msg_id VARCHAR(35)  COLLATE 'en-ci'  comment 'Epbr ERX Message Identifier',
      erx_app_exception_rslv_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'ERX Application Exception Resolve Code',
      erx_del_ctrl_drug_gpi CHAR(14)  COLLATE 'en-ci'  comment  'ERX Delete Control Drug GPI'   ,
      erx_del_ctrl_drug_ndc VARCHAR(13)  COLLATE 'en-ci'  comment 'ERX Delete Control Drug National Drug Code',
      erx_del_ctrl_drug_name VARCHAR(35)  COLLATE 'en-ci'  comment 'ERX Delete Control Drug Name',
      erx_del_ctrl_pbr_id DECIMAL(11,0)   comment  'ERX Delete Control Prescriber Identifier' ,
      erx_msg_rcvd_dttm TIMESTAMP   comment  'ERX Message Received Datetime' ,
      erx_msg_sent_dttm TIMESTAMP   comment  'ERX Message Sent Datetime' ,
      erx_msg_rcvd_type_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'ERX Message Received Type Code',
      erx_msg_sent_type_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'ERX Message Sent Type Code',
      erx_msg_vndr_app_name VARCHAR(35)  COLLATE 'en-ci'  comment 'ERX Message Vendor Application Name',
      erx_msg_vndr_app_vers_name VARCHAR(35)  COLLATE 'en-ci'  comment 'ERX Message Vendor Application Version Name',
      erx_msg_vndr_name VARCHAR(35)  COLLATE 'en-ci'  comment 'ERX Message Vendor Name',
      erx_pat_addr VARCHAR(100)  COLLATE 'en-ci'  comment 'ERX Patient Address',
      erx_pat_full_name VARCHAR(107)  COLLATE 'en-ci'  comment 'ERX Patient Full Name',
      erx_pbr_addr VARCHAR(100)  COLLATE 'en-ci'  comment 'ERX Prescriber Address',
      erx_pbr_full_name VARCHAR(107)  COLLATE 'en-ci'  comment 'ERX Prescriber Full Name',
      erx_msg_xml_image_id VARCHAR(19)  COLLATE 'en-ci'  comment 'ERX Message XML Image Identifier',
      erx_pbr_clinic_id VARCHAR(35)  COLLATE 'en-ci'  comment 'ERX Prescriber Clinic Identifier',
      pbr_dgtl_signature_dgst_val VARCHAR(256)  COLLATE 'en-ci'  comment 'Prescriber Digital Signature Digest Value',
      pbr_dgtl_signature_publ_key VARCHAR(2000)  COLLATE 'en-ci'  comment 'Prescriber Digital Signature Public Key',
      pbr_dgtl_signature_val VARCHAR(256)  COLLATE 'en-ci'  comment 'Prescriber Digital Signature Value',
      wag_dgtl_signature_publ_key VARCHAR(2000)  COLLATE 'en-ci'  comment 'Walgreens Digital Signature Public Key',
      wag_dgtl_signature_val VARCHAR(256)  COLLATE 'en-ci'  comment 'Walgreens Digital Signature Value',
      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
      src_create_user_sk BIGINT  NOT NULL comment  'Source Create User Surrogate Key'  ,
      src_create_user_chng_sk BIGINT  NOT NULL comment  'Source Create User Change Surrogate Key'  ,
      src_create_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Create User Identifier',
      src_update_dttm TIMESTAMP   comment  'Source Update Datetime' ,
      src_update_user_sk BIGINT  NOT NULL comment  'Source Update User Surrogate Key'  ,
      src_update_user_chng_sk BIGINT  NOT NULL comment  'Source Update User Change Surrogate Key'  ,
      src_update_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Update User Identifier',
      fac_1_id VARCHAR(35)  COLLATE 'en-ci'  comment 'Facility 1 Identifier',
      fac_2_id VARCHAR(35)  COLLATE 'en-ci'  comment 'Facility 2 Identifier',
      fac_3_id VARCHAR(35)  COLLATE 'en-ci'  comment 'Facility 3 Identifier',
      fac_1_id_qlfr VARCHAR(8)  COLLATE 'en-ci'  comment 'Facility 1 Identifier Qualifier',
      fac_2_id_qlfr VARCHAR(8)  COLLATE 'en-ci'  comment 'Facility 2 Identifier Qualifier',
      fac_3_id_qlfr VARCHAR(8)  COLLATE 'en-ci'  comment 'Facility 3 Identifier Qualifier',
      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier',
      edw_etl_step VARCHAR(5)  COLLATE 'en-ci' ) COMMENT = '{"multiset": true}' ;
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.stg_prescription_erx_message 
SELECT	* 
FROM	prdstgcif.stg_prescription_erx_msg_99;""",
    [])
  ])
  #--5 removed return call list 
  #--6 
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'stg_prescription_trflog_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    stg6()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.stg_prescription_trflog_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  stg6()
def stg6():
  executeSql([], [
    ("""alter table prdstgcif.stg_prescription_transfer_log rename to prdstgcif.stg_prescription_trflog_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.stg_prescription_transfer_log 
     (
      store_nbr INTEGER  NOT NULL comment  'Store Number',
      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
      xfer_dttm TIMESTAMP  NOT NULL comment  'Transfer Datetime',
      dir_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Direction Code',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key',
      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk',
      xfer_to_store_nbr INTEGER comment 'Transfer To Store Number',
      xfer_to_rx_src_id VARCHAR(32)  COLLATE 'en-ci'  comment 'Transfer To Prescription Source Identifier',
      xfer_to_rx_nbr VARCHAR(20)  COLLATE 'en-ci'  comment 'Transfer To Prescription Number',
      xfer_to_rx_create_dt DATE  comment  'Transfer To Prescription Create Date{"FORMAT":"YYYY/MM/DD" }',
      xfer_to_store_sk BIGINT  NOT NULL comment  'Transfer To Store Surrogate Key',
      dim_xfer_to_store_sk BIGINT  NOT NULL comment  'Dim Transfer To Store SK',
      xfer_to_rx_create_tm TIME(0) comment 'Transfer To Prescription Create Time',
      xfer_to_competitor_area_cd CHAR(3)  COLLATE 'en-ci'  comment  'Transfer To Competitor Area Code'   ,
      xfer_to_competitor_phone_nbr CHAR(7)  COLLATE 'en-ci'  comment  'Transfer To Competitor Phone Number'   ,
      xfer_to_competitor_store_name VARCHAR(200)  COLLATE 'en-ci'  comment 'Transfer To Competitor Store Name',
      xfer_to_rph_first_name VARCHAR(75)  COLLATE 'en-ci'  comment 'Transfer To Pharmacist First Name',
      xfer_to_rph_last_name VARCHAR(75)  COLLATE 'en-ci'  comment 'Transfer To Pharmacist Last Name',
      xfer_to_rph_initials CHAR(3)  COLLATE 'en-ci'  comment  'Transfer To Pharmacist Initials'   ,
      xfer_to_phrm_dea_nbr VARCHAR(20)  COLLATE 'en-ci'  comment 'Transfer To Pharmacy DEA Number',
      xfer_to_competitor_addr_line VARCHAR(90)  COLLATE 'en-ci'  comment 'Transfer To Competitor Address Line',
      xfer_to_competitor_city_name VARCHAR(60)  COLLATE 'en-ci'  comment 'Transfer To Competitor City Name',
      xfer_to_competitor_state_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Transfer To Competitor State Code',
      xfer_to_competitor_zip_cd_5 CHAR(5)  COLLATE 'en-ci'  comment  'Transfer To Competitor Zip Code 5'   ,
      xfer_to_competitor_zip_cd_4 CHAR(4)  COLLATE 'en-ci'  comment  'Transfer To Competitor Zip Code 4'   ,
      xfer_fm_store_nbr INTEGER comment 'Transfer From Store Number',
      xfer_fm_rx_src_id VARCHAR(32)  COLLATE 'en-ci'  comment 'Transfer From Prescription Source Identifier',
      xfer_fm_rx_nbr VARCHAR(20)  COLLATE 'en-ci'  comment 'Transfer From Prescription Number',
      xfer_fm_rx_create_dt DATE  comment  'Transfer From Prescription Create Date{"FORMAT":"YYYY/MM/DD" }',
      xfer_fm_rx_create_tm TIME(0) comment 'Transfer From Prescription Create Time',
      xfer_fm_store_sk BIGINT  NOT NULL comment  'Transfer From Store Surrogate Key',
      dim_xfer_fm_store_sk BIGINT  NOT NULL comment  'Dim Transfer From Store SK',
      xfer_fm_competitor_area_cd CHAR(3)  COLLATE 'en-ci'  comment  'Transfer From Competitor Area Code'   ,
      xfer_fm_competitor_phone_nbr CHAR(7)  COLLATE 'en-ci'  comment  'Transfer From Competitor Phone Number'   ,
      xfer_fm_competitor_store_name VARCHAR(200)  COLLATE 'en-ci'  comment 'Transfer From Competitor Store Name',
      xfer_fm_competitor_rph_name VARCHAR(30)  COLLATE 'en-ci'  comment 'Transfer From Competitor Pharmacist Name',
      xfer_fm_rph_initials CHAR(3)  COLLATE 'en-ci'  comment  'Transfer From Pharmacist Initials'   ,
      fm_competitor_first_fill_dttm TIMESTAMP   comment  'From Competitor First Fill Datetime' ,
      fm_competitor_rx_create_dttm TIMESTAMP   comment  'From Competitor Prescription Create Datetime' ,
      reason_close_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Reason Close Code',
      reason_close_cmnt VARCHAR(1000)  COLLATE 'en-ci'  comment 'Reason Close Comment',
      xfer_reason_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Transfer Reason Code',
      xfer_reason_cmnt VARCHAR(1000)  COLLATE 'en-ci'  comment 'Transfer Reason Comment',
      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key',
      src_partition_nbr BYTEINT comment 'Source Partition Number',
      src_create_dttm TIMESTAMP comment 'Source Create Datetime',
      src_create_user_sk BIGINT  NOT NULL comment  'Source Create User Surrogate Key',
      src_create_user_chng_sk BIGINT  NOT NULL comment  'Source Create User Change Surrogate Key',
      src_create_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Create User Identifier',
      src_update_dttm TIMESTAMP   comment  'Source Update Datetime' ,
      src_update_user_sk BIGINT  NOT NULL comment  'Source Update User Surrogate Key',
      src_update_user_chng_sk BIGINT  NOT NULL comment  'Source Update User Change Surrogate Key',
      src_update_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Update User Identifier',
      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier',
      edw_etl_step VARCHAR(5)  COLLATE 'en-ci' ) COMMENT = '{"multiset": true}' ;
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.stg_prescription_transfer_log 
SELECT	* 
FROM	prdstgcif.stg_prescription_trflog_99;""",
    [])
  ])
  #--7
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'stg_prescription_vacc_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    stg7()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.stg_prescription_vacc_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  stg7()
def stg7():
  executeSql([], [
    ("""alter table prdstgcif.stg_prescription_vaccination rename to prdstgcif.stg_prescription_vacc_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.stg_prescription_vaccination 
     (
      store_nbr INTEGER  NOT NULL comment  'Store Number',
      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
      rx_vaccine_consent_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Vaccine Consent Code',
      rx_vaccine_expire_dttm TIMESTAMP   comment  'Prescription Vaccine Expiration Datetime' ,
      rx_vaccine_mfg_lot_nbr VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Vaccine Manufacturing Lot Number',
      phys_ntfcn_ltr_enter_dttm TIMESTAMP   comment  'Physician Notification Letter Entered Datetime' ,
      phys_ntfcn_ltr_dstrb_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Physician Notification Letter Distribution Code',
      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier',
      edw_etl_step VARCHAR(5)  COLLATE 'en-ci' ) COMMENT = '{"multiset": true}' ;
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.stg_prescription_vaccination 
SELECT	* 
FROM	prdstgcif.stg_prescription_vacc_99;""",
    [])
  ])
  #--8
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'stg_prescription_wrkflusr_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    stg8()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.stg_prescription_wrkflusr_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  stg8()
def stg8():
  executeSql([], [
    ("""alter table prdstgcif.stg_prescription_wrkflow_user rename to prdstgcif.stg_prescription_wrkflusr_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.stg_prescription_wrkflow_user 
     (
      store_nbr INTEGER  NOT NULL comment  'Store Number',
      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
      scan_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Scan User Identifier',
      scan_store_nbr INTEGER  NOT NULL comment  'Scan Store Number'  ,
      scan_dttm TIMESTAMP   comment  'Scan Datetime' ,
      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
      src_create_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Create User Identifier',
      src_update_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Update User Identifier',
      src_update_dttm TIMESTAMP   comment  'Source Update Datetime' ,
      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier',
      edw_etl_step VARCHAR(5)  COLLATE 'en-ci' ) COMMENT = '{"multiset": true}' ;
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.stg_prescription_wrkflow_user 
SELECT	* 
FROM	prdstgcif.stg_prescription_wrkflusr_99;""",
    [])
  ])
  #--9 removed prepay 
  #--1
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_prescription_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc1()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_prescription_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc1()
def proc1():
  executeSql([], [
    ("""alter table prdstgcif.proc_prescription rename to prdstgcif.proc_prescription_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.proc_prescription 
 	     (
 	      store_nbr INTEGER  NOT NULL comment  'Store Number',
 	      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
 	      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
 	      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
 	      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
 	      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
 	      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
 	      rx_create_dt_cur DATE  comment  'Prescription Create Date Current{"FORMAT":"YYYY/MM/DD" }',
 	      rx_create_tm_cur TIME(0) comment 'Prescription Create Time Current',
 	      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key',
 	      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk',
 	      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key',
 	      route_store_nbr INTEGER  NOT NULL comment  'Route Store Number',
 	      route_store_sk BIGINT  NOT NULL comment  'Route Store Surrogate Key',
 	      dim_route_store_sk BIGINT  NOT NULL comment  'dim route store sk',
 	      drug_sk BIGINT  NOT NULL comment  'drug sk',
 	      drug_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'drug identifier',
 	      dim_drug_sk BIGINT  NOT NULL comment  'dim drug sk',
 	      ord_drug_sk BIGINT  NOT NULL comment  'Ordered Drug Surrogate Key',
 	      ord_drug_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Ordered Drug Identifier',
 	      dea_class_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'DEA Class Code',
 	      dim_ord_drug_sk BIGINT  NOT NULL comment  'Dim Ordered Drug Sk',
 	      drug_cmpnd_non_sys_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Drug Compound Non System Code',
 	      drug_substn_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Drug Substitution Code',
 	      rx_90day_reqst_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription 90Day Request Code',
 	      rx_90day_reqst_dttm TIMESTAMP comment 'Prescription 90Day Request Datetime',
 	      rx_90day_reqst_stat_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription 90Day Request Status Code',
 	      rx_90day_reqst_stat_dttm TIMESTAMP comment 'Prescription 90Day Request Status Datetime',
 	      rx_orig_fill_dttm TIMESTAMP comment 'Prescription Original Fill Datetime',
 	      rx_refill_expire_dttm TIMESTAMP comment 'Prescription Refill Expiration Datetime',
 	      rx_orig_days_supply_nbr SMALLINT comment 'Prescription Original Days Supply Number',
 	      pat_generic_substn_pref_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Patient Generic Substitution Preference Code',
 	      rx_daw_ind_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Dispense As Written Indicator Code',
 	      rx_daw_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Dispense As Written Code',
 	      rx_written_dttm TIMESTAMP comment 'Prescription Written Datetime',
 	      rx_sig_txt VARCHAR(224)  COLLATE 'en-ci'  comment 'Prescription SIG Text',
 	      fill_prescribed_cnt DECIMAL(15,5) comment 'Fill Prescribed Count',
 	      added_fill_cnt SMALLINT comment 'Added Fill Count',
 	      fill_unlimit_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Unlimited Code',
 	      rx_orig_qty DECIMAL(12,4) comment 'Prescription Original Quantity',
 	      rx_orig_dspn_qty DECIMAL(10,3) comment 'Prescription Original Dispensed Quantity',
 	      rx_added_qty DECIMAL(8,3) comment 'Prescription Added Quantity',
 	      rx_auto_fill_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Automatic Fill Code',
 	      rx_tot_fill_dspn_cnt SMALLINT comment 'Prescription Total Fill Dispensed Count',
 	      rx_tot_dspn_qty DECIMAL(12,5) comment 'Prescription Total Dispensed Quantity',
 	      rx_pad_barcode_val VARCHAR(14)  COLLATE 'en-ci'  comment 'Prescription Pad Barcode Value',
 	      rx_pad_prog_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Pad Program Code',
 	      rx_stat_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Status Code',
 	      rx_origin_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Origin Code',
 	      pbr_provider_ord_nbr VARCHAR(35)  COLLATE 'en-ci'  comment 'Prescriber Provider Order Number',
 	      rx_cmnt_txt VARCHAR(1000)  COLLATE 'en-ci'  comment 'Prescription Comment Text',
 	      image_id VARCHAR(19)  COLLATE 'en-ci'  comment 'Image Identifier',
 	      pat_src_id VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Patient Source Identifier',
 	      composite_type_cd CHAR(2)  COLLATE 'en-ci'   NOT NULL comment  'Composite Type Code',
 	      msg_type_cd CHAR(1)  COLLATE 'en-ci'   NOT NULL comment  'Message Type Code',
 	      eid_dim_cust_sk BIGINT  NOT NULL comment  'EID DIM Customer Surrogate Key',
 	      mid_dim_cust_sk BIGINT  NOT NULL comment  'MID DIM Customer Surrogate Key',
 	      dim_pat_cust_sk BIGINT  NOT NULL comment  'DIM Patient/Customer Surrogate Key',
 	      cust_sk BIGINT  NOT NULL comment  'Customer Surrogate Key',
 	      primary_diagnosis_cd_sk BIGINT  NOT NULL comment  'Primary Diagnosis Code Surrogate Key',
 	      primary_diagnosis_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Primary Diagnosis Code',
 	      primary_diagnosis_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Primary Diagnosis Qualifier Code',
 	      primary_diagnosis_cd_chng_sk BIGINT  NOT NULL comment  'Primary Diagnosis Code Change Surrogate Key',
 	      scndry_diagnosis_cd_sk BIGINT  NOT NULL comment  'Secondary Diagnosis Code Surrogate Key',
 	      scndry_diagnosis_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Secondary Diagnosis Code',
 	      scndry_diagnosis_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Secondary Diagnosis Qualifier Code',
 	      scndry_diagnosis_cd_chng_sk BIGINT  NOT NULL comment  'Secondary Diagnosis Code Change Surrogate key',
 	      anatomic_loc_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Anatomic Location Code',
 	      pbr_provider_sk BIGINT  NOT NULL comment  'Prescriber Provider Surrogate Key',
 	      pbr_provider_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescriber Provider Source Identifier',
 	      pbr_provider_chng_sk BIGINT  NOT NULL comment  'Prescriber Provider Change Surrogate Key',
 	      pbr_provider_addr_sk BIGINT  NOT NULL comment  'Prescriber Provider Address Surrogate Key',
 	      pbr_provider_addr_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescriber Provider Address Source Identifier',
 	      dim_pbr_provider_addr_sk BIGINT  NOT NULL comment  'DIM Prescriber Provider Address Surrogate Key',
 	      orig_store_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Original Store Source Identifier',
 	      orig_store_crosswalk_chng_sk BIGINT  NOT NULL comment  'Original Store Crosswalk Change Surrogate Key',
 	      store_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Store Source Identifier',
 	      store_crosswalk_chng_sk BIGINT  NOT NULL comment  'Store Crosswalk Change Surrogate Key',
 	      rx_rnw_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Renew Code',
 	      inj_dt DATE  comment  'Injury Date{"FORMAT":"YYYY/MM/DD" }',
 	      rx_discont_dt DATE  comment  'Prescription Discontinuation Date{"FORMAT":"YYYY/MM/DD" }',
 	      rx_disease_state_catg_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Disease State Category Code',
 	      rx_discont_desc VARCHAR(250)  COLLATE 'en-ci'  comment 'Prescription Discontinuation Description',
 	      internal_xfer_rx_nbr DECIMAL(13,0) comment 'Internal Transfer Prescription Number',
 	      fill_last_days_supply_nbr SMALLINT comment 'Fill Last Days Supply Number',
 	      fill_last_enter_dttm TIMESTAMP comment 'Fill Last Entered Datetime',
 	      fill_last_dspn_nbr SMALLINT comment 'Fill Last Dispensed Number',
 	      fill_last_dspn_qty DECIMAL(8,3) comment 'Fill Last Dispensed Quantity',
 	      pbr_dea_nbr CHAR(9)  COLLATE 'en-ci'  comment 'Prescriber DEA Number',
 	      pbr_dea_suffix VARCHAR(6)  COLLATE 'en-ci'  comment 'Prescriber DEA Suffix',
 	      buyout_rx_cd VARCHAR(20)  COLLATE 'en-ci' ,
 	      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
 	      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
 	      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_prescription 
SELECT	* 
FROM	prdstgcif.proc_prescription_99;""",
    [])
  ])
  #--2 
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_prescription_dgn_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc2()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_prescription_dgn_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc2()
def proc2():
  executeSql([], [
    ("""alter table prdstgcif.proc_prescription_diagnosis rename to prdstgcif.proc_prescription_dgn_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.proc_prescription_diagnosis 
      (
       store_nbr INTEGER  NOT NULL comment  'Store Number',
       rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
       rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
       rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
       rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
       src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
       diagnosis_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Diagnosis Code',
       diagnosis_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Diagnosis Qualifier Code',
       diagnosis_seq_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Diagnosis Sequence Code',
       src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
       diagnosis_cd_sk BIGINT  NOT NULL comment  'Diagnosis Code SK',
       diagnosis_cd_chng_sk BIGINT  NOT NULL comment  'Diagnosis Code Change Surrogate Key',
       loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key',
       dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk',
       loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key',
       edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
       edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
       edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_prescription_diagnosis 
SELECT	* 
FROM	prdstgcif.proc_prescription_dgn_99;""",
    [])
  ])
  #--3 
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_prescription_vcn_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc3()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_prescription_vcn_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc3()
def proc3():
  executeSql([], [
    ("""alter table prdstgcif.proc_prescription_vaccination rename to prdstgcif.proc_prescription_vcn_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.proc_prescription_vaccination 
 	     (
 	      store_nbr INTEGER  NOT NULL comment  'Store Number',
 	      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
 	      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
 	      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
 	      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
 	      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
 	      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
 	      rx_vaccine_consent_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Vaccine Consent Code',
 	      rx_vaccine_expire_dttm TIMESTAMP comment 'Prescription Vaccine Expiration Datetime',
 	      rx_vaccine_mfg_lot_nbr VARCHAR(20)  COLLATE 'en-ci'  comment 'Prescription Vaccine Manufacturing Lot Number',
 	      phys_ntfcn_ltr_enter_dttm TIMESTAMP comment 'Physician Notification Letter Entered Datetime',
 	      phys_ntfcn_ltr_dstrb_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Physician Notification Letter Distribution Code',
 	      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key',
 	      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk',
 	      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key',
 	      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
 	      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
 	      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_prescription_vaccination 
SELECT	* 
FROM	prdstgcif.proc_prescription_vcn_99;""",
    [])
  ])
  #--4
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_prescription_wrkflwusr_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc4()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_prescription_wrkflwusr_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc4()
def proc4():
  executeSql([], [
    ("""alter table prdstgcif.proc_prescription_wrkflow_user rename to prdstgcif.proc_prescription_wrkflwusr_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.proc_prescription_wrkflow_user 
      (
       store_nbr INTEGER  NOT NULL comment  'Store Number',
       rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
       rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
       rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
       rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
       src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
       src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
       loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
       dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
       scan_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Scan User Identifier',
       scan_store_nbr INTEGER  NOT NULL comment  'Scan Store Number'  ,
       scan_dttm TIMESTAMP   comment  'Scan Datetime' ,
       loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
       src_create_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Create User Identifier',
       src_update_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Update User Identifier',
       src_update_dttm TIMESTAMP   comment  'Source Update Datetime' ,
       edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
       edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
       edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_prescription_wrkflow_user 
SELECT	* 
FROM	prdstgcif.proc_prescription_wrkflwusr_99;""",
    [])
  ])
  #-- 5
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_drug_claim_reject_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc5()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_drug_claim_reject_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc5()
def proc5():
  executeSql([], [
    ("""alter table prdstgcif.proc_drug_claim_reject rename to prdstgcif.proc_drug_claim_reject_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.proc_drug_claim_reject 
 	     (
 	      store_nbr INTEGER  NOT NULL comment  'Store Number',
 	      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
 	      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
 	      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
 	      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
 	      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
 	      rx_fill_nbr INTEGER  NOT NULL comment  'Prescription Fill Number',
 	      rx_partial_fill_nbr VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Partial Fill Number',
 	      fill_enter_dt DATE   NOT NULL comment  'Fill Enter Date''{"FORMAT":"YYYY/MM/DD" }',
 	      fill_enter_tm TIME(0)  NOT NULL comment  'Fill Enter Time',
 	      insure_plan_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Insurance Plan Source Identifier',
 	      plan_rank_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Plan Rank Code',
 	      reject_seq_nbr SMALLINT  NOT NULL comment  'Reject Sequence Number',
 	      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
 	      insure_plan_chng_sk BIGINT  NOT NULL comment  'Insurance Plan Change Surrogate Key',
 	      insure_plan_sk BIGINT  NOT NULL comment  'Insurance Plan Surrogate Key',
 	      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key',
 	      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk',
 	      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key',
 	      src_update_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Update User Identifier',
 	      src_update_user_chng_sk BIGINT  NOT NULL comment  'Source Update User Change Surrogate Key',
 	      src_update_user_sk BIGINT  NOT NULL comment  'Source Update User Surrogate Key',
 	      src_create_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Create User Identifier',
 	      src_create_user_chng_sk BIGINT  NOT NULL comment  'Source Create User Change SK',
 	      src_create_user_sk BIGINT  NOT NULL comment  'Source Create User Surrogate Key',
 	      reject_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Reject Code',
 	      fill_sold_dt DATE  comment  'Fill Sold Date{"FORMAT":"YYYY/MM/DD" }',
 	      src_update_dttm TIMESTAMP comment 'Source Update Datetime',
 	      edw_create_dttm TIMESTAMP  NOT NULL comment  'edw create datetime',
 	      edw_update_dttm TIMESTAMP  NOT NULL comment  'edw update datetime',
 	      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch id') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_drug_claim_reject 
SELECT	* 
FROM	prdstgcif.proc_drug_claim_reject_99;""",
    [])
  ])
  #-- 6
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_prescription_fill_mdat_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc6()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_prescription_fill_mdat_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc6()
def proc6():
  executeSql([], [
    ("""alter table prdstgcif.proc_prescription_fill_med_aut rename to prdstgcif.proc_prescription_fill_mdat_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.proc_prescription_fill_med_aut 
 	     (
 	      store_nbr INTEGER  NOT NULL comment  'Store Number',
 	      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
 	      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
 	      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
 	      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
 	      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
 	      rx_fill_nbr INTEGER  NOT NULL comment  'Prescription Fill Number',
 	      rx_partial_fill_nbr VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Partial Fill Number',
 	      fill_enter_dt DATE   NOT NULL comment  'Fill Enter Date''{"FORMAT":"YYYY/MM/DD" }',
 	      fill_enter_tm TIME(0)  NOT NULL comment  'Fill Enter Time',
 	      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
 	      fill_sold_dt DATE  comment  'Fill Sold Date{"FORMAT":"YYYY/MM/DD" }',
 	      med_auth_nbr CHAR(7)  COLLATE 'en-ci'  comment 'Medication Authorization Number',
 	      mfgr_confirmation_nbr CHAR(7)  COLLATE 'en-ci'  comment 'Manufacturer Confirmation Number',
 	      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key',
 	      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk',
 	      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key',
 	      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
 	      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
 	      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_prescription_fill_med_aut 
SELECT	* 
FROM	prdstgcif.proc_prescription_fill_mdat_99;""",
    [])
  ])
  #--7
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_prescription_fill_patp_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc7()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_prescription_fill_patp_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc7()
def proc7():
  executeSql([], [
    ("""alter table prdstgcif.proc_prescription_fill_pat_pic rename to prdstgcif.proc_prescription_fill_patp_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.proc_prescription_fill_pat_pic 
      (
       store_nbr INTEGER  NOT NULL comment  'Store Number',
       rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
       rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
       rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
       rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
       src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
       rx_fill_nbr INTEGER  NOT NULL comment  'Prescription Fill Number',
       rx_partial_fill_nbr VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Partial Fill Number',
       fill_enter_dt DATE   NOT NULL comment  'Fill Enter Date''{"FORMAT":"YYYY/MM/DD" }',
       fill_enter_tm TIME(0)  NOT NULL comment  'Fill Enter Time',
       src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
       fill_sold_dt DATE  comment  'Fill Sold Date{"FORMAT":"YYYY/MM/DD" }',
       pat_pickup_id VARCHAR(20)  COLLATE 'en-ci'  comment 'patient pickup identifier',
       pickup_id VARCHAR(20)  COLLATE 'en-ci'  comment 'pickup identifier',
       pickup_first_name VARCHAR(50)  COLLATE 'en-ci'  comment 'pickup first name',
       pickup_last_name VARCHAR(50)  COLLATE 'en-ci'  comment 'pickup last name',
       pickup_id_qlfr VARCHAR(2)  COLLATE 'en-ci'  comment 'pickup identifier qualifier',
       pickup_id_state_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Pickup Identifier State Code',
       pickup_id_cntry_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Pickup Identifier Country Code',
       pickup_relation_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Pickup Relation Code',
       loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
       dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
       loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
       pat_pickup_gov_auth CHAR(3)  COLLATE 'en-ci'  comment 'Patient pickup government authorization',
       pat_pickup_relation_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Patient pickup relation code',
       pat_pickup_id_qlfr VARCHAR(20)  COLLATE 'en-ci'  comment 'Patient Pickup identifier Qualifier',
       edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
       edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
       edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_prescription_fill_pat_pic 
SELECT	* 
FROM	prdstgcif.proc_prescription_fill_patp_99;""",
    [])
  ])
  #--8
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_prescription_fill_wkf_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc8()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_prescription_fill_wkf_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc8()
def proc8():
  executeSql([], [
    ("""alter table prdstgcif.proc_prescription_fill_wrkflow rename to prdstgcif.proc_prescription_fill_wkf_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE	 TABLE prdstgcif.proc_prescription_fill_wrkflow 
      (
       store_nbr INTEGER  NOT NULL comment  'Store Number',
       rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
       rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
       rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
       rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
       rx_fill_nbr INTEGER  NOT NULL comment  'Prescription Fill Number',
       src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
       rx_partial_fill_nbr VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Partial Fill Number',
       fill_enter_dt DATE   NOT NULL comment  'Fill Enter Date''{"FORMAT":"YYYY/MM/DD" }',
       fill_enter_tm TIME(0)  NOT NULL comment  'Fill Enter Time',
       src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
       fill_sold_dt DATE  comment  'Fill Sold Date{"FORMAT":"YYYY/MM/DD" }',
       loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
       dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
       fill_vrfy_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Fill Verify User Identifier',
       fill_vrfy_dttm TIMESTAMP   comment  'Fill Verify Datetime' ,
       fill_data_review_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Fill Data Review User Identifier',
       fill_data_review_dttm TIMESTAMP   comment  'Fill Data Review Datetime' ,
       fill_review_store_nbr INTEGER  NOT NULL comment  'Fill Review Store Number'  ,
       fill_enter_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Fill Enter User Identifier',
       fill_enter_store_nbr INTEGER  NOT NULL comment  'Fill Enter Store Number'  ,
       filling_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Filling User Identifier',
       filling_dttm TIMESTAMP   comment  'Filling Datetime' ,
       override_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Override User Identifier',
       override_dttm TIMESTAMP   comment  'Override Datetime' ,
       data_review_spct_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Data Review Specialist Identifier',
       data_review_spct_store_nbr INTEGER  NOT NULL comment  'Data Review Specialist Store Number'  ,
       data_review_spct_dttm TIMESTAMP   comment  'Data Review Specialist Datetime' ,
       fill_rph_of_rec_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Fill Pharmacist Of Record Identifier',
       fill_print_dttm TIMESTAMP   comment  'Fill Print Datetime' ,
       fill_rebill_dttm TIMESTAMP   comment  'Fill Rebill Datetime' ,
       src_create_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Create User Identifier',
       src_create_dttm TIMESTAMP   comment  'Source Create Datetime' ,
       src_update_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Update User Identifier',
       src_update_dttm TIMESTAMP   comment  'Source Update Datetime' ,
       loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
       edw_create_dttm TIMESTAMP  NOT NULL comment  'edw_create_datetime',
       edw_update_dttm TIMESTAMP  NOT NULL comment  'edw_update_datetime',
       edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw_batch_identifier') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_prescription_fill_wrkflow 
SELECT	* 
FROM	prdstgcif.proc_prescription_fill_wkf_99;""",
    [])
  ])
  #--9
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_drug_claim_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc9()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_drug_claim_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc9()
def proc9():
  executeSql([], [
    ("""alter table prdstgcif.proc_drug_claim rename to prdstgcif.proc_drug_claim_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE  TABLE prdstgcif.proc_drug_claim 
	     (
	      store_nbr INTEGER  NOT NULL comment  'Store Number',
	      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
	      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
	      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
	      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
	      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
	      rx_fill_nbr INTEGER  NOT NULL comment  'Prescription Fill Number',
	      rx_partial_fill_nbr VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Partial Fill Number',
	      fill_enter_dt DATE   NOT NULL comment  'Fill Enter Date''{"FORMAT":"YYYY/MM/DD" }',
	      fill_enter_tm TIME(0)  NOT NULL comment  'Fill Enter Time',
	      insure_plan_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Insurance Plan Source Identifier',
	      plan_rank_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Plan Rank Code',
	      claim_audit_id INTEGER  NOT NULL comment  'Claim Audit Identifier',
	      claim_response_id INTEGER  NOT NULL comment  'Claim Response Identifier',
	      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
	      mbr_sk BIGINT  NOT NULL comment  'Member Surrogate Key'  ,
	      mbr_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Member Source Identifier',
	      mbr_chng_sk BIGINT  NOT NULL comment  'Member Change Surrogate Key'  ,
	      cust_sk BIGINT  NOT NULL comment  'Customer Surrogate Key'  ,
	      pat_src_id VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Patient Source Identifier',
	      composite_type_cd CHAR(2)  COLLATE 'en-ci'   NOT NULL comment  'Composite Type Code' ,
	      msg_type_cd CHAR(1)  COLLATE 'en-ci'   NOT NULL comment  'Message Type Code' ,
	      eid_dim_cust_sk BIGINT  NOT NULL comment  'EID DIM Customer Surrogate Key'  ,
	      mid_dim_cust_sk BIGINT  NOT NULL comment  'MID DIM Customer Surrogate Key'  ,
	      dim_pat_cust_sk BIGINT  NOT NULL comment  'DIM Patient/Customer Surrogate Key'  ,
	      insure_plan_sk BIGINT  NOT NULL comment  'Insurance Plan Surrogate Key'  ,
	      insure_plan_chng_sk BIGINT  NOT NULL comment  'Insurance Plan Change Surrogate Key'  ,
	      src_update_user_sk BIGINT  NOT NULL comment  'Source Update User Surrogate Key'  ,
	      src_update_user_chng_sk BIGINT  NOT NULL comment  'Source Update User Change Surrogate Key'  ,
	      src_update_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Update User Identifier',
	      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
	      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
	      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
	      claim_ref_nbr VARCHAR(20)  COLLATE 'en-ci'  comment 'Claim Reference Number',
	      src_create_user_sk BIGINT  NOT NULL comment  'Source Create User Surrogate Key'  ,
	      src_create_user_chng_sk BIGINT  NOT NULL comment  'Source Create User Change Surrogate Key'  ,
	      src_create_user_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Source Create User Identifier',
	      adjud_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Adjudication Code',
	      adjud_dt DATE   comment  'Adjudication Date''{"FORMAT":"YYYY/MM/DD" }'  ,
	      adjud_tm TIME(0)   comment  'Adjudication Time' ,
	      fill_sold_dt DATE  comment  'Fill Sold Date{"FORMAT":"YYYY/MM/DD" }',
	      plan_gross_due_amt DECIMAL(12,5)   comment  'Plan Gross Due Amount' ,
	      gov_funded_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Government Funded Code',
	      plan_return_copay_amt DECIMAL(12,5)   comment  'Plan Return Copay Amount' ,
	      plan_return_fee_amt DECIMAL(12,5)   comment  'Plan Return Fee Amount' ,
	      plan_submit_copay_amt DECIMAL(12,5)   comment  'Plan Submit Copay Amount' ,
	      plan_tax_amt DECIMAL(12,5)   comment  'Plan Tax Amount' ,
	      plan_tot_paid_amt DECIMAL(12,5)   comment  'Plan Total Paid Amount' ,
	      pat_tax_amt DECIMAL(8,2)   comment  'Patient Tax Amount' ,
	      basis_of_remb_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Basis Of Reimbursement Code',
	      general_phrm_nbr VARCHAR(15)  COLLATE 'en-ci'  comment 'General Pharmacy Number',
	      general_recipient_nbr VARCHAR(21)  COLLATE 'en-ci'  comment 'General Recipient Number',
	      general_rph_nbr VARCHAR(15)  COLLATE 'en-ci'  comment 'General Pharmacist Number',
	      major_medical_prior_auth_nbr VARCHAR(20)  COLLATE 'en-ci'  comment 'Major Medical Prior Authorization Number',
	      plan_acct_receivable_amt DECIMAL(12,5)   comment  'Plan Account Receivable Amount' ,
	      pat_copay_amt DECIMAL(8,2)   comment  'Patient Copay Amount' ,
	      plan_submit_incentive_amt DECIMAL(8,2)   comment  'Plan Submit Incentive Amount' ,
	      plan_return_incentive_amt DECIMAL(8,2)   comment  'Plan Return Incentive Amount' ,
	      plan_return_cost_amt DECIMAL(8,2)   comment  'Plan Return Cost Amount' ,
	      plan_return_tax_amt DECIMAL(8,2)   comment  'Plan Return Tax Amount' ,
	      plan_return_coinsure1_amt DECIMAL(8,2)   comment  'Plan Return Coinsurance1 Amount' ,
	      plan_return_coinsure2_amt DECIMAL(8,2)   comment  'Plan Return Coinsurance2 Amount' ,
	      plan_submit_cost_amt DECIMAL(8,2)   comment  'Plan Submit Cost Amount' ,
	      plan_submit_fee_amt DECIMAL(8,2)   comment  'Plan Submit Fee Amount' ,
	      plan_submit_tax_amt DECIMAL(8,2)   comment  'Plan Submit Tax Amount' ,
	      remb_loss_amt DECIMAL(8,2)   comment  'Reimbursement Loss Amount' ,
	      src_update_dttm TIMESTAMP   comment  'Source Update DateTime' ,
	      response_receive_dt DATE   comment  'Response Receive Date''{"FORMAT":"YYYY/MM/DD" }'  ,
	      benefit_stg_1_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Benefit Stage 1 Qualifier Code',
	      benefit_stg_2_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Benefit Stage 2 Qualifier Code',
	      benefit_stg_3_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Benefit Stage 3 Qualifier Code',
	      benefit_stg_4_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Benefit Stage 4 Qualifier Code',
	      benefit_stg_1_amt DECIMAL(8,2)   comment  'Benefit Stage 1 Amount' ,
	      benefit_stg_2_amt DECIMAL(8,2)   comment  'Benefit Stage 2 Amount' ,
	      benefit_stg_3_amt DECIMAL(8,2)   comment  'Benefit Stage 3 Amount' ,
	      benefit_stg_4_amt DECIMAL(8,2)   comment  'Benefit Stage 4 Amount' ,
	      coupon_drug_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Coupon Drug Identifier',
	      coupon_drug_sk BIGINT  NOT NULL comment  'coupon drug surrogate key'  ,
	      dim_coupon_drug_sk BIGINT  NOT NULL comment  'dim coupon drug surrogate key'  ,
	      coupon_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Coupon Code',
	      other_payr_coverage_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Other Payer Coverage Code',
	      plan_other_amt DECIMAL(8,2)   comment  'Plan Other Amount' ,
	      plan_other_paid_amt_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Plan Other Paid Amount Qualifier Code',
	      plan_other_paid_amt DECIMAL(8,2)   comment  'Plan Other Paid Amount' ,
	      plan_other_paid_2_amt_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Plan Other Paid 2 Amount Qualifier Code',
	      plan_other_paid_2_amt DECIMAL(8,2)   comment  'Plan Other Paid 2 Amount' ,
	      plan_other_paid_3_amt_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Plan Other Paid 3 Amount Qualifier Code',
	      plan_other_paid_3_amt DECIMAL(8,2)   comment  'Plan Other Paid 3 Amount' ,
	      plan_other_submit_amt_qlfr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Plan Other Submitted Amount Qualifier Code',
	      plan_other_submit_amt DECIMAL(8,2)   comment  'Plan Other Submitted Amount' ,
	      plan_bank_id_nbr VARCHAR(50)  COLLATE 'en-ci'  comment 'Plan Bank Identification Number',
	      processor_ctrl_id VARCHAR(10)  COLLATE 'en-ci'  comment 'Processor Control Identifier',
	      pat_medicare_gap_id VARCHAR(20)  COLLATE 'en-ci'  comment 'patient medicare gap identifier',
	      plac_of_service_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'place of service code',
	      rx_deny_override_cd1 VARCHAR(20)  COLLATE 'en-ci'  comment 'prescription denial override code1',
	      rx_deny_override_cd2 VARCHAR(20)  COLLATE 'en-ci'  comment 'prescription denial override code2',
	      rx_deny_override_cd3 VARCHAR(20)  COLLATE 'en-ci'  comment 'prescription denial override code3',
	      aprv_msg_cd1 VARCHAR(20)  COLLATE 'en-ci'  comment 'approved message code1',
	      aprv_msg_cd2 VARCHAR(20)  COLLATE 'en-ci'  comment 'approved message code2',
	      aprv_msg_cd3 VARCHAR(20)  COLLATE 'en-ci'  comment 'approved message code3',
	      aprv_msg_cd4 VARCHAR(20)  COLLATE 'en-ci'  comment 'approved message code4',
	      aprv_msg_cd5 VARCHAR(20)  COLLATE 'en-ci'  comment 'approved message code5',
	      general_recipient_return_id VARCHAR(21)  COLLATE 'en-ci'  comment 'general recipient return identification',
	      general_pbr_nbr VARCHAR(15)  COLLATE 'en-ci'  comment 'general prescriber number',
	      general_rph_id_qlfr CHAR(2)  COLLATE 'en-ci'  comment  'general pharmacist identifier qualifier'   ,
	      ntwrk_remb_return_id VARCHAR(10)  COLLATE 'en-ci'  comment 'network reimbursement returned identification',
	      return_plan_id VARCHAR(8)  COLLATE 'en-ci'  comment 'return plan identification',
	      return_plan_group_id VARCHAR(15)  COLLATE 'en-ci'  comment 'return plan group identification',
	      prior_auth_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Prior Authorization Code',
	      prior_auth_nbr VARCHAR(11)  COLLATE 'en-ci'  comment 'Prior Authorization Number',
	      tax_exmpt_plan_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'tax exempt plan code',
	      plan_tax_exmpt_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'plan tax exempt code',
	      insure_plan_group_src_nbr VARCHAR(20)  COLLATE 'en-ci'  comment 'Insurance Plan Group Source Number',
	      del_adjud_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Delete Adjudication Code',
	      prcs_local_dttm TIMESTAMP   comment  'Process Local Datetime' ,
	      prcs_del_local_dttm TIMESTAMP   comment  'Process Delete Local Datetime' ,
	      tmout_local_dttm TIMESTAMP   comment  'Timeout Local Datetime' ,
	      tmout_del_local_dttm TIMESTAMP   comment  'Timeout Delete Local Datetime' ,
	      edw_create_dttm TIMESTAMP  NOT NULL comment  'edw create datetime',
	      edw_update_dttm TIMESTAMP  NOT NULL comment  'edw update datetime',
	      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch id') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_drug_claim 
SELECT	* 
FROM	prdstgcif.proc_drug_claim_99;""",
    [])
  ])
  #--10
  executeSql([], [
    ("""SELECT 1 FROM INFORMATION_SCHEMA.tables WHERE TABLE_SCHEMA =  upper( 'prdstgcif')  AND TABLE_NAME =  upper( 'proc_prescription_fill_99') ;
-- DBC_USAGE - Replace DBC with SNOWCONVERT.INFORMATION_SCHEMA
-- Replace System tables and columns with equivalent tables and columns
""",
    [])
  ])
  if (Action.activityCount == 0):
    proc10()
    return
  executeSql([], [
    ("""DROP TABLE if exists prdstgcif.proc_prescription_fill_99;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  proc10()
def proc10():
  executeSql([], [
    ("""alter table prdstgcif.proc_prescription_fill rename to prdstgcif.proc_prescription_fill_99;
-- RENAME_TABLE - Change to ALTER TABLE ... RENAME TO
""",
    [])
  ])
  executeSql([], [
    ("""CREATE  TABLE prdstgcif.proc_prescription_fill 
	     (
	      store_nbr INTEGER  NOT NULL comment  'Store Number',
	      rx_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Source Identifier',
	      rx_nbr VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Number',
	      rx_create_dt DATE   NOT NULL comment  'Prescription Create Date''{"FORMAT":"YYYY/MM/DD" }',
	      rx_create_tm TIME(0)  NOT NULL comment  'Prescription Create Time',
	      src_partition_nbr BYTEINT  NOT NULL comment  'Source Partition Number',
	      rx_fill_nbr INTEGER  NOT NULL comment  'Prescription Fill Number',
	      rx_partial_fill_nbr VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescription Partial Fill Number',
	      fill_enter_dt DATE   NOT NULL comment  'Fill Enter Date''{"FORMAT":"YYYY/MM/DD" }',
	      fill_enter_tm TIME(0)  NOT NULL comment  'Fill Enter Time',
	      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
	      fill_sold_dt DATE  comment  'Fill Sold Date{"FORMAT":"YYYY/MM/DD" }',
	      fill_sold_tm TIME(0)   comment  'Fill Sold Time' ,
	      fill_dspn_nbr DECIMAL(5,0)   comment  'Fill Dispensed Number' ,
	      fill_dspn_qty DECIMAL(13,5)   comment  'Fill Dispensed Quantity' ,
	      fill_partial_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Partial Code',
	      fill_stat_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Status Code',
	      drug_sk BIGINT  NOT NULL comment  'drug sk'  ,
	      drug_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'drug identifier',
	      dim_drug_sk BIGINT  NOT NULL comment  'dim drug sk'  ,
	      drug_dspn_sk BIGINT  NOT NULL comment  'drug dispensed surrogate key'  ,
	      drug_dspn_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'drug dispensed identifier',
	      dim_drug_dspn_sk BIGINT  NOT NULL comment  'dim drug dispensed surrogate key'  ,
	      fill_type_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Type Code',
	      fill_src_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Source Code',
	      fill_del_dttm TIMESTAMP   comment  'Fill Delete Datetime' ,
	      fill_consult_outcome_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Consultation Outcome Code',
	      refill_remain_cnt INTEGER   comment  'Refill Remaining Count' ,
	      refill_remain_when_enter_cnt VARCHAR(10)  COLLATE 'en-ci'  comment 'Refill Remaining When Entered Count',
	      fill_pay_method_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Pay Method Code',
	      fill_days_supply_nbr DECIMAL(12,3)   comment  'Fill Days Supply Number' ,
	      fill_expire_dt DATE   comment  'Fill Expiration Date''{"FORMAT":"YYYY/MM/DD" }'  ,
	      fill_est_pickup_dttm TIMESTAMP   comment  'Fill Estimate Pickup Datetime' ,
	      fill_90day_reqst_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill 90Day Request Code',
	      fill_90day_reqst_stat_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill 90Day Request Status Code',
	      dea_class_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'DEA Class Code',
	      drug_name VARCHAR(50)  COLLATE 'en-ci'  comment 'Drug Name',
	      store_sourcing_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Store Sourcing Code',
	      loc_store_sk BIGINT  NOT NULL comment  'Location Store Surrogate Key'  ,
	      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk'  ,
	      loc_store_relocate_chng_sk BIGINT  NOT NULL comment  'Location Store Relocation Change Surrogate Key'  ,
	      fill_price_override_amt DECIMAL(8,2)   comment  'Fill Price Override Amount' ,
	      fax_image_id VARCHAR(20)  COLLATE 'en-ci'  comment 'Fax Image Identifier',
	      fill_sold_amt DECIMAL(8,2)   comment  'Fill Sold Amount' ,
	      fill_label_price_amt DECIMAL(12,5)   comment  'Fill Label Price Amount' ,
	      fill_awp_amt DECIMAL(15,5)   comment  'Fill Average Wholesale Price Amount' ,
	      fill_rtl_price_amt DECIMAL(8,2)   comment  'Fill Retail Price Amount' ,
	      fill_cost_plus_fee_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Cost Plus Fee Code',
	      fill_discnt_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Discount Code',
	      fill_discnt_amt DECIMAL(8,2)   comment  'Fill Discount Amount' ,
	      cash_discnt_savings_amt DECIMAL(8,2)   comment  'Cash Discount Savings Amount' ,
	      tot_amt_paid_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Total Amount Paid Code',
	      fill_sales_metric_basis_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Fill Sales Metric Basis Code',
	      fill_cost_amt DECIMAL(8,2)   comment  'Fill Cost Amount' ,
	      fill_rev_amt DECIMAL(8,2)   comment  'Fill Revenue Amount' ,
	      fill_reship_cost_amt DECIMAL(8,2)   comment  'Fill Reship Cost Amount' ,
	      fill_gross_profit_amt DECIMAL(8,2)   comment  'Fill Gross Profit Amount' ,
	      fill_plan_tot_tax_amt DECIMAL(8,2)   comment  'Fill Plan Total Tax Amount' ,
	      fill_pat_src_id VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Fill Patient Source Identifier',
	      composite_type_cd CHAR(2)  COLLATE 'en-ci'   NOT NULL comment  'Composite Type Code' ,
	      msg_type_cd CHAR(1)  COLLATE 'en-ci'   NOT NULL comment  'Message Type Code' ,
	      eid_dim_fill_cust_sk BIGINT  NOT NULL comment  'EID DIM Fill Customer Surrogate Key'  ,
	      mid_dim_fill_cust_sk BIGINT  NOT NULL comment  'MID DIM Fill Customer Surrogate Key'  ,
	      dim_fill_pat_cust_sk BIGINT  NOT NULL comment  'DIM Fill Patient Customer Surrogate Key'  ,
	      fill_cust_sk BIGINT  NOT NULL comment  'Fill Customer Surrogate Key'  ,
	      route_store_tech_initials CHAR(3)  COLLATE 'en-ci'  comment  'routing_store_tech_initials'   ,
	      service_lvl_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'service level code',
	      ecom_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'ecom_cd',
	      overstock_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'overstock code',
	      medicare_d_nte_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'medicare d notice code',
	      medicare_d_nte_print_dttm TIMESTAMP   comment  'medicare d notice print datetime' ,
	      fill_wac_amt DECIMAL(15,5)   comment  'Fill Walgreens Acquisition Cost Amount' ,
	      dspn_store_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Dispensed Store Source Identifier',
	      dspn_store_crosswalk_chng_sk BIGINT  NOT NULL comment  'Dispensed Store Crosswalk Change Surrogate Key'  ,
	      fill_memo_txt VARCHAR(1000)  COLLATE 'en-ci'  comment 'Fill Memo Text',
	      fill_metric_qty DECIMAL(13,5)   comment  'Fill Metric Quantity' ,
	      hcfa_genr_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'HCFA Generated Code',
	      label_print_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Label Print Code',
	      unit_per_dose_qty DECIMAL(6,2)   comment  'Unit Per Dose Quantity' ,
	      whac_unit_amt DECIMAL(12,5)   comment  'Wholesale Cost Unit Amount' ,
	      partial_fill_tot_intended_qty DECIMAL(8,3)   comment  'Partial Fill Total Intended Quantity' ,
	      triplicate_ser_nbr VARCHAR(25)  COLLATE 'en-ci'  comment 'Triplicate Serial Number',
	      delivery_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'Delivery Code',
	      delivery_cmnts VARCHAR(120)  COLLATE 'en-ci'  comment 'Delivery Comments',
	      src_sys_name VARCHAR(10)  COLLATE 'en-ci'  comment 'Source System Name',
	      src_sys_txn_id VARCHAR(35)  COLLATE 'en-ci'  comment 'Source System Transaction Id',
	      rec_src_cd CHAR(1)  COLLATE 'en-ci'  comment  'Record Source_Code'   ,
	      dim_pbr_provider_addr_sk BIGINT  NOT NULL comment  'DIM Prescriber Provider Address Surrogate Key',
	      pbr_provider_addr_sk BIGINT  NOT NULL comment  'Prescriber Provider Address Surrogate Key',
	      pbr_provider_addr_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescriber Provider Address Source Identifier',
	      pbr_provider_sk BIGINT  NOT NULL comment  'Prescriber Provider Surrogate Key',
	      pbr_provider_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'Prescriber Provider Source Identifier',
	      route_store_rph_initials CHAR(3)  COLLATE 'en-ci'  comment  'routing store pharmacist initials'   ,
	      sys_stat_when_ent SMALLINT   comment  'system status when enterer' ,
	      orig_enter_dttm TIMESTAMP   comment  'original entered datetime' ,
	      fill_sold_local_dttm TIMESTAMP   comment  'Fill Sold Local Datetime' ,
	      edw_create_dttm TIMESTAMP  NOT NULL comment  'EDW Create DateTime',
	      edw_update_dttm TIMESTAMP  NOT NULL comment  'EDW Update DateTime',
	      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier') COMMENT = '{"multiset": true}' ;
ECHO is off.
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove compress
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- COLUMN_ATTRIBUTES - move format into comment
-- COL_ATTR_TITLE: Replace TITLE with COMMENT
-- COL_ATTR_TITLE_MOVE: Replace TITLE with COMMENT, move COMMENT to last position
-- CREATE_MULTISET_OPTION - Remove MULTISET create table option
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- EXPR_MOD - Change expression MOD to %
-- FUN_HASHBUCKET_EXCPTN - Hashbucket function unchanged. Exception raised.
-- FUN_HASHROW - replace function HASHROW with HASH
-- TABLE_INDEX - Remove table index options
-- TABLE_PARTITION - replace partition by columns/range with CLUSTER BY, please review
-- T_CREATE_TABLE_META - Add table metadata to table comment
""",
    [])
  ])
  executeSql([], [
    ("""INSERT	INTO prdstgcif.proc_prescription_fill 
SELECT	* 
FROM	prdstgcif.proc_prescription_fill_99;""",
    [])
  ])
if __name__ == '__main__':
  main()
  cleanup()
  done()

#!/bin/ksh

WORKDIR=/usr/local/edw/pharmacy/prod/common/scripts/TD

SQLFILE1=DSS_GAP_insert_cif_ic_drug_claim_reject_99.sql

cd $WORKDIR

for SQLFILE in $SQLFILE1
do
   $WORKDIR/Bteq_idl.sh $SQLFILE
   RC=$?
   if [[ $RC -ne 0 ]]; then
      mailx -s "Alert: $SQLFILE" EDW-Rx-Batch@walgreens.com < $WORKDIR/$SQLFILE.log
   else
      mailx -s "Completed: $SQLFILE" EDW-Rx-Batch@walgreens.com < $WORKDIR/$SQLFILE.log
   fi
done

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescrip_consult_ac_99
(
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,consult_actv_type_cd
,consult_campgn_id
,fill_sold_dt
,remote_store_nbr
,consult_actv_stat_cd
,fill_dspn_nbr
,consult_reqst_cmnts
,consult_reqst_dttm
,consult_reqst_rph_initials
,consult_reqst_rph_src_user_id
,consult_rph_barcd_supv_src_id
,consult_rslvd_cmnts
,consult_rslvd_dttm
,consult_rslvd_rph_initials
,consult_rslvd_rph_src_user_id
,src_create_dttm
,src_update_dttm
,src_create_user_id
,src_update_user_id
)
select
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,consult_actv_type_cd
,consult_campgn_id
,fill_sold_dt
,remote_store_nbr
,consult_actv_stat_cd
,fill_dspn_nbr
,consult_reqst_cmnts
,consult_reqst_dttm
,consult_reqst_rph_initials
,consult_reqst_rph_src_user_id
,consult_rph_barcd_supv_src_id
,consult_rslvd_cmnts
,consult_rslvd_dttm
,consult_rslvd_rph_initials
,consult_rslvd_rph_src_user_id
,src_create_dttm
,src_update_dttm
,src_create_user_id
,src_update_user_id
FROM prdstgcif.cif_ic_prescription_consult_ac;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_consult_ac;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescrip_consult_ac_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

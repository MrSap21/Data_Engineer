#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""insert into prdedwdb.prescription_consultation
(
rx_nbr
,str_nbr
,rx_create_dt
,rx_fill_nbr
,rx_partial_fill_nbr
,consult_tm
,consult_dt
,fill_sold_dt
,consult_req_ind
,consult_rph_initials
,fill_nbr_dspn
,relocate_fm_str_nbr
,create_user_id
,edw_batch_id
,update_user_id
,update_dttm
,create_dt
,create_tm
,pat_id
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_response_cd
)
select
rx_nbr
,store_nbr
,NULL
,fill_nbr
,fill_partial_nbr
,cast(consult_dttm as time(0))
,cast(consult_dttm as  date)
,NULL
,consult_req_ind
,consult_rph_inits
,fill_nbr_dispensed
,store_nbr
,create_user_id
,20090329150015
,update_user_id
,update_dttm
,cast(create_dttm as date)
,cast(create_dttm as time(0))
,pat_id
,1
,consult_rph_user_id
,pat_pregnancy_respons_cd
from
prdrx2icp.icp_tbf0_rx_consult_hist_1;
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
,
    ("""insert into prdedwdb.prescription_consultation
(
rx_nbr
,str_nbr
,rx_create_dt
,rx_fill_nbr
,rx_partial_fill_nbr
,consult_tm
,consult_dt
,fill_sold_dt
,consult_req_ind
,consult_rph_initials
,fill_nbr_dspn
,relocate_fm_str_nbr
,create_user_id
,edw_batch_id
,update_user_id
,update_dttm
,create_dt
,create_tm
,pat_id
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_response_cd
)
select
rx_nbr
,store_nbr
,NULL
,fill_nbr
,fill_partial_nbr
,cast(consult_dttm as time(0))
,cast(consult_dttm as  date)
,NULL
,consult_req_ind
,consult_rph_inits
,fill_nbr_dispensed
,store_nbr
,create_user_id
,20090329150514
,update_user_id
,update_dttm
,cast(create_dttm as date)
,cast(create_dttm as time(0))
,pat_id
,2
,consult_rph_user_id
,pat_pregnancy_respons_cd
from
prdrx2icp.icp_tbf0_rx_consult_hist_2;
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
,
    ("""insert into prdedwdb.prescription_consultation
(
rx_nbr
,str_nbr
,rx_create_dt
,rx_fill_nbr
,rx_partial_fill_nbr
,consult_tm
,consult_dt
,fill_sold_dt
,consult_req_ind
,consult_rph_initials
,fill_nbr_dspn
,relocate_fm_str_nbr
,create_user_id
,edw_batch_id
,update_user_id
,update_dttm
,create_dt
,create_tm
,pat_id
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_response_cd
)
select
rx_nbr
,store_nbr
,NULL
,fill_nbr
,fill_partial_nbr
,cast(consult_dttm as time(0))
,cast(consult_dttm as  date)
,NULL
,consult_req_ind
,consult_rph_inits
,fill_nbr_dispensed
,store_nbr
,create_user_id
,20090330000015
,update_user_id
,update_dttm
,cast(create_dttm as date)
,cast(create_dttm as time(0))
,pat_id
,3
,consult_rph_user_id
,pat_pregnancy_respons_cd
from
prdrx2icp.icp_tbf0_rx_consult_hist_3;
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
,
    ("""insert into prdedwdb.prescription_consultation
(
rx_nbr
,str_nbr
,rx_create_dt
,rx_fill_nbr
,rx_partial_fill_nbr
,consult_tm
,consult_dt
,fill_sold_dt
,consult_req_ind
,consult_rph_initials
,fill_nbr_dspn
,relocate_fm_str_nbr
,create_user_id
,edw_batch_id
,update_user_id
,update_dttm
,create_dt
,create_tm
,pat_id
,src_partition_nbr
,consult_rph_user_id
,pat_pregnancy_response_cd
)
select
rx_nbr
,store_nbr
,NULL
,fill_nbr
,fill_partial_nbr
,cast(consult_dttm as time(0))
,cast(consult_dttm as  date)
,NULL
,consult_req_ind
,consult_rph_inits
,fill_nbr_dispensed
,store_nbr
,create_user_id
,20090330000518
,update_user_id
,update_dttm
,cast(create_dttm as date)
,cast(create_dttm as time(0))
,pat_id
,4
,consult_rph_user_id
,pat_pregnancy_respons_cd
from
prdrx2icp.icp_tbf0_rx_consult_hist_4;
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

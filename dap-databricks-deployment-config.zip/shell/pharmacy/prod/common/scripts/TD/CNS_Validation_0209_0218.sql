#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""select edw_batch_id, count(*) 
from prdedwvw.prescription
group by edw_batch_id;""",
    [])
  ])
  executeSql([], [
    ("""select cdc_operation_type_cd,count(*) 
from prdrx2stage.etl_tbf0_rx_cmpnd_nonsys
group by cdc_operation_type_cd;""",
    [])
  ])
  #----*** check if there is any bogus row inserted into target ***
  executeSql([], [
    ("""select rx_nbr,str_nbr,edw_batch_id from prdedwvw.prescription
where rx_create_dt is null;""",
    [])
  ])
  #----*** inserts and updates should all be treated as udpate unless there is missing rx header ***
  executeSql([], [
    ("""select count(*) from (
select store_nbr, rx_nbr
from prdrx2stage.etl_tbf0_rx_cmpnd_nonsys
where cdc_operation_type_cd in ('INSERT', 'SQL COMPUPDATE')
and cdc_before_after_cd = 'AFTER'
group by store_nbr, rx_nbr
) a;""",
    [])
  ])
  #----*** missing PK update in target ***
  executeSql([], [
    ("""select store_nbr, rx_nbr
from prdrx2stage.etl_tbf0_rx_cmpnd_nonsys
where cdc_operation_type_cd = 'PK UPDATE'
minus 
select str_nbr, rx_nbr
from prdedwvw.prescription
where edw_batch_id = 20090218095959;""",
    [])
  ])
  #----*** missing update in target ***
  executeSql([], [
    ("""select store_nbr, rx_nbr
from prdrx2stage.etl_tbf0_rx_cmpnd_nonsys
where cdc_operation_type_cd in ('INSERT', 'SQL COMPUPDATE')
and cdc_before_after_cd = 'AFTER'
group by store_nbr, rx_nbr
minus
select str_nbr, rx_nbr from prdedwvw.prescription
where edw_batch_id = 20090218095959;""",
    [])
  ])
  #-----*** PK update old key still exist in target
  executeSql([], [
    ("""SELECT BFR.STORE_NBR, BFR.RX_NBR
FROM prdrx2stage.etl_tbf0_rx_cmpnd_nonsys AFT
JOIN prdrx2stage.etl_tbf0_rx_cmpnd_nonsys BFR
 ON  AFT.cdc_txn_commit_dttm = BFR.cdc_txn_commit_dttm 
 AND  AFT.cdc_seq_nbr = BFR.cdc_seq_nbr 
 AND  AFT.cdc_rba_nbr = BFR.cdc_rba_nbr 
 AND  AFT.cdc_before_after_cd = 'AFTER'
 AND  AFT.cdc_operation_type_cd = 'PK UPDATE' 
 AND  BFR.cdc_before_after_cd = 'BEFORE'
 AND  BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 
where (BFR.STORE_NBR, BFR.RX_NBR)
in
(select str_nbr, rx_nbr
from prdedwvw.prescription);""",
    [])
  ])
  executeSql([], [
    ("""create temporary  table  Vt_dup_rx_date_calc 
(rx_nbr       integer not null, 
 store_nbr    integer not null,
rx_dt date,
dt_rank smallint 
 ) 
on commit preserve rows;
-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
-- TABLE_INDEX - Remove table index options
""",
    [])
  ])
  executeSql([], [
    ("""insert into vt_dup_rx_date_calc
select str_nbr, rx_nbr, coalesce(rx_create_dt, '2099-12-31'::DATE) as RX_DT, 
 RANK() OVER (PARTITION BY str_nbr,rx_nbr   ORDER BY RX_DT )      Dt_rank  
  from   prdedwvw.prescription
where (str_nbr, rx_nbr) in
(select str_nbr, rx_nbr from   prdedwvw.prescription
group by 1,2
having count(*) > 1);
-- COL_ALIAS_IN_EXPR - Review column alias reference
-- FUN_DATE_CAST - Reformat STRING-to-DATE casting
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  executeSql([], [
    ("""select a.store_nbr, a.rx_nbr, b.rx_dt - a.rx_dt as Days_Apart
from Vt_dup_rx_date_calc a,
     Vt_dup_rx_date_calc b
where a.store_nbr = b.store_nbr
and   a.rx_nbr  = b.rx_nbr
and   a.dt_rank+1 = b.dt_rank
and days_apart < 731;
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  return
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_diagnosis_99
(
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,diagnosis_seq_cd
,src_sys_cd
,diagnosis_cd
,diagnosis_qlfr_cd
,diagnosis_cd_sk
,diagnosis_cd_chng_sk
,loc_store_sk
,dim_loc_store_sk
,loc_store_relocate_chng_sk
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
)
SELECT
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,diagnosis_seq_cd
,src_sys_cd
,diagnosis_cd
,diagnosis_qlfr_cd
,diagnosis_cd_sk
,diagnosis_cd_chng_sk
,loc_store_sk
,dim_loc_store_sk
,loc_store_relocate_chng_sk
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
FROM prdidldb.prescription_diagnosis;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_diagnosis;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_diagnosis_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

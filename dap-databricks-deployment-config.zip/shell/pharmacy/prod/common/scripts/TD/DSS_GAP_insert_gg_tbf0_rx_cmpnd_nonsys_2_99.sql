#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdrx2stage.gg_tbf0_rx_cmpnd_nonsys_2_99
(
cdc_txn_commit_dttm,
cdc_seq_nbr,
cdc_rba_nbr,
cdc_operation_type_cd,
cdc_before_after_cd,
cdc_txn_position_cd,
edw_batch_id,
store_nbr,
rx_nbr,
drug_non_system_name,
drug_assigned_ndc,
drug_non_system_mfg_nm,
priced_as_nonsys_ind,
wic_nbr,
src_partition_nbr,
compound_type
)
select
cdc_txn_commit_dttm,
cdc_seq_nbr,
cdc_rba_nbr,
cdc_operation_type_cd,
cdc_before_after_cd,
cdc_txn_position_cd,
edw_batch_id,
store_nbr,
rx_nbr,
drug_non_system_name,
drug_assigned_ndc,
drug_non_system_mfg_nm,
priced_as_nonsys_ind,
wic_nbr,
src_partition_nbr,
compound_type
FROM prdrx2stage.gg_tbf0_rx_cmpnd_nonsys_2;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdrx2stage.gg_tbf0_rx_cmpnd_nonsys_2;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdrx2stage.gg_tbf0_rx_cmpnd_nonsys_2_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#!/bin/ksh
#echo ".logoff;\n.quit" >>$1
python3<<EOF 1>${1}.log 2>&1
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  mainErrorLevel = Action.errorLevel
  Action.errorLevel = 0
  mainErrorCodeOverride = Action.errorCodeOverride
  Action.errorCodeOverride = None
  FormatOptions.width = 1000
  import $1
  mainErrorLevel = Action.errorLevel
  Action.errorLevel = 0
  mainErrorCodeOverride = Action.errorCodeOverride
  Action.errorCodeOverride = None
  $1.main()
  if(Action.errorLevel != 0 or Action.errorCodeOverride != None):
    return
  else:
    Action.errorLevel = mainErrorLevel
    Action.errorCodeOverride = mainErrorCodeOverride

main()
cleanup()
done()
EOF


#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.proc_prescription_fill_99
(
store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, src_sys_cd
, fill_sold_dt
, fill_sold_tm
, fill_dspn_nbr
, fill_dspn_qty
, fill_partial_cd
, fill_stat_cd
, drug_sk
, drug_id
, dim_drug_sk
, drug_dspn_sk
, drug_dspn_id
, dim_drug_dspn_sk
, fill_type_cd
, fill_src_cd
, fill_del_dttm
, fill_consult_outcome_cd
, refill_remain_cnt
, refill_remain_when_enter_cnt
, fill_pay_method_cd
, fill_days_supply_nbr
, fill_expire_dt
, fill_est_pickup_dttm
, fill_90day_reqst_cd
, fill_90day_reqst_stat_cd
, dea_class_cd
, drug_name
, store_sourcing_cd
, loc_store_sk
, dim_loc_store_sk
, loc_store_relocate_chng_sk
, fill_price_override_amt
, fax_image_id
, fill_sold_amt
, fill_label_price_amt
, fill_awp_amt
, fill_rtl_price_amt
, fill_cost_plus_fee_cd
, fill_discnt_cd
, fill_discnt_amt
, cash_discnt_savings_amt
, tot_amt_paid_cd
, fill_sales_metric_basis_cd
, fill_cost_amt
, fill_rev_amt
, fill_reship_cost_amt
, fill_gross_profit_amt
, fill_plan_tot_tax_amt
, fill_pat_src_id
, composite_type_cd
, msg_type_cd
, eid_dim_fill_cust_sk
, mid_dim_fill_cust_sk
, dim_fill_pat_cust_sk
, fill_cust_sk
, route_store_tech_initials
, service_lvl_cd
, ecom_cd
, overstock_cd
, medicare_d_nte_cd
, medicare_d_nte_print_dttm
, fill_wac_amt
, dspn_store_src_id
, dspn_store_crosswalk_chng_sk
, fill_memo_txt
, fill_metric_qty
, hcfa_genr_cd
, label_print_cd
, unit_per_dose_qty
, whac_unit_amt
, partial_fill_tot_intended_qty
, triplicate_ser_nbr
, delivery_cd
, delivery_cmnts
, src_sys_name
, src_sys_txn_id
, rec_src_cd
, dim_pbr_provider_addr_sk
, pbr_provider_addr_sk
, pbr_provider_addr_src_id
, pbr_provider_sk
, pbr_provider_src_id
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT
store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, src_sys_cd
, fill_sold_dt
, fill_sold_tm
, fill_dspn_nbr
, fill_dspn_qty
, fill_partial_cd
, fill_stat_cd
, drug_sk
, drug_id
, dim_drug_sk
, drug_dspn_sk
, drug_dspn_id
, dim_drug_dspn_sk
, fill_type_cd
, fill_src_cd
, fill_del_dttm
, fill_consult_outcome_cd
, refill_remain_cnt
, refill_remain_when_enter_cnt
, fill_pay_method_cd
, fill_days_supply_nbr
, fill_expire_dt
, fill_est_pickup_dttm
, fill_90day_reqst_cd
, fill_90day_reqst_stat_cd
, dea_class_cd
, drug_name
, store_sourcing_cd
, loc_store_sk
, dim_loc_store_sk
, loc_store_relocate_chng_sk
, fill_price_override_amt
, fax_image_id
, fill_sold_amt
, fill_label_price_amt
, fill_awp_amt
, fill_rtl_price_amt
, fill_cost_plus_fee_cd
, fill_discnt_cd
, fill_discnt_amt
, cash_discnt_savings_amt
, tot_amt_paid_cd
, fill_sales_metric_basis_cd
, fill_cost_amt
, fill_rev_amt
, fill_reship_cost_amt
, fill_gross_profit_amt
, fill_plan_tot_tax_amt
, fill_pat_src_id
, composite_type_cd
, msg_type_cd
, eid_dim_fill_cust_sk
, mid_dim_fill_cust_sk
, dim_fill_pat_cust_sk
, fill_cust_sk
, route_store_tech_inits
, service_lvl_cd
, ecom_cd
, overstock_cd
, medicare_d_nte_cd
, medicare_d_nte_print_dttm
, fill_wac_amt
, dspn_store_src_id
, dspn_store_crosswalk_chng_sk
, fill_memo_txt
, fill_metric_qty
, hcfa_genr_cd
, label_print_cd
, unit_per_dose_qty
, whac_unit_amt
, partial_fill_tot_intended_qty
, triplicate_ser_nbr
, delivery_cd
, delivery_cmnts
, src_sys_name
, src_sys_txn_id
, rec_src_cd
, -1
, -1
, '#'
, -1
, '#' 
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
FROM prdstgcif.proc_prescription_fill;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.proc_prescription_fill;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.proc_prescription_fill_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

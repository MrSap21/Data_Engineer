#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.proc_presc_fill_pat_pic_99
(
store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, src_sys_cd
, fill_sold_dt
, pat_pickup_id
, pickup_id
, pickup_first_name
, pickup_last_name
, pickup_id_qlfr
, pickup_id_state_cd
, pickup_id_cntry_cd
, pickup_relation_cd
, loc_store_sk
, dim_loc_store_sk
, loc_store_relocate_chng_sk
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT
store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, src_sys_cd
, fill_sold_dt
, pat_pickup_id
, pickup_id
, pickup_first_name
, pickup_last_name
, pickup_id_qlfr
, pickup_id_state_cd
, pickup_id_cntry_cd
, pickup_relation_cd
, loc_store_sk
, dim_loc_store_sk
, loc_store_relocate_chng_sk
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
FROM prdstgcif.proc_prescription_fill_pat_pic;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.proc_prescription_fill_pat_pic;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.proc_prescription_fill_pat_pic_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

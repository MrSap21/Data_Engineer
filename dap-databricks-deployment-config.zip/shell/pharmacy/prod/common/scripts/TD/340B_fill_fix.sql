#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO PRDETL.FILL_340B
SELECT * FROM PRDEDWVW.PRESCRIPTION_FILL
WHERE edw_batch_id >= 20090616235600
AND drug_id IS NULL;""",
    [])
  ])
  executeSql([], [
    ("""UPDATE prdetl.fill_340B  fill
SET  pbr_id = rx.pbr_id,
       pbr_loc_id = rx.pbr_loc_id,
       drug_name = rx.drug_non_sys_name             ,
       dea_class_cd = rx.dea_class_cd,
       drug_id = rx.drug_id,
       pat_id = rx.pat_id
FROM    prdedwvw.prescription rx
  WHERE rx.rx_nbr = fill.rx_nbr
AND rx.str_nbr = fill.str_nbr
AND rx.rx_create_dt = fill.rx_create_dt;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  #--2. Populate table with required columns from RXDW1 
  executeSql([], [
    ("""INSERT        INTO prdetl.rxdw_340B 
(rx_nbr,location_nbr,fill_nbr,fill_partial_nbr,fill_entered_dttm,refills_remain_nbr,wac_cost_dlrs) 
select rx_nbr,location_nbr,fill_nbr,fill_partial_nbr,fill_entered_dttm,refills_remain_nbr,wac_cost_dlrs 
FROM        prdedwvw.rxdw_sold_fill 
WHERE       (rx_nbr,location_nbr,fill_nbr,fill_partial_nbr, fill_entered_dttm) 
IN 
(SELECT rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,CAST(fill_enter_dt AS CHAR(10)) || ' ' ||  CAST(fill_enter_tm AS CHAR(8))
FROM prdetl.fill_340B);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  #/* don't run yet  
#					delete from PRDETL.rxdw_340B
#					where wac_cost_dlrs=0
#					and refills_remain_nbr=0
#					;
#					delete from PRDETL.rxdw_340B
#					where (location_nbr, rx_nbr, fill_nbr, fill_partial_nbr, fill_entered_dttm) IN (
#					select location_nbr, rx_nbr, fill_nbr, fill_partial_nbr, fill_entered_dttm from PRDETL.rxdw_340B
#					group by location_nbr, rx_nbr, fill_nbr, fill_partial_nbr, fill_entered_dttm
#					having count(*) > 1 )
#					and refills_remain_nbr=0
#*/
  #--3. Update prescription_fill target for everything except where duplicate records exist with different values in req fields 
  executeSql([], [
    ("""UPDATE        prdetl.fill_340B 
SET fill_wac_dlrs = PRDETL.rxdw_340B.wac_cost_dlrs, 
    refills_remain_cnt = PRDETL.rxdw_340B.refills_remain_nbr
WHERE         
                prdetl.fill_340B.str_nbr = PRDETL.rxdw_340B.location_nbr 
        AND        prdetl.fill_340B.rx_nbr = PRDETL.rxdw_340B.rx_nbr 
        AND        prdetl.fill_340B.rx_fill_nbr = PRDETL.rxdw_340B.fill_nbr 
        AND        prdetl.fill_340B.rx_partial_fill_nbr = PRDETL.rxdw_340B.fill_partial_nbr 
        AND        (CAST(prdetl.fill_340B.fill_enter_dt AS CHAR(10)) || ' ' ||  CAST(prdetl.fill_340B.fill_enter_tm AS CHAR(8))) = CAST(PRDETL.rxdw_340B.fill_entered_dttm AS CHAR(19));""",
    [])
  ])
  #/*  check the result first  */
if __name__ == '__main__':
  main()
  cleanup()
  done()

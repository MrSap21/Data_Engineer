#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""UPDATE prdedwdb.prescription_cmpnd_ingredient 
SET            str_nbr = R.relocate_to_str_nbr, 
        edw_batch_id=20090414120000 
FROM 
        prdedwdb.location_store_relocation  R 
WHERE 
        prdedwdb.prescription_cmpnd_ingredient.str_nbr =R.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE prdrx2stage.etl_proc_dup_rx_cmpnd_ingrdnt 
SET            store_nbr = R.relocate_to_str_nbr, 
        edw_batch_id=20090414120000 
FROM 
        prdedwdb.location_store_relocation  R 
WHERE 
        prdrx2stage.etl_proc_dup_rx_cmpnd_ingrdnt.store_nbr =R.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdrx2stage.gg_tbf0_erx_msg_mapping_99
(
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,icp_erx_msg_id
,rx_nbr
,store_nbr
,epbr_erx_msg_id
,erx_msg_type_sent
,erx_msg_sent_dttm
,erx_msg_type_rcvd
,erx_msg_rcvd_dttm
,create_user_id
,create_dttm
,update_user_id
,update_dttm
,pbr_clinic_id
,erx_xml_image_id
,drug_schedule
,erx_pat_full_name
,erx_pat_address
,erx_pbr_full_name
,erx_pbr_address
,digital_sig_ind
,erx_del_cntrl_drug_nme
,erx_del_cntrl_drug_ndc
,erx_del_cntrl_drug_gpi
,erx_del_cntrl_pbr_id
,MSG_NCPDP_VENDOR_NAME
,MSG_NCPDP_APP_NAME
,MSG_NCPDP_APP_VERSION
,MSG_DRUG_COV_CDS
,pbr_dig_sig_value
,pbr_dig_digest_value
,pbr_dig_X509DATA
,wag_dig_sig
,wag_dig_X509DATA
,ERX_EXC_RESOLVED_IND
)
SELECT
cdc_txn_commit_dttm
,cdc_seq_nbr
,cdc_rba_nbr
,cdc_operation_type_cd
,cdc_before_after_cd
,cdc_txn_position_cd
,edw_batch_id
,icp_erx_msg_id
,rx_nbr
,store_nbr
,epbr_erx_msg_id
,erx_msg_type_sent
,erx_msg_sent_dttm
,erx_msg_type_rcvd
,erx_msg_rcvd_dttm
,create_user_id
,create_dttm
,update_user_id
,update_dttm
,pbr_clinic_id
,erx_xml_image_id
,drug_schedule
,erx_pat_full_name
,erx_pat_address
,erx_pbr_full_name
,erx_pbr_address
,digital_sig_ind
,erx_del_cntrl_drug_nme
,erx_del_cntrl_drug_ndc
,erx_del_cntrl_drug_gpi
,erx_del_cntrl_pbr_id
,MSG_NCPDP_VENDOR_NAME
,MSG_NCPDP_APP_NAME
,MSG_NCPDP_APP_VERSION
,MSG_DRUG_COV_CDS
,pbr_dig_sig_value
,pbr_dig_digest_value
,pbr_dig_X509DATA
,wag_dig_sig
,wag_dig_X509DATA
,ERX_EXC_RESOLVED_IND
FROM prdrx2stage.gg_tbf0_erx_msg_mapping;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdrx2stage.gg_tbf0_erx_msg_mapping;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdrx2stage.gg_tbf0_erx_msg_mapping_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_control_subst_99
(
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,txn_cd
,src_partition_nbr
,fill_sold_dt
,loc_store_sk
,dim_loc_store_sk
,drug_sk
,drug_id
,dim_drug_sk
,drug_non_sys_name
,fill_vrfy_user_initials
,src_create_dttm
,src_create_user_sk
,src_create_user_chng_sk
,src_create_user_id
,src_update_dttm
,src_update_user_sk
,src_update_user_chng_sk
,src_update_user_id
,loc_store_relocate_chng_sk
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
)
SELECT
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,txn_cd
,src_partition_nbr
,fill_sold_dt
,loc_store_sk
,dim_loc_store_sk
,drug_sk
,drug_id
,dim_drug_sk
,drug_non_sys_name
,fill_vrfy_user_initials
,src_create_dttm
,src_create_user_sk
,src_create_user_chng_sk
,src_create_user_id
,src_update_dttm
,src_update_user_sk
,src_update_user_chng_sk
,src_update_user_id
,loc_store_relocate_chng_sk
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
FROM prdidldb.prescription_control_substance;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_control_substance;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_control_subst_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_vaccination_99
(
store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, src_sys_cd
, rx_vaccine_consent_cd
, rx_vaccine_expire_dttm
, rx_vaccine_mfg_lot_nbr
, phys_ntfcn_ltr_enter_dttm
, phys_ntfcn_ltr_dstrb_cd
, loc_store_sk
, dim_loc_store_sk
, loc_store_relocate_chng_sk
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
)
SELECT
store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, src_sys_cd
, rx_vaccine_consent_cd
, rx_vaccine_expire_dttm
, rx_vaccine_mfg_lot_nbr
, phys_ntfcn_ltr_enter_dttm
, phys_ntfcn_ltr_dstrb_cd
, loc_store_sk
, dim_loc_store_sk
, loc_store_relocate_chng_sk
, edw_create_dttm
, edw_update_dttm
, edw_batch_id
FROM prdidldb.prescription_vaccination;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_vaccination;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_vaccination_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

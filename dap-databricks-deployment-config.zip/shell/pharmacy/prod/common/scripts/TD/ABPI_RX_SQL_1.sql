#/usr/bin/python3
from npjet import *
def main():

  #/* 7. perform store relo  against stage */
  executeSql([], [
    ("""UPDATE prdetl.etl_tbf0_rx_p2 stg
set store_nbr= s.relocate_to_str_nbr
FROM    prdetl.location_store_relocation_p2 s
where
stg.store_nbr=s.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE prdetl.etl_tbf0_rx_p2 stg
set scanned_store_nbr=s.relocate_to_str_nbr
FROM    prdetl.location_store_relocation_p2 s
where stg.scanned_store_nbr=s.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE prdetl.etl_tbf0_rx_p2 stg
set routing_store_nbr=s.relocate_to_str_nbr
FROM    prdetl.location_store_relocation_p2 s
where stg.routing_store_nbr=s.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  #/*  8. dedup  etl  stage  based on str_nbr, rx_nbr and pick the max(update_dttm  */
  executeSql([], [
    ("""create temporary table prdetl.rx_inserts
(
      store_nbr DECIMAL(5,0) NOT NULL,
      rx_nbr DECIMAL(7,0) NOT NULL,
      update_dttm TIMESTAMP
) on commit preserve rows;
-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- TABLE_INDEX - Remove table index options
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""insert into  prdetl.rx_inserts
select store_nbr, rx_nbr,max(update_dttm) as update_dttm
from prdetl.etl_tbf0_rx_p2
where (store_nbr,rx_nbr)
in
	(
	select store_nbr, rx_nbr
	from prdetl.etl_tbf0_rx_p2
group by 1,2
having count(*) > 1
	)
group by 1,2;
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from prdetl.etl_tbf0_rx_p2 stg 
using prdetl.rx_inserts v 
where stg.store_nbr=v.store_nbr
and stg.rx_nbr=v.rx_nbr
and stg.update_dttm <> v.update_dttm;
-- DEL_STATEMENT - Replace DEL with DELETE
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""drop table if exists prdetl.rx_inserts;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  #----------------------------------------------------------------------------
  #/*  9. merge with tagret against 3 part key */
  executeSql([], [
    ("""delete from prdetl.etl_tbf0_rx_p2 stg 
using prdetl.prescription_tgt_icp tgt 
where 
stg.store_nbr=tgt.store_nbr
and stg.rx_nbr=tgt.rx_nbr
and tgt.create_dttm=stg.create_dttm;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  #/* 10. merge with target table agianst 2 part key and 730 days check */
  executeSql([], [
    ("""delete from prdetl.etl_tbf0_rx_p2 stg 
using prdetl.prescription_tgt_icp tgt 
where 
stg.store_nbr=tgt.store_nbr
and stg.rx_nbr=tgt.rx_nbr
and cast(tgt.create_dttm as date) - cast(stg.create_dttm as date) <=730;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  return
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

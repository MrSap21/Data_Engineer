#/usr/bin/python3
from npjet import *
def main():

  #/****** Store Relo Prescription_Close_Log *****/
  executeSql([], [
    ("""UPDATE prdedwdb.prescription_close_log
ECHO is off.
set    xfer_fm_str_nbr = R.relocate_to_str_nbr
,edw_batch_id=20090414120000
 from   prdedwdb.location_store_relocation  R
 where  prdedwdb.prescription_close_log.xfer_fm_str_nbr =
 R.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE prdedwdb.prescription_close_log
ECHO is off.
set    xfer_to_str_nbr = R.relocate_to_str_nbr
,edw_batch_id=20090414120000
 from   prdedwdb.location_store_relocation  R
 where  prdedwdb.prescription_close_log.xfer_to_str_nbr =
 R.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  #/****** Store Relo Dup_Rx_Close_Log *****/
  executeSql([], [
    ("""UPDATE prdrx2stage.etl_proc_dup_rx_close_log
ECHO is off.
set    rx_xfr_from_store_nbr = R.relocate_to_str_nbr
,edw_batch_id=20090414120000
 from   prdedwdb.location_store_relocation  R
 where  prdrx2stage.etl_proc_dup_rx_close_log.rx_xfr_from_store_nbr =
 R.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE prdrx2stage.etl_proc_dup_rx_close_log
ECHO is off.
set    rx_xfr_to_store_nbr = R.relocate_to_str_nbr
 ,edw_batch_id=20090414120000
 from   prdedwdb.location_store_relocation  R
 where  prdrx2stage.etl_proc_dup_rx_close_log.rx_xfr_to_store_nbr =
 R.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

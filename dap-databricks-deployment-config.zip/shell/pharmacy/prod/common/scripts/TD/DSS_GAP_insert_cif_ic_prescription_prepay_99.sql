#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescription_prepay_99
(
cdc_txn_commit_dttm
,src_partition_nbr
,src_sys_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,rx_create_dt
,rx_create_tm
,fill_enter_dt
,fill_enter_tm
,fill_sold_dt
,prpd_store_nbr
,rfn_nbr
,prpd_amt
,prpd_dttm
,prpd_stat_cd
,prpd_tax_amt
,mail_payment_apply_cd
,src_create_dttm
,src_update_dttm
)
SELECT 
cdc_txn_commit_dttm
,src_partition_nbr
,src_sys_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,rx_create_dt
,rx_create_tm
,fill_enter_dt
,fill_enter_tm
,fill_sold_dt
,prpd_store_nbr
,rfn_nbr
,prpd_amt
,prpd_dttm
,prpd_stat_cd
,prpd_tax_amt
,mail_payment_apply_cd
,src_create_dttm
,src_update_dttm
 FROM prdstgcif.cif_ic_prescription_prepay;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_prepay;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescription_prepay_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

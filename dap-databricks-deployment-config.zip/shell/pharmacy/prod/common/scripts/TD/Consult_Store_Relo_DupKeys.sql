#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""insert into prdetl.consultation_str_dups_Keys
select TGT.str_nbr,TGT.rx_nbr,TGT.fill_nbr_dspn,TGT.create_dt,TGT.create_tm
from prdedwdb.prescription_consultation TGT, prdetl.location_store_relocation_p2 RELO
where TGT.str_nbr=RELO.relocate_to_str_nbr
group by 1,2,3,4,5
having count(*) >1;
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

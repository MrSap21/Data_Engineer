#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""insert into prdetl.consult_multiple_keys 
select rx_nbr,str_nbr,fill_nbr_dspn,create_dt,create_tm from prdedwvw.prescription_consultation
group by 1,2,3,4,5
having count(*) >1;
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

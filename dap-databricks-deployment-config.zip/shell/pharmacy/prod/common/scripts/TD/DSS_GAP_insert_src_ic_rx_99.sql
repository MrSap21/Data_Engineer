#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.src_ic_rx_99 
( 
change_cd
, cdc_txn_commit_dttm
, src_partition_nbr
, edw_batch_id
, store_nbr
, rx_nbr
, pat_id
, drug_id
, drug_class
, drug_non_system_cd
, pbr_id
, fill_qty_dispensed
, fill_days_supply
, rx_daw_ind
, rx_written_dttm
, rx_original_fill_dttm
, rx_added_qty
, rx_sig
, rx_refills_by_dttm
, fill_nbr_prescribed
, fill_nbr_dispensed
, fill_nbr_added
, fill_auto_ind
, fill_nbr_last_disp
, fill_entered_dttm
, image_id
, scanned_user_id
, scanned_dttm
, scanned_store_nbr
, tip_rx_ind
, pbr_order_nbr
, drug_sub_cd
, pbr_loc_id
, pay_cd
, rx_comment
, rx_status_cd
, fill_unlimited_ind
, ordered_drug_id
, create_user_id
, create_dttm
, create_dttm_init
, update_user_id
, update_dttm
, generic_subs_pref
, routing_store_nbr
, rx_original_qty_disp
, rx_original_days_supply
, rx_total_dispensed_qty
, rx_original_qty
, diagnosis_cd
, diagnosis_cd_qualifier
, origin_cd
, diagnosis_cd_2
, diagnosis_cd_3
, diagnosis_cd_4
, rx_pad_program_ind
, rx_pad_barcode
, rx_vacc_manuf_lot_nbr
, rx_vacc_exp_dttm
, rx_vacc_area_of_admin
, rx_vacc_consent_ind
, rx_vacc_pnl_ent_dttm
, rx_vacc_pnl_status_cd
, rx_90day_pref_ind
, rx_90day_pref_dttm
, rx_90day_pref_stat_cd
, rx_90day_pref_stat_dttm
, pbr_dea_nbr
, pbr_dea_suf
, diagnosis_cd_5
, diagnosis_cd_qualifier_2
, diagnosis_cd_qualifier_3
, diagnosis_cd_qualifier_4
, diagnosis_cd_qualifier_5
)
SELECT
change_cd
, cdc_txn_commit_dttm
, src_partition_nbr
, edw_batch_id
, store_nbr
, rx_nbr
, pat_id
, drug_id
, drug_class
, drug_non_system_cd
, pbr_id
, fill_qty_dispensed
, fill_days_supply
, rx_daw_ind
, rx_written_dttm
, rx_original_fill_dttm
, rx_added_qty
, rx_sig
, rx_refills_by_dttm
, fill_nbr_prescribed
, fill_nbr_dispensed
, fill_nbr_added
, fill_auto_ind
, fill_nbr_last_disp
, fill_entered_dttm
, image_id
, scanned_user_id
, scanned_dttm
, scanned_store_nbr
, tip_rx_ind
, pbr_order_nbr
, drug_sub_cd
, pbr_loc_id
, pay_cd
, rx_comment
, rx_status_cd
, fill_unlimited_ind
, ordered_drug_id
, create_user_id
, create_dttm
, create_dttm_init
, update_user_id
, update_dttm
, generic_subs_pref
, routing_store_nbr
, rx_original_qty_disp
, rx_original_days_supply
, rx_total_dispensed_qty
, rx_original_qty
, diagnosis_cd
, diagnosis_cd_qualifier
, origin_cd
, diagnosis_cd_2
, diagnosis_cd_3
, diagnosis_cd_4
, rx_pad_program_ind
, rx_pad_barcode
, rx_vacc_manuf_lot_nbr
, rx_vacc_exp_dttm
, rx_vacc_area_of_admin
, rx_vacc_consent_ind
, rx_vacc_pnl_ent_dttm
, rx_vacc_pnl_status_cd
, rx_90day_pref_ind
, rx_90day_pref_dttm
, rx_90day_pref_stat_cd
, rx_90day_pref_stat_dttm
, pbr_dea_nbr
, pbr_dea_suf
, diagnosis_cd_5
, diagnosis_cd_qualifier_2
, diagnosis_cd_qualifier_3
, diagnosis_cd_qualifier_4
, diagnosis_cd_qualifier_5
FROM prdstgcif.src_ic_rx;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.src_ic_rx;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.src_ic_rx_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

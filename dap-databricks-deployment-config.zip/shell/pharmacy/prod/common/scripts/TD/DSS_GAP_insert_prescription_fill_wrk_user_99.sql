#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_fill_wrk_user_99
(
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,src_partition_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,fill_sold_dt
,loc_store_sk
,dim_loc_store_sk
,fill_vrfy_user_id
,fill_vrfy_dttm
,fill_data_review_user_id
,fill_data_review_dttm
,fill_review_store_nbr
,fill_enter_user_id
,fill_enter_store_nbr
,filling_user_id
,filling_dttm
,override_user_id
,override_dttm
,data_review_spct_id
,data_review_spct_store_nbr
,data_review_spct_dttm
,fill_rph_of_rec_id
,fill_print_dttm
,fill_rebill_dttm
,src_create_user_id
,src_create_dttm
,src_update_user_id
,src_update_dttm
,loc_store_relocate_chng_sk
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
)
SELECT
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,src_partition_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,fill_sold_dt
,loc_store_sk
,dim_loc_store_sk
,fill_vrfy_user_id
,fill_vrfy_dttm
,fill_data_review_user_id
,fill_data_review_dttm
,fill_review_store_nbr
,fill_enter_user_id
,fill_enter_store_nbr
,filling_user_id
,filling_dttm
,override_user_id
,override_dttm
,data_review_spct_id
,data_review_spct_store_nbr
,data_review_spct_dttm
,fill_rph_of_rec_id
,fill_print_dttm
,fill_rebill_dttm
,src_create_user_id
,src_create_dttm
,src_update_user_id
,src_update_dttm
,loc_store_relocate_chng_sk
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
FROM prdidldb.prescription_fill_wrkflow_user;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_fill_wrkflow_user;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_fill_wrk_user_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  Action.exportFileName = "FillKeysToPullFromBCV.dat"
  ExportOptions.colLimit = 100
  Action.charSet = "UTF-8"
  executeSql([], [
    ("""select f.str_nbr, f.rx_nbr, f.rx_fill_nbr, f.rx_partial_fill_nbr,
 f.fill_enter_dt, f.fill_enter_tm from prescription_fill f 
left outer join prescription_fill_plan p 
on (f.str_nbr = p.str_nbr 
and f.rx_nbr = p.rx_nbr 
and f.rx_fill_nbr = p.rx_fill_nbr
and f.rx_partial_fill_nbr = p.rx_partial_fill_nbr
and f.fill_enter_dt = p.fill_enter_dt
and f.fill_enter_tm = p.fill_enter_tm)
where f.fill_pay_method_cd = 'T' 
and p.third_party_plan_id is null 
and f.fill_sold_dt < '2006-01-01';
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    return
  executeSql([], [
    ("""select f.str_nbr, f.rx_nbr, f.rx_fill_nbr, f.rx_partial_fill_nbr,
 f.fill_enter_dt, f.fill_enter_tm from prescription_fill f 
left outer join prescription_fill_plan p 
on (f.str_nbr = p.str_nbr 
and f.rx_nbr = p.rx_nbr 
and f.rx_fill_nbr = p.rx_fill_nbr
and f.rx_partial_fill_nbr = p.rx_partial_fill_nbr
and f.fill_enter_dt = p.fill_enter_dt
and f.fill_enter_tm = p.fill_enter_tm)
where f.fill_pay_method_cd = 'T' 
and p.third_party_plan_id is null 
and f.fill_sold_dt >= '2006-01-01' AND f.fill_sold_dt < '2007-01-01';
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    return
  executeSql([], [
    ("""select f.str_nbr, f.rx_nbr, f.rx_fill_nbr, f.rx_partial_fill_nbr,
 f.fill_enter_dt, f.fill_enter_tm from prescription_fill f 
left outer join prescription_fill_plan p 
on (f.str_nbr = p.str_nbr 
and f.rx_nbr = p.rx_nbr 
and f.rx_fill_nbr = p.rx_fill_nbr
and f.rx_partial_fill_nbr = p.rx_partial_fill_nbr
and f.fill_enter_dt = p.fill_enter_dt
and f.fill_enter_tm = p.fill_enter_tm)
where f.fill_pay_method_cd = 'T' 
and p.third_party_plan_id is null 
and f.fill_sold_dt >= '2007-01-01' AND f.fill_sold_dt < '2008-01-01';
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    return
  executeSql([], [
    ("""select f.str_nbr, f.rx_nbr, f.rx_fill_nbr, f.rx_partial_fill_nbr,
 f.fill_enter_dt, f.fill_enter_tm from prescription_fill f 
left outer join prescription_fill_plan p 
on (f.str_nbr = p.str_nbr 
and f.rx_nbr = p.rx_nbr 
and f.rx_fill_nbr = p.rx_fill_nbr
and f.rx_partial_fill_nbr = p.rx_partial_fill_nbr
and f.fill_enter_dt = p.fill_enter_dt
and f.fill_enter_tm = p.fill_enter_tm)
where f.fill_pay_method_cd = 'T' 
and p.third_party_plan_id is null 
and f.fill_sold_dt >= '2008-01-01' AND f.fill_sold_dt < '2008-06-01';
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    return
  executeSql([], [
    ("""select f.str_nbr, f.rx_nbr, f.rx_fill_nbr, f.rx_partial_fill_nbr,
 f.fill_enter_dt, f.fill_enter_tm from prescription_fill f 
left outer join prescription_fill_plan p 
on (f.str_nbr = p.str_nbr 
and f.rx_nbr = p.rx_nbr 
and f.rx_fill_nbr = p.rx_fill_nbr
and f.rx_partial_fill_nbr = p.rx_partial_fill_nbr
and f.fill_enter_dt = p.fill_enter_dt
and f.fill_enter_tm = p.fill_enter_tm)
where f.fill_pay_method_cd = 'T' 
and p.third_party_plan_id is null 
and f.fill_sold_dt >= '2008-06-01' AND f.fill_sold_dt < '2009-01-01';
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    return
  executeSql([], [
    ("""select f.str_nbr, f.rx_nbr, f.rx_fill_nbr, f.rx_partial_fill_nbr,
 f.fill_enter_dt, f.fill_enter_tm from prescription_fill f 
left outer join prescription_fill_plan p 
on (f.str_nbr = p.str_nbr 
and f.rx_nbr = p.rx_nbr 
and f.rx_fill_nbr = p.rx_fill_nbr
and f.rx_partial_fill_nbr = p.rx_partial_fill_nbr
and f.fill_enter_dt = p.fill_enter_dt
and f.fill_enter_tm = p.fill_enter_tm)
where f.fill_pay_method_cd = 'T' 
and p.third_party_plan_id is null 
and f.fill_sold_dt >= '2009-01-01' AND f.fill_sold_dt < '2009-04-01';
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    return
  executeSql([], [
    ("""select f.str_nbr, f.rx_nbr, f.rx_fill_nbr, f.rx_partial_fill_nbr,
 f.fill_enter_dt, f.fill_enter_tm from prescription_fill f 
left outer join prescription_fill_plan p 
on (f.str_nbr = p.str_nbr 
and f.rx_nbr = p.rx_nbr 
and f.rx_fill_nbr = p.rx_fill_nbr
and f.rx_partial_fill_nbr = p.rx_partial_fill_nbr
and f.fill_enter_dt = p.fill_enter_dt
and f.fill_enter_tm = p.fill_enter_tm)
where f.fill_pay_method_cd = 'T' 
and p.third_party_plan_id is null 
and f.fill_sold_dt >= '2009-04-01' AND f.fill_sold_dt < '2009-08-01';
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    return
  executeSql([], [
    ("""select f.str_nbr, f.rx_nbr, f.rx_fill_nbr, f.rx_partial_fill_nbr,
 f.fill_enter_dt, f.fill_enter_tm from prescription_fill f 
left outer join prescription_fill_plan p 
on (f.str_nbr = p.str_nbr 
and f.rx_nbr = p.rx_nbr 
and f.rx_fill_nbr = p.rx_fill_nbr
and f.rx_partial_fill_nbr = p.rx_partial_fill_nbr
and f.fill_enter_dt = p.fill_enter_dt
and f.fill_enter_tm = p.fill_enter_tm)
where f.fill_pay_method_cd = 'T' 
and p.third_party_plan_id is null 
and f.fill_sold_dt >= '2009-08-01';
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    return
  executeSql([], [
    ("""select f.str_nbr, f.rx_nbr, f.rx_fill_nbr, f.rx_partial_fill_nbr,
 f.fill_enter_dt, f.fill_enter_tm from prescription_fill f 
left outer join prescription_fill_plan p 
on (f.str_nbr = p.str_nbr 
and f.rx_nbr = p.rx_nbr 
and f.rx_fill_nbr = p.rx_fill_nbr
and f.rx_partial_fill_nbr = p.rx_partial_fill_nbr
and f.fill_enter_dt = p.fill_enter_dt
and f.fill_enter_tm = p.fill_enter_tm)
where f.fill_pay_method_cd = 'T' 
and p.third_party_plan_id is null 
and f.fill_sold_dt IS NULL;
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  #--2. POPULATE TEMP TABLES
  executeSql([], [
    ("""INSERT INTO PRDETL.FILL_PLAN_340B
SELECT * FROM prescription_fill_plan fp
WHERE 
fp.edw_batch_id >= 20090616235600
AND fp.cob_ind = 'N'
--AND fp.fill_adjud_cd   IN ('A','L','X')
AND 
(
(
	(  fp.plan_return_copay_dlrs   IS NULL  AND fp.plan_copay_dlrs IS NOT NULL)
	OR  (  fp.plan_return_cost_dlrs  IS NULL )
	OR  (  fp.plan_return_tax_dlrs    IS NULL AND  fp.plan_tax_dlrs IS NOT NULL)
)
OR
(
	(  fp.plan_submit_cost_dlrs  IS NULL )
	OR  (fp.plan_submit_copay_dlrs  IS NULL  AND fp.plan_copay_dlrs IS NOT NULL)
	OR 	(plan_submit_tax_dlrs       IS NULL AND plan_tax_dlrs IS NOT NULL)
)
);""",
    [])
  ])
  executeSql([], [
    ("""INSERT INTO prdetl.rxdw_340b_fp
(rx_nbr,location_nbr,fill_nbr,fill_partial_nbr,fill_entered_dttm,returnd_ing_cost_dlrs)
select rx_nbr,location_nbr,fill_nbr,fill_partial_nbr,fill_entered_dttm,returnd_ing_cost_dlrs         
FROM        prdedwvw.rxdw_sold_fill 
WHERE       (rx_nbr,location_nbr,fill_nbr,fill_partial_nbr, fill_entered_dttm) 
IN 
(SELECT rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,CAST(fill_enter_dt AS CHAR(10)) || ' ' ||  CAST(fill_enter_tm AS CHAR(8))
FROM PRDETL.FILL_PLAN_340B);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  #--3. UPDATE FILL PLAN plan_return records
  executeSql([], [
    ("""UPDATE prdetl.FILL_PLAN_340B tfp
SET plan_return_cost_dlrs = rxdw.returnd_ing_cost_dlrs
FROM    prdetl.rxdw_340b_fp rxdw
WHERE         
        tfp.str_nbr = rxdw.location_nbr 
        And        tfp.rx_nbr = rxdw.rx_nbr 
        And        tfp.rx_fill_nbr = rxdw.fill_nbr 
        And        tfp.rx_partial_fill_nbr = rxdw.fill_partial_nbr 
        And        (Cast(tfp.fill_enter_dt As char(10)) || ' ' ||  Cast(tfp.fill_enter_tm As char(8))) = CAST(rxdw.fill_entered_dttm as CHAR(19))
		AND 		tfp.plan_return_cost_dlrs  IS NULL AND rxdw.returnd_ing_cost_dlrs IS NOT NULL
		AND 		tfp.fill_adjud_cd   IN ('A','L','X');
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  executeSql([], [
    ("""UPDATE   prdetl.FILL_PLAN_340B
SET plan_return_copay_dlrs = plan_copay_dlrs
WHERE         
plan_return_copay_dlrs   IS NULL  
AND plan_copay_dlrs IS NOT NULL
AND	fill_adjud_cd   IN ('A','L','X');""",
    [])
  ])
  executeSql([], [
    ("""UPDATE   prdetl.FILL_PLAN_340B
SET plan_return_tax_dlrs = plan_tax_dlrs
WHERE         
plan_return_tax_dlrs    IS NULL 
AND plan_tax_dlrs IS NOT NULL
AND fill_adjud_cd   IN ('A','L','X');""",
    [])
  ])
  #--3. UPDATE FILL PLAN plan_submit  records 
  executeSql([], [
    ("""UPDATE prdetl.FILL_PLAN_340B tfp
SET plan_submit_cost_dlrs   = rxdw.returnd_ing_cost_dlrs
FROM    prdetl.rxdw_340b_fp rxdw
WHERE         
        tfp.str_nbr = rxdw.location_nbr 
        And        tfp.rx_nbr = rxdw.rx_nbr 
        And        tfp.rx_fill_nbr = rxdw.fill_nbr 
        And        tfp.rx_partial_fill_nbr = rxdw.fill_partial_nbr 
        And        (Cast(tfp.fill_enter_dt As char(10)) || ' ' ||  Cast(tfp.fill_enter_tm As char(8))) = CAST(rxdw.fill_entered_dttm as CHAR(19))
		AND 		tfp.plan_submit_cost_dlrs  IS NULL AND rxdw.returnd_ing_cost_dlrs IS NOT NULL
		AND 		tfp.fill_adjud_cd  NOT IN ('A','L','X');
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  executeSql([], [
    ("""UPDATE   prdetl.FILL_PLAN_340B
SET plan_submit_copay_dlrs         = plan_copay_dlrs
WHERE         
plan_submit_copay_dlrs           IS NULL  
AND plan_copay_dlrs IS NOT NULL
AND	fill_adjud_cd  NOT  IN ('A','L','X');""",
    [])
  ])
  executeSql([], [
    ("""UPDATE   prdetl.FILL_PLAN_340B
SET plan_submit_tax_dlrs           = plan_tax_dlrs
WHERE         
plan_submit_tax_dlrs              IS NULL 
AND plan_tax_dlrs IS NOT NULL
AND fill_adjud_cd NOT  IN ('A','L','X');""",
    [])
  ])
  #--------------------- ###############################
  #-- MOVE THE RECORDS BACK TO FILL PLAN
  executeSql([], [
    ("""UPDATE PRDETL.FILL_PLAN_340B
SET EDW_BATCH_ID = 20090624132700;""",
    [])
  ])
if __name__ == '__main__':
  main()
  cleanup()
  done()

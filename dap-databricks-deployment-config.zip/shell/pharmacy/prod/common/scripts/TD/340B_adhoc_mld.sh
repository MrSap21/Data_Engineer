python3<<ZZ >/usr/local/edw/pharmacy/prod/teralog/$0.log
#!/usr/bin/python3

from npjet import *

def main():
  sys.path.append("/usr/local/edwphrm")
  import _logonformld
  mainErrorLevel = Action.errorLevel
  Action.errorLevel = 0
  mainErrorCodeOverride = Action.errorCodeOverride
  Action.errorCodeOverride = None
  _logonformld.main()
  if Action.errorLevel != 0 or Action.errorCodeOverride != None:
    return
  else:
    Action.errorLevel = mainErrorLevel
    Action.errorCodeOverride = mainErrorCodeOverride
  runSql("""drop table if exists prdetl.adhoc_340B_ERR1;\n-- DROP_TBL: Add if exists in drop table\n""")
  if Action.errorCode != 0:
    return
  runSql("""drop table if exists prdetl.adhoc_340B_ERR2;\n-- DROP_TBL: Add if exists in drop table\n""")
  if Action.errorCode != 0:
    return
  runSql("""drop table if exists prdetl.adhoc_340B_WRK;\n-- DROP_TBL: Add if exists in drop table\n""")
  if Action.errorCode != 0:
    return
  release=True
  release=True
  runSql("""delete from PHARMSUP.adhoc_340B_0414;""")
  if Action.errorCode != 0:
    return
  # Missing multiset configuration, for table: adhoc_340B_0414, will default to no duplicates
  LoadOptions.ignoreMissingUpdate = "FIXME"
  LoadOptions.importFileName = "/usr/local/edw/pharmacy/prod/audit/340B_adhoc_0410.dat"
  LoadOptions.delimiter = "|"
  LoadOptions.targetTableName = "PHARMSUP.adhoc_340B_0414"
  LoadOptions.uploadTableName = "prdetl.adhoc_340B_ERR2"
  LoadOptions.stageName = "DIRECT_UPLOAD_PHARMSUP_adhoc_340B_0414"
  runSql("""CREATE TEMPORARY STAGE IF NOT EXISTS """ + LoadOptions.stageName)
  if Action.errorCode != 0:
    return
  runSql("""PUT 'file://""" + LoadOptions.importFileName + """' '@""" + LoadOptions.stageName + """' parallel=10 overwrite=true""")
  if Action.errorCode != 0:
    return
  runSql("""CREATE TABLE """ + getTable(LoadOptions.uploadTableName) + """ LIKE """ + getTable(LoadOptions.targetTableName) + """""")
  if Action.errorCode != 0:
    return
  runSql("""COPY INTO """ + getTable(LoadOptions.uploadTableName) + " (rx_nbr, str_nbr, adjudication_dt)" + """
FROM(
  SELECT
    $1, $2, $3
  FROM @""" + LoadOptions.stageName + """
) FILE_FORMAT = (
  TYPE=CSV
  ENCODING='""" + LoadOptions.inputCharset + """'
  FIELD_DELIMITER='""" + LoadOptions.delimiter + """'
  TRIM_SPACE=TRUE
 """ + getFieldQuote() + """
)
 """ + LoadOptions.sfErrorHandler + """
  ENFORCE_LENGTH=FALSE""")
  if Action.errorCode != 0:
    return
  runSql("""select * from table(validate(""" + getTable(LoadOptions.uploadTableName) + """, job_id => '_last'))""")
  if Action.errorCode != 0:
    return
  if Action.activityCount >= LoadOptions.maxErrorCount:
    nprint("maxErrorCount reached. Raising error ", Action.quietLevel)
    setErrorCode(3706)
  if Action.errorCode != 0:
    return
  runSql("""INSERT INTO """+ getTable(LoadOptions.targetTableName) +  "(rx_nbr, str_nbr, adjudication_dt) " +"""
SELECT """ + LoadOptions.ignoreDuplicatesInsert + """rx_nbr, str_nbr, adjudication_dt
 FROM """+ getTable(LoadOptions.uploadTableName) + """
""")
  if Action.errorCode != 0:
    return
  runSql("""DROP TABLE """ + getTable(LoadOptions.uploadTableName))
  if Action.errorCode != 0:
    return
  runSql(""" DROP STAGE """ + LoadOptions.stageName)

if __name__ == '__main__':
  main()
  cleanup()
  done()

ZZ
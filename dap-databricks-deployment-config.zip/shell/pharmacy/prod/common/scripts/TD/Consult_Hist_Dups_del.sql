#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""delete from prescription_consultation
where( rx_nbr
,str_nbr
,fill_nbr_dspn
,cast(create_dt||' '||cast(create_tm as char(8)) as timestamp(0))
)
in (select rx_nbr
,str_nbr
,fill_nbr_dispensed
,create_dttm from prdetl.consult_keys);
-- DEL_STATEMENT - Replace DEL with DELETE
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""UPDATE prdedwdb.prescription_consultation Consult
ECHO is off.
set    rx_create_dt = STG.to_create_dt
 FROM    (Select str_nbr ,rx_nbr ,cast(frm_create_dttm as date) frm_create_dt,
     cast(to_create_dttm as date) to_create_dt, change_prcs_ind
                FROM    prdrx2stage.rx_create_dttm_change
WHERE frm_create_dt <> to_create_dt
ECHO is off.
        GROUP BY 1,2,3,4,5
ECHO is off.
        )  STG
 where  Consult.str_nbr = STG.str_nbr
  AND Consult.rx_nbr = STG.rx_nbr
  AND Consult.rx_create_dt =  STG.frm_create_dt
  AND Consult.rx_create_dt IS NOT NULL
  AND STG.change_prcs_ind = 'N';
-- SEL_BODY_CLAUSES_ORDER - change the order of all the clauses of a select statement
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

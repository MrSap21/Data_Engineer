#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.src_ic_rx_cmpnd_nonsys_99
(
cdc_txn_commit_dttm
,edw_batch_id
,src_partition_nbr
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,compound_type
)
select
cdc_txn_commit_dttm
,edw_batch_id
,src_partition_nbr
,store_nbr
,rx_nbr
,drug_non_system_name
,drug_assigned_ndc
,drug_non_system_mfg_nm
,priced_as_nonsys_ind
,wic_nbr
,compound_type
FROM prdstgcif.src_ic_rx_cmpnd_nonsys;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.src_ic_rx_cmpnd_nonsys;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.src_ic_rx_cmpnd_nonsys_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

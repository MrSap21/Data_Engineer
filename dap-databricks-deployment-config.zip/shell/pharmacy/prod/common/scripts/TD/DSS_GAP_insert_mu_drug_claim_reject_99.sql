#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.mu_drug_claim_reject_99
(
cdc_txn_commit_dttm
, change_cd
, store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, insure_plan_src_id
, plan_rank_cd
, reject_seq_nbr
, src_sys_cd
, src_update_user_id
, src_create_user_id
, reject_cd
, fill_sold_dt
, src_update_dttm
)
SELECT
cdc_txn_commit_dttm
, change_cd
, store_nbr
, rx_src_id
, rx_nbr
, rx_create_dt
, rx_create_tm
, src_partition_nbr
, rx_fill_nbr
, rx_partial_fill_nbr
, fill_enter_dt
, fill_enter_tm
, insure_plan_src_id
, plan_rank_cd
, reject_nbr_seq
, src_sys_cd
, src_update_user_id
, src_create_user_id
, reject_cd
, fill_sold_dt
, src_update_dttm
FROM prdstgcif.mu_drug_claim_reject;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.mu_drug_claim_reject;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.mu_drug_claim_reject_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

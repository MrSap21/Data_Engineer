#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescription_cns_99
(
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,src_sys_cd
,drug_cmpnd_type_cd
,drug_cmpnd_non_sys_name
,drug_cmpnd_non_sys_assign_ndc
,drug_cmpnd_non_sys_mfgr_name
,wag_inv_ctrl_nbr
,non_sys_priced_cd
)
select
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,src_sys_cd
,drug_cmpnd_type_cd
,drug_cmpnd_non_sys_name
,drug_cmpnd_non_sys_assign_ndc
,drug_cmpnd_non_sys_mfgr_name
,wag_inv_ctrl_nbr
,non_sys_priced_cd
FROM prdstgcif.cif_ic_prescription_cns;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_cns;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescription_cns_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

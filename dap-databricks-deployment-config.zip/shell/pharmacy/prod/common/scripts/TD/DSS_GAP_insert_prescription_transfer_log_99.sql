#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_transfer_log_99
(
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,xfer_dttm
,dir_cd
,src_sys_cd
,loc_store_sk
,dim_loc_store_sk
,xfer_to_store_nbr
,xfer_to_rx_src_id
,xfer_to_rx_nbr
,xfer_to_rx_create_dt
,xfer_to_store_sk
,dim_xfer_to_store_sk
,xfer_to_rx_create_tm
,xfer_to_competitor_area_cd
,xfer_to_competitor_phone_nbr
,xfer_to_competitor_store_name
,xfer_to_rph_first_name
,xfer_to_rph_last_name
,xfer_to_rph_initials
,xfer_to_phrm_dea_nbr
,xfer_to_competitor_addr_line
,xfer_to_competitor_city_name
,xfer_to_competitor_state_cd
,xfer_to_competitor_zip_cd_5
,xfer_to_competitor_zip_cd_4
,xfer_fm_store_nbr
,xfer_fm_rx_src_id
,xfer_fm_rx_nbr
,xfer_fm_rx_create_dt
,xfer_fm_rx_create_tm
,xfer_fm_store_sk
,dim_xfer_fm_store_sk
,xfer_fm_competitor_area_cd
,xfer_fm_competitor_phone_nbr
,xfer_fm_competitor_store_name
,xfer_fm_competitor_rph_name
,xfer_fm_rph_initials
,fm_competitor_first_fill_dttm
,fm_competitor_rx_create_dttm
,reason_close_cd
,reason_close_cmnt
,xfer_reason_cd
,xfer_reason_cmnt
,loc_store_relocate_chng_sk
,src_partition_nbr
,src_create_dttm
,src_create_user_sk
,src_create_user_chng_sk
,src_create_user_id
,src_update_dttm
,src_update_user_sk
,src_update_user_chng_sk
,src_update_user_id
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
)
SELECT
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,xfer_dttm
,dir_cd
,src_sys_cd
,loc_store_sk
,dim_loc_store_sk
,xfer_to_store_nbr
,xfer_to_rx_src_id
,xfer_to_rx_nbr
,xfer_to_rx_create_dt
,xfer_to_store_sk
,dim_xfer_to_store_sk
,xfer_to_rx_create_tm
,xfer_to_competitor_area_cd
,xfer_to_competitor_phone_nbr
,xfer_to_competitor_store_name
,xfer_to_rph_first_name
,xfer_to_rph_last_name
,xfer_to_rph_initials
,xfer_to_phrm_dea_nbr
,xfer_to_competitor_addr_line
,xfer_to_competitor_city_name
,xfer_to_competitor_state_cd
,xfer_to_competitor_zip_cd_5
,xfer_to_competitor_zip_cd_4
,xfer_fm_store_nbr
,xfer_fm_rx_src_id
,xfer_fm_rx_nbr
,xfer_fm_rx_create_dt
,xfer_fm_rx_create_tm
,xfer_fm_store_sk
,dim_xfer_fm_store_sk
,xfer_fm_competitor_area_cd
,xfer_fm_competitor_phone_nbr
,xfer_fm_competitor_store_name
,xfer_fm_competitor_rph_name
,xfer_fm_rph_initials
,fm_competitor_first_fill_dttm
,fm_competitor_rx_create_dttm
,reason_close_cd
,reason_close_cmnt
,xfer_reason_cd
,xfer_reason_cmnt
,loc_store_relocate_chng_sk
,src_partition_nbr
,src_create_dttm
,src_create_user_sk
,src_create_user_chng_sk
,src_create_user_id
,src_update_dttm
,src_update_user_sk
,src_update_user_chng_sk
,src_update_user_id
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
FROM prdidldb.prescription_transfer_log;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_transfer_log;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_transfer_log_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

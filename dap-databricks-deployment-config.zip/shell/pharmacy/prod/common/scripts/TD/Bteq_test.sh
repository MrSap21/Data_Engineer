#!/bin/ksh
#echo ".logoff;\n.quit" >>$1
python3<<EOF 1>$0.log 2>&1
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  mainErrorLevel = Action.errorLevel
  Action.errorLevel = 0
  mainErrorCodeOverride = Action.errorCodeOverride
  Action.errorCodeOverride = None
  FormatOptions.width = 1000
  executeSql([], [
    ("""DATABASE prdedwvw""",
    [])
  ])
  executeSql([], [
    ("""select * from prdedwvw.patient limit 10""",
    [])
  ])
  #-- SEL_TOP - Replace TOP clause with LIMIT clause
  executeSql([], [
    ("""create temporary table prdedwvw.temptest
as select * from prdetl.etl_fill_missing_updates""",
    [])
  ])
  #-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
  #-- CTAS - Change CTAS <tbl_name> to CTAS select * from <tbl_name>
  #-- CTAS_WITH_DATA - Remove WITH DATA clause
  #-- TABLE_COMMIT_OPTIONS - Remove ON COMMIT PRESERVE ROWS
  executeSql([], [
    ("""select * from prdedwvw.temptest""",
    [])
  ])
  #--.lrun file=$1

main()
cleanup()
done()
EOF


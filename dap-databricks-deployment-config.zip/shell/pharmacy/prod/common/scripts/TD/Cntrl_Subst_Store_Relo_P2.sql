#/usr/bin/python3
from npjet import *
def main():

  #/****** Store Relo Prescription_Cntrl_Subst *****/
  executeSql([], [
    ("""UPDATE prdedwdb.prescription_control_substance
set str_nbr = R.relocate_to_str_nbr
,edw_batch_id=20090414120000
from prdedwdb.location_store_relocation R
where prdedwdb.prescription_control_substance.str_nbr =
R.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  #/****** Store Relo Dup_Rx_Cntrl_subst *****/
  executeSql([], [
    ("""UPDATE prdrx2stage.etl_proc_dup_rx_cntrl_subst
set store_nbr = R.relocate_to_str_nbr
,edw_batch_id=20090414120000
from prdedwdb.location_store_relocation R
where prdrx2stage.etl_proc_dup_rx_cntrl_subst.store_nbr =
R.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

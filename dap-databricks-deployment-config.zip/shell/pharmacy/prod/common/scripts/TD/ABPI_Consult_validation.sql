#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""insert into prdetl.ABPI_Consult_Keys
select STORE_NBR,RX_NBR,fill_nbr_dispensed, create_dttm from prdrx2abpi.abpi_tbf0_rx_consult_hist_1 
where (pat_id % 4) + 1 = 1 
and store_nbr not in (1,340)
and (store_nbr, rx_nbr) not in (select store_nbr, rx_nbr From prdrx2stage.etl_proc_dup_rx);
-- EXPR_MOD - Change expression MOD to %
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
,
    ("""insert into prdetl.ABPI_Consult_Keys
select STORE_NBR,RX_NBR,fill_nbr_dispensed, create_dttm from prdrx2abpi.abpi_tbf0_rx_consult_hist_2 
where (pat_id % 4) + 1 = 2 
and store_nbr not in (1,340)
and (store_nbr, rx_nbr) not in (select store_nbr, rx_nbr From prdrx2stage.etl_proc_dup_rx);
-- EXPR_MOD - Change expression MOD to %
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
,
    ("""insert into prdetl.ABPI_Consult_Keys
select STORE_NBR,RX_NBR,fill_nbr_dispensed, create_dttm from prdrx2abpi.abpi_tbf0_rx_consult_hist_3 
where (pat_id % 4) + 1 = 3 
and store_nbr not in (1,340)
and (store_nbr, rx_nbr) not in (select store_nbr, rx_nbr From prdrx2stage.etl_proc_dup_rx);
-- EXPR_MOD - Change expression MOD to %
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
,
    ("""insert into prdetl.ABPI_Consult_Keys
select STORE_NBR,RX_NBR,fill_nbr_dispensed, create_dttm from prdrx2abpi.abpi_tbf0_rx_consult_hist_4 
where (pat_id % 4) + 1 = 4 
and store_nbr not in (1,340)
and (store_nbr, rx_nbr) not in (select store_nbr, rx_nbr From prdrx2stage.etl_proc_dup_rx);
-- EXPR_MOD - Change expression MOD to %
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from prdetl.ABPI_Consult_Keys K 
using prdedwdb.prescription_consultation T 
where T.str_nbr=K.store_nbr
and T.rx_nbr=K.rx_nbr
and T.fill_nbr_dspn=K.fill_nbr_dispensed
and cast(T.create_dt||' '||cast(T.create_tm as char(8)) as timestamp(0))=K.create_dttm
and T.edw_batch_id in (20090329150015
  ,20090329150514
  ,20090330000015
  ,20090330000518
);
-- DEL_STATEMENT - Replace DEL with DELETE
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE prdetl.ABPI_Consult_Keys K
set store_nbr=Relo.relocate_to_str_nbr
FROM    prdetl.location_store_relocation_p2 Relo
where store_nbr=Relo.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from prdetl.ABPI_Consult_Keys K 
using prdedwdb.prescription_consultation T 
where T.str_nbr=K.store_nbr
and T.rx_nbr=K.rx_nbr
and T.fill_nbr_dspn=K.fill_nbr_dispensed
and cast(T.create_dt||' '||cast(T.create_tm as char(8)) as timestamp(0))=K.create_dttm
and T.edw_batch_id in (20090329150015
  ,20090329150514
  ,20090330000015
  ,20090330000518
);
-- DEL_STATEMENT - Replace DEL with DELETE
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

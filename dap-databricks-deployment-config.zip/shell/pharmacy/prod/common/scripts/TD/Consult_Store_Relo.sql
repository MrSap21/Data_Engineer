#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""UPDATE prdedwdb.prescription_consultation TGT
ECHO is off.
set str_nbr=relocate_to_str_nbr
FROM    prdetl.location_store_relocation_p2 RELO
where TGT.str_nbr=RELO.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

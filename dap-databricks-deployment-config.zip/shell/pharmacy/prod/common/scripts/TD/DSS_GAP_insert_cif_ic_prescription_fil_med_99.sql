#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescription_fil_med_99
(
cdc_txn_commit_dttm
,change_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,fill_sold_dt
,med_auth_nbr
,mfgr_confirmation_nbr
)
select
cdc_txn_commit_dttm
,change_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,fill_sold_dt
,med_auth_nbr
,mfgr_confirmation_nbr
FROM prdstgcif.cif_ic_prescription_fill_med;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_fill_med;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescription_fil_med_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescrip_consult_ad_99
(
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,src_create_dttm
,fill_sold_dt
,fill_dspn_nbr
,consult_rslvd_cmnts
,consult_rslvd_dttm
,consult_rslvd_rph_initials
,consult_rslvd_rph_src_user_id
,src_create_user_id
)
select
cdc_txn_commit_dttm
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,src_create_dttm
,fill_sold_dt
,fill_dspn_nbr
,consult_rslvd_cmnts
,consult_rslvd_dttm
,consult_rslvd_rph_initials
,consult_rslvd_rph_src_user_id
,src_create_user_id
FROM prdstgcif.cif_ic_prescription_consult_ad;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_consult_ad;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescrip_consult_ad_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""select str_nbr,rx_nbr,fill_nbr_dspn,cast(create_dt||' '||cast(create_tm as char(8)) as timestamp(0))
 from prescription_consultation where edw_batch_id in (20090404150015
 ,20090403192515
 ,20090404150514
 ,20090403193016
)
 minus
ECHO is off.
 select store_nbr,rx_nbr,fill_nbr_dispensed,create_dttm from prdetl.ABPI_Consult_Keys;
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

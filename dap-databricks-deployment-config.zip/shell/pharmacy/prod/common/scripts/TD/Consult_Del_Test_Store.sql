#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""delete from prescription_consultation
where str_nbr in (1,340);
-- DEL_STATEMENT - Replace DEL with DELETE
""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

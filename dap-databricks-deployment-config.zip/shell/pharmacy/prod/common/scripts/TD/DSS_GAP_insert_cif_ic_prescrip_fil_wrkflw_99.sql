#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescrip_fil_wrkflw_99
(
cdc_txn_commit_dttm
,change_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,src_partition_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,fill_sold_dt
,fill_vrfy_user_id
,fill_vrfy_dttm
,fill_data_review_user_id
,fill_data_review_dttm
,fill_review_store_nbr
,fill_enter_user_id
,fill_enter_store_nbr
,filling_user_id
,filling_dttm
,override_user_id
,override_dttm
,data_review_spct_id
,data_review_spct_store_nbr
,data_review_spct_dttm
,fill_rph_of_rec_id
,fill_print_dttm
,fill_rebill_dttm
,src_create_user_id
,src_create_dttm
,src_update_user_id
,src_update_dttm
)
select
cdc_txn_commit_dttm
,change_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,src_partition_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_sys_cd
,fill_sold_dt
,fill_vrfy_user_id
,fill_vrfy_dttm
,fill_data_review_user_id
,fill_data_review_dttm
,fill_review_store_nbr
,fill_enter_user_id
,fill_enter_store_nbr
,filling_user_id
,filling_dttm
,override_user_id
,override_dttm
,data_review_spct_id
,data_review_spct_store_nbr
,data_review_spct_dttm
,fill_rph_of_rec_id
,fill_print_dttm
,fill_rebill_dttm
,src_create_user_id
,src_create_dttm
,src_update_user_id
,src_update_dttm
FROM prdstgcif.cif_ic_prescription_fil_wrkflw;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_fil_wrkflw;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescrip_fil_wrkflw_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

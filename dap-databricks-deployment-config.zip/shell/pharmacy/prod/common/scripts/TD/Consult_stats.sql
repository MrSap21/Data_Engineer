#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""call prdutil.table_stats('prdedwdb','prescription_consultation');""",
    [])
  ])
  return
if __name__ == '__main__':
  main()
  cleanup()
  done()

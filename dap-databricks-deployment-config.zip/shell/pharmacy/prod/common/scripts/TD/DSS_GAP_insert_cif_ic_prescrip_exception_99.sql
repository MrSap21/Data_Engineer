#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescrip_exception_99
(
cdc_txn_commit_dttm
,exception_nbr
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_partition_nbr
,src_sys_cd
,fill_sold_dt
,exception_reason_cd
,exception_credit_card_response
,exception_cmnt
,exception_resolution_cd
,excptn_resolution_user_src_id
,exception_resolution_dttm
,exception_critical_dttm
,exception_reason_update_dttm
,exception_stat_update_dttm
,exception_stat_cd
,exception_subtype_cd
,fill_del_cd
,max_ldr_type_cd
,max_ldr_type_severe_cd
,prescribe_pbr_refill_added_cnt
,prescribe_reply_cd
,msg_cmnt
,prescribe_pbr_auth_id
,cntc_by_cd
,pbr_phone_cmnt
,exception_mgr_select_cd
,emergency_qty
,equivalent_generic_copay_amt
,prescribe_pbr_auth_full_name
,prescribe_pbr_full_name
,epa_reply_msg
,epa_stat_cd
,refill_added_cnt
,workstation_lock_ip_addr
,last_actn_dttm
,fax_image_id
,tpr_sold_cd
,tpr_stat_cd
,tpr_assign_cd
,tpr_stat_update_dttm
,resubmit_dttm
,resubmit_reh_dttm
,src_create_dttm
,src_create_user_id
,src_update_dttm
,src_update_user_id
)
select
cdc_txn_commit_dttm
,exception_nbr
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,src_partition_nbr
,src_sys_cd
,fill_sold_dt
,exception_reason_cd
,exception_credit_card_response
,exception_cmnt
,exception_resolution_cd
,excptn_resolution_user_src_id
,exception_resolution_dttm
,exception_critical_dttm
,exception_reason_update_dttm
,exception_stat_update_dttm
,exception_stat_cd
,exception_subtype_cd
,fill_del_cd
,max_ldr_type_cd
,max_ldr_type_severe_cd
,prescribe_pbr_refill_added_cnt
,prescribe_reply_cd
,msg_cmnt
,prescribe_pbr_auth_id
,cntc_by_cd
,pbr_phone_cmnt
,exception_mgr_select_cd
,emergency_qty
,equivalent_generic_copay_amt
,prescribe_pbr_auth_full_name
,prescribe_pbr_full_name
,epa_reply_msg
,epa_stat_cd
,refill_added_cnt
,workstation_lock_ip_addr
,last_actn_dttm
,fax_image_id
,tpr_sold_cd
,tpr_stat_cd
,tpr_assign_cd
,tpr_stat_update_dttm
,resubmit_dttm
,resubmit_reh_dttm
,src_create_dttm
,src_create_user_id
,src_update_dttm
,src_update_user_id
FROM prdstgcif.cif_ic_prescription_exception;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_exception;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescrip_exception_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

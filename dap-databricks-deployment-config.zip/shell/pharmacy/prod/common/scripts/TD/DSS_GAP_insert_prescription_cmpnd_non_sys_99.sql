#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_cmpnd_non_sys_99
(
store_nbr,
rx_src_id,
rx_nbr,
rx_create_dt,
rx_create_tm,
src_partition_nbr,
src_sys_cd,
drug_cmpnd_type_cd,
drug_cmpnd_non_sys_name,
drug_cmpnd_non_sys_assign_ndc,
drug_cmpnd_non_sys_mfgr_name,
wag_inv_ctrl_nbr,
non_sys_priced_cd,
loc_store_sk,
dim_loc_store_sk,
loc_store_relocate_chng_sk,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
select
store_nbr,
rx_src_id,
rx_nbr,
rx_create_dt,
rx_create_tm,
src_partition_nbr,
src_sys_cd,
drug_cmpnd_type_cd,
drug_cmpnd_non_sys_name,
drug_cmpnd_non_sys_assign_ndc,
drug_cmpnd_non_sys_mfgr_name,
wag_inv_ctrl_nbr,
non_sys_priced_cd,
loc_store_sk,
dim_loc_store_sk,
loc_store_relocate_chng_sk,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
FROM prdidldb.prescription_cmpnd_non_system;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_cmpnd_non_system;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_cmpnd_non_sys_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

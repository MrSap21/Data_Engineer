#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdstgcif.cif_ic_prescription_erx_msg_99
(
cdc_txn_commit_dttm
,icp_erx_msg_src_id
,src_sys_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,dgtl_signature_cd
,drug_coverage_stat_array_cd
,drug_sched_cd
,epbr_erx_msg_id
,erx_app_exception_rslv_cd
,erx_del_ctrl_drug_gpi
,erx_del_ctrl_drug_ndc
,erx_del_ctrl_drug_name
,erx_del_ctrl_pbr_id
,erx_msg_rcvd_dttm
,erx_msg_sent_dttm
,erx_msg_rcvd_type_cd
,erx_msg_sent_type_cd
,erx_msg_vndr_app_name
,erx_msg_vndr_app_vers_name
,erx_msg_vndr_name
,erx_pat_addr
,erx_pat_full_name
,erx_pbr_addr
,erx_pbr_full_name
,erx_msg_xml_image_id
,erx_pbr_clinic_id
,pbr_dgtl_signature_dgst_val
,pbr_dgtl_signature_publ_key
,pbr_dgtl_signature_val
,wag_dgtl_signature_publ_key
,wag_dgtl_signature_val
,src_create_user_id
,src_update_dttm
,src_update_user_id
)
SELECT
cdc_txn_commit_dttm
,icp_erx_msg_src_id
,src_sys_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,dgtl_signature_cd
,drug_coverage_stat_array_cd
,drug_sched_cd
,epbr_erx_msg_id
,erx_app_exception_rslv_cd
,erx_del_ctrl_drug_gpi
,erx_del_ctrl_drug_ndc
,erx_del_ctrl_drug_name
,erx_del_ctrl_pbr_id
,erx_msg_rcvd_dttm
,erx_msg_sent_dttm
,erx_msg_rcvd_type_cd
,erx_msg_sent_type_cd
,erx_msg_vndr_app_name
,erx_msg_vndr_app_vers_name
,erx_msg_vndr_name
,erx_pat_addr
,erx_pat_full_name
,erx_pbr_addr
,erx_pbr_full_name
,erx_msg_xml_image_id
,erx_pbr_clinic_id
,pbr_dgtl_signature_dgst_val
,pbr_dgtl_signature_publ_key
,pbr_dgtl_signature_val
,wag_dgtl_signature_publ_key
,wag_dgtl_signature_val
,src_create_user_id
,src_update_dttm
,src_update_user_id
FROM  prdstgcif.cif_ic_prescription_erx_msg;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdstgcif.cif_ic_prescription_erx_msg;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdstgcif.cif_ic_prescription_erx_msg_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

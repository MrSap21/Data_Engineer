#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""UPDATE Prescription_Consultation Consult
set fill_sold_dt=Fill.fill_sold_dt
,rx_create_dt=Fill.rx_create_dt
FROM    (
select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,rx_create_dt,fill_sold_dt
from Prescription_FIll 
where (rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,cast(fill_enter_dt||cast(fill_enter_tm as char(8)) as timestamp(0))) in
(select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,max(cast(fill_enter_dt||cast(fill_enter_tm as char(8)) as timestamp(0)))
from Prescription_FIll  where fill_sold_dt<='2007-05-31' group by 1,2,3,4))
 Fill
where fill.rx_nbr=Consult.rx_nbr
and fill.str_nbr=Consult.str_nbr
and fill.rx_fill_nbr=Consult.rx_fill_nbr
and fill.rx_partial_fill_nbr=Consult.rx_partial_fill_nbr
and fill.fill_sold_dt is not null
and fill.fill_sold_dt<='2007-05-31';
-- SEL_STATEMENT - Replace SEL with SELECT
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  executeSql([], [
    ("""UPDATE Prescription_Consultation Consult
set fill_sold_dt=Fill.fill_sold_dt
,rx_create_dt=Fill.rx_create_dt
FROM    (
select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,rx_create_dt,fill_sold_dt
from Prescription_FIll 
where (rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,cast(fill_enter_dt||cast(fill_enter_tm as char(8)) as timestamp(0))) in
(select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,max(cast(fill_enter_dt||cast(fill_enter_tm as char(8)) as timestamp(0)))
from Prescription_FIll  where fill_sold_dt between '2007-06-01' and '2008-05-31' group by 1,2,3,4))
 Fill
where fill.rx_nbr=Consult.rx_nbr
and fill.str_nbr=Consult.str_nbr
and fill.rx_fill_nbr=Consult.rx_fill_nbr
and fill.rx_partial_fill_nbr=Consult.rx_partial_fill_nbr
and fill.fill_sold_dt is not null
and fill.fill_sold_dt between '2007-06-01' and '2008-05-31';
-- SEL_STATEMENT - Replace SEL with SELECT
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  executeSql([], [
    ("""UPDATE Prescription_Consultation Consult
set fill_sold_dt=Fill.fill_sold_dt
,rx_create_dt=Fill.rx_create_dt
FROM    (
select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,rx_create_dt,fill_sold_dt
from Prescription_FIll 
where (rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,cast(fill_enter_dt||cast(fill_enter_tm as char(8)) as timestamp(0))) in
(select rx_nbr,str_nbr,rx_fill_nbr,rx_partial_fill_nbr,max(cast(fill_enter_dt||cast(fill_enter_tm as char(8)) as timestamp(0)))
from Prescription_FIll  where fill_sold_dt >= '2008-06-01' group by 1,2,3,4))
 Fill
where fill.rx_nbr=Consult.rx_nbr
and fill.str_nbr=Consult.str_nbr
and fill.rx_fill_nbr=Consult.rx_fill_nbr
and fill.rx_partial_fill_nbr=Consult.rx_partial_fill_nbr
and fill.fill_sold_dt is not null
and fill.fill_sold_dt >= '2008-06-01';
-- SEL_STATEMENT - Replace SEL with SELECT
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_erx_msg_map_99
(
icp_erx_msg_src_id
,src_sys_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,loc_store_sk
,dim_loc_store_sk
,dgtl_signature_cd
,drug_coverage_stat_array_cd
,drug_sched_cd
,epbr_erx_msg_id
,erx_app_exception_rslv_cd
,erx_del_ctrl_drug_gpi
,erx_del_ctrl_drug_ndc
,erx_del_ctrl_drug_name
,erx_del_ctrl_pbr_id
,erx_msg_rcvd_dttm
,erx_msg_sent_dttm
,erx_msg_rcvd_type_cd
,erx_msg_sent_type_cd
,erx_msg_vndr_app_name
,erx_msg_vndr_app_vers_name
,erx_msg_vndr_name
,erx_pat_addr
,erx_pat_full_name
,erx_pbr_addr
,erx_pbr_full_name
,erx_msg_xml_image_id
,erx_pbr_clinic_id
,pbr_dgtl_signature_dgst_val
,pbr_dgtl_signature_publ_key
,pbr_dgtl_signature_val
,wag_dgtl_signature_publ_key
,wag_dgtl_signature_val
,loc_store_relocate_chng_sk
,src_create_user_sk
,src_create_user_chng_sk
,src_create_user_id
,src_update_dttm
,src_update_user_sk
,src_update_user_chng_sk
,src_update_user_id
,fac_1_id
,fac_2_id
,fac_3_id
,fac_1_id_qlfr
,fac_2_id_qlfr
,fac_3_id_qlfr
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
)
SELECT
icp_erx_msg_src_id
,src_sys_cd
,store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,loc_store_sk
,dim_loc_store_sk
,dgtl_signature_cd
,drug_coverage_stat_array_cd
,drug_sched_cd
,epbr_erx_msg_id
,erx_app_exception_rslv_cd
,erx_del_ctrl_drug_gpi
,erx_del_ctrl_drug_ndc
,erx_del_ctrl_drug_name
,erx_del_ctrl_pbr_id
,erx_msg_rcvd_dttm
,erx_msg_sent_dttm
,erx_msg_rcvd_type_cd
,erx_msg_sent_type_cd
,erx_msg_vndr_app_name
,erx_msg_vndr_app_vers_name
,erx_msg_vndr_name
,erx_pat_addr
,erx_pat_full_name
,erx_pbr_addr
,erx_pbr_full_name
,erx_msg_xml_image_id
,erx_pbr_clinic_id
,pbr_dgtl_signature_dgst_val
,pbr_dgtl_signature_publ_key
,pbr_dgtl_signature_val
,wag_dgtl_signature_publ_key
,wag_dgtl_signature_val
,loc_store_relocate_chng_sk
,src_create_user_sk
,src_create_user_chng_sk
,src_create_user_id
,src_update_dttm
,src_update_user_sk
,src_update_user_chng_sk
,src_update_user_id
,fac_1_id
,fac_2_id
,fac_3_id
,fac_1_id_qlfr
,fac_2_id_qlfr
,fac_3_id_qlfr
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
FROM prdidldb.prescription_erx_message_map;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_erx_message_map;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_erx_msg_map_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.drug_claim_sdl_reject_log_99
(
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,sdl_msg_id
,reject_nbr
,src_sys_cd
,fill_sold_dt
,dl_reject_cd
,dl_reject_reason
,loc_store_sk
,dim_loc_store_sk
,loc_store_relocate_chng_sk
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
)
SELECT
store_nbr
,rx_src_id
,rx_nbr
,rx_create_dt
,rx_create_tm
,src_partition_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
,sdl_msg_id
,reject_nbr
,src_sys_cd
,fill_sold_dt
,dl_reject_cd
,dl_reject_reason
,loc_store_sk
,dim_loc_store_sk
,loc_store_relocate_chng_sk
,edw_create_dttm
,edw_update_dttm
,edw_batch_id
FROM prdidldb.drug_claim_sdl_reject_log;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.drug_claim_sdl_reject_log;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.drug_claim_sdl_reject_log_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

#/usr/bin/python3
from npjet import *
def main():

  executeSql([], [
    ("""INSERT INTO prdidldb.prescription_consult_adhoc_99
(
store_nbr,
rx_src_id,
rx_nbr,
rx_create_dt,
rx_create_tm,
src_partition_nbr,
rx_fill_nbr,
rx_partial_fill_nbr,
fill_enter_dt,
fill_enter_tm,
src_sys_cd,
src_create_dttm,
fill_sold_dt,
fill_dspn_nbr,
loc_store_sk,
dim_loc_store_sk,
loc_store_relocate_chng_sk,
consult_rslvd_cmnts,
consult_rslvd_dttm,
consult_rslvd_rph_initials,
consult_rslvd_rph_user_sk,
consult_rslvd_rph_user_chng_sk,
consult_rslvd_rph_src_user_id,
src_create_user_sk,
src_create_user_chng_sk,
src_create_user_id,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
)
SELECT
store_nbr,
rx_src_id,
rx_nbr,
rx_create_dt,
rx_create_tm,
src_partition_nbr,
rx_fill_nbr,
rx_partial_fill_nbr,
fill_enter_dt,
fill_enter_tm,
src_sys_cd,
src_create_dttm,
fill_sold_dt,
fill_dspn_nbr,
loc_store_sk,
dim_loc_store_sk,
loc_store_relocate_chng_sk,
consult_rslvd_cmnts,
consult_rslvd_dttm,
consult_rslvd_rph_initials,
consult_rslvd_rph_user_sk,
consult_rslvd_rph_user_chng_sk,
consult_rslvd_rph_src_user_id,
src_create_user_sk,
src_create_user_chng_sk,
src_create_user_id,
edw_create_dttm,
edw_update_dttm,
edw_batch_id
FROM prdidldb.prescription_consult_adhoc;""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_old_cnt FROM prdidldb.prescription_consult_adhoc;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""SELECT count(*)::decimal (18,0)   target_new_cnt FROM prdidldb.prescription_consult_adhoc_99;
-- FUN_CAST_OPTR - Reformat casting
""",
    [])
  ])
  if (Action.errorCode 
    Action.errorCodeOverride = 8
    return
if __name__ == '__main__':
  main()
  cleanup()
  done()

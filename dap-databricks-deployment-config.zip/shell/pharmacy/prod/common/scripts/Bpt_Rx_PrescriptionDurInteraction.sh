!/bin/sh
pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
pTDEDWTargetTable=$7

python3 <<ZZ
#!/usr/bin/python3


#import os
#import sys

#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():

  executeSql([], [
    ("""delete from $pTDStageDB.ETL_PROC_DUR_INTER_FILL; 
-- DEL_ALL - Remove ALL keyword from DELETE statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""insert into $pTDStageDB.ETL_PROC_DUR_INTER_FILL
(
rx_nbr
,str_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
)
select 
TRX.rx_nbr
,TRX.str_nbr
,TRX.rx_fill_nbr
,TRX.rx_partial_fill_nbr
,cast(TRX.fill_enter_dttm as date)  fill_enter_dt
,SUBSTRING(CAST(TRX.fill_enter_dttm AS CHAR(19)),12,8)   fill_enter_tm
From
(
select 
fill.rx_nbr
,fill.str_nbr
,fill.rx_fill_nbr
,fill.rx_partial_fill_nbr
,max(cast(fill.fill_enter_dt||' '|| cast(fill.fill_enter_tm as varchar(8)) as timestamp(0))) fill_enter_dttm
 from $pTDViewDBName.prescription_fill fill,
(select
rx_nbr                        
,store_nbr
,fill_nbr                      
,fill_partial_nbr        
from $pTDStageDB.etl_tbf0_dur_history
group by 1,2,3,4 ) tmp
where fill.rx_nbr = tmp.rx_nbr
and fill.str_nbr = tmp.store_nbr
and fill.rx_fill_nbr = tmp.fill_nbr
and fill.rx_partial_fill_nbr = tmp.fill_partial_nbr
and fill.fill_enter_dt is not null
and fill.fill_enter_tm is not null
Group by 1,2,3,4
) TRX;
-- FUN_SUBSTR - Reformat function SUBSTRING
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""insert into $pTDStageDB.ETL_PROC_DUR_INTER_FILL
(
rx_nbr
,str_nbr
,rx_fill_nbr
,rx_partial_fill_nbr
,fill_enter_dt
,fill_enter_tm
)
select 
rx_nbr
,store_nbr
,fill_nbr
,fill_partial_nbr
,cast(fill_enter_dttm as date)
,cast(fill_enter_dttm as time(0))
from  $pTDStageDB.ETL_TBF0_FILL
group by 1,2,3,4,5,6;
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDDBName.Prescription_Dur_Interaction TGT

set fill_enter_dt=STG.fill_enter_dt
,fill_enter_tm=STG.fill_enter_tm
FROM    $pTDStageDB.ETL_PROC_DUR_INTER_FILL STG
where TGT.rx_nbr=STG.rx_nbr
and TGT.str_nbr=STG.str_nbr
and TGT.rx_fill_nbr=STG.rx_fill_nbr
and TGT.rx_partial_fill_nbr=STG.rx_partial_fill_nbr
and TGT.fill_enter_dt is null;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.ETL_PROC_RX_DUR_INTER; 
-- DEL_ALL - Remove ALL keyword from DELETE statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.ETL_PROC_RX_DUR_INTER
(
rx_nbr
,str_nbr
,rx_create_dt
,rx_fill_nbr
,rx_partial_fill_nbr
,dur_interact_nbr
,fill_sold_dt
,dur_type_cd 
,dur_outcome_cd 
,dur_override_ind
,dur_override_dt
,dur_override_tm
,dur_cmnt
,dur_cmnt_cd
,dur_intervention_cd 
,dur_severe_cd 
,relocate_fm_str_nbr
,edw_batch_id
,update_dttm
,src_partition_nbr
,fill_enter_dt
,fill_enter_tm
,dur_override_user_id
,dur_src_cd
)
SELECT	
TDUR.rx_nbr
,TDUR.str_nbr
,TDUR.rx_create_dt
,TDUR.rx_fill_nbr
,TDUR.rx_partial_fill_nbr
,TDUR.dur_interact_nbr
,TDUR.fill_sold_dt
,TDUR.dur_type_cd 
,TDUR.dur_outcome_cd 
,TDUR.dur_override_ind
,TDUR.dur_override_dt
,TDUR.dur_override_tm
,TDUR.dur_cmnt
,TDUR.dur_cmnt_cd
,TDUR.dur_intervention_cd 
,TDUR.dur_severe_cd 
,TDUR.relocate_fm_str_nbr
,TDUR.edw_batch_id
,TDUR.update_dttm
,TDUR.src_partition_nbr
,TDUR.fill_enter_dt
,TDUR.fill_enter_tm
,TDUR.dur_override_user_id
,TDUR.dur_src_cd
FROM	$pTDDBName."$pTDEDWTargetTable" TDUR,
       (SELECT Z.rx_nbr,Z.str_nbr,Z.rx_fill_nbr, Z.rx_partial_fill_nbr, Z.dur_interact_nbr
      FROM  $pTDDBName."$pTDEDWTargetTable" Z,
                  (SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, DUR_INTERACTION_NBR
                     FROM $pTDStageDB.ETL_TBF0_DUR_HISTORY 
                     WHERE CDC_OPERATION_TYPE_CD IN ('PK UPDATE','SQL COMPUPDATE')
                     GROUP BY RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, DUR_INTERACTION_NBR
                           MINUS
     					SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, DUR_INTERACTION_NBR
     					FROM $pTDStageDB.ETL_TBF0_DUR_HISTORY 
     					WHERE CDC_OPERATION_TYPE_CD='INSERT') Y
     WHERE Z.RX_NBR = Y.RX_NBR
         AND Z.str_nbr = Y.STORE_NBR
         AND Z.rx_fill_nbr = Y.FILL_NBR
         AND Z.rx_partial_fill_nbr = Y.FILL_PARTIAL_NBR
	 AND Z.dur_interact_nbr= Y.DUR_INTERACTION_NBR
         group by 1,2,3,4,5 ) as TMP
WHERE TDUR.RX_NBR = TMP.rx_nbr
AND     TDUR.STR_NBR = TMP.str_nbr
AND     TDUR.RX_FILL_NBR = TMP.rx_fill_nbr
AND     TDUR.RX_PARTIAL_FILL_NBR = TMP.rx_partial_fill_nbr
AND 	  TDUR.dur_interact_nbr=TMP.dur_interact_nbr;
-- OBJ_NAME - double quote object name which include special characters or keyword.
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.ETL_ENDDATED_RX_DUR_INTER; 
-- DEL_ALL - Remove ALL keyword from DELETE statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""insert into $pTDStageDB.ETL_ENDDATED_RX_DUR_INTER
select * from $pTDStageDB.V_rx_dur_interaction_endated;
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.ETL_OUTER_RX_DUR_INTER; 
-- DEL_ALL - Remove ALL keyword from DELETE statement
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT	INTO $pTDStageDB.ETL_OUTER_RX_DUR_INTER
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,dur_interaction_nbr           
,dur_type_cd                   
,dur_severity_cd               
,dur_overridden_ind            
,dur_comment                   
,dur_override_dttm             
,dur_comment_cd                
,dur_intervention_cd           
,dur_outcome_cd                
,src_partition_nbr             
,DUR_SOURCE_CD                 
,DUR_OVERRIDE_USER_ID          
,relocate_fm_str_nbr           
)
SELECT
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,dur_interaction_nbr           
,dur_type_cd                   
,dur_severity_cd               
,dur_overridden_ind            
,dur_comment                   
,dur_override_dttm             
,dur_comment_cd                
,dur_intervention_cd           
,dur_outcome_cd                
,src_partition_nbr             
,DUR_SOURCE_CD                 
,DUR_OVERRIDE_USER_ID          
,relocate_fm_str_nbr           
FROM	$pTDStageDB.etl_tbf0_dur_history
WHERE	(STORE_NBR,RX_NBR,FILL_NBR,FILL_PARTIAL_NBR,DUR_INTERACTION_NBR,CDC_TXN_COMMIT_DTTM,CDC_SEQ_NBR,CDC_RBA_NBR)
IN 
(
SELECT	BFR.STORE_NBR,BFR.RX_NBR,BFR.FILL_NBR,BFR.FILL_PARTIAL_NBR,BFR.DUR_INTERACTION_NBR,BFR.CDC_TXN_COMMIT_DTTM,BFR.CDC_SEQ_NBR,BFR.CDC_RBA_NBR           
FROM	$pTDStageDB.etl_tbf0_dur_history BFR
INNER	JOIN  $pTDStageDB.etl_tbf0_dur_history AFT
ON	AFT.CDC_TXN_COMMIT_DTTM		= BFR.CDC_TXN_COMMIT_DTTM           
AND	AFT.CDC_SEQ_NBR			= BFR.CDC_SEQ_NBR                  
AND	AFT.CDC_RBA_NBR			= BFR.CDC_RBA_NBR    
AND	AFT.CDC_OPERATION_TYPE_CD	IN ('SQL COMPUPDATE','PK UPDATE') 
AND	AFT.CDC_BEFORE_AFTER_CD		= 'AFTER'
AND	BFR.CDC_OPERATION_TYPE_CD	= 'SQL COMPUPDATE'    
AND	BFR.CDC_BEFORE_AFTER_CD		= 'BEFORE'
AND
(       
   (BFR.dur_type_cd			IS NOT NULL AND AFT.dur_type_cd			IS NULL )
OR (BFR.dur_severity_cd			IS NOT NULL AND AFT.dur_severity_cd		IS NULL )
OR (BFR.dur_overridden_ind		IS NOT NULL AND AFT.dur_overridden_ind		IS NULL )
OR (BFR.dur_comment			IS NOT NULL AND AFT.dur_comment			IS NULL )
OR (BFR.dur_override_dttm		IS NOT NULL AND AFT.dur_override_dttm		IS NULL )
OR (BFR.dur_comment_cd			IS NOT NULL AND AFT.dur_comment_cd		IS NULL )
OR (BFR.dur_intervention_cd		IS NOT NULL AND AFT.dur_intervention_cd		IS NULL )
OR (BFR.dur_outcome_cd			IS NOT NULL AND AFT.dur_outcome_cd		IS NULL )
OR (BFR.DUR_SOURCE_CD			IS NOT NULL AND AFT.DUR_SOURCE_CD		IS NULL )
OR (BFR.DUR_OVERRIDE_USER_ID		IS NOT NULL AND AFT.DUR_OVERRIDE_USER_ID	IS NULL )
));""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  return

if __name__ == '__main__':
  main()
  cleanup()
  done()

ZZ
#!/bin/sh
pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDViewDBName=$5
APT_TERA_SYNC_DATABASE=$6

python3 <<ZZ
#!/usr/bin/python3

#import os
#import sys

#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():

  executeSql([], [
    ("""CREATE TABLE $APT_TERA_SYNC_DATABASE.V_rx_dur_post 
     (
      str_nbr INTEGER NOT NULL,
      rx_nbr INTEGER NOT NULL,
      rx_fill_nbr INTEGER NOT NULL ,
      rx_partial_fill_nbr INTEGER NOT NULL,
      fill_enter_dttm TIMESTAMP
      );
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- TABLE_INDEX - Remove table index options
""",
    [])
  ])
  executeSql([], [
    ("""insert into $APT_TERA_SYNC_DATABASE.V_rx_dur_post
(
      str_nbr,
      rx_nbr,
      rx_fill_nbr,
      rx_partial_fill_nbr,
      fill_enter_dttm
)
select
      F.str_nbr,
      F.rx_nbr,
      F.rx_fill_nbr,
      F.rx_partial_fill_nbr,
      max(case when F.fill_enter_dt is null then cast('1899-12-31 12:12:12' as timestamp(0)) else cast(F.fill_enter_dt||' ' || cast(F.fill_enter_tm as varchar(8))as timestamp(0)) end )as fill_enter_dttm
from $pTDViewDBName.prescription_fill F, $pTDViewDBName.prescription_dur_interaction T
where
 F.str_nbr=T.str_nbr
and F.rx_nbr=T.rx_nbr
and F.rx_fill_nbr=T.rx_fill_nbr
and F.rx_partial_fill_nbr=T.rx_partial_fill_nbr
and T.rx_create_dt is null
group by 1,2,3,4;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_dur_interaction T
set rx_create_dt = F.rx_create_dt
       ,fill_sold_dt=F.fill_sold_dt
FROM    $APT_TERA_SYNC_DATABASE.V_rx_dur_post TRX,
   $pTDViewDBName.prescription_fill F
where
T.rx_nbr = TRX.rx_nbr
and T.str_nbr = TRX.str_nbr
and T.rx_fill_nbr = TRX.rx_fill_nbr
and T.rx_partial_fill_nbr = TRX.rx_partial_fill_nbr
and TRX.rx_nbr=F.rx_nbr
and TRX.str_nbr=F.str_nbr
and TRX.rx_fill_nbr=F.rx_fill_nbr
and TRX.rx_partial_fill_nbr=F.rx_partial_fill_nbr
and TRX.fill_enter_dttm=case when F.fill_enter_dt is null then cast('1899-12-31 12:12:12' as timestamp(0)) else cast(F.fill_enter_dt||' ' ||cast(F.fill_enter_tm as varchar(8)) as timestamp(0))  end
and T.rx_create_dt IS NULL;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""drop table if exists $APT_TERA_SYNC_DATABASE.V_rx_dur_post;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_dur_interaction DUR
    
set    rx_create_dt = STG.to_create_dt
 FROM    (Select str_nbr ,rx_nbr ,cast(frm_create_dttm as date) frm_create_dt,
     cast(to_create_dttm as date) to_create_dt, change_prcs_ind
                FROM    prdrx2stage.rx_create_dttm_change
WHERE frm_create_dt <> to_create_dt
        
        GROUP BY 1,2,3,4,5
        
        )  STG
 where  DUR.str_nbr = STG.str_nbr
  AND DUR.rx_nbr = STG.rx_nbr
  AND DUR.rx_create_dt =  STG.frm_create_dt
  AND DUR.rx_create_dt IS NOT NULL
  AND STG.change_prcs_ind = 'N';
-- SEL_BODY_CLAUSES_ORDER - change the order of all the clauses of a select statement
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  return

if __name__ == '__main__':
  main()
  cleanup()
  done()

ZZ
#!/bin/sh

DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDDBName1=$8
pTDStageDB=$5
pTDViewDBName=$6
APT_TERA_SYNC_DATABASE=$7

python3 <<ZZ 
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  #--BC /*================================================================**
  #--BC ** PERFORM STORE RELO UPDATES FOR TARGET TABLES                   **
  #--BC **================================================================*/
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_fill_plan
 
set    str_nbr = R.relocate_to_str_nbr
 from   $pTDDBName1.location_store_relocation  R
 where  $pTDDBName.prescription_fill_plan.str_nbr =
          R.relocate_fm_str_nbr
  and   R.relocate_prcs_ind = 'N'""",
    [])
  ])
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--BC /*================================================================**
  #--BC ** PERFORM UPDATES FOR CHANGES TO RX CREATE DT IN TARGET TABLES   **
  #--BC **================================================================*/
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_fill_plan FillPlan
    
set    rx_create_dt = STG.to_create_dt 
 FROM    (Select str_nbr ,rx_nbr ,cast(frm_create_dttm as date) frm_create_dt, cast(to_create_dttm as date) to_create_dt, change_prcs_ind
		FROM    $pTDStageDB.rx_create_dttm_change_stg
WHERE frm_create_dt <> to_create_dt
	
	GROUP BY 1,2,3,4,5
	
	)  STG
 where  FillPlan.str_nbr = STG.str_nbr
  AND FillPlan.rx_nbr = STG.rx_nbr
  AND FillPlan.rx_create_dt =  STG.frm_create_dt
  AND FillPlan.rx_create_dt IS NOT NULL
  AND STG.change_prcs_ind = 'N'  
/*============================================================================================**
** ADDED THE BELOW STEP AS PART OF PHARMACY BATCH OPTIMIZATION ON 10/17/2017 BY SUPPORT TEAM. **
** THIS LOGIC WILL ALSO CAPTURE THE FILL SOLD Rx DATA FOR WHICH THE FILL Rx CREATE DATE IS    **
** GREATER THAN THE FILL Rx SOLD DATE                                                         **
**============================================================================================*/
  AND (FillPlan.fill_sold_dt >= (select MIN(CAST(FRM_CREATE_DTTM AS DATE))-180 FROM $pTDStageDB.rx_create_dttm_change_stg) OR FillPlan.fill_sold_dt IS NULL)""",
    [])
  ])
  #-- SEL_BODY_CLAUSES_ORDER - change the order of all the clauses of a select statement
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  return

main()
cleanup()
done()
ZZ

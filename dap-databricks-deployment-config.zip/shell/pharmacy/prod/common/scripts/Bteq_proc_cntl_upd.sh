#!/bin/ksh

#echo ".logoff;\n.quit" >>$1
#.export report file=${1}.dat
LOG=/usr/local/edw/pharmacy/prod/audit/proc_cntl_update_`date +%Y%m%d`
python3<<EOF 1>${LOG}.log 2>&1
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  mainErrorLevel = Action.errorLevel
  Action.errorLevel = 0
  mainErrorCodeOverride = Action.errorCodeOverride
  Action.errorCodeOverride = None
  FormatOptions.width = 1000
  import $1
  mainErrorLevel = Action.errorLevel
  Action.errorLevel = 0
  mainErrorCodeOverride = Action.errorCodeOverride
  Action.errorCodeOverride = None
  $1.main()
  if(Action.errorLevel != 0 or Action.errorCodeOverride != None):
    return
  else:
    Action.errorLevel = mainErrorLevel
    Action.errorCodeOverride = mainErrorCodeOverride
  return

main()
cleanup()
done()
EOF

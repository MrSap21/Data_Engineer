#!/bin/sh

DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
pTDEDWTargetTable=$7

python3 <<ZZ
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.ETL_PROC_FILL_FILL_PLAN""",
    [])
  ])
  #-- DEL_ALL - Remove ALL keyword from DELETE statement
  if (Action.errorCode != 0):
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.ETL_PROC_FILL_FILL_PLAN
(
RX_NBR
	,STR_NBR
	,RX_CREATE_DT
	,RX_FILL_NBR
	,RX_PARTIAL_FILL_NBR
	,THIRD_PARTY_PLAN_ID
	,FILL_SOLD_DT
	,COB_IND
	,FILL_ADJUD_DT
	,FILL_ADJUD_TM
	,FILL_ADJUD_CD
	,CLAIM_REF_NBR
	,PLAN_TOT_PAID_DLRS
	,PLAN_RETURN_COST_DLRS
	,PLAN_RETURN_FEE_DLRS
	,PLAN_RETURN_COPAY_DLRS
	,PLAN_RETURN_TAX_DLRS
	,PLAN_SUBMIT_COPAY_DLRS
	,PLAN_SUBMIT_COST_DLRS
	,PLAN_SUBMIT_FEE_DLRS
	,PLAN_SUBMIT_TAX_DLRS
	,RELOCATE_FM_STR_NBR
	,EDW_BATCH_ID
	,PLAN_AR_DLRS
	,CREATE_USER_ID
	,UPDATE_DTTM
	,UPDATE_USER_ID
	,SRC_PARTITION_NBR
	,PLAN_GROSS_DUE_DLRS
	,BASIS_OF_REIMB_DETRM
        ,BIN_NBR
        ,PLAN_GROUP_NBR
        ,FILL_ENTER_DT
        ,FILL_ENTER_TM
	,del_adjud_cd                  
	,general_phrm_nbr              
	,general_recipient_nbr         
	,general_rph_nbr               
	,maj_med_prior_auth_nbr        
	,plan_incent_submtd_dlrs       
	,plan_incentive_paid_dlrs      
	,plan_other_paid_dlrs          
	,plan_other_submtd_dlrs        
	,attributed_to_tax_dlrs        
	,reimburs_loss_dlrs            
	,plan_copay_dlrs               
	,plan_other_dlrs               
	,plan_tax_dlrs                 
)
SELECT	TFILLP.RX_NBR
	,TFILLP.STR_NBR
	,TFILLP.RX_CREATE_DT
	,TFILLP.RX_FILL_NBR
	,TFILLP.RX_PARTIAL_FILL_NBR
	,TFILLP.THIRD_PARTY_PLAN_ID
	,TFILLP.FILL_SOLD_DT
	,TFILLP.COB_IND
	,TFILLP.FILL_ADJUD_DT
	,TFILLP.FILL_ADJUD_TM
	,TFILLP.FILL_ADJUD_CD
	,TFILLP.CLAIM_REF_NBR
	,TFILLP.PLAN_TOT_PAID_DLRS
	,TFILLP.PLAN_RETURN_COST_DLRS
	,TFILLP.PLAN_RETURN_FEE_DLRS
	,TFILLP.PLAN_RETURN_COPAY_DLRS
	,TFILLP.PLAN_RETURN_TAX_DLRS
	,TFILLP.PLAN_SUBMIT_COPAY_DLRS
	,TFILLP.PLAN_SUBMIT_COST_DLRS
	,TFILLP.PLAN_SUBMIT_FEE_DLRS
	,TFILLP.PLAN_SUBMIT_TAX_DLRS
	,TFILLP.RELOCATE_FM_STR_NBR
	,TFILLP.EDW_BATCH_ID
	,TFILLP.PLAN_AR_DLRS
	,TFILLP.CREATE_USER_ID
	,TFILLP.UPDATE_DTTM
	,TFILLP.UPDATE_USER_ID
	,TFILLP.SRC_PARTITION_NBR
	,TFILLP.PLAN_GROSS_DUE_DLRS
	,TFILLP.BASIS_OF_REIMB_DETRM
        ,TFILLP.BIN_NBR
        ,TFILLP.PLAN_GROUP_NBR
        ,TFILLP.FILL_ENTER_DT
        ,TFILLP.FILL_ENTER_TM
	,TFILLP.del_adjud_cd                  
	,TFILLP.general_phrm_nbr              
	,TFILLP.general_recipient_nbr         
	,TFILLP.general_rph_nbr               
	,TFILLP.maj_med_prior_auth_nbr        
	,TFILLP.plan_incent_submtd_dlrs       
	,TFILLP.plan_incentive_paid_dlrs      
	,TFILLP.plan_other_paid_dlrs          
	,TFILLP.plan_other_submtd_dlrs        
	,TFILLP.attributed_to_tax_dlrs        
	,TFILLP.reimburs_loss_dlrs            
	,TFILLP.plan_copay_dlrs               
	,TFILLP.plan_other_dlrs               
	,TFILLP.plan_tax_dlrs             
FROM	$pTDViewDBName.$pTDEDWTargetTable TFILLP,
                  (SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTER_DTTM
                     FROM $pTDStageDB.ETL_TBF0_FILL 
                     WHERE CDC_OPERATION_TYPE_CD IN ('PK UPDATE','SQL COMPUPDATE')
                     GROUP BY RX_NBR, STORE_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM
                      MINUS
     					SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTER_DTTM
     					FROM $pTDStageDB.ETL_TBF0_FILL
     					WHERE CDC_OPERATION_TYPE_CD='INSERT'
                     ) B
WHERE TFILLP.RX_NBR = B.RX_NBR
AND     TFILLP.STR_NBR = B.STORE_NBR
AND     TFILLP.RX_FILL_NBR = B.FILL_NBR
AND     TFILLP.RX_PARTIAL_FILL_NBR = B.FILL_PARTIAL_NBR
AND     TFILLP.FILL_ENTER_DT = CAST( B.FILL_ENTER_DTTM AS DATE)
AND     TFILLP.FILL_ENTER_TM = CAST( B.FILL_ENTER_DTTM AS TIME(0))""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("""call PRDUTIL.TABLE_STATS('$pTDStageDB', 'ETL_PROC_FILL_FILL_PLAN')""",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.ETL_ENDATED_FILLPLAN_RX_FILL""",
    [])
  ])
  #-- DEL_ALL - Remove ALL keyword from DELETE statement
  if (Action.errorCode != 0):
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.ETL_ENDATED_FILLPLAN_RX_FILL
(rx_nbr                        
,str_nbr                       
,rx_create_dt                  
,rx_fill_nbr                   
,rx_partial_fill_nbr           
,third_party_plan_id           
,fill_sold_dt                  
,cob_ind                       
,fill_adjud_dt                 
,fill_adjud_tm                 
,fill_adjud_cd                 
,claim_ref_nbr                 
,plan_tot_paid_dlrs            
,plan_return_cost_dlrs         
,plan_return_fee_dlrs          
,plan_return_copay_dlrs        
,plan_return_tax_dlrs          
,plan_submit_copay_dlrs        
,plan_submit_cost_dlrs         
,plan_submit_fee_dlrs          
,plan_submit_tax_dlrs          
,relocate_fm_str_nbr           
,edw_batch_id                  
,plan_ar_dlrs                  
,create_user_id                
,update_dttm                   
,update_user_id                
,src_partition_nbr             
,plan_gross_due_dlrs           
,basis_of_reimb_detrm          
,bin_nbr                       
,plan_group_nbr                
,fill_enter_dt                 
,fill_enter_tm                 
,del_adjud_cd                  
,general_phrm_nbr              
,general_recipient_nbr         
,general_rph_nbr               
,maj_med_prior_auth_nbr        
,plan_incent_submtd_dlrs       
,plan_incentive_paid_dlrs      
,plan_other_paid_dlrs          
,plan_other_submtd_dlrs        
,attributed_to_tax_dlrs        
,reimburs_loss_dlrs            
,plan_copay_dlrs               
,plan_other_dlrs               
,plan_tax_dlrs                 
,src_eff_dt                    
,src_eff_tm                    
,src_end_dt                    
,src_end_tm                    
,cdc_rba_nbr                   
,edw_dml_ind                   
,edw_rank                      
)
SELECT 
rx_nbr                        
,str_nbr                       
,rx_create_dt                  
,rx_fill_nbr                   
,rx_partial_fill_nbr           
,third_party_plan_id           
,fill_sold_dt                  
,cob_ind                       
,fill_adjud_dt                 
,fill_adjud_tm                 
,fill_adjud_cd                 
,claim_ref_nbr                 
,plan_tot_paid_dlrs            
,plan_return_cost_dlrs         
,plan_return_fee_dlrs          
,plan_return_copay_dlrs        
,plan_return_tax_dlrs          
,plan_submit_copay_dlrs        
,plan_submit_cost_dlrs         
,plan_submit_fee_dlrs          
,plan_submit_tax_dlrs          
,relocate_fm_str_nbr           
,edw_batch_id                  
,plan_ar_dlrs                  
,create_user_id                
,update_dttm                   
,update_user_id                
,src_partition_nbr             
,plan_gross_due_dlrs           
,basis_of_reimb_detrm          
,bin_nbr                       
,plan_group_nbr                
,fill_enter_dt                 
,fill_enter_tm                 
,del_adjud_cd                  
,general_phrm_nbr              
,general_recipient_nbr         
,general_rph_nbr               
,maj_med_prior_auth_nbr        
,plan_incent_submtd_dlrs       
,plan_incentive_paid_dlrs      
,plan_other_paid_dlrs          
,plan_other_submtd_dlrs        
,attributed_to_tax_dlrs        
,reimburs_loss_dlrs            
,plan_copay_dlrs               
,plan_other_dlrs               
,plan_tax_dlrs                 
,src_eff_dt                    
,src_eff_tm                    
,src_end_dt                    
,src_end_tm                    
,cdc_rba_nbr                   
,edw_dml_ind                   
,edw_rank                      
FROM $pTDStageDB.V_FILLPLAN_RX_FILL_ENDATED""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("""CALL PRDUTIL.TABLE_STATS('$pTDStageDB','ETL_ENDATED_FILLPLAN_RX_FILL')""",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  return

main()
cleanup()
done()
ZZ


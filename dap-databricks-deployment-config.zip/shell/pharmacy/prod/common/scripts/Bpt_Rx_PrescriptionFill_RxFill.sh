#!/bin/sh

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
pTDEDWTargetTable=$7

python3 <<ZZ
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *
 
def main():
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.ETL_PROC_FILL_FILL""",
    [])
  ])
  #-- DEL_ALL - Remove ALL keyword from DELETE statement
  if (Action.errorCode != 0):
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.ETL_PROC_FILL_FILL
 (	 RX_NBR
	,STR_NBR
	,RX_CREATE_DT
	,RX_FILL_NBR
	,RX_PARTIAL_FILL_NBR
	,DSPN_FILL_NBR
	,PARTIAL_FILL_CD
	,PAT_ID
	,PBR_ID
	,PBR_LOC_ID
	,FILL_SOLD_DT
	,FILL_SOLD_TM
	,FILL_SOLD_DLRS
	,FILL_STAT_CD
	,FILL_QTY_DSPN
	,FILL_PAY_METHOD_CD
	,FILL_DAYS_SUPPLY
	,FILL_AWP_COST_DLRS
	,FILL_DISCNT_CD
	,FILL_DISCNT_DLRS
	,FILL_RTL_PRICE_DLRS
	,FILL_LABEL_PRICE_DLRS
	,FILL_VRFY_USER_ID
	,FILL_VRFY_DT
	,FILL_VRFY_TM
	,FILL_TYPE_CD
	,FILL_DEL_DT
	,FILL_DEL_TM
	,FILL_DATA_REVIEW_USER_ID
	,FILL_DATA_REVIEW_DT
	,FILL_DATA_REVIEW_TM
	,FILL_ENTER_USER_ID
	,FILL_ENTER_DT
	,FILL_ENTER_TM
	,FILL_SRC_CD
	,FILL_WAC_DLRS
	,FILLING_USER_ID
	,FILLING_DT
	,FILLING_TM
	,FILL_ENTER_STR_NBR
	,FILL_REVIEW_STR_NBR
	,DRUG_ID
	,DRUG_NAME
	,DEA_CLASS_CD
	,REFILLS_REMAIN_CNT
	,ORIG_REFILLS_REMAIN_WHEN_ENTER
	,TOT_AMT_PAID_IND
	,SIMS_UPC
	,OVERRIDE_USER_ID
	,OVERRIDE_DT
	,OVERRIDE_TM
	,RELOCATE_FM_STR_NBR
	,CREATE_USER_ID
	,CREATE_DTTM
	,EDW_BATCH_ID
	,UPDATE_USER_ID
	,UPDATE_DTTM
	,SRC_PARTITION_NBR
	,accept_consult_ind            
	,cash_disc_sav_dlrs            
	,data_rev_spec_dttm            
	,data_rev_spec_id              
	,data_rev_spec_str_nbr         
	,fax_image_id                  
	,fill_price_override_dlrs      
	,fill_rph_of_rec_id            
	,route_str_tech_inits          
	,drug_whse_ind                 
	,lvl_of_svc_cd                 
	,rx_daw_ind                    
	,sourcing_ind                  
	,tip_rsn_for_svc_cd            
	,fill_est_pick_up_dttm         
	,cost_plus_fee_cd
)
SELECT	TFILL.RX_NBR
	,TFILL.STR_NBR
	,TFILL.RX_CREATE_DT
	,TFILL.RX_FILL_NBR
	,TFILL.RX_PARTIAL_FILL_NBR
	,TFILL.DSPN_FILL_NBR
	,TFILL.PARTIAL_FILL_CD
	,TFILL.PAT_ID
	,TFILL.PBR_ID
	,TFILL.PBR_LOC_ID
	,TFILL.FILL_SOLD_DT
	,TFILL.FILL_SOLD_TM
	,TFILL.FILL_SOLD_DLRS
	,TFILL.FILL_STAT_CD
	,TFILL.FILL_QTY_DSPN
	,TFILL.FILL_PAY_METHOD_CD
	,TFILL.FILL_DAYS_SUPPLY
	,TFILL.FILL_AWP_COST_DLRS
	,TFILL.FILL_DISCNT_CD
	,TFILL.FILL_DISCNT_DLRS
	,TFILL.FILL_RTL_PRICE_DLRS
	,TFILL.FILL_LABEL_PRICE_DLRS
	,TFILL.FILL_VRFY_USER_ID
	,TFILL.FILL_VRFY_DT
	,TFILL.FILL_VRFY_TM
	,TFILL.FILL_TYPE_CD
	,TFILL.FILL_DEL_DT
	,TFILL.FILL_DEL_TM
	,TFILL.FILL_DATA_REVIEW_USER_ID
	,TFILL.FILL_DATA_REVIEW_DT
	,TFILL.FILL_DATA_REVIEW_TM
	,TFILL.FILL_ENTER_USER_ID
	,TFILL.FILL_ENTER_DT
	,TFILL.FILL_ENTER_TM
	,TFILL.FILL_SRC_CD
	,TFILL.FILL_WAC_DLRS
	,TFILL.FILLING_USER_ID
	,TFILL.FILLING_DT
	,TFILL.FILLING_TM
	,TFILL.FILL_ENTER_STR_NBR
	,TFILL.FILL_REVIEW_STR_NBR
	,TFILL.DRUG_ID
	,TFILL.DRUG_NAME
	,TFILL.DEA_CLASS_CD
	,TFILL.REFILLS_REMAIN_CNT
	,TFILL.ORIG_REFILLS_REMAIN_WHEN_ENTER
	,TFILL.TOT_AMT_PAID_IND
	,TFILL.SIMS_UPC
	,TFILL.OVERRIDE_USER_ID
	,TFILL.OVERRIDE_DT
	,TFILL.OVERRIDE_TM
	,TFILL.RELOCATE_FM_STR_NBR
	,TFILL.CREATE_USER_ID
	,TFILL.CREATE_DTTM
	,TFILL.EDW_BATCH_ID
	,TFILL.UPDATE_USER_ID
	,TFILL.UPDATE_DTTM
	,TFILL.SRC_PARTITION_NBR
	,TFILL.accept_consult_ind            
	,TFILL.cash_disc_sav_dlrs            
	,TFILL.data_rev_spec_dttm            
	,TFILL.data_rev_spec_id              
	,TFILL.data_rev_spec_str_nbr         
	,TFILL.fax_image_id                  
	,TFILL.fill_price_override_dlrs      
	,TFILL.fill_rph_of_rec_id            
	,TFILL.route_str_tech_inits          
	,TFILL.drug_whse_ind                 
	,TFILL.lvl_of_svc_cd                 
	,TFILL.rx_daw_ind                    
	,TFILL.sourcing_ind                  
	,TFILL.tip_rsn_for_svc_cd            
	,TFILL.fill_est_pick_up_dttm         
	,TFILL.cost_plus_fee_cd
FROM	$pTDViewDBName.$pTDEDWTargetTable TFILL,
                  (SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTER_DTTM
                     FROM $pTDStageDB.ETL_TBF0_FILL 
                     WHERE CDC_OPERATION_TYPE_CD IN ('PK UPDATE','SQL COMPUPDATE')
                     GROUP BY RX_NBR, STORE_NBR, FILL_NBR, FILL_PARTIAL_NBR, FILL_ENTER_DTTM
                           MINUS
     					SELECT RX_NBR, STORE_NBR, FILL_NBR,FILL_PARTIAL_NBR, FILL_ENTER_DTTM 
     					FROM $pTDStageDB.ETL_TBF0_FILL
     					WHERE CDC_OPERATION_TYPE_CD='INSERT' ) B
WHERE TFILL.RX_NBR = B.RX_NBR
AND     TFILL.STR_NBR = B.STORE_NBR
AND     TFILL.RX_FILL_NBR = B.FILL_NBR
AND     TFILL.RX_PARTIAL_FILL_NBR = B.FILL_PARTIAL_NBR
AND     TFILL.FILL_ENTER_DT = CAST ( B.FILL_ENTER_DTTM AS DATE )
AND     TFILL.FILL_ENTER_TM = CAST ( B.FILL_ENTER_DTTM AS TIME(0))""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("""call PRDUTIL.TABLE_STATS('$pTDStageDB', 'ETL_PROC_FILL_FILL')""",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  executeSql([], [
    ("""DELETE FROM $pTDStageDB.ETL_ENDATED_FILL_RX_FILL""",
    [])
  ])
  #-- DEL_ALL - Remove ALL keyword from DELETE statement
  if (Action.errorCode != 0):
    return
  executeSql([], [
    ("""INSERT INTO $pTDStageDB.ETL_ENDATED_FILL_RX_FILL 
(rx_nbr                        
,str_nbr                       
,rx_create_dt                  
,rx_fill_nbr                   
,rx_partial_fill_nbr           
,dspn_fill_nbr                 
,partial_fill_cd               
,pat_id                        
,pbr_id                        
,pbr_loc_id                    
,fill_sold_dt                  
,fill_sold_tm                  
,fill_sold_dlrs                
,fill_stat_cd                  
,fill_qty_dspn                 
,fill_pay_method_cd            
,fill_day_supply               
,fill_awp_cost_dlrs            
,fill_discnt_cd                
,fill_discnt_dlrs              
,fill_rtl_price_dlrs           
,fill_label_price_dlrs         
,fill_vrfy_user_id             
,fill_vrfy_dt                  
,fill_vrfy_tm                  
,fill_type_cd                  
,fill_del_dt                   
,fill_del_tm                   
,fill_data_review_user_id      
,fill_data_review_dt           
,fill_data_review_tm           
,fill_enter_user_id            
,fill_enter_dt                 
,fill_enter_tm                 
,fill_src_cd                   
,fill_wac_dlrs                 
,filling_user_id               
,filling_dt                    
,filling_tm                    
,fill_enter_str_nbr            
,fill_review_str_nbr           
,drug_id                       
,drug_name                     
,dea_class_cd                  
,refills_remain_cnt            
,orig_refills_remain_when_enter
,tot_amt_paid_ind              
,sims_upc                      
,override_user_id              
,override_dt                   
,override_tm                   
,relocate_fm_str_nbr           
,create_user_id                
,create_dttm                   
,edw_batch_id                  
,update_user_id                
,update_dttm                   
,src_partition_nbr             
,accept_consult_ind            
,cash_disc_sav_dlrs            
,data_rev_spec_dttm            
,data_rev_spec_id              
,data_rev_spec_str_nbr         
,fax_image_id                  
,fill_price_override_dlrs      
,fill_rph_of_rec_id            
,route_str_tech_inits          
,drug_whse_ind                 
,lvl_of_svc_cd                 
,rx_daw_ind                    
,sourcing_ind                  
,tip_rsn_for_svc_cd            
,fill_est_pick_up_dttm 
,cost_plus_fee_cd        
,src_eff_dt                    
,src_eff_tm                    
,src_end_dt                    
,src_end_tm                    
,cdc_rba_nbr                   
,edw_dml_ind                   
,edw_rank             
)
SELECT 
rx_nbr                        
,str_nbr                       
,rx_create_dt                  
,rx_fill_nbr                   
,rx_partial_fill_nbr           
,dspn_fill_nbr                 
,partial_fill_cd               
,pat_id                        
,pbr_id                        
,pbr_loc_id                    
,fill_sold_dt                  
,fill_sold_tm                  
,fill_sold_dlrs                
,fill_stat_cd                  
,fill_qty_dspn                 
,fill_pay_method_cd            
,fill_day_supply               
,fill_awp_cost_dlrs            
,fill_discnt_cd                
,fill_discnt_dlrs              
,fill_rtl_price_dlrs           
,fill_label_price_dlrs         
,fill_vrfy_user_id             
,fill_vrfy_dt                  
,fill_vrfy_tm                  
,fill_type_cd                  
,fill_del_dt                   
,fill_del_tm                   
,fill_data_review_user_id      
,fill_data_review_dt           
,fill_data_review_tm           
,fill_enter_user_id            
,fill_enter_dt                 
,fill_enter_tm                 
,fill_src_cd                   
,fill_wac_dlrs                 
,filling_user_id               
,filling_dt                    
,filling_tm                    
,fill_enter_str_nbr            
,fill_review_str_nbr           
,drug_id                       
,drug_name                     
,dea_class_cd                  
,refills_remain_cnt            
,orig_refills_remain_when_enter
,tot_amt_paid_ind              
,sims_upc                      
,override_user_id              
,override_dt                   
,override_tm                   
,relocate_fm_str_nbr           
,create_user_id                
,create_dttm                   
,edw_batch_id                  
,update_user_id                
,update_dttm                   
,src_partition_nbr             
,accept_consult_ind            
,cash_disc_sav_dlrs            
,data_rev_spec_dttm            
,data_rev_spec_id              
,data_rev_spec_str_nbr         
,fax_image_id                  
,fill_price_override_dlrs      
,fill_rph_of_rec_id            
,route_str_tech_inits          
,drug_whse_ind                 
,lvl_of_svc_cd                 
,rx_daw_ind                    
,sourcing_ind                  
,tip_rsn_for_svc_cd            
,fill_est_pick_up_dttm 
,cost_plus_fee_cd        
,src_eff_dt                    
,src_eff_tm                    
,src_end_dt                    
,src_end_tm                    
,cdc_rba_nbr                   
,edw_dml_ind                   
,edw_rank                      
FROM $pTDStageDB.V_FILL_RX_FILL_ENDATED""",
    [])
  ])
  if (Action.errorCode != 0):
    return
#  executeSql([], [
#    ("""CALL PRDUTIL.TABLE_STATS('$pTDStageDB','ETL_ENDATED_FILL_RX_FILL')""",
#    [])
#  ])
#  if (Action.errorCode != 0):
#    return
  return

main()
cleanup()
done()
ZZ


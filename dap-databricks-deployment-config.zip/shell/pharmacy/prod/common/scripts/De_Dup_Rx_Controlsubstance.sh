#!/bin/sh

pTDServer=$1
pTDUserid=$2
pTDPassword=$3
pTDDBName=$4
pTDStageDB=$5
pTDViewDBName=$6
APT_TERA_SYNC_DATABASE=$7

python3 <<ZZ
#!/usr/bin/python3

#import os
#import sys

#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():

  #/* PERFORM STORE RELO UPDATES FOR TARGET TABLES */
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_control_substance

set str_nbr = R.relocate_to_str_nbr
from $pTDDBName.location_store_relocation R
where $pTDDBName.prescription_control_substance.str_nbr =
R.relocate_fm_str_nbr
and R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* PERFORM STORE RELO UPDATES FOR DEDUP TABLES */
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_proc_dup_rx_cntrl_subst

set store_nbr = R.relocate_to_str_nbr
from $pTDDBName.location_store_relocation R
where $pTDStageDB.etl_proc_dup_rx_cntrl_subst.store_nbr =
R.relocate_fm_str_nbr
and R.relocate_prcs_ind = 'N';
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* REMOVE PK UPDATES FOR STORE RELOS IN STAGE TABLES */
  executeSql([], [
    ("""delete from
$pTDStageDB.etl_tbf0_rx_cntrl_substance
where
( cdc_txn_commit_dttm,
cdc_seq_nbr,
cdc_rba_nbr )
IN
(select bfr.cdc_txn_commit_dttm,
bfr.cdc_seq_nbr,
bfr.cdc_rba_nbr
from $pTDStageDB.etl_tbf0_rx_cntrl_substance BFR,
$pTDStageDB.etl_tbf0_rx_cntrl_substance AFT,
$pTDDBName.location_store_relocation SR
where BFR.cdc_txn_commit_dttm = AFT.cdc_txn_commit_dttm
and BFR.cdc_seq_nbr = AFT.cdc_seq_nbr
and BFR.cdc_rba_nbr = AFT.cdc_rba_nbr

and SR.relocate_fm_str_nbr = BFR.store_nbr
and SR.relocate_to_str_nbr = AFT.store_nbr

and BFR.cdc_before_after_cd = 'BEFORE'
and AFT.cdc_before_after_cd = 'AFTER'
and BFR.cdc_operation_type_cd = 'SQL COMPUPDATE'
and AFT.cdc_operation_type_cd = 'PK UPDATE'

and BFR.store_nbr <> AFT.store_nbr
and BFR.rx_nbr = AFT.rx_nbr
and BFR.fill_nbr = AFT.fill_nbr
and BFR.fill_partial_nbr = AFT.fill_partial_nbr
and BFR.transaction_cd = AFT.transaction_cd
);""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* UPDATE STORE NUMBERS FOR STORE RELOS IN STAGE TABLES */
  executeSql([], [
    ("""UPDATE $pTDStageDB.etl_tbf0_rx_cntrl_substance

set store_nbr = SR.relocate_to_str_nbr
from $pTDDBName.location_store_relocation SR
where store_nbr = SR.relocate_fm_str_nbr;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* DEDUP STARTS FROM HERE */
  #-----------------------------------------------------------------------
  #/* delete Test Stores if any */
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_rx_cntrl_substance
where store_nbr in
(select store_nbr from $pTDStageDB.etl_proc_test_store);""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #-------------------------------------------------------------------------------------
  #/* delete multiple inserts from the same batch with different create_dttm */
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cntrl_subst
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,relocate_fm_str_nbr
)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm        
,relocate_fm_str_nbr
from
$pTDStageDB.etl_tbf0_rx_cntrl_substance
where
(store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd )
in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd
From $pTDStageDB.etl_tbf0_rx_cntrl_substance
where cdc_operation_type_cd = 'INSERT'
group by store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd
having count(distinct create_dttm) > 1);
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete
from $pTDStageDB.etl_tbf0_rx_cntrl_substance
where
( store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd )
in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd
From $pTDStageDB.etl_tbf0_rx_cntrl_substance
where cdc_operation_type_cd = 'INSERT'
group by store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd
having count(distinct create_dttm) > 1);
-- DEL_STATEMENT - Replace DEL with DELETE
-- SEL_STATEMENT - Replace SEL with SELECT
-- SYN_HAVING - Reformat syntax HAVING
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--------------------------------------------------------------------------------------
  executeSql([], [
    ("""DELETE FROM $APT_TERA_SYNC_DATABASE.ETL_TBF0_CNTRL_SUB_CHG_ANLYS;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""INSERT INTO $APT_TERA_SYNC_DATABASE.ETL_TBF0_CNTRL_SUB_CHG_ANLYS
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm        
,relocate_fm_str_nbr
)
SELECT 
STG.cdc_txn_commit_dttm           
,STG.cdc_seq_nbr                   
,STG.cdc_rba_nbr                   
,STG.cdc_operation_type_cd         
,STG.cdc_before_after_cd           
,STG.cdc_txn_position_cd           
,STG.edw_batch_id                  
,STG.store_nbr                     
,STG.rx_nbr                        
,STG.fill_nbr                      
,STG.fill_partial_nbr              
,STG.fill_verified_user_inits      
,STG.transaction_cd                
,STG.drug_id                       
,STG.drug_non_system_name          
,STG.src_partition_nbr             
,STG.create_user_id                
,STG.create_dttm                   
,STG.update_user_id                
,STG.update_dttm    
,STG.relocate_fm_str_nbr
FROM
(
SELECT rx_nbr,store_nbr, fill_nbr, fill_partial_nbr,transaction_cd, max(cdc_txn_commit_dttm) max_cdc_dttm
FROM $pTDStageDB.etl_tbf0_rx_cntrl_substance
WHERE cdc_operation_type_cd='INSERT'
GROUP BY 1,2,3,4,5) MX_INS,
$pTDStageDB.etl_tbf0_rx_cntrl_substance STG
WHERE STG.STORE_NBR=MX_INS.STORE_NBR
AND STG.RX_NBR=MX_INS.RX_NBR
AND STG.FILL_NBR=MX_INS.FILL_NBR
AND STG.FILL_PARTIAL_NBR=MX_INS.FILL_PARTIAL_NBR
AND STG.TRANSACTION_CD=MX_INS.TRANSACTION_CD
AND STG.CDC_TXN_COMMIT_DTTM < MX_INS.max_CDC_DTTM;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_rx_cntrl_substance STG 
using $APT_TERA_SYNC_DATABASE.ETL_TBF0_CNTRL_SUB_CHG_ANLYS PROC 
WHERE STG.STORE_NBR=PROC.STORE_NBR
AND STG.RX_NBR=PROC.RX_NBR
AND STG.fill_nbr=PROC.fill_nbr
AND STG.fill_partial_nbr=PROC.fill_partial_nbr
AND STG.transaction_cd= PROC.transaction_cd
AND STG.CDC_TXN_COMMIT_DTTM = PROC.CDC_TXN_COMMIT_DTTM
AND STG.CDC_RBA_NBR = PROC.CDC_RBA_NBR
AND STG.CDC_BEFORE_AFTER_CD = PROC.CDC_BEFORE_AFTER_CD
AND STG.CDC_OPERATION_TYPE_CD = PROC.CDC_OPERATION_TYPE_CD
AND STG.CDC_TXN_POSITION_CD = PROC.CDC_TXN_POSITION_CD;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #-----------------------------------------------------------------------------
  #/* remove rx_dupes from etl stage table */
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cntrl_subst
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,relocate_fm_str_nbr
)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm        
,relocate_fm_str_nbr
from $pTDStageDB.etl_tbf0_rx_cntrl_substance
where
(store_nbr,rx_nbr)
in
(select store_nbr, rx_nbr From $pTDStageDB.etl_proc_dup_rx group by 1,2);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete
from $pTDStageDB.etl_tbf0_rx_cntrl_substance
where
(store_nbr,rx_nbr)
in
(select store_nbr, rx_nbr From $pTDStageDB.etl_proc_dup_rx group by 1,2);
-- DEL_STATEMENT - Replace DEL with DELETE
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------------------------------------
  #/* remove dupes from Trans Dupes table */
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cntrl_subst
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm        
,relocate_fm_str_nbr
)
select 
ETL.cdc_txn_commit_dttm           
,ETL.cdc_seq_nbr                   
,ETL.cdc_rba_nbr                   
,ETL.cdc_operation_type_cd         
,ETL.cdc_before_after_cd           
,ETL.cdc_txn_position_cd           
,ETL.edw_batch_id                  
,ETL.store_nbr                     
,ETL.rx_nbr                        
,ETL.fill_nbr                      
,ETL.fill_partial_nbr              
,ETL.fill_verified_user_inits      
,ETL.transaction_cd                
,ETL.drug_id                       
,ETL.drug_non_system_name          
,ETL.src_partition_nbr             
,ETL.create_user_id                
,ETL.create_dttm                   
,ETL.update_user_id                
,ETL.update_dttm    
,ETL.relocate_fm_str_nbr
from $pTDStageDB.etl_tbf0_rx_cntrl_substance ETL,
$pTDStageDB.etl_proc_dup_rx_tran DUP
where ETL.store_nbr = DUP.store_nbr
and ETL.rx_nbr = DUP.rx_nbr
and ETL.fill_nbr= DUP.fill_nbr
and ETL.fill_partial_nbr= DUP.fill_partial_nbr;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_rx_cntrl_substance ETL 
using $pTDStageDB.etl_proc_dup_rx_tran DUP 
where ETL.store_nbr = DUP.store_nbr
and ETL.rx_nbr = DUP.rx_nbr
and ETL.fill_nbr= DUP.fill_nbr
and ETL.fill_partial_nbr= DUP.fill_partial_nbr;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #------------------------------------------------------------------------------------
  #/* remove dupes from Fill Dupes table */
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cntrl_subst
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,relocate_fm_str_nbr
)
select 
ETL.cdc_txn_commit_dttm           
,ETL.cdc_seq_nbr                   
,ETL.cdc_rba_nbr                   
,ETL.cdc_operation_type_cd         
,ETL.cdc_before_after_cd           
,ETL.cdc_txn_position_cd           
,ETL.edw_batch_id                  
,ETL.store_nbr                     
,ETL.rx_nbr                        
,ETL.fill_nbr                      
,ETL.fill_partial_nbr              
,ETL.fill_verified_user_inits      
,ETL.transaction_cd                
,ETL.drug_id                       
,ETL.drug_non_system_name          
,ETL.src_partition_nbr             
,ETL.create_user_id                
,ETL.create_dttm                   
,ETL.update_user_id                
,ETL.update_dttm    
,ETL.relocate_fm_str_nbr
from $pTDStageDB.etl_tbf0_rx_cntrl_substance ETL,
$pTDStageDB.etl_proc_dup_fill DUP
where ETL.store_nbr = DUP.store_nbr
and ETL.rx_nbr = DUP.rx_nbr
and ETL.fill_nbr= DUP.fill_nbr
and ETL.fill_partial_nbr= DUP.fill_partial_nbr;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete from $pTDStageDB.etl_tbf0_rx_cntrl_substance ETL 
using $pTDStageDB.etl_proc_dup_fill DUP 
where ETL.store_nbr = DUP.store_nbr
and ETL.rx_nbr = DUP.rx_nbr
and ETL.fill_nbr= DUP.fill_nbr
and ETL.fill_partial_nbr= DUP.fill_partial_nbr;
-- DEL_WITH_JOIN - change from_clause in delete_with_join statement into from_clause and using_clause
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #----------------------------------------------------------------------------------------------------------------------------------
  #/* remove dupes from dup_rx_cntrl_sub */
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cntrl_subst
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm                   
,relocate_fm_str_nbr
)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm        
,relocate_fm_str_nbr
from
$pTDStageDB.etl_tbf0_rx_cntrl_substance
where
(store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd )
in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd
From $pTDStageDB.etl_proc_dup_rx_cntrl_subst group by 1,2,3,4,5);
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete
from $pTDStageDB.etl_tbf0_rx_cntrl_substance
where
( store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd )
in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd
From $pTDStageDB.etl_proc_dup_rx_cntrl_subst group by 1,2,3,4,5);
-- DEL_STATEMENT - Replace DEL with DELETE
-- SEL_STATEMENT - Replace SEL with SELECT
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #--------------------------------------------------------------------------------------------------------------------------------
  #/* IDENTIFYING DUPLICATES BETWEEN ETL STAGE AND TARGET date -730 days check */
  executeSql([], [
    ("""CREATE temporary TABLE $pTDStageDB.V_dup_rx_fill
(
store_nbr DECIMAL(5,0) NOT NULL,
rx_nbr DECIMAL(7,0) NOT NULL,
fill_nbr DECIMAL(3,0),
fill_partial_nbr DECIMAL(1,0),
transaction_cd CHAR(1)  COLLATE 'en-ci' 
)
on commit preserve rows;
-- CHAR_SET - Remove CHARACTER SET create table option
-- COLUMN_ATTRIBUTES - Remove not casespecific and replace with collate en-ci
-- CREATE_TABLE_TYPE_OPTION - Replace VOLATILE with TEMPORARY
-- TABLE_INDEX - Remove table index options
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""insert into $pTDStageDB.V_dup_rx_fill
select STG.store_nbr,
STG.rx_nbr,
STG.fill_nbr,
STG.fill_partial_nbr,
STG.transaction_cd
from $pTDStageDB.etl_tbf0_rx_cntrl_substance STG,
$pTDViewDBName.prescription_control_substance TGT
where STG.rx_nbr = TGT.rx_nbr
and STG.store_nbr = TGT.str_nbr
and STG.fill_nbr = TGT.rx_fill_nbr
and STG.fill_partial_nbr = TGT.rx_partial_fill_nbr
and STG.transaction_cd=TGT.txn_cd
and coalesce( STG.create_dttm , cast( '1900-01-01 01:01:01' as timestamp(0)) ) <> coalesce( TGT.create_dttm , cast( '1900-01-01 01:01:01' as timestamp(0)) )
and cast(TGT.create_dttm as date) >= CAST(STG.create_dttm AS DATE) - 730
and cdc_operation_type_cd='INSERT'
group by STG.store_nbr,STG.rx_nbr, STG.fill_nbr, STG.fill_partial_nbr, STG.transaction_cd;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""insert into $pTDStageDB.etl_proc_dup_rx_cntrl_subst
(
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm        
,relocate_fm_str_nbr
)
select 
cdc_txn_commit_dttm           
,cdc_seq_nbr                   
,cdc_rba_nbr                   
,cdc_operation_type_cd         
,cdc_before_after_cd           
,cdc_txn_position_cd           
,edw_batch_id                  
,store_nbr                     
,rx_nbr                        
,fill_nbr                      
,fill_partial_nbr              
,fill_verified_user_inits      
,transaction_cd                
,drug_id                       
,drug_non_system_name          
,src_partition_nbr             
,create_user_id                
,create_dttm                   
,update_user_id                
,update_dttm        
,relocate_fm_str_nbr
from $pTDStageDB.etl_tbf0_rx_cntrl_substance
where (store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd)
in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd from $pTDStageDB.V_dup_rx_fill)
and cdc_operation_type_cd = 'INSERT';""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""delete
from $pTDStageDB.etl_tbf0_rx_cntrl_substance
where (store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd)
in
(select store_nbr,rx_nbr,fill_nbr,fill_partial_nbr,transaction_cd from $pTDStageDB.V_dup_rx_fill)
and cdc_operation_type_cd = 'INSERT';""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""drop table if exists $pTDStageDB.V_dup_rx_fill;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* PERFORM UPDATES FOR CHANGES TO RX CREATE DT parent   */
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_control_substance CntrlSub
    
set    rx_create_dt = STG.to_create_dt
 FROM    (Select str_nbr ,rx_nbr ,cast(frm_create_dttm as date) frm_create_dt, cast(to_create_dttm as date) to_create_dt, change_prcs_ind
                FROM    $pTDStageDB.rx_create_dttm_change
WHERE frm_create_dt <> to_create_dt
        
        GROUP BY 1,2,3,4,5
        
        )  STG
 where  CntrlSub.str_nbr = STG.str_nbr
  AND CntrlSub.rx_nbr = STG.rx_nbr
  AND CntrlSub.rx_create_dt =  STG.frm_create_dt
  AND CntrlSub.rx_create_dt IS NOT NULL
  AND STG.change_prcs_ind = 'N';
-- SEL_BODY_CLAUSES_ORDER - change the order of all the clauses of a select statement
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  #/* PERFORM UPDATES FOR CHANGES TO fill_sold DT IN parent  */
  executeSql([], [
    ("""CREATE TABLE $APT_TERA_SYNC_DATABASE.V_rx_cntrl_pre 
     (
      str_nbr INTEGER NOT NULL,
      rx_nbr INTEGER NOT NULL,
      rx_fill_nbr INTEGER NOT NULL ,
      rx_partial_fill_nbr INTEGER NOT NULL,
      fill_enter_dttm TIMESTAMP
      );
-- CREATE_TABLE_OPTION - remove create table options
-- DATA_TYPE - data type replace, timestamp with precision -> timestamp
-- TABLE_INDEX - Remove table index options
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""insert into $APT_TERA_SYNC_DATABASE.V_rx_cntrl_pre
(
      str_nbr,
      rx_nbr,
      rx_fill_nbr,
      rx_partial_fill_nbr,
      fill_enter_dttm
)
select
      AFT.STORE_NBR,
      AFT.rx_nbr,
      AFT.fill_nbr,
      AFT.fill_partial_nbr,
      max(AFT.FILL_ENTER_DTTM) as fill_enter_dttm
from $pTDStageDB.etl_tbf0_fill  BFR,
$pTDStageDB.etl_tbf0_fill  AFT
where
 BFR.STORE_NBR =AFT.STORE_NBR 
and BFR.rx_nbr=AFT.rx_nbr
and BFR.fill_nbr=AFT.fill_nbr
and BFR.fill_partial_nbr=AFT.fill_partial_nbr
and BFR.fill_enter_dttm=AFT.fill_enter_dttm
and BFR.cdc_operation_type_cd = 'SQL COMPUPDATE' 
and AFT.cdc_operation_type_cd = 'SQL COMPUPDATE' 
and AFT.cdc_before_after_cd = 'AFTER' 
and BFR.cdc_txn_commit_dttm= AFT.cdc_txn_commit_dttm 
and BFR.cdc_seq_nbr= AFT.cdc_seq_nbr 
and BFR.cdc_rba_nbr= AFT.cdc_rba_nbr 
and BFR.cdc_before_after_cd = 'BEFORE'
group by 1,2,3,4;""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""UPDATE $pTDDBName.prescription_control_substance T
set fill_sold_dt=F.fill_sold_dt
FROM    $APT_TERA_SYNC_DATABASE.V_rx_cntrl_pre TRX
,
   $pTDViewDBName.prescription_fill F
where
T.rx_nbr = TRX.rx_nbr
and T.str_nbr = TRX.str_nbr
and T.rx_fill_nbr = TRX.rx_fill_nbr
and T.rx_partial_fill_nbr = TRX.rx_partial_fill_nbr
and TRX.rx_nbr=F.rx_nbr
and TRX.str_nbr=F.str_nbr
and TRX.rx_fill_nbr=F.rx_fill_nbr
and TRX.rx_partial_fill_nbr=F.rx_partial_fill_nbr
and TRX.fill_enter_dttm=case when F.fill_enter_dt is null then cast('2099-12-31 12:12:12' as timestamp(0)) else cast(F.fill_enter_dt||' ' ||cast(F.fill_enter_tm as varchar(8)) as timestamp(0))  end
and T.rx_create_dt IS NOT NULL;
-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  executeSql([], [
    ("""drop table if exists $APT_TERA_SYNC_DATABASE.V_rx_cntrl_pre;
-- DROP_TBL: Add if exists in drop table
""",
    [])
  ])
  if (Action.errorCode != 0):
    Action.errorCodeOverride = 8
    return
  return

if __name__ == '__main__':
  main()
  cleanup()
  done()

ZZ


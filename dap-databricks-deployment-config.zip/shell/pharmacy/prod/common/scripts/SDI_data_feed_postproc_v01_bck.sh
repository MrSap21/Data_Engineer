#!/bin/sh


#------------------------------------------------------------------------------
#                      (C) Copyright 2009, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------
#  AUTHOR:           CHIRAG PATEL
#  FILE NAME:        SDI_data_feed_postproc_v01.sh
#  DATE:             06-08-2010
#  DESCRIPTION:      THIS SCRIPT WILL SFTP THE SDI DATA FEED FILE TO THE _____
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    |  Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  CHIRAG P  | 06-08-2010
#---------+-------------------------------------------+------------+-----------

LC_ALL=en_US
export LC_ALL

FTPSERVER=wag1l
FTPUSER=xfer125
DIRLOADREADY=$3
EDWBATCHID=$4
LOG_FILE=$5
EDWRXEMLADDR=$6
EDWBATCHDT=`print $EDWBATCHID | cut -c1-8`
SDIFILE01=SDI_data_feed_01_$EDWBATCHID.dat
SFTPSDIFILE01=WAG_125_${EDWBATCHDT}_01.dat
#SFTPSDIFILE01=SDI_data_feed_01_${EDWBATCHDT}.dat

echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "--------------- STARTING SCRIPT SDI_data_feed_postproc_v01.sh ---------------" >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "FTPSERVER        = " $FTPSERVER                                                >> $LOG_FILE
echo "FTPUSER          = " $FTPUSER                                                  >> $LOG_FILE
echo "DIRLOADREADY     = " $DIRLOADREADY                                             >> $LOG_FILE
echo "EDWBATCHID       = " $EDWBATCHID                                               >> $LOG_FILE
echo "LOG_FILE         = " $LOG_FILE                                                 >> $LOG_FILE
echo "EMAILTOADDR      = " $EMAILTOADDR                                              >> $LOG_FILE
echo "EDWBATCHDT       = " $EDWBATCHDT                                               >> $LOG_FILE
echo "SDIFILE01        = " $SDIFILE01                                                >> $LOG_FILE
echo "SFTPSDIFILE01    = " $SFTPSDIFILE01                                            >> $LOG_FILE
echo "-----------------------------------------------------------------------------" >> $LOG_FILE
echo "                                                                             " >> $LOG_FILE

###################################################################################
##### FTP SDIFILE01 AS LONG AS THE FILE EXISTS                                #####
###################################################################################
if [ -s $DIRLOADREADY/$SDIFILE01 ]
then
  echo "------------------------------------" >> $LOG_FILE
  echo "SENDING SDI FILE 01                 " >> $LOG_FILE
  echo "------------------------------------" >> $LOG_FILE
  gzip $DIRLOADREADY/$SDIFILE01
  print "put $DIRLOADREADY/$SDIFILE01.gz '/data02/xfer125/in/$SFTPSDIFILE01.tmp.gz'" > $DIRLOADREADY/SDI_FILE01_SFTP_PUT_CMD1.dat
  sftp -b $DIRLOADREADY/SDI_FILE01_SFTP_PUT_CMD1.dat $FTPUSER@$FTPSERVER
  RC=$?
  if [ $RC -ne 0 ]
  then
    echo "-------------------------" >> $LOG_FILE
    echo "SDI FILE 01 SFTP FAILURE " >> $LOG_FILE
    echo "-------------------------" >> $LOG_FILE
    uuencode $LOG_FILE $LOG_FILE | mail -s "SDI FILE 01 SFTP FAILURE - REQUIRES INVESTIGATION" $EDWRXEMLADDR
    exit 1
  else
    echo "-------------------------" >> $LOG_FILE
    echo "SDI FILE 01 SFTP SUCCESS " >> $LOG_FILE
    echo "-------------------------" >> $LOG_FILE
    rm $DIRLOADREADY/SDI_FILE01_SFTP_PUT_CMD1.dat
  fi

  echo "------------------------------------" >> $LOG_FILE
  echo "RENAMING SDI FILE                   " >> $LOG_FILE
  echo "------------------------------------" >> $LOG_FILE
  print "rename /data02/xfer125/in/$SFTPSDIFILE01.tmp.gz '/data02/xfer125/in/$SFTPSDIFILE01.gz'" > $DIRLOADREADY/SDI_FILE_SFTP_PUT_CMD2.dat
  sftp -b $DIRLOADREADY/SDI_FILE_SFTP_PUT_CMD2.dat $FTPUSER@$FTPSERVER
  RC=$?
  if [ $RC -ne 0 ]
  then
    echo "-------------------------" >> $LOG_FILE
    echo "RENAME SDI FILE FAILURE  " >> $LOG_FILE
    echo "-------------------------" >> $LOG_FILE
    uuencode $LOG_FILE $LOG_FILE | mail -s "RENAME SDI FILE FAILURE - REQUIRES INVESTIGATION" $EDWRXEMLADDR
    exit 1
  else
    echo "-------------------------" >> $LOG_FILE
    echo "RENAME SDI FILE SUCCESS  " >> $LOG_FILE
    echo "-------------------------" >> $LOG_FILE
    rm $DIRLOADREADY/SDI_FILE_SFTP_PUT_CMD2.dat
  fi

else
  echo "--------------------------" >> $LOG_FILE
  echo "SDI FILE 01 DOES NOT EXIST" >> $LOG_FILE
  echo "--------------------------" >> $LOG_FILE
  uuencode $LOG_FILE $LOG_FILE | mail -s "SDI FILE 01 DOES NOT EXIST - REQUIRES INVESTIGATION" $EDWRXEMLADDR
  exit 1
fi

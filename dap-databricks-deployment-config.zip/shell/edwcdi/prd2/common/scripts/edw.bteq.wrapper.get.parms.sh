#!/bin/ksh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Hal Hale & Chirag Patel
#  File name:        edw.bteq.wrapper.get.parms.sh
#  Date:             04-18-2008
#  Description:      Execute generic DataStage sequence
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-01-2008
#         |                                           |  C Patel   |
#---------+-------------------------------------------+------------+-----------
#   1.1   |  Clean up conditional processing for      |  C Patel   | 07-14-2008
#         |  bad parateter return                     |            |
#---------+-------------------------------------------+------------+-----------
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDDB=${4}
PARMTABLE=${5}
DSPROJECT=${6}
DSJOBNAME=${7}
DSJOBINVOCATION=${8}
ENVIRONMENT=${9}
PARMBTEQOUT=${10}
LOGFILE=${11}

echo "*=================================================================="
echo "| RETRIEVE PARAMETER LIST STARTED                                 *"
echo "| `date +'%D %r'` STARTED edw.bteq.wrapper.get.parms.sh           *"
echo "*=================================================================="
echo " "
echo "*=================================================================*"
echo "| Retrieve the parameter name / parameter values pairs for a      *"
echo "| DataStage Job.Invocation, within a DataStage project.           *"
echo "|                                                                 *"
echo "| If no parameter pairs are available for the specified job, an   *"
echo "| empty string will be returned.                                  *"
echo "|                                                                 *"
echo "| For parameter pairs where the parameter name begins with a      *"
echo "| dollar sign, the entire parameter pair will be put in double    *"
echo "| quotes.                                                         *"
echo "|                                                                 *"
echo "| Note: the parameter name pEdwBatchId is a reserved name.  The   *"
echo "|       parameter value will be replaced with the current Batch   *"
echo "|       ID in the calling wrapper script.                         *"
echo "*=================================================================*"
echo "**************************************************"
echo "* Application Specific Parameters                *"
echo "**************************************************"
echo "| TDSERVER           =$TDSERVER"
echo "| TDUSER             =$TDUSER"
echo "| TDPWD              =xxxxxxxx"
echo "| TDDB               =$TDDB"
echo "| PARMTABLE          =$PARMTABLE"
echo "| DSPROJECT          =$DSPROJECT"
echo "| DSJOBNAME          =$DSJOBNAME"
echo "| DSJOBINVOCATION    =$DSJOBINVOCATION"
echo "| ENVIRONMENT        =$ENVIRONMENT"
echo "| PARMBTEQOUT        =$PARMBTEQOUT"
echo "*=================================================================*"
echo "| Retrieve the parameter name and parameter value pairs.          *"
echo "*=================================================================*"
echo "|"
# INITIATE BTEQ SESSION AND INSERT SELECT LATEST BATCH ID AND BATCH STATUS DETAILS.

export TDDB
export PARMTABLE
export DSPROJECT
export DSJOBNAME
export DSJOBINVOCATION
export ENVIRONMENT
export PARMBTEQOUT

  > $PARMBTEQOUT

  python3 << EOF #>>$LOGFILE
import os
import sys
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  FormatOptions.width = 250
  Action.exportFileName = f"""{os.getenv("PARMBTEQOUT")}"""
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  #-- LOCKING ROW FOR ACCESS 
  executeSql([], [
    (f"""SELECT TRIM(parm_name)  as "",'|'  as "", parm_val  as "" FROM {os.getenv("TDDB")}.{os.getenv("PARMTABLE")} WHERE proj_name='{os.getenv("DSPROJECT")}' AND job_name='{os.getenv("DSJOBNAME")}' AND job_invocation_id='{os.getenv("DSJOBINVOCATION")}' AND envrt='{os.getenv("ENVIRONMENT")}'""",
    [])
  ])
  #-- LOCKING - comment out locking clause
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (Action.errorCode == 0):
    SELECTOK()
    return
  print("""SELECT JOB PARAMETERS FAILURE""")
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  SELECTOK()
def SELECTOK():
  print("""SELECT JOB PARAMETERS SUCCESS""")
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ]
then
  echo "*==========================================================*"
  echo "| *** PARAMETER RETRIEVAL FAILURE : RC=$RC                 *"
  echo "*==========================================================*"
  exit 1
else
  echo "*==========================================================*"
  echo "| *** PARAMETER RETRIEVAL SUCCESS : RC=$RC                 *"
  echo "*==========================================================*"
fi

echo "*=================================================================="
echo "| RETRIEVE PARMETER LIST FINISHED                                 *"
echo "| `date +'%D %r'` FINISHED edw.bteq.wrapper.get.parms.sh          *"
echo "*=================================================================="
echo "|"
exit 0

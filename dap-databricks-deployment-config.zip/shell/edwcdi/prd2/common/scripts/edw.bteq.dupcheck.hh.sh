#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw.bteq.dupcheck.sh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 06-11-2009
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------


## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDDBNAME=${4}
LOGFILE=${5}
DATE=${6}



## INITIATE BTEQ SESSION AND TAKE COUNT

  > $LOGBTEQOUT

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  executeSql([], [
    ("select seqno 
from
(select 
row_number() over (order by tbl.seq_dttm) seqno
from 
(
select seq_dttm,msg_txt from 
$TDDBNAME.stg_cdi_hh_consumerA where seq_dttm between '$DATE'||' 00:00:00.00000' and '$DATE'||' 23:59:59.99999'
union all
select seq_dttm,msg_txt from 
$TDDBNAME.stg_cdi_hh_consumerB where seq_dttm between  '$DATE'||' 00:00:00.00000' and '$DATE'||' 23:59:59.99999'
) Tbl) a
group by 1
having count(*)>1",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    FAILURE()
    return
  if (Action.activityCount != 0):
    FAILURE()
    return
  Action.errorCodeOverride = 0
  return
  FAILURE()
def FAILURE():
  Action.errorCodeOverride = 1
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ] 
 then
    exit 1
else
exit 0
fi
    

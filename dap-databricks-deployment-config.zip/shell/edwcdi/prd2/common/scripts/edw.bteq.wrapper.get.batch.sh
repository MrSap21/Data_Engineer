#!/bin/ksh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Hal Hale & Chirag Patel
#  File name:        edw.bteq.wrapper.get.batch.sh
#  Date:             04-18-2008
#  Description:      Execute generic DataStage sequence
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-01-2008
#         |                                           |  C Patel   | 
#---------+-------------------------------------------+------------+-----------
#   1.1   |  Dedup log records                        |  C Patel   | 07-14-2008
#---------+-------------------------------------------+------------+-----------
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDDB=${4}
BTCHTABLE=${5}
DSPROJECT=${6}
BTCHBTEQOUT=${7}

## SET SCRIPT PARAMETERS
echo "*=================================================================="
echo "| Get Batch ID Start                                              *" 
echo "|                                                                 *"
echo "| `date +'%D %r'` Start of edw.bteq.wrapper.get.batch.sh          *"
echo "|                                                                 *"
echo "*=================================================================="
echo " "
echo "*=================================================================*"
echo "| Retrieve the Cycle batch ID from the process control BATCH      *"
echo "| table.                                                          *"
echo "|                                                                 *"
echo "| If the last batch ID in the table is still active, the cycle    *"
echo "| will use this batch ID.                                         *"
echo "|                                                                 *"
echo "| If all batch IDs are closed, then create a new batch ID and     *"
echo "| insert it into the BATCH table.  This will be the batch ID      *"
echo "| used for the processing cycle.                                  *"
echo "*=================================================================*"
echo "**************************************************" 
echo "* Application Specific Parameters                *"
echo "**************************************************"
echo "| TDSERVER           =$TDSERVER"
echo "| TDUSER             =$TDUSER"
echo "| TDPWD              =xxxxxxxx"
echo "| TDDB               =$TDDB"
echo "| BTCHTABLE          =$BTCHTABLE"
echo "| DSPROJECT          =$DSPROJECT"
echo "| BTCHBTEQOUT        =$BTCHBTEQOUT"
echo "*=================================================================*"
echo "| Retrieve the Cycle batch ID from the process control BATCH      *"
echo "| table.                                                          *"
echo "*=================================================================*"
echo "|"

export TDSERVER
export TDUSER
export TDPWD
export TDDB
export BTCHTABLE
export DSPROJECT
export BTCHBTEQOUT
## INITIATE BTEQ SESSION AND INSERT SELECT LATEST BATCH ID AND BATCH STATUS DETAILS.

  > $BTCHBTEQOUT

python3 << EOF
import os
import sys
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  FormatOptions.width = 250
  Action.exportFileName = f"""{os.getenv("BTCHBTEQOUT")}"""
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  #-- LOCKING ROW FOR ACCESS
  executeSql([], [
    (f"""SELECT TRIM(cast(edw_batch_id as varchar(100))) as "",'|' as "", TRIM(btch_stat) as "" FROM {os.getenv("TDDB")}.{os.getenv("BTCHTABLE")} WHERE edw_batch_id=(SELECT MAX(edw_batch_id) FROM {os.getenv("TDDB")}.{os.getenv("BTCHTABLE")} WHERE proj_name='{os.getenv("DSPROJECT")}') AND proj_name='{os.getenv("DSPROJECT")}'""",
    [])
  ])
  #-- LOCKING - comment out locking clause
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement

  if (Action.errorCode == 0):
    SELECTOK()
    return
  print("""SELECT BATCH ID FAILURE""")
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  SELECTOK()
def SELECTOK():
  print("""SELECT BATCH ID SUCCESS""")
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ]
then
  echo "*======================================================*" 
  echo "| *** BATCH RETRIEVAL FAILURE : RC=$RC                 *" 
  echo "*======================================================*" 
  exit 1
else
  echo "*======================================================*" 
  echo "| *** BATCH RETRIEVAL SUCCESS : RC=$RC                 *" 
  echo "*======================================================*" 
fi

#------------------------------------------------------------------------------
## IF THE BATCH IS COMPLETE CREATE A NEW BATCH ID AND INSERT THE NEW RECORD ##
#------------------------------------------------------------------------------

BTCHSTAT=`cut -f2 -d'|' $BTCHBTEQOUT | tr -d ' '`

if [ "$BTCHSTAT" = "0" ]
  then
  echo "*=================================================================*"
  echo "| ALL BATCH IDs HAVE BEEN COMPLETED                               *"
  echo "| CREATING A NEW BATCH ID AND INSERTING IT INTO THE PROCESS       *"
  echo "| CONTROL BATCH TABLE.                                            *"
  echo "*=================================================================*"
  echo "|"

  EDWBTCHID=`date +"%C%y%m%d%H%M%S"`;
  BTCHINCOMPLETE="1";
  export EDWBTCHID
  export BTCHINCOMPLETE

  python3 << EOF
import os
import sys
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = f"""{os.getenv("BTCHBTEQOUT")}"""
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    (f"""INSERT INTO {os.getenv("TDDB")}.{os.getenv("BTCHTABLE")} (proj_name, edw_batch_id, btch_stat) VALUES ('{os.getenv("DSPROJECT")}', '{os.getenv("EDWBTCHID")}', '{os.getenv("BTCHINCOMPLETE")}')""",
    [])
  ])
  if (Action.errorCode == 0):
    INSERTOK()
    return
  print("""INSERT BATCH ID FAILURE""")
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  INSERTOK()
def INSERTOK():
  print("""INSERT BATCH ID SUCCESS""")
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

  RC=$?
  if [ $RC -ne 0 ]
  then
    echo "*======================================================*" 
    echo "| *** BATCH INSERT FAILURE : RC=$RC                    *" 
    echo "*======================================================*" 
    exit 1
  else
    echo "*======================================================*" 
    echo "| *** BATCH INSERT SUCCESS : RC=$RC                    *" 
    echo "*======================================================*" 
  fi

  print $EDWBTCHID > $BTCHBTEQOUT;
    
  echo "*=================================================================*"
  echo "| WRITE BATCH ID OUT TO A TEMPORARY FILE.                         *"
  echo "| USING BATCH ID = $EDWBTCHID                                     *"
  echo "*=================================================================*"
  echo "|"
  exit 0;
fi

if [ -f $BTCHBTEQOUT ] && [ -s $BTCHBTEQOUT ]
then
  echo "*=================================================================*"
  echo "| INCOMPLETE BATCH ID EXISTS.                                     *"
  echo "| USING AN ACTIVE BATCH ID.                                       *"
  echo "*=================================================================*"
  echo "|"

      EDWBTCHID=`cut -f1 -d"|" $BTCHBTEQOUT | tr -d ' '`;
      print $EDWBTCHID > $BTCHBTEQOUT;

  echo "*=================================================================*"
  echo "| WRITE BATCH ID OUT TO A TEMPORARY FILE.                         *"
  echo "| USING BATCH ID = $EDWBTCHID                                     *"
  echo "*=================================================================*"
  echo "|"

else
  echo "*=================================================================*"
  echo "| BATCH ID NOT FOUND FOR THIS PROJECT.                            *"
  echo "| CREATING A NEW BATCH ID                                         *"
  echo "| INSERTING BATCH ID INTO THE BATCH PROCESS CONTROL TABLE.        *" 
  echo "*=================================================================*"
  echo "|"
  
  EDWBTCHID=`date +"%C%y%m%d%H%M%S"`;
  BTCHINCOMPLETE="1";
  export EDWBTCHID
  export BTCHINCOMPLETE

  python << EOF
import os
import sys
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = f"""{os.getenv("BTCHBTEQOUT")}"""
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    (f"""INSERT INTO {os.getenv("TDDB")}.{os.getenv("BTCHTABLE")} (proj_name, edw_batch_id, btch_stat) VALUES ('{os.getenv("DSPROJECT")}', '{os.getenv("EDWBTCHID")}', '{os.getenv("BTCHINCOMPLETE")}')""",
    [])
  ])
  if (Action.errorCode == 0):
    INSERTOK()
    return
  print("""INSERT BATCH ID FAILURE""")
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  INSERTOK()
def INSERTOK():
  print("""INSERT BATCH ID SUCCESS""")
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

    RC=$?
    if [ $RC -ne 0 ]
    then
        echo "*======================================================*" 
        echo "| *** BATCH INSERT FAILURE : RC=$RC                    *" 
        echo "*======================================================*" 
        exit 1
    else
        echo "*======================================================*" 
        echo "| *** BATCH INSERT SUCCESS : RC=$RC                    *" 
        echo "*======================================================*" 
    fi

      print $EDWBTCHID > $BTCHBTEQOUT;

    echo "*=================================================================*"
    echo "| WRITE BATCH ID OUT TO A TEMPORARY FILE.                         *"
    echo "| USING BATCH ID = $EDWBTCHID                                     *"
    echo "*=================================================================*"
    echo "|"
fi

echo "*=================================================================="
echo "| RETRIEVE BATCH ID FINISHED"
echo "| `date +'%D %r'` FINISHED edw.bteq.wrapper.get.batch.sh"
echo "*=================================================================="
exit 0

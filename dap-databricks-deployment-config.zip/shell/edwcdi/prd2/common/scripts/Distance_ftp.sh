#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw_erecs_ftpscript.ksh 
#  Date:             07-22-2009
#  Description:      FTP output extract
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         | P Sarker   | 07-22-2009
#---------+-------------------------------------------+------------+-----------
if [[ `uname -n` == "dedwbt01" ]]
then
	ENVR="tst2"
	DS_PROJECT="EDW_CDI2_tst"
else
	ENVR="prd2"
	DS_PROJECT="EDW_CDI2_prd"
fi



. /usr/local/edw/edwcdi/${ENVR}/common/scripts/edw_cdi_config.ksh $DS_PROJECT

TARGET_BOX="prdbatch01"
SOURCE_BOX=`uname -n`

FTP_USER="edwcdipd"

SOURCE_DIR=/usr/local/edw/edwcdi/prd2/distance/output
TARGET_DIR=/ab/output/distance/cdi_dist
SOURCE_DATA_FILE1=cust_dcal_20100715.txt
SOURCE_DATA_FILE2=cust_dcal.trg
LOGFILE=$APP_ROOT/audit/Disftperec.log.`date +%m%d%H%M`
ERR_FILE=$APP_ROOT/audit/Disftperec.err.`date +%m%d%H%M`
TEMP_FILE=$APP_ROOT/audit/Dis.ftp_resultserec

cd $SOURCE_DIR

sftp ${FTP_USER}@${TARGET_BOX} <<-ENDFTP >$TEMP_FILE 2>>$ERR_FILE
        cd $TARGET_DIR
        pwd
        mput  $SOURCE_DATA_FILE1
        mput  $SOURCE_DATA_FILE2
        quit
ENDFTP
FTP_GET_RC=$?

echo "*************************************************************" >> $LOGFILE
echo "*  FTP Retrieval Results log                                *" >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo " "  >> $LOGFILE
cat $TEMP_FILE >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo "*  FTP Retrieval Error log (If applicable)                  *" >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo " "  >> $LOGFILE
cat $ERR_FILE >> $LOGFILE
echo " "  >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo " "  >> $LOGFILE
rm $ERR_FILE $TEMP_FILE 
echo "#############################################" >> $LOGFILE
echo "#  End   FTP `date +'%D %r'`           #" >> $LOGFILE
echo "#  Return Code = $FTP_GET_RC                          #" >> $LOGFILE
echo "#############################################" >> $LOGFILE


#----------------------------------------------------------------------
# Check for FTP errors
#----------------------------------------------------------------------
if [ $FTP_GET_RC -ne 0 ]
then
        echo "#############################################" >> $LOGFILE
        echo "#      F T P      F A I L E D               #" >> $LOGFILE
        echo "#############################################" >> $LOGFILE
	exit $FTP_GET_RC
fi
echo "#############################################" >> $LOGFILE
echo "#      F T P      C O M P L E T E           #" >> $LOGFILE
echo "#############################################" >> $LOGFILE

exit 0










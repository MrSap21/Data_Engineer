#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw_phy_tbl.ksh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 06-11-2009
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------

if [[ `uname -n` == "dedwbt01" ]]
then
	ENVR="tst"
	DS_PROJECT="EDW_CDI2_tst"
else
	ENVR="prd2"
	DS_PROJECT="EDW_CDI2_prd"
fi

## SET SCRIPT PARAMETERS

. /usr/local/edw/edwcdi/${ENVR}/common/scripts/edw_cdi_config.ksh $DS_PROJECT

LOGFILE=$APP_ROOT/audit/Physical.log.`date +%m%d%H%M`

EDWBTCHID=`date +"%C%y%m%d%H%M%S"`;

## INITIATE BTEQ SESSION AND TAKE COUNT

  > $LOGBTEQOUT

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  executeSql([], [
    ("update prdetl.cdi2_consumer_keys set one_to_one_rln_ind=NULL",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("UPDATE prdetl.cdi2_consumer_keys A
set eps_mul_rln_eid=b.cnt
FROM    (select agility_key_indv,count(*) cnt from (select eid,agility_key_indv from  prdetl.cdi2_consumer_keys where eid is not null and agility_key_indv is not null group by 1,2) a
group  by 1
having count(*)>1) b
where a.agility_key_indv=b.agility_key_indv and a.agility_key_indv is not null",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- SYN_HAVING - Reformat syntax HAVING
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_consumer_keys set eps_mul_rln_eid=0 where (eid is null or agility_key_indv is null) and eps_mul_rln_eid is null",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_consumer_keys set eps_mul_rln_eid=1 where eps_mul_rln_eid is null",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_consumer_keys set one_to_one_rln_ind='Y' where eid_mul_rln_eps in (0,1) and 
eid_mul_rln_aarp in (0,1) and 
eps_mul_rln_eid in (0,1) and 
eps_mul_rln_aarp in (0,1) and 
aarp_mul_rln_eps in (0,1) and 
aarp_mul_rln_eid in (0,1)",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_consumer_keys set one_to_one_rln_ind='N' where one_to_one_rln_ind is NULL",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  Action.errorCodeOverride = 0
  return
  FAILURE()
def FAILURE():
  Action.errorCodeOverride = 1
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ] 
 then
    exit 1
else
exit 0
fi

#!/usr/bin/ksh
#--------------------------------------------------------------------------------------------
#
#  Description:      Script to delete the corrupted records from /usr/local/edw/edwcdi/prd2/input/CDI_Linkages_*
#  Frequency:        On Demand by Support
#
#
#--------------------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------------------
# Revision|                Description                |    Name    |  Date
#---------+-------------------------------------------+------------+-----------------------
#   1.0   |  Initial version.                         |EDW Offshore|
#---------+-------------------------------------------+------------+-----------------------


#MSS_SUB_HOME=/usr/local/edw/sandboxes/mxs51_sandboxes/pos/subject-area/ecdw
INPUT_FILE=$1

cd /usr/local/edw/edwcdi/prd2/input
AUDIT=/usr/local/edw/edwcdi/prd2/audit

JOB_NAME=`basename ${0} | sed 's/.ksh//g'`
LOG_FILE=$AUDIT/$JOB_NAME.log.`date +%m%d%H%M`
ERR_FILE=$AUDIT/$JOB_NAME.err.`date +%m%d%H%M`
RUN_DATE=`date +%Y%m%d`

#------------------------------------------------------------------------------
# Start Job
#------------------------------------------------------------------------------
echo "$JOB_NAME.ksh started on `date +'%D %r'` Running Job" >> $LOG_FILE

#INPUT_FILE=process_pos_ej_E0140.dat
echo "Input file to process is : $INPUT_FILE" >> $LOG_FILE


cp $INPUT_FILE ORG_${RUN_DATE}_${INPUT_FILE}.BKP
RC=$?

if [ $RC -ne 0 ]
then
        echo "Backup of source file failed `date`" >> $LOG_FILE
        exit 1
else
        echo "Backup of source file Success `date`" >> $LOG_FILE
fi

awk -F'|' '{if ( length($4) < 10 ) print NR":"$0}' $INPUT_FILE > $AUDIT/corrupted_cdi_linkages.dat
RC=$?

if [ $RC -eq 0 -a -s $AUDIT/corrupted_cdi_linkages.dat ]
then
        echo "fetching corrupted records success `date`" >> $LOG_FILE
        
else
        echo "fetching corrupted records failed `date`" >> $LOG_FILE
		exit 1
fi

echo "\n\n" >> $LOG_FILE
cat $AUDIT/corrupted_cdi_linkages.dat >> $LOG_FILE
echo "\n\n" >> $LOG_FILE

awk -F'|' '{if ( length($4) < 10 ) print NR"d"}' $INPUT_FILE > $AUDIT/delete_invalid_rec.sed
RC=$?

if [ $RC -ne 0 ]
then
        echo "creation of delete_invalid_rec.sed failed `date`" >> $LOG_FILE
        exit 1
else
        echo "creation of delete_invalid_rec.sed success `date`" >> $LOG_FILE
fi


echo "\n\n" >> $LOG_FILE

sed -f $AUDIT/delete_invalid_rec.sed < ORG_${RUN_DATE}_${INPUT_FILE}.BKP > $INPUT_FILE

RC=$?

if [ $RC -ne 0 ]
then
        echo "Deletion of corrupted records -- creation of $INPUT_FILE failed `date`" >> $LOG_FILE
        exit 1
else
        echo "Deletion of corrupted records -- creation of $INPUT_FILE Success `date`" >> $LOG_FILE
fi

echo "$JOB_NAME.ksh ended on `date +'%D %r'`" >> $LOG_FILE
exit 0




#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Chirag Patel & Hal Hale
#  File name:        edw.bteq.after.ld.job.log.sh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-05-2008
#         |                                           |  C Patel   |
#---------+-------------------------------------------+------------+-----------
#   1.1   |  Modified - Remove Duplicates from source |  C Patel   | 07-14-2008
#---------+-------------------------------------------+------------+-----------

## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDDB=${4}
LOGDTLFILENAME=${5}
LOGDTLTABLE=${6}
EDWBATCHID=${7}
DSPROJECT=${8}
DSJOBNAME=${9}
DSJOBINVOCATION=${10}
LOGBTEQOUT=${11}
LOGFILE=${12}

echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "| `date +'%D %r'` STARTED edw.bteq.after.ld.job.log.sh            *" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo " "                                                                   >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  => DataStage Job Name= "$DSJOBNAME                                >> $LOGFILE
echo "*  => Job Invocation ID = "DSJOBINVOCATION                           >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  =>TDSERVER       = "$TDSERVER                                     >> $LOGFILE
echo "*  =>TDUSER         = "$TDUSER                                       >> $LOGFILE
echo "*  =>TDPWD          = xxxxxxxx"                                      >> $LOGFILE
echo "*  =>TDDB           = "$TDDB                                         >> $LOGFILE
echo "*  =>LOGDTLFILENAME = "$LOGDTLFILENAME                               >> $LOGFILE
echo "*  =>LOGDTLTABLE    = "$LOGDTLTABLE                                  >> $LOGFILE
echo "*  =>EDWBATCHID     = "$EDWBATCHID                                   >> $LOGFILE
echo "*  =>DSPROJECT      = "$DSPROJECT                                    >> $LOGFILE
echo "*  =>LOGBTEQOUT     = "$LOGBTEQOUT                                   >> $LOGFILE
echo "*  =>LOGFILE        = "$LOGFILE                                      >> $LOGFILE

*************************************************************
#           REMOVE DUPLICATES FROM SOURCE DATA              #

REMDUPLOGDTLFILENAME=${LOGDTLFILENAME}_REMDUP
sort -d -u $LOGDTLFILENAME > $REMDUPLOGDTLFILENAME

#                                                           #
*************************************************************

## INITIATE BTEQ SESSION AND INSERT JOB LOG DETAILS FOR THE CURRENT JOB.

  > $LOGBTEQOUT

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "$LOGBTEQOUT"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  Action.importFileName = "$REMDUPLOGDTLFILENAME"
  ImportOptions.type = "VARTEXT"
  ImportOptions.separator ="\u00C7"
  Action.repeatCount = None
  executeSql([
    ["projname", 30],
    ["batchid", 18],
    ["jobname", 50],
    ["jobinvocation", 50],
    ["eventmsg", 2000],
    ["eventuser", 30],
    ["eventtype", 1],
    ["eventdttm", 19]], [
    ("INSERT INTO $TDDB.$LOGDTLTABLE (proj_name,edw_batch_id,job_name,job_invocation_id,evt_msg,evt_user,evt_type_cd,evt_dttm)
      VALUES
    (
      ?,
      ?,
      ?,
      ?,
      ?,
      ?,
      ?,
      ?
    )",
      ["""projname"""
      , """batchid"""
      , """jobname"""
      , """jobinvocation"""
      , """eventmsg"""
      , """eventuser"""
      , """eventtype"""
      , """eventdttm"""])
  ])
  #-- LOCKING ROW FOR ACCESS 
  executeSql([], [
    ("SELECT TRIM(count(*))  as "" FROM $TDDB.$LOGDTLTABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCATION'",
    [])
  ])
  #-- LOCKING - comment out locking clause
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  Action.exportFileName = None
  return

main()
cleanup()
done()
EOF

## VERIFY JOB LOG DETAILS HAVE BEEN INSERTED TO DATABASE ##

  if [ `cat $LOGBTEQOUT | tr -d ' '` = `cat $REMDUPLOGDTLFILENAME | wc -l | tr -d ' '` ]
    then
rm $LOGBTEQOUT;
rm $LOGDTLFILENAME;
rm $REMDUPLOGDTLFILENAME;
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                        ( SUCCESS )                              *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED edw.bteq.after.ld.job.log.sh           *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
exit 0;
    else
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                      (FAILED)                                   *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED edw.bteq.after.ld.job.log.sh           *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|  Process will continue to the next step.  Notice that records   *" >> $LOGFILE
ech0 "|  may have been dropped due to duplicate records in source data. *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
      exit 1;
  fi

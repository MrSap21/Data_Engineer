#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw.bteq.dates.sh
#  Date:             09-04-2009
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 06-11-2009
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------


## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDDBNAME=${4}
LOGBTEQOUT=${5}
LOGFILE=${6}



## INITIATE BTEQ SESSION AND TAKE COUNT

  > $LOGBTEQOUT

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "$LOGBTEQOUT"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    ("insert into $TDDBNAME.Cdi2_hh_Queue_ctl_table
select 
current_date,
max(Listener_dt)+1,
'N',
'N',
'N'
from
$TDDBNAME.Cdi2_hh_Queue_ctl_table where 
Processed_Ind='Y'",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("delete from $TDDBNAME.Cdi2_hh_Queue_ctl_table where listener_dt is null",
    [])
  ])
  #-- DEL_STATEMENT - Replace DEL with DELETE
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("select 
cast (min(Listener_dt) as varchar(10))||' 00:00:00.00000'||'|'||cast (min(Listener_dt) as varchar(10))||' 23:59.59.99999'||'|'  as ""
from $TDDBNAME.Cdi2_hh_Queue_ctl_table where processed_ind='N'",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (Action.errorCode != 0):
    FAILURE()
    return
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return
  FAILURE()
def FAILURE():
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ] 
 then
    exit 1
else
cat $LOGBTEQOUT|read dates
RC=$?
if [ $RC -ne 0 ] 
then
       exit 1
 else
rm $LOGBTEQOUT
RC=$?
if [ $RC -ne 0 ] 
then
exit 1
else
print $dates;
exit 0
fi
fi
fi
    

#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw_cdi_delqtbl.ksh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 06-11-2009
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------

if [[ `uname -n` == "dedwbt01" ]]
then
	ENVR="tst"
	DS_PROJECT="EDW_CDI2_tst"
else
	ENVR="prd2"
	DS_PROJECT="EDW_CDI2_prd"
fi

## SET SCRIPT PARAMETERS

. /usr/local/edw/edwcdi/${ENVR}/common/scripts/edw_cdi_config.ksh $DS_PROJECT

LOGFILE=$APP_ROOT/audit/Physical.log.`date +%m%d%H%M`

## INITIATE BTEQ SESSION AND TAKE COUNT

  > $LOGBTEQOUT

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  executeSql([], [
    ("update prdetl.cdi2_key3 set flg1=1 where flg1=0",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("UPDATE prdetl.cdi2_key3 A
set flg2=b.cnt
FROM    (select eid,count(*) cnt from (select eid,aa_id from  prdetl.cdi2_key3 where aa_id is not null and eid is not null group by 1,2) a
group  by 1
having count(*)>1) b
where a.eid=b.eid and a.eid is not null",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- SYN_HAVING - Reformat syntax HAVING
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_key3 set flg2=1 where flg2=0",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("UPDATE prdetl.cdi2_key3 A
set flg3=b.cnt
FROM    (select es_id,count(*) cnt from (select eid,es_id from  prdetl.cdi2_key3 where eid is not null and es_id is not null group by 1,2) a
group  by 1
having count(*)>1) b
where a.es_id=b.es_id and a.es_id is not null",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- SYN_HAVING - Reformat syntax HAVING
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_key3 set flg3=1 where flg3=0",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("UPDATE prdetl.cdi2_key3 A
set flg4=b.cnt
FROM    (select es_id,count(*) cnt from (select aa_id,es_id from  prdetl.cdi2_key3 where aa_id is not null and es_id is not null group by 1,2) a
group  by 1
having count(*)>1) b
where a.es_id=b.es_id and a.es_id is not null",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- SYN_HAVING - Reformat syntax HAVING
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_key3 set flg4=1 where flg4=0",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("UPDATE prdetl.cdi2_key3 A
set flg5=b.cnt
FROM    (select aa_id,count(*) cnt from (select aa_id,es_id from  prdetl.cdi2_key3 where aa_id is not null and es_id is not null group by 1,2) a
group  by 1
having count(*)>1) b
where a.aa_id=b.aa_id and a.aa_id is not null",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- SYN_HAVING - Reformat syntax HAVING
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_key3 set flg5=1 where flg5=0",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("UPDATE prdetl.cdi2_key3 A
set flg6=b.cnt
FROM    (select aa_id,count(*) cnt from (select eid,aa_id from  prdetl.cdi2_key3 where eid is not null and aa_id is not null group by 1,2) a
group  by 1
having count(*)>1) b
where a.aa_id=b.aa_id and a.aa_id is not null",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- SYN_HAVING - Reformat syntax HAVING
  #-- UPD_ALIAS_STATEMENT - Reformat UPDATE-FROM-SET to UPDATE-SET-FROM
  #-- UPD_ALIAS_STATEMENT - Replace UPDATE <alias> with UPDATE <table_name> and/or <alias>
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_key3 set flg6=1 where flg6=0",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_key3 set flg7='Y' where eid  in (select a.eid from (
select eid from  prdetl.cdi2_key3
group by 1
having count(*)=1
qualify row_number() over (order by eid)<=28514318) a) and eid is not null",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("update prdetl.cdi2_key3 set flg7='Y' where eid  in (select a.eid from (
select eid from  prdetl.cdi2_key3
group by 1
having count(*)=1
qualify row_number() over (order by eid)>28514318) a) and eid is not null",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- SYN_HAVING - Reformat syntax HAVING
  if (Action.errorCode != 0):
    FAILURE()
    return
  Action.errorCodeOverride = 0
  return
  FAILURE()
def FAILURE():
  Action.errorCodeOverride = 1
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ] 
 then
    exit 1
else
exit 0
fi

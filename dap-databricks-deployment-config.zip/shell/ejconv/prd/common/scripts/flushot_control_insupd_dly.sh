#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           satish
#  File name:        flushot_control_insupd_dly.sh
#  Date:             18-10-2010
#  Description:      This script would update and insert giftcard_ctl_dw table.

#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  satish    | 18-10-2010
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------

## SET SCRIPT PARAMETERS


if [[ `uname -n` == "dedwbt01" ]]
then 
ENVR="dev"
DS_PROJECT="edw_ejc_dev"
else
ENVR="prd"
DS_PROJECT="edw_ejc_prd"
fi

## SET SCRIPT PARAMETERS


TDSERVER=$1
TDUSER=$2
TDPWD=$3
TDDB=$4


LOGFILE=/usr/local/edw/ejconv/${ENVR}/flushot/flulog/fluwcarddailyproclogfinal.log.`date +%m%d%H%M%S`

touch $LOGFILE ;

echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "|`date +'%D %r'` STARTED flushot_control_insupd_dly.sh                 *" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo " "                                                                   >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  => DataStage Job Name= "$DSJOBNAME                                >> $LOGFILE
echo "*  => Job Invocation ID = "DSJOBINVOCATION                           >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  =>TDSERVER	 = "$TDSERVER          	                           >> $LOGFILE
echo "*  =>TDUSER	 = "$TDUSER                                        >> $LOGFILE
echo "*  =>TDPWD	 = "********                                       >> $LOGFILE
echo "*  =>TDDB	 = "$TDDB                                      >> $LOGFILE


python3 <<EOF>>$LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  #--.set echoreq off;
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  executeSql([], [
    ("""update	$TDDB.giftcard_ctl_dw  
set	 Processed_Ind='Y' 
	,EDW_PROCESS_DT=Current_Date  
where	Stg_Insrt_Dt= (
select	TRIM(max(Stg_Insrt_Dt))  as ""  
from	$TDDB.giftcard_ctl_dw where jobtype_ind='D' 
	and	processed_ind='N')""",
    [])
  ])
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (Action.errorCode == 0):
    test2()
    return
  test2()
def test2():
  executeSql([], [
    ("""Insert	into $TDDB.giftcard_ctl_dw (EDW_PROCESS_DT, Stg_Insrt_Dt, Processed_Ind,jobtype_ind)
select	Current_Date as "EDW_PROCESS_DT" , Max(Stg_Insrt_Dt) +   INTERVAL '1  day' as "Stg_Insrt_Dt",
		'N' as "Processed_Ind",'D' as "jobtype_ind"
From	$TDDB.giftcard_ctl_dw where jobtype_ind='D' 
	and	processed_ind='Y'""",
    [])
  ])
  #-- CAST_AS_INTERVAL - Reformat CAST AS INTERVAL
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode == 0):
    SUCCESS()
    return
  Action.errorCodeOverride = 3
  return
  SUCCESS()
def SUCCESS():
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ] 
 then
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                      (FAILED)                                   *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED flushot_control_insupd_dly.sh               *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
exit 1;
else
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                        ( SUCCESS )                              *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED flushot_control_insupd_dly.sh               *">>$LOGFILE
echo "*==================================================================" >> $LOGFILE

# rm -f $LOGFILE

exit 0;
fi


#!/bin/ksh

# global environment variable, should be called in each shell script 

# key vault
export KEY_VAULT_SECRET=<keyVaultSecret>
export KEY_VAULT_SCOPE=<keyVaultScope>
export KEY_VAULT_SECRET_SFPASSWORD=<keyVaultSecret_sfPassword>

# snowflake
export SF_USER_NAME=<sfUser>
export SF_USER_PWD=<sfPassword>
export SF_ACCOUNT_NAME=<sfAccount>
export SF_WAREHOUSE_NAME=<sfWarehouse>
export SF_DATABASE_NAME=<sfDatabase>
export SF_SCHEMA_NAME=<sfSchema>
export SF_CONNECTION_STRING=<sfUrl>

# path to storage
export EDWPROJ=ejconv
export EDWROOT=/dbfs/mnt/wrangled
#export EDWROOT=
export ENVR=prd

# path to dbfs
export DBFSROOT=/dbfs/FileStore/apps

# databricks REST API
export DATABRICKS_INSTANCE=<databricks_instance>
export GET_STAT_TIMEOUT=600


#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Satish 
#  File name:        edw_cdi_delqtbl.ksh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 06-11-2009
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------

if [[ `uname -n` == "dedwbt01" ]]
then
	ENVR="dev"
	DS_PROJECT="edw_ejc_dev"
else
	ENVR="prd"
	DS_PROJECT="edw_ejc_prd"
fi

## SET SCRIPT PARAMETERS

. /usr/local/edw/ejconv/${ENVR}/common/scripts/edw_cdi_config.ksh $DS_PROJECT

LOGFILE=/usr/local/edw/ejconv/${ENVR}/flushot/flulog/flushotcleanup.log.`date +%m%d%H%M`

exec >  $LOGFILE 2>&1

LOGBTEQOUT=/usr/local/edw/ejconv/${ENVR}/flushot/flulog/flushotStage.Data.`date +%m%d%H%M`

## INITIATE BTEQ SESSION AND TAKE COUNT

  > $LOGBTEQOUT

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  #-- .set echoreq off;
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "$LOGBTEQOUT"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    ("""select * from $TD_FLUCNTRL_DB.giftcard_ctl_dw where Stg_Insrt_Dt <= (select max(Stg_Insrt_Dt) from 
$TD_FLUCNTRL_DB.giftcard_ctl_dw where processed_ind='Y' and jobtype_ind='D' and Stg_Insrt_Dt < dateadd(day, -30, current_date))
union
select * from $TD_FLUCNTRL_DB.giftcard_ctl_dw where adweek_enddt <= (select max(adweek_enddt) from 
$TD_FLUCNTRL_DB.giftcard_ctl_dw where processed_ind='Y' and jobtype_ind='W' and adweek_enddt<dateadd(day, -60, current_date))""",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("""delete from $TD_FLUCNTRL_DB.giftcard_ctl_dw where Stg_Insrt_Dt <= (select max(Stg_Insrt_Dt)  from 
$TD_FLUCNTRL_DB.giftcard_ctl_dw where processed_ind='Y' and jobtype_ind='D' and Stg_Insrt_Dt<dateadd(day, -30, current_date))""",
    [])
  ])
  #-- DEL_STATEMENT - Replace DEL with DELETE
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("""delete from $TD_FLUCNTRL_DB.giftcard_ctl_dw where adweek_enddt <= (select max(adweek_enddt)  from 
$TD_FLUCNTRL_DB.giftcard_ctl_dw where processed_ind='Y' and jobtype_ind='W' and adweek_enddt<dateadd(day, -60, current_date))""",
    [])
  ])
  #-- DEL_STATEMENT - Replace DEL with DELETE
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode != 0):
    FAILURE()
    return
  Action.errorCodeOverride = 0
  return
  FAILURE()
def FAILURE():
  Action.errorCodeOverride = 1
  return

main()
cleanup()
done()
EOF

SourceDir="/usr/local/edw/ejconv/${ENVR}/flushot/flulog"
cd $SourceDir

filecount=`find $SourceDir -type f -mtime +7 -exec ls -1 {} \; | wc -l | awk '{print $1}'`
echo "Number of files candidate for cleanup in $SourceDir is: " $filecount >> $LOGFILE
if [ $filecount -ne 0 ]
then
echo "List of Files candidate for clean up is: \n `find $SourceDir -type f -mtime +7  -exec ls -1 {} \;`" >> $LOGFILE
for  filename in `find $SourceDir -type f -mtime +7 -exec ls -1 {} \;`
do
rm $filename  
echo $filename >> $LOGFILE

CmdOut=$?
        if [ CmdOut -eq 0 ]
        then
        echo "File $filename Present in $SourceDir removed successfully " >> $LOGFILE
        else
        echo " cleanup of File $filename Present in $SourceDir failed. Exiting the Script " >> $LOGFILE
        exit 1
        fi  
done

else
     echo "There is no file present in $SourceDir to be cleanup." >> $LOGFILE
fi

SourceDir2="/usr/local/edw/ejconv/${ENVR}/flushot/archive"
cd $SourceDir2

filecount=`find $SourceDir2 -type f -mtime +30 -name 'DAILY*' -exec ls -1 {} \; | wc -l | awk '{print $1}'`
echo "Number of files candidate for cleanup in $SourceDir2 is: " $filecount >> $LOGFILE
if [ $filecount -ne 0 ]
then
echo "List of Files candidate for clean up is: \n `find $SourceDir2 -type f -mtime +30 -name 'DAILY*' -exec ls -1 {} \;`" >> $LOGFILE
for  filename in `find $SourceDir2 -type f -mtime +30 -name 'DAILY*' -exec ls -1 {} \;`
do
rm $filename  
CmdOut=$?
        if [ CmdOut -eq 0 ]
        then
        echo "File $filename Present in $SourceDir2 removed successfully " >> $LOGFILE
        else
        echo " cleanup of File $filename Present in $SourceDir2 failed. Exiting the Script " >> $LOGFILE
        exit 1
        fi  
done

else
     echo "There is no file present in $SourceDir2 to be cleanup." >> $LOGFILE
fi

SourceDir2="/usr/local/edw/ejconv/${ENVR}/flushot/archive"
cd $SourceDir2

filecount=`find $SourceDir2 -type f -mtime +60 -name 'ADWK*' -exec ls -1 {} \; | wc -l | awk '{print $1}'`
echo "Number of files candidate for cleanup in $SourceDir2 is: " $filecount >> $LOGFILE
if [ $filecount -ne 0 ]
then
echo "List of Files candidate for clean up is: \n `find $SourceDir2 -type f -mtime +60 -name 'ADWK*' -exec ls -1 {} \;`" >> $LOGFILE
for  filename in `find $SourceDir2 -type f -mtime +60 -name 'ADWK*' -exec ls -1 {} \;`
do
rm $filename  
CmdOut=$?
        if [ CmdOut -eq 0 ]
        then
        echo "File $filename Present in $SourceDir2 removed successfully " >> $LOGFILE
        else
        echo " cleanup of File $filename Present in $SourceDir2 failed. Exiting the Script " >> $LOGFILE
        exit 1
        fi  
done

else
     echo "There is no file present in $SourceDir2 to be cleanup." >> $LOGFILE
fi




RC=$?
if [ $RC -eq 0 ] 
 then

echo "***************************************************************************************" >> $LOGFILE
echo "************************  SCRIPT ENDED SUCCESSFULLY************************************" >> $LOGFILE
echo "***************************************************************************************" >> $LOGFILE
exit 0
else
echo "***************************************************************************************" >> $LOGFILE
echo "************************  SCRIPT FAILED ***********************************************" >> $LOGFILE
echo "***************************************************************************************" >> $LOGFILE
exit 1
fi

#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw.loyalty.sftp.sh 
#  Date:             07-22-2009
#  Description:      FTP output extract
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         | P Sarker   | 07-22-2009
#---------+-------------------------------------------+------------+-----------
if [[ `uname -n` == "dedwbt01" ]]
then
	ENVR="tst"
	DS_PROJECT="edw_ejc_tst"
else
	ENVR="prd"
	DS_PROJECT="edw_ejc_prd"
fi



. /usr/local/edw/ejconv/${ENVR}/common/scripts/edw_cdi_config.ksh $DS_PROJECT

TARGET_BOX=${APP_TGT_BOX1}
SOURCE_BOX=`uname -n`

FTP_USER="ejmbsftp"

SOURCE_DIR=$APP_ROOT/output
TARGET_DIR=${APP_TGT_LY_DIR}

cd $SOURCE_DIR

SOURCE_DATA_FILE1=`ls -rt WAG_EDW_LOC_????????_??????.dat|tail -1`
SOURCE_DATA_FILE2=`ls -rt WAG_EDW_LOC_????????_??????.ok|tail -1`
SOURCE_DATA_FILE3=`ls -rt WAG_EDW_MIS_????????_??????.dat|tail -1`
SOURCE_DATA_FILE4=`ls -rt WAG_EDW_MIS_????????_??????.ok|tail -1`
LOGFILE=$APP_ROOT/audit/EJftply.log.`date +%m%d%H%M`
ERR_FILE=$APP_ROOT/audit/EJftply.err.`date +%m%d%H%M`
TEMP_FILE=$APP_ROOT/audit/EJ.ftp_resultsly
SCR_DIR="/usr/local/edw/ejconv/${ENVR}/common/scripts/"


 # ${SCR_DIR}Ftp_File_Date_Chk.sh $SOURCE_DATA_FILE1 $LOGFILE
 # if [ $? -ne 0 ] 
 #then exit -10
 #fi

 #${SCR_DIR}Ftp_File_Date_Chk.sh $SOURCE_DATA_FILE2 $LOGFILE

 #if [ $? -ne 0 ] 
 #then exit -10
 #fi

 #${SCR_DIR}Ftp_File_Date_Chk.sh $SOURCE_DATA_FILE3 $LOGFILE

 #if [ $? -ne 0 ] 
 #then exit -10
 #fi

 #${SCR_DIR}Ftp_File_Date_Chk.sh $SOURCE_DATA_FILE4 $LOGFILE

 #if [ $? -ne 0 ] 
 #then exit -10
 #fi

sftp ${FTP_USER}@${TARGET_BOX} <<-ENDFTP >$TEMP_FILE 2>>$ERR_FILE
        cd $TARGET_DIR
        pwd
        mput  $SOURCE_DATA_FILE1
        mput  $SOURCE_DATA_FILE2
        mput  $SOURCE_DATA_FILE3
        mput  $SOURCE_DATA_FILE4
        quit
ENDFTP
FTP_GET_RC=$?


echo "*************************************************************" >> $LOGFILE
echo "*  FTP Retrieval Results log                                *" >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo " "  >> $LOGFILE
cat $TEMP_FILE >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo "*  FTP Retrieval Error log (If applicable)                  *" >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo " "  >> $LOGFILE
cat $ERR_FILE >> $LOGFILE
echo " "  >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo " "  >> $LOGFILE
rm $ERR_FILE $TEMP_FILE 
echo "#############################################" >> $LOGFILE
echo "#  End   FTP `date +'%D %r'`           #" >> $LOGFILE
echo "#  Return Code = $FTP_GET_RC                          #" >> $LOGFILE
echo "#############################################" >> $LOGFILE


#----------------------------------------------------------------------
# Check for FTP errors
#----------------------------------------------------------------------
if [ $FTP_GET_RC -ne 0 ]
then
        echo "#############################################" >> $LOGFILE
        echo "#      F T P      F A I L E D               #" >> $LOGFILE
        echo "#############################################" >> $LOGFILE
	exit $FTP_GET_RC
fi
echo "#############################################" >> $LOGFILE
echo "#      F T P      C O M P L E T E           #" >> $LOGFILE
echo "#############################################" >> $LOGFILE

exit 0

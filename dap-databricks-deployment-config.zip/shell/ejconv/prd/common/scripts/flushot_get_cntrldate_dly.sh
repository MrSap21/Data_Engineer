#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           satish
#  File name:        flushot_get_cntrlDate_dly.sh
#  Date:             18-10-2010
#  Description:      This job would retrieve control date for daily load.
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  satish    | 18-10-2010
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------

## SET SCRIPT PARAMETERS


if [[ `uname -n` == "dedwbt01" ]]
then 
ENVR="dev"
DS_PROJECT="edw_ejc_dev"
else
ENVR="prd"
DS_PROJECT="edw_ejc_prd"
fi

## SET SCRIPT PARAMETERS


TDSERVER=$1
TDUSER=$2
TDPWD=$3
TDDB=$4


if [ -s /usr/local/edw/ejconv/${ENVR}/flushot/flulog/wcardfludailyfinal.txt -o -a /usr/local/edw/ejconv/${ENVR}/flushot/flulog/wcardfludailyfinal.txt ]
then
rm -f /usr/local/edw/ejconv/${ENVR}/flushot/flulog/wcardfludailyfinal.txt
fi

LOGFILE=/usr/local/edw/ejconv/${ENVR}/flushot/flulog/wcardfludailylogfinalxx.log.`date +%m%d%H%M%S`

touch $LOGFILE ;

echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "|`date +'%D %r'` STARTED flushot_get_cntrlDate_dly.sh                 *" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo " "                                                                   >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  => DataStage Job Name= "$DSJOBNAME                                >> $LOGFILE
echo "*  => Job Invocation ID = "DSJOBINVOCATION                           >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  =>TDSERVER	 = "$TDSERVER          	                           >> $LOGFILE
echo "*  =>TDUSER	 = "$TDUSER                                        >> $LOGFILE
echo "*  =>TDPWD	 = "********                                       >> $LOGFILE
echo "*  =>TDDB	 = "$TDDB                                      >> $LOGFILE



## INITIATE BTEQ SESSION AND INSERT ##


## INITIATE BTEQ SESSION AND TAKE COUNT


python3 <<EOF>>$LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  #--.set echoreq off;
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = f"""/usr/local/edw/ejconv/${ENVR}/flushot/flulog/wcardfludailyfinal.txt"""
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    ("""select TRIM(max(Stg_Insrt_Dt))  as ""  from $TDDB.giftcard_ctl_dw where jobtype_ind='D' and processed_ind='N'""",
    [])
  ])
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (Action.errorCode == 0):
    SUCCESS()
    return
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  SUCCESS()
def SUCCESS():
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF


cd /usr/local/edw/ejconv/${ENVR}/flushot/flulog
StgInsertDt=$(cat -s `find . -type f -name wcardfludailyfinal.txt | awk -F"/" '{print $2}'`) 
echo -n ${StgInsertDt}

RC=$?
if [ $RC -ne 0 ] 
 then
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                      (FAILED)                                   *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED flushot_get_cntrlDate_dly.sh               *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
exit 1;
else
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******        Log Events   Level logging to                  *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                        ( SUCCESS )                              *" >> $LOGFILE
echo "| `date +'%D %r'` FINISHED flushot_get_cntrlDate_dly.sh               *">>$LOGFILE
echo "*==================================================================" >> $LOGFILE

#rm -f $LOGFILE

exit 0;
fi

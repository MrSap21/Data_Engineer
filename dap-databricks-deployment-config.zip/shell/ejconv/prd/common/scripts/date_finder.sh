######################################################################################################
######################Script Developed by Sahil Malhotra##############################################
##Purpose: this Script is used to determine the start_dt and Run_dt from the file. If file is not#####
##	     present, It calculates the start_dt and end_dt from the current_dt			 #####
######################################################################################################
######################################################################################################	    



dr=$1   
diff1=$2	
diff2=$3
source=$4

cd $dr
if [ $? -ne 0 ]
	then
		echo "Error in changing Directory" please check the Directory..
		exit -10
fi


if [ -f ./${source}_run_date ]   #check for run_date file
then 

	if [ `cat ./${source}_run_date|awk -F"|" '{ print NF }'` -lt 2 ] 
		then echo "Exit:Dates present in the file are not in correct format enter as: start_dt|end_dt "
			exit -10
		else break
	fi

else 
	

day=`date +%d`
month=`date +%m`
year=`date +%Y`

day=`echo $day-$diff1|bc`
if [ $day -lt 1 ]
	then
		month=`echo $month-1|bc`
			if [ $month -eq 0 ]
				then 
					year=`expr $year - 1`
					month=12
			fi
		day=`expr $day - 1`
		day=`cal $month $year|grep .|fmt -1|tr -d " "|tail $day|head -1`
	
fi

if [ $month -lt 10 -a `echo $month|wc -c` -lt 3 ]	
	then 
		month="0"$month
fi

if [ $day -lt 10 ]
	then 
		day="0"$day
fi

start_dt=$year"-"$month"-"$day


day=`date +%d`
month=`date +%m`
year=`date +%Y`

day=`echo $day-$diff2|bc`
if [ $day -lt 1 ]
	then
		month=`echo $month-1|bc`
			if [ $month -eq 0 ]
				then 
					year=`expr $year - 1`
					month=12
			fi
		day=`expr $day - 1`
		day=`cal $month $year|grep .|fmt -1|tr -d " "|tail $day|head -1`
	
fi


if [ $day -lt 10 ]
	then 
		day="0"$day
fi
if [ $month -lt 10 -a `echo $month|wc -c` -lt 3 ]	
	then 
		month="0"$month
fi

end_dt=$year"-"$month"-"$day


echo $start_dt"|"$end_dt > ./${source}_run_date
fi

cat ./${source}_run_date

#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Chirag Patel & Hal Hale
#  File name:        edw.bteq.before.ld.strt.status.sh 
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-05-2008
#         |                                           |  C Patel   |
#---------+-------------------------------------------+------------+-----------
#   1.1   |  Modified for JOB EXECUTION CONTROL.      |  C Patel   | 07-11-2008
#---------+-------------------------------------------+------------+-----------


## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDDB=${4}
JOBEXECTABLE=${5}
JOBLOGTABLE=${6}
JOBSTAGETABLE=${7}
JOBLINKTABLE=${8}
EDWBATCHID=${9}
DSPROJECT=${10}
DSJOBNAME=${11}
DSJOBINVOCNAME=${12}
BTEQOUTDIR=${13}
LOGFILE=${14}
TDDBVIEW=prdedwvw

JOBSTARTDTTM=`date +"%C%y-%m-%d %H:%M:%S"`
JOBFINISHDTTM="1800-01-01 00:00:00"
BTEQOUTFILE=$BTEQOUTDIR/$DSJOBNAME.$DSJOBINVOCNAME.bteq.out.`date +%m%d%H%M%S`

RUNSTATUS=0

echo "*==================================================================" >> $LOGFILE
echo "| BEFORE JOB EXECUTION BTEQ SCRIPT.#####                          *" >> $LOGFILE
echo "| `date +'%D %r'` START edw.bteq.before.ld.strt.status.sh           *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo " "                                                                   >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE
echo "| Initiate the DataStage job by enterint a record into the        *" >> $LOGFILE
echo "| Process Control table ( Job ecxecutuion Details).               *" >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  => DataStage Job Name= "$DSJOBNAME                                >> $LOGFILE
echo "*  => Job Invocation ID = "$DSJOBINVOCNAME                           >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE
echo "*  =>TDSERVER       = "$TDSERVER                                     >> $LOGFILE
echo "*  =>TDUSER         = "$TDUSER                                       >> $LOGFILE
echo "*  =>TDPWD          = xxxxxxxx"                                      >> $LOGFILE
echo "*  =>TDDB           = "$TDDB                                         >> $LOGFILE
echo "*  =>JOBEXECTABLE   = "$JOBEXECTABLE                                 >> $LOGFILE
echo "*  =>JOBLOGTABLE    = "$JOBLOGTABLE                                  >> $LOGFILE
echo "*  =>JOBSTAGETABLE  = "$JOBSTAGETABLE                                >> $LOGFILE
echo "*  =>JOBLINKTABLE   = "$JOBLINKTABLE                                 >> $LOGFILE
echo "*  =>EDWBATCHID     = "$EDWBATCHID                                   >> $LOGFILE
echo "*  =>DSPROJECT      = "$DSPROJECT                                    >> $LOGFILE
echo "*  =>BTEQOUT        = "$BTEQOUT                                      >> $LOGFILE
echo "*  =>LOGFILE        = "$LOGFILE                                      >> $LOGFILE
echo "*  =>JOBSTARTDTTM   = "$JOBSTARTDTTM                                 >> $LOGFILE
echo "*  =>JOBFINISHDTTM  = "$JOBFINISHDTTM                                >> $LOGFILE
echo "*  =>LOGFILE        = "$LOGFILE                                      >> $LOGFILE
echo "*  =>BTEQOUTFILE    = "$BTEQOUTFILE                                  >> $LOGFILE
echo "*************************************************************"       >> $LOGFILE

## INITIATE BTEQ SESSION AND INSERT A JOB RUNNING STATUS RECORD FOR THE CURRENT JOB.
#. /usr/local/edw/edwcdi/prd2/common/scripts/globalConfig.sh
> $BTEQOUTFILE
python3 << EOF >> $LOGFILE
#import os
#import sys
#sys.path.append("/databricks/python3/lib/python3.7/site-packages")
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *
sys.path.append("/databricks/python3/lib/python3.7/site-packages")

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "$BTEQOUTFILE"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  #-- LOCKING ROW FOR ACCESS
  executeSql([], [
    ("""SELECT TRIM(job_stat_cd) as "" FROM $TDDBVIEW.$JOBEXECTABLE WHERE edw_batch_id=$EDWBATCHID AND proj_name='$DSPROJECT' AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME'""",
    [])
  ])
  #-- LOCKING - comment out locking clause
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (Action.activityCount > 0):
    CHCKSTAT()
    return
  executeSql([], [
    ("INSERT INTO $TDDB.$JOBEXECTABLE (proj_name,edw_batch_id,job_name,job_invocation_id,job_stat_cd,job_start_dttm,job_fnsh_dttm) VALUES ('$DSPROJECT','$EDWBATCHID','$DSJOBNAME','$DSJOBINVOCNAME','$RUNSTATUS','$JOBSTARTDTTM','$JOBFINISHDTTM')",
    [])
  ])
  if (Action.errorCode == 0):
    INSERTOK()
    return
  print("""INSERT OF JOB EXECUTION STATUS UNSUCCESSFUL""")
  Action.exportFileName = None
  Action.errorCodeOverride = 100
  return
  INSERTOK()
def INSERTOK():
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return
  CHCKSTAT()
def CHCKSTAT():
  Action.exportFileName = None
  Action.errorCodeOverride = 200
  return

main()
cleanup()
done()
EOF
BTEQ1_RC=$?
echo "BTEQ1_RC ="$BTEQ1_RC >> $LOGFILE
if [ $BTEQ1_RC -eq 0 ]
 then
  echo "*============================================================================" >> $LOGFILE
  echo "JOB HAS NOT BEEN EXECUTED FOR CURRENT BATCH "                                  >> $LOGFILE 
  echo "INSERTED JOB RUNNING STATUS RECORD"                                            >> $LOGFILE
  echo "RETURNING CONTROL TO JOB SEQUENCE"                                             >> $LOGFILE
  echo "*============================================================================" >> $LOGFILE
  exit 0
fi
if [ $BTEQ1_RC -eq 100 ]
 then
  echo "*============================================================================" >> $LOGFILE
  echo "JOB HAS NOT BEEN EXECUTED FOR CURRENT BATCH "                                  >> $LOGFILE
  echo "FAILURE UPON INSERTING JOB RUNNING STATUS RECORD"                              >> $LOGFILE
  echo "RETURNING CONTROL TO JOB SEQUENCE"                                             >> $LOGFILE
  echo "*============================================================================" >> $LOGFILE
  exit 1
fi
# cat $BTEQOUTFILE | read teststat
# echo "teststat = |"$teststat"|"

#if [ `cat $BTEQOUTFILE | tr -d ' '` = 3 ]
if [ `cat $BTEQOUTFILE | tr -d ' '` -ne 1 ] && [ `cat $BTEQOUTFILE | tr -d ' '` -ne 2 ]
  then
  echo "*============================================================================" >> $LOGFILE
  echo "JOB HAS BEEN EXECUTED FOR CURRENT BATCH "                                      >> $LOGFILE
  echo "JOB ABORTED LAST RUN FOR CURRENT BATCH AND REQUIRES RERUN"                     >> $LOGFILE
  echo "UPDATING JOB STATUS TO RUNNING STATUS"                                         >> $LOGFILE
  echo "RETURNING CONTROL TO JOB SEQUENCE"                                             >> $LOGFILE
  echo "*============================================================================" >> $LOGFILE

         > $BTEQOUTFILE
         python3 << EOF >> $LOGFILE
#import os
#import sys
#sys.path.append("/databricks/python3/lib/python3.7/site-packages")
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *
sys.path.append("/databricks/python3/lib/python3.7/site-packages")

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  FormatOptions.echoReqLevel = EchoReqLevel.ON
  Action.exportFileName = "$BTEQOUTFILE"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    ("UPDATE $TDDB.$JOBEXECTABLE SET job_stat_cd='$RUNSTATUS', job_start_dttm='$JOBSTARTDTTM',job_fnsh_dttm='$JOBFINISHDTTM' WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME'",
    [])
  ])
  if (Action.errorCode == 0):
    UPDATEOK()
    return
  print("""UPDATE OF JOB EXECUTION STATUS UNSUCCESSFUL""")
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  UPDATEOK()
def UPDATEOK():
  executeSql([], [
    ("DELETE FROM $TDDB.$JOBLOGTABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME'",
    [])
  ])
  if (Action.errorCode == 0):
    DELLOGOK()
    return
  print("""DELETE FROM LOG TABLE UNSUCCESSFUL""")
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  DELLOGOK()
def DELLOGOK():
  executeSql([], [
    ("DELETE FROM $TDDB.$JOBSTAGETABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME'",
    [])
  ])
  if (Action.errorCode == 0):
    DELSTAGEOK()
    return
  print("""DELETE FROM STAGE TABLE UNSUCCESSFUL""")
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  DELSTAGEOK()
def DELSTAGEOK():
  executeSql([], [
    ("DELETE FROM $TDDB.$JOBLINKTABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCNAME'",
    [])
  ])
  if (Action.errorCode == 0):
    DELLINKOK()
    return
  print("""DELETE FROM LINK TABLE UNSUCCESSFUL""")
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  DELLINKOK()
def DELLINKOK():
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF
  BTEQ2_RC=$?
  exit $BTEQ2_RC 

else
  echo "*============================================================================" >> $LOGFILE
  echo "JOB HAS BEEN EXECUTED FOR CURRENT BATCH "                                      >> $LOGFILE
  echo "JOB FINISHED SUCCESSFUL LAST RUN FOR CURRENT BATCH "                           >> $LOGFILE
  echo "JOB EXECUTION WILL BE BYPASSED "                                               >> $LOGFILE
  echo "RETURNING CONTROL TO JOB SEQUENCE"                                             >> $LOGFILE
  echo "*============================================================================" >> $LOGFILE
  exit 2
fi 

rm $BTEQOUTFILE
echo "*==================================================================" >> $LOGFILE
echo "| BEFORE JOB EXECUTION BTEQ SCRIPT.#########                      *" >> $LOGFILE
echo "| `date +'%D %r'` END edw.bteq.before.ld.strt.status.sh           *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE

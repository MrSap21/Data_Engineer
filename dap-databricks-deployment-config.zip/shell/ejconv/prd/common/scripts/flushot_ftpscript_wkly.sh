#!/bin/ksh
cleanup() {
  [[ -f $LOGFILE ]] && cp $LOGFILE $FLULOG && rm $LOGFILE
}
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Rajeev Kumar
#  File name:        edw_mnthly_ftpscript.ksh
#  Date:             11-03-2010
#  Description:      FTP output extract
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         | P Sarker   | 07-22-2009
#---------+-------------------------------------------+------------+-----------
# if [[ `uname -n` == "dedwbt01" ]]
# then
# 	ENVR="dev"
# 	DS_PROJECT="edw_ejc_dev"
# else
# 	ENVR="prd"
# 	DS_PROJECT="edw_ejc_prd"
# fi

ENVR="prd"
DS_PROJECT="edw_ejc_prd"

. $EDWROOT/usr/local/edw/ejconv/${ENVR}/common/scripts/edw_cdi_config.ksh $DS_PROJECT

TARGET_BOX=${APP_TGT_BOX1}
SOURCE_BOX=$(uname -n)

TDUSER=$TD_LTY_USER
TDPWD=$TD_LTY_PASSWORD
TDDB=$TD_FLUCNTRL_DB
TDSERVER=$TD_SERVER

FTP_USER="ejmbsftp"

SOURCE_DIR=$EDWROOT/usr/local/edw/ejconv/${ENVR}/flushot/dataset
TARGET_DIR=/ab/output/vendor_daysls/edw_src_trans_sls

FLULOG=$EDWROOT/usr/local/edw/ejconv/${ENVR}/flushot/flulog
LOGFILE=/tmp/FLUWeeklyftp.log.$(date +%m%d%H%M%S)
exec >$LOGFILE 2>&1

if [ -s $FLULOG/fluweeklyfinal_ftp.txt -o -f $FLULOG/fluweeklyfinal_ftp.txt ]; then
  rm -f $FLULOG/fluweeklyfinal_ftp.txt
fi

## INITIATE BTEQ SESSION AND TAKE LAST RUN DATE ##

python3 <<EOF >>$LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  #--.set echoreq off;
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = f"""$FLULOG/fluweeklyfinal_ftp.txt"""
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    ("""select TRIM(max(Adweek_EndDt))  as ""  from $TDDB.giftcard_ctl_dw where jobtype_ind='W' and processed_ind='Y'""",
    [])
  ])
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (Action.errorCode == 0):
    SUCCESS()
    return
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  SUCCESS()
def SUCCESS():
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

cd $FLULOG
MaxDt=$(cat -s $(find . -type f -name fluweeklyfinal_ftp.txt | awk -F"/" '{print $2}'))
export CURDT=$(echo $MaxDt | sed 's/-//g')

mv $SOURCE_DIR/ADWK-STR-GIFTCARD-UNITSSOLD.dat $SOURCE_DIR/ADWK-STR-GIFTCARD-UNITSSOLD_$CURDT.dat
mv $SOURCE_DIR/ADWK-STR-GIFTCARD-UNITSREDEEMED.dat $SOURCE_DIR/ADWK-STR-GIFTCARD-UNITSREDEEMED_$CURDT.dat
mv $SOURCE_DIR/ADWK-CHN-GIFTCARD-UNITSSOLD.dat $SOURCE_DIR/ADWK-CHN-GIFTCARD-UNITSSOLD_$CURDT.dat
mv $SOURCE_DIR/ADWK-CHN-GIFTCARD-UNITSREDEEMED.dat $SOURCE_DIR/ADWK-CHN-GIFTCARD-UNITSREDEEMED_$CURDT.dat

if [ $? -ne 0 ]; then
  cleanup
  exit -10
fi

SOURCE_DATA_FILE1=$(ls -rt $SOURCE_DIR/ADWK-STR-GIFTCARD-UNITSSOLD_????????.dat | tail -1)
SOURCE_DATA_FILE2=$(ls -rt $SOURCE_DIR/ADWK-STR-GIFTCARD-UNITSREDEEMED_????????.dat | tail -1)
SOURCE_DATA_FILE3=$(ls -rt $SOURCE_DIR/ADWK-CHN-GIFTCARD-UNITSSOLD_????????.dat | tail -1)
SOURCE_DATA_FILE4=$(ls -rt $SOURCE_DIR/ADWK-CHN-GIFTCARD-UNITSREDEEMED_????????.dat | tail -1)
ERR_FILE=$FLULOG/FLUWEEKLYftp.err.$(date +%m%d%H%M)
TEMP_FILE=$FLULOG/FLUWEEKLY.ftp_resultsflu
SCR_DIR="$EDWROOT/usr/local/edw/ejconv/${ENVR}/common/scripts/"

cd $SOURCE_DIR

#   ____NP_SKIP_SFTP____
# sftp ${FTP_USER}@${TARGET_BOX} <<-ENDFTP >$LOGFILE 2>>$LOGFILE
# cd $TARGET_DIR
# pwd
# put  $SOURCE_DATA_FILE1
# put  $SOURCE_DATA_FILE2
# put  $SOURCE_DATA_FILE3
# put  $SOURCE_DATA_FILE4
# chmod 775 ADWK*
# quit
# ENDFTP

FTP_GET_RC=$?

echo "*************************************************************" >>$LOGFILE
echo "*  FTP Retrieval Results log                                *" >>$LOGFILE
echo "*************************************************************" >>$LOGFILE
echo " " >>$LOGFILE
#cat $TEMP_FILE >> $LOGFILE
echo "*************************************************************" >>$LOGFILE
echo "*  FTP Retrieval Error log (If applicable)                  *" >>$LOGFILE
echo "*************************************************************" >>$LOGFILE
echo " " >>$LOGFILE
#cat $ERR_FILE >> $LOGFILE
echo " " >>$LOGFILE
echo "*************************************************************" >>$LOGFILE
echo " " >>$LOGFILE
#rm $ERR_FILE $TEMP_FILE
echo "#############################################" >>$LOGFILE
echo "#  End   FTP $(date +'%D %r')           #" >>$LOGFILE
echo "#  Return Code = $FTP_GET_RC                          #" >>$LOGFILE
echo "#############################################" >>$LOGFILE

#----------------------------------------------------------------------
# Check for FTP errors
#----------------------------------------------------------------------
if [ $FTP_GET_RC -ne 0 ]; then
  echo "#############################################" >>$LOGFILE
  echo "#      F T P      F A I L E D               #" >>$LOGFILE
  echo "#############################################" >>$LOGFILE
  cleanup
  exit $FTP_GET_RC
fi
echo "#############################################" >>$LOGFILE
echo "#      F T P      C O M P L E T E           #" >>$LOGFILE
echo "#############################################" >>$LOGFILE

echo "" >>$LOGFILE
echo "*******************************************************************************************" >>$LOGFILE
echo "********Archiving the Flu Data Set Files and Moving to the Archive Directory**************" >>$LOGFILE
echo "*******************************************************************************************" >>$LOGFILE
echo "" >>$LOGFILE

cd $SOURCE_DIR
ArchiveDir=$EDWROOT/usr/local/edw/ejconv/${ENVR}/flushot/archive

filecount=$(ls -l $SOURCE_DIR/ADWK* | wc -l)
echo "Number of files candidate for archiving in $SOURCE_DIR is: " $filecount >>$LOGFILE
if [ $filecount -ne 0 ]; then
  zip -j ADWK_FluShotFiles_$CURDT $SOURCE_DIR/ADWK* >>$LOGFILE
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Files Present in $SOURCE_DIR zipped successfully " >>$LOGFILE
  else
    echo " Archival of Files Present in $SOURCE_DIR failed. Exiting the Script " >>$LOGFILE
    cleanup
    exit 1
  fi

  mv ADWK_FluShotFiles_$CURDT.zip $ArchiveDir
  CmdOut=$?
  if [ CmdOut -eq 0 ]; then
    echo "Weekly Files Present in $SOURCE_DIR moved to Archive Folder successfully" >>$LOGFILE

    rm $SOURCE_DIR/ADWK*
    echo "Weekly Files Present in $SOURCE_DIR removed successfully " >>$LOGFILE

  else
    echo "Movement of Files Present in $SOURCE_DIR to Archival Directory Failed. Exiting the Script" >>$LOGFILE
    cleanup
    exit 1
  fi

else
  echo "There is no file present in $SOURCE_DIR to be archived." >>$LOGFILE
fi
cleanup
exit 0

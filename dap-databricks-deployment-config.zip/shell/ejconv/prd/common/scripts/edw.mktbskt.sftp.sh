#!/bin/ksh
cleanup(){
  [[ -f $LOGFILE ]] && cp $LOGFILE $AUDIT_DIR && rm $LOGFILE
  [[ -f $TDLOGFILE ]] && cp $TDLOGFILE $TERALOG && rm $TDLOGFILE
}
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw.mktbskt.sftp.sh
#  Date:             02-04-2010
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 02-04-2010
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------

# if [[ `uname -n` == "dedwbt01" ]]
# then
# 	ENVR="tst"
# 	DS_PROJECT="edw_ejc_tst"
# else
# 	ENVR="prd"
# 	DS_PROJECT="edw_ejc_prd"
# fi

ENVR="prd"
DS_PROJECT="edw_ejc_prd"

. $EDWROOT/usr/local/edw/ejconv/${ENVR}/common/scripts/edw_cdi_config.ksh $DS_PROJECT

## SET SCRIPT PARAMETERS

# TDSERVER=${TD_SERVER}
# TDUSER=${TD_USER}
# TDPWD=${TD_PASSWORD}
TERALOG=$EDWROOT/usr/local/edw/ejconv/${ENVR}/teralog
LOGBTEQOUT="$TERALOG/Mktbskt_date_"$(date +%Y%m%d)".txt"
TDLOGFILE="/tmp/Mktbskt_log_"$(date +%Y%m%d%H%M%S)".txt"

## INITIATE BTEQ SESSION AND TAKE COUNT

>$LOGBTEQOUT

python3 <<EOF >>$TDLOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "$LOGBTEQOUT"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    ("""select substr(to_date(calendar_date-3 ::VARCHAR(30), 'yyyy-mm-dd'),1,4)||
substr(to_date(calendar_date-3 ::VARCHAR(30), 'yyyy-mm-dd'),6,2)||substr(to_date(calendar_date-3 ::VARCHAR(30), 'yyyy-mm-dd'),9,2)   as ""
from 
sys_calendar.calendar where 
calendar_date=dateadd(day, -2, current_date) and day_of_week=3""",
    [])
  ])
  #-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (Action.errorCode == 0):
    SELECTOK()
    return
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  SELECTOK()
def SELECTOK():
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ]; then
  cleanup
  exit 1
else
  cat $LOGBTEQOUT | read dates
  rm $LOGBTEQOUT
  RC=$?
  if [ $RC -ne 0 ]; then
    cleanup
    exit 1
  else

    TARGET_BOX=${APP_TGT_BOX1}
    SOURCE_BOX=$(uname -n)

    FTP_USER="ejmbsftp"

    AUDIT_DIR=$EDWROOT$APP_ROOT/audit
    SOURCE_DIR=$EDWROOT$APP_ROOT/output
    TARGET_DIR1=/ab/input/wkmrkt_basket/$dates
    TARGET_DIR2=/ab/input/wkmrkt_basket
    SOURCE_DATA_FILE1="Market_Basket_extract.txt"
    SOURCE_SIG_FILE=$dates.sig
    LOGFILE=/tmp/EJftpmkb.log.$(date +%m%d%H%M)
    ERR_FILE=/tmp/EJftpmkb.err.$(date +%m%d%H%M)
    TEMP_FILE=/tmp/EJ.ftp_resultsmkb
    SCR_DIR="$EDWROOT/usr/local/edw/ejconv/${ENVR}/common/scripts/"

    cd $SOURCE_DIR

    wc -l $SOURCE_DATA_FILE1 | awk '{print $1}' >$SOURCE_SIG_FILE
    if [ $? -ne 0 ]; then
      cleanup
      exit -10
    fi

    ${SCR_DIR}Ftp_File_Date_Chk.sh $SOURCE_DATA_FILE1 $LOGFILE
    if [ $? -ne 0 ]; then
      exit -10
    fi
    echo ${FTP_USER}
    echo ${TARGET_BOX}
#   ____NP_SKIP_SFTP____
#     sftp ${FTP_USER}@${TARGET_BOX} <<-ENDFTP >$TEMP_FILE 2>>$ERR_FILE
#         cd $TARGET_DIR1
#         pwd
#         mput  $SOURCE_DATA_FILE1
#         cd $TARGET_DIR2
#         mput $SOURCE_SIG_FILE
#         quit
# ENDFTP
    FTP_GET_RC=$?

    echo "*************************************************************" >>$LOGFILE
    echo "*  FTP Retrieval Results log                                *" >>$LOGFILE
    echo "*************************************************************" >>$LOGFILE
    echo " " >>$LOGFILE
    cat $TEMP_FILE >>$LOGFILE
    echo "*************************************************************" >>$LOGFILE
    echo "*  FTP Retrieval Error log (If applicable)                  *" >>$LOGFILE
    echo "*************************************************************" >>$LOGFILE
    echo " " >>$LOGFILE
    cat $ERR_FILE >>$LOGFILE
    echo " " >>$LOGFILE
    echo "*************************************************************" >>$LOGFILE
    echo " " >>$LOGFILE
    rm $ERR_FILE $TEMP_FILE
    echo "#############################################" >>$LOGFILE
    echo "#  End   FTP $(date +'%D %r')           #" >>$LOGFILE
    echo "#  Return Code = $FTP_GET_RC                          #" >>$LOGFILE
    echo "#############################################" >>$LOGFILE

    #----------------------------------------------------------------------
    # Check for FTP errors
    #----------------------------------------------------------------------
    if [ $FTP_GET_RC -ne 0 ]; then
      echo "#############################################" >>$LOGFILE
      echo "#      F T P      F A I L E D               #" >>$LOGFILE
      echo "#############################################" >>$LOGFILE
      cleanup
      exit $FTP_GET_RC
    else
      mv $SOURCE_DATA_FILE1 $SOURCE_DATA_FILE1$(date +"%Y%m%d%H%M%S")
    fi
    echo "#############################################" >>$LOGFILE
    echo "#      F T P      C O M P L E T E           #" >>$LOGFILE
    echo "#############################################" >>$LOGFILE
    cleanup
    exit 0
  fi
fi

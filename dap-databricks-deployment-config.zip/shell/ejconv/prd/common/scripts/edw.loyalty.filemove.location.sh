#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw.mktbskt.sftp.sh
#  Date:             02-04-2010
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 02-04-2010
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------

OUTDIR=${1}


if [[ `uname -n` == "dedwbt01" ]]
then
	ENVR="tst"
	DS_PROJECT="edw_ejc_tst"
else
	ENVR="prd"
	DS_PROJECT="edw_ejc_prd"
fi



#. /usr/local/edw/ejconv/${ENVR}/common/scripts/edw_cdi_config.ksh $DS_PROJECT

export TGT_340B_DIR=/dbfs/mnt/wg-adslgen2-fs/usr/local/whsitbts/data/inbound/btsxedw
export CURDT=`date +%Y%m%d`_`date +%H%M%S`

mv $OUTDIR/WAG_EDW_LOC_YYYYMMDD_HHMMSS.dat $OUTDIR/WAG_EDW_LOC_`echo $CURDT`.dat

if [ $? -ne 0 ] 
then exit -10
fi

FILENAME=$OUTDIR/WAG_EDW_LOC_`echo $CURDT`.dat


wc -l $FILENAME|awk '{print $1}' > $OUTDIR/WAG_EDW_LOC_`echo $CURDT`.ok

if [ $? -ne 0 ] 
then exit -10
fi
cp $OUTDIR/WAG_EDW_LOC_`echo $CURDT`.dat $TGT_340B_DIR/WAG_EDW_LOC_`echo $CURDT`.dat

if [ $? -ne 0 ] 
then exit -10
fi

exit 0;



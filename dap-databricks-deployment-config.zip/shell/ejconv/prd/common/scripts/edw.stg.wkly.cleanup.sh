#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw_cdi_delqtbl.ksh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 06-11-2009
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------

if [[ `uname -n` == "dedwbt01" ]]
then
	ENVR="tst"
	DS_PROJECT="edw_ejc_tst"
else
	ENVR="prd"
	DS_PROJECT="edw_ejc_prd"
fi

## SET SCRIPT PARAMETERS

. /usr/local/edw/ejconv/${ENVR}/common/scripts/edw_cdi_config.ksh $DS_PROJECT


LOGFILE=$APP_ROOT/audit/EDWLoyaltycleanup.log.`date +%m%d%H%M`

LOGBTEQOUT=$APP_ROOT/archive/EDWLoyaltyStage.Data.`date +%m%d%H%M`

## INITIATE BTEQ SESSION AND TAKE COUNT

  > $LOGBTEQOUT

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "$LOGBTEQOUT"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    ("""select * from prdhubq.stg_loyaltyA where insert_dttm <= (select cast(max(Stg_Insrt_Dt) as varchar(10))||' 23:59:59.999'  max_tm from 
prdedwdb.Loyalty_ctl_table where processed_ind='Y' and a_delete_ind='N' and Stg_Insrt_Dt<dateadd(day, -7, current_date))
union
select * from prdhubq.stg_loyaltyB where insert_dttm <= (select cast(max(Stg_Insrt_Dt) as varchar(10))||' 23:59:59.999' max_tm from 
prdedwdb.Loyalty_ctl_table where processed_ind='Y' and b_delete_ind='N' and Stg_Insrt_Dt<dateadd(day, -7, current_date))""",
    [])
  ])
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("""delete from prdhubq.stg_loyaltyA where insert_dttm <= (select cast(max(Stg_Insrt_Dt) as varchar(10))||' 23:59:59.999' max_tm from 
prdedwdb.Loyalty_ctl_table where processed_ind='Y' and a_delete_ind='N' and Stg_Insrt_Dt<dateadd(day, -7, current_date))""",
    [])
  ])
  #-- DEL_STATEMENT - Replace DEL with DELETE
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("""update prdedwdb.Loyalty_ctl_table set a_delete_ind='Y' where processed_ind='Y' and a_delete_ind='N' and Stg_Insrt_Dt<dateadd(day, -7, current_date)""",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("""delete from prdhubq.stg_loyaltyB where insert_dttm <= (select cast(max(Stg_Insrt_Dt) as varchar(10))||' 23:59:59.999' max_tm from 
prdedwdb.Loyalty_ctl_table where processed_ind='Y' and b_delete_ind='N' and Stg_Insrt_Dt<dateadd(day, -7, current_date))""",
    [])
  ])
  #-- DEL_STATEMENT - Replace DEL with DELETE
  #-- SEL_STATEMENT - Replace SEL with SELECT
  if (Action.errorCode != 0):
    FAILURE()
    return
  executeSql([], [
    ("""update prdedwdb.Loyalty_ctl_table set b_delete_ind='Y' where processed_ind='Y' and b_delete_ind='N' and Stg_Insrt_Dt<dateadd(day, -7, current_date)""",
    [])
  ])
  if (Action.errorCode != 0):
    FAILURE()
    return
  Action.errorCodeOverride = 0
  return
  FAILURE()
def FAILURE():
  Action.errorCodeOverride = 1
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ] 
 then
    exit 1
else
exit 0
fi

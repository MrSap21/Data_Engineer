#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Pijush sarker
#  File name:        edw.bteq.dates.sh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  P Sarker  | 06-11-2009
#         |                                           |            |
#---------+-------------------------------------------+------------+-----------


## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
LOGBTEQOUT=${4}
LOGFILE=${5}



## INITIATE BTEQ SESSION AND TAKE COUNT

  > $LOGBTEQOUT

  python3 << EOF >> $LOGFILE
#import os
#import sys
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "$LOGBTEQOUT"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  executeSql([], [
    ("""select 
cast(a.mxdt as varchar(10)) || '|' || cast(a.mndt as varchar(10)) || '|' || cast(b.load_dttm as varchar(19)) || '|'||to_char(current_date ,'yyyy-mm-dd') || '|' || cast(current_time as varchar(8)) || '|'  as ""
from
(select to_date(max(calendar_date) ::VARCHAR(30), 'yyyy-mm-dd') mxdt,to_date(min(calendar_date) ::VARCHAR(30), 'yyyy-mm-dd') mndt from sys_calendar.calendar
where month_of_year=extract(month from add_months(current_date,-1) )
 and year_of_calendar=extract(year from add_months(current_date,-1) )  ) a,

(select cast(to_date(calendar_date ::VARCHAR(30), 'yyyy-mm-dd')||' 22:00:00' as timestamp(0)) load_dttm from 
sys_calendar.calendar where year_of_calendar=extract(year from add_months(current_date,-1) ) and 
month_of_year=extract(month from add_months(current_date,-1) ) and day_of_month=3) b""",
    [])
  ])
  #-- EXPR_FORMAT - Convert expression FORMAT/CAST_AS_FORMAT to TO_CHAR/TO_DATE
  #-- SEL_STATEMENT - Replace SEL with SELECT
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  if (Action.errorCode == 0):
    SELECTOK()
    return
  Action.exportFileName = None
  Action.errorCodeOverride = 1
  return
  SELECTOK()
def SELECTOK():
  Action.exportFileName = None
  Action.errorCodeOverride = 0
  return

main()
cleanup()
done()
EOF

RC=$?
if [ $RC -ne 0 ] 
 then
    exit 1
else
cat $LOGBTEQOUT|read dates
RC=$?
if [ $RC -ne 0 ] 
then
       exit 1
 else
rm $LOGBTEQOUT
RC=$?
if [ $RC -ne 0 ] 
then
exit 1
else
print $dates;
exit 0
fi
fi
fi
    

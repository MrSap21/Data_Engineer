#!/bin/ksh
DIR="$(cd "$(dirname "$0")" && pwd)"
. $DIR/globalConfig.sh
#------------------------------------------------------------------------------#
#                      (C) Copyright 2001, Walgreen Co.
#           Licensed Material - Program - Property of Walgreen Co.
#                             All Rights Reserved
#------------------------------------------------------------------------------#
#  Author:           Chirag Patel & Hal Hale
#  File name:        edw.bteq.after.ld.job.exec.sh
#  Date:             06-04-2008
#  Description:      Initiate Process Control for DataStage Jobs
#------------------------------------------------------------------------------
#                      M A I N T E N A N C E   H I S T O R Y
#------------------------------------------------------------------------------
# Revision|                Description                |    Name    | Date
#---------+-------------------------------------------+------------+-----------
#   1.0   |  Initial release.                         |  H Hale    | 06-05-2008
#         |                                           |  C Patel   |
#---------+-------------------------------------------+------------+-----------


## SET SCRIPT PARAMETERS

TDSERVER=${1}
TDUSER=${2}
TDPWD=${3}
TDDB=${4}
EXECFILENAME=${5}
EXECTABLE=${6}
EDWBATCHID=${7}
DSPROJECT=${8}
DSJOBNAME=${9}
DSJOBINVOCATION=${10}
EXECBTEQOUT=${11}
LOGFILE=${12}
TDDBVIEW=prdedwvw

echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******       JOB Execution   Level logging to                *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "| `date +'%D %r'` Start edw.bteq.after.ld.job.exec.sh       *" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
echo " " >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE
echo "| An attempt at executing  the job is complete.  The appropriate  *" >> $LOGFILE
echo "| job status will be recorded in the  Process Control table       *" >> $LOGFILE
echo "| (Job execution   Details).                                      *" >> $LOGFILE
echo "|                                                                 *" >> $LOGFILE
echo "*=================================================================*" >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo "*  => DataStage Job Name= "$DSJOBNAME >>$LOGFILE
echo "*  => Job Invocation ID = "$DSJOBINVOCATION >> $LOGFILE
echo "*************************************************************" >> $LOGFILE
echo "*  =>TDSERVER       = "$TDSERVER >> $LOGFILE
echo "*  =>TDUSER         = "$TDUSER >> $LOGFILE
echo "*  =>TDPWD          = xxxxxxxx" >> $LOGFILE
echo "*  =>TDDB           = "$TDDB >> $LOGFILE
echo "*  =>EXECFILENAME   = "$EXECFILENAME >> $LOGFILE
echo "*  =>EXECTABLE      = "$EXECTABLE >> $LOGFILE
echo "*  =>EDWBATCHID     = "$EDWBATCHID >> $LOGFILE
echo "*  =>DSPROJECT      = "$DSPROJECT >> $LOGFILE
echo "*  =>EXECBTEQOUT    = "$EXECBTEQOUT >> $LOGFILE
echo "*  =>LOGFILE        = "$LOGFILE >> $LOGFILE
echo "*************************************************************" >> $LOGFILE

## INITIATE BTEQ SESSION AND INSERT JOB EXEC DETAILS  FOR THE CURRENT JOB.

  > $EXECBTEQOUT
  python3 << EOF >> $LOGFILE
#import os
#import sys
#sys.path.append("/databricks/python3/lib/python3.7/site-packages")
#from npcommon import *
#from np_fastload import *
#from np_fexport import *
from npjet import *
sys.path.append("/databricks/python3/lib/python3.7/site-packages")

def main():
  FormatOptions.echoReqLevel = EchoReqLevel.OFF
  FormatOptions.titleDashes = TitleDashesLevel.ALL_OFF
  Action.exportFileName = "$EXECBTEQOUT"
  ExportOptions.colLimit = 100
  Action.charSet = "ISO-8859-1"
  Action.importFileName = "$EXECFILENAME"
  ImportOptions.type = "VARTEXT"
  ImportOptions.separator ="|"
  Action.repeatCount = None
  executeSql([
    ["projname", 30],
    ["batchid", 18],
    ["jobname", 50],
    ["jobinvocation", 50],
    ["jobstatus", 2],
    ["jobstartdttm", 19],
    ["jobfinishdttm", 19]], [
    ("""UPDATE $TDDB.$EXECTABLE
    SET
      proj_name=?,
      edw_batch_id=?,
      job_name=?,
      job_invocation_id=?,
      job_stat_cd=?,
      job_start_dttm=?,
      job_fnsh_dttm=?
    WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCATION'""",
      ["""projname"""
      , """batchid"""
      , """jobname"""
      , """jobinvocation"""
      , """jobstatus"""
      , """jobstartdttm"""
      , """jobfinishdttm"""])
  ])
  #-- LOCKING ROW FOR ACCESS 
  executeSql([], [
    ("""SELECT TRIM(count(*))  as "" FROM $TDDB.$EXECTABLE WHERE proj_name='$DSPROJECT' AND edw_batch_id=$EDWBATCHID AND job_name='$DSJOBNAME' AND job_invocation_id='$DSJOBINVOCATION'""",
    [])
  ])
  #-- LOCKING - comment out locking clause
  #-- TITLE_IN_SEL - Remove TITLE <string> in SELECT statement
  Action.exportFileName = None
  return

main()
cleanup()
done()
EOF

## VERIFY JOB EXECUTION DETAILS HAVE BEEN INSERTED TO DATABASE
  if [ `cat $EXECBTEQOUT | tr -d ' '` = `cat $EXECFILENAME | wc -l | tr -d ' '` ]
    then
## CLEANUP
rm $EXECBTEQOUT;
rm $EXECFILENAME;
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******       JOB Execution   Level logging to                *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
      echo "*==================================================================" >> $LOGFILE
      echo "|                          (Success)                               *" >> $LOGFILE
      echo "| `date +'%D %r'` Start edw.bteq.after.ld.job.exec.sh       *" >> $LOGFILE
      echo "|                                                                  *" >> $LOGFILE
      echo "*==================================================================" >> $LOGFILE
      exit 0;
    else
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******       JOB Execution   Level logging to                *****" >> $LOGFILE
echo "*******                Process Control                        *****" >> $LOGFILE
echo "*******                                                       *****" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*******************************************************************" >> $LOGFILE
echo "*==================================================================" >> $LOGFILE
      echo "*==================================================================" >> $LOGFILE
      echo "|                          (Failed)                                *" >> $LOGFILE
      echo "| `date +'%D %r'` Start edw.bteq.after.ld.job.exec.sh       *" >> $LOGFILE
      echo "|                                                                  *" >> $LOGFILE
      echo "*==================================================================" >> $LOGFILE
      exit 1;
  fi


#!/bin.bash

sudo apt-get install -y ksh
sudo apt-get install -y gzip

ln -s /dbfs/mnt/wrangled/usr/local/edw /usr/local/edw
ln -s /dbfs/mnt/wrangled/master_data /master_data
ln -s /dbfs/mnt/wrangled/usr/local/teradata /usr/local/teradata
ln -s /dbfs/mnt/wrangled /mnt/wrangled

echo 'DBFSROOT="/dbfs/FileStore/apps"' >> /etc/environment

pip install aiofiles
pip install aiohttp
pip install adal
pip install msal
pip install pyyaml
pip install snowflake-connector-python==2.4.6

curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
curl https://packages.microsoft.com/config/ubuntu/16.04/prod.list > /etc/apt/sources.list.d/mssql-release.list
sudo apt-get update
sudo ACCEPT_EULA=Y apt-get -q -y install msodbcsql17

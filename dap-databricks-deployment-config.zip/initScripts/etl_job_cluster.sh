#!/bin.bash

wget https://repo1.maven.org/maven2/com/databricks/spark-xml_2.12/0.11.0/spark-xml_2.12-0.11.0.jar -O /databricks/jars/spark-xml_2.12-0.11.0.jar
wget https://repo1.maven.org/maven2/net/snowflake/spark-snowflake_2.12/2.8.4-spark_3.0/spark-snowflake_2.12-2.8.4-spark_3.0.jar -O /databricks/jars/spark-snowflake_2.12.jar

pip install snowflake-connector-python==2.4.6
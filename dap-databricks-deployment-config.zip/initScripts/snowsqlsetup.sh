#! /bin/bash

curl https://sfc-repo.snowflakecomputing.com/snowsql/bootstrap/1.2/linux_x86_64/snowsql-1.2.0-linux_x86_64.bash > /databricks/driver/snowsql-1.2.0-linux_x86_64.bash

SNOWSQL_DEST=/root/bin SNOWSQL_LOGIN_SHELL=/root/.profile bash /databricks/driver/snowsql-1.2.0-linux_x86_64.bash


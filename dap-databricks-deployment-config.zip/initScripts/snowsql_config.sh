#! /bin/bash
fileexist=$(ls ~/.snowsql/config | wc -l)
if [ $fileexist -eq 0 ]
  then
    echo "file not found"
    mkdir -p ~/.snowsql/
    cp /dbfs/FileStore/apps/config/config ~/.snowsql/config
    exit 0
else
    echo "file found"
	exit 0
fi

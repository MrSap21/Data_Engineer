#!/usr/bin/python3

from npspark import *

def Parameter_Set_MSS_EDW_dataset():
  """
  Parameter_Set_MSS_EDW Parameter Set
  Parameters:
  -----------
  pAdditionalParameters:
    Additional parameters required for Teradata enterprise stage
    sessionsperplayer=1,requestedsessions=4,synctimeout=160,workdb=devetl
  pTDRef2DBName:
    Pos View Name is
    devposbivw
  pTDRef1DBName:
    Rx view name
    devrx2vw
  APT_CONFIG_FILE:
    Configuration file
    The Parallel job configuration file.
  pDirControlFile:
    Root directory for process control log files
  pDirParmFile:
    Root directory for process control  parameter  files
  pDirOutput:
    Root Output directory
  pDirReject:
    Root directory for rejected records
  pDirSchema:
    Root directory for DataStage Schema files
  pDirAudit:
    Root directory for audit files and information
  pDirArchive:
    Root directory for archive files
  pDirTDLog:
    Root directory for Teradata log and message files
  pDirScripts:
    Root directory for Unix scripts
  pScriptRunDSJob:
    Enter the name of the script to be executed to run the DataStage Job.
  pScriptTeraExecLd:
    Enter the name of the script to be called in order to load the job execution data to Teradata. (Process Control)
  pScriptTeraLinkLd:
    Enter the name of the script to be called in order to load the job link detail data to Teradata. (Process Control)
  pScriptTeraLogLd:
    Enter the name of the script to be called in order to load the job log detail data to Teradata. (Process Control)
  pScriptTeraRunJobStatus:
    Enter the script to be exectued to load the job start status into the edw_abc tables. (Process Control)
  pScriptTeraStageLd:
    Enter the name of the script to be called in order to load the job stage detail data to Teradata. (Process Control)
  pEmailFrom:
    Enter the sender of email on Job Failure. (Process Control)
  pEmailTo:
    Enter the receiver of email on Job Failure. (Process Control)
  pDSServer:
    DataStage server
  pDSProject:
    DataStage project
  pDSUserid:
    DataStage logon ID
  pDSPassword:
    DataStage logon password
    HDI@IJV8O9JN064IL:JD1K95
  pTDDBName:
    Teradata Databese
  pTDStageDB:
    Teradata Staging Database
  pTDProcessControlDB:
    Teradata Process Control Database
  pTDServer:
    Teradata server
  pTDUserid:
    Teradata logon ID
  pTDPassword:
    Teradata logon password
    LEHD9;RH<=3<0FDI4:J41KI4B<<ME1U<2QKMoF;d71Q?3PO:HE0
  pTDJobExecTable:
    Enter the name of the Teradata Job Execution Detail Table. (Process Control)
  pTDStageDtlTable:
    Enter the edw stage detail table name. (Process Control)
  pTDLinkDtlTable:
    Enter the edw link detail table name. (Process Control)
  pTDLogDtlTable:
    Enter the edw log detail table name. (Process Control)
  pDirInput:
    Input directory for source files
    /usr/local/edw/edwmss/dev/input
  pEdwBatchId:
    Enter the batch ID for the current cycle
    99
  pDSJobName:
    Enter the jobname to be executed
    no_job_specified
  pAuditBypass:
    Bypass Process Control Auditing? (1=bypass)
    1=Bypass Process Control Auditing.  Everything else will run Process Control Auditing.
  pDSJob1:
    The first DataStage job to execute
    Cross_Ref
  pSeq_InvocationId:
    pDSJob1_InvocationId
    NOINVID
  pDSJob_TeraPrefix1:
    pDSJob1_TeraPrefix
    Comp_Name
  pdirou:
    pdirou
    /usr/local/edw/cdixref/prd/common/scripts
  pBteqLog:
    pBteqLog
    /usr/local/edw/cdixref/prd/common/scripts/BTEQ.txt
  pdir1:
    pdir
    /usr/local/edw
  pdir2:
    pdir2
    /cdixref/prd/process/controlfile/
  pdim_ad_event_inputfilename:
    dim_ad_event_inputfilename
    ADV710.120.EVENT.TEMP.dat
  pdim_ad_event_tablename:
    dim_ad_event_tablename
    dim_ad_event
  pdim_ad_media_inputfilename:
    pdim_ad_media_inputfilename
    ADV721.5000.DIM_AD_MEDIA.dat
  pdim_ad_media_tablename:
    pdim_ad_media_tablename
    dim_ad_media
  pdim_ad_str_media_inputfilename:
    pdim_ad_str_media_inputfilename
    ADV720.600.DIM_AD_STR_MEDIA.dat
  pdim_ad_str_media_tablename:
    pdim_ad_str_media_tablename
    dim_ad_str_media
  pdim_ad_loyalty_inputfilename:
    pdim_ad_loyalty_inputfilename
    ADV721.1000.DIM_AD_LOYALTY.dat
  pdim_ad_loalty_tablename:
    pdim_ad_loalty_tablename
    dim_ad_loyalty
  pDirDataSet:
    Directory for datasets
    /usr/local/edw/edwmss/dev/dataset
  pdim_location_inputfilename:
    dim_location_inputfilename
    dim_location_all.dat
  pdim_location_log_file:
    pdim_location_log_file
    /usr/local/edw/edwmss/dev/audit/msslocstg.log
  pTDStageDBName:
    Teradata staging database name
    devetl
  pdim_location_staging_script:
    Script to load staging Dim_location table
    mssdimloc_fast.ksh
  pHighEndDt:
    High end Date like 9999-12-31 23:59:59
    9999-12-31
  pStartDate:
    Initial date from when the history is loaded
    2008-03-01
  pdim_vendor_inputfilename:
    dim_vendor_inputfilename
    DCAVP-DIM-6_DIM_VENDOR.dat
  pdim_vendor_log_file:
    pdim_vendor_log_file
    /usr/local/edw/edwmss/dev/audit/mssvenstg.log
  pdim_vendor_staging_script:
    Script to load staging Dim_vendor table
    mssdimven_fast.ksh
  pedw_mss_loc_xref_tablename:
    edw_mss_location_xref table name
    edw_mss_location_xref
  pdim_location_stg_tablename:
    dim_location_stg_tablename
    dim_stg_location
  pdim_location_tablename:
    dim_location table name
    dim_location
  pdim_ad_event_type_inputfilename:
    pdim_ad_event_type_inputfilename
    dim_ad_event_type.dat
  pdim_ad_event_type_tablename:
    pdim_ad_event_type_tablename
    dim_ad_event_type
  SessionsPerPlayer:
    SessionsPerPlayer
    7
  RequestedSessions:
    RequestedSession
    28
  pSchemaDir:
    pSchemaDir
    /usr/local/edw/edwmss/dev/common/schema/
  pTDDBVW:
    Teradata view database
    devetl
  pfct_input_filename:
    pfct_input_filename
    ADV715.50.FCT.AD.NEW.dat
  pfct_tablename:
    pfct_tablename
    fct_adwk_upc
  pfct_sls_typ_file_name:
    pfct_sls_typ_file_name
    WKCHN553.1000.????????.dat
  pfct_sls_typ_table_name:
    pfct_sls_typ_table_name
    adwk_sls_typ
    
  p_mss_location_xref_tablename:
    p_mss_location_xref_tablename
    edw_mss_location_xref"""
  return [
    exprParamStr("pAdditionalParameters", "sessionsperplayer=1,requestedsessions=4,synctimeout=160,workdb=devetl"),
    exprParamStr("pTDRef2DBName", "devposbivw"),
    exprParamStr("pTDRef1DBName", "devrx2vw"),
    projParamStr("APT_CONFIG_FILE"),
    projParamStr("pDirControlFile"),
    projParamStr("pDirParmFile"),
    projParamStr("pDirOutput"),
    projParamStr("pDirReject"),
    projParamStr("pDirSchema"),
    projParamStr("pDirAudit"),
    projParamStr("pDirArchive"),
    projParamStr("pDirTDLog"),
    projParamStr("pDirScripts"),
    projParamStr("pScriptRunDSJob"),
    projParamStr("pScriptTeraExecLd"),
    projParamStr("pScriptTeraLinkLd"),
    projParamStr("pScriptTeraLogLd"),
    projParamStr("pScriptTeraRunJobStatus"),
    projParamStr("pScriptTeraStageLd"),
    projParamStr("pEmailFrom"),
    projParamStr("pEmailTo"),
    projParamStr("pDSServer"),
    projParamStr("pDSProject"),
    projParamStr("pDSUserid"),
    exprParamStr("pDSPassword", "HDI@IJV8O9JN064IL:JD1K95"),
    projParamStr("pTDDBName"),
    projParamStr("pTDStageDB"),
    projParamStr("pTDProcessControlDB"),
    projParamStr("pTDServer"),
    projParamStr("pTDUserid"),
    exprParamStr("pTDPassword", "dummy"),
    projParamStr("pTDJobExecTable"),
    projParamStr("pTDStageDtlTable"),
    projParamStr("pTDLinkDtlTable"),
    projParamStr("pTDLogDtlTable"),
    exprParamStr("pDirInput", "/usr/local/edw/edwmss/prd/input"),
    argParamStr("pEdwBatchId"),
    exprParamStr("pDSJobName", "no_job_specified"),
    exprParamStr("pAuditBypass", "0"),
    exprParamStr("pLogFile", "__job.log"),
    exprParamStr("pDSJob1", "Cross_Ref"),
    exprParamStr("pSeq_InvocationId", "NOINVID"),
    exprParamStr("pDSJob_TeraPrefix1", "Comp_Name"),
    exprParamStr("pdirou", "/usr/local/edw/cdixref/prd/common/scripts"),
    exprParamStr("pBteqLog", "/usr/local/edw/cdixref/prd/common/scripts/BTEQ.txt"),
    exprParamStr("pdir1", "/usr/local/edw"),
    exprParamStr("pdir2", "/cdixref/prd/process/controlfile/"),
    exprParamStr("pdim_ad_event_inputfilename", "ADV710.120.EVENT.TEMP.dat"),
    exprParamStr("pdim_ad_event_tablename", "dim_ad_event"),
    exprParamStr("pdim_ad_media_inputfilename", "ADV721.5000.DIM_AD_MEDIA.dat"),
    exprParamStr("pdim_ad_media_tablename", "dim_ad_media"),
    exprParamStr("pdim_ad_str_media_inputfilename", "ADV720.600.DIM_AD_STR_MEDIA.dat"),
    exprParamStr("pdim_ad_str_media_tablename", "dim_ad_str_media"),
    exprParamStr("pdim_ad_loyalty_inputfilename", "ADV721.1000.DIM_AD_LOYALTY.dat"),
    exprParamStr("pdim_ad_loalty_tablename", "dim_ad_loyalty"),
    exprParamStr("pDirDataSet", "/usr/local/edw/edwmss/dev/dataset"),
    exprParamStr("pdim_location_inputfilename", "dim_location_all_20211208212818.dat"),
    exprParamStr("pdim_location_log_file", "/usr/local/edw/edwmss/prd/audit/msslocstg.log"),
    exprParamStr("pTDStageDBName", "devetl"),
    exprParamStr("pdim_location_staging_script", "mssdimloc_fast.ksh"),
    exprParamStr("pHighEndDt", "9999-12-31"),
    exprParamStr("pStartDate", "2008-03-01"),
    exprParamStr("pdim_vendor_inputfilename", "DCAVP-DIM-6_DIM_VENDOR.dat"),
    exprParamStr("pdim_vendor_log_file", "/usr/local/edw/edwmss/prd/audit/mssvenstg.log"),
    exprParamStr("pdim_vendor_staging_script", "mssdimven_fast.ksh"),
    exprParamStr("pedw_mss_loc_xref_tablename", "edw_mss_location_xref"),
    exprParamStr("pdim_location_stg_tablename", "dim_stg_location"),
    exprParamStr("pdim_location_tablename", "dim_location"),
    exprParamStr("pdim_ad_event_type_inputfilename", "dim_ad_event_type.dat"),
    exprParamStr("pdim_ad_event_type_tablename", "dim_ad_event_type"),
    exprParamStr("SessionsPerPlayer", "7"),
    exprParamStr("RequestedSessions", "28"),
    exprParamStr("pSchemaDir", "/usr/local/edw/edwmss/dev/common/schema/"),
    exprParamStr("pTDDBVW", "devetl"),
    exprParamStr("pfct_input_filename", "ADV715.50.FCT.AD.NEW.dat"),
    exprParamStr("pfct_tablename", "fct_adwk_upc"),
    exprParamStr("pfct_sls_typ_file_name", "WKCHN553.1000.????????.dat"),
    exprParamStr("pfct_sls_typ_table_name", "adwk_sls_typ"),
    exprParamStr("pDirOutputMasterDataProduct", "/master_data/product/loadready"),
    exprParamStr("pTDDBNameMasterDataProduct", "DEV_MASTER_DATA"),
    exprParamStr("pTDStageDBMasterDataProduct", "DEV_STAGING"),
    exprParamStr("pTDSchemaDBMasterDataProduct", "PRODUCT"),
    exprParamStr("p_mss_location_xref_tablename", "edw_mss_location_xref"),
    exprParamStr("pDirDataSetMasterDataPartner", "/master_data/partner/dataset/"),
    exprParamStr("pDirOutputMasterDataPartner", "/master_data/partner/loadready"),
    exprParamStr("pSFTablePatVd", "partner.dim_vendor"),
    exprParamStr("Insert_Load_Ready", "dim_vendor"),
    exprParamStr("pSFTablePatStgVd", "partner.dim_Vendor_stg"),
    exprParamStr("SRC_FILE_PATTERN", "DCAVP_DIM_6_DIM_VENDOR"),
    #Parameters Added FOR EDW_MSS_LOCATION_XREF AND EDW_LOC_HRCHY_MAP
    exprParamStr("pDirInputMasterDataLocation", "/master_data/location/input"),
    exprParamStr("pDirOutputMasterDataLocation", "/master_data/location/output"),
    exprParamStr("pDirSchemaMasterDataLocation", "/master_data/location/common/schema"),
    exprParamStr("pDirLoadreadyMasterDataLocation", "/master_data/location/loadready"),
    exprParamStr("pDirDataSetMasterDataLocation", "/master_data/location/dataset"),
    exprParamStr("pDirRejectMasterDataLocation", "/master_data/location/reject"),
    projParamStr("DP_DB_MASTER_DATA"),
    projParamStr("DP_DB_STAGING"),
    projParamStr("READ_API_URL"),
    projParamStr("pUpdateAssetAPI"),
    projParamStr("pAssetStatus"),
    exprParamStr("DP_DB_STAGE_SCHEMA", "PRDETL"),
    exprParamStr("pSFTableLocHrchyMap", "location.edw_loc_hrchy_map"),
    exprParamStr("pSFTableMssLocXref", "location.edw_mss_location_xref"),
    exprParamStr("pSFTableDimLoc", "location.dim_location"),
    exprParamStr("pSFTableLocDistrict", "location.location_district"),
    exprParamStr("pSFTableMdseDemandGrp", "location.location_mdse_demand_grp"),
    exprParamStr("pSFTableLocRegion", "location.location_region"),
    exprParamStr("pSFTableLocStore", "location.location_store"),
    exprParamStr("pSFTableLocDc", "location.Location_dc"),
    exprParamStr("pSFTableLocOperation", "location.Location_operation"),
    exprParamStr("pSFTableDimLoc", "location.Dim_location"),
    exprParamStr("pSFStagingDimLocStg", "location.Dim_location_STG"),
    exprParamStr("edw_mss_loc_xref_ds", "edw_mss_location_xref"),
    exprParamStr("SRC_FILE_PATTERN_EdwMssLocationXref", "dim_location_all")]


def Parameter_Set_MSS_EDW_dataset_2():
  return [
    #Parameters Added for FCT_ADWK_UPC:
    exprParamStr("SRC_FILE_PATTERN_FCT_AD_NEW", "ADV715_50_FCT_AD_NEW"),
    exprParamStr("SRC_FILE_PATTERN_ADWK_UPC_PROD_REJ", "adwk_upc_product_reject_recycle_txt"),
    exprParamStr("pDirRejectRetailPromotions", "/retail/promotions/reject"),
    exprParamStr("pSFTableFctAdwkUpc", "promotions.fct_adwk_upc"),
    projParamStr("DP_DB_RETAIL"),
    exprParamStr("pSFTableMssDimProduct","product.mss_dim_product"),
    exprParamStr("pSFTableDimAdEvent","promotions.dim_ad_event"),
    exprParamStr("SRC_FILE_PATTERN_WKCHN553_1000","WKCHN553_1000_dat"),
    exprParamStr("SRC_FILE_PATTERN_ADWK_SLS_PROD_REJ","adwk_sls_product_reject_recycle_txt"),
    exprParamStr("pSFTableAdwkSlsTyp", "promotions.adwk_sls_typ"),
    exprParamStr("SRC_FILE_PATTERN_DIM_AD_MEDIA", "ADV721_5000_DIM_AD_MEDIA"),
    exprParamStr("pDirLoadreadyRetailPromotion", "retail/promotions/loadready"),
    exprParamStr("pSFTableDimAdMedia", "promotions.dim_ad_media"),
    #Parameters Added for AD_STR_MEDIA
    exprParamStr("SRC_FILE_PATTERN_STR_MEDIA", "ADV720_600_DIM_AD_STR_MEDIA"),
    exprParamStr("pSFTableadstrmedia", "promotions.dim_ad_str_media"),
    #Parameters Added for AD_EVENT
    exprParamStr("pSFTabledim_ad_event_tablename", "promotions.dim_ad_event"),
    exprParamStr("SRC_FILE_PATTERN_AD_EVENT", "ADV710_120_EVENT_TEMP")]


values = {"Parameter_Set_MSS_EDW": Parameter_Set_MSS_EDW_dataset(), "Parameter_Set_MSS_EDW_2": Parameter_Set_MSS_EDW_dataset_2()}

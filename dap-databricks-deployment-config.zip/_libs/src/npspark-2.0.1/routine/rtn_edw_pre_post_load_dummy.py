import json
import asyncio

async def rtn_edw_pre_post_load_dummy(controlFlow, **parameters):
  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.rtn_edw_pre_post_load_dummy: {txt}")
  msg(parameters)
  return 0

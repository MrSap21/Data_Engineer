import os
import uuid
import logging
import asyncio
from npctrl import runScript, TerminationType

async def rtn_edw_pre_load_process_ver1_0(controlFlow,pTDServer,pTDUserid,pTDPassword,pTDProcessControlDB,pTDJobStageTable,pDirScripts,pScriptPreLoadProc,pEdwBatchId,pDSProject,pDSJobName,pDSJobInvocation,pLogFile,pErrPreThreshold,pEmailFrom,pEmailTo):
  # INITIATE LOGGING
  _pLogFile = "/dev/null"
  logid = str(uuid.uuid4())
  if pLogFile != _pLogFile:
    _pLogFile = os.path.join("/tmp", logid)
  formatter = logging.Formatter('%(asctime)s %(name)s %(levelname)s:%(message)s')
  handler = logging.FileHandler(_pLogFile)
  handler.setFormatter(formatter)
  logging.getLogger("py4j").setLevel(logging.ERROR)
  logger = logging.getLogger("rtn_edw_pre_load_process_ver1_0")
  logger.setLevel(logging.DEBUG)
  logger.addHandler(handler)
  moveLogCmd = f"cp {_pLogFile} {pLogFile}.{logid} && rm {_pLogFile}"

  if not controlFlow.isRunning():
    msg(f"Skipping routine as job terminated")
    return  
  # ** INITIATE ROUTINE PARAMETERS
  Ans = 0
  RoutineName = "rtn_edw_pre_load_process_ver1_0"
  DSJobInvocation = f".{pDSJobInvocation}"
  JobSegmentSeparator = "#################################################################################################"
  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.rtn_edw_pre_load_process_ver1_0: {txt}")

  # ****** LOG ROUTINE START TO LOG FILE
  msg("PRE LOAD PROCESSING HAS STARTED")
  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)
  logger.info(f"{RoutineName}: - PRE LOAD PROCESSING HAS STARTED")
  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)

  # **CALL PRE LOAD SCRIPT IN ORDER TO VERIFY REJECT ARE WITHIN THE PREDEFINED THRESHOLD
  ExecScriptCmd = f'{pDirScripts}/{pScriptPreLoadProc} {pTDServer} {pTDUserid} {pTDPassword} {pTDProcessControlDB} {pTDJobStageTable} {pEdwBatchId} {pDSProject} {pDSJobName} {pDSJobInvocation} {_pLogFile} {pErrPreThreshold}'
  returnValue = await runScript(controlFlow,ExecScriptCmd)

  if returnValue.ReturnValue != 0:
    Ans=1
    logger.info(JobSegmentSeparator)
    logger.info(f"{RoutineName}: - PRE LOAD PROCESSING HAS FAILED")
    logger.info(JobSegmentSeparator)

    # Reply=DSSendMail("From:":pEmailFrom:"\\nTo:":pEmailTo:"\\nSubject:PRELOAD PROCESSING HAS FAILED PROJECT: ":pDSProject:": EDWBATCHID: ":pEdwBatchId:"\\nBody:REJECT THRESHOLD EXCEEDED OR PRELOAD SCRIPT BTEQ ERROR ENCOUNTERED - PLEASE REFER TO ":pLogFile)
    Message = f"{RoutineName} - PRE LOAD SCRIPT HAS RETURNED A NON-ZERO RETRUN CODE OF {returnValue.ReturnValue} - ABORTING PROCESSING"
    msg(f"Warning: {Message}")
    return Ans

  # **LOG ROUTINE FINISHED TO LOG FILE / DS DIRECTOR LOG
  FinishMsg = "PRE LOAD PROCESSING HAS SUCCESSFULLY FINISHED"
  msg(FinishMsg)

  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)
  logger.info(f"{RoutineName}: - PRE LOAD PROCESSING HAS SUCCESSFULLY FINISHED")
  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)

  if pLogFile != "/dev/null":
    await runScript(controlFlow,moveLogCmd)  
  return Ans
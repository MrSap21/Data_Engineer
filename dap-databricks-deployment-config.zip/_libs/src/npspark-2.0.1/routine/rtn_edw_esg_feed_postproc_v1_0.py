import json
import asyncio

async def rtn_edw_esg_feed_postproc_v1_0(controlFlow, **parameters):
  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.rtn_edw_esg_feed_postproc_v1_0: {txt}")
  msg(parameters)
  return 0

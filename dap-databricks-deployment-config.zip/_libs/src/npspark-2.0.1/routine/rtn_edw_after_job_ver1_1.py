import os
import uuid
import asyncio
import aiofiles
import logging
from datetime import datetime
from npctrl import runScript

""" This routine will perform the following functions:

CREATE THE JOB LOG AUDIT FILE CONTAINING THE FOLLOWING:
  Job Invocation ID
  Job Status
    1 = Finished Successfully
    2 = Finished with Warnings
    4 = Failed (Finished Prematurely)
  Job Name
  Job Start Timestamp
  Job Finished Timestamp
  Job User Name

CREATE A CHECKPOINT TOUCH FILE IF THE JOB EXECUTED SUCCESSFULLY
  This routine will create a checkpoint touch file after the successful completion of any job for job restartability purposes.
"""

async def rtn_edw_after_job_ver1_1(controlFlow,
                                   pAuditBypass,pTDServer,pTDUser,pTDPassword,pTDProcessControlDB,
                                   pTDJobExecTable,pTDLogDtlTable,pTDStageDtlTable,pTDLinkDtlTable,
                                   pDirControlFile,pTeraBteqOut,pLogFile,pDirScripts,pScriptTeraExecLd,
                                   pScriptTeraLogLd,pScriptTeraStageLd,pScriptTeraLinkLd,
                                   pEmailFrom,pEmailTo,pEdwBatchId,pDSProject,pDSJobName,pDSJobInvocation):

  # INITIATE LOGGING
  _pLogFile = "/dev/null"
  logid = str(uuid.uuid4())
  if pLogFile != _pLogFile:
    _pLogFile = os.path.join("/tmp", logid)
  formatter = logging.Formatter('%(asctime)s %(name)s %(levelname)s:%(message)s')
  handler = logging.FileHandler(_pLogFile)
  handler.setFormatter(formatter)
  logging.getLogger("py4j").setLevel(logging.ERROR)
  logger = logging.getLogger("rtn_edw_after_job_ver1_1")
  logger.setLevel(logging.DEBUG)
  logger.addHandler(handler)
  jobStatus = controlFlow.jobStatus[pDSJobName]
  moveLogCmd = f"cp {_pLogFile} {pLogFile}.{logid} && rm {_pLogFile}"
  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.rtn_edw_after_job_ver1_1: {txt}")

  def TeraBteqLoad():
    if JobStatus.ReturnValue != 0:
      Message = f"Script Command:  {ExecScriptCmd}: was unsuccessful for job {pDSJobName}{DSJobInvocation}"
      msg(f"Fatal: {Message}")
      return 1
    return 0

  def ExitRoutine():
    if AbortFlag == 1:
      Ans = 1
      logger.info(f"{RoutineName} HAS FINISHED AND THE FOLLOWING JOB HAS ABORTED: {pDSJobName}{DSJobInvocation}.")
      Message = f"{pDSJobName}{DSJobInvocation} has aborted for EDWBATCHID: {pEdwBatchId}. For job log information, refer to: {pDirControlFile}/{LogDtlFilename}"
      msg(f"Fatal: {Message}")
    else:
      logger.info(JobSegmentSeparator)
      logger.info(JobSegmentSeparator)
      logger.info(JobSegmentSeparator)
      logger.info(JobSegmentSeparator)
      logger.info(f"{RoutineName}: AFTER JOB EXECUTION PROCESSING HAS FINISHED FOR JOB {pDSJobName}{DSJobInvocation}.")
      logger.info(JobSegmentSeparator)
      logger.info(JobSegmentSeparator)
      logger.info(JobSegmentSeparator)
      logger.info(JobSegmentSeparator)
      msg(f"INFO: AFTER JOB EXECUTION PROCESSING HAS FINISHED FOR JOB {pDSJobName}{DSJobInvocation}.")

  if not controlFlow.isRunning():
    msg(f"Skipping routine as job terminated")
    return
  # **INITIATE ROUTINE PARAMETERS
  Ans = 0
  AbortFlag = 0
  RoutineName = "rtn_edw_after_job_ver1_1"
  DSJobInvocation = f".{pDSJobInvocation}"
  JobSegmentSeparator = "#################################################################################################"
  JobExecFilename = f"{pDirControlFile}/{pEdwBatchId}.{pDSJobName}{DSJobInvocation}.exec.dtl.txt"
  LogDtlFilename = f"{pDirControlFile}/{pEdwBatchId}.{pDSJobName}{DSJobInvocation}.log.dtl.txt"
  TeraExecBteqOut = f"{pDirControlFile}/bteq.after.ld.jobexec.{pEdwBatchId}.{pDSJobName}{DSJobInvocation}.out"
  TeraLogBteqOut = f"{pDirControlFile}/bteq.after.ld.joblog.{pEdwBatchId}.{pDSJobName}{DSJobInvocation}.out"

  # **LOG ROUTINE START TO LOG FILE
  StartMsg=f"AFTER JOB EXECUTION PROCESSING HAS STARTED FOR JOB: {pDSJobName}.{pDSJobInvocation}"
  msg(f"INFO: {StartMsg}")
  logger.info(JobSegmentSeparator)
  logger.info(f"{RoutineName}: AFTER JOB EXECUTION PROCESSING HAS STARTED FOR JOB {pDSJobName}{DSJobInvocation}")
  logger.info(JobSegmentSeparator)

  # **IF ROUTINE BYPASS IS SET THEN EXIT OUT OF ROUTINE IMMEDIATELY
  if pAuditBypass == 1:
    logger.info(f"{RoutineName} has been manually bypassed.")
    if pLogFile != "/dev/null":
      await runScript(controlFlow,moveLogCmd)
    return Ans

  # **ATTACH JOBHANDLE TO JOB AND RETRIEVE JOB STATUS - IF JOB ABORTED, FLAG ABORT INDICATOR.
  if jobStatus.JobStatus == 4 or jobStatus.JobStatus == 6:
    AbortFlag=1
  
  start_time = datetime.fromtimestamp(jobStatus.StartTime  / 1e3)
  end_time = datetime.fromtimestamp(jobStatus.EndTime / 1e3)
  # **RETRIEVE JOB EXECUTION FOR MOST RECENT JOB RUN / CREATE THE JOB EXECUTION DATA FILE AND CALL LOCAL SUBROUTINE TO LOAD JOB EXECUTION DETAIL DATA TO TERADATA
  logger.info(f'Job Status={jobStatus.JobStatus}; Job Start Time={start_time}; Job Finish Time={end_time}')
  
  # print(f'Job Status={jobStatus.JobStatus}; Job Start Time={jobStatus.StartTime}; Job Finish Time={jobStatus.EndTime}')
  async with aiofiles.open(JobExecFilename, 'w') as JobExec:
    # await JobExec.write(f"'{pDSProject}�{pEdwBatchId}�{pDSJobName}�{pDSJobInvocation}�{jobStatus.JobStatus}�{jobStatus.StartTime}�{jobStatus.EndTime}'")
    await JobExec.write(f"{pDSProject}|{pEdwBatchId}|{pDSJobName}|{pDSJobInvocation}|{jobStatus.JobStatus}|{start_time}|{end_time}\n")
  
  async with aiofiles.open(LogDtlFilename, 'w') as JobLogDtl:
    # DS info {EventMessage}�{EventUser}�{EventType}�{EventTimeStamp} does not support."
    EventMessage = "0" #N/A
    EventUser = "0" #N/A
    EventType = "0" #N/A 
    EventTimeStamp = end_time
    # await JobLogDtl.write(f"{pDSProject}�{pEdwBatchId}�{pDSJobName}�{pDSJobInvocation}�{EventMessage}�{EventUser}�{EventType}�{EventTimeStamp}")
    await JobLogDtl.write(f"{pDSProject}|{pEdwBatchId}|{pDSJobName}|{pDSJobInvocation}|{EventMessage}|{EventUser}|{EventType}|{EventTimeStamp}\n")

  # **FILTER INFO MESSAGE TYPES (1) AND CREATE JOB LOG DETAIL FILE / WHEN ALL ENTRIES HAVE BEEN SCANNED; CALL LOCAL SUBROUTINE TO LOAD JOB LOG DETAIL DATA TO TERADATA
  ExecScriptCmd = f'{pDirScripts}/{pScriptTeraLogLd} {pTDServer} {pTDUser} {pTDPassword} {pTDProcessControlDB} {LogDtlFilename} {pTDLogDtlTable} {pEdwBatchId} {pDSProject} {pDSJobName} {pDSJobInvocation} {TeraLogBteqOut} {_pLogFile}'
  if not controlFlow.isCompleting(): return
  JobStatus = await runScript(controlFlow,ExecScriptCmd)
  Ans = TeraBteqLoad()
  if Ans == 1:
    ExitRoutine()
    if pLogFile != "/dev/null":
      await runScript(controlFlow,moveLogCmd)
    return Ans
  logger.info(f"{RoutineName}: JOB LOG DETAILS SUCCESSFULLY IMPORTED TO PROCESS CONTROL.")

  # ** CALL LOCAL SUBROUTINE TO LOAD JOB EXEC DETAIL DATA TO TERADATA
  ExecScriptCmd = f'{pDirScripts}/{pScriptTeraExecLd} {pTDServer} {pTDUser} {pTDPassword} {pTDProcessControlDB} {JobExecFilename} {pTDJobExecTable} {pEdwBatchId} {pDSProject} {pDSJobName} {pDSJobInvocation} {TeraExecBteqOut} {_pLogFile}'
  if not controlFlow.isCompleting(): return
  JobStatus = await runScript(controlFlow,ExecScriptCmd)
  Ans = TeraBteqLoad()
  if Ans == 1:
    ExitRoutine()
    if pLogFile != "/dev/null":
      await runScript(controlFlow,moveLogCmd)
    return Ans
  logger.info(f"{RoutineName}: JOB EXECUTION DETAILS SUCCESSFULLY IMPORTED TO PROCESS CONTROL.")
  if pLogFile != "/dev/null":
    await runScript(controlFlow,moveLogCmd)
  return Ans

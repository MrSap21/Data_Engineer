import os
import uuid
import asyncio
import logging
from npctrl import runScript

""" This Routine will perform the following funtions:
   1. Reset the job if the job is not in a runnable state.
   2. Insert into the job execution detail table a job running status record. 
"""
async def rtn_edw_before_job_ver1_1(controlFlow,
                                    pAuditBypass,pTDServer,pTDUser,pTDPassword,
                                    pTDProcessControlDB,pTDJobExecTable,pTDLogTable,pTDStageTable,pTDLinkTable,
                                    pDirTeraLog,pLogFile,
                                    pEdwBatchId,pDSProject,pDSJobName,pDSJobInvocation,pDirScripts,pScriptTeraRunJobStatus,
                                    pEmailFrom,pEmailTo):
  # INITIATE LOGGING
  _pLogFile = "/dev/null"
  logid = str(uuid.uuid4())
  if pLogFile != _pLogFile:
    _pLogFile = os.path.join("/tmp", logid)
  formatter = logging.Formatter('%(asctime)s %(name)s %(levelname)s:%(message)s')
  handler = logging.FileHandler(_pLogFile)
  handler.setFormatter(formatter)
  logging.getLogger("py4j").setLevel(logging.ERROR)
  logger = logging.getLogger("rtn_edw_before_job_ver1_1")
  logger.setLevel(logging.DEBUG)
  logger.addHandler(handler)
  # ** INITIATE ROUTINE PARAMETERS
  Ans = 0
  RoutineName = "rtn_edw_before_job_ver1_1"
  DSJobInvocation = f".{pDSJobInvocation}"
  JobSegmentSeparator = "#################################################################################################"
  moveLogCmd = f"cp {_pLogFile} {pLogFile}.{logid} && rm {_pLogFile}"

  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.{RoutineName}: {txt}")
  # **LOG ROUTINE START TO LOG FILE / DS DIRECTOR LOG
  if not controlFlow.isRunning():
    msg(f"Skipping routine as job terminated")
    return
  StartMsg = f"BEFORE JOB EXECUTION PROCESSING HAS STARTED FOR JOB: {pDSJobName}.{pDSJobInvocation}"
  msg(f"INFO: {StartMsg}")
  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)
  logger.info(f"{RoutineName}: BEFORE JOB EXECUTION PROCESSING HAS STARTED FOR JOB {pDSJobName}{DSJobInvocation}")
  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)
  logger.info(JobSegmentSeparator)
  # **IF ROUTINE BYPASS IS SET THEN EXIT OUT OF ROUTINE IMMEDIATELY
  if pAuditBypass == 1:
    logger.info(f"{RoutineName} has been manually bypassed.")
    if pLogFile != "/dev/null":
      await runScript(controlFlow,moveLogCmd)
    return Ans
  # ** INSERT JOB START STATUS RECORD INTO PROCESS CONTROL TABLES
  ExecScriptCmd = f'{pDirScripts}/{pScriptTeraRunJobStatus} {pTDServer} {pTDUser} {pTDPassword} {pTDProcessControlDB} {pTDJobExecTable} {pTDLogTable} {pTDStageTable} {pTDLinkTable} {pEdwBatchId} {pDSProject} {pDSJobName} {pDSJobInvocation} {pDirTeraLog} {_pLogFile}'
  returnValue = await runScript(controlFlow,ExecScriptCmd)
  logger.info(f"{pScriptTeraRunJobStatus} finished with exit code {returnValue.ReturnValue}.")
  Ans = returnValue.ReturnValue
  if Ans == 1:
    # Reply = DSSendMail(f"From:{pEmailFrom}\\nTo:{pEmailTo}\\nSubject:Job: {pDSJobName}{DSJobInvocation} has failed for PROJECT {pDSProject} {EDWBATCHID} {pEdwBatchId}\\nBody:{pDirScripts}/{pScriptTeraRunJobStatus} was unsuccessful in loading the job running status to TeraData")
    Message = f"{pDirScripts}/{pScriptTeraRunJobStatus} was unable to be executed successfully for job {pDSJobName}{DSJobInvocation}"
    msg(f"Fatal: {Message}")
    if pLogFile != "/dev/null":
      await runScript(controlFlow,moveLogCmd)
    return Ans
  if Ans == 2:
    BypassMsg = f"BYPASSING JOB: {pDSJobName}{DSJobInvocation} JOB HAS BEEN EXECUTED FOR CURRENT BATCH"
    msg(f"INFO: {BypassMsg}")
  # **LOG ROUTINE FINISHED TO LOG FILE / DS DIRECTOR LOG
  logger.info(JobSegmentSeparator)
  logger.info(f"{RoutineName} BEFORE JOB EXECUTION PROCESSING HAS FINISHED.")
  logger.info(JobSegmentSeparator)
  FnshMsg = f"BEFORE JOB EXECUTION PROCESSING HAS FINISHED FOR JOB: {pDSJobName}.{pDSJobInvocation}"
  msg(f"INFO: {FnshMsg}")
  if pLogFile != "/dev/null":
    await runScript(controlFlow,moveLogCmd)
  return Ans

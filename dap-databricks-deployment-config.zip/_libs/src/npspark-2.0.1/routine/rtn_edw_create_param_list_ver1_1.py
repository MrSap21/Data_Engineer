import json
import asyncio

async def rtn_edw_create_param_list_ver1_1(controlFlow, **parameters):
  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.rtn_edw_create_param_list_ver1_1: {txt}")
  msg(parameters)
  return 0

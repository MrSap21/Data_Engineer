import os
import uuid
import logging
import asyncio
from npctrl import runScript, TerminationType

async def rtn_edw_wk_feed_postproc_IL__v1_0(controlFlow,pDirLoadReady,pDirScripts,pFTPServer,pFTPUser,pLogFile,pEmailFrom,pEmailTo,pDSJobName,pDSJobInvocation,pDSProject,pEdwBatchId,pMaxFillEnterDt):
  # INITIATE LOGGING
  _pLogFile = "/dev/null"
  logid = str(uuid.uuid4())
  if pLogFile != _pLogFile:
    _pLogFile = os.path.join("/tmp", logid)
  formatter = logging.Formatter('%(asctime)s %(name)s %(levelname)s:%(message)s')
  handler = logging.FileHandler(_pLogFile)
  handler.setFormatter(formatter)
  logging.getLogger("py4j").setLevel(logging.ERROR)
  logger = logging.getLogger("rtn_edw_wk_feed_postproc_IL__v1_0")
  logger.setLevel(logging.DEBUG)
  logger.addHandler(handler)
  moveLogCmd = f"cp {_pLogFile} {pLogFile}.{logid} && rm {_pLogFile}"

  if not controlFlow.isRunning():
    msg(f"Skipping routine as job terminated")
    return
  # ** INITIATE ROUTINE PARAMETERS
  Ans = 0
  RoutineName = "rtn_edw_wk_feed_postproc_IL__v1_0"
  pScriptWKFeedPostProc = "WK_data_feed_postproc_v01_IL.sh"
  JobSegmentSeparator = "**********************************************************************"
  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.rtn_edw_wk_feed_postproc_IL__v1_0: {txt}")

  # ****** LOG ROUTINE START TO LOG FILE
  logger.info(JobSegmentSeparator)
  logger.info(f"{RoutineName}: HAS STARTED.")
  logger.info(JobSegmentSeparator)

  # ****** EXECUTE POST PROCESSING SCRIPT (TRANSFORM FLAT FILE LAYOUT, FTP TO EDW90DAYFILLS SERVER)
  logger.info(JobSegmentSeparator)
  logger.info(f"{pScriptWKFeedPostProc}: HAS BEEN EXECUTED")
  logger.info(JobSegmentSeparator)

  ExecScriptCmd = f'{pDirScripts}/{pScriptWKFeedPostProc} {pFTPServer} {pFTPUser} {pDirLoadReady} {pEdwBatchId} {_pLogFile} {pMaxFillEnterDt} {pEmailTo}'
  returnValue = await runScript(controlFlow,ExecScriptCmd)

  if returnValue.ReturnValue != 0:
    Ans=1
    logger.info(JobSegmentSeparator)
    logger.info(f"SCRIPT COMMAND:  {ExecScriptCmd} WAS UNSUCCESSFUL FOR JOB {pDSJobName}.{pDSJobInvocation}")
    logger.info(JobSegmentSeparator)

    # Reply=DSSendMail("From:":pEmailFrom:"\\nTo:":pEmailTo:"\\nSubject:Job: ":pDSJobName:pDSJobInvocation:" HAS FAILED FOR PROJECT: ":pDSProject:" - EDWBATCHID: ":pEdwBatchId:"\\nBody:ROUTINE FAILED.")
    Message = f"SCRIPT COMMAND: {ExecScriptCmd}: WAS UNSUCCESSFUL FOR JOB {pDSJobName}{pDSJobInvocation}"
    msg(f"Fatal: Message")
    controlFlow.terminate(TerminationType.STOP)

  logger.info(JobSegmentSeparator)
  logger.info(f"{RoutineName}: HAS BEEN EXECUTED SUCCESSFULLY.")
  logger.info(JobSegmentSeparator)

  if pLogFile != "/dev/null":
    await runScript(controlFlow,moveLogCmd)  
  return Ans
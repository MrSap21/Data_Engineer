
class PropMap:
  """ A map expanding embedded property references in its values """
  def __init__(self, map):
    self.map = map
  def valueOfKey(self, key):
    if key not in self.map:
      raise KeyError(key)
    v = self.map[key]
    if type(v) != str:
      return v
    return v.format_map(self)
  def __getitem__(self, key):
    if key in self.map:
      return self.valueOfKey(key)
    else:
      return "{" + key + "}"

class ParameterSet:
  """ Parameter set for bundling shared parameter definition """
  def __init__(self, parameters):
    self._parameters = parameters
  def __getattr__(self, key):
    return self.get(key)
  def map(self):
    return self._parameters.map
  def get(self, key):
    return self._parameters.valueOfKey(key)

def buildJobParameterArgs(parameters):
  kvMap = {}
  for k,v in parameters.items():
    if not isinstance(v, ParameterSet):
      kvMap[k] = v
    else:
      for k2,v2 in v.map().items():
        kvMap[k2] = v2
  return kvMap


from pyspark.sql.types import StringType, StructType
from pyspark.sql.functions import col, lit, coalesce, concat_ws

def createCsvFrameReaderWithReject(ctx, path, schema, **options):
  """
  Creates a pair of dataframe readers for csv file, the first being
  good records and the second is the rejected records
  Parameters:
  ----------
  path: CSV file path
  schema: CSV file schema
  options: CSV reader options
  Returns:
  --------
  A tuple of (good, bad) where good is a dataframe with records parsed normally
  and bad contains records that failed to parse
  """
  ctx.spark().sparkContext.setCheckpointDir(ctx.checkPointPath)
  
  badCol = "_corrupt_record"
  schemaWithError = StructType()
  for f in schema:
    schemaWithError.add(f)
  schemaWithError.add(badCol, StringType(), True)

  df = (ctx.spark().read
    .format("csv")
    .schema(schemaWithError)
    .options(**options)
    .load(resultPaths(ctx, path)).cache())

  bad = (df.filter(df._corrupt_record.isNotNull())
    .select(col(badCol).alias("rejected"))
    .drop(badCol))
  valid = df.filter(df._corrupt_record.isNull()).drop(badCol)

  good, nulls = ctx.validateSchema(valid, schema)

  if nulls is not None:
    cols = []
    for f in schema:
      cols.append(coalesce(nulls[f.name].cast("string"), lit('""')))
    toCsv = concat_ws(',', *cols)
    rejectedNulls = (nulls.withColumn("__rejected_nulls", toCsv)
      .select(col("__rejected_nulls").alias("rejected"))
      .drop("__rejected_nulls"))
    bad = bad.union(rejectedNulls)
  
  good = good.checkpoint()
  bad = bad.checkpoint()

  df.unpersist(True)
  return (good, bad)

def createCsvFrameReader(ctx, ignoreBadRecords, path, schema, **options):
  """
  Creates a dataframe reader for csv file
  Records that fail processing are rejected
  Parameters:
  ----------
  ignoreBadRecords: True to ignore all bad records, false to stop on first one
  path: CSV file path
  schema: CSV file schema
  options: CSV reader options
  Returns:
  --------
  Dataframe with good records
  """
  if ignoreBadRecords:
    mode = "FAILFAST"
  else:
    mode = "DROPMALFORMED"
  df = (ctx.spark().read
    .format("csv")
    .schema(schema)
    .option("mode", mode)
    .options(**options)
    .load(resultPaths(ctx, path)))
  return df

def resultPaths(ctx, paths):
  res = []
  for p in paths:
    res.append(ctx.resultsPath(p))
  return res

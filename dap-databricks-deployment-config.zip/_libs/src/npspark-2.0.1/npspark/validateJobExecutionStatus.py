import requests
import json
from datetime import datetime
from .procCntrlDBSession import *


class ValidateJobExecutionStatus:

    def validateStatusSuccessful(self, pJobList, pEdwBatchId, ctx, pJobInvocationID):
        sql_session = ProcCntrlDBSession(ctx)
        cursor = sql_session.sqlConn()
        
        query = "select count(*) from [dbo].[DAP_Proc_Cntrl_Pipeline_Run_Detail] " \
        "where PipeLine_Name in ('" + "','".join(pJobList) + "') " \
        "and Edw_batch_id = " + pEdwBatchId + " " \
        "and Status_cd = 1 "

        if pJobInvocationID:
            query = query + "and job_invocation_id = '" + pJobInvocationID + "'"

        successful_jobs = cursor.execute(
            (query)).fetchone()

        if successful_jobs[0] == len(pJobList):
            return True
        else:
            return False


def ValidateParallelJobStatusSuccessful(pJobList, pEdwBatchId, ctx, pJobInvocationID = None):
    validateObj = ValidateJobExecutionStatus()
    return validateObj.validateStatusSuccessful(pJobList, pEdwBatchId, ctx, pJobInvocationID)
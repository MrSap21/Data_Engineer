
def addSurrogateKeyCol(ctx, df, sequenceName, surrogateKeyColName,
  initialValue):
  createSequence = f"""
    CREATE SEQUENCE IF NOT EXISTS {ctx.sequenceSchema}."{sequenceName}"
    WITH START = {initialValue}"""
  with ctx.dbSession() as db:
    db.execute(createSequence)
  src = df.selectExpr("row_number() OVER(ORDER BY NULL) as __rownum", "*")
  count = src.count()
  ids = (ctx.dbFrameReader()
   .option("query",
      f"""
      SELECT
        ROW_NUMBER() OVER (ORDER BY NULL) __rownum,
        {ctx.sequenceSchema}."{sequenceName}".nextval {surrogateKeyColName}
      FROM table(generator(rowcount => {count}))
      """)
      .load());
  return ids.join(src, "__rownum").drop("__rownum")
  
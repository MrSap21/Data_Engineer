import glob; 
import os; 
from pyspark.sql import SparkSession;
from pyspark.sql.types import *
from pyspark.sql.functions import *
import pyspark.sql.functions as f

class SharedContainerPharmClnseData:
  
  def __init__(self, spark):
    self.spark = spark

  def get_not_nll_data(self, df, not_nl_col, nll_fld_val):
    dfa = df.withColumn("Retain_Ind",lit("Keep"))
    for a in [col(x) for x in not_nl_col]:
      df1 = dfa.withColumn("Retain_Ind", when(((trim(a)=="") | (trim(a)==nll_fld_val) | (a.isNull()) | (dfa.Retain_Ind=="Drop")),"Drop").otherwise("Keep"))
      dfa = df1
    return dfa
  
  def clnse_data_pharm_sc (self, source_file, sch_file, rej_file):
    
  # Read the schema file
    src_schema = self.spark.read.text(sch_file)
    
  # Extract the delimiter from the schema file
    sch_prop=src_schema.collect()[1][0]
    sch_prop_tmp1=sch_prop[sch_prop.find("delim_string="):sch_prop.rfind(",")]
    sch_delim=sch_prop_tmp1[sch_prop_tmp1.find("=")+2:sch_prop_tmp1.rfind(",")-1]
    
  # Extract the final delimiter from the schema file
    fnl_del=sch_prop[sch_prop.find("final_delim="):sch_prop.find(",")]
    fnl_delm=fnl_del[fnl_del.find("=")+1:]
  
  # Extract the null field value the schema file
    nll_fld=sch_prop[sch_prop.find("null_field="):sch_prop.rfind(", ")]
    nll_field=nll_fld[nll_fld.find("=")+2:-1]
      
  # Extract column details from schema file
    x=2
    y=3
    column_list=[]
    while x <= src_schema.count()-1:
      col_list=src_schema.collect()[x:y][0][0]
      col_list1=col_list.replace("(","").replace(")","").strip()
      column_list.append(col_list1)   
      x=x+1
      y=y+1
    column_list=[i for i in column_list if i]
  
  # Get the list of columns, data types, nullability and nullable columns
    type_map= {'decimal':DoubleType(), 'string':StringType(), 'timestamp':TimestampType(), 'date':DateType(), 'integer':IntegerType(), 'default':StringType(), 'int32':IntegerType(), 'int16':IntegerType(), 'int8':IntegerType(), 'time':StringType()}
    dtype_list = []
    col_nm_list=[]
    nl_list=[]
    not_nl_col=[]
    x=0
    while x <= len(column_list)-1:
      dt_typ=column_list[x][str(column_list[x]).find(":"):].strip()
      dt_typ1=dt_typ[1:dt_typ.find('[')].replace('nullable','').strip()
      
      if dt_typ1 in type_map.keys():
        dtype_list.append(type_map[dt_typ1])
      else:
        dtype_list.append(StringType())
        
      clnm_lst=column_list[x][:str(column_list[x]).find(":")].strip()
      col_nm_list.append(clnm_lst)
        
      if column_list[x].find("nullable")==-1:
        not_nl_col.append(clnm_lst)    
      x=x+1

  # Read the source file/files  
    src_file1 = source_file.select(f.array_join(f.array(col_nm_list), sch_delim, null_replacement=''))
    src_file=src_file1.toDF("AllCols")
  
  # Remove the special characters
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(0) , " "))
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(10) , " "))
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(12) , " "))
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(13) , " "))
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(128) , " "))

  # If src_file is empty, please return source_file and drop all records
    src_file_empty = source_file.drop()
    if src_file.rdd.isEmpty(): return src_file_empty
    
  # Read the rdd as dataframe using the delimiter, columns and data types
    df = src_file.rdd.map(lambda  x:x[0].split(sch_delim)).toDF(col_nm_list)
    df1 = df.select([col(column).cast(dtype) for column,dtype in zip(col_nm_list, dtype_list)])
    if not nll_field=='':
      df1 = df1.na.replace(nll_field,'')
    
  # Find out the records to keep or drop by adding new column Retain_Ind
    tgt_df_all = self.get_not_nll_data(df1, not_nl_col, nll_field)
    tgt_df_all.cache()
    tgt_df_keep = tgt_df_all.where(tgt_df_all.Retain_Ind=="Keep").drop(tgt_df_all.Retain_Ind)
  
  # Check if there are any null values in Not Nullables columns, if yes, write it to reject file
    tgt_df_drop = tgt_df_all.where(tgt_df_all.Retain_Ind=="Drop").drop(tgt_df_all.Retain_Ind)
    tgt_df_drop.write.mode('overwrite').csv(rej_file, sep='Ç')
    
    return tgt_df_keep

def SCNTNRClnseData(src_file, pDirReject, pDirSchema, pSchemaFile_ETLTBL01, pEdwBatchId, pDSJobName, pDSJobInvocation, pTDETLStageTable, pTDETLReadSessions, ctx):
  if src_file.rdd.isEmpty(): return src_file
  schemafile= ctx.fileSystem_utility + '/' + pDirSchema + '/' + pSchemaFile_ETLTBL01
  reject_file= ctx.fileSystem + '/' + pDirReject + '/' + str(pEdwBatchId) + '_' + pDSJobName + '_' + str(pDSJobInvocation) + '.extract.coli.distr.all.cols.rej'  
  SC_PharmClnseData=SharedContainerPharmClnseData(ctx.spark())
  df_PharmClnseData=SC_PharmClnseData.clnse_data_pharm_sc(src_file,schemafile,reject_file)
  return df_PharmClnseData
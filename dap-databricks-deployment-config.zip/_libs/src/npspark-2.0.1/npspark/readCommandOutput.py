import os
from subprocess import run, STDOUT, PIPE

def readCommandOutput(ctx, indentCount, *commands):
  out = []
  repl = "\n"
  print(str(indentCount))
  pattern = repl + (" " * indentCount)
  _env = os.environ
  _env["SF_USER_PWD_PASSED"] = ctx.sfPassword
  for command in commands:
    cmd = command.replace(pattern, repl)
    res = run(args=cmd, shell=True, text=True, check=True,
      stderr=STDOUT, stdout=PIPE, env=_env)
    for line in res.stdout.splitlines():
      out.append([line])
  return ctx.spark().createDataFrame(out).toDF('vardata')

import glob; 
import os; 
from pyspark.sql import SparkSession;
from pyspark.sql.types import *
from pyspark.sql.functions import *
import pyspark.sql.functions as f

class SharedContainerPharmEtlClnseData:
  
  def __init__(self, spark):
    self.spark = spark

  def get_not_nll_data(self, df, not_nl_col, nll_fld_val):
    dfa = df.withColumn("Retain_Ind",lit("Keep"))
    for a in [col(x) for x in not_nl_col]:
      df1 = dfa.withColumn("Retain_Ind", when(((trim(a)=="") | (trim(a)==nll_fld_val) | (a.isNull()) | (dfa.Retain_Ind=="Drop")),"Drop").otherwise("Keep"))
      dfa = df1
    return dfa
  
  def remspecific_nonprint_char(self, src_file):
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(0) , " "))
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(10) , " "))
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(12) , " "))
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(13) , " "))
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(128) , " "))
    return src_file
  
  def remall_nonprint_char(self, src_file):
    src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), "[^ -~]", " "))
    return src_file
  
  
  def clnse_data_pharm_etl (self, source_file, schema_file, rej_file, sc_name):

  # Read the schema file
    src_schema = self.spark.read.text(schema_file)
    
  # Extract the delimiter from the schema file
    sch_prop=src_schema.collect()[1][0]
    sch_prop_tmp1=sch_prop[sch_prop.find("delim_string="):sch_prop.rfind(",")]
    sch_delim=sch_prop_tmp1[sch_prop_tmp1.find("=")+2:sch_prop_tmp1.rfind(",")-1]
    
  # Extract the final delimiter from the schema file
    fnl_del=sch_prop[sch_prop.find("final_delim="):sch_prop.find(",")]
    fnl_delm=fnl_del[fnl_del.find("=")+1:]
  
  # Extract the null field value the schema file
    nll_fld=sch_prop[sch_prop.find("null_field="):sch_prop.rfind(", ")]
    nll_field=nll_fld[nll_fld.find("=")+2:-1]
      
  # Extract column details from schema file
    x=2
    y=3
    column_list=[]
    while x <= src_schema.count()-1:
      col_list=src_schema.collect()[x:y][0][0]
      col_list1=col_list.replace("(","").replace(")","").strip()
      column_list.append(col_list1)   
      x=x+1
      y=y+1
    column_list=[i for i in column_list if i]
  
  # Get the list of columns, data types, nullability and nullable columns
    type_map= {'decimal':DoubleType(), 'string':StringType(), 'timestamp':TimestampType(), 'date':DateType(), 'integer':IntegerType(), 'default':StringType(), 'int32':IntegerType(), 'int16':IntegerType(), 'int8':IntegerType(), 'time':StringType()}
    dtype_list = []
    col_nm_list=[]
    nl_list=[]
    not_nl_col=[]
    x=0
    while x <= len(column_list)-1:
      dt_typ=column_list[x][str(column_list[x]).find(":"):].strip()
      dt_typ1=dt_typ[1:dt_typ.find('[')].replace('nullable','').strip()
      
      if dt_typ1 in type_map.keys():
        dtype_list.append(type_map[dt_typ1])
      else:
        dtype_list.append(StringType())
        
      clnm_lst=column_list[x][:str(column_list[x]).find(":")].strip()
      col_nm_list.append(clnm_lst)
        
      if column_list[x].find("nullable")==-1:
        not_nl_col.append(clnm_lst)    
      x=x+1
     
  # Read the source file/files  
    src_file1 = source_file.select(f.array_join(f.array(col_nm_list), sch_delim, null_replacement=''))
    src_file=src_file1.toDF("AllCols")
    
  # Call function to either replace all non-printable characters or specified few 
    if sc_name in ('SCNTNRExtClnseEtlStg','SCNTNRExtClnseEtlStgAll','SCNTNRExtClnseEtlStgAllExc'):
        src_file = self.remspecific_nonprint_char(src_file)
    else:
        src_file = self.remall_nonprint_char(src_file)
    
  # If src_file is empty, please return source_file and drop all records  
    src_file_empty = source_file.drop()
    if src_file.rdd.isEmpty(): return src_file_empty
    
  # Read the rdd as dataframe using the delimiter, columns and data types
    df = src_file.rdd.map(lambda  x:x[0].split(sch_delim)).toDF(col_nm_list)
    df1 = df.select([col(column).cast(dtype) for column,dtype in zip(col_nm_list, dtype_list)])
    if not nll_field=='':
      df1 = df1.na.replace(nll_field,'')
    
  # Find out the records to keep or drop by adding new column Retain_Ind
    tgt_df_all = self.get_not_nll_data(df1, not_nl_col, nll_field)
    tgt_df_all.cache()
    tgt_df_keep = tgt_df_all.where(tgt_df_all.Retain_Ind=="Keep").drop(tgt_df_all.Retain_Ind)
  
  # Check if there are any null values in Not Nullables columns, if yes, write it to reject file
    tgt_df_drop = tgt_df_all.where(tgt_df_all.Retain_Ind=="Drop").drop(tgt_df_all.Retain_Ind)
    tgt_df_drop.write.mode('overwrite').csv(rej_file, sep='Ç')
    
    return tgt_df_keep
    
def SCNTNRExtClnseEtlStg(pEdwBatchId, pDSJobName, pDSJobInvocation, pTDServer, pTDStageDB, pTDUserid, pTDPassword, pTDETLStageView, pTDETLVWReadSessions, APT_TERA_SYNC_DATABASE, pDirReject, pDirSchema, pSchemaFile_ETLVW01, ctx):
  
  Teradata_Connector_read_1 = ctx.dbFrameReader() \
    .option("query", f"""SELECT * from {pTDStageDB}.{pTDETLStageView} WHERE EDW_DML_IND<>'C'""") \
    .load()
  if Teradata_Connector_read_1.rdd.isEmpty(): return Teradata_Connector_read_1 
  schemafile= ctx.fileSystem_utility + '/' + pDirSchema + '/' + pSchemaFile_ETLVW01
  reject_file= ctx.fileSystem + '/' + pDirReject + '/' + str(pEdwBatchId) + '_' + pDSJobName + '_' + str(pDSJobInvocation) + '.extract.coli.distr.all.cols.rej'
  sc_name = 'SCNTNRExtClnseEtlStg'
  SC_EtlStg=SharedContainerPharmEtlClnseData(ctx.spark())
  df_sc_etlstg=SC_EtlStg.clnse_data_pharm_etl(Teradata_Connector_read_1,schemafile,reject_file, sc_name)
  return df_sc_etlstg
  
def SCNTNRExtClnseEtlStgAll(pEdwBatchId, pDSJobName, pDSJobInvocation, pTDServer, pTDStageDB, pTDUserid, pTDPassword, pTDETLStageView, pTDETLVWReadSessions, APT_TERA_SYNC_DATABASE, pDirReject, pDirSchema, pSchemaFile_ETLVW01, ctx):
  
  Teradata_Connector_read_1 = ctx.dbFrameReader() \
    .option("query", f"""SELECT * from {pTDStageDB}.{pTDETLStageView}""") \
    .load() 
  if Teradata_Connector_read_1.rdd.isEmpty(): return Teradata_Connector_read_1
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + '/' + pSchemaFile_ETLVW01
  reject_file= ctx.fileSystem + "/" + pDirReject + '/' + str(pEdwBatchId) + '_' + pDSJobName + '_' + str(pDSJobInvocation) + '.extract.coli.distr.all.cols.rej'
  sc_name = 'SCNTNRExtClnseEtlStgAll'
  SC_EtlStgAll=SharedContainerPharmEtlClnseData(ctx.spark())
  df_sc_etlstgall=SC_EtlStgAll.clnse_data_pharm_etl(Teradata_Connector_read_1,schemafile,reject_file, sc_name)
  return df_sc_etlstgall
  
def SCNTNRExtClnseEtlStgAllExc(pEdwBatchId, pDSJobName, pDSJobInvocation, pTDServer, pTDStageDB, pTDUserid, pTDPassword, pTDETLStageView, pTDETLVWReadSessions, APT_TERA_SYNC_DATABASE, pDirReject, pDirSchema, pSchemaFile_ETLVW01, ctx):
  Teradata_Connector_read_1 = ctx.dbFrameReader() \
    .option("query", f"""SELECT cdc_txn_commit_dttm, 
            cdc_seq_nbr,
            cdc_rba_nbr,
            cdc_operation_type_cd,
            cdc_before_after_cd,
            cdc_txn_position_cd,
            edw_batch_id, 
            src_partition_nbr, 
            store_nbr, 
            rx_nbr,
            fill_nbr,
            fill_partial_nbr,
            exc_nbr, 
            exc_reason_cd, 
            exc_ccp_response, 
            exc_cmt, 
            exc_resolution_cd, 
            exc_resolution_user_id, 
            COALESCE (exc_resolution_dttm,  TIMESTAMP  '1800-01-01 00:00:00') as exc_resolution_dttm,
            COALESCE (exc_critical_dttm,  TIMESTAMP  '1800-01-01 00:00:00') as exc_critical_dttm,
            fill_deleted_ind, 
            max_ldr_type_cd, 
            max_ldr_type_sevr_cd, 
            create_user_id, 
            refills_added, 
            create_dttm,
            update_user_id, 
            update_dttm,
            prescribe_refills_added, 
            prescribe_reply_cd, 
            msg_cmts, 
            prescribe_auth_id, 
            COALESCE (exc_reason_update_dttm,TIMESTAMP  '1800-01-01 00:00:00') as exc_reason_update_dttm, 
            contacted_by_cd, 
            COALESCE (resubmit_dttm,TIMESTAMP  '1800-01-01 00:00:00') as resubmit_dttm,
            sold_thrd_pty_rej_ind, 
            exc_status_cd, 
            COALESCE (exc_status_update_dttm,TIMESTAMP  '1800-01-01 00:00:00') as exc_status_update_dttm, 
            pbr_phone_cmts, 
            em_selected_ind, 
            exc_sub_type_ind, 
            emergency_quantity, 
            equivalent_generic_copay, 
            pbr_auth_full_name, 
            msg_pbr_full_name, 
            epa_status, 
            epa_reply_msg, 
            workstation_locked_ip, 
            COALESCE (last_action_dttm, TIMESTAMP  '1800-01-01 00:00:00') as last_action_dttm,
            fax_image_id, 
            tpr_status_cd, 
            tpr_assignment_cd, 
            COALESCE (tpr_status_update_dttm, TIMESTAMP  '1800-01-01 00:00:00' ) as tpr_status_update_dttm
            FROM {pTDStageDB}.{pTDETLStageView}""") \
    .load() 
  if Teradata_Connector_read_1.rdd.isEmpty(): return Teradata_Connector_read_1
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + '/' + pSchemaFile_ETLVW01
  reject_file= ctx.fileSystem + "/" + pDirReject + '/' + str(pEdwBatchId) + '_' + pDSJobName + '_' + str(pDSJobInvocation) + '.extract.coli.distr.all.cols.rej'
  sc_name = 'SCNTNRExtClnseEtlStgAllExc'
  SC_EtlStgAllExc=SharedContainerPharmEtlClnseData(ctx.spark())
  df_sc_etlstg_allexc=SC_EtlStgAllExc.clnse_data_pharm_etl(Teradata_Connector_read_1,schemafile,reject_file, sc_name)
  return df_sc_etlstg_allexc
  
def SCNTNRExtClnseEtlStgIdntfyBadData(pEdwBatchId, pDSJobName, pDSJobInvocation, pTDServer, pTDStageDB, pTDUserid, pTDPassword, pTDETLStageView, pTDETLVWReadSessions, APT_TERA_SYNC_DATABASE, pDirReject, pDirSchema, pSchemaFile_ETLVW01, ctx):
  Teradata_Connector_read_1 = ctx.dbFrameReader() \
    .option("query", f"""SELECT * from {pTDStageDB}.{pTDETLStageView} WHERE EDW_DML_IND<>'C' ORDER BY PAT_ID""") \
    .load() 
  if Teradata_Connector_read_1.rdd.isEmpty(): return Teradata_Connector_read_1
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + '/' + pSchemaFile_ETLVW01
  reject_file= ctx.fileSystem + "/" + pDirReject + '/' + str(pEdwBatchId) + '_' + pDSJobName + '_' + str(pDSJobInvocation) + '.peek_output_patient_baddata.rej'
  sc_name = 'SCNTNRExtClnseEtlStgIdntfyBadData'
  SC_EtlStgIdBadData=SharedContainerPharmEtlClnseData(ctx.spark())
  df_sc_etlstg_idbaddata=SC_EtlStgIdBadData.clnse_data_pharm_etl(Teradata_Connector_read_1,schemafile,reject_file, sc_name)
  return df_sc_etlstg_idbaddata
from pyspark.sql.functions import monotonically_increasing_id, asc, desc

def logDf(ctx, df, fileName, columns, count, skip=0):
  if columns is not None:
    df = df.select(columns)
  if count is not None:
    if skip != 0:
      df = (df.limit(count + skip)
         .withColumn("np_temp_index", monotonically_increasing_id())
         .orderBy(desc("np_temp_index"))
         .limit(count)
         .orderBy(asc("np_temp_index"))
         .drop("np_temp_index"))
    else:
      df = df.limit(count)
  else:
    if skip != 0:
      count = df.count() - skip
      df = (df.withColumn("np_temp_index", monotonically_increasing_id())
         .orderBy(desc("np_temp_index"))
         .limit(count)
         .orderBy(asc("np_temp_index"))
         .drop("np_temp_index"))
  if fileName is None:
    df.show(df.count(), False)
  else:
    df.write.text(fileName)

import glob; 
import os; 
from pyspark.sql import SparkSession;
from pyspark.sql.types import *
from pyspark.sql.functions import *

class SharedContainerORASrc:
  
  def __init__(self, spark):
    self.spark = spark

  def get_not_nll_data(self, df, not_nl_col, nll_fld_val):
    dfa = df.withColumn("Retain_Ind",lit("Keep"))
    for a in [col(x) for x in not_nl_col]:
      df1 = dfa.withColumn("Retain_Ind", when(((trim(a)=="") |(trim(a)==nll_fld_val) | (a.isNull()) | (dfa.Retain_Ind=="Drop")),"Drop").otherwise("Keep"))
      dfa = df1
    return dfa

  def clean_df(self, df):
    for col in df.columns:
      df = df.withColumn(col, trim(df[col])) # Trim white spaces
    return df
  
  def get_df_for_ora_container(self, source_file, sch_file, rej_file, ctx):
    
  # Read the schema file
    src_schema = self.spark.read.text(sch_file)
    
  # Extract the delimiter from the schema file
    sch_prop=src_schema.collect()[1][0]
    sch_prop_tmp1=sch_prop[sch_prop.find("delim_string="):sch_prop.rfind(",")]
    sch_delim=sch_prop_tmp1[sch_prop_tmp1.find("=")+2:sch_prop_tmp1.rfind(",")-1]
    
  # Extract the final delimiter from the schema file
    fnl_del=sch_prop[sch_prop.find("final_delim="):sch_prop.find(",")]
    fnl_delm=fnl_del[fnl_del.find("=")+1:]
    
  # Extract the null field value the schema file
    nll_fld=sch_prop[sch_prop.find("null_field="):sch_prop.rfind(", ")]
    nll_field=nll_fld[nll_fld.find("=")+2:-1]
  
  # Read the source file/files  
    src_file=self.spark.read.option("delimiter", sch_delim).csv(source_file)
    src_file=self.clean_df(src_file)
    src_file = src_file.fillna("DSNullPlaceHolder")
    src_file=src_file.withColumn("AllCols", concat_ws("\x01", *src_file.columns)).select("AllCols")

  # Remove the special characters
  # src_file= src_file.withColumn('AllCols', regexp_replace(col('AllCols'), "[^ -~]", " ")) This is being commented because it would break the encrypted characters      

  # Extract column details from schema file
    x=2
    y=3
    column_list=[]
    while x <= src_schema.count()-1:
      col_list=src_schema.collect()[x:y][0][0]
      col_list1=col_list.replace("(","").replace(")","").strip()
      column_list.append(col_list1)   
      x=x+1
      y=y+1
    column_list=[i for i in column_list if i]
  
  # Get the list of columns, data types, nullability and nullable columns
    type_map= {'decimal':DoubleType(), 'string':StringType(), 'timestamp':TimestampType(), 'date':DateType(), 'integer':IntegerType(), 'default':StringType(), 'int32':LongType(), 'int16':IntegerType(), 'int8':IntegerType(), 'time':StringType()}
    dtype_list = []
    col_nm_list=[]
    nl_list=[]
    not_nl_col=[]
    schema = StructType()
    x=0
    while x <= len(column_list)-1:
      dt_typ=column_list[x][str(column_list[x]).find(":"):].strip()
      dt_typ1=dt_typ[1:dt_typ.find('[')].replace('nullable','').strip()
      
      if dt_typ1 in type_map.keys():
        dtype_list.append(type_map[dt_typ1])
      else:
        dtype_list.append(StringType())
        
      clnm_lst=column_list[x][:str(column_list[x]).find(":")].strip()
      col_nm_list.append(clnm_lst)
      
      if column_list[x].find("nullable")==-1:
        nl_list.append(False)
      else:
        nl_list.append(True)
        
      if column_list[x].find("nullable")==-1:
        not_nl_col.append(clnm_lst)    
      
      if clnm_lst.find("nullable")==-1:
        schema.add(clnm_lst, type_map.get(dt_typ1, StringType()), False)
      else:
        schema.add(clnm_lst, type_map.get(dt_typ1, StringType()), True)
      
      x=x+1
    
  # Check if src_file is empty else return empty df with schema
  
    if src_file.rdd.isEmpty(): return ctx.emptyDataFrameWithSchema(schema)
    
  # Read the rdd as dataframe using the delimiter, columns and data types
    df = src_file.rdd.map(lambda  x:x[0].split("\x01")).toDF(col_nm_list).replace("DSNullPlaceHolder", None)
    df1 = df.select([col(column).cast(dtype) for column,dtype in zip(col_nm_list, dtype_list)])
    if not nll_field=='':
      df1 = df1.na.replace(nll_field,'')
  
  # Find out the records to keep or drop by adding new column Retain_Ind
    tgt_df_all = self.get_not_nll_data(df1, not_nl_col, nll_field)
    tgt_df_all.cache()
    tgt_df_keep = tgt_df_all.where(tgt_df_all.Retain_Ind=="Keep").drop(tgt_df_all.Retain_Ind)
    
  # Check if there are any null values in Not Nullables columns, if yes, write it to reject file
    tgt_df_drop = tgt_df_all.where(tgt_df_all.Retain_Ind=="Drop").drop(tgt_df_all.Retain_Ind)
    tgt_df_drop.write.mode('overwrite').csv(rej_file, sep='Ç')
    
    return tgt_df_keep
    
#def SCNTNRExtClnseORASrc(pEdwBatchId, pDSJobName, pDSJobInvocation, pDirReject, pDirSchema, pSchemaFile_ORATBL01, pORASchemaOwner, pORATable, pORAUserId, pORAPassword, pORARemoteServer, ctx):
#  src_file = ctx.fileSystem + "/" + ctx.oracleInputFolder + '/' + pORASchemaOwner + '.' + pORATable + '.csv'
#  schemafile= ctx.fileSystem + "/" + pDirSchema + '/' + pSchemaFile_ORATBL01
#  reject_file= ctx.fileSystem + "/" + pDirReject + '/' + str(pEdwBatchId) + '_' + pDSJobName + '_' + str(pDSJobInvocation) + '.extract.colx.crt.one.col.rej'
#  SC_ORASrc=SharedContainerORASrc(ctx.spark())
#  df_sc_orasrc=SC_ORASrc.get_df_for_ora_container(src_file,schemafile,reject_file, ctx)
#  return df_sc_orasrc

def SCNTNRExtClnseORASrcFromIngFr(pEdwBatchId, pDSJobName, pDSJobInvocation, pDirReject, pDirSchema, pSchemaFile_ORATBL01, pSourceFileLocation, ctx):
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + '/' + pSchemaFile_ORATBL01
  reject_file= ctx.fileSystem + "/" + pDirReject + '/' + str(pEdwBatchId) + '_' + pDSJobName + '_' + str(pDSJobInvocation) + '.extract.colx.crt.one.col.rej'
  SC_ORASrc=SharedContainerORASrc(ctx.spark())
  df_sc_orasrc=SC_ORASrc.get_df_for_ora_container(pSourceFileLocation,schemafile,reject_file, ctx)
  return df_sc_orasrc
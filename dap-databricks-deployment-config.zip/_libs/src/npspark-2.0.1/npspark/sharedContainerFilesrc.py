import glob; 
import os; 
from pyspark.sql import SparkSession;
from pyspark.sql.types import *
from pyspark.sql.functions import *

class SharedContainerFileSrc:
  
  def __init__(self, spark):
    self.spark = spark

  def get_not_nl_data(self, df, not_nl_col, nll_fld_val):
    dfa = df.withColumn("Retain_Ind",lit("Keep"))
    for a in [col(x) for x in not_nl_col]:
      df1 = dfa.withColumn("Retain_Ind", when(((trim(a)=="") |(trim(a)==nll_fld_val) | (a.isNull()) | (dfa.Retain_Ind=="Drop")),"Drop").otherwise("Keep"))
      dfa = df1
    return dfa

  def clean_df(self, df):
    for col in df.columns:
      df = df.withColumn(col, trim(df[col])) # Trim white spaces
    return df  
  
  def get_df_frm_container(self, source_file, sch_file, rej_file, ctx):
  
  # Read the schema file
    src_schema = self.spark.read.text(sch_file)
    
  # Extract the delimiter from the schema file
    sch_prop=src_schema.collect()[1][0]
    sch_prop_tmp1=sch_prop[sch_prop.find("delim_string="):sch_prop.find("',")]
    sch_delim=sch_prop_tmp1[sch_prop_tmp1.find("=")+2:]
    
  # Extract the final delimiter from the schema file
    fnl_del=sch_prop[sch_prop.find("final_delim="):sch_prop.find(",")]
    fnl_delm=fnl_del[fnl_del.find("=")+1:]
    
  # Extract the null field value the schema file
    nll_fld=sch_prop[sch_prop.find("null_field="):sch_prop.rfind(", ")]
    nll_field=nll_fld[nll_fld.find("=")+2:-1]
    
  # Extract column details from schema file
    x=2
    y=3
    column_list=[]
    while x <= src_schema.count()-1:
      col_list=src_schema.collect()[x:y][0][0]
      col_list1=col_list.replace("(","").replace(")","").strip()
      column_list.append(col_list1)   
      x=x+1
      y=y+1
    column_list=[i for i in column_list if i]
  
  # Get the list of columns, data types, nullability and nullable columns
    type_map= {'decimal':DoubleType(), 'string':StringType(), 'timestamp':TimestampType(), 'date':DateType(), 'integer':IntegerType(), 'default':StringType(), 'int32':IntegerType(), 'int16':IntegerType(), 'int8':IntegerType(), 'time':StringType()}
    dtype_list = []
    col_nm_list=[]
    nl_list=[]
    not_nl_col=[]
    schema = StructType()
    x=0
    while x <= len(column_list)-1:
      dt_typ=column_list[x][str(column_list[x]).find(":"):].strip()
      dt_typ1=dt_typ[1:dt_typ.find('[')].replace('nullable','').strip()
      
      if dt_typ1 in type_map.keys():
        dtype_list.append(type_map[dt_typ1])
      else:
        dtype_list.append(StringType())
        
      clnm_lst=column_list[x][:str(column_list[x]).find(":")].strip()
      col_nm_list.append(clnm_lst)
        
      if column_list[x].find("nullable")==-1:
        not_nl_col.append(clnm_lst)    
        
      if clnm_lst.find("nullable")==-1:
        schema.add(clnm_lst, type_map.get(dt_typ1, StringType()), False)
      else:
        schema.add(clnm_lst, type_map.get(dt_typ1, StringType()), True)
      x=x+1
  
  # Read the source file/files  
    if source_file==[]:
      return ctx.emptyDataFrameWithSchema(schema)
    else:
        src_file=self.spark.read.option("delimiter", sch_delim).csv(source_file)
        src_file=self.clean_df(src_file)
        src_file = src_file.fillna("DSNullPlaceHolder")
        src_file=src_file.withColumn("AllCols", concat_ws("\x01", *src_file.columns)).select("AllCols")
    #Rejecting the records which were having extra SOH (\x01) and storing them in a reject file
    src_file=src_file.withColumn("delim_count",length(src_file.AllCols)-length(regexp_replace("AllCols", "\x01", "")))
    reject_file=src_file.filter(src_file.delim_count!=len(col_nm_list)-1).drop(src_file.delim_count)
    src_file=src_file.filter(src_file.delim_count==len(col_nm_list)-1).drop(src_file.delim_count)
    reject_file.coalesce(1).write.mode('overwrite').csv(rej_file+"_schema_mismatch", sep='\x01')
  
  # Remove the special characters ( commented to avoid breaking the encrypted characters )
    # src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(9) , " "))
    # src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(10) , " "))
    # src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(12) , " "))
    # src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(13) , " "))
    # src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(26) , " "))
    # src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(128) , " "))
    # src_file = src_file.withColumn('AllCols', regexp_replace(col('AllCols'), chr(199) , " "))
  
  # Check src_file is empty else return empty dataframe with schema
  
    if src_file.rdd.isEmpty(): return ctx.emptyDataFrameWithSchema(schema)
    
  # Read the source file using the delimiter, columns and data types
    df = src_file.rdd.map(lambda  x:x[0].split("\x01")).toDF(col_nm_list).replace("DSNullPlaceHolder", None)
    # df = src_file.select(split(col("AllCols"),sch_delim)).drop("AllCols").toDF(col_nm_list)
    df1 = df.select([col(column).cast(dtype) for column,dtype in zip(col_nm_list, dtype_list)])
    if not nll_field=='':
      df1 = df1.na.replace(nll_field,'')
    
    tgt_df_all = self.get_not_nl_data(df1,not_nl_col, nll_field)
    tgt_df_all.cache()
    tgt_df_keep = tgt_df_all.where(tgt_df_all.Retain_Ind=="Keep").drop(tgt_df_all.Retain_Ind)
    
  # Check if there are any null values in Not Nullables columns, if yes, write it to reject file
    tgt_df_drop = tgt_df_all.where(tgt_df_all.Retain_Ind=="Drop").drop(tgt_df_all.Retain_Ind)
    tgt_df_drop.write.mode('overwrite').csv(rej_file, sep='|')
    
    return tgt_df_keep
  
def CdiReadAndCleanFtpData(pDirFtp, pDirSchema, pDirReject, pSchemaFile1, pBatchId, ctx):
  param_list=[]
  if ctx.projectName == 'EDW_CDI2':
    for file in glob.glob(ctx.fileSystem + "/" + pDirFtp + "/*" + pSchemaFile1 + "*" + pBatchId + "*"):
      if ctx.spark().read.text(file).toDF("OneCol").rdd.isEmpty():
        None
      else:
        param_list.append(file)
    schemafile= ctx.fileSystem_utility + "/" + pDirSchema + "/" + pSchemaFile1 + '.sch'
    reject_file=ctx.fileSystem + "/" + pDirReject + '/' + pBatchId + '_' + pSchemaFile1 + '_ShrCont.rej'
    shared_container=SharedContainerFileSrc(ctx.spark())
    df_cont_gen=shared_container.get_df_frm_container(param_list,schemafile,reject_file,ctx)
  else:
    for file in glob.glob(ctx.fileSystem + "/" + pDirFtp + "/*" + pSchemaFile1 + "*"):
      if ctx.spark().read.text(file).toDF("OneCol").rdd.isEmpty():
        None
      else:
        param_list.append(file)
    schemafile= ctx.fileSystem_utility + "/" + pDirSchema + "/" + pSchemaFile1 + '.sch'
    reject_file=ctx.fileSystem + "/" + pDirReject + '/' + pBatchId + '_' + pSchemaFile1 + '_ShrCont.rej'
    shared_container=SharedContainerFileSrc(ctx.spark())
    df_cont_gen=shared_container.get_df_frm_container(param_list,schemafile,reject_file,ctx)
  return df_cont_gen

def CdiReadAndCleanFtpDataFromIngFr(pSourceFileLocation, pDirSchema, pDirReject, pSchemaFile1, pBatchId, ctx):
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + "/" + pSchemaFile1 + '.sch'
  reject_file=ctx.fileSystem + "/" + pDirReject + '/' + pSchemaFile1 + '_' + pBatchId + '.rej'
  shared_container=SharedContainerFileSrc(ctx.spark())
  df_cont_gen=shared_container.get_df_frm_container(pSourceFileLocation,schemafile,reject_file,ctx)
  return df_cont_gen  
  
def CdiInitialReadAndCleanFtpData(pDirFtp, pDirSchema, pDirReject, pSchemaFile1, pBatchId, ctx):
  param_list=[]
  if ctx.projectName == 'EDW_CDI2':
    for file in glob.glob(ctx.fileSystem + "/" + pDirFtp + "/*" + pSchemaFile1 + "*"):
      if ctx.spark().read.text(file).toDF("OneCol").rdd.isEmpty():
        None
      else:
        param_list.append(file)
    schemafile= ctx.fileSystem_utility + "/" + pDirSchema + "/" + pSchemaFile1 + '.sch'
    reject_file=ctx.fileSystem + "/" + pDirReject + '/' + pBatchId + '_' + pSchemaFile1 + '_ShrCont.rej'
    shared_container=SharedContainerFileSrc(ctx.spark())
    df_cont_init=shared_container.get_df_frm_container(param_list,schemafile,reject_file,ctx)    
  return df_cont_init
  
def EDWMMReadAndCleanFtpData(pDirFtp, pDirSchema, pDirReject, pSchemaFile1, pBatchId, ctx):
  param_list=[]
  for file in glob.glob(ctx.fileSystem + "/" + pDirFtp + "/*" + pSchemaFile1 + "*"):
    if ctx.spark().read.text(file).toDF("OneCol").rdd.isEmpty():
      None
    else:
      param_list.append(file)
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + "/" + pSchemaFile1 + '.sch'
  reject_file=ctx.fileSystem + "/" + pDirReject + '/' + pSchemaFile1 + '_' + pBatchId + '.rej'
  shared_container=SharedContainerFileSrc(ctx.spark())
  df_EDWMM=shared_container.get_df_frm_container(param_list,schemafile,reject_file,ctx)    
  return df_EDWMM

def EDWMMReadAndCleanFtpDataFromIngFr(pSourceFileLocation, pDirSchema, pDirReject, pSchemaFile1, pBatchId, ctx):
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + "/" + pSchemaFile1 + '.sch'
  reject_file=ctx.fileSystem + "/" + pDirReject + '/' + pSchemaFile1 + '_' + pBatchId + '.rej'
  shared_container=SharedContainerFileSrc(ctx.spark())
  df_EDWMM=shared_container.get_df_frm_container(pSourceFileLocation,schemafile,reject_file,ctx)    
  return df_EDWMM

def EDWMMPCCReadAndCleanFtpData(pDirFtp, pDirSchema, pDirReject, pSchemaFile1, pBatchId, ctx):
  param_list=[]
  for file in glob.glob(ctx.fileSystem + "/" + pDirFtp + "/*" + pSchemaFile1 + "*"):
    if ctx.spark().read.text(file).toDF("OneCol").rdd.isEmpty():
      None
    else:
      param_list.append(file)
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + "/" + pSchemaFile1 + '.sch'
  reject_file=ctx.fileSystem + "/" + pDirReject + '/' + pSchemaFile1 + '_' + pBatchId + '.rej'
  shared_container=SharedContainerFileSrc(ctx.spark())
  df_EDWMMPCC=shared_container.get_df_frm_container(param_list,schemafile,reject_file,ctx)    
  return df_EDWMMPCC

def EDWMMPCCReadAndCleanFtpDataFromIngFr(pSourceFileLocation, pDirSchema, pDirReject, pSchemaFile1, pBatchId, ctx):
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + "/" + pSchemaFile1 + '.sch'
  reject_file=ctx.fileSystem + "/" + pDirReject + '/' + pSchemaFile1 + '_' + pBatchId + '.rej'
  shared_container=SharedContainerFileSrc(ctx.spark())
  df_EDWMMPCC=shared_container.get_df_frm_container(pSourceFileLocation,schemafile,reject_file,ctx)    
  return df_EDWMMPCC
    
def CdiDistReadAndCleanFtpData(pDirFtp, pDirSchema, pDirReject, pSchemaFile1, pBatchId, pInputfile, ctx):
  param_list=[]
  if ctx.projectName == 'EDW_CDI2':
    src_file = ctx.fileSystem + "/" + pDirFtp + '/' + pInputfile
    schemafile= ctx.fileSystem_utility + "/" + pDirSchema + '/' + pSchemaFile1 + '.sch'
    reject_file= ctx.fileSystem + "/" + pDirReject + '/' + pSchemaFile1 + '.rej'
    param_list.append(src_file)
    shared_container=SharedContainerFileSrc(ctx.spark())
    df_cont_dist=shared_container.get_df_frm_container(param_list,schemafile,reject_file,ctx)
  return df_cont_dist
  
def photoReadAndCleanFtpData(pDirFtp, pDirSchema, pDirReject, pSchemaFile1, pBatchId, ctx):
  param_list=[]
  for file in glob.glob(ctx.fileSystem + "/" + pDirFtp + "/*" + pSchemaFile1 + '.dat.' + "*"):
    if ctx.spark().read.text(file).toDF("OneCol").rdd.isEmpty():
      None
    else:
      param_list.append(file)
  schemafile= ctx.fileSystem_utility + "/" + pDirSchema + "/" + pSchemaFile1 + '.sch'
  reject_file=ctx.fileSystem + "/" + pDirReject + '/' + pSchemaFile1 + '.rej'
  shared_container=SharedContainerFileSrc(ctx.spark())
  df_photoRCFtp=shared_container.get_df_frm_container(param_list,schemafile,reject_file,ctx)    
  return df_photoRCFtp
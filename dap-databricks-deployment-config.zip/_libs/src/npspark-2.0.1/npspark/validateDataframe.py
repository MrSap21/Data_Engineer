
from pyspark.sql.types import StructType
from pyspark.sql.functions import col, concat_ws, lit, when

def validateDataframe(ctx, df, schema):
  """ Validates dataframe schema 
  Parameters:
  -----------
  ctx: a job context
  df: A dataframe to validate
  schema: An instance of StructType defining schema of the dataframe
  Return:
  -------
  A tuple of (good, bad) where good is a dataframe defining validated recordss
  and bad contains records that failed validation
  """
  isValid = None
  if schema is not None:
    for f in schema:
      if not f.nullable:
        c = df[f.name].isNotNull()
        if isValid is None:
          isValid = c
        else:
          isValid = isValid & c
  if isValid is None:
    bad = None
    good = df
  else:
    colName = '__is_valid'
    df = df.withColumn(colName, isValid)
    bad = df.filter(~df.__is_valid).drop(colName)
    bad = (bad.withColumn("rejected", concat_ws(",", *[
      when(col(c).isNotNull(), col(c).cast("string")).otherwise(lit(""))
           for c in bad.columns])))
    good = df.filter(df.__is_valid).drop(colName)
  return (good, bad)

from .procCntrlDBSession import *
import requests
import json
from datetime import datetime
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry


class UpdateIngFrAssetStatus:

    def __init__(self, ctx):
        self._ctx = ctx
        self.cursor = ProcCntrlDBSession(ctx).sqlConn()

    def update_asset_ingfr(self, list_assets_to_close, pUpdateAssetAPI, pAssetStatus):
        # defining the api-endpoint
        API_ENDPOINT = pUpdateAssetAPI

        # data to be sent to api
        body = json.dumps({"assetId": list_assets_to_close, "statusId": pAssetStatus})

        # sending post request and saving response as response object
        headers = {'Content-Type': 'application/json'}

        # configure retries
        retry_strategy = Retry(
            total=5,
            status_forcelist=[429, 500, 502, 503, 504],
            method_whitelist=["POST", "PUT", "GET", "DELETE"]
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        http = requests.Session()
        http.mount("https://", adapter)
        http.mount("http://", adapter)

        print(f"Calling endpoint: {API_ENDPOINT}")
        print(f"Payload: {body}")

        response = http.post(API_ENDPOINT, data=body, headers=headers)

        if response.status_code != requests.codes.ok:
            raise "Not able to update asset ids " + list_assets_to_close + ". Response: " + response.history

    def get_job_map(self, pJobName, pFeedName):
        feed_job_map_id = self.cursor.execute(
            (
                "select map.feed_job_id  "
                "from [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] map "
                "inner join [dbo].[DAP_Proc_Cntrl_ETL_Jobs] jobs on map.job_id = jobs.job_id "
                "where jobs.job_name = ? "
                "and map.feed_name = ? "
            ), (pJobName, pFeedName)).fetchone()

        return feed_job_map_id

    def update_asset_status(self, feedName, pJobName, pJobFeedMap, pUpdateAssetAPI, pAssetStatus, ctx):

        # Update asset status for this job
        self.cursor.execute(
            (
                '''update [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution]
                   set close_job_dttm = pldt.Finish_dttm
                   from [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution] ex
                   inner join [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] map on ex.feed_job_id = map.feed_job_id
                   inner join [dbo].[DAP_Proc_Cntrl_ETL_Jobs] job on job.job_id = map.job_id
                   inner join [dbo].[DAP_Proc_Cntrl_Pipeline_Run_Detail] pldt on (pldt.Edw_batch_id = ex.edw_batch_id and pldt.PipeLine_Name = job.job_name)
                   where map.feed_job_id = ?
                   and pldt.Status_cd = 1
                   and ex.close_job_dttm is null
                '''
            ), (pJobFeedMap))

        # Get number of jobs depending on the feed
        feed_dependencies_count = self.cursor.execute(
            (
                '''select count(distinct job_name) dependencies
                   from [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] mp
                   inner join [dbo].[DAP_Proc_Cntrl_ETL_Jobs] jobs on mp.job_id = jobs.job_id
                   where feed_name = ?'''
            ), (feedName)).fetchone()

        print(f"Number of dependencies mapped to feed {feedName}: {feed_dependencies_count[0]}")

        # For a asset, get how many jobs which depend on it have been successfully completed
        jobs_completed_successfully = self.cursor.execute(
            (
                '''select ex.asset_id, count(distinct jobs.job_id) dependencies_successfully_executed
                   from [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] mp
                   inner join [dbo].[DAP_Proc_Cntrl_ETL_Jobs] jobs on mp.job_id = jobs.job_id
                   inner join [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution] ex on ex.feed_job_id = mp.feed_job_id
                   where mp.feed_name = ?
                   and ex.close_job_dttm is not null
                   and ex.close_asset_dttm is null
                   group by asset_id'''
            ), (feedName)).fetchall()

        list_assets_to_close = []
        for row_by_asset in jobs_completed_successfully:
            asset_id = row_by_asset[0]
            jobs_executed_count = row_by_asset[1]
            print(f"For asset {asset_id}, {jobs_executed_count} job(s) have been successfully executed")

            # If all dependencies have been successfully executed, then set the asset to be updated
            if jobs_executed_count == feed_dependencies_count[0]:
                print(f"Adding asset {asset_id} to the list of assets to be closed")
                list_assets_to_close.append(asset_id)

        # Close assets
        if list_assets_to_close:
            # Close assets in Ingestion Framework
            print(f"Assets to be closed: {list_assets_to_close}")
            self.update_asset_ingfr(list_assets_to_close, pUpdateAssetAPI, pAssetStatus)
            print(f"Assets successfully closed")
        else:
            print(f"No assets are ready to be closed")

        self.cursor.commit()


def UpdateProcessedFilesStatus(pFeedNames, pJobName, pUpdateAssetAPI, pAssetStatus, ctx):
    updateAssetObj = UpdateIngFrAssetStatus(ctx)

    for feedName in pFeedNames:
        print(f"Job {pJobName} to start closing assets for feed: {feedName}")
        feed_job_map = updateAssetObj.get_job_map(pJobName,feedName)

        if feed_job_map:
            updateAssetObj.update_asset_status(feedName, pJobName, feed_job_map[0], pUpdateAssetAPI, pAssetStatus, ctx)
        else:
            raise Exception("INGESTION FRAMEWORK ERROR: Feed " + feedName + " is not mapped to job " + pJobName)

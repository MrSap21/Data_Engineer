
def csvSaveDataframe(ctx, df, schema, path, header, delimiter, updateMode,
  rejectMode):
  good, bad = ctx.validateSchema(df, schema)
  if rejectMode == 'fail':
    if bad is not None and len(bad.take(1)) == 1:
      raise RuntimeError('Schema errors when saving dataframe to file: ' + path)
  stagingPath = ctx.stagingPath(path)
  resultPath = ctx.resultsPath(path)
  (good.coalesce(1).write
    .mode(updateMode)
    .option("header", header)
    .option("delimiter", delimiter)
    .format("csv")
    .save(stagingPath))
  moveResults(ctx, resultPath, stagingPath)
  return bad if bad is not None else ctx.emptyDataFrameWithSchema(schema)

def moveResults(ctx, resultPath, stagingPath):
  dbutils = get_dbutils(ctx)
  fileList = dbutils.fs.ls(stagingPath)
  for i in fileList:
    if i[1].startswith("part-00000"):
      readName = i[1]
  dbutils.fs.mv(stagingPath+"/"+readName, resultPath)
  dbutils.fs.rm(stagingPath, recurse=True)
  
def get_dbutils(ctx):
  key = "spark.databricks.service.client.enabled"
  cnf = ctx.spark().conf
  if cnf.get(key) == "true":
    from pyspark.dbutils import DBUtils
    return DBUtils(ctx.spark())
  else:
    import IPython
    return IPython.get_ipython().user_ns["dbutils"]

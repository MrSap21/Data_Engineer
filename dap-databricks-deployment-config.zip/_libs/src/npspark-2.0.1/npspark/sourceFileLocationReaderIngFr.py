import requests
import json
from datetime import datetime
from .procCntrlDBSession import *
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry


class SourceFileLocationReader:

    def __init__(self, ctx):
        self._ctx = ctx
        self.cursor = ProcCntrlDBSession(ctx).sqlConn()

    def get_job_map(self, pJobName, pFeedName):
        feed_job_map_id = self.cursor.execute(
            (
                "select map.feed_job_id  "
                "from [dbo].[DAP_Proc_Cntrl_Feed_Job_Map] map "
                "inner join [dbo].[DAP_Proc_Cntrl_ETL_Jobs] jobs on map.job_id = jobs.job_id "
                "where jobs.job_name = ? "
                "and map.feed_name = ? "
            ), (pJobName, pFeedName)).fetchone()
        
        return feed_job_map_id

    def get_unprocessedFiles(self, pFeedName, pGetUnprocessedFilesAPI):

        # defining the api-endpoint
        API_ENDPOINT = pGetUnprocessedFilesAPI

        # data to be sent to api
        key = "feedNames"
        body = json.dumps({key: [pFeedName]})

        # sending post request and saving response as response object

        headers = {'Content-Type': 'application/json'}

        # configure retries

        retry_strategy = Retry(
            total=5,
            status_forcelist=[429, 500, 502, 503, 504],
            method_whitelist=["POST", "PUT", "GET", "DELETE"]
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        http = requests.Session()
        http.mount("https://", adapter)
        http.mount("http://", adapter)

        print(f"Calling endpoint: {API_ENDPOINT}")
        print(f"Payload: {body}")

        response = http.post(API_ENDPOINT, data=body, headers=headers)

        print(f"Response code: {response.status_code}")
        print(f"Response text: {response.text}")

        return response.text

    def build_list_assets(self, pJsonObj, pFeedJobMap):
        listAssets = []
        for asset in pJsonObj:
            listAssets.append(str(asset["assetid"]))

        # Check of assets have already been processed by this job
        closed_assets = self.cursor.execute(
                (
                    "select distinct(asset_id) "
                    "from [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution] "
                    f"where feed_job_id = {pFeedJobMap}"
                    "and asset_id in (" + ",".join(listAssets) + ") "
                    "and close_job_dttm is not null "
                )).fetchall()

        for asset in closed_assets:
            listAssets.remove(str(asset[0]))
        
        return listAssets
        

    def get_list_location(self, pJsonObj, pFileSystem, pFileType, pFeedJobMap):
        liststr = []

        # Build list of assets which haven't been processed by this job
        listAssets = self.build_list_assets(pJsonObj, pFeedJobMap)

        if listAssets:
            # Filtering oldest asset if pFileType = "O"
            if pFileType is "O":
                listAssets = [min(listAssets)]

            # Generating list of paths
            for asset in pJsonObj:
                assetID = str(asset["assetid"])
                if assetID in listAssets:
                    liststr.append(pFileSystem + "/" + asset["assetcurrentlocation"] + "/" + asset["assetname"])

        return liststr, listAssets

    def log_assets(self, pEdwBatchId, pFeedJobMap, listAssets):
        if listAssets and pFeedJobMap:
            for asset in listAssets:
                self.cursor.execute("insert into [dbo].[DAP_Proc_Cntrl_Feed_Job_Execution] (feed_job_id, asset_id, edw_batch_id, read_dttm) values (?,?,?,?)",
                (pFeedJobMap, asset, pEdwBatchId, datetime.now()))
            self.cursor.commit()


#pFileTypes defines how many assets this function will return. "A" = All, "O" = "Oldest"
def GetUnprocessedFiles(pEdwBatchId, pJobName, pFeedName, pGetUnprocessedFilesAPI, pFileSystem, pFileType, ctx):
    file_reader = SourceFileLocationReader(ctx)

    list_files = []

    # get job-feed map id
    feed_job_map_id = file_reader.get_job_map(pJobName, pFeedName)

    if feed_job_map_id:
        # get list of unprocessed files from Ingestion Framework
        object_response = file_reader.get_unprocessedFiles(pFeedName, pGetUnprocessedFilesAPI)

        # extract list of path from response
        try:
            response_json = json.loads(object_response)
            list_files, list_assets = file_reader.get_list_location(response_json, pFileSystem, pFileType, feed_job_map_id[0])

            # log assets
            file_reader.log_assets(pEdwBatchId, feed_job_map_id[0], list_assets)
        except ValueError as e:
            raise Exception("INGESTION FRAMEWORK ERROR: Invalid API response for feed name " + pFeedName)
    else:
        raise Exception("INGESTION FRAMEWORK ERROR: Feed " + pFeedName + " is not mapped to job " + pJobName)

    if list_files:
        return list_files
    else:
        raise Exception("INGESTION FRAMEWORK ERROR: There are no unprocessed assets for feed " + pFeedName + " and job " + pJobName)

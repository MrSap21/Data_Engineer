
from pyspark.sql.functions import length, substring, trim, when, lit

def createTextFrameReaderWithReject(ctx, schema, widths, paths, lineSep=None):
  len = sum(widths)
  df = ctx.spark().read.text(paths,lineSep=lineSep)
  value = df['value']
  lengthOk = length(value) == len
  offset = 0
  isValid = None
  colNames = []
  for ndx, width in enumerate(widths):
    field = schema[ndx];
    colName = field.name
    colNames.append(colName)
    raw = trim(substring(value, offset + 1, width))
    notEmpty = length(raw) != 0
    col = (when(lengthOk & notEmpty, raw)
      .otherwise(lit(None)).cast(field.dataType))
    if not field.nullable:
      if isValid is None:
        isValid = notEmpty
      else:
        isValid = isValid & notEmpty
    df = df.withColumn(colName, col)
    offset += width
  if isValid is None:
    valid = lengthOk
  else:
    valid = lengthOk & isValid
  notValid = ~ valid;
  df = df.cache()
  good = df.filter(valid).drop(value)
  bad = (df.filter(notValid)
    .withColumnRenamed('value', 'rejected')
    .drop(*colNames))
  return (good, bad)

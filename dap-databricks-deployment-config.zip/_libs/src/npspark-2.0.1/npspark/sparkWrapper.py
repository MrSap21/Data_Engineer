
from  pyspark.sql import SparkSession

def sfOptions(ctx):
  return {
    "sfUrl": ctx.sfUrl,
    "sfUser": ctx.sfUser,
    "sfPassword": ctx.sfPassword,
    "sfDatabase": ctx.sfDatabase,
    "sfSchema": ctx.sfSchema,
    "sfWarehouse": ctx.sfWarehouse
  }


def createSparkSession(ctx):
  #return SparkSession \
  #  .builder \
  #  .appName(ctx.jobName) \
  #  .config(ctx.fileSystemCredential, ctx.storageAccountAccessKey) \
  #  .config("spark.sql.analyzer.failAmbiguousSelfJoin", ctx.spark_sql_analyzer_failAmbiguousSelfJoin) \
  #  .getOrCreate()
  return SparkSession \
    .builder \
    .appName(ctx.jobName) \
    .config("spark.sql.analyzer.failAmbiguousSelfJoin", ctx.spark_sql_analyzer_failAmbiguousSelfJoin) \
    .getOrCreate()

def createdbFrameWriter(ctx, df):
  #return df.write.format("snowflake").options(**sfOptions(ctx))
  #TRUNCATECOLUMNS option, which can truncate text strings that exceed the target column length.
  return df.write.format("snowflake").options(**sfOptions(ctx)).option("TRUNCATE_COLUMNS","True")

def createdbFrameReader(ctx):
  return ctx.spark().read.format("snowflake").options(**sfOptions(ctx))

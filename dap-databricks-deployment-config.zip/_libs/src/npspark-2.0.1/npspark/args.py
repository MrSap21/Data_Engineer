from enum import Enum, auto
from os import getenv
from os import path
import sys
import json
from .propMap import *

class Lookup(Enum):
  """ Definition of parameter lookup order """
  # Parameter is read from arguments, default from project file
  PROJECT = auto()
  # Parameter is read from arguments, default from environment file
  ENV = auto()
  # Parameter is read from arguments, default from provided expression
  EXPR = auto()
  # Parameter is read from arguments only, no default
  ARG = auto()
  # Value of parameter must be ignored
  UNSET = auto()
  # Parameter set
  PARAMS = auto()

class Param:
  """Job parameter descriptor"""
  def __init__(self, name, lookup, validate=None, expr=None):
    self.name = name
    self.lookup = lookup
    self.validate = validate
    self.expr = expr
  def __str__(self):
    return f"Param(name={self.name}, lookup={self.lookup}, " + \
      f"validate={self.validate}, expr={self.expr})"

def parameterSet(name):
  return Param(name, Lookup.PARAMS)

def projParamStr(name):
  return Param(name, Lookup.PROJECT)
def projParamInt(name):
  return Param(name, Lookup.PROJECT, validateInt)
def projParamBool(name):
  return Param(name, Lookup.PROJECT, validateBool)

def envParamStr(name):
  return Param(name, Lookup.ENV)
def envParamInt(name):
  return Param(name, Lookup.ENV, validateInt)
def envParamBool(name):
  return Param(name, Lookup.ENV, validateBool)

def exprParamStr(name, expr):
  return Param(name, Lookup.EXPR, None, expr)
def exprParamInt(name, expr):
  return Param(name, Lookup.EXPR, validateInt, expr)
def exprParamBool(name, expr):
  return Param(name, Lookup.EXPR, validateBool, expr)

def argParamStr(name):
  return Param(name, Lookup.ARG)
def argParamInt(name):
  return Param(name, Lookup.ARG, validateInt)
def argParamBool(name):
  return Param(name, Lookup.ARG, validateBool)

def unsetParam(name):
  return Param(name, Lookup.UNSET)

def validateInt(val):
  return int(val)

def validateBool(val):
  if type(val) == bool:
    return val
  return val.lower() in ['true', 'y', '1', 'yes', 'on', 'y']

def loadParameters(params):
  """
  Loads job parameters in the prescribed order
  Arguments
  params - A list of Param objects defining job parameters
  Return 
    A map of parameter name -> parameter value
  Throws
    KeyError if parameter was not found as per prescribed lookup
  """
  if len(sys.argv) > 3:
    raise ValueError("Invalid number of command-line arguments")
  if len(sys.argv) > 1:
    args = json.loads(sys.argv[1])
  else:
    args = {}
  if len(sys.argv) == 3:
    projPath = sys.argv[2]
  else:
    projPath = "./project.json"
  if not path.exists(projPath):
    projectValues = {}
  else:
    with open(projPath) as projFile:
      projectValues = json.load(projFile)
  #populate parameter map
  projectValues["projectFile"] = projPath
  return expandParameters(params, args, projectValues)

def expandParameters(params, args, projectValues):
  paramMap = dict(projectValues)
  for p in params:
    if p.lookup == Lookup.UNSET:
      paramMap.pop(p.name, None)
      continue
    v = args.get(p.name)
    if v is None:
      if p.lookup == Lookup.PARAMS:
        v = loadParamSet(p.name, args, projectValues)
      elif p.lookup == Lookup.ENV:
        v = getenv(p.name)
      elif p.lookup == Lookup.EXPR:
        v = paramMap.get(p.name)
        if v is None:
          v = p.expr
      if v is None:
        v = paramMap.get(p.name)
    if v is None:
      raise KeyError(p.name)
    if p.validate:
      v = p.validate(v)
    paramMap[p.name] = v
  return PropMap(paramMap)

def loadParamSet(name, args, projectValues):
  projParamsPath = path.dirname(projectValues["projectFile"])
  if projParamsPath not in sys.path:
    sys.path.append(projParamsPath)
    import paramSets
  params = paramSets.values[name]
  paramMap = expandParameters(params, args, projectValues)
  return ParameterSet(paramMap)

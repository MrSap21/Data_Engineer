import struct
import pyodbc
from adal import AuthenticationContext
from pyspark.dbutils import DBUtils


class ProcCntrlDBSession:
    def __init__(self, ctx):
        self._ctx = ctx
        self._conn = None

    def sqlConn(self):
        if self._conn is None:
            dbutils = DBUtils(self._ctx.spark())
            TenantId = dbutils.secrets.get(scope=self._ctx.keyVaultScope,key=self._ctx.keyVaultSecret_tenantIDKey)
            authority = "https://login.windows.net/" + TenantId
            resourceAppIdURI = "https://database.windows.net/"
            servicePrincipalId = dbutils.secrets.get(scope=self._ctx.keyVaultScope,key=self._ctx.keyVaultSecret_sqlClientIDKey)
            client_secret = dbutils.secrets.get(scope=self._ctx.keyVaultScope,key=self._ctx.keyVaultSecret_sqlClientSecretKey)
            server = self._ctx.sqlServerName
            database = self._ctx.procCntrlDBName

            context = AuthenticationContext(authority)
            newtoken = context.acquire_token_with_client_credentials(resourceAppIdURI, servicePrincipalId,
                                                                     client_secret)
            properties = {"accessToken": newtoken.get('accessToken'), "hostNameInCertificate": "*.database.windows.net",
                          "encrypt": "true"}

            databaseToken = properties.get('accessToken')
            tokenb = bytes(databaseToken, "UTF-8")

            exptoken = b''
            for i in tokenb:
                exptoken += bytes({i})
                exptoken += bytes(1)
            tokenstruct = struct.pack("=i", len(exptoken)) + exptoken

            connString = "Driver={ODBC Driver 17 for SQL Server};SERVER=" + server + ";DATABASE=" + database + ""

            SQL_COPT_SS_ACCESS_TOKEN = 1256
            conn = pyodbc.connect(connString, attrs_before={SQL_COPT_SS_ACCESS_TOKEN: tokenstruct})

            self._conn = conn.cursor()

        return self._conn

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        if self._conn is not None:
            self._conn.close()
            self._conn = None
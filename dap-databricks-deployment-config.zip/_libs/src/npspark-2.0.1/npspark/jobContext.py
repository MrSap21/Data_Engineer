
import os
import sys
import subprocess
import collections
import random
import string
from datetime import datetime
from datetime import timedelta 
from pyspark import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from .args import *
from .csvFrameReader import createCsvFrameReader, createCsvFrameReaderWithReject
from .csvSave import csvSaveDataframe, get_dbutils
from .dbSession import DbSession
from .logDf import logDf
from .propMap import buildJobParameterArgs
from .readCommandOutput import readCommandOutput
from .sharedContainerFilesrc import *
from .sharedContainerPharmClnseData import *
from .sharedContainerPharmEtl import *
from .sharedContainerPharmOraSrc import *
from .sourceFileLocationReaderIngFr import *
from .sourceFileAssetUpdateIngFr import *
from .procCntrlDBSession import *
from .validateJobExecutionStatus import *
from .sparkWrapper import *
from .text import createTextFrameReaderWithReject
from .validateDataframe import validateDataframe
from .surrogateKey import addSurrogateKeyCol

class JobContext:
  """Context for building dataflow pipelines"""

  def __init__(self, jobName, *parameters):
    self._spark = None
    self.jobName = jobName
    if parameters:
      p = list(parameters)
    else:
      p = []
    self._parameters = loadParameters(p)

    if self.keyVaultSecret == "true":
      dbutils = get_dbutils(self)
      self._parameters.map["sfPassword"] = dbutils.secrets.get(
        scope = self.keyVaultScope, 
        key = self.keyVaultSecret_sfPassword)
      self._parameters.map["storageAccountAccessKey"] = dbutils.secrets.get(
        scope = self.keyVaultScope, 
        key = self.keyVaultSecret_storageAccountAccessKey)
      self._parameters.map["databricksApiAccessToken"] = dbutils.secrets.get(
        scope = self.keyVaultScope, 
        key = self.keyVaultSecret_databricksApiAccessToken)
      self._parameters.map["sq_server_client_id"] = dbutils.secrets.get(
        scope = self.keyVaultSQScope, 
        key = self.keyVaultSecret_sqlserverClientID)
      self._parameters.map["sq_server_client_secret"] = dbutils.secrets.get(
        scope = self.keyVaultSQScope, 
        key = self.keyVaultSecret_sqlserverClientSecret)



  def spark(self):
    """ Returns current spark session """
    if self._spark is None:
      self._spark = createSparkSession(self)
    return self._spark

  def dbSession(self):
    return DbSession(self)

  def dbFrameWriter(self, df):
    """ Creates a dataframe writer for the target database """
    return createdbFrameWriter(self, df)

  def dbFrameReader(self):
    """ Creates a dataframe reader for the target database """
    return createdbFrameReader(self)

  def csvFrameReader(self, ignoreBadRecords, path, schema, **options):
    """ Returns frame reader, bad records are either ignored
    if ignoreBadRecords is true or execution stops if ignoreBadRecords is false
    """
    return createCsvFrameReader(self, ignoreBadRecords, path, schema, **options)

  def csvFrameReaderWithReject(self, path, schema, **options):
    """ Returns tuple of frame reader and bad records dataframe """
    return createCsvFrameReaderWithReject(self, path, schema, **options)

  def __getattr__(self, key):
    return self._parameters.valueOfKey(key)

  def buildJobParameters(self, parameters):
    return buildJobParameterArgs(parameters)

  def stagingPath(self, path):
    return self.fileSystem + self.stagingFolder + path

  def resultsPath(self, path):
    return self.fileSystem + path

  def resultsPathUtility(self, path):
    return self.fileSystem_utility + path

  def saveAsErrorTable1(self, tableName, df):
    """ Saves dataframe df to error table structured as Error Table 1 in TD """
    toBinary = udf(lambda s: bytes(s, 'utf-8'), BinaryType())
    df_new = df.select(
       lit(-1).alias("ErrorCode"),
       lit("<undefined>").alias("ErrorFieldName"),
       toBinary(df.rejected).alias("DataParcel"))
    (self.dbFrameWriter(df_new)
      .mode('overwrite')
      .option("dbtable", tableName)
      .save())

  def validateSchema(self, df, schema):
    """ Validates dataframe schema """
    return validateDataframe(self, df, schema)

  def emptyDataFrameWithSchema(self, schema):
    """ Creates an empty dataframe for a given schema """
    if schema is None:
      s = StructType()
    else:
      s = schema
    sc = self.spark()
    return sc.createDataFrame(sc.sparkContext.emptyRDD(), s)

  def saveAsCsv(self, df, path, header, delimiter, updateMode,
         schema=None,
         rejectMode='continue'):
    """ Saves dataframe as CSV file """
    return csvSaveDataframe(self, df=df, path=path, schema=schema, header=header,
      delimiter=delimiter, updateMode=updateMode, rejectMode=rejectMode)

  def commandOutputDataframe(self, indentCount, *commands):
    "Create a dataframe that reads output of a shell command or commands"
    return readCommandOutput(self, indentCount, *commands)

  def logDataFrame(self, df,
    fileName=None, # Optional file name to write log to
    columns=None,  # Optional list of column names to log, all columns if not specified
    count=None,    # Optional 
    skip=0):
    """Log dataframe to console or to a file
    Parameters:
    ----------
    df : A dataframe to log
    fileName: option file name to to log to, or log to console if not specified
    columns: optional list of columns to log, all columns logged if not set
    count: Optional count of rows to log, all rows logged if not set
    skip: Optional count of records to skip before starting logging rows,
          no rows are skipped if not set
    """
    return logDf(self, df, fileName, columns, count, skip)

  def writeFile(self, dest, readPath):
    dbutils = get_dbutils(self)
    fileList = dbutils.fs.ls(readPath)
    for i in fileList:
      if i[1].startswith("part-00000"):
        readName = i[1]
    dbutils.fs.mv(readPath+"/"+readName, dest)
    dbutils.fs.rm(readPath, recurse=True)

  def runSubr(self, subr_type, cmd, before=None):
    def msg(txt):
      print(f"{self.jobName}.runSubr: {txt}")
    if subr_type == 'DSU.ExecSH':
      _env = os.environ
      _env["SF_USER_PWD_PASSED"] = self.sfPassword
      process = subprocess.run(cmd, shell=True,
                               env=_env,
                               universal_newlines=True,
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE)
      msg(process.stdout)
      if process.returncode != 0:
        msg(f"WARNING: {process.stderr}")
        if before:
          msg(f"Abort the job {self.jobName}")
          exit(process.returncode)
    else:
      msg(f"{subr_type} not supported")
      return
  
  def structTypeMap(self):
    return {'decimal':DoubleType(), 'string':StringType(), 'timestamp':TimestampType(),
            'date':DateType(), 'integer':IntegerType(), 'default':StringType(), 
            'int32':IntegerType(), 'int16':IntegerType(), 'int8':IntegerType(), 'time':StringType()}

  def textFrameReaderWithReject(self, schema, widths, paths, lineSep=None):
    """Create a dataframe to read text files as per provided schema
    Parameters:
    -----------
      schema: defines fields in the text file
      widths: record field widths
      paths: a set of files to read
      lineSep: line separator, if not defined the line will be split on 
                \r\n or \n or \r, as found in the file
    """
    return createTextFrameReaderWithReject(self, schema, widths, paths, lineSep)

  def csvFrameReaderWithSchemaFileAndReject(self, source_file, sch_file, rej_file):
    source_list = self.linuxPaths(glob.glob(self.resultsPath(source_file)))
    schema, sch_delim = self.csvSchemaFile(sch_file)
    return self.csvFrameReaderWithReject(schema=schema,
        path=source_list,
        header=False,
        delimiter=sch_delim)

  def csvFrameReaderWithSchemaFile(self, source_file, sch_file):
    source_list = self.linuxPaths(glob.glob(self.resultsPath(source_file)))
    schema, sch_delim = self.csvSchemaFile(sch_file)
    return self.csvFrameReader(ignoreBadRecords=True,
        schema=schema,
        path=source_list,
        header=False,
        delimiter=sch_delim)

  def csvSchemaFile(self, sch_file):
    # Read the schema file
    src_schema = self.spark().read.text(self.resultsPathUtility(sch_file))
    # Extract the delimiter from the schema file
    sch_prop = src_schema.collect()[1][0]
    sch_prop_tmp1 = sch_prop[sch_prop.find(",")+2:sch_prop.rfind(",")]
    sch_delim = sch_prop_tmp1[sch_prop_tmp1.find("=")+2:-1]
    # Remove first 2 lines and last line from schema file
    x = 3
    y = 4
    column_list = []
    while x < src_schema.count()-1:
      col_list = src_schema.collect()[x:y][0][0].replace(
          "(", "").replace(")", "").strip()
      column_list.append(col_list)
      x = x+1
      y = y+1
    # Get the list of columns, data types, nullability and nullable columns
    type_map = self.structTypeMap()
    x = 0
    schema = StructType()
    while x <= len(column_list)-1:
      dt_typ = column_list[x][str(column_list[x]).find(":"):].strip()
      dt_typ1 = dt_typ[1:dt_typ.find('[')].replace('nullable', '').strip()
      clnm_lst = column_list[x][:str(column_list[x]).find(":")].strip()
      if clnm_lst.find("nullable") == -1:
        schema.add(clnm_lst, type_map.get(dt_typ1, StringType()), False)
      else:
        schema.add(clnm_lst, type_map.get(dt_typ1, StringType()), True)
      x = x+1
    return schema, sch_delim

  def linuxPaths(self, paths):
    res = []
    for p in paths:
      res.append(p.replace(self.fileSystem, ''))
    return res

  def addSurrogateKey(self, df, sequenceName, surrogateKeyColName,
    initialValue = 1):
    return addSurrogateKeyCol(self, df, sequenceName, surrogateKeyColName,
      initialValue)


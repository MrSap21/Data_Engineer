import snowflake.connector

class DbSession:
  def __init__(self, ctx):
    self._ctx = ctx
    self._conn = None

  def conn(self):
    if self._conn is None:
      self._conn = snowflake.connector.connect(
        user=self._ctx.sfUser,
        password=self._ctx.sfPassword,
        account=self._ctx.sfAccount,
        warehouse=self._ctx.sfWarehouse,
        database=self._ctx.sfDatabase,
        schema=self._ctx.sfSchema)
    return self._conn

  def __enter__(self):
    return self

  def __exit__(self, type, value, traceback):
    if self._conn is not None:
      self._conn.close()
      self._conn = None

  def executeStmts(self, sql, separator=';'):
    """ Sequentially executes statements separated by configured separator """
    for stmt in sql.split(separator):
      if stmt:
        sql = stmt.strip()
        if sql:
          self.execute(sql)

  def execute(self, sql):
    self.conn().execute_string(sql, return_cursors=False)

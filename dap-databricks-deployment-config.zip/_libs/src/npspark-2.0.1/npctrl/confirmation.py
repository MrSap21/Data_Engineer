
class Confirmation:
  """ A class defining OK and Failed fields confirming 
      operation completed or failed """
  def __init__(self, isOK):
    self.OK = isOK
    self.Failed = not isOK
  def __str__(self):
    return (f"Confirmation(OK:{self.OK}, Failed:{self.Failed}" + '}')

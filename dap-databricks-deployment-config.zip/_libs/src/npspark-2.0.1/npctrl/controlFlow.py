# Control flow support functionality
import asyncio
from enum import Enum, auto
from datetime import datetime

class TerminationType(Enum):
  """ Definition of what should happen as the job terminates """
  # Send stop requests to running jobs and exit
  STOP = auto()
  # Send stop requests and wait pending job completion
  STOP_AND_WAIT = auto()
  # Just exit current job 
  ABORT = auto()
  # Wait until pending jobs complete then exit
  WAIT = auto()

class ControlJobStatus:
  def __init__(self, startTime, endTime, code):
    self.StartTime = startTime
    self.EndTime = endTime
    self.JobStatus = code

class ControlFlowContext:
  def __init__(self, jobContext):
    self.terminationType = None
    self.tasks = [];
    self.jobStatus = {}
    self.jobContext = jobContext
    self._startTime = datetime.now().strftime("%C%y-%m-%d %H:%M:%S")

  @property
  def jobName(self):
    return self.jobContext.jobName

  def jobStatus(self):
    if self.terminationType is not None:
      code = 4
    else:
      code = 1
    endTime = datetime.now().strftime("%C%y-%m-%d %H:%M:%S")
    return ControlJobStatus(self._startTime, endTime, code)

  def terminate(self, terminationType):
    self.terminationType = terminationType
    if terminationType != TerminationType.WAIT:
      for task in self.tasks:
        if not task.done():
          task.cancel()

  def isRunning(self):
    """ Tells is current job is still running normally """
    return self.terminationType is None

  def isCompleting(self):
    """ Tells is current job is completing pending tasks, should not start any """
    return self.terminationType is None or self.terminationType == TerminationType.WAIT;

  def isStop(self):
    """ Tells when to send stop request to currently executing jobs """
    return self.terminationType == TerminationType.STOP

  def isStopAndWait(self):
    """ Tells when to send stop request to currently executing jobs
        and then wait for them to stop """
    return self.terminationType == TerminationType.STOP_AND_WAIT

  def isAbort(self):
    """ Tells when to just quit current job without notifying the jobs
        being executed """
    return self.terminationType == TerminationType.ABORT

  async def exec(self, aw):
    """ Execute an awaitable and return result if completed normally
        or None if terminated """
    result = None
    if self.isRunning:
      task = asyncio.create_task(aw)
      self.tasks.append(task)
      try:
        return await task
      except asyncio.CancelledError:
        # cancellation is handled below when analyzing termination type
        return None
      finally:
        if task in self.tasks:
          self.tasks.remove(task)

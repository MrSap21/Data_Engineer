import time
import os
from json import loads
import asyncio

class ReturnValue():

  def __init__(self, rc=-1, std=None):
    self.__return = rc
    self.__stdout = std
  
  @property
  def ReturnValue(self):
    return self.__return

  @property
  def OK(self):
    return self.__return == 0

  @property
  def Failed(self):
    return self.__return != 0

  @property
  def CommandOutput(self):
    return self.__stdout

  def __str__(self):
    return (f"ReturnValue(OK:{self.OK}, " +
      f"Failed:{self.Failed}, ReturnValue:{self.ReturnValue}" + '}')

async def runScript(controlFlow, command, path=None):
  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.runScript: {txt}")
  def report(res):
    if res and res[0]:
      msg(f'[stdout]\n{res[0].decode(errors="ignore")}')
    if res and res[1]:
      msg(f'[stderr]\n{res[1].decode(errors="ignore")}')

  if not controlFlow.isRunning():
    msg(f"Skipping executing command as job terminated: {command!r}")
    return ReturnValue()
  _env = os.environ
  _env["SF_USER_PWD_PASSED"] = controlFlow.jobContext.sfPassword
  _env["SQ_SERVER_CLIENT_ID_PASSED"] = controlFlow.jobContext.sq_server_client_id
  _env["SQ_SERVER_CLIENT_SECRET_PASSED"] = controlFlow.jobContext.sq_server_client_secret
  

  cmd = f"/bin/ksh -c \"{command}\""
  if path: cmd = f"/bin/ksh -c \"{path} {command}\""
  msg(f"Executing command: {cmd!r}")
  proc = await controlFlow.exec(asyncio.create_subprocess_shell(cmd,
      stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT, env=_env))
  if not controlFlow.isRunning():
    msg("Aborting before start process completed")
    return ReturnValue()
  res = await controlFlow.exec(proc.communicate())
  if not controlFlow.isCompleting():
    msg("Received termination request, canceling execution...")
    proc.terminate()
    res = await proc.communicate()
    rc =  ReturnValue(proc.returncode, res[0].decode(errors="ignore"))
    msg(f"Cancelled execution, returning: {rc}")
    report(res)
    return rc
  msg(f'{cmd!r} exited with {proc.returncode}')
  report(res)
  stdout = None
  if res: stdout = res[0].decode(errors="ignore")
  return ReturnValue(proc.returncode, stdout)

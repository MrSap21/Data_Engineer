import asyncio
from os import path
from .confirmation import Confirmation

async def waitFile(controlFlow, filePath, isAppear, timeout):
  if not controlFlow.isRunning():
    return Confirmation(False)
  tm = 0
  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.waitFile: {txt}")
  while tm <= timeout and controlFlow.isRunning():
    msg(f"Checking if file {filePath} {'appear' if isAppear else 'disappear'}ed")
    fileExists = path.exists(filePath)
    if bool(isAppear) == bool(fileExists):
      msg("File change detected, reporting success")
      return Confirmation(True)
    poll = controlFlow.jobContext.waitFilePollInterval
    if tm < poll:
      interval = 1
    else:
      interval = poll
    msg(f"Waiting for {interval} sec.")
    await controlFlow.exec(asyncio.sleep(interval))
    tm += interval
  msg("File change not detected, reporting failure")
  return Confirmation(False)

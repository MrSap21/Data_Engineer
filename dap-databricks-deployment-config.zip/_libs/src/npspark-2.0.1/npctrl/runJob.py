import time
import json
import asyncio
from aiohttp import ClientSession

class JobStatus():
  def __init__(self):
    self.__status = None
    self.__return = None
    self.__ok = None
    self.__failed = None
    self.__starttm = None
    self.__endtm = None

  @property
  def StartTime(self):
    return self.__starttm

  @StartTime.setter
  def StartTime(self, starttm):
    self.__starttm = starttm

  @property
  def EndTime(self):
    return self.__endtm

  @EndTime.setter
  def EndTime(self, endtm):
    self.__endtm = endtm

  @property
  def ReturnValue(self):
    return self.__return

  @ReturnValue.setter
  def ReturnValue(self, returncode):
    self.__return = returncode

  @property
  def OK(self):
    return self.__ok

  @OK.setter
  def OK(self, flg):
    self.__ok = flg

  @property
  def Failed(self):
    return self.__failed

  @Failed.setter
  def Failed(self, flg):
    self.__failed = flg
  
  @property
  def JobStatus(self):
    return self.__status

  @JobStatus.setter
  def JobStatus(self, status):
    if status == "SUCCESS":
      self.__status = 1
    elif status == "FAILED":
      self.__status = 4
    elif status == "TIMEDOUT":
      self.__status = 5
    elif status == "CANCELED":
      self.__status = 6
    elif status == "Exception":
      self.__status = 8
    else:
      self.__status = 999

def extract_fields_from_response(response):
    """Extract status from API's response"""
    state = response.get("state", {})
    life_cycle_state = state.get("life_cycle_state", None)
    result_state = state.get("result_state", None)
    return result_state

async def cancel_job(job_name, run_id, end_point, headers):
  def msg(txt):
    print(f"{job_name}: {txt}")
  url = end_point + "/cancel"
  payload = { "run_id": run_id }
  async with ClientSession() as session:
    await session.request(method='POST', url=url, headers=headers, json=payload)
  msg("Cancel request has been sent")

async def check_canceled(job_name, run_id, timeout, interval, end_point, headers):
  def msg(txt):
    print(f"{job_name}: {txt}")
  cancel_timeout = 0
  url = end_point + "/runs/get?run_id=" + str(run_id)
  job_status = JobStatus()
  while cancel_timeout <= timeout:
    async with ClientSession(headers=headers) as session:
      async with session.request(method='GET', url=url) as response:
        response_json = await response.json()
    status = extract_fields_from_response(response_json)
    if status:
      job_status.StartTime = response_json.get('start_time',None)
      job_status.EndTime = response_json.get('end_time',None)
      job_status.JobStatus = status
      if job_status.JobStatus == 6:
        msg("Job cancelled")
        job_status.Failed = True
        return job_status
      elif job_status.JobStatus == 1:
        msg("Job had succeded before was cancelled")
        job_status.OK = True
        return job_status
      else:
        msg("Job had terminated before was cancelled")
        job_status.Failed = True
        return job_status
    else:
      msg(f"{response_json['state']['life_cycle_state']}. Waiting {interval} sec for canceling...")
      time.sleep(interval)
      cancel_timeout += interval
  msg("wait job timeout")
  job_status.JobStatus = "TIMEDOUT"
  job_status.Failed = True
  return job_status

async def request(controlFlow, jobName, method, url, headers, payload=None):
  async with ClientSession(headers=headers) as session:
    async with session.request(method=method, url=url, json=payload) as response:
      json_body = await controlFlow.exec(response.json())
  async def ctr_status(flg):
    end_point = controlFlow.jobContext.databricksJobsApi
    timeout = controlFlow.jobContext.waitJobTimeout
    interval = controlFlow.jobContext.waitJobStatusInterval
    if flg.isAbort():
      return JobStatus()
    elif flg.isStop():
      if json_body:
        run_id = json_body.get("run_id")
        await cancel_job(jobName, run_id, end_point, headers)
      return JobStatus()
    elif flg.isStopAndWait():
      if json_body:
        run_id = json_body.get("run_id")
        await cancel_job(jobName, run_id, end_point, headers)
        job_status = await check_canceled(jobName, run_id, timeout, interval, end_point, headers)
        return job_status
      return JobStatus()
  return ctr_status, json_body

async def runJob(controlFlow, jobName, parameters):
  """
  Runs a job by name with provided parameters. If parameters contain a parameter
  set, then all key-value pairs referenced by parameter set are copied.

  Parameters:
  ----------
  controlFlow: current context
  jobName: name of a job to run
  parameters: A map of parameter name to parameter value or a parameter set

  Return:
  -------
  An instance of jobStatus class identifying execution status. This value
  is also recorded in the control flow context as per provided job name
  """
  def msg(txt):
    if controlFlow.jobContext.logEnabled:
      print(f"{controlFlow.jobName}.runJob: {txt}")
  def resultWith(status):
    controlFlow.jobStatus[jobName] = status
    return status
  job_status = JobStatus()
  if controlFlow.isRunning():
    with open(f"{controlFlow.jobContext.dbJobIdMappingFile}", 'r') as f:
      jobs = json.load(f)  
    token = controlFlow.jobContext.databricksApiAccessToken
    headers = { "Content-Type":"application/json",
                "Authorization": f"Bearer {token}" }
    end_point = controlFlow.jobContext.databricksJobsApi
    msg(f"{jobName} HAS STARTED")
    """Wrapper for running program"""
    run_id = ""
    url = end_point + "/run-now"
    kvArgs = controlFlow.jobContext.buildJobParameters(parameters)
    params = [ json.dumps(kvArgs) ]
    if controlFlow.jobContext.projectFile:
      params.append(controlFlow.jobContext.projectFile)
    payload = {
      "job_id": jobs[jobName],
      "python_params": params
      }
    timeout = controlFlow.jobContext.waitJobTimeout
    interval = controlFlow.jobContext.waitJobStatusInterval
    ctr_status, response = await request(controlFlow, jobName, method='POST',
           url=url, headers=headers, payload=payload)
    _status = await ctr_status(controlFlow)
    if _status:
      return resultWith(_status)

    run_id = response.get("run_id")    
    count = 0
    while True:
      """Get job details using databrickes API"""
      url = end_point + "/runs/get?run_id=" + str(run_id)
      _, response = await request(controlFlow, jobName, method='GET', url=url, headers=headers)
      _status = await ctr_status(controlFlow)
      if _status:
        return resultWith(_status)
      if count > timeout:
        job_status.JobStatus = "TIMEDOUT"
        job_status.Failed = True
        break
      else:
        status = extract_fields_from_response(response)
        if status:
          msg(f"{jobName} HAS FINISHED: {status}")
          job_status.StartTime = response.get('start_time',None)
          job_status.EndTime = response.get('end_time',None)
          job_status.JobStatus = status
          if job_status.JobStatus == 1:
            job_status.OK = True
          else:
            job_status.Failed = True
          break
        else: 
          msg(f"Retrieve Job Status: - {jobName} - RUNNING...")
          time.sleep(interval)
          count += interval
  return resultWith(job_status)

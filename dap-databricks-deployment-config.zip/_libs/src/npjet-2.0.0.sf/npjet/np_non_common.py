from .npcommon import *

def rowContainsMultipleCols():
  return isinstance(rowData, tuple)

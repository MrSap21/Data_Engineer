
from .np_static import *

WARNINGS = [2580, 2667, 3534, 3666, 3737, 3747, 3803, 3804, 3805, 5527, 5607]
USER_ERRORS = [100, 2123, 2538, 2541, 2632, 2639, 2641, 2644, 2654, 2805, 2809,
  2815, 2818, 2825, 2826, 2827, 2828, 2830, 2835, 2837, 2838, 2840, 2843, 2866,
  2868, 2920, 2921, 2926, 3001, 3111, 3116, 3119, 3120, 3127, 3128, 3178, 3319,
  3329, 3415, 3523, 3524, 3566, 3596, 3598, 3603, 3613, 3656, 3658, 3705, 3707,
  3708, 3802, 3807, 3824, 3873, 3877, 3897, 3916, 5495, 5880, 5991, 7423, 7592,
  7618, 7676, 8024, 8086, 9728]
SEVERE_ERRORS = [2971, 2972, 3625, 3706, 4802, 5526, 5603, 7980]

class Action:
  current = 0                 # current action
  activityCount = 0           # last record count
  errorCode = 0               # last error code
  errorCodeOverride = None    # the error code we should use on exit
  errorLevel = 0              # last errorLevel
  maxErrorLevel = None        # configured max error level
  lastSql = ""                # last SQL text executed
  connection = None           # current connection
  exportFileName = None       # export file
  importFileName = None       # import file
  repeatCount = None          # default repeat count
  quietLevel = QuietLevel.OFF # default QUIET level
  charSet = None              # input/output charset
  recordMode = True           # record mode
  forceTrim = False           # force trim
  etCount = 0                 # mimic &SYSETCNT
  uvCont = 0                  # mimic &SYSUVCNT
  
def setErrorCode(errorCode):
  Action.errorCode = errorCode
  if errorCode == 0:
    errorLevel = 0
  elif errorCode in WARNINGS:
    errorLevel = 4
  elif errorCode in USER_ERRORS:
    errorLevel = 8
  elif errorCode in SEVERE_ERRORS:
    errorLevel = 12
  else:
    # Unknown error code
    errorLevel = 8

  if(errorLevel > Action.errorLevel):
    Action.errorLevel = errorLevel
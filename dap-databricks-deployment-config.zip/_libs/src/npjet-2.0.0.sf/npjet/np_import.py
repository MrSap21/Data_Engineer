import os
import csv
import struct
from .np_static import *
from .np_connect import *
from .npcommon import *

class InvalidFieldException(Exception):
  pass


def doImport(cursor, fields, params, sqlQuery, importFile, importOptions, quietLevel):
  #print ("doImport: Quiet level is set to ON" if quietLevel == QuietLevel.ON else "",)
  #print ("doImport: Quiet level is set to OFF" if quietLevel == QuietLevel.OFF else "",)
  #print ("doImport: Quiet level is set to ALL" if quietLevel == QuietLevel.ALL else "",)

  nprint("doImport of Type: " + importOptions.type, quietLevel) 
  if "VARTEXT".lower() == importOptions.type.lower():
     doVartextImport(cursor, fields, params, sqlQuery, importFile, importOptions, quietLevel)
  elif "REPORT" == importOptions.type: 
    #fields = [["plan", 15], ["medicaid_nbr", 15], ["first_name", 15], ["last_name", 15]]
    doReportImport(cursor, fields, params, sqlQuery, importFile, importOptions, quietLevel)

def doVartextImport(cursor, fields, params, sqlQuery, importFile, importOptions, quietLevel):
  nprint(">>>importing vartext file with delimiter : " + str(importOptions.separator), quietLevel)

  #we might be reading repeatedly from the same file
  importFile.seek(0)

  query = sqlQuery.replace("?", "'{}'")
  lineCnt = 0
  skippedCount = 0
  csvReader = csv.reader(importFile, delimiter=importOptions.separator)
  for row in csvReader:
    if(len(row) > 0):
      lineCnt += 1 
      if importOptions.repeatCount != None and (lineCnt - skippedCount) > importOptions.repeatCount:
        break
      if importOptions.skipCount != None and lineCnt <= importOptions.skipCount:
        nprint("skipping row :" + str(lineCnt), quietLevel)
        skippedCount += 1
      else:
        rowValues = prepareRowValues(row, fields, params, importOptions)

        sql = query.format(*rowValues);
        #print(">>>>>>>>>>>>>> formatted sql  " + sql)
        cursor.execute(sql)


def doReportImport(cursor, fields, params, sqlQuery, importFile, importOptions, quietLevel):
  nprint(">>>importing report file", quietLevel)

  #we might be reading repeatedly from the same file
  importFile.seek(0)

  fieldWidths = []
  for f in fields:
    fieldWidths.append(f[1])

  #read line by line from file
  line = importFile.readline()
  lineCnt = 0
  skippedCount = 0
  while line:
    lineCnt += 1
    if importOptions.repeatCount != None and (lineCnt - skippedCount) > importOptions.repeatCount:
      break
    if importOptions.skipCount != None and lineCnt <= importOptions.skipCount:
      nprint("skipping row :" + str(lineCnt), quietLevel)
      skippedCount += 1
    else:
      row = getFixedLengthRowValues(fieldWidths, line)
      #print("<<<<<<<<<<rowvalues " + ",".join(row))

      query = sqlQuery.replace("?", "'{}'")
      rowValues = prepareRowValues(row, fields, params, importOptions)

      sql = query.format(*rowValues);
      cursor.execute(sql)

    line = importFile.readline()

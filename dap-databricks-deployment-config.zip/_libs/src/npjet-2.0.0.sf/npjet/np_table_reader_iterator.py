
from .np_action import *
from .npcommon import *
from .np_split_record import *
from .np_errorhandling import *

class TableReaderIterator:

  sqlList = None
  fields = None
  sqlPos = 0
  rs = None
  nextRecord = None
  failure = None
  recordNum = 0

  def __init__(self, sqlList, fields):
    self.sqlList = sqlList
    self.fields = fields

  def hasNext(self):
    if (self.failure is not None):
      return True

    try:
      while self.nextRecord is None:
        if (self.sqlPos >= len(self.sqlList)):
          return False

        if (self.rs is None):
          sql = self.sqlList[self.sqlPos]
          print("Export query: {}", sql)
          self.rs = executeStmt(sql, None)
        row = self.rs.fetchone()
        if (row is None):
          self.closeRs()
          self.sqlPos += 1
        else:
          values=list(row)
          self.recordNum += 1
          self.nextRecord = SplitRecord("", self.recordNum, self.recordNum, 1, values)

    except Exception as e:
      self.failure = e
      errorHandling(e, Action)

    return True

  def closeRs(self):
    if (self.rs is not None):
      self.cleanup(self.rs)
      self.rs = None

  def next(self):
    if (self.hasNext() == False):
      return

    if (self.failure is not None):
      return
    result = self.nextRecord
    self.nextRecord = None
    return result

  def cleanup(self, closeable):
    if (closeable is not None):
      try:
        closeable.close()
      except Exception as ex:
        print("Close operation failed.", ex)
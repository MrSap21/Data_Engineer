#!/usr/bin/python3

import os
import pyodbc
import snowflake.connector
from .np_static import *

def getDBConnection(quietLevel):
  nprint("+++ Connecting to SNOWFLAKE", quietLevel)
  snowflake.connector.paramstyle='qmark'
  if os.getenv("SF_USER_PWD_PASSED"):
    nprint("using password from SF_USER_PWD_PASSED", quietLevel)  
    sfPassword = os.getenv("SF_USER_PWD_PASSED")
  else:    
    if os.getenv("KEY_VAULT_SECRET") and os.getenv("KEY_VAULT_SECRET").lower() ==  "true":
      sfPassword = retrievePasswordFromKeyVault()
      nprint("sfPassword retrieved from keyVault", quietLevel)
    else:
      sfPassword = os.getenv('SF_USER_PWD')
  return snowflake.connector.connect(
      user=os.getenv('SF_USER_NAME'),
      password=sfPassword,
      account=os.getenv('SF_ACCOUNT_NAME'),
      database=os.getenv('SF_DATABASE_NAME'),
      schema=os.getenv('SF_SCHEMA_NAME'),
      warehouse=os.getenv('SF_WAREHOUSE_NAME'),
      role=os.getenv('SF_ROLE_NAME'),
      validate_default_parameters=True)

def getDBConnectionSQLServer(quietLevel):
  nprint("+++ Connecting to SQL Server", quietLevel)
  snowflake.connector.paramstyle='qmark'
  SQ_SERVER_DRIVER = os.getenv('SQL_SERVER_DRIVER')
  SQ_SERVER_NAME = os.getenv('SQL_SERVER_NAME')
  SQ_SERVER_DB = os.getenv('SQL_SERVER_DB')
  if os.getenv("SQ_SERVER_CLIENT_ID_PASSED") and os.getenv("SQ_SERVER_CLIENT_SECRET_PASSED"):
    nprint("using password from SQ_SERVER_CLIENT_ID_PASSED", quietLevel)  
    nprint("using password from SQ_SERVER_CLIENT_SECRET_PASSED", quietLevel)  
    client_id = os.getenv("SQ_SERVER_CLIENT_ID_PASSED")
    client_secret = os.getenv("SQ_SERVER_CLIENT_SECRET_PASSED")
  else:    
    if os.getenv("KEY_VAULT_SECRET") and os.getenv("KEY_VAULT_SECRET").lower() ==  "true":
      client_id = retrieveclientidFromKeyVault()
      client_secret = retrieveclientsecretFromKeyVault()
      nprint("client_id retrieved from keyVault", quietLevel)
      nprint("client_secret retrieved from keyVault", quietLevel)
    else:
      client_id = os.getenv('sqlserverClientID')
      client_secret = os.getenv('sqlserverClientSecret')
  return eval("""pyodbc.connect('Driver={};'
                        'Server={};'
                      'Database={};'
                      'UID={};'
                      'PWD={};'
                      'Authentication=ActiveDirectoryServicePrincipal'
                     )""".format(SQ_SERVER_DRIVER,SQ_SERVER_NAME,SQ_SERVER_DB,client_id,client_secret))

def datatype_translator(type):
  return type

def setAutoCommit(Connection):
  return

def getSqlTypeCursor(cursor):
  # sqlType = 0 - SELECT Statement
  # sqlType = 1 - Any other DDL or DML: 'status' - DROP/CREATE TABLE; 'number of rows inserted' - INSERT; 'number of rows updated' - UPDATE; 'number of rows deleted' - DELETE

  sqlTypesMap={'status': 1, 'number of rows inserted': 1 , 'number of rows updated': 1, 'number of rows deleted': 1}

  if cursor.description is not None:
    typeID = (cursor.description[0])[0]
  else:
    typeID = ''
  return sqlTypesMap.get(typeID, 0)

def getNullValue():
  return ("TEXT", None)
  
def retrievePasswordFromKeyVault():
  from pyspark.sql import SparkSession
  spark = SparkSession.builder.appName("jet2.0")\
    .getOrCreate()

  dbutils = get_dbutils(spark)
  keyVaultScope = os.getenv("KEY_VAULT_SCOPE")
  keyVaultKey = os.getenv("KEY_VAULT_SECRET_SFPASSWORD")
  sPasswd = dbutils.secrets.get(scope = keyVaultScope, key = keyVaultKey)
  return sPasswd

def retrieveclientidFromKeyVault():
  from pyspark.sql import SparkSession
  spark = SparkSession.builder.appName("jet2.0")\
    .getOrCreate()

  dbutils = get_dbutils(spark)
  keyVaultScope = os.getenv("KEY_VAULT_SCOPE")
  keyVaultKey = os.getenv("KEYVAULTSECRET_SQLSERVERCLIENTID")
  client_id = dbutils.secrets.get(scope = keyVaultScope, key = keyVaultKey)
  return client_id

def retrieveclientsecretFromKeyVault():
  from pyspark.sql import SparkSession
  spark = SparkSession.builder.appName("jet2.0")\
    .getOrCreate()

  dbutils = get_dbutils(spark)
  keyVaultScope = os.getenv("KEY_VAULT_SCOPE")
  keyVaultKey = os.getenv("KEYVAULTSECRET_SQLSERVERCLIENTSECRET")
  client_secret = dbutils.secrets.get(scope = keyVaultScope, key = keyVaultKey)
  return client_secret

def get_dbutils(spark):
  key = "spark.databricks.service.client.enabled"
  cnf = spark.conf
  if cnf.get(key) == "true":
    from pyspark.dbutils import DBUtils
    return DBUtils(spark)
  else:
    import IPython
    return IPython.get_ipython().user_ns["dbutils"]

def retrievePasswordFromKeyVaultWithAzureClient():
  from azure.keyvault.secrets import SecretClient
  from azure.identity import DefaultAzureCredential

  keyVaultName = os.getenev["KEY_VAULT_NAME"]
  KVUri = f"https://{keyVaultName}.vault.azure.net"

  credential = DefaultAzureCredential()
  client = SecretClient(vault_url=KVUri, credential=credential)

  secretKeyName= os.getenv("KEY_VAULT_SECRET_SFPASSWORD")
  print(f"Retrieving sfPassword from keyVault: {keyVaultName}.")
  
  ret = client.get_secret(secretName)
  return None if not ret else ret.value
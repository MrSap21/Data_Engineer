import sys
import getopt
import re
from np_param_parse import *


def loadArgs(argv): 
  optlist, argv = getopt.getopt(argv, 'f:l:r:u:v:j:')
  params = {}

  try:
    for opt, arg in optlist:
      # filename
      if opt.lower() == '-f':
        if arg.strip() == '' or arg is None:
          print("Enter a valid filename")
          sys.exit(2)
        else:
          params['python_filename'] = arg

      # Load
      if opt.lower() == '-l':
        if arg.strip() == '' or arg is None:
          print("Enter a valid login")
            sys.exit(2)
          else:
            params['login'] = arg

      # checkpoint directory
      if opt.lower() == '-r':
        if arg.strip() == '' or arg is None:
          print("Enter a valid checkpoint directory")
          sys.exit(2)
        else:
          params['checkpoint_dir'] = arg

      # assignment of variables in string
      if opt.lower() == '-u':
        if arg.strip() == '' or arg is None:
          print("Enter a valid argument string")
          sys.exit(2)
        else:
          double_quote = False
          if re.match(r'^".*"$', arg):
            double_quote = True
            #params['job_vars_string'] = parse_var_string(arg, ignore_encapsulating_dquotes=double_quote)
            params = {**params, **parse_var_string(arg, ignore_encapsulating_dquotes=double_quote)}

      # assignment of variables in file
      if opt.lower() == '-v':
        if arg.strip() == '' or arg is None:
          print("Enter a valid argument file")
          sys.exit(2)
        else:
          #params['job_vars_file'] = parse_var_file(arg)
          params = {**params, **parse_var_file(arg)}

      # job name
      if opt.lower() == '-j':
        if arg.strip() == '' or arg is None:
          print("Enter a valid job name")
          sys.exit(2)
        else:
          params['job_name'] = arg

  except Exception as e:
    print(str(e))

  for item in params:
    print('{key}:{value}'.format(key=item, value=params[item]))

  return params    

if __name__ == "__main__":
  main(sys.argv[1:])

#!/usr/bin/python3

import os
import runpy
import traceback
from enum import Enum
from .np_static import *
from .np_action import setErrorCode

def errorHandling(e, Action):
  if (str(type(e)) == "<class 'snowflake.connector.errors.ProgrammingError'>") :
    nprint('Error {0} ({1}): {2} ({3})'.format(e.errno, e.sqlstate, e.msg, e.sfqid), Action.quietLevel)
    if (e.sqlstate == "42S02" or
        e.sqlstate == "42501" or
        e.sqlstate == "42P01" or
        e.sqlstate == "HY000" or
        e.sqlstate == "22000"):
      setErrorCode(3807)
    elif e.sqlstate == "42000" :
      setErrorCode(3706)
    elif e.sqlstate == "42710" :
      setErrorCode(3803)
    else:
      setErrorCode(100)
  else :
    nprint('Error: ' + str(e), Action.quietLevel)
    setErrorCode(100)
  traceback.print_exc()

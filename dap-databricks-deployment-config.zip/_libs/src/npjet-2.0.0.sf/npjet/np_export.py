import os
import datetime
import csv
import tempfile
from .np_static import *
from .np_connect import datatype_translator
from .np_non_common import rowContainsMultipleCols
from .npcommon import *

BLANK = "";
lineCounter = 1
titleString = ""
titles = []
previousRowData = None
LINE_FEED = "\n";
rtitle = None
suppressedColumns = []
underline = None;

class BaseJDBCDataType:
  columnType = None
  columnPrecision = 0

  def __init__(self, columnType, precision):
    #print(">>baseJdbc " + str(columnType) + " " + str(precision))
    self.columnType = columnType
    self.columnPrecision = precision

  def getColumnPrecision(self):
    return self.columnPrecision

  def getColumnType(self):
    return self.columnType


class JDBCDataType(BaseJDBCDataType):

  CHAR = BaseJDBCDataType(2, -1)
  DATE = BaseJDBCDataType(3, 8)
  BIGINT = BaseJDBCDataType(0, 20)
  VARCHAR = BaseJDBCDataType(2, -1)
  TIMESTAMP = BaseJDBCDataType(6, -1)
  NUMBER = BaseJDBCDataType(0, 20)

  #=============================================================================
  # BYTE = JDBCDataType(-1)
  # VARBYTE = JDBCDataType(-1)
  # SMALLINT = JDBCDataType(11)
  # INTEGER = JDBCDataType(11)
  # BIGINT = JDBCDataType(20)
  # DECIMAL = JDBCDataType(40)
  # DATE = JDBCDataType(8)
  # VARCHAR = JDBCDataType(-1)
  # TIMESTAMP = JDBCDataType(-1)
  # TIME = JDBCDataType(-1)
  #=============================================================================

  typesToPrecisionMap={0: NUMBER, 1 : CHAR , 2: VARCHAR, 3 : DATE, 6: TIMESTAMP}

  def valueOf(type):
    return JDBCDataType.typesToPrecisionMap.get(type)


def setColumnsInfo(columnsInfo, exportFile, formatOptions):
  createTitleTextAndDashes(exportFile, columnsInfo, formatOptions)
  setSuppressedColumns(columnsInfo, formatOptions)


def getColumnInfo(cursor, colCount):
  d = cursor.description
  columnsInfo = [] * colCount
  i = 0
  for col in cursor.description:
#     for i in col:
#     print("++++0 " + str(col[0]))
#     print("++++1 " + str(col[1]))
#     print("++++2 " + str(col[2]))
#     print("++++3 " + str(col[3]))
#     print("++++4 " + str(col[4]))
#     print("++++5 " + str(col[5]))
#     print("++++6 " + str(col[6]))

    if i >= colCount:
      break
    columnInfo = ColumnInfo()
    columnInfo.columnName = col[0]
    if col[3] is not None:
      columnInfo.columnSize = col[3]
    translated_type = datatype_translator(col[1])
    columnInfo.columnType = JDBCDataType.valueOf(translated_type)
    #print("++++++ loaded columnInfo with columntype,columnPrecision= " + str(columnInfo.columnType.getColumnPrecision()))
    if col[4] is not None:
      columnInfo.precision = col[4]
    columnInfo.scale = col[5]
    #columnInfo.isNullable = col[6]
    columnsInfo.append(columnInfo)

    i += 1

  return columnsInfo



def createTitleTextAndDashes(exportFile, columnsInfo, formatOptions):
  global titleString
  global rtitle
  global underline
  global titles
  #FIXME - better place
  global LINE_FEED
  width = formatOptions.width
  if width == None:
    width = 254
  titleText = ''
  titleDashes = ''
  titleWidth = 254
  #end FIXME

  #reset it in between exports
  global previousRowData
  previousRowData = None

  if(formatOptions.sidetitles):
    maxLength = 0
    for colInfo in columnsInfo:
      if len(colInfo.columnName) > maxLength:
          maxLength = len(colInfo.columnName)
    for colInfo in columnsInfo:
      titles.append(colInfo.columnName.rjust(maxLength, ' '))
  elif (formatOptions.titleDashes == TitleDashesLevel.ALL_ON
          or formatOptions.underline == True 
          or isHeadingEnabled(formatOptions) 
          or isRtitleEnabled(formatOptions)):
    columnCount = len(columnsInfo)
    titleTextIndex = 0;
    for i in range(columnCount):
      columnInfo = columnsInfo[i]
      columnSize = overrideColumnSizeWithAppropriatePrecision(columnInfo, formatOptions)
      columnName = columnInfo.columnName
      lastColumn = columnCount == (i + 1)
      # verify first if adding the next column will produce a width
      # greater than the requested width i.e. value provided in
      # textFormat.getWidth()
      formattedColumnName = toTeradataFormat(columnInfo, columnName, columnSize, lastColumn,
                                              formatOptions)
      if (titleTextIndex + columnSize) > width:
        fetchCharacters = columnSize - ((titleTextIndex + columnSize) - width)
        if fetchCharacters > 0:
          if len(formattedColumnName) > fetchCharacters:
            #columnName = formattedColumnName[0, int(fetchCharacters)]
            columnName = formattedColumnName[0 : fetchCharacters]
          else:
            columnName = formattedColumnName
          titleText += columnName;
          titleDashes += "-" * fetchCharacters;
        break;
      titleTextIndex += columnSize;

      titleText+=formattedColumnName
      if isFoldColumn(i, formatOptions) and titleTextIndex < width and i != 0:
        titleDashes += ' ';
      titleDashes+=''.rjust(columnSize, '-');

      if (titleTextIndex < width and i != (columnCount - 1)):
        if(isFoldColumn(i + 1, formatOptions)):
          titleText+=LINE_FEED;

          if formatOptions.titleDashes == TitleDashesLevel.ALL_ON:
            titleText = titleText + titleDashes + LINE_FEED + ' '
            titleDashes = ''
        titleTextIndex+= 1
        titleText+=formatOptions.separator
        titleDashes+=formatOptions.separator

    titleDashesString = str(titleDashes)
    titleWidth = len(titleDashesString)
    if formatOptions.underline == True:
      underline = (titleDashesString + LINE_FEED).replace(' ', '-')
      underline = underline.replace(formatOptions.separator, '-')

  rtitleText = ""
  # Create rtitle and print on the first line
  if isRtitleEnabled(formatOptions) or isHeadingEnabled(formatOptions):
    if isRtitleEnabled(formatOptions):
      rtitleText = formatOptions.rtitle
    else:
      rtitleText = formatOptions.heading
    customized = ("&date" in rtitleText
               or "&time" in rtitleText
               or "&page" in rtitleText
               or isHeadingEnabled(formatOptions))

    rightNow = datetime.datetime.now();
    date = rightNow.date()
    dateString = date.strftime("%y/%m/%d");
    #time = new SimpleDateFormat("HH:mm").format(date);
    time = str(rightNow.time());
    if customized:
      rtitleText = rtitleText.replace("&date", dateString).replace("&time", time);

    # 10 chars for  page number and 'page ' word
    if customized:
      dataLength = len(rtitleText);
    else:
      dataLength = len(rtitleText) + len(dateString) + 10;

    if (dataLength + 2) > titleWidth:
      titleWidth = dataLength + 2;

    space1 = (titleWidth - dataLength) // 2;
    space2 = titleWidth - dataLength - space1;
    if customized:
      rtitleTemp = "{:<" + str(space1) + "}" + "{}{:>" + str(space2) + "}"
      rtitle = rtitleTemp.format("", rtitleText, "")
    else:
      rtitleTemp = "{}{:<" + str(space1) + "}" + "{}{:<" + str(space2) + "}page " + "{}"
      rtitle = rtitleTemp.format(dateString, "", rtitleText, "", "&page")

    output(exportFile, formatOptions, rtitle.replace("&page", "{:5d}".format(1)) + LINE_FEED + LINE_FEED);

  if formatOptions.sidetitles == False and formatOptions.titleDashes == TitleDashesLevel.ALL_ON:
      lines = [titleText, LINE_FEED, titleDashes, LINE_FEED]
      titleString = "".join(lines);
      output(exportFile, formatOptions, titleString)


def setSuppressedColumns(columnsInfo, formatOptions):
  if formatOptions.isSuppressApplicable:
    global suppressedColumns  
    suppressedColumns = [False] * len(columnsInfo)
    for suppressColumn in formatOptions.suppressedColumns:
      if (suppressColumn <= len(columnsInfo)):
        suppressedColumns[suppressColumn - 1] = True;



#
def isRtitleEnabled(formatOptions):
  return formatOptions.format == "ON" and formatOptions.rtitle is not None;


#
def isHeadingEnabled(formatOptions):
  return formatOptions.format == "ON" and formatOptions.heading is not None;


##
# @param columnInfo: the column to return the precision for
# @return precision for this specific column
##
def overrideColumnSizeWithAppropriatePrecision(columnInfo, formatOptions):
  #TERADATA data type precision can supersede column precision
  result = columnSize(columnInfo);
  #print(">>>overrideColumnSizeWithAppropriatePrecision starting with: " + str(result))
  if columnInfo.columnSize == columnInfo.UNDEFINDED_COLUMN_SIZE:
    #print(">>>overrideColumnSizeWithAppropriatePrecision 0: " + str(len(columnInfo.columnName)))
    result = len(columnInfo.columnName)

  #if TITLEDASHES is ON column name length can supersede previous precision
  if formatOptions.titleDashes == TitleDashesLevel.ALL_ON:
    #print(">>>overrideColumnSizeWithAppropriatePrecision 1")
    if len(columnInfo.columnName) > result:
      #print(">>>overrideColumnSizeWithAppropriatePrecision 2 : " + str(len(columnInfo.columnName)))
      result = len(columnInfo.columnName)
  return result;


##
# @param columnInfo: i.e. reference to columnName, columnSize, type
# @param columnData: the data associated to this column
# @param columnSize: the column precision
# @param lastColumn: does this column represent the last column of the row
# @return the data formated according to the TERADATA data type
##
def toTeradataFormat(columnInfo,
            stringToFormat, columnSize, lastColumn, formatOptions):
  result = None
  colType = columnInfo.columnType;
  if(colType is not None):
    type = colType.getColumnType()
  else:
    type = None  
  #if (type == "INTEGER" or type == "DECIMAL" or type == "DATE" or type == "BIGINT"):
  if (type == 0 or type == 0 or type == 3 or type == 6):
    result = str(stringToFormat).rjust(columnSize, ' ')
  else:
    if (lastColumn == True and formatOptions.fastExport == False):
      result = stringToFormat
    else:
      result = str(stringToFormat).ljust(columnSize, ' ')
  return result;

##
#
##
def columnSize(columnInfo):
  #TERADATA data type precision can supersede column precision
  if(isinstance(columnInfo, type(None))):
    return None
  if(columnInfo.columnType is not None and columnInfo.columnType.getColumnPrecision() > 0):
    #print("++++ColumnSize() returning colInfo,columnPrecison: " + str(columnInfo.columnType.getColumnPrecision()))
    return columnInfo.columnType.getColumnPrecision()
  else:
    #print("++++columnSize() returning colInfo,columnSize: " + str(columnInfo.columnType.getColumnPrecision()))
    return columnInfo.columnSize

##
#
##
def isFoldColumn(currentColIndex, formatOptions):
  return formatOptions.isFoldlineApplicable == True and (
      len(formatOptions.foldlineColumns) == 0 or currentColIndex in formatOptions.foldlineColumns)

##
#
##
def output(exportFile, formatOptions, text):
  global lineCounter
  if(rtitle is not None and "\n" in text):
    stringBuilder = []
    for c in list(text):
      stringBuilder.append(c);
      if c == '\n':
        lineCounter += 1

        # BTEQ adds two empty line before next page
        # Probably footer and page break
        if(lineCounter % formatOptions.pageLength == 0):
          stringBuilder.append(LINE_FEED)
          stringBuilder.append(LINE_FEED)
          stringBuilder.append(str(rtitle.replace("&page", "{:5d}".format((lineCounter // formatOptions.pageLength) + 1))))
          stringBuilder.append(LINE_FEED)
          stringBuilder.append(LINE_FEED)
          lineCounter +=4;

          if formatOptions.titleDashes == TitleDashesLevel.ALL_ON:
            stringBuilder.append(titleString)
            lineCounter += 2

    text = ''.join(stringBuilder)
  if formatOptions.charSet != None:
    exportFile.write(bytes(text.encode(formatOptions.charSet)))
  else:
    exportFile.write(text)


##
# matchesPreviousRowData
## 
def matchesPreviousRowData(index, rowData):
  for i in range(0, index+1):
    if previousRowData[i] != rowData[i]:
      return False
  return True;

##
# writeRecord
##
def writeRecord(exportFile, recNum, columnsInfo, rowData, formatOptions):
  global previousRowData
  global titles
  #FIXME - better place
  width = formatOptions.width
  if width == None:
    width = 254
  #end FIXME

  columnCount = len(columnsInfo)
  dataIndex = 0
  skipLine = False

  stringBuilder = []
  for i in range(columnCount):
    columnInfo = columnsInfo[i]
    columnSize = overrideColumnSizeWithAppropriatePrecision(columnInfo, formatOptions);
    if rowContainsMultipleCols:
      data = rowData[i]
    else:
      data = rowData
    lastColumn = columnCount == i + 1;
    #
    # BTEQ always displays the first occurrence of a new value in each column,
    # regardless of the setting of the SUPPRESS command options. After that, if
    # the SUPPRESS command option is set to ON, BTEQ replaces those values with
    # space characters in the specified columns. (Each row containing a new value
    # can be preceded by one or more blank lines, depending on the settings of
    # the SKIPLINE and SKIPDOUBLE commands options.)
    #
    if (formatOptions.isSuppressApplicable and previousRowData is not  None and suppressedColumns[i]):
      if (matchesPreviousRowData(i, rowData)):
        data = BLANK;
        #SKIPLINE
      else:
        skipLine = True;
    if(data == None):
      data = formatOptions.nullReplacement;

    formatedData =  toTeradataFormat(columnInfo, data, columnSize, lastColumn, formatOptions)

    if (dataIndex + columnSize > width):
      fetchCharacters = columnSize - ((dataIndex + columnSize) - width);
      if (fetchCharacters > 0): 
        if formatOptions.sidetitles:
          stringBuilder.append(titles[i])
          stringBuilder.append(formatOptions.separator)
        else:
          stringBuilder.append(formatedData)

        if formatOptions.sidetitles:
          stringBuilder.append(LINE_FEED);
      break
    dataIndex += columnSize;
    #include separator between columns
    if (dataIndex < width and i != columnCount - 1 and not formatOptions.sidetitles):
      dataIndex += 1
      if(isFoldColumn(i + 1, formatOptions)):
        formatedData +=LINE_FEED
        formatedData += " "
        # Reseting line width after new line
        dataIndex = len(formatOptions.separator)

      formatedData += formatOptions.separator;

    if formatOptions.sidetitles:
      stringBuilder.append(titles[i])
      stringBuilder.append(formatOptions.separator);
    stringBuilder.append(formatedData);
    if formatOptions.sidetitles:
      stringBuilder.append(LINE_FEED);

  if (previousRowData is not None and
      underline is not None and
      formatOptions.underline == True and
      (formatOptions.underlineColumns is None or len(formatOptions.underlineColumns) == 0
         or
       isUnderlineColumnsDifferent(formatOptions.underlineColumns, rowData)
      )):
    output(exportFile, formatOptions, underline)

  if (skipLine):
    output(exportFile, formatOptions, LINE_FEED)

  output(exportFile, formatOptions, ''.join(str(v) for v in stringBuilder))

  if formatOptions.sidetitles == False:
    output(exportFile, formatOptions, LINE_FEED)

  if (formatOptions.isSuppressApplicable or formatOptions.underline == True):
    previousRowData = rowData



##
#
##
def isUnderlineColumnsDifferent(underlineColumns, rowData):
  for c in underlineColumns:
    if rowData[c-1] != previousRowData[c-1]:
      return True
  return False


def writeToTempFile(resultSet,
                    tempFile,
                    maxWidth,
                    columnInfo):

  colCount = len(columnInfo)
  for row in resultSet:
    for i in range(colCount):
      data = row[i]
      if data != None:
        if type(data) is tuple:
          s = ''
          for item in data:
            s += item
          data = s
        if columnInfo[i].isSizeUndefined() and len(data) > maxWidth[i]:
          maxWidth[i] = len(data)
        tempFile.write(data)
    tempFile.write('\n')
  tempFile.seek(0)

def runSql(sql):
  executeSql([], [(sql, [])])

def runSqlWithParams(sql, params):
  executeSql([], [(sql, params)])

def executeSql(fields, sqlsAndParams):
  Action.errorCode = 0
  Action.activityCount = 0

  ImportOptions.repeatCount = Action.repeatCount
  ImportOptions.forceTrim = Action.forceTrim
  FormatOptions.charSet= Action.charSet

  if Action.exportFileName is  None:
    runExport2(None, fields, sqlsAndParams)
  else:
    runExport(Action.exportFileName, fields, sqlsAndParams)

def runExport(exportFileName, fields, sqlsAndParams):
  try:
    if Action.charSet != None:
      exportFile = open(exportFileName, "wb")
    else:
      exportFile = open(exportFileName, "w+", newline="\n")
  except Exception as ex:
    setErrorCode(4802)
    nprint("Failed to open file: " + exportFileName, Action.quietLevel)
    return
  runExport2(exportFile, fields, sqlsAndParams)
  exportFile.close()


def runExport2(exportFile, fields, sqlsAndParams):
  if len(fields) == 0:
    # plain sql, 1 or more times
    executeExport(sqlsAndParams[0], None, exportFile)

  else:
    # sql is parameterized with values read from file
    #for (int ndx = 0; isRepeat.test(ndx) && it.hasNext(); ++ndx) {
    # iterate over rows in file 
    if Action.importFileName  != None:
      importFile = open(Action.importFileName, "r")
      if "VARTEXT".lower() == ImportOptions.type.lower():
        iterateCsvFile(importFile, fields, sqlsAndParams)
      elif "REPORT" == ImportOptions.type:
        iterateFixedLengthFile(importFile, fields, sqlsAndParams)

      importFile.close()
      print("closing import file")


def iterateCsvFile(importFile, fields, sqlsAndParams):
  nprint("Iterate CSV file :" + importFile.name, Action.quietLevel)
  lineCnt = 0
  skippedCount = 0
  csvReader = csv.reader(importFile, delimiter=ImportOptions.separator)
  for row in csvReader:
    #nprint("+++++++++++++++++++++++++++++ row: " + ".".join(map(str, row)), Action.quietLevel)
    if(len(row) > 0):
      lineCnt += 1
      if ImportOptions.repeatCount != None and (lineCnt - skippedCount) > ImportOptions.repeatCount:
        nprint("repeat count reached :" + str(lineCnt), Action.quietLevel)
        break
      if ImportOptions.skipCount != None and lineCnt <= ImportOptions.skipCount:
        nprint("skipping row :" + str(lineCnt), Action.quietLevel)
        skippedCount += 1
      else:
        for sql in sqlsAndParams:
          params = sql[1]
          rowValues = prepareRowValues(row, fields, params, ImportOptions)
          #nprint(">>>>>>>>>rowValues: " + ".".join(map(str, rowValues)), Action.quietLevel)
          executeExportStmt(sql[0], rowValues, None)


def iterateFixedLengthFile(importFile, fields, sqlsAndParams):
  nprint("Iterate REPORT file :" + importFile.name, Action.quietLevel)
  fieldWidths = []
  for f in fields:
    fieldWidths.append(f[1])

  #read line by line from file
  line = importFile.readline()
  lineCnt = 0
  skippedCount = 0
  while line:
    lineCnt += 1
    if ImportOptions.repeatCount != None and (lineCnt - skippedCount) > ImportOptions.repeatCount:
      nprint("repeat count reached :" + str(lineCnt), Action.quietLevel)
      break
    if ImportOptions.skipCount != None and lineCnt <= ImportOptions.skipCount:
      nprint("skipping row :" + str(lineCnt), Action.quietLevel)
      skippedCount += 1
    else:
      row = getFixedLengthRowValues(fieldWidths, line)
      #nprint("<<<<<<<<<<rowvalues " + ",".join(row), Action.quietLevel)
      for sql in sqlsAndParams:
        params = sql[1]
        rowValues = prepareRowValues(row, fields, params, ImportOptions)
        #nprint(">>>>>>>>>rowValues: " + ".".join(map(str, rowValues)), Action.quietLevel)
        executeExportStmt(sql[0], rowValues, None)
    line = importFile.readline()


def executeExport(sql, args, exportFile):
  executeExportStmt(sql[0], args, exportFile)

def executeExportStmt(sql, args, exportFile):
  cursor = None
  try:
    cursor = executeStmt(sql, args)
    lastRecordCount = 0
    #if(!stmt.execute)=
    #print("sqlType", getSqlTypeCursor(cursor))
    if getSqlTypeCursor(cursor) == 1:
      lastRecordCount = cursor.rowcount
      if lastRecordCount == 1:
        normalizedSql = sql.strip().upper();
        # getUpdateCount return -1 for DDL in java but the pythin connector
        # returns 1 in spite of documentation 
        # If exception was not thrown then call was successful
        if (normalizedSql.startswith("DROP") or
            normalizedSql.startswith("CREATE") or
            normalizedSql.startswith("ALTER")):
          lastRecordCount = 1;
    elif (exportFile is not None):  # else

      resultSet = cursor.fetchall(  )
      rsMetadata = cursor.description
      rsColCount = len(rsMetadata)

      colCount = 0
      if ExportOptions.colLimit < rsColCount:
        colCount = ExportOptions.colLimit
      else:
        colCount = rsColCount
      columnInfo = getColumnInfo(cursor, colCount)
      #print(">>>>>>>>>>>>>>>> columnInfo len " + str(len(columnInfo)))

      undefinedColumnSizeFound = False
      maxWidth = [None] * colCount
      tempFile = None
      for i in range(colCount):
        if(columnInfo[i - 1].isSizeUndefined()):
          #Undefined column size detected. Need write
          #to temp file and calculate size
          undefinedColumnSizeFound = True;
          maxWidth[i - 1] = -1;

      iterateOverResultSet = False
      isEmpty = True
      if undefinedColumnSizeFound:
        tempFile = tempfile.TemporaryFile(mode="r+", newline="\n")
        writeToTempFile(resultSet, tempFile, maxWidth, columnInfo)
        for i in range(colCount):
          if columnInfo[i].isSizeUndefined():
            columnInfo[i].size = maxWidth[i]
          #r = fileDataProvider(tempFile, columnInfo)
          #if r == None:
          #  nprint("Failed to instantiate file data provider")
          #  return
      else:
        iterateOverResultSet = True

      #while (true):
      #Either<Failure, Boolean> rn = dataProvider.next();
      if iterateOverResultSet == True:
        for rowData in resultSet:
          if isEmpty == True:
            isEmpty = False
            setColumnsInfo (columnInfo, exportFile, FormatOptions)
          writeRecord(exportFile, lastRecordCount, columnInfo, rowData, FormatOptions)
          #ATEM-741 Adding actual number of rows processed
          #recordCount = getRecordCount(columnInfo, dataProvider);
          lastRecordCount += 1
          if ExportOptions.rowLimit != None and ExportOptions.rowLimit <= lastRecordCount:
            break
        if isEmpty == True:
          nprint("(Empty Result Set)", Action.quietLevel)
      else:
        fileLine = tempFile.readline()
        isEmpty = True
        while fileLine:
          isEmpty = False
          writeRecord(exportFile, lastRecordCount, columnInfo, fileLine, FormatOptions)
          #ATEM-741 Adding actual number of rows processed
          #recordCount = getRecordCount(columnInfo, dataProvider);
          lastRecordCount += 1
          if ExportOptions.rowLimit != None and ExportOptions.rowLimit <= lastRecordCount:
            break
          fileLine = tempFile.readline()
        if isEmpty:
          nprint("(Empty Result Set)", Action.quietLevel)
      if tempFile is not None:
        tempFile.close()
    else:
        resultSet = cursor.fetchall()
        metadata = cursor.description
        columnList = ""
        underLine = ""
        for columnDescr in metadata:
            columnList = columnList + columnDescr[0] + ' ' * 8
            underLine = underLine + '=' * len(columnDescr[0]) + '=' * 8
        if Action.quietLevel != QuietLevel.ALL and Action.quietLevel != QuietLevel.ON:
           print(columnList)
           print(underLine)
        isEmpty = True
        for row in resultSet:
            isEmpty = False
            rowList = ""
            for column in row:
                rowList = rowList + str(column) + ' ' * 8
            if Action.quietLevel != QuietLevel.ALL and Action.quietLevel != QuietLevel.ON:
               print(rowList)
        if isEmpty == True:
           if Action.quietLevel != QuietLevel.ALL and Action.quietLevel != QuietLevel.ON:
              print("(Empty Result Set)")

    if Action.quietLevel != QuietLevel.ALL and Action.quietLevel != QuietLevel.ON:
       print("++++++ activityCount : " +  str(Action.activityCount))

  except Exception as e:
      errorHandling(e, Action)
  finally:
    if cursor is not None:
      cursor.close()
    print("++++++ Done, errorCode " + str(Action.errorCode) + ", errorlevel: " + str(Action.errorLevel))


def getSqlResult(sql):
  args = []
  cursor = None
  try:
    cursor = executeStmt(sql, args)
    if getSqlTypeCursor(cursor) != 0:
      fprint("++++Only select statements are supported by this method")
      return

    resultSet = cursor.fetchall(  )
    rsMetadata = cursor.description
    rsColCount = len(rsMetadata)

    if(rsColCount > 1):
      print("++++Result should contain only one column, found ", rsColCount)
      return

    if len(resultSet) == 0:
      return None

    row = resultSet[0]
    data = row[0]
    if data != None:
      if type(data) is tuple:
        s = ''
        for item in data:
          s += item
        data = s
    return data

    if Action.quietLevel != QuietLevel.ALL and Action.quietLevel != QuietLevel.ON:
       fprint("++++++ activityCount : " +  str(Action.activityCount))

  except Exception as e:
      errorHandling(e, Action)
  finally:
    if cursor is not None:
      cursor.close()
    print("++++++ Done, errorCode " + str(Action.errorCode) + ", errorlevel: " + str(Action.errorLevel))
#!/usr/bin/python3
import re

# parses a var file and returns a dictionary of the variable mappings
def parse_var_file(file_input, assignment_operator = '='):

  out = {}

  with open(file_input,'r') as f:
    for line in f.readlines():
      if line.strip() == '':
        continue
      splitted = line.split(assignment_operator)
      out[splitted[0].strip()] = splitted[1].strip()

  return out

# parses a delimited string and returns a dictionary of the variables mappings
def parse_var_string(string_input, assignment_operator = '=', delimiter = ',', ignore_encapsulating_dquotes = True):

  tmp = string_input.strip()
  out = {}

  if ignore_encapsulating_dquotes:
    tmp = tmp[1:-1]

  pattern = ",(?=(?:[^\']*\'[^\']*\')*[^\']*$)".replace(',', delimiter)
  parameters = re.split(pattern,tmp)

  for param in parameters:
    splitted = param.split(assignment_operator)
    out[splitted[0].strip()] = splitted[1].strip()

  return out
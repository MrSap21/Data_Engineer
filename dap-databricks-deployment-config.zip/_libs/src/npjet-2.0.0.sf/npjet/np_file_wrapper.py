import gzip
from zipfile import *
from io import *
from .npcommon import *
from .np_split_record import *
from .np_mapped_iterator import *
from .np_table_reader_iterator import *
from .np_record_mapper import *

class FileWrapper:

  exportFile = None
  exportFileName = None

  def __init__(self, exportFileName, isAppend):
    self.exportFileName = exportFileName
    if(exportFileName.endswith(".zip")):
      if(isAppend):
        print("Not supported error")
      else:
        self.exportFile = BytesIO()
    elif(exportFileName.endswith(".gz")):
      if(isAppend):
        self.exportFile = gzip.open(exportFileName, "ab")
        self.exportFile.write(bytes("\n", Action.charSet))
      else:
        self.exportFile = gzip.open(exportFileName, "wb")

    else:
      if(isAppend):
        self.exportFile = open(exportFileName, "ab")
        self.exportFile.write(bytes("\n", Action.charSet))
      else:
        self.exportFile = open(exportFileName, "wb")

  def write(self, data):
    self.exportFile.write(data)

  def close(self):
    if(self.exportFileName.endswith(".zip")):
      file = ZipFile(self.exportFileName, "w")
      file.writestr(self.exportFileName[:-4], self.exportFile.getvalue())
      file.close()
    else:
      self.exportFile.close()
from .npcommon import *
from .np_split_record import *

class RecordMapper:

  fieldMap = None

  def __init__(self, sourceFields, targetFields):
    self.fieldMap = [sourceFields.index(tg) for tg in targetFields]

  def map(self, record):
    targetValues = record.fields
    if not self.fieldMap:
      targetValues = record.fields
    else:
      targetValues = [record.fields[i] for i in self.fieldMap]
    return SplitRecord(record.rawData, record.recordNum, record.startLineNum, record.lineCount, targetValues)
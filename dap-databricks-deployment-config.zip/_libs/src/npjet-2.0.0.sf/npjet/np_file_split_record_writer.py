from io import *
from .npcommon import *
from .np_split_record import *
from .np_mapped_iterator import *
from .np_table_reader_iterator import *
from .np_record_mapper import *
from .np_file_wrapper import *

def writeFile(sqls, sourceColumns, targetColumns, fileName, isAppend, mappers):
  tableIterator = TableReaderIterator(sqls, sourceColumns)
  recordMapper = RecordMapper(sourceColumns, targetColumns)
  recordIterator = MappedIterator(tableIterator, recordMapper)
  writeSplitRecords(recordIterator, fileName, isAppend, mappers)

def writeSplitRecords(recordIterator, fileName, isAppend, mappers):
  writer = openFile(fileName, isAppend)
  if(writer is None):
    print("Can't create export file: " + fileName)
    return
  writeRecords(recordIterator, writer, mappers)
  try:
    writer.close()
  except Exception as e:
    nprint("+++exception closing export file " + str(e), Action.quietLevel)

def openFile(exportFileName, isAppend):
  try:
    wrapper = FileWrapper(exportFileName, isAppend)
    return wrapper
  except Exception as ex:
    Action.errorCodeOverride = 8
    return

def writeRecords(recordIterator, writer, mappers):
  count = 0
  record = recordIterator.next()
  while(record is not None):
    writeSplitRecord(writer, record, mappers)
    count += 1
    record = recordIterator.next()
    if(record is not None):
      writer.write(bytes("\n", Action.charSet))
  return count

def writeSplitRecord(writer, record, mappers):
    values = record.fields
    for pos in range(len(values)):
      if not mappers:
        cellValue = "" if not values[pos] else str(values[pos]) + FormatOptions.separator
      else: 
        cellValue = mappers[pos](values[pos])
      b = bytes("" if not cellValue else cellValue, Action.charSet)
      writer.write(b)

def textWithWidth(width):
  def textWithWidthFunction(value):
    if(len(value) < width):
      return value.rjust(width, " ")
    else:
      if(len(value) > width):
        return value[0: width]
      else:
        return value
  return textWithWidthFunction

def delimitedField(delimiter, delimiterEscape, isLast):
  def delimitedFieldFunction(value):
    if(delimiterEscape is None):
      escapedValue = value
    else:
      escapedValue = checkInsertEscape(value, delimiter, delimiterEscape)
    return appendDelimiter(delimiter, isLast, escapedValue);
  return delimitedFieldFunction

def appendDelimiter(delimiter, isLast, value):
  if(value is None):
    value = ""
  else:
    value = str(value)
  if(isLast):
    return value
  else:
    return value + delimiter

def checkInsertEscape(value, delimiter, delimiterEscape):
  if(delimiter not in value):
    return value
  else:
    return insertEscape(value, delimiter, delimiterEscape)

def insertEscape(value, delimiter, delimiterEscape):
  return value.replace(delimiter, delimiterEscape + delimiter)

def delimitedMandatoryQuotedFile(delimiter, startQuote, endQuote, escapeQuote, isLast):
  def delimitedMandatoryQuotedFileFunction(value):
    return appendDelimiter(delimiter, isLast, addQuotes(value, startQuote, endQuote, escapeQuote))
  return delimitedMandatoryQuotedFileFunction

def addQuotes(value, startQuote, endQuote, escapeQuote):
  return startQuote + insertEscape(value, endQuote, escapeQuote) + endQuote

def delimitedOptionallyQuotedFile(delimiter, startQuote, endQuote, escapeQuote, isLast):
  def delimitedOptionallyQuotedFileFunction(value):
    if(delimiter in value or startQuote in value):
      return appendDelimiter(delimiter, isLast, addQuotes(value, startQuote, endQuote, escapeQuote))
    else:
      return appendDelimiter(delimiter, isLast, value)
  return delimitedOptionallyQuotedFileFunction
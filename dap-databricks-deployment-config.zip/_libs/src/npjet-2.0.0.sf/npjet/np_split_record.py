
class SplitRecord:
  rawData = None
  recordNum = 0
  startLineNum = 0
  lineCount = 0
  fields = None

  def __init__(self, rawData, recordNum, startLineNum, lineCount, fields):
    self.rawData = rawData
    self.recordNum = recordNum
    self.startLineNum = startLineNum
    self.lineCount = lineCount 
    self.fields = fields
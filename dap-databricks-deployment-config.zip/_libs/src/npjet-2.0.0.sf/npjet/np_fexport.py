import os
import sys
from .npcommon import *
from .np_connect import *
from .np_export import *
from .np_import import *
from .np_static import *
from .np_errorhandling import *

def executeFStmt(sql, args):
  Action.activityCount = 0
  FormatOptions.charSet = Action.charSet
  try:
    cursor = executeStmt(sql, args)

    lastRecordCount = 0
    if getSqlTypeCursor(cursor) == 1:
      lastRecordCount = cursor.rowcount
      if lastRecordCount == 1:
        normalizedSql = sql.strip().upper();
        # getUpdateCount return -1 for DDL in java but the python connector
        # returns 1 in spite of documentation 
        # If exception was not thrown then call was successful
        if (normalizedSql.startswith("DROP") or
            normalizedSql.startswith("CREATE") or
            normalizedSql.startswith("ALTER")):
          lastRecordCount = 1;

    return cursor

  except Exception as e:
      errorHandling(e, Action)

def executeFExport(exportFileName, cursor):

  # Open file for export
  try:
    if Action.charSet != None:
      exportFile = open(exportFileName, "wb")
    else:
      exportFile = open(exportFileName, "w+", newline="\n")
  except Exception as ex:
    Action.errorCodeOverride = 8
    return

  # Exporting data
  try:
    resultSet = cursor.fetchall()
    rsMetadata = cursor.description
    rsColCount = len(rsMetadata)
  except Exception as e:
    errorHandling(e, Action)
    # Handler has no mapping for error
    if Action.errorCode == 100:
      setErrorCode(3708)
    return

  colCount = 0
  if ExportOptions.colLimit < rsColCount:
    colCount = ExportOptions.colLimit
  else:
    colCount = rsColCount
  columnInfo = getColumnInfo(cursor, colCount)

  undefinedColumnSizeFound = False
  maxWidth = [None] * colCount

  for i in range(colCount):
    if(columnInfo[i - 1].isSizeUndefined()):
      #Undefined column size detected. Need write
      #to temp file and calculate size
      undefinedColumnSizeFound = True;
      maxWidth[i - 1] = -1;

  iterateOverResultSet = False
  isEmpty = True
  if undefinedColumnSizeFound:
    tempFile = open("fexp.output", "w+", newline="\n")
    writeToTempFile(resultSet, tempFile, maxWidth, columnInfo)
    for i in range(colCount):
      if columnInfo[i].isSizeUndefined():
        columnInfo[i].size = maxWidth[i]
  else:
    iterateOverResultSet = True

  lastRecordCount = 0

  if iterateOverResultSet == True:
    for rowData in resultSet:
      if isEmpty == True:
        isEmpty = False
        setColumnsInfo (columnInfo, exportFile, FormatOptions)
      writeRecord(exportFile, lastRecordCount, columnInfo, rowData, FormatOptions)
      #ATEM-741 Adding actual number of rows processed
      #recordCount = getRecordCount(columnInfo, dataProvider);
      lastRecordCount += 1
      if ExportOptions.rowLimit != None and ExportOptions.rowLimit <= lastRecordCount:
        break
    if isEmpty == True:
      fprint("(Empty Result Set)")
  else:
    fileLine = tempFile.readline()
    while fileLine:
      writeRecord(exportFile, lastRecordCount, columnsInfo, fileLine, formatOptions)
      #ATEM-741 Adding actual number of rows processed
      #recordCount = getRecordCount(columnInfo, dataProvider);
      lastRecordCount += recordCount
      if ExportOptions.rowLimit != None and ExportOptions.rowLimit <= lastRecordCount:
        break
      fileLine = tempFile.readline()
    if isEmpty == True:
      fprint("(Empty Result Set)")

  if exportFile != None:
    exportFile.close()
  return True

def setFexpDefaultFormatOptions():
  FormatOptions.fastExport = True
  Action.quietLevel = QuietLevel.OFF
  FormatOptions.nullReplacement = " "
  FormatOptions.separator = ""
  FormatOptions.format = "ON"
  FormatOptions.titleDashes = "ALL_ON"
  FormatOptions.isFoldlineApplicable = False
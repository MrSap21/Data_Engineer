
class MappedIterator:

  iterator = None
  mapper = None

  def __init__(self, iterator, mapper):
    self.iterator = iterator
    self.mapper = mapper

  def hasNext(self):
    return self.iterator.hasNext()

  def next(self):
    sourceRecord = self.iterator.next()
    if(sourceRecord is not None):
      return self.mapper.map(sourceRecord)
    else:
      return None

  def closeRs(self):
    self.iterator.closeRs()

  def cleanup(self, closeable):
    self.iterator.cleanup(closeable)
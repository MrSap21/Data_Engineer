
import os
import runpy
from enum import Enum

class QuietLevel(Enum):
  OFF = 0
  ON = 1
  ALL = 2

class EchoReqLevel(Enum):
  ON = 0
  OFF = 1
  ERROR_ONLY = 2

class TitleDashesLevel(Enum):
  ALL_ON = 0
  ALL_OFF = 1

class ColumnInfo:
 UNDEFINDED_COLUMN_SIZE = 16777216
 columnName = None
 columnSize = 0
 columnType = None
 precision = 0
 scale = 0
 def isSizeUndefined(self):
   return self.columnSize == self.UNDEFINDED_COLUMN_SIZE


def nprint(text, level):
  if level != QuietLevel.ALL:
    print(text)

from .npcommon import *

def getTable(tn):
  return tn
  
def getFieldQuote():
  if LoadOptions.fieldQuote != None:
      return " FIELD_OPTIONALLY_ENCLOSED_BY = '" + LoadOptions.fieldQuote + "'"
  else:
      return ""
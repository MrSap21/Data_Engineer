import os
import sys
import runpy
import traceback
import struct
import subprocess
import shlex

from enum import Enum
from .np_connect import *
from .np_static import *
from .np_errorhandling import errorHandling
from .np_action import *

WARNINGS = [2580, 2667, 3534, 3666, 3737, 3747, 3803, 3804, 3805, 5527, 5607]
USER_ERRORS = [100, 2123, 2538, 2541, 2632, 2639, 2641, 2644, 2654, 2805, 2809,
  2815, 2818, 2825, 2826, 2827, 2828, 2830, 2835, 2837, 2838, 2840, 2843, 2866,
  2868, 2920, 2921, 2926, 3001, 3111, 3116, 3119, 3120, 3127, 3128, 3178, 3319,
  3329, 3415, 3523, 3524, 3566, 3596, 3598, 3603, 3613, 3656, 3658, 3705, 3707,
  3708, 3802, 3807, 3824, 3873, 3877, 3897, 3916, 5495, 5880, 5991, 7423, 7592,
  7618, 7676, 8024, 8086, 9728]
SEVERE_ERRORS = [2971, 2972, 3706, 4802, 5526, 5603, 7980]

class FormatOptions:
  format = "ON"  
  titleDashes = TitleDashesLevel.ALL_ON
  underline = False
  rtitle = None
  pageLength = 55
  heading = None
  sidetitles = False
  separator = "  "
  width = 254
  isSuppressApplicable = False
  suppressedColumns = None
  underlineColumns = None
  nullReplacement = "?"
  isFoldlineApplicable = False
  foldlineColumns = None
  echoReqLevel = EchoReqLevel.ON
  charSet = None
  fastExport = False

class ImportOptions:
  type = None
  separator = None
  skipCount = None
  repeatCount = None
  forceTrim = False

class ExportOptions:
  colLimit = 100
  rowLimit = None

class LoadOptions:
  fieldQuote = None  
  delimiter = "|"
  type = None
  sfErrorHandler = """ON_ERROR=CONTINUE"""
  azErrorHandler = """, MAXERRORS=999999999"""
  azContainerName = os.getenv('AZ_CONTAINER_NAME')
  ignoreDuplicatesInsert = " DISTINCT "
  ignoreMissingUpdate = ""
  maxErrorCount = 999999999
  importFileName = None 
  inputCharset="UTF-8"
  fieldQuote = None


class FastLoadOptions(LoadOptions):
  columnNames = None
  targetTableName = None
  err2TableName = None
  values = None
  recordRangeStart = None
  recordRangeEnd = None

class MLoadOptions(LoadOptions):
  tableGroups = None
  importLocation = None

def cleanup():
  if Action.connection is not None:
    nprint("++++++ Closing connection", Action.quietLevel)
    Action.connection.close()

def done():
  if Action.errorCodeOverride != None:
    code = Action.errorCodeOverride
  else:
    code = Action.errorLevel
  nprint("exiting with code: " + str(code), Action.quietLevel)
  sys.exit(code)

def getFixedLengthRowValues(fieldWidths, line):
  fmtstring = ' '.join('{}{}'.format(abs(fw), 'x' if fw < 0 else 's') for fw in fieldWidths)
  fieldstruct = struct.Struct(fmtstring)
  unpack = fieldstruct.unpack_from
  parse = lambda line: tuple(s.decode() for s in unpack(line.encode()))
  #print('fmtstring: {!r}, recsize: {} chars'.format(fmtstring, fieldstruct.size))
  return parse(line)

def prepareRowValues(row, fields, params, importOptions):
  paramCount = len(params)
  paramIndex = [None] * paramCount
  for ndx in range(paramCount):
    colName = params[ndx]
    ret = indexOfField(fields, colName)
    if paramIndex[ndx] == -1:
      raise InvalidFieldException()
    else:
      paramIndex[ndx] = ret

  usedValues = []
  for i in paramIndex:
    if importOptions.forceTrim == True:
      if not row[i].strip():
        usedValues.append(getNullValue())
      else:
        usedValues.append(row[i].strip())
    else:
      if not row[i]:
        usedValues.append(getNullValue())
      else:
        usedValues.append(row[i])
  return usedValues


def indexOfField(fields, fieldName):
  ndx = 0
  for field in fields:
    if field[0] == fieldName:
      return ndx
    ndx += 1
  return -1;

def executeStmt(sql, args):

  if Action.connection is None:
    # Initialize connection params
    fprint("+++ Acquiring connection ...")
    Action.connection = getDBConnection(Action.quietLevel)
    fprint("+++ Connection retrieved")
    setAutoCommit(Action.connection)

  fprint("executeStmt sql: " + sql)
  fprint("executeStmt args: " + str(args))

  cursor = Action.connection.cursor()
  Action.lastSql = sql
  if args is None:
    cursor.execute(sql)
  else:
    cursor.execute(sql, args)
  Action.activityCount = cursor.rowcount
  if Action.quietLevel != QuietLevel.ALL and Action.quietLevel != QuietLevel.ON:
    print("executeStmt Action.activityCount " + str(Action.activityCount))

  return cursor


def fprint(text):
  nprint(text, Action.quietLevel)
  
def invokeFileConverter(args):
  fprint('>>>Running command %s: %s' % (args[0], subprocess.list2cmdline(args)))
  try:
    return subprocess.check_output(args)
  except BaseException as err:
    fprint("Failed invoking the file converter: " + str(err))

def getAcceptParams(fileName, params):
  try:
    file = open(fileName,'r')
    lines = file.readlines()
    if(len(lines) > 1):
      fprint('WARNING: multiple lines in .ACCEPT file: ' + fileName)
    file.close
  except:
    fprint('Failed loading ACCEPT file: ' + fileName)
    setErrorCode(4802)
    return
  values = []
  for line in lines:
    values += shlex.split(line)
  acceptDict = {}
  for i in range(len(params)):
    value = values[i] if i < len(values) else ""
    acceptDict[params[i]] = value
  return acceptDict

def acceptFromFile(fileName, count):
  params = [str(n) for n in range(count)]
  acceptDict = getAcceptParams(fileName, params)
  if(acceptDict is not None):
    return tuple(acceptDict.values())

import sys
import getopt
import zipfile
import gzip
import re
from io import BytesIO
from .np_action import *
from .npcommon import *
from .np_export import *

class TptVariables:
  map = {}

# Validate command-line parameters for case when TPT job contains
# anonymous step
def validateStandaloneTptParams():
  return

# Fetch a TPT variable from command line arguments
# Param: A name of TPT variable
# Return: A value that has been assigned to this variable or None
#         if value cannot be resolved
def getVar(ref):
  try:
    value = getRawVar(ref)
    if(len(value) > 2 and value.startswith("'") and value.endswith("'")):
      return value[1:-1]
  except:
    print("ERROR: An TPT variable Exception has accured")
  if(ref in TptVariables.map.keys()):
    return TptVariables.map[ref]
  else:
    return


# Fetch a TPT variable from command line arguments and convert it to integer
# Param: A name of TPT variable
# Return: A value that has been assigned to this variable or None
#         if value cannot be resolved or is a not an integer
def getIntVar(ref):
  try:
    return int(getRawVar(ref))
  except:
    return None

def executeJob(job):
  step = getStep()
  if(step is None):
      key = list(job.keys())[0]
      func = job[key]
  else:
    intStep = None
    try:
      intStep = int(step)
    except:
      print("ERROR: Cannot convert object 'step' to Integer")

    if(intStep is None):
      key = step
      func = job.get(step)
    else:
      key = list(job.keys())[intStep - 1]
      func = job[key]
    print("Jump to step: " + key)
    if(func is None) :
      print("""TPT_INFRA: TPT03625: Error: tbuild -s option argument '{}' (job step identifier)
  does not match any job step; job aborted.
TPT_INFRA: TPT02992: Error: Execution Plan generation failed.""".format(key))
      setErrorCode(3625)
      return
  func()

# Execute tpt job, staret step is configurable
# Param: job a Map of steps
def executeTpt(job):
  key = list(job.keys())[0]
  func = job[key]
  func()
  return

# Format: -u "MyTdpId = 'database1', MyUserName = 'johndoe'"
def getRawVar(ref):
  arg = getOptValue("-u")

  if(arg is not None):
    varSplit = re.split(",(?=(?:[^\']*\'[^\']*\')*[^\']*$)",arg)
    for varStr in varSplit:
      name, value = re.split("=(?=(?:[^\']*\'[^\']*\')*[^\']*$)",varStr.strip())
      if(name.strip() == ref):
        return value.strip()

  # continue looking i the file specified by -v
  arg = getOptValue("-v")
  if(arg is not None):
    file_params = {}
    file_params = {**file_params, **parse_var_file(arg)}
    value = file_params.get(ref)
    if not value:
      return None
    else:
      return value.strip()

def parse_var_file(file_input, assignment_operator = '='):

    out = {}

    with open(file_input,'r') as f:
        for line in f.readlines():
            if line.strip() == '':
                continue
            splitted = line.split(assignment_operator)
            out[splitted[0].strip()] = splitted[1].strip()

    return out    

def getTptOpts():
  #=============================================================================
  # -f Specifies the filename to be used as input.
  # -u Specifies job variable values which are to be applied.
  # -z Specifies a checkpoint interval to be used for the client side.
  # -s Specifies that job execution is to start at a specific job step.
  # -v Specifies that job attributes are to be read from an external file.
  # -l Specifies latency interval - how often to flush stale buffers.
  # -j Specifies the job to run
  #=============================================================================
  return getopt.getopt(sys.argv[1:], "f:u:z:s:v:l:j:")

def getStep():
  return getOptValue("-s")

def getJob():
  return getOptValue("-j")

def getOptValue(flag):
  opts, args = getTptOpts()

  for opt, arg in opts:

    if opt == flag:
      return arg

def executeTptExport(exportFileName, cursor):

  # Open file for export
  try:
    if Action.charSet != None:
      if(exportFileName.endswith(".zip")):
        archive = BytesIO()
        zipArchive = zipfile.ZipFile(archive, 'w')
        # Create three files on zip archive
        exportFile = zipArchive.open(exportFileName[-4], 'w') 
        #exportFile = zipfile.ZipFile(exportFileName, mode='wb', compression=zipfile.ZIP_DEFLATED)
      elif(exportFileName.endswith(".gz")):
        exportFile = gzip.open(exportFileName, 'wb')
      else:
        exportFile = open(exportFileName, "wb")
    else:
      if(exportFileName.endswith(".zip")):
        exportFile = zipfile.ZipFile(exportFileName, mode='w', compression=zipfile.ZIP_DEFLATED)
      elif(exportFileName.endswith(".gz")):
        exportFile = gzip.open(exportFileName, 'w')
      else:
        exportFile = open(exportFileName, "w+", newline="\n")
  except Exception as ex:
    setErrorCode(4802)
    return

    # Exporting data
  try:
    resultSet = cursor.fetchall()
    rsMetadata = cursor.description
    rsColCount = len(rsMetadata)
  except Exception as e:
    errorHandling(e, Action)
    # Handler has no mapping for error
    if Action.errorCode == 100:
      setErrorCode(3708)
    return

  colCount = 0
  if ExportOptions.colLimit < rsColCount:
    colCount = ExportOptions.colLimit
  else:
    colCount = rsColCount
  columnInfo = getColumnInfo(cursor, colCount)

  undefinedColumnSizeFound = False
  maxWidth = [None] * colCount

  for i in range(colCount):
    if(columnInfo[i - 1].isSizeUndefined()):
      #Undefined column size detected. Need write
      #to temp file and calculate size
      undefinedColumnSizeFound = True
      maxWidth[i - 1] = -1

  iterateOverResultSet = False
  isEmpty = True
  if undefinedColumnSizeFound:
    tempFile = open("fexp.output", "w+", newline="\n")
    writeToTempFile(resultSet, tempFile, maxWidth, columnInfo)
    for i in range(colCount):
      if columnInfo[i].isSizeUndefined():
        columnInfo[i].size = maxWidth[i]
  else:
    iterateOverResultSet = True

  lastRecordCount = 0

  if iterateOverResultSet == True:
    for rowData in resultSet:
      if isEmpty == True:
        isEmpty = False
        setColumnsInfo (columnInfo, exportFile, FormatOptions)
      writeRecord(exportFile, lastRecordCount, columnInfo, rowData, FormatOptions)
      #ATEM-741 Adding actual number of rows processed
      #recordCount = getRecordCount(columnInfo, dataProvider)
      lastRecordCount += 1
      if ExportOptions.rowLimit != None and ExportOptions.rowLimit <= lastRecordCount:
        break
    if isEmpty == True:
      fprint("(Empty Result Set)")
  else:
    fileLine = tempFile.readline()
    while fileLine:
      writeRecord(exportFile, lastRecordCount, columnsInfo, fileLine, formatOptions)
      #ATEM-741 Adding actual number of rows processed
      #recordCount = getRecordCount(columnInfo, dataProvider)
      lastRecordCount += recordCount
      if ExportOptions.rowLimit != None and ExportOptions.rowLimit <= lastRecordCount:
        break
      fileLine = tempFile.readline()
    if isEmpty == True:
      fprint("(Empty Result Set)")

  if exportFile != None:
    if(exportFileName.endswith(".zip")):
      with open(exportFileName, 'wb') as f:
        f.write(archive.getbuffer())
      archive.close()
    else:
      exportFile.close()

  return True
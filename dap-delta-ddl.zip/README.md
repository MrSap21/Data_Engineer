# Introduction 
dap-delta-ddl contains all DDL converted from the legacy on-prem Hadoop Cluster and represents the structural elements defining the Azure Databricks Delta Tables stored as a ADLS Data Lake. All code in the /scripts/ and /ddl_deploy/ directories in this repository was converted from HQL to SQL using String Object manipulation techniques in Python.

## FAQs

Q: 
__Why is there a ./scripts/ directory and seemingly matching ./ddl_deploy/ directory?__
<br>
A: 
The `./scripts/` directory contains all fully parameterized code. This is meant to enable teams to dynamically define and change structural elements of a table by using the metadata and migrations.

Q: 
__I can't find a script for a table thats in Hadoop. Do we not have all the table DDLs here? [OR] Whats with these `tbd.zip` files?__
<br>
A: 
All DDL was converted, over 20,000 tables in total; not all DDL was in scope for the migration though. If there was no domain or subdomain defined for a given table _at the time of conversion_, then there was no place to logically put the script. Thus, we placed the extras in a domain/subdomain labeled as _tbd_. There is significant volume that fell into this category, so in order to contain the runaway quantity of scripts in the repository we have zipped these up (as well as separated the ddl metadata into `./migrations/ddl_tbd.json`). If you need one of these scripts, its not an issue. Checkout the Section defining how to use the `utility/ddl_move_tbd_file.py` script which automates this chore.

<br> 

# Getting Started
Below is an introduction. Please be aware that sync tables are slightly different, so I would advise to not practice with these tables. Please see the utiliy/sync.py section below for more details.

1. You will need to activate a python environment to proceed. The version likely wont make much of a difference, but it was origionally built using 3.10. The VDI has Anaconda installed, and its recommended you use the base environment provided by that. Activate that enviornment by running this script in a bash notebook:
  ```sh
  source C:/ProgramData/Anaconda3/Scripts/activate
  ```
  In the case you are using the S-Performance VDI, you must manually create and install for your venv:
  ```sh
  python -m venv env
  source env/Scripts/activate
  pip install pandas
  ```
  If you already have created a virtual environment, then you can simply start it up using:
  ```sh
  source env/Scripts/activate
  ```

2. Checkout the development branch to obtain the latest changes and to create your feature branch off that branch:
  ```sh
  $ git checkout development
  $ git pull development
  $ git checkout -b feature-branch
  ```

3. Copy a list of files into [deploy_list.txt](./migrations/utility/assets/deploy_list.txt). This list will look like this (note: capitalization does not matter, but incorrect names do. Order does not matter either.):
  ```
  wag_gen_cooked.sca_work_order
  wag_gen_raw.sca_work_order
  wag_gen_work.sca_work_order_LL
  wag_gen_work.sca_work_order_new
  ```
   
4. Execute the application to create a new release. This release contains files for tables listed in step 3 above, and is stored in JSON [here](./migrations/releases/README.md). __Please click that link to better understand the release naming conventions used__. (More information can be found below, in the section for `utility/create_release.py`)
  ```bash
  $ cd migrations
  $ python -m utility.create_release
  $ Enter valid release \# [X.X.X]: 5.4.1 # Example release number
  ```
  
**If there are no errors, go to step 7!**

5. You may notice some "\[ERROR\]" are logged. Depending on the issue, there are 2 possible things that you need to do. 
    - If there is only an "\[ALERT\]", and says something about an 'updates.json', then you can reference below. see the section for `utility/ddl_move_tbd_file.py`.
    - If there is a "\[FATAL\]" issue, then you probably spelled a table wrong. There is a slight chance that the table you are looking for was a temp table or some table which may not be captured in the DDL. In this case, you will need to add this table's files and add a record in the metadata for the table (./migrations/ddl.json). In this case, you'll want to create another table and add a record in to ddl.json to set it up.

6. Fix the issues listed above. Then re-run the create_release.py script. This may require running the script __utility/ddl_move_tbd_file.py__, which is detailed below.

#### Running Migrations
7. These steps are detailed far greater below. To run a migration that is now defined in the ./migrations/releases/*.json file you've created, add the migration number to the correct file in the ./migrations/deploy.json file. For example, [this is the dev file](./migrations/deploy.json). You will add that in the __deploy__ section like below:
    ```json
    {
      "state": {
        "4.0.0": "2022-02-24",
        "4.1.0": "2022-02-24",
        "4.2.0": "2022-02-24"
      },
      "deploy": ["5.0.0", "5.0.1"] //could just be ["5.0.0"] if only one
    }
    ```

8. Run the migration for the environment using the below commands:
    ```bash
    cd migrations
    export ENVIRONMENT=dev
    bash migrate.sh
    cd ..
    git add .
    git commit -m '5.4.1'
    git push origin R5
    ```
9. (Optional) PR this branch to the required environment branch to trigger a deployment.

10. (Optional) For manual deployment, open databricks, and go the to correct branch. Make sure to pull the changes just pushed. Then open up the file and click _Run All_.

<br>
<br>

# Migrations
A core piece of DDL management in any applications is how we define tables across different environments. Simply put, we want the _right_ datatypes for the _right_ columns, for the _right_ table, with the _right_ partitions, pointing to the _right_ ADLS location, with the _right_ format, ,in the _right_ environment, within the _right_ workspace. Unfortunately, managing the physical structure of data can be a difficult problem at scale. There are several nuances to be aware about and a few different tools which are built to help us be flexible and agile when supporting the Data Engineering & ETL teams here at Walgreens.

The tooling within the `./migrations/` directory are built to give the maintainers a way to easily and effectively define the structural elements of a given table in a given environment. Below is a list of scripts with a short description. Each is covered in more detail below, including the steps to execute and properly use these tools.

- `migrate.sh (& migrate.py)`: The scripts to define & prepare the code to deploy. 
- `utility/create_release.py`: Creates release JSON files given a list of tables. The release JSON is how migrations are defined.
- `utility/ddl_move_tbd_file.py`: Retrieves & prepares tables not determined as staging tables or tables in scope for migration from tbd.zip file.
- `utility/move_to_staging.py`: In some cases, staging tables exist in the on-prem cooked layer. Easily moves a table (and metadata) from curated to wrangled.
- `utility/sync.py`: Automate the snowflake sync jobs. just fine the script and run this.
- `utility/table_report.py`: People want to know what scripts are deployed. This is an easy way to create release notes.

## migrate.sh
#### About
Parameterizes and moves scripts as needed & tracks what releases are in which environment. This is where the magic is, and is the primary tool to create scripts which will either be run manually, or to create files in the __/ddl_deploy/__ directory, which will be deployed to the given environment when a PR is opened to a branch. The key here is to understand the __release__ json documents which define packages of tables/objects that you want deployed as a single unit, such as a code drop.

#### Use
1. First, you need to define a migration or groups of migrations that you want to deploy. The general structure is better described [migrations/releases/](./migrations/releases/README.md). An easy way to do this is by using the `utility/create_release.py` tool.
2. Next, assure your files are set up properly to create a deployment. There are 2 different files you must be aware of. The first of which is `migrations/deploy.json`. You will use the ame file for all environments, because it is simply a file to helpus track and tell the code what to deploy, the file you will use is [migrations/deploy.json](./migrations/deploy.json). If you want more info on the release json, please refer [here](./migrations/releases/README.md). Add a release in the "deploy" list. Your file might look like this, where you will deploy releases 5.1.0, 5.2.0, 5.2.1:
    ```json
    {
      "state": {
        "4.0.0": "2022-03-11",
        "4.1.0": "2022-03-11",
        "4.2.0": "2022-03-11",
        "5.0.0": "2022-03-11",
        "5.0.1": "2022-03-11",
      },
      "deploy": ["5.1.0", "5.2.0", "5.2.1"]
    }
    ```
3. Now you will need to create an environment variable that defines which environment you want to create a deployment for. **NOTE**: This really only applies to manual deployments, in the case that you need a notebook to physically run for some reason. The primary use/purpose of this will likely fade as time goes on. The options here are: dev, uat, and prod. (as there is no generic test environment at this time)
    ```bash
    (base)
    $ export ENVIRONMENT=dev
    ```
4. Last, execute the bash script, migrations.sh. This runs the migrate.py and reads in the environment variables from the `./configs/` folder to fill in the parameterization required for each script. This migrate.py essentially reads in the upgrades/downgrades defined in the release json files listed in (2.) above, and then does a couple of things:
    1. Reads the files, replaces the parameterization with the correct items.
    2. Copies the prepared files from `./scripts/` to `./ddl_deploy/`.
    3. Creates an optional `./ddl_deploy/deploy.py` file that can be used in deployment pipelines.
    4. Creates 2 python scripts which can be manually executed in databricks (next step). Depending on the enviornment, the files are named `manual/<env>_upgrade.py` and `manual/<env>_downgrade.py`.
    ```bash
    (base)
    $ bash migrate.sh
    > ...
    ```
5. (Optional) Manual Execution... Open the repository in Azure Databricks and navigate to the correct branch & file. Open the file and click to __Run All__.
6. Verify all scripts are created as expected.

#### Example
You can prepare both DEV and UAT deployments for example:
```bash
cd migrations
export ENVIRONMENT=dev
bash migrate.sh
export ENVIRONMENT=uat
bash migrate.sh
cd ..
git add .
git commit -m '5.4.0'
git push origin r5
```

#### Related Files
There are a few folders and files you first need to be aware of prior to using this tool:
- [migrations/deploy.json](./migrations/deploy.json): Where the enironment _state_ is defined. This JSON files defines the exact releases that are deployed, and keeps track of the past deployments.
- [migrations/releases/](./migrations/releases/README.md): Where the defined _releases_ or _code drops_ are defined. Groups of files which are to be deployed as a unit.

## utility.create_release
#### About
Automates the creation of release json for us, given a list of scripts. If there are issues with the input in [deploy_list.txt](./migrations/utility/assets/deploy_list.txt), then an error is thrown and the user must fill out the appropraite fields in update.json.

#### Use
This script is best used via the command line using bash. Below are some scripts which you can use to observe the results:

1. Open `.migrations/utility/assests/deploy_list.txt` Write or Copy a list of legacy schema names for the table(s) you'd like to migrate. **NOTE:** Avoid empty lines.
2. cd into the `./migrations/` folder, and run the script 
    ```bash
    (base)
    $ cd migrations
    (base)
    $ python -m utility.create_release
    (base)
    $ Enter valid release \# [X.X.X]: 0.0.0 # Example release number
    ```
3. Open the resulting release json file to check it. Also note the output printed to the console. In the case the file is not found in ddl.json, but __is__ found in ddl_tbd.json, then it creates the update.json file for use to move the ddl from tbd to a domain & subdomain of your choosing. This is covered in `utility/ddl_move_tbd_file.py`. In the case the table is not found in ddl.json or ddl_tbd.json, it throws an error and tells you the table was not found at all. Look for [FATAL] in the output.

#### Related Files
There are a few folders and files you first need to be aware of prior to using this tool. 
- [deploy_list.txt](./migrations/utility/assests/deploy_list.txt)
- [updates.json](./migrations/utility/assests/updates.json)



## utility.ddl_move_tbd_file
#### About
When converting the files, it was impossible to know what all the staging tables were for a particular target table. Some were obvious, where the table name was the same as the "cooked" table name with a suffix such as "stg", "new", "temp", "managed", etc.. Others are not so obvious, in which case they were not able to be assigned a domain or subdomain during conversion. There were _a lot_ of these tables. So many, that it was decided to put these in a zip folder so they dont slow the repository down excessively. The challenge becomes: __How do we retrieve these files and set them up in the metadata?__. 

This application helps us to quickly extract the table's script out of the zip folder and set these scripts up in whatever domain and subdomain is needed. It also handles the creation of a record in the metadata for the new script. This is easily run following a run of create_release.py, where it gives you an error that looks something like this: "    [ALERT]: {tbl} in TBD DDL. Prepare the Script in updates.json with proper domain/subdomain and run ddl_move_tbd_file.py". This is telling you that you must use this application.

See below for steps to use it.
<br>
#### Use
This script is best used via the command line using bash. Below are some scripts which you can use to observe the results:

1. Open `./migrations/utility/assests/update.json`. The format should look like the example below. If you are using this script _after_ the create_release.py script, then the format should already be there. Optionally fill in an empty string for data_classification_level, given the table is in wrangled. Save the file.
    ```json
    [
      {
        "legacy_schema": "dae_work.cons_icp_ent_dly",
        "domain": "<domain>",
        "subdomain": "<subdomain>",
        "data_classification_level": "<data-class>"
      }
    ]
    ```
2. cd into the `./migrations/` folder, and run the script 
    ```bash
    (base)
    $ cd migrations
    (base)
    $ python -m utility.ddl_move_tbd_file
    ```
3. Check [ddl.json](./migrations/ddl.json) was updated, and check the filenames which were outputted. Observe that the conversion to the Domain/Subdomain were successful. Add this to the release by re-running the create_release.py script if desired.

#### Related Files
There are a few folders and files you first need to be aware of prior to using this tool. 
- [updates.json](./migrations/utility/assests/updates.json)
- [ddl.json](./migrations/ddl.json)
- [ddl_tbd.json](./migrations/ddl_tbd.json)
- [curated - tbd.zip](./scripts/curated/tbd.zip)
- [wrangled - tbd.zip](./scripts/wrangled/tbd.zip)


## utility.move_to_staging
#### About
Sometimes a table exists in the _cooked_ layer on-prem, but the table is actually a staging table. This means the script might have been automatically set to be a __curated__ table, but in reality all ETL/staging tables should be in __wrangled__. To automatically move this file from curated to wrangled, this is the application to do so.

#### Use
1. Grab the ID's for the srcipts in the ddl.json. Then copy/paste each on a new line in the `./migrations/utility/assets/move_to_staging.txt` file.
2. Run the application from the migrations directory:
    ```bash
    $ cd migrations
    $ python -m utility.move_to_staging
    ```
3. Verify the scripts are now altered. The script should now be in the wrangled folder and have the correct information.


#### Related Files
- [move_to_staging.txt](./migrations/utility/assets/move_to_staging.txt) - Where you place the list of table id's to change.
- [move_to_staging.py](./migrations/utility/move_to_staging.py) - the code which we execute



## utility.move_to_domain
#### About
This utility helps you move the scripts domain. By running this, it will automaticaly update the domain and subdomain in both the metadata and the parameterization. It will also move the file to the correct location.

#### Use
To run:
```bash
cd migrations
python -m utility.move_to_domain
```

You'll need to set the __assets/updates.json__ with values like below:
```json
[
  {    
      "script": "T.1920.1.crt.valeant_audit_sold_count.sql",
      "domain": "pharmacy_healthcare",
      "subdomain": "consignment"
  },
  {
      "script": "T.1921.1.crt.valeant_audit_sold_icp_count.sql",
      "domain": "pharmacy_healthcare",
      "subdomain": "consignment"
  },
  {
      "script": "T.1922.1.crt.valeant_audit_trans_count.sql",
      "domain": "pharmacy_healthcare",
      "subdomain": "consignment"
  },
  {
      "script": "T.1923.1.crt.valeant_audit_trans_icp_count.sql",
      "domain": "pharmacy_healthcare",
      "subdomain": "consignment"
  }
]
```

## utility.create_ddl
#### About
Creating new ddl is an annoying task given the metadata being the scenes, so we've built a tool to quickly generate DDL. 

This utility helps you create new ddl files which are automatically added to the metadata, as well as cerate auto-generated files which you can then fill the table logic in. This can be used to create new table versions, or to simply create a new file altogether. Once running, simply follow the directions and you will create your scripts. If at anytime you need to abort, just use `Ctrl+C`.

#### Use
To run (make sure you have the conda environment activated):
```bash
cd migrations
python -m utility.create_ddl
```

Then fill in the input as needed for a net-new table:
```
$ python -m utility.create_ddl
Add Versioned DDL for Existing Table? (Y/N): N
Object Type (Database=D, Table=T, View=V): T
Table Name: tl_prescription_data_migration
Domain: pharmacy_healthcare
Subdomain: patient_services
Zone: wrangled
{
    ...
}
Confirm above record is correct? (Y/N): y
writing at path:  ../scripts/wrangled/pharmacy_healthcare/patient_services/T.19913.1.wrg.tl_prescription_data_migration.sql
Are you sure you want to overwrite the Metadata DDL? (Y/N): Y
```

Or, optionally fill in info for a new versioned script for a table:
```
$ python -m utility.create_ddl
Add Versioned DDL for Existing Table? (Y/N): y
Table ID: T.1877.1
{
    ...
}
Confirm above record is correct? (Y/N): y
writing at path:  ../scripts/curated/pharmacy_healthcare/patient_services/T.1877.2.crt.tl_prescription.sql
Are you sure you want to overwrite the Metadata DDL? (Y/N): y
```


# Syncing DDL with Snowflake DDL
#### About
There are cases we need to _sync_ the table structure with the structure found in Snowflake. For these tables, we need to find the file in the dap-snowflake repository and place that in the json: `./sync/sync.json`. If it is a new table altogether, then it will go in the **new** list in the json, else it will go in the **toSync** list, which must be in format: "snowflake_file_name": "dap-delta-ddl file name". This will then overwrite the table columns in the delta table to reflect that of the snowflake table. Following this the user can automatically convert the script needed for the sync table by executing a single script.

The code works to automatically check the dap-snowflake repository out, find the files you've list, and then either updates the file that was present or creates a new files altogether and adds the metadata to `migrations/ddl.json`.

#### Use
For directions how to use this tool, go to the [sync folder](./sync/README.md)

#### Related Files
- [sync.json](./sync/sync.json) - where the files to sync, and the historical sync's are kept
- [sync.py](./sync/sync.py) - the code or python logic
- [sync.sh](./sync/sync.py) - the code or clone/repo logic











# Build and Test
To build, simply PR the feature branch back onto the development branch. Then create a tag for deloyment as such:

- dev: ddl-deploy-dev-yyyymmdd.01 (using development branch)
- test: ddl-deploy-test-yyyymmdd.01
- sit: ddl-deploy-sit-yyyymmdd.01 (using sit branch)
- uat: ddl-deploy-uat-yyyymmdd.01 (using development branch)
- prod: ddl-deploy-prod-yyyymmdd.01 (using master branch)



## Structure
```dap-delta-ddl
├───env_configs
├───convert
│   ├───convert
│   ├───hive_ddl
│   └───reference
├───migrations
│   ├───archived_releases
│   ├───deploy
│   ├───releases
│   ├───state
│   └───utility
│       ├───assets
│       └───helpers
├───ddl_deploy
│   ├───curated
│   │   └───domain
│   │       └───subdomain
│   │           └───downgrade
│   └───wrangled
│       └───domain
│           └───subdomain
│               └───downgrade
├───scripts
│   ├───curated
│   │   └───domain
│   │       └───subdomain
│   │           └───downgrade
│   └───wrangled
│       └───domain
│           └───subdomain
│               └───downgrade
├───scripts
│   ├───sync.json
│   ├───sync.sh
│   └───sync.py
└───README.md
```

# Code Conversion
The code in the repository was converted via the conversion scripts in the `./convert/` directory. Here you will notice a few folders:
- __/convert/__: the core logic for converting the hive ddl found in `./convert/hive_ddl/`. Python scripts which read the ddl in as String objects to manipulate the code in order to alter the syntax and collect information for the ddl.json metadata.
- __/hive_ddl/__: ddl collected from the production Hadoop cluster and stored as txt files by database. Obtained by recursively running SHOW CREATE TABLE $table_name;
- __/reference/__: contains the reference material used in the conversion logic. Namely, contains the table inventory used to determine the domain / subdomain information while creating the scripts and corresponding metadata.
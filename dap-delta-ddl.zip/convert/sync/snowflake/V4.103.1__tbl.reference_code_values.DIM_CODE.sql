CREATE TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_reference_code_values }}.DIM_CODE
(
      src_cd_val VARCHAR(20)  COLLATE 'en-ci'  NOT NULL,
      src_sys_cd VARCHAR(10)  COLLATE 'en-ci'  NOT NULL,
      tgt_tbl_name VARCHAR(30)  COLLATE 'en-ci'  NOT NULL,
      tgt_col_name VARCHAR(30)  COLLATE 'en-ci'  NOT NULL,
      edw_rec_begin_dt DATE   NOT NULL comment  'record begin date{"FORMAT":"YYYY-MM-DD" }',
      edw_rec_end_dt DATE   NOT NULL comment  'record end date{"FORMAT":"YYYY-MM-DD" }',
      src_cd_catg VARCHAR(30)  COLLATE 'en-ci' ,
      src_cd_catg_desc VARCHAR(60)  COLLATE 'en-ci' ,
      src_cd_val_short_desc VARCHAR(50)  COLLATE 'en-ci' ,
      src_cd_val_long_desc VARCHAR(500)  COLLATE 'en-ci' ,
      std_cd_val VARCHAR(20)  COLLATE 'en-ci' ,
      std_cd_val_short_desc VARCHAR(50)  COLLATE 'en-ci' ,
      std_cd_val_long_desc VARCHAR(500)  COLLATE 'en-ci' ,
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch id'
);
CREATE TABLE IF NOT EXISTS  {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_patient }}.patient_health_condition_type
---prdedwdb.patient_health_condition_type 
     (
      hlth_cond_cd VARCHAR(8)  COLLATE 'en-ci'  NOT NULL,
      hlth_cond_grp VARCHAR(8)  COLLATE 'en-ci' ,
      hlth_cond_desc VARCHAR(25)  COLLATE 'en-ci' ,
      src_eff_dt DATE  NOT NULL comment '{"FORMAT":"yyyy-mm-dd" }',
      src_eff_tm TIME(0) NOT NULL,
      src_end_dt DATE  comment '{"FORMAT":"yyyy-mm-dd"}',
      src_end_tm TIME(0),
      edw_batch_id DECIMAL(18,0),
      history_seq_nbr SMALLINT,
      history_seq_cd CHAR(1)  COLLATE 'en-ci' 
     );
CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_patient }}.patient_merge
--prdedwdb.patient_merge 
     (
      merged_fm_pat_id DECIMAL(13,0) NOT NULL,
      pat_id DECIMAL(13,0) NOT NULL,
      src_create_dttm TIMESTAMP(0),
      src_create_user_id DECIMAL(9,0),
      pat_merge_stat_ind VARCHAR(2)  COLLATE 'en-ci' ,
      src_eff_dt DATE  NOT NULL comment '{"FORMAT":"yyyy-mm-dd" }',
      src_eff_tm TIME(0) NOT NULL,
      src_end_dt DATE  comment '{"FORMAT":"yyyy-mm-dd"}',
      src_end_tm TIME(0),
      history_seq_nbr SMALLINT,
      history_seq_cd CHAR(1)  COLLATE 'en-ci' ,
      edw_batch_id DECIMAL(18,0)
      );
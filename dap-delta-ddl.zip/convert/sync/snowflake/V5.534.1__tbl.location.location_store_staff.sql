CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.location_store_staff
---PRDIDLDB.location_store_staff 
     (
      loc_store_staff_chng_sk BIGINT  NOT NULL comment  'location store staff change sk',
      loc_store_sk BIGINT  NOT NULL comment  'location store sk',
      store_nbr INTEGER  NOT NULL comment  'store number',
      staff_type_cd VARCHAR(15)  COLLATE 'en-ci'   NOT NULL comment  'staff type code',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"yyyy-mm-dd" }',
      first_name VARCHAR(25)  COLLATE 'en-ci'  comment 'first name',
      middle_initial CHAR(1)  COLLATE 'en-ci'  comment  'middle initial'   ,
      last_name VARCHAR(25)  COLLATE 'en-ci'  comment 'last name',
      staff_title CHAR(3)  COLLATE 'en-ci'  comment  'staff title'   ,
      src_update_user_id VARCHAR(32)  COLLATE 'en-ci'  comment 'source update user identifier',
      district_nbr INTEGER   comment  'district number' ,
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"yyyy-mm-dd" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
      );
CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.location_store_relocation
--prdedwdb.location_store_relocation 
(
      relocate_fm_str_nbr INTEGER NOT NULL,
      relocate_to_str_nbr INTEGER,
      relocate_prcs_ind CHAR(1)  COLLATE 'en-ci' ,
      edw_batch_id DECIMAL(18,0)
      
);
ALTER TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.location_store_relocation
add unique ( relocate_fm_str_nbr );
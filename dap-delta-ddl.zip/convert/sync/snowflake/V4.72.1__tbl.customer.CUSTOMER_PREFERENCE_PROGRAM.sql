CREATE TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_customer }}.CUSTOMER_PREFERENCE_PROGRAM
(
      cust_pref_prog_chng_sk BIGINT  NOT NULL comment  'customer preference program change surrogate key',
      cust_pref_prog_group_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'customer preference program group code',
      cust_pref_prog_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'customer preference program code',
      cust_pref_prog_group_sk BIGINT  NOT NULL comment  'customer preference program group surrogate key',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'source system code',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date''{"FORMAT":"YYYY/MM/DD" }',
      cust_pref_prog_id DECIMAL(19,0)  NOT NULL comment  'customer preference program identifier',
      cust_pref_prog_name VARCHAR(30)  COLLATE 'en-ci'  comment 'customer preference program name',
      cust_pref_prog_desc VARCHAR(255)  COLLATE 'en-ci'  comment 'customer preference program description',
      cust_pref_prog_start_dt DATE  comment  'customer preference program start date{"FORMAT":"YYYY-MM-DD" }',
      cust_pref_prog_end_dt DATE  comment  'customer preference program end date{"FORMAT":"YYYY-MM-DD" }',
      cust_pref_prog_enrl_start_dt DATE  comment  'customer preference program enrollment start date{"FORMAT":"YYYY-MM-DD" }',
      cust_pref_prog_enrl_end_dt DATE  comment  'customer preference program enrollment end date{"FORMAT":"YYYY-MM-DD" }',
      cust_pref_prog_type_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'customer preference program type code',
      cust_pref_prog_stat_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'customer preference program status code',
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date''{"FORMAT":"YYYY-MM-DD" }',
      edw_create_dttm TIMESTAMP(0)   NOT NULL comment  'edw create datetime''{"FORMAT":"YYYY/MM/DD" }',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update dttm',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
) COMMENT = '{"multiset": true}' ;
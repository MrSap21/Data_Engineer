CREATE TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_customer }}.CUSTOMER_CONTACT_CHANNEL
(
      cust_cntc_chnnl_chng_sk BIGINT  NOT NULL comment  'customer contact channel change sk',
      cust_sk BIGINT  NOT NULL comment  'customer sk',
      cntc_chnnl_type_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'contact channel type code' ,
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date''{"FORMAT":"YYYY-MM-DD" }' ,
      cust_src_id VARCHAR(80)  COLLATE 'en-ci'   NOT NULL comment  'customer source identifier',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'source system code',
      composite_type_cd CHAR(2)  COLLATE 'en-ci'   NOT NULL comment  'composite type code' ,
      msg_type_cd CHAR(1)  COLLATE 'en-ci'   NOT NULL comment  'message type code' ,
      cntc_priority_type_cd VARCHAR(20)  COLLATE 'en-ci'  comment  'contact priority type code'  ,
      comm_cd VARCHAR(20)  COLLATE 'en-ci'  comment  'communication code'  ,
      comm_val VARCHAR(100)  COLLATE 'en-ci'  comment  'communication value'  ,
      txt_msg_cd VARCHAR(20)  COLLATE 'en-ci'  comment  'text messaging code'  ,
      comm_cntc_tm_cd VARCHAR(20)  COLLATE 'en-ci'  comment  'communication contact time code'  ,
      edw_rec_end_dt DATE  comment  'edw record end date{"FORMAT":"YYYY-MM-DD" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
) COMMENT = '{"multiset": true}' ;
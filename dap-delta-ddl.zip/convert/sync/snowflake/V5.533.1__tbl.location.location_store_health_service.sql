CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.location_store_health_service
--PRDIDLDB.location_store_health_service 
     (
      loc_store_hlth_service_chng_sk BIGINT  NOT NULL comment  'location store health service change sk',
      loc_store_sk BIGINT  NOT NULL comment  'location store sk',
      store_nbr INTEGER  NOT NULL comment  'store number',
      service_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'service code',
      service_type VARCHAR(30)  COLLATE 'en-ci'   NOT NULL comment  'service type',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"yyyy-mm-dd" }',
      service_stat CHAR(1)  COLLATE 'en-ci'  comment  'service status'   ,
      src_create_user_id VARCHAR(32)  COLLATE 'en-ci'  comment 'source create user identifier',
      src_update_user_id VARCHAR(32)  COLLATE 'en-ci'  comment 'source update user identifier',
      src_create_dttm TIMESTAMP(0)   comment  'source create datetime' ,
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"yyyy-mm-dd" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
      );
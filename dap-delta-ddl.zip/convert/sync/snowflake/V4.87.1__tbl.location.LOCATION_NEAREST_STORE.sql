CREATE TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.LOCATION_NEAREST_STORE
(
      loc_nearest_store_chng_sk BIGINT  NOT NULL comment  'location nearest store change sk',
      loc_store_sk BIGINT  NOT NULL comment  'location store sk',
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"YY/MM/DD" }',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"YY/MM/DD" }',
      store_nbr INTEGER  NOT NULL comment  'store number',
      nearest_store_nbr INTEGER comment 'nearest store number',
      distance DECIMAL(6,2) comment 'distance',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
);
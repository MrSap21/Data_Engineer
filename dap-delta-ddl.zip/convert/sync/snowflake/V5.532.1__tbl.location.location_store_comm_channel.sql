CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.location_store_comm_channel
---PRDIDLDB.location_store_comm_channel 
     (
      loc_store_comm_channel_chng_sk BIGINT  NOT NULL comment  'location store communication channel change sk',
      loc_store_sk BIGINT  NOT NULL comment  'location store sk',
      store_nbr INTEGER  NOT NULL comment  'store number',
      channel_type_cd CHAR(8)  COLLATE 'en-ci'   NOT NULL comment  'channel type code',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"yyyy-mm-dd" }',
      comm_channel_val VARCHAR(100)  COLLATE 'en-ci'  comment 'communication channel value',
      comm_channel_val_stat VARCHAR(15)  COLLATE 'en-ci'  comment 'communication channel value status',
      src_update_user_id VARCHAR(32)  COLLATE 'en-ci'  comment 'source update user identifier',
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"yyyy-mm-dd" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
      );
CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.dim_location_store_xref
--PRDIDLDB.DIM_LOCATION_STORE_XREF 
     (
      dim_loc_store_sk BIGINT  NOT NULL comment  'dim location store sk',
      loc_store_chng_sk BIGINT  NOT NULL comment  'location store change sk',
      loc_store_sk BIGINT  NOT NULL comment  'location store sk',
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"YY/MM/DD" }',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"YY/MM/DD" }',
      loc_district_chng_sk BIGINT  NOT NULL comment  'location district change sk',
      loc_operation_chng_sk BIGINT  NOT NULL comment  'location operation change sk',
      loc_region_chng_sk BIGINT  NOT NULL comment  'location region change sk',
      loc_area_chng_sk BIGINT  NOT NULL comment  'location area change sk',
      take_care_hlth_svc_chng_sk BIGINT  NOT NULL comment  'take care health services change sk',
      immunize_hlth_svc_chng_sk BIGINT  NOT NULL comment  'immunizations health services change sk',
      store_str_addr_chng_sk BIGINT  NOT NULL comment  'store street address change sk',
      mss_store_info_chng_sk BIGINT  NOT NULL comment  'mss store info change sk',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
      ) COMMENT = '{"multiset": true}' ;
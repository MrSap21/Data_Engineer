CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_drug }}.drug_therapeutic_class
--PRDIDLDB.drug_therapeutic_class 
     (
      therapeutic_class_cd VARCHAR(10)  COLLATE 'en-ci'   NOT NULL comment  'therapeutic class code',
      therapeutic_class_form CHAR(1)  COLLATE 'en-ci'   NOT NULL comment  'therapeutic class form',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'source system code',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date''{"FORMAT":"yyyy-mm-dd" }',
      therapeutic_class_name VARCHAR(60)  COLLATE 'en-ci'  comment 'therapeutic class name',
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date''{"FORMAT":"yyyy-mm-dd" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
     );
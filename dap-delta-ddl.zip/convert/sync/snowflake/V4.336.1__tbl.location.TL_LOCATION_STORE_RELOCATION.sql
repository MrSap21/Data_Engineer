CREATE TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.TL_LOCATION_STORE_RELOCATION
--.prdedwdb.TL_location_store_relocation 
(
      relocate_fm_str_nbr INTEGER NOT NULL,
      relocate_to_str_nbr INTEGER,
      relocate_prcs_ind CHAR(1)  COLLATE 'en-ci' ,
      edw_batch_id DECIMAL(18,0)
);

alter table {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.TL_LOCATION_STORE_RELOCATION
add unique ( relocate_fm_str_nbr );
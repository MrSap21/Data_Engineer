CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_drug }}.medispan_product_price
--PRDIDLDB.MEDISPAN_PRODUCT_PRICE 
     (
      medispan_price_chng_sk BIGINT  NOT NULL comment  'medispan price change sk',
      ndc_nbr VARCHAR(11)  COLLATE 'en-ci'   NOT NULL comment  'ndc number',
      ndc_form_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'ndc form code',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'source system code',
      price_type_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'price type code',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date',
      price_eff_dt DATE  comment  'price effective date',
      price_type_desc VARCHAR(40)  COLLATE 'en-ci'  comment 'price type description',
      prod_price_amt DECIMAL(13,5) comment 'product price amount',
      awp_ind CHAR(1)  COLLATE 'en-ci'  comment  'awp indicator'   ,
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime'
      ) COMMENT = '{"multiset": true}' ;
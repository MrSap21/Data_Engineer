CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_patient_services }}.prescription_sdl_reject
--prdedwdb.prescription_sdl_reject 
     (
      rx_nbr INTEGER NOT NULL,
      str_nbr INTEGER NOT NULL,
      rx_create_dt DATE  NOT NULL comment '{"FORMAT":"yyyy-mm-dd" }',
      rx_fill_nbr INTEGER NOT NULL,
      rx_partial_fill_nbr INTEGER NOT NULL,
      fill_enter_dt DATE  NOT NULL comment '{"FORMAT":"yyyy-mm-dd" }',
      fill_enter_tm TIME(0) NOT NULL,
      sdl_msg_id CHAR(6)  COLLATE 'en-ci'  NOT NULL,
      reject_nbr BYTEINT NOT NULL,
      fill_sold_dt DATE  comment '{"FORMAT":"yyyy-mm-dd"}',
      dl_reject_cd CHAR(3)  COLLATE 'en-ci' ,
      dl_reject_reason VARCHAR(100)  COLLATE 'en-ci' ,
      edw_batch_id DECIMAL(18,0),
      relocate_fm_str_nbr INTEGER  ,
      src_partition_nbr BYTEINT 
      );
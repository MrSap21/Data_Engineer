CREATE TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_customer }}.LINK_TO_CUSTOMER
(
      link_to_cust_chng_sk BIGINT  NOT NULL comment  'link to customer change sk',
      cust_src_id VARCHAR(80)  COLLATE 'en-ci'   NOT NULL comment  'customer source identifier',
      cust_src_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'customer source code',
      composite_type_cd CHAR(2)  COLLATE 'en-ci'   NOT NULL comment  'composite type code',
      msg_type_cd CHAR(1)  COLLATE 'en-ci'   NOT NULL comment  'message type code',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date''{"FORMAT":"YYYY-MM-DD" }',
      cust_src_sk BIGINT  NOT NULL comment  'customer source sk',
      cdi_cust_sk BIGINT  NOT NULL comment  'cdi customer sk',
      cdi_cust_src_id VARCHAR(80)  COLLATE 'en-ci'   NOT NULL comment  'cdi customer source identifier',
      cdi_composite_type_cd CHAR(2)  COLLATE 'en-ci'   NOT NULL comment  'cdi composite type code',
      cdi_msg_type_cd CHAR(1)  COLLATE 'en-ci'   NOT NULL comment  'cdi message type code',
      mbr_stat_cd CHAR(1)  COLLATE 'en-ci'   NOT NULL comment  'member status code',
      edw_rec_end_dt DATE  comment  'edw record end date{"FORMAT":"YYYY-MM-DD" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
) COMMENT = '{"multiset": true}';

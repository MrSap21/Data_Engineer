CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_prescriber }}.hc_provider_link
--PRDIDLDB.hc_provider_link 
     (
      provider_link_chng_sk BIGINT  NOT NULL comment  'Provider Link Change Sk',
      hc_provider_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'HealthCare Provider Source Identifier',
      hc_provider_addr_src_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'HealthCare Provider Address Source Identifier',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'Source System Code',
      hc_provider_eid VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'HealthCare Provider Eid',
      hc_provider_addr_eid VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'HealthCare Provider Address EID',
      hc_provider_sk BIGINT  NOT NULL comment  'HealthCare Provider Surrogate Key',
      hc_provider_addr_sk BIGINT  NOT NULL comment  'HealthCare Provider Address Surrogate Key',
      hc_provider_eid_sk BIGINT  NOT NULL comment  'HealthCare Provider EID Surrogate Key',
      hc_provider_addr_eid_sk BIGINT  NOT NULL comment  'HealthCare Provider Address EID Surrogate Key',
      edw_rec_begin_dt DATE   NOT NULL comment  'Edw Record Begin Date''{"FORMAT":"YYYY/MM/DD" }',
      edw_rec_end_dt DATE   NOT NULL comment  'Edw Record End Date''{"FORMAT":"YYYY/MM/DD" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'EDW Create DateTime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'EDW Update DateTime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'EDW Batch Identifier'
      );
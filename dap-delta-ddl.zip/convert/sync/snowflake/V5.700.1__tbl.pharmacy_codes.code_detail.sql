CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_pharmacy_codes }}.code_detail
--prdedwdb.code_detail 
     (
      catg_cd INTEGER NOT NULL,
      decode_cd VARCHAR(8)  COLLATE 'en-ci'  NOT NULL,
      primary_decode VARCHAR(80)  COLLATE 'en-ci' ,
      secondary_decode VARCHAR(80)  COLLATE 'en-ci' ,
      src_eff_dt DATE  NOT NULL comment '{"FORMAT":"yyyy-mm-dd" }',
      src_eff_tm TIME(0) NOT NULL,
      src_create_user_id DECIMAL(9,0),
      src_create_dttm TIMESTAMP(0),
      src_update_user_id DECIMAL(9,0),
      src_end_dt DATE  comment '{"FORMAT":"yyyy-mm-dd"}',
      src_end_tm TIME(0),
      history_seq_nbr SMALLINT  ,
      history_seq_cd CHAR(1)  COLLATE 'en-ci'   ,
      edw_batch_id DECIMAL(18,0)
      );
CREATE TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.location_region	
--PRDIDLDB.location_region 
     (
      loc_region_chng_sk BIGINT  NOT NULL comment  'location region change sk',
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"YY/MM/DD" }',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"YY/MM/DD" }',
      region_nbr INTEGER  NOT NULL comment  'region number',
      region_name VARCHAR(30)  COLLATE 'en-ci'  comment 'Region Name',
      region_type CHAR(1)  COLLATE 'en-ci'  comment 'region type',
      operation_nbr INTEGER comment 'operation number',
      src_create_user_id VARCHAR(30)  COLLATE 'en-ci'  comment 'source create user identifier',
      src_update_user_id VARCHAR(30)  COLLATE 'en-ci'  comment 'source update user identifier',
      src_create_dttm TIMESTAMP(0) comment 'source create datetime',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
      );

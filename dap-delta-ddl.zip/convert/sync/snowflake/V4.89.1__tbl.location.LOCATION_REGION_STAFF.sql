CREATE TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.LOCATION_REGION_STAFF
(
      loc_region_staff_chng_sk BIGINT  NOT NULL comment  'location region staff change sk',
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"YY/MM/DD" }',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"YY/MM/DD" }',
      staff_type_cd VARCHAR(15)  COLLATE 'en-ci'   NOT NULL comment  'staff type code',
      staff_title CHAR(3)  COLLATE 'en-ci'  comment 'staff title',
      first_name VARCHAR(25)  COLLATE 'en-ci'  comment 'first name',
      middle_initial CHAR(1)  COLLATE 'en-ci'  comment 'middle initial',
      last_name VARCHAR(25)  COLLATE 'en-ci'  comment 'last name',
      region_nbr INTEGER comment 'region number',
      src_update_user_id VARCHAR(30)  COLLATE 'en-ci'  comment 'source update user identifier',
      operation_nbr INTEGER comment 'operation number',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create DATETIME',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
);
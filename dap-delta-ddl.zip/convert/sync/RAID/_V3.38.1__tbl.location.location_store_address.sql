CREATE TABLE {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.location_store_address
(
	dna_eff_dttm DATETIME(0) NOT NULL,
	dna_end_dttm DATETIME(0) NOT NULL,
	dna_stat_cd char(1) NOT NULL,
	dna_create_dttm DATETIME(0) NOT NULL,
	dna_update_dttm DATETIME(0) NOT NULL,
	dna_batch_id decimal(18, 0) NOT NULL,
	store_nbr int NOT NULL,
	addr_type_cd char(3) NULL,
	addr_line_1 varchar(60) NULL,
	addr_line_2 varchar(60) NULL,
	city varchar(30) NULL,
	state_cd char(2) NULL,
	cntry varchar(30) NULL,
	zip_cd_4 char(4) NULL,
	zip_cd_5 char(5) NULL,
	county varchar(30) NULL,
	src_update_user_id varchar(30) NULL
);
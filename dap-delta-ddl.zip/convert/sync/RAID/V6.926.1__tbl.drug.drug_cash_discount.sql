CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_drug }}.drug_cash_discount
--PRDIDLDB.drug_cash_discount 
     (
      drug_cash_discnt_chng_sk BIGINT  NOT NULL comment  'drug cash discount change sk',
      drug_sk BIGINT  NOT NULL comment  'drug sk',
      drug_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'drug identifier',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'source system code',
      discnt_priority_seq_nbr SMALLINT  NOT NULL comment  'discount priority sequence number',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"yyyy-mm-dd" }',
      cash_discnt_prch_qty DECIMAL(10,3)   comment  'cash discount purchase quantity' ,
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"yyyy-mm-dd" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
     );
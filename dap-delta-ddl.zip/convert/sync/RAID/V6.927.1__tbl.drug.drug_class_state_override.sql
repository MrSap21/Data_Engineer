CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_drug }}.drug_class_state_override
--PRDIDLDB.drug_class_state_override 
     (
      drug_override_chng_sk BIGINT  NOT NULL comment  'drug override change sk',
      drug_sk BIGINT  NOT NULL comment  'drug sk',
      drug_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'drug identifier',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'source system code',
      state_cd CHAR(2)  COLLATE 'en-ci'   NOT NULL comment  'state code',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"yyyy-mm-dd" }',
      src_eff_dt DATE   NOT NULL comment  'source effective date{"FORMAT":"yyyy-mm-dd" }',
      dea_class_cd CHAR(2)  COLLATE 'en-ci'  comment  'dea class code'   ,
      rx_otc_cd CHAR(1)  COLLATE 'en-ci'  comment  'rx otc code'   ,
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"yyyy-mm-dd" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
     );
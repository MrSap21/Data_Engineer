CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_pharmacy_healthcare }}.{{ subdomain_drug }}.drug_indicator
--PRDIDLDB.DRUG_INDICATOR 
     (
      drug_ind_chng_sk BIGINT  NOT NULL comment  'drug indicator change sk',
      drug_id VARCHAR(32)  COLLATE 'en-ci'   NOT NULL comment  'drug identifier',
      src_sys_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'source system code',
      ind_type_cd VARCHAR(20)  COLLATE 'en-ci'   NOT NULL comment  'indicator type code',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"YYYY-MM-DD" }',
      ind_val VARCHAR(20)  COLLATE 'en-ci'  comment 'indicator value',
      manual_maint_cd VARCHAR(20)  COLLATE 'en-ci'  comment 'manual maintenance code',
      src_create_user_id VARCHAR(30)  COLLATE 'en-ci'  comment 'source create user id',
      src_create_dttm TIMESTAMP(0) comment 'source create datetime',
      src_update_user_id VARCHAR(30)  COLLATE 'en-ci'  comment 'source update user id',
      src_update_dttm TIMESTAMP(0) comment 'source update datetime',
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"YYYY-MM-DD" }',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
     ) COMMENT = '{"multiset": true}' ;
CREATE TABLE IF NOT EXISTS {{ env }}_{{ domain_master_data }}.{{ subdomain_location }}.location_store_address
--PRDIDLDB.location_store_address 
     (
      loc_store_addr_chng_sk BIGINT  NOT NULL comment  'location store address change sk',
      loc_store_sk BIGINT  NOT NULL comment  'location store sk',
      edw_rec_end_dt DATE   NOT NULL comment  'edw record end date{"FORMAT":"YY/MM/DD" }',
      edw_rec_begin_dt DATE   NOT NULL comment  'edw record begin date{"FORMAT":"YY/MM/DD" }',
      store_nbr INTEGER  NOT NULL comment  'Store Number',
      addr_type_cd CHAR(3)  COLLATE 'en-ci'   NOT NULL comment  'address type code',
      addr_line_1 VARCHAR(60)  COLLATE 'en-ci'  comment 'address line 1',
      addr_line_2 VARCHAR(60)  COLLATE 'en-ci'  comment 'address line 2',
      city VARCHAR(30)  COLLATE 'en-ci'  comment 'city',
      state_cd CHAR(2)  COLLATE 'en-ci'  comment 'state code',
      cntry VARCHAR(30)  COLLATE 'en-ci'  comment 'country',
      zip_cd_5 CHAR(5)  COLLATE 'en-ci'  comment 'zip code 5',
      zip_cd_4 CHAR(4)  COLLATE 'en-ci'  comment 'zip code 4',
      county VARCHAR(30)  COLLATE 'en-ci'  comment 'county',
      src_update_user_id VARCHAR(30)  COLLATE 'en-ci'  comment 'source update user identifier',
      edw_create_dttm TIMESTAMP(0)  NOT NULL comment  'edw create datetime',
      edw_update_dttm TIMESTAMP(0)  NOT NULL comment  'edw update datetime',
      edw_batch_id DECIMAL(18,0)  NOT NULL comment  'edw batch identifier'
      );
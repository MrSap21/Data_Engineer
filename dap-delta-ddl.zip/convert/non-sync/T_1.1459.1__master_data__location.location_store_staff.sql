-- Databricks notebook source
CREATE TABLE IF NOT EXISTS ${DOMAIN_master_data}__${SUBDOMAIN_location}.location_store_staff(
  str_nbr INT, 
  staff_type_cd STRING, 
  first_name STRING, 
  middle_initial STRING, 
  last_name STRING, 
  staff_title STRING, 
  src_end_dt STRING, 
  src_end_tm STRING, 
  edw_batch_id DECIMAL(18,0), 
  src_eff_dt STRING, 
  src_eff_tm STRING, 
  src_update_user_id STRING)
USING ${TABLE_STORAGE_TYPE}
LOCATION
   ${TABLE_LOCATION}



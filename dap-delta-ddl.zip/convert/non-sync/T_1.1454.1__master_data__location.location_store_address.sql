-- Databricks notebook source
CREATE TABLE IF NOT EXISTS ${DOMAIN_master_data}__${SUBDOMAIN_location}.location_store_address(
  loc_store_addr_chng_sk BIGINT, 
  loc_store_sk BIGINT, 
  edw_rec_end_dt STRING, -- now dna_
  edw_rec_begin_dt STRING, 
  store_nbr INT, 
  addr_type_cd STRING, 
  addr_line_1 STRING, 
  addr_line_2 STRING, 
  city STRING, 
  state_cd STRING, 
  cntry STRING, 
  zip_cd_5 STRING, 
  zip_cd_4 STRING, 
  county STRING, 
  src_update_user_id STRING, 
  edw_create_dttm STRING, 
  edw_update_dttm STRING, 
  edw_batch_id DECIMAL(18,0))
USING ${TABLE_STORAGE_TYPE}
LOCATION
   ${TABLE_LOCATION}



-- Databricks notebook source
  CREATE TABLE IF NOT EXISTS dae_code_raw_ingestion.acap_campaign_resp_file_raw(           
   file_id STRING,                                                                           
   vendor_id STRING,                                                                         
   file_received_dttm STRING,                                                                
   response_file_name STRING,                                                                
   create_dttm STRING,                                                                       
   update_dttm STRING,                                                                       
   tracking_id STRING,                                                                       
   file_arrival_date STRING)
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
PARTITIONED BY (                                                                             
   partition_column STRING)
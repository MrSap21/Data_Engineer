-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.rx_sms_refill_info_insert_records(
  mongo_id STRING, 
  transaction_id STRING, 
  record_id STRING, 
  pat_id STRING, 
  phone_number STRING, 
  store_ph_no STRING, 
  create_dttm STRING, 
  update_dttm STRING, 
  first_name STRING, 
  last_name STRING, 
  dob_verified STRING, 
  acap_created_dttm TIMESTAMP)
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
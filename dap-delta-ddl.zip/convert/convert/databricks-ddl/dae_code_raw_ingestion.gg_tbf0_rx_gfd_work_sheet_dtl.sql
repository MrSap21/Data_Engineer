-- Databricks notebook source
CREATE TABLE IF NOT EXISTS dae_code_raw_ingestion.gg_tbf0_rx_gfd_work_sheet_dtl(                            
   cdc_txn_commit_dttm STRING COMMENT 'FROM deserializer',                                     
   cdc_txn_commit_dttm_after STRING COMMENT 'FROM deserializer',                               
   cdc_seq_nbr STRING COMMENT 'FROM deserializer',                                             
   cdc_seq_nbr_after STRING COMMENT 'FROM deserializer',                                       
   cdc_rba_nbr STRING COMMENT 'FROM deserializer',                                             
   cdc_rba_nbr_after STRING COMMENT 'FROM deserializer',                                       
   cdc_operation_type_cd STRING COMMENT 'FROM deserializer',                                   
   cdc_operation_type_cd_after STRING COMMENT 'FROM deserializer',                             
   cdc_before_after_cd STRING COMMENT 'FROM deserializer',                                     
   cdc_before_after_cd_after STRING COMMENT 'FROM deserializer',                               
   cdc_txn_position_cd STRING COMMENT 'FROM deserializer',                                     
   cdc_txn_position_cd_after STRING COMMENT 'FROM deserializer',                               
   edw_batch_id STRING COMMENT 'FROM deserializer',                                            
   edw_batch_id_after STRING COMMENT 'FROM deserializer',                                      
   work_list_nbr STRING COMMENT 'FROM deserializer',                                           
   work_list_nbr_after STRING COMMENT 'FROM deserializer',                                     
   pat_id STRING COMMENT 'FROM deserializer',                                                  
   pat_id_after STRING COMMENT 'FROM deserializer',                                            
   rx_gfd_list_nbr STRING COMMENT 'FROM deserializer',                                         
   rx_gfd_list_nbr_after STRING COMMENT 'FROM deserializer',                                   
   rx_gfd_cd STRING COMMENT 'FROM deserializer',                                               
   rx_gfd_cd_after STRING COMMENT 'FROM deserializer',                                         
   rx_gfd_comments STRING COMMENT 'FROM deserializer',                                         
   rx_gfd_comments_after STRING COMMENT 'FROM deserializer',                                   
   src_create_user_id STRING COMMENT 'FROM deserializer',                                      
   src_create_user_id_after STRING COMMENT 'FROM deserializer',                                
   src_create_dttm STRING COMMENT 'FROM deserializer',                                         
   src_create_dttm_after STRING COMMENT 'FROM deserializer',                                   
   src_update_user_id STRING COMMENT 'FROM deserializer',                                      
   src_update_user_id_after STRING COMMENT 'FROM deserializer',                                
   src_update_dttm STRING COMMENT 'FROM deserializer',                                         
   src_update_dttm_after STRING COMMENT 'FROM deserializer',                                   
   tracking_id STRING COMMENT 'FROM deserializer')
PARTITIONED BY (                                                                               
   partition_column STRING)
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
  CREATE TABLE IF NOT EXISTS dae_code_raw_ingestion.acap_campaign_resp_cust_raw(            
   response_id STRING,                                                                       
   address_1 STRING,                                                                         
   address_2 STRING,                                                                         
   age STRING,                                                                               
   audience_id STRING,                                                                       
   city STRING,                                                                              
   dob STRING,                                                                               
   email_address STRING,                                                                     
   first_name STRING,                                                                        
   gender_cd STRING,                                                                         
   last_name STRING,                                                                         
   middle_name STRING,                                                                       
   pat_id STRING,                                                                            
   phone_1 STRING,                                                                           
   phone_2 STRING,                                                                           
   state STRING,                                                                             
   zip_4 STRING,                                                                             
   zip_5 STRING,                                                                             
   create_dttm STRING,                                                                       
   update_dttm STRING,                                                                       
   cust_id STRING,                                                                           
   rx_nbr STRING,                                                                            
   call_duration STRING,                                                                     
   me_id STRING,                                                                             
   drug_id STRING,                                                                           
   generic_prod_id STRING,                                                                   
   src_cd STRING,                                                                            
   src_id_char STRING,                                                                       
   newline STRING,                                                                           
   tracking_id STRING,                                                                       
   file_arrival_date STRING)
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
PARTITIONED BY (                                                                             
   partition_column STRING)
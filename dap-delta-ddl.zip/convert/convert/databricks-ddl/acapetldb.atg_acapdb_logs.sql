-- Databricks notebook source
CREATE TABLE IF NOT EXISTS staging__${DOMAIN_digital}__${SUBDOMAIN_ecom}.atg_acapdb_logs(
    file STRING,
    col_cnt_iss_cnt INT,
    src_recd_cnt INT,
    null_rej_cnt INT,
    target_tbl_cnt INT,
    comment STRING,
    insert_cnt INT,
    update_cnt INT,
    retained_cnt INT)
USING ${TABLE_STORAGE_TYPE}
LOCATION
   ${TABLE_LOCATION}
PARTITIONED BY (    
    ingestion_date TIMESTAMP,
    file_name STRING)
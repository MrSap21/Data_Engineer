-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.plugins_lkp(
  id STRING, 
  desc STRING)
COMMENT 'lookup for plugins'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE LOCATION}
-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.languages_lkp(
  id INT, 
  desc STRING)
COMMENT 'lookup for languages'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
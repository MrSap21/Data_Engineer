-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.event_lkp(
  id INT, 
  desc STRING)
COMMENT 'lookup for event'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
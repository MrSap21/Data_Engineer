-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.browser_type_lkp(
  id BIGINT, 
  desc STRING)
COMMENT 'lookup for browser_type'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
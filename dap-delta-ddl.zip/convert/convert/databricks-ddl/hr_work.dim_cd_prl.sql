-- Databricks notebook source

CREATE TABLE IF NOT EXISTS hr_work.dim_cd_prl(
   cd_key BIGINT,  
   cd_id BIGINT,  
   cd_ind STRING,  
   cd_name STRING,  
   cd_type STRING,  
   cd_category STRING,  
   cd_desc STRING,  
   start_date DATE,  
  end_date DATE)
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
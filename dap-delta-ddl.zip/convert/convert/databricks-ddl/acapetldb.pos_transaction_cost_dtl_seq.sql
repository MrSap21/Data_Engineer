-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.pos_transaction_cost_dtl_seq(
  sales_txn_id STRING, 
  sales_txn_dt STRING, 
  sales_ord_src_type STRING, 
  sales_txn_type STRING, 
  src_sys_cd STRING, 
  line_item_seq_nbr INT, 
  cost_type_cd STRING, 
  cost_dlrs DECIMAL(8,2), 
  cost_src_type_cd STRING, 
  edw_create_dttm STRING, 
  edw_update_dttm STRING, 
  edw_batch_id DECIMAL(18,0))
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
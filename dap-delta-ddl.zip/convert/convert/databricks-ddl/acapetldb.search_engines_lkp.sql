-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.search_engines_lkp(
  id INT, 
  desc STRING)
COMMENT 'lookup for search_engines'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}

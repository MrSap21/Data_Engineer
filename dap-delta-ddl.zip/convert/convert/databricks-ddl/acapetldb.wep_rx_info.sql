-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.wep_rx_info(
  urlid STRING COMMENT 'FROM deserializer', 
  patid STRING COMMENT 'FROM deserializer', 
  firstname STRING COMMENT 'FROM deserializer', 
  lastname STRING COMMENT 'FROM deserializer', 
  rxnbr STRING COMMENT 'FROM deserializer', 
  strnbr STRING COMMENT 'FROM deserializer', 
  staddr STRING COMMENT 'FROM deserializer', 
  stcity STRING COMMENT 'FROM deserializer', 
  ststate STRING COMMENT 'FROM deserializer', 
  stzip STRING COMMENT 'FROM deserializer', 
  channelms STRING COMMENT 'FROM deserializer', 
  createdt STRING COMMENT 'FROM deserializer', 
  updatedt STRING COMMENT 'FROM deserializer', 
  homeeligi STRING COMMENT 'FROM deserializer', 
  strphnnbr STRING COMMENT 'FROM deserializer', 
  strfaxnbr STRING COMMENT 'FROM deserializer', 
  fillnbr STRING COMMENT 'FROM deserializer', 
  phnnbr STRING COMMENT 'FROM deserializer')
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
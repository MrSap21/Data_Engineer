-- Databricks notebook source
CREATE TABLE IF NOT EXISTS staging__${DOMAIN_digital}__${SUBDOMAIN_ecom}.www_source_system_lookup_etl(                                 
  me_id STRING,                                                                  
  source_system STRING,                                                          
  source_system_id STRING,                                                       
  source_status STRING,                                                          
  create_dttm STRING,                                                            
  update_dttm STRING,                                                            
  create_user STRING,                                                            
  update_user STRING)                                                            
USING ${TABLE_STORAGE_TYPE}
LOCATION
   ${TABLE_LOCATION}

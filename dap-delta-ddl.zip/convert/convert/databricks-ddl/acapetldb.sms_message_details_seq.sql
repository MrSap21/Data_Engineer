-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.sms_message_details_seq(
  messagedirection STRING COMMENT 'FROM deserializer', 
  message_id STRING COMMENT 'FROM deserializer', 
  client_id STRING COMMENT 'FROM deserializer', 
  client_name STRING COMMENT 'FROM deserializer', 
  carrier_id STRING COMMENT 'FROM deserializer', 
  carrier_name STRING COMMENT 'FROM deserializer', 
  short_code STRING COMMENT 'FROM deserializer', 
  country_code STRING COMMENT 'FROM deserializer', 
  phonenumber STRING COMMENT 'FROM deserializer', 
  campaigntype_id STRING COMMENT 'FROM deserializer', 
  campaigntypename STRING COMMENT 'FROM deserializer', 
  trigger_id STRING COMMENT 'FROM deserializer', 
  campaign_id STRING COMMENT 'FROM deserializer', 
  campaignname STRING COMMENT 'FROM deserializer', 
  clienttag STRING COMMENT 'FROM deserializer', 
  messagetext STRING COMMENT 'FROM deserializer', 
  status_id STRING COMMENT 'FROM deserializer', 
  statusdescription STRING COMMENT 'FROM deserializer', 
  detailedstatusid STRING COMMENT 'FROM deserializer', 
  detailedstatusdescription STRING COMMENT 'FROM deserializer', 
  submitted_date STRING COMMENT 'FROM deserializer')
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
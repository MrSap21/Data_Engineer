-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.referrer_type_lkp(
  id INT, 
  desc STRING)
COMMENT 'lookup for referrer_type'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.country_lkp(
  id INT, 
  desc STRING)
COMMENT 'lookup for country'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
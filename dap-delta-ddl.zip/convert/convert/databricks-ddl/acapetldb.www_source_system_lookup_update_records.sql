-- Databricks notebook source
create table staging__${DOMAIN_digital}__${SUBDOMAIN_ecom}.www_source_system_lookup_update_records(
    me_id STRING
    ,source_system STRING
    ,source_system_id STRING
    ,source_status STRING
    ,create_dttm TIMESTAMP
    ,CREATE_USER STRING
    ,UPDATE_DTTM TIMESTAMP
    ,UPDATE_USER STRING)
USING ${TABLE_STORAGE_TYPE}
LOCATION
   ${TABLE_LOCATION}

-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.javascript_lkp(
  id INT, 
  desc STRING)
COMMENT 'lookup for javascript_version'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
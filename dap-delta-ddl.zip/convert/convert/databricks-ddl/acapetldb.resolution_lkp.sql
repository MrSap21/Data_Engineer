-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.resolution_lkp(
  id INT, 
  desc STRING)
COMMENT 'lookup for resolution'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
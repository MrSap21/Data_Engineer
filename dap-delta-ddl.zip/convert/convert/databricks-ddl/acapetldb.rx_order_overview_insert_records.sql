-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.rx_order_overview_insert_records(
  rx_ord_ref_num STRING, 
  rx_ord_store_num STRING, 
  rx_ord_channel_cd STRING, 
  rx_ord_channel_detail_cd STRING, 
  rx_ord_dttm TIMESTAMP, 
  rx_ord_gq_submit_dttm TIMESTAMP, 
  rx_ord_process_count STRING, 
  rx_ord_submit_status_cd STRING, 
  rx_ord_owner_me_id STRING, 
  rx_ord_site_cd STRING)
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
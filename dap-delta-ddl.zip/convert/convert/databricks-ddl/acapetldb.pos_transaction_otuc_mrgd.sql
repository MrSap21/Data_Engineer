-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.pos_transaction_otuc_mrgd(
  sales_txn_id STRING, 
  sales_txn_dt STRING, 
  sales_ord_src_type STRING, 
  sales_txn_type STRING, 
  src_sys_cd STRING, 
  line_item_seq_nbr INT, 
  line_item_dtl_nbr DECIMAL(38,0), 
  plu_nbr DECIMAL(4,0), 
  one_tm_use_coupon_barcode STRING, 
  entry_mode_cd STRING, 
  basket_lvl_cd STRING, 
  edw_create_dttm STRING, 
  edw_update_dttm STRING, 
  edw_batch_id DECIMAL(18,0))
PARTITIONED BY (
  sales_txn_year STRING)
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
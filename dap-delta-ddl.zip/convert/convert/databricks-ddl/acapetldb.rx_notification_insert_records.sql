-- Databricks notebook source
CREATE TABLE IF NOT EXISTS staging__${DOMAIN_digital}__${SUBDOMAIN_ecom}.rx_notification_insert_records( 
 aggregation_id STRING, 
 notification_channel STRING, 
 communication_channel STRING, 
 pat_id STRING, 
 source_system STRING, 
 notification_msg STRING, 
 notification_language STRING, 
 field_activity_ind STRING, 
 app_instance STRING, 
 create_dttm TIMESTAMP) 
USING ${TABLE_STORAGE_TYPE}
LOCATION
   ${TABLE_LOCATION}

-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.www_wep_rx_info_update_records(
  short_url_id STRING, 
  pat_id STRING, 
  first_name STRING, 
  last_name STRING, 
  rx_number STRING, 
  store_number STRING, 
  st_addr STRING, 
  st_city STRING, 
  st_state STRING, 
  st_zip STRING, 
  channel_msg_sent STRING, 
  create_dttm TIMESTAMP, 
  update_dttm TIMESTAMP, 
  home_deli_eligble_ind STRING, 
  store_ph_number STRING, 
  store_fax_number STRING, 
  fill_number STRING, 
  phone_num STRING)
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE TABLE IF NOT EXISTS staging__${DOMAIN_digital}__${SUBDOMAIN_ecom}.browser_lkp(
  id BIGINT, 
  desc STRING)
COMMENT 'lookup for browser'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.rx_order_overview(
  rx_ord_ref_num STRING COMMENT 'FROM deserializer', 
  rx_ord_store_num STRING COMMENT 'FROM deserializer', 
  rx_ord_channel_cd STRING COMMENT 'FROM deserializer', 
  rx_ord_channel_detail_cd STRING COMMENT 'FROM deserializer', 
  rx_ord_dttm STRING COMMENT 'FROM deserializer', 
  rx_ord_gq_submit_dttm STRING COMMENT 'FROM deserializer', 
  rx_ord_process_count STRING COMMENT 'FROM deserializer', 
  rx_ord_submit_status_cd STRING COMMENT 'FROM deserializer', 
  rx_ord_owner_me_id STRING COMMENT 'FROM deserializer', 
  rx_ord_site_cd STRING COMMENT 'FROM deserializer')
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.rx_sms_refill_info_stg(
  mongo_id STRING COMMENT 'FROM deserializer', 
  transaction_id STRING COMMENT 'FROM deserializer', 
  record_id STRING COMMENT 'FROM deserializer', 
  pat_id STRING COMMENT 'FROM deserializer', 
  phone_number STRING COMMENT 'FROM deserializer', 
  store_ph_no STRING COMMENT 'FROM deserializer', 
  create_dttm STRING COMMENT 'FROM deserializer', 
  first_name STRING COMMENT 'FROM deserializer', 
  last_name STRING COMMENT 'FROM deserializer', 
  update_dttm STRING COMMENT 'FROM deserializer', 
  dob_verified STRING COMMENT 'FROM deserializer')
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
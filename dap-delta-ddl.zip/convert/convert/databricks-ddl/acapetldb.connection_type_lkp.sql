-- Databricks notebook source
CREATE TABLE IF NOT EXISTS acapetldb.connection_type_lkp(
  id INT, 
  desc STRING)
COMMENT 'lookup for connection_type_lkp'
USING ${TABLE_STORAGE_TYPE}
LOCATION ${TABLE_LOCATION}
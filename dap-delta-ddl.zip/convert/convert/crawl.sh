beelineConnString='???'
databases=$(beeline -u ${beelineConnString} --showHeader=false --outputformat=tsv2 -e "show databases;")
db_list=echo "${databases}"
for db in $databases
do
    tables=$(beeline -u ${beelineConnString} --showHeader=false --outputformat=tsv2 -e "show tables in $db;")
    tbl_list=echo "${tables}"
    for tbl in $tbl_list
    do 
        hiveddl=$(beeline -u ${beelineConnString} --showHeader=false --outputformat=tsv2 -e "show create table ${db}.${tbl};") 
        python convert.py $hiveddl >> ${db}.${tbl}.sql
    done
done
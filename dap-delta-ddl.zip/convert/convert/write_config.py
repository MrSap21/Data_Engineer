import json 
import pandas as pd 
import numpy as np
import re
from reference import (
    domain_param_switch,
    subdomain_param_switch
)

df = pd.read_parquet('./data/ddl.parquet')
print("Total Tables Converted:        ", (len(df)))
print("Total Domain Tables Converted: ", len(df[df.domain != 'tbd']))





# -------------------------------------------------
# Write .env:
# -------------------------------------------------
with open('./databricks-ddl/configs/.dev.env', 'w') as f:
    f.write('STORAGE_TYPE=DELTA\n')
    f.write('\n')
    for i in set(df.domain_param.tolist()):
        p = i.replace('${','')[:-1]
        s = p.replace('DOMAIN_','')
        f.write(f"{p}={s}\n")
    f.write('\n')
    for i in set(df.sub_domain_param.tolist()):
        p = i.replace('${','')[:-1]
        s = p.replace('SUBDOMAIN_','')
        f.write(f"{p}={s}\n")
    f.write('\n')
    for i in set(df.loc_storage_acct_param.tolist()):
        p = i.replace('${','')[:-1]
        f.write(f"{p}=\n")
    f.write('\n')
    for i in set(df.loc_container_param.tolist()):
        p = i.replace('${','')[:-1]
        f.write(f"{p}=\n")





# -------------------------------------------------
# Write json:
# -------------------------------------------------
configs = {
    'domains': {},
    'subdomains': {},
    'adls': {
        'storage_account': {},
        'container': {},
    }
}
for k,v in domain_param_switch.items():
    p = v.replace('${','')[:-1]
    configs['domains'][p] = k
for k,v in subdomain_param_switch.items():
    p = v.replace('${','')[:-1]
    configs['subdomains'][p] = k
for i in set(df.loc_storage_acct_param.tolist()):
    p = i.replace('${','')[:-1]
    configs['adls']['storage_account'][p] = ''
for i in set(df.loc_container_param.tolist()):
    p = i.replace('${','')[:-1]
    configs['adls']['container'][p] = ''

with open('./databricks-ddl/configs/configs.json', 'w') as f:
    json.dump(configs, f, indent=2)




# -------------------------------------------------
# Write ymal:
# -------------------------------------------------
with open('./databricks-ddl/configs/configs.yaml', 'w') as f:
    f.write('domains:\n')
    for i in set(df.domain_param.tolist()):
        p = i.replace('${','')[:-1]
        s = p.replace('DOMAIN_','')
        f.write(f"    {p}: {s}\n")

    f.write('\nsubdomains:\n')
    for i in set(df.sub_domain_param.tolist()):
        p = i.replace('${','')[:-1]
        s = p.replace('SUBDOMAIN_','')
        f.write(f"    {p}: {s}\n")

    f.write('\nstorage_accounts:\n')    
    for i in set(df.loc_storage_acct_param.tolist()):
        p = i.replace('${','')[:-1]
        f.write(f"    {p}: \n")

    f.write('\ncontainers:\n')    
    for i in set(df.loc_container_param.tolist()):
        p = i.replace('${','')[:-1]
        f.write(f"    {p}: \n")


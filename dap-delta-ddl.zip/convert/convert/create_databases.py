import json 
from pathlib import Path
from reference import (
    domain_param_switch,
    subdomain_param_switch,
    ddl_record
)

with open('./databricks-ddl/migrations/ddl.json', 'r') as f:
    ddl_dict = json.load(f)
    
Path(f"databricks-ddl/scripts/curated/databases/").mkdir(exist_ok=True)
Path(f"databricks-ddl/scripts/curated/databases/downgrade/").mkdir(exist_ok=True)
Path(f"databricks-ddl/scripts/wrangled/databases/").mkdir(exist_ok=True)
Path(f"databricks-ddl/scripts/wrangled/databases/downgrade/").mkdir(exist_ok=True)

counter = 1
databases = {}
locations = {}
for i in ddl_dict:
    if i['domain'] == 'tbd' or i['sub_domain'] == 'tbd':
        pass
    else:
        db_name = i['param_table_name'].split('.')[0].replace('${','').replace('}','').replace('SUBDOMAIN_','').replace('DOMAIN_','')
        databases[db_name] = {
            'database_param': i['param_table_name'].split('.')[0],
            'location': '/'.join(i['location'].strip().split('/')[:-1]) + "';",
            'zone': i['zone'],
            'domain': i['domain'],
            'sub_domain': i['sub_domain'],
            'domain_param': i['domain_param'],
            'sub_domain_param': i['sub_domain_param'],
            'loc_storage_acct_param': i['loc_storage_acct_param'],
            'loc_container_param': i['loc_container_param'],
        }
        
new = []
counter = 1
for k,v in databases.items():
    print(k)
    script = f"-- Databricks notebook source\nCREATE SCHEMA IF NOT EXISTS {v.get('database_param')}\nLOCATION {v.get('location')}"
    down_script = f"-- Databricks notebook source\DROP SCHEMA IF EXISTS {v.get('database_param')}"
    
    if v.get('zone') == 'wrangled':
        path = 'databricks-ddl/scripts/wrangled/databases/'
    else:
        path = 'databricks-ddl/scripts/curated/databases/'
        
    ddl_record = {
        'id': f'D_1.{counter}.1',
        'script': f'D_1.{counter}.1__{k}.sql',
        'path': f'{path}D_1.{counter}.1__{k}.sql',
        'table_name': None,
        'param_table_name': None,
        'legacy_db': None,
        'legacy_schema': None,
        'table_type': 'database',
        'zone': v.get('zone'),
        'domain': v.get('domain'),
        'sub_domain': v.get('sub_domain'),
        'wrangled_extra_layer': None,
        'location': v.get('location'),
        'domain_param': v.get('domain_param'),
        'sub_domain_param': v.get('sub_domain_param'),
        'loc_storage_acct_param': v.get('loc_storage_acct_param'),
        'loc_container_param': v.get('loc_container_param'),
        'deploy_flag': None,
        'current_revision': 0,
        'upgrade_id': None,
        'downgrade_path': f'{path}downgrade/D_1.{counter}.1__{k}.sql',
        'storage_type': None,
        'partitioned_by': None,
        'clustered_by': None,
        'sorted_by': None,
        'table_buckets': None,
        'ancestors': None,
        'descendents': None,
        'create_date': None,
        'created_by': None,
        'update_date': None,
        'updated_by': None,
        'deployment_date': None
    }
    
    with open(f'{path}D_1.{counter}.1__{k}.sql','w') as f:
        f.write(script)
    with open(f'{path}downgrade/D_1.{counter}.1__{k}.sql','w') as f:
        f.write(down_script)

    ddl_dict.append(ddl_record)
    new.append(ddl_record)
    counter = counter + 1
    
with open('./databricks-ddl/migrations/ddl.json', 'w') as f:
    json.dump(ddl_dict, f, indent=2)

with open('./databricks-ddl/migrations/new.json', 'w') as f:
    json.dump(new, f, indent=2)

import json
import re
import pandas as pd 
import numpy as np
from datetime import datetime  
from pathlib import Path
from reference import (
    domain_param_switch,
    subdomain_param_switch,
    table_columns
)

ddl_json = []
df_ref = pd.read_csv('./data/Target_Table_Master_File.csv')
df_ref[['Domain','Sub_Domain']] = df_ref[['Domain','Sub_Domain']].fillna('TDB').astype(str)
df_ref = df_ref.fillna('').astype(str)
df_ref['Table_Name'] = df_ref['Table_Name'].str.lower()

# =================================================
# load files
# =================================================
files_list = []
DDLs = Path('./').glob("DDLs/**/*.txt")
print("LOADED DDL FILES:")
for item in DDLs:
    files_list.append(item)
    print(item)

# =================================================
# define regex
# =================================================
regex_TBLPROPERTIES = re.compile(r"TBLPROPERTIES \((.*?)\)", re.DOTALL)
regex_COMMENT = re.compile(r"COMMENT '(.*?)'", re.DOTALL)
regex_SERDE_PROPS = re.compile(r"[\s]WITH SERDEPROPERTIES(.*?)(\n\W(.+))+", re.MULTILINE)
regex_ROW_FORMAT = re.compile(r"[\s]ROW FORMAT (.*?)(\n\W(.+))+", re.MULTILINE)
regex_INPUTFORMAT = re.compile(r"STORED AS INPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)
regex_OUTPUTFORMAT = re.compile(r"[\s]OUTPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)
regex_varchar = re.compile(r"` varchar\((.*?)\)")
regex_char = re.compile(r"` char\((.*?)\)")
regex_PARTITION = re.compile(r"[\s]PARTITIONED BY \((.*?)\)", re.DOTALL)
regex_CLUSTERED = re.compile(r"[\s]CLUSTERED BY \((.*?)\)", re.DOTALL)
regex_SORTED = re.compile(r"[\s]SORTED BY \((.*?)\)", re.DOTALL)
regex_BUCKETS = re.compile(r"[\s]INTO(.*?)BUCKETS", re.DOTALL)
regex_LOCATION = re.compile(r"LOCATION(\s+)'(.*?)'", re.DOTALL)
regex_FROM = re.compile(r"FROM (.*?)(\s+), re.DOTALL")
regex_JOIN = re.compile(r"JOIN (.*?)(\s+), re.DOTALL")

regex_COLUMNS = re.compile(r"\(\n(.*?)(\n\W(.+))+", re.MULTILINE)




# =================================================
# iterate over DDL loaded in
# =================================================
counter = 1
revisions_counter = 1
for file in files_list:
    table_columns = {
        "table_schema": [],
        "column_name": [],
        "dtype": [],
        "isPartition": [],
        "domain": [],
        "subdomain": []
    }
    with open(file, 'r') as f:
        db_name = file.parts[-1].replace('_ddl.txt','')
        print(db_name)
        # if db_name in ['dae_cooked', 'wag_gen_raw']: # uncomment to only look at one file and change any logic.
        if db_name not in ['dae_uat_work']:
            text = f.read()
            text = text.replace('from ', 'FROM ')
            text = text.replace('join ', 'JOIN ')

            # -------------------------------------------------
            # Print individual HQL files out
            # -------------------------------------------------
            ddl_hql_dict = {}
            ddl_hql = list(filter(None, text.split('\nCREATE')))
            for item in ddl_hql:
                item = item.replace('`','')
                item = 'CREATE'+item # put it back after split
                schema_index_begin = item.find(db_name)
                if schema_index_begin == -1:
                    print('No Schema in DDL?', item)
                if "CREATE TABLE" in item:
                    schema = item[item.find(db_name)-1:item.find('(')].strip()
                elif "CREATE EXTERNAL TABLE" in item:
                    schema = item[item.find(db_name)-1:item.find('(')].strip()
                elif "VIEW" in item:
                    schema = item[item.find(db_name)-1:item.find(' AS')].strip()
                else:
                    schema = item[item.find(db_name)-1:item.find(' AS')].strip()
                schema = schema.strip()
                ddl_hql_dict[schema] = item
            
            Path(f"ddl/{db_name}").mkdir(exist_ok=True)
            for key, value in ddl_hql_dict.items():
                file_name = f"ddl/{db_name}/{key}.hql"
                with open(file_name, 'w') as f:
                    f.write(value)

            # -------------------------------------------------
            # Apply the compiled regex, replace what patterns are identified.
            # -------------------------------------------------
            text = re.sub(regex_TBLPROPERTIES, '', text)
            text = re.sub(regex_COMMENT, '', text)
            text = re.sub(regex_ROW_FORMAT, '', text)
            text = re.sub(regex_SERDE_PROPS, '', text)
            text = re.sub(regex_INPUTFORMAT, 'USING ${TABLE_STORAGE_TYPE}', text)
            text = re.sub(regex_OUTPUTFORMAT, '', text)
            text = re.sub(regex_LOCATION, "LOCATION\n   ${TABLE_LOCATION}", text)
            text = re.sub(regex_varchar, '` STRING', text)
            text = re.sub(regex_char, '` STRING', text)
            std_replace = [
                ('` string', '` STRING'),
                ('` bigint', '` BIGINT'),
                ('` smallint', '` SMALLINT'),
                ('` double', '` DOUBLE'),
                ('` int', '` INT'),
                ('` decimal(', '` DECIMAL('),
                ('` date', '` DATE'),
                ('` timestamp', '` TIMESTAMP'),
                # ('`', ''),
                ('CREATE ', '\n\nCREATE '),
                ('CREATE TABLE', 'CREATE TABLE IF NOT EXISTS'),
                ('CREATE EXTERNAL TABLE', 'CREATE TABLE IF NOT EXISTS'), 
                ('CREATE VIEW', 'CREATE OR REPLACE VIEW'),
                ('SUBSTR(', 'SUBSTRING('),
                ('NVL(', 'COALESCE(')
            ]
            for item in std_replace:
                text = text.replace(item[0], item[1])

            # -------------------------------------------------
            # Separate DDL to separate items in a list. Apply other transformations.
            # -------------------------------------------------
            ddl_list = list(filter(None, text.split('\n\nCREATE')))
            ddl_sql_dict = {}
            
            for item in ddl_list:
                item = 'CREATE' + item
                table_ancestors=[]
                columns, part_cols_check = [], []
                columns_str, columns_search, part_cols_search, partitioned_by = '', '', '', ''
                
                


                if "CREATE TABLE" in item:
                    schema = item[item.find(db_name)-1:item.find('(')].strip().replace('`','')
                    table_type = 'table'
                elif "CREATE EXTERNAL TABLE" in item:
                    schema = item[item.find(db_name)-1:item.find('(')].strip().replace('`','')
                    table_type = 'external_table'
                elif "VIEW" in item:
                    schema = item[item.find(db_name)-1:item.find(' AS')].strip().replace('`','')
                    table_type = 'view'
                else:
                    schema = item[item.find(db_name)-1:item.find(' AS')].strip().replace('`','')
                    table_type = 'other'
                
                if table_type != 'view':

                    columns_search = re.search(regex_COLUMNS, item)
                    if columns_search is not None:
                        span = columns_search.span()
                        cols = item[span[0]:span[1]][1:-1].replace('`','').replace('  ','').strip()
                        columns_str = cols

                    part_cols_search = re.search(regex_PARTITION, item)
                    if part_cols_search is not None:
                        span = part_cols_search.span()
                        part_cols = item[span[0]:span[1]].replace('PARTITIONED BY (','')[2:-1].replace('`','').replace('  ','').strip() # weird, but it gets the job done. -1 to remove the closing ")"
                        partitioned_by = part_cols
                        columns_str = columns_str + '\n' + part_cols
                        part_cols_list = part_cols.split('\n')
                        for c in part_cols_list:
                            if c != '':
                                c = c.strip()
                                if c.endswith(','):
                                    c = c[:-1]
                                col = c.split(' ')
                                part_cols_check.append(col[0])
                    

                    table_name = schema.split('.')[-1].strip().lower()
                    try:
                        table_ref = df_ref[df_ref.Table_Name == table_name].to_dict('records')[0]
                    except Exception as e:
                        try:
                            check_name = table_name.replace('ext_','').replace('fl_','').replace('tl_','').replace('_new','').replace('_stg','').replace('wrk_','').replace('_idl','').replace('gg_tbf0_','').replace('etl_tbf0_','').replace('temp_','')
                            table_ref = df_ref[df_ref.Table_Name == check_name].to_dict('records')[0]
                        except Exception as e2:
                            table_ref = {'Domain': 'tbd','Sub_Domain': 'tbd'}
                            pass
                    table_domain = table_ref.get('Domain','tbd')
                    table_subdomain = table_ref.get('Sub_Domain','tbd')
                    
                    if 'cooked' in db_name or 'served' in db_name or db_name in ['emp_wlns','cso','scm','acapdb', 'acapcar','customer']:
                        table_zone = 'curated'
                        table_extra_layer = ''
                    else:
                        table_zone = 'wrangled'
                        table_name = f"{table_name}_stg"
                        if 'work' in db_name: table_extra_layer = 'work'
                        elif 'etl' in db_name: table_extra_layer = 'etl'
                        elif 'scratch' in db_name: table_extra_layer = 'scratch'
                        elif 'idl' in db_name: table_extra_layer = 'idl'
                        elif 'raw' in db_name: table_extra_layer = 'raw'
                        else: table_extra_layer = 'misc'
                    
                    print('==========================================================', schema)
                    # print(columns_str)
                    
                    columns = columns_str.split('\n')
                    for c in columns:
                        if c != '':
                            c = c.strip()
                            if c.endswith(','):
                                c = c[:-1]
                            col = c.split(' ')
                            if col[0] in part_cols_check:
                                isPartition=True
                            else:
                                isPartition=False
                            table_columns['table_schema'].append(schema)
                            table_columns['column_name'].append(col[0])
                            table_columns['dtype'].append(col[-1])
                            table_columns['isPartition'].append(isPartition)
                            table_columns['domain'].append(table_domain)
                            table_columns['subdomain'].append(table_subdomain)
    df = pd.DataFrame(table_columns)
    df.to_csv(f'./cols/{db_name}.csv', index=False)

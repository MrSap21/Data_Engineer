import json
import re
import pandas as pd 
import numpy as np
from datetime import datetime  
from pathlib import Path

text = """
CREATE TABLE `hr_work.dim_cd_prl`(
   `cd_key` bigint,  
   `cd_id` bigint,  
   `cd_ind` varchar(8),  
   `cd_name` varchar(30),  
   `cd_type` varchar(8),  
   `cd_category` varchar(4),  
   `cd_desc` varchar(300),  
   `start_date` date,  
  `end_date` date)
ROW FORMAT SERDE 
  'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe' 
STORED AS INPUTFORMAT 
  'org.apache.hadoop.mapred.TextInputFormat' 
OUTPUTFORMAT 
  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION
  'hdfs://HAProd2/data/dae/work/db/tde/pii/hr/core/dim_cd_prl'
TBLPROPERTIES (
   'COLUMN_STATS_ACCURATE'='{\"BASIC_STATS\":\"true\"}',  
   'numFiles'='1',  
   'numRows'='334733',  
   'rawDataSize'='19338024',  
   'totalSize'='2973536',  
  'transient_lastDdlTime'='1642576555')
"""
Path(f"./databricks-ddl/").mkdir(exist_ok=True)

std_replace = [
    ('`', ''),
    (' string', ' STRING'),
    (' bigint', ' BIGINT'),
    (' smallint', ' SMALLINT'),
    (' double', ' DOUBLE'),
    (' int', ' INT'),
    (' decimal(', ' DECIMAL('),
    (' date', ' DATE'),
    (' timestamp', ' TIMESTAMP'),
    (' Timestamp', ' TIMESTAMP'),
    # ('\nCREATE ', '\n\nCREATE '),
    ('CREATE TABLE ', 'CREATE TABLE IF NOT EXISTS '),
    ('CREATE EXTERNAL TABLE ', 'CREATE TABLE IF NOT EXISTS '), 
    ('CREATE VIEW', 'CREATE OR REPLACE VIEW'),
    ('SUBSTR(', 'SUBSTRING('),
    ('NVL(', 'COALESCE('),
    ('from ', 'FROM '),
    ('join ', 'JOIN ')
]

# =================================================
# define regex
# =================================================
regex_TBLPROPERTIES = re.compile(r"TBLPROPERTIES \(.*?\)", re.DOTALL)
regex_COLUMNS = re.compile(r"", re.MULTILINE)
# regex_COMMENT = re.compile(r"COMMENT '.*?'", re.DOTALL)
regex_SERDE_PROPS = re.compile(r"\sWITH SERDEPROPERTIES(.*?)(\n\W(.+))+", re.MULTILINE)
regex_ROW_FORMAT = re.compile(r"\sROW FORMAT (.*?)(\s+(.+))+", re.MULTILINE)
regex_INPUTFORMAT = re.compile(r"STORED AS INPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)
regex_OUTPUTFORMAT = re.compile(r"\sOUTPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)
regex_varchar = re.compile(r" varchar\((.*?)\)", re.IGNORECASE)
regex_char = re.compile(r" char\((.*?)\)", re.IGNORECASE)
regex_name = re.compile(r"\w+\.\w+")
regex_PARTITION = re.compile(r"\sPARTITIONED BY \(.*?\)", re.DOTALL)
regex_CLUSTERED = re.compile(r"\sCLUSTERED BY \(.*?\)", re.DOTALL)
regex_SORTED = re.compile(r"\sSORTED BY \(.*?\)", re.DOTALL)
regex_BUCKETS = re.compile(r"\sINTO.+BUCKETS", re.DOTALL)
regex_LOCATION = re.compile(r"\sLOCATION\s+'.+'", re.DOTALL)
regex_FROM = re.compile(r"FROM .*?\s+, re.DOTALL")
regex_JOIN = re.compile(r"JOIN .*?\s+, re.DOTALL")
# regex_COLUMNS = re.compile(r"STORED AS INPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)
# regex_OPTIONS = re.compile(r"STORED AS INPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)
# cols_search = re.findall(r"\(.*?\)", text, re.DOTALL)
# if cols_search is not None:
#     span = cols_search
#     print(cols_search)

# text = re.sub(regex_COMMENT, '', text)
text = re.sub(regex_TBLPROPERTIES, '', text)
text = re.sub(regex_ROW_FORMAT, '', text)
text = re.sub(regex_SERDE_PROPS, '', text)
text = re.sub(regex_INPUTFORMAT, 'USING ${TABLE_STORAGE_TYPE}', text)
text = re.sub(regex_OUTPUTFORMAT, '', text)
text = re.sub(regex_LOCATION, "\nLOCATION\n   ${TABLE_LOCATION}", text)
text = re.sub(regex_varchar, '` STRING', text)
text = re.sub(regex_char, '` STRING', text)
for item in std_replace:
    text = text.replace(item[0], item[1])

text = '-- Databricks notebook source\n'+text 
name_search = re.search(regex_name, text)
part_cols_search = re.search(regex_PARTITION, text)
clustered_search = re.search(regex_CLUSTERED, text)
sorted_search = re.search(regex_SORTED, text)
buckets_search = re.search(regex_BUCKETS, text)
if name_search is not None:
    span = name_search.span()
    print(text[span[0]:span[1]])
    name = text[span[0]:span[1]]
if part_cols_search is not None:
    span = part_cols_search.span()
    part_cols = text[span[0]:span[1]].replace('PARTITIONED BY (','')[2:-1] # weird, but it gets the job done. -1 to remove the closing ")"
    partitioned_by = part_cols
    text = re.sub(regex_PARTITION, '', text)
    text = text.rstrip() + f'\nPARTITIONED BY ({part_cols})'
    # text = text.rstrip() + '\nPARTITIONED BY (\n   <TABLE_PARTITION>)'                
if clustered_search is not None:
    span = clustered_search.span()
    clustered_cols = text[span[0]:span[1]].replace('CLUSTERED BY (','')[2:-1]
    text = re.sub(regex_CLUSTERED, '', text)
    # text = text.rstrip() + f'\nCLUSTERED BY ({clustered_cols})'
    if sorted_search is not None:
        span = sorted_search.span()
        sorted_cols = text[span[0]:span[1]].replace('SORTED BY (','')[2:-1]
        sorted_stmt = text[span[0]:span[1]]
        text = re.sub(regex_SORTED, '', text)
    if buckets_search is not None:
        span = buckets_search.span()
        table_buckets = text[span[0]:span[1]].replace('INTO','').replace('BUCKETS','').strip()
        text = re.sub(regex_BUCKETS, '', text)
        # text = text.rstrip() + f'\nINTO {table_buckets} BUCKETS)'

print(text)

file_name = f"./databricks-ddl/{name}.sql"
with open(file_name, 'w') as f:
    f.write(text.strip())
    f.write("\nUSING ${TABLE_STORAGE_TYPE}")
    f.write("\nLOCATION ${TABLE_LOCATION}")

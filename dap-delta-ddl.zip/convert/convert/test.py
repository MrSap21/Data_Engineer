import pandas as pd 
import numpy as np
import re




df = pd.read_parquet('./data/ddl.parquet')
print("Total Tables Converted:        ", (len(df)))
print("Total Domain Tables Converted: ", len(df[df.domain != 'tbd']))


 
df.drop('sql', inplace=True, axis=1)
df = df[df.table_type == 'view'].fillna('').astype(str).to_csv('./views.csv')


# for i in set(df.sub_domain.tolist()):
#     print(f'"{i}": "${{SUBDOMAIN_{i}}}",')




# df = df[df.domain == 'property_services']
# df = df[df.table_name == 'e']
# print(df['sql'].iloc[0])
# print(df['legacy_db'].drop_duplicates(keep='first').head())

# df = df[['table_name','legacy_db', 'zone']]['table_name'].value_counts().reset_index()
# df_a = df[['table_name','legacy_db']].groupby('table_name').count()
# df_a = df_a.rename(columns={'legacy_db':'cnt'})
# df = pd.merge(df, df_a, how='left', left_on='table_name', right_on='table_name', suffixes=(None, '_'))
# df = df[df.cnt > 1]

# df[['table_name', 'legacy_db', 'zone', 'table_type', 'cnt']].to_csv('./dups.csv', index=False)

# for i,r in df.iterrows():
#     print(r['legacy_schema'])


# out = [
#     'dae_cooked.supplier',
#     'dae_cooked.adr_supplier',
#     'fin_cooked.pars_summary_deposits',
#     'fin_cooked.pars_remitter_master_data',
#     'fin_cooked.pars_granular_deposits',
#     'fin_cooked.oracle_vendorapic',
#     'fin_cooked.mgr_rpt_tl_prescription_fill',
#     'fin_cooked.mgr_rpt_agg_results',
#     'fin_cooked.lawson_open_invoices',
#     'fin_cooked.lawson_ap265'
# ]

# print(df.head())

# df = pd.read_csv('ddl.csv', delimiter='|')
# df = df[df.descendents != []]
# df = df[(~df.sql.str.contains('LOCATION')) & (df.table_type != 'view')]
# df = df[df.sql.str.contains('<TABLE_NAME>C<TABLE_NAME>')]
# print(df.table_type.value_counts())
# print(df.iloc[0])
# print(df.sql.iloc[0].replace('<TABLE_NAME>',''))
# print(df[df.legacy_schema.str.contains('cutoff_hive')]['sql'].iloc[0])
# df = df[df.legacy_schema.str.contains('acapcar.rx_uce_prod')]
# print(df.iloc[0])
# print(df.sql.iloc[0])
# df = df[~df.sql.str.contains('CLUSTERED|PARTITIONED')]
# print(df.iloc[:3])
# df = df[df.sql.str.contains('CLUSTERED')]
# df = df[df.legacy_schema == 'dae_code_raw_ingestion.gg_tbf0_patient']
# print(df.sql.iloc[0].replace('<TABLE_NAME>',df.table_name.iloc[0]).replace('<TABLE_STORAGE_TYPE>',df.storage_type.iloc[0]).replace('<TABLE_LOCATION>',df.location.iloc[0]).replace('<TABLE_PARTITION>',df.partitioned_by.iloc[0]))



# df = df[df.table_type != 'Other' ]
# df_inventory = df[['table_name','legacy_schema', 'table_type', 'domain', 'sub_domain', 'ancestors']].copy()
# df_inventory['fileName'] = df_inventory['legacy_schema'].apply(lambda x: x + ".hql")
# df_inventory['filePath'] = df_inventory['legacy_schema'].apply(lambda x: "ddl\\" + x.split('.')[0] + '\\' + x + ".hql")
# df_inventory['onPremObjectCategory'] = df_inventory['table_type']
# df_inventory['onPremFileExtension'] = 'hql'
# df_inventory['repository'] = 'ddl'
# df_inventory['fileExtension'] = 'hql'

# df_inventory = df_inventory[['onPremObjectCategory', 'onPremFileExtension', 'fileName', 'filePath', 'repository', 'fileExtension', 'domain']]
# print(df_inventory.head())
# df_inventory.to_csv('ddl_inventory.csv', index=False)


import json
import re
import pandas as pd 
import numpy as np
from datetime import datetime  
from pathlib import Path
from reference import (
    std_replace, 
    domain_param_switch,
    subdomain_param_switch,
    ddl_record
)

df_ddl = pd.read_json(path_or_buf='../../migrations/ddl.json', orient='records')
df_tbd = pd.read_json(path_or_buf='../../migrations/ddl_tbd.json', orient='records')
legacy_schemas_already_converted = set(df_ddl.legacy_schema.tolist() + df_tbd.legacy_schema.tolist())
current_ids = set(df_ddl.id.tolist() + df_tbd.id.tolist())
tbl_ids = set([int(i.split('.')[1]) for i in current_ids])

with open('../../migrations/ddl.json', 'r') as f:
    ddl_current = json.load(f)

with open('../../migrations/ddl_tbd.json', 'r') as f:
    ddl_tbd = json.load(f)




# Path(f"databricks-ddl/").mkdir(exist_ok=True)
# Path(f"databricks-ddl/scripts/").mkdir(exist_ok=True)
# Path(f"databricks-ddl/managed/").mkdir(exist_ok=True)
# Path(f"databricks-ddl/configs/").mkdir(exist_ok=True)
# Path(f"databricks-ddl/migrations/").mkdir(exist_ok=True)
# Path(f"databricks-ddl/scripts/curated").mkdir(exist_ok=True)
# Path(f"databricks-ddl/scripts/wrangled").mkdir(exist_ok=True)
# Path(f"databricks-ddl/managed/curated").mkdir(exist_ok=True)
# Path(f"databricks-ddl/managed/wrangled").mkdir(exist_ok=True)

ddl_json = []
df_ref = pd.read_csv('../reference/Target_Table_Master_File.csv')
df_ref[['Domain','Sub_Domain']] = df_ref[['Domain','Sub_Domain']].fillna('TDB').astype(str)
df_ref = df_ref.fillna('').astype(str)
df_ref['Table_Name'] = df_ref['Table_Name'].str.lower()
df_ref['Domain'] = df_ref['Domain'].str.replace(' ','_').replace('-','_').str.lower()
df_ref['Sub_Domain'] = df_ref['Sub_Domain'].str.replace(' ','_').replace('-','_').str.lower()

# =================================================
# load files
# =================================================
files_list = []
DDLs = Path('../').glob("hive_ddl/**/*.txt")
print("LOADED DDL FILES:")
for item in DDLs:
    files_list.append(item)
    print(item)

# =================================================
# define regex
# =================================================
regex_TBLPROPERTIES = re.compile(r"TBLPROPERTIES \((.*?)\)", re.DOTALL)
regex_COMMENT = re.compile(r"COMMENT '(.*?)'", re.DOTALL)
regex_SERDE_PROPS = re.compile(r"[\s]WITH SERDEPROPERTIES(.*?)(\n\W(.+))+", re.MULTILINE)
regex_ROW_FORMAT = re.compile(r"[\s]ROW FORMAT (.*?)(\n\W(.+))+", re.MULTILINE)
regex_INPUTFORMAT = re.compile(r"STORED AS INPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)
regex_OUTPUTFORMAT = re.compile(r"[\s]OUTPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)
regex_varchar = re.compile(r"` varchar\((.*?)\)")
regex_char = re.compile(r"` char\((.*?)\)")
regex_PARTITION = re.compile(r"[\s]PARTITIONED BY \((.*?)\)", re.DOTALL)
regex_CLUSTERED = re.compile(r"[\s]CLUSTERED BY \((.*?)\)", re.DOTALL)
regex_SORTED = re.compile(r"[\s]SORTED BY \((.*?)\)", re.DOTALL)
regex_BUCKETS = re.compile(r"[\s]INTO(.*?)BUCKETS", re.DOTALL)
regex_LOCATION = re.compile(r"LOCATION(\s+)'(.*?)'", re.DOTALL)
regex_FROM = re.compile(r"FROM (.*?)(\s+), re.DOTALL")
regex_JOIN = re.compile(r"JOIN (.*?)(\s+), re.DOTALL")

# regex_COLUMNS = re.compile(r"STORED AS INPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)
# regex_OPTIONS = re.compile(r"STORED AS INPUTFORMAT(.*?)(\n\W(.+))+", re.MULTILINE)




# =================================================
# iterate over DDL loaded in
# =================================================
counter = max(tbl_ids)
print(counter)
for file in files_list:
    with open(file, 'r') as f:
        db_name = file.parts[-1].replace('_ddl.txt','')
        print(db_name)
        # if db_name in ['dae_cooked', 'wag_gen_raw']: # uncomment to only look at one file and change any logic.
        if db_name not in ['dae_uat_work']:
            text = f.read()
            text = text.replace('from ', 'FROM ')
            text = text.replace('join ', 'JOIN ')

            # -------------------------------------------------
            # Apply the compiled regex, replace what patterns are identified.
            # -------------------------------------------------
            text = re.sub(regex_TBLPROPERTIES, '', text)
            text = re.sub(regex_COMMENT, '', text)
            text = re.sub(regex_ROW_FORMAT, '', text)
            text = re.sub(regex_SERDE_PROPS, '', text)
            text = re.sub(regex_INPUTFORMAT, 'USING ${TABLE_STORAGE_TYPE}', text)
            text = re.sub(regex_OUTPUTFORMAT, '', text)
            text = re.sub(regex_LOCATION, "LOCATION\n   ${TABLE_LOCATION}", text)
            text = re.sub(regex_varchar, '` STRING', text)
            text = re.sub(regex_char, '` STRING', text)
            for item in std_replace:
                text = text.replace(item[0], item[1])

            # -------------------------------------------------
            # Separate DDL to separate items in a list. Apply other transformations.
            # -------------------------------------------------
            ddl_list = list(filter(None, text.split('\n\nCREATE')))
            ddl_sql_dict = {}
            
            for item in ddl_list:
                table_ancestors=[]
                table_clustered, table_sorted, table_buckets, part_cols_search, partitioned_by = '', '', '', '', ''
                
                item = '-- Databricks notebook source\nCREATE'+item # put it back after split
                part_cols_search = re.search(regex_PARTITION, item)
                clustered_search = re.search(regex_CLUSTERED, item)
                sorted_search = re.search(regex_SORTED, item)
                buckets_search = re.search(regex_BUCKETS, item)
                from_search = re.findall(r"FROM (.*?)(\s+)", item, re.DOTALL)  
                join_search = re.findall(r"JOIN (.*?)(\s+)", item, re.DOTALL)
                
                if part_cols_search is not None:
                    span = part_cols_search.span()
                    part_cols = item[span[0]:span[1]].replace('PARTITIONED BY (','')[2:-1] # weird, but it gets the job done. -1 to remove the closing ")"
                    partitioned_by = part_cols
                    item = re.sub(regex_PARTITION, '', item)
                    item = item.rstrip() + f'\nPARTITIONED BY ({part_cols})'
                    # item = item.rstrip() + '\nPARTITIONED BY (\n   ${TABLE_PARTITION})'                
                if clustered_search is not None:
                    span = clustered_search.span()
                    clustered_cols = item[span[0]:span[1]].replace('CLUSTERED BY (','')[2:-1]
                    item = re.sub(regex_CLUSTERED, '', item)
                    item = item.rstrip() + f'\nCLUSTERED BY ({clustered_cols})'
                    # item = item.rstrip() + '\nCLUSTERED BY (\n   ${TABLE_CLUSTERED})'
                    if sorted_search is not None:
                        span = sorted_search.span()
                        sorted_cols = item[span[0]:span[1]].replace('SORTED BY (','')[2:-1]
                        sorted_stmt = item[span[0]:span[1]]
                        item = re.sub(regex_SORTED, '', item)
                        # item = item.rstrip() + '\nSORTED BY (\n   ${TABLE_SORTED})'
                    if buckets_search is not None:
                        span = buckets_search.span()
                        table_buckets = item[span[0]:span[1]].replace('INTO','').replace('BUCKETS','').strip()
                        item = re.sub(regex_BUCKETS, '', item)
                        item = item.rstrip() + f'\nINTO {table_buckets} BUCKETS)'
                        # item = item.rstrip() + '\nINTO ${TABLE_BUCKETS} BUCKETS)'
                        
                if from_search is not None:
                    for i in from_search:
                        if i[0] != '' and '(' not in i[0]:
                            ancs = i[0].strip().lower()
                            item = item.replace(i[0],ancs)
                            ancs = ancs.replace('))temp', '')
                            if ')' in ancs: ancs = ancs[:-1]
                            table_ancestors.append(ancs)
                if join_search is not None:
                    for i in join_search:
                        if i[0] != '' and '(' not in i[0]:
                            ancs = i[0].strip().lower()
                            item = item.replace(i[0],ancs)
                            ancs = ancs.replace('))temp', '')
                            if ')' in ancs: ancs = ancs[:-1]
                            table_ancestors.append(ancs)
                
                if "CREATE TABLE" in item:
                    schema = item[item.find(db_name)-1:item.find('(')].strip()
                    table_type = 'table'
                elif "CREATE EXTERNAL TABLE" in item:
                    schema = item[item.find(db_name)-1:item.find('(')].strip()
                    table_type = 'external_table'
                elif "VIEW" in item:
                    schema = item[item.find(db_name)-1:item.find(' AS')].strip()
                    table_type = 'view'
                else:
                    schema = item[item.find(db_name)-1:item.find(' AS')].strip()
                    table_type = 'other'
                
                # because most are already converted, I've put this here to limit to explicitly do what _hasn't_ been converted yet.
                if schema not in legacy_schemas_already_converted:
                    
                    # this part searches the csv from /reference/, which holds the baseline table inventory. Thats where we get the domain/subdomain, etc from
                    table_name = schema.split('.')[-1].strip().lower()
                    legacy_db = schema.split('.')[0]

                    try:
                        table_ref = df_ref[df_ref.Table_Name == table_name].to_dict('records')[0]
                    except Exception as e:
                        try:
                            check_name = table_name.replace('ext_','')\
                                .replace('fl_','')\
                                .replace('tl_','')\
                                .replace('_new','')\
                                .replace('_stg','')\
                                .replace('wrk_','')\
                                .replace('_idl','')\
                                .replace('gg_tbf0_','')\
                                .replace('etl_tbf0_','')\
                                .replace('temp_','')\
                                .replace('_managed_temp','')\
                                .replace('_managed','')

                            table_ref = df_ref[df_ref.Table_Name == check_name].to_dict('records')[0]
                        except Exception as e2:
                            table_ref = {'Domain': 'tbd','Sub_Domain': 'tbd'}
                            pass
                    table_domain = table_ref.get('Domain','tbd')
                    table_subdomain = table_ref.get('Sub_Domain','tbd')
                    param_domain = domain_param_switch.get(table_domain, 'tbd')
                    param_subdomain = subdomain_param_switch.get(table_subdomain, 'tbd')
                    if 'cooked' in db_name or 'served' in db_name or db_name in ['emp_wlns','cso','scm','acapdb', 'acapcar','customer']:
                        table_zone = 'curated'
                        table_extra_layer = ''
                        container_param = "${CONTAINER_crt_"+table_domain+"}"
                        storage_acct_param = "${STORAGE_ACCT_crt_"+table_domain+"}"
                        table_location = f"'abfss://{container_param}@{storage_acct_param}.dfs.core.windows.net/{param_domain}/{param_subdomain}/{table_name}'"
                        item = item.replace(schema, f'{param_domain}__{param_subdomain}.{table_name}')
                        param_table_name = f'{param_domain}__{param_subdomain}.{table_name}'
                        new_schema = f'{table_domain}__{table_subdomain}'
                    else:
                        table_zone = 'wrangled'
                        table_name = f"{table_name}_stg"
                        if 'work' in db_name: table_extra_layer = 'work'
                        elif 'etl' in db_name: table_extra_layer = 'etl'
                        elif 'scratch' in db_name: table_extra_layer = 'scratch'
                        elif 'idl' in db_name: table_extra_layer = 'idl'
                        elif 'raw' in db_name: table_extra_layer = 'raw'
                        else: table_extra_layer = 'misc'
                        container_param = "${CONTAINER_wrg_"+table_domain+"}"
                        storage_acct_param = "${STORAGE_ACCT_wrg_"+table_domain+"}"
                        table_location = f"'abfss://{container_param}@{storage_acct_param}.dfs.core.windows.net/{param_domain}/{param_subdomain}/staging/{table_name}'"
                        item = item.replace(schema, f'staging__{param_domain}__{param_subdomain}.{table_name}')
                        param_table_name = f'staging__{param_domain}__{param_subdomain}.{table_name}'
                        new_schema = f'staging__{table_domain}__{table_subdomain}'

                    if table_type == 'view':
                        ttype ='V'
                    else:
                        ttype='T'

                    if table_domain != 'tbd':
                        path = f"../../scripts/{table_zone}/{table_domain}/{table_subdomain}"
                        Path(path).mkdir(exist_ok=True)
                        file_name = f"{path}/{ttype}_1.{counter}.1__{new_schema}.{table_name}.sql"
                        path = path + '/downgrade'
                        Path(path).mkdir(exist_ok=True)
                        rm_file_name = f"{path}/{ttype}_1.{counter}.1__{new_schema}.{table_name}.py"
                    else:
                        path = f"../../scripts/{table_zone}/tbd"
                        Path(path).mkdir(exist_ok=True)
                        file_name = f"{path}/{ttype}_1.{counter}.0__{schema}.sql"
                        path = path + '/downgrade'
                        Path(path).mkdir(exist_ok=True)
                        rm_file_name = f"{path}/{ttype}_1.{counter}.0__{schema}.py"

                    with open(file_name, 'w') as f:
                        if f != 'E.sql':
                            item = item.replace('${TABLE_LOCATION}', table_location)
                            f.write('-- Databricks notebook source\n')
                            f.write(item)
                    with open(rm_file_name, 'w') as f:
                        if f != 'E.py' and table_type != 'view':
                            f.write(f"# Databricks notebook source\ndbutils.fs.rm({table_location},recurse=True)")
                            f.write(f"\n# COMMAND ----------\n%sql\nDROP TABLE IF EXISTS {param_table_name}")
                    
                    ddl_item = {
                        'id': f'{ttype}_1.{counter}.1',
                        'script': file_name.split('/')[-1],
                        'path': file_name.replace('../.',''),
                        'table_name': table_name,
                        'param_table_name': param_table_name,
                        'legacy_db': legacy_db,
                        'legacy_schema': schema,
                        'table_type': table_type,
                        'zone': table_zone,
                        'domain': table_domain,
                        'sub_domain': table_subdomain,
                        'wrangled_extra_layer': table_extra_layer,
                        'location': table_location,
                        'domain_param': param_domain,
                        'sub_domain_param': param_subdomain,
                        'loc_storage_acct_param':  storage_acct_param,
                        'loc_container_param': container_param,
                        'deploy_flag': False,
                        'upgrade_id': None,
                        'downgrade_path': rm_file_name.replace('../.',''),
                        'storage_type': 'DELTA',
                        'partitioned_by': partitioned_by,
                        'clustered_by': table_clustered,
                        'sorted_by': table_sorted,
                        'table_buckets': table_buckets,
                        'ancestors': table_ancestors,
                        'descendents': None,
                        'create_date': datetime.today().strftime('%Y-%m-%d'),
                        'created_by': 'brandon.donelan@walgreens.com',
                        'update_date': None,
                        'updated_by': None,
                        'deployment_date': None
                    }

                    if table_domain != 'tbd':
                        ddl_current.append(ddl_item)
                    else:
                        ddl_tbd.append(ddl_item) 

                    counter = counter + 1
                    del table_type
                    del schema

# update views with anything in the "FROM/JOIN" clause.
for i in ddl_json:
    if i['table_type'] == 'view' and i['ancestors'] != []:
        try:
            update_ancestors = []
            with open(i['path'], 'r') as f:
                ddl_text = f.read()
            for a in i['ancestors']:
                param_table_name = df_ddl[df_ddl.legacy_schema == a].param_table_name.iloc[0]
                ddl_text = ddl_text.replace(a, param_table_name)
                update_ancestors.append(param_table_name)
            with open(i['path'], 'w') as f:
                f.write(ddl_text)
        except Exception as e:
            print("[ERROR] ------------------------------->", i['script'], " | ", a)



with open('../../migrations/ddl.json', 'w') as f:
    json.dump(ddl_current, f, indent=2)

with open('../../migrations/ddl_tbd.json', 'w') as f:
    json.dump(ddl_tbd, f, indent=2)

# print('------------------------------------------------')
# print(f'Complete. {len(df_ddl)} Total Files Converted.')
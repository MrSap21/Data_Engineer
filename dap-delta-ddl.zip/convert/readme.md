# Convert Hive DDL


# Getting Started

The VDI has Anaconda installed, and its recommended you use the base environment provided by that. Activate that enviornment by running this script in a bash notebook:

```sh
$ source C:/ProgramData/Anaconda3/Scripts/activate
```

To run the conversion on all scripts in the /hive_ddl/*.txt files, simply run:

```sh
(base)
$ python -m convert.converter
```


# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.codes_stg(
code_value DECIMAL(4,0),
code_type STRING,
code_description STRING,
code_value_char STRING,
code_effective_date STRING,
code_end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/codes_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.deduction_stg(
sed_employee_id DECIMAL(11,0),
process_date STRING,
deduction_code DECIMAL(4,0),
deduction_amount DECIMAL(11,2),
register_type STRING,
batch_id DECIMAL(5,0),
pay_period_end_date STRING,
emp_rec_id DECIMAL(15,0),
wage_type_description STRING,
short_description STRING,
sequence_num DECIMAL(8,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/deduction_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.earnings_stg(
sed_employee_id DECIMAL(11,0),
process_date STRING,
earnings_code DECIMAL(4,0),
earnings_hours DECIMAL(5,2),
earnings_amount DECIMAL(11,2),
location_charged DECIMAL(5,0),
register_type STRING,
batch_id DECIMAL(5,0),
pay_period_end_date STRING,
emp_rec_id DECIMAL(15,0),
charge_corp_code DECIMAL(4,0),
cost_center STRING,
short_description STRING,
sequence_num DECIMAL(8,0),
wage_type_description STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/earnings_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.employee_detail_stg(
payroll_location DECIMAL(5,0),
sed_employee_id DECIMAL(11,0),
process_date STRING,
check_number STRING,
average_hours DECIMAL(5,2),
fed_exempt DECIMAL(2,0),
state_exempt DECIMAL(2,0),
state_code DECIMAL(2,0),
salary DECIMAL(11,2),
hourly_rate DECIMAL(11,6),
direct_deposit_ind STRING,
regular_hours DECIMAL(5,2),
overtime_hours DECIMAL(5,2),
gross_pay DECIMAL(11,2),
net_pay DECIMAL(11,2),
taxable_gross DECIMAL(11,2),
federal_tax DECIMAL(11,2),
state_tax DECIMAL(11,2),
local_tax DECIMAL(11,2),
special_local_tax DECIMAL(11,2),
fica DECIMAL(11,2),
medicare DECIMAL(11,2),
local_code STRING,
resident_local_code DECIMAL(4,0),
resident_state_code DECIMAL(2,0),
resident_local_tax DECIMAL(11,2),
resident_state_tax DECIMAL(11,2),
disability_tax DECIMAL(11,2),
scheduled_hours DECIMAL(5,2),
register_type STRING,
batch_id DECIMAL(5,0),
work_location DECIMAL(5,0),
pay_period_end_date STRING,
reg_rec_id DECIMAL(14,0),
emp_rec_id DECIMAL(15,0),
average_12wk_hrs DECIMAL(5,2),
location_city_number DECIMAL(4,0),
location_district DECIMAL(3,0),
location_store_number DECIMAL(5,0),
location_type_code STRING,
corp_code DECIMAL(4,0),
division_type_code STRING,
position_start_date DECIMAL(4,0),
co_med_tax DECIMAL(11,2),
employer_fica_tax DECIMAL(11,2),
sut_tax DECIMAL(11,2),
fut_tax DECIMAL(11,2),
regular_earnings_ytd DECIMAL(11,2),
federal_tax_wages_ytd DECIMAL(11,2),
st_txbl_wages DECIMAL(11,2),
liability_whwt DECIMAL(11,2),
liability_ficaw DECIMAL(11,2),
liability_medwt DECIMAL(11,2),
liability_futaw DECIMAL(11,2),
accrual_group DECIMAL(5,0),
pay_date STRING,
dir_dep_eff_date STRING,
location_number DECIMAL(5,0),
cost_center STRING,
country_code STRING,
pay_ocrsn STRING,
location_type STRING,
emp_401k_amount DECIMAL(11,2),
pp_401k_eligible_hours DECIMAL(6,2),
sequence_num DECIMAL(8,0),
org_key STRING,
ecp_period_for_payroll STRING,
home_cost_center STRING,
alt_cost_center STRING,
ecp_state_cd STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/employee_detail_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.codes_temp_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/codes_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.codes_temp1_stg(
code_value STRING,
code_type STRING,
code_description STRING,
code_value_char STRING,
code_effective_date STRING,
code_end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/codes_temp1_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_temp_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_temp1_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_temp1_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_temp2_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_temp2_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.location_codes_temp_stg(
location_type_code STRING,
description STRING,
cd_type STRING,
cd_category STRING,
cd_key STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/location_codes_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.pr_deduction_emp_stg(
payroll_location DECIMAL(5,0),
sed_employee_id DECIMAL(11,0),
process_date STRING,
check_number STRING,
average_hours DECIMAL(5,2),
fed_exempt DECIMAL(2,0),
state_exempt DECIMAL(2,0),
state_code DECIMAL(2,0),
salary DECIMAL(11,2),
hourly_rate DECIMAL(11,6),
direct_deposit_ind STRING,
regular_hours DECIMAL(5,2),
overtime_hours DECIMAL(5,2),
gross_pay DECIMAL(11,2),
net_pay DECIMAL(11,2),
taxable_gross DECIMAL(11,2),
federal_tax DECIMAL(11,2),
state_tax DECIMAL(11,2),
local_tax DECIMAL(11,2),
special_local_tax DECIMAL(11,2),
fica DECIMAL(11,2),
medicare DECIMAL(11,2),
local_code STRING,
resident_local_code DECIMAL(4,0),
resident_state_code DECIMAL(2,0),
resident_local_tax DECIMAL(11,2),
resident_state_tax DECIMAL(11,2),
disability_tax DECIMAL(11,2),
scheduled_hours DECIMAL(5,2),
register_type STRING,
batch_id DECIMAL(5,0),
work_location DECIMAL(5,0),
pay_period_end_date STRING,
reg_rec_id DECIMAL(14,0),
emp_rec_id DECIMAL(15,0),
average_12wk_hrs DECIMAL(5,2),
location_city_number DECIMAL(4,0),
location_district DECIMAL(3,0),
location_store_number DECIMAL(5,0),
location_type_code STRING,
corp_code DECIMAL(4,0),
division_type_code STRING,
position_entry_date STRING,
co_med_tax DECIMAL(11,2),
employer_fica_tax DECIMAL(11,2),
sut_tax DECIMAL(11,2),
fut_tax DECIMAL(11,2),
regular_earnings_ytd DECIMAL(11,2),
federal_tax_wages_ytd DECIMAL(11,2),
st_txbl_wages DECIMAL(11,2),
liability_whwt DECIMAL(11,2),
liability_ficaw DECIMAL(11,2),
liability_medwt DECIMAL(11,2),
liability_futaw DECIMAL(11,2),
accrual_group DECIMAL(5,0),
pay_date STRING,
dir_dep_eff_date STRING,
location_number DECIMAL(5,0),
cost_center STRING,
country_code DECIMAL(2,0),
pay_ocrsn STRING,
location_type STRING,
emp_401k_amount DECIMAL(11,2),
pp_401k_eligible_hours DECIMAL(5,2),
sequence_num DECIMAL(8,0),
org_key STRING,
ecp_period_for_payroll STRING,
home_cost_center STRING,
alt_cost_center STRING,
ecp_state_cd STRING,
code DECIMAL(4,0),
amount DECIMAL(11,2),
location_charged STRING,
earnings_hours DECIMAL(5,2),
cost_center_er STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/pr_deduction_emp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.pr_earning_emp_stg(
payroll_location DECIMAL(5,0),
sed_employee_id DECIMAL(11,0),
process_date STRING,
check_number STRING,
average_hours DECIMAL(5,2),
fed_exempt DECIMAL(2,0),
state_exempt DECIMAL(2,0),
state_code DECIMAL(2,0),
salary DECIMAL(11,2),
hourly_rate DECIMAL(11,6),
direct_deposit_ind STRING,
regular_hours DECIMAL(5,2),
overtime_hours DECIMAL(5,2),
gross_pay DECIMAL(11,2),
net_pay DECIMAL(11,2),
taxable_gross DECIMAL(11,2),
federal_tax DECIMAL(11,2),
state_tax DECIMAL(11,2),
local_tax DECIMAL(11,2),
special_local_tax DECIMAL(11,2),
fica DECIMAL(11,2),
medicare DECIMAL(11,2),
local_code STRING,
resident_local_code DECIMAL(4,0),
resident_state_code DECIMAL(2,0),
resident_local_tax DECIMAL(11,2),
resident_state_tax DECIMAL(11,2),
disability_tax DECIMAL(11,2),
scheduled_hours DECIMAL(5,2),
register_type STRING,
batch_id DECIMAL(5,0),
work_location DECIMAL(5,0),
pay_period_end_date STRING,
reg_rec_id DECIMAL(14,0),
emp_rec_id DECIMAL(15,0),
average_12wk_hrs DECIMAL(5,2),
location_city_number DECIMAL(4,0),
location_district DECIMAL(3,0),
location_store_number DECIMAL(5,0),
location_type_code STRING,
corp_code DECIMAL(4,0),
division_type_code STRING,
position_entry_date STRING,
co_med_tax DECIMAL(11,2),
employer_fica_tax DECIMAL(11,2),
sut_tax DECIMAL(11,2),
fut_tax DECIMAL(11,2),
regular_earnings_ytd DECIMAL(11,2),
federal_tax_wages_ytd DECIMAL(11,2),
st_txbl_wages DECIMAL(11,2),
liability_whwt DECIMAL(11,2),
liability_ficaw DECIMAL(11,2),
liability_medwt DECIMAL(11,2),
liability_futaw DECIMAL(11,2),
accrual_group DECIMAL(5,0),
pay_date STRING,
dir_dep_eff_date STRING,
location_number DECIMAL(5,0),
cost_center STRING,
country_code DECIMAL(2,0),
pay_ocrsn STRING,
location_type STRING,
emp_401k_amount DECIMAL(11,2),
pp_401k_eligible_hours DECIMAL(5,2),
sequence_num DECIMAL(8,0),
org_key STRING,
ecp_period_for_payroll STRING,
home_cost_center STRING,
alt_cost_center STRING,
ecp_state_cd STRING,
code DECIMAL(4,0),
amount DECIMAL(21,2),
location_charged DECIMAL(5,0),
earnings_hours DECIMAL(5,2),
cost_center_er STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/pr_earning_emp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.reg_compaction_audit_stg(
run_date DECIMAL(20,0),
batch_id DECIMAL(5,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/reg_compaction_audit_stg'""")
# COMMAND ----------
migration_data=[{"release": "10.0.6", "scripts": ["T.14670.1.wrg.employee_detail_stg.sql", "T.15208.1.wrg.pr_deduction_emp_stg.sql", "T.15209.1.wrg.pr_earning_emp_stg.sql", "T.14622.1.wrg.deduction_stg.sql", "T.14658.1.wrg.earnings_stg.sql", "T.14866.1.wrg.dim_cd_temp1_stg.sql", "T.14867.1.wrg.dim_cd_temp2_stg.sql", "T.14865.1.wrg.dim_cd_temp_stg.sql", "T.15089.1.wrg.location_codes_temp_stg.sql", "T.14825.1.wrg.codes_temp_stg.sql", "T.14826.1.wrg.codes_temp1_stg.sql", "T.14618.1.wrg.codes_stg.sql", "T.15216.1.wrg.reg_compaction_audit_stg.sql"], "migration_date": "2022-12-19"}]
table_data=[{"release": "10.0.6", "table_id": "T.14670.1", "table_name": "employee_detail_stg", "table_schema": "staging__hr__payroll.employee_detail_stg", "table_legacy_schema": "hr_raw.employee_detail", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.employee_detail_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.15208.1", "table_name": "pr_deduction_emp_stg", "table_schema": "staging__hr__payroll.pr_deduction_emp_stg", "table_legacy_schema": "hr_work.pr_deduction_emp", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.pr_deduction_emp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.15209.1", "table_name": "pr_earning_emp_stg", "table_schema": "staging__hr__payroll.pr_earning_emp_stg", "table_legacy_schema": "hr_work.pr_earning_emp", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.pr_earning_emp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.14622.1", "table_name": "deduction_stg", "table_schema": "staging__hr__payroll.deduction_stg", "table_legacy_schema": "hr_raw.deduction", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.deduction_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.14658.1", "table_name": "earnings_stg", "table_schema": "staging__hr__payroll.earnings_stg", "table_legacy_schema": "hr_raw.earnings", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.earnings_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.14866.1", "table_name": "dim_cd_temp1_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_temp1_stg", "table_legacy_schema": "hr_work.dim_cd_temp1", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_temp1_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.14867.1", "table_name": "dim_cd_temp2_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_temp2_stg", "table_legacy_schema": "hr_work.dim_cd_temp2", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_temp2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.14865.1", "table_name": "dim_cd_temp_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_temp_stg", "table_legacy_schema": "hr_work.dim_cd_temp", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.15089.1", "table_name": "location_codes_temp_stg", "table_schema": "staging__hr__lookup_codes.location_codes_temp_stg", "table_legacy_schema": "hr_work.location_codes_temp", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.location_codes_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.14825.1", "table_name": "codes_temp_stg", "table_schema": "staging__hr__lookup_codes.codes_temp_stg", "table_legacy_schema": "hr_work.codes_temp", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.codes_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.14826.1", "table_name": "codes_temp1_stg", "table_schema": "staging__hr__lookup_codes.codes_temp1_stg", "table_legacy_schema": "hr_work.codes_temp1", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.codes_temp1_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.14618.1", "table_name": "codes_stg", "table_schema": "staging__hr__lookup_codes.codes_stg", "table_legacy_schema": "hr_raw.codes", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.codes_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}, {"release": "10.0.6", "table_id": "T.15216.1", "table_name": "reg_compaction_audit_stg", "table_schema": "staging__hr__payroll.reg_compaction_audit_stg", "table_legacy_schema": "hr_work.reg_compaction_audit", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.reg_compaction_audit_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-12-19 09:32:37", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
# %sql
# MERGE INTO  master_data__information_schema.databricks_table_catalog tables
#     USING temp_catalog new
#     ON tables.table_schema = new.table_schema AND tables.table_name = new.table_name
# WHEN MATCHED THEN
#     UPDATE SET
#         tables.table_schema = new.table_schema,
#         tables.table_database = new.table_database,
#         tables.table_legacy_schema = new.table_legacy_schema
#         tables.table_name = new.table_name,
#         tables.table_domain = new.table_domain,
#         tables.table_subdomain = new.table_subdomain,
#         tables.table_data_class = new.table_data_class,
#         tables.table_location = new.table_location,
#         tables.table_partition = new.table_partition,
#         tables.table_zone = new.table_zone,
#         tables.create_date = tables.create_date
#         tables.update_date = current_timestamp()
# WHEN NOT MATCHED THEN
#     INSERT 
#         new.table_schema,
#         new.table_database,
#         new.table_name,
#         new.table_legacy_schema,
#         new.table_domain,
#         new.table_subdomain,
#         new.table_data_class,
#         new.table_location,
#         new.table_partition,
#         new.table_zone,
#         new.create_date,
#         new.update_date
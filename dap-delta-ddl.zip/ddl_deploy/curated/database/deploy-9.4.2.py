# Databricks notebook source
dbutils.widgets.text(name='hr_crt_sa', defaultValue='${hr_crt_sa}', label='hr_crt_sa')
dbutils.widgets.text(name='property_services_crt_sa', defaultValue='${property_services_crt_sa}', label='property_services_crt_sa')
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__employment_history.address;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__employment_history.address(
update_flag STRING,
person_id STRING,
address_type STRING,
start_date STRING,
address1 STRING,
apartment STRING,
city STRING,
street_number STRING,
address2 STRING,
careof STRING,
municipality STRING,
governorate STRING,
town STRING,
municipality1 STRING,
camp STRING,
camp1 STRING,
building STRING,
district STRING,
country STRING,
county STRING,
created_by STRING,
created_on STRING,
urbanization STRING,
end_date STRING,
last_modified_by STRING,
last_modified_on STRING,
province STRING,
state STRING,
zip_code STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://employment-history-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/address'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__payroll.bank;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.bank(
update_flag STRING,
external_code BIGINT,
bank_country STRING,
bank_name STRING,
business_identifier_code STRING,
city STRING,
created_by STRING,
created_date STRING,
status STRING,
last_modified_by STRING,
last_modified_date STRING,
mdf_system_record_status STRING,
postal_code STRING,
routing_number STRING,
street STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://payroll-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/bank'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__employment_history.biographical;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__employment_history.biographical(
employee_id STRING,
biographical_created_by STRING,
biographical_created_on STRING,
legacy_emp_id STRING,
date_of_birth STRING,
biographical_last_modified_by STRING,
biographical_last_modified_on STRING,
biographical_portlet_name STRING,
biographical_update_flag STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://employment-history-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/biographical'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.cust_lineofbusiness;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.cust_lineofbusiness(
update_flag STRING,
effective_start_date STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_description_default_value STRING,
cust_description_en_us STRING,
cust_description_localized STRING,
cust_effective_status STRING,
cust_head_of_unit STRING,
cust_parent_lob STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_effective_end_date STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/cust_lineofbusiness'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__recruiting.econtacts;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__recruiting.econtacts(
update_flag STRING,
employee_id STRING,
name STRING,
relationship STRING,
created_by STRING,
created_on STRING,
email STRING,
last_modified_by STRING,
last_modified_on STRING,
phone STRING,
primary_flag STRING,
second_phone STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://recruiting-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/econtacts'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__recruiting.email;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__recruiting.email(
update_flag STRING,
employee_id STRING,
email_type STRING,
created_by STRING,
created_on STRING,
email_address STRING,
is_primary STRING,
last_modified_by STRING,
last_modified_on STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://recruiting-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/email'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__employment_history.employmentinfoathire;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__employment_history.employmentinfoathire(
employee_id STRING,
employment_hire_created_by STRING,
employment_hire_created_on STRING,
employment_hire_last_modified_by STRING,
employment_hire_last_modified_on STRING,
original_start_date STRING,
service_date STRING,
employment_hire_start_date STRING,
employment_hire_portlet_name STRING,
employment_hire_update_flag STRING,
requisition_number STRING,
recent_hire_date STRING,
legal_hold_date STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://employment-history-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/employmentinfoathire'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.fobusinessunit;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.fobusinessunit(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_parent_of_business_unit STRING,
cust_to_department_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_defaultvalue STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fobusinessunit'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.focompany;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.focompany(
update_flag STRING,
country STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
end_date STRING,
external_code STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
start_date STRING,
status STRING,
cust_legal_entity_group STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/focompany'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.focostcenter;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.focostcenter(
update_flag STRING,
external_code STRING,
start_date STRING,
external_object_id STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
cust_legal_entity STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/focostcenter'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.fodepartment;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.fodepartment(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_to_division_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
cust_to_division STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fodepartment'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.fodivision;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.fodivision(
update_flag STRING,
start_date STRING,
external_code STRING,
created_by STRING,
created_on STRING,
created_date_time STRING,
line_of_business STRING,
description STRING,
description_defaul_tvalue STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fodivision'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__payroll.foeventreason;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.foeventreason(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
empl_status STRING,
end_date STRING,
event STRING,
implicit_position_action BIGINT,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
payroll_event STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://payroll-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/foeventreason'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__payroll.fofrequency;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.fofrequency(
update_flag STRING,
external_code STRING,
annualization_factor DECIMAL(9,2),
created_by STRING,
created_date_time STRING,
created_on STRING,
frequency_description STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
frequency_name STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://payroll-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fofrequency'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.fogeozone;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.fogeozone(
update_flag STRING,
external_code STRING,
start_date STRING,
adjustment_percentage INT,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fogeozone'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.fojobcode;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.fojobcode(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
default_employee_class STRING,
default_job_level STRING,
description STRING,
description_defaul_tvalue STRING,
description_en_us STRING,
description_localized STRING,
employee_class STRING,
end_date STRING,
job_level STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fojobcode'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.folocation;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.folocation(
update_flag STRING,
location_id STRING,
start_date STRING,
address_line_1 STRING,
address_line_2 STRING,
city STRING,
country STRING,
county STRING,
province STRING,
state STRING,
zip STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
hcc_market STRING,
location_type STRING,
store_type STRING,
operation STRING,
region STRING,
area STRING,
district STRING,
hcc_clinic_no STRING,
location_description STRING,
end_date STRING,
geo_zone_id STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
location_group_flx STRING,
truncated_location_name STRING,
status_ind STRING,
timezone STRING,
location_type_code STRING,
location_type_description STRING,
operation_id STRING,
region_id STRING,
area_id STRING,
district_id STRING,
hcc_market_nbr STRING,
store_type_id STRING,
address_line_3 STRING,
apartment STRING,
town STRING,
building_number STRING,
building STRING,
bed_number STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/folocation'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__compensation_benefits.fopaycomponent;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.fopaycomponent(
update_flag STRING,
external_code STRING,
start_date STRING,
basepay_component_group STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
frequency_code STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
number DECIMAL(9,2),
pay_component_type STRING,
pay_component_value DECIMAL(9,2),
rate DECIMAL(9,2),
previous_pay_rate DECIMAL(9,2),
status STRING,
target STRING,
tax_treatment STRING,
used_for_comp_planning STRING,
can_override STRING,
display_on_self_service STRING,
is_earning STRING,
is_end_dated_payment STRING,
max_fraction_digits STRING,
recurring STRING,
self_service_description STRING,
unit_of_measure STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fopaycomponent'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__compensation_benefits.fopaycomponentgroup;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.fopaycomponentgroup(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_component_flx STRING,
status STRING,
show_on_comp_ui STRING,
sort_order STRING,
use_for_comparatio_calc STRING,
use_for_range_penetration STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fopaycomponentgroup'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__compensation_benefits.fopaygrade;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.fopaygrade(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_grade_level STRING,
previous_pay_grade_level STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fopaygrade'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__compensation_benefits.fopayrange;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.fopayrange(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
frequency_code STRING,
geozone_flx STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
maximum_pay DECIMAL(9,2),
midpoint DECIMAL(9,2),
minimum_pay DECIMAL(9,2),
name STRING,
pay_grade_flx STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fopayrange'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.jobclassificationusa;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.jobclassificationusa(
update_flag STRING,
external_code STRING,
job_classification_country_country STRING,
job_classification_effective_start_date STRING,
job_classification_external_code STRING,
created_by STRING,
created_date_time STRING,
cust_census_code STRING,
cust_standard_code STRING,
eeo1_job_category STRING,
eeo4_job_category STRING,
eeo5_job_category STRING,
eeo6_job_category STRING,
eeo_job_group STRING,
flsa_status_usa STRING,
last_modified_by STRING,
last_modified_date_time STRING,
local_job_title STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/jobclassificationusa'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.jobrelationships;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.jobrelationships(
relationship_type STRING,
job_rel_start_date STRING,
employee_id STRING,
job_rel_user_id STRING,
job_rel_created_by STRING,
job_rel_created_on STRING,
job_rel_end_date STRING,
job_rel_last_modified_by STRING,
job_rel_last_modified_on STRING,
rel_user_id STRING,
job_rel_portlet_name STRING,
job_rel_update_flag STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/jobrelationships'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__terms_of_employment.madetails;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__terms_of_employment.madetails(
update_flag STRING,
person_id_external_external_code STRING,
effective_start_date STRING,
cust_racycle STRING,
cust_tsa_flag STRING,
cust_acq_comp_rate STRING,
cust_acq_company STRING,
cust_acq_date STRING,
cust_acq_emp_id STRING,
cust_acq_per_indicator STRING,
cust_ave_hours_day STRING,
cust_ave_hours_week STRING,
cust_deal_name STRING,
cust_emp_con_date STRING,
cust_non_compete_date STRING,
cust_ret_agr_date STRING,
cust_retention_date STRING,
cust_ring_fence_end STRING,
cust_ring_fence_start STRING,
cust_severance_date STRING,
cust_severance_flag STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://employment-terms-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/madetails'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__payroll.paycalendar;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.paycalendar(
update_flag STRING,
pay_group STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://payroll-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/paycalendar'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__compensation_benefits.paycompnonrecurring;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.paycompnonrecurring(
update_flag STRING,
employee_id STRING,
pay_component_code STRING,
pay_date STRING,
alternative_cost_center STRING,
calculated_amount DECIMAL(9,2),
created_by STRING,
created_on STRING,
currency_code STRING,
custom_double_spotbonus DECIMAL(9,2),
last_modified_by STRING,
last_modified_on STRING,
value DECIMAL(9,2),
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/paycompnonrecurring'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__compensation_benefits.paycomprecurring;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.paycomprecurring(
update_flag STRING,
employee_id STRING,
pay_component STRING,
sequence_number STRING,
start_date STRING,
created_by STRING,
created_on STRING,
currency_code STRING,
end_date STRING,
frequency STRING,
last_modified_by STRING,
last_modified_on STRING,
pay_comp_value DECIMAL(9,2),
previous_pay_comp_value DECIMAL(9,2),
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/paycomprecurring'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__payroll.payinfo;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.payinfo(
update_flag STRING,
employee_id STRING,
paymentinformation_effective_start_date STRING,
paymentinformation_worker STRING,
external_code STRING,
account_number STRING,
account_owner STRING,
amount DECIMAL(9,2),
bank STRING,
bank_country STRING,
business_identifier_code STRING,
created_by STRING,
created_date_time STRING,
currency STRING,
iban STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_type STRING,
payment_method STRING,
paymentinformation_percent DECIMAL(9,2),
routing_number STRING,
account_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://payroll-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/payinfo'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__payroll.payperiod;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.payperiod(
update_flag STRING,
pay_calendar_pay_group STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_pay_periods_per_year BIGINT,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_check_issue_date STRING,
pay_period_begin_date STRING,
pay_period_end_date STRING,
off_cycle STRING,
processing_run_id STRING,
run_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://payroll-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/payperiod'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__payroll.payscalegroup;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.payscalegroup(
update_flag STRING,
code STRING,
country STRING,
created_by STRING,
created_date_time STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_scale_area STRING,
pay_scale_group STRING,
pay_scale_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://payroll-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/payscalegroup'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__payroll.payscalelevel;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.payscalelevel(
update_flag STRING,
code STRING,
effective_start_date STRING,
created_by STRING,
created_date_time STRING,
effective_end_date STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
next_pay_scale_level STRING,
pay_scale_level STRING,
pay_scale_group STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://payroll-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/payscalelevel'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__payroll.payscalepaycomponent;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.payscalepaycomponent(
update_flag STRING,
pay_scale_level_code STRING,
pay_scale_level_effective_start_date STRING,
code STRING,
amount DECIMAL(9,2),
created_by STRING,
created_date_time STRING,
currency STRING,
frequency STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
number DECIMAL(9,2),
percentage DECIMAL(9,2),
rate DECIMAL(9,2),
unit STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://payroll-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/payscalepaycomponent'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__recruiting.phone;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__recruiting.phone(
update_flag STRING,
employee_id STRING,
phone_type STRING,
area_code STRING,
country_code STRING,
created_by STRING,
created_on STRING,
extension STRING,
is_primary STRING,
last_modified_by STRING,
last_modified_on STRING,
phone_number STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://recruiting-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/phone'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__lookup_codes.picklistvalue;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__lookup_codes.picklistvalue(
update_flag STRING,
option_id STRING,
min_value STRING,
max_value STRING,
value STRING,
status STRING,
external_code STRING,
parent_option_id STRING,
country_description STRING,
picklist_type STRING,
picklist_label STRING,
batch_id STRING,
create_date TIMESTAMP,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://lookup-codes-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/picklistvalue'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.position;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.position(
update_flag STRING,
code STRING,
start_date STRING,
business_unit STRING,
change_reason STRING,
comment STRING,
company STRING,
cost_center STRING,
created_by STRING,
created_date_time STRING,
cust_comp_code STRING,
previous_cust_comp_code STRING,
cust_flsa STRING,
flsa_status STRING,
cust_line_of_business STRING,
cust_pos_func STRING,
position_function_name STRING,
cust_pos_sub_func STRING,
position_sub_function_name STRING,
cust_aap STRING,
aap_job_group_name STRING,
cust_coc STRING,
cust_coc_desc STRING,
cust_company_group STRING,
cust_eeo1 STRING,
eeo1_code_desc STRING,
cust_employee_type STRING,
cust_pay_scale_area STRING,
cust_pay_scale_group STRING,
cust_pay_scale_level STRING,
cust_pay_scale_type STRING,
cust_payroll_name STRING,
payroll_company_name STRING,
cust_union STRING,
union_name STRING,
previous_union_code STRING,
department STRING,
description STRING,
division STRING,
effective_end_date STRING,
effective_status STRING,
employee_class STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
job_code STRING,
job_level STRING,
job_level_name STRING,
job_title STRING,
last_modified_by STRING,
last_modified_date_time STRING,
legacy_position_id BIGINT,
location STRING,
mdf_system_optimistic_lock_uuid STRING,
mdf_system_record_status STRING,
multiple_incumbent_sallowed STRING,
pay_grade STRING,
payr_ange STRING,
position_controlled STRING,
position_criticality STRING,
position_title STRING,
previous_position_title STRING,
regular_temporary STRING,
standard_hours DECIMAL(9,2),
target_fte DECIMAL(9,2),
position_category STRING,
vacant STRING,
parent_position STRING,
creation_source STRING,
criticality STRING,
cust_alt_cost_center STRING,
cust_bonus_plan_indicator STRING,
cust_bonus_target STRING,
cust_dist_percent STRING,
cust_fixed_variable STRING,
fixed_variable_cost_name STRING,
cust_location_group STRING,
cust_mapping_code STRING,
cust_pay_group STRING,
cust_soc STRING,
cust_soc_desc STRING,
incumbent STRING,
technical_parameters STRING,
cust_payroll_loc STRING,
cust_no_work_days STRING,
cust_standard_hours_per_pay_period STRING,
business_unit_name STRING,
company_group_name STRING,
department_name STRING,
division_name STRING,
sub_department_name STRING,
pay_grade_name STRING,
pay_range_name STRING,
pay_scale_area_name STRING,
pay_scale_group_name STRING,
pay_scale_level_name STRING,
pay_scale_type_name STRING,
pay_group_name STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/position'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__organization_structure.positionmatrixrelationship;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__organization_structure.positionmatrixrelationship(
update_flag STRING,
position_position_code STRING,
position_start_date STRING,
type STRING,
mdf_system_created_by STRING,
mdf_system_created_date STRING,
mdf_system_last_modified_by STRING,
mdf_system_last_modified_date STRING,
mdf_system_record_status STRING,
related_position STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://organization-structure-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/positionmatrixrelationship'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__recruiting.userinfo;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__recruiting.userinfo(
employee_id STRING,
user_id STRING,
user_last_modified_by STRING,
user_created_by STRING,
user_created_on STRING,
user_portlet_name STRING,
user_update_flag STRING,
user_name STRING,
user_last_modified_on STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://recruiting-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/userinfo'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__terms_of_employment.workpermit;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__terms_of_employment.workpermit(
update_flag STRING,
employee_id STRING,
workpermit_country STRING,
doc_type STRING,
doc_title STRING,
doc_num STRING,
issue_date STRING,
issue_place STRING,
issuing_auth STRING,
exp_date STRING,
validated STRING,
attachment_id STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://employment-terms-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/workpermit'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS property_services__property_services.prprty_spotlight_trans_approval;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS property_services__property_services.prprty_spotlight_trans_approval(
transaction_id INT,
transaction_name STRING,
lease_id STRING,
site_uid STRING,
location_number STRING,
location_type STRING,
tenant STRING,
approval_number INT,
description STRING,
address STRING,
broker_name_and_company STRING,
level_number INT,
level_name STRING,
approval_date DATE,
approver_email STRING,
approval_status STRING,
comment STRING,
partition_column STRING)
USING DELTA
LOCATION
'abfss://property-services-bussnstv@{getArgument('property_services_crt_sa')}.dfs.core.windows.net/prprty_spotlight_trans_approval'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS property_services__property_services.prprty_spotlight_trans_approval_hist;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS property_services__property_services.prprty_spotlight_trans_approval_hist(
transaction_id INT,
transaction_name STRING,
lease_id STRING,
site_uid STRING,
location_number STRING,
location_type STRING,
tenant STRING,
approval_number INT,
description STRING,
address STRING,
broker_name_and_company STRING,
level_number INT,
level_name STRING,
approval_date DATE,
approver_email STRING,
approval_status STRING,
comment STRING)
USING DELTA
LOCATION
'abfss://property-services-bussnstv@{getArgument('property_services_crt_sa')}.dfs.core.windows.net/prprty_spotlight_trans_approval_hist'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS property_services__property_services.prprty_tracker_idle_dispo;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS property_services__property_services.prprty_tracker_idle_dispo(
jll_idle_dispo_id INT,
jll_parent_property_id INT,
site_uid STRING,
location_num STRING,
location_type STRING,
quiet_marketing STRING,
last_day_of_rx_business TIMESTAMP,
employee_notification_date TIMESTAMP,
marketing_expiration_date TIMESTAMP,
inquiries_received float,
reason STRING,
offers_received float,
buyout_guidance DECIMAL(19,6),
buyout_guidance_date TIMESTAMP,
updated_by STRING,
updated_date TIMESTAMP,
wag_store_number STRING,
bulk_pursuit STRING,
bulk_pursuit_company STRING,
bulk_pursuit_company_2 STRING,
bulk_pursuit_company_3 STRING,
master_broker_name STRING,
local_broker_name STRING,
local_broker_company STRING,
local_broker_phone STRING,
local_broker_email STRING,
co_broker_name STRING,
co_broker_company STRING,
co_broker_phone STRING,
co_broker_email STRING,
total_est_broker_commission DECIMAL(19,6),
commission_paid_by STRING,
proposed_deal_type STRING,
rec_previously_reviewed_offer STRING,
rec_date TIMESTAMP,
executive_summary STRING,
major_positive_attributes STRING,
general_re_concerns_or_challenges STRING,
challenges_quantified STRING,
highest_buyout_offer_presented DECIMAL(19,6),
buyout_offer_presented_effective_date TIMESTAMP,
date_buyout_offer_presented TIMESTAMP,
ll_release_price DECIMAL(19,6),
ll_release_effective_date TIMESTAMP,
reason_ll_wasnt_interested STRING,
presented_in_connection_with_subtenant_cash_flow STRING,
proposed_termination_payment DECIMAL(19,6),
proposed_effective_date TIMESTAMP,
termination_estimated_broker_commission DECIMAL(19,6),
rx_restriction STRING,
rx_restriction_until TIMESTAMP,
subtenant_full_name STRING,
subtenant_type_of_entity STRING,
subtenant_state_of_incorporation STRING,
subtenant_contact_name STRING,
subtenant_street_address STRING,
subtenant_city_state_zip STRING,
subtenant_phone STRING,
subtenant_email STRING,
subtenant_sqft_required float,
subtenant_providing_guarantee STRING,
subtenant_or_guarantor_previous_year_revenue DECIMAL(19,6),
subtenant_or_guarantor_previous_year_net_income DECIMAL(19,6),
subtenant_or_guarantor_previous_year_total_assets DECIMAL(19,6),
subtenant_or_guarantor_previous_year_total_long_term_debt DECIMAL(19,6),
subtenant_current_balance_sheet_provided STRING,
subtenant_current_income_statement_provided STRING,
subtenant_interest_in_location STRING,
subtenant_description_of_business STRING,
subtenant_years_of_operation float,
subtenant_number_of_operations float,
subtenant_credit_rating STRING,
subtenant_proposed_use STRING,
subtenant_proposed_use_allowed STRING,
offer_security_deposit_months float,
offer_security_deposit_amount DECIMAL(19,6),
subtenant_total_proposed_investment_in_location DECIMAL(19,6),
tia_provided_by_wag DECIMAL(19,6),
reason_wag_is_providing_tia STRING,
termination_right_in_sublease STRING,
recapture_right_in_sublease STRING,
estimated_execution_date TIMESTAMP,
date_of_possession TIMESTAMP,
rent_commencement_date TIMESTAMP,
free_rent_months float,
coterminous_lease_term STRING,
sublease_term_years float,
number_of_options float,
years_per_option float,
subtenant_pays_ret STRING,
ret_included_in_rent_schedule STRING,
subtenant_pays_cam STRING,
cam_included_in_rent_schedule STRING,
contingencies STRING,
proposed_annual_rent_schedule_yr_1 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_2 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_3 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_4 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_5 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_6 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_7 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_8 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_9 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_10 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_11 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_12 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_13 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_14 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_15 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_16 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_17 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_18 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_19 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_20 DECIMAL(19,6),
buyer_company STRING,
buyer_type_of_entity STRING,
buyer_contact_name STRING,
buyer_state_of_incorporation STRING,
buyer_street_address STRING,
buyer_email STRING,
buyer_city STRING,
buyer_state STRING,
buyer_zip STRING,
buyer_phone_number STRING,
buyers_proposed_plans STRING,
sale_price DECIMAL(19,6),
building_price_psf DECIMAL(19,6),
land_price_psf DECIMAL(19,6),
inspection_period float,
inspection_period_extension_1 float,
inspection_period_extension_2 float,
closing_period_days float,
closing_month_estimated TIMESTAMP,
earnest_money DECIMAL(19,6),
additional_deposit DECIMAL(19,6),
any_contingencies STRING,
financing_contingency STRING,
site_plan_approval_contingency STRING,
permit_approval_contingency STRING,
tenant_approval_contingency STRING,
other_contingencies STRING,
transaction_costs DECIMAL(19,6),
property_restrictions_included_in_sale STRING,
pharmacy_restriction_included STRING,
personal_property_included_in_sale STRING,
personal_property_list STRING,
full_name_of_wag_entity STRING,
wag_type_of_entity STRING,
wag_state_of_incorporation STRING,
landlord_type_of_entity STRING,
landlord_state_of_incorporation STRING,
wag_signatory STRING,
title_of_wag_signatory STRING,
wag_re_legal_contact STRING,
wag_facilities_contact STRING,
legal_description_of_property STRING,
street_names_if_on_a_corner STRING,
property_owner STRING,
pylon_or_monument_sign STRING,
restrictive_covenant_on_the_property STRING,
shopping_center_name STRING,
original_overlease_modified STRING,
overlease_net_lease STRING,
wag_pays_percentage_rent STRING,
sublease_requires_landlord_consent STRING,
wag_landlord_recapture_right STRING,
wag_landlord_termination_right STRING,
property_sold_subject_to_leases STRING,
provisions_or_conditions_included_in_sales_agreement STRING,
remaining_obligation DECIMAL(19,6),
sublease_obligation DECIMAL(19,6),
termination_fee DECIMAL(19,6),
sale_net_proceeds DECIMAL(19,6),
gap_to_guidance DECIMAL(19,6),
pl_impact DECIMAL(19,6),
brokerage_fee DECIMAL(19,6),
deal_npv float,
reserves_nbv DECIMAL(19,6),
adjusted_dop TIMESTAMP,
last_comment STRING,
partition_column STRING)
USING DELTA
LOCATION
'abfss://property-services-pii@{getArgument('property_services_crt_sa')}.dfs.core.windows.net/prprty_tracker_idle_dispo'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS property_services__property_services.prprty_tracker_idle_dispo_hist;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS property_services__property_services.prprty_tracker_idle_dispo_hist(
jll_idle_dispo_id INT,
jll_parent_property_id INT,
site_uid STRING,
location_num STRING,
location_type STRING,
quiet_marketing STRING,
last_day_of_rx_business TIMESTAMP,
employee_notification_date TIMESTAMP,
marketing_expiration_date TIMESTAMP,
inquiries_received float,
reason STRING,
offers_received float,
buyout_guidance DECIMAL(19,6),
buyout_guidance_date TIMESTAMP,
updated_by STRING,
updated_date TIMESTAMP,
wag_store_number STRING,
bulk_pursuit STRING,
bulk_pursuit_company STRING,
bulk_pursuit_company_2 STRING,
bulk_pursuit_company_3 STRING,
master_broker_name STRING,
local_broker_name STRING,
local_broker_company STRING,
local_broker_phone STRING,
local_broker_email STRING,
co_broker_name STRING,
co_broker_company STRING,
co_broker_phone STRING,
co_broker_email STRING,
total_est_broker_commission DECIMAL(19,6),
commission_paid_by STRING,
proposed_deal_type STRING,
rec_previously_reviewed_offer STRING,
rec_date TIMESTAMP,
executive_summary STRING,
major_positive_attributes STRING,
general_re_concerns_or_challenges STRING,
challenges_quantified STRING,
highest_buyout_offer_presented DECIMAL(19,6),
buyout_offer_presented_effective_date TIMESTAMP,
date_buyout_offer_presented TIMESTAMP,
ll_release_price DECIMAL(19,6),
ll_release_effective_date TIMESTAMP,
reason_ll_wasnt_interested STRING,
presented_in_connection_with_subtenant_cash_flow STRING,
proposed_termination_payment DECIMAL(19,6),
proposed_effective_date TIMESTAMP,
termination_estimated_broker_commission DECIMAL(19,6),
rx_restriction STRING,
rx_restriction_until TIMESTAMP,
subtenant_full_name STRING,
subtenant_type_of_entity STRING,
subtenant_state_of_incorporation STRING,
subtenant_contact_name STRING,
subtenant_street_address STRING,
subtenant_city_state_zip STRING,
subtenant_phone STRING,
subtenant_email STRING,
subtenant_sqft_required float,
subtenant_providing_guarantee STRING,
subtenant_or_guarantor_previous_year_revenue DECIMAL(19,6),
subtenant_or_guarantor_previous_year_net_income DECIMAL(19,6),
subtenant_or_guarantor_previous_year_total_assets DECIMAL(19,6),
subtenant_or_guarantor_previous_year_total_long_term_debt DECIMAL(19,6),
subtenant_current_balance_sheet_provided STRING,
subtenant_current_income_statement_provided STRING,
subtenant_interest_in_location STRING,
subtenant_description_of_business STRING,
subtenant_years_of_operation float,
subtenant_number_of_operations float,
subtenant_credit_rating STRING,
subtenant_proposed_use STRING,
subtenant_proposed_use_allowed STRING,
offer_security_deposit_months float,
offer_security_deposit_amount DECIMAL(19,6),
subtenant_total_proposed_investment_in_location DECIMAL(19,6),
tia_provided_by_wag DECIMAL(19,6),
reason_wag_is_providing_tia STRING,
termination_right_in_sublease STRING,
recapture_right_in_sublease STRING,
estimated_execution_date TIMESTAMP,
date_of_possession TIMESTAMP,
rent_commencement_date TIMESTAMP,
free_rent_months float,
coterminous_lease_term STRING,
sublease_term_years float,
number_of_options float,
years_per_option float,
subtenant_pays_ret STRING,
ret_included_in_rent_schedule STRING,
subtenant_pays_cam STRING,
cam_included_in_rent_schedule STRING,
contingencies STRING,
proposed_annual_rent_schedule_yr_1 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_2 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_3 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_4 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_5 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_6 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_7 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_8 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_9 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_10 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_11 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_12 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_13 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_14 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_15 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_16 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_17 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_18 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_19 DECIMAL(19,6),
proposed_annual_rent_schedule_yr_20 DECIMAL(19,6),
buyer_company STRING,
buyer_type_of_entity STRING,
buyer_contact_name STRING,
buyer_state_of_incorporation STRING,
buyer_street_address STRING,
buyer_email STRING,
buyer_city STRING,
buyer_state STRING,
buyer_zip STRING,
buyer_phone_number STRING,
buyers_proposed_plans STRING,
sale_price DECIMAL(19,6),
building_price_psf DECIMAL(19,6),
land_price_psf DECIMAL(19,6),
inspection_period float,
inspection_period_extension_1 float,
inspection_period_extension_2 float,
closing_period_days float,
closing_month_estimated TIMESTAMP,
earnest_money DECIMAL(19,6),
additional_deposit DECIMAL(19,6),
any_contingencies STRING,
financing_contingency STRING,
site_plan_approval_contingency STRING,
permit_approval_contingency STRING,
tenant_approval_contingency STRING,
other_contingencies STRING,
transaction_costs DECIMAL(19,6),
property_restrictions_included_in_sale STRING,
pharmacy_restriction_included STRING,
personal_property_included_in_sale STRING,
personal_property_list STRING,
full_name_of_wag_entity STRING,
wag_type_of_entity STRING,
wag_state_of_incorporation STRING,
landlord_type_of_entity STRING,
landlord_state_of_incorporation STRING,
wag_signatory STRING,
title_of_wag_signatory STRING,
wag_re_legal_contact STRING,
wag_facilities_contact STRING,
legal_description_of_property STRING,
street_names_if_on_a_corner STRING,
property_owner STRING,
pylon_or_monument_sign STRING,
restrictive_covenant_on_the_property STRING,
shopping_center_name STRING,
original_overlease_modified STRING,
overlease_net_lease STRING,
wag_pays_percentage_rent STRING,
sublease_requires_landlord_consent STRING,
wag_landlord_recapture_right STRING,
wag_landlord_termination_right STRING,
property_sold_subject_to_leases STRING,
provisions_or_conditions_included_in_sales_agreement STRING,
remaining_obligation DECIMAL(19,6),
sublease_obligation DECIMAL(19,6),
termination_fee DECIMAL(19,6),
sale_net_proceeds DECIMAL(19,6),
gap_to_guidance DECIMAL(19,6),
pl_impact DECIMAL(19,6),
brokerage_fee DECIMAL(19,6),
deal_npv float,
reserves_nbv DECIMAL(19,6),
adjusted_dop TIMESTAMP,
last_comment STRING)
USING DELTA
LOCATION
'abfss://property-services-pii@{getArgument('property_services_crt_sa')}.dfs.core.windows.net/prprty_tracker_idle_dispo_hist'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS property_services__property_services.prprty_tracker_parent;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS property_services__property_services.prprty_tracker_parent(
jll_property_id INT,
site_uid STRING,
location_num STRING,
location_type STRING,
company STRING,
rad_store_number STRING,
address STRING,
city STRING,
state STRING,
zip_code STRING,
total_location_sf float,
location_status STRING,
tracker_store_location_type STRING,
store_type_description STRING,
operation STRING,
corporate_operation STRING,
region STRING,
area float,
district float,
territory_name STRING,
cbsa STRING,
own_or_lease STRING,
lease_type STRING,
existing_subtenant STRING,
drive_through STRING,
store_key_location STRING,
wba_guarantee STRING,
fred_receiving STRING,
updated_by STRING,
updated_date TIMESTAMP,
latitude float,
longitude float,
performance_metric STRING,
performance_trend STRING,
portfolio_landlord STRING,
portfolio_landlord_name STRING,
landlord STRING,
landlord_type STRING,
landlord_contact STRING,
landlord_address STRING,
landlord_address_2 STRING,
landlord_address_3 STRING,
landlord_city STRING,
landlord_state STRING,
landlord_zip_code STRING,
landlord_phone STRING,
landlord_fax STRING,
landlord_email STRING,
landlord_2 STRING,
landlord_2_type STRING,
landlord_2_contact STRING,
landlord_2_address STRING,
landlord_2_address_2 STRING,
landlord_2_address_3 STRING,
landlord_2_city STRING,
landlord_2_state STRING,
landlord_2_zip_code STRING,
landlord_2_phone STRING,
landlord_2_fax STRING,
landlord_2_email STRING,
term_start_date TIMESTAMP,
firm_term_end_date TIMESTAMP,
notice_by_date TIMESTAMP,
notice_date_type STRING,
term_end_date TIMESTAMP,
closure_date TIMESTAMP,
early_termination_right TIMESTAMP,
conversion_date TIMESTAMP,
base_rent DECIMAL(19,6),
base_rent_psf DECIMAL(19,6),
total_occupancy DECIMAL(19,6),
options_available STRING,
next_option_base_rent DECIMAL(19,6),
ret DECIMAL(19,6),
cam DECIMAL(19,6),
ins DECIMAL(19,6),
percentage_rent_paid DECIMAL(19,6),
percentage_rent_rate float,
current_subtenant_active STRING,
current_subtenant_name STRING,
current_subtenant_contact STRING,
current_subtenant_term_expiration TIMESTAMP,
current_subtenant_rent_payment_terms STRING,
current_subtenant_sublease_category STRING,
current_subtenant_use STRING,
current_subtenant_gla_sqft float,
current_subtenant_base_rent DECIMAL(19,6),
current_subtenant_responsible_for_cam STRING,
current_subtenant_responsible_for_re_tax STRING,
service_provider_lease_restructures STRING,
service_provider_dispositions STRING,
current_assignment STRING,
master_broker_group STRING,
master_broker_name STRING,
re_director STRING,
repm STRING,
re_lead STRING,
mpr_geo_director STRING,
finance_director STRING,
last_comment STRING,
partition_column STRING)
USING DELTA
LOCATION
'abfss://property-services-bussnstv@{getArgument('property_services_crt_sa')}.dfs.core.windows.net/prprty_tracker_parent'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS property_services__property_services.prprty_tracker_parent_hist;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS property_services__property_services.prprty_tracker_parent_hist(
jll_property_id INT,
site_uid STRING,
location_num STRING,
location_type STRING,
company STRING,
rad_store_number STRING,
address STRING,
city STRING,
state STRING,
zip_code STRING,
total_location_sf float,
location_status STRING,
tracker_store_location_type STRING,
store_type_description STRING,
operation STRING,
corporate_operation STRING,
region STRING,
area float,
district float,
territory_name STRING,
cbsa STRING,
own_or_lease STRING,
lease_type STRING,
existing_subtenant STRING,
drive_through STRING,
store_key_location STRING,
wba_guarantee STRING,
fred_receiving STRING,
updated_by STRING,
updated_date TIMESTAMP,
latitude float,
longitude float,
performance_metric STRING,
performance_trend STRING,
portfolio_landlord STRING,
portfolio_landlord_name STRING,
landlord STRING,
landlord_type STRING,
landlord_contact STRING,
landlord_address STRING,
landlord_address_2 STRING,
landlord_address_3 STRING,
landlord_city STRING,
landlord_state STRING,
landlord_zip_code STRING,
landlord_phone STRING,
landlord_fax STRING,
landlord_email STRING,
landlord_2 STRING,
landlord_2_type STRING,
landlord_2_contact STRING,
landlord_2_address STRING,
landlord_2_address_2 STRING,
landlord_2_address_3 STRING,
landlord_2_city STRING,
landlord_2_state STRING,
landlord_2_zip_code STRING,
landlord_2_phone STRING,
landlord_2_fax STRING,
landlord_2_email STRING,
term_start_date TIMESTAMP,
firm_term_end_date TIMESTAMP,
notice_by_date TIMESTAMP,
notice_date_type STRING,
term_end_date TIMESTAMP,
closure_date TIMESTAMP,
early_termination_right TIMESTAMP,
conversion_date TIMESTAMP,
base_rent DECIMAL(19,6),
base_rent_psf DECIMAL(19,6),
total_occupancy DECIMAL(19,6),
options_available STRING,
next_option_base_rent DECIMAL(19,6),
ret DECIMAL(19,6),
cam DECIMAL(19,6),
ins DECIMAL(19,6),
percentage_rent_paid DECIMAL(19,6),
percentage_rent_rate float,
current_subtenant_active STRING,
current_subtenant_name STRING,
current_subtenant_contact STRING,
current_subtenant_term_expiration TIMESTAMP,
current_subtenant_rent_payment_terms STRING,
current_subtenant_sublease_category STRING,
current_subtenant_use STRING,
current_subtenant_gla_sqft float,
current_subtenant_base_rent DECIMAL(19,6),
current_subtenant_responsible_for_cam STRING,
current_subtenant_responsible_for_re_tax STRING,
service_provider_lease_restructures STRING,
service_provider_dispositions STRING,
current_assignment STRING,
master_broker_group STRING,
master_broker_name STRING,
re_director STRING,
repm STRING,
re_lead STRING,
mpr_geo_director STRING,
finance_director STRING,
last_comment STRING)
USING DELTA
LOCATION
'abfss://property-services-bussnstv@{getArgument('property_services_crt_sa')}.dfs.core.windows.net/prprty_tracker_parent_hist'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS property_services__property_services.prprty_tracker_portfolio;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS property_services__property_services.prprty_tracker_portfolio(
jll_portfolio_mgmt_id INT,
jll_parent_property_id INT,
site_uid STRING,
location_num STRING,
location_type STRING,
strategy STRING,
value_creation_strategy STRING,
current_option_notice_date TIMESTAMP,
current_firm_term_end_date TIMESTAMP,
strategy_details STRING,
master_broker_name STRING,
reason STRING,
termination_notice_submitted STRING,
possible_relocation_in_progress STRING,
deal_complete STRING,
updated_by STRING,
updated_date TIMESTAMP,
mra_date TIMESTAMP,
mra_high_psf_rent DECIMAL(19,6),
mra_low_psf_rent DECIMAL(19,6),
mra_comments STRING,
executive_summary STRING,
proposed_term_months float,
proposed_term_start_date TIMESTAMP,
proposed_term_end_date TIMESTAMP,
existing_lease_obligation DECIMAL(19,6),
negotiated_lease_obligation DECIMAL(19,6),
proposed_base_rent DECIMAL(19,6),
base_rent_escalations STRING,
proposed_term_savings DECIMAL(19,6),
irr float,
npv DECIMAL(19,6),
options_added float,
tia DECIMAL(19,6),
capital_contribution_date TIMESTAMP,
vendor_fee DECIMAL(19,6),
anticipated_rec_date TIMESTAMP,
proposed_rent_for_entire_lease_or_firm_term STRING,
curr_fy_gapp_benefit DECIMAL(19,6),
next_fy_gaap_benefit DECIMAL(19,6),
relocation_master_broker STRING,
relocation_start_date TIMESTAMP,
relocation_new_base_rent DECIMAL(19,6),
relocation_new_store_number STRING,
relocation_fixed_term_months float,
relocation_sf float,
relocation_commission DECIMAL(19,6),
relocation_lease_end_date TIMESTAMP,
last_comment STRING,
partition_column STRING)
USING DELTA
LOCATION
'abfss://property-services-bussnstv@{getArgument('property_services_crt_sa')}.dfs.core.windows.net/prprty_tracker_portfolio'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS property_services__property_services.prprty_tracker_portfolio_hist;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS property_services__property_services.prprty_tracker_portfolio_hist(
jll_portfolio_mgmt_id INT,
jll_parent_property_id INT,
site_uid STRING,
location_num STRING,
location_type STRING,
strategy STRING,
value_creation_strategy STRING,
current_option_notice_date TIMESTAMP,
current_firm_term_end_date TIMESTAMP,
strategy_details STRING,
master_broker_name STRING,
reason STRING,
termination_notice_submitted STRING,
possible_relocation_in_progress STRING,
deal_complete STRING,
updated_by STRING,
updated_date TIMESTAMP,
mra_date TIMESTAMP,
mra_high_psf_rent DECIMAL(19,6),
mra_low_psf_rent DECIMAL(19,6),
mra_comments STRING,
executive_summary STRING,
proposed_term_months float,
proposed_term_start_date TIMESTAMP,
proposed_term_end_date TIMESTAMP,
existing_lease_obligation DECIMAL(19,6),
negotiated_lease_obligation DECIMAL(19,6),
proposed_base_rent DECIMAL(19,6),
base_rent_escalations STRING,
proposed_term_savings DECIMAL(19,6),
irr float,
npv DECIMAL(19,6),
options_added float,
tia DECIMAL(19,6),
capital_contribution_date TIMESTAMP,
vendor_fee DECIMAL(19,6),
anticipated_rec_date TIMESTAMP,
proposed_rent_for_entire_lease_or_firm_term STRING,
curr_fy_gapp_benefit DECIMAL(19,6),
next_fy_gaap_benefit DECIMAL(19,6),
relocation_master_broker STRING,
relocation_start_date TIMESTAMP,
relocation_new_base_rent DECIMAL(19,6),
relocation_new_store_number STRING,
relocation_fixed_term_months float,
relocation_sf float,
relocation_commission DECIMAL(19,6),
relocation_lease_end_date TIMESTAMP,
last_comment STRING)
USING DELTA
LOCATION
'abfss://property-services-bussnstv@{getArgument('property_services_crt_sa')}.dfs.core.windows.net/prprty_tracker_portfolio_hist'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
migration_data=[{"release": "9.4.2", "scripts": ["T.14437.0.crt.address.sql", "T.14437.1.crt.address.sql", "T.14439.0.crt.bank.sql", "T.14439.1.crt.bank.sql", "T.14440.0.crt.biographical.sql", "T.14440.1.crt.biographical.sql", "T.14445.0.crt.cust_lineofbusiness.sql", "T.14445.1.crt.cust_lineofbusiness.sql", "T.14452.0.crt.econtacts.sql", "T.14452.1.crt.econtacts.sql", "T.14453.0.crt.email.sql", "T.14453.1.crt.email.sql", "T.14457.0.crt.employmentinfoathire.sql", "T.14457.1.crt.employmentinfoathire.sql", "T.14469.0.crt.fobusinessunit.sql", "T.14469.1.crt.fobusinessunit.sql", "T.14470.0.crt.focompany.sql", "T.14470.1.crt.focompany.sql", "T.14471.0.crt.focostcenter.sql", "T.14471.1.crt.focostcenter.sql", "T.14472.0.crt.fodepartment.sql", "T.14472.1.crt.fodepartment.sql", "T.14473.0.crt.fodivision.sql", "T.14473.1.crt.fodivision.sql", "T.14474.0.crt.foeventreason.sql", "T.14474.1.crt.foeventreason.sql", "T.14475.0.crt.fofrequency.sql", "T.14475.1.crt.fofrequency.sql", "T.14476.0.crt.fogeozone.sql", "T.14476.1.crt.fogeozone.sql", "T.14477.0.crt.fojobcode.sql", "T.14477.1.crt.fojobcode.sql", "T.14479.0.crt.folocation.sql", "T.14479.1.crt.folocation.sql", "T.14481.0.crt.fopaycomponent.sql", "T.14481.1.crt.fopaycomponent.sql", "T.14482.0.crt.fopaycomponentgroup.sql", "T.14482.1.crt.fopaycomponentgroup.sql", "T.14483.0.crt.fopaygrade.sql", "T.14483.1.crt.fopaygrade.sql", "T.14485.0.crt.fopayrange.sql", "T.14485.1.crt.fopayrange.sql", "T.14489.0.crt.jobclassificationusa.sql", "T.14489.1.crt.jobclassificationusa.sql", "T.14491.0.crt.jobrelationships.sql", "T.14491.1.crt.jobrelationships.sql", "T.14512.0.crt.madetails.sql", "T.14512.1.crt.madetails.sql", "T.14536.0.crt.paycalendar.sql", "T.14536.1.crt.paycalendar.sql", "T.14537.0.crt.paycompnonrecurring.sql", "T.14537.1.crt.paycompnonrecurring.sql", "T.14538.0.crt.paycomprecurring.sql", "T.14538.1.crt.paycomprecurring.sql", "T.14539.0.crt.payinfo.sql", "T.14539.1.crt.payinfo.sql", "T.14540.0.crt.payperiod.sql", "T.14540.1.crt.payperiod.sql", "T.14542.0.crt.payscalegroup.sql", "T.14542.1.crt.payscalegroup.sql", "T.14543.0.crt.payscalelevel.sql", "T.14543.1.crt.payscalelevel.sql", "T.14544.0.crt.payscalepaycomponent.sql", "T.14544.1.crt.payscalepaycomponent.sql", "T.14549.0.crt.phone.sql", "T.14549.1.crt.phone.sql", "T.14550.0.crt.picklistvalue.sql", "T.14550.1.crt.picklistvalue.sql", "T.14552.0.crt.position.sql", "T.14552.1.crt.position.sql", "T.14553.0.crt.positionmatrixrelationship.sql", "T.14553.1.crt.positionmatrixrelationship.sql", "T.14555.0.crt.userinfo.sql", "T.14555.1.crt.userinfo.sql", "T.14558.0.crt.workpermit.sql", "T.14558.1.crt.workpermit.sql", "T.19215.0.crt.prprty_spotlight_trans_approval.sql", "T.19215.1.crt.prprty_spotlight_trans_approval.sql", "T.19216.0.crt.prprty_spotlight_trans_approval_hist.sql", "T.19216.1.crt.prprty_spotlight_trans_approval_hist.sql", "T.19226.0.crt.prprty_tracker_idle_dispo.sql", "T.19226.1.crt.prprty_tracker_idle_dispo.sql", "T.19227.0.crt.prprty_tracker_idle_dispo_hist.sql", "T.19227.1.crt.prprty_tracker_idle_dispo_hist.sql", "T.19228.0.crt.prprty_tracker_parent.sql", "T.19228.1.crt.prprty_tracker_parent.sql", "T.19229.0.crt.prprty_tracker_parent_hist.sql", "T.19229.1.crt.prprty_tracker_parent_hist.sql", "T.19230.0.crt.prprty_tracker_portfolio.sql", "T.19230.1.crt.prprty_tracker_portfolio.sql", "T.19231.0.crt.prprty_tracker_portfolio_hist.sql", "T.19231.1.crt.prprty_tracker_portfolio_hist.sql"], "migration_date": "2022-09-29"}]
table_data=[{"release": "9.4.2", "table_id": "T.14437.1", "table_name": "address", "table_schema": "hr__employment_history.address", "table_legacy_schema": "hr_cooked.address", "table_domain": "hr", "table_subdomain": "employment_history", "table_location": "hr__employment_history.address", "table_partition": "", "table_db": "hr__employment_history", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14439.1", "table_name": "bank", "table_schema": "hr__payroll.bank", "table_legacy_schema": "hr_cooked.bank", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.bank", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14440.1", "table_name": "biographical", "table_schema": "hr__employment_history.biographical", "table_legacy_schema": "hr_cooked.biographical", "table_domain": "hr", "table_subdomain": "employment_history", "table_location": "hr__employment_history.biographical", "table_partition": "", "table_db": "hr__employment_history", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14445.1", "table_name": "cust_lineofbusiness", "table_schema": "hr__organization_structure.cust_lineofbusiness", "table_legacy_schema": "hr_cooked.cust_lineofbusiness", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.cust_lineofbusiness", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14452.1", "table_name": "econtacts", "table_schema": "hr__recruiting.econtacts", "table_legacy_schema": "hr_cooked.econtacts", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "hr__recruiting.econtacts", "table_partition": "", "table_db": "hr__recruiting", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14453.1", "table_name": "email", "table_schema": "hr__recruiting.email", "table_legacy_schema": "hr_cooked.email", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "hr__recruiting.email", "table_partition": "", "table_db": "hr__recruiting", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14457.1", "table_name": "employmentinfoathire", "table_schema": "hr__employment_history.employmentinfoathire", "table_legacy_schema": "hr_cooked.employmentinfoathire", "table_domain": "hr", "table_subdomain": "employment_history", "table_location": "hr__employment_history.employmentinfoathire", "table_partition": "", "table_db": "hr__employment_history", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14469.1", "table_name": "fobusinessunit", "table_schema": "hr__organization_structure.fobusinessunit", "table_legacy_schema": "hr_cooked.fobusinessunit", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.fobusinessunit", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14470.1", "table_name": "focompany", "table_schema": "hr__organization_structure.focompany", "table_legacy_schema": "hr_cooked.focompany", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.focompany", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14471.1", "table_name": "focostcenter", "table_schema": "hr__organization_structure.focostcenter", "table_legacy_schema": "hr_cooked.focostcenter", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.focostcenter", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14472.1", "table_name": "fodepartment", "table_schema": "hr__organization_structure.fodepartment", "table_legacy_schema": "hr_cooked.fodepartment", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.fodepartment", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14473.1", "table_name": "fodivision", "table_schema": "hr__organization_structure.fodivision", "table_legacy_schema": "hr_cooked.fodivision", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.fodivision", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14474.1", "table_name": "foeventreason", "table_schema": "hr__payroll.foeventreason", "table_legacy_schema": "hr_cooked.foeventreason", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.foeventreason", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14475.1", "table_name": "fofrequency", "table_schema": "hr__payroll.fofrequency", "table_legacy_schema": "hr_cooked.fofrequency", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.fofrequency", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14476.1", "table_name": "fogeozone", "table_schema": "hr__organization_structure.fogeozone", "table_legacy_schema": "hr_cooked.fogeozone", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.fogeozone", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14477.1", "table_name": "fojobcode", "table_schema": "hr__organization_structure.fojobcode", "table_legacy_schema": "hr_cooked.fojobcode", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.fojobcode", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14479.1", "table_name": "folocation", "table_schema": "hr__organization_structure.folocation", "table_legacy_schema": "hr_cooked.folocation", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.folocation", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14481.1", "table_name": "fopaycomponent", "table_schema": "hr__compensation_benefits.fopaycomponent", "table_legacy_schema": "hr_cooked.fopaycomponent", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.fopaycomponent", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14482.1", "table_name": "fopaycomponentgroup", "table_schema": "hr__compensation_benefits.fopaycomponentgroup", "table_legacy_schema": "hr_cooked.fopaycomponentgroup", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.fopaycomponentgroup", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14483.1", "table_name": "fopaygrade", "table_schema": "hr__compensation_benefits.fopaygrade", "table_legacy_schema": "hr_cooked.fopaygrade", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.fopaygrade", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14485.1", "table_name": "fopayrange", "table_schema": "hr__compensation_benefits.fopayrange", "table_legacy_schema": "hr_cooked.fopayrange", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.fopayrange", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14489.1", "table_name": "jobclassificationusa", "table_schema": "hr__organization_structure.jobclassificationusa", "table_legacy_schema": "hr_cooked.jobclassificationusa", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.jobclassificationusa", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14491.1", "table_name": "jobrelationships", "table_schema": "hr__organization_structure.jobrelationships", "table_legacy_schema": "hr_cooked.jobrelationships", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.jobrelationships", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14512.1", "table_name": "madetails", "table_schema": "hr__terms_of_employment.madetails", "table_legacy_schema": "hr_cooked.madetails", "table_domain": "hr", "table_subdomain": "terms_of_employment", "table_location": "hr__terms_of_employment.madetails", "table_partition": "", "table_db": "hr__terms_of_employment", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14536.1", "table_name": "paycalendar", "table_schema": "hr__payroll.paycalendar", "table_legacy_schema": "hr_cooked.paycalendar", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.paycalendar", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14537.1", "table_name": "paycompnonrecurring", "table_schema": "hr__compensation_benefits.paycompnonrecurring", "table_legacy_schema": "hr_cooked.paycompnonrecurring", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.paycompnonrecurring", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14538.1", "table_name": "paycomprecurring", "table_schema": "hr__compensation_benefits.paycomprecurring", "table_legacy_schema": "hr_cooked.paycomprecurring", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.paycomprecurring", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14539.1", "table_name": "payinfo", "table_schema": "hr__payroll.payinfo", "table_legacy_schema": "hr_cooked.payinfo", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.payinfo", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14540.1", "table_name": "payperiod", "table_schema": "hr__payroll.payperiod", "table_legacy_schema": "hr_cooked.payperiod", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.payperiod", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14542.1", "table_name": "payscalegroup", "table_schema": "hr__payroll.payscalegroup", "table_legacy_schema": "hr_cooked.payscalegroup", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.payscalegroup", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14543.1", "table_name": "payscalelevel", "table_schema": "hr__payroll.payscalelevel", "table_legacy_schema": "hr_cooked.payscalelevel", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.payscalelevel", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14544.1", "table_name": "payscalepaycomponent", "table_schema": "hr__payroll.payscalepaycomponent", "table_legacy_schema": "hr_cooked.payscalepaycomponent", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.payscalepaycomponent", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14549.1", "table_name": "phone", "table_schema": "hr__recruiting.phone", "table_legacy_schema": "hr_cooked.phone", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "hr__recruiting.phone", "table_partition": "", "table_db": "hr__recruiting", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14550.1", "table_name": "picklistvalue", "table_schema": "hr__lookup_codes.picklistvalue", "table_legacy_schema": "hr_cooked.picklistvalue", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "hr__lookup_codes.picklistvalue", "table_partition": "", "table_db": "hr__lookup_codes", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14552.1", "table_name": "position", "table_schema": "hr__organization_structure.position", "table_legacy_schema": "hr_cooked.position", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.position", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14553.1", "table_name": "positionmatrixrelationship", "table_schema": "hr__organization_structure.positionmatrixrelationship", "table_legacy_schema": "hr_cooked.positionmatrixrelationship", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "hr__organization_structure.positionmatrixrelationship", "table_partition": "", "table_db": "hr__organization_structure", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14555.1", "table_name": "userinfo", "table_schema": "hr__recruiting.userinfo", "table_legacy_schema": "hr_cooked.userinfo", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "hr__recruiting.userinfo", "table_partition": "", "table_db": "hr__recruiting", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.14558.1", "table_name": "workpermit", "table_schema": "hr__terms_of_employment.workpermit", "table_legacy_schema": "hr_cooked.workpermit", "table_domain": "hr", "table_subdomain": "terms_of_employment", "table_location": "hr__terms_of_employment.workpermit", "table_partition": "", "table_db": "hr__terms_of_employment", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.19215.1", "table_name": "prprty_spotlight_trans_approval", "table_schema": "property_services__property_services.prprty_spotlight_trans_approval", "table_legacy_schema": "wag_gen_cooked.prprty_spotlight_trans_approval", "table_domain": "property_services", "table_subdomain": "property_services", "table_location": "property_services__property_services.prprty_spotlight_trans_approval", "table_partition": "", "table_db": "property_services__property_services", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.19216.1", "table_name": "prprty_spotlight_trans_approval_hist", "table_schema": "property_services__property_services.prprty_spotlight_trans_approval_hist", "table_legacy_schema": "wag_gen_cooked.prprty_spotlight_trans_approval_hist", "table_domain": "property_services", "table_subdomain": "property_services", "table_location": "property_services__property_services.prprty_spotlight_trans_approval_hist", "table_partition": "\n  partition_column STRING", "table_db": "property_services__property_services", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.19226.1", "table_name": "prprty_tracker_idle_dispo", "table_schema": "property_services__property_services.prprty_tracker_idle_dispo", "table_legacy_schema": "wag_gen_cooked.prprty_tracker_idle_dispo", "table_domain": "property_services", "table_subdomain": "property_services", "table_location": "property_services__property_services.prprty_tracker_idle_dispo", "table_partition": "", "table_db": "property_services__property_services", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.19227.1", "table_name": "prprty_tracker_idle_dispo_hist", "table_schema": "property_services__property_services.prprty_tracker_idle_dispo_hist", "table_legacy_schema": "wag_gen_cooked.prprty_tracker_idle_dispo_hist", "table_domain": "property_services", "table_subdomain": "property_services", "table_location": "property_services__property_services.prprty_tracker_idle_dispo_hist", "table_partition": "\n  partition_column STRING", "table_db": "property_services__property_services", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.19228.1", "table_name": "prprty_tracker_parent", "table_schema": "property_services__property_services.prprty_tracker_parent", "table_legacy_schema": "wag_gen_cooked.prprty_tracker_parent", "table_domain": "property_services", "table_subdomain": "property_services", "table_location": "property_services__property_services.prprty_tracker_parent", "table_partition": "", "table_db": "property_services__property_services", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.19229.1", "table_name": "prprty_tracker_parent_hist", "table_schema": "property_services__property_services.prprty_tracker_parent_hist", "table_legacy_schema": "wag_gen_cooked.prprty_tracker_parent_hist", "table_domain": "property_services", "table_subdomain": "property_services", "table_location": "property_services__property_services.prprty_tracker_parent_hist", "table_partition": "\n  partition_column STRING", "table_db": "property_services__property_services", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.19230.1", "table_name": "prprty_tracker_portfolio", "table_schema": "property_services__property_services.prprty_tracker_portfolio", "table_legacy_schema": "wag_gen_cooked.prprty_tracker_portfolio", "table_domain": "property_services", "table_subdomain": "property_services", "table_location": "property_services__property_services.prprty_tracker_portfolio", "table_partition": "", "table_db": "property_services__property_services", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}, {"release": "9.4.2", "table_id": "T.19231.1", "table_name": "prprty_tracker_portfolio_hist", "table_schema": "property_services__property_services.prprty_tracker_portfolio_hist", "table_legacy_schema": "wag_gen_cooked.prprty_tracker_portfolio_hist", "table_domain": "property_services", "table_subdomain": "property_services", "table_location": "property_services__property_services.prprty_tracker_portfolio_hist", "table_partition": "\n  partition_column STRING", "table_db": "property_services__property_services", "table_zone": "curated", "create_date": "2022-09-29 20:16:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.','address','bank','biographical','cust_lineofbusiness','econtacts','email','employmentinfoathire','fobusinessunit','focompany','focostcenter','fodepartment','fodivision','foeventreason','fofrequency','fogeozone','fojobcode','folocation','fopaycomponent','fopaycomponentgroup','fopaygrade','fopayrange','jobclassificationusa','jobrelationships','madetails','paycalendar','paycompnonrecurring','paycomprecurring','payinfo','payperiod','payscalegroup','payscalelevel','payscalepaycomponent','phone','picklistvalue','position','positionmatrixrelationship','userinfo','workpermit','prprty_spotlight_trans_approval','prprty_spotlight_trans_approval_hist','prprty_tracker_idle_dispo','prprty_tracker_idle_dispo_hist','prprty_tracker_parent','prprty_tracker_parent_hist','prprty_tracker_portfolio','prprty_tracker_portfolio_hist');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
# %sql
# MERGE INTO  master_data__information_schema.databricks_table_catalog tables
#     USING temp_catalog new
#     ON tables.table_schema = new.table_schema AND tables.table_name = new.table_name
# WHEN MATCHED THEN
#     UPDATE SET
#         tables.table_schema = new.table_schema,
#         tables.table_database = new.table_database,
#         tables.table_legacy_schema = new.table_legacy_schema
#         tables.table_name = new.table_name,
#         tables.table_domain = new.table_domain,
#         tables.table_subdomain = new.table_subdomain,
#         tables.table_data_class = new.table_data_class,
#         tables.table_location = new.table_location,
#         tables.table_partition = new.table_partition,
#         tables.table_zone = new.table_zone,
#         tables.create_date = tables.create_date
#         tables.update_date = current_timestamp()
# WHEN NOT MATCHED THEN
#     INSERT 
#         new.table_schema,
#         new.table_database,
#         new.table_name,
#         new.table_legacy_schema,
#         new.table_domain,
#         new.table_subdomain,
#         new.table_data_class,
#         new.table_location,
#         new.table_partition,
#         new.table_zone,
#         new.create_date,
#         new.update_date
# Databricks notebook source
dbutils.widgets.text(name='retail_crt_sa', defaultValue='${retail_crt_sa}', label='retail_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__ccpa.ccpa_rtd_log(
tkt_nbr STRING,
tkt_open_dt DATE,
reqst_type_cd STRING,
tkt_line_seq INT,
db_name STRING,
tbl_name STRING,
subject_area STRING,
del_rec_cnt INT,
rec_del_dt DATE,
stat_cd STRING,
idh_update_dttm STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://ccpa-pii@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_rtd_log'
PARTITIONED BY (
idh_create_dttm STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.icplus_status_update_har(
str_nbr INT,
bin_nbr STRING,
prcs_ctrl_nbr STRING,
store_npi_nbr STRING,
general_recipient_nbr STRING,
fill_enter_dt STRING,
rx_nbr INT,
rx_fill_nbr INT,
drug_id INT,
dspn_ndc STRING,
other_payr_coverage_cd DECIMAL(2,0),
plan_group_nbr STRING,
plan_tot_paid_dlrs DECIMAL(8,2),
plan_return_cost_dlrs DECIMAL(8,2),
plan_return_fee_dlrs DECIMAL(8,2),
plan_return_copay_dlrs DECIMAL(8,2),
plan_return_tax_dlrs DECIMAL(8,2),
plan_ar_dlrs DECIMAL(8,2),
plan_submit_fee_dlrs DECIMAL(8,2),
basis_of_reimb_detrm STRING,
fill_label_price_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
third_party_plan_id STRING,
claim_ref_nbr STRING,
del_adjud_cd STRING,
rx_create_dt STRING,
fill_sold_dt STRING,
fill_del_dt STRING,
pat_id DECIMAL(13,0),
plan_type STRING,
contract_name STRING,
plan_name STRING,
dspn_fill_nbr SMALLINT,
partial_fill_cd STRING,
fill_pay_method_cd STRING,
fill_days_supply SMALLINT,
fill_qty_dspn DECIMAL(8,3),
cob_ind STRING,
rx_partial_fill_nbr INT,
fill_enter_tm STRING,
update_dttm STRING,
edw_batch_id STRING)
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/icplus_status_update_har'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_promo(
sales_txn_id STRING,
txn_business_dt_promo DATE,
store_nbr_promo INT,
loc_store_sk INT,
register_nbr_promo INT,
txn_nbr_promo INT,
txn_ly_card_promo STRING,
sales_txn_type STRING,
src_sys_cd STRING)
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo'
PARTITIONED BY (
sales_txn_dt DATE)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_promo_dtl(
sales_txn_id STRING,
line_seq_nbr_promo DECIMAL(38,0),
promo_seq_nbr INT,
promo_type STRING,
promo_adj_dlrs DECIMAL(8,2),
promo_plu DECIMAL(14,0),
promo_entry_mode STRING,
sales_txn_type STRING,
src_sys_cd STRING)
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo_dtl'
PARTITIONED BY (
sales_txn_dt DATE)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_promo_item(
sales_txn_id STRING,
line_seq_nbr_promo DECIMAL(38,0),
upc_nbr DECIMAL(14,0),
prod_sk INT,
original_unit_price_dlrs_promo DECIMAL(8,2),
regular_ext_price_dlrs_promo DECIMAL(8,2),
qty_promo DECIMAL(8,0),
selling_price_dlrs_promo DECIMAL(8,2),
sales_txn_type STRING,
src_sys_cd STRING)
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo_item'
PARTITIONED BY (
sales_txn_dt DATE)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.pos_ipsos_promomvt_xml_parsed_unmatched_stg
(
Str INT ,
BDate DATE COMMENT '{{"FORMAT":"YYYY/MM/DD" }}',
BDate_before DATE COMMENT '{{"FORMAT":"YYYY/MM/DD" }}',
BDate_after DATE COMMENT '{{"FORMAT":"YYYY/MM/DD" }}',
Reg SMALLINT,
RNum SMALLINT,
Lyl STRING,
Line DECIMAL(38,0),
Upc DECIMAL(14,0),
RUP DECIMAL(8,2),
Qty DECIMAL(8,0),
REP DECIMAL(8,2),
SEP DECIMAL(8,2),
Promo_seq_num INT,
Typ STRING,
Adj DECIMAL(8,2),
Plu DECIMAL(14,0),
Mode1 STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/pos_ipsos_promomvt_xml_parsed_unmatched_stg'""")
# COMMAND ----------
migration_data=[{"release": "10.2.1", "scripts": ["T.1392.1.crt.icplus_status_update_har.sql", "T.1798.1.crt.sales_transaction_promo.sql", "T.1799.1.crt.sales_transaction_promo_dtl.sql", "T.1800.1.crt.sales_transaction_promo_item.sql", "T.1068.1.crt.ccpa_rtd_log.sql", "T.20034.1.wrg.pos_ipsos_promomvt_xml_parsed_unmatched_stg.sql"], "migration_date": "2022-12-28"}]
table_data=[{"release": "10.2.1", "table_id": "T.1392.1", "table_name": "icplus_status_update_har", "table_schema": "pharmacy_healthcare__patient_services.icplus_status_update_har", "table_legacy_schema": "dae_cooked.icplus_status_update_har", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.icplus_status_update_har", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-12-28 10:46:23", "update_date": ""}, {"release": "10.2.1", "table_id": "T.1798.1", "table_name": "sales_transaction_promo", "table_schema": "retail__retail_sales.sales_transaction_promo", "table_legacy_schema": "dae_cooked.sales_transaction_promo", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_promo", "table_partition": "\n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-12-28 10:46:23", "update_date": ""}, {"release": "10.2.1", "table_id": "T.1799.1", "table_name": "sales_transaction_promo_dtl", "table_schema": "retail__retail_sales.sales_transaction_promo_dtl", "table_legacy_schema": "dae_cooked.sales_transaction_promo_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_promo_dtl", "table_partition": "\n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-12-28 10:46:23", "update_date": ""}, {"release": "10.2.1", "table_id": "T.1800.1", "table_name": "sales_transaction_promo_item", "table_schema": "retail__retail_sales.sales_transaction_promo_item", "table_legacy_schema": "dae_cooked.sales_transaction_promo_item", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_promo_item", "table_partition": "\n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-12-28 10:46:23", "update_date": ""}, {"release": "10.2.1", "table_id": "T.1068.1", "table_name": "ccpa_rtd_log", "table_schema": "retail__ccpa.ccpa_rtd_log", "table_legacy_schema": "dae_cooked.ccpa_rtd_log", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "retail__ccpa.ccpa_rtd_log", "table_partition": "\n  idh_create_dttm STRING", "table_db": "retail__ccpa", "table_zone": "curated", "create_date": "2022-12-28 10:46:23", "update_date": ""}, {"release": "10.2.1", "table_id": "T.20034.1", "table_name": "pos_ipsos_promomvt_xml_parsed_unmatched_stg", "table_schema": "staging__retail__retail_sales.pos_ipsos_promomvt_xml_parsed_unmatched_stg", "table_legacy_schema": "", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.pos_ipsos_promomvt_xml_parsed_unmatched_stg", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-12-28 10:46:23", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
# %sql
# MERGE INTO  master_data__information_schema.databricks_table_catalog tables
#     USING temp_catalog new
#     ON tables.table_schema = new.table_schema AND tables.table_name = new.table_name
# WHEN MATCHED THEN
#     UPDATE SET
#         tables.table_schema = new.table_schema,
#         tables.table_database = new.table_database,
#         tables.table_legacy_schema = new.table_legacy_schema
#         tables.table_name = new.table_name,
#         tables.table_domain = new.table_domain,
#         tables.table_subdomain = new.table_subdomain,
#         tables.table_data_class = new.table_data_class,
#         tables.table_location = new.table_location,
#         tables.table_partition = new.table_partition,
#         tables.table_zone = new.table_zone,
#         tables.create_date = tables.create_date
#         tables.update_date = current_timestamp()
# WHEN NOT MATCHED THEN
#     INSERT 
#         new.table_schema,
#         new.table_database,
#         new.table_name,
#         new.table_legacy_schema,
#         new.table_domain,
#         new.table_subdomain,
#         new.table_data_class,
#         new.table_location,
#         new.table_partition,
#         new.table_zone,
#         new.create_date,
#         new.update_date
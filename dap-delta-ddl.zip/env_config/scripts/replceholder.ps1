param (
    $ENV_TYPE,
    $configTemplatePath,
    $configPath
)
filter timestamp { "$(Get-Date -Format o): $_" }
function Transform-ConfigString {
    [CmdletBinding()]
    param(
        [Parameter(Position = 1, Mandatory = $true, HelpMessage = 'The templated sql file path with file name.')]
        [string]$configTemplatePath,
        [Parameter(Position = 2, Mandatory = $true, HelpMessage = 'The placeholder template file name.')]
        [string]$placeholderTemplate,
        [Parameter(Position = 3, Mandatory = $true, HelpMessage = 'The placeholder file name.')]
        [string]$placeholderValue
    )
    Write-Host "Executing Transform config"
    if (!$configTemplatePath -or !(Test-Path -path $configTemplatePath -PathType Leaf)) {
        throw "File not found. $configTemplatePath"
    }
    Write-Output "Loading config templated file from $configTemplatePath"
    $configTemplate = (Get-Content $configTemplatePath)
    #$placeHolder = -join('${', $placeholderTemplate, '}')
    $placeHolder = '${' + $placeholderTemplate + '}'
    # Write-Warning $placeHolder
    Write-Output "Replacing $placeholderTemplate with value $placeholderValue in $configTemplatePath"
    ($configTemplate) | Foreach-Object {
        # $_ -replace $placeholderTemplate, $placeholderValue
        $_ -replace [regex]::Escape($placeHolder), $placeholderValue
    } | Set-Content $configTemplatePath
}
$configVariablePath = "$configPath\$($ENV_TYPE).properties"
Write-Output "configVariablePath is $configVariablePath and configTemplatePath is $configTemplatePath"
$configVariable = (Get-Content $configVariablePath)
    ($configVariable) | Foreach-Object {
    if ($_[0] -ne "#") {
        $pos = $_.IndexOf("=")
        if ($pos -ge 0) {
            $leftPart = $_.Substring(0, $pos).Trim()
            $rightPart = $_.Substring($pos + 1).Trim()
            Get-ChildItem $configTemplatePath -Filter *.sql -Recurse -Force |
            ForEach-Object {
                Write-Host "Transforming $($_.FullName)"
                Transform-ConfigString -configTemplatePath $_.FullName -placeholderTemplate $leftPart -placeholderValue $rightPart
            }
            Get-ChildItem $configTemplatePath -Filter *.py -Recurse -Force |
            ForEach-Object {
                Write-Host "Transforming $($_.FullName)"
                Transform-ConfigString -configTemplatePath $_.FullName -placeholderTemplate $leftPart -placeholderValue $rightPart
            }
        }
    }
}
-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_finance}__${SUBDOMAIN_fn_reports};
--LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_hr}__${SUBDOMAIN_organization_structure};
--LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_hr}__${SUBDOMAIN_lookup_codes};
--LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_property_services}__${SUBDOMAIN_property_services};
--LOCATION ${TABLE_LOCATION}
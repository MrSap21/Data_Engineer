-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_master_data}__${SUBDOMAIN_reference_code_values};
--LOCATION ${TABLE_LOCATION}
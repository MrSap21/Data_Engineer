-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_hr}__${SUBDOMAIN_payroll};
--LOCATION ${TABLE_LOCATION}
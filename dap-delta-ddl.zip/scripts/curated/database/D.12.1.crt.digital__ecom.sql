-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_digital}__${SUBDOMAIN_ecom};
--LOCATION ${TABLE_LOCATION}
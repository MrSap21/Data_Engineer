-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_mna_buyout}__${SUBDOMAIN_retail};
--LOCATION ${TABLE_LOCATION}
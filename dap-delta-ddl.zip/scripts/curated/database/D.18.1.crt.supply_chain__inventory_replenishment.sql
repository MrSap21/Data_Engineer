-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_supply_chain}__${SUBDOMAIN_inventory_replenishment};
--LOCATION ${TABLE_LOCATION}
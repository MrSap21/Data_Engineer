-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_pharmacy_healthcare}__${SUBDOMAIN_patient_services};
--LOCATION ${TABLE_LOCATION}
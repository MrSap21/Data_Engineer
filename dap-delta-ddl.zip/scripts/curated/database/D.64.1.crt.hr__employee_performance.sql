-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_hr}__${SUBDOMAIN_employee_performance};
--LOCATION ${TABLE_LOCATION}
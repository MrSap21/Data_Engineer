-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_pharmacy_healthcare}__${SUBDOMAIN_mail_order};
--LOCATION ${TABLE_LOCATION}
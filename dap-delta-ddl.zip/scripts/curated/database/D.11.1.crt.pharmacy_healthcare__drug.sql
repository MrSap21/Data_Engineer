-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_pharmacy_healthcare}__${SUBDOMAIN_drug};
--LOCATION ${TABLE_LOCATION}
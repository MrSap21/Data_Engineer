-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_pharmacy_healthcare}__${SUBDOMAIN_plan};
--LOCATION ${TABLE_LOCATION}
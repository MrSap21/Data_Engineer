-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_hr}__${SUBDOMAIN_employment_history};
--LOCATION ${TABLE_LOCATION}
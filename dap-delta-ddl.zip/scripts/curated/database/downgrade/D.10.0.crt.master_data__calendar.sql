-- Databricks notebook source
DROP SCHEMA IF EXISTS ${DOMAIN_master_data}__${SUBDOMAIN_calendar}
-- Databricks notebook source
DROP SCHEMA IF EXISTS ${DOMAIN_partner_extracts}__${SUBDOMAIN_pharmacy_healthcare}
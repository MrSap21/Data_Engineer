-- Databricks notebook source
DROP SCHEMA IF EXISTS ${DOMAIN_pharmacy_healthcare}__${SUBDOMAIN_drug}
-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_master_data}__${SUBDOMAIN_product};
--LOCATION ${TABLE_LOCATION}
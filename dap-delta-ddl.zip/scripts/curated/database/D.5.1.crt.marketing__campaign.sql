-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_marketing}__${SUBDOMAIN_campaign};
--LOCATION ${TABLE_LOCATION}
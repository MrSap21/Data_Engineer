-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_supply_chain}__${SUBDOMAIN_purchasing};
--LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_retail}__${SUBDOMAIN_promotions};
--LOCATION ${TABLE_LOCATION}
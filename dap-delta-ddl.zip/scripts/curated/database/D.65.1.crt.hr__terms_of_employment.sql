-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_hr}__${SUBDOMAIN_terms_of_employment};
--LOCATION ${TABLE_LOCATION}
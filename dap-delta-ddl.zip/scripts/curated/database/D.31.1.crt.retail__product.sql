-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_retail}__${SUBDOMAIN_product};
--LOCATION ${TABLE_LOCATION}
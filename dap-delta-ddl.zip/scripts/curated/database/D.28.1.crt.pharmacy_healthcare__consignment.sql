-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_pharmacy_healthcare}__${SUBDOMAIN_consignment};
--LOCATION ${TABLE_LOCATION}
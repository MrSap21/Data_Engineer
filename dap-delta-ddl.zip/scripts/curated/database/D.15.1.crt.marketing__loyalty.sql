-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_marketing}__${SUBDOMAIN_loyalty};
--LOCATION ${TABLE_LOCATION}
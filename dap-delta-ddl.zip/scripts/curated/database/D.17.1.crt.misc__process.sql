-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_misc}__${SUBDOMAIN_process};
--LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_retail}__${SUBDOMAIN_space_planning};
--LOCATION ${TABLE_LOCATION}
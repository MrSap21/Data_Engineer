-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_hr}__${SUBDOMAIN_recruiting};
--LOCATION ${TABLE_LOCATION}
-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_partner_extracts}__${SUBDOMAIN_pharmacy_healthcare};
--LOCATION ${TABLE_LOCATION}
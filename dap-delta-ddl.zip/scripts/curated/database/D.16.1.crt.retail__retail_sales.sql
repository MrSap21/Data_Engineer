-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_retail}__${SUBDOMAIN_retail_sales};
--LOCATION ${TABLE_LOCATION}
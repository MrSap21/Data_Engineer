-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_finance}__${SUBDOMAIN_account_payables};
--LOCATION ${TABLE_LOCATION}
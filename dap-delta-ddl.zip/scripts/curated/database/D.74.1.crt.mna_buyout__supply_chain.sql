-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS ${DOMAIN_mna_buyout}__${SUBDOMAIN_supply_chain};
--LOCATION ${TABLE_LOCATION}
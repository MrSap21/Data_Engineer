-- Databricks notebook source
CREATE SCHEMA IF NOT EXISTS master_data__information_schema;

CREATE TABLE IF NOT EXISTS master_data__information_schema.databricks_migrations(
    release STRING,
    scripts ARRAY<STRING>,
    migration_date DATE
)
USING DELTA
LOCATION
   'abfss://{STORAGE_ACCT_crt_master_data}@${STORAGE_ACCT_crt_master_data}.dfs.core.windows.net/${DOMAIN_master_data}/${SUBDOMAIN_information_schema}/databricks_migrations';


CREATE TABLE IF NOT EXISTS master_data__information_schema.databricks_tables(
    release STRING,
    table_id STRING,
    table_name STRING,
    table_schema STRING,
    table_legacy_schema STRING,
    table_domain STRING,
    table_subdomain STRING,
    table_location STRING,
    table_partition STRING,
    table_db STRING,
    table_zone STRING,
    create_date TIMESTAMP,
    update_date TIMESTAMP
)
USING DELTA
LOCATION
   'abfss://{STORAGE_ACCT_crt_master_data}@${STORAGE_ACCT_crt_master_data}.dfs.core.windows.net/${DOMAIN_master_data}/${SUBDOMAIN_information_schema}/databricks_tables';




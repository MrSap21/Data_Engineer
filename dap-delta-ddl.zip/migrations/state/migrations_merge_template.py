migration_data=<MIGRATION_DATA>
table_data=<TABLE_DATA>
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN (<TABLE_NAMES_LIST>);
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
# %sql
# MERGE INTO  master_data__information_schema.databricks_table_catalog tables
#     USING temp_catalog new
#     ON tables.table_schema = new.table_schema AND tables.table_name = new.table_name
# WHEN MATCHED THEN
#     UPDATE SET
#         tables.table_schema = new.table_schema,
#         tables.table_database = new.table_database,
#         tables.table_legacy_schema = new.table_legacy_schema
#         tables.table_name = new.table_name,
#         tables.table_domain = new.table_domain,
#         tables.table_subdomain = new.table_subdomain,
#         tables.table_data_class = new.table_data_class,
#         tables.table_location = new.table_location,
#         tables.table_partition = new.table_partition,
#         tables.table_zone = new.table_zone,
#         tables.create_date = tables.create_date
#         tables.update_date = current_timestamp()
# WHEN NOT MATCHED THEN
#     INSERT 
#         new.table_schema,
#         new.table_database,
#         new.table_name,
#         new.table_legacy_schema,
#         new.table_domain,
#         new.table_subdomain,
#         new.table_data_class,
#         new.table_location,
#         new.table_partition,
#         new.table_zone,
#         new.create_date,
#         new.update_date
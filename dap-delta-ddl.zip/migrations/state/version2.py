# Databricks notebook source
spark.sql(f"""CREATE TABLE IF NOT EXISTS master_data__information_schema.databricks_table_catalog(
    table_schema STRING,
    table_database STRING,
    table_name STRING,
    table_legacy_schema STRING,
    table_domain STRING,
    table_subdomain STRING,
    table_data_class STRING,
    table_location STRING,
    table_partition STRING,
    table_zone STRING,
    create_date TIMESTAMP,
    update_date TIMESTAMP
)
USING DELTA
LOCATION
   'abfss://curated@{getArgument('STORAGE_ACCT_crt_master_data')}.dfs.core.windows.net/master_data/information_schema/databricks_table_catalog';""")
# COMMAND ----------

# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables tables
    USING temp_tables new
    ON tables.table_schema = new.table_schema AND tables.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        tables.table_schema = new.table_schema,
        tables.table_database = new.table_database,
        tables.table_legacy_schema = new.table_legacy_schema
        tables.table_name = new.table_name,
        tables.table_domain = new.table_domain,
        tables.table_subdomain = new.table_subdomain,
        tables.table_data_class = new.table_data_class,
        tables.table_location = new.table_location,
        tables.table_partition = new.table_partition,
        tables.table_zone = new.table_zone,
        tables.create_date = tables.create_date
        tables.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT 
        new.table_schema,
        new.table_database,
        new.table_name,
        new.table_legacy_schema,
        new.table_domain,
        new.table_subdomain,
        new.table_data_class,
        new.table_location,
        new.table_partition,
        new.table_zone,
        new.create_date,
        new.update_date
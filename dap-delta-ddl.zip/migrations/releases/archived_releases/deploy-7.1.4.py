# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_digital', defaultValue='${STORAGE_ACCT_wrg_digital}', label='STORAGE_ACCT_wrg_digital')
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__organization_structure;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__organization_structure;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.positionmatrixrelationship_stg(
update_flag STRING,
position_position_code STRING,
position_start_date STRING,
type STRING,
mdf_system_created_by STRING,
mdf_system_created_date STRING,
mdf_system_last_modified_by STRING,
mdf_system_last_modified_date STRING,
mdf_system_record_status STRING,
related_position STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/positionmatrixrelationship_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.positionmatrixrelationship_delta_stg(
update_flag STRING,
position_position_code STRING,
position_start_date STRING,
type STRING,
mdf_system_created_by STRING,
mdf_system_created_date STRING,
mdf_system_last_modified_by STRING,
mdf_system_last_modified_date STRING,
mdf_system_record_status STRING,
related_position STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/positionmatrixrelationship_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.positionmatrixrelationship_persistent_stg(
update_flag STRING,
position_position_code STRING,
position_start_date STRING,
type STRING,
mdf_system_created_by STRING,
mdf_system_created_date STRING,
mdf_system_last_modified_by STRING,
mdf_system_last_modified_date STRING,
mdf_system_record_status STRING,
related_position STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/positionmatrixrelationship_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.positionmatrixrelationship_unchanged_stg(
update_flag STRING,
position_position_code STRING,
position_start_date STRING,
type STRING,
mdf_system_created_by STRING,
mdf_system_created_date STRING,
mdf_system_last_modified_by STRING,
mdf_system_last_modified_date STRING,
mdf_system_record_status STRING,
related_position STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/positionmatrixrelationship_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.cust_lineofbusiness_new_stg(
update_flag STRING,
effective_start_date STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_description_default_value STRING,
cust_description_en_us STRING,
cust_description_localized STRING,
cust_effective_status STRING,
cust_head_of_unit STRING,
cust_parent_lob STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_effective_end_date STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/cust_lineofbusiness_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.cust_lineofbusiness_updated_stg(
update_flag STRING,
effective_start_date STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_description_default_value STRING,
cust_description_en_us STRING,
cust_description_localized STRING,
cust_effective_status STRING,
cust_head_of_unit STRING,
cust_parent_lob STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_effective_end_date STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/cust_lineofbusiness_updated_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_notification_stg(
aggregation_id STRING,
notification_channel STRING,
communication_channel STRING,
pat_id STRING,
source_system STRING,
notification_msg STRING,
notification_language STRING,
field_activity_ind STRING,
app_instance STRING,
create_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_notification_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.atg_acapdb_logs_stg(
file STRING,
col_cnt_iss_cnt INT,
src_recd_cnt INT,
null_rej_cnt INT,
target_tbl_cnt INT,
comment STRING,
insert_cnt INT,
update_cnt INT,
retained_cnt INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/atg_acapdb_logs_stg'
PARTITIONED BY (
ingestion_date TIMESTAMP,
file_name STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_source_system_lookup_temp_stg(
ME_ID STRING
,SOURCE_SYSTEM STRING
,SOURCE_SYSTEM_ID STRING
,SOURCE_STATUS STRING
,CREATE_DTTM STRING
,CREATE_USER STRING
,UPDATE_DTTM STRING
,UPDATE_USER STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_source_system_lookup_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_source_system_lookup_etl_stg(
me_id STRING,
source_system STRING,
source_system_id STRING,
source_status STRING,
create_dttm STRING,
update_dttm STRING,
create_user STRING,
update_user STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_source_system_lookup_etl_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_source_system_lookup_update_records_stg(
me_id STRING
,source_system STRING
,source_system_id STRING
,source_status STRING
,create_dttm TIMESTAMP
,CREATE_USER STRING
,UPDATE_DTTM TIMESTAMP
,UPDATE_USER STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_source_system_lookup_update_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_source_system_lookup_insert_records_stg(
ME_ID STRING
,SOURCE_SYSTEM STRING
,SOURCE_SYSTEM_ID STRING
,SOURCE_STATUS STRING
,CREATE_DTTM TIMESTAMP
,CREATE_USER STRING
,UPDATE_DTTM TIMESTAMP
,UPDATE_USER STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_source_system_lookup_insert_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_source_system_lookup_retained_records_stg(
ME_ID STRING
,SOURCE_SYSTEM STRING
,SOURCE_SYSTEM_ID STRING
,SOURCE_STATUS STRING
,CREATE_DTTM TIMESTAMP
,CREATE_USER STRING
,UPDATE_DTTM TIMESTAMP
,UPDATE_USER STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_source_system_lookup_retained_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_notification_temp_stg(
aggregation_id STRING,
notification_channel STRING,
communication_channel STRING,
pat_id STRING,
source_system STRING,
notification_msg STRING,
notification_language STRING,
field_activity_ind STRING,
app_instance STRING,
create_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_notification_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_notification_update_records_stg(
aggregation_id STRING,
notification_channel STRING,
communication_channel STRING,
pat_id STRING,
source_system STRING,
notification_msg STRING,
notification_language STRING,
field_activity_ind STRING,
app_instance STRING,
create_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_notification_update_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_notification_insert_records_stg(
aggregation_id STRING,
notification_channel STRING,
communication_channel STRING,
pat_id STRING,
source_system STRING,
notification_msg STRING,
notification_language STRING,
field_activity_ind STRING,
app_instance STRING,
create_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_notification_insert_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_notification_retained_records_stg(
aggregation_id STRING,
notification_channel STRING,
communication_channel STRING,
pat_id STRING,
source_system STRING,
notification_msg STRING,
notification_language STRING,
field_activity_ind STRING,
app_instance STRING,
create_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_notification_retained_records_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.1.4", "scripts": ["D.5.1.crt.marketing__campaign.sql", "D.54.1.wrg.digital__ecom.sql", "D.61.1.crt.hr__organization_structure.sql", "D.68.1.wrg.hr__organization_structure.sql", "T.14748.1.wrg.positionmatrixrelationship_stg.sql", "T.15198.1.wrg.positionmatrixrelationship_delta_stg.sql", "T.15199.1.wrg.positionmatrixrelationship_persistent_stg.sql", "T.15200.1.wrg.positionmatrixrelationship_unchanged_stg.sql", "T.19900.1.wrg.cust_lineofbusiness_new_stg.sql", "T.19901.1.wrg.cust_lineofbusiness_updated_stg.sql", "T.19902.1.wrg.rx_notification_stg.sql", "T.19903.1.wrg.atg_acapdb_logs_stg.sql", "T.19904.1.wrg.www_source_system_lookup_temp_stg.sql", "T.19905.1.wrg.www_source_system_lookup_etl_stg.sql", "T.19906.1.wrg.www_source_system_lookup_update_records_stg.sql", "T.19907.1.wrg.www_source_system_lookup_insert_records_stg.sql", "T.19908.1.wrg.www_source_system_lookup_retained_records_stg.sql", "T.19909.1.wrg.rx_notification_temp_stg.sql", "T.19910.1.wrg.rx_notification_update_records_stg.sql", "T.19911.1.wrg.rx_notification_insert_records_stg.sql", "T.19912.1.wrg.rx_notification_retained_records_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.1.4", "table_id": "T.14748.1", "table_name": "positionmatrixrelationship_stg", "table_schema": "staging__hr__organization_structure.positionmatrixrelationship_stg", "table_legacy_schema": "hr_raw.positionmatrixrelationship", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.positionmatrixrelationship_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.15198.1", "table_name": "positionmatrixrelationship_delta_stg", "table_schema": "staging__hr__organization_structure.positionmatrixrelationship_delta_stg", "table_legacy_schema": "hr_work.positionmatrixrelationship_delta", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.positionmatrixrelationship_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.15199.1", "table_name": "positionmatrixrelationship_persistent_stg", "table_schema": "staging__hr__organization_structure.positionmatrixrelationship_persistent_stg", "table_legacy_schema": "hr_work.positionmatrixrelationship_persistent", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.positionmatrixrelationship_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.15200.1", "table_name": "positionmatrixrelationship_unchanged_stg", "table_schema": "staging__hr__organization_structure.positionmatrixrelationship_unchanged_stg", "table_legacy_schema": "hr_work.positionmatrixrelationship_unchanged", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.positionmatrixrelationship_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19900.1", "table_name": "cust_lineofbusiness_new_stg", "table_schema": "staging__hr__organization_structure.cust_lineofbusiness_new_stg", "table_legacy_schema": "hr_work.cust_lineofbusiness_new", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.cust_lineofbusiness_new_stg", "table_partition": "", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19901.1", "table_name": "cust_lineofbusiness_updated_stg", "table_schema": "staging__hr__organization_structure.cust_lineofbusiness_updated_stg", "table_legacy_schema": "hr_work.cust_lineofbusiness_updated", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.cust_lineofbusiness_updated_stg", "table_partition": "", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19902.1", "table_name": "rx_notification_stg", "table_schema": "staging__digital__ecom.rx_notification_stg", "table_legacy_schema": "acapetldb.rx_notification", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_notification_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19903.1", "table_name": "atg_acapdb_logs_stg", "table_schema": "staging__digital__ecom.atg_acapdb_logs_stg", "table_legacy_schema": "acapetldb.atg_acapdb_logs", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.atg_acapdb_logs_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19904.1", "table_name": "www_source_system_lookup_temp_stg", "table_schema": "staging__digital__ecom.www_source_system_lookup_temp_stg", "table_legacy_schema": "acapetldb.www_source_system_lookup_temp", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_source_system_lookup_temp_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19905.1", "table_name": "www_source_system_lookup_etl_stg", "table_schema": "staging__digital__ecom.www_source_system_lookup_etl_stg", "table_legacy_schema": "acapetldb.www_source_system_lookup_etl", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_source_system_lookup_etl_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19906.1", "table_name": "www_source_system_lookup_update_records_stg", "table_schema": "staging__digital__ecom.www_source_system_lookup_update_records_stg", "table_legacy_schema": "acapetldb.www_source_system_lookup_update_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_source_system_lookup_update_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19907.1", "table_name": "www_source_system_lookup_insert_records_stg", "table_schema": "staging__digital__ecom.www_source_system_lookup_insert_records_stg", "table_legacy_schema": "acapetldb.www_source_system_lookup_insert_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_source_system_lookup_insert_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19908.1", "table_name": "www_source_system_lookup_retained_records_stg", "table_schema": "staging__digital__ecom.www_source_system_lookup_retained_records_stg", "table_legacy_schema": "acapetldb.www_source_system_lookup_retained_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_source_system_lookup_retained_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19909.1", "table_name": "rx_notification_temp_stg", "table_schema": "staging__digital__ecom.rx_notification_temp_stg", "table_legacy_schema": "acapetldb.rx_notification_temp", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_notification_temp_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19910.1", "table_name": "rx_notification_update_records_stg", "table_schema": "staging__digital__ecom.rx_notification_update_records_stg", "table_legacy_schema": "acapetldb.rx_notification_update_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_notification_update_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19911.1", "table_name": "rx_notification_insert_records_stg", "table_schema": "staging__digital__ecom.rx_notification_insert_records_stg", "table_legacy_schema": "acapetldb.rx_notification_insert_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_notification_insert_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.4", "table_id": "T.19912.1", "table_name": "rx_notification_retained_records_stg", "table_schema": "staging__digital__ecom.rx_notification_retained_records_stg", "table_legacy_schema": "acapetldb.rx_notification_retained_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_notification_retained_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
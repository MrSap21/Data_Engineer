# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.paycalendar_stg(
update_flag STRING,
pay_group STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/paycalendar_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payinfo_stg(
update_flag STRING,
employee_id STRING,
paymentinformation_effective_start_date STRING,
paymentinformation_worker STRING,
external_code STRING,
account_number STRING,
account_owner STRING,
amount STRING,
bank STRING,
bank_country STRING,
business_identifier_code STRING,
created_by STRING,
created_date_time STRING,
currency STRING,
iban STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_type STRING,
payment_method STRING,
paymentinformation_percent STRING,
routing_number STRING,
account_type STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payinfo_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payperiod_stg(
update_flag STRING,
pay_calendar_pay_group STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_pay_periods_per_year STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_check_issue_date STRING,
pay_period_begin_date STRING,
pay_period_end_date STRING,
off_cycle STRING,
processing_run_id STRING,
run_type STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payperiod_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.paycalendar_delta_stg(
update_flag STRING,
pay_group STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/paycalendar_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.paycalendar_unchanged_stg(
update_flag STRING,
pay_group STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/paycalendar_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payinfo_delta_stg(
update_flag STRING,
employee_id STRING,
paymentinformation_effective_start_date STRING,
paymentinformation_worker STRING,
external_code STRING,
account_number STRING,
account_owner STRING,
amount DECIMAL(9,2),
bank STRING,
bank_country STRING,
business_identifier_code STRING,
created_by STRING,
created_date_time STRING,
currency STRING,
iban STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_type STRING,
payment_method STRING,
paymentinformation_percent DECIMAL(9,2),
routing_number STRING,
account_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payinfo_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payinfo_unchanged_stg(
update_flag STRING,
employee_id STRING,
paymentinformation_effective_start_date STRING,
paymentinformation_worker STRING,
external_code STRING,
account_number STRING,
account_owner STRING,
amount DECIMAL(9,2),
bank STRING,
bank_country STRING,
business_identifier_code STRING,
created_by STRING,
created_date_time STRING,
currency STRING,
iban STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_type STRING,
payment_method STRING,
paymentinformation_percent DECIMAL(9,2),
routing_number STRING,
account_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payinfo_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payperiod_delta_stg(
update_flag STRING,
pay_calendar_pay_group STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_pay_periods_per_year BIGINT,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_check_issue_date STRING,
pay_period_begin_date STRING,
pay_period_end_date STRING,
off_cycle STRING,
processing_run_id STRING,
run_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payperiod_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payperiod_unchanged_stg(
update_flag STRING,
pay_calendar_pay_group STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_pay_periods_per_year BIGINT,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_check_issue_date STRING,
pay_period_begin_date STRING,
pay_period_end_date STRING,
off_cycle STRING,
processing_run_id STRING,
run_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payperiod_unchanged_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.3.4", "scripts": ["D.60.1.crt.hr__payroll.sql", "D.67.1.wrg.hr__payroll.sql", "T.14727.1.wrg.paycalendar_stg.sql", "T.14730.1.wrg.payinfo_stg.sql", "T.14731.1.wrg.payperiod_stg.sql", "T.15111.1.wrg.paycalendar_delta_stg.sql", "T.15113.1.wrg.paycalendar_unchanged_stg.sql", "T.15128.1.wrg.payinfo_delta_stg.sql", "T.15130.1.wrg.payinfo_unchanged_stg.sql", "T.15132.1.wrg.payperiod_delta_stg.sql", "T.15134.1.wrg.payperiod_unchanged_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.3.4", "table_id": "T.14727.1", "table_name": "paycalendar_stg", "table_schema": "staging__hr__payroll.paycalendar_stg", "table_legacy_schema": "hr_raw.paycalendar", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.paycalendar_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.4", "table_id": "T.14730.1", "table_name": "payinfo_stg", "table_schema": "staging__hr__payroll.payinfo_stg", "table_legacy_schema": "hr_raw.payinfo", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payinfo_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.4", "table_id": "T.14731.1", "table_name": "payperiod_stg", "table_schema": "staging__hr__payroll.payperiod_stg", "table_legacy_schema": "hr_raw.payperiod", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payperiod_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.4", "table_id": "T.15111.1", "table_name": "paycalendar_delta_stg", "table_schema": "staging__hr__payroll.paycalendar_delta_stg", "table_legacy_schema": "hr_work.paycalendar_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.paycalendar_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.4", "table_id": "T.15113.1", "table_name": "paycalendar_unchanged_stg", "table_schema": "staging__hr__payroll.paycalendar_unchanged_stg", "table_legacy_schema": "hr_work.paycalendar_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.paycalendar_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.4", "table_id": "T.15128.1", "table_name": "payinfo_delta_stg", "table_schema": "staging__hr__payroll.payinfo_delta_stg", "table_legacy_schema": "hr_work.payinfo_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payinfo_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.4", "table_id": "T.15130.1", "table_name": "payinfo_unchanged_stg", "table_schema": "staging__hr__payroll.payinfo_unchanged_stg", "table_legacy_schema": "hr_work.payinfo_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payinfo_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.4", "table_id": "T.15132.1", "table_name": "payperiod_delta_stg", "table_schema": "staging__hr__payroll.payperiod_delta_stg", "table_legacy_schema": "hr_work.payperiod_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payperiod_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.4", "table_id": "T.15134.1", "table_name": "payperiod_unchanged_stg", "table_schema": "staging__hr__payroll.payperiod_unchanged_stg", "table_legacy_schema": "hr_work.payperiod_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payperiod_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscalegroup_stg(
update_flag STRING,
code STRING,
country STRING,
created_by STRING,
created_date_time STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_scale_area STRING,
pay_scale_group STRING,
pay_scale_type STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscalegroup_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscaletype_stg(
update_flag STRING,
code STRING,
country STRING,
created_by STRING,
created_date_time STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_scale_type STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscaletype_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaycomponentgroup_delta_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_component_flx STRING,
status STRING,
show_on_comp_ui STRING,
sort_order STRING,
use_for_comparatio_calc STRING,
use_for_range_penetration STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaycomponentgroup_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaycomponentgroup_unchanged_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_component_flx STRING,
status STRING,
show_on_comp_ui STRING,
sort_order STRING,
use_for_comparatio_calc STRING,
use_for_range_penetration STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaycomponentgroup_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscalegroup_delta_stg(
update_flag STRING,
code STRING,
country STRING,
created_by STRING,
created_date_time STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_scale_area STRING,
pay_scale_group STRING,
pay_scale_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscalegroup_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscalegroup_unchanged_stg(
update_flag STRING,
code STRING,
country STRING,
created_by STRING,
created_date_time STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_scale_area STRING,
pay_scale_group STRING,
pay_scale_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscalegroup_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscaletype_delta_stg(
update_flag STRING,
code STRING,
country STRING,
created_by STRING,
created_date_time STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_scale_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscaletype_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscaletype_unchanged_stg(
update_flag STRING,
code STRING,
country STRING,
created_by STRING,
created_date_time STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
pay_scale_type STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscaletype_unchanged_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.4.3", "scripts": ["D.67.1.wrg.hr__payroll.sql", "D.71.1.wrg.hr__compensation_benefits.sql", "T.14735.1.wrg.payscalegroup_stg.sql", "T.14738.1.wrg.payscaletype_stg.sql", "T.15034.1.wrg.fopaycomponentgroup_delta_stg.sql", "T.15036.1.wrg.fopaycomponentgroup_unchanged_stg.sql", "T.15142.1.wrg.payscalegroup_delta_stg.sql", "T.15144.1.wrg.payscalegroup_unchanged_stg.sql", "T.15154.1.wrg.payscaletype_delta_stg.sql", "T.15156.1.wrg.payscaletype_unchanged_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.4.3", "table_id": "T.14735.1", "table_name": "payscalegroup_stg", "table_schema": "staging__hr__payroll.payscalegroup_stg", "table_legacy_schema": "hr_raw.payscalegroup", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscalegroup_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.3", "table_id": "T.14738.1", "table_name": "payscaletype_stg", "table_schema": "staging__hr__payroll.payscaletype_stg", "table_legacy_schema": "hr_raw.payscaletype", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscaletype_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.3", "table_id": "T.15034.1", "table_name": "fopaycomponentgroup_delta_stg", "table_schema": "staging__hr__compensation_benefits.fopaycomponentgroup_delta_stg", "table_legacy_schema": "hr_work.fopaycomponentgroup_delta", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaycomponentgroup_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.3", "table_id": "T.15036.1", "table_name": "fopaycomponentgroup_unchanged_stg", "table_schema": "staging__hr__compensation_benefits.fopaycomponentgroup_unchanged_stg", "table_legacy_schema": "hr_work.fopaycomponentgroup_unchanged", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaycomponentgroup_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.3", "table_id": "T.15142.1", "table_name": "payscalegroup_delta_stg", "table_schema": "staging__hr__payroll.payscalegroup_delta_stg", "table_legacy_schema": "hr_work.payscalegroup_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscalegroup_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.3", "table_id": "T.15144.1", "table_name": "payscalegroup_unchanged_stg", "table_schema": "staging__hr__payroll.payscalegroup_unchanged_stg", "table_legacy_schema": "hr_work.payscalegroup_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscalegroup_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.3", "table_id": "T.15154.1", "table_name": "payscaletype_delta_stg", "table_schema": "staging__hr__payroll.payscaletype_delta_stg", "table_legacy_schema": "hr_work.payscaletype_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscaletype_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.3", "table_id": "T.15156.1", "table_name": "payscaletype_unchanged_stg", "table_schema": "staging__hr__payroll.payscaletype_unchanged_stg", "table_legacy_schema": "hr_work.payscaletype_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscaletype_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
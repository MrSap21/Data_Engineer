# Databricks notebook source 
dbutils.widgets.text(name='retail_crt_sa', defaultValue='${retail_crt_sa}', label='retail_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_crt_partner_extracts', defaultValue='${STORAGE_ACCT_crt_partner_extracts}', label='STORAGE_ACCT_crt_partner_extracts')
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_crt_digital', defaultValue='${STORAGE_ACCT_crt_digital}', label='STORAGE_ACCT_crt_digital')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
dbutils.widgets.text(name='marketing_crt_sa', defaultValue='${marketing_crt_sa}', label='marketing_crt_sa')
dbutils.widgets.text(name='digital_crt_sa', defaultValue='${digital_crt_sa}', label='digital_crt_sa')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='partner_extracts_crt_sa', defaultValue='${partner_extracts_crt_sa}', label='partner_extracts_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='hr_crt_sa', defaultValue='${hr_crt_sa}', label='hr_crt_sa')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__promotions;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__employee_performance;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_campaign_target_patients(
pat_id DECIMAL(13,0),
first_fill_dt STRING,
last_fill_dt STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/car_campaign_target_patients'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.contact_hist_acap_reconcilaition(
day_dt STRING,
per_id STRING,
contact_date STRING,
planned_contact_date STRING,
campaigncode STRING,
channel_cd STRING,
packageid STRING,
cell_id STRING,
offer_cd STRING,
treatment_id STRING,
contact_status_id STRING,
count_val STRING,
file_dttm STRING)
USING DELTA
LOCATION
'abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/contact_hist_acap_reconcilaition'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.contact_hist_ora_reconcilaition(
batch_dttm STRING,
contactdatetime STRING,
planned_contact_date STRING,
campaign_cd STRING,
channel_cd STRING,
packageid STRING,
cellid STRING,
offer_cd STRING,
treatment_id DECIMAL(19,0),
treatment_cd STRING,
contactstatusid STRING,
count STRING,
file_dttm STRING)
USING DELTA
LOCATION
'abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/contact_hist_ora_reconcilaition'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__promotions.ad_event_type(
ad_evt_type_id INT,
ad_group_type_id INT,
ad_evt_type_desc STRING,
ad_evt_lvl_name STRING,
ad_group_type_desc STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://promotions-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ad_event_type'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_mapping(
integration_prtnr STRING,
campgn_name STRING,
metadata_01_name STRING,
metadata_02_name STRING,
metadata_03_name STRING,
metadata_04_name STRING,
metadata_05_name STRING,
metadata_06_name STRING,
metadata_07_name STRING,
metadata_08_name STRING,
metadata_09_name STRING,
metadata_10_name STRING,
metadata_11_name STRING,
metadata_12_name STRING,
metadata_13_name STRING,
metadata_14_name STRING,
metadata_15_name STRING,
metadata_16_name STRING,
metadata_17_name STRING,
metadata_18_name STRING,
metadata_19_name STRING,
metadata_20_name STRING,
metadata_21_name STRING,
metadata_22_name STRING,
metadata_23_name STRING,
metadata_24_name STRING,
metadata_25_name STRING,
metadata_26_name STRING,
metadata_27_name STRING,
metadata_28_name STRING,
metadata_29_name STRING,
metadata_30_name STRING,
metadata_31_name STRING,
metadata_32_name STRING,
metadata_33_name STRING,
metadata_34_name STRING,
metadata_35_name STRING,
metadata_36_name STRING,
metadata_37_name STRING,
metadata_38_name STRING,
metadata_39_name STRING,
metadata_40_name STRING,
metadata_41_name STRING,
metadata_42_name STRING,
metadata_43_name STRING,
metadata_44_name STRING,
metadata_45_name STRING,
metadata_46_name STRING,
metadata_47_name STRING,
metadata_48_name STRING,
metadata_49_name STRING,
metadata_50_name STRING,
metadata_51_name STRING,
metadata_52_name STRING,
metadata_53_name STRING,
metadata_54_name STRING,
metadata_55_name STRING,
metadata_56_name STRING,
metadata_57_name STRING,
metadata_58_name STRING,
metadata_59_name STRING,
metadata_60_name STRING,
metadata_61_name STRING,
metadata_62_name STRING,
metadata_63_name STRING,
metadata_64_name STRING,
metadata_65_name STRING,
edw_batch_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/car_vip_payer_non_demographic_mapping'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_meid_insight(
me_id STRING,
insight_name STRING,
edw_rec_begin_dt STRING,
external_src_id STRING,
external_src_sk BIGINT,
external_src_cd STRING,
composite_type_cd STRING,
msg_type_cd STRING,
non_demo_attr STRING,
insight_val STRING,
metadata_01_val STRING,
metadata_02_val STRING,
metadata_03_val STRING,
metadata_04_val STRING,
metadata_05_val STRING,
metadata_06_val STRING,
metadata_07_val STRING,
metadata_08_val STRING,
metadata_09_val STRING,
metadata_10_val STRING,
metadata_11_val STRING,
metadata_12_val STRING,
metadata_13_val STRING,
metadata_14_val STRING,
metadata_15_val STRING,
metadata_16_val STRING,
metadata_17_val STRING,
metadata_18_val STRING,
metadata_19_val STRING,
metadata_20_val STRING,
metadata_21_val STRING,
metadata_22_val STRING,
metadata_23_val STRING,
metadata_24_val STRING,
metadata_25_val STRING,
metadata_26_val STRING,
metadata_27_val STRING,
metadata_28_val STRING,
metadata_29_val STRING,
metadata_30_val STRING,
metadata_31_val STRING,
metadata_32_val STRING,
metadata_33_val STRING,
metadata_34_val STRING,
metadata_35_val STRING,
metadata_36_val STRING,
metadata_37_val STRING,
metadata_38_val STRING,
metadata_39_val STRING,
metadata_40_val STRING,
metadata_41_val STRING,
metadata_42_val STRING,
metadata_43_val STRING,
metadata_44_val STRING,
metadata_45_val STRING,
metadata_46_val STRING,
metadata_47_val STRING,
metadata_48_val STRING,
metadata_49_val STRING,
metadata_50_val STRING,
metadata_51_val STRING,
metadata_52_val STRING,
metadata_53_val STRING,
metadata_54_val STRING,
metadata_55_val STRING,
metadata_56_val STRING,
metadata_57_val STRING,
metadata_58_val STRING,
metadata_59_val STRING,
metadata_60_val STRING,
metadata_61_val STRING,
metadata_62_val STRING,
metadata_63_val STRING,
metadata_64_val STRING,
metadata_65_val STRING,
cdi_cust_sk BIGINT,
cdi_cust_src_id STRING,
cdi_composite_type_cd STRING,
cdi_msg_type_cd STRING,
edw_rec_end_dt STRING,
metadata_val STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_create_userid STRING,
edw_update_userid STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/car_vip_payer_non_demographic_meid_insight'
PARTITIONED BY (
edw_rec_end_yr STRING,
plan_yr STRING,
integration_prtnr STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.application_comments(
student_id STRING,
application_id STRING,
comment_type STRING,
appl_comments STRING,
access_ind STRING,
application_status STRING,
create_userid STRING,
create_date STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/application_comments'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.code_decode(
code STRING,
code_type STRING,
decode STRING,
status_ind STRING,
create_userid STRING,
create_date STRING,
update_userid STRING,
update_date STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/code_decode'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.colleges_master(
cop_code STRING,
cop_name STRING,
cop_status STRING,
cop_state STRING,
create_userid STRING,
create_date STRING,
update_userid STRING,
update_date STRING,
pharm_degree_type STRING,
pharm_degree_type_three STRING,
pharm_degree_type_six STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/colleges_master'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.dim_period_hr(
period_key BIGINT,
period_type STRING,
period_date DATE,
day_name STRING,
date_nbr BIGINT,
wk_start_date DATE,
wk_end_date DATE,
mnth_nbr INT,
mnth_name STRING,
mnth_start_date DATE,
mnth_end_date DATE,
mnth_start_work_date DATE,
mnth_end_work_date DATE,
calendar_year INT,
calendar_qtr INT,
calendar_mnth INT,
calendar_date DATE,
qtr_nbr INT,
fiscal_qtr INT,
fiscal_year INT,
fiscal_mnth INT,
fiscal_wk INT,
previous_qtr INT,
previous_mnth INT,
previous_wk INT,
previous_date INT,
end_of_wk_nbr INT,
end_of_working_wk INT,
current_qtr_cd INT,
current_dt DATE,
current_mnth INT,
holiday_type STRING,
holiday_desc STRING,
year_start_date DATE,
year_end_date DATE,
next_mnth DATE,
next_wk_date DATE,
next_working_day DATE,
next_working_date DATE,
wk_pay_start_date DATE,
wk_pay_end_date DATE,
mnth_pay_start_date DATE,
bi_wk_pay_end_date DATE,
bi_wk_pay_start_date DATE,
mnth_pay_end_date DATE,
pay_type STRING,
qtr_end_date DATE,
qtr_start_date DATE,
calendar_week INT,
previous_cal_year INT,
fiscal_mnth_start_date DATE,
fiscal_mnth_end_date DATE,
fiscal_qtr_start_date DATE,
fiscal_qtr_end_date DATE,
fiscal_year_start_date DATE,
fiscal_year_end_date DATE)
USING DELTA
LOCATION
'abfss://compensation-benefits-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_period_hr'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__employee_performance.performance_codes(
extract_date STRING,
reason STRING,
dimension_name STRING,
rating_name STRING,
rating_desc STRING,
rating_value STRING)
USING DELTA
LOCATION
'abfss://employee-performance-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/performance_codes'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__employee_performance.performance_rating(
performance_rating STRING,
performance_category STRING,
performance_level STRING,
performance_sub_level STRING)
USING DELTA
LOCATION
'abfss://employee-performance-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/performance_rating'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.dim_period_hr_stg(
period_key BIGINT,
period_type STRING,
period_date DATE,
day_name STRING,
date_nbr BIGINT,
wk_start_date DATE,
wk_end_date DATE,
mnth_nbr INT,
mnth_name STRING,
mnth_start_date DATE,
mnth_end_date DATE,
mnth_start_work_date DATE,
mnth_end_work_date DATE,
calendar_year INT,
calendar_qtr INT,
calendar_mnth INT,
calendar_date DATE,
qtr_nbr INT,
fiscal_qtr INT,
fiscal_year INT,
fiscal_mnth INT,
fiscal_wk INT,
previous_qtr INT,
previous_mnth INT,
previous_wk INT,
previous_date INT,
end_of_wk_nbr INT,
end_of_working_wk INT,
current_qtr_cd INT,
current_dt DATE,
current_mnth INT,
holiday_type STRING,
holiday_desc STRING,
year_start_date DATE,
year_end_date DATE,
next_mnth DATE,
next_wk_date DATE,
next_working_day DATE,
next_working_date DATE,
wk_pay_start_date DATE,
wk_pay_end_date DATE,
mnth_pay_start_date DATE,
bi_wk_pay_end_date DATE,
bi_wk_pay_start_date DATE,
mnth_pay_end_date DATE,
pay_type STRING,
qtr_end_date DATE,
qtr_start_date DATE,
calendar_week INT,
previous_cal_year INT,
fiscal_mnth_start_date DATE,
fiscal_mnth_end_date DATE,
fiscal_qtr_start_date DATE,
fiscal_qtr_end_date DATE,
fiscal_year_start_date DATE,
fiscal_year_end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/dim_period_hr_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.p3_tl_prescription_exception(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
exc_nbr DECIMAL(2,0),
fill_enter_tm STRING,
fill_enter_dt STRING,
fill_sold_dt STRING,
rx_create_dt STRING,
exc_reason_cd STRING,
exc_ccp_response STRING,
exc_cmt STRING,
exc_resolution_cd STRING,
exc_resolution_user_id DECIMAL(9,0),
exc_resolution_dttm STRING,
exc_critical_dttm STRING,
fill_del_ind STRING,
max_ldr_type_cd STRING,
max_ldr_type_sevr_cd STRING,
create_user_id DECIMAL(9,0),
refills_added STRING,
create_dttm STRING,
update_user_id DECIMAL(9,0),
update_user_dttm STRING,
prescribe_refills_added STRING,
prescribe_reply_cd STRING,
msg_cmts STRING,
prescribe_auth_id STRING,
exc_reason_update_dttm STRING,
cntc_by_cd STRING,
resubmit_dttm STRING,
sold_thrd_pty_rej_ind STRING,
exc_stat_cd STRING,
exc_stat_update_dttm STRING,
pbr_phone_cmts STRING,
em_select_ind STRING,
exc_sub_type_ind STRING,
emergency_qty DECIMAL(8,3),
equivalent_generic_copay_dlrs DECIMAL(7,2),
pbr_auth_full_name STRING,
msg_pbr_full_name STRING,
epa_stat STRING,
epa_reply_msg STRING,
workstation_locked_ip STRING,
last_actn_dttm STRING,
fax_image_id STRING,
tpr_stat_cd STRING,
tpr_assign_cd STRING,
tpr_stat_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
relocate_fm_str_nbr INT,
src_partition_nbr tinyint,
reh_resubmit_dttm STRING)
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/p3_tl_prescription_exception'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.patient_adherence_outreach_detail(
store_nbr INT,
pat_id DECIMAL(13,0),
rx_nbr INT,
drug_adherence_pctg INT,
drug_name STRING,
refills_remain_cnt INT,
third_party_plan_id STRING,
plan_group_nbr STRING,
fnl_disposition_stat STRING,
fnl_disposition_dt STRING,
intervention_month STRING,
src_load_dt STRING)
USING DELTA
LOCATION
'abfss://campaign-phi@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/patient_adherence_outreach_detail'
PARTITIONED BY (
src_catg_cd STRING,
call_type STRING,
idh_load_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.cmd_covid_waitlist_sup(
eml_addr STRING,
loyalty_mbr_id STRING,
src_id STRING,
src_cd STRING,
news_ltr_subscribe_ind STRING,
photo_subscribe_ind STRING,
spcl_off_subscribe_ind STRING,
wkly_ad_subscribe_ind STRING,
loyalty_subscribe_ind STRING,
sub_date DATE)
USING DELTA
LOCATION
'abfss://patient-services-pii@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/cmd_covid_waitlist_sup'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_external_source(
external_src_cd STRING,
desc STRING,
create_userid STRING,
create_dttm STRING,
update_userid STRING,
update_dttm STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/car_external_source'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_weekly_extract(
pat_id STRING,
include_cd STRING,
reserved STRING,
chain STRING,
store STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/car_weekly_extract'
PARTITIONED BY (
integration_prtnr STRING,
output_cmpgn_cd STRING,
last_run_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.covid19_waitlist_suppression(
eml_addr STRING,
update_date DATE)
USING DELTA
LOCATION
'abfss://patient-services-pii@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/covid19_waitlist_suppression'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.hist_car_vip_payer_non_demographic_data(
external_src_id STRING,
non_demo_attr STRING,
attr_val STRING,
metadata_val STRING,
edw_rec_begin_dt STRING,
edw_rec_end_dt STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_create_userid STRING,
edw_update_userid STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/hist_car_vip_payer_non_demographic_data'
PARTITIONED BY (
edw_rec_end_yr STRING,
plan_yr STRING,
integration_prtnr STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.hist_rx_uce_tt(
pat_id DECIMAL(13,0),
therapy STRING,
insight STRING,
run_dt STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/hist_rx_uce_tt'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.rx_uce_delta(
me_id STRING,
insight_name STRING,
value STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/rx_uce_delta'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.rx_sms_refill_info(
mongo_id STRING,
transaction_id STRING,
record_id STRING,
pat_id STRING,
phone_number STRING,
store_ph_no STRING,
create_dttm STRING,
update_dttm STRING,
first_name STRING,
last_name STRING,
dob_verified STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/rx_sms_refill_info'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.rx_uce_gov_plan(
pat_id DECIMAL(13,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/rx_uce_gov_plan'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_campaign_eligible(
external_src_id STRING,
non_demo_attr STRING,
attr_val STRING,
metadata_val STRING,
edw_rec_begin_dt STRING,
edw_rec_end_dt STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_create_userid STRING,
edw_update_userid STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/car_vip_payer_non_demographic_campaign_eligible'
PARTITIONED BY (
edw_rec_end_yr STRING,
plan_yr STRING,
integration_prtnr STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_diff1(
me_id STRING,
insight_name STRING,
value STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_diff1'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_diff2(
me_id STRING,
insight_name STRING,
value STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_diff2'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_fill(
pat_id DECIMAL(13,0),
first_fill_dt STRING,
last_fill_dt STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_fill'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_id(
me_id STRING,
loyalty_mbr_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_id'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_loyalty_mem_emp(
loyalty_mbr_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_loyalty_mem_emp'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_data(
external_src_id STRING,
non_demo_attr STRING,
attr_val STRING,
metadata_val STRING,
edw_rec_begin_dt STRING,
edw_rec_end_dt STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_create_userid STRING,
edw_update_userid STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/car_vip_payer_non_demographic_data'
PARTITIONED BY (
edw_rec_end_yr STRING,
plan_yr STRING,
integration_prtnr STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_meid_emp(
me_id STRING,
loyalty_mbr_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_meid_emp'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_pat_data(
me_id STRING,
therapy STRING,
insight STRING,
cnt BIGINT)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_pat_data'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_prod(
prod_sk BIGINT,
ops_dept_nbr DECIMAL(3,0),
timeframe INT)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_prod'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_prod2(
me_id STRING,
ops_dept_nbr DECIMAL(3,0),
times INT)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_prod2'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_insights_active(
me_id STRING,
insight_name STRING,
value STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_vip_payer_insights_active'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_insights_diff(
me_id STRING,
insight_name STRING,
value STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_vip_payer_insights_diff'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_insights_inactive(
me_id STRING,
insight_name STRING,
value STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_vip_payer_insights_inactive'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_non_demographic_campaign_eligible(
external_src_id STRING,
non_demo_attr STRING,
attr_val STRING,
metadata_val STRING,
edw_rec_begin_dt STRING,
edw_rec_end_dt STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_create_userid STRING,
edw_update_userid STRING,
edw_batch_id DECIMAL(18,0),
plan_yr STRING,
integration_prtnr STRING,
edw_rec_end_yr STRING,
pat_id STRING,
eid STRING,
cdi_composite_type_cd STRING,
cdi_msg_type_cd STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_vip_payer_non_demographic_campaign_eligible'""")
# COMMAND ----------
migration_data=[{"release": "8.0.1", "scripts": ["D.1.1.crt.partner_extracts__pharmacy_healthcare.sql", "D.12.1.crt.digital__ecom.sql", "D.5.1.crt.marketing__campaign.sql", "D.57.1.crt.hr__compensation_benefits.sql", "D.6.1.crt.pharmacy_healthcare__patient_services.sql", "D.64.1.crt.hr__employee_performance.sql", "D.3.1.crt.retail__promotions.sql", "D.71.1.wrg.hr__compensation_benefits.sql", "T.1.1.crt.car_campaign_target_patients.sql", "T.1118.1.crt.contact_hist_acap_reconcilaition.sql", "T.1119.1.crt.contact_hist_ora_reconcilaition.sql", "T.12.1.crt.car_vip_payer_non_demographic_mapping.sql", "T.14.1.crt.car_vip_payer_non_demographic_meid_insight.sql", "T.14438.1.crt.application_comments.sql", "T.14442.1.crt.code_decode.sql", "T.14443.1.crt.colleges_master.sql", "T.14449.1.crt.dim_period_hr.sql", "T.14546.1.crt.performance_codes.sql", "T.14547.1.crt.performance_rating.sql", "T.14645.1.wrg.dim_period_hr_stg.sql", "T.1551.1.crt.p3_tl_prescription_exception.sql", "T.1565.1.crt.patient_adherence_outreach_detail.sql", "T.196.1.crt.cmd_covid_waitlist_sup.sql", "T.2.1.crt.car_external_source.sql", "T.20.1.crt.car_weekly_extract.sql", "T.202.1.crt.covid19_waitlist_suppression.sql", "T.25.1.crt.hist_car_vip_payer_non_demographic_data.sql", "T.26.1.crt.hist_rx_uce_tt.sql", "T.34.1.crt.rx_uce_delta.sql", "T.347.1.crt.rx_sms_refill_info.sql", "T.38.1.crt.rx_uce_gov_plan.sql", "T.7.1.crt.car_vip_payer_non_demographic_campaign_eligible.sql", "T.74.1.crt.wrk_car_rx_uce_diff1.sql", "T.75.1.crt.wrk_car_rx_uce_diff2.sql", "T.76.1.crt.wrk_car_rx_uce_fill.sql", "T.77.1.crt.wrk_car_rx_uce_id.sql", "T.79.1.crt.wrk_car_rx_uce_loyalty_mem_emp.sql", "T.8.1.crt.car_vip_payer_non_demographic_data.sql", "T.80.1.crt.wrk_car_rx_uce_meid_emp.sql", "T.81.1.crt.wrk_car_rx_uce_pat_data.sql", "T.82.1.crt.wrk_car_rx_uce_prod.sql", "T.83.1.crt.wrk_car_rx_uce_prod2.sql", "T.90.1.crt.wrk_car_vip_payer_insights_active.sql", "T.91.1.crt.wrk_car_vip_payer_insights_diff.sql", "T.92.1.crt.wrk_car_vip_payer_insights_inactive.sql", "T.94.1.crt.wrk_car_vip_payer_non_demographic_campaign_eligible.sql", "T.117.1.crt.ad_event_type.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.0.1", "table_id": "T.1.1", "table_name": "car_campaign_target_patients", "table_schema": "partner_extracts__pharmacy_healthcare.car_campaign_target_patients", "table_legacy_schema": "acapcar.car_campaign_target_patients", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_campaign_target_patients", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.1118.1", "table_name": "contact_hist_acap_reconcilaition", "table_schema": "marketing__campaign.contact_hist_acap_reconcilaition", "table_legacy_schema": "dae_cooked.contact_hist_acap_reconcilaition", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.contact_hist_acap_reconcilaition", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.1119.1", "table_name": "contact_hist_ora_reconcilaition", "table_schema": "marketing__campaign.contact_hist_ora_reconcilaition", "table_legacy_schema": "dae_cooked.contact_hist_ora_reconcilaition", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.contact_hist_ora_reconcilaition", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.12.1", "table_name": "car_vip_payer_non_demographic_mapping", "table_schema": "partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_mapping", "table_legacy_schema": "acapcar.car_vip_payer_non_demographic_mapping", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_mapping", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.14.1", "table_name": "car_vip_payer_non_demographic_meid_insight", "table_schema": "partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_meid_insight", "table_legacy_schema": "acapcar.car_vip_payer_non_demographic_meid_insight", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_meid_insight", "table_partition": "\n  edw_rec_end_yr STRING, \n  plan_yr STRING, \n  integration_prtnr STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.14438.1", "table_name": "application_comments", "table_schema": "hr__compensation_benefits.application_comments", "table_legacy_schema": "hr_cooked.application_comments", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.application_comments", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.14442.1", "table_name": "code_decode", "table_schema": "hr__compensation_benefits.code_decode", "table_legacy_schema": "hr_cooked.code_decode", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.code_decode", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.14443.1", "table_name": "colleges_master", "table_schema": "hr__compensation_benefits.colleges_master", "table_legacy_schema": "hr_cooked.colleges_master", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.colleges_master", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.14449.1", "table_name": "dim_period_hr", "table_schema": "hr__compensation_benefits.dim_period_hr", "table_legacy_schema": "hr_cooked.dim_period", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.dim_period_hr", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.14546.1", "table_name": "performance_codes", "table_schema": "hr__employee_performance.performance_codes", "table_legacy_schema": "hr_cooked.performance_codes", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "hr__employee_performance.performance_codes", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "hr__employee_performance", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.14547.1", "table_name": "performance_rating", "table_schema": "hr__employee_performance.performance_rating", "table_legacy_schema": "hr_cooked.performance_rating", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "hr__employee_performance.performance_rating", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "hr__employee_performance", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.14645.1", "table_name": "dim_period_hr_stg", "table_schema": "staging__hr__compensation_benefits.dim_period_hr_stg", "table_legacy_schema": "hr_raw.dim_period", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.dim_period_hr_stg", "table_partition": "", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.1551.1", "table_name": "p3_tl_prescription_exception", "table_schema": "pharmacy_healthcare__patient_services.p3_tl_prescription_exception", "table_legacy_schema": "dae_cooked.p3_tl_prescription_exception", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.p3_tl_prescription_exception", "table_partition": "\n  fill_sold_yr STRING, \n  fill_enter_mnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.1565.1", "table_name": "patient_adherence_outreach_detail", "table_schema": "marketing__campaign.patient_adherence_outreach_detail", "table_legacy_schema": "dae_cooked.patient_adherence_outreach_detail", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.patient_adherence_outreach_detail", "table_partition": "\n  src_catg_cd STRING, \n  call_type STRING, \n  idh_load_dt STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.196.1", "table_name": "cmd_covid_waitlist_sup", "table_schema": "pharmacy_healthcare__patient_services.cmd_covid_waitlist_sup", "table_legacy_schema": "acapdb.cmd_covid_waitlist_sup", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.cmd_covid_waitlist_sup", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.2.1", "table_name": "car_external_source", "table_schema": "partner_extracts__pharmacy_healthcare.car_external_source", "table_legacy_schema": "acapcar.car_external_source", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_external_source", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.20.1", "table_name": "car_weekly_extract", "table_schema": "partner_extracts__pharmacy_healthcare.car_weekly_extract", "table_legacy_schema": "acapcar.car_weekly_extract", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_weekly_extract", "table_partition": "\n  integration_prtnr STRING, \n  output_cmpgn_cd STRING, \n  last_run_dt STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.202.1", "table_name": "covid19_waitlist_suppression", "table_schema": "pharmacy_healthcare__patient_services.covid19_waitlist_suppression", "table_legacy_schema": "acapdb.covid19_waitlist_suppression", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.covid19_waitlist_suppression", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.25.1", "table_name": "hist_car_vip_payer_non_demographic_data", "table_schema": "partner_extracts__pharmacy_healthcare.hist_car_vip_payer_non_demographic_data", "table_legacy_schema": "acapcar.hist_car_vip_payer_non_demographic_data", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.hist_car_vip_payer_non_demographic_data", "table_partition": "\n  edw_rec_end_yr STRING, \n  plan_yr STRING, \n  integration_prtnr STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.26.1", "table_name": "hist_rx_uce_tt", "table_schema": "partner_extracts__pharmacy_healthcare.hist_rx_uce_tt", "table_legacy_schema": "acapcar.hist_rx_uce_tt", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.hist_rx_uce_tt", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.34.1", "table_name": "rx_uce_delta", "table_schema": "partner_extracts__pharmacy_healthcare.rx_uce_delta", "table_legacy_schema": "acapcar.rx_uce_delta", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.rx_uce_delta", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.347.1", "table_name": "rx_sms_refill_info", "table_schema": "digital__ecom.rx_sms_refill_info", "table_legacy_schema": "acapdb.rx_sms_refill_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.rx_sms_refill_info", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.38.1", "table_name": "rx_uce_gov_plan", "table_schema": "partner_extracts__pharmacy_healthcare.rx_uce_gov_plan", "table_legacy_schema": "acapcar.rx_uce_gov_plan", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.rx_uce_gov_plan", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.7.1", "table_name": "car_vip_payer_non_demographic_campaign_eligible", "table_schema": "partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_campaign_eligible", "table_legacy_schema": "acapcar.car_vip_payer_non_demographic_campaign_eligible", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_campaign_eligible", "table_partition": "\n  edw_rec_end_yr STRING, \n  plan_yr STRING, \n  integration_prtnr STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.74.1", "table_name": "wrk_car_rx_uce_diff1", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_diff1", "table_legacy_schema": "acapcar.wrk_car_rx_uce_diff1", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_diff1", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.75.1", "table_name": "wrk_car_rx_uce_diff2", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_diff2", "table_legacy_schema": "acapcar.wrk_car_rx_uce_diff2", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_diff2", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.76.1", "table_name": "wrk_car_rx_uce_fill", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_fill", "table_legacy_schema": "acapcar.wrk_car_rx_uce_fill", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_fill", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.77.1", "table_name": "wrk_car_rx_uce_id", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_id", "table_legacy_schema": "acapcar.wrk_car_rx_uce_id", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_id", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.79.1", "table_name": "wrk_car_rx_uce_loyalty_mem_emp", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_loyalty_mem_emp", "table_legacy_schema": "acapcar.wrk_car_rx_uce_loyalty_mem_emp", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_loyalty_mem_emp", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.8.1", "table_name": "car_vip_payer_non_demographic_data", "table_schema": "partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_data", "table_legacy_schema": "acapcar.car_vip_payer_non_demographic_data", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.car_vip_payer_non_demographic_data", "table_partition": "\n  edw_rec_end_yr STRING, \n  plan_yr STRING, \n  integration_prtnr STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.80.1", "table_name": "wrk_car_rx_uce_meid_emp", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_meid_emp", "table_legacy_schema": "acapcar.wrk_car_rx_uce_meid_emp", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_meid_emp", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.81.1", "table_name": "wrk_car_rx_uce_pat_data", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_pat_data", "table_legacy_schema": "acapcar.wrk_car_rx_uce_pat_data", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_pat_data", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.82.1", "table_name": "wrk_car_rx_uce_prod", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_prod", "table_legacy_schema": "acapcar.wrk_car_rx_uce_prod", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_prod", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.83.1", "table_name": "wrk_car_rx_uce_prod2", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_prod2", "table_legacy_schema": "acapcar.wrk_car_rx_uce_prod2", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_prod2", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.90.1", "table_name": "wrk_car_vip_payer_insights_active", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_insights_active", "table_legacy_schema": "acapcar.wrk_car_vip_payer_insights_active", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_insights_active", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.91.1", "table_name": "wrk_car_vip_payer_insights_diff", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_insights_diff", "table_legacy_schema": "acapcar.wrk_car_vip_payer_insights_diff", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_insights_diff", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.92.1", "table_name": "wrk_car_vip_payer_insights_inactive", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_insights_inactive", "table_legacy_schema": "acapcar.wrk_car_vip_payer_insights_inactive", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_insights_inactive", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.94.1", "table_name": "wrk_car_vip_payer_non_demographic_campaign_eligible", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_non_demographic_campaign_eligible", "table_legacy_schema": "acapcar.wrk_car_vip_payer_non_demographic_campaign_eligible", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_vip_payer_non_demographic_campaign_eligible", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.0.1", "table_id": "T.117.1", "table_name": "ad_event_type", "table_schema": "retail__promotions.ad_event_type", "table_legacy_schema": "acapdb.ad_event_type", "table_domain": "retail", "table_subdomain": "promotions", "table_location": "retail__promotions.ad_event_type", "table_partition": "", "table_db": "retail__promotions", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

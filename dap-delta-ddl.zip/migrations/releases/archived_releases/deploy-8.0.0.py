# Databricks notebook source 
dbutils.widgets.text(name='partner_extracts_crt_sa', defaultValue='${partner_extracts_crt_sa}', label='partner_extracts_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_digital', defaultValue='${STORAGE_ACCT_crt_digital}', label='STORAGE_ACCT_crt_digital')
dbutils.widgets.text(name='STORAGE_ACCT_crt_supply_chain', defaultValue='${STORAGE_ACCT_crt_supply_chain}', label='STORAGE_ACCT_crt_supply_chain')
dbutils.widgets.text(name='digital_crt_sa', defaultValue='${digital_crt_sa}', label='digital_crt_sa')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_master_data', defaultValue='${STORAGE_ACCT_crt_master_data}', label='STORAGE_ACCT_crt_master_data')
dbutils.widgets.text(name='marketing_crt_sa', defaultValue='${marketing_crt_sa}', label='marketing_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='hr_crt_sa', defaultValue='${hr_crt_sa}', label='hr_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
dbutils.widgets.text(name='master_data_crt_sa', defaultValue='${master_data_crt_sa}', label='master_data_crt_sa')
dbutils.widgets.text(name='retail_crt_sa', defaultValue='${retail_crt_sa}', label='retail_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_partner_extracts', defaultValue='${STORAGE_ACCT_crt_partner_extracts}', label='STORAGE_ACCT_crt_partner_extracts')
# COMMAND ----------
%sql
DROP TABLE IF EXISTS retail__ccpa.ccpa_customer_extracts_activity;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_customer_extracts_activity", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_retail')}.dfs.core.windows.net/retail/ccpa/ccpa_customer_extracts_activity", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__ccpa.ccpa_customer_extracts_activity(
cust_src_id STRING,
extract_info STRING,
create_dttm STRING)
USING DELTA
LOCATION
'abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_customer_extracts_activity'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS retail__ccpa.ccpa_email_rtd_log;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_email_rtd_log", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_retail')}.dfs.core.windows.net/retail/ccpa/ccpa_email_rtd_log", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__ccpa.ccpa_email_rtd_log(
tkt_nbr STRING,
db_name STRING,
tbl_name STRING,
del_rec_cnt INT,
stat_cd STRING,
idh_update_dttm STRING)
USING DELTA
LOCATION
'abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_email_rtd_log'
PARTITIONED BY (
idh_batch_id DECIMAL(18,0))""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS master_data__customer.ccpa_rtd_log;
-- DROP TABLE IF EXISTS retail__ccpa.ccpa_rtd_log;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_rtd_log", recurse=True)
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_master_data')}.dfs.core.windows.net/master_data/customer/ccpa_rtd_log", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__ccpa.ccpa_rtd_log(
tkt_nbr STRING,
tkt_open_dt DATE,
reqst_type_cd STRING,
tkt_line_seq INT,
db_name STRING,
tbl_name STRING,
subject_area STRING,
del_rec_cnt INT,
rec_del_dt DATE,
stat_cd STRING,
idh_update_dttm STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_rtd_log'
PARTITIONED BY (
idh_create_dttm STRING)""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS marketing__campaign.cmg_satr_eligibility;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://campaign-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/cmg_satr_eligibility", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/cmg_satr_eligibility", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.cmg_satr_eligibility(
pat_id DECIMAL(13,0),
rx_count INT,
str_nbr INT,
create_dt DATE,
fill_sold_dt DATE)
USING DELTA
LOCATION
'abfss://campaign-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/cmg_satr_eligibility'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS marketing__campaign.contact_hist_acap_reconcilaition;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/contact_hist_acap_reconcilaition", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/contact_hist_acap_reconcilaition", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.contact_hist_acap_reconcilaition(
day_dt STRING,
per_id STRING,
contact_date STRING,
planned_contact_date STRING,
campaigncode STRING,
channel_cd STRING,
packageid STRING,
cell_id STRING,
offer_cd STRING,
treatment_id STRING,
contact_status_id STRING,
count_val STRING,
file_dttm STRING)
USING DELTA
LOCATION
'abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/contact_hist_acap_reconcilaition'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS marketing__campaign.contact_hist_ora_reconcilaition;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/contact_hist_ora_reconcilaition", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/contact_hist_ora_reconcilaition", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.contact_hist_ora_reconcilaition(
batch_dttm STRING,
contactdatetime STRING,
planned_contact_date STRING,
campaign_cd STRING,
channel_cd STRING,
packageid STRING,
cellid STRING,
offer_cd STRING,
treatment_id DECIMAL(19,0),
treatment_cd STRING,
contactstatusid STRING,
count STRING,
file_dttm STRING)
USING DELTA
LOCATION
'abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/contact_hist_ora_reconcilaition'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS hr__lookup_codes.dim_cd;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://lookup-codes-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_cd", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_hr')}.dfs.core.windows.net/hr/lookup_codes/dim_cd", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__lookup_codes.dim_cd(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://lookup-codes-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_cd'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS hr__lookup_codes.dim_cd_lookup;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://lookup-codes-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_cd_lookup", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_hr')}.dfs.core.windows.net/hr/lookup_codes/dim_cd_lookup", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__lookup_codes.dim_cd_lookup(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://lookup-codes-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_cd_lookup'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS hr__recruiting.dim_school;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://recruiting-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_school", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_hr')}.dfs.core.windows.net/hr/recruiting/dim_school", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__recruiting.dim_school(
school_key BIGINT,
school_name STRING,
school_cd STRING,
school_type STRING,
school_address1 STRING,
school_address2 STRING,
school_zip STRING,
school_city STRING,
school_state STRING,
school_email STRING,
school_phone1 STRING,
school_contact STRING,
school_fax STRING)
USING DELTA
LOCATION
'abfss://recruiting-bussnstv@{getArgument('hr_crt_sa')}.dfs.core.windows.net/dim_school'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS hr__compensation_benefits.employee_xref;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/employee_xref", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_hr')}.dfs.core.windows.net/hr/compensation_benefits/employee_xref", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.employee_xref(
employee_id STRING,
biographical_created_by STRING,
biographical_created_on DATE,
legacy_emp_id STRING,
date_of_birth DATE,
biographical_last_modified_by STRING,
biographical_last_modified_on DATE,
biographical_portlet_name STRING,
biographical_update_flag STRING,
personal_start_date DATE,
birth_name STRING,
personal_created_by STRING,
personal_created_on DATE,
display_name STRING,
personal_end_date DATE,
first_name STRING,
first_name_alt1 STRING,
gender STRING,
personal_last_modified_by STRING,
personal_last_modified_on DATE,
last_name STRING,
last_name_alt1 STRING,
marital_status STRING,
middle_name_initials STRING,
middle_name_alt1 STRING,
nationality STRING,
native_preferred_language STRING,
salutation STRING,
suffix STRING,
personal_portlet_name STRING,
personal_update_flag STRING,
race_ethnicity STRING,
veteran_status STRING,
disability_status_from_form_cc305 STRING,
employees_name_given_in_form_cc305 STRING,
submission_date_of_form_cc305 DATE,
card_type STRING,
national_id_country STRING,
national_id_created_by STRING,
national_id_created_on DATE,
national_id_primary STRING,
national_id_last_modified_by STRING,
national_id_last_modified_on DATE,
national_id STRING,
national_id_portlet_name STRING,
national_id_update_flag STRING,
email_type STRING,
email_update_flag STRING,
email_created_by STRING,
email_created_on DATE,
email_address STRING,
email_is_primary STRING,
email_last_modified_by STRING,
email_last_modified_on DATE,
phone_type STRING,
phone_update_flag STRING,
phone_area_code STRING,
phone_country_code STRING,
phone_created_by STRING,
phone_created_on DATE,
phone_extension STRING,
phone_is_primary STRING,
phone_last_modified_by STRING,
phone_last_modified_on DATE,
phone_number STRING,
employment_hire_created_by STRING,
employment_hire_created_on DATE,
employment_hire_last_modified_by STRING,
employment_hire_last_modified_on DATE,
original_start_date DATE,
service_date DATE,
employment_hire_start_date DATE,
employment_hire_portlet_name STRING,
employment_hire_update_flag STRING,
requisition_number STRING,
recent_hire_date DATE,
legal_hold_date DATE,
employment_term_end_date DATE,
employment_term_created_by STRING,
employment_term_created_on DATE,
employment_term_event_reason STRING,
last_date_worked DATE,
employment_term_last_modified_by STRING,
employment_term_last_modified_on DATE,
new_main_employment_id STRING,
ok_to_rehire STRING,
employment_term_payroll_end_date DATE,
employment_term_portlet_name STRING,
employment_term_update_flag STRING,
date_of_death DATE,
manager_id STRING,
manager_ind STRING,
manager_first_name STRING,
manager_middle_name_initials STRING,
manager_last_name STRING,
avg_52wk_hrs STRING,
avg_12wk_hrs STRING,
bonus_amt DECIMAL(11,2),
bonus_year STRING)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/employee_xref'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS hr__payroll.fct_payroll_details;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://payroll-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fct_payroll_details", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_hr')}.dfs.core.windows.net/hr/payroll/fct_payroll_details", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__payroll.fct_payroll_details(
emp_id DECIMAL(11,0),
cost_center STRING,
org_key STRING,
period_key BIGINT,
cd_key BIGINT,
pos STRING,
loc STRING,
business_unit STRING,
dept STRING,
division STRING,
job_title STRING,
line_of_business STRING,
loc_type_cd STRING,
charged_payr_loc_key STRING,
ck_nbr STRING,
prcs_dt STRING,
batch_dt STRING,
wek_nbr DECIMAL(2,0),
pos_start_dt STRING,
payr_amt DECIMAL(21,2),
flng_mrtl_stat STRING,
fed_exempt DECIMAL(2,0),
state_exempts DECIMAL(2,0),
slry_rate DECIMAL(11,2),
hrly_rate DECIMAL(11,6),
direct_dpst_ind STRING,
acct_cd DECIMAL(4,0),
register_type STRING,
bank_nbr DECIMAL(3,0),
comments STRING,
case_nbr STRING,
state_num_taxed DECIMAL(2,0),
city_num_taxed DECIMAL(2,0),
rsdnt_state_tax_ind STRING,
rsdnt_city_tax_ind STRING,
local_cd STRING,
state_cd DECIMAL(2,0),
corp_cd DECIMAL(4,0),
rsdnt_local_cd DECIMAL(4,0),
rsdnt_state_cd DECIMAL(2,0),
avg_52wk_hrs DECIMAL(5,2),
avg_12wk_hrs DECIMAL(5,2),
reglr_hrs DECIMAL(5,2),
overtime_hrs DECIMAL(5,2),
scheduled_hrs DECIMAL(5,2),
gross_pay_amt DECIMAL(11,2),
net_pay_amt DECIMAL(11,2),
taxable_gross_amt DECIMAL(11,2),
federal_gross_amt DECIMAL(11,2),
state_tax_amt DECIMAL(11,2),
local_tax_amt DECIMAL(11,2),
special_local_tax_amt DECIMAL(11,2),
fica_amt DECIMAL(11,2),
medicare_amt DECIMAL(11,2),
rsdnt_state_tax_amt DECIMAL(11,2),
rsdnt_local_tax_amt DECIMAL(11,2),
dsab_tax_amt DECIMAL(11,2),
overtime1_prem_pay_amt DECIMAL(11,2),
overtime2_prem_pay_amt DECIMAL(11,2),
calc_gross_earnings_amt DECIMAL(11,2),
neg_adj_amt DECIMAL(11,2),
tot_manual_earnings_amt DECIMAL(11,2),
corporate_medical_tax_amt DECIMAL(11,2),
employer_fica_tax_amt DECIMAL(11,2),
sut_tax_amt DECIMAL(11,2),
fut_tax_amt DECIMAL(11,2),
st_txbl_wages_amt DECIMAL(11,2),
earnings_hours DOUBLE,
emp_rec_id DECIMAL(15,0),
acc_year STRING,
acc_month STRING)
USING DELTA
LOCATION
'abfss://payroll-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fct_payroll_details'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS hr__compensation_benefits.fct_scholarship_details;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fct_scholarship_details", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_hr')}.dfs.core.windows.net/hr/compensation_benefits/fct_scholarship_details", recurse=True)

# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.fct_scholarship_details(
school_key BIGINT,
payment_type STRING,
scholarship_award_type STRING,
period_key BIGINT,
application_id BIGINT,
employee_id BIGINT,
scholarship_desc STRING,
check_nbr STRING,
check_amt DECIMAL(7,2),
check_status STRING,
relinquishment_amt DECIMAL(9,2),
corp_monies_charged DECIMAL(7,2),
district_monies_charged DECIMAL(7,2),
budget_credit_amt DECIMAL(7,2),
location STRING,
position STRING,
status_date DATE,
cd_key BIGINT,
scholarship_year INT,
award_nbr INT,
scholarship_comments_ind STRING,
school_phone_nbr STRING,
expect_grad_year DATE,
pharmacy_assoc_1 STRING,
scholarship_eligibility_status STRING,
stay_through_date DATE)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/fct_scholarship_details'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS hr__employee_performance.latest_performance_rating;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://employee-performance-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/latest_performance_rating", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_hr')}.dfs.core.windows.net/hr/employee_performance/latest_performance_rating", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__employee_performance.latest_performance_rating(
employee_id STRING,
latest_employee_acknowledgement STRING,
latest_location_when_rated STRING,
latest_mgr_acknowledgement STRING,
latest_overall_rating STRING,
latest_overall_rating_desc STRING,
latest_position_when_rated STRING,
latest_rating_period_start_date DATE,
latest_rating_period_end_date DATE,
latest_reviewed_by_employee_id STRING,
latest_reviewer_first_name STRING,
latest_reviewer_middle_name STRING,
latest_reviewer_last_name STRING,
latest_review_type STRING,
previous_year_overall_rating STRING,
previous_year_overall_rating_desc STRING,
previous_year_rating_period_start_date DATE,
previous_year_rating_period_end_date DATE,
previous_2_year_overall_rating STRING,
previous_2_year_overall_rating_desc STRING,
previous_2_year_rating_period_start_date DATE,
previous_2_year_rating_period_end_date DATE,
latest_promotion_rating STRING,
latest_promotion_rating_desc STRING)
USING DELTA
LOCATION
'abfss://employee-performance-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/latest_performance_rating'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS marketing__campaign.patient_adherence_outreach_detail;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://campaign-phi@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/patient_adherence_outreach_detail", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/patient_adherence_outreach_detail", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.patient_adherence_outreach_detail(
store_nbr INT,
pat_id DECIMAL(13,0),
rx_nbr INT,
drug_adherence_pctg INT,
drug_name STRING,
refills_remain_cnt INT,
third_party_plan_id STRING,
plan_group_nbr STRING,
fnl_disposition_stat STRING,
fnl_disposition_dt STRING,
intervention_month STRING,
src_load_dt STRING)
USING DELTA
LOCATION
'abfss://campaign-phi@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/patient_adherence_outreach_detail'
PARTITIONED BY (
src_catg_cd STRING,
call_type STRING,
idh_load_dt STRING)""")
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM supply_chain__fleet_transportation_management.dispatcharc_c;
VACUUM supply_chain__fleet_transportation_management.dispatcharc_c RETAIN 0 HOURS;
DROP TABLE supply_chain__fleet_transportation_management.dispatcharc_c;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_supply_chain')}.dfs.core.windows.net/supply_chain/fleet_transportation_management/dispatcharc_c", recurse=True)
# COMMAND ----------
if 'dapuat' not in getArgument('STORAGE_ACCT_crt_master_data'):
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")
    spark.sql("DELETE FROM pharmacy_healthcare__patient_services.prescription")
    spark.sql("VACUUM pharmacy_healthcare__patient_services.prescription RETAIN 0 HOURS")
    spark.sql("DROP TABLE pharmacy_healthcare__patient_services.prescription")
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = True")
    dbutils.fs.rm(f"abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription(
cdc_txn_commit_dttm TIMESTAMP,
rx_nbr DECIMAL(38,0),
str_nbr DECIMAL(38,0),
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_create_tm STRING,
pat_id DECIMAL(13,0) ,
pbr_id DECIMAL(11,0) ,
pbr_loc_id SMALLINT ,
pbr_ord_nbr STRING ,
drug_id DECIMAL(38,0) ,
dea_class_cd STRING ,
drug_non_sys_cd STRING ,
drug_non_sys_name STRING ,
drug_non_sys_assign_ndc STRING ,
drug_non_sys_mfgr_name STRING ,
drug_sub_cd STRING ,
ord_drug_id DECIMAL(38,0) ,
generic_substn_pref_ind STRING ,
fill_unlimited_ind STRING ,
fill_qty_dispensed DECIMAL(8,3) ,
fill_days_supply SMALLINT ,
rx_daw_cd STRING ,
rx_daw_ind STRING ,
rx_sig STRING ,
rx_stat_cd STRING ,
rx_tot_dspn_qty DECIMAL(10,3) ,
rx_written_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_written_tm STRING,
rx_orig_fill_dttm TIMESTAMP,
rx_added_qty DECIMAL(8,3) ,
rx_refill_expire_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_refill_expire_tm STRING,
rx_cmnt STRING ,
fill_nbr_prescribed SMALLINT ,
fill_nbr_dspn SMALLINT ,
fill_nbr_added SMALLINT ,
fill_auto_ind STRING ,
fill_nbr_last_disp SMALLINT ,
fill_entered_dttm TIMESTAMP,
image_id STRING ,
scan_user_id DECIMAL(9,0) ,
scan_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
scan_tm STRING,
scan_str_nbr DECIMAL(38,0) ,
tip_rx_ind STRING ,
route_str_nbr DECIMAL(38,0) ,
priced_as_nonsys_ind STRING ,
wag_inv_ctrl_nbr DECIMAL(38,0) ,
relocate_fm_str_nbr DECIMAL(38,0) ,
create_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
update_user_id DECIMAL(9,0),
update_dttm TIMESTAMP,
rx_orig_qty_dspn DECIMAL(8,3) ,
rx_orig_days_supply SMALLINT ,
rx_orig_qty DECIMAL(8,3),
src_partition_nbr TINYINT ,
diagnosis_cd_1 STRING ,
diagnosis_cd_2 STRING ,
diagnosis_cd_3 STRING ,
diagnosis_cd_4 STRING ,
diagnosis_cd_qlfr STRING ,
origin_cd STRING ,
rx_pad_barcode STRING ,
rx_pad_prgm_ind STRING ,
rx_vacc_mfg_lot_nbr STRING ,
rx_vacc_exp_dttm TIMESTAMP,
rx_vacc_area_of_admin STRING ,
rx_vacc_consent_ind STRING ,
rx_vacc_pnl_ent_dttm TIMESTAMP,
rx_vacc_pnl_status_cd STRING ,
drug_cmpnd_type_cd STRING ,
rx_90day_ind STRING ,
rx_90day_dttm TIMESTAMP,
rx_90day_stat_cd STRING ,
rx_90day_stat_dttm TIMESTAMP,
dosage_form_cd STRING ,
pbr_dea_nbr STRING ,
pbr_dea_suffix STRING ,
buyout_rx_cd STRING ,
diagnosis_cd_5 STRING ,
diagnosis_cd_qlfr_2 STRING ,
diagnosis_cd_qlfr_3 STRING ,
diagnosis_cd_qlfr_4 STRING ,
diagnosis_cd_qlfr_5 STRING ,
trmt_type_cd STRING,
fill_adv_rfl_opt_ind STRING,
fill_adv_rfl_opt_dttm STRING,
rx_vacc_info_race STRING,
rx_vacc_info_ethnicity STRING,
rx_vacc_info_comorbidity STRING
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription'
PARTITIONED BY (
rx_create_yr STRING,
rx_create_mnth STRING)""")
# COMMAND ----------
if 'dapuat' not in getArgument('STORAGE_ACCT_crt_master_data'):
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")
    spark.sql("DELETE FROM pharmacy_healthcare__patient_services.prescription_consult_adhoc")
    spark.sql("VACUUM pharmacy_healthcare__patient_services.prescription_consult_adhoc RETAIN 0 HOURS")
    spark.sql("DROP TABLE pharmacy_healthcare__patient_services.prescription_consult_adhoc")
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = True")
    dbutils.fs.rm(f"abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_consult_adhoc", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_consult_adhoc(
rx_nbr DECIMAL(38,0),
str_nbr DECIMAL(38,0),
rx_fill_nbr DECIMAL(38,0) ,
rx_partial_fill_nbr DECIMAL(38,0) ,
consult_adhoc_create_dttm TIMESTAMP,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
fill_enter_tm STRING,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
dspn_fill_nbr SMALLINT ,
adhoc_consult_rslv_rph_intl STRING ,
adhoc_consult_rslv_dttm TIMESTAMP,
adhoc_consult_rslv_cmnts STRING ,
adhoc_consult_rslv_rph_user_id DECIMAL(9,0),
src_create_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
edw_gg_commit_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
relocate_fm_str_nbr DECIMAL(38,0)
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_consult_adhoc'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_yrmnth STRING)""")
# COMMAND ----------
if 'dapuat' not in getArgument('STORAGE_ACCT_crt_master_data'):
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")
    spark.sql("DELETE FROM pharmacy_healthcare__patient_services.prescription_sdl")
    spark.sql("VACUUM pharmacy_healthcare__patient_services.prescription_sdl RETAIN 0 HOURS")
    spark.sql("DROP TABLE pharmacy_healthcare__patient_services.prescription_sdl")
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = True")
    dbutils.fs.rm(f"abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_sdl", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_sdl(
rx_nbr DECIMAL(38,0),
str_nbr DECIMAL(38,0),
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
rx_fill_nbr DECIMAL(38,0) ,
rx_partial_fill_nbr DECIMAL(38,0) ,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
fill_enter_tm STRING,
sdl_msg_id STRING ,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
pat_id DECIMAL(13,0),
fill_qty_dspn DECIMAL(8,3) ,
fill_days_supply DECIMAL(3,0) ,
fill_nbr_dspn DECIMAL(3,0) ,
drug_name STRING ,
drug_ndc_nbr STRING ,
rx_written_dttm TIMESTAMP,
general_pbr_nbr STRING ,
submit_user_id DECIMAL(9,0),
submit_dttm TIMESTAMP,
plan_id STRING ,
plan_group_nbr STRING ,
general_recipient_nbr STRING ,
prior_auth_cd STRING ,
prior_auth_nbr STRING ,
rx_deny_override_cd STRING ,
elig_override_cd STRING ,
diagnosis_cd STRING ,
pay_cd STRING ,
dl_proc_msg STRING ,
dl_additional_msg STRING ,
dur_conflict_cd STRING ,
dur_intervention_cd STRING ,
dur_outcome_cd STRING ,
other_payr_reject_cd STRING ,
other_cover_cd DECIMAL(2,0) ,
other_payr_cvrg_type STRING ,
plan_other_amt_paid_type STRING ,
plan_other_amt_paid DECIMAL(8,2) ,
other_payr_id STRING ,
other_payr_id_qlfr STRING ,
first_provider_paid_dlrs DECIMAL(8,2) ,
plan_tot_paid_dlrs DECIMAL(8,2) ,
plan_returnd_cost_dlrs DECIMAL(8,2) ,
plan_returnd_fee_dlrs DECIMAL(8,2) ,
plan_incentive_paid_dlrs DECIMAL(8,2) ,
fill_rtl_price_dlrs DECIMAL(8,2) ,
pat_rem_ded_dlrs DECIMAL(8,2) ,
pat_rem_ben_dlrs DECIMAL(8,2) ,
pat_acc_ded_dlrs DECIMAL(8,2) ,
pat_ded_apply_dlrs DECIMAL(8,2) ,
fill_del_adjud_cd STRING ,
fill_adjud_cd STRING ,
claim_ref_nbr STRING ,
plan_returnd_copay_dlrs DECIMAL(8,2) ,
plan_returnd_tax_dlrs DECIMAL(8,2) ,
fill_sold_dlrs DECIMAL(8,2) ,
sales_adj_cd STRING ,
rx_daw_ind STRING ,
claim_reversal_ind STRING ,
edw_batch_id DECIMAL(18,0) ,
relocate_fm_str_nbr DECIMAL(38,0),
src_partition_nbr TINYINT ,
place_of_service_cd DECIMAL(2,0) ,
rx_deny_override_2_cd STRING ,
rx_deny_override_3_cd STRING ,
delay_reason_cd DECIMAL(2,0) ,
return_plan_group_nbr STRING ,
return_third_party_plan_id STRING ,
covered_mbr_network_id STRING ,
prcs_fee_collect_dlrs DECIMAL(8,2) ,
provider_network_collect_dlrs DECIMAL(8,2) ,
brand_drug_collect_dlrs DECIMAL(8,2) ,
npref_form_collect_dlrs DECIMAL(8,2) ,
coverage_gap_collect_dlrs DECIMAL(8,2) ,
plan_fund_asst_dlrs DECIMAL(8,2) ,
third_party_ingrd_cont_dlrs DECIMAL(8,2) ,
third_party_disp_cont_fee_dlrs DECIMAL(8,2) ,
plan_sales_tax_dlrs DECIMAL(8,2) ,
pat_sales_tax_dlrs DECIMAL(8,2) ,
other_payr_recognize_dlrs DECIMAL(8,2) ,
benefit_stg_deduct_dlrs DECIMAL(8,2) ,
benefit_stg_initial_cvrg_dlrs DECIMAL(8,2) ,
benefit_stg_coverage_gap_dlrs DECIMAL(8,2) ,
benefit_stg_catastrophic_dlrs DECIMAL(8,2) ,
plan_return_coinsure_dlrs DECIMAL(8,2) ,
plan_other_amt_paid_2_type STRING ,
plan_other_amt_paid_3_type STRING ,
plan_other_amt_2_paid DECIMAL(8,2) ,
plan_other_amt_3_paid DECIMAL(8,2) ,
phrm_service_type_cd DECIMAL(2,0) ,
brand_npref_form_collect_dlrs DECIMAL(8,2) ,
ingrd_cost_pd_rmb_calc_meth_cd STRING ,
return_copay_dlrs DECIMAL(8,2) ,
plan_incent_submtd_dlrs DECIMAL(8,2) ,
plan_gross_due_dlrs DECIMAL(8,2) ,
benefit_stg_1_amt DECIMAL(8,2),
benefit_stg_1_qlfr_cd STRING ,
benefit_stg_2_amt DECIMAL(8,2),
benefit_stg_2_qlfr_cd STRING ,
benefit_stg_3_amt DECIMAL(8,2),
benefit_stg_3_qlfr_cd STRING ,
benefit_stg_4_amt DECIMAL(8,2),
benefit_stg_4_qlfr_cd STRING ,
coupon_ind STRING ,
coupon_drug_id DECIMAL(38,0),
sdl_type_cd SMALLINT
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_sdl'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_yrmnth STRING)""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS master_data__product.product_hierarchy;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://product-bussnstv@{getArgument('master_data_crt_sa')}.dfs.core.windows.net/product_hierarchy", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_master_data')}.dfs.core.windows.net/master_data/product/product_hierarchy", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS master_data__product.product_hierarchy(
prod_hierarchy_chng_sk BIGINT COMMENT 'product_hierarchy_change_sk',
prod_sk BIGINT COMMENT 'product sk',
src_sys_prod_id_1 STRING COMMENT 'source system product id 1',
src_sys_prod_id_2 STRING COMMENT 'source system product id 2',
src_sys_prod_id_3 STRING COMMENT 'source system product id 3',
src_sys_prod_id_4 STRING COMMENT 'source system product id 4',
src_sys_cd STRING COMMENT 'source system code',
edw_rec_end_dt DATE COMMENT 'record end date{{"FORMAT":"YYYY-MM-DD" }}',
edw_rec_begin_dt DATE COMMENT 'record begin date{{"FORMAT":"YYYY-MM-DD" }}',
pln_nbr DECIMAL(14,0) COMMENT 'pln_nbr',
pln_desc STRING COMMENT 'pln_desc',
core_prod_ind STRING COMMENT 'core_prod_ind',
pln_prod_id DECIMAL(8,0) COMMENT 'pln product identifier',
pln_home_bd_nbr DECIMAL(4,0) COMMENT 'pln_home_bd_nbr',
pln_home_bd_desc STRING COMMENT 'pln_home_bd_desc',
prod_cat_nbr DECIMAL(6,0) COMMENT 'prod_cat_nbr',
prod_cat_name STRING COMMENT 'prod_cat_name',
prod_cat_id DECIMAL(8,0) COMMENT 'prod_cat_id',
ops_dept_nbr DECIMAL(3,0) COMMENT 'ops_dept_nbr',
ops_dept_name STRING COMMENT 'ops_dept_name',
ops_dept_prod_id DECIMAL(8,0) COMMENT 'ops department product identifier',
ops_dept_buyer_nbr DECIMAL(3,0) COMMENT 'ops_dept_buyer_nbr',
ops_dept_buyer_name STRING COMMENT 'ops_dept_buyer_name',
mdse_cat_nbr DECIMAL(3,0) COMMENT 'mdse_cat_nbr',
mdse_cat_name STRING COMMENT 'mdse_cat_name',
mdse_catg_prod_id DECIMAL(8,0) COMMENT 'merchandise category product identifier',
mktg_mdse_div_nbr DECIMAL(3,0) COMMENT 'mktg_mdse_div_nbr',
mktg_mdse_div_name STRING COMMENT 'mktg_mdse_div_name',
mdse_div_nbr DECIMAL(3,0) COMMENT 'mdse_div_nbr',
mdse_div_name STRING COMMENT 'mdse_div_name',
mdse_div_prod_id DECIMAL(8,0) COMMENT 'merchandise division product identifier',
sls_cat_name STRING COMMENT 'sls_cat_name',
sls_cat_prod_id DECIMAL(8,0) COMMENT 'sls_cat_prod_id',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://product-bussnstv@{getArgument('master_data_crt_sa')}.dfs.core.windows.net/product_hierarchy'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS partner_extracts__pharmacy_healthcare.sa_pat_event_log;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/sa_pat_event_log", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/sa_pat_event_log", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_pat_event_log(
pharmacypatientid DECIMAL(13,0),
enrollment_status STRING,
status_change_date STRING,
reason_for_unenrollment STRING,
loginname STRING,
usergroup STRING,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_batch_id STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-bussnstv@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/sa_pat_event_log'
PARTITIONED BY (
idh_ingestion_month STRING)""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS partner_extracts__pharmacy_healthcare.sa_rx_event_log;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/sa_rx_event_log", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/sa_rx_event_log", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_rx_event_log(
pharmacypatientid DECIMAL(13,0),
gpi_14 STRING,
rx_nbr_last INT,
clientstoreid_last INT,
fill_sold_dt_last STRING,
fill_days_supply_last INT,
filldisp_nbr_last INT,
refill_remaining_last INT,
copay DECIMAL(8,2),
script_alignment_status STRING,
clientstoreid INT,
sync_date STRING,
sync_cycle_length INT,
loginname STRING,
usergroup STRING,
dspn_fill_nbr SMALLINT,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_batch_id STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/sa_rx_event_log'
PARTITIONED BY (
idh_ingestion_month STRING)""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS retail__retail_sales.sales_transaction_promo;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_retail')}.dfs.core.windows.net/retail/retail_sales/sales_transaction_promo", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_promo(
sales_txn_id STRING,
txn_business_dt_promo DATE,
store_nbr_promo INT,
loc_store_sk INT,
register_nbr_promo INT,
txn_nbr_promo INT,
txn_ly_card_promo STRING,
sales_txn_type STRING,
src_sys_cd STRING)
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo'
PARTITIONED BY (
sales_txn_dt DATE)""")
# COMMAND ----------
%sql
DROP TABLE retail__retail_sales.sales_transaction_promo_dtl;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo_dtl", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_retail')}.dfs.core.windows.net/retail/retail_sales/sales_transaction_promo_dtl", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_promo_dtl(
sales_txn_id STRING,
line_seq_nbr_promo DECIMAL(38,0),
promo_seq_nbr INT,
promo_type STRING,
promo_adj_dlrs DECIMAL(8,2),
promo_plu DECIMAL(14,0),
promo_entry_mode STRING,
sales_txn_type STRING,
src_sys_cd STRING)
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo_dtl'
PARTITIONED BY (
sales_txn_dt DATE)""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS retail__retail_sales.sales_transaction_promo_item;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo_item", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_retail')}.dfs.core.windows.net/retail/retail_sales/sales_transaction_promo_item", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_promo_item(
sales_txn_id STRING,
line_seq_nbr_promo DECIMAL(38,0),
upc_nbr DECIMAL(14,0),
prod_sk INT,
original_unit_price_dlrs_promo DECIMAL(8,2),
regular_ext_price_dlrs_promo DECIMAL(8,2),
qty_promo DECIMAL(8,0),
selling_price_dlrs_promo DECIMAL(8,2),
sales_txn_type STRING,
src_sys_cd STRING)
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_promo_item'
PARTITIONED BY (
sales_txn_dt DATE)""")
# COMMAND ----------
if 'dapuat' not in getArgument('STORAGE_ACCT_crt_master_data'):
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")
    spark.sql("DELETE FROM retail__retail_sales.sales_transaction_detail_rx")
    spark.sql("VACUUM retail__retail_sales.sales_transaction_detail_rx RETAIN 0 HOURS")
    spark.sql("DROP TABLE retail__retail_sales.sales_transaction_detail_rx")
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = True")
    dbutils.fs.rm(f"abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_detail_rx", recurse=True)
# COMMAND ----------
if 'dapuat' not in getArgument('STORAGE_ACCT_crt_master_data'):
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")
    spark.sql("DELETE FROM retail__retail_sales.sales_transaction_program")
    spark.sql("VACUUM retail__retail_sales.sales_transaction_program RETAIN 0 HOURS")
    spark.sql("DROP TABLE retail__retail_sales.sales_transaction_program")
    spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = True")
    dbutils.fs.rm(f"abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_program", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_detail_rx (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YY/MM/DD" }}',
sales_ord_src_type STRING COMMENT 'Sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
line_item_seq_nbr INT COMMENT 'line item sequence DOUBLE',
rx_elig_ind STRING COMMENT 'rx eligible indicator',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_detail_rx'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_program (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YY/MM/DD" }}',
sales_ord_src_type STRING COMMENT 'Sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
prog_type_cd STRING COMMENT 'program_type_cd',
prog_acct_nbr STRING COMMENT 'program_acct_nbr',
prog_cust_id STRING COMMENT 'program_cust_nbr',
dim_cust_sk BIGINT COMMENT 'dim_cust_sk' ,
cust_sk BIGINT COMMENT 'cust_sk' ,
eid_dim_cust_sk BIGINT COMMENT 'eid_dim_cust_sk' ,
eid_cust_sk BIGINT COMMENT 'eid_cust_sk' ,
mid_dim_cust_sk BIGINT COMMENT 'mid_dim_cust_sk' ,
mid_cust_sk BIGINT COMMENT 'mid_cust_sk' ,
entry_mode_cd STRING COMMENT ' entry mode cd ',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime' ,
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_program'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS digital__ecom.mobile_hit_transaction;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ecom-pii@{getArgument('digital_crt_sa')}.dfs.core.windows.net/mobile_hit_transaction", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/mobile_hit_transaction", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.mobile_hit_transaction(
accept_language STRING,
browser STRING,
browser_type STRING,
browser_height DECIMAL(32,0),
browser_width DECIMAL(32,0),
campaign STRING,
c_color STRING,
channel STRING,
click_action STRING,
click_action_type BIGINT,
click_context STRING,
click_context_type BIGINT,
click_sourceid DECIMAL(32,0),
click_tag STRING,
code_ver STRING,
color STRING,
connection_type STRING,
cookies STRING,
country STRING,
ct_connect_type STRING,
currency STRING,
curr_factor STRING,
curr_rate DECIMAL(24,12),
cust_hit_time_gmt DECIMAL(32,0),
cust_visid STRING,
daily_visitor BIGINT,
date_time STRING,
domain STRING,
duplicated_from STRING,
duplicate_events STRING,
duplicate_purchase BIGINT,
evar1 STRING,
evar2 STRING,
evar3 STRING,
evar4 STRING,
evar5 STRING,
evar6 STRING,
evar7 STRING,
evar8 STRING,
evar9 STRING,
evar10 STRING,
evar11 STRING,
evar12 STRING,
evar13 STRING,
evar14 STRING,
evar15 STRING,
evar16 STRING,
evar17 STRING,
evar18 STRING,
evar19 STRING,
evar20 STRING,
evar21 STRING,
evar22 STRING,
evar23 STRING,
evar24 STRING,
evar25 STRING,
evar26 STRING,
evar27 STRING,
evar28 STRING,
evar29 STRING,
evar30 STRING,
evar31 STRING,
evar32 STRING,
evar33 STRING,
evar34 STRING,
evar35 STRING,
evar36 STRING,
evar37 STRING,
evar38 STRING,
evar39 STRING,
evar40 STRING,
evar41 STRING,
evar42 STRING,
evar43 STRING,
evar44 STRING,
evar45 STRING,
evar46 STRING,
evar47 STRING,
evar48 STRING,
evar49 STRING,
evar50 STRING,
evar51 STRING,
evar52 STRING,
evar53 STRING,
evar54 STRING,
evar55 STRING,
evar56 STRING,
evar57 STRING,
evar58 STRING,
evar59 STRING,
evar60 STRING,
evar61 STRING,
evar62 STRING,
evar63 STRING,
evar64 STRING,
evar65 STRING,
evar66 STRING,
evar67 STRING,
evar68 STRING,
evar69 STRING,
evar70 STRING,
evar71 STRING,
evar72 STRING,
evar73 STRING,
evar74 STRING,
evar75 STRING,
event_list STRING,
exclude_hit BIGINT,
first_hit_pagename STRING,
first_hit_page_url STRING,
first_hit_referrer STRING,
first_hit_time_gmt DECIMAL(32,0),
geo_city STRING,
geo_country STRING,
geo_dma DECIMAL(32,0),
geo_region STRING,
geo_zip STRING,
hier1 STRING,
hier2 STRING,
hier3 STRING,
hier4 STRING,
hier5 STRING,
hitid_high STRING,
hitid_low STRING,
hit_source BIGINT,
hit_time_gmt DECIMAL(32,0),
homepage STRING,
hourly_visitor BIGINT,
ip STRING,
ip2 STRING,
java_enabled STRING,
javascript STRING,
j_jscript STRING,
language STRING,
last_hit_time_gmt DECIMAL(32,0),
last_purchase_num DECIMAL(32,0),
last_purchase_time_gmt DECIMAL(32,0),
mobile_id DECIMAL(32,0),
monthly_visitor BIGINT,
mvvar1 STRING,
mvvar2 STRING,
mvvar3 STRING,
namespace STRING,
new_visit BIGINT,
os STRING,
page_event STRING,
page_event_var1 STRING,
page_event_var2 STRING,
page_event_var3 STRING,
pagename STRING,
page_type STRING,
page_url STRING,
paid_search BIGINT,
partner_plugins STRING,
persistent_cookie STRING,
plugins STRING,
post_browser_height DECIMAL(32,0),
post_browser_width DECIMAL(32,0),
post_campaign STRING,
post_channel STRING,
post_cookies STRING,
post_currency STRING,
post_cust_hit_time_gmt DECIMAL(32,0),
post_cust_visid BIGINT,
post_evar1 STRING,
post_evar2 STRING,
post_evar3 STRING,
post_evar4 STRING,
post_evar5 STRING,
post_evar6 STRING,
post_evar7 STRING,
post_evar8 STRING,
post_evar9 STRING,
post_evar10 STRING,
post_evar11 STRING,
post_evar12 STRING,
post_evar13 STRING,
post_evar14 STRING,
post_evar15 STRING,
post_evar16 STRING,
post_evar17 STRING,
post_evar18 STRING,
post_evar19 STRING,
post_evar20 STRING,
post_evar21 STRING,
post_evar22 STRING,
post_evar23 STRING,
post_evar24 STRING,
post_evar25 STRING,
post_evar26 STRING,
post_evar27 STRING,
post_evar28 STRING,
post_evar29 STRING,
post_evar30 STRING,
post_evar31 STRING,
post_evar32 STRING,
post_evar33 STRING,
post_evar34 STRING,
post_evar35 STRING,
post_evar36 STRING,
post_evar37 STRING,
post_evar38 STRING,
post_evar39 STRING,
post_evar40 STRING,
post_evar41 STRING,
post_evar42 STRING,
post_evar43 STRING,
post_evar44 STRING,
post_evar45 STRING,
post_evar46 STRING,
post_evar47 STRING,
post_evar48 STRING,
post_evar49 STRING,
post_evar50 STRING,
post_evar51 STRING,
post_evar52 STRING,
post_evar53 STRING,
post_evar54 STRING,
post_evar55 STRING,
post_evar56 STRING,
post_evar57 STRING,
post_evar58 STRING,
post_evar59 STRING,
post_evar60 STRING,
post_evar61 STRING,
post_evar62 STRING,
post_evar63 STRING,
post_evar64 STRING,
post_evar65 STRING,
post_evar66 STRING,
post_evar67 STRING,
post_evar68 STRING,
post_evar69 STRING,
post_evar70 STRING,
post_evar71 STRING,
post_evar72 STRING,
post_evar73 STRING,
post_evar74 STRING,
post_evar75 STRING,
post_event_list STRING,
post_hier1 STRING,
post_hier2 STRING,
post_hier3 STRING,
post_hier4 STRING,
post_hier5 STRING,
post_java_enabled STRING,
post_keywords STRING,
post_mvvar1 STRING,
post_mvvar2 STRING,
post_mvvar3 STRING,
post_page_event STRING,
post_page_event_var1 STRING,
post_page_event_var2 STRING,
post_page_event_var3 STRING,
post_pagename STRING,
post_pagename_no_url STRING,
post_page_type STRING,
post_page_url STRING,
post_partner_plugins STRING,
post_persistent_cookie STRING,
post_product_list STRING,
post_prop1 STRING,
post_prop2 STRING,
post_prop3 STRING,
post_prop4 STRING,
post_prop5 STRING,
post_prop6 STRING,
post_prop7 STRING,
post_prop8 STRING,
post_prop9 STRING,
post_prop10 STRING,
post_prop11 STRING,
post_prop12 STRING,
post_prop13 STRING,
post_prop14 STRING,
post_prop15 STRING,
post_prop16 STRING,
post_prop17 STRING,
post_prop18 STRING,
post_prop19 STRING,
post_prop20 STRING,
post_prop21 STRING,
post_prop22 STRING,
post_prop23 STRING,
post_prop24 STRING,
post_prop25 STRING,
post_prop26 STRING,
post_prop27 STRING,
post_prop28 STRING,
post_prop29 STRING,
post_prop30 STRING,
post_prop31 STRING,
post_prop32 STRING,
post_prop33 STRING,
post_prop34 STRING,
post_prop35 STRING,
post_prop36 STRING,
post_prop37 STRING,
post_prop38 STRING,
post_prop39 STRING,
post_prop40 STRING,
post_prop41 STRING,
post_prop42 STRING,
post_prop43 STRING,
post_prop44 STRING,
post_prop45 STRING,
post_prop46 STRING,
post_prop47 STRING,
post_prop48 STRING,
post_prop49 STRING,
post_prop50 STRING,
post_prop51 STRING,
post_prop52 STRING,
post_prop53 STRING,
post_prop54 STRING,
post_prop55 STRING,
post_prop56 STRING,
post_prop57 STRING,
post_prop58 STRING,
post_prop59 STRING,
post_prop60 STRING,
post_prop61 STRING,
post_prop62 STRING,
post_prop63 STRING,
post_prop64 STRING,
post_prop65 STRING,
post_prop66 STRING,
post_prop67 STRING,
post_prop68 STRING,
post_prop69 STRING,
post_prop70 STRING,
post_prop71 STRING,
post_prop72 STRING,
post_prop73 STRING,
post_prop74 STRING,
post_prop75 STRING,
post_purchaseid STRING,
post_referrer STRING,
post_search_engine STRING,
post_state STRING,
post_survey STRING,
post_tnt STRING,
post_transactionid STRING,
post_t_time_info STRING,
post_visid_high STRING,
post_visid_low STRING,
post_visid_type BIGINT,
post_zip STRING,
p_plugins STRING,
prev_page DECIMAL(32,0),
product_list STRING,
product_merchandising STRING,
prop1 STRING,
prop2 STRING,
prop3 STRING,
prop4 STRING,
prop5 STRING,
prop6 STRING,
prop7 STRING,
prop8 STRING,
prop9 STRING,
prop10 STRING,
prop11 STRING,
prop12 STRING,
prop13 STRING,
prop14 STRING,
prop15 STRING,
prop16 STRING,
prop17 STRING,
prop18 STRING,
prop19 STRING,
prop20 STRING,
prop21 STRING,
prop22 STRING,
prop23 STRING,
prop24 STRING,
prop25 STRING,
prop26 STRING,
prop27 STRING,
prop28 STRING,
prop29 STRING,
prop30 STRING,
prop31 STRING,
prop32 STRING,
prop33 STRING,
prop34 STRING,
prop35 STRING,
prop36 STRING,
prop37 STRING,
prop38 STRING,
prop39 STRING,
prop40 STRING,
prop41 STRING,
prop42 STRING,
prop43 STRING,
prop44 STRING,
prop45 STRING,
prop46 STRING,
prop47 STRING,
prop48 STRING,
prop49 STRING,
prop50 STRING,
prop51 STRING,
prop52 STRING,
prop53 STRING,
prop54 STRING,
prop55 STRING,
prop56 STRING,
prop57 STRING,
prop58 STRING,
prop59 STRING,
prop60 STRING,
prop61 STRING,
prop62 STRING,
prop63 STRING,
prop64 STRING,
prop65 STRING,
prop66 STRING,
prop67 STRING,
prop68 STRING,
prop69 STRING,
prop70 STRING,
prop71 STRING,
prop72 STRING,
prop73 STRING,
prop74 STRING,
prop75 STRING,
purchaseid STRING,
quarterly_visitor BIGINT,
ref_domain STRING,
referrer STRING,
ref_type STRING,
resolution STRING,
sampled_hit STRING,
search_engine STRING,
search_page_num DECIMAL(32,0),
secondary_hit BIGINT,
service STRING,
sourceid DECIMAL(32,0),
s_resolution STRING,
state STRING,
stats_server STRING,
tnt STRING,
tnt_post_vista STRING,
transactionid STRING,
truncated_hit STRING,
t_time_info STRING,
ua_color STRING,
ua_os STRING,
ua_pixels STRING,
user_agent STRING,
user_hash DECIMAL(32,0),
userid DECIMAL(32,0),
username STRING,
user_server STRING,
va_closer_detail STRING,
va_closer_id BIGINT,
va_finder_detail STRING,
va_finder_id BIGINT,
va_instance_event BIGINT,
va_new_engagement BIGINT,
visid_high STRING,
visid_low STRING,
visid_new STRING,
visid_timestamp DECIMAL(32,0),
visid_type BIGINT,
visit_keywords STRING,
visit_num DECIMAL(32,0),
visit_page_num DECIMAL(32,0),
visit_referrer STRING,
visit_search_engine DECIMAL(32,0),
visit_start_pagename STRING,
visit_start_page_url STRING,
visit_start_time_gmt DECIMAL(32,0),
weekly_visitor BIGINT,
yearly_visitor BIGINT,
zip STRING,
mobileaction STRING,
mobileappid STRING,
mobilecampaigncontent STRING,
mobilecampaignmedium STRING,
mobilecampaignname STRING,
mobilecampaignsource STRING,
mobilecampaignterm STRING,
mobiledayofweek STRING,
mobiledayssincefirstuse STRING,
mobiledayssincelastuse STRING,
mobiledevice STRING,
mobilehourofday STRING,
mobileinstalldate STRING,
mobilelaunchnumber STRING,
mobileltv STRING,
mobileosversion STRING,
mobileresolution STRING,
podecimalofdecimalerest STRING,
podecimalofdecimalerestdistance STRING,
post_mobileaction STRING,
post_mobileappid STRING,
post_mobilecampaigncontent STRING,
post_mobilecampaignmedium STRING,
post_mobilecampaignname STRING,
post_mobilecampaignsource STRING,
post_mobilecampaignterm STRING,
post_mobiledayofweek STRING,
post_mobiledayssincefirstuse STRING,
post_mobiledayssincelastuse STRING,
post_mobiledevice STRING,
post_mobilehourofday STRING,
post_mobileinstalldate STRING,
post_mobilelaunchnumber STRING,
post_mobileltv STRING,
post_mobileosversion STRING,
post_mobileresolution STRING,
post_podecimalofdecimalerest STRING,
post_podecimalofdecimalerestdistance STRING,
socialassettrackingcode STRING,
socialauthor STRING,
socialaveragesentiment STRING,
socialcontentprovider STRING,
sociallanguage STRING,
sociallatlong STRING,
sociallink STRING,
socialproperty STRING,
socialterm STRING,
socialtermslist STRING,
post_socialassettrackingcode STRING,
post_socialauthor STRING,
post_socialaveragesentiment STRING,
post_socialcontentprovider STRING,
post_sociallanguage STRING,
post_sociallatlong STRING,
post_sociallink STRING,
post_socialproperty STRING,
post_socialterm STRING,
post_socialtermslist STRING,
video STRING,
videoad STRING,
videoadinpod STRING,
videoadplayername STRING,
videoadpod STRING,
videochannel STRING,
videocontenttype STRING,
videopath STRING,
videoplayername STRING,
videosegment STRING,
post_video STRING,
post_videoad STRING,
post_videoadinpod STRING,
post_videoadplayername STRING,
post_videoadpod STRING,
post_videochannel STRING,
post_videocontenttype STRING,
post_videopath STRING,
post_videoplayername STRING,
post_videosegment STRING)
USING DELTA
LOCATION
'abfss://ecom-pii@{getArgument('digital_crt_sa')}.dfs.core.windows.net/mobile_hit_transaction'
PARTITIONED BY (
hit_date STRING)""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS digital__ecom.refill_reminder_info;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/refill_reminder_info", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/refill_reminder_info", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.refill_reminder_info(
mongo_id STRING,
record_id STRING,
pat_id STRING,
me_id STRING,
first_name STRING,
last_name STRING,
customer_type STRING,
br_ind STRING,
campaign_code STRING,
audience_id STRING,
treatment_code STRING,
gpi14 STRING,
create_dttm STRING,
update_dttm STRING,
preference_mode STRING,
phi_ind STRING,
planned_contact_dttm STRING,
upi_code STRING,
channel_code STRING,
timezone_cd STRING,
email struct<emailId:string,psmSent:struct<status:string,sentDTTM:string>,order:struct<submitDTTM:string,channel:string,submitStatus:string,orderReference:string>,dispositionCode:string>,
email_id STRING,
psm_sent_status STRING,
psm_sent_dttm STRING,
submit_dttm STRING,
order_channel STRING,
order_submit_status STRING,
order_reference STRING,
email_disposition_code STRING,
control_group STRING,
reminder_template STRING,
language_pref STRING,
rx_details array<struct<rxNumber:string,drugName:string,drugId:string,groupDrugName:string,lastFillDate:string,ninetyDayInd:string,prescriberFName:string,prescriberLName:string,quantity:string,store:struct<brand:string,number:string>>>,
rx_number STRING,
drug_name STRING,
drug_id STRING,
group_drug_name STRING,
last_fill_date STRING,
ninety_day_ind STRING,
prescriber_first_name STRING,
prescriber_last_name STRING,
quantity STRING,
store_brand STRING,
store_number STRING,
phone_numbers array<struct<phoneNumber:string,sms:struct<status:string,sentDTTM:string>,dispositionCd:string,dispositionDTTM:string>>,
phone_number STRING,
phone_status STRING,
sent_dttm STRING,
disposition_cd STRING,
disposition_dttm STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/refill_reminder_info'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS digital__ecom.rx_sms_refill_info;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/rx_sms_refill_info", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/rx_sms_refill_info", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.rx_sms_refill_info(
mongo_id STRING,
transaction_id STRING,
record_id STRING,
pat_id STRING,
phone_number STRING,
store_ph_no STRING,
create_dttm STRING,
update_dttm STRING,
first_name STRING,
last_name STRING,
dob_verified STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/rx_sms_refill_info'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS retail__retail_sales.sales_txn_dgtl_wallet_dtl;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_txn_dgtl_wallet_dtl", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_retail')}.dfs.core.windows.net/retail/retail_sales/sales_txn_dgtl_wallet_dtl", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_txn_dgtl_wallet_dtl(
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date',
sales_ord_src_type STRING COMMENT 'sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'source system code',
wallet_seq_nbr INT COMMENT 'wallet sequence DOUBLE',
wallet_data STRING COMMENT 'wallet data',
inp_method STRING COMMENT 'input method',
loyalty_mbr_id STRING COMMENT 'loyalty member id',
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_txn_dgtl_wallet_dtl'
PARTITIONED BY (
sales_txn_dt,
src_sys_cd)""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_txn_dgtl_wallet_paymt_dtl", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_retail')}.dfs.core.windows.net/retail/retail_sales/sales_txn_dgtl_wallet_paymt_dtl", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl(
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date',
sales_ord_src_type STRING COMMENT 'sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'source system code',
payment_seq_nbr INT COMMENT 'payment sequence DOUBLE',
payment_stat STRING COMMENT 'payment status',
wallet_card_token STRING COMMENT 'wallet card token',
payment_token STRING COMMENT 'payment token',
payment_amt DECIMAL(10,2) COMMENT 'payment amount',
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_txn_dgtl_wallet_paymt_dtl'
PARTITIONED BY (
sales_txn_dt,
src_sys_cd)""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS digital__ecom.sms_message_details;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ecom-pii@{getArgument('digital_crt_sa')}.dfs.core.windows.net/sms_message_details", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/sms_message_details", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.sms_message_details(
messagedirection STRING,
message_id STRING,
client_id STRING,
client_name STRING,
carrier_id STRING,
carrier_name STRING,
short_code STRING,
country_code STRING,
phonenumber STRING,
campaigntype_id STRING,
campaigntypename STRING,
trigger_id STRING,
campaign_id STRING,
campaignname STRING,
clienttag STRING,
messagetext STRING,
status_id STRING,
statusdescription STRING,
detailedstatusid STRING,
detailedstatusdescription STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://ecom-pii@{getArgument('digital_crt_sa')}.dfs.core.windows.net/sms_message_details'
PARTITIONED BY (
submitted_date STRING)""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS digital__ecom.www_rx_order_overview;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/www_rx_order_overview", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/www_rx_order_overview", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_rx_order_overview(
rx_ord_ref_num STRING,
rx_ord_dttm TIMESTAMP,
rx_ord_owner_me_id STRING,
rx_ord_store_num STRING,
rx_ord_channel_cd STRING,
rx_ord_channel_detail_cd STRING,
rx_ord_submit_status_cd STRING,
rx_ord_process_count STRING,
rx_ord_gq_submit_dttm TIMESTAMP,
rx_ord_site_cd STRING)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/www_rx_order_overview'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS digital__ecom.www_rx_order_retail;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/www_rx_order_retail", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/www_rx_order_retail", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_rx_order_retail(
rx_r_id STRING,
rx_r_ref_num STRING,
rx_r_dttm TIMESTAMP,
rx_r_doc_fname STRING,
rx_r_doc_lname STRING,
rx_r_xfr_rx_num STRING,
rx_r_xfr_store_num STRING,
rx_r_val_app_cd STRING,
rx_r_est_price STRING,
rx_r_submit_q STRING,
rx_r_submit_q_stat STRING,
rx_r_fill_nbr STRING,
rx_r_req_fill_dttm TIMESTAMP,
rx_r_90_day_ind STRING,
rx_r_update_dttm TIMESTAMP,
rx_r_generic_ind STRING,
rx_r_sold_dttm TIMESTAMP,
rx_r_fill_num_disp STRING,
rx_r_ready_price STRING,
rx_r_doc_area_cd STRING,
rx_r_doc_phone_nbr STRING,
rx_r_xfr_pharm_name STRING,
rx_r_xfr_pharm_area_cd STRING,
rx_r_xfr_pharm_phone_nbr STRING,
rx_r_dtl_id STRING,
rx_r_delivery_ind STRING,
rx_r_delivery_comments STRING,
rx_r_addl_cmnts STRING,
rx_r_transfer_rx_num STRING,
drug_id STRING)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/www_rx_order_retail'""")
# COMMAND ----------
%sql
DROP TABLE IF EXISTS digital__ecom.www_wep_rx_info;
# COMMAND ----------
# dbutils.fs.rm(f"abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/www_wep_rx_info", recurse=True)
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/www_wep_rx_info", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.www_wep_rx_info(
short_url_id STRING,
pat_id STRING,
first_name STRING,
last_name STRING,
rx_number STRING,
store_number STRING,
st_addr STRING,
st_city STRING,
st_state STRING,
st_zip STRING,
channel_msg_sent STRING,
create_dttm TIMESTAMP,
update_dttm TIMESTAMP,
home_deli_eligble_ind STRING,
store_ph_number STRING,
store_fax_number STRING,
fill_number STRING,
phone_num STRING)
USING DELTA
LOCATION
'abfss://ecom-phi@{getArgument('digital_crt_sa')}.dfs.core.windows.net/www_wep_rx_info'""")
# COMMAND ----------
migration_data=[{"release": "8.0.0", "scripts": ["T.279.0.crt.mobile_hit_transaction.sql", "T.340.0.crt.refill_reminder_info.sql", "T.347.0.crt.rx_sms_refill_info.sql", "T.379.0.crt.sms_message_details.sql", "T.403.0.crt.www_rx_order_overview.sql", "T.404.0.crt.www_rx_order_retail.sql", "T.415.0.crt.www_wep_rx_info.sql", "T.14454.0.crt.employee_xref.sql", "T.14468.0.crt.fct_scholarship_details.sql", "T.14492.0.crt.latest_performance_rating.sql", "T.14446.0.crt.dim_cd.sql", "T.14448.0.crt.dim_cd_lookup.sql", "T.14467.0.crt.fct_payroll_details.sql", "T.14450.0.crt.dim_school.sql", "T.1081.0.crt.cmg_satr_eligibility.sql", "T.1118.0.crt.contact_hist_acap_reconcilaition.sql", "T.1119.0.crt.contact_hist_ora_reconcilaition.sql", "T.1565.0.crt.patient_adherence_outreach_detail.sql", "T.1068.0.crt.ccpa_rtd_log.sql", "T.1736.0.crt.product_hierarchy.sql", "T.1770.0.crt.sa_pat_event_log.sql", "T.1780.0.crt.sa_rx_event_log.sql", "T.1624.0.crt.prescription.sql", "T.1642.0.crt.prescription_consult_adhoc.sql", "T.1713.0.crt.prescription_sdl.sql", "T.1065.0.crt.ccpa_customer_extracts_activity.sql", "T.1067.0.crt.ccpa_email_rtd_log.sql", "T.19986.0.crt.sales_transaction_detail_rx.sql", "T.19986.0.crt.sales_transaction_program.sql", "T.1798.0.crt.sales_transaction_promo.sql", "T.1799.0.crt.sales_transaction_promo_dtl.sql", "T.1800.0.crt.sales_transaction_promo_item.sql", "T.374.0.crt.sales_txn_dgtl_wallet_dtl.sql", "T.375.0.crt.sales_txn_dgtl_wallet_paymt_dtl.sql", "T.16190.0.crt.dispatcharc_c.sql", "T.279.1.crt.mobile_hit_transaction.sql", "T.340.1.crt.refill_reminder_info.sql", "T.347.1.crt.rx_sms_refill_info.sql", "T.379.1.crt.sms_message_details.sql", "T.403.1.crt.www_rx_order_overview.sql", "T.404.1.crt.www_rx_order_retail.sql", "T.415.1.crt.www_wep_rx_info.sql", "T.14454.1.crt.employee_xref.sql", "T.14468.1.crt.fct_scholarship_details.sql", "T.14492.1.crt.latest_performance_rating.sql", "T.14446.1.crt.dim_cd.sql", "T.14448.1.crt.dim_cd_lookup.sql", "T.14467.1.crt.fct_payroll_details.sql", "T.14450.1.crt.dim_school.sql", "T.1081.1.crt.cmg_satr_eligibility.sql", "T.1118.1.crt.contact_hist_acap_reconcilaition.sql", "T.1119.1.crt.contact_hist_ora_reconcilaition.sql", "T.1565.1.crt.patient_adherence_outreach_detail.sql", "T.1068.1.crt.ccpa_rtd_log.sql", "T.1736.1.crt.product_hierarchy.sql", "T.1770.1.crt.sa_pat_event_log.sql", "T.1780.1.crt.sa_rx_event_log.sql", "T.1624.1.crt.prescription.sql", "T.1642.1.crt.prescription_consult_adhoc.sql", "T.1713.1.crt.prescription_sdl.sql", "T.1065.1.crt.ccpa_customer_extracts_activity.sql", "T.1067.1.crt.ccpa_email_rtd_log.sql", "T.19986.1.crt.sales_transaction_detail_rx.sql", "T.19986.1.crt.sales_transaction_program.sql", "T.1798.1.crt.sales_transaction_promo.sql", "T.1799.1.crt.sales_transaction_promo_dtl.sql", "T.1800.1.crt.sales_transaction_promo_item.sql", "T.374.1.crt.sales_txn_dgtl_wallet_dtl.sql", "T.375.1.crt.sales_txn_dgtl_wallet_paymt_dtl.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.0.0", "table_id": "T.279.1", "table_name": "mobile_hit_transaction", "table_schema": "digital__ecom.mobile_hit_transaction", "table_legacy_schema": "acapdb.mobile_hit_transaction", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.mobile_hit_transaction", "table_partition": "\n  hit_date STRING", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.340.1", "table_name": "refill_reminder_info", "table_schema": "digital__ecom.refill_reminder_info", "table_legacy_schema": "acapdb.refill_reminder_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.refill_reminder_info", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.347.1", "table_name": "rx_sms_refill_info", "table_schema": "digital__ecom.rx_sms_refill_info", "table_legacy_schema": "acapdb.rx_sms_refill_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.rx_sms_refill_info", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.379.1", "table_name": "sms_message_details", "table_schema": "digital__ecom.sms_message_details", "table_legacy_schema": "acapdb.sms_message_details", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.sms_message_details", "table_partition": "\n  submitted_date STRING", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.403.1", "table_name": "www_rx_order_overview", "table_schema": "digital__ecom.www_rx_order_overview", "table_legacy_schema": "acapdb.www_rx_order_overview", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_rx_order_overview", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.404.1", "table_name": "www_rx_order_retail", "table_schema": "digital__ecom.www_rx_order_retail", "table_legacy_schema": "acapdb.www_rx_order_retail", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_rx_order_retail", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.415.1", "table_name": "www_wep_rx_info", "table_schema": "digital__ecom.www_wep_rx_info", "table_legacy_schema": "acapdb.www_wep_rx_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.www_wep_rx_info", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.14454.1", "table_name": "employee_xref", "table_schema": "hr__compensation_benefits.employee_xref", "table_legacy_schema": "hr_cooked.employee_xref", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.employee_xref", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.14468.1", "table_name": "fct_scholarship_details", "table_schema": "hr__compensation_benefits.fct_scholarship_details", "table_legacy_schema": "hr_cooked.fct_scholarship_details", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.fct_scholarship_details", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.14492.1", "table_name": "latest_performance_rating", "table_schema": "hr__employee_performance.latest_performance_rating", "table_legacy_schema": "hr_cooked.latest_performance_rating", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "hr__employee_performance.latest_performance_rating", "table_partition": "", "table_db": "hr__employee_performance", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.14446.1", "table_name": "dim_cd", "table_schema": "hr__lookup_codes.dim_cd", "table_legacy_schema": "hr_cooked.dim_cd", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "hr__lookup_codes.dim_cd", "table_partition": "", "table_db": "hr__lookup_codes", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.14448.1", "table_name": "dim_cd_lookup", "table_schema": "hr__lookup_codes.dim_cd_lookup", "table_legacy_schema": "hr_cooked.dim_cd_lookup", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "hr__lookup_codes.dim_cd_lookup", "table_partition": "", "table_db": "hr__lookup_codes", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.14467.1", "table_name": "fct_payroll_details", "table_schema": "hr__payroll.fct_payroll_details", "table_legacy_schema": "hr_cooked.fct_payroll_details", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "hr__payroll.fct_payroll_details", "table_partition": "", "table_db": "hr__payroll", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.14450.1", "table_name": "dim_school", "table_schema": "hr__recruiting.dim_school", "table_legacy_schema": "hr_cooked.dim_school", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "hr__recruiting.dim_school", "table_partition": "", "table_db": "hr__recruiting", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1081.1", "table_name": "cmg_satr_eligibility", "table_schema": "marketing__campaign.cmg_satr_eligibility", "table_legacy_schema": "dae_cooked.cmg_satr_eligibility", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.cmg_satr_eligibility", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1118.1", "table_name": "contact_hist_acap_reconcilaition", "table_schema": "marketing__campaign.contact_hist_acap_reconcilaition", "table_legacy_schema": "dae_cooked.contact_hist_acap_reconcilaition", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.contact_hist_acap_reconcilaition", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1119.1", "table_name": "contact_hist_ora_reconcilaition", "table_schema": "marketing__campaign.contact_hist_ora_reconcilaition", "table_legacy_schema": "dae_cooked.contact_hist_ora_reconcilaition", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.contact_hist_ora_reconcilaition", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1565.1", "table_name": "patient_adherence_outreach_detail", "table_schema": "marketing__campaign.patient_adherence_outreach_detail", "table_legacy_schema": "dae_cooked.patient_adherence_outreach_detail", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.patient_adherence_outreach_detail", "table_partition": "\n  src_catg_cd STRING, \n  call_type STRING, \n  idh_load_dt STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1068.1", "table_name": "ccpa_rtd_log", "table_schema": "retail__ccpa.ccpa_rtd_log", "table_legacy_schema": "dae_cooked.ccpa_rtd_log", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "retail__ccpa.ccpa_rtd_log", "table_partition": "\n  idh_create_dttm STRING", "table_db": "retail__ccpa", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1736.1", "table_name": "product_hierarchy", "table_schema": "master_data__product.product_hierarchy", "table_legacy_schema": "dae_cooked.product_hierarchy", "table_domain": "master_data", "table_subdomain": "product", "table_location": "master_data__product.product_hierarchy", "table_partition": "", "table_db": "master_data__product", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1770.1", "table_name": "sa_pat_event_log", "table_schema": "partner_extracts__pharmacy_healthcare.sa_pat_event_log", "table_legacy_schema": "dae_cooked.sa_pat_event_log", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_pat_event_log", "table_partition": "\n  idh_ingestion_month STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1780.1", "table_name": "sa_rx_event_log", "table_schema": "partner_extracts__pharmacy_healthcare.sa_rx_event_log", "table_legacy_schema": "dae_cooked.sa_rx_event_log", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_rx_event_log", "table_partition": "\n  idh_ingestion_month STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1624.1", "table_name": "prescription", "table_schema": "pharmacy_healthcare__patient_services.prescription", "table_legacy_schema": "dae_cooked.prescription", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription", "table_partition": "\n  rx_create_yr STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1642.1", "table_name": "prescription_consult_adhoc", "table_schema": "pharmacy_healthcare__patient_services.prescription_consult_adhoc", "table_legacy_schema": "dae_cooked.prescription_consult_adhoc", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_consult_adhoc", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1713.1", "table_name": "prescription_sdl", "table_schema": "pharmacy_healthcare__patient_services.prescription_sdl", "table_legacy_schema": "dae_cooked.prescription_sdl", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_sdl", "table_partition": "\n  fill_sold_yr STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1065.1", "table_name": "ccpa_customer_extracts_activity", "table_schema": "retail__ccpa.ccpa_customer_extracts_activity", "table_legacy_schema": "dae_cooked.ccpa_customer_extracts_activity", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "retail__ccpa.ccpa_customer_extracts_activity", "table_partition": "", "table_db": "retail__ccpa", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1067.1", "table_name": "ccpa_email_rtd_log", "table_schema": "retail__ccpa.ccpa_email_rtd_log", "table_legacy_schema": "dae_cooked.ccpa_email_rtd_log", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "retail__ccpa.ccpa_email_rtd_log", "table_partition": "\n  idh_batch_id DECIMAL(18,0", "table_db": "retail__ccpa", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.19986.1", "table_name": "sales_transaction_detail_rx", "table_schema": "retail__retail_sales.sales_transaction_detail_rx", "table_legacy_schema": "SNOWFLAKE.sales_transaction_detail_rx", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_detail_rx", "table_partition": "", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.19986.1", "table_name": "sales_transaction_program", "table_schema": "retail__retail_sales.sales_transaction_program", "table_legacy_schema": "SNOWFLAKE.sales_transaction_program", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_program", "table_partition": "", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1798.1", "table_name": "sales_transaction_promo", "table_schema": "retail__retail_sales.sales_transaction_promo", "table_legacy_schema": "dae_cooked.sales_transaction_promo", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_promo", "table_partition": "\n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1799.1", "table_name": "sales_transaction_promo_dtl", "table_schema": "retail__retail_sales.sales_transaction_promo_dtl", "table_legacy_schema": "dae_cooked.sales_transaction_promo_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_promo_dtl", "table_partition": "\n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.1800.1", "table_name": "sales_transaction_promo_item", "table_schema": "retail__retail_sales.sales_transaction_promo_item", "table_legacy_schema": "dae_cooked.sales_transaction_promo_item", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_promo_item", "table_partition": "\n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.374.1", "table_name": "sales_txn_dgtl_wallet_dtl", "table_schema": "retail__retail_sales.sales_txn_dgtl_wallet_dtl", "table_legacy_schema": "acapdb.sales_txn_dgtl_wallet_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_txn_dgtl_wallet_dtl", "table_partition": "\n  sales_txn_dt DATE, \n  src_sys_cd STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}, {"release": "8.0.0", "table_id": "T.375.1", "table_name": "sales_txn_dgtl_wallet_paymt_dtl", "table_schema": "retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl", "table_legacy_schema": "acapdb.sales_txn_dgtl_wallet_paymt_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl", "table_partition": "\n  sales_txn_dt STRING, \n  src_sys_cd STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 14:50:30", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('mobile_hit_transaction','refill_reminder_info','rx_sms_refill_info','sms_message_details','www_rx_order_overview','www_rx_order_retail','www_wep_rx_info','employee_xref','fct_scholarship_details','latest_performance_rating','dim_cd','dim_cd_lookup','fct_payroll_details','dim_school','cmg_satr_eligibility','contact_hist_acap_reconcilaition','contact_hist_ora_reconcilaition','patient_adherence_outreach_detail','ccpa_rtd_log','product_hierarchy','sa_pat_event_log','sa_rx_event_log','prescription','prescription_consult_adhoc','prescription_sdl','ccpa_customer_extracts_activity','ccpa_email_rtd_log','sales_transaction_detail_rx','sales_transaction_program','sales_transaction_promo','sales_transaction_promo_dtl','sales_transaction_promo_item','sales_txn_dgtl_wallet_dtl','sales_txn_dgtl_wallet_paymt_dtl','dispatcharc_c');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Databricks notebook source
dbutils.widgets.text(name='retail_crt_sa', defaultValue='${retail_crt_sa}', label='retail_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_crt_master_data', defaultValue='${STORAGE_ACCT_crt_master_data}', label='STORAGE_ACCT_crt_master_data')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
dbutils.widgets.text(name='master_data_crt_sa', defaultValue='${master_data_crt_sa}', label='master_data_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_master_data', defaultValue='${STORAGE_ACCT_wrg_master_data}', label='STORAGE_ACCT_wrg_master_data')
dbutils.widgets.text(name='mna_buyout_crt_sa', defaultValue='${mna_buyout_crt_sa}', label='mna_buyout_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_mna_buyout', defaultValue='${STORAGE_ACCT_crt_mna_buyout}', label='STORAGE_ACCT_crt_mna_buyout')
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
dbutils.widgets.text(name='marketing_crt_sa', defaultValue='${marketing_crt_sa}', label='marketing_crt_sa')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__drug;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS master_data__product;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__loyalty;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__retail_sales;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS mna_buyout__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__retail_sales;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__master_data__product;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_consult_activity(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT ,
rx_partial_fill_nbr INT ,
consult_actv_type_cd STRING ,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
fill_enter_tm STRING,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
consult_campaign_id DECIMAL(8,0),
dspn_fill_nbr SMALLINT ,
consult_actv_stat_ind STRING ,
consult_reqst_rph_user_id DECIMAL(9,0),
consult_reqst_rph_intl STRING ,
consult_reqst_dttm TIMESTAMP,
consult_reqst_cmnts STRING ,
consult_rslv_rph_user_id DECIMAL(9,0),
consult_rslv_rph_intl STRING ,
consult_rslv_dttm TIMESTAMP,
consult_rslv_cmnts STRING ,
src_create_user_id DECIMAL(9,0),
src_create_dttm TIMESTAMP,
src_update_user_id DECIMAL(9,0),
src_update_dttm TIMESTAMP,
remote_str_nbr INT,
edw_batch_id DECIMAL(18,0),
edw_gg_commit_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
relocate_fm_str_nbr INT ,
consult_rph_barcd_sprvsr_id DECIMAL(9,0)
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_consult_activity'
PARTITIONED BY (
fill_sold_yr STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_sdl_reject(
rx_nbr INT,
str_nbr INT,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
fill_enter_tm STRING,
sdl_msg_id STRING ,
reject_nbr TINYINT,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
dl_reject_cd STRING ,
dl_reject_reason STRING ,
edw_batch_id DECIMAL(18,0),
relocate_fm_str_nbr INT ,
src_partition_nbr TINYINT
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_sdl_reject'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_detail(
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YY/MM/DD" }}',
sales_ord_src_type STRING COMMENT 'Sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
line_item_seq_nbr INT COMMENT 'line item sequence DOUBLE',
ord_item_id STRING COMMENT 'order item id',
dim_prod_sk BIGINT COMMENT 'product_dim_sk' ,
prod_price_chng_sk BIGINT COMMENT 'prod_price_chng_sk' ,
prod_sk BIGINT COMMENT 'product_sk' ,
upc_prod_sk BIGINT COMMENT 'upc product sk' ,
src_sys_prod_id_1 STRING COMMENT 'source system product id 1',
src_sys_prod_id_2 STRING COMMENT 'source system product id 2',
src_sys_prod_id_3 STRING COMMENT 'source system product id 3',
src_sys_prod_id_4 STRING COMMENT 'source system product id 4',
upc_nbr DECIMAL(14,0) COMMENT 'upc DOUBLE' ,
upc_desc STRING COMMENT 'upc_desc',
txn_type STRING COMMENT 'txn_type' ,
tax_type_cd STRING COMMENT 'tax_type_cd',
ecomm_order_ind STRING COMMENT 'ecomm_order_ind',
tax_exempt_ind STRING COMMENT 'tax_exempt_ind',
tax_exempt_id STRING COMMENT 'tax_exempt_id',
fsa_item_ind STRING COMMENT 'fsa_item_ind',
rx_not_on_ic_ind STRING COMMENT 'rx_not_on_ic_ind',
price_verify_ind STRING COMMENT 'price_verify_ind',
return_ind STRING COMMENT 'return_ind',
sale_ind STRING COMMENT 'sale_ind',
walgreen_brand_ind STRING COMMENT 'walgreen_brand_ind' ,
prod_id INT COMMENT 'prod_id',
rx_nbr STRING COMMENT 'rx_nbr',
item_unit_price_dlrs DECIMAL(12,2) COMMENT 'item_unit_price_dlrs',
original_price_dlrs DECIMAL(8,2) COMMENT 'original_price_dlrs' ,
selling_price_dlrs DECIMAL(8,2) COMMENT 'selling_price_dlrs',
unit_qty DECIMAL(18,0) COMMENT 'unit_qty' ,
item_void_cd STRING COMMENT 'item_void_cd',
ecomm_order_nbr DECIMAL(12,0) COMMENT 'ecomm_order_nbr' ,
over_age_cd STRING COMMENT 'over_age_cd',
birth_date DATE COMMENT 'birth_date{{"FORMAT":"YY/MM/DD" }}' ,
wag_coup_cd STRING COMMENT 'wag_coup_cd',
mfg_coup_cd STRING COMMENT 'mfg_coup_cd',
discnt_cd STRING COMMENT 'discnt_cd',
rx_type_cd STRING COMMENT 'rx_type_cd',
price_modify_cd STRING COMMENT 'price_modify_cd',
upc_hardkey_cd STRING COMMENT 'upc_hardkey_cd',
dept_hardkey_cd STRING COMMENT 'dept_hardkey_cd',
regstr_key_nbr SMALLINT COMMENT 'regstr_key_nbr' ,
payout_acct_nbr SMALLINT COMMENT 'payout_acct_nbr' ,
photo_env_nbr DECIMAL(11,0) COMMENT 'photo_env_nbr' ,
photo_print_cnt SMALLINT COMMENT 'photo_print_cnt' ,
item_sz DECIMAL(7,2) COMMENT 'item size' ,
discnt_applicable_qty DECIMAL(8,0) COMMENT 'discount applicable quantity' ,
discnt_qualify_qty DECIMAL(8,0) COMMENT 'discount qualify quantity' ,
rx_fill_nbr INT COMMENT 'rx fill DOUBLE' ,
xfer_rx_nbr INT COMMENT 'transfer rx DOUBLE' ,
rx_str_nbr INT COMMENT 'rx store DOUBLE' ,
rx_tranfer_to_str_nbr INT COMMENT 'rx tranfer to store DOUBLE' ,
list_price_dlrs DECIMAL(8,2) COMMENT 'list price dollars' ,
raw_tot_price_dlrs DECIMAL(8,2) COMMENT 'raw total price dollars' ,
sale_price_dlrs DECIMAL(8,2) COMMENT 'sale price dollars' ,
discnt_dlrs DECIMAL(8,2) COMMENT 'discount dollars' ,
prod_cost_dlrs DECIMAL(12,2) COMMENT 'product cost dollars' ,
price_before_discnt_dlrs DECIMAL(8,2) COMMENT 'price before discount dollars' ,
coupon_savings_dlrs DECIMAL(8,2) COMMENT 'coupon savings dollars' ,
aarp_ind STRING COMMENT 'aarp indicator' ,
availability_ind STRING COMMENT 'availability indicator' ,
price_override_reason STRING COMMENT 'price override reason',
eye_side STRING COMMENT 'eye side' ,
item_stat STRING COMMENT 'item status',
item_stat_detail STRING COMMENT 'item status detail',
orig_ord_wic DECIMAL(10,0) COMMENT 'original order wic' ,
est_price_dlrs DECIMAL(8,2) COMMENT 'estimated price dollars' ,
ready_price_dlrs DECIMAL(8,2) COMMENT 'ready price dollars' ,
ready_dt DATE COMMENT 'ready date{{"FORMAT":"YY/MM/DD" }}' ,
ready_tm STRING COMMENT 'ready time' ,
sold_dt DATE COMMENT 'sold date{{"FORMAT":"YY/MM/DD" }}' ,
sold_tm STRING COMMENT 'sold time' ,
voiding_dlrs DECIMAL(7,2) COMMENT 'voiding_dlrs',
disposable_item_desc STRING COMMENT 'disposable item description',
gqm_prod_id STRING COMMENT 'gqm_prod_id',
wic DECIMAL(18,0) COMMENT 'wic' ,
return_shipment_req_ind STRING COMMENT 'return shipment required indicator' ,
return_reason_desc STRING COMMENT 'return reason description',
return_stat_desc STRING COMMENT 'return status description',
prod_discnt_tot_dlrs DECIMAL(8,2) COMMENT 'product discount total dollars' ,
prod_price_before_discnt_dlrs DECIMAL(8,2) COMMENT 'product price before discount dollars' ,
return_bonus_dlrs DECIMAL(8,2) COMMENT 'return bonus dollars' ,
qty_rcvd DECIMAL(18,0) COMMENT 'quantity received' ,
qty_to_return DECIMAL(18,0) COMMENT 'quantity to return' ,
loyalty_earn_elig_ind STRING COMMENT 'loyalty eligible indicator' ,
loyalty_redeem_elig_ind STRING COMMENT 'loyalty redeem eligible indicator' ,
price_cd STRING COMMENT 'pricing code',
rx_partial_fill_cd_ind STRING COMMENT 'rx partial fill code indicator' ,
rx_primary_plan_gov_funded_ind STRING COMMENT 'rx primary plan government funded indicator' ,
rx_cob_plan_gov_funded_ind STRING COMMENT 'rx cob plan government funded indicator' ,
rx_30_to_90_day_ind STRING COMMENT 'rx 30 to 90 day indicator' ,
line_item_dtl_nbr DECIMAL(38,0) COMMENT 'line item detail DOUBLE from next gen pos' ,
wic_item_catg STRING COMMENT 'women infant children item category' ,
wic_item_sub_catg STRING COMMENT 'women infant children item sub category' ,
ewic_paid_item_ind STRING COMMENT 'ewic paid item indicator' ,
pos_id_type STRING COMMENT 'identifies the type of POS item' ,
evt_id STRING COMMENT 'event_id',
evt_desc STRING COMMENT 'event description',
item_correct_price DECIMAL(8,2) COMMENT 'item_correct_price' ,
item_sold_price DECIMAL(8,2) COMMENT 'item_sold_price' ,
prchd_card_type_name STRING COMMENT 'purchased card type name',
prchd_card_acct_nbr STRING COMMENT 'purchased card account DOUBLE',
prchd_card_activiation_stat_cd STRING COMMENT 'purchased card activiation status code',
orig_sales_txn_id STRING COMMENT 'original_sales_transaction_id',
orig_sales_txn_src_sys_cd STRING COMMENT 'original sales transaction source system code',
orig_sale_price_dlrs DECIMAL(8,2) COMMENT 'original_sale_price_dollars' ,
orig_refund_stat_cd STRING COMMENT 'original_refund_status_code' ,
orig_line_item_seq_nbr INT COMMENT 'original line item sequence DOUBLE' ,
actv_stat_cd STRING COMMENT 'activation status code',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-phi@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_detail'
PARTITIONED BY (
src_sys_cd,
sales_txn_dt)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_tender(
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YYYY/MM/DD" }}',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
sales_ord_src_type STRING COMMENT 'sales order source type',
tndr_seq_nbr SMALLINT COMMENT 'tender sequence DOUBLE',
card_hash_val_sk BIGINT COMMENT 'card hash value surrogate key',
tndr_type_cd STRING COMMENT 'tndr_type_cd' ,
tndr_dlrs DECIMAL(8,2) COMMENT 'tndr_dlrs',
entry_mode_cd STRING COMMENT 'entry_mode_cd',
acct_nbr STRING COMMENT 'acct_nbr' ,
ck_bank_route_nbr DECIMAL(9,0) COMMENT 'ck_bank_route_nbr' ,
ck_nbr DECIMAL(15,0) COMMENT 'ck_nbr' ,
expire_dt STRING COMMENT 'expire_dt',
service_cd STRING COMMENT 'service code' ,
emv_cd STRING COMMENT 'emv code' ,
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_tender'
PARTITIONED BY (
sales_txn_dt)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.tender_card_hash(
card_hash_val_sk BIGINT COMMENT 'card hash value surrogate key',
card_id DECIMAL(18,0) COMMENT 'card identifier',
card_token_val STRING COMMENT 'card token value',
card_first_6_char STRING COMMENT 'card_first_6_char',
card_last_4_char STRING COMMENT 'card_last_4_char',
latest_txn_dt DATE COMMENT 'latest transaction date{{"FORMAT":"YYYY-MM-DD" }}',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/tender_card_hash'
PARTITIONED BY (
edw_create_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.tl_prescription_return_call_list(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT ,
rx_partial_fill_nbr INT ,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
fill_enter_tm STRING,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
call_list_stat_cd STRING ,
call_list_elig_dttm TIMESTAMP,
call_list_cmnt_stat_cd STRING ,
call_list_cmnt_stat_dttm TIMESTAMP,
call_list_cmnt_txt STRING ,
call_list_cmnt_dttm TIMESTAMP,
auto_fill_cd STRING ,
relocate_fm_str_nbr INT ,
create_user_id DECIMAL(9,0),
create_dttm TIMESTAMP,
update_user_id DECIMAL(9,0),
update_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0)
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/tl_prescription_return_call_list'
PARTITIONED BY (
fill_sold_yr STRING ,
fill_enter_yrmnth STRING )""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.tl_prescription_return_call_list_data_migration(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT ,
rx_partial_fill_nbr INT ,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
fill_enter_tm STRING,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
call_list_stat_cd STRING ,
call_list_elig_dttm TIMESTAMP,
call_list_cmnt_stat_cd STRING ,
call_list_cmnt_stat_dttm TIMESTAMP,
call_list_cmnt_txt STRING ,
call_list_cmnt_dttm TIMESTAMP,
auto_fill_cd STRING ,
relocate_fm_str_nbr INT ,
create_user_id DECIMAL(9,0),
create_dttm TIMESTAMP,
update_user_id DECIMAL(9,0),
update_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/tl_prescription_return_call_list_data_migration'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.tender_card_hash_data_migration(
card_hash_val_sk BIGINT COMMENT 'card hash value surrogate key',
card_id DECIMAL(18,0) COMMENT 'card identifier',
card_token_val STRING COMMENT 'card token value',
card_first_6_char STRING COMMENT 'card_first_6_char',
card_last_4_char STRING COMMENT 'card_last_4_char',
latest_txn_dt DATE COMMENT 'latest transaction date{{"FORMAT":"YYYY-MM-DD" }}',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id')
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/tender_card_hash_data_migration'
PARTITIONED BY (
edw_create_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_sdl_reject_data_migration(
rx_nbr INT,
str_nbr INT,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
fill_enter_tm STRING,
sdl_msg_id STRING ,
reject_nbr TINYINT,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
dl_reject_cd STRING ,
dl_reject_reason STRING ,
edw_batch_id DECIMAL(18,0),
relocate_fm_str_nbr INT ,
src_partition_nbr TINYINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_sdl_reject_data_migration'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YYYY/MM/DD" }}',
sales_ord_src_type STRING COMMENT 'sales order source type' ,
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
dim_loc_store_sk BIGINT COMMENT 'dim_loc_sk' ,
loc_store_sk BIGINT COMMENT 'loc_id' ,
store_nbr INT COMMENT 'store DOUBLE' ,
dim_loc_mgrs_sk BIGINT COMMENT 'dim_loc_staff_sk' ,
src_cust_id STRING COMMENT 'ecom_customer_id' ,
txn_end_dttm TIMESTAMP COMMENT 'txn_end_dttm',
ord_stat_cd STRING COMMENT 'order status code' ,
fulfillment_type_cd STRING COMMENT 'fulfillment type code' ,
originating_str_nbr INT COMMENT 'originating_str_nbr' ,
originating_store_sk BIGINT COMMENT 'originating store surrogate key' ,
fulfillment_str_nbr INT COMMENT 'fulfillment store DOUBLE' ,
fulfillment_store_sk BIGINT COMMENT 'fulfillment store surrogate key' ,
pick_up_at_str_nbr INT COMMENT 'pick up at store DOUBLE' ,
pickup_at_store_sk BIGINT COMMENT 'pickup at store surrogate key' ,
bypass_reason_cd SMALLINT COMMENT 'bypass reason code' ,
ord_entry_channel_cd STRING COMMENT 'order entry channel code' ,
ord_desc STRING COMMENT 'order description' ,
promise_dt DATE COMMENT 'promise date{{"FORMAT":"YYYY/MM/DD" }}' ,
promise_tm STRING COMMENT 'promise time' ,
rx_reqst_fill_dt DATE COMMENT 'rx request fill date{{"FORMAT":"YYYY/MM/DD" }}' ,
rx_reqst_fill_tm STRING COMMENT 'rx request fill time' ,
txn_type STRING COMMENT 'txn_type' ,
ord_ship_dt DATE COMMENT 'order ship date{{"FORMAT":"YYYY/MM/DD" }}' ,
ord_ship_tm STRING COMMENT 'order ship time' ,
return_stat_desc STRING COMMENT 'return status description' ,
prcs_ind STRING COMMENT 'prcs indicator' ,
prcs_immediate_ind STRING COMMENT 'prcs immediate indicator' ,
nbr_of_images INT COMMENT 'number of images' ,
tot_image_sz_kb DECIMAL(10,2) COMMENT 'total image size mb' ,
pcp_ord_id STRING COMMENT 'pcp order id' ,
vndr_cust_id STRING COMMENT 'vendor customer id' ,
vndr_ord_id STRING COMMENT 'vendor order id' ,
commision_vndr_cd STRING COMMENT 'commision vendor code' ,
photo_origin_id STRING COMMENT 'photo origin identifier' ,
spcl_ord_desc STRING COMMENT 'special order description' ,
orig_inv_dlrs DECIMAL(8,2) COMMENT 'original invoice dollars' ,
prod_cost_dlrs DECIMAL(8,2) COMMENT 'product cost dollars' ,
shipping_price_dlrs DECIMAL(8,2) COMMENT 'shipping price dollars' ,
in_str_ord_ind STRING COMMENT 'in store order indicator' ,
share_ord_ind STRING COMMENT 'shared order indicator' ,
aarp_ind STRING COMMENT 'aarp indicator' ,
ord_return_ind STRING COMMENT 'order return indicator' ,
pre_click_ord_ind STRING COMMENT 'pre click order indicator' ,
held_ord_ind STRING COMMENT 'held order indicator' ,
lens_ord_ind STRING COMMENT 'lens order indicator' ,
self_pay_ind STRING COMMENT 'self pay indicator' ,
xref_line_item_seq_nbr SMALLINT COMMENT 'xref_line_item_seq_nbr',
generic_ord_ind STRING COMMENT 'generic order indicator' ,
fsa_ind STRING COMMENT 'flexible spending account indicator' ,
cashier_nbr SMALLINT COMMENT 'cashier_nbr' ,
create_id STRING COMMENT 'create_id' ,
cashier_employee_id DECIMAL(10,0) COMMENT 'cashier id' ,
mgr_employee_id DECIMAL(10,0) COMMENT 'manager id' ,
loyalty_employee_id DECIMAL(10,0) COMMENT 'employee_id' ,
exchange_cd STRING COMMENT 'exchange_cd' ,
offline_txn_ind STRING COMMENT 'offline_txn_ind' ,
price_verify_cd STRING COMMENT 'price_verify_cd' ,
register_nbr SMALLINT COMMENT 'register_nbr' ,
store_register_sk BIGINT COMMENT 'store register sk',
rfn_value STRING COMMENT 'rfn_value' ,
next_gen_rfn_value STRING COMMENT 'next_gen_rfn_value' ,
training_txn_ind STRING COMMENT 'training_txn_ind' ,
txn_incomplete_ind STRING COMMENT 'txn_incomplete_ind' ,
txn_nbr SMALLINT COMMENT 'txn_nbr',
txn_start_dttm TIMESTAMP COMMENT 'txn_start_dttm',
txn_tot_discnt_line_cnt SMALLINT COMMENT 'txn_tot_discnt_line_cnt' ,
txn_tot_discnt_line_qty SMALLINT COMMENT 'txn_tot_discnt_line_qty' ,
txn_tot_discnt_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_return_dlrs' ,
txn_tot_discnt_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_sale_dlrs' ,
txn_tot_dlrs DECIMAL(8,2) COMMENT 'txn_tot_dlrs' ,
txn_tot_line_cnt SMALLINT COMMENT 'txn_tot_line_cnt' ,
txn_tot_line_voided_cnt SMALLINT COMMENT 'txn_tot_line_voided_cnt' ,
txn_tot_line_voids_cnt SMALLINT COMMENT 'txn_tot_line_voids_cnt' ,
txn_tot_mfg_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_mfg_coup_dlrs' ,
txn_tot_net_qty DECIMAL(5,0) COMMENT 'txn_tot_net_qty' ,
txn_tot_price_vrfy_line_cnt SMALLINT COMMENT 'txn_tot_price_vrfy_line_cnt' ,
txn_tot_reg_line_cnt SMALLINT COMMENT 'txn_tot_reg_line_cnt' ,
txn_tot_reg_line_qty SMALLINT COMMENT 'txn_tot_reg_line_qty' ,
txn_tot_reg_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_return_dlrs' ,
txn_tot_reg_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_sale_dlrs' ,
txn_tot_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_return_dlrs' ,
txn_tot_return_line_cnt SMALLINT COMMENT 'txn_tot_return_line_cnt' ,
txn_tot_rx_line_cnt SMALLINT COMMENT 'txn_tot_rx_line_cnt' ,
txn_tot_tax_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tax_dlrs' ,
txn_tot_tndr_cnt SMALLINT COMMENT 'txn_tot_tndr_cnt' ,
txn_tot_tndr_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tndr_dlrs' ,
txn_tot_void_dlrs DECIMAL(8,2) COMMENT 'txn_tot_void_dlrs' ,
txn_tot_wag_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_wag_coup_dlrs' ,
discnt_mode_cd STRING COMMENT 'discnt_mode_cd' ,
affiliate_discnt_cd STRING COMMENT 'affiliate discount code' ,
post_void_status_cd STRING COMMENT 'post_void_status_cd' ,
return_reason_cd SMALLINT COMMENT 'return reason code' ,
return_auth_nbr STRING COMMENT 'return authorization DOUBLE' ,
vndr_refund_id DECIMAL(19,0) COMMENT 'vendor refund id' ,
shipping_price_discnt_dlrs DECIMAL(8,2) COMMENT 'shipping price discount dollars' ,
suggest_tax_return_dlrs DECIMAL(8,2) COMMENT 'suggested tax return dollars' ,
actl_tax_return_dlrs DECIMAL(8,2) COMMENT 'actl_tax_return_dlrs' ,
suggest_ship_return_dlrs DECIMAL(8,2) COMMENT 'suggested ship return dollars' ,
actl_ship_return_dlrs DECIMAL(8,2) COMMENT 'actl_ship_return_dlrs' ,
paypal_return_dlrs DECIMAL(8,2) COMMENT 'paypal_return_dlrs' ,
authenticator_id STRING COMMENT 'authenticator_id' ,
credit_card_return_dlrs DECIMAL(8,2) COMMENT 'credit_card_return_dlrs' ,
gift_card_return_dlrs DECIMAL(8,2) COMMENT 'gift_card_return_dlrs' ,
loyalty_enrl_ind STRING COMMENT 'loyalty enrollment indicator' ,
aarp_opt_out_ind STRING COMMENT 'aarp opt out indicator' ,
identification_method STRING COMMENT 'identification method' ,
price_button_evt_ind STRING COMMENT 'pricing button event indicator' ,
emp_discnt_button_use STRING COMMENT 'employee discount button_use' ,
loyalty_card_scan_ind STRING COMMENT 'loyalty card scan indicator' ,
store_emp_loyalty_acct_ind STRING COMMENT 'store employee loyalty account indicator' ,
onscreen_redeem_button_use STRING COMMENT 'onscreen_redeem_button_use' ,
bounty_super_refund_cd STRING COMMENT 'bounty_super_refund_cd' ,
csr_id STRING COMMENT 'csr identifier' ,
ord_sub_type_cd STRING COMMENT 'order sub type code' ,
void_type_cd STRING COMMENT 'void type code' ,
void_reason_cd STRING COMMENT 'void reason code' ,
emv_stat_cd STRING COMMENT 'emv status code' ,
pinpad_stat_cd STRING COMMENT 'pinpad status code' ,
channel_cd STRING COMMENT 'channel code' ,
channel_desc STRING COMMENT 'channel description' ,
channel_detail_cd STRING COMMENT 'channel detail code' ,
channel_detail_desc STRING COMMENT 'channel detail description' ,
func_cd STRING COMMENT 'functionality code' ,
func_desc STRING COMMENT 'functionality description' ,
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.sales_txn_apriss_return_auth_data_migration (
sales_txn_id STRING ,
sales_ord_src_type STRING ,
sales_txn_type STRING ,
seq_nbr STRING ,
apriss_auth_stat STRING ,
apriss_txn_id STRING ,
edw_create_dttm STRING ,
edw_update_dttm STRING ,
edw_batch_id DECIMAL(18,0) ,
acap_batch_id STRING
)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_txn_apriss_return_auth_data_migration'
PARTITIONED BY (
sales_txn_dt STRING ,
src_sys_cd STRING )""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.sales_transaction_data_migration (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_ord_src_type STRING COMMENT 'sales order source type' ,
sales_txn_type STRING COMMENT 'sales_txn type',
dim_loc_store_sk BIGINT COMMENT 'dim_loc_sk' ,
loc_store_sk BIGINT COMMENT 'loc_id' ,
store_nbr INT COMMENT 'store DOUBLE' ,
dim_loc_mgrs_sk BIGINT COMMENT 'dim_loc_staff_sk' ,
src_cust_id STRING COMMENT 'ecom_customer_id' ,
txn_end_dttm TIMESTAMP COMMENT 'txn_end_dttm',
ord_stat_cd STRING COMMENT 'order status code' ,
fulfillment_type_cd STRING COMMENT 'fulfillment type code' ,
originating_str_nbr INT COMMENT 'originating_str_nbr' ,
originating_store_sk BIGINT COMMENT 'originating store surrogate key' ,
fulfillment_str_nbr INT COMMENT 'fulfillment store DOUBLE' ,
fulfillment_store_sk BIGINT COMMENT 'fulfillment store surrogate key' ,
pick_up_at_str_nbr INT COMMENT 'pick up at store DOUBLE' ,
pickup_at_store_sk BIGINT COMMENT 'pickup at store surrogate key' ,
bypass_reason_cd SMALLINT COMMENT 'bypass reason code' ,
ord_entry_channel_cd STRING COMMENT 'order entry channel code' ,
ord_desc STRING COMMENT 'order description' ,
promise_dt DATE COMMENT 'promise date{{"FORMAT":"YYYY/MM/DD" }}' ,
promise_tm STRING COMMENT 'promise time' ,
rx_reqst_fill_dt DATE COMMENT 'rx request fill date{{"FORMAT":"YYYY/MM/DD" }}' ,
rx_reqst_fill_tm STRING COMMENT 'rx request fill time' ,
txn_type STRING COMMENT 'txn_type' ,
ord_ship_dt DATE COMMENT 'order ship date{{"FORMAT":"YYYY/MM/DD" }}' ,
ord_ship_tm STRING COMMENT 'order ship time' ,
return_stat_desc STRING COMMENT 'return status description' ,
prcs_ind STRING COMMENT 'prcs indicator' ,
prcs_immediate_ind STRING COMMENT 'prcs immediate indicator' ,
nbr_of_images INT COMMENT 'number of images' ,
tot_image_sz_kb DECIMAL(10,2) COMMENT 'total image size mb' ,
pcp_ord_id STRING COMMENT 'pcp order id' ,
vndr_cust_id STRING COMMENT 'vendor customer id' ,
vndr_ord_id STRING COMMENT 'vendor order id' ,
commision_vndr_cd STRING COMMENT 'commision vendor code' ,
photo_origin_id STRING COMMENT 'photo origin identifier' ,
spcl_ord_desc STRING COMMENT 'special order description' ,
orig_inv_dlrs DECIMAL(8,2) COMMENT 'original invoice dollars' ,
prod_cost_dlrs DECIMAL(8,2) COMMENT 'product cost dollars' ,
shipping_price_dlrs DECIMAL(8,2) COMMENT 'shipping price dollars' ,
in_str_ord_ind STRING COMMENT 'in store order indicator' ,
share_ord_ind STRING COMMENT 'shared order indicator' ,
aarp_ind STRING COMMENT 'aarp indicator' ,
ord_return_ind STRING COMMENT 'order return indicator' ,
pre_click_ord_ind STRING COMMENT 'pre click order indicator' ,
held_ord_ind STRING COMMENT 'held order indicator' ,
lens_ord_ind STRING COMMENT 'lens order indicator' ,
self_pay_ind STRING COMMENT 'self pay indicator' ,
xref_line_item_seq_nbr SMALLINT COMMENT 'xref_line_item_seq_nbr',
generic_ord_ind STRING COMMENT 'generic order indicator' ,
fsa_ind STRING COMMENT 'flexible spending account indicator' ,
cashier_nbr SMALLINT COMMENT 'cashier_nbr' ,
create_id STRING COMMENT 'create_id' ,
cashier_employee_id DECIMAL(10,0) COMMENT 'cashier id' ,
mgr_employee_id DECIMAL(10,0) COMMENT 'manager id' ,
loyalty_employee_id DECIMAL(10,0) COMMENT 'employee_id' ,
exchange_cd STRING COMMENT 'exchange_cd' ,
offline_txn_ind STRING COMMENT 'offline_txn_ind' ,
price_verify_cd STRING COMMENT 'price_verify_cd' ,
register_nbr SMALLINT COMMENT 'register_nbr' ,
store_register_sk BIGINT COMMENT 'store register sk',
rfn_value STRING COMMENT 'rfn_value' ,
next_gen_rfn_value STRING COMMENT 'next_gen_rfn_value' ,
training_txn_ind STRING COMMENT 'training_txn_ind' ,
txn_incomplete_ind STRING COMMENT 'txn_incomplete_ind' ,
txn_nbr SMALLINT COMMENT 'txn_nbr',
txn_start_dttm TIMESTAMP COMMENT 'txn_start_dttm',
txn_tot_discnt_line_cnt SMALLINT COMMENT 'txn_tot_discnt_line_cnt' ,
txn_tot_discnt_line_qty SMALLINT COMMENT 'txn_tot_discnt_line_qty' ,
txn_tot_discnt_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_return_dlrs' ,
txn_tot_discnt_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_sale_dlrs' ,
txn_tot_dlrs DECIMAL(8,2) COMMENT 'txn_tot_dlrs' ,
txn_tot_line_cnt SMALLINT COMMENT 'txn_tot_line_cnt' ,
txn_tot_line_voided_cnt SMALLINT COMMENT 'txn_tot_line_voided_cnt' ,
txn_tot_line_voids_cnt SMALLINT COMMENT 'txn_tot_line_voids_cnt' ,
txn_tot_mfg_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_mfg_coup_dlrs' ,
txn_tot_net_qty DECIMAL(5,0) COMMENT 'txn_tot_net_qty' ,
txn_tot_price_vrfy_line_cnt SMALLINT COMMENT 'txn_tot_price_vrfy_line_cnt' ,
txn_tot_reg_line_cnt SMALLINT COMMENT 'txn_tot_reg_line_cnt' ,
txn_tot_reg_line_qty SMALLINT COMMENT 'txn_tot_reg_line_qty' ,
txn_tot_reg_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_return_dlrs' ,
txn_tot_reg_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_sale_dlrs' ,
txn_tot_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_return_dlrs' ,
txn_tot_return_line_cnt SMALLINT COMMENT 'txn_tot_return_line_cnt' ,
txn_tot_rx_line_cnt SMALLINT COMMENT 'txn_tot_rx_line_cnt' ,
txn_tot_tax_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tax_dlrs' ,
txn_tot_tndr_cnt SMALLINT COMMENT 'txn_tot_tndr_cnt' ,
txn_tot_tndr_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tndr_dlrs' ,
txn_tot_void_dlrs DECIMAL(8,2) COMMENT 'txn_tot_void_dlrs' ,
txn_tot_wag_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_wag_coup_dlrs' ,
discnt_mode_cd STRING COMMENT 'discnt_mode_cd' ,
affiliate_discnt_cd STRING COMMENT 'affiliate discount code' ,
post_void_status_cd STRING COMMENT 'post_void_status_cd' ,
return_reason_cd SMALLINT COMMENT 'return reason code' ,
return_auth_nbr STRING COMMENT 'return authorization DOUBLE' ,
vndr_refund_id DECIMAL(19,0) COMMENT 'vendor refund id' ,
shipping_price_discnt_dlrs DECIMAL(8,2) COMMENT 'shipping price discount dollars' ,
suggest_tax_return_dlrs DECIMAL(8,2) COMMENT 'suggested tax return dollars' ,
actl_tax_return_dlrs DECIMAL(8,2) COMMENT 'actl_tax_return_dlrs' ,
suggest_ship_return_dlrs DECIMAL(8,2) COMMENT 'suggested ship return dollars' ,
actl_ship_return_dlrs DECIMAL(8,2) COMMENT 'actl_ship_return_dlrs' ,
paypal_return_dlrs DECIMAL(8,2) COMMENT 'paypal_return_dlrs' ,
authenticator_id STRING COMMENT 'authenticator_id' ,
credit_card_return_dlrs DECIMAL(8,2) COMMENT 'credit_card_return_dlrs' ,
gift_card_return_dlrs DECIMAL(8,2) COMMENT 'gift_card_return_dlrs' ,
loyalty_enrl_ind STRING COMMENT 'loyalty enrollment indicator' ,
aarp_opt_out_ind STRING COMMENT 'aarp opt out indicator' ,
identification_method STRING COMMENT 'identification method' ,
price_button_evt_ind STRING COMMENT 'pricing button event indicator' ,
emp_discnt_button_use STRING COMMENT 'employee discount button_use' ,
loyalty_card_scan_ind STRING COMMENT 'loyalty card scan indicator' ,
store_emp_loyalty_acct_ind STRING COMMENT 'store employee loyalty account indicator' ,
onscreen_redeem_button_use STRING COMMENT 'onscreen_redeem_button_use' ,
bounty_super_refund_cd STRING COMMENT 'bounty_super_refund_cd' ,
csr_id STRING COMMENT 'csr identifier' ,
ord_sub_type_cd STRING COMMENT 'order sub type code' ,
void_type_cd STRING COMMENT 'void type code' ,
void_reason_cd STRING COMMENT 'void reason code' ,
emv_stat_cd STRING COMMENT 'emv status code' ,
pinpad_stat_cd STRING COMMENT 'pinpad status code' ,
channel_cd STRING COMMENT 'channel code' ,
channel_desc STRING COMMENT 'channel description' ,
channel_detail_cd STRING COMMENT 'channel detail code' ,
channel_detail_desc STRING COMMENT 'channel detail description' ,
func_cd STRING COMMENT 'functionality code' ,
func_desc STRING COMMENT 'functionality description' ,
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id',
src_sys_cd STRING COMMENT 'sales_txn source system code',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YYYY/MM/DD" }}'
)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_transaction_data_migration'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS master_data__product.product (
prod_chng_sk BIGINT COMMENT 'product_change_sk',
prod_sk BIGINT COMMENT 'product_sk',
prod_vndr_mfgr_sk BIGINT COMMENT 'prod_vndr_mfgr_sk',
edw_rec_begin_dt DATE COMMENT 'edw record begin date{{"FORMAT":"yyyy-mm-dd" }}',
edw_rec_end_dt DATE COMMENT 'record end date{{"FORMAT":"yyyy-mm-dd" }}',
src_sys_prod_id_1 STRING COMMENT 'source system product id 1',
src_sys_prod_id_2 STRING COMMENT 'source system product id 2',
src_sys_prod_id_3 STRING COMMENT 'source system product id 3',
src_sys_prod_id_4 STRING COMMENT 'source system product id 4',
src_sys_cd STRING COMMENT 'source system code',
wic DECIMAL(18,0) COMMENT 'wic',
mss_wic_nbr INT COMMENT 'mss wic DOUBLE',
ecom_prod_id STRING COMMENT 'ecom_prod_id',
prod_id INT COMMENT 'prod_id',
mss_prod_id INT COMMENT 'mss product identifier',
wic_prod_id INT COMMENT 'wic product identifier',
basic_prod_ind STRING COMMENT 'basic product indicator' ,
upc STRING COMMENT 'upc',
sku_id STRING COMMENT 'sku_id',
prod_sz DECIMAL(8,2) COMMENT 'product size',
prod_desc STRING COMMENT 'product description',
rtl_unit_qty DECIMAL(18,0) COMMENT 'retail unit quantity',
unit_id STRING COMMENT 'unit id',
brand_name STRING COMMENT 'brand name',
prod_start_dt DATE COMMENT 'product start date{{"FORMAT":"yyyy-mm-dd" }}',
prod_start_tm STRING COMMENT 'product start time',
prod_end_dt DATE COMMENT 'product end date{{"FORMAT":"yyyy-mm-dd" }}',
prod_end_tm STRING COMMENT 'product end time',
prod_create_dt DATE COMMENT 'product creation date{{"FORMAT":"yyyy-mm-dd" }}',
prod_create_tm STRING COMMENT 'product creation time',
prod_update_dt DATE COMMENT 'product update date{{"FORMAT":"yyyy-mm-dd" }}' ,
new_item_start_dt DATE COMMENT 'new item start date{{"FORMAT":"yyyy-mm-dd" }}',
new_item_start_tm STRING COMMENT 'new item start time',
new_item_end_dt DATE COMMENT 'new item end date{{"FORMAT":"yyyy-mm-dd" }}',
new_item_end_tm STRING COMMENT 'new item end time',
display_name STRING COMMENT 'display name',
aarp_item_cd STRING COMMENT 'aarp item code',
prch_limit INT COMMENT 'purchase limit',
mfgr_id STRING COMMENT 'manufacturer id',
mfgr_prod_id DECIMAL(8,0) COMMENT 'manufacturer product identifier',
rtl_sell_unit_cd STRING COMMENT 'retail sell unit code',
ship_to_cust_only_ind STRING COMMENT 'ship to customer only indicator',
complete_ind STRING COMMENT 'complete indicator',
lens_prod_ind STRING COMMENT 'lens product indicator',
affiliate_discntable_ind STRING COMMENT 'affiliate discountable indicator',
cmnts STRING COMMENT 'comments',
vndr_id STRING COMMENT 'vendor identifier',
prod_report_desc STRING COMMENT 'prod_report_desc',
prod_level_name STRING COMMENT 'prod_level_name',
mss_prod_desc STRING COMMENT 'mss product description',
upc_nbr DECIMAL(14,0) COMMENT 'upc_nbr',
upc_desc STRING COMMENT 'upc_desc',
upc_prod_id INT COMMENT 'upc product id',
ndc_nbr STRING COMMENT 'ndc_nbr',
first_scan_dt DATE COMMENT 'first_scan_dt{{"FORMAT":"yyyy-mm-dd" }}',
super_compet_ind STRING COMMENT 'super_compet_ind',
wic_desc STRING COMMENT 'wic_desc',
wic_buyer_nbr DECIMAL(3,0) COMMENT 'wic_buyer_nbr',
wic_buyer_name STRING COMMENT 'wic_buyer_name',
item_nbr STRING COMMENT 'item_nbr',
item_desc STRING COMMENT 'item_desc',
item_home_bd_nbr DECIMAL(4,0) COMMENT 'item_home_bd_nbr',
item_home_bd_desc STRING COMMENT 'item_home_bd_desc',
item_type_cd STRING COMMENT 'item_type_cd',
item_type_desc STRING COMMENT 'item_type_desc',
item_prod_id INT COMMENT 'item product identifier',
prod_source_cd STRING COMMENT 'prod_source_cd',
reorderable_ind STRING COMMENT 'reorderable_ind',
food_stamp_elig_ind STRING COMMENT 'food_stamp_elig_ind',
import_ind STRING COMMENT 'import_ind',
private_label_ind STRING COMMENT 'private_label_ind',
natl_prod_wic_nbr DECIMAL(6,0) COMMENT 'natl_prod_wic_nbr',
natl_prod_brd_name STRING COMMENT 'natl_prod_brd_name',
natl_prod_desc STRING COMMENT 'natl_prod_desc',
short_desc STRING COMMENT 'short_desc',
vol_of_measure DECIMAL(9,2) COMMENT 'vol_of_measure',
unit_of_measure_abbr STRING COMMENT 'unit_of_measure_abbr',
prod_height_inch DECIMAL(5,2) COMMENT 'prod_height_inch',
prod_width_inch DECIMAL(5,2) COMMENT 'prod_width_inch',
prod_depth_inch DECIMAL(5,2) COMMENT 'prod_depth_inch',
innerpack_qty DECIMAL(4,0) COMMENT 'innerpack_qty',
min_order_qty DECIMAL(7,0) COMMENT 'min_order_qty',
case_pack_qty DECIMAL(5,0) COMMENT 'case_pack_qty',
eas_tag_ind STRING COMMENT 'eas_tag_ind',
wic_established_dt DATE COMMENT 'wic_established_dt{{"FORMAT":"yyyy-mm-dd" }}',
whse_prod_vendor_name STRING COMMENT 'whse_prod_vendor_name',
shade_flavor_desc STRING COMMENT 'shade_flavor_desc',
mdse_lnk_nbr DECIMAL(15,0) COMMENT 'mdse_lnk_nbr',
base_forcast_lnk_nbr DECIMAL(6,0) COMMENT 'base_forcast_lnk_nbr',
parent_child_lnk_nbr DECIMAL(6,0) COMMENT 'parent_child_lnk_nbr',
same_retail_link_nbr DECIMAL(5,0) COMMENT 'same_retail_link_nbr',
ndc_single_comb_cd STRING COMMENT 'ndc_single_comb_cd',
ndc_storage_cond_cd STRING COMMENT 'ndc_storage_cond_cd',
ndc_dngrs_cond_ind STRING COMMENT 'ndc_dngrs_cond_ind',
ndc_cntrl_drug_class_cd STRING COMMENT 'ndc_cntrl_drug_class_cd',
ndc_cntrl_drug_nbr DECIMAL(3,0) COMMENT 'ndc_cntrl_drug_nbr',
cntrl_wic_nbr DECIMAL(6,0) COMMENT 'cntrl_wic_nbr',
brd_name STRING COMMENT 'brd_name',
private_label_brd_ind STRING COMMENT 'private_label_brd_ind',
brd_prod_id DECIMAL(8,0) COMMENT 'brd_prod_id',
item_discontinued_dt DATE COMMENT 'item_discontinued_dt{{"FORMAT":"yyyy-mm-dd" }}',
prod_seasonaltyp_desc STRING COMMENT 'prod_seasonaltyp_desc',
prod_attrib1_desc STRING COMMENT 'prod_attrib1_desc',
prod_attrib2_desc STRING COMMENT 'prod_attrib2_desc',
prod_attrib3_desc STRING COMMENT 'prod_attrib3_desc',
prod_attrib4_desc STRING COMMENT 'prod_attrib4_desc',
prod_attrib5_desc STRING COMMENT 'prod_attrib5_desc',
upc_only_ind STRING COMMENT 'upc_only_ind',
mdse_link_desc STRING COMMENT 'mdse_link_desc',
dmm_name STRING COMMENT 'dmm_name',
gmm_nbr DECIMAL(3,0) COMMENT 'gmm_nbr',
gmm_name STRING COMMENT 'gmm_name',
private_label_wic_nbr DECIMAL(6,0) COMMENT 'private_label_wic_nbr',
item_order_ind STRING COMMENT 'item_order_ind',
mult_relation_ind STRING COMMENT 'mult_relation_ind',
season_type_cd STRING COMMENT 'season_type_cd',
skus_per_retail_unit DECIMAL(7,0) COMMENT 'skus_per_retail_unit',
sub_dept_nbr DECIMAL(2,0) COMMENT 'sub_dept_nbr',
prod_attrib6_desc STRING COMMENT 'prod_attrib6_desc',
prod_attrib7_desc STRING COMMENT 'prod_attrib7_desc',
prod_attrib8_desc STRING COMMENT 'prod_attrib8_desc',
prod_attrib9_desc STRING COMMENT 'prod_attrib9_desc',
prod_attrib10_desc STRING COMMENT 'prod_attrib10_desc',
reorder_source_cd STRING COMMENT 'reorder_source_cd',
wic_dmm_name STRING COMMENT 'wic_dmm_name',
wic_dmm_nbr DECIMAL(3,0) COMMENT 'wic_dmm_nbr',
wic_gmm_name STRING COMMENT 'wic_gmm_name',
wic_gmm_nbr DECIMAL(3,0) COMMENT 'wic_gmm_nbr',
acn_dept_nbr DECIMAL(6,0) COMMENT 'AC Nielsen department DOUBLE',
assess_item_nbr DECIMAL(6,0) COMMENT 'assmt_item_nbr',
competitor_group_desc STRING COMMENT 'compet_grp_desc',
iri_dept_nbr DECIMAL(6,0) COMMENT 'iri_dept_nbr',
item_service_type STRING COMMENT 'item_service_type',
life_cycle_cd STRING COMMENT 'life_cycle_cd',
life_cycle_exit_dt DATE COMMENT 'life_cycle_exit_date{{"FORMAT":"yyyy-mm-dd" }}',
prod_char_desc STRING COMMENT 'prod_characteristic_desc',
sku_type_cd INT COMMENT 'sku type code',
sku_start_dt DATE COMMENT 'sku start date{{"FORMAT":"yyyy-mm-dd" }}',
sku_start_tm STRING COMMENT 'sku start time',
sku_end_dt DATE COMMENT 'sku end date{{"FORMAT":"yyyy-mm-dd" }}',
sku_end_tm STRING COMMENT 'sku end time',
sku_create_dt DATE COMMENT 'sku creation date{{"FORMAT":"yyyy-mm-dd" }}',
sku_create_tm STRING COMMENT 'sku creation time',
que_entry_dt DATE COMMENT 'queue entry date{{"FORMAT":"yyyy-mm-dd" }}',
que_entry_tm STRING COMMENT 'queue entry time',
que_cmnts STRING COMMENT 'queue COMMENTs',
str_return_avail_ind STRING COMMENT 'store return available indicator',
nutrition_label_avail_ind STRING COMMENT 'nutrition label available indicator',
admin_preord_ind STRING COMMENT 'admin preorder code',
fulfiller_type DECIMAL(18,0) COMMENT 'fulfiller_type',
sku_type_desc STRING COMMENT 'sku type description',
mfr_nbr DECIMAL(6,0) COMMENT 'mfr_nbr',
mfr_name STRING COMMENT 'mfr_name',
lens_pkg_days_supply SMALLINT COMMENT 'lens package days supply',
loyalty_elig_cd STRING COMMENT 'loyalty eligible code',
loyalty_redeem_elig_cd STRING COMMENT 'loyalty redeem eligible code',
price_relate_item_cd STRING COMMENT 'price relate item code',
edw_batch_id DECIMAL(18,0) COMMENT 'edw_batch_id',
edw_create_dtttm TIMESTAMP COMMENT 'edw CREATE datettime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw_update datetime'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://product-bussnstv@{getArgument('master_data_crt_sa')}.dfs.core.windows.net/product'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__master_data__product.product_wic_price_detail_data_migration(
wic STRING COMMENT 'wic',
rtl_lvl_nbr STRING COMMENT 'retail level DOUBLE',
rtl_eff_dt DATE COMMENT 'retail effective date{{"FORMAT":"YY/MM/DD" }}',
src_sys_cd STRING COMMENT 'source_system_code',
same_rtl_link_nbr STRING COMMENT 'same retail link DOUBLE',
loc_store_region_zone_price_sk BIGINT COMMENT 'loc_store_region_zone_change_sk',
rtl_terminate_dt DATE COMMENT 'retail termination date{{"FORMAT":"YY/MM/DD" }}',
rtl_price DECIMAL(7,2) COMMENT 'retail price',
rtl_price_rule SMALLINT COMMENT 'retail price rule',
rtl_mult DECIMAL(7,2) COMMENT 'retail multiple',
single_unit_rtl_price DECIMAL(7,2) COMMENT 'single unit retail price',
src_create_user_id STRING COMMENT 'source CREATE user id',
src_create_dttm TIMESTAMP COMMENT 'source CREATE datetime',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id')
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_master_data')}.dfs.core.windows.net/master_data/product/staging/product_wic_price_detail_data_migration'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__master_data__product.product_upc_price_detail_data_migration(
upc STRING COMMENT 'upc',
rtl_lvl_nbr STRING COMMENT 'retail level DOUBLE',
rtl_eff_dt DATE COMMENT 'retail effective date{{"FORMAT":"YY/MM/DD" }}',
src_sys_cd STRING COMMENT 'source_system_code',
same_rtl_link_nbr STRING COMMENT 'same retail link DOUBLE',
upc_prod_sk BIGINT COMMENT 'upc_product_sk',
loc_store_region_zone_price_sk BIGINT COMMENT 'loc_store_region_zone_change_sk',
src_sys_prod_id_1 STRING COMMENT 'source system prod id_1',
src_sys_prod_id_2 STRING COMMENT 'source system prod_id_2',
src_sys_prod_id_3 STRING COMMENT 'source system prod_id_3',
src_sys_prod_id_4 STRING COMMENT 'source_system_prod_id_4',
rtl_terminate_dt DATE COMMENT 'retail termination date{{"FORMAT":"YY/MM/DD" }}',
rtl_price DECIMAL(7,2) COMMENT 'retail price',
rtl_price_rule SMALLINT COMMENT 'retail price rule',
rtl_mult DECIMAL(7,2) COMMENT 'retail multiple',
single_unit_rtl_price DECIMAL(7,2) COMMENT 'single unit retail price',
src_create_user_id STRING COMMENT 'source CREATE user id',
src_create_dttm TIMESTAMP COMMENT 'source CREATE datetime',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id')
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_master_data')}.dfs.core.windows.net/master_data/product/staging/product_upc_price_detail_data_migration'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_consult_activity_data_migration(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT ,
rx_partial_fill_nbr INT ,
consult_actv_type_cd STRING ,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
fill_enter_tm STRING,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
consult_campaign_id DECIMAL(8,0),
dspn_fill_nbr SMALLINT ,
consult_actv_stat_ind STRING ,
consult_reqst_rph_user_id DECIMAL(9,0),
consult_reqst_rph_intl STRING ,
consult_reqst_dttm TIMESTAMP,
consult_reqst_cmnts STRING ,
consult_rslv_rph_user_id DECIMAL(9,0),
consult_rslv_rph_intl STRING ,
consult_rslv_dttm TIMESTAMP,
consult_rslv_cmnts STRING ,
src_create_user_id DECIMAL(9,0),
src_create_dttm TIMESTAMP,
src_update_user_id DECIMAL(9,0),
src_update_dttm TIMESTAMP,
remote_str_nbr INT,
edw_batch_id DECIMAL(18,0),
edw_gg_commit_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
relocate_fm_str_nbr INT ,
consult_rph_barcd_sprvsr_id DECIMAL(9,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_consult_activity_data_migration'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.sales_transaction_tender_data_migration(
sales_txn_id STRING,
sales_txn_type STRING,
src_sys_cd STRING,
sales_ord_src_type STRING,
tndr_seq_nbr SMALLINT,
card_hash_val_sk BIGINT,
tndr_type_cd STRING,
tndr_dlrs DECIMAL(8,2),
entry_mode_cd STRING,
acct_nbr STRING,
ck_bank_route_nbr DECIMAL(9,0),
ck_nbr DECIMAL(15,0),
expire_dt STRING,
service_cd STRING,
emv_cd STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_transaction_tender_data_migration'
PARTITIONED BY (
sales_txn_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.sales_transaction_detail_data_migration(
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_ord_src_type STRING COMMENT 'Sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
line_item_seq_nbr INT COMMENT 'line item sequence DOUBLE',
ord_item_id STRING COMMENT 'order item id',
dim_prod_sk BIGINT COMMENT 'product_dim_sk' ,
prod_price_chng_sk BIGINT COMMENT 'prod_price_chng_sk' ,
prod_sk BIGINT COMMENT 'product_sk' ,
upc_prod_sk BIGINT COMMENT 'upc product sk' ,
src_sys_prod_id_1 STRING COMMENT 'source system product id 1',
src_sys_prod_id_2 STRING COMMENT 'source system product id 2',
src_sys_prod_id_3 STRING COMMENT 'source system product id 3',
src_sys_prod_id_4 STRING COMMENT 'source system product id 4',
upc_nbr DECIMAL(14,0) COMMENT 'upc DOUBLE' ,
upc_desc STRING COMMENT 'upc_desc',
txn_type STRING COMMENT 'txn_type' ,
tax_type_cd STRING COMMENT 'tax_type_cd',
ecomm_order_ind STRING COMMENT 'ecomm_order_ind',
tax_exempt_ind STRING COMMENT 'tax_exempt_ind',
tax_exempt_id STRING COMMENT 'tax_exempt_id',
fsa_item_ind STRING COMMENT 'fsa_item_ind',
rx_not_on_ic_ind STRING COMMENT 'rx_not_on_ic_ind',
price_verify_ind STRING COMMENT 'price_verify_ind',
return_ind STRING COMMENT 'return_ind',
sale_ind STRING COMMENT 'sale_ind',
walgreen_brand_ind STRING COMMENT 'walgreen_brand_ind' ,
prod_id INT COMMENT 'prod_id',
rx_nbr STRING COMMENT 'rx_nbr',
item_unit_price_dlrs DECIMAL(12,2) COMMENT 'item_unit_price_dlrs',
original_price_dlrs DECIMAL(8,2) COMMENT 'original_price_dlrs' ,
selling_price_dlrs DECIMAL(8,2) COMMENT 'selling_price_dlrs',
unit_qty DECIMAL(18,0) COMMENT 'unit_qty' ,
item_void_cd STRING COMMENT 'item_void_cd',
ecomm_order_nbr DECIMAL(12,0) COMMENT 'ecomm_order_nbr' ,
over_age_cd STRING COMMENT 'over_age_cd',
birth_date DATE COMMENT 'birth_date{{"FORMAT":"YY/MM/DD" }}' ,
wag_coup_cd STRING COMMENT 'wag_coup_cd',
mfg_coup_cd STRING COMMENT 'mfg_coup_cd',
discnt_cd STRING COMMENT 'discnt_cd',
rx_type_cd STRING COMMENT 'rx_type_cd',
price_modify_cd STRING COMMENT 'price_modify_cd',
upc_hardkey_cd STRING COMMENT 'upc_hardkey_cd',
dept_hardkey_cd STRING COMMENT 'dept_hardkey_cd',
regstr_key_nbr SMALLINT COMMENT 'regstr_key_nbr' ,
payout_acct_nbr SMALLINT COMMENT 'payout_acct_nbr' ,
photo_env_nbr DECIMAL(11,0) COMMENT 'photo_env_nbr' ,
photo_print_cnt SMALLINT COMMENT 'photo_print_cnt' ,
item_sz DECIMAL(7,2) COMMENT 'item size' ,
discnt_applicable_qty DECIMAL(8,0) COMMENT 'discount applicable quantity' ,
discnt_qualify_qty DECIMAL(8,0) COMMENT 'discount qualify quantity' ,
rx_fill_nbr INT COMMENT 'rx fill DOUBLE' ,
xfer_rx_nbr INT COMMENT 'transfer rx DOUBLE' ,
rx_str_nbr INT COMMENT 'rx store DOUBLE' ,
rx_tranfer_to_str_nbr INT COMMENT 'rx tranfer to store DOUBLE' ,
list_price_dlrs DECIMAL(8,2) COMMENT 'list price dollars' ,
raw_tot_price_dlrs DECIMAL(8,2) COMMENT 'raw total price dollars' ,
sale_price_dlrs DECIMAL(8,2) COMMENT 'sale price dollars' ,
discnt_dlrs DECIMAL(8,2) COMMENT 'discount dollars' ,
prod_cost_dlrs DECIMAL(12,2) COMMENT 'product cost dollars' ,
price_before_discnt_dlrs DECIMAL(8,2) COMMENT 'price before discount dollars' ,
coupon_savings_dlrs DECIMAL(8,2) COMMENT 'coupon savings dollars' ,
aarp_ind STRING COMMENT 'aarp indicator' ,
availability_ind STRING COMMENT 'availability indicator' ,
price_override_reason STRING COMMENT 'price override reason',
eye_side STRING COMMENT 'eye side' ,
item_stat STRING COMMENT 'item status',
item_stat_detail STRING COMMENT 'item status detail',
orig_ord_wic DECIMAL(10,0) COMMENT 'original order wic' ,
est_price_dlrs DECIMAL(8,2) COMMENT 'estimated price dollars' ,
ready_price_dlrs DECIMAL(8,2) COMMENT 'ready price dollars' ,
ready_dt DATE COMMENT 'ready date{{"FORMAT":"YY/MM/DD" }}' ,
ready_tm STRING COMMENT 'ready time' ,
sold_dt DATE COMMENT 'sold date{{"FORMAT":"YY/MM/DD" }}' ,
sold_tm STRING COMMENT 'sold time' ,
voiding_dlrs DECIMAL(7,2) COMMENT 'voiding_dlrs',
disposable_item_desc STRING COMMENT 'disposable item description',
gqm_prod_id STRING COMMENT 'gqm_prod_id',
wic DECIMAL(18,0) COMMENT 'wic' ,
return_shipment_req_ind STRING COMMENT 'return shipment required indicator' ,
return_reason_desc STRING COMMENT 'return reason description',
return_stat_desc STRING COMMENT 'return status description',
prod_discnt_tot_dlrs DECIMAL(8,2) COMMENT 'product discount total dollars' ,
prod_price_before_discnt_dlrs DECIMAL(8,2) COMMENT 'product price before discount dollars' ,
return_bonus_dlrs DECIMAL(8,2) COMMENT 'return bonus dollars' ,
qty_rcvd DECIMAL(18,0) COMMENT 'quantity received' ,
qty_to_return DECIMAL(18,0) COMMENT 'quantity to return' ,
loyalty_earn_elig_ind STRING COMMENT 'loyalty eligible indicator' ,
loyalty_redeem_elig_ind STRING COMMENT 'loyalty redeem eligible indicator' ,
price_cd STRING COMMENT 'pricing code',
rx_partial_fill_cd_ind STRING COMMENT 'rx partial fill code indicator' ,
rx_primary_plan_gov_funded_ind STRING COMMENT 'rx primary plan government funded indicator' ,
rx_cob_plan_gov_funded_ind STRING COMMENT 'rx cob plan government funded indicator' ,
rx_30_to_90_day_ind STRING COMMENT 'rx 30 to 90 day indicator' ,
line_item_dtl_nbr DECIMAL(38,0) COMMENT 'line item detail DOUBLE from next gen pos' ,
wic_item_catg STRING COMMENT 'women infant children item category' ,
wic_item_sub_catg STRING COMMENT 'women infant children item sub category' ,
ewic_paid_item_ind STRING COMMENT 'ewic paid item indicator' ,
pos_id_type STRING COMMENT 'identifies the type of POS item' ,
evt_id STRING COMMENT 'event_id',
evt_desc STRING COMMENT 'event description',
item_correct_price DECIMAL(8,2) COMMENT 'item_correct_price' ,
item_sold_price DECIMAL(8,2) COMMENT 'item_sold_price' ,
prchd_card_type_name STRING COMMENT 'purchased card type name',
prchd_card_acct_nbr STRING COMMENT 'purchased card account DOUBLE',
prchd_card_activiation_stat_cd STRING COMMENT 'purchased card activiation status code',
orig_sales_txn_id STRING COMMENT 'original_sales_transaction_id',
orig_sales_txn_src_sys_cd STRING COMMENT 'original sales transaction source system code',
orig_sale_price_dlrs DECIMAL(8,2) COMMENT 'original_sale_price_dollars' ,
orig_refund_stat_cd STRING COMMENT 'original_refund_status_code' ,
orig_line_item_seq_nbr INT COMMENT 'original line item sequence DOUBLE' ,
actv_stat_cd STRING COMMENT 'activation status code',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id',
src_sys_cd STRING COMMENT 'sales_txn source system code',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YY/MM/DD" }}')
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_transaction_detail_data_migration'
PARTITIONED BY (
src_sys_cd,
sales_txn_dt)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_detail_rx (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YY/MM/DD" }}',
sales_ord_src_type STRING COMMENT 'Sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
line_item_seq_nbr INT COMMENT 'line item sequence DOUBLE',
rx_elig_ind STRING COMMENT 'rx eligible indicator',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_detail_rx'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_program (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YY/MM/DD" }}',
sales_ord_src_type STRING COMMENT 'Sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
prog_type_cd STRING COMMENT 'program_type_cd',
prog_acct_nbr STRING COMMENT 'program_acct_nbr',
prog_cust_id STRING COMMENT 'program_cust_nbr',
dim_cust_sk BIGINT COMMENT 'dim_cust_sk' ,
cust_sk BIGINT COMMENT 'cust_sk' ,
eid_dim_cust_sk BIGINT COMMENT 'eid_dim_cust_sk' ,
eid_cust_sk BIGINT COMMENT 'eid_cust_sk' ,
mid_dim_cust_sk BIGINT COMMENT 'mid_dim_cust_sk' ,
mid_cust_sk BIGINT COMMENT 'mid_cust_sk' ,
entry_mode_cd STRING COMMENT ' entry mode cd ',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime' ,
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_program'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl_data_migration(
sales_txn_id STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
payment_seq_nbr INT,
payment_stat STRING,
wallet_card_token STRING,
payment_token STRING,
payment_amt DECIMAL(10,2),
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_txn_dgtl_wallet_paymt_dtl_data_migration'
PARTITIONED BY (
sales_txn_dt STRING,
src_sys_cd STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.sales_txn_dgtl_wallet_dtl_data_migration(
sales_txn_id STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
wallet_seq_nbr INT,
wallet_data STRING,
inp_method STRING,
loyalty_mbr_id STRING,
edw_create_dttm TIMESTAMP,
edw_update_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_txn_dgtl_wallet_dtl_data_migration'
PARTITIONED BY (
sales_txn_dt STRING,
src_sys_cd STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__drug.drug_ic (
drug_id INT,
ndc_mfgr_nbr STRING ,
ndc_prod_nbr STRING ,
ndc_pkg_cd STRING ,
sims_upc STRING ,
repack_nbr STRING ,
ndc_form_cd SMALLINT,
prev_ndc_mfgr_nbr STRING ,
prev_ndc_prod_nbr STRING ,
prev_ndc_pkg_cd STRING ,
prev_repack_nbr STRING ,
prev_ndc_form_cd SMALLINT,
upc_hri_format_cd SMALLINT,
ndc_upc_hri_nbr STRING ,
dur_ndc STRING ,
prev_ndc_upc_hri_nbr STRING ,
prev_upc_hri_format_cd SMALLINT,
dea_class_cd STRING ,
orange_book_rating STRING ,
drug_name_cd STRING ,
generic_prod_pkg_cd STRING ,
generic_id_type_cd STRING ,
generic_ingrd_id DECIMAL(9,0),
ahfscc_therapeutic_class_cd INT,
limit_stability_cd STRING ,
pkg_desc STRING ,
rx_otc_cd STRING ,
maint_drug_ind STRING ,
route_admin STRING ,
generic_drug_cd STRING ,
drug_type_cd STRING ,
drug_single_combine_cd STRING ,
drug_storage_cd STRING ,
prod_name STRING ,
prod_name_suffix STRING ,
prod_name_extn STRING ,
prod_name_medispan_abbr STRING ,
generic_prod_id STRING ,
generic_prod_id_name STRING ,
mfgr_name STRING ,
mfgr_name_abbr STRING ,
medispan_mfgr_name_abbr STRING ,
mfgr_name_suffix STRING ,
drug_strength DECIMAL(13,5),
drug_strength_uom STRING ,
dosage_form_cd STRING ,
pkg_sz DECIMAL(8,3),
pkg_sz_uom STRING ,
pkg_qty INT,
rx_to_otc_dt DATE,
awp_per_unit_dlrs DECIMAL(10,5),
drug_cnt_cell_id DECIMAL(3,0),
awp_dt DATE,
hcfa_ffp_limit_eff_dt DATE,
hcfa_ffp_limit_dlrs DECIMAL(10,5),
prod_name_abbr STRING ,
drug_stat_cd STRING ,
drug_discontinue_dt DATE,
most_freq_prescribed_nbr STRING ,
wic_nbr INT,
pat_pkg_insert_ind STRING ,
min_dspnsbl_metric_qty DECIMAL(10,3),
default_sig STRING ,
default_day_supply SMALLINT,
drug_expire_day SMALLINT,
drug_class_excpn_ind STRING ,
ops_study_dept_nbr SMALLINT,
drug_whse_ind STRING ,
price_protect_ind STRING ,
puerto_rico_drug_ind STRING ,
price_override_drug_id INT,
price_type SMALLINT,
aac_per_unit_dlrs DECIMAL(10,5),
wac_per_unit_dlrs DECIMAL(10,5),
prorated_qty DECIMAL(10,3),
price_qty DECIMAL(10,3),
drug_shape_cd STRING ,
primary_color_cd STRING ,
secondary_color_cd STRING ,
drug_side_1_id STRING ,
drug_side_2_id STRING ,
bill_ndc STRING ,
drug_cmnt_cd STRING ,
default_smart_sig_cd STRING ,
drug_loc_cd STRING ,
drug_multihit_display_ind STRING ,
substn_drug_id INT,
substn_prod_type STRING ,
drug_volume DECIMAL(10,3),
precount_qty_ind STRING ,
precount_qty_1 SMALLINT,
precount_qty_2 SMALLINT,
dur_knowledge_base_drug_cd STRING ,
unit_dose_unit_of_use_cd STRING ,
label_cmnt_cd STRING ,
reconstitute_water_qty DECIMAL(5,1),
drug_spcl_cmnt_cd STRING ,
fax_pbr_cmnt_cd STRING ,
promise_substn_drug_id INT,
spclty_drug_ind STRING ,
piece_weight DECIMAL(6,4),
stock_bottle_barcode STRING ,
dose_per_pkg DECIMAL(5,0),
tot_discnt_card_pct DECIMAL(7,2),
pet_drug_ind STRING ,
limit_dstrb_cd STRING ,
complicate_supplies_ind STRING ,
spclty_review_ind STRING ,
clinical_val_ind STRING ,
req_supplies_ind STRING ,
mail_drug_multihit_display_ind STRING ,
mixed_ind STRING ,
drug_image_filename STRING ,
top_drug_image_ind STRING ,
quality_alert_msg STRING ,
quality_alert_keyword STRING ,
quality_alert_rule_ind STRING ,
quality_alert_screen_ind STRING ,
tip_ind STRING ,
ref_drug_id INT,
hc_proc_cd STRING ,
preferred_mfgr_drug_ind STRING ,
med_guide_filename STRING ,
med_guide_print_ind STRING ,
item_class DECIMAL(12,0),
item_formulary_ind STRING ,
item_lob DECIMAL(12,0),
item_conv_factor DECIMAL(18,4),
item_list_price_dlrs DECIMAL(12,2),
item_rtl_price_dlrs DECIMAL(12,2),
item_prch_uom DECIMAL(12,0),
item_selling_uom DECIMAL(12,0),
specific_gravity DECIMAL(18,4),
conc_nbr DECIMAL(18,4),
drug_item_conc_unit_cd DECIMAL(12,0),
lipids_ind STRING ,
amino_acid_ind STRING ,
poolable_ind STRING ,
trace_element_ind STRING ,
electrolyte_ind STRING ,
contnr_material_cd DECIMAL(12,0),
contnr_max_capacity DECIMAL(18,4),
drug_vehicle_method_ind STRING ,
drug_vehicle_method DECIMAL(12,0),
cocktail_ind STRING ,
base_ind STRING ,
item_type_cd DECIMAL(12,0),
conc_dextrose_ind STRING ,
contnr_ind STRING ,
contnr_type DECIMAL(12,0),
plx_drug_use_ind STRING ,
item_pkg_sz DECIMAL(18,4),
item_pkg_sz_uom DECIMAL(12,0),
item_full_name STRING ,
item_short_name STRING ,
item_awp_dlrs DECIMAL(16,6),
item_bill_factor DECIMAL(18,4),
drug_disease_type_cd STRING ,
item_drug_sub_catg DECIMAL(12,0),
item_drug_catg DECIMAL(12,0),
item_drug_sub_grp DECIMAL(12,0),
item_drug_grp DECIMAL(12,0),
src_eff_dt DATE,
src_eff_tm STRING,
src_create_user_id DECIMAL(9,0),
src_update_user_id DECIMAL(9,0),
src_end_dt DATE,
src_end_tm STRING,
edw_batch_id DECIMAL(18,0),
track_inv_ind STRING ,
src_create_dttm TIMESTAMP,
history_seq_nbr SMALLINT,
inferred_drug_ind STRING ,
min_drug_price_dlrs DECIMAL(4,2),
excl_drug_auto_rcmd_ind STRING ,
medicare_b_dts_ind STRING,
excl_tbltop_cnt_ind STRING ,
require_tbltop_clean_ind STRING ,
ahfs_extend_therapeutic_class_cd STRING,
hzrds_lvl_cd STRING ,
AUTH_GENERIC_CD STRING ,
FDA_IND STRING ,
FDA_IND_VALUE STRING ,
AUTH_NDC_UPC_HRI STRING ,
AUTH_GEN_OVERRIDE_IND STRING ,
DDID STRING ,
RXCUI_TYPE STRING ,
RXCUI STRING ,
ELSEVIER_PACK_ID STRING,
ELSEVIER_PROD_ID STRING,
MED_DOSAGE_UNIT DECIMAL(6,2),
MED_CONV_FACTOR DECIMAL(6,2),
MME_CALC_FACTOR DECIMAL(6,2)
,delta_batch_id  DECIMAL(18,0))
USING DELTA
PARTITIONED BY (
history_seq_cd STRING)
LOCATION
'abfss://drug-bussnstv@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/drug_ic'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.digital_coupon_offer(
offer_cd STRING COMMENT 'offer code',
src_sys_cd STRING COMMENT 'source system code',
ad_evt_sk BIGINT COMMENT 'ad evt sk',
actv_dttm TIMESTAMP COMMENT 'active datetime',
actv_timezone STRING COMMENT 'active timezone',
expire_dttm TIMESTAMP COMMENT 'expire datetime',
expire_timezone STRING COMMENT 'expire timezone',
campgn_shutoff_dttm TIMESTAMP COMMENT 'campaign shutoff datetime' ,
campgn_shutoff_timezone STRING COMMENT 'campaign shutoff timezone',
offer_desc STRING COMMENT 'offer description',
offer_src_name STRING COMMENT 'offer source name',
offer_val DECIMAL(7,2) COMMENT 'offer value',
prod_brand_name STRING COMMENT 'product brand name',
prod_mfgr_name STRING COMMENT 'product manufacturer name',
prtnr_cd STRING COMMENT 'partner code',
campgn_cd STRING COMMENT 'campaign code',
ser_nbr STRING COMMENT 'serial DOUBLE',
barcode_type STRING COMMENT 'barcode type',
barcode STRING COMMENT 'barcode',
group_lvl_1_name STRING COMMENT 'group level 1 name',
group_lvl_2_name STRING COMMENT 'group level 2 name',
catg_lvl_1_name STRING COMMENT 'category level 1 name',
catg_lvl_2_name STRING COMMENT 'category level 2 name',
catg_lvl_3_name STRING COMMENT 'category level 3 name',
catg_lvl_4_name STRING COMMENT 'category level 4 name',
catg_lvl_5_name STRING COMMENT 'category level 5 name',
stat STRING COMMENT 'status',
origin_company_name STRING COMMENT 'origin company name',
desc_sumr STRING COMMENT 'description summary',
dsclmr_txt STRING COMMENT 'disclaimer text',
intent_txt STRING COMMENT 'intent text',
offer_keywords STRING COMMENT 'offer keywords',
link_url STRING COMMENT 'link url',
link_txt STRING COMMENT 'link text',
unit_cost_dlrs DECIMAL(5,2) COMMENT 'unit cost dollars',
unit_rev_dlrs DECIMAL(5,2) COMMENT 'unit revenue dollars',
condition_min_basket_val DECIMAL(5,2) COMMENT 'condition minimum basket value',
condition_min_qty_prchd INT COMMENT 'condition minimum quantity purchased',
condition_min_trip_cnt INT COMMENT 'condition minimum trip count',
condition_redmptn_freq STRING COMMENT 'condition redemption frequency',
condition_redmptn_limit INT COMMENT 'condition redemption limit',
condition_shop_x_tms INT COMMENT 'condition shop x times',
condition_user_actv_limit INT COMMENT 'condition user activation limit',
prch_ord INT COMMENT 'purchase order',
is_dgtl_offer_cd STRING COMMENT 'is digital offer code',
tgted_cd STRING COMMENT 'targeted code',
spcl_cnsd_cd STRING COMMENT 'special consideration code',
reward_type STRING COMMENT 'reward type',
reward_qty INT COMMENT 'reward quantity',
catg_lvl_1_image_url STRING COMMENT 'category level 1 image url',
image_1 STRING COMMENT 'image 1',
image_2 STRING COMMENT 'image 2',
misc_promo_cd STRING COMMENT 'miscellaneous promotion code',
misc_group_cd STRING COMMENT 'miscellaneous group code',
misc_store_cd STRING COMMENT 'miscellaneous store code',
misc_store_stat STRING COMMENT 'miscellaneous store status',
misc_display_type STRING COMMENT 'miscellaneous display type',
misc_mfgr_acct_nbr STRING COMMENT 'miscellaneous manufacturer account DOUBLE',
misc_clearing_hse_clearing_cd STRING COMMENT 'miscellaneous clearing house clearing code',
misc_clearing_hse_cntc_name STRING COMMENT 'miscellaneous clearing house contact name',
mfgr_offer_cd STRING COMMENT 'manufacturer offer code',
offer_inv_qty INT COMMENT 'offer inventory quantity',
offer_bal_qty INT COMMENT 'offer balance quantity',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/digital_coupon_offer'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.digital_coupon_redeemed_prod(
offer_cd STRING COMMENT 'offer code',
loyalty_cust_sk BIGINT COMMENT 'loyalty customer sk',
upc_prod_sk BIGINT COMMENT 'upc_prod_sk',
upc_qty INT COMMENT 'prod_qty',
loyalty_mbr_id STRING COMMENT 'loyalty member identifier',
upc STRING COMMENT 'upc',
prod_id_1 STRING COMMENT 'product identifier 1',
prod_id_2 STRING COMMENT 'product identifier 2',
prod_id_3 STRING COMMENT 'product identifier 3',
prod_id_4 STRING COMMENT 'product identifier 4',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/digital_coupon_redeemed_prod'
PARTITIONED BY (
edw_create_year STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.digital_coupon_user_activity(
offer_cd STRING COMMENT 'offer code',
loyalty_cust_sk BIGINT COMMENT 'loyalty customer sk',
loyalty_mbr_id STRING COMMENT 'loyalty member identifier',
coupon_clip_dttm TIMESTAMP COMMENT 'coupon clip datetime',
coupon_redmptn_dttm TIMESTAMP COMMENT 'coupon redemption datetime' ,
rfn_value STRING COMMENT 'rfn value' ,
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"yyyy-mm-dd" }}' ,
sales_txn_type STRING COMMENT 'sales_txn type' ,
sales_txn_src_sys_cd STRING COMMENT 'sales_txn source system code',
sales_ord_src_type STRING COMMENT 'sales order source type' ,
coupon_actv_type_name STRING COMMENT 'coupon activation type name',
coupon_clip_channel_name STRING COMMENT 'coupon clip channel name',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://campaign-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/digital_coupon_user_activity'
PARTITIONED BY (
edw_create_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_customer_program(
cust_sk BIGINT COMMENT 'customer sk',
prog_id STRING COMMENT 'program identifier',
prog_cd STRING COMMENT 'program code',
prog_start_dt DATE COMMENT 'program start date{{"FORMAT":"YY/MM/DD" }}',
loyalty_mbr_id STRING COMMENT 'loyalty member identifier',
src_sys_cd STRING COMMENT 'source system code',
composite_type_cd STRING COMMENT 'composite type code',
msg_type_cd STRING COMMENT 'message type code',
prog_stat_cd STRING COMMENT 'program status code',
prog_end_dt DATE COMMENT 'program end date{{"FORMAT":"YY/MM/DD" }}',
security_class_cd STRING COMMENT 'security class code',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_customer_program'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_enrollment(
cust_sk BIGINT COMMENT 'customer sk',
loyalty_mbr_id STRING COMMENT 'loyalty member identifier',
src_sys_cd STRING COMMENT 'source system code',
composite_type_cd STRING COMMENT 'composite type code',
msg_type_cd STRING COMMENT 'message type code',
enrl_dt DATE COMMENT 'enrollment date{{"FORMAT":"YY/MM/DD" }}',
enrl_chnnl STRING COMMENT 'enrollment channel',
dim_loc_store_sk BIGINT COMMENT 'dim location store sk',
loc_store_sk BIGINT COMMENT 'location store sk',
store_nbr DECIMAL(7,0) COMMENT 'store DOUBLE',
agent_id STRING COMMENT 'agent identifier',
assoc_id STRING COMMENT 'associate identifier',
store_register_chng_sk BIGINT COMMENT 'store register change sk',
register_nbr SMALLINT COMMENT 'register DOUBLE',
rfn_val STRING COMMENT 'rfn value',
acqstn_strgy_cd STRING COMMENT 'acquisition strategy code',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_enrollment'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_member_point_balance(
loyalty_mbr_id STRING COMMENT 'loyalty member id',
postd_dt DATE COMMENT 'posted date{{"FORMAT":"YY/MM/DD" }}',
edw_rec_begin_dt DATE COMMENT 'edw_record begin date{{"FORMAT":"YY/MM/DD" }}' ,
edw_rec_end_dt DATE COMMENT 'edw record end date{{"FORMAT":"YY/MM/DD" }}' ,
loyalty_dim_cust_sk BIGINT COMMENT 'loyalty dim_cust_sk' ,
loyalty_cust_sk BIGINT COMMENT 'loyalty cust_sk' ,
loyalty_eid_dim_cust_sk BIGINT COMMENT 'loyalty eid_dim_cust_sk' ,
loyalty_eid_cust_sk BIGINT COMMENT 'loyalty eid_cust_sk' ,
loyalty_mid_dim_cust_sk BIGINT COMMENT 'loyalty mid_dim_cust_sk' ,
loyalty_mid_cust_sk BIGINT COMMENT 'loyalty mid_cust_sk' ,
pnt_bal DECIMAL(11,2) COMMENT 'point balance' ,
pnt_range_cd STRING COMMENT 'point range code' ,
pnt_to_next_tier INT COMMENT 'point to next tier' ,
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_member_point_balance'
PARTITIONED BY (
edw_rec_end_mnth STRING )""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_mss_vendor_deal(
wic DECIMAL(6,0) COMMENT 'wic',
upc_nbr DECIMAL(14,0) COMMENT 'upc DOUBLE',
dim_ad_evt_sk BIGINT COMMENT 'dim advertisement event sk',
ad_evt_type STRING COMMENT 'advertisement event type',
ad_evt_seq_nbr STRING COMMENT 'advertisement event sequence DOUBLE',
ad_evt_vers_type_cd STRING COMMENT 'advertisement event version type code',
ad_evt_vers_seq_nbr STRING COMMENT 'advertisement event version sequence DOUBLE',
ad_offer_cd STRING COMMENT 'advertisement offer code',
sales_txn_dt DATE COMMENT 'sales transaction date{{"FORMAT":"YY/MM/DD" }}',
postd_dttm TIMESTAMP COMMENT ' Posted Datetime',
dim_prod_sk BIGINT COMMENT 'dim_product sk',
upc_prod_sk BIGINT COMMENT 'upc product sk',
dim_loc_str_sk BIGINT COMMENT 'dim_loc_str_sk',
loc_store_sk BIGINT COMMENT 'loc_store_sk',
store_nbr INT COMMENT ' Store DOUBLE',
vndr_id INT COMMENT 'vendor identifier',
rate DECIMAL(14,5) COMMENT 'rate',
calc_cost DECIMAL(14,5) COMMENT 'calculated cost',
pnt_val DECIMAL(38,0) COMMENT ' Point value ',
deal_id INT COMMENT 'deal id',
internal_fund_ind STRING COMMENT 'internal fund indicator',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_mss_vendor_deal'
PARTITIONED BY (
postd_mnth STRING )""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_offer(
LOYALTY_ATTRIB_ID INT COMMENT 'LOYALTY ATTRIBUTE IDENTIFIER',
LOYALTY_ATTRIB STRING COMMENT 'LOYALTY ATTRIBUTE',
LOYALTY_ATTRIB_LONG_DESC STRING COMMENT 'LOYALTY ATTRIBUTE LONG DESCRIPTION',
ATTRIB_DATA_TYPE STRING COMMENT 'ATTRIBUTE_DATA_TYPE',
ATTRIB_SZ INT COMMENT 'ATTRIBUTE_SIZE',
DECIMAL_SZ INT COMMENT 'DECIMAL_SIZE',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'EDW_CREATE_DTTM',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'EDW_UPDATE_DTTM',
EDW_BATCH_ID DECIMAL(18,0) COMMENT 'EDW_BATCH_ID'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_offer'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_offer_template(
LOYALTY_ATTRIB_ID INT COMMENT 'LOYALTY ATTRIBUTE IDENTIFIER',
LOYALTY_TEMPLATE_TYPE STRING COMMENT 'LOYALTY TEMPLATE TYPE',
LOYALTY_ATTRIB_SEQ_NBR INT COMMENT 'LOYALTY ATTRIBUTE SEQUENCE DOUBLE',
MNDTY_IND STRING COMMENT 'MANDATORY_IND',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'EDW_CREATE_DTTM',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'EDW_UPDATE_DTTM',
EDW_BATCH_ID DECIMAL(18,0) COMMENT 'EDW_BATCH_ID'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_offer_template'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS master_data__product.product_upc_price_detail(
upc STRING COMMENT 'upc',
rtl_lvl_nbr STRING COMMENT 'retail level DOUBLE',
rtl_eff_dt DATE COMMENT 'retail effective date{{"FORMAT":"YY/MM/DD" }}',
src_sys_cd STRING COMMENT 'source_system_code',
same_rtl_link_nbr STRING COMMENT 'same retail link DOUBLE',
upc_prod_sk BIGINT COMMENT 'upc_product_sk',
loc_store_region_zone_price_sk BIGINT COMMENT 'loc_store_region_zone_change_sk',
src_sys_prod_id_1 STRING COMMENT 'source system prod id_1',
src_sys_prod_id_2 STRING COMMENT 'source system prod_id_2',
src_sys_prod_id_3 STRING COMMENT 'source system prod_id_3',
src_sys_prod_id_4 STRING COMMENT 'source_system_prod_id_4',
rtl_terminate_dt DATE COMMENT 'retail termination date{{"FORMAT":"YY/MM/DD" }}',
rtl_price DECIMAL(7,2) COMMENT 'retail price',
rtl_price_rule SMALLINT COMMENT 'retail price rule',
rtl_mult DECIMAL(7,2) COMMENT 'retail multiple',
single_unit_rtl_price DECIMAL(7,2) COMMENT 'single unit retail price',
src_create_user_id STRING COMMENT 'source CREATE user id',
src_create_dttm TIMESTAMP COMMENT 'source CREATE datetime',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0)
)
USING DELTA
LOCATION
'abfss://product-bussnstv@{getArgument('master_data_crt_sa')}.dfs.core.windows.net/product_upc_price_detail'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS master_data__product.product_wic_price_detail(
wic STRING COMMENT 'wic',
rtl_lvl_nbr STRING COMMENT 'retail level DOUBLE',
rtl_eff_dt DATE COMMENT 'retail effective date{{"FORMAT":"YY/MM/DD" }}',
src_sys_cd STRING COMMENT 'source_system_code',
same_rtl_link_nbr STRING COMMENT 'same retail link DOUBLE',
loc_store_region_zone_price_sk BIGINT COMMENT 'loc_store_region_zone_change_sk',
rtl_terminate_dt DATE COMMENT 'retail termination date{{"FORMAT":"YY/MM/DD" }}',
rtl_price DECIMAL(7,2) COMMENT 'retail price',
rtl_price_rule SMALLINT COMMENT 'retail price rule',
rtl_mult DECIMAL(7,2) COMMENT 'retail multiple',
single_unit_rtl_price DECIMAL(7,2) COMMENT 'single unit retail price',
src_create_user_id STRING COMMENT 'source CREATE user id',
src_create_dttm TIMESTAMP COMMENT 'source CREATE datetime',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0)
)
USING DELTA
LOCATION
'abfss://product-bussnstv@{getArgument('master_data_crt_sa')}.dfs.core.windows.net/product_wic_price_detail'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_txn_apriss_return_auth(
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date',
sales_ord_src_type STRING COMMENT 'sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'source system code',
seq_nbr DECIMAL(38,0) COMMENT 'sequence DOUBLE',
apriss_auth_stat STRING COMMENT 'apriss authorization status',
apriss_txn_id STRING COMMENT 'apriss transaction id',
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_txn_apriss_return_auth'
PARTITIONED BY (
sales_txn_dt,
src_sys_cd)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_txn_dgtl_wallet_dtl(
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date',
sales_ord_src_type STRING COMMENT 'sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'source system code',
wallet_seq_nbr INT COMMENT 'wallet sequence DOUBLE',
wallet_data STRING COMMENT 'wallet data',
inp_method STRING COMMENT 'input method',
loyalty_mbr_id STRING COMMENT 'loyalty member id',
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_txn_dgtl_wallet_dtl'
PARTITIONED BY (
sales_txn_dt,
src_sys_cd)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl(
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date',
sales_ord_src_type STRING COMMENT 'sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'source system code',
payment_seq_nbr INT COMMENT 'payment sequence DOUBLE',
payment_stat STRING COMMENT 'payment status',
wallet_card_token STRING COMMENT 'wallet card token',
payment_token STRING COMMENT 'payment token',
payment_amt DECIMAL(10,2) COMMENT 'payment amount',
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_txn_dgtl_wallet_paymt_dtl'
PARTITIONED BY (
sales_txn_dt,
src_sys_cd)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS mna_buyout__pharmacy_healthcare.buyout_patient(
buyout_pat_id STRING ,
buyout_phrm_ncpdp_nbr STRING ,
buyout_pat_purged_rx_ind STRING ,
rcvng_phrm_str_nbr INT ,
wag_pat_id DECIMAL(13,0),
vndr_name STRING ,
first_name STRING ,
middle_initial STRING ,
last_name STRING ,
last_name_suffix STRING ,
brth_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
gndr_cd STRING ,
phone_area_cd STRING ,
phone_nbr STRING ,
addr_line STRING ,
city STRING ,
state_cd STRING ,
zip_cd_5 STRING ,
zip_cd_4 STRING ,
src_create_dttm TIMESTAMP,
src_create_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
src_update_dttm TIMESTAMP ,
phrm_name STRING ,
phrm_dea_nbr STRING ,
phrm_phone_area_cd STRING ,
phrm_phone_nbr STRING ,
phrm_addr_line STRING ,
phrm_city STRING ,
phrm_state_cd STRING ,
phrm_zip_cd_5 STRING ,
phrm_zip_cd_4 STRING
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-pii@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/buyout_patient'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS mna_buyout__pharmacy_healthcare.buyout_prescription(
buyout_rx_nbr STRING ,
buyout_phrm_ncpdp_nbr STRING ,
buyout_pat_id STRING ,
buyout_rph_init STRING ,
ndc_mfgr_nbr STRING ,
ndc_prod_nbr STRING ,
ndc_pkg_cd STRING ,
drug_name STRING ,
drug_strength STRING ,
drug_mfgr_name STRING ,
rx_daw_ind STRING ,
orig_fill_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
rx_stat_cd STRING ,
rx_sig STRING ,
rx_written_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
rx_orig_qty DECIMAL(8,3) ,
rx_orig_dspn_qty DECIMAL(8,3) ,
rx_cmnt STRING ,
rx_remain_qty DECIMAL(9,2) ,
rx_prescribed_day_supply SMALLINT ,
rx_prescribed_fill_cnt SMALLINT ,
rx_remain_fill_cnt SMALLINT ,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
pbr_dea_nbr STRING ,
pbr_first_name STRING ,
pbr_last_name STRING ,
pbr_addr_line STRING ,
pbr_city STRING ,
pbr_state_cd STRING ,
pbr_zip_cd_5 STRING ,
pbr_zip_cd_4 STRING ,
close_reason_cd STRING ,
close_reason_cmnt STRING ,
cmptr_str_name STRING ,
cmptr_phone_area_cd STRING ,
cmptr_phone_nbr STRING ,
xfer_to_str_nbr INT ,
xfer_to_rx_nbr DECIMAL(7,0) ,
xfer_to_rph_initials STRING ,
xfer_to_tech_initials STRING ,
xfer_fm_str_nbr INT ,
xfer_fm_rph_initials STRING ,
xfer_fm_tech_initials STRING ,
xfer_reason_cd STRING ,
wag_pat_id DECIMAL(13,0) ,
src_create_dttm TIMESTAMP,
src_create_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
src_update_dttm TIMESTAMP
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/buyout_prescription'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS mna_buyout__pharmacy_healthcare.buyout_prescription_fill(
buyout_rx_nbr STRING ,
buyout_fill_nbr SMALLINT,
buyout_phrm_ncpdp_nbr STRING ,
fill_dspn_qty DECIMAL(8,3) ,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
rtl_price_dlrs DECIMAL(8,2) ,
pat_copay_dlrs DECIMAL(8,2) ,
rph_initials STRING ,
drug_name STRING ,
fill_stat_cd STRING ,
src_create_dttm TIMESTAMP,
src_create_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
src_update_dttm TIMESTAMP
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/buyout_prescription_fill'""")
# COMMAND ----------
migration_data=[{"release": "8.2.0", "scripts": ["D.15.1.crt.marketing__loyalty.sql", "D.5.1.crt.marketing__campaign.sql", "D.11.1.crt.pharmacy_healthcare__drug.sql", "D.26.1.crt.mna_buyout__pharmacy_healthcare.sql", "D.13.1.crt.master_data__product.sql", "D.83.1.wrg.master_data__product.sql", "D.6.1.crt.pharmacy_healthcare__patient_services.sql", "D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "D.16.1.crt.retail__retail_sales.sql", "D.50.1.wrg.retail__retail_sales.sql", "T.1908.1.crt.tl_prescription_return_call_list.sql", "T.228.1.crt.digital_coupon_offer.sql", "T.229.1.crt.digital_coupon_redeemed_prod.sql", "T.230.1.crt.digital_coupon_user_activity.sql", "T.265.1.crt.loyalty_customer_program.sql", "T.267.1.crt.loyalty_enrollment.sql", "T.269.1.crt.loyalty_member_point_balance.sql", "T.275.1.crt.loyalty_offer_template.sql", "T.19945.1.wrg.tl_prescription_return_call_list_data_migration.sql", "T.273.1.crt.loyalty_mss_vendor_deal.sql", "T.1715.1.crt.prescription_sdl_reject.sql", "T.1868.1.crt.tender_card_hash.sql", "T.274.1.crt.loyalty_offer.sql", "T.19969.1.wrg.prescription_sdl_reject_data_migration.sql", "T.19968.1.wrg.tender_card_hash_data_migration.sql", "T.373.1.crt.sales_txn_apriss_return_auth.sql", "T.19972.1.wrg.sales_txn_apriss_return_auth_data_migration.sql", "T.19971.1.crt.sales_transaction.sql", "T.19973.1.wrg.sales_transaction_data_migration.sql", "T.19974.1.crt.product.sql", "T.322.1.crt.product_upc_price_detail.sql", "T.19976.1.wrg.product_upc_price_detail_data_migration.sql", "T.323.1.crt.product_wic_price_detail.sql", "T.19975.1.wrg.product_wic_price_detail_data_migration.sql", "T.1637.1.crt.prescription_consult_activity.sql", "T.19979.1.wrg.prescription_consult_activity_data_migration.sql", "T.19980.1.wrg.sales_transaction_tender_data_migration.sql", "T.1801.1.crt.sales_transaction_tender.sql", "T.994.1.crt.buyout_patient.sql", "T.995.1.crt.buyout_prescription.sql", "T.996.1.crt.buyout_prescription_fill.sql", "T.1793.1.crt.sales_transaction_detail.sql", "T.19981.1.wrg.sales_transaction_detail_data_migration.sql", "T.19988.1.wrg.sales_txn_dgtl_wallet_paymt_dtl_data_migration.sql", "T.375.1.crt.sales_txn_dgtl_wallet_paymt_dtl.sql", "T.19986.1.crt.sales_transaction_detail_rx.sql", "T.19986.1.crt.sales_transaction_program.sql", "T.374.1.crt.sales_txn_dgtl_wallet_dtl.sql", "T.19992.1.wrg.sales_txn_dgtl_wallet_dtl_data_migration.sql", "T.19993.1.crt.drug_ic.sql"], "migration_date": "2022-08-12"}]
table_data=[{"release": "8.2.0", "table_id": "T.1908.1", "table_name": "tl_prescription_return_call_list", "table_schema": "pharmacy_healthcare__patient_services.tl_prescription_return_call_list", "table_legacy_schema": "dae_cooked.tl_prescription_return_call_list", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.tl_prescription_return_call_list", "table_partition": "\n  fill_sold_yr STRING, \n  fill_enter_yrmnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.228.1", "table_name": "digital_coupon_offer", "table_schema": "marketing__campaign.digital_coupon_offer", "table_legacy_schema": "acapdb.digital_coupon_offer", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.digital_coupon_offer", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.229.1", "table_name": "digital_coupon_redeemed_prod", "table_schema": "marketing__campaign.digital_coupon_redeemed_prod", "table_legacy_schema": "acapdb.digital_coupon_redeemed_prod", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.digital_coupon_redeemed_prod", "table_partition": "\n  edw_create_year STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.230.1", "table_name": "digital_coupon_user_activity", "table_schema": "marketing__campaign.digital_coupon_user_activity", "table_legacy_schema": "acapdb.digital_coupon_user_activity", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.digital_coupon_user_activity", "table_partition": "\n  edw_create_month STRING", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.265.1", "table_name": "loyalty_customer_program", "table_schema": "marketing__loyalty.loyalty_customer_program", "table_legacy_schema": "acapdb.loyalty_customer_program", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_customer_program", "table_partition": "", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.267.1", "table_name": "loyalty_enrollment", "table_schema": "marketing__loyalty.loyalty_enrollment", "table_legacy_schema": "acapdb.loyalty_enrollment", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_enrollment", "table_partition": "", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.269.1", "table_name": "loyalty_member_point_balance", "table_schema": "marketing__loyalty.loyalty_member_point_balance", "table_legacy_schema": "acapdb.loyalty_member_point_balance", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_member_point_balance", "table_partition": "\n  edw_rec_end_mnth STRING ", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.275.1", "table_name": "loyalty_offer_template", "table_schema": "marketing__loyalty.loyalty_offer_template", "table_legacy_schema": "acapdb.loyalty_offer_template", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_offer_template", "table_partition": "", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19945.1", "table_name": "tl_prescription_return_call_list_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.tl_prescription_return_call_list_data_migration", "table_legacy_schema": "dae_cooked.tl_prescription_return_call_list", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.tl_prescription_return_call_list_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.273.1", "table_name": "loyalty_mss_vendor_deal", "table_schema": "marketing__loyalty.loyalty_mss_vendor_deal", "table_legacy_schema": "acapdb.loyalty_mss_vendor_deal", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_mss_vendor_deal", "table_partition": "\n  postd_mnth STRING ", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.1715.1", "table_name": "prescription_sdl_reject", "table_schema": "pharmacy_healthcare__patient_services.prescription_sdl_reject", "table_legacy_schema": "dae_cooked.prescription_sdl_reject", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_sdl_reject", "table_partition": "\n  fill_sold_yr STRING, \n  fill_enter_yrmnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.1868.1", "table_name": "tender_card_hash", "table_schema": "retail__retail_sales.tender_card_hash", "table_legacy_schema": "dae_cooked.tender_card_hash", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.tender_card_hash", "table_partition": "\n  edw_create_dt STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.274.1", "table_name": "loyalty_offer", "table_schema": "marketing__loyalty.loyalty_offer", "table_legacy_schema": "acapdb.loyalty_offer", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_offer", "table_partition": "", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19969.1", "table_name": "prescription_sdl_reject_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_sdl_reject_data_migration", "table_legacy_schema": "dae_cooked.prescription_sdl_reject", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_sdl_reject_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19968.1", "table_name": "tender_card_hash_data_migration", "table_schema": "staging__retail__retail_sales.tender_card_hash_data_migration", "table_legacy_schema": "acapdb.tender_card_hash", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.tender_card_hash_data_migration", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.373.1", "table_name": "sales_txn_apriss_return_auth", "table_schema": "retail__retail_sales.sales_txn_apriss_return_auth", "table_legacy_schema": "acapdb.sales_txn_apriss_return_auth", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_txn_apriss_return_auth", "table_partition": "\n  sales_txn_dt STRING , \n  src_sys_cd STRING ", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19972.1", "table_name": "sales_txn_apriss_return_auth_data_migration", "table_schema": "staging__retail__retail_sales.sales_txn_apriss_return_auth_data_migration", "table_legacy_schema": "acapdb.sales_txn_apriss_return_auth", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.sales_txn_apriss_return_auth_data_migration", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19971.1", "table_name": "sales_transaction", "table_schema": "retail__retail_sales.sales_transaction", "table_legacy_schema": "dae_cooked.sales_transaction", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction", "table_partition": "", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19973.1", "table_name": "sales_transaction_data_migration", "table_schema": "staging__retail__retail_sales.sales_transaction_data_migration", "table_legacy_schema": "dae_cooked.sales_transaction", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.sales_transaction_data_migration", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19974.1", "table_name": "product", "table_schema": "master_data__product.product", "table_legacy_schema": "dae_cooked.product", "table_domain": "master_data", "table_subdomain": "product", "table_location": "master_data__product.product", "table_partition": "", "table_db": "master_data__product", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.322.1", "table_name": "product_upc_price_detail", "table_schema": "master_data__product.product_upc_price_detail", "table_legacy_schema": "acapdb.product_upc_price_detail", "table_domain": "master_data", "table_subdomain": "product", "table_location": "master_data__product.product_upc_price_detail", "table_partition": "", "table_db": "master_data__product", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19976.1", "table_name": "product_upc_price_detail_data_migration", "table_schema": "staging__master_data__product.product_upc_price_detail_data_migration", "table_legacy_schema": "acapdb.product_upc_price_detail", "table_domain": "master_data", "table_subdomain": "product", "table_location": "staging__master_data__product.product_upc_price_detail_data_migration", "table_partition": "", "table_db": "staging__master_data__product", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.323.1", "table_name": "product_wic_price_detail", "table_schema": "master_data__product.product_wic_price_detail", "table_legacy_schema": "acapdb.product_wic_price_detail", "table_domain": "master_data", "table_subdomain": "product", "table_location": "master_data__product.product_wic_price_detail", "table_partition": "", "table_db": "master_data__product", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19975.1", "table_name": "product_wic_price_detail_data_migration", "table_schema": "staging__master_data__product.product_wic_price_detail_data_migration", "table_legacy_schema": "acapdb.product_wic_price_detail", "table_domain": "master_data", "table_subdomain": "product", "table_location": "staging__master_data__product.product_wic_price_detail_data_migration", "table_partition": "", "table_db": "staging__master_data__product", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.1637.1", "table_name": "prescription_consult_activity", "table_schema": "pharmacy_healthcare__patient_services.prescription_consult_activity", "table_legacy_schema": "dae_cooked.prescription_consult_activity", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_consult_activity", "table_partition": "\n  fill_sold_yr STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19979.1", "table_name": "prescription_consult_activity_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_consult_activity_data_migration", "table_legacy_schema": "dae_cooked.prescription_consult_activity", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_consult_activity_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19980.1", "table_name": "sales_transaction_tender_data_migration", "table_schema": "staging__retail__retail_sales.sales_transaction_tender_data_migration", "table_legacy_schema": "dae_cooked.sales_transaction_tender", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.sales_transaction_tender_data_migration", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.1801.1", "table_name": "sales_transaction_tender", "table_schema": "retail__retail_sales.sales_transaction_tender", "table_legacy_schema": "dae_cooked.sales_transaction_tender", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_tender", "table_partition": "\n  sales_txn_dt STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.994.1", "table_name": "buyout_patient", "table_schema": "mna_buyout__pharmacy_healthcare.buyout_patient", "table_legacy_schema": "dae_cooked.buyout_patient", "table_domain": "mna_buyout", "table_subdomain": "pharmacy_healthcare", "table_location": "mna_buyout__pharmacy_healthcare.buyout_patient", "table_partition": "", "table_db": "mna_buyout__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.995.1", "table_name": "buyout_prescription", "table_schema": "mna_buyout__pharmacy_healthcare.buyout_prescription", "table_legacy_schema": "dae_cooked.buyout_prescription", "table_domain": "mna_buyout", "table_subdomain": "pharmacy_healthcare", "table_location": "mna_buyout__pharmacy_healthcare.buyout_prescription", "table_partition": "", "table_db": "mna_buyout__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.996.1", "table_name": "buyout_prescription_fill", "table_schema": "mna_buyout__pharmacy_healthcare.buyout_prescription_fill", "table_legacy_schema": "dae_cooked.buyout_prescription_fill", "table_domain": "mna_buyout", "table_subdomain": "pharmacy_healthcare", "table_location": "mna_buyout__pharmacy_healthcare.buyout_prescription_fill", "table_partition": "", "table_db": "mna_buyout__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.1793.1", "table_name": "sales_transaction_detail", "table_schema": "retail__retail_sales.sales_transaction_detail", "table_legacy_schema": "dae_cooked.sales_transaction_detail", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_detail", "table_partition": "\n  src_sys_cd STRING, \n  sales_txn_dt DATE", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19981.1", "table_name": "sales_transaction_detail_data_migration", "table_schema": "staging__retail__retail_sales.sales_transaction_detail_data_migration", "table_legacy_schema": "dae_cooked.sales_transaction_detail", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.sales_transaction_detail_data_migration", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19988.1", "table_name": "sales_txn_dgtl_wallet_paymt_dtl_data_migration", "table_schema": "staging__retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl_data_migration", "table_legacy_schema": "acapdb.sales_txn_dgtl_wallet_paymt_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl_data_migration", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.375.1", "table_name": "sales_txn_dgtl_wallet_paymt_dtl", "table_schema": "retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl", "table_legacy_schema": "acapdb.sales_txn_dgtl_wallet_paymt_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_txn_dgtl_wallet_paymt_dtl", "table_partition": "\n  sales_txn_dt STRING, \n  src_sys_cd STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19986.1", "table_name": "sales_transaction_detail_rx", "table_schema": "retail__retail_sales.sales_transaction_detail_rx", "table_legacy_schema": "SNOWFLAKE.sales_transaction_detail_rx", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_detail_rx", "table_partition": "", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19986.1", "table_name": "sales_transaction_program", "table_schema": "retail__retail_sales.sales_transaction_program", "table_legacy_schema": "SNOWFLAKE.sales_transaction_program", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_program", "table_partition": "", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.374.1", "table_name": "sales_txn_dgtl_wallet_dtl", "table_schema": "retail__retail_sales.sales_txn_dgtl_wallet_dtl", "table_legacy_schema": "acapdb.sales_txn_dgtl_wallet_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_txn_dgtl_wallet_dtl", "table_partition": "\n  sales_txn_dt DATE, \n  src_sys_cd STRING", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19992.1", "table_name": "sales_txn_dgtl_wallet_dtl_data_migration", "table_schema": "staging__retail__retail_sales.sales_txn_dgtl_wallet_dtl_data_migration", "table_legacy_schema": "acapdb.sales_txn_dgtl_wallet_dtl", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.sales_txn_dgtl_wallet_dtl_data_migration", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-12 02:43:59", "update_date": ""}, {"release": "8.2.0", "table_id": "T.19993.1", "table_name": "drug_ic", "table_schema": "pharmacy_healthcare__drug.drug_ic", "table_legacy_schema": "SNOWFLAKE.drug_ic", "table_domain": "pharmacy_healthcare", "table_subdomain": "drug", "table_location": "pharmacy_healthcare__drug.drug_ic", "table_partition": "", "table_db": "pharmacy_healthcare__drug", "table_zone": "curated", "create_date": "2022-08-12 02:43:59", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_marketing', defaultValue='${STORAGE_ACCT_wrg_marketing}', label='STORAGE_ACCT_wrg_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_partner_extracts', defaultValue='${STORAGE_ACCT_wrg_partner_extracts}', label='STORAGE_ACCT_wrg_partner_extracts')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_daily_extracts_stg(
pat_id STRING,
new_pat_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_eligible_daily_extracts_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.sa_pat_event_log_stg(
pharmacypatientid DECIMAL(13,0),
enrollment_status STRING,
status_change_date STRING,
reason_for_unenrollment STRING,
loginname STRING,
usergroup STRING,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/sa_pat_event_log_stg'
PARTITIONED BY (
idh_ingestion_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_resp_raw_stg(
response_id STRING,
file_id STRING,
answer_num STRING,
answer_num_other STRING,
campaign_batch_nbr STRING,
campaign_cd STRING,
campaign_id STRING,
comment_1 STRING,
comment_2 STRING,
DATE_of_contact STRING,
disposition_code STRING,
number_contacted STRING,
question_num STRING,
response_channel STRING,
response_desc STRING,
response_value STRING,
risk_score STRING,
site_location STRING,
store_nbr STRING,
survey_id STRING,
total_no_attempt STRING,
create_dttm STRING,
update_dttm STRING,
response_direction_code STRING,
response_phase_code STRING,
response_dttm STRING,
contact_type_code STRING,
contact_sequence_code STRING,
offer_cd STRING,
treatment_cd STRING,
fill_sold_date STRING,
issue_id STRING,
issue_name STRING,
comm_id STRING,
comm_subject STRING,
comm_name STRING,
cell_code STRING,
msg_send_rslt_cd STRING,
mime_type_cd STRING,
ebm_trigger_send_dttm STRING,
ebm_trigger_evt_id STRING,
orig_evt_ip_addr STRING,
msg_part_type_open_cd STRING,
redirect_link_name STRING,
dest_url_addr STRING,
evt_click_or_open_dttm STRING,
confirm_page_txn_id STRING,
confirm_page_txn_amt STRING,
confirm_page_info STRING,
preferred_lang_cd STRING,
final_call_attempt_start_dt STRING,
final_call_attempt_end_dt STRING,
call_transfer_start_dttm STRING,
call_transfer_answer_dttm STRING,
refill_due_date STRING,
barcode STRING,
register_nbr STRING,
cntrl_treatmt_ind STRING,
tracking_id STRING,
file_arrival_date STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/acap_campaign_resp_raw_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_resp_cust_raw_stg(
response_id STRING,
address_1 STRING,
address_2 STRING,
age STRING,
audience_id STRING,
city STRING,
dob STRING,
email_address STRING,
first_name STRING,
gender_cd STRING,
last_name STRING,
middle_name STRING,
pat_id STRING,
phone_1 STRING,
phone_2 STRING,
state STRING,
zip_4 STRING,
zip_5 STRING,
create_dttm STRING,
update_dttm STRING,
cust_id STRING,
rx_nbr STRING,
call_duration STRING,
me_id STRING,
drug_id STRING,
generic_prod_id STRING,
src_cd STRING,
src_id_char STRING,
newline STRING,
tracking_id STRING,
file_arrival_date STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/acap_campaign_resp_cust_raw_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_resp_file_raw_stg(
file_id STRING,
vendor_id STRING,
file_received_dttm STRING,
response_file_name STRING,
create_dttm STRING,
update_dttm STRING,
tracking_id STRING,
file_arrival_date STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/acap_campaign_resp_file_raw_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
migration_data=[{"release": "8.2.1", "scripts": ["D.39.1.wrg.partner_extracts__pharmacy_healthcare.sql", "D.53.1.wrg.marketing__campaign.sql", "T.11636.1.wrg.satr_patients_eligible_daily_extracts_stg.sql", "T.19964.1.wrg.acap_campaign_resp_raw_stg.sql", "T.19965.1.wrg.acap_campaign_resp_cust_raw_stg.sql", "T.19966.1.wrg.acap_campaign_resp_file_raw_stg.sql", "T.19644.1.wrg.sa_pat_event_log_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.2.1", "table_id": "T.11636.1", "table_name": "satr_patients_eligible_daily_extracts_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_daily_extracts_stg", "table_legacy_schema": "dae_work.satr_patients_eligible_daily_extracts", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_daily_extracts_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.1", "table_id": "T.19964.1", "table_name": "acap_campaign_resp_raw_stg", "table_schema": "staging__marketing__campaign.acap_campaign_resp_raw_stg", "table_legacy_schema": "dae_code_raw_ingestion.acap_campaign_resp_raw", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.acap_campaign_resp_raw_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.1", "table_id": "T.19965.1", "table_name": "acap_campaign_resp_cust_raw_stg", "table_schema": "staging__marketing__campaign.acap_campaign_resp_cust_raw_stg", "table_legacy_schema": "dae_code_raw_ingestion.acap_campaign_resp_cust_raw", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.acap_campaign_resp_cust_raw_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.1", "table_id": "T.19966.1", "table_name": "acap_campaign_resp_file_raw_stg", "table_schema": "staging__marketing__campaign.acap_campaign_resp_file_raw_stg", "table_legacy_schema": "dae_code_raw_ingestion.acap_campaign_resp_file_raw", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.acap_campaign_resp_file_raw_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.1", "table_id": "T.19644.1", "table_name": "sa_pat_event_log_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.sa_pat_event_log_stg", "table_legacy_schema": "dae_raw.sa_pat_event_log", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.sa_pat_event_log_stg", "table_partition": "\n  idh_ingestion_month STRING", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

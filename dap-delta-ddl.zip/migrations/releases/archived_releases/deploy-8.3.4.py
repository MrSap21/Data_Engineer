# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_partner_extracts', defaultValue='${STORAGE_ACCT_wrg_partner_extracts}', label='STORAGE_ACCT_wrg_partner_extracts')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_plan_exclusion_list_expanded_stg(
third_party_plan_id STRING,
plan_group_nbr STRING,
plan_type STRING,
tracking_id STRING,
ingestion_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_plan_exclusion_list_expanded_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_temp_stg(
third_party_plan_id STRING,
plan_group_nbr STRING,
plan_type STRING,
ingestion_date STRING,
inc_ind STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_plan_inc_exc_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_plan_inclusion_list_expanded_stg(
third_party_plan_id STRING,
plan_group_nbr STRING,
plan_type STRING,
tracking_id STRING,
ingestion_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_plan_inclusion_list_expanded_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.omnicell_missing_demo_file_stg(
pat_id STRING,
idh_ingest_dt STRING,
tracking_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/omnicell_missing_demo_file_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_plan_exclusion_list_stg(
third_party_plan_id STRING,
plan_group_nbr STRING,
tracking_id STRING,
ingestion_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_plan_exclusion_list_stg'
PARTITIONED BY (
ingestion_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_plan_inclusion_list_stg(
third_party_plan_id STRING,
plan_group_nbr STRING,
tracking_id STRING,
ingestion_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_plan_inclusion_list_stg'
PARTITIONED BY (
ingestion_mnth STRING)""")
# COMMAND ----------
migration_data=[{"release": "8.3.4", "scripts": ["D.39.1.wrg.partner_extracts__pharmacy_healthcare.sql", "T.11696.1.wrg.satr_plan_exclusion_list_expanded_stg.sql", "T.11697.1.wrg.satr_plan_inc_exc_temp_stg.sql", "T.11698.1.wrg.satr_plan_inclusion_list_expanded_stg.sql", "T.19570.1.wrg.omnicell_missing_demo_file_stg.sql", "T.19739.1.wrg.satr_plan_exclusion_list_stg.sql", "T.19740.1.wrg.satr_plan_inclusion_list_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.3.4", "table_id": "T.11696.1", "table_name": "satr_plan_exclusion_list_expanded_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_plan_exclusion_list_expanded_stg", "table_legacy_schema": "dae_work.satr_plan_exclusion_list_expanded", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_plan_exclusion_list_expanded_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 13:42:24", "update_date": ""}, {"release": "8.3.4", "table_id": "T.11697.1", "table_name": "satr_plan_inc_exc_temp_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_temp_stg", "table_legacy_schema": "dae_work.satr_plan_inc_exc_temp", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 13:42:24", "update_date": ""}, {"release": "8.3.4", "table_id": "T.11698.1", "table_name": "satr_plan_inclusion_list_expanded_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_plan_inclusion_list_expanded_stg", "table_legacy_schema": "dae_work.satr_plan_inclusion_list_expanded", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_plan_inclusion_list_expanded_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 13:42:24", "update_date": ""}, {"release": "8.3.4", "table_id": "T.19570.1", "table_name": "omnicell_missing_demo_file_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.omnicell_missing_demo_file_stg", "table_legacy_schema": "dae_raw.omnicell_missing_demo_file", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.omnicell_missing_demo_file_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 13:42:24", "update_date": ""}, {"release": "8.3.4", "table_id": "T.19739.1", "table_name": "satr_plan_exclusion_list_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_plan_exclusion_list_stg", "table_legacy_schema": "dae_raw.satr_plan_exclusion_list", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_plan_exclusion_list_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 13:42:24", "update_date": ""}, {"release": "8.3.4", "table_id": "T.19740.1", "table_name": "satr_plan_inclusion_list_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_plan_inclusion_list_stg", "table_legacy_schema": "dae_raw.satr_plan_inclusion_list", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_plan_inclusion_list_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 13:42:24", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__plan;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__mail_order;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__mail_order.mail_order_detail(
ord_nbr STRING ,
rx_nbr INT,
ord_receive_dt DATE COMMENT '{{"FORMAT":"YY/MM/DD" }}',
str_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_enter_dt DATE COMMENT '{{"FORMAT":"YY/MM/DD" }}',
fill_enter_tm STRING,
line_nbr INT,
cash_out_reason_cd STRING ,
cancel_reason_cd STRING ,
pat_id DECIMAL(13,0),
pat_mail_service_id STRING ,
pbr_id DECIMAL(11,0),
pbr_loc_id SMALLINT,
plan_group_nbr STRING ,
plan_id STRING ,
cob_plan_id STRING ,
upi STRING ,
cob_upi STRING ,
actual_ship_method_cd STRING ,
line_stat_cd STRING ,
drug_id INT,
drug_class_cd STRING ,
drug_pick_up_str_nbr INT,
fill_sold_dt DATE COMMENT '{{"FORMAT":"YY/MM/DD"}}',
fill_sold_tm STRING,
fill_del_dt DATE COMMENT '{{"FORMAT":"YY/MM/DD"}}',
fill_del_tm STRING,
fill_pick_up_dt DATE COMMENT '{{"FORMAT":"YY/MM/DD"}}',
fill_pick_up_tm STRING,
fill_qty_dspn DECIMAL(8,3),
ord_qty INT,
pick_qty INT,
prev_exception_ind STRING ,
line_reship_ind STRING ,
mail_wac_cost_dlrs DECIMAL(8,2),
otc_ship_hdlg_charge_dlrs DECIMAL(8,2),
src_create_user_id DECIMAL(9,0),
src_update_user_id DECIMAL(9,0),
src_create_dttm TIMESTAMP,
src_update_dttm TIMESTAMP,
edw_create_dttm TIMESTAMP,
edw_update_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0)
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/mail_order/mail_order_detail'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription(
cdc_txn_commit_dttm TIMESTAMP,
rx_nbr INT,
str_nbr INT,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_create_tm STRING,
pat_id DECIMAL(13,0) ,
pbr_id DECIMAL(11,0) ,
pbr_loc_id SMALLINT ,
pbr_ord_nbr STRING ,
drug_id INT ,
dea_class_cd STRING ,
drug_non_sys_cd STRING ,
drug_non_sys_name STRING ,
drug_non_sys_assign_ndc STRING ,
drug_non_sys_mfgr_name STRING ,
drug_sub_cd STRING ,
ord_drug_id INT ,
generic_substn_pref_ind STRING ,
fill_unlimited_ind STRING ,
fill_qty_dispensed DECIMAL(8,3) ,
fill_days_supply SMALLINT ,
rx_daw_cd STRING ,
rx_daw_ind STRING ,
rx_sig STRING ,
rx_stat_cd STRING ,
rx_tot_dspn_qty DECIMAL(10,3) ,
rx_written_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_written_tm STRING,
rx_orig_fill_dttm TIMESTAMP,
rx_added_qty DECIMAL(8,3) ,
rx_refill_expire_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_refill_expire_tm STRING,
rx_cmnt STRING ,
fill_nbr_prescribed SMALLINT ,
fill_nbr_dspn SMALLINT ,
fill_nbr_added SMALLINT ,
fill_auto_ind STRING ,
fill_nbr_last_disp SMALLINT ,
fill_entered_dttm TIMESTAMP,
image_id STRING ,
scan_user_id DECIMAL(9,0) ,
scan_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
scan_tm STRING,
scan_str_nbr INT ,
tip_rx_ind STRING ,
route_str_nbr INT ,
priced_as_nonsys_ind STRING ,
wag_inv_ctrl_nbr INT ,
relocate_fm_str_nbr INT ,
create_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
update_user_id DECIMAL(9,0),
update_dttm TIMESTAMP,
rx_orig_qty_dspn DECIMAL(8,3) ,
rx_orig_days_supply SMALLINT ,
rx_orig_qty DECIMAL(8,3),
src_partition_nbr TINYINT ,
diagnosis_cd_1 STRING ,
diagnosis_cd_2 STRING ,
diagnosis_cd_3 STRING ,
diagnosis_cd_4 STRING ,
diagnosis_cd_qlfr STRING ,
origin_cd STRING ,
rx_pad_barcode STRING ,
rx_pad_prgm_ind STRING ,
rx_vacc_mfg_lot_nbr STRING ,
rx_vacc_exp_dttm TIMESTAMP,
rx_vacc_area_of_admin STRING ,
rx_vacc_consent_ind STRING ,
rx_vacc_pnl_ent_dttm TIMESTAMP,
rx_vacc_pnl_status_cd STRING ,
drug_cmpnd_type_cd STRING ,
rx_90day_ind STRING ,
rx_90day_dttm TIMESTAMP,
rx_90day_stat_cd STRING ,
rx_90day_stat_dttm TIMESTAMP,
dosage_form_cd STRING ,
pbr_dea_nbr STRING ,
pbr_dea_suffix STRING ,
buyout_rx_cd STRING ,
diagnosis_cd_5 STRING ,
diagnosis_cd_qlfr_2 STRING ,
diagnosis_cd_qlfr_3 STRING ,
diagnosis_cd_qlfr_4 STRING ,
diagnosis_cd_qlfr_5 STRING ,
trmt_type_cd STRING
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription'
PARTITIONED BY (
rx_create_yr STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_close_log(
xfer_fm_rx_nbr INT,
xfer_fm_str_nbr INT,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
xfer_to_rx_nbr INT ,
xfer_to_str_nbr INT ,
xfer_to_competitor_str_name STRING ,
close_reason_cd STRING ,
close_reason_cmnt STRING ,
xfer_fm_rph_initials STRING ,
xfer_to_rph_initials STRING ,
xfer_to_competitor_area_cd STRING ,
xfer_to_competitor_phone_nbr STRING ,
rx_xfer_close_reason_cd STRING ,
relocate_fm_str_nbr INT,
create_user_id DECIMAL(9,0) ,
edw_batch_id DECIMAL(18,0) ,
update_user_id DECIMAL(9,0) ,
update_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
close_log_create_dttm TIMESTAMP,
xfer_to_rph_first_name STRING ,
xfer_to_rph_last_name STRING ,
xfer_to_phrm_dea_nbr STRING ,
xfer_to_competitor_addr_line STRING ,
xfer_to_competitor_city STRING ,
xfer_to_competitor_state_cd STRING ,
xfer_to_competitor_zip_cd_5 STRING ,
xfer_to_competitor_zip_cd_4 STRING
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_close_log'
PARTITIONED BY (
rx_create_yr STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_consult_adhoc(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT ,
rx_partial_fill_nbr INT ,
consult_adhoc_create_dttm TIMESTAMP,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
fill_enter_tm STRING,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
dspn_fill_nbr SMALLINT ,
adhoc_consult_rslv_rph_intl STRING ,
adhoc_consult_rslv_dttm TIMESTAMP,
adhoc_consult_rslv_cmnts STRING ,
adhoc_consult_rslv_rph_user_id DECIMAL(9,0),
src_create_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
edw_gg_commit_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
relocate_fm_str_nbr INT
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_consult_adhoc'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_fill_verify(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_fill_nbr_dspn INT,
reqst_actn_cd STRING ,
response_cd STRING ,
vrfy_txn_id STRING ,
vrfy_txn_dt DATE COMMENT '{{"FORMAT":"YYYY-MM-DD" }}',
str_npi_nbr STRING ,
phrm_service_type_cd DECIMAL(2,0),
phrm_txn_id STRING ,
response_actn STRING ,
response_msg STRING ,
vrx_call_origin STRING ,
src_create_user_id DECIMAL(9,0),
src_create_dttm TIMESTAMP,
src_update_user_id DECIMAL(9,0),
src_update_dttm TIMESTAMP,
create_dttm TIMESTAMP,
update_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0)
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/prescription_fill_verify'
PARTITIONED BY (
vrfy_txn_yr STRING,
vrfy_txn_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__plan.third_party_plan(
third_party_plan_id STRING ,
src_eff_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}',
src_eff_tm STRING,
bill_form_type_cd STRING ,
phone_area_cd STRING ,
phone_nbr STRING ,
plan_type_cd STRING ,
plan_name STRING ,
plan_actv_ind STRING ,
plan_eff_dttm TIMESTAMP,
phrm_str_nbr_cd STRING ,
primary_pbr_cd STRING ,
secondary_pbr_cd STRING ,
cmpnd_drug_cd STRING ,
uc_adj_dlrs DECIMAL(8,2),
tax_exmpt_plan_ind STRING ,
uc_ind STRING ,
uc_copay_ind STRING ,
direct_link_cd STRING ,
bin_nbr STRING ,
ncpdp_vers STRING ,
processor_ctrl_nbr STRING ,
override_bill_adj_cd STRING ,
override_bill_adj_dlrs DECIMAL(8,2),
override_bill_adj_type STRING ,
primary_bill_adj_dlrs DECIMAL(8,2),
primary_bill_adj_cd STRING ,
primary_bill_adj_type STRING ,
bill_method_cd STRING ,
state_plan_cd STRING ,
generic_dspn_fee_dlrs DECIMAL(8,2),
generic_dspn_fee_cd STRING ,
generic_copay_dlrs DECIMAL(8,2),
generic_copay_cd STRING ,
brand_dspn_fee_dlrs DECIMAL(8,2),
brand_dspn_fee_cd STRING ,
brand_copay_dlrs DECIMAL(8,2),
brand_copay_cd STRING ,
otc_dspn_fee_dlrs DECIMAL(8,2),
otc_dspn_fee_cd STRING ,
otc_copay_dlrs DECIMAL(8,2),
otc_copay_cd STRING ,
custom_pay_cd_ind STRING ,
link_type_cd STRING ,
uc_adj_type_cd STRING ,
signature_req_ind STRING ,
src_create_user_id DECIMAL(9,0),
src_update_user_id DECIMAL(9,0),
child_plan_qty SMALLINT,
parent_plan_id STRING ,
plan_cost_fee_copay_excl_ind STRING ,
sign_ind STRING ,
promise_costfee_copay_excl_ind STRING ,
mail_plan_uc_cd STRING ,
mail_plan_uc_default_dlrs DECIMAL(8,2),
plan_hlp_phone_area_cd STRING ,
plan_hlp_phone_nbr STRING ,
plan_prior_auth_phone_area_cd STRING ,
plan_prior_auth_phone_nbr STRING ,
partial_fill_vers_cd STRING ,
third_party_certify_id STRING ,
assign_nbr_ind STRING ,
dur_lvl_straightforward STRING ,
dur_lvl_low_complexity STRING ,
dur_lvl_moderate_complexity STRING ,
dur_lvl_high_complexity STRING ,
dur_lvl_comprehensive STRING ,
cob_seg_ind STRING ,
sr_dividend_elig_ind STRING ,
manual_claim_ind STRING ,
pbr_assign_nbr_ind STRING ,
rph_cd STRING ,
person_cd STRING ,
actl_processor_ctrl_nbr STRING ,
cob_ind STRING ,
cob_bill_method_cd STRING ,
send_cob_seg_copay_bill_ind STRING ,
send_other_amt_claimed_ind STRING ,
cob_bill_hybrid_threshold_dlrs DECIMAL(8,2),
cob_bill_for_zero_copay_ind STRING ,
cob_other_cover_zero_copay_cd STRING ,
send_cob_seg_for_full_bill_ind STRING ,
cob_other_cover_full_bill_cd STRING ,
default_other_payr_amt_qlfr STRING ,
default_other_payr_cover_type_ STRING ,
discnt_plan_cd STRING ,
plan_tip_excl_ind STRING ,
doc_id INT,
epa_ind STRING ,
secondary_pbr_assign_nbr_ind STRING ,
subm_direct_link_cob_cd STRING ,
allow_non_rx_otc_ind STRING ,
non_rx_otc_pbr_id DECIMAL(11,0),
non_rx_otc_day_supply SMALLINT,
src_create_dttm TIMESTAMP,
src_end_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
src_end_tm STRING,
edw_batch_id DECIMAL(18,0),
history_seq_nbr SMALLINT,
history_seq_cd STRING ,
government_plan_cd STRING ,
cob_full_claim_amt_cover_cd STRING ,
cob_zero_prime_pay_cover_cd DECIMAL(2,0),
websdl_cob_ind STRING ,
elig_plan_desc STRING ,
elig_plan_mbr_id_instr_desc STRING ,
supply_utlz_days_pctg DECIMAL(3,0),
cob_bill_lo_cost_fee_copay_ind STRING ,
cob_payr_amt_admin_ind STRING ,
cob_payr_amt_cogn_ind STRING ,
cob_payr_amt_deliv_ind STRING ,
cob_payr_amt_drug_beni_ind STRING ,
cob_payr_amt_incntv_ind STRING ,
cob_payr_amt_pstg_ind STRING ,
cob_payr_amt_ship_ind STRING ,
cob_payr_amt_pat_lump_sum_ind STRING ,
cob_payr_amt_break_down_ind STRING ,
primary_gt_zero_other_cover_cd DECIMAL(2,0),
primary_lt_zero_other_cover_cd DECIMAL(2,0),
primary_reject_other_cover_cd DECIMAL(2,0)
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/plan/third_party_plan'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_fill_verify_data_migration(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_fill_nbr_dspn INT,
reqst_actn_cd STRING ,
response_cd STRING ,
vrfy_txn_id STRING ,
vrfy_txn_dt DATE COMMENT '{{"FORMAT":"YYYY-MM-DD" }}',
str_npi_nbr STRING ,
phrm_service_type_cd DECIMAL(2,0),
phrm_txn_id STRING ,
response_actn STRING ,
response_msg STRING ,
vrx_call_origin STRING ,
src_create_user_id DECIMAL(9,0),
src_create_dttm TIMESTAMP,
src_update_user_id DECIMAL(9,0),
src_update_dttm TIMESTAMP,
create_dttm TIMESTAMP,
update_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_fill_verify_data_migration'
PARTITIONED BY (
vrfy_txn_yr STRING,
vrfy_txn_mnth STRING)""")
# COMMAND ----------
migration_data=[{"release": "7.4.0", "scripts": ["D.32.1.crt.pharmacy_healthcare__plan.sql", "D.36.1.crt.pharmacy_healthcare__mail_order.sql", "D.6.1.crt.pharmacy_healthcare__patient_services.sql", "T.1493.1.crt.mail_order_detail.sql", "T.1624.1.crt.prescription.sql", "T.1630.1.crt.prescription_close_log.sql", "T.1642.1.crt.prescription_consult_adhoc.sql", "T.1696.1.crt.prescription_fill_verify.sql", "T.19925.1.wrg.prescription_fill_verify_data_migration.sql", "T.1869.1.crt.third_party_plan.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.4.0", "table_id": "T.1493.1", "table_name": "mail_order_detail", "table_schema": "pharmacy_healthcare__mail_order.mail_order_detail", "table_legacy_schema": "dae_cooked.mail_order_detail", "table_domain": "pharmacy_healthcare", "table_subdomain": "mail_order", "table_location": "pharmacy_healthcare__mail_order.mail_order_detail", "table_partition": "", "table_db": "pharmacy_healthcare__mail_order", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.0", "table_id": "T.1624.1", "table_name": "prescription", "table_schema": "pharmacy_healthcare__patient_services.prescription", "table_legacy_schema": "dae_cooked.prescription", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription", "table_partition": "\n  rx_create_yr STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.0", "table_id": "T.1630.1", "table_name": "prescription_close_log", "table_schema": "pharmacy_healthcare__patient_services.prescription_close_log", "table_legacy_schema": "dae_cooked.prescription_close_log", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_close_log", "table_partition": "\n  rx_create_yr STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.0", "table_id": "T.1642.1", "table_name": "prescription_consult_adhoc", "table_schema": "pharmacy_healthcare__patient_services.prescription_consult_adhoc", "table_legacy_schema": "dae_cooked.prescription_consult_adhoc", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_consult_adhoc", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.0", "table_id": "T.1696.1", "table_name": "prescription_fill_verify", "table_schema": "pharmacy_healthcare__patient_services.prescription_fill_verify", "table_legacy_schema": "dae_cooked.prescription_fill_verify", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_fill_verify", "table_partition": "\n  vrfy_txn_yr STRING, \n  vrfy_txn_mnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.0", "table_id": "T.19925.1", "table_name": "prescription_fill_verify_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_fill_verify_data_migration", "table_legacy_schema": "", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_fill_verify_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.0", "table_id": "T.1869.1", "table_name": "third_party_plan", "table_schema": "pharmacy_healthcare__plan.third_party_plan", "table_legacy_schema": "dae_cooked.third_party_plan", "table_domain": "pharmacy_healthcare", "table_subdomain": "plan", "table_location": "pharmacy_healthcare__plan.third_party_plan", "table_partition": "", "table_db": "pharmacy_healthcare__plan", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
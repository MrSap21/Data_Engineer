# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_digital', defaultValue='${STORAGE_ACCT_wrg_digital}', label='STORAGE_ACCT_wrg_digital')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_order_retail_stg(
rx_r_id STRING COMMENT 'FROM deserializer',
rx_r_ref_num STRING COMMENT 'FROM deserializer',
rx_r_dttm STRING COMMENT 'FROM deserializer',
rx_r_doc_fname STRING COMMENT 'FROM deserializer',
rx_r_doc_lname STRING COMMENT 'FROM deserializer',
rx_r_xfr_rx_num STRING COMMENT 'FROM deserializer',
rx_r_xfr_store_num STRING COMMENT 'FROM deserializer',
rx_r_val_app_cd STRING COMMENT 'FROM deserializer',
rx_r_est_price STRING COMMENT 'FROM deserializer',
rx_r_submit_q STRING COMMENT 'FROM deserializer',
rx_r_submit_q_stat STRING COMMENT 'FROM deserializer',
rx_r_fill_nbr STRING COMMENT 'FROM deserializer',
rx_r_req_fill_dttm STRING COMMENT 'FROM deserializer',
rx_r_90_day_ind STRING COMMENT 'FROM deserializer',
rx_r_update_dttm STRING COMMENT 'FROM deserializer',
rx_r_generic_ind STRING COMMENT 'FROM deserializer',
rx_r_sold_dttm STRING COMMENT 'FROM deserializer',
rx_r_fill_num_disp STRING COMMENT 'FROM deserializer',
rx_r_ready_price STRING COMMENT 'FROM deserializer',
rx_r_doc_area_cd STRING COMMENT 'FROM deserializer',
rx_r_doc_phone_nbr STRING COMMENT 'FROM deserializer',
rx_r_xfr_pharm_name STRING COMMENT 'FROM deserializer',
rx_r_xfr_pharm_area_cd STRING COMMENT 'FROM deserializer',
rx_r_xfr_pharm_phone_nbr STRING COMMENT 'FROM deserializer',
rx_r_dtl_id STRING COMMENT 'FROM deserializer',
rx_r_delivery_ind STRING COMMENT 'FROM deserializer',
rx_r_delivery_comments STRING COMMENT 'FROM deserializer',
rx_r_addl_cmnts STRING COMMENT 'FROM deserializer',
rx_r_transfer_rx_num STRING COMMENT 'FROM deserializer',
drug_id STRING COMMENT 'FROM deserializer')
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_order_retail_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_rx_order_retail_temp_stg(
rx_r_id STRING,
rx_r_ref_num STRING,
rx_r_dttm TIMESTAMP,
rx_r_doc_fname STRING,
rx_r_doc_lname STRING,
rx_r_xfr_rx_num STRING,
rx_r_xfr_store_num STRING,
rx_r_val_app_cd STRING,
rx_r_est_price STRING,
rx_r_submit_q STRING,
rx_r_submit_q_stat STRING,
rx_r_fill_nbr STRING,
rx_r_req_fill_dttm TIMESTAMP,
rx_r_90_day_ind STRING,
rx_r_update_dttm TIMESTAMP,
rx_r_generic_ind STRING,
rx_r_sold_dttm TIMESTAMP,
rx_r_fill_num_disp STRING,
rx_r_ready_price STRING,
rx_r_doc_area_cd STRING,
rx_r_doc_phone_nbr STRING,
rx_r_xfr_pharm_name STRING,
rx_r_xfr_pharm_area_cd STRING,
rx_r_xfr_pharm_phone_nbr STRING,
rx_r_dtl_id STRING,
rx_r_delivery_ind STRING,
rx_r_delivery_comments STRING,
rx_r_addl_cmnts STRING,
rx_r_transfer_rx_num STRING,
drug_id STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_rx_order_retail_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_order_retail_update_records_stg(
rx_r_id STRING,
rx_r_ref_num STRING,
rx_r_dttm TIMESTAMP,
rx_r_doc_fname STRING,
rx_r_doc_lname STRING,
rx_r_xfr_rx_num STRING,
rx_r_xfr_store_num STRING,
rx_r_val_app_cd STRING,
rx_r_est_price STRING,
rx_r_submit_q STRING,
rx_r_submit_q_stat STRING,
rx_r_fill_nbr STRING,
rx_r_req_fill_dttm TIMESTAMP,
rx_r_90_day_ind STRING,
rx_r_update_dttm TIMESTAMP,
rx_r_generic_ind STRING,
rx_r_sold_dttm TIMESTAMP,
rx_r_fill_num_disp STRING,
rx_r_ready_price STRING,
rx_r_doc_area_cd STRING,
rx_r_doc_phone_nbr STRING,
rx_r_xfr_pharm_name STRING,
rx_r_xfr_pharm_area_cd STRING,
rx_r_xfr_pharm_phone_nbr STRING,
rx_r_dtl_id STRING,
rx_r_delivery_ind STRING,
rx_r_delivery_comments STRING,
rx_r_addl_cmnts STRING,
rx_r_transfer_rx_num STRING,
drug_id STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_order_retail_update_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_order_retail_insert_records_stg(
rx_r_id STRING,
rx_r_ref_num STRING,
rx_r_dttm TIMESTAMP,
rx_r_doc_fname STRING,
rx_r_doc_lname STRING,
rx_r_xfr_rx_num STRING,
rx_r_xfr_store_num STRING,
rx_r_val_app_cd STRING,
rx_r_est_price STRING,
rx_r_submit_q STRING,
rx_r_submit_q_stat STRING,
rx_r_fill_nbr STRING,
rx_r_req_fill_dttm TIMESTAMP,
rx_r_90_day_ind STRING,
rx_r_update_dttm TIMESTAMP,
rx_r_generic_ind STRING,
rx_r_sold_dttm TIMESTAMP,
rx_r_fill_num_disp STRING,
rx_r_ready_price STRING,
rx_r_doc_area_cd STRING,
rx_r_doc_phone_nbr STRING,
rx_r_xfr_pharm_name STRING,
rx_r_xfr_pharm_area_cd STRING,
rx_r_xfr_pharm_phone_nbr STRING,
rx_r_dtl_id STRING,
rx_r_delivery_ind STRING,
rx_r_delivery_comments STRING,
rx_r_addl_cmnts STRING,
rx_r_transfer_rx_num STRING,
drug_id STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_order_retail_insert_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_order_retail_retained_records_stg(
rx_r_id STRING,
rx_r_ref_num STRING,
rx_r_dttm TIMESTAMP,
rx_r_doc_fname STRING,
rx_r_doc_lname STRING,
rx_r_xfr_rx_num STRING,
rx_r_xfr_store_num STRING,
rx_r_val_app_cd STRING,
rx_r_est_price STRING,
rx_r_submit_q STRING,
rx_r_submit_q_stat STRING,
rx_r_fill_nbr STRING,
rx_r_req_fill_dttm TIMESTAMP,
rx_r_90_day_ind STRING,
rx_r_update_dttm TIMESTAMP,
rx_r_generic_ind STRING,
rx_r_sold_dttm TIMESTAMP,
rx_r_fill_num_disp STRING,
rx_r_ready_price STRING,
rx_r_doc_area_cd STRING,
rx_r_doc_phone_nbr STRING,
rx_r_xfr_pharm_name STRING,
rx_r_xfr_pharm_area_cd STRING,
rx_r_xfr_pharm_phone_nbr STRING,
rx_r_dtl_id STRING,
rx_r_delivery_ind STRING,
rx_r_delivery_comments STRING,
rx_r_addl_cmnts STRING,
rx_r_transfer_rx_num STRING,
drug_id STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_order_retail_retained_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.wep_rx_info_stg(
urlid STRING COMMENT 'FROM deserializer',
patid STRING COMMENT 'FROM deserializer',
firstname STRING COMMENT 'FROM deserializer',
lastname STRING COMMENT 'FROM deserializer',
rxnbr STRING COMMENT 'FROM deserializer',
strnbr STRING COMMENT 'FROM deserializer',
staddr STRING COMMENT 'FROM deserializer',
stcity STRING COMMENT 'FROM deserializer',
ststate STRING COMMENT 'FROM deserializer',
stzip STRING COMMENT 'FROM deserializer',
channelms STRING COMMENT 'FROM deserializer',
createdt STRING COMMENT 'FROM deserializer',
updatedt STRING COMMENT 'FROM deserializer',
homeeligi STRING COMMENT 'FROM deserializer',
strphnnbr STRING COMMENT 'FROM deserializer',
strfaxnbr STRING COMMENT 'FROM deserializer',
fillnbr STRING COMMENT 'FROM deserializer',
phnnbr STRING COMMENT 'FROM deserializer')
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/wep_rx_info_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_wep_rx_info_temp_stg(
short_url_id STRING,
pat_id STRING,
first_name STRING,
last_name STRING,
rx_number STRING,
store_number STRING,
st_addr STRING,
st_city STRING,
st_state STRING,
st_zip STRING,
channel_msg_sent STRING,
create_dttm TIMESTAMP,
update_dttm TIMESTAMP,
home_deli_eligble_ind STRING,
store_ph_number STRING,
store_fax_number STRING,
fill_number STRING,
phone_num STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_wep_rx_info_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_wep_rx_info_update_records_stg(
short_url_id STRING,
pat_id STRING,
first_name STRING,
last_name STRING,
rx_number STRING,
store_number STRING,
st_addr STRING,
st_city STRING,
st_state STRING,
st_zip STRING,
channel_msg_sent STRING,
create_dttm TIMESTAMP,
update_dttm TIMESTAMP,
home_deli_eligble_ind STRING,
store_ph_number STRING,
store_fax_number STRING,
fill_number STRING,
phone_num STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_wep_rx_info_update_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_wep_rx_info_insert_records_stg(
short_url_id STRING,
pat_id STRING,
first_name STRING,
last_name STRING,
rx_number STRING,
store_number STRING,
st_addr STRING,
st_city STRING,
st_state STRING,
st_zip STRING,
channel_msg_sent STRING,
create_dttm TIMESTAMP,
update_dttm TIMESTAMP,
home_deli_eligble_ind STRING,
store_ph_number STRING,
store_fax_number STRING,
fill_number STRING,
phone_num STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_wep_rx_info_insert_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_wep_rx_info_retained_records_stg(
short_url_id STRING,
pat_id STRING,
first_name STRING,
last_name STRING,
rx_number STRING,
store_number STRING,
st_addr STRING,
st_city STRING,
st_state STRING,
st_zip STRING,
channel_msg_sent STRING,
create_dttm TIMESTAMP,
update_dttm TIMESTAMP,
home_deli_eligble_ind STRING,
store_ph_number STRING,
store_fax_number STRING,
fill_number STRING,
phone_num STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_wep_rx_info_retained_records_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.1.7", "scripts": ["D.54.1.wrg.digital__ecom.sql", "T.19953.1.wrg.rx_order_retail_stg.sql", "T.19954.1.wrg.www_rx_order_retail_temp_stg.sql", "T.19955.1.wrg.rx_order_retail_update_records_stg.sql", "T.19956.1.wrg.rx_order_retail_insert_records_stg.sql", "T.19957.1.wrg.rx_order_retail_retained_records_stg.sql", "T.19958.1.wrg.wep_rx_info_stg.sql", "T.19959.1.wrg.www_wep_rx_info_temp_stg.sql", "T.19960.1.wrg.www_wep_rx_info_update_records_stg.sql", "T.19961.1.wrg.www_wep_rx_info_insert_records_stg.sql", "T.19962.1.wrg.www_wep_rx_info_retained_records_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.1.7", "table_id": "T.19953.1", "table_name": "rx_order_retail_stg", "table_schema": "staging__digital__ecom.rx_order_retail_stg", "table_legacy_schema": "acapetldb.rx_order_retail", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_order_retail_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.7", "table_id": "T.19954.1", "table_name": "www_rx_order_retail_temp_stg", "table_schema": "staging__digital__ecom.www_rx_order_retail_temp_stg", "table_legacy_schema": "acapetldb.www_rx_order_retail_temp", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_rx_order_retail_temp_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.7", "table_id": "T.19955.1", "table_name": "rx_order_retail_update_records_stg", "table_schema": "staging__digital__ecom.rx_order_retail_update_records_stg", "table_legacy_schema": "acapetldb.rx_order_retail_update_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_order_retail_update_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.7", "table_id": "T.19956.1", "table_name": "rx_order_retail_insert_records_stg", "table_schema": "staging__digital__ecom.rx_order_retail_insert_records_stg", "table_legacy_schema": "acapetldb.rx_order_retail_insert_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_order_retail_insert_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.7", "table_id": "T.19957.1", "table_name": "rx_order_retail_retained_records_stg", "table_schema": "staging__digital__ecom.rx_order_retail_retained_records_stg", "table_legacy_schema": "acapetldb.rx_order_retail_retained_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_order_retail_retained_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.7", "table_id": "T.19958.1", "table_name": "wep_rx_info_stg", "table_schema": "staging__digital__ecom.wep_rx_info_stg", "table_legacy_schema": "acapetldb.wep_rx_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.wep_rx_info_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.7", "table_id": "T.19959.1", "table_name": "www_wep_rx_info_temp_stg", "table_schema": "staging__digital__ecom.www_wep_rx_info_temp_stg", "table_legacy_schema": "acapetldb.www_wep_rx_info_temp", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_wep_rx_info_temp_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.7", "table_id": "T.19960.1", "table_name": "www_wep_rx_info_update_records_stg", "table_schema": "staging__digital__ecom.www_wep_rx_info_update_records_stg", "table_legacy_schema": "acapetldb.www_wep_rx_info_update_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_wep_rx_info_update_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.7", "table_id": "T.19961.1", "table_name": "www_wep_rx_info_insert_records_stg", "table_schema": "staging__digital__ecom.www_wep_rx_info_insert_records_stg", "table_legacy_schema": "acapetldb.www_wep_rx_info_insert_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_wep_rx_info_insert_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.7", "table_id": "T.19962.1", "table_name": "www_wep_rx_info_retained_records_stg", "table_schema": "staging__digital__ecom.www_wep_rx_info_retained_records_stg", "table_legacy_schema": "acapetldb.www_wep_rx_info_retained_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_wep_rx_info_retained_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

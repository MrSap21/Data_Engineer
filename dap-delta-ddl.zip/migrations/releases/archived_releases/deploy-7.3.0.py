# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='STORAGE_ACCT_crt_digital', defaultValue='${STORAGE_ACCT_crt_digital}', label='STORAGE_ACCT_crt_digital')
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__promotions;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__promotions.ad_event(
AD_EVT_SK BIGINT COMMENT 'AD_EVT_SK',
AD_EVT_ID INT COMMENT 'AD_EVT_ID',
SRC_SYS_CD STRING COMMENT 'SOURCE SYSTEM CODE',
AD_EVT_SEQ_NBR STRING COMMENT 'AD_EVT_SEQ_NBR',
AD_EVT_VERS_SEQ_NBR STRING COMMENT 'AD_EVT_VERS_SEQ_NBR',
AD_EVT_TYPE STRING COMMENT 'AD_EVT_TYPE',
AD_EVT_VERS_TYPE_CD STRING COMMENT 'AD_EVT_VERS_TYPE_CD',
AD_EVT_TYPE_CD STRING COMMENT 'AD_EVT_TYPE_CD',
AD_EVT_DESC STRING COMMENT 'AD_EVT_DESC',
AD_EVT_LVL_NAME STRING COMMENT 'AD_EVT_LVL_NAME',
AD_DESC STRING COMMENT 'AD_DESC',
PAGE_SZ_CD STRING COMMENT 'PAGE_SIZE_CD',
PAGE_SZ_DESC STRING COMMENT 'PAGE_SIZE_DESC',
PAGE_CNT SMALLINT COMMENT 'PAGE_CNT',
BREAK_DT DATE COMMENT 'BREAK_DT{{"FORMAT":"YYYY-MM-DD" }}',
BREAK_WK_DAY SMALLINT COMMENT 'BREAK_WEEK_DAY',
DAY_CNT SMALLINT COMMENT 'DAY_CNT',
SPOT_CNT SMALLINT COMMENT 'SPOT_CNT',
AD_EVT_TYPE_DESC STRING COMMENT 'EVENT_TYPE_DESC',
AD_EVT_VERS_MKT_CD STRING COMMENT 'EVENT_VERS_MARKET_CD',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'EDW CREATE TIMESTAMP',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'EDW_UPDATE_DTTM',
EDW_BATCH_ID DECIMAL(18,0) COMMENT 'EDW BATCH ID'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_retail')}.dfs.core.windows.net/retail/promotions/ad_event'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.tl_prescription_close_log(
xfer_fm_rx_nbr INT,
xfer_fm_str_nbr INT,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
xfer_to_rx_nbr INT ,
xfer_to_str_nbr INT ,
xfer_to_competitor_str_name STRING ,
close_reason_cd STRING ,
close_reason_cmnt STRING ,
xfer_fm_rph_initials STRING ,
xfer_to_rph_initials STRING ,
xfer_to_competitor_area_cd STRING ,
xfer_to_competitor_phone_nbr STRING ,
rx_xfer_close_reason_cd STRING ,
relocate_fm_str_nbr INT,
create_user_id DECIMAL(9,0) ,
edw_batch_id DECIMAL(18,0) ,
update_user_id DECIMAL(9,0) ,
update_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
close_log_create_dttm TIMESTAMP,
xfer_to_rph_first_name STRING ,
xfer_to_rph_last_name STRING ,
xfer_to_phrm_dea_nbr STRING ,
xfer_to_competitor_addr_line STRING ,
xfer_to_competitor_city STRING ,
xfer_to_competitor_state_cd STRING ,
xfer_to_competitor_zip_cd_5 STRING ,
xfer_to_competitor_zip_cd_4 STRING
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/tl_prescription_close_log'
PARTITIONED BY (
rx_create_yr STRING,
rx_create_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.tl_prescription_close_log_data_migration(
xfer_fm_rx_nbr INT,
xfer_fm_str_nbr INT,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
xfer_to_rx_nbr INT ,
xfer_to_str_nbr INT ,
xfer_to_competitor_str_name STRING ,
close_reason_cd STRING ,
close_reason_cmnt STRING ,
xfer_fm_rph_initials STRING ,
xfer_to_rph_initials STRING ,
xfer_to_competitor_area_cd STRING ,
xfer_to_competitor_phone_nbr STRING ,
rx_xfer_close_reason_cd STRING ,
relocate_fm_str_nbr INT,
create_user_id DECIMAL(9,0) ,
edw_batch_id DECIMAL(18,0) ,
update_user_id DECIMAL(9,0) ,
update_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
close_log_create_dttm TIMESTAMP,
xfer_to_rph_first_name STRING ,
xfer_to_rph_last_name STRING ,
xfer_to_phrm_dea_nbr STRING ,
xfer_to_competitor_addr_line STRING ,
xfer_to_competitor_city STRING ,
xfer_to_competitor_state_cd STRING ,
xfer_to_competitor_zip_cd_5 STRING ,
xfer_to_competitor_zip_cd_4 STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/tl_prescription_close_log_data_migration'
PARTITIONED BY (
rx_create_yr STRING,
rx_create_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.ecom_covid19_wait_list(
ecom_acct_id STRING COMMENT 'ecom account identifier',
mongo_src_id STRING COMMENT 'mongo source identifier',
eml_addr STRING COMMENT 'email address',
user_first_name STRING COMMENT 'user first name',
user_last_name STRING COMMENT 'user last name',
zip_cd STRING COMMENT 'zip code',
eml_src_id STRING COMMENT 'email source id',
eml_src_cd STRING COMMENT 'email source code',
eml_src_desc STRING COMMENT 'email source description',
update_src_id STRING COMMENT 'update source identifier',
src_create_dttm TIMESTAMP COMMENT 'source CREATE datetime',
src_update_dttm TIMESTAMP COMMENT 'source update datetime',
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/ecom_covid19_wait_list'""")
# COMMAND ----------
migration_data=[{"release": "7.3.0", "scripts": ["D.3.1.crt.retail__promotions.sql", "D.12.1.crt.digital__ecom.sql", "D.6.1.crt.pharmacy_healthcare__patient_services.sql", "T.115.1.crt.ad_event.sql", "T.248.1.crt.ecom_covid19_wait_list.sql", "T.1879.1.crt.tl_prescription_close_log.sql", "T.19923.1.wrg.tl_prescription_close_log_data_migration.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.3.0", "table_id": "T.115.1", "table_name": "ad_event", "table_schema": "retail__promotions.ad_event", "table_legacy_schema": "acapdb.ad_event", "table_domain": "retail", "table_subdomain": "promotions", "table_location": "retail__promotions.ad_event", "table_partition": "", "table_db": "retail__promotions", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.0", "table_id": "T.248.1", "table_name": "ecom_covid19_wait_list", "table_schema": "digital__ecom.ecom_covid19_wait_list", "table_legacy_schema": "acapdb.ecom_covid19_wait_list", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.ecom_covid19_wait_list", "table_partition": "", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.0", "table_id": "T.1879.1", "table_name": "tl_prescription_close_log", "table_schema": "pharmacy_healthcare__patient_services.tl_prescription_close_log", "table_legacy_schema": "dae_cooked.tl_prescription_close_log", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.tl_prescription_close_log", "table_partition": "\n  rx_create_yr STRING, \n  rx_create_yrmnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.0", "table_id": "T.19923.1", "table_name": "tl_prescription_close_log_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.tl_prescription_close_log_data_migration", "table_legacy_schema": "", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.tl_prescription_close_log_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

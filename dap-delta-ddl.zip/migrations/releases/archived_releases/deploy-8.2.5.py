# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
dbutils.widgets.text(name='STORAGE_ACCT_crt_master_data', defaultValue='${STORAGE_ACCT_crt_master_data}', label='STORAGE_ACCT_crt_master_data')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='retail_crt_sa', defaultValue='${retail_crt_sa}', label='retail_crt_sa')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__ccpa;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS master_data__customer;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_acm_config_bkup_stg(
config_id INT,
config_type_cd STRING,
config_type_desc STRING,
actv_ind STRING,
state_cd STRING,
drug_class STRING,
eff_start_dt STRING,
eff_end_dt STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
edw_start_date STRING,
edw_end_date STRING,
edw_batch_id STRING,
history_seq_nbr SMALLINT,
history_seq_cd STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_acm_config_bkup_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_acm_config_current_stg(
config_id INT,
config_type_cd STRING,
config_type_desc STRING,
actv_ind STRING,
state_cd STRING,
drug_class STRING,
eff_start_dt STRING,
eff_end_dt STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
edw_start_date STRING,
edw_end_date STRING,
edw_batch_id STRING,
edw_dml_ind STRING,
history_seq_nbr SMALLINT,
history_seq_cd STRING,
etl_proc_seq_nbr SMALLINT,
proc_history_seq_nbr SMALLINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_acm_config_current_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_insert_records_stg(
work_list_nbr STRING,
pat_id STRING,
rx_gfd_list_nbr STRING,
rx_gfd_cd STRING,
rx_gfd_comments STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING,
edw_batch_id STRING,
src_create_mnth STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_gfd_work_sheet_dtl_insert_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_pre_cdc_stg(
work_list_nbr STRING,
pat_id STRING,
rx_gfd_list_nbr STRING,
rx_gfd_cd STRING,
rx_gfd_comments STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING,
edw_batch_id STRING,
src_create_mnth STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_gfd_work_sheet_dtl_pre_cdc_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_retained_records_stg(
work_list_nbr DECIMAL(10,0),
pat_id DECIMAL(13,0),
rx_gfd_list_nbr SMALLINT,
rx_gfd_cd STRING,
rx_gfd_comments STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
src_create_mnth STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_gfd_work_sheet_dtl_retained_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_update_records_stg(
work_list_nbr STRING,
pat_id STRING,
rx_gfd_list_nbr STRING,
rx_gfd_cd STRING,
rx_gfd_comments STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING,
edw_batch_id STRING,
src_create_mnth STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_gfd_work_sheet_dtl_update_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_madr_auto_rules_bkup_stg(
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_madr_auto_rules_bkup_stg'
PARTITIONED BY (
history_seq_cd STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__ccpa.ccpa_rtd_log(
tkt_nbr STRING,
tkt_open_dt DATE,
reqst_type_cd STRING,
tkt_line_seq INT,
db_name STRING,
tbl_name STRING,
subject_area STRING,
del_rec_cnt INT,
rec_del_dt DATE,
stat_cd STRING,
idh_update_dttm STRING,
idh_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_rtd_log'
PARTITIONED BY (
idh_create_dttm STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_etl_tbfo_prescription_auto_chg_mfg_config_current_stg(
config_id INT,
config_type_cd STRING,
config_type_desc STRING,
actv_ind STRING,
state_cd STRING,
drug_class STRING,
eff_start_dt STRING,
eff_end_dt STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
edw_start_date STRING,
edw_end_date STRING,
edw_batch_id STRING,
edw_dml_ind STRING,
history_seq_nbr SMALLINT,
history_seq_cd STRING,
etl_proc_seq_nbr SMALLINT,
proc_history_seq_nbr SMALLINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_etl_tbfo_prescription_auto_chg_mfg_config_current_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
config_id INT,
config_type_cd STRING,
config_type_desc STRING,
actv_ind STRING,
state_cd STRING,
drug_class STRING,
eff_start_dt STRING,
eff_end_dt STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
edw_start_date STRING,
edw_end_date STRING,
edw_batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_auto_chg_mfg_config_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_cdc_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
config_id INT,
config_type_cd STRING,
config_type_desc STRING,
actv_ind STRING,
state_cd STRING,
drug_class STRING,
eff_start_dt STRING,
eff_end_dt STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
edw_start_date STRING,
edw_end_date STRING,
edw_batch_id STRING,
edw_dml_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_auto_chg_mfg_config_cdc_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_stg(
config_id INT,
config_type_cd STRING,
config_type_desc STRING,
actv_ind STRING,
state_cd STRING,
drug_class STRING,
eff_start_dt STRING,
eff_end_dt STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
edw_start_date STRING,
edw_end_date STRING,
edw_batch_id STRING,
edw_dml_ind STRING,
history_seq_nbr SMALLINT,
history_seq_cd STRING,
etl_proc_seq_nbr SMALLINT,
proc_history_seq_nbr SMALLINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_proc_seq_nbr_stg(
config_id INT,
config_type_cd STRING,
config_type_desc STRING,
actv_ind STRING,
state_cd STRING,
drug_class STRING,
eff_start_dt STRING,
eff_end_dt STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
edw_start_date STRING,
edw_end_date STRING,
edw_batch_id STRING,
edw_dml_ind STRING,
history_seq_nbr SMALLINT,
history_seq_cd STRING,
etl_proc_seq_nbr SMALLINT,
proc_history_seq_nbr SMALLINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_proc_seq_nbr_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_prep_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
config_id INT,
config_type_cd STRING,
config_type_desc STRING,
actv_ind STRING,
state_cd STRING,
drug_class STRING,
eff_start_dt STRING,
eff_end_dt STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
edw_start_date STRING,
edw_end_date STRING,
edw_batch_id STRING,
edw_dml_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_auto_chg_mfg_config_prep_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_cdc_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr INT,
cdc_rba_nbr DECIMAL(18,0),
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id DECIMAL(18,0),
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_dml_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_prescription_madr_auto_rules_cdc_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_current_stg(
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING,
history_seq_cd STRING,
edw_dml_ind STRING,
etl_proc_seq_nbr SMALLINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_prescription_madr_auto_rules_current_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_stg(
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING,
history_seq_cd STRING,
edw_dml_ind STRING,
edw_rank SMALLINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_proc_seq_nbr_stg(
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING,
history_seq_cd STRING,
edw_dml_ind STRING,
etl_proc_seq_nbr SMALLINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_proc_seq_nbr_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr INT,
cdc_rba_nbr DECIMAL(18,0),
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id DECIMAL(18,0),
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_dml_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_upd_rej_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr INT,
cdc_rba_nbr DECIMAL(18,0),
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id DECIMAL(18,0),
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_dml_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_upd_rej_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_current_stg(
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING,
history_seq_cd STRING,
edw_dml_ind STRING,
etl_proc_seq_nbr SMALLINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_prescription_madr_auto_rules_current_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_final_stg(
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING,
edw_dml_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_prescription_madr_auto_rules_final_stg'
PARTITIONED BY (
history_seq_cd STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_insert_stg(
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_prescription_madr_auto_rules_insert_stg'
PARTITIONED BY (
history_seq_cd STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_update_stg(
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
edw_batch_id DECIMAL(18,0),
start_dt STRING,
end_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_prescription_madr_auto_rules_update_stg'
PARTITIONED BY (
history_seq_cd STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.dim_school_dedup_stg(
school_key BIGINT,
school_name STRING,
school_cd STRING,
school_type STRING,
school_address1 STRING,
school_address2 STRING,
school_zip STRING,
school_city STRING,
school_state STRING,
school_email STRING,
school_phone1 STRING,
school_contact STRING,
school_fax STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/dim_school_dedup_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.dim_school_new_stg(
school_key BIGINT,
school_name STRING,
school_cd STRING,
school_type STRING,
school_address1 STRING,
school_address2 STRING,
school_zip STRING,
school_city STRING,
school_state STRING,
school_email STRING,
school_phone1 STRING,
school_contact STRING,
school_fax STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/dim_school_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.dim_school_new_assign_stg(
school_key BIGINT,
school_name STRING,
school_cd STRING,
school_type STRING,
school_address1 STRING,
school_address2 STRING,
school_zip STRING,
school_city STRING,
school_state STRING,
school_email STRING,
school_phone1 STRING,
school_contact STRING,
school_fax STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/dim_school_new_assign_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.dim_school_persistent_stg(
school_key BIGINT,
school_name STRING,
school_cd STRING,
school_type STRING,
school_address1 STRING,
school_address2 STRING,
school_zip STRING,
school_city STRING,
school_state STRING,
school_email STRING,
school_phone1 STRING,
school_contact STRING,
school_fax STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/dim_school_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.dim_school_reformat_stg(
school_key BIGINT,
school_name STRING,
school_cd STRING,
school_type STRING,
school_address1 STRING,
school_address2 STRING,
school_zip STRING,
school_city STRING,
school_state STRING,
school_email STRING,
school_phone1 STRING,
school_contact STRING,
school_fax STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/dim_school_reformat_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.dim_school_unchanged_stg(
school_key BIGINT,
school_name STRING,
school_cd STRING,
school_type STRING,
school_address1 STRING,
school_address2 STRING,
school_zip STRING,
school_city STRING,
school_state STRING,
school_email STRING,
school_phone1 STRING,
school_contact STRING,
school_fax STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/dim_school_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.dim_school_updated_stg(
school_key BIGINT,
school_name STRING,
school_cd STRING,
school_type STRING,
school_address1 STRING,
school_address2 STRING,
school_zip STRING,
school_city STRING,
school_state STRING,
school_email STRING,
school_phone1 STRING,
school_contact STRING,
school_fax STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/dim_school_updated_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.max_school_key_stg(
school_key INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/max_school_key_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_prescription_acm_config_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id STRING,
config_id STRING,
config_type_cd STRING,
config_type_desc STRING,
active_ind STRING,
state_cd STRING,
drug_class STRING,
effective_start_date STRING,
effective_end_date STRING,
config_data STRING,
config_data_desc STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING,
tracking_id STRING,
partition_column STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/cons_etl_tbf0_prescription_acm_config_stg'
PARTITIONED BY (
proc_cntrl_batch_id DECIMAL(18,0) )""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_rx_gfd_work_sheet_dtl_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id STRING,
work_list_nbr STRING,
pat_id STRING,
rx_gfd_list_nbr STRING,
rx_gfd_cd STRING,
rx_gfd_comments STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/cons_etl_tbf0_rx_gfd_work_sheet_dtl_stg'
PARTITIONED BY (
src_create_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.etl_tbf0_prescription_madr_auto_rules_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr INT,
cdc_rba_nbr DECIMAL(18,0),
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id DECIMAL(18,0),
gpi STRING,
ndc_nbr DECIMAL(11,0),
rule_id DECIMAL(6,0),
rule_seq DECIMAL(3,0),
rule_active_ind STRING,
param_key STRING,
param_value STRING,
audit_sent_local_ind STRING,
audit_dttm STRING,
audit_image_cd STRING,
audit_action_cd STRING,
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/etl_tbf0_prescription_madr_auto_rules_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_auto_rules_stg (
cdc_txn_commit_dttm string,
cdc_txn_commit_dttm_after string,
cdc_seq_nbr string,
cdc_seq_nbr_after string,
cdc_rba_nbr string,
cdc_rba_nbr_after string,
cdc_operation_type_cd string,
cdc_operation_type_cd_after string,
cdc_before_after_cd string,
cdc_before_after_cd_after string,
cdc_txn_position_cd string,
cdc_txn_position_cd_after string,
edw_batch_id string,
edw_batch_id_after string,
gpi string,
gpi_after string,
ndc_nbr string,
ndc_nbr_after string,
rule_id string,
rule_id_after string,
rule_seq string,
rule_seq_after string,
rule_active_ind string,
rule_active_ind_after string,
param_key string,
param_key_after string,
param_value string,
param_value_after string,
audit_sent_local_ind string,
audit_sent_local_ind_after string,
audit_dttm string,
audit_dttm_after string,
audit_image_cd string,
audit_image_cd_after string,
audit_action_cd string,
audit_action_cd_after string,
src_create_user_id string,
src_create_user_id_after string,
src_create_dttm string,
src_create_dttm_after string,
src_update_user_id string,
src_update_user_id_after string,
src_update_dttm string,
src_update_dttm_after string,
tracking_id string)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_auto_rules_stg'
PARTITIONED BY (
partition_column string)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_prescription_acm_config_stg (
cdc_txn_commit_dttm string,
cdc_txn_commit_dttm_after string,
cdc_seq_nbr string,
cdc_seq_nbr_after string,
cdc_rba_nbr string,
cdc_rba_nbr_after string,
cdc_operation_type_cd string,
cdc_operation_type_cd_after string,
cdc_before_after_cd string,
cdc_before_after_cd_after string,
cdc_txn_position_cd string,
cdc_txn_position_cd_after string,
edw_batch_id string,
edw_batch_id_after string,
config_id string,
config_id_after string,
config_type_cd string,
config_type_cd_after string,
config_type_desc string,
config_type_desc_after string,
active_ind string,
active_ind_after string,
state_cd string,
state_cd_after string,
drug_class string,
drug_class_after string,
effective_start_date string,
effective_start_date_after string,
effective_end_date string,
effective_end_date_after string,
config_data string,
config_data_after string,
config_data_desc string,
config_data_desc_after string,
audit_sent_local_ind string,
audit_sent_local_ind_after string,
audit_dttm string,
audit_dttm_after string,
audit_image_cd string,
audit_image_cd_after string,
audit_action_cd string,
audit_action_cd_after string,
src_create_user_id string,
src_create_user_id_after string,
src_create_dttm string,
src_create_dttm_after string,
src_update_user_id string,
src_update_user_id_after string,
src_update_dttm string,
src_update_dttm_after string,
tracking_id string)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_prescription_acm_config_stg'
PARTITIONED BY (
partition_column string)""")
# COMMAND ----------
migration_data=[{"release": "8.2.5", "scripts": ["D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "D.56.1.wrg.hr__recruiting.sql", "D.6.1.crt.pharmacy_healthcare__patient_services.sql", "D.7.1.crt.master_data__customer.sql", "D.2.1.crt.retail__ccpa.sql", "T.10262.1.wrg.prescription_acm_config_bkup_stg.sql", "T.10263.1.wrg.prescription_acm_config_current_stg.sql", "T.10652.1.wrg.prescription_gfd_work_sheet_dtl_insert_records_stg.sql", "T.10654.1.wrg.prescription_gfd_work_sheet_dtl_pre_cdc_stg.sql", "T.10655.1.wrg.prescription_gfd_work_sheet_dtl_retained_records_stg.sql", "T.10657.1.wrg.prescription_gfd_work_sheet_dtl_update_records_stg.sql", "T.10669.1.wrg.prescription_madr_auto_rules_bkup_stg.sql", "T.1068.1.crt.ccpa_rtd_log.sql", "T.13140.1.wrg.wrk_etl_tbfo_prescription_auto_chg_mfg_config_current_stg.sql", "T.13386.1.wrg.wrk_rxo_etl_tbf0_auto_chg_mfg_config_stg.sql", "T.13387.1.wrg.wrk_rxo_etl_tbf0_auto_chg_mfg_config_cdc_stg.sql", "T.13388.1.wrg.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_stg.sql", "T.13389.1.wrg.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_proc_seq_nbr_stg.sql", "T.13390.1.wrg.wrk_rxo_etl_tbf0_auto_chg_mfg_config_prep_stg.sql", "T.13560.1.wrg.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_cdc_stg.sql", "T.13561.1.wrg.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_current_stg.sql", "T.13562.1.wrg.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_stg.sql", "T.13563.1.wrg.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_proc_seq_nbr_stg.sql", "T.13564.1.wrg.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_stg.sql", "T.13565.1.wrg.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_upd_rej_stg.sql", "T.14185.1.wrg.wrk_rxo_prescription_madr_auto_rules_current_stg.sql", "T.14186.1.wrg.wrk_rxo_prescription_madr_auto_rules_final_stg.sql", "T.14187.1.wrg.wrk_rxo_prescription_madr_auto_rules_insert_stg.sql", "T.14188.1.wrg.wrk_rxo_prescription_madr_auto_rules_update_stg.sql", "T.14897.1.wrg.dim_school_dedup_stg.sql", "T.14898.1.wrg.dim_school_new_stg.sql", "T.14899.1.wrg.dim_school_new_assign_stg.sql", "T.14900.1.wrg.dim_school_persistent_stg.sql", "T.14901.1.wrg.dim_school_reformat_stg.sql", "T.14903.1.wrg.dim_school_unchanged_stg.sql", "T.14904.1.wrg.dim_school_updated_stg.sql", "T.15097.1.wrg.max_school_key_stg.sql", "T.694.1.wrg.cons_etl_tbf0_prescription_acm_config_stg.sql", "T.7456.1.wrg.cons_etl_tbf0_rx_gfd_work_sheet_dtl_stg.sql", "T.8051.1.wrg.etl_tbf0_prescription_madr_auto_rules_stg.sql", "T.934.1.wrg.gg_tbf0_auto_rules_stg.sql", "T.939.1.wrg.gg_tbf0_prescription_acm_config_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.2.5", "table_id": "T.10262.1", "table_name": "prescription_acm_config_bkup_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_acm_config_bkup_stg", "table_legacy_schema": "dae_work.prescription_acm_config_bkup", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_acm_config_bkup_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.10263.1", "table_name": "prescription_acm_config_current_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_acm_config_current_stg", "table_legacy_schema": "dae_work.prescription_acm_config_current", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_acm_config_current_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.10652.1", "table_name": "prescription_gfd_work_sheet_dtl_insert_records_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_insert_records_stg", "table_legacy_schema": "dae_work.prescription_gfd_work_sheet_dtl_insert_records", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_insert_records_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.10654.1", "table_name": "prescription_gfd_work_sheet_dtl_pre_cdc_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_pre_cdc_stg", "table_legacy_schema": "dae_work.prescription_gfd_work_sheet_dtl_pre_cdc", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_pre_cdc_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.10655.1", "table_name": "prescription_gfd_work_sheet_dtl_retained_records_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_retained_records_stg", "table_legacy_schema": "dae_work.prescription_gfd_work_sheet_dtl_retained_records", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_retained_records_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.10657.1", "table_name": "prescription_gfd_work_sheet_dtl_update_records_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_update_records_stg", "table_legacy_schema": "dae_work.prescription_gfd_work_sheet_dtl_update_records", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_gfd_work_sheet_dtl_update_records_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.10669.1", "table_name": "prescription_madr_auto_rules_bkup_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_madr_auto_rules_bkup_stg", "table_legacy_schema": "dae_work.prescription_madr_auto_rules_bkup", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_madr_auto_rules_bkup_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.1068.1", "table_name": "ccpa_rtd_log", "table_schema": "retail__ccpa.ccpa_rtd_log", "table_legacy_schema": "dae_cooked.ccpa_rtd_log", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "retail__ccpa.ccpa_rtd_log", "table_partition": "\n  idh_create_dttm STRING", "table_db": "retail__ccpa", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13140.1", "table_name": "wrk_etl_tbfo_prescription_auto_chg_mfg_config_current_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_etl_tbfo_prescription_auto_chg_mfg_config_current_stg", "table_legacy_schema": "dae_work.wrk_etl_tbfo_prescription_auto_chg_mfg_config_current", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_etl_tbfo_prescription_auto_chg_mfg_config_current_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13386.1", "table_name": "wrk_rxo_etl_tbf0_auto_chg_mfg_config_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_auto_chg_mfg_config", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13387.1", "table_name": "wrk_rxo_etl_tbf0_auto_chg_mfg_config_cdc_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_cdc_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_auto_chg_mfg_config_cdc", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_cdc_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13388.1", "table_name": "wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13389.1", "table_name": "wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_proc_seq_nbr_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_proc_seq_nbr_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_proc_seq_nbr", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_ins_upd_proc_seq_nbr_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13390.1", "table_name": "wrk_rxo_etl_tbf0_auto_chg_mfg_config_prep_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_prep_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_auto_chg_mfg_config_prep", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_auto_chg_mfg_config_prep_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13560.1", "table_name": "wrk_rxo_etl_tbf0_prescription_madr_auto_rules_cdc_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_cdc_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_cdc", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_cdc_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13561.1", "table_name": "wrk_rxo_etl_tbf0_prescription_madr_auto_rules_current_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_current_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_current", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_current_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13562.1", "table_name": "wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13563.1", "table_name": "wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_proc_seq_nbr_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_proc_seq_nbr_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_proc_seq_nbr", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_ins_upd_proc_seq_nbr_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13564.1", "table_name": "wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.13565.1", "table_name": "wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_upd_rej_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_upd_rej_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_upd_rej", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_prescription_madr_auto_rules_prep_upd_rej_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14185.1", "table_name": "wrk_rxo_prescription_madr_auto_rules_current_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_current_stg", "table_legacy_schema": "dae_work.wrk_rxo_prescription_madr_auto_rules_current", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_current_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14186.1", "table_name": "wrk_rxo_prescription_madr_auto_rules_final_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_final_stg", "table_legacy_schema": "dae_work.wrk_rxo_prescription_madr_auto_rules_final", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_final_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14187.1", "table_name": "wrk_rxo_prescription_madr_auto_rules_insert_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_insert_stg", "table_legacy_schema": "dae_work.wrk_rxo_prescription_madr_auto_rules_insert", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_insert_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14188.1", "table_name": "wrk_rxo_prescription_madr_auto_rules_update_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_update_stg", "table_legacy_schema": "dae_work.wrk_rxo_prescription_madr_auto_rules_update", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_madr_auto_rules_update_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14897.1", "table_name": "dim_school_dedup_stg", "table_schema": "staging__hr__recruiting.dim_school_dedup_stg", "table_legacy_schema": "hr_work.dim_school_dedup", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.dim_school_dedup_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14898.1", "table_name": "dim_school_new_stg", "table_schema": "staging__hr__recruiting.dim_school_new_stg", "table_legacy_schema": "hr_work.dim_school_new", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.dim_school_new_stg", "table_partition": "", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14899.1", "table_name": "dim_school_new_assign_stg", "table_schema": "staging__hr__recruiting.dim_school_new_assign_stg", "table_legacy_schema": "hr_work.dim_school_new_assign", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.dim_school_new_assign_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14900.1", "table_name": "dim_school_persistent_stg", "table_schema": "staging__hr__recruiting.dim_school_persistent_stg", "table_legacy_schema": "hr_work.dim_school_persistent", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.dim_school_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14901.1", "table_name": "dim_school_reformat_stg", "table_schema": "staging__hr__recruiting.dim_school_reformat_stg", "table_legacy_schema": "hr_work.dim_school_reformat", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.dim_school_reformat_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14903.1", "table_name": "dim_school_unchanged_stg", "table_schema": "staging__hr__recruiting.dim_school_unchanged_stg", "table_legacy_schema": "hr_work.dim_school_unchanged", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.dim_school_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.14904.1", "table_name": "dim_school_updated_stg", "table_schema": "staging__hr__recruiting.dim_school_updated_stg", "table_legacy_schema": "hr_work.dim_school_updated", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.dim_school_updated_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.15097.1", "table_name": "max_school_key_stg", "table_schema": "staging__hr__recruiting.max_school_key_stg", "table_legacy_schema": "hr_work.max_school_key", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.max_school_key_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.694.1", "table_name": "cons_etl_tbf0_prescription_acm_config_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_prescription_acm_config_stg", "table_legacy_schema": "dae_code_etl.cons_etl_tbf0_prescription_acm_config", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_prescription_acm_config_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.7456.1", "table_name": "cons_etl_tbf0_rx_gfd_work_sheet_dtl_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_rx_gfd_work_sheet_dtl_stg", "table_legacy_schema": "dae_work.cons_etl_tbf0_rx_gfd_work_sheet_dtl", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_rx_gfd_work_sheet_dtl_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.8051.1", "table_name": "etl_tbf0_prescription_madr_auto_rules_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.etl_tbf0_prescription_madr_auto_rules_stg", "table_legacy_schema": "dae_work.etl_tbf0_prescription_madr_auto_rules", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.etl_tbf0_prescription_madr_auto_rules_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.934.1", "table_name": "gg_tbf0_auto_rules_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_auto_rules_stg", "table_legacy_schema": "dae_code_raw_ingestion.gg_tbf0_auto_rules", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_auto_rules_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.5", "table_id": "T.939.1", "table_name": "gg_tbf0_prescription_acm_config_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_prescription_acm_config_stg", "table_legacy_schema": "dae_code_raw_ingestion.gg_tbf0_prescription_acm_config", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_prescription_acm_config_stg", "table_partition": "\n  partition_column string", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

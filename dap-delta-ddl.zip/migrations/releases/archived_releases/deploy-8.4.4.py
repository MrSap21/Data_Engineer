# Databricks notebook source 
dbutils.widgets.text(name='marketing_crt_sa', defaultValue='${marketing_crt_sa}', label='marketing_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__loyalty;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_fill_batch_union_keys_stg(
rx_nbr INT,
str_nbr INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_prescription_fill_batch_union_keys_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_create_dttm_change_clean_stg(
str_nbr DECIMAL(5,0),
rx_nbr DECIMAL(7,0),
frm_create_dt STRING,
to_create_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_rx_create_dttm_change_clean_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_verification_stg(
cdc_txn_commit_dttm STRING COMMENT 'FROM deserializer',
cdc_txn_commit_dttm_after STRING COMMENT 'FROM deserializer',
cdc_seq_nbr STRING COMMENT 'FROM deserializer',
cdc_seq_nbr_after STRING COMMENT 'FROM deserializer',
cdc_rba_nbr STRING COMMENT 'FROM deserializer',
cdc_rba_nbr_after STRING COMMENT 'FROM deserializer',
cdc_operation_type_cd STRING COMMENT 'FROM deserializer',
cdc_operation_type_cd_after STRING COMMENT 'FROM deserializer',
cdc_before_after_cd STRING COMMENT 'FROM deserializer',
cdc_before_after_cd_after STRING COMMENT 'FROM deserializer',
cdc_txn_position_cd STRING COMMENT 'FROM deserializer',
cdc_txn_position_cd_after STRING COMMENT 'FROM deserializer',
edw_batch_id STRING COMMENT 'FROM deserializer',
edw_batch_id_after STRING COMMENT 'FROM deserializer',
str_nbr STRING COMMENT 'FROM deserializer',
str_nbr_after STRING COMMENT 'FROM deserializer',
rx_nbr STRING COMMENT 'FROM deserializer',
rx_nbr_after STRING COMMENT 'FROM deserializer',
rx_fill_nbr STRING COMMENT 'FROM deserializer',
rx_fill_nbr_after STRING COMMENT 'FROM deserializer',
rx_partial_fill_nbr STRING COMMENT 'FROM deserializer',
rx_partial_fill_nbr_after STRING COMMENT 'FROM deserializer',
item_num_key STRING COMMENT 'FROM deserializer',
item_num_key_after STRING COMMENT 'FROM deserializer',
item_vrfy_dttm STRING COMMENT 'FROM deserializer',
item_vrfy_dttm_after STRING COMMENT 'FROM deserializer',
fill_vrfy_user_id STRING COMMENT 'FROM deserializer',
fill_vrfy_user_id_after STRING COMMENT 'FROM deserializer',
fill_vrfy_dttm STRING COMMENT 'FROM deserializer',
fill_vrfy_dttm_after STRING COMMENT 'FROM deserializer',
fill_vrfy_str_nbr STRING COMMENT 'FROM deserializer',
fill_vrfy_str_nbr_after STRING COMMENT 'FROM deserializer',
fill_enter_dttm STRING COMMENT 'FROM deserializer',
fill_enter_dttm_after STRING COMMENT 'FROM deserializer',
src_create_user_id STRING COMMENT 'FROM deserializer',
src_create_user_id_after STRING COMMENT 'FROM deserializer',
src_create_dttm STRING COMMENT 'FROM deserializer',
src_create_dttm_after STRING COMMENT 'FROM deserializer',
src_update_user_id STRING COMMENT 'FROM deserializer',
src_update_user_id_after STRING COMMENT 'FROM deserializer',
src_update_dttm STRING COMMENT 'FROM deserializer',
src_update_dttm_after STRING COMMENT 'FROM deserializer',
edw_create_dttm STRING COMMENT 'FROM deserializer',
tracking_id STRING COMMENT 'FROM deserializer')
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_rx_verification_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_verification_temp_stg
(
cdc_txn_commit_dttm                STRING
,cdc_txn_commit_dttm_after          STRING
,cdc_seq_nbr                        STRING
,cdc_seq_nbr_after                  STRING
,cdc_rba_nbr                        STRING
,cdc_rba_nbr_after                  STRING
,cdc_operation_type_cd              STRING
,cdc_operation_type_cd_after        STRING
,cdc_before_after_cd                STRING
,cdc_before_after_cd_after          STRING
,cdc_txn_position_cd                STRING
,cdc_txn_position_cd_after          STRING
,edw_batch_id                       STRING
,edw_batch_id_after                 STRING
,str_nbr                            STRING
,str_nbr_after                      STRING
,rx_nbr                             STRING
,rx_nbr_after                       STRING
,rx_fill_nbr                        STRING
,rx_fill_nbr_after                  STRING
,rx_partial_fill_nbr                STRING
,rx_partial_fill_nbr_after          STRING
,item_num_key                       STRING
,item_num_key_after                 STRING
,item_vrfy_dttm                     STRING
,item_vrfy_dttm_after               STRING
,fill_vrfy_user_id                  STRING
,fill_vrfy_user_id_after            STRING
,fill_vrfy_dttm                     STRING
,fill_vrfy_dttm_after               STRING
,fill_vrfy_str_nbr                  STRING
,fill_vrfy_str_nbr_after            STRING
,fill_enter_dttm                    STRING
,fill_enter_dttm_after              STRING
,src_create_user_id                 STRING
,src_create_user_id_after           STRING
,src_create_dttm                    STRING
,src_create_dttm_after              STRING
,src_update_user_id                 STRING
,src_update_user_id_after           STRING
,src_update_dttm                    STRING
,src_update_dttm_after              STRING
,edw_create_dttm             		string
,tracking_id                        STRING
,partition_column                   STRING
)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_rx_verification_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_point_activity_acap(
loyalty_vndr_txn_id BIGINT,
loyalty_vndr_txn_detail_id BIGINT,
loyalty_vndr_txn_hs_id INT,
loyalty_mbr_id STRING,
sales_txn_id STRING,
sales_txn_dt STRING,
sales_txn_type STRING,
src_sys_cd STRING,
line_item_seq_nbr INT,
dim_loc_str_sk BIGINT,
store_nbr INT,
loyalty_dim_cust_sk BIGINT,
loyalty_cust_sk BIGINT,
loyalty_eid_dim_cust_sk BIGINT,
loyalty_mid_dim_cust_sk BIGINT,
pnt_txn_type_cd STRING,
loyalty_adj_type_cd STRING,
loyalty_adj_cd_desc STRING,
sys_adj_ind STRING,
orig_sales_txn_id STRING,
orig_sales_txn_dt STRING,
orig_sales_txn_type STRING,
orig_ecom_ord_id STRING,
orig_rfn_val STRING,
ecom_ord_id STRING,
rfn_val STRING,
missing_txn_ind STRING,
postd_dttm STRING,
dim_ad_evt_sk BIGINT,
ad_evt_type STRING,
ad_evt_seq_nbr STRING,
ad_evt_vers_type_cd STRING,
ad_evt_vers_seq_nbr STRING,
ad_offer_cd STRING,
plu_nbr DECIMAL(4,0),
dim_prod_sk BIGINT,
upc_prod_sk BIGINT,
upc_nbr DECIMAL(14,0),
wic DECIMAL(6,0),
rx_ind STRING,
ehr_service_cd STRING,
pnt_val INT,
pnt_expire_dt STRING,
redeem_tier_pnt INT,
redeem_tier_dlrs DECIMAL(11,2),
redeem_tndr_dlrs DECIMAL(11,2),
vndr_id INT,
rate DECIMAL(14,5),
calc_cost DECIMAL(15,5),
deal_id INT,
INTernal_fund_ind STRING,
government_funded_cd STRING,
ad_tgted_cust_cd STRING,
rx_elig_ind STRING,
affl_cd STRING,
actv_cd STRING,
src_devc_cd STRING,
third_party_prtnr STRING,
heats_up_ad_evt_type STRING,
heats_up_ad_evt_seq_nbr STRING,
heats_up_ad_evt_vers_type_cd STRING,
heats_up_ad_evt_vers_seq_nbr STRING,
heats_up_ad_offer_cd STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
acap_batch_id STRING,
pnt_dlrs DECIMAL(15,2))
USING DELTA
LOCATION 'abfss://loyalty-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_point_activity_acap'
PARTITIONED BY (
postd_dt STRING)""")
# COMMAND ----------
migration_data=[{"release": "8.4.4", "scripts": ["D.15.1.crt.marketing__loyalty.sql", "D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "T.14040.1.wrg.wrk_rxo_prescription_fill_batch_union_keys_stg.sql", "T.14262.1.wrg.wrk_rxo_rx_create_dttm_change_clean_stg.sql", "T.20023.1.wrg.gg_tbf0_rx_verification_stg.sql", "T.20024.1.wrg.gg_tbf0_rx_verification_temp_stg.sql", "T.20026.1.crt.loyalty_point_activity_acap.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.4.4", "table_id": "T.14040.1", "table_name": "wrk_rxo_prescription_fill_batch_union_keys_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_fill_batch_union_keys_stg", "table_legacy_schema": "dae_work.wrk_rxo_prescription_fill_batch_union_keys", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_prescription_fill_batch_union_keys_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.4", "table_id": "T.14262.1", "table_name": "wrk_rxo_rx_create_dttm_change_clean_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_create_dttm_change_clean_stg", "table_legacy_schema": "dae_work.wrk_rxo_rx_create_dttm_change_clean", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_create_dttm_change_clean_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.4", "table_id": "T.20023.1", "table_name": "gg_tbf0_rx_verification_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_verification_stg", "table_legacy_schema": "dae_code_raw_ingestion.gg_tbf0_rx_verification", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_verification_stg", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.4", "table_id": "T.20024.1", "table_name": "gg_tbf0_rx_verification_temp_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_verification_temp_stg", "table_legacy_schema": "temp_dae_code_raw_ingestion.gg_tbf0_rx_verification", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_verification_temp_stg", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.4", "table_id": "T.20026.1", "table_name": "loyalty_point_activity_acap", "table_schema": "marketing__loyalty.loyalty_point_activity_acap", "table_legacy_schema": "acapdb.loyalty_point_activity", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_point_activity_acap", "table_partition": "", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

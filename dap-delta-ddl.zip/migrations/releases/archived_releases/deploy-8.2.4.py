# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_auto_rules_temp_stg (
cdc_txn_commit_dttm string,
cdc_txn_commit_dttm_after string,
cdc_seq_nbr string,
cdc_seq_nbr_after string,
cdc_rba_nbr string,
cdc_rba_nbr_after string,
cdc_operation_type_cd string,
cdc_operation_type_cd_after string,
cdc_before_after_cd string,
cdc_before_after_cd_after string,
cdc_txn_position_cd string,
cdc_txn_position_cd_after string,
edw_batch_id string,
edw_batch_id_after string,
gpi string,
gpi_after string,
ndc_nbr string,
ndc_nbr_after string,
rule_id string,
rule_id_after string,
rule_seq string,
rule_seq_after string,
rule_active_ind string,
rule_active_ind_after string,
param_key string,
param_key_after string,
param_value string,
param_value_after string,
audit_sent_local_ind string,
audit_sent_local_ind_after string,
audit_dttm string,
audit_dttm_after string,
audit_image_cd string,
audit_image_cd_after string,
audit_action_cd string,
audit_action_cd_after string,
src_create_user_id string,
src_create_user_id_after string,
src_create_dttm string,
src_create_dttm_after string,
src_update_user_id string,
src_update_user_id_after string,
src_update_dttm string,
src_update_dttm_after string,
tracking_id string)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_auto_rules_temp_stg'
PARTITIONED BY (
partition_column string)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_prescription_acm_config_temp_stg (
cdc_txn_commit_dttm string,
cdc_txn_commit_dttm_after string,
cdc_seq_nbr string,
cdc_seq_nbr_after string,
cdc_rba_nbr string,
cdc_rba_nbr_after string,
cdc_operation_type_cd string,
cdc_operation_type_cd_after string,
cdc_before_after_cd string,
cdc_before_after_cd_after string,
cdc_txn_position_cd string,
cdc_txn_position_cd_after string,
edw_batch_id string,
edw_batch_id_after string,
config_id string,
config_id_after string,
config_type_cd string,
config_type_cd_after string,
config_type_desc string,
config_type_desc_after string,
active_ind string,
active_ind_after string,
state_cd string,
state_cd_after string,
drug_class string,
drug_class_after string,
effective_start_date string,
effective_start_date_after string,
effective_end_date string,
effective_end_date_after string,
config_data string,
config_data_after string,
config_data_desc string,
config_data_desc_after string,
audit_sent_local_ind string,
audit_sent_local_ind_after string,
audit_dttm string,
audit_dttm_after string,
audit_image_cd string,
audit_image_cd_after string,
audit_action_cd string,
audit_action_cd_after string,
src_create_user_id string,
src_create_user_id_after string,
src_create_dttm string,
src_create_dttm_after string,
src_update_user_id string,
src_update_user_id_after string,
src_update_dttm string,
src_update_dttm_after string,
tracking_id string)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_prescription_acm_config_temp_stg'
PARTITIONED BY (
partition_column string)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_gfd_work_sheet_temp_stg (
cdc_txn_commit_dttm string,
cdc_txn_commit_dttm_after string,
cdc_seq_nbr string,
cdc_seq_nbr_after string,
cdc_rba_nbr string,
cdc_rba_nbr_after string,
cdc_operation_type_cd string,
cdc_operation_type_cd_after string,
cdc_before_after_cd string,
cdc_before_after_cd_after string,
cdc_txn_position_cd string,
cdc_txn_position_cd_after string,
edw_batch_id string,
edw_batch_id_after string,
store_nbr string,
store_nbr_after string,
rx_nbr string,
rx_nbr_after string,
pat_id string,
pat_id_after string,
rx_fill_nbr string,
rx_fill_nbr_after string,
dspn_fill_nbr string,
dspn_fill_nbr_after string,
image_id string,
image_id_after string,
drug_mme string,
drug_mme_after string,
work_list_stat string,
work_list_stat_after string,
rx_gfd_notes string,
rx_gfd_notes_after string,
work_list_nbr string,
work_list_nbr_after string,
src_create_user_id string,
src_create_user_id_after string,
src_create_dttm string,
src_create_dttm_after string,
src_update_user_id string,
src_update_user_id_after string,
src_update_dttm string,
src_update_dttm_after string,
pbr_last_name string,
pbr_last_name_after string,
pbr_first_name string,
pbr_first_name_after string,
drug_name string,
drug_name_after string,
rx_written_dttm string,
rx_written_dttm_after string,
gfd_ws_orig_ind string,
gfd_ws_orig_ind_after string,
rules_triggered string,
rules_triggered_after string,
tracking_id string)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_rx_gfd_work_sheet_temp_stg'
PARTITIONED BY (
partition_column string)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gfd_work_sheet_dtl_stg (
cdc_txn_commit_dttm string,
cdc_txn_commit_dttm_after string,
cdc_seq_nbr string,
cdc_seq_nbr_after string,
cdc_rba_nbr string,
cdc_rba_nbr_after string,
cdc_operation_type_cd string,
cdc_operation_type_cd_after string,
cdc_before_after_cd string,
cdc_before_after_cd_after string,
cdc_txn_position_cd string,
cdc_txn_position_cd_after string,
edw_batch_id string,
edw_batch_id_after string,
work_list_nbr string,
work_list_nbr_after string,
pat_id string,
pat_id_after string,
rx_gfd_list_nbr string,
rx_gfd_list_nbr_after string,
rx_gfd_cd string,
rx_gfd_cd_after string,
rx_gfd_comments string,
rx_gfd_comments_after string,
src_create_user_id string,
src_create_user_id_after string,
src_create_dttm string,
src_create_dttm_after string,
src_update_user_id string,
src_update_user_id_after string,
src_update_dttm string,
src_update_dttm_after string,
tracking_id string)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gfd_work_sheet_dtl_stg'
PARTITIONED BY (
partition_column string)""")
# COMMAND ----------
migration_data=[{"release": "8.2.4", "scripts": ["D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "T.19171.1.wrg.gg_tbf0_auto_rules_stg.sql", "T.19176.1.wrg.gg_tbf0_prescription_acm_config_stg.sql", "T.19183.1.wrg.gg_tbf0_rx_gfd_work_sheet_stg.sql", "T.19184.1.wrg.gfd_work_sheet_dtl_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.2.4", "table_id": "T.19171.1", "table_name": "gg_tbf0_auto_rules_temp_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_auto_rules_temp_stg", "table_legacy_schema": "temp_dae_code_raw_ingestion.gg_tbf0_auto_rules", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_auto_rules_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.4", "table_id": "T.19176.1", "table_name": "gg_tbf0_prescription_acm_config_temp_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_prescription_acm_config_temp_stg", "table_legacy_schema": "temp_dae_code_raw_ingestion.gg_tbf0_prescription_acm_config", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_prescription_acm_config_temp_stg", "table_partition": "\n  partition_column string", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.4", "table_id": "T.19183.1", "table_name": "gg_tbf0_rx_gfd_work_sheet_temp_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_gfd_work_sheet_temp_stg", "table_legacy_schema": "temp_dae_code_raw_ingestion.gg_tbf0_rx_gfd_work_sheet", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_gfd_work_sheet_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.4", "table_id": "T.19184.1", "table_name": "gfd_work_sheet_dtl_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gfd_work_sheet_dtl_stg", "table_legacy_schema": "temp_dae_code_raw_ingestion.gfd_work_sheet_dtl", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gfd_work_sheet_dtl_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

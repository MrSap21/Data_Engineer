# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
dbutils.widgets.text(name='STORAGE_ACCT_crt_partner_extracts', defaultValue='${STORAGE_ACCT_crt_partner_extracts}', label='STORAGE_ACCT_crt_partner_extracts')
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_partner_extracts', defaultValue='${STORAGE_ACCT_wrg_partner_extracts}', label='STORAGE_ACCT_wrg_partner_extracts')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__employee_performance;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__employee_performance;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.ppl_rating_info_stg(
employee_id STRING,
review_start_date STRING,
review_end_date STRING,
review_type STRING,
position_code STRING,
location_number STRING,
job_title_id STRING,
business_unit_id STRING,
rating STRING,
min_rating STRING,
max_rating STRING,
description STRING,
prom_rating STRING,
review_by_id STRING,
review_sign_id STRING,
employee_sign_date STRING,
reviewer_sign_date STRING,
employee_pid STRING,
manager_pid STRING,
location_type STRING,
review_desc STRING,
rating_update_date STRING,
update_userid STRING,
update_date STRING,
create_userid STRING,
create_date STRING,
action_flag STRING,
update_date_emp_review STRING,
tracking_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/ppl_rating_info_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.ppl_rating_info_last_run_stg(
last_run_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/ppl_rating_info_last_run_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dcd_perf_new_stg(
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
cd_ind STRING,
cd_key STRING,
cd_id STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dcd_perf_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dcd_perf_unchanged_stg(
cd_key STRING,
cd_id STRING,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dcd_perf_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dcd_perf_updates_stg(
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
cd_ind STRING,
cd_key STRING,
cd_id STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dcd_perf_updates_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dcd_performance_stg(
cd_key STRING,
cd_id STRING,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dcd_performance_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dcd_performance_previous_stg(
cd_key STRING,
cd_id STRING,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dcd_performance_previous_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dedup_unfil1_consolidated_stg(
employee_id STRING,
rating STRING,
description STRING,
min_rating STRING,
max_rating STRING,
position_code STRING,
location_number STRING,
job_title_id STRING,
business_unit_id STRING,
prom_rating STRING,
review_by_id STRING,
review_start_date STRING,
review_end_date STRING,
employee_sign_date STRING,
reviewer_sign_date STRING,
review_sign_id STRING,
employee_pid STRING,
manager_pid STRING,
review_type STRING,
review_desc STRING,
update_userid STRING,
update_date STRING,
location_type STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dedup_unfil1_consolidated_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dedup_unfil1_consolidated_reformatted_stg(
employee_id STRING,
rating STRING,
description STRING,
min_rating STRING,
max_rating STRING,
position_code STRING,
location_number STRING,
job_title_id STRING,
business_unit_id STRING,
prom_rating STRING,
review_by_id STRING,
review_start_date STRING,
review_end_date STRING,
employee_sign_date STRING,
reviewer_sign_date STRING,
review_sign_id STRING,
employee_pid STRING,
manager_pid STRING,
review_type STRING,
review_desc STRING,
update_userid STRING,
update_date STRING,
location_type STRING,
reject_reason STRING,
position STRING,
location STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dedup_unfil1_consolidated_reformatted_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dedup_unfil1_reformatted_cpy_reformatted_stg(
cd_key STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
cd_ind STRING,
end_date STRING,
cd_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dedup_unfil1_reformatted_cpy_reformatted_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dedup_unfil1_reformatted_cpy_reformatted_dedup_stg(
cd_key STRING,
cd_id STRING,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dedup_unfil1_reformatted_cpy_reformatted_dedup_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dim_cd_new_inserts_stg(
cd_key STRING,
cd_id STRING,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dim_cd_new_inserts_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dim_cd_nochange_stg(
cd_key STRING,
cd_id STRING,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dim_cd_nochange_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.dim_cd_updates_stg(
cd_key STRING,
cd_id STRING,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/dim_cd_updates_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.fct_emp_performance_details_insert_stg(
period_key STRING,
employee_id STRING,
performance_start_date STRING,
performance_approver_id STRING,
performance_approver_name STRING,
performance_end_date STRING,
performance_effective_date STRING,
performance_effective_end_date STRING,
performance_desc STRING,
performance_rating1 STRING,
performance_reviewer_emp_id STRING,
performance_rating2 STRING,
performance_feedback1 STRING,
performance_feedback2 STRING,
cd_key STRING,
location STRING,
position STRING,
rating_category_class STRING,
rating_location_class STRING,
performance_review_type STRING,
performance_mgr_ack_date STRING,
performance_emp_ack_date STRING,
performance_category STRING,
performance_level STRING,
performance_sub_level STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/fct_emp_performance_details_insert_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.fct_emp_performance_details_update_stg(
period_key STRING,
employee_id STRING,
performance_start_date STRING,
performance_approver_id STRING,
performance_approver_name STRING,
performance_end_date STRING,
performance_effective_date STRING,
performance_effective_end_date STRING,
performance_desc STRING,
performance_rating1 STRING,
performance_reviewer_emp_id STRING,
performance_rating2 STRING,
performance_feedback1 STRING,
performance_feedback2 STRING,
cd_key STRING,
location STRING,
position STRING,
rating_category_class STRING,
rating_location_class STRING,
performance_review_type STRING,
performance_mgr_ack_date STRING,
performance_emp_ack_date STRING,
performance_category STRING,
performance_level STRING,
performance_sub_level STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/fct_emp_performance_details_update_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.inserts_for_fct_emp_performance_details_stg(
period_key STRING,
employee_id STRING,
performance_start_date STRING,
performance_approver_id STRING,
performance_approver_name STRING,
performance_end_date STRING,
performance_effective_date STRING,
performance_effective_end_date STRING,
performance_desc STRING,
performance_rating1 STRING,
performance_reviewer_emp_id STRING,
performance_rating2 STRING,
performance_feedback1 STRING,
performance_feedback2 STRING,
cd_key STRING,
location STRING,
position STRING,
rating_category_class STRING,
rating_location_class STRING,
performance_review_type STRING,
performance_mgr_ack_date STRING,
performance_emp_ack_date STRING,
performance_category STRING,
performance_level STRING,
performance_sub_level STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/inserts_for_fct_emp_performance_details_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.max_cd_key_lookup_stg(
max_cd_key INT,
always_zero INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/max_cd_key_lookup_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.performance_cd_refmt_union_flow1_refmt_stg(
cd_key STRING,
cd_id STRING,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
end_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/performance_cd_refmt_union_flow1_refmt_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.performance_code_dedup_reformatted_stg(
cd_key STRING,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date STRING,
end_date STRING,
cd_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/performance_code_dedup_reformatted_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.performance_codes_deduped_stg(
extract_date STRING,
reason STRING,
dimension_name STRING,
rating_name STRING,
rating_desc STRING,
rating_value STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/performance_codes_deduped_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.ppl_rating_info_deduped_stg(
employee_id STRING,
rating STRING,
description STRING,
min_rating STRING,
max_rating STRING,
position_code STRING,
location_number STRING,
job_title_id STRING,
business_unit_id STRING,
prom_rating STRING,
review_by_id STRING,
review_start_date STRING,
review_end_date STRING,
employee_sign_date STRING,
reviewer_sign_date STRING,
review_sign_id STRING,
employee_pid STRING,
manager_pid STRING,
review_type STRING,
review_desc STRING,
update_userid STRING,
update_date STRING,
location_type STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/ppl_rating_info_deduped_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.ppl_rating_info_deduped2_stg(
employee_id STRING,
rating STRING,
description STRING,
min_rating STRING,
max_rating STRING,
position_code STRING,
location_number STRING,
job_title_id STRING,
business_unit_id STRING,
prom_rating STRING,
review_by_id STRING,
review_start_date STRING,
review_end_date STRING,
employee_sign_date STRING,
reviewer_sign_date STRING,
review_sign_id STRING,
employee_pid STRING,
manager_pid STRING,
review_type STRING,
review_desc STRING,
update_userid STRING,
update_date STRING,
location_type STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/ppl_rating_info_deduped2_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.ppl_rating_info_deduped_filter1_stg(
employee_id STRING,
rating STRING,
description STRING,
min_rating STRING,
max_rating STRING,
position_code STRING,
location_number STRING,
job_title_id STRING,
business_unit_id STRING,
prom_rating STRING,
review_by_id STRING,
review_start_date STRING,
review_end_date STRING,
employee_sign_date STRING,
reviewer_sign_date STRING,
review_sign_id STRING,
employee_pid STRING,
manager_pid STRING,
review_type STRING,
review_desc STRING,
update_userid STRING,
update_date STRING,
location_type STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/ppl_rating_info_deduped_filter1_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.ppl_rating_info_deduped_unfilter1_stg(
employee_id STRING,
rating STRING,
description STRING,
min_rating STRING,
max_rating STRING,
position_code STRING,
location_number STRING,
job_title_id STRING,
business_unit_id STRING,
prom_rating STRING,
review_by_id STRING,
review_start_date STRING,
review_end_date STRING,
employee_sign_date STRING,
reviewer_sign_date STRING,
review_sign_id STRING,
employee_pid STRING,
manager_pid STRING,
review_type STRING,
review_desc STRING,
update_userid STRING,
update_date STRING,
location_type STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/ppl_rating_info_deduped_unfilter1_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.transform0_stg(
employee_id STRING,
period_key STRING,
performance_start_date STRING,
performance_approver_id STRING,
performance_approver_name STRING,
performance_end_date STRING,
performance_effective_date STRING,
performance_effective_end_date STRING,
performance_desc STRING,
performance_rating1 STRING,
performance_reviewer_emp_id STRING,
performance_rating2 STRING,
performance_feedback1 STRING,
performance_feedback2 STRING,
cd_key STRING,
location STRING,
position STRING,
rating_category_class STRING,
rating_location_class STRING,
performance_review_type STRING,
performance_emp_ack_date STRING,
performance_mgr_ack_date STRING,
performance_category STRING,
performance_level STRING,
performance_sub_level STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/transform0_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.transform0_fct_emp_performance_details_inserts_updates_stg(
period_key STRING,
employee_id STRING,
performance_start_date STRING,
performance_approver_id STRING,
performance_approver_name STRING,
performance_end_date STRING,
performance_effective_date STRING,
performance_effective_end_date STRING,
performance_desc STRING,
performance_rating1 STRING,
performance_reviewer_emp_id STRING,
performance_rating2 STRING,
performance_feedback1 STRING,
performance_feedback2 STRING,
cd_key STRING,
location STRING,
position STRING,
rating_category_class STRING,
rating_location_class STRING,
performance_review_type STRING,
performance_mgr_ack_date STRING,
performance_emp_ack_date STRING,
performance_category STRING,
performance_level STRING,
performance_sub_level STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/transform0_fct_emp_performance_details_inserts_updates_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.unchanged_in_fct_emp_performance_details_stg(
period_key STRING,
employee_id STRING,
performance_start_date STRING,
performance_approver_id STRING,
performance_approver_name STRING,
performance_end_date STRING,
performance_effective_date STRING,
performance_effective_end_date STRING,
performance_desc STRING,
performance_rating1 STRING,
performance_reviewer_emp_id STRING,
performance_rating2 STRING,
performance_feedback1 STRING,
performance_feedback2 STRING,
cd_key STRING,
location STRING,
position STRING,
rating_category_class STRING,
rating_location_class STRING,
performance_review_type STRING,
performance_mgr_ack_date STRING,
performance_emp_ack_date STRING,
performance_category STRING,
performance_level STRING,
performance_sub_level STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/unchanged_in_fct_emp_performance_details_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.updates_for_fct_emp_performance_details_stg(
period_key STRING,
employee_id STRING,
performance_start_date STRING,
performance_approver_id STRING,
performance_approver_name STRING,
performance_end_date STRING,
performance_effective_date STRING,
performance_effective_end_date STRING,
performance_desc STRING,
performance_rating1 STRING,
performance_reviewer_emp_id STRING,
performance_rating2 STRING,
performance_feedback1 STRING,
performance_feedback2 STRING,
cd_key STRING,
location STRING,
position STRING,
rating_category_class STRING,
rating_location_class STRING,
performance_review_type STRING,
performance_mgr_ack_date STRING,
performance_emp_ack_date STRING,
performance_category STRING,
performance_level STRING,
performance_sub_level STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/updates_for_fct_emp_performance_details_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.sa_attention_need_stg(
pharmacypatientid STRING,
clientstoreid STRING,
rxnum STRING,
medicationname STRING,
firstname STRING,
lastname STRING,
nextrxfilldate STRING,
firstappearead STRING,
idh_ingestion_time STRING,
tracking_id STRING,
src_file_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/sa_attention_need_stg'
PARTITIONED BY (
idh_ingestion_dt STRING)""")
# COMMAND ----------
migration_data=[{"release": "8.1.3", "scripts": ["D.1.1.crt.partner_extracts__pharmacy_healthcare.sql", "D.39.1.wrg.partner_extracts__pharmacy_healthcare.sql", "D.64.1.crt.hr__employee_performance.sql", "D.92.1.wrg.hr__employee_performance.sql", "T.14749.1.wrg.ppl_rating_info_stg.sql", "T.14750.1.wrg.ppl_rating_info_last_run_stg.sql", "T.14842.1.wrg.dcd_perf_new_stg.sql", "T.14843.1.wrg.dcd_perf_unchanged_stg.sql", "T.14844.1.wrg.dcd_perf_updates_stg.sql", "T.14845.1.wrg.dcd_performance_stg.sql", "T.14846.1.wrg.dcd_performance_previous_stg.sql", "T.14847.1.wrg.dedup_unfil1_consolidated_stg.sql", "T.14848.1.wrg.dedup_unfil1_consolidated_reformatted_stg.sql", "T.14849.1.wrg.dedup_unfil1_reformatted_cpy_reformatted_stg.sql", "T.14850.1.wrg.dedup_unfil1_reformatted_cpy_reformatted_dedup_stg.sql", "T.14860.1.wrg.dim_cd_new_inserts_stg.sql", "T.14861.1.wrg.dim_cd_nochange_stg.sql", "T.14870.1.wrg.dim_cd_updates_stg.sql", "T.14955.1.wrg.fct_emp_performance_details_insert_stg.sql", "T.14957.1.wrg.fct_emp_performance_details_update_stg.sql", "T.15057.1.wrg.inserts_for_fct_emp_performance_details_stg.sql", "T.15096.1.wrg.max_cd_key_lookup_stg.sql", "T.15160.1.wrg.performance_cd_refmt_union_flow1_refmt_stg.sql", "T.15161.1.wrg.performance_code_dedup_reformatted_stg.sql", "T.15162.1.wrg.performance_codes_deduped_stg.sql", "T.15201.1.wrg.ppl_rating_info_deduped_stg.sql", "T.15202.1.wrg.ppl_rating_info_deduped2_stg.sql", "T.15203.1.wrg.ppl_rating_info_deduped_filter1_stg.sql", "T.15204.1.wrg.ppl_rating_info_deduped_unfilter1_stg.sql", "T.15249.1.wrg.transform0_stg.sql", "T.15250.1.wrg.transform0_fct_emp_performance_details_inserts_updates_stg.sql", "T.15251.1.wrg.unchanged_in_fct_emp_performance_details_stg.sql", "T.15252.1.wrg.updates_for_fct_emp_performance_details_stg.sql", "T.19626.1.wrg.sa_attention_need_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.1.3", "table_id": "T.14749.1", "table_name": "ppl_rating_info_stg", "table_schema": "staging__hr__employee_performance.ppl_rating_info_stg", "table_legacy_schema": "hr_raw.ppl_rating_info", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.ppl_rating_info_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14750.1", "table_name": "ppl_rating_info_last_run_stg", "table_schema": "staging__hr__employee_performance.ppl_rating_info_last_run_stg", "table_legacy_schema": "hr_raw.ppl_rating_info_last_run", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.ppl_rating_info_last_run_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14842.1", "table_name": "dcd_perf_new_stg", "table_schema": "staging__hr__employee_performance.dcd_perf_new_stg", "table_legacy_schema": "hr_work.dcd_perf_new", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dcd_perf_new_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14843.1", "table_name": "dcd_perf_unchanged_stg", "table_schema": "staging__hr__employee_performance.dcd_perf_unchanged_stg", "table_legacy_schema": "hr_work.dcd_perf_unchanged", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dcd_perf_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14844.1", "table_name": "dcd_perf_updates_stg", "table_schema": "staging__hr__employee_performance.dcd_perf_updates_stg", "table_legacy_schema": "hr_work.dcd_perf_updates", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dcd_perf_updates_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14845.1", "table_name": "dcd_performance_stg", "table_schema": "staging__hr__employee_performance.dcd_performance_stg", "table_legacy_schema": "hr_work.dcd_performance", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dcd_performance_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14846.1", "table_name": "dcd_performance_previous_stg", "table_schema": "staging__hr__employee_performance.dcd_performance_previous_stg", "table_legacy_schema": "hr_work.dcd_performance_previous", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dcd_performance_previous_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14847.1", "table_name": "dedup_unfil1_consolidated_stg", "table_schema": "staging__hr__employee_performance.dedup_unfil1_consolidated_stg", "table_legacy_schema": "hr_work.dedup_unfil1_consolidated", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dedup_unfil1_consolidated_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14848.1", "table_name": "dedup_unfil1_consolidated_reformatted_stg", "table_schema": "staging__hr__employee_performance.dedup_unfil1_consolidated_reformatted_stg", "table_legacy_schema": "hr_work.dedup_unfil1_consolidated_reformatted", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dedup_unfil1_consolidated_reformatted_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14849.1", "table_name": "dedup_unfil1_reformatted_cpy_reformatted_stg", "table_schema": "staging__hr__employee_performance.dedup_unfil1_reformatted_cpy_reformatted_stg", "table_legacy_schema": "hr_work.dedup_unfil1_reformatted_cpy_reformatted", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dedup_unfil1_reformatted_cpy_reformatted_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14850.1", "table_name": "dedup_unfil1_reformatted_cpy_reformatted_dedup_stg", "table_schema": "staging__hr__employee_performance.dedup_unfil1_reformatted_cpy_reformatted_dedup_stg", "table_legacy_schema": "hr_work.dedup_unfil1_reformatted_cpy_reformatted_dedup", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dedup_unfil1_reformatted_cpy_reformatted_dedup_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14860.1", "table_name": "dim_cd_new_inserts_stg", "table_schema": "staging__hr__employee_performance.dim_cd_new_inserts_stg", "table_legacy_schema": "hr_work.dim_cd_new_inserts", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dim_cd_new_inserts_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14861.1", "table_name": "dim_cd_nochange_stg", "table_schema": "staging__hr__employee_performance.dim_cd_nochange_stg", "table_legacy_schema": "hr_work.dim_cd_nochange", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dim_cd_nochange_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14870.1", "table_name": "dim_cd_updates_stg", "table_schema": "staging__hr__employee_performance.dim_cd_updates_stg", "table_legacy_schema": "hr_work.dim_cd_updates", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.dim_cd_updates_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14955.1", "table_name": "fct_emp_performance_details_insert_stg", "table_schema": "staging__hr__employee_performance.fct_emp_performance_details_insert_stg", "table_legacy_schema": "hr_work.fct_emp_performance_details_insert", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.fct_emp_performance_details_insert_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.14957.1", "table_name": "fct_emp_performance_details_update_stg", "table_schema": "staging__hr__employee_performance.fct_emp_performance_details_update_stg", "table_legacy_schema": "hr_work.fct_emp_performance_details_update", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.fct_emp_performance_details_update_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15057.1", "table_name": "inserts_for_fct_emp_performance_details_stg", "table_schema": "staging__hr__employee_performance.inserts_for_fct_emp_performance_details_stg", "table_legacy_schema": "hr_work.inserts_for_fct_emp_performance_details", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.inserts_for_fct_emp_performance_details_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15096.1", "table_name": "max_cd_key_lookup_stg", "table_schema": "staging__hr__employee_performance.max_cd_key_lookup_stg", "table_legacy_schema": "hr_work.max_cd_key_lookup", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.max_cd_key_lookup_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15160.1", "table_name": "performance_cd_refmt_union_flow1_refmt_stg", "table_schema": "staging__hr__employee_performance.performance_cd_refmt_union_flow1_refmt_stg", "table_legacy_schema": "hr_work.performance_cd_refmt_union_flow1_refmt", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.performance_cd_refmt_union_flow1_refmt_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15161.1", "table_name": "performance_code_dedup_reformatted_stg", "table_schema": "staging__hr__employee_performance.performance_code_dedup_reformatted_stg", "table_legacy_schema": "hr_work.performance_code_dedup_reformatted", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.performance_code_dedup_reformatted_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15162.1", "table_name": "performance_codes_deduped_stg", "table_schema": "staging__hr__employee_performance.performance_codes_deduped_stg", "table_legacy_schema": "hr_work.performance_codes_deduped", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.performance_codes_deduped_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15201.1", "table_name": "ppl_rating_info_deduped_stg", "table_schema": "staging__hr__employee_performance.ppl_rating_info_deduped_stg", "table_legacy_schema": "hr_work.ppl_rating_info_deduped", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.ppl_rating_info_deduped_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15202.1", "table_name": "ppl_rating_info_deduped2_stg", "table_schema": "staging__hr__employee_performance.ppl_rating_info_deduped2_stg", "table_legacy_schema": "hr_work.ppl_rating_info_deduped2", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.ppl_rating_info_deduped2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15203.1", "table_name": "ppl_rating_info_deduped_filter1_stg", "table_schema": "staging__hr__employee_performance.ppl_rating_info_deduped_filter1_stg", "table_legacy_schema": "hr_work.ppl_rating_info_deduped_filter1", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.ppl_rating_info_deduped_filter1_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15204.1", "table_name": "ppl_rating_info_deduped_unfilter1_stg", "table_schema": "staging__hr__employee_performance.ppl_rating_info_deduped_unfilter1_stg", "table_legacy_schema": "hr_work.ppl_rating_info_deduped_unfilter1", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.ppl_rating_info_deduped_unfilter1_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15249.1", "table_name": "transform0_stg", "table_schema": "staging__hr__employee_performance.transform0_stg", "table_legacy_schema": "hr_work.transform0", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.transform0_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15250.1", "table_name": "transform0_fct_emp_performance_details_inserts_updates_stg", "table_schema": "staging__hr__employee_performance.transform0_fct_emp_performance_details_inserts_updates_stg", "table_legacy_schema": "hr_work.transform0_fct_emp_performance_details_inserts_updates", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.transform0_fct_emp_performance_details_inserts_updates_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15251.1", "table_name": "unchanged_in_fct_emp_performance_details_stg", "table_schema": "staging__hr__employee_performance.unchanged_in_fct_emp_performance_details_stg", "table_legacy_schema": "hr_work.unchanged_in_fct_emp_performance_details", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.unchanged_in_fct_emp_performance_details_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.15252.1", "table_name": "updates_for_fct_emp_performance_details_stg", "table_schema": "staging__hr__employee_performance.updates_for_fct_emp_performance_details_stg", "table_legacy_schema": "hr_work.updates_for_fct_emp_performance_details", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.updates_for_fct_emp_performance_details_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.3", "table_id": "T.19626.1", "table_name": "sa_attention_need_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.sa_attention_need_stg", "table_legacy_schema": "dae_raw.sa_attention_need", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.sa_attention_need_stg", "table_partition": "\n  idh_ingestion_dt STRING", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_finance', defaultValue='${STORAGE_ACCT_wrg_finance}', label='STORAGE_ACCT_wrg_finance')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__product;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__product;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__finance__account_payables;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__terms_of_employment;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__terms_of_employment;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.econtacts_stg(
update_flag STRING,
employee_id STRING,
name STRING,
relationship STRING,
created_by STRING,
created_on STRING,
email STRING,
last_modified_by STRING,
last_modified_on STRING,
phone STRING,
primary_flag STRING,
second_phone STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/econtacts_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.paycompnonrecurring_stg(
update_flag STRING,
employee_id STRING,
pay_component_code STRING,
pay_date STRING,
alternative_cost_center STRING,
calculated_amount STRING,
created_by STRING,
created_on STRING,
currency_code STRING,
custom_double_spotbonus STRING,
last_modified_by STRING,
last_modified_on STRING,
value STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/paycompnonrecurring_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.paycomprecurring_stg(
update_flag STRING,
employee_id STRING,
pay_component STRING,
sequence_number STRING,
start_date STRING,
created_by STRING,
created_on STRING,
currency_code STRING,
end_date STRING,
frequency STRING,
last_modified_by STRING,
last_modified_on STRING,
pay_comp_value STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/paycomprecurring_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__terms_of_employment.workpermit_stg(
update_flag STRING,
employee_id STRING,
workpermit_country STRING,
doc_type STRING,
doc_title STRING,
doc_num STRING,
issue_date STRING,
issue_place STRING,
issuing_auth STRING,
exp_date STRING,
validated STRING,
attachment_id STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/terms_of_employment/staging/workpermit_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.econtacts_delta_stg(
update_flag STRING,
employee_id STRING,
name STRING,
relationship STRING,
created_by STRING,
created_on STRING,
email STRING,
last_modified_by STRING,
last_modified_on STRING,
phone STRING,
primary_flag STRING,
second_phone STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/econtacts_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.econtacts_persistent_stg(
update_flag STRING,
employee_id STRING,
name STRING,
relationship STRING,
created_by STRING,
created_on STRING,
email STRING,
last_modified_by STRING,
last_modified_on STRING,
phone STRING,
primary_flag STRING,
second_phone STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/econtacts_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.econtacts_unchanged_stg(
update_flag STRING,
employee_id STRING,
name STRING,
relationship STRING,
created_by STRING,
created_on STRING,
email STRING,
last_modified_by STRING,
last_modified_on STRING,
phone STRING,
primary_flag STRING,
second_phone STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/econtacts_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.paycompnonrecurring_delta_stg(
update_flag STRING,
employee_id STRING,
pay_component_code STRING,
pay_date STRING,
alternative_cost_center STRING,
calculated_amount DECIMAL(9,2),
created_by STRING,
created_on STRING,
currency_code STRING,
custom_double_spotbonus DECIMAL(9,2),
last_modified_by STRING,
last_modified_on STRING,
value DECIMAL(9,2),
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/paycompnonrecurring_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.paycompnonrecurring_unchanged_stg(
update_flag STRING,
employee_id STRING,
pay_component_code STRING,
pay_date STRING,
alternative_cost_center STRING,
calculated_amount DECIMAL(9,2),
created_by STRING,
created_on STRING,
currency_code STRING,
custom_double_spotbonus DECIMAL(9,2),
last_modified_by STRING,
last_modified_on STRING,
value DECIMAL(9,2),
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/paycompnonrecurring_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.paycomprecurring_delta_stg(
update_flag STRING,
employee_id STRING,
pay_component STRING,
sequence_number STRING,
start_date STRING,
created_by STRING,
created_on STRING,
currency_code STRING,
end_date STRING,
frequency STRING,
last_modified_by STRING,
last_modified_on STRING,
pay_comp_value DECIMAL(9,2),
previous_pay_comp_value DECIMAL(9,2),
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/paycomprecurring_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.paycomprecurring_new_stg(
update_flag STRING,
employee_id STRING,
pay_component STRING,
sequence_number STRING,
start_date STRING,
created_by STRING,
created_on STRING,
currency_code STRING,
end_date STRING,
frequency STRING,
last_modified_by STRING,
last_modified_on STRING,
pay_comp_value DECIMAL(9,2),
previous_pay_comp_value DECIMAL(9,2),
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/paycomprecurring_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.paycomprecurring_updated_stg(
update_flag STRING,
employee_id STRING,
pay_component STRING,
sequence_number STRING,
start_date STRING,
created_by STRING,
created_on STRING,
currency_code STRING,
end_date STRING,
frequency STRING,
last_modified_by STRING,
last_modified_on STRING,
pay_comp_value DECIMAL(9,2),
previous_pay_comp_value DECIMAL(9,2),
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/paycomprecurring_updated_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__terms_of_employment.workpermit_delta_stg(
update_flag STRING,
employee_id STRING,
workpermit_country STRING,
doc_type STRING,
doc_title STRING,
doc_num STRING,
issue_date STRING,
issue_place STRING,
issuing_auth STRING,
exp_date STRING,
validated STRING,
attachment_id STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/terms_of_employment/staging/workpermit_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__terms_of_employment.workpermit_unchanged_stg(
update_flag STRING,
employee_id STRING,
workpermit_country STRING,
doc_type STRING,
doc_title STRING,
doc_num STRING,
issue_date STRING,
issue_place STRING,
issuing_auth STRING,
exp_date STRING,
validated STRING,
attachment_id STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/terms_of_employment/staging/workpermit_unchanged_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.2.2", "scripts": ["D.31.1.crt.retail__product.sql", "D.46.1.wrg.retail__product.sql", "D.47.1.wrg.finance__account_payables.sql", "D.56.1.wrg.hr__recruiting.sql", "D.57.1.crt.hr__compensation_benefits.sql", "D.63.1.crt.hr__recruiting.sql", "D.65.1.crt.hr__terms_of_employment.sql", "D.71.1.wrg.hr__compensation_benefits.sql", "D.72.1.wrg.hr__terms_of_employment.sql", "T.14659.1.wrg.econtacts_stg.sql", "T.14728.1.wrg.paycompnonrecurring_stg.sql", "T.14729.1.wrg.paycomprecurring_stg.sql", "T.14778.1.wrg.workpermit_stg.sql", "T.14914.1.wrg.econtacts_delta_stg.sql", "T.14915.1.wrg.econtacts_persistent_stg.sql", "T.14916.1.wrg.econtacts_unchanged_stg.sql", "T.15115.1.wrg.paycompnonrecurring_delta_stg.sql", "T.15117.1.wrg.paycompnonrecurring_unchanged_stg.sql", "T.15119.1.wrg.paycomprecurring_delta_stg.sql", "T.15123.1.wrg.paycomprecurring_new_stg.sql", "T.15126.1.wrg.paycomprecurring_updated_stg.sql", "T.15258.1.wrg.workpermit_delta_stg.sql", "T.15260.1.wrg.workpermit_unchanged_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.2.2", "table_id": "T.14659.1", "table_name": "econtacts_stg", "table_schema": "staging__hr__recruiting.econtacts_stg", "table_legacy_schema": "hr_raw.econtacts", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.econtacts_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.14728.1", "table_name": "paycompnonrecurring_stg", "table_schema": "staging__hr__compensation_benefits.paycompnonrecurring_stg", "table_legacy_schema": "hr_raw.paycompnonrecurring", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.paycompnonrecurring_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.14729.1", "table_name": "paycomprecurring_stg", "table_schema": "staging__hr__compensation_benefits.paycomprecurring_stg", "table_legacy_schema": "hr_raw.paycomprecurring", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.paycomprecurring_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.14778.1", "table_name": "workpermit_stg", "table_schema": "staging__hr__terms_of_employment.workpermit_stg", "table_legacy_schema": "hr_raw.workpermit", "table_domain": "hr", "table_subdomain": "terms_of_employment", "table_location": "staging__hr__terms_of_employment.workpermit_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__terms_of_employment", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.14914.1", "table_name": "econtacts_delta_stg", "table_schema": "staging__hr__recruiting.econtacts_delta_stg", "table_legacy_schema": "hr_work.econtacts_delta", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.econtacts_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.14915.1", "table_name": "econtacts_persistent_stg", "table_schema": "staging__hr__recruiting.econtacts_persistent_stg", "table_legacy_schema": "hr_work.econtacts_persistent", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.econtacts_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.14916.1", "table_name": "econtacts_unchanged_stg", "table_schema": "staging__hr__recruiting.econtacts_unchanged_stg", "table_legacy_schema": "hr_work.econtacts_unchanged", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.econtacts_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.15115.1", "table_name": "paycompnonrecurring_delta_stg", "table_schema": "staging__hr__compensation_benefits.paycompnonrecurring_delta_stg", "table_legacy_schema": "hr_work.paycompnonrecurring_delta", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.paycompnonrecurring_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.15117.1", "table_name": "paycompnonrecurring_unchanged_stg", "table_schema": "staging__hr__compensation_benefits.paycompnonrecurring_unchanged_stg", "table_legacy_schema": "hr_work.paycompnonrecurring_unchanged", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.paycompnonrecurring_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.15119.1", "table_name": "paycomprecurring_delta_stg", "table_schema": "staging__hr__compensation_benefits.paycomprecurring_delta_stg", "table_legacy_schema": "hr_work.paycomprecurring_delta", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.paycomprecurring_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.15123.1", "table_name": "paycomprecurring_new_stg", "table_schema": "staging__hr__compensation_benefits.paycomprecurring_new_stg", "table_legacy_schema": "hr_work.paycomprecurring_new", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.paycomprecurring_new_stg", "table_partition": "", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.15126.1", "table_name": "paycomprecurring_updated_stg", "table_schema": "staging__hr__compensation_benefits.paycomprecurring_updated_stg", "table_legacy_schema": "hr_work.paycomprecurring_updated", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.paycomprecurring_updated_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.15258.1", "table_name": "workpermit_delta_stg", "table_schema": "staging__hr__terms_of_employment.workpermit_delta_stg", "table_legacy_schema": "hr_work.workpermit_delta", "table_domain": "hr", "table_subdomain": "terms_of_employment", "table_location": "staging__hr__terms_of_employment.workpermit_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__terms_of_employment", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.2", "table_id": "T.15260.1", "table_name": "workpermit_unchanged_stg", "table_schema": "staging__hr__terms_of_employment.workpermit_unchanged_stg", "table_legacy_schema": "hr_work.workpermit_unchanged", "table_domain": "hr", "table_subdomain": "terms_of_employment", "table_location": "staging__hr__terms_of_employment.workpermit_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__terms_of_employment", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
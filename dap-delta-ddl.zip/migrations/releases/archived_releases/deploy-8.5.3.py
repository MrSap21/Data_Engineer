# Databricks notebook source
dbutils.widgets.text(name='master_data_crt_sa', defaultValue='${master_data_crt_sa}', label='master_data_crt_sa')
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM master_data__customer.dim_customer_xref;
VACUUM master_data__customer.dim_customer_xref RETAIN 0 HOURS;
DROP TABLE master_data__customer.dim_customer_xref;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://customer-pii@{getArgument('master_data_crt_sa')}.dfs.core.windows.net/dim_customer_xref", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS master_data__customer.dim_customer_xref (
dim_cust_sk BIGINT COMMENT 'dim customer sk',
cust_sk BIGINT COMMENT 'customer sk',
cust_chng_sk BIGINT COMMENT 'customer change sk',
eid_dim_cust_sk BIGINT COMMENT 'eid dim customer sk',
mid_dim_cust_sk BIGINT COMMENT 'mid dim customer sk',
eid_cust_cur_sk BIGINT COMMENT 'eid customer current sk',
mid_cust_cur_sk BIGINT COMMENT 'mid customer current sk',
cust_permnt_addr_chng_sk BIGINT COMMENT 'customer permanent address change sk',
cust_scndry_addr_chng_sk BIGINT COMMENT 'customer secondary address change sk',
cust_work_addr_chng_sk BIGINT COMMENT 'customer work address change sk',
cust_bill_addr_chng_sk BIGINT COMMENT 'customer billing address change sk',
cust_home_cntc_chng_sk BIGINT COMMENT 'customer home contact change sk',
cust_work_cntc_chng_sk BIGINT COMMENT 'customer work contact change sk',
cust_cell_cntc_chng_sk BIGINT COMMENT 'customer cell contact change sk',
cust_mail_cntc_chng_sk BIGINT COMMENT 'customerr mail contact change sk',
cust_old_mail_cntc_chng_sk BIGINT COMMENT 'customer old mail contact change sk',
cust_primary_cntc_chng_sk BIGINT COMMENT 'customer primary contact change sk',
cust_scndry_cntc_chng_sk BIGINT COMMENT 'customer secondary contact change sk',
cust_tertiary_cntc_chng_sk BIGINT COMMENT 'customer tertiary contact change sk',
cust_src_id STRING COMMENT 'customer source identifier',
src_sys_cd STRING COMMENT 'customer source code',
composite_type_cd STRING COMMENT 'composite type code',
msg_type_cd STRING COMMENT 'message type code',
eid STRING COMMENT 'eid',
eid_cur STRING COMMENT 'eid_current',
mid STRING COMMENT 'mid',
mid_cur STRING COMMENT 'mid current',
data_display_restrict_cd STRING COMMENT 'data display restriction code',
edw_rec_begin_dt DATE COMMENT 'edw record begin date{{"FORMAT":"YYYY/MM/DD" }}',
edw_rec_end_dt DATE COMMENT 'edw record end date{{"FORMAT":"YYYY/MM/DD" }}',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING  DELTA
LOCATION
'abfss://customer-pii@{getArgument('master_data_crt_sa')}.dfs.core.windows.net/dim_customer_xref'
PARTITIONED BY (
edw_rec_end_dt)""")
# COMMAND ----------
migration_data=[{"release": "8.5.3", "scripts": ["T.20027.0.crt.dim_customer_xref.sql", "T.20027.1.crt.dim_customer_xref.sql"], "migration_date": "2022-08-19"}]
table_data=[{"release": "8.5.3", "table_id": "T.20027.1", "table_name": "dim_customer_xref", "table_schema": "master_data__customer.dim_customer_xref", "table_legacy_schema": "dae_cooked.dim_customer_xref", "table_domain": "master_data", "table_subdomain": "customer", "table_location": "master_data__customer.dim_customer_xref", "table_partition": "", "table_db": "master_data__customer", "table_zone": "curated", "create_date": "2022-08-19 07:48:55", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.','dim_customer_xref');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
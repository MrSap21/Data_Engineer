# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_digital', defaultValue='${STORAGE_ACCT_wrg_digital}', label='STORAGE_ACCT_wrg_digital')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.refill_reminder_info_stg(
mongo_id STRING COMMENT 'FROM deserializer',
record_id STRING COMMENT 'FROM deserializer',
pat_id STRING COMMENT 'FROM deserializer',
me_id STRING COMMENT 'FROM deserializer',
first_name STRING COMMENT 'FROM deserializer',
last_name STRING COMMENT 'FROM deserializer',
customer_type STRING COMMENT 'FROM deserializer',
br_ind STRING COMMENT 'FROM deserializer',
campaign_code STRING COMMENT 'FROM deserializer',
audience_id STRING COMMENT 'FROM deserializer',
treatment_code STRING COMMENT 'FROM deserializer',
gpi14 STRING COMMENT 'FROM deserializer',
create_dttm STRING COMMENT 'FROM deserializer',
update_dttm STRING COMMENT 'FROM deserializer',
preference_mode STRING COMMENT 'FROM deserializer',
phi_ind STRING COMMENT 'FROM deserializer',
planned_contact_dttm STRING COMMENT 'FROM deserializer',
upi_code STRING COMMENT 'FROM deserializer',
channel_code STRING COMMENT 'FROM deserializer',
timezone_cd STRING COMMENT 'FROM deserializer',
email_id STRING COMMENT 'FROM deserializer',
psm_sent_status STRING COMMENT 'FROM deserializer',
psm_sent_dttm STRING COMMENT 'FROM deserializer',
submit_dttm STRING COMMENT 'FROM deserializer',
order_channel STRING COMMENT 'FROM deserializer',
order_submit_status STRING COMMENT 'FROM deserializer',
order_reference STRING COMMENT 'FROM deserializer',
email_disposition_code STRING COMMENT 'FROM deserializer',
control_group STRING COMMENT 'FROM deserializer',
reminder_template STRING COMMENT 'FROM deserializer',
language_pref STRING COMMENT 'FROM deserializer',
rx_number STRING COMMENT 'FROM deserializer',
drug_name STRING COMMENT 'FROM deserializer',
drug_id STRING COMMENT 'FROM deserializer',
group_drug_name STRING COMMENT 'FROM deserializer',
last_fill_date STRING COMMENT 'FROM deserializer',
ninety_day_ind STRING COMMENT 'FROM deserializer',
prescriber_first_name STRING COMMENT 'FROM deserializer',
prescriber_last_name STRING COMMENT 'FROM deserializer',
quantity STRING COMMENT 'FROM deserializer',
store_brand STRING COMMENT 'FROM deserializer',
store_number STRING COMMENT 'FROM deserializer',
phone_number STRING COMMENT 'FROM deserializer',
phone_status STRING COMMENT 'FROM deserializer',
sent_dttm STRING COMMENT 'FROM deserializer',
disposition_cd STRING COMMENT 'FROM deserializer',
disposition_dttm STRING COMMENT 'FROM deserializer')
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/refill_reminder_info_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.refill_reminder_info_temp_stg(
mongo_id STRING,
record_id STRING,
pat_id STRING,
me_id STRING,
first_name STRING,
last_name STRING,
customer_type STRING,
br_ind STRING,
campaign_code STRING,
audience_id STRING,
treatment_code STRING,
gpi14 STRING,
create_dttm STRING,
update_dttm STRING,
preference_mode STRING,
phi_ind STRING,
planned_contact_dttm STRING,
upi_code STRING,
channel_code STRING,
timezone_cd STRING,
email struct<emailid:string,psmsent:struct<status:string,sentdttm:string>,order:struct<submitdttm:string,channel:string,submitstatus:string,orderreference:string>,dispositioncode:string>,
email_id STRING,
psm_sent_status STRING,
psm_sent_dttm STRING,
submit_dttm STRING,
order_channel STRING,
order_submit_status STRING,
order_reference STRING,
email_disposition_code STRING,
control_group STRING,
reminder_template STRING,
language_pref STRING,
rx_details array<struct<rxnumber:string,drugname:string,drugid:string,groupdrugname:string,lastfilldate:string,ninetydayind:string,prescriberfname:string,prescriberlname:string,quantity:string,store:struct<brand:string,number:string>>>,
rx_number STRING,
drug_name STRING,
drug_id STRING,
group_drug_name STRING,
last_fill_date STRING,
ninety_day_ind STRING,
prescriber_first_name STRING,
prescriber_last_name STRING,
quantity STRING,
store_brand STRING,
store_number STRING,
phone_numbers array<struct<phonenumber:string,sms:struct<status:string,sentdttm:string>,dispositioncd:string,dispositiondttm:string>>,
phone_number STRING,
phone_status STRING,
sent_dttm STRING,
disposition_cd STRING,
disposition_dttm STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/refill_reminder_info_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.refill_reminder_info_update_records_stg(
mongo_id STRING,
record_id STRING,
pat_id STRING,
me_id STRING,
first_name STRING,
last_name STRING,
customer_type STRING,
br_ind STRING,
campaign_code STRING,
audience_id STRING,
treatment_code STRING,
gpi14 STRING,
create_dttm STRING,
update_dttm STRING,
preference_mode STRING,
phi_ind STRING,
planned_contact_dttm STRING,
upi_code STRING,
channel_code STRING,
timezone_cd STRING,
email struct<emailid:string,psmsent:struct<status:string,sentdttm:string>,order:struct<submitdttm:string,channel:string,submitstatus:string,orderreference:string>,dispositioncode:string>,
email_id STRING,
psm_sent_status STRING,
psm_sent_dttm STRING,
submit_dttm STRING,
order_channel STRING,
order_submit_status STRING,
order_reference STRING,
email_disposition_code STRING,
control_group STRING,
reminder_template STRING,
language_pref STRING,
rx_details array<struct<rxnumber:string,drugname:string,drugid:string,groupdrugname:string,lastfilldate:string,ninetydayind:string,prescriberfname:string,prescriberlname:string,quantity:string,store:struct<brand:string,number:string>>>,
rx_number STRING,
drug_name STRING,
drug_id STRING,
group_drug_name STRING,
last_fill_date STRING,
ninety_day_ind STRING,
prescriber_first_name STRING,
prescriber_last_name STRING,
quantity STRING,
store_brand STRING,
store_number STRING,
phone_numbers array<struct<phonenumber:string,sms:struct<status:string,sentdttm:string>,dispositioncd:string,dispositiondttm:string>>,
phone_number STRING,
phone_status STRING,
sent_dttm STRING,
disposition_cd STRING,
disposition_dttm STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/refill_reminder_info_update_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.refill_reminder_info_insert_records_stg(
mongo_id STRING,
record_id STRING,
pat_id STRING,
me_id STRING,
first_name STRING,
last_name STRING,
customer_type STRING,
br_ind STRING,
campaign_code STRING,
audience_id STRING,
treatment_code STRING,
gpi14 STRING,
create_dttm STRING,
update_dttm STRING,
preference_mode STRING,
phi_ind STRING,
planned_contact_dttm STRING,
upi_code STRING,
channel_code STRING,
timezone_cd STRING,
email struct<emailid:string,psmsent:struct<status:string,sentdttm:string>,order:struct<submitdttm:string,channel:string,submitstatus:string,orderreference:string>,dispositioncode:string>,
email_id STRING,
psm_sent_status STRING,
psm_sent_dttm STRING,
submit_dttm STRING,
order_channel STRING,
order_submit_status STRING,
order_reference STRING,
email_disposition_code STRING,
control_group STRING,
reminder_template STRING,
language_pref STRING,
rx_details array<struct<rxnumber:string,drugname:string,drugid:string,groupdrugname:string,lastfilldate:string,ninetydayind:string,prescriberfname:string,prescriberlname:string,quantity:string,store:struct<brand:string,number:string>>>,
rx_number STRING,
drug_name STRING,
drug_id STRING,
group_drug_name STRING,
last_fill_date STRING,
ninety_day_ind STRING,
prescriber_first_name STRING,
prescriber_last_name STRING,
quantity STRING,
store_brand STRING,
store_number STRING,
phone_numbers array<struct<phonenumber:string,sms:struct<status:string,sentdttm:string>,dispositioncd:string,dispositiondttm:string>>,
phone_number STRING,
phone_status STRING,
sent_dttm STRING,
disposition_cd STRING,
disposition_dttm STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/refill_reminder_info_insert_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.refill_reminder_info_retained_records_stg(
mongo_id STRING,
record_id STRING,
pat_id STRING,
me_id STRING,
first_name STRING,
last_name STRING,
customer_type STRING,
br_ind STRING,
campaign_code STRING,
audience_id STRING,
treatment_code STRING,
gpi14 STRING,
create_dttm STRING,
update_dttm STRING,
preference_mode STRING,
phi_ind STRING,
planned_contact_dttm STRING,
upi_code STRING,
channel_code STRING,
timezone_cd STRING,
email struct<emailid:string,psmsent:struct<status:string,sentdttm:string>,order:struct<submitdttm:string,channel:string,submitstatus:string,orderreference:string>,dispositioncode:string>,
email_id STRING,
psm_sent_status STRING,
psm_sent_dttm STRING,
submit_dttm STRING,
order_channel STRING,
order_submit_status STRING,
order_reference STRING,
email_disposition_code STRING,
control_group STRING,
reminder_template STRING,
language_pref STRING,
rx_details array<struct<rxnumber:string,drugname:string,drugid:string,groupdrugname:string,lastfilldate:string,ninetydayind:string,prescriberfname:string,prescriberlname:string,quantity:string,store:struct<brand:string,number:string>>>,
rx_number STRING,
drug_name STRING,
drug_id STRING,
group_drug_name STRING,
last_fill_date STRING,
ninety_day_ind STRING,
prescriber_first_name STRING,
prescriber_last_name STRING,
quantity STRING,
store_brand STRING,
store_number STRING,
phone_numbers array<struct<phonenumber:string,sms:struct<status:string,sentdttm:string>,dispositioncd:string,dispositiondttm:string>>,
phone_number STRING,
phone_status STRING,
sent_dttm STRING,
disposition_cd STRING,
disposition_dttm STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/refill_reminder_info_retained_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_order_overview_stg(
rx_ord_ref_num STRING COMMENT 'FROM deserializer',
rx_ord_store_num STRING COMMENT 'FROM deserializer',
rx_ord_channel_cd STRING COMMENT 'FROM deserializer',
rx_ord_channel_detail_cd STRING COMMENT 'FROM deserializer',
rx_ord_dttm STRING COMMENT 'FROM deserializer',
rx_ord_gq_submit_dttm STRING COMMENT 'FROM deserializer',
rx_ord_process_count STRING COMMENT 'FROM deserializer',
rx_ord_submit_status_cd STRING COMMENT 'FROM deserializer',
rx_ord_owner_me_id STRING COMMENT 'FROM deserializer',
rx_ord_site_cd STRING COMMENT 'FROM deserializer')
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_order_overview_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.www_rx_order_overview_temp_stg(
rx_ord_ref_num STRING,
rx_ord_dttm TIMESTAMP,
rx_ord_owner_me_id STRING,
rx_ord_store_num STRING,
rx_ord_channel_cd STRING,
rx_ord_channel_detail_cd STRING,
rx_ord_submit_status_cd STRING,
rx_ord_process_count STRING,
rx_ord_gq_submit_dttm TIMESTAMP,
rx_ord_site_cd STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/www_rx_order_overview_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_order_overview_update_records_stg(
rx_ord_ref_num STRING,
rx_ord_store_num STRING,
rx_ord_channel_cd STRING,
rx_ord_channel_detail_cd STRING,
rx_ord_dttm TIMESTAMP,
rx_ord_gq_submit_dttm TIMESTAMP,
rx_ord_process_count STRING,
rx_ord_submit_status_cd STRING,
rx_ord_owner_me_id STRING,
rx_ord_site_cd STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_order_overview_update_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_order_overview_insert_records_stg(
rx_ord_ref_num STRING,
rx_ord_store_num STRING,
rx_ord_channel_cd STRING,
rx_ord_channel_detail_cd STRING,
rx_ord_dttm TIMESTAMP,
rx_ord_gq_submit_dttm TIMESTAMP,
rx_ord_process_count STRING,
rx_ord_submit_status_cd STRING,
rx_ord_owner_me_id STRING,
rx_ord_site_cd STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_order_overview_insert_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_order_overview_retained_records_stg(
rx_ord_ref_num STRING,
rx_ord_store_num STRING,
rx_ord_channel_cd STRING,
rx_ord_channel_detail_cd STRING,
rx_ord_dttm TIMESTAMP,
rx_ord_gq_submit_dttm TIMESTAMP,
rx_ord_process_count STRING,
rx_ord_submit_status_cd STRING,
rx_ord_owner_me_id STRING,
rx_ord_site_cd STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_order_overview_retained_records_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.1.8", "scripts": ["D.54.1.wrg.digital__ecom.sql", "T.19943.1.wrg.refill_reminder_info_stg.sql", "T.19944.1.wrg.refill_reminder_info_temp_stg.sql", "T.19945.1.wrg.refill_reminder_info_update_records_stg.sql", "T.19946.1.wrg.refill_reminder_info_insert_records_stg.sql", "T.19947.1.wrg.refill_reminder_info_retained_records_stg.sql", "T.19948.1.wrg.rx_order_overview_stg.sql", "T.19949.1.wrg.www_rx_order_overview_temp_stg.sql", "T.19950.1.wrg.rx_order_overview_update_records_stg.sql", "T.19951.1.wrg.rx_order_overview_insert_records_stg.sql", "T.19952.1.wrg.rx_order_overview_retained_records_stg.sql"], "migration_date": "2022-08-11"}]
table_data=[{"release": "8.1.8", "table_id": "T.19943.1", "table_name": "refill_reminder_info_stg", "table_schema": "staging__digital__ecom.refill_reminder_info_stg", "table_legacy_schema": "acapetldb.refill_reminder_info", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.refill_reminder_info_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}, {"release": "8.1.8", "table_id": "T.19944.1", "table_name": "refill_reminder_info_temp_stg", "table_schema": "staging__digital__ecom.refill_reminder_info_temp_stg", "table_legacy_schema": "acapetldb.refill_reminder_info_temp", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.refill_reminder_info_temp_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}, {"release": "8.1.8", "table_id": "T.19945.1", "table_name": "refill_reminder_info_update_records_stg", "table_schema": "staging__digital__ecom.refill_reminder_info_update_records_stg", "table_legacy_schema": "acapetldb.refill_reminder_info_update_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.refill_reminder_info_update_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}, {"release": "8.1.8", "table_id": "T.19946.1", "table_name": "refill_reminder_info_insert_records_stg", "table_schema": "staging__digital__ecom.refill_reminder_info_insert_records_stg", "table_legacy_schema": "acapetldb.refill_reminder_info_insert_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.refill_reminder_info_insert_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}, {"release": "8.1.8", "table_id": "T.19947.1", "table_name": "refill_reminder_info_retained_records_stg", "table_schema": "staging__digital__ecom.refill_reminder_info_retained_records_stg", "table_legacy_schema": "acapetldb.refill_reminder_info_retained_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.refill_reminder_info_retained_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}, {"release": "8.1.8", "table_id": "T.19948.1", "table_name": "rx_order_overview_stg", "table_schema": "staging__digital__ecom.rx_order_overview_stg", "table_legacy_schema": "acapetldb.rx_order_overview", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_order_overview_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}, {"release": "8.1.8", "table_id": "T.19949.1", "table_name": "www_rx_order_overview_temp_stg", "table_schema": "staging__digital__ecom.www_rx_order_overview_temp_stg", "table_legacy_schema": "acapetldb.www_rx_order_overview_temp", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.www_rx_order_overview_temp_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}, {"release": "8.1.8", "table_id": "T.19950.1", "table_name": "rx_order_overview_update_records_stg", "table_schema": "staging__digital__ecom.rx_order_overview_update_records_stg", "table_legacy_schema": "acapetldb.rx_order_overview_update_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_order_overview_update_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}, {"release": "8.1.8", "table_id": "T.19951.1", "table_name": "rx_order_overview_insert_records_stg", "table_schema": "staging__digital__ecom.rx_order_overview_insert_records_stg", "table_legacy_schema": "acapetldb.rx_order_overview_insert_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_order_overview_insert_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}, {"release": "8.1.8", "table_id": "T.19952.1", "table_name": "rx_order_overview_retained_records_stg", "table_schema": "staging__digital__ecom.rx_order_overview_retained_records_stg", "table_legacy_schema": "acapetldb.rx_order_overview_retained_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_order_overview_retained_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-11 23:46:18", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
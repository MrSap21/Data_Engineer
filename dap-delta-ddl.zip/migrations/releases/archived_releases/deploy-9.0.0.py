# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__retail__retail_sales.sales_transaction_data_migration;
VACUUM staging__retail__retail_sales.sales_transaction_data_migration RETAIN 0 HOURS;
DROP TABLE staging__retail__retail_sales.sales_transaction_data_migration;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_transaction_data_migration", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.sales_transaction_data_migration (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_ord_src_type STRING COMMENT 'sales order source type' ,
sales_txn_type STRING COMMENT 'sales_txn type',
dim_loc_store_sk BIGINT COMMENT 'dim_loc_sk' ,
loc_store_sk BIGINT COMMENT 'loc_id' ,
store_nbr INT COMMENT 'store DOUBLE' ,
dim_loc_mgrs_sk BIGINT COMMENT 'dim_loc_staff_sk' ,
src_cust_id STRING COMMENT 'ecom_customer_id' ,
txn_end_dttm TIMESTAMP COMMENT 'txn_end_dttm',
ord_stat_cd STRING COMMENT 'order status code' ,
fulfillment_type_cd STRING COMMENT 'fulfillment type code' ,
originating_str_nbr INT COMMENT 'originating_str_nbr' ,
originating_store_sk BIGINT COMMENT 'originating store surrogate key' ,
fulfillment_str_nbr INT COMMENT 'fulfillment store DOUBLE' ,
fulfillment_store_sk BIGINT COMMENT 'fulfillment store surrogate key' ,
pick_up_at_str_nbr INT COMMENT 'pick up at store DOUBLE' ,
pickup_at_store_sk BIGINT COMMENT 'pickup at store surrogate key' ,
bypass_reason_cd SMALLINT COMMENT 'bypass reason code' ,
ord_entry_channel_cd STRING COMMENT 'order entry channel code' ,
ord_desc STRING COMMENT 'order description' ,
promise_dt DATE COMMENT 'promise date{{"FORMAT":"YYYY/MM/DD" }}' ,
promise_tm STRING COMMENT 'promise time' ,
rx_reqst_fill_dt DATE COMMENT 'rx request fill date{{"FORMAT":"YYYY/MM/DD" }}' ,
rx_reqst_fill_tm STRING COMMENT 'rx request fill time' ,
txn_type STRING COMMENT 'txn_type' ,
ord_ship_dt DATE COMMENT 'order ship date{{"FORMAT":"YYYY/MM/DD" }}' ,
ord_ship_tm STRING COMMENT 'order ship time' ,
return_stat_desc STRING COMMENT 'return status description' ,
prcs_ind STRING COMMENT 'prcs indicator' ,
prcs_immediate_ind STRING COMMENT 'prcs immediate indicator' ,
nbr_of_images INT COMMENT 'number of images' ,
tot_image_sz_kb DECIMAL(10,2) COMMENT 'total image size mb' ,
pcp_ord_id STRING COMMENT 'pcp order id' ,
vndr_cust_id STRING COMMENT 'vendor customer id' ,
vndr_ord_id STRING COMMENT 'vendor order id' ,
commision_vndr_cd STRING COMMENT 'commision vendor code' ,
photo_origin_id STRING COMMENT 'photo origin identifier' ,
spcl_ord_desc STRING COMMENT 'special order description' ,
orig_inv_dlrs DECIMAL(8,2) COMMENT 'original invoice dollars' ,
prod_cost_dlrs DECIMAL(8,2) COMMENT 'product cost dollars' ,
shipping_price_dlrs DECIMAL(8,2) COMMENT 'shipping price dollars' ,
in_str_ord_ind STRING COMMENT 'in store order indicator' ,
share_ord_ind STRING COMMENT 'shared order indicator' ,
aarp_ind STRING COMMENT 'aarp indicator' ,
ord_return_ind STRING COMMENT 'order return indicator' ,
pre_click_ord_ind STRING COMMENT 'pre click order indicator' ,
held_ord_ind STRING COMMENT 'held order indicator' ,
lens_ord_ind STRING COMMENT 'lens order indicator' ,
self_pay_ind STRING COMMENT 'self pay indicator' ,
xref_line_item_seq_nbr SMALLINT COMMENT 'xref_line_item_seq_nbr',
generic_ord_ind STRING COMMENT 'generic order indicator' ,
fsa_ind STRING COMMENT 'flexible spending account indicator' ,
cashier_nbr SMALLINT COMMENT 'cashier_nbr' ,
create_id STRING COMMENT 'create_id' ,
cashier_employee_id DECIMAL(10,0) COMMENT 'cashier id' ,
mgr_employee_id DECIMAL(10,0) COMMENT 'manager id' ,
loyalty_employee_id DECIMAL(10,0) COMMENT 'employee_id' ,
exchange_cd STRING COMMENT 'exchange_cd' ,
offline_txn_ind STRING COMMENT 'offline_txn_ind' ,
price_verify_cd STRING COMMENT 'price_verify_cd' ,
register_nbr SMALLINT COMMENT 'register_nbr' ,
store_register_sk BIGINT COMMENT 'store register sk',
rfn_value STRING COMMENT 'rfn_value' ,
next_gen_rfn_value STRING COMMENT 'next_gen_rfn_value' ,
training_txn_ind STRING COMMENT 'training_txn_ind' ,
txn_incomplete_ind STRING COMMENT 'txn_incomplete_ind' ,
txn_nbr SMALLINT COMMENT 'txn_nbr',
txn_start_dttm TIMESTAMP COMMENT 'txn_start_dttm',
txn_tot_discnt_line_cnt SMALLINT COMMENT 'txn_tot_discnt_line_cnt' ,
txn_tot_discnt_line_qty SMALLINT COMMENT 'txn_tot_discnt_line_qty' ,
txn_tot_discnt_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_return_dlrs' ,
txn_tot_discnt_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_sale_dlrs' ,
txn_tot_dlrs DECIMAL(8,2) COMMENT 'txn_tot_dlrs' ,
txn_tot_line_cnt SMALLINT COMMENT 'txn_tot_line_cnt' ,
txn_tot_line_voided_cnt SMALLINT COMMENT 'txn_tot_line_voided_cnt' ,
txn_tot_line_voids_cnt SMALLINT COMMENT 'txn_tot_line_voids_cnt' ,
txn_tot_mfg_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_mfg_coup_dlrs' ,
txn_tot_net_qty DECIMAL(5,0) COMMENT 'txn_tot_net_qty' ,
txn_tot_price_vrfy_line_cnt SMALLINT COMMENT 'txn_tot_price_vrfy_line_cnt' ,
txn_tot_reg_line_cnt SMALLINT COMMENT 'txn_tot_reg_line_cnt' ,
txn_tot_reg_line_qty SMALLINT COMMENT 'txn_tot_reg_line_qty' ,
txn_tot_reg_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_return_dlrs' ,
txn_tot_reg_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_sale_dlrs' ,
txn_tot_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_return_dlrs' ,
txn_tot_return_line_cnt SMALLINT COMMENT 'txn_tot_return_line_cnt' ,
txn_tot_rx_line_cnt SMALLINT COMMENT 'txn_tot_rx_line_cnt' ,
txn_tot_tax_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tax_dlrs' ,
txn_tot_tndr_cnt SMALLINT COMMENT 'txn_tot_tndr_cnt' ,
txn_tot_tndr_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tndr_dlrs' ,
txn_tot_void_dlrs DECIMAL(8,2) COMMENT 'txn_tot_void_dlrs' ,
txn_tot_wag_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_wag_coup_dlrs' ,
discnt_mode_cd STRING COMMENT 'discnt_mode_cd' ,
affiliate_discnt_cd STRING COMMENT 'affiliate discount code' ,
post_void_status_cd STRING COMMENT 'post_void_status_cd' ,
return_reason_cd SMALLINT COMMENT 'return reason code' ,
return_auth_nbr STRING COMMENT 'return authorization DOUBLE' ,
vndr_refund_id DECIMAL(19,0) COMMENT 'vendor refund id' ,
shipping_price_discnt_dlrs DECIMAL(8,2) COMMENT 'shipping price discount dollars' ,
suggest_tax_return_dlrs DECIMAL(8,2) COMMENT 'suggested tax return dollars' ,
actl_tax_return_dlrs DECIMAL(8,2) COMMENT 'actl_tax_return_dlrs' ,
suggest_ship_return_dlrs DECIMAL(8,2) COMMENT 'suggested ship return dollars' ,
actl_ship_return_dlrs DECIMAL(8,2) COMMENT 'actl_ship_return_dlrs' ,
paypal_return_dlrs DECIMAL(8,2) COMMENT 'paypal_return_dlrs' ,
authenticator_id STRING COMMENT 'authenticator_id' ,
credit_card_return_dlrs DECIMAL(8,2) COMMENT 'credit_card_return_dlrs' ,
gift_card_return_dlrs DECIMAL(8,2) COMMENT 'gift_card_return_dlrs' ,
loyalty_enrl_ind STRING COMMENT 'loyalty enrollment indicator' ,
aarp_opt_out_ind STRING COMMENT 'aarp opt out indicator' ,
identification_method STRING COMMENT 'identification method' ,
price_button_evt_ind STRING COMMENT 'pricing button event indicator' ,
emp_discnt_button_use STRING COMMENT 'employee discount button_use' ,
loyalty_card_scan_ind STRING COMMENT 'loyalty card scan indicator' ,
store_emp_loyalty_acct_ind STRING COMMENT 'store employee loyalty account indicator' ,
onscreen_redeem_button_use STRING COMMENT 'onscreen_redeem_button_use' ,
bounty_super_refund_cd STRING COMMENT 'bounty_super_refund_cd' ,
csr_id STRING COMMENT 'csr identifier' ,
ord_sub_type_cd STRING COMMENT 'order sub type code' ,
void_type_cd STRING COMMENT 'void type code' ,
void_reason_cd STRING COMMENT 'void reason code' ,
emv_stat_cd STRING COMMENT 'emv status code' ,
pinpad_stat_cd STRING COMMENT 'pinpad status code' ,
channel_cd STRING COMMENT 'channel code' ,
channel_desc STRING COMMENT 'channel description' ,
channel_detail_cd STRING COMMENT 'channel detail code' ,
channel_detail_desc STRING COMMENT 'channel detail description' ,
func_cd STRING COMMENT 'functionality code' ,
func_desc STRING COMMENT 'functionality description' ,
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_transaction_data_migration'
PARTITIONED BY (
src_sys_cd STRING,
sales_txn_dt DATE)""")
# COMMAND ----------
migration_data=[{"release": "9.0.0", "scripts": ["T.19973.0.wrg.sales_transaction_data_migration.sql", "T.19973.1.wrg.sales_transaction_data_migration.sql"], "migration_date": "2022-08-29"}]
table_data=[{"release": "9.0.0", "table_id": "T.19973.1", "table_name": "sales_transaction_data_migration", "table_schema": "staging__retail__retail_sales.sales_transaction_data_migration", "table_legacy_schema": "dae_cooked.sales_transaction", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.sales_transaction_data_migration", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-29 23:54:17", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.','sales_transaction_data_migration');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

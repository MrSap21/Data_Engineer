# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp1_stg(
str_nbr INT,
bin_nbr STRING,
prcs_ctrl_nbr STRING,
store_npi_nbr STRING,
general_recipient_nbr STRING,
fill_enter_dt STRING,
rx_nbr INT,
rx_fill_nbr INT,
drug_id INT,
dspn_ndc STRING,
other_payr_coverage_cd SMALLINT,
plan_group_nbr STRING,
plan_tot_paid_dlrs DECIMAL(8,2),
plan_return_cost_dlrs DECIMAL(8,2),
plan_return_fee_dlrs DECIMAL(8,2),
plan_return_copay_dlrs DECIMAL(8,2),
plan_return_tax_dlrs DECIMAL(8,2),
plan_ar_dlrs DECIMAL(8,2),
plan_submit_fee_dlrs DECIMAL(8,2),
basis_of_reimb_detrm STRING,
fill_label_price_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
third_party_plan_id STRING,
claim_ref_nbr STRING,
del_adjud_cd STRING,
rx_create_dt STRING,
fill_sold_dt STRING,
fill_del_dt STRING,
pat_id DECIMAL(13,0),
plan_type STRING,
contract_name STRING,
plan_name STRING,
dspn_fill_nbr SMALLINT,
partial_fill_cd STRING,
fill_pay_method_cd STRING,
fill_days_supply SMALLINT,
fill_qty_dspn DECIMAL(8,3),
cob_ind STRING,
rx_partial_fill_nbr INT,
fill_enter_tm STRING,
update_dttm STRING,
edw_batch_id INT)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/icplus_status_update_har_1808_tmp1_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.icplus_status_har_ua_stg(
str_nbr INT,
fill_enter_dt STRING,
rx_nbr INT,
rx_fill_nbr INT,
drug_id INT,
dspn_ndc STRING,
fill_label_price_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
rx_create_dt STRING,
fill_sold_dt STRING,
fill_del_dt STRING,
pat_id DECIMAL(13,0),
dspn_fill_nbr SMALLINT,
partial_fill_cd STRING,
fill_pay_method_cd STRING,
fill_days_supply SMALLINT,
fill_qty_dspn DECIMAL(8,3),
rx_partial_fill_nbr INT,
fill_enter_tm STRING,
update_dttm STRING,
edw_batch_id BIGINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/icplus_status_har_ua_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.icplus_status_har_ua_pos_stg(
upc_desc STRING,
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
dspn_fill_nbr SMALLINT,
fill_enter_dt STRING,
fill_sold_dt STRING,
rx_create_dt STRING,
sales_txn_dt STRING,
sales_txn_id STRING,
partial_fill_cd STRING,
update_dttm STRING,
line_item_seq_nbr STRING,
selling_price_dlrs DECIMAL(8,2),
edw_batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/icplus_status_har_ua_pos_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.icplus_status_har_ua_unsold_stg(
str_nbr INT,
fill_enter_dt STRING,
rx_nbr INT,
rx_fill_nbr INT,
drug_id INT,
dspn_ndc STRING,
fill_label_price_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
rx_create_dt STRING,
fill_sold_dt STRING,
fill_del_dt STRING,
pat_id DECIMAL(13,0),
dspn_fill_nbr SMALLINT,
partial_fill_cd STRING,
fill_pay_method_cd STRING,
fill_days_supply SMALLINT,
fill_qty_dspn DECIMAL(8,3),
rx_partial_fill_nbr INT,
fill_enter_tm STRING,
update_dttm STRING,
edw_batch_id BIGINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/icplus_status_har_ua_unsold_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp2_stg(
str_nbr INT,
bin_nbr STRING,
processor_ctrl_nbr STRING,
store_npi_nbr STRING,
general_recipient_nbr STRING,
fill_enter_dt STRING,
rx_nbr INT,
rx_fill_nbr INT,
drug_id INT,
dspn_ndc STRING,
other_payr_coverage_cd DECIMAL(2,0),
plan_group_nbr STRING,
plan_tot_paid_dlrs DECIMAL(8,2),
plan_return_cost_dlrs DECIMAL(8,2),
plan_return_fee_dlrs DECIMAL(8,2),
plan_return_copay_dlrs DECIMAL(8,2),
plan_return_tax_dlrs DECIMAL(8,2),
plan_ar_dlrs DECIMAL(8,2),
plan_submit_fee_dlrs DECIMAL(8,2),
basis_of_reimb_detrm STRING,
fill_label_price_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
third_party_plan_id STRING,
claim_ref_nbr STRING,
del_adjud_cd STRING,
rx_create_dt STRING,
fill_sold_dt STRING,
fill_del_dt STRING,
pat_id DECIMAL(13,0),
plan_type_cd STRING,
contract_name STRING,
plan_name STRING,
dspn_fill_nbr SMALLINT,
partial_fill_cd STRING,
fill_pay_method_cd STRING,
fill_days_supply SMALLINT,
fill_qty_dspn DECIMAL(8,3),
cob_ind STRING,
rx_partial_fill_nbr INT,
fill_enter_tm STRING,
update_dttm STRING,
edw_batch_id BIGINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/icplus_status_update_har_1808_tmp2_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.3.5", "scripts": ["D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "T.20015.1.wrg.icplus_status_update_har_1808_tmp1_stg.sql", "T.8861.1.wrg.icplus_status_har_ua_stg.sql", "T.8866.1.wrg.icplus_status_har_ua_pos_stg.sql", "T.8883.1.wrg.icplus_status_har_ua_unsold_stg.sql", "T.8900.1.wrg.icplus_status_update_har_1808_tmp2_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.3.5", "table_id": "T.20015.1", "table_name": "icplus_status_update_har_1808_tmp1_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp1_stg", "table_legacy_schema": "dae_work.icplus_status_update_har_1808_tmp1", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp1_stg", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.5", "table_id": "T.8861.1", "table_name": "icplus_status_har_ua_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.icplus_status_har_ua_stg", "table_legacy_schema": "dae_work.icplus_status_har_ua", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.icplus_status_har_ua_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.5", "table_id": "T.8866.1", "table_name": "icplus_status_har_ua_pos_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.icplus_status_har_ua_pos_stg", "table_legacy_schema": "dae_work.icplus_status_har_ua_pos", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.icplus_status_har_ua_pos_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.5", "table_id": "T.8883.1", "table_name": "icplus_status_har_ua_unsold_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.icplus_status_har_ua_unsold_stg", "table_legacy_schema": "dae_work.icplus_status_har_ua_unsold", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.icplus_status_har_ua_unsold_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.5", "table_id": "T.8900.1", "table_name": "icplus_status_update_har_1808_tmp2_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp2_stg", "table_legacy_schema": "dae_work.icplus_status_update_har_1808_tmp2", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

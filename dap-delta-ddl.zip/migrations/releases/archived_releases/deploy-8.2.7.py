# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__retail_sales;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.pos_transaction_cost_adj_seq_stg(
sales_txn_id STRING,
sales_txn_dt STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
src_sys_cd STRING,
line_item_seq_nbr INT,
adj_cd STRING,
adj_dlrs DECIMAL(8,2),
loyalty_adj_dlrs DECIMAL(8,2),
cost_type_cd STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/pos_transaction_cost_adj_seq_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.pos_transaction_cost_adj_mrgd_stg(
sales_txn_id STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
src_sys_cd STRING,
line_item_seq_nbr INT,
adj_cd STRING,
adj_dlrs DECIMAL(8,2),
loyalty_adj_dlrs DECIMAL(8,2),
cost_type_cd STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
PARTITIONED BY (
sales_txn_dt STRING)
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/pos_transaction_cost_adj_mrgd_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.pos_transaction_cost_dtl_seq_stg(
sales_txn_id STRING,
sales_txn_dt STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
src_sys_cd STRING,
line_item_seq_nbr INT,
cost_type_cd STRING,
cost_dlrs DECIMAL(8,2),
cost_src_type_cd STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/pos_transaction_cost_dtl_seq_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.pos_transaction_cost_dtl_mrgd_stg(
sales_txn_id STRING,
sales_ord_src_type STRING,
sales_txn_type STRING,
src_sys_cd STRING,
line_item_seq_nbr INT,
cost_type_cd STRING,
cost_dlrs DECIMAL(8,2),
cost_src_type_cd STRING,
edw_create_dttm STRING,
edw_update_dttm STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
PARTITIONED BY (
sales_txn_dt STRING)
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/pos_transaction_cost_dtl_mrgd_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.2.7", "scripts": ["D.50.1.wrg.retail__retail_sales.sql", "T.19982.1.wrg.pos_transaction_cost_adj_seq_stg.sql", "T.19983.1.wrg.pos_transaction_cost_adj_mrgd_stg.sql", "T.19984.1.wrg.pos_transaction_cost_dtl_seq_stg.sql", "T.19985.1.wrg.pos_transaction_cost_dtl_mrgd_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.2.7", "table_id": "T.19982.1", "table_name": "pos_transaction_cost_adj_seq_stg", "table_schema": "staging__retail__retail_sales.pos_transaction_cost_adj_seq_stg", "table_legacy_schema": "acapetldb.pos_transaction_cost_adj_seq", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.pos_transaction_cost_adj_seq_stg", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.7", "table_id": "T.19983.1", "table_name": "pos_transaction_cost_adj_mrgd_stg", "table_schema": "staging__retail__retail_sales.pos_transaction_cost_adj_mrgd_stg", "table_legacy_schema": "acapetldb.pos_transaction_cost_adj_mrgd", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.pos_transaction_cost_adj_mrgd_stg", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.7", "table_id": "T.19984.1", "table_name": "pos_transaction_cost_dtl_seq_stg", "table_schema": "staging__retail__retail_sales.pos_transaction_cost_dtl_seq_stg", "table_legacy_schema": "acapetldb.pos_transaction_cost_dtl_seq", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.pos_transaction_cost_dtl_seq_stg", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.7", "table_id": "T.19985.1", "table_name": "pos_transaction_cost_dtl_mrgd_stg", "table_schema": "staging__retail__retail_sales.pos_transaction_cost_dtl_mrgd_stg", "table_legacy_schema": "acapetldb.pos_transaction_cost_dtl_mrgd", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.pos_transaction_cost_dtl_mrgd_stg", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

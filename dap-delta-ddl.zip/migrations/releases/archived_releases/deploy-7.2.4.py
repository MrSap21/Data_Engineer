# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.paycomprecurring_unchanged_stg(
update_flag STRING,
employee_id STRING,
pay_component STRING,
sequence_number STRING,
start_date STRING,
created_by STRING,
created_on STRING,
currency_code STRING,
end_date STRING,
frequency STRING,
last_modified_by STRING,
last_modified_on STRING,
pay_comp_value DECIMAL(9,2),
previous_pay_comp_value DECIMAL(9,2),
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/paycomprecurring_unchanged_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.2.4", "scripts": ["D.71.1.wrg.hr__compensation_benefits.sql", "T.15125.1.wrg.paycomprecurring_unchanged_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.2.4", "table_id": "T.15125.1", "table_name": "paycomprecurring_unchanged_stg", "table_schema": "staging__hr__compensation_benefits.paycomprecurring_unchanged_stg", "table_legacy_schema": "hr_work.paycomprecurring_unchanged", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.paycomprecurring_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
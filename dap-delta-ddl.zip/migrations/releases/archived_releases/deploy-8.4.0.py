# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='marketing_crt_sa', defaultValue='${marketing_crt_sa}', label='marketing_crt_sa')
dbutils.widgets.text(name='master_data_crt_sa', defaultValue='${master_data_crt_sa}', label='master_data_crt_sa')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_master_data', defaultValue='${STORAGE_ACCT_crt_master_data}', label='STORAGE_ACCT_crt_master_data')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__loyalty;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS master_data__customer;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_consult_adhoc(
rx_nbr DECIMAL(38,0),
str_nbr DECIMAL(38,0),
rx_fill_nbr DECIMAL(38,0) ,
rx_partial_fill_nbr DECIMAL(38,0) ,
consult_adhoc_create_dttm TIMESTAMP,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
fill_enter_tm STRING,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
dspn_fill_nbr SMALLINT ,
adhoc_consult_rslv_rph_intl STRING ,
adhoc_consult_rslv_dttm TIMESTAMP,
adhoc_consult_rslv_cmnts STRING ,
adhoc_consult_rslv_rph_user_id DECIMAL(9,0),
src_create_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
edw_gg_commit_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
relocate_fm_str_nbr DECIMAL(38,0)
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_consult_adhoc'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_sdl(
rx_nbr DECIMAL(38,0),
str_nbr DECIMAL(38,0),
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
rx_fill_nbr DECIMAL(38,0) ,
rx_partial_fill_nbr DECIMAL(38,0) ,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
fill_enter_tm STRING,
sdl_msg_id STRING ,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
pat_id DECIMAL(13,0),
fill_qty_dspn DECIMAL(8,3) ,
fill_days_supply DECIMAL(3,0) ,
fill_nbr_dspn DECIMAL(3,0) ,
drug_name STRING ,
drug_ndc_nbr STRING ,
rx_written_dttm TIMESTAMP,
general_pbr_nbr STRING ,
submit_user_id DECIMAL(9,0),
submit_dttm TIMESTAMP,
plan_id STRING ,
plan_group_nbr STRING ,
general_recipient_nbr STRING ,
prior_auth_cd STRING ,
prior_auth_nbr STRING ,
rx_deny_override_cd STRING ,
elig_override_cd STRING ,
diagnosis_cd STRING ,
pay_cd STRING ,
dl_proc_msg STRING ,
dl_additional_msg STRING ,
dur_conflict_cd STRING ,
dur_intervention_cd STRING ,
dur_outcome_cd STRING ,
other_payr_reject_cd STRING ,
other_cover_cd DECIMAL(2,0) ,
other_payr_cvrg_type STRING ,
plan_other_amt_paid_type STRING ,
plan_other_amt_paid DECIMAL(8,2) ,
other_payr_id STRING ,
other_payr_id_qlfr STRING ,
first_provider_paid_dlrs DECIMAL(8,2) ,
plan_tot_paid_dlrs DECIMAL(8,2) ,
plan_returnd_cost_dlrs DECIMAL(8,2) ,
plan_returnd_fee_dlrs DECIMAL(8,2) ,
plan_incentive_paid_dlrs DECIMAL(8,2) ,
fill_rtl_price_dlrs DECIMAL(8,2) ,
pat_rem_ded_dlrs DECIMAL(8,2) ,
pat_rem_ben_dlrs DECIMAL(8,2) ,
pat_acc_ded_dlrs DECIMAL(8,2) ,
pat_ded_apply_dlrs DECIMAL(8,2) ,
fill_del_adjud_cd STRING ,
fill_adjud_cd STRING ,
claim_ref_nbr STRING ,
plan_returnd_copay_dlrs DECIMAL(8,2) ,
plan_returnd_tax_dlrs DECIMAL(8,2) ,
fill_sold_dlrs DECIMAL(8,2) ,
sales_adj_cd STRING ,
rx_daw_ind STRING ,
claim_reversal_ind STRING ,
edw_batch_id DECIMAL(18,0) ,
relocate_fm_str_nbr DECIMAL(38,0),
src_partition_nbr TINYINT ,
place_of_service_cd DECIMAL(2,0) ,
rx_deny_override_2_cd STRING ,
rx_deny_override_3_cd STRING ,
delay_reason_cd DECIMAL(2,0) ,
return_plan_group_nbr STRING ,
return_third_party_plan_id STRING ,
covered_mbr_network_id STRING ,
prcs_fee_collect_dlrs DECIMAL(8,2) ,
provider_network_collect_dlrs DECIMAL(8,2) ,
brand_drug_collect_dlrs DECIMAL(8,2) ,
npref_form_collect_dlrs DECIMAL(8,2) ,
coverage_gap_collect_dlrs DECIMAL(8,2) ,
plan_fund_asst_dlrs DECIMAL(8,2) ,
third_party_ingrd_cont_dlrs DECIMAL(8,2) ,
third_party_disp_cont_fee_dlrs DECIMAL(8,2) ,
plan_sales_tax_dlrs DECIMAL(8,2) ,
pat_sales_tax_dlrs DECIMAL(8,2) ,
other_payr_recognize_dlrs DECIMAL(8,2) ,
benefit_stg_deduct_dlrs DECIMAL(8,2) ,
benefit_stg_initial_cvrg_dlrs DECIMAL(8,2) ,
benefit_stg_coverage_gap_dlrs DECIMAL(8,2) ,
benefit_stg_catastrophic_dlrs DECIMAL(8,2) ,
plan_return_coinsure_dlrs DECIMAL(8,2) ,
plan_other_amt_paid_2_type STRING ,
plan_other_amt_paid_3_type STRING ,
plan_other_amt_2_paid DECIMAL(8,2) ,
plan_other_amt_3_paid DECIMAL(8,2) ,
phrm_service_type_cd DECIMAL(2,0) ,
brand_npref_form_collect_dlrs DECIMAL(8,2) ,
ingrd_cost_pd_rmb_calc_meth_cd STRING ,
return_copay_dlrs DECIMAL(8,2) ,
plan_incent_submtd_dlrs DECIMAL(8,2) ,
plan_gross_due_dlrs DECIMAL(8,2) ,
benefit_stg_1_amt DECIMAL(8,2),
benefit_stg_1_qlfr_cd STRING ,
benefit_stg_2_amt DECIMAL(8,2),
benefit_stg_2_qlfr_cd STRING ,
benefit_stg_3_amt DECIMAL(8,2),
benefit_stg_3_qlfr_cd STRING ,
benefit_stg_4_amt DECIMAL(8,2),
benefit_stg_4_qlfr_cd STRING ,
coupon_ind STRING ,
coupon_drug_id DECIMAL(38,0),
sdl_type_cd SMALLINT
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_sdl'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_drug_tracking(
str_nbr INT,
rx_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
dspn_fill_nbr SMALLINT,
gtin_nbr DECIMAL(20,0),
lot_nbr STRING,
exp_dt STRING,
bottle_ser_nbr STRING,
scan_dttm STRING,
scan_nbr INT,
fill_enter_dt STRING,
fill_enter_tm STRING,
scan_type STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_drug_tracking'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_drug_tracking_data_migration(
str_nbr INT,
rx_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
dspn_fill_nbr SMALLINT,
gtin_nbr DECIMAL(20,0),
lot_nbr STRING,
exp_dt STRING,
bottle_ser_nbr STRING,
scan_dttm STRING,
scan_nbr INT,
fill_enter_dt STRING,
fill_enter_tm STRING,
scan_type STRING,
edw_batch_id DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_drug_tracking_data_migration'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_consult_adhoc_data_migration(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
consult_adhoc_create_dttm STRING,
fill_enter_dt STRING,
fill_enter_tm STRING,
fill_sold_dt STRING,
rx_create_dt STRING,
dspn_fill_nbr SMALLINT,
adhoc_consult_rslv_rph_intl STRING,
adhoc_consult_rslv_dttm STRING,
adhoc_consult_rslv_cmnts STRING,
adhoc_consult_rslv_rph_user_id DECIMAL(9,0),
src_create_user_id DECIMAL(9,0),
edw_batch_id DECIMAL(18,0),
edw_gg_commit_dttm STRING,
src_partition_nbr tinyint,
relocate_fm_str_nbr INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_consult_adhoc_data_migration'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.prescription_sdl_data_migration(
rx_nbr INT,
str_nbr INT,
rx_create_dt STRING,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_enter_dt STRING,
fill_enter_tm STRING,
sdl_msg_id STRING,
fill_sold_dt STRING,
pat_id DECIMAL(13,0),
fill_qty_dspn DECIMAL(8,3),
fill_days_supply DECIMAL(3,0),
fill_nbr_dspn DECIMAL(3,0),
drug_name STRING,
drug_ndc_nbr STRING,
rx_written_dttm STRING,
general_pbr_nbr STRING,
submit_user_id DECIMAL(9,0),
submit_dttm STRING,
plan_id STRING,
plan_group_nbr STRING,
general_recipient_nbr STRING,
prior_auth_cd STRING,
prior_auth_nbr STRING,
rx_deny_override_cd STRING,
elig_override_cd STRING,
diagnosis_cd STRING,
pay_cd STRING,
dl_proc_msg STRING,
dl_additional_msg STRING,
dur_conflict_cd STRING,
dur_intervention_cd STRING,
dur_outcome_cd STRING,
other_payr_reject_cd STRING,
other_cover_cd DECIMAL(2,0),
other_payr_cvrg_type STRING,
plan_other_amt_paid_type STRING,
plan_other_amt_paid DECIMAL(8,2),
other_payr_id STRING,
other_payr_id_qlfr STRING,
first_provider_paid_dlrs DECIMAL(8,2),
plan_tot_paid_dlrs DECIMAL(8,2),
plan_returnd_cost_dlrs DECIMAL(8,2),
plan_returnd_fee_dlrs DECIMAL(8,2),
plan_incentive_paid_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
pat_rem_ded_dlrs DECIMAL(8,2),
pat_rem_ben_dlrs DECIMAL(8,2),
pat_acc_ded_dlrs DECIMAL(8,2),
pat_ded_apply_dlrs DECIMAL(8,2),
fill_del_adjud_cd STRING,
fill_adjud_cd STRING,
claim_ref_nbr STRING,
plan_returnd_copay_dlrs DECIMAL(8,2),
plan_returnd_tax_dlrs DECIMAL(8,2),
fill_sold_dlrs DECIMAL(8,2),
sales_adj_cd STRING,
rx_daw_ind STRING,
claim_reversal_ind STRING,
edw_batch_id DECIMAL(18,0),
relocate_fm_str_nbr INT,
src_partition_nbr tinyint,
place_of_service_cd DECIMAL(2,0),
rx_deny_override_2_cd STRING,
rx_deny_override_3_cd STRING,
delay_reason_cd DECIMAL(2,0),
return_plan_group_nbr STRING,
return_third_party_plan_id STRING,
covered_mbr_network_id STRING,
prcs_fee_collect_dlrs DECIMAL(8,2),
provider_network_collect_dlrs DECIMAL(8,2),
brand_drug_collect_dlrs DECIMAL(8,2),
npref_form_collect_dlrs DECIMAL(8,2),
coverage_gap_collect_dlrs DECIMAL(8,2),
plan_fund_asst_dlrs DECIMAL(8,2),
third_party_ingrd_cont_dlrs DECIMAL(8,2),
third_party_disp_cont_fee_dlrs DECIMAL(8,2),
plan_sales_tax_dlrs DECIMAL(8,2),
pat_sales_tax_dlrs DECIMAL(8,2),
other_payr_recognize_dlrs DECIMAL(8,2),
benefit_stg_deduct_dlrs DECIMAL(8,2),
benefit_stg_initial_cvrg_dlrs DECIMAL(8,2),
benefit_stg_coverage_gap_dlrs DECIMAL(8,2),
benefit_stg_catastrophic_dlrs DECIMAL(8,2),
plan_return_coinsure_dlrs DECIMAL(8,2),
plan_other_amt_paid_2_type STRING,
plan_other_amt_paid_3_type STRING,
plan_other_amt_2_paid DECIMAL(8,2),
plan_other_amt_3_paid DECIMAL(8,2),
phrm_service_type_cd DECIMAL(2,0),
brand_npref_form_collect_dlrs DECIMAL(8,2),
ingrd_cost_pd_rmb_calc_meth_cd STRING,
return_copay_dlrs DECIMAL(8,2),
plan_incent_submtd_dlrs DECIMAL(8,2),
plan_gross_due_dlrs DECIMAL(8,2),
benefit_stg_1_amt DECIMAL(8,2),
benefit_stg_1_qlfr_cd STRING,
benefit_stg_2_amt DECIMAL(8,2),
benefit_stg_2_qlfr_cd STRING,
benefit_stg_3_amt DECIMAL(8,2),
benefit_stg_3_qlfr_cd STRING,
benefit_stg_4_amt DECIMAL(8,2),
benefit_stg_4_qlfr_cd STRING,
coupon_ind STRING,
coupon_drug_id INT,
sdl_type_cd SMALLINT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/prescription_sdl_data_migration'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_adjustment_code (
loyalty_adj_type_cd STRING COMMENT 'loyalty adjustment type code',
loyalty_adj_cd_desc STRING COMMENT 'loyalty adjustment code description',
sys_adj_ind STRING COMMENT 'system adjustment indicator',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw_update_datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-bussnstv@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_adjustment_code'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_point_activity_detail (
loyalty_vndr_txn_id BIGINT COMMENT 'loyalty vendor transaction id',
loyalty_vndr_txn_detail_id BIGINT COMMENT 'loyalty vendor transaction detail id' ,
loyalty_vndr_txn_hs_id DECIMAL(38,0) COMMENT 'loyalty vendor transaction hs id' ,
sales_txn_id STRING COMMENT 'sales transaction id',
sales_txn_dt DATE COMMENT 'sales transaction date{{"FORMAT":"YYYY/MM/DD" }}',
sales_txn_type STRING COMMENT 'sales transaction type' ,
src_sys_cd STRING COMMENT 'source system code',
line_item_seq_nbr DECIMAL(38,0) COMMENT 'line item sequence DOUBLE',
pnt_txn_type_cd STRING COMMENT 'point transaction type code',
postd_dttm TIMESTAMP COMMENT 'posted datetime',
ad_evt_type STRING COMMENT 'advertisement event type' ,
ad_evt_seq_nbr STRING COMMENT 'advertisement event sequence DOUBLE' ,
ad_evt_vers_type_cd STRING COMMENT 'advertisement event version type code',
ad_evt_vers_seq_nbr STRING COMMENT 'advertisement event version sequence DOUBLE' ,
ad_offer_cd STRING COMMENT 'advertisement offer code' ,
plu_nbr DECIMAL(4,0) COMMENT 'plu DOUBLE' ,
dim_prod_sk BIGINT COMMENT 'dim_product sk',
upc_prod_sk BIGINT COMMENT 'upc product sk' ,
upc_nbr DECIMAL(14,0) COMMENT 'upc DOUBLE',
rx_ind STRING COMMENT 'rx indicator' ,
ehr_service_cd STRING COMMENT 'ehr service code',
pnt_val DECIMAL(38,0) COMMENT 'point value',
pnt_expire_dt DATE COMMENT 'point expiration date{{"FORMAT":"YYYY/MM/DD" }}' ,
redeem_tier_pnt DECIMAL(38,0) COMMENT 'redeem tier point' ,
redeem_tier_dlrs DECIMAL(11,2) COMMENT 'redeem tier dollars' ,
redeem_tndr_dlrs DECIMAL(11,2) COMMENT 'redeem tender dollars' ,
government_funded_cd STRING COMMENT 'government funded code',
ad_tgted_cust_cd STRING COMMENT 'advertisement targeted customer code',
affl_cd STRING COMMENT 'affiliation code',
actv_cd STRING COMMENT 'activity code',
src_devc_cd STRING COMMENT 'source device code',
third_party_prtnr STRING COMMENT 'third party partner',
heats_up_ad_evt_type STRING COMMENT 'heats up advertisement event type' ,
heats_up_ad_evt_seq_nbr STRING COMMENT 'heats up advertisement event sequence DOUBLE' ,
heats_up_ad_evt_vers_type_cd STRING COMMENT 'heats up advertisement event version type code',
heats_up_ad_evt_vers_seq_nbr STRING COMMENT 'heats up advertisement event version sequence DOUBLE' ,
heats_up_ad_offer_cd STRING COMMENT 'heats up advertisement offer code' ,
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_point_activity_detail'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_point_activity_detail_v2 (
loyalty_vndr_txn_id BIGINT COMMENT 'loyalty vendor transaction id',
loyalty_vndr_txn_detail_id BIGINT COMMENT 'loyalty vendor transaction detail id' ,
sales_txn_id STRING COMMENT 'sales transaction id',
sales_txn_dt DATE COMMENT 'sales transaction date{{"FORMAT":"YYYY/MM/DD" }}',
sales_txn_type STRING COMMENT 'sales transaction type' ,
src_sys_cd STRING COMMENT 'source system code',
pnt_dlrs DECIMAL(15,2) COMMENT 'point dollars' ,
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_point_activity_detail_v2'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS master_data__customer.dim_customer_xref (
dim_cust_sk BIGINT COMMENT 'dim customer sk',
cust_sk BIGINT COMMENT 'customer sk',
cust_chng_sk BIGINT COMMENT 'customer change sk',
eid_dim_cust_sk BIGINT COMMENT 'eid dim customer sk',
mid_dim_cust_sk BIGINT COMMENT 'mid dim customer sk',
eid_cust_cur_sk BIGINT COMMENT 'eid customer current sk',
mid_cust_cur_sk BIGINT COMMENT 'mid customer current sk',
cust_permnt_addr_chng_sk BIGINT COMMENT 'customer permanent address change sk',
cust_scndry_addr_chng_sk BIGINT COMMENT 'customer secondary address change sk',
cust_work_addr_chng_sk BIGINT COMMENT 'customer work address change sk',
cust_bill_addr_chng_sk BIGINT COMMENT 'customer billing address change sk',
cust_home_cntc_chng_sk BIGINT COMMENT 'customer home contact change sk',
cust_work_cntc_chng_sk BIGINT COMMENT 'customer work contact change sk',
cust_cell_cntc_chng_sk BIGINT COMMENT 'customer cell contact change sk',
cust_mail_cntc_chng_sk BIGINT COMMENT 'customerr mail contact change sk',
cust_old_mail_cntc_chng_sk BIGINT COMMENT 'customer old mail contact change sk',
cust_primary_cntc_chng_sk BIGINT COMMENT 'customer primary contact change sk',
cust_scndry_cntc_chng_sk BIGINT COMMENT 'customer secondary contact change sk',
cust_tertiary_cntc_chng_sk BIGINT COMMENT 'customer tertiary contact change sk',
cust_src_id STRING COMMENT 'customer source identifier',
src_sys_cd STRING COMMENT 'customer source code',
composite_type_cd STRING COMMENT 'composite type code',
msg_type_cd STRING COMMENT 'message type code',
eid STRING COMMENT 'eid',
eid_cur STRING COMMENT 'eid_current',
mid STRING COMMENT 'mid',
mid_cur STRING COMMENT 'mid current',
data_display_restrict_cd STRING COMMENT 'data display restriction code',
edw_rec_begin_dt DATE COMMENT 'edw record begin date{{"FORMAT":"YYYY/MM/DD" }}',
edw_rec_end_dt DATE COMMENT 'edw record end date{{"FORMAT":"YYYY/MM/DD" }}',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING  DELTA
LOCATION
'abfss://customer-pii@{getArgument('master_data_crt_sa')}.dfs.core.windows.net/dim_customer_xref'
PARTITIONED BY (
edw_rec_end_dt)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__loyalty.loyalty_point_activity(
loyalty_vndr_txn_id BIGINT COMMENT 'loyalty vendor transaction id',
loyalty_mbr_id STRING COMMENT 'loyalty member identifier',
sales_txn_id STRING COMMENT 'sales transaction id',
sales_txn_dt DATE COMMENT 'sales transaction date{{"FORMAT":"YY/MM/DD" }}',
sales_txn_type STRING COMMENT 'sales transaction type',
src_sys_cd STRING COMMENT 'source system code',
dim_loc_str_sk BIGINT COMMENT 'dim location store sk',
store_nbr DECIMAL(38,0) COMMENT 'store DOUBLE',
loyalty_dim_cust_sk BIGINT COMMENT 'loyalty dim_cust_sk',
loyalty_cust_sk BIGINT COMMENT 'loyalty cust_sk',
loyalty_eid_dim_cust_sk BIGINT COMMENT 'loyalty eid_dim_cust_sk',
loyalty_eid_cust_sk BIGINT COMMENT 'loyalty eid_cust_sk',
loyalty_mid_dim_cust_sk BIGINT COMMENT 'loyalty mid_dim_cust_sk',
loyalty_mid_cust_sk BIGINT COMMENT 'loyalty mid_cust_sk',
pnt_txn_type_cd STRING COMMENT 'point transaction type code',
loyalty_adj_type_cd STRING COMMENT 'loyalty adjustment type code',
orig_sales_txn_id STRING COMMENT 'original sales transaction id',
orig_sales_txn_dt DATE COMMENT 'original sales transaction date{{"FORMAT":"YY/MM/DD" }}',
orig_sales_txn_type STRING COMMENT 'original sales transaction type',
orig_ecom_ord_id STRING COMMENT 'original ecom order DOUBLE',
orig_rfn_val STRING COMMENT 'original rfn value',
ecom_ord_id STRING COMMENT 'ecom order DOUBLE',
rfn_val STRING COMMENT 'rfn value',
missing_txn_ind STRING COMMENT 'missing transaction indicator',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://loyalty-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/loyalty_point_activity'""")
# COMMAND ----------
migration_data=[{"release": "8.4.0", "scripts": ["D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "D.6.1.crt.pharmacy_healthcare__patient_services.sql", "D.15.1.crt.marketing__loyalty.sql", "D.7.1.crt.master_data__customer.sql", "T.1887.1.crt.prescription_drug_tracking.sql", "T.20012.1.wrg.prescription_drug_tracking_data_migration.sql", "T.20016.1.wrg.prescription_consult_adhoc_data_migration.sql", "T.20017.1.wrg.prescription_sdl_data_migration.sql", "T.1713.1.crt.prescription_sdl.sql", "T.1642.1.crt.prescription_consult_adhoc.sql", "T.20025.1.crt.loyalty_point_activity_detail.sql", "T.20025.1.crt.loyalty_point_activity_detail_v2.sql", "T.20025.1.crt.loyalty_adjustment_code.sql", "T.276.1.crt.loyalty_point_activity.sql", "T.20027.1.crt.dim_customer_xref.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.4.0", "table_id": "T.1887.1", "table_name": "prescription_drug_tracking", "table_schema": "pharmacy_healthcare__patient_services.prescription_drug_tracking", "table_legacy_schema": "dae_cooked.prescription_drug_tracking", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_drug_tracking", "table_partition": "\n  fill_enter_mnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.20012.1", "table_name": "prescription_drug_tracking_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_drug_tracking_data_migration", "table_legacy_schema": "dae_cooked.tl_prescription_drug_tracking", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_drug_tracking_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.20016.1", "table_name": "prescription_consult_adhoc_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_consult_adhoc_data_migration", "table_legacy_schema": "dae_cooked.tl_prescription_consult_adhoc", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_consult_adhoc_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.20017.1", "table_name": "prescription_sdl_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.prescription_sdl_data_migration", "table_legacy_schema": "dae_cooked.tl_prescription_sdl", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.prescription_sdl_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.1713.1", "table_name": "prescription_sdl", "table_schema": "pharmacy_healthcare__patient_services.prescription_sdl", "table_legacy_schema": "dae_cooked.prescription_sdl", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_sdl", "table_partition": "\n  fill_sold_yr STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.1642.1", "table_name": "prescription_consult_adhoc", "table_schema": "pharmacy_healthcare__patient_services.prescription_consult_adhoc", "table_legacy_schema": "dae_cooked.prescription_consult_adhoc", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_consult_adhoc", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.20025.1", "table_name": "loyalty_point_activity_detail", "table_schema": "marketing__loyalty.loyalty_point_activity_detail", "table_legacy_schema": "SNOWFLAKE.loyalty_point_activity_detail", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_point_activity_detail", "table_partition": "", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.20025.1", "table_name": "loyalty_point_activity_detail_v2", "table_schema": "marketing__loyalty.loyalty_point_activity_detail_v2", "table_legacy_schema": "SNOWFLAKE.loyalty_point_activity_detail_v2", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_point_activity_detail_v2", "table_partition": "", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.20025.1", "table_name": "loyalty_adjustment_code", "table_schema": "marketing__loyalty.loyalty_adjustment_code", "table_legacy_schema": "SNOWFLAKE.loyalty_adjustment_code", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_adjustment_code", "table_partition": "", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.276.1", "table_name": "loyalty_point_activity", "table_schema": "marketing__loyalty.loyalty_point_activity", "table_legacy_schema": "snowflake.loyalty_point_activity", "table_domain": "marketing", "table_subdomain": "loyalty", "table_location": "marketing__loyalty.loyalty_point_activity", "table_partition": "\n  postd_dt STRING", "table_db": "marketing__loyalty", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.0", "table_id": "T.20027.1", "table_name": "dim_customer_xref", "table_schema": "master_data__customer.dim_customer_xref", "table_legacy_schema": "dae_cooked.dim_customer_xref", "table_domain": "master_data", "table_subdomain": "customer", "table_location": "master_data__customer.dim_customer_xref", "table_partition": "", "table_db": "master_data__customer", "table_zone": "curated", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

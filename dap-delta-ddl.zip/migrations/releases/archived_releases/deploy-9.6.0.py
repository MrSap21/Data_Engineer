# Databricks notebook source
dbutils.widgets.text(name='mna_buyout_crt_sa', defaultValue='${mna_buyout_crt_sa}', label='mna_buyout_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_mna_buyout', defaultValue='${STORAGE_ACCT_crt_mna_buyout}', label='STORAGE_ACCT_crt_mna_buyout')
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_fin_monthly_wac_cost_by_gpi;
VACUUM mna_buyout__pharmacy_healthcare.rad_fin_monthly_wac_cost_by_gpi RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_fin_monthly_wac_cost_by_gpi;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_fin_monthly_wac_cost_by_gpi", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_hc_ar_tpcas_adjust;
VACUUM mna_buyout__pharmacy_healthcare.rad_hc_ar_tpcas_adjust RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_hc_ar_tpcas_adjust;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_hc_ar_tpcas_adjust", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_hc_ar_tpcre_cshrcnle;
VACUUM mna_buyout__pharmacy_healthcare.rad_hc_ar_tpcre_cshrcnle RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_hc_ar_tpcre_cshrcnle;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_hc_ar_tpcre_cshrcnle", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_hc_ar_tpcsh_cashrec;
VACUUM mna_buyout__pharmacy_healthcare.rad_hc_ar_tpcsh_cashrec RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_hc_ar_tpcsh_cashrec;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_hc_ar_tpcsh_cashrec", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_hc_ar_tprac_archive;
VACUUM mna_buyout__supply_chain.rad_hc_ar_tprac_archive RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_hc_ar_tprac_archive;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_hc_ar_tprac_archive", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_hc_ar_tprat_archive;
VACUUM mna_buyout__pharmacy_healthcare.rad_hc_ar_tprat_archive RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_hc_ar_tprat_archive;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_hc_ar_tprat_archive", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_patient_link_ext;
VACUUM mna_buyout__pharmacy_healthcare.rad_patient_link_ext RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_patient_link_ext;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_patient_link_ext", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_relocation_tracker_short;
VACUUM mna_buyout__pharmacy_healthcare.rad_relocation_tracker_short RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_relocation_tracker_short;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_relocation_tracker_short", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_daily;
VACUUM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_daily RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_daily;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_rite_report_metrics_daily", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_daily_fix;
VACUUM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_daily_fix RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_daily_fix;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_rite_report_metrics_daily_fix", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_daily_orc11;
VACUUM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_daily_orc11 RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_daily_orc11;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_rite_report_metrics_daily_orc11", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_monthly;
VACUUM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_monthly RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_monthly;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_rite_report_metrics_monthly", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_monthly_txt1;
VACUUM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_monthly_txt1 RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_monthly_txt1;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_rite_report_metrics_monthly_txt1", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_weekly;
VACUUM mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_weekly RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_rite_report_metrics_weekly;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_rite_report_metrics_weekly", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_rx_daily_wac_cost_by_ndc;
VACUUM mna_buyout__pharmacy_healthcare.rad_rx_daily_wac_cost_by_ndc RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_rx_daily_wac_cost_by_ndc;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_rx_daily_wac_cost_by_ndc", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__pharmacy_healthcare.rad_rx_store_inventory;
VACUUM mna_buyout__pharmacy_healthcare.rad_rx_store_inventory RETAIN 0 HOURS;
DROP TABLE mna_buyout__pharmacy_healthcare.rad_rx_store_inventory;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://pharmacy-healthcare-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_rx_store_inventory", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_adr_store_data_bo_hist;
VACUUM mna_buyout__supply_chain.rad_scm_adr_store_data_bo_hist RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_adr_store_data_bo_hist;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_adr_store_data_bo_hist", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_adwk_msp_fcst_waste;
VACUUM mna_buyout__supply_chain.rad_scm_adwk_msp_fcst_waste RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_adwk_msp_fcst_waste;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_adwk_msp_fcst_waste", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_adwk_msp_fcst_waste_new;
VACUUM mna_buyout__supply_chain.rad_scm_adwk_msp_fcst_waste_new RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_adwk_msp_fcst_waste_new;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_adwk_msp_fcst_waste_new", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_all_waves_conf_loc_pln;
VACUUM mna_buyout__supply_chain.rad_scm_all_waves_conf_loc_pln RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_all_waves_conf_loc_pln;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_all_waves_conf_loc_pln", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_basket_by_division;
VACUUM mna_buyout__supply_chain.rad_scm_basket_by_division RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_basket_by_division;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_basket_by_division", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_bu_managed_start_dates;
VACUUM mna_buyout__supply_chain.rad_scm_bu_managed_start_dates RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_bu_managed_start_dates;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_bu_managed_start_dates", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cat_upc_item_desc;
VACUUM mna_buyout__supply_chain.rad_scm_cat_upc_item_desc RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cat_upc_item_desc;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cat_upc_item_desc", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cat_upc_item_desc_date;
VACUUM mna_buyout__supply_chain.rad_scm_cat_upc_item_desc_date RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cat_upc_item_desc_date;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cat_upc_item_desc_date", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cat_upc_item_desc_date_staging;
VACUUM mna_buyout__supply_chain.rad_scm_cat_upc_item_desc_date_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cat_upc_item_desc_date_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cat_upc_item_desc_date_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cat_upc_item_desc_month;
VACUUM mna_buyout__supply_chain.rad_scm_cat_upc_item_desc_month RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cat_upc_item_desc_month;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cat_upc_item_desc_month", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_category_wag_div_bu_staging;
VACUUM mna_buyout__supply_chain.rad_scm_category_wag_div_bu_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_category_wag_div_bu_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_category_wag_div_bu_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_category_wag_div_bu_stg;
VACUUM mna_buyout__supply_chain.rad_scm_category_wag_div_bu_stg RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_category_wag_div_bu_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_category_wag_div_bu_stg", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_conform_transfer_items;
VACUUM mna_buyout__supply_chain.rad_scm_conform_transfer_items RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_conform_transfer_items;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_conform_transfer_items", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_conform_transfer_items_staging;
VACUUM mna_buyout__supply_chain.rad_scm_conform_transfer_items_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_conform_transfer_items_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_conform_transfer_items_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_conformed_store_cat_upc_item_desc;
VACUUM mna_buyout__supply_chain.rad_scm_conformed_store_cat_upc_item_desc RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_conformed_store_cat_upc_item_desc;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_conformed_store_cat_upc_item_desc", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_conforming_item;
VACUUM mna_buyout__supply_chain.rad_scm_conforming_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_conforming_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_conforming_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_conforming_items;
VACUUM mna_buyout__supply_chain.rad_scm_conforming_items RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_conforming_items;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_conforming_items", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_conver_wag_plano_for_rad_str_item;
VACUUM mna_buyout__supply_chain.rad_scm_conver_wag_plano_for_rad_str_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_conver_wag_plano_for_rad_str_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_conver_wag_plano_for_rad_str_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_conversion_stores;
VACUUM mna_buyout__supply_chain.rad_scm_conversion_stores RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_conversion_stores;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_conversion_stores", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_conversion_stores_update;
VACUUM mna_buyout__supply_chain.rad_scm_conversion_stores_update RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_conversion_stores_update;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_conversion_stores_update", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_converted_fcst_ssis_sls_bias_str_pln;
VACUUM mna_buyout__supply_chain.rad_scm_converted_fcst_ssis_sls_bias_str_pln RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_converted_fcst_ssis_sls_bias_str_pln;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_converted_fcst_ssis_sls_bias_str_pln", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cooper_store;
VACUUM mna_buyout__supply_chain.rad_scm_cooper_store RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cooper_store;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cooper_store", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cost_consolidated_rgis_inv_sales;
VACUUM mna_buyout__supply_chain.rad_scm_cost_consolidated_rgis_inv_sales RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cost_consolidated_rgis_inv_sales;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cost_consolidated_rgis_inv_sales", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cost_inventory_staging;
VACUUM mna_buyout__supply_chain.rad_scm_cost_inventory_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cost_inventory_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cost_inventory_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cso_sourcing_unique_source_items;
VACUUM mna_buyout__supply_chain.rad_scm_cso_sourcing_unique_source_items RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cso_sourcing_unique_source_items;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_cso_sourcing_unique_source_items", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_day_store_cat;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_day_store_cat RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_day_store_cat;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_inv_day_store_cat", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_sales_wk_store_cat_new;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_sales_wk_store_cat_new RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_sales_wk_store_cat_new;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_inv_sales_wk_store_cat_new", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_sales_wk_store_cat_new_part;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_sales_wk_store_cat_new_part RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_sales_wk_store_cat_new_part;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_inv_sales_wk_store_cat_new_part", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_inv_wk_store_cat", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_archive;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_archive RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_archive;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_inv_wk_store_cat_archive", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_finance;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_finance RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_finance;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_inv_wk_store_cat_finance", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_new;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_new RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_new;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_inv_wk_store_cat_new", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_new_part;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_new_part RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_inv_wk_store_cat_new_part;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_inv_wk_store_cat_new_part", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_day_store_cat;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_day_store_cat RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_day_store_cat;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_sales_day_store_cat", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_wk_store_cat;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_wk_store_cat RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_wk_store_cat;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_sales_wk_store_cat", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_wk_store_cat_archive;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_wk_store_cat_archive RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_wk_store_cat_archive;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_sales_wk_store_cat_archive", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_wk_store_cat_new;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_wk_store_cat_new RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_conver_conform_sales_wk_store_cat_new;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_conver_conform_sales_wk_store_cat_new", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_day_str_cat;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_day_str_cat RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_day_str_cat;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_inv_sales_conform_plano_day_str_cat", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_day_str_cat_archive;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_day_str_cat_archive RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_day_str_cat_archive;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_inv_sales_conform_plano_day_str_cat_archive", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_wk_str_cat;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_wk_str_cat RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_wk_str_cat;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_inv_sales_conform_plano_wk_str_cat", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_wk_str_cat_archive;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_wk_str_cat_archive RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_inv_sales_conform_plano_wk_str_cat_archive;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_inv_sales_conform_plano_wk_str_cat_archive", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_archive;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_archive RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_archive;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_archive", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_new;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_new RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_new;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_new", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_old_parts;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_old_parts RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_old_parts;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item_old_parts", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_sales_conform_catalog_conv_cost_day_str_item;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_sales_conform_catalog_conv_cost_day_str_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_sales_conform_catalog_conv_cost_day_str_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_sales_conform_catalog_conv_cost_day_str_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_sales_conform_catalog_conv_cost_day_str_item_old_parts;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_sales_conform_catalog_conv_cost_day_str_item_old_parts RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_sales_conform_catalog_conv_cost_day_str_item_old_parts;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_sales_conform_catalog_conv_cost_day_str_item_old_parts", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_str_item_inv_sales_output;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_str_item_inv_sales_output RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_str_item_inv_sales_output;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_str_item_inv_sales_output", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_cutover_str_item_inv_sales_output_old_table;
VACUUM mna_buyout__supply_chain.rad_scm_cutover_str_item_inv_sales_output_old_table RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_cutover_str_item_inv_sales_output_old_table;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_str_item_inv_sales_output_old_table", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_dashboard_new_promo_items;
VACUUM mna_buyout__supply_chain.rad_scm_dashboard_new_promo_items RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_dashboard_new_promo_items;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_dashboard_new_promo_items", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_df_wh_prices;
VACUUM mna_buyout__supply_chain.rad_scm_df_wh_prices RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_df_wh_prices;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_df_wh_prices", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_df_wh_prices_staging;
VACUUM mna_buyout__supply_chain.rad_scm_df_wh_prices_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_df_wh_prices_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_df_wh_prices_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_dim_period;
VACUUM mna_buyout__supply_chain.rad_scm_dim_period RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_dim_period;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_dim_period", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_dim_prod_pln_nz_dly;
VACUUM mna_buyout__supply_chain.rad_scm_dim_prod_pln_nz_dly RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_dim_prod_pln_nz_dly;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_dim_prod_pln_nz_dly", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_distinct_dailyparameters;
VACUUM mna_buyout__supply_chain.rad_scm_distinct_dailyparameters RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_distinct_dailyparameters;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_distinct_dailyparameters", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_fcst_promo_items;
VACUUM mna_buyout__supply_chain.rad_scm_fcst_promo_items RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_fcst_promo_items;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_fcst_promo_items", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_fcst_ssis_sls_bias_str_pln;
VACUUM mna_buyout__supply_chain.rad_scm_fcst_ssis_sls_bias_str_pln RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_fcst_ssis_sls_bias_str_pln;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_fcst_ssis_sls_bias_str_pln", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_fcst_ssis_sls_bias_str_pln_4weeks;
VACUUM mna_buyout__supply_chain.rad_scm_fcst_ssis_sls_bias_str_pln_4weeks RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_fcst_ssis_sls_bias_str_pln_4weeks;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_fcst_ssis_sls_bias_str_pln_4weeks", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_fct_sls_str_upc_dly;
VACUUM mna_buyout__supply_chain.rad_scm_fct_sls_str_upc_dly RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_fct_sls_str_upc_dly;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_fct_sls_str_upc_dly", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_fe_list_dc_cost;
VACUUM mna_buyout__supply_chain.rad_scm_fe_list_dc_cost RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_fe_list_dc_cost;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_fe_list_dc_cost", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_fe_list_staging;
VACUUM mna_buyout__supply_chain.rad_scm_fe_list_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_fe_list_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_fe_list_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_fo_stores;
VACUUM mna_buyout__supply_chain.rad_scm_fo_stores RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_fo_stores;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_fo_stores", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_grand_opening_store_list;
VACUUM mna_buyout__supply_chain.rad_scm_grand_opening_store_list RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_grand_opening_store_list;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_grand_opening_store_list", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_day_store_item;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_day_store_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_day_store_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_day_store_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_month_store_category;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_month_store_category RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_month_store_category;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_month_store_category", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_rep_conform_conv_cost_day_store_item_catalog;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_rep_conform_conv_cost_day_store_item_catalog RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_rep_conform_conv_cost_day_store_item_catalog;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_rep_conform_conv_cost_day_store_item_catalog", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_report_conforming_cost_day_store_item;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_report_conforming_cost_day_store_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_report_conforming_cost_day_store_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_report_conforming_cost_day_store_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_report_cost_day_store_item;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_report_cost_day_store_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_report_cost_day_store_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_report_cost_day_store_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_report_day_store_item;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_report_day_store_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_report_day_store_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_report_day_store_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_report_wow_conversion_partition;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_report_wow_conversion_partition RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_report_wow_conversion_partition;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_report_wow_conversion_partition", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_waterfall_post_conv;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_waterfall_post_conv RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_waterfall_post_conv;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_waterfall_post_conv", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_waterfall_post_conv_30_days;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_waterfall_post_conv_30_days RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_waterfall_post_conv_30_days;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_waterfall_post_conv_30_days", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_inventory_week_store_category;
VACUUM mna_buyout__supply_chain.rad_scm_inventory_week_store_category RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_inventory_week_store_category;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_inventory_week_store_category", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_invoice_day_store_item;
VACUUM mna_buyout__supply_chain.rad_scm_invoice_day_store_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_invoice_day_store_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_invoice_day_store_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_invoice_month_store_category;
VACUUM mna_buyout__supply_chain.rad_scm_invoice_month_store_category RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_invoice_month_store_category;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_invoice_month_store_category", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_invoice_report_conforming_cost_day_store_item;
VACUUM mna_buyout__supply_chain.rad_scm_invoice_report_conforming_cost_day_store_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_invoice_report_conforming_cost_day_store_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_invoice_report_conforming_cost_day_store_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_invoice_report_conforming_shipment_day_store;
VACUUM mna_buyout__supply_chain.rad_scm_invoice_report_conforming_shipment_day_store RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_invoice_report_conforming_shipment_day_store;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_invoice_report_conforming_shipment_day_store", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_invoice_week_store_category;
VACUUM mna_buyout__supply_chain.rad_scm_invoice_week_store_category RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_invoice_week_store_category;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_invoice_week_store_category", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_it002p;
VACUUM mna_buyout__supply_chain.rad_scm_it002p RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_it002p;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_it002p", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_jai_report_inv_sales_day_fo_store;
VACUUM mna_buyout__supply_chain.rad_scm_jai_report_inv_sales_day_fo_store RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_jai_report_inv_sales_day_fo_store;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_jai_report_inv_sales_day_fo_store", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_jai_report_inv_sales_day_store;
VACUUM mna_buyout__supply_chain.rad_scm_jai_report_inv_sales_day_store RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_jai_report_inv_sales_day_store;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_jai_report_inv_sales_day_store", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_liquidation_dates;
VACUUM mna_buyout__supply_chain.rad_scm_liquidation_dates RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_liquidation_dates;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_liquidation_dates", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_liquidation_dates_staging;
VACUUM mna_buyout__supply_chain.rad_scm_liquidation_dates_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_liquidation_dates_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_liquidation_dates_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_liquidation_store_date;
VACUUM mna_buyout__supply_chain.rad_scm_liquidation_store_date RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_liquidation_store_date;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_liquidation_store_date", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_liquidation_store_date_all;
VACUUM mna_buyout__supply_chain.rad_scm_liquidation_store_date_all RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_liquidation_store_date_all;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_liquidation_store_date_all", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_liquidation_store_date_staging;
VACUUM mna_buyout__supply_chain.rad_scm_liquidation_store_date_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_liquidation_store_date_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_liquidation_store_date_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_liquidation_stores_staging;
VACUUM mna_buyout__supply_chain.rad_scm_liquidation_stores_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_liquidation_stores_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_liquidation_stores_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_markdown_sku_wave_staging;
VACUUM mna_buyout__supply_chain.rad_scm_markdown_sku_wave_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_markdown_sku_wave_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_markdown_sku_wave_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_master_conver_str_plano;
VACUUM mna_buyout__supply_chain.rad_scm_master_conver_str_plano RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_master_conver_str_plano;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_master_conver_str_plano", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_master_conver_str_plano_staging;
VACUUM mna_buyout__supply_chain.rad_scm_master_conver_str_plano_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_master_conver_str_plano_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_master_conver_str_plano_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_misc_simplified_wag_catalog_staging;
VACUUM mna_buyout__supply_chain.rad_scm_misc_simplified_wag_catalog_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_misc_simplified_wag_catalog_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_misc_simplified_wag_catalog_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_on_time_wag_metrics;
VACUUM mna_buyout__supply_chain.rad_scm_on_time_wag_metrics RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_on_time_wag_metrics;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_on_time_wag_metrics", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_pln_prod_str_dsd_mcl;
VACUUM mna_buyout__supply_chain.rad_scm_pln_prod_str_dsd_mcl RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_pln_prod_str_dsd_mcl;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_pln_prod_str_dsd_mcl", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_pln_prod_str_dsd_mcl_source;
VACUUM mna_buyout__supply_chain.rad_scm_pln_prod_str_dsd_mcl_source RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_pln_prod_str_dsd_mcl_source;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_pln_prod_str_dsd_mcl_source", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_pln_prod_str_dsd_mcl_test;
VACUUM mna_buyout__supply_chain.rad_scm_pln_prod_str_dsd_mcl_test RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_pln_prod_str_dsd_mcl_test;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_pln_prod_str_dsd_mcl_test", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_recship_raw_30_days;
VACUUM mna_buyout__supply_chain.rad_scm_recship_raw_30_days RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_recship_raw_30_days;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_recship_raw_30_days", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_report_by_dept;
VACUUM mna_buyout__supply_chain.rad_scm_report_by_dept RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_report_by_dept;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_report_by_dept", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_report_inv_store_cat;
VACUUM mna_buyout__supply_chain.rad_scm_report_inv_store_cat RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_report_inv_store_cat;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_report_inv_store_cat", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_report_inventory_sales_day_store;
VACUUM mna_buyout__supply_chain.rad_scm_report_inventory_sales_day_store RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_report_inventory_sales_day_store;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_report_inventory_sales_day_store", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_sales_day_store_item;
VACUUM mna_buyout__supply_chain.rad_scm_sales_day_store_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_sales_day_store_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_sales_day_store_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_sales_day_store_item_hist;
VACUUM mna_buyout__supply_chain.rad_scm_sales_day_store_item_hist RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_sales_day_store_item_hist;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_sales_day_store_item_hist", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_sales_month_store_category;
VACUUM mna_buyout__supply_chain.rad_scm_sales_month_store_category RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_sales_month_store_category;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_sales_month_store_category", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_sales_month_store_category_hist;
VACUUM mna_buyout__supply_chain.rad_scm_sales_month_store_category_hist RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_sales_month_store_category_hist;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_sales_month_store_category_hist", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_sales_report_day_store_item_mm_current;
VACUUM mna_buyout__supply_chain.rad_scm_sales_report_day_store_item_mm_current RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_sales_report_day_store_item_mm_current;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_sales_report_day_store_item_mm_current", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_sales_report_day_store_item_mm_hist;
VACUUM mna_buyout__supply_chain.rad_scm_sales_report_day_store_item_mm_hist RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_sales_report_day_store_item_mm_hist;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_sales_report_day_store_item_mm_hist", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_sales_week_store_category;
VACUUM mna_buyout__supply_chain.rad_scm_sales_week_store_category RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_sales_week_store_category;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_sales_week_store_category", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_sales_week_store_category_hist;
VACUUM mna_buyout__supply_chain.rad_scm_sales_week_store_category_hist RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_sales_week_store_category_hist;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_sales_week_store_category_hist", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssdt_hist_ontime_metrics;
VACUUM mna_buyout__supply_chain.rad_scm_ssdt_hist_ontime_metrics RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssdt_hist_ontime_metrics;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssdt_hist_ontime_metrics", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis;
VACUUM mna_buyout__supply_chain.rad_scm_ssis RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_dashboard_combine;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_dashboard_combine RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_dashboard_combine;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_dashboard_combine", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_2019_0924;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_2019_0924 RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_2019_0924;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_dashboard_new_2019_0924", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_30_days_04012020;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_30_days_04012020 RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_30_days_04012020;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_dashboard_new_30_days_04012020", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_30_days_temp;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_30_days_temp RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_30_days_temp;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_dashboard_new_30_days_temp", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_past_data;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_past_data RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_past_data;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_dashboard_new_past_data", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_source;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_source RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_source;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_dashboard_new_source", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_temp_table_45_days;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_temp_table_45_days RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_dashboard_new_temp_table_45_days;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_dashboard_new_temp_table_45_days", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_dashboard_sf;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_dashboard_sf RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_dashboard_sf;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_ssis_dashboard_sf", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_staging;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_modified_test_date;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_modified_test_date RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_modified_test_date;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_waves_breakdown_dashboard_modified_test_date", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_test;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_test RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_test;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_waves_breakdown_dashboard_test", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_test_date;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_test_date RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_test_date;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_waves_breakdown_dashboard_test_date", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_test_wave;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_test_wave RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_dashboard_test_wave;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_waves_breakdown_dashboard_test_wave", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_test;
VACUUM mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_test RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_ssis_waves_breakdown_test;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_ssis_waves_breakdown_test", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_staging_conver_str_item_inventory;
VACUUM mna_buyout__supply_chain.rad_scm_staging_conver_str_item_inventory RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_staging_conver_str_item_inventory;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_staging_conver_str_item_inventory", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_staging_conver_str_item_invoice;
VACUUM mna_buyout__supply_chain.rad_scm_staging_conver_str_item_invoice RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_staging_conver_str_item_invoice;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_staging_conver_str_item_invoice", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_staging_conver_str_item_sales;
VACUUM mna_buyout__supply_chain.rad_scm_staging_conver_str_item_sales RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_staging_conver_str_item_sales;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_staging_conver_str_item_sales", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_staging_conver_str_pln_fcst;
VACUUM mna_buyout__supply_chain.rad_scm_staging_conver_str_pln_fcst RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_staging_conver_str_pln_fcst;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_staging_conver_str_pln_fcst", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_staging_cost_inventory;
VACUUM mna_buyout__supply_chain.rad_scm_staging_cost_inventory RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_staging_cost_inventory;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_staging_cost_inventory", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_staging_store_rad_to_wag;
VACUUM mna_buyout__supply_chain.rad_scm_staging_store_rad_to_wag RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_staging_store_rad_to_wag;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_staging_store_rad_to_wag", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_store_close_conformed_upc_cost_qty;
VACUUM mna_buyout__supply_chain.rad_scm_store_close_conformed_upc_cost_qty RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_store_close_conformed_upc_cost_qty;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_store_close_conformed_upc_cost_qty", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_store_close_upc_cost_qty;
VACUUM mna_buyout__supply_chain.rad_scm_store_close_upc_cost_qty RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_store_close_upc_cost_qty;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_store_close_upc_cost_qty", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_store_inventory_preconv;
VACUUM mna_buyout__supply_chain.rad_scm_store_inventory_preconv RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_store_inventory_preconv;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_store_inventory_preconv", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_store_rad_to_wag;
VACUUM mna_buyout__supply_chain.rad_scm_store_rad_to_wag RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_store_rad_to_wag;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_store_rad_to_wag", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_store_rad_to_wag_staging;
VACUUM mna_buyout__supply_chain.rad_scm_store_rad_to_wag_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_store_rad_to_wag_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_store_rad_to_wag_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_store_to_rad_zone;
VACUUM mna_buyout__supply_chain.rad_scm_store_to_rad_zone RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_store_to_rad_zone;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_store_to_rad_zone", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_stores_with_cutover_dates;
VACUUM mna_buyout__supply_chain.rad_scm_stores_with_cutover_dates RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_stores_with_cutover_dates;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_stores_with_cutover_dates", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_stores_with_cutover_dates_staging;
VACUUM mna_buyout__supply_chain.rad_scm_stores_with_cutover_dates_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_stores_with_cutover_dates_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_stores_with_cutover_dates_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_tables_refresh_tracker;
VACUUM mna_buyout__supply_chain.rad_scm_tables_refresh_tracker RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_tables_refresh_tracker;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_tables_refresh_tracker", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_book3_output;
VACUUM mna_buyout__supply_chain.rad_scm_temp_book3_output RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_book3_output;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_book3_output", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_book3_staging;
VACUUM mna_buyout__supply_chain.rad_scm_temp_book3_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_book3_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_book3_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_cat_upc_item;
VACUUM mna_buyout__supply_chain.rad_scm_temp_cat_upc_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_cat_upc_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_cat_upc_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_cat_upc_item_bu;
VACUUM mna_buyout__supply_chain.rad_scm_temp_cat_upc_item_bu RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_cat_upc_item_bu;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_cat_upc_item_bu", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_conversion_stores;
VACUUM mna_buyout__supply_chain.rad_scm_temp_conversion_stores RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_conversion_stores;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_conversion_stores", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_daily_report_conform_item;
VACUUM mna_buyout__supply_chain.rad_scm_temp_daily_report_conform_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_daily_report_conform_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_daily_report_conform_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_daily_report_liquidation;
VACUUM mna_buyout__supply_chain.rad_scm_temp_daily_report_liquidation RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_daily_report_liquidation;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_daily_report_liquidation", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_dc_upc_items_staging;
VACUUM mna_buyout__supply_chain.rad_scm_temp_dc_upc_items_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_dc_upc_items_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_dc_upc_items_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_disc;
VACUUM mna_buyout__supply_chain.rad_scm_temp_disc RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_disc;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_disc", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_disc_staging;
VACUUM mna_buyout__supply_chain.rad_scm_temp_disc_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_disc_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_disc_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_facings;
VACUUM mna_buyout__supply_chain.rad_scm_temp_facings RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_facings;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_facings", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_facings_staging;
VACUUM mna_buyout__supply_chain.rad_scm_temp_facings_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_facings_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_facings_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_gt30days_leadtime_pln_upc_item;
VACUUM mna_buyout__supply_chain.rad_scm_temp_gt30days_leadtime_pln_upc_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_gt30days_leadtime_pln_upc_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_gt30days_leadtime_pln_upc_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_item_cost;
VACUUM mna_buyout__supply_chain.rad_scm_temp_item_cost RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_item_cost;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_item_cost", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_item_cost_staging;
VACUUM mna_buyout__supply_chain.rad_scm_temp_item_cost_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_item_cost_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_item_cost_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_liquidation_analysis;
VACUUM mna_buyout__supply_chain.rad_scm_temp_liquidation_analysis RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_liquidation_analysis;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_liquidation_analysis", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_pi_table;
VACUUM mna_buyout__supply_chain.rad_scm_temp_pi_table RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_pi_table;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_pi_table", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_report_conform_day_store;
VACUUM mna_buyout__supply_chain.rad_scm_temp_report_conform_day_store RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_report_conform_day_store;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_report_conform_day_store", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_report_inv_store_cat;
VACUUM mna_buyout__supply_chain.rad_scm_temp_report_inv_store_cat RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_report_inv_store_cat;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_report_inv_store_cat", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_rgis;
VACUUM mna_buyout__supply_chain.rad_scm_temp_rgis RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_rgis;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_rgis", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_stores;
VACUUM mna_buyout__supply_chain.rad_scm_temp_stores RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_stores;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_stores", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_test_wag_pkd_for_waterfall_v0;
VACUUM mna_buyout__supply_chain.rad_scm_temp_test_wag_pkd_for_waterfall_v0 RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_test_wag_pkd_for_waterfall_v0;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_temp_test_wag_pkd_for_waterfall_v0", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_upc_cost_category;
VACUUM mna_buyout__supply_chain.rad_scm_temp_upc_cost_category RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_upc_cost_category;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_upc_cost_category", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_upc_cost_category_status;
VACUUM mna_buyout__supply_chain.rad_scm_temp_upc_cost_category_status RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_upc_cost_category_status;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_upc_cost_category_status", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_upc_ric_wic;
VACUUM mna_buyout__supply_chain.rad_scm_temp_upc_ric_wic RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_upc_ric_wic;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_upc_ric_wic", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_wave34_47_liquidation_analysis_1;
VACUUM mna_buyout__supply_chain.rad_scm_temp_wave34_47_liquidation_analysis_1 RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_wave34_47_liquidation_analysis_1;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_wave34_47_liquidation_analysis_1", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_wave34_47_liquidation_analysis_ric_1;
VACUUM mna_buyout__supply_chain.rad_scm_temp_wave34_47_liquidation_analysis_ric_1 RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_wave34_47_liquidation_analysis_ric_1;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_wave34_47_liquidation_analysis_ric_1", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_temp_wave34_47_upc_liquidation_analysis;
VACUUM mna_buyout__supply_chain.rad_scm_temp_wave34_47_upc_liquidation_analysis RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_temp_wave34_47_upc_liquidation_analysis;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_temp_wave34_47_upc_liquidation_analysis", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_cat_upc_item_desc;
VACUUM mna_buyout__supply_chain.rad_scm_test_cat_upc_item_desc RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_cat_upc_item_desc;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_cat_upc_item_desc", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_conversion_wag_planogram_staging;
VACUUM mna_buyout__supply_chain.rad_scm_test_conversion_wag_planogram_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_conversion_wag_planogram_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_conversion_wag_planogram_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_product_cost_master_inventory;
VACUUM mna_buyout__supply_chain.rad_scm_test_product_cost_master_inventory RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_product_cost_master_inventory;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_product_cost_master_inventory", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_product_cost_master_inventory_final;
VACUUM mna_buyout__supply_chain.rad_scm_test_product_cost_master_inventory_final RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_product_cost_master_inventory_final;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_product_cost_master_inventory_final", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_product_price_master;
VACUUM mna_buyout__supply_chain.rad_scm_test_product_price_master RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_product_price_master;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_product_price_master", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_product_price_master_inventory;
VACUUM mna_buyout__supply_chain.rad_scm_test_product_price_master_inventory RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_product_price_master_inventory;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_product_price_master_inventory", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_product_price_master_sales;
VACUUM mna_buyout__supply_chain.rad_scm_test_product_price_master_sales RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_product_price_master_sales;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_product_price_master_sales", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_rep_conversion_conform_inv_sales_day_store_cat_plano;
VACUUM mna_buyout__supply_chain.rad_scm_test_rep_conversion_conform_inv_sales_day_store_cat_plano RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_rep_conversion_conform_inv_sales_day_store_cat_plano;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_rep_conversion_conform_inv_sales_day_store_cat_plano", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_rep_conversion_conform_inv_sales_week_store_cat_plano_part;
VACUUM mna_buyout__supply_chain.rad_scm_test_rep_conversion_conform_inv_sales_week_store_cat_plano_part RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_rep_conversion_conform_inv_sales_week_store_cat_plano_part;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_rep_conversion_conform_inv_sales_week_store_cat_plano_part", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_rep_conversion_conform_inv_sales_week_store_item;
VACUUM mna_buyout__supply_chain.rad_scm_test_rep_conversion_conform_inv_sales_week_store_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_rep_conversion_conform_inv_sales_week_store_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_rep_conversion_conform_inv_sales_week_store_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store;
VACUUM mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_report_inv_sales_day_store", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store2;
VACUUM mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store2 RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store2;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_report_inv_sales_day_store2", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store3;
VACUUM mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store3 RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store3;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_report_inv_sales_day_store3", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store_table;
VACUUM mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store_table RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_report_inv_sales_day_store_table;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_report_inv_sales_day_store_table", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_sales_day_store_item;
VACUUM mna_buyout__supply_chain.rad_scm_test_sales_day_store_item RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_sales_day_store_item;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_sales_day_store_item", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_sales_detail;
VACUUM mna_buyout__supply_chain.rad_scm_test_sales_detail RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_sales_detail;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_sales_detail", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_temp_stores;
VACUUM mna_buyout__supply_chain.rad_scm_test_temp_stores RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_temp_stores;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_temp_stores", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_test_upc_data_staging;
VACUUM mna_buyout__supply_chain.rad_scm_test_upc_data_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_test_upc_data_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_test_upc_data_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_upc;
VACUUM mna_buyout__supply_chain.rad_scm_upc RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_upc;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_upc", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_vehicleloadline;
VACUUM mna_buyout__supply_chain.rad_scm_vehicleloadline RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_vehicleloadline;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_vehicleloadline", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_vehicleloadline_days;
VACUUM mna_buyout__supply_chain.rad_scm_vehicleloadline_days RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_vehicleloadline_days;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_vehicleloadline_days", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_vehicleloadline_future;
VACUUM mna_buyout__supply_chain.rad_scm_vehicleloadline_future RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_vehicleloadline_future;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_vehicleloadline_future", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_vehicleloadline_new;
VACUUM mna_buyout__supply_chain.rad_scm_vehicleloadline_new RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_vehicleloadline_new;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_vehicleloadline_new", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_vehicleloadline_received_days;
VACUUM mna_buyout__supply_chain.rad_scm_vehicleloadline_received_days RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_vehicleloadline_received_days;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_vehicleloadline_received_days", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_vehicleloadline_received_seq;
VACUUM mna_buyout__supply_chain.rad_scm_vehicleloadline_received_seq RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_vehicleloadline_received_seq;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_vehicleloadline_received_seq", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_vehicleloadline_staging;
VACUUM mna_buyout__supply_chain.rad_scm_vehicleloadline_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_vehicleloadline_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_vehicleloadline_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_conversion_planogram;
VACUUM mna_buyout__supply_chain.rad_scm_wag_conversion_planogram RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_conversion_planogram;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_conversion_planogram", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_conversion_planogram_staging;
VACUUM mna_buyout__supply_chain.rad_scm_wag_conversion_planogram_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_conversion_planogram_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_conversion_planogram_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_conversion_planogram_staging_1;
VACUUM mna_buyout__supply_chain.rad_scm_wag_conversion_planogram_staging_1 RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_conversion_planogram_staging_1;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_conversion_planogram_staging_1", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_conversion_planogram_staging_2;
VACUUM mna_buyout__supply_chain.rad_scm_wag_conversion_planogram_staging_2 RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_conversion_planogram_staging_2;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_conversion_planogram_staging_2", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_day_ops_store_sales;
VACUUM mna_buyout__supply_chain.rad_scm_wag_day_ops_store_sales RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_day_ops_store_sales;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_day_ops_store_sales", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_day_ops_store_ssis;
VACUUM mna_buyout__supply_chain.rad_scm_wag_day_ops_store_ssis RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_day_ops_store_ssis;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_day_ops_store_ssis", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_day_ops_store_ssis_sales;
VACUUM mna_buyout__supply_chain.rad_scm_wag_day_ops_store_ssis_sales RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_day_ops_store_ssis_sales;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_day_ops_store_ssis_sales", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_dos_by_op;
VACUUM mna_buyout__supply_chain.rad_scm_wag_dos_by_op RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_dos_by_op;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_dos_by_op", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_pkd_for_waterfall;
VACUUM mna_buyout__supply_chain.rad_scm_wag_pkd_for_waterfall RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_pkd_for_waterfall;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_wag_pkd_for_waterfall", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_planogram;
VACUUM mna_buyout__supply_chain.rad_scm_wag_planogram RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_planogram;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_planogram", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_planogram_staging;
VACUUM mna_buyout__supply_chain.rad_scm_wag_planogram_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_planogram_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_planogram_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_str_upc_conform;
VACUUM mna_buyout__supply_chain.rad_scm_wag_str_upc_conform RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_str_upc_conform;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_str_upc_conform", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wag_t32_fo_date_staging;
VACUUM mna_buyout__supply_chain.rad_scm_wag_t32_fo_date_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wag_t32_fo_date_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wag_t32_fo_date_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_waterfall_outs;
VACUUM mna_buyout__supply_chain.rad_scm_waterfall_outs RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_waterfall_outs;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_waterfall_outs", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wave_conf_item_rgis_pi_sales;
VACUUM mna_buyout__supply_chain.rad_scm_wave_conf_item_rgis_pi_sales RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wave_conf_item_rgis_pi_sales;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wave_conf_item_rgis_pi_sales", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wave_conf_items;
VACUUM mna_buyout__supply_chain.rad_scm_wave_conf_items RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wave_conf_items;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wave_conf_items", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wave_conf_items_staging;
VACUUM mna_buyout__supply_chain.rad_scm_wave_conf_items_staging RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wave_conf_items_staging;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wave_conf_items_staging", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wave_new_items;
VACUUM mna_buyout__supply_chain.rad_scm_wave_new_items RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wave_new_items;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wave_new_items", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wave_post_conversion_ssis;
VACUUM mna_buyout__supply_chain.rad_scm_wave_post_conversion_ssis RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wave_post_conversion_ssis;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wave_post_conversion_ssis", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wave_post_conversion_ssis_test;
VACUUM mna_buyout__supply_chain.rad_scm_wave_post_conversion_ssis_test RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wave_post_conversion_ssis_test;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wave_post_conversion_ssis_test", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wave_store_item_rgis_pi_sales_old;
VACUUM mna_buyout__supply_chain.rad_scm_wave_store_item_rgis_pi_sales_old RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wave_store_item_rgis_pi_sales_old;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wave_store_item_rgis_pi_sales_old", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_waves_markdown_sku;
VACUUM mna_buyout__supply_chain.rad_scm_waves_markdown_sku RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_waves_markdown_sku;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_waves_markdown_sku", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_waves_markdown_sku_test;
VACUUM mna_buyout__supply_chain.rad_scm_waves_markdown_sku_test RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_waves_markdown_sku_test;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_waves_markdown_sku_test", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wic_retail;
VACUUM mna_buyout__supply_chain.rad_scm_wic_retail RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wic_retail;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wic_retail", recurse=True)
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM mna_buyout__supply_chain.rad_scm_wic_suggestedretail;
VACUUM mna_buyout__supply_chain.rad_scm_wic_suggestedretail RETAIN 0 HOURS;
DROP TABLE mna_buyout__supply_chain.rad_scm_wic_suggestedretail;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_wic_suggestedretail", recurse=True)

# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_finance', defaultValue='${STORAGE_ACCT_wrg_finance}', label='STORAGE_ACCT_wrg_finance')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_digital', defaultValue='${STORAGE_ACCT_wrg_digital}', label='STORAGE_ACCT_wrg_digital')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__product;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__product;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__finance__account_payables;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__employment_history;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__employment_history;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__organization_structure;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employment_history.address_stg(
update_flag STRING,
person_id STRING,
address_type STRING,
start_date STRING,
address1 STRING,
apartment STRING,
city STRING,
street_number STRING,
address2 STRING,
careof STRING,
municipality STRING,
governorate STRING,
town STRING,
municipality1 STRING,
camp STRING,
camp1 STRING,
building STRING,
district STRING,
country STRING,
county STRING,
created_by STRING,
created_on STRING,
urbanization STRING,
end_date STRING,
last_modified_by STRING,
last_modified_on STRING,
province STRING,
state STRING,
zip_code STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employment_history/staging/address_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.bank_stg(
update_flag STRING,
external_code STRING,
bank_country STRING,
bank_name STRING,
business_identifier_code STRING,
city STRING,
created_by STRING,
created_date STRING,
status STRING,
last_modified_by STRING,
last_modified_date STRING,
mdf_system_record_status STRING,
postal_code STRING,
routing_number STRING,
street STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/bank_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.email_stg(
update_flag STRING,
employee_id STRING,
email_type STRING,
created_by STRING,
created_on STRING,
email_address STRING,
is_primary STRING,
last_modified_by STRING,
last_modified_on STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/email_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.foeventreason_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
empl_status STRING,
end_date STRING,
event STRING,
implicit_position_action STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
payroll_event STRING,
status STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/foeventreason_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employment_history.address_delta_stg(
update_flag STRING,
person_id STRING,
address_type STRING,
start_date STRING,
address1 STRING,
apartment STRING,
city STRING,
street_number STRING,
address2 STRING,
careof STRING,
municipality STRING,
governorate STRING,
town STRING,
municipality1 STRING,
camp STRING,
camp1 STRING,
building STRING,
district STRING,
country STRING,
county STRING,
created_by STRING,
created_on STRING,
urbanization STRING,
end_date STRING,
last_modified_by STRING,
last_modified_on STRING,
province STRING,
state STRING,
zip_code STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employment_history/staging/address_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employment_history.address_persistent_stg(
update_flag STRING,
person_id STRING,
address_type STRING,
start_date STRING,
address1 STRING,
apartment STRING,
city STRING,
street_number STRING,
address2 STRING,
careof STRING,
municipality STRING,
governorate STRING,
town STRING,
municipality1 STRING,
camp STRING,
camp1 STRING,
building STRING,
district STRING,
country STRING,
county STRING,
created_by STRING,
created_on STRING,
urbanization STRING,
end_date STRING,
last_modified_by STRING,
last_modified_on STRING,
province STRING,
state STRING,
zip_code STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employment_history/staging/address_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employment_history.address_unchanged_stg(
update_flag STRING,
person_id STRING,
address_type STRING,
start_date STRING,
address1 STRING,
apartment STRING,
city STRING,
street_number STRING,
address2 STRING,
careof STRING,
municipality STRING,
governorate STRING,
town STRING,
municipality1 STRING,
camp STRING,
camp1 STRING,
building STRING,
district STRING,
country STRING,
county STRING,
created_by STRING,
created_on STRING,
urbanization STRING,
end_date STRING,
last_modified_by STRING,
last_modified_on STRING,
province STRING,
state STRING,
zip_code STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employment_history/staging/address_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.bank_delta_stg(
update_flag STRING,
external_code BIGINT,
bank_country STRING,
bank_name STRING,
business_identifier_code STRING,
city STRING,
created_by STRING,
created_date STRING,
status STRING,
last_modified_by STRING,
last_modified_date STRING,
mdf_system_record_status STRING,
postal_code STRING,
routing_number STRING,
street STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/bank_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.bank_persistent_stg(
update_flag STRING,
external_code BIGINT,
bank_country STRING,
bank_name STRING,
business_identifier_code STRING,
city STRING,
created_by STRING,
created_date STRING,
status STRING,
last_modified_by STRING,
last_modified_date STRING,
mdf_system_record_status STRING,
postal_code STRING,
routing_number STRING,
street STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/bank_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.bank_unchanged_stg(
update_flag STRING,
external_code BIGINT,
bank_country STRING,
bank_name STRING,
business_identifier_code STRING,
city STRING,
created_by STRING,
created_date STRING,
status STRING,
last_modified_by STRING,
last_modified_date STRING,
mdf_system_record_status STRING,
postal_code STRING,
routing_number STRING,
street STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/bank_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.foeventreason_delta_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
empl_status STRING,
end_date STRING,
event STRING,
implicit_position_action BIGINT,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
payroll_event STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/foeventreason_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.foeventreason_persistent_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
empl_status STRING,
end_date STRING,
event STRING,
implicit_position_action BIGINT,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
payroll_event STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/foeventreason_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.foeventreason_unchanged_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
empl_status STRING,
end_date STRING,
event STRING,
implicit_position_action BIGINT,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
payroll_event STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/foeventreason_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.jobclassificationusa_persistent_stg(
update_flag STRING,
external_code STRING,
job_classification_country_country STRING,
job_classification_effective_start_date STRING,
job_classification_external_code STRING,
created_by STRING,
created_date_time STRING,
cust_census_code STRING,
cust_standard_code STRING,
eeo1_job_category STRING,
eeo4_job_category STRING,
eeo5_job_category STRING,
eeo6_job_category STRING,
eeo_job_group STRING,
flsa_status_usa STRING,
last_modified_by STRING,
last_modified_date_time STRING,
local_job_title STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/jobclassificationusa_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__product.adr_part_managed_stg(
part_nbr STRING,
part_rvsn_nbr STRING,
part_desc_1 STRING,
part_desc_2 STRING,
std_cost STRING,
std_cost_currency STRING,
std_cost_dt STRING,
stock_ind STRING,
mfgr_name STRING,
mfgr_part_nbr STRING,
lead_time_ind_days STRING,
flex_fld_1 STRING,
flex_fld_2 STRING,
flex_fld_3 STRING,
part_flex_txt_1 STRING,
part_flex_txt_2 STRING,
part_flex_txt_3 STRING,
origin_cntry STRING,
ops_study_nbr STRING,
fcst_usag_1 STRING,
fcst_usag_2 STRING,
fcst_usag_3 STRING,
pvt_lable_ind STRING,
gnfr_ind STRING,
prod_brand_name STRING,
mat_group_cd STRING,
cntrl_wic STRING,
cntrl_upc STRING,
wic STRING,
upc STRING,
uom STRING,
tracking_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/product/staging/adr_part_managed_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__product.load_month_hist_stg(
load_date DATE,
file_name STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/product/staging/load_month_hist_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.1.5", "scripts": ["D.31.1.crt.retail__product.sql", "D.46.1.wrg.retail__product.sql", "D.47.1.wrg.finance__account_payables.sql", "D.54.1.wrg.digital__ecom.sql", "D.56.1.wrg.hr__recruiting.sql", "D.59.1.crt.hr__employment_history.sql", "D.60.1.crt.hr__payroll.sql", "D.63.1.crt.hr__recruiting.sql", "D.66.1.wrg.hr__employment_history.sql", "D.67.1.wrg.hr__payroll.sql", "D.68.1.wrg.hr__organization_structure.sql", "T.14609.1.wrg.address_stg.sql", "T.14611.1.wrg.bank_stg.sql", "T.14660.1.wrg.email_stg.sql", "T.14704.1.wrg.foeventreason_stg.sql", "T.14781.1.wrg.address_delta_stg.sql", "T.14785.1.wrg.address_persistent_stg.sql", "T.14786.1.wrg.address_unchanged_stg.sql", "T.14796.1.wrg.bank_delta_stg.sql", "T.14797.1.wrg.bank_persistent_stg.sql", "T.14798.1.wrg.bank_unchanged_stg.sql", "T.15000.1.wrg.foeventreason_delta_stg.sql", "T.15001.1.wrg.foeventreason_persistent_stg.sql", "T.15002.1.wrg.foeventreason_unchanged_stg.sql", "T.15060.1.wrg.jobclassificationusa_persistent_stg.sql", "T.19439.1.wrg.adr_part_managed_stg.sql", "T.9291.1.wrg.load_month_hist_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.1.5", "table_id": "T.14609.1", "table_name": "address_stg", "table_schema": "staging__hr__employment_history.address_stg", "table_legacy_schema": "hr_raw.address", "table_domain": "hr", "table_subdomain": "employment_history", "table_location": "staging__hr__employment_history.address_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__employment_history", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.14611.1", "table_name": "bank_stg", "table_schema": "staging__hr__payroll.bank_stg", "table_legacy_schema": "hr_raw.bank", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.bank_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.14660.1", "table_name": "email_stg", "table_schema": "staging__hr__recruiting.email_stg", "table_legacy_schema": "hr_raw.email", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.email_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.14704.1", "table_name": "foeventreason_stg", "table_schema": "staging__hr__payroll.foeventreason_stg", "table_legacy_schema": "hr_raw.foeventreason", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.foeventreason_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.14781.1", "table_name": "address_delta_stg", "table_schema": "staging__hr__employment_history.address_delta_stg", "table_legacy_schema": "hr_work.address_delta", "table_domain": "hr", "table_subdomain": "employment_history", "table_location": "staging__hr__employment_history.address_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employment_history", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.14785.1", "table_name": "address_persistent_stg", "table_schema": "staging__hr__employment_history.address_persistent_stg", "table_legacy_schema": "hr_work.address_persistent", "table_domain": "hr", "table_subdomain": "employment_history", "table_location": "staging__hr__employment_history.address_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employment_history", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.14786.1", "table_name": "address_unchanged_stg", "table_schema": "staging__hr__employment_history.address_unchanged_stg", "table_legacy_schema": "hr_work.address_unchanged", "table_domain": "hr", "table_subdomain": "employment_history", "table_location": "staging__hr__employment_history.address_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employment_history", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.14796.1", "table_name": "bank_delta_stg", "table_schema": "staging__hr__payroll.bank_delta_stg", "table_legacy_schema": "hr_work.bank_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.bank_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.14797.1", "table_name": "bank_persistent_stg", "table_schema": "staging__hr__payroll.bank_persistent_stg", "table_legacy_schema": "hr_work.bank_persistent", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.bank_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.14798.1", "table_name": "bank_unchanged_stg", "table_schema": "staging__hr__payroll.bank_unchanged_stg", "table_legacy_schema": "hr_work.bank_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.bank_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.15000.1", "table_name": "foeventreason_delta_stg", "table_schema": "staging__hr__payroll.foeventreason_delta_stg", "table_legacy_schema": "hr_work.foeventreason_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.foeventreason_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.15001.1", "table_name": "foeventreason_persistent_stg", "table_schema": "staging__hr__payroll.foeventreason_persistent_stg", "table_legacy_schema": "hr_work.foeventreason_persistent", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.foeventreason_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.15002.1", "table_name": "foeventreason_unchanged_stg", "table_schema": "staging__hr__payroll.foeventreason_unchanged_stg", "table_legacy_schema": "hr_work.foeventreason_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.foeventreason_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.15060.1", "table_name": "jobclassificationusa_persistent_stg", "table_schema": "staging__hr__organization_structure.jobclassificationusa_persistent_stg", "table_legacy_schema": "hr_work.jobclassificationusa_persistent", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.jobclassificationusa_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.19439.1", "table_name": "adr_part_managed_stg", "table_schema": "staging__retail__product.adr_part_managed_stg", "table_legacy_schema": "dae_raw.adr_part_managed", "table_domain": "retail", "table_subdomain": "product", "table_location": "staging__retail__product.adr_part_managed_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__retail__product", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.5", "table_id": "T.9291.1", "table_name": "load_month_hist_stg", "table_schema": "staging__retail__product.load_month_hist_stg", "table_legacy_schema": "dae_work.load_month_hist", "table_domain": "retail", "table_subdomain": "product", "table_location": "staging__retail__product.load_month_hist_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__retail__product", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
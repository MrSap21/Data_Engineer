# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__employee_performance;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.perf_rating_data_stg(
employee_id STRING,
performance_emp_ack_date DATE,
location STRING,
performance_mgr_ack_date DATE,
performance_rating1 STRING,
performance_desc STRING,
position STRING,
performance_review_type STRING,
performance_effective_date DATE,
performance_effective_end_date DATE,
performance_reviewer_emp_id STRING,
cd_key STRING,
rno STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/perf_rating_data_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.promo_extended_stg(
employee_id STRING,
latest_promotion_rating STRING,
promo_start_date DATE,
latest_promotion_rating_desc STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/promo_extended_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__employee_performance.perf_extended_stg(
employee_id STRING,
performance_emp_ack_date DATE,
location STRING,
performance_mgr_ack_date DATE,
performance_rating1 STRING,
performance_desc STRING,
position STRING,
performance_review_type STRING,
performance_start_date DATE,
performance_end_date DATE,
performance_reviewer_emp_id STRING,
rno STRING,
cd_name STRING,
cd_ind STRING,
cd_desc STRING,
cd_type STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/employee_performance/staging/perf_extended_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.1.1", "scripts": ["D.92.1.wrg.hr__employee_performance.sql", "T.15159.1.wrg.perf_rating_data_stg.sql", "T.19990.1.wrg.promo_extended_stg.sql", "T.19991.1.wrg.perf_extended_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.1.1", "table_id": "T.15159.1", "table_name": "perf_rating_data_stg", "table_schema": "staging__hr__employee_performance.perf_rating_data_stg", "table_legacy_schema": "hr_work.perf_rating_data", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.perf_rating_data_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.1", "table_id": "T.19990.1", "table_name": "promo_extended_stg", "table_schema": "staging__hr__employee_performance.promo_extended_stg", "table_legacy_schema": "hr_work.promo_extended", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.promo_extended_stg", "table_partition": "", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.1", "table_id": "T.19991.1", "table_name": "perf_extended_stg", "table_schema": "staging__hr__employee_performance.perf_extended_stg", "table_legacy_schema": "hr_work.perf_extended", "table_domain": "hr", "table_subdomain": "employee_performance", "table_location": "staging__hr__employee_performance.perf_extended_stg", "table_partition": "", "table_db": "staging__hr__employee_performance", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

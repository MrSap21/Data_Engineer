# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='STORAGE_ACCT_crt_master_data', defaultValue='${STORAGE_ACCT_crt_master_data}', label='STORAGE_ACCT_crt_master_data')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__ccpa;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__ccpa;""")
# COMMAND ----------
%sql
DROP TABLE master_data__customer.ccpa_customer_request_list
# COMMAND ----------
dbutils.fs.rm(f"abfss://curated@{getArgument('STORAGE_ACCT_crt_master_data')}.dfs.core.windows.net/master_data/customer/ccpa_customer_request_list", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__ccpa.ccpa_customer_request_list(
tkt_nbr STRING COMMENT 'ticket DOUBLE',
tkt_open_dt DATE COMMENT 'ticket open date',
reqst_type_cd STRING COMMENT 'request type code',
tkt_line_seq INT COMMENT 'ticket line sequence',
edw_tkt_receive_dt DATE COMMENT 'edw ticket receive date',
TASK_ID STRING COMMENT 'Task id',
TASK_DEADLINE DATE COMMENT 'Task deadline',
USER_TYPE STRING COMMENT 'User Type',
TASK_NAME STRING COMMENT 'Task name',
CV_FLAG STRING COMMENT 'CV Flag',
Minor_FL STRING COMMENT 'Minor Flag',
cust_src_id STRING COMMENT 'customer source identifier',
src_sys_cd STRING COMMENT 'source system code',
composite_type_cd STRING COMMENT 'composite type code',
msg_type_cd STRING COMMENT 'message type code',
LV_Flag STRING COMMENT 'Lesser Verification Flag',
REQ_STATUS STRING ,
STATUS_COMMENT STRING ,
Optout_begin_dt DATE COMMENT 'optout begin date',
Optout_end_dt DATE COMMENT 'optout end date',
Notification_dt DATE COMMENT 'Notification date',
cust_first_name STRING COMMENT 'customer first name',
cust_middle_name STRING COMMENT 'customer middle name',
cust_last_name STRING COMMENT 'customer last name',
cust_brth_dt DATE COMMENT 'customer birth date',
cust_addr_line_1 STRING COMMENT 'customer address line 1',
cust_addr_line_2 STRING COMMENT 'customer address line 2',
cust_city STRING COMMENT 'customer city',
cust_state_cd STRING COMMENT 'customer state code',
cust_zip_cd STRING COMMENT 'customer zip code',
cust_eml_addr STRING COMMENT 'customer email address',
cust_phone_nbr STRING COMMENT 'customer phone DOUBLE',
edw_reqst_complete_dt DATE COMMENT 'edw request complete date',
edw_tkt_complete_dt DATE COMMENT 'edw ticket complete date',
edw_cmnt_txt STRING COMMENT 'edw COMMENT text',
edw_detail_rpt_path STRING COMMENT 'edw detail report path',
edw_sumr_rpt_path STRING COMMENT 'edw summary report path',
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_retail')}.dfs.core.windows.net/retail/ccpa/ccpa_customer_request_list'
PARTITIONED BY (
edw_create_dttm)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__ccpa.ccpa_customer_extracts_activity_purge_stg(
cust_src_id STRING,
src_sys_cd STRING,
extract_id STRING,
last_activity_dt STRING,
create_dttm STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/ccpa/staging/ccpa_customer_extracts_activity_purge_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.0.0", "scripts": ["D.2.1.crt.retail__ccpa.sql", "D.91.1.wrg.retail__ccpa.sql", "T.1066.0.crt.ccpa_customer_request_list.sql", "T.1066.1.crt.ccpa_customer_request_list.sql", "T.7151.1.wrg.ccpa_customer_extracts_activity_purge_stg.sql"], "migration_date": "2022-06-29"}]
table_data=[{"release": "7.0.0", "table_id": "T.1066.1", "table_name": "ccpa_customer_request_list", "table_schema": "retail__ccpa.ccpa_customer_request_list", "table_legacy_schema": "dae_cooked.ccpa_customer_request_list", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "retail__ccpa.ccpa_customer_request_list", "table_partition": "\n  edw_create_dttm STRING", "table_db": "retail__ccpa", "table_zone": "curated", "create_date": "2022-06-29 10:44:51", "update_date": ""}, {"release": "7.0.0", "table_id": "T.7151.1", "table_name": "ccpa_customer_extracts_activity_purge_stg", "table_schema": "staging__retail__ccpa.ccpa_customer_extracts_activity_purge_stg", "table_legacy_schema": "dae_work.ccpa_customer_extracts_activity_purge", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "staging__retail__ccpa.ccpa_customer_extracts_activity_purge_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__retail__ccpa", "table_zone": "wrangled", "create_date": "2022-06-29 10:44:51", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.','ccpa_customer_request_list');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_mna_buyout', defaultValue='${STORAGE_ACCT_crt_mna_buyout}', label='STORAGE_ACCT_crt_mna_buyout')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS mna_buyout__supply_chain;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS mna_buyout__supply_chain.rad_scm_grand_open_daily_store_offer_items(
wag_store INT,
official_wave INT,
urban_format STRING,
business_tourist STRING,
pln_nbr BIGINT,
pln_desc STRING,
go_ad_start_date DATE,
go_ad_end_date DATE,
year INT,
month STRING,
official_wk DATE,
conversion_date DATE,
source_file_name STRING,
offer_details STRING,
price_or_offer STRING,
per_id INT,
ad_wk_begin_dt DATE,
ad_wk_end_dt DATE,
ops_dept_nbr INT,
ops_dept_name STRING,
whse_prod_vendor_name STRING,
whse_prod_vendor_nbr INT,
dc_loc_name STRING,
disc_reason_description STRING,
discontinue_reason_code STRING,
bdm_str_count BIGINT,
str_with_ioh BIGINT,
ioh_end_units BIGINT,
excl_rsn_cd STRING,
mdg_nbr INT,
mdg_loc_id INT,
mdg_loc_name STRING,
city STRING,
state STRING,
str_latitude_deg DECIMAL(10,6),
str_longitude_deg DECIMAL(10,6),
sales_cost_dlrs DECIMAL(38,4),
sales_dlrs DECIMAL(38,2),
sales_units DECIMAL(38,1),
profit_dlrs DECIMAL(38,4),
wk1_user DECIMAL(23,5),
wk2_user DECIMAL(23,5),
wk3_user DECIMAL(23,5),
wk4_user DECIMAL(23,5),
wk1_system DECIMAL(23,5),
wk2_system DECIMAL(23,5),
wk3_system DECIMAL(23,5),
wk4_system DECIMAL(23,5))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_mna_buyout')}.dfs.core.windows.net/mna_buyout/supply_chain/rad_scm_grand_open_daily_store_offer_items'
PARTITIONED BY (
day_date DATE)""")
# COMMAND ----------
migration_data=[{"release": "9.6.4", "scripts": ["D.74.1.crt.mna_buyout__supply_chain.sql", "T.15530.1.crt.rad_scm_grand_open_daily_store_offer_items.sql"], "migration_date": "2022-10-27"}]
table_data=[{"release": "9.6.4", "table_id": "T.15530.1", "table_name": "rad_scm_grand_open_daily_store_offer_items", "table_schema": "mna_buyout__supply_chain.rad_scm_grand_open_daily_store_offer_items", "table_legacy_schema": "mna_cooked.rad_scm_grand_open_daily_store_offer_items", "table_domain": "mna_buyout", "table_subdomain": "supply_chain", "table_location": "mna_buyout__supply_chain.rad_scm_grand_open_daily_store_offer_items", "table_partition": "\n  day_date DATE", "table_db": "mna_buyout__supply_chain", "table_zone": "curated", "create_date": "2022-10-27 12:07:06", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

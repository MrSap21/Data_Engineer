# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.employeetime_delta_stg(
update_flag STRING,
employee_id STRING,
external_code STRING,
approval_status STRING,
start_date STRING,
start_time STRING,
end_date STRING,
end_time STRING,
cancellation_workflow_request_id STRING,
comment STRING,
created_by STRING,
created_date_time STRING,
deduction_quantity STRING,
editable STRING,
flexible_requesting STRING,
fraction_quantity STRING,
last_modified_by STRING,
last_modified_date_time STRING,
loa_actual_return_date STRING,
loa_end_job_info_id STRING,
loa_expected_return_date STRING,
loa_start_job_info_id STRING,
mdf_system_record_status STRING,
original_quantity_in_days STRING,
quantity_in_days STRING,
quantity_in_hours STRING,
recurrence_group STRING,
time_record_origin STRING,
time_type STRING,
undetermined_end_date STRING,
workflow_initiated_by_admin STRING,
workflow_request_id STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/employeetime_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.employeetime_unchanged_stg(
update_flag STRING,
employee_id STRING,
external_code STRING,
approval_status STRING,
start_date STRING,
start_time STRING,
end_date STRING,
end_time STRING,
cancellation_workflow_request_id STRING,
comment STRING,
created_by STRING,
created_date_time STRING,
deduction_quantity STRING,
editable STRING,
flexible_requesting STRING,
fraction_quantity STRING,
last_modified_by STRING,
last_modified_date_time STRING,
loa_actual_return_date STRING,
loa_end_job_info_id STRING,
loa_expected_return_date STRING,
loa_start_job_info_id STRING,
mdf_system_record_status STRING,
original_quantity_in_days STRING,
quantity_in_days STRING,
quantity_in_hours STRING,
recurrence_group STRING,
time_record_origin STRING,
time_type STRING,
undetermined_end_date STRING,
workflow_initiated_by_admin STRING,
workflow_request_id STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/employeetime_unchanged_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.3.6", "scripts": ["D.71.1.wrg.hr__compensation_benefits.sql", "T.14927.1.wrg.employeetime_delta_stg.sql", "T.14929.1.wrg.employeetime_unchanged_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.3.6", "table_id": "T.14927.1", "table_name": "employeetime_delta_stg", "table_schema": "staging__hr__compensation_benefits.employeetime_delta_stg", "table_legacy_schema": "hr_work.employeetime_delta", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.employeetime_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.6", "table_id": "T.14929.1", "table_name": "employeetime_unchanged_stg", "table_schema": "staging__hr__compensation_benefits.employeetime_unchanged_stg", "table_legacy_schema": "hr_work.employeetime_unchanged", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.employeetime_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_digital', defaultValue='${STORAGE_ACCT_wrg_digital}', label='STORAGE_ACCT_wrg_digital')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr INT,
cdc_rba_nbr DECIMAL(18,0),
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id DECIMAL(18,0),
str_nbr DECIMAL(5,0),
rx_nbr DECIMAL(7,0),
rx_fill_nbr DECIMAL(3,0),
rx_partial_fill_nbr DECIMAL(1,0),
item_num_key INT,
item_vrfy_dttm STRING,
fill_vrfy_user_id INT,
fill_vrfy_dttm STRING,
fill_vrfy_str_nbr INT,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
fill_enter_dt STRING,
fill_enter_tm STRING,
edw_create_dttm STRING,
rx_create_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_stg'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_sold_dt_stg(
edw_batch_id DECIMAL(18,0),
str_nbr DECIMAL(5,0),
rx_nbr DECIMAL(7,0),
rx_fill_nbr DECIMAL(3,0),
rx_partial_fill_nbr DECIMAL(1,0),
item_num_key INT,
item_vrfy_dttm STRING,
fill_vrfy_user_id INT,
fill_vrfy_dttm STRING,
fill_vrfy_str_nbr INT,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
fill_enter_dt STRING,
fill_enter_tm STRING,
edw_create_dttm STRING,
rx_create_dt STRING,
fill_sold_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_sold_dt_stg'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_nucleus_verification_prep_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id STRING,
str_nbr STRING,
rx_nbr STRING,
rx_fill_nbr STRING,
rx_partial_fill_nbr STRING,
item_num_key STRING,
item_vrfy_dttm STRING,
fill_vrfy_user_id STRING,
fill_vrfy_dttm STRING,
fill_vrfy_str_nbr STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING,
fill_enter_dttm STRING,
edw_create_dttm STRING,
store_nbr_bkp STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_rx_nucleus_verification_prep_stg'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_fl_rx_nucleus_verification_stg(
edw_batch_id DECIMAL(18,0),
str_nbr DECIMAL(5,0),
rx_nbr DECIMAL(7,0),
rx_fill_nbr DECIMAL(3,0),
rx_partial_fill_nbr DECIMAL(1,0),
item_num_key INT,
item_vrfy_dttm STRING,
fill_vrfy_user_id INT,
fill_vrfy_dttm STRING,
fill_vrfy_str_nbr INT,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
fill_enter_dt STRING,
fill_enter_tm STRING,
edw_create_dttm STRING,
rx_create_dt STRING,
fill_sold_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_fl_rx_nucleus_verification_stg'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_fill_enter_mnth_stg(
fill_enter_mnth STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_rx_nucleus_verification_mod_fill_enter_mnth_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_prep_stg(
edw_batch_id DECIMAL(18,0),
rx_nbr DECIMAL(7,0),
str_nbr DECIMAL(5,0),
rx_fill_nbr DECIMAL(3,0),
rx_partial_fill_nbr DECIMAL(1,0),
item_num_key INT,
item_vrfy_dttm STRING,
fill_vrfy_user_id INT,
fill_vrfy_dttm STRING,
fill_vrfy_str_nbr INT,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
fill_enter_dt STRING,
fill_enter_tm STRING,
edw_create_dttm STRING,
rx_create_dt STRING,
fill_sold_dt STRING,
proc_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_rx_nucleus_verification_mod_prep_stg'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_prep_plus_stg(
edw_batch_id DECIMAL(18,0),
str_nbr DECIMAL(5,0),
rx_nbr DECIMAL(7,0),
rx_fill_nbr DECIMAL(3,0),
rx_partial_fill_nbr DECIMAL(1,0),
item_num_key INT,
item_vrfy_dttm STRING,
fill_vrfy_user_id INT,
fill_vrfy_dttm STRING,
fill_vrfy_str_nbr INT,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
fill_enter_dt STRING,
fill_enter_tm STRING,
edw_create_dttm STRING,
rx_create_dt STRING,
fill_sold_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_rx_nucleus_verification_mod_prep_plus_stg'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_process_keys_stg(
rx_nbr INT,
old_str_nbr INT,
new_str_nbr INT,
old_fill_vrfy_str_nbr INT,
new_fill_vrfy_str_nbr INT,
old_rx_create_dt STRING,
new_rx_create_dt STRING,
fill_enter_dt STRING,
fill_enter_tm STRING,
fill_sold_dt STRING,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
item_num_key INT,
item_vrfy_dttm STRING,
fill_vrfy_user_id INT,
fill_vrfy_dttm STRING,
str_relo_ind STRING,
fill_vrfy_str_relo_ind STRING,
rxcdt_chng_ind STRING,
rx_etl_keys_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_rx_nucleus_verification_mod_process_keys_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_new_stg(
edw_batch_id DECIMAL(18,0),
rx_nbr DECIMAL(7,0),
str_nbr DECIMAL(5,0),
rx_fill_nbr DECIMAL(3,0),
rx_partial_fill_nbr DECIMAL(1,0),
item_num_key INT,
item_vrfy_dttm STRING,
fill_vrfy_user_id INT,
fill_vrfy_dttm STRING,
fill_vrfy_str_nbr INT,
src_create_user_id INT,
src_create_dttm STRING,
src_update_user_id INT,
src_update_dttm STRING,
fill_enter_dt STRING,
fill_enter_tm STRING,
edw_create_dttm STRING,
rx_create_dt STRING,
fill_sold_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_rx_nucleus_verification_new_stg'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_sms_refill_info_update_records_stg(
mongo_id STRING,
transaction_id STRING,
record_id STRING,
pat_id STRING,
phone_number STRING,
store_ph_no STRING,
create_dttm STRING,
update_dttm STRING,
first_name STRING,
last_name STRING,
dob_verified STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_sms_refill_info_update_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_sms_refill_info_insert_records_stg(
mongo_id STRING,
transaction_id STRING,
record_id STRING,
pat_id STRING,
phone_number STRING,
store_ph_no STRING,
create_dttm STRING,
update_dttm STRING,
first_name STRING,
last_name STRING,
dob_verified STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_sms_refill_info_insert_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_sms_refill_info_retained_records_stg(
mongo_id STRING,
transaction_id STRING,
record_id STRING,
pat_id STRING,
phone_number STRING,
store_ph_no STRING,
create_dttm STRING,
update_dttm STRING,
first_name STRING,
last_name STRING,
dob_verified STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_sms_refill_info_retained_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_sms_refill_info_temp_stg(
mongo_id STRING,
transaction_id STRING,
record_id STRING,
pat_id STRING,
phone_number STRING,
store_ph_no STRING,
create_dttm STRING,
update_dttm STRING,
first_name STRING,
last_name STRING,
dob_verified STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_sms_refill_info_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.rx_sms_refill_info_stg(
mongo_id STRING COMMENT 'FROM deserializer',
transaction_id STRING COMMENT 'FROM deserializer',
record_id STRING COMMENT 'FROM deserializer',
pat_id STRING COMMENT 'FROM deserializer',
phone_number STRING COMMENT 'FROM deserializer',
store_ph_no STRING COMMENT 'FROM deserializer',
create_dttm STRING COMMENT 'FROM deserializer',
first_name STRING COMMENT 'FROM deserializer',
last_name STRING COMMENT 'FROM deserializer',
update_dttm STRING COMMENT 'FROM deserializer',
dob_verified STRING COMMENT 'FROM deserializer')
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/rx_sms_refill_info_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_rx_nucleus_verification_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id STRING,
str_nbr STRING,
rx_nbr STRING,
rx_fill_nbr STRING,
rx_partial_fill_nbr STRING,
item_num_key STRING,
item_vrfy_dttm STRING,
fill_vrfy_user_id STRING,
fill_vrfy_dttm STRING,
fill_vrfy_str_nbr STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING,
fill_enter_dttm STRING,
edw_create_dttm STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/cons_etl_tbf0_rx_nucleus_verification_stg'
PARTITIONED BY (
fill_enter_mnth STRING)""")
# COMMAND ----------
migration_data=[{"release": "8.4.3", "scripts": ["D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "D.54.1.wrg.digital__ecom.sql", "T.13716.1.wrg.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_stg.sql", "T.13717.1.wrg.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_sold_dt_stg.sql", "T.13720.1.wrg.wrk_rxo_etl_tbf0_rx_nucleus_verification_prep_stg.sql", "T.13896.1.wrg.wrk_rxo_fl_rx_nucleus_verification_stg.sql", "T.14295.1.wrg.wrk_rxo_rx_nucleus_verification_mod_fill_enter_mnth_stg.sql", "T.14296.1.wrg.wrk_rxo_rx_nucleus_verification_mod_prep_stg.sql", "T.14297.1.wrg.wrk_rxo_rx_nucleus_verification_mod_prep_plus_stg.sql", "T.14298.1.wrg.wrk_rxo_rx_nucleus_verification_mod_process_keys_stg.sql", "T.14299.1.wrg.wrk_rxo_rx_nucleus_verification_new_stg.sql", "T.20018.1.wrg.rx_sms_refill_info_update_records_stg.sql", "T.20019.1.wrg.rx_sms_refill_info_insert_records_stg.sql", "T.20020.1.wrg.rx_sms_refill_info_retained_records_stg.sql", "T.20021.1.wrg.rx_sms_refill_info_temp_stg.sql", "T.20022.1.wrg.rx_sms_refill_info_stg.sql", "T.7461.1.wrg.cons_etl_tbf0_rx_nucleus_verification_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.4.3", "table_id": "T.13716.1", "table_name": "wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.13717.1", "table_name": "wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_sold_dt_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_sold_dt_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_sold_dt", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_nucleus_verification_clean_sold_dt_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.13720.1", "table_name": "wrk_rxo_etl_tbf0_rx_nucleus_verification_prep_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_nucleus_verification_prep_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_rx_nucleus_verification_prep", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_nucleus_verification_prep_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.13896.1", "table_name": "wrk_rxo_fl_rx_nucleus_verification_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_fl_rx_nucleus_verification_stg", "table_legacy_schema": "dae_work.wrk_rxo_fl_rx_nucleus_verification", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_fl_rx_nucleus_verification_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.14295.1", "table_name": "wrk_rxo_rx_nucleus_verification_mod_fill_enter_mnth_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_fill_enter_mnth_stg", "table_legacy_schema": "dae_work.wrk_rxo_rx_nucleus_verification_mod_fill_enter_mnth", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_fill_enter_mnth_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.14296.1", "table_name": "wrk_rxo_rx_nucleus_verification_mod_prep_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_prep_stg", "table_legacy_schema": "dae_work.wrk_rxo_rx_nucleus_verification_mod_prep", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_prep_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.14297.1", "table_name": "wrk_rxo_rx_nucleus_verification_mod_prep_plus_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_prep_plus_stg", "table_legacy_schema": "dae_work.wrk_rxo_rx_nucleus_verification_mod_prep_plus", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_prep_plus_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.14298.1", "table_name": "wrk_rxo_rx_nucleus_verification_mod_process_keys_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_process_keys_stg", "table_legacy_schema": "dae_work.wrk_rxo_rx_nucleus_verification_mod_process_keys", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_mod_process_keys_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.14299.1", "table_name": "wrk_rxo_rx_nucleus_verification_new_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_new_stg", "table_legacy_schema": "dae_work.wrk_rxo_rx_nucleus_verification_new", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_rx_nucleus_verification_new_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.20018.1", "table_name": "rx_sms_refill_info_update_records_stg", "table_schema": "staging__digital__ecom.rx_sms_refill_info_update_records_stg", "table_legacy_schema": "acapetldb.rx_sms_refill_info_update_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_sms_refill_info_update_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.20019.1", "table_name": "rx_sms_refill_info_insert_records_stg", "table_schema": "staging__digital__ecom.rx_sms_refill_info_insert_records_stg", "table_legacy_schema": "acapetldb.rx_sms_refill_info_insert_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_sms_refill_info_insert_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.20020.1", "table_name": "rx_sms_refill_info_retained_records_stg", "table_schema": "staging__digital__ecom.rx_sms_refill_info_retained_records_stg", "table_legacy_schema": "acapetldb.rx_sms_refill_info_retained_records", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_sms_refill_info_retained_records_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.20021.1", "table_name": "rx_sms_refill_info_temp_stg", "table_schema": "staging__digital__ecom.rx_sms_refill_info_temp_stg", "table_legacy_schema": "acapetldb.rx_sms_refill_info_temp", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_sms_refill_info_temp_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.20022.1", "table_name": "rx_sms_refill_info_stg", "table_schema": "staging__digital__ecom.rx_sms_refill_info_stg", "table_legacy_schema": "acapetldb.rx_sms_refill_info_stg", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.rx_sms_refill_info_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.4.3", "table_id": "T.7461.1", "table_name": "cons_etl_tbf0_rx_nucleus_verification_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_rx_nucleus_verification_stg", "table_legacy_schema": "dae_work.cons_etl_tbf0_rx_nucleus_verification", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_rx_nucleus_verification_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

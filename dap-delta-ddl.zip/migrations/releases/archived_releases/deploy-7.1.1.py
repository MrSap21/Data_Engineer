# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_crt_partner_extracts', defaultValue='${STORAGE_ACCT_crt_partner_extracts}', label='STORAGE_ACCT_crt_partner_extracts')
dbutils.widgets.text(name='STORAGE_ACCT_crt_master_data', defaultValue='${STORAGE_ACCT_crt_master_data}', label='STORAGE_ACCT_crt_master_data')
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_marketing', defaultValue='${STORAGE_ACCT_wrg_marketing}', label='STORAGE_ACCT_wrg_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_crt_digital', defaultValue='${STORAGE_ACCT_crt_digital}', label='STORAGE_ACCT_crt_digital')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS master_data__location;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__ccpa;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.contact_hist_ora_reconcilaition(
batch_dttm STRING,
contactdatetime STRING,
planned_contact_date STRING,
campaign_cd STRING,
channel_cd STRING,
packageid STRING,
cellid STRING,
offer_cd STRING,
treatment_id DECIMAL(19,0),
treatment_cd STRING,
contactstatusid STRING,
count STRING,
file_dttm STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_marketing')}.dfs.core.windows.net/marketing/campaign/contact_hist_ora_reconcilaition'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.sa_pat_event_log_camp_phase2_stg(
pharmacypatientid DECIMAL(13,0),
enrollment_status STRING,
status_change_date STRING,
reason_for_unenrollment STRING,
loginname STRING,
usergroup STRING,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_batch_id STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/sa_pat_event_log_camp_phase2_stg'
PARTITIONED BY (
idh_ingestion_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.satr_patient_eligibile_staging2_phase2_stg(
pat_id DECIMAL(13,0),
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_sold_dt STRING,
fill_enter_dt STRING,
fill_days_supply SMALLINT,
drug_id INT,
gpi14 STRING,
inc_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/satr_patient_eligibile_staging2_phase2_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.satr_patient_eligibile_staging3_phase2_stg(
pat_id DECIMAL(13,0),
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT,
rx_partial_fill_nbr INT,
fill_sold_dt STRING,
fill_enter_dt STRING,
fill_days_supply SMALLINT,
drug_id INT,
gpi14 STRING,
inc_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/satr_patient_eligibile_staging3_phase2_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.satr_patient_speciality_stg(
pat_id DECIMAL(13,0),
str_nbr INT,
idh_batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/satr_patient_speciality_stg'
PARTITIONED BY (
rpt_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.satr_pilot_stores_phase2_stg(
str_nbr INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/satr_pilot_stores_phase2_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__ccpa.stg_ccpa_eid_update_stg(
reqst_tkt_nbr STRING,
reqst_tkt_open_dt STRING,
reqst_type_cd STRING,
reqst_tkt_line_seq STRING,
edw_reqst_complete_dt STRING,
reqst_edw_tkt_complete_dt STRING,
reqst_edw_batch_id STRING,
cust_src_id STRING,
cust_src_cd STRING,
prev_edw_rec_end_dt STRING,
curr_edw_rec_end_dt STRING,
cust_src_sk STRING,
prev_cdi_cust_sk STRING,
new_cdi_cust_sk STRING,
prev_cdi_cust_src_id STRING,
curr_cdi_cust_src_id STRING,
prev_mbr_stat_cd STRING,
curr_mbr_stat_cd STRING,
prev_composite_type_cd STRING,
deleted_cdi_composite_type_cd STRING,
prev_cdi_msg_type_cd STRING,
deleted_cdi_msg_type_cd STRING,
linked_to_pharmacy STRING,
edw_update_dttm STRING,
edw_batch_id STRING,
edw_create_dttm STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/ccpa/staging/stg_ccpa_eid_update_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.allocation_email(
member_id STRING,
email_address STRING,
audience_key STRING,
campaign_code STRING,
customer_test_1 STRING,
customer_test_2 STRING,
customer_test_3 STRING,
customer_test_4 STRING,
run_date STRING,
model_score STRING,
seed_ind STRING,
test_holdout_flag STRING,
offer_code_1 STRING,
offer_position_1 STRING,
offer_type_1 STRING,
offer_code_2 STRING,
offer_position_2 STRING,
offer_type_2 STRING,
offer_code_3 STRING,
offer_position_3 STRING,
offer_type_3 STRING,
offer_code_4 STRING,
offer_position_4 STRING,
offer_type_4 STRING,
offer_code_5 STRING,
offer_position_5 STRING,
offer_type_5 STRING,
offer_code_6 STRING,
offer_position_6 STRING,
offer_type_6 STRING,
offer_code_7 STRING,
offer_position_7 STRING,
offer_type_7 STRING,
offer_code_8 STRING,
offer_position_8 STRING,
offer_type_8 STRING,
offer_code_9 STRING,
offer_position_9 STRING,
offer_type_9 STRING,
offer_code_10 STRING,
offer_position_10 STRING,
offer_type_10 STRING,
version_code_1 STRING,
version_code_2 STRING,
campaign_logic STRING,
channel_code STRING,
filler_1 STRING,
filler_2 STRING,
filler_3 STRING,
filler_4 STRING,
filler_5 STRING,
acap_created_dttm TIMESTAMP,
filler_6 STRING,
filler_7 STRING,
filler_8 STRING,
filler_9 STRING,
filler_10 STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/allocation_email'
PARTITIONED BY (
batch_id STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.allocation_email_rp(
member_id STRING,
email_address STRING,
audience_key STRING,
campaign_code STRING,
customer_test_1 STRING,
customer_test_2 STRING,
customer_test_3 STRING,
customer_test_4 STRING,
run_date STRING,
model_score STRING,
seed_ind STRING,
test_holdout_flag STRING,
offer_code_1 STRING,
offer_position_1 STRING,
offer_type_1 STRING,
offer_code_2 STRING,
offer_position_2 STRING,
offer_type_2 STRING,
offer_code_3 STRING,
offer_position_3 STRING,
offer_type_3 STRING,
offer_code_4 STRING,
offer_position_4 STRING,
offer_type_4 STRING,
offer_code_5 STRING,
offer_position_5 STRING,
offer_type_5 STRING,
offer_code_6 STRING,
offer_position_6 STRING,
offer_type_6 STRING,
offer_code_7 STRING,
offer_position_7 STRING,
offer_type_7 STRING,
offer_code_8 STRING,
offer_position_8 STRING,
offer_type_8 STRING,
offer_code_9 STRING,
offer_position_9 STRING,
offer_type_9 STRING,
offer_code_10 STRING,
offer_position_10 STRING,
offer_type_10 STRING,
version_code_1 STRING,
version_code_2 STRING,
campaign_logic STRING,
channel_code STRING,
filler_1 STRING,
filler_2 STRING,
filler_3 STRING,
filler_4 STRING,
filler_5 STRING,
filler_6 STRING,
filler_7 STRING,
filler_8 STRING,
filler_9 STRING,
filler_10 STRING,
filler_11 STRING,
filler_12 STRING,
filler_13 STRING,
filler_14 STRING,
filler_15 STRING,
filler_16 STRING,
filler_17 STRING,
filler_18 STRING,
filler_19 STRING,
filler_20 STRING,
filler_21 STRING,
filler_22 STRING,
filler_23 STRING,
filler_24 STRING,
filler_25 STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/allocation_email_rp'
PARTITIONED BY (
batch_id STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.allocation_points_expiration(
member_id STRING,
email_address STRING,
audience_key STRING,
campaign_code STRING,
customer_test_1 STRING,
customer_test_2 STRING,
customer_test_3 STRING,
customer_test_4 STRING,
run_date STRING,
model_score STRING,
seed_ind STRING,
test_holdout_flag STRING,
offer_code_1 STRING,
offer_position_1 STRING,
offer_type_1 STRING,
offer_code_2 STRING,
offer_position_2 STRING,
offer_type_2 STRING,
offer_code_3 STRING,
offer_position_3 STRING,
offer_type_3 STRING,
offer_code_4 STRING,
offer_position_4 STRING,
offer_type_4 STRING,
offer_code_5 STRING,
offer_position_5 STRING,
offer_type_5 STRING,
offer_code_6 STRING,
offer_position_6 STRING,
offer_type_6 STRING,
offer_code_7 STRING,
offer_position_7 STRING,
offer_type_7 STRING,
offer_code_8 STRING,
offer_position_8 STRING,
offer_type_8 STRING,
offer_code_9 STRING,
offer_position_9 STRING,
offer_type_9 STRING,
offer_code_10 STRING,
offer_position_10 STRING,
offer_type_10 STRING,
version_code_1 STRING,
version_code_2 STRING,
campaign_logic STRING,
channel_code STRING,
filler_1 STRING,
filler_2 STRING,
filler_3 STRING,
filler_4 STRING,
filler_5 STRING,
filler_6 STRING,
filler_7 STRING,
filler_8 STRING,
filler_9 STRING,
filler_10 STRING,
filler_11 STRING,
filler_12 STRING,
filler_13 STRING,
filler_14 STRING,
filler_15 STRING,
filler_16 STRING,
filler_17 STRING,
filler_18 STRING,
filler_19 STRING,
filler_20 STRING,
filler_21 STRING,
filler_22 STRING,
filler_23 STRING,
filler_24 STRING,
filler_25 STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/allocation_points_expiration'
PARTITIONED BY (
batch_id STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS digital__ecom.allocation_senior_day(
member_id STRING,
email_address STRING,
audience_key DECIMAL(18,0),
campaign_code STRING,
customer_test_1 STRING,
customer_test_2 STRING,
customer_test_3 STRING,
customer_test_4 STRING,
run_date STRING,
model_score DECIMAL(6,4),
seed_ind STRING,
test_holdout_flag STRING,
offer_code_1 STRING,
offer_type_1 DECIMAL(6,4),
offer_position_1 DECIMAL(2,0),
offer_code_2 STRING,
offer_type_2 DECIMAL(6,4),
offer_position_2 DECIMAL(2,0),
offer_code_3 STRING,
offer_type_3 DECIMAL(6,4),
offer_position_3 DECIMAL(2,0),
offer_code_4 STRING,
offer_type_4 DECIMAL(6,4),
offer_position_4 DECIMAL(2,0),
offer_code_5 STRING,
offer_type_5 DECIMAL(6,4),
offer_position_5 DECIMAL(2,0),
offer_code_6 STRING,
offer_type_6 DECIMAL(6,4),
offer_position_6 DECIMAL(2,0),
offer_code_7 STRING,
offer_type_7 DECIMAL(6,4),
offer_position_7 DECIMAL(2,0),
offer_code_8 STRING,
offer_type_8 DECIMAL(6,4),
offer_position_8 DECIMAL(2,0),
offer_code_9 STRING,
offer_type_9 DECIMAL(6,4),
offer_position_9 DECIMAL(2,0),
offer_code_10 STRING,
offer_type_10 DECIMAL(6,4),
offer_position_10 DECIMAL(2,0),
version_code_1 STRING,
version_code_2 STRING,
campaign_logic STRING,
channel_code STRING,
filler_1 STRING,
filler_2 STRING,
filler_3 STRING,
filler_4 STRING,
filler_5 STRING,
filler_6 STRING,
filler_7 STRING,
filler_8 STRING,
filler_9 STRING,
filler_10 STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_digital')}.dfs.core.windows.net/digital/ecom/allocation_senior_day'
PARTITIONED BY (
batch_id STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS master_data__location.location_store(
loc_store_chng_sk BIGINT,
loc_store_sk BIGINT,
edw_rec_end_dt DATE,
edw_rec_begin_dt DATE,
store_nbr INT,
loc_id INT,
district_nbr INT,
mdse_demand_group_nbr SMALLINT,
loc_type_cd STRING,
dtr_nbr INT,
propose_fixture_dt DATE,
actl_fixture_dt DATE,
propose_mdse_dt DATE,
actl_mdse_dt DATE,
store_name STRING,
open_24_hrs_dt DATE,
propose_open_dt DATE,
close_dt DATE,
propose_close_dt DATE,
store_tax_id STRING,
store_stat_cd STRING,
str_intersection_desc STRING,
store_fein STRING,
drv_thru_type STRING,
timezone_cd STRING,
dst_ind STRING,
longitude STRING,
latitude STRING,
general_sales_sqft INT,
general_stock_sqft INT,
convenience_sqft INT,
rx_sales_sqft INT,
rx_wait_rm_sales_sqft INT,
liquor_sales_sqft INT,
liquor_stock_sqft INT,
photo_sales_sqft INT,
second_floor_sales_sqft INT,
second_floor_stock_sqft INT,
basement_sales_sqft INT,
basement_stock_sqft INT,
nbr_of_freezer_doors SMALLINT,
nbr_of_cooler_doors SMALLINT,
traffic_light_ind STRING,
traffic_cnt_east_west STRING,
traffic_cnt_north_south STRING,
show_window_type STRING,
propose_possession_dt DATE,
actl_possession_dt DATE,
store_nabp_nbr STRING,
liquor_type STRING,
one_hr_photo_ind STRING,
dstrb_ord_close_dt DATE,
area_security_lvl STRING,
building_dimension STRING,
open_dt DATE,
grand_opening_dt DATE,
legal_corp_id STRING,
legal_corp_name STRING,
ic_store_type_cd STRING,
self_svc_dept_ind STRING,
phrm_dept_ind STRING,
cigarette_dept_ind STRING,
liquor_dept_ind STRING,
convenience_food_dept_ind STRING,
sbu_cd STRING,
peer_grp_nbr STRING,
acquisition_dt DATE,
acquisition_cost_dlrs DECIMAL(12,2),
propose_footings_dt DATE,
actl_footings_dt DATE,
peer_grp_desc STRING,
sbu_environ STRING,
concatenated_addr STRING,
security_lvl STRING,
general_compete_lvl INT,
general_compete_lvl_eff_dt DATE,
light_mgt_company_name STRING,
primary_sign_type STRING,
secondary_sign_type STRING,
tertiary_sign_type STRING,
quaternary_sign_type STRING,
land_cost_dlrs DECIMAL(14,2),
building_cost_dlrs DECIMAL(14,2),
geographic_ad_mkt STRING,
leased_ind STRING,
reit_nbr STRING,
area_security_lvl_cmnt STRING,
local_tax_cd STRING,
establishment_nbr STRING,
photo_inkjet_refill_ind STRING,
photo_printer_paper_company STRING,
complete_punchlist_ind STRING,
expense_dt DATE,
rx_svc_rm_desc STRING,
rx_layout_desc STRING,
rx_in_window_ind STRING,
interchange_ind STRING,
beverage_fixture_type STRING,
acquisition_ind STRING,
greeter_ind STRING,
guard_ind STRING,
propose_leasehold_dt DATE,
actl_leasehold_dt DATE,
rx_compete_lvl INT,
rx_dispenser_type STRING,
rx_dispenser_install_dt DATE,
parking_lot_type STRING,
parking_lot_sz STRING,
free_standing_ind STRING,
estbl_cd STRING,
phrm_dea_nbr STRING,
store_tax_rate DECIMAL(7,6),
tax_calc_type STRING,
print_rpt_ind STRING,
tot_terminal_nbr SMALLINT,
store_rollout_flag_1 STRING,
store_rollout_flag_2 STRING,
sims_conv_dt DATE,
rx_2000_conv_dt DATE,
price_pair_nbr SMALLINT,
price_pair_mkt_fact SMALLINT,
price_pair_min DECIMAL(4,2),
store_block_type SMALLINT,
sims_update_dt DATE,
std_tm_offset SMALLINT,
daylight_tm_offset SMALLINT,
tm_offset_cd SMALLINT,
rph_of_rec_initials STRING,
rph_of_rec_user_id DECIMAL(9,0),
rph_of_rec_first_name STRING,
rph_of_rec_last_name STRING,
rph_label_id STRING,
rph_in_charge_user_id DECIMAL(9,0),
discnt_prof_ind STRING,
discnt_emp_ind STRING,
discnt_sr_ind STRING,
store_inv_movement_cd STRING,
drug_ord_cd STRING,
ctrl_drug_ord_cd STRING,
allow_data_sync_ind STRING,
store_ntt_prompt_nbr INT,
cnt_cells_nbr INT,
precount_nbr INT,
fast_movers_nbr INT,
quick_shelf_nbr INT,
cassette_nbr SMALLINT,
ksu_type STRING,
ksu_software_lvl STRING,
phrm_trunk_qty SMALLINT,
phrm_pbr_trunk_qty SMALLINT,
phrm_fax_trunk_qty SMALLINT,
store_trunk_qty SMALLINT,
cip_conv_dt DATE,
store_preferred_lang_cd STRING,
cip_alternative_lang_cd STRING,
txn_journal_cd STRING,
license STRING,
imaging_ind STRING,
store_rollout_flag_3 STRING,
store_npi_nbr STRING,
store_bc_nbr STRING,
store_medicare_nbr STRING,
store_bs_nbr STRING,
store_upin_nbr STRING,
store_medicaid_nbr STRING,
store_champus_nbr STRING,
store_hlth_ind_nbr STRING,
license_nbr STRING,
license_state STRING,
auto_print_sched_ind STRING,
cnt_mach_type_cd STRING,
scale_ind STRING,
pet_center_ind STRING,
cmpnd_center_ind STRING,
spclty_depot_ind STRING,
rxplus_rollout_ind STRING,
remote_fac_cd STRING,
otc_charge_tax_ind STRING,
cluster_changed_ind STRING,
peg_changed_ind STRING,
rva_workload_balancing_ind STRING,
store_rollout_flag_4 STRING,
remote_data_entry_bal_ind STRING,
thermal_print_ind STRING,
ctrl_substance_rpt_ind STRING,
thermal_label_layout_vers STRING,
center_price_ind STRING,
fax_barcode_ind STRING,
depot_cd STRING,
kpi_hold_tm_threshold INT,
kpi_max_call_hold_tm INT,
store_brand_name STRING,
store_brand_name_desc STRING,
spcl_svc_type STRING,
unit_of_use_nbr INT,
add_instruction_window_ind STRING,
center_ivr_ind STRING,
center_fax_ind STRING,
src_create_dttm TIMESTAMP,
src_create_user_id STRING,
src_update_dttm TIMESTAMP,
src_update_user_id STRING,
ldb_store_type_cd STRING,
rx_image_barcode_ind STRING,
mail_retail_ind STRING,
pos_ctrller_type STRING,
phrm_service_type_cd DECIMAL(2,0),
str_opv_cd STRING,
open_24_hrs_ind STRING,
store_stat_val STRING,
atm_ind STRING,
community_ldr_emp_id DECIMAL(10,0),
relocate_fm_store_nbr INT,
relocate_to_store_nbr INT,
clinic_ind STRING,
acct_loc_id STRING,
edw_create_dttm TIMESTAMP,
edw_update_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0),
delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_master_data')}.dfs.core.windows.net/master_data/location/location_store'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_pat_event_log(
pharmacypatientid DECIMAL(13,0),
enrollment_status STRING,
status_change_date STRING,
reason_for_unenrollment STRING,
loginname STRING,
usergroup STRING,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_batch_id STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/sa_pat_event_log'
PARTITIONED BY (
idh_ingestion_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.sa_rx_event_log(
pharmacypatientid DECIMAL(13,0),
gpi_14 STRING,
rx_nbr_last INT,
clientstoreid_last INT,
fill_sold_dt_last STRING,
fill_days_supply_last INT,
filldisp_nbr_last INT,
refill_remaining_last INT,
copay DECIMAL(8,2),
script_alignment_status STRING,
clientstoreid INT,
sync_date STRING,
sync_cycle_length INT,
loginname STRING,
usergroup STRING,
dspn_fill_nbr SMALLINT,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_batch_id STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://curated@{getArgument('STORAGE_ACCT_crt_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/sa_rx_event_log'
PARTITIONED BY (
idh_ingestion_month STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.patient_adherence_retail_90d_stg(
store_nbr INT,
pat_id DECIMAL(13,0),
rx_nbr INT,
call_type STRING,
drug_adherence_pctg INT,
drug_name STRING,
refills_remain_cnt INT,
third_party_plan_id STRING,
plan_group_nbr STRING,
fnl_disposition_stat STRING,
fnl_disposition_dt STRING,
src_load_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/patient_adherence_retail_90d_stg'
PARTITIONED BY (
idh_load_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.patient_adherence_retail_ltr_stg(
store_nbr INT,
pat_id DECIMAL(13,0),
rx_nbr INT,
call_type STRING,
drug_adherence_pctg INT,
drug_name STRING,
refills_remain_cnt INT,
third_party_plan_id STRING,
plan_group_nbr STRING,
fnl_disposition_stat STRING,
fnl_disposition_dt STRING,
src_load_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/patient_adherence_retail_ltr_stg'
PARTITIONED BY (
idh_load_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.patient_adherence_retail_ntt_stg(
store_nbr INT,
pat_id DECIMAL(13,0),
rx_nbr INT,
call_type STRING,
drug_adherence_pctg INT,
drug_name STRING,
refills_remain_cnt INT,
third_party_plan_id STRING,
plan_group_nbr STRING,
fnl_disposition_stat STRING,
fnl_disposition_dt STRING,
src_load_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/patient_adherence_retail_ntt_stg'
PARTITIONED BY (
idh_load_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.patient_adherence_specialty_90d_stg(
store_nbr INT,
pat_id DECIMAL(13,0),
rx_nbr INT,
call_type STRING,
drug_adherence_pctg INT,
drug_name STRING,
refills_remain_cnt INT,
third_party_plan_id STRING,
plan_group_nbr STRING,
fnl_disposition_stat STRING,
fnl_disposition_dt STRING,
src_load_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/patient_adherence_specialty_90d_stg'
PARTITIONED BY (
idh_load_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.patient_adherence_specialty_ltr_stg(
store_nbr INT,
pat_id DECIMAL(13,0),
rx_nbr INT,
call_type STRING,
drug_adherence_pctg INT,
drug_name STRING,
refills_remain_cnt INT,
third_party_plan_id STRING,
plan_group_nbr STRING,
fnl_disposition_stat STRING,
fnl_disposition_dt STRING,
src_load_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/patient_adherence_specialty_ltr_stg'
PARTITIONED BY (
idh_load_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.patient_adherence_specialty_ntt_stg(
store_nbr INT,
pat_id DECIMAL(13,0),
rx_nbr INT,
call_type STRING,
drug_adherence_pctg INT,
drug_name STRING,
refills_remain_cnt INT,
third_party_plan_id STRING,
plan_group_nbr STRING,
fnl_disposition_stat STRING,
fnl_disposition_dt STRING,
src_load_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/patient_adherence_specialty_ntt_stg'
PARTITIONED BY (
idh_load_dt STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.cmg_satr_eligibility_temp_stg(
pat_id DECIMAL(13,0),
rx_nbr INT,
str_nbr INT,
fill_sold_dt DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/cmg_satr_eligibility_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.cmg_satr_store_lookup_stg(
pat_id DECIMAL(13,0),
str_nbr INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/cmg_satr_store_lookup_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.cmg_satr_tl_prescription_fill_dataset_stg(
pat_id DECIMAL(13,0),
str_nbr INT,
fill_sold_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/cmg_satr_tl_prescription_fill_dataset_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.cmg_satr_tl_prsc_fill_str_filter_dataset_stg(
pat_id DECIMAL(13,0),
str_nbr INT,
fill_sold_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/cmg_satr_tl_prsc_fill_str_filter_dataset_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.compare_oracle_acap_reconciliation_stg(
day_dt STRING,
batch_dttm STRING,
contact_date STRING,
ora_contactdatetime STRING,
planned_contact_date STRING,
ora_planned_contact_date STRING,
campaigncode STRING,
ora_campaign_cd STRING,
channel_cd STRING,
ora_channel_cd STRING,
packageid STRING,
ora_packageid STRING,
cell_id STRING,
ora_cellid STRING,
offer_cd STRING,
ora_offer_cd STRING,
treatment_id STRING,
ora_treatment_id STRING,
contact_status_id STRING,
ora_contactstatusid STRING,
count_val STRING,
oracle_count_val STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/compare_oracle_acap_reconciliation_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.1.1", "scripts": ["D.1.1.crt.partner_extracts__pharmacy_healthcare.sql", "D.12.1.crt.digital__ecom.sql", "D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "D.5.1.crt.marketing__campaign.sql", "D.53.1.wrg.marketing__campaign.sql", "D.9.1.crt.master_data__location.sql", "D.91.1.wrg.retail__ccpa.sql", "T.1119.1.crt.contact_hist_ora_reconcilaition.sql", "T.11428.1.wrg.sa_pat_event_log_camp_phase2_stg.sql", "T.11609.1.wrg.satr_patient_eligibile_staging2_phase2_stg.sql", "T.11615.1.wrg.satr_patient_eligibile_staging3_phase2_stg.sql", "T.11623.1.wrg.satr_patient_speciality_stg.sql", "T.11688.1.wrg.satr_pilot_stores_phase2_stg.sql", "T.11984.1.wrg.stg_ccpa_eid_update_stg.sql", "T.130.1.crt.allocation_email.sql", "T.131.1.crt.allocation_email_rp.sql", "T.133.1.crt.allocation_points_expiration.sql", "T.134.1.crt.allocation_senior_day.sql", "T.1453.1.crt.location_store.sql", "T.1770.1.crt.sa_pat_event_log.sql", "T.1780.1.crt.sa_rx_event_log.sql", "T.19576.1.wrg.patient_adherence_retail_90d_stg.sql", "T.19580.1.wrg.patient_adherence_retail_ltr_stg.sql", "T.19584.1.wrg.patient_adherence_retail_ntt_stg.sql", "T.19587.1.wrg.patient_adherence_specialty_90d_stg.sql", "T.19590.1.wrg.patient_adherence_specialty_ltr_stg.sql", "T.19593.1.wrg.patient_adherence_specialty_ntt_stg.sql", "T.7363.1.wrg.cmg_satr_eligibility_temp_stg.sql", "T.7364.1.wrg.cmg_satr_store_lookup_stg.sql", "T.7366.1.wrg.cmg_satr_tl_prescription_fill_dataset_stg.sql", "T.7368.1.wrg.cmg_satr_tl_prsc_fill_str_filter_dataset_stg.sql", "T.7426.1.wrg.compare_oracle_acap_reconciliation_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.1.1", "table_id": "T.1119.1", "table_name": "contact_hist_ora_reconcilaition", "table_schema": "marketing__campaign.contact_hist_ora_reconcilaition", "table_legacy_schema": "dae_cooked.contact_hist_ora_reconcilaition", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.contact_hist_ora_reconcilaition", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.11428.1", "table_name": "sa_pat_event_log_camp_phase2_stg", "table_schema": "staging__marketing__campaign.sa_pat_event_log_camp_phase2_stg", "table_legacy_schema": "dae_work.sa_pat_event_log_camp_phase2", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.sa_pat_event_log_camp_phase2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.11609.1", "table_name": "satr_patient_eligibile_staging2_phase2_stg", "table_schema": "staging__marketing__campaign.satr_patient_eligibile_staging2_phase2_stg", "table_legacy_schema": "dae_work.satr_patient_eligibile_staging2_phase2", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.satr_patient_eligibile_staging2_phase2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.11615.1", "table_name": "satr_patient_eligibile_staging3_phase2_stg", "table_schema": "staging__marketing__campaign.satr_patient_eligibile_staging3_phase2_stg", "table_legacy_schema": "dae_work.satr_patient_eligibile_staging3_phase2", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.satr_patient_eligibile_staging3_phase2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.11623.1", "table_name": "satr_patient_speciality_stg", "table_schema": "staging__marketing__campaign.satr_patient_speciality_stg", "table_legacy_schema": "dae_work.satr_patient_speciality", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.satr_patient_speciality_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.11688.1", "table_name": "satr_pilot_stores_phase2_stg", "table_schema": "staging__marketing__campaign.satr_pilot_stores_phase2_stg", "table_legacy_schema": "dae_work.satr_pilot_stores_phase2", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.satr_pilot_stores_phase2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.11984.1", "table_name": "stg_ccpa_eid_update_stg", "table_schema": "staging__retail__ccpa.stg_ccpa_eid_update_stg", "table_legacy_schema": "dae_work.stg_ccpa_eid_update", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "staging__retail__ccpa.stg_ccpa_eid_update_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__retail__ccpa", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.130.1", "table_name": "allocation_email", "table_schema": "digital__ecom.allocation_email", "table_legacy_schema": "acapdb.allocation_email", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.allocation_email", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.131.1", "table_name": "allocation_email_rp", "table_schema": "digital__ecom.allocation_email_rp", "table_legacy_schema": "acapdb.allocation_email_rp", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.allocation_email_rp", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.133.1", "table_name": "allocation_points_expiration", "table_schema": "digital__ecom.allocation_points_expiration", "table_legacy_schema": "acapdb.allocation_points_expiration", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.allocation_points_expiration", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.134.1", "table_name": "allocation_senior_day", "table_schema": "digital__ecom.allocation_senior_day", "table_legacy_schema": "acapdb.allocation_senior_day", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "digital__ecom.allocation_senior_day", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "digital__ecom", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.1453.1", "table_name": "location_store", "table_schema": "master_data__location.location_store", "table_legacy_schema": "dae_cooked.location_store", "table_domain": "master_data", "table_subdomain": "location", "table_location": "master_data__location.location_store", "table_partition": "", "table_db": "master_data__location", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.1770.1", "table_name": "sa_pat_event_log", "table_schema": "partner_extracts__pharmacy_healthcare.sa_pat_event_log", "table_legacy_schema": "dae_cooked.sa_pat_event_log", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_pat_event_log", "table_partition": "\n  idh_ingestion_month STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.1780.1", "table_name": "sa_rx_event_log", "table_schema": "partner_extracts__pharmacy_healthcare.sa_rx_event_log", "table_legacy_schema": "dae_cooked.sa_rx_event_log", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.sa_rx_event_log", "table_partition": "\n  idh_ingestion_month STRING", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.19576.1", "table_name": "patient_adherence_retail_90d_stg", "table_schema": "staging__marketing__campaign.patient_adherence_retail_90d_stg", "table_legacy_schema": "dae_raw.patient_adherence_retail_90d", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.patient_adherence_retail_90d_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.19580.1", "table_name": "patient_adherence_retail_ltr_stg", "table_schema": "staging__marketing__campaign.patient_adherence_retail_ltr_stg", "table_legacy_schema": "dae_raw.patient_adherence_retail_ltr", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.patient_adherence_retail_ltr_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.19584.1", "table_name": "patient_adherence_retail_ntt_stg", "table_schema": "staging__marketing__campaign.patient_adherence_retail_ntt_stg", "table_legacy_schema": "dae_raw.patient_adherence_retail_ntt", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.patient_adherence_retail_ntt_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.19587.1", "table_name": "patient_adherence_specialty_90d_stg", "table_schema": "staging__marketing__campaign.patient_adherence_specialty_90d_stg", "table_legacy_schema": "dae_raw.patient_adherence_specialty_90d", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.patient_adherence_specialty_90d_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.19590.1", "table_name": "patient_adherence_specialty_ltr_stg", "table_schema": "staging__marketing__campaign.patient_adherence_specialty_ltr_stg", "table_legacy_schema": "dae_raw.patient_adherence_specialty_ltr", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.patient_adherence_specialty_ltr_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.19593.1", "table_name": "patient_adherence_specialty_ntt_stg", "table_schema": "staging__marketing__campaign.patient_adherence_specialty_ntt_stg", "table_legacy_schema": "dae_raw.patient_adherence_specialty_ntt", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.patient_adherence_specialty_ntt_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.7363.1", "table_name": "cmg_satr_eligibility_temp_stg", "table_schema": "staging__marketing__campaign.cmg_satr_eligibility_temp_stg", "table_legacy_schema": "dae_work.cmg_satr_eligibility_temp", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.cmg_satr_eligibility_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.7364.1", "table_name": "cmg_satr_store_lookup_stg", "table_schema": "staging__marketing__campaign.cmg_satr_store_lookup_stg", "table_legacy_schema": "dae_work.cmg_satr_store_lookup", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.cmg_satr_store_lookup_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.7366.1", "table_name": "cmg_satr_tl_prescription_fill_dataset_stg", "table_schema": "staging__marketing__campaign.cmg_satr_tl_prescription_fill_dataset_stg", "table_legacy_schema": "dae_work.cmg_satr_tl_prescription_fill_dataset", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.cmg_satr_tl_prescription_fill_dataset_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.7368.1", "table_name": "cmg_satr_tl_prsc_fill_str_filter_dataset_stg", "table_schema": "staging__marketing__campaign.cmg_satr_tl_prsc_fill_str_filter_dataset_stg", "table_legacy_schema": "dae_work.cmg_satr_tl_prsc_fill_str_filter_dataset", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.cmg_satr_tl_prsc_fill_str_filter_dataset_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.1", "table_id": "T.7426.1", "table_name": "compare_oracle_acap_reconciliation_stg", "table_schema": "staging__marketing__campaign.compare_oracle_acap_reconciliation_stg", "table_legacy_schema": "dae_work.compare_oracle_acap_reconciliation", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.compare_oracle_acap_reconciliation_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
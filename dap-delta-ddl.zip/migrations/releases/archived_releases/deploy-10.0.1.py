# Databricks notebook source
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
dbutils.widgets.text(name='finance_crt_sa', defaultValue='${finance_crt_sa}', label='finance_crt_sa')
dbutils.widgets.text(name='partner_extracts_crt_sa', defaultValue='${partner_extracts_crt_sa}', label='partner_extracts_crt_sa')
dbutils.widgets.text(name='marketing_crt_sa', defaultValue='${marketing_crt_sa}', label='marketing_crt_sa')
dbutils.widgets.text(name='hr_crt_sa', defaultValue='${hr_crt_sa}', label='hr_crt_sa')
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS marketing__campaign.contact_hist_acap_reconcilaition;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.contact_hist_acap_reconcilaition(
day_dt STRING,
per_id STRING,
contact_date STRING,
planned_contact_date STRING,
campaigncode STRING,
channel_cd STRING,
packageid STRING,
cell_id STRING,
offer_cd STRING,
treatment_id STRING,
contact_status_id STRING,
count_val STRING,
file_dttm STRING)
USING DELTA
LOCATION
'abfss://campaign-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/contact_hist_acap_reconcilaition'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS marketing__campaign.contact_hist_ora_reconcilaition;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.contact_hist_ora_reconcilaition(
batch_dttm STRING,
contactdatetime STRING,
planned_contact_date STRING,
campaign_cd STRING,
channel_cd STRING,
packageid STRING,
cellid STRING,
offer_cd STRING,
treatment_id DECIMAL(19,0),
treatment_cd STRING,
contactstatusid STRING,
count STRING,
file_dttm STRING)
USING DELTA
LOCATION
'abfss://campaign-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/contact_hist_ora_reconcilaition'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__compensation_benefits.activity_details;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__compensation_benefits.activity_details(
activity_id BIGINT,
client_name STRING,
title STRING,
description STRING,
is_team_member_visible STRING,
activity_type STRING,
br_points BIGINT,
offer_code STRING,
affiliation_code STRING,
start_date STRING,
end_date STRING,
logo STRING,
action_text STRING,
action_type STRING,
action_navigation STRING,
confirm_text STRING,
completion_message STRING,
cta_text STRING,
cta_type STRING,
cta_navigation STRING,
insight_id STRING,
sort_rank STRING,
background_color STRING,
acap_created_dttm TIMESTAMP)
USING DELTA
LOCATION
'abfss://compensation-benefits-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/activity_details'""")
# COMMAND ----------
dbutils.fs.rm(f"abfss://account-receivables-bussnstv@{getArgument('finance_crt_sa')}.dfs.core.windows.net/fin_rec_count_check", recurse=True)
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS finance__account_receivables.fin_rec_count_check;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS finance__account_receivables.fin_rec_count_check(
source_name STRING,
table_name STRING,
cur_date DATE,
curr_batch_id STRING,
rule_type STRING,
pre_count BIGINT,
post_count BIGINT,
status STRING)
USING DELTA
LOCATION
'abfss://account-receivables-bussnstv@{getArgument('finance_crt_sa')}.dfs.core.windows.net/fin_rec_count_check'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS hr__recruiting.personalinfo;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS hr__recruiting.personalinfo(
employee_id STRING,
birth_name STRING,
personal_created_by STRING,
personal_created_on STRING,
display_name STRING,
personal_end_date STRING,
first_name STRING,
first_name_alt1 STRING,
gender STRING,
personal_last_modified_by STRING,
personal_last_modified_on STRING,
last_name STRING,
last_name_alt1 STRING,
marital_status STRING,
middle_name_initials STRING,
middle_name_alt1 STRING,
nationality STRING,
native_preferred_language STRING,
salutation STRING,
personal_start_date STRING,
suffix STRING,
personal_portlet_name STRING,
personal_update_flag STRING,
race_ethnicity STRING,
race_code_desc STRING,
veteran_status STRING,
disability_status_from_form_cc305 STRING,
employees_name_given_in_form_cc305 STRING,
submission_date_of_form_cc305 STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://recruiting-pii@{getArgument('hr_crt_sa')}.dfs.core.windows.net/personalinfo'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS partner_extracts__pharmacy_healthcare.missing_demo_profiles_queue;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.missing_demo_profiles_queue(
pat_id STRING,
records_ingest_dt STRING,
src_system STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/missing_demo_profiles_queue'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS partner_extracts__pharmacy_healthcare.omnicell_missing_profile_tracking;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.omnicell_missing_profile_tracking(
pat_id STRING,
removal_dt STRING,
src_system STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/omnicell_missing_profile_tracking'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS marketing__campaign.campaign_resp_cust_encrypt;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS marketing__campaign.campaign_resp_cust_encrypt(
response_id STRING ,
address_1 STRING ,
address_2 STRING ,
age STRING ,
audience_id STRING ,
city STRING ,
dob STRING ,
email_address STRING ,
first_name STRING ,
gender_cd STRING ,
last_name STRING ,
middle_name STRING ,
pat_id STRING ,
phone_1 STRING ,
phone_2 STRING ,
state STRING ,
zip_4 STRING ,
zip_5 STRING ,
update_dttm STRING ,
cust_id STRING ,
rx_nbr STRING ,
call_duration STRING ,
me_id STRING ,
drug_id STRING ,
generic_prod_id STRING ,
src_cd STRING ,
src_id_char STRING ,
create_dttm STRING )
USING DELTA
LOCATION
'abfss://campaign-pii@{getArgument('marketing_crt_sa')}.dfs.core.windows.net/campaign_resp_cust_encrypt'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_current;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_current(
third_party_plan_id STRING,
plan_group_nbr STRING,
plan_type STRING,
ingestion_date STRING,
inc_ind STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/satr_plan_inc_exc_current'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS pharmacy_healthcare__patient_services.cmd_covid_waitlist_sup;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.cmd_covid_waitlist_sup(
eml_addr STRING,
loyalty_mbr_id STRING,
src_id STRING,
src_cd STRING,
news_ltr_subscribe_ind STRING,
photo_subscribe_ind STRING,
spcl_off_subscribe_ind STRING,
wkly_ad_subscribe_ind STRING,
loyalty_subscribe_ind STRING,
sub_date DATE)
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/cmd_covid_waitlist_sup'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_loyalty_mem_emp;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_loyalty_mem_emp(
loyalty_mbr_id STRING)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_loyalty_mem_emp'""")
# COMMAND ----------
spark.sql(f"""DROP TABLE IF EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_pat_data;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_pat_data(
me_id STRING,
therapy STRING,
insight STRING,
cnt BIGINT)
USING DELTA
LOCATION
'abfss://pharmacy-healthcare-phi@{getArgument('partner_extracts_crt_sa')}.dfs.core.windows.net/wrk_car_rx_uce_pat_data'""")
# COMMAND ----------
migration_data=[{"release": "10.0.1", "scripts": ["T.1500.0.crt.missing_demo_profiles_queue.sql", "T.1500.1.crt.missing_demo_profiles_queue.sql", "T.1541.0.crt.omnicell_missing_profile_tracking.sql", "T.1541.1.crt.omnicell_missing_profile_tracking.sql", "T.14378.0.crt.activity_details.sql", "T.14378.1.crt.activity_details.sql", "T.176.0.crt.campaign_resp_cust_encrypt.sql", "T.176.1.crt.campaign_resp_cust_encrypt.sql", "T.1118.0.crt.contact_hist_acap_reconcilaition.sql", "T.1118.1.crt.contact_hist_acap_reconcilaition.sql", "T.1119.0.crt.contact_hist_ora_reconcilaition.sql", "T.1119.1.crt.contact_hist_ora_reconcilaition.sql", "T.1825.0.crt.satr_plan_inc_exc_current.sql", "T.1825.1.crt.satr_plan_inc_exc_current.sql", "T.79.0.crt.wrk_car_rx_uce_loyalty_mem_emp.sql", "T.79.1.crt.wrk_car_rx_uce_loyalty_mem_emp.sql", "T.81.0.crt.wrk_car_rx_uce_pat_data.sql", "T.81.1.crt.wrk_car_rx_uce_pat_data.sql", "T.196.0.crt.cmd_covid_waitlist_sup.sql", "T.196.1.crt.cmd_covid_waitlist_sup.sql", "T.14391.0.crt.fin_rec_count_check.sql", "T.14391.1.crt.fin_rec_count_check.sql", "T.14548.0.crt.personalinfo.sql", "T.14548.1.crt.personalinfo.sql"], "migration_date": "2022-11-04"}]
table_data=[{"release": "10.0.1", "table_id": "T.1500.1", "table_name": "missing_demo_profiles_queue", "table_schema": "partner_extracts__pharmacy_healthcare.missing_demo_profiles_queue", "table_legacy_schema": "dae_cooked.missing_demo_profiles_queue", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.missing_demo_profiles_queue", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.1541.1", "table_name": "omnicell_missing_profile_tracking", "table_schema": "partner_extracts__pharmacy_healthcare.omnicell_missing_profile_tracking", "table_legacy_schema": "dae_cooked.omnicell_missing_profile_tracking", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.omnicell_missing_profile_tracking", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.14378.1", "table_name": "activity_details", "table_schema": "hr__compensation_benefits.activity_details", "table_legacy_schema": "emp_wlns.activity_details", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "hr__compensation_benefits.activity_details", "table_partition": "", "table_db": "hr__compensation_benefits", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.176.1", "table_name": "campaign_resp_cust_encrypt", "table_schema": "marketing__campaign.campaign_resp_cust_encrypt", "table_legacy_schema": "acapdb.campaign_resp_cust_encrypt", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.campaign_resp_cust_encrypt", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.1118.1", "table_name": "contact_hist_acap_reconcilaition", "table_schema": "marketing__campaign.contact_hist_acap_reconcilaition", "table_legacy_schema": "dae_cooked.contact_hist_acap_reconcilaition", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.contact_hist_acap_reconcilaition", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.1119.1", "table_name": "contact_hist_ora_reconcilaition", "table_schema": "marketing__campaign.contact_hist_ora_reconcilaition", "table_legacy_schema": "dae_cooked.contact_hist_ora_reconcilaition", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "marketing__campaign.contact_hist_ora_reconcilaition", "table_partition": "", "table_db": "marketing__campaign", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.1825.1", "table_name": "satr_plan_inc_exc_current", "table_schema": "partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_current", "table_legacy_schema": "dae_cooked.satr_plan_inc_exc_current", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.satr_plan_inc_exc_current", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.79.1", "table_name": "wrk_car_rx_uce_loyalty_mem_emp", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_loyalty_mem_emp", "table_legacy_schema": "acapcar.wrk_car_rx_uce_loyalty_mem_emp", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_loyalty_mem_emp", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.81.1", "table_name": "wrk_car_rx_uce_pat_data", "table_schema": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_pat_data", "table_legacy_schema": "acapcar.wrk_car_rx_uce_pat_data", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "partner_extracts__pharmacy_healthcare.wrk_car_rx_uce_pat_data", "table_partition": "", "table_db": "partner_extracts__pharmacy_healthcare", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.196.1", "table_name": "cmd_covid_waitlist_sup", "table_schema": "pharmacy_healthcare__patient_services.cmd_covid_waitlist_sup", "table_legacy_schema": "acapdb.cmd_covid_waitlist_sup", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.cmd_covid_waitlist_sup", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.14391.1", "table_name": "fin_rec_count_check", "table_schema": "finance__account_receivables.fin_rec_count_check", "table_legacy_schema": "fin_cooked.fin_rec_count_check", "table_domain": "finance", "table_subdomain": "account_receivables", "table_location": "finance__account_receivables.fin_rec_count_check", "table_partition": "", "table_db": "finance__account_receivables", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}, {"release": "10.0.1", "table_id": "T.14548.1", "table_name": "personalinfo", "table_schema": "hr__recruiting.personalinfo", "table_legacy_schema": "hr_cooked.personalinfo", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "hr__recruiting.personalinfo", "table_partition": "", "table_db": "hr__recruiting", "table_zone": "curated", "create_date": "2022-11-04 19:48:06", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.','missing_demo_profiles_queue','omnicell_missing_profile_tracking','activity_details','campaign_resp_cust_encrypt','contact_hist_acap_reconcilaition','contact_hist_ora_reconcilaition','satr_plan_inc_exc_current','wrk_car_rx_uce_loyalty_mem_emp','wrk_car_rx_uce_pat_data','cmd_covid_waitlist_sup','fin_rec_count_check','personalinfo');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
# %sql
# MERGE INTO  master_data__information_schema.databricks_table_catalog tables
#     USING temp_catalog new
#     ON tables.table_schema = new.table_schema AND tables.table_name = new.table_name
# WHEN MATCHED THEN
#     UPDATE SET
#         tables.table_schema = new.table_schema,
#         tables.table_database = new.table_database,
#         tables.table_legacy_schema = new.table_legacy_schema
#         tables.table_name = new.table_name,
#         tables.table_domain = new.table_domain,
#         tables.table_subdomain = new.table_subdomain,
#         tables.table_data_class = new.table_data_class,
#         tables.table_location = new.table_location,
#         tables.table_partition = new.table_partition,
#         tables.table_zone = new.table_zone,
#         tables.create_date = tables.create_date
#         tables.update_date = current_timestamp()
# WHEN NOT MATCHED THEN
#     INSERT 
#         new.table_schema,
#         new.table_database,
#         new.table_name,
#         new.table_legacy_schema,
#         new.table_domain,
#         new.table_subdomain,
#         new.table_data_class,
#         new.table_location,
#         new.table_partition,
#         new.table_zone,
#         new.create_date,
#         new.update_date
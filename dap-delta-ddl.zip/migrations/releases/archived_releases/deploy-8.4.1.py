# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_partner_extracts', defaultValue='${STORAGE_ACCT_wrg_partner_extracts}', label='STORAGE_ACCT_wrg_partner_extracts')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patient_client_file_stg(
pharmacypatientid STRING,
patientstatus STRING,
idh_ingestion_time STRING,
tracking_id STRING,
srcfilename STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patient_client_file_stg'
PARTITIONED BY (
idh_ingestion_dt STRING)""")
# COMMAND ----------
migration_data=[{"release": "8.4.1", "scripts": ["D.39.1.wrg.partner_extracts__pharmacy_healthcare.sql", "T.19737.1.wrg.satr_patient_client_file_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.4.1", "table_id": "T.19737.1", "table_name": "satr_patient_client_file_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patient_client_file_stg", "table_legacy_schema": "dae_raw.satr_patient_client_file", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patient_client_file_stg", "table_partition": "\n  idh_ingestion_dt STRING", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

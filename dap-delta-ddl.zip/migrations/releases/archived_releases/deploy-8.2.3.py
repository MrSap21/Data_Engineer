# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_crt_marketing', defaultValue='${STORAGE_ACCT_crt_marketing}', label='STORAGE_ACCT_crt_marketing')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_partner_extracts', defaultValue='${STORAGE_ACCT_wrg_partner_extracts}', label='STORAGE_ACCT_wrg_partner_extracts')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS marketing__loyalty;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.sa_rx_event_log_stg(
pharmacypatientid DECIMAL(13,0),
gpi_14 STRING,
rx_nbr_last INT,
clientstoreid_last INT,
fill_sold_dt_last STRING,
fill_days_supply_last INT,
filldisp_nbr_last INT,
refill_remaining_last INT,
copay DECIMAL(8,2),
script_alignment_status STRING,
clientstoreid INT,
sync_date STRING,
sync_cycle_length INT,
loginname STRING,
usergroup STRING,
dspn_fill_nbr SMALLINT,
tracking_id STRING,
idh_ingestion_dt STRING,
idh_ingestion_time STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/sa_rx_event_log_stg'
PARTITIONED BY (
idh_ingestion_month STRING)""")
# COMMAND ----------
migration_data=[{"release": "8.2.3", "scripts": ["D.15.1.crt.marketing__loyalty.sql", "D.39.1.wrg.partner_extracts__pharmacy_healthcare.sql", "T.19699.1.wrg.sa_rx_event_log_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.2.3", "table_id": "T.19699.1", "table_name": "sa_rx_event_log_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.sa_rx_event_log_stg", "table_legacy_schema": "dae_raw.sa_rx_event_log", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.sa_rx_event_log_stg", "table_partition": "\n  idh_ingestion_month STRING", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

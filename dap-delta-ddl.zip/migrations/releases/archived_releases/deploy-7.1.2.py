# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
dbutils.widgets.text(name='STORAGE_ACCT_crt_digital', defaultValue='${STORAGE_ACCT_crt_digital}', label='STORAGE_ACCT_crt_digital')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__retail_sales;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__retail_sales;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__organization_structure;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__organization_structure;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.cust_lineofbusiness_stg(
update_flag STRING,
effective_start_date STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_description_default_value STRING,
cust_description_en_us STRING,
cust_description_localized STRING,
cust_effective_status STRING,
cust_head_of_unit STRING,
cust_parent_lob STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_effective_end_date STRING,
mdf_system_record_status STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/cust_lineofbusiness_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fobusinessunit_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_parent_of_business_unit STRING,
cust_to_department_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_defaultvalue STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fobusinessunit_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.jobclassificationusa_stg(
update_flag STRING,
external_code STRING,
job_classification_country_country STRING,
job_classification_effective_start_date STRING,
job_classification_external_code STRING,
created_by STRING,
created_date_time STRING,
cust_census_code STRING,
cust_standard_code STRING,
eeo1_job_category STRING,
eeo4_job_category STRING,
eeo5_job_category STRING,
eeo6_job_category STRING,
eeo_job_group STRING,
flsa_status_usa STRING,
last_modified_by STRING,
last_modified_date_time STRING,
local_job_title STRING,
mdf_system_record_status STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/jobclassificationusa_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.phone_stg(
update_flag STRING,
employee_id STRING,
phone_type STRING,
area_code STRING,
country_code STRING,
created_by STRING,
created_on STRING,
extension STRING,
is_primary STRING,
last_modified_by STRING,
last_modified_on STRING,
phone_number STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/phone_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.cust_lineofbusiness_delta_stg(
update_flag STRING,
effective_start_date STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_description_default_value STRING,
cust_description_en_us STRING,
cust_description_localized STRING,
cust_effective_status STRING,
cust_head_of_unit STRING,
cust_parent_lob STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_effective_end_date STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/cust_lineofbusiness_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.cust_lineofbusiness_unchanged_stg(
update_flag STRING,
effective_start_date STRING,
external_code STRING,
created_by STRING,
created_date_time STRING,
cust_description_default_value STRING,
cust_description_en_us STRING,
cust_description_localized STRING,
cust_effective_status STRING,
cust_head_of_unit STRING,
cust_parent_lob STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_effective_end_date STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/cust_lineofbusiness_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fobusinessunit_delta_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_parent_of_business_unit STRING,
cust_to_department_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_defaultvalue STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fobusinessunit_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fobusinessunit_persistent_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_parent_of_business_unit STRING,
cust_to_department_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_defaultvalue STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fobusinessunit_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fobusinessunit_unchanged_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_parent_of_business_unit STRING,
cust_to_department_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_defaultvalue STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fobusinessunit_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.jobclassificationusa_delta_stg(
update_flag STRING,
external_code STRING,
job_classification_country_country STRING,
job_classification_effective_start_date STRING,
job_classification_external_code STRING,
created_by STRING,
created_date_time STRING,
cust_census_code STRING,
cust_standard_code STRING,
eeo1_job_category STRING,
eeo4_job_category STRING,
eeo5_job_category STRING,
eeo6_job_category STRING,
eeo_job_group STRING,
flsa_status_usa STRING,
last_modified_by STRING,
last_modified_date_time STRING,
local_job_title STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/jobclassificationusa_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.jobclassificationusa_unchanged_stg(
update_flag STRING,
external_code STRING,
job_classification_country_country STRING,
job_classification_effective_start_date STRING,
job_classification_external_code STRING,
created_by STRING,
created_date_time STRING,
cust_census_code STRING,
cust_standard_code STRING,
eeo1_job_category STRING,
eeo4_job_category STRING,
eeo5_job_category STRING,
eeo6_job_category STRING,
eeo_job_group STRING,
flsa_status_usa STRING,
last_modified_by STRING,
last_modified_date_time STRING,
local_job_title STRING,
mdf_system_record_status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/jobclassificationusa_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.phone_delta_stg(
update_flag STRING,
employee_id STRING,
phone_type STRING,
area_code STRING,
country_code STRING,
created_by STRING,
created_on STRING,
extension STRING,
is_primary STRING,
last_modified_by STRING,
last_modified_on STRING,
phone_number STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/phone_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__recruiting.phone_unchanged_stg(
update_flag STRING,
employee_id STRING,
phone_type STRING,
area_code STRING,
country_code STRING,
created_by STRING,
created_on STRING,
extension STRING,
is_primary STRING,
last_modified_by STRING,
last_modified_on STRING,
phone_number STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/recruiting/staging/phone_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.global_branding_pos_basket_stg(
transaction_date STRING,
transaction_time STRING,
transaction_number STRING,
store_number STRING,
loyalty_card_number STRING,
mid STRING,
card_id STRING,
item_total_quantity STRING,
gross_sales_amount STRING,
reduction_total_amount STRING,
ewic_wic_ind STRING,
ebt_ind STRING,
idh_load_dt STRING,
sequence_nbr STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/global_branding_pos_basket_stg'
PARTITIONED BY (
extract_date STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.global_branding_pos_transaction_stg(
transaction_date STRING,
transaction_time STRING,
transaction_number STRING,
store_number STRING,
loyalty_card_number STRING,
mid STRING,
card_id STRING,
upc STRING,
wic STRING,
retailer_product_identifier STRING,
item_list_price STRING,
item_net_price STRING,
item_quantity STRING,
weighted_item_weight STRING,
weighted_item_count STRING,
item_deal_quantity STRING,
item_sale_quantity STRING,
item_net_amount STRING,
item_gross_amount STRING,
return_indicator STRING,
cost_dlrs STRING,
cost_adj_dlrs STRING,
loyalty_cost_adj_dlrs STRING,
gross_profit STRING,
sale_ind STRING,
idh_load_dt STRING,
sequence_nbr STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/global_branding_pos_transaction_stg'
PARTITIONED BY (
extract_date STRING)""")
# COMMAND ----------
migration_data=[{"release": "7.1.2", "scripts": ["D.12.1.crt.digital__ecom.sql", "D.16.1.crt.retail__retail_sales.sql", "D.50.1.wrg.retail__retail_sales.sql", "D.56.1.wrg.hr__recruiting.sql", "D.61.1.crt.hr__organization_structure.sql", "D.63.1.crt.hr__recruiting.sql", "D.68.1.wrg.hr__organization_structure.sql", "T.14621.1.wrg.cust_lineofbusiness_stg.sql", "T.14699.1.wrg.fobusinessunit_stg.sql", "T.14718.1.wrg.jobclassificationusa_stg.sql", "T.14743.1.wrg.phone_stg.sql", "T.14839.1.wrg.cust_lineofbusiness_delta_stg.sql", "T.14841.1.wrg.cust_lineofbusiness_unchanged_stg.sql", "T.14980.1.wrg.fobusinessunit_delta_stg.sql", "T.14981.1.wrg.fobusinessunit_persistent_stg.sql", "T.14982.1.wrg.fobusinessunit_unchanged_stg.sql", "T.15059.1.wrg.jobclassificationusa_delta_stg.sql", "T.15061.1.wrg.jobclassificationusa_unchanged_stg.sql", "T.15172.1.wrg.phone_delta_stg.sql", "T.15174.1.wrg.phone_unchanged_stg.sql", "T.19522.1.wrg.global_branding_pos_basket_stg.sql", "T.19527.1.wrg.global_branding_pos_transaction_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.1.2", "table_id": "T.14621.1", "table_name": "cust_lineofbusiness_stg", "table_schema": "staging__hr__organization_structure.cust_lineofbusiness_stg", "table_legacy_schema": "hr_raw.cust_lineofbusiness", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.cust_lineofbusiness_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.14699.1", "table_name": "fobusinessunit_stg", "table_schema": "staging__hr__organization_structure.fobusinessunit_stg", "table_legacy_schema": "hr_raw.fobusinessunit", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fobusinessunit_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.14718.1", "table_name": "jobclassificationusa_stg", "table_schema": "staging__hr__organization_structure.jobclassificationusa_stg", "table_legacy_schema": "hr_raw.jobclassificationusa", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.jobclassificationusa_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.14743.1", "table_name": "phone_stg", "table_schema": "staging__hr__recruiting.phone_stg", "table_legacy_schema": "hr_raw.phone", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.phone_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.14839.1", "table_name": "cust_lineofbusiness_delta_stg", "table_schema": "staging__hr__organization_structure.cust_lineofbusiness_delta_stg", "table_legacy_schema": "hr_work.cust_lineofbusiness_delta", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.cust_lineofbusiness_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.14841.1", "table_name": "cust_lineofbusiness_unchanged_stg", "table_schema": "staging__hr__organization_structure.cust_lineofbusiness_unchanged_stg", "table_legacy_schema": "hr_work.cust_lineofbusiness_unchanged", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.cust_lineofbusiness_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.14980.1", "table_name": "fobusinessunit_delta_stg", "table_schema": "staging__hr__organization_structure.fobusinessunit_delta_stg", "table_legacy_schema": "hr_work.fobusinessunit_delta", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fobusinessunit_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.14981.1", "table_name": "fobusinessunit_persistent_stg", "table_schema": "staging__hr__organization_structure.fobusinessunit_persistent_stg", "table_legacy_schema": "hr_work.fobusinessunit_persistent", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fobusinessunit_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.14982.1", "table_name": "fobusinessunit_unchanged_stg", "table_schema": "staging__hr__organization_structure.fobusinessunit_unchanged_stg", "table_legacy_schema": "hr_work.fobusinessunit_unchanged", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fobusinessunit_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.15059.1", "table_name": "jobclassificationusa_delta_stg", "table_schema": "staging__hr__organization_structure.jobclassificationusa_delta_stg", "table_legacy_schema": "hr_work.jobclassificationusa_delta", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.jobclassificationusa_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.15061.1", "table_name": "jobclassificationusa_unchanged_stg", "table_schema": "staging__hr__organization_structure.jobclassificationusa_unchanged_stg", "table_legacy_schema": "hr_work.jobclassificationusa_unchanged", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.jobclassificationusa_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.15172.1", "table_name": "phone_delta_stg", "table_schema": "staging__hr__recruiting.phone_delta_stg", "table_legacy_schema": "hr_work.phone_delta", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.phone_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.15174.1", "table_name": "phone_unchanged_stg", "table_schema": "staging__hr__recruiting.phone_unchanged_stg", "table_legacy_schema": "hr_work.phone_unchanged", "table_domain": "hr", "table_subdomain": "recruiting", "table_location": "staging__hr__recruiting.phone_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__recruiting", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.19522.1", "table_name": "global_branding_pos_basket_stg", "table_schema": "staging__retail__retail_sales.global_branding_pos_basket_stg", "table_legacy_schema": "dae_raw.global_branding_pos_basket", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.global_branding_pos_basket_stg", "table_partition": "\n  extract_date STRING", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.2", "table_id": "T.19527.1", "table_name": "global_branding_pos_transaction_stg", "table_schema": "staging__retail__retail_sales.global_branding_pos_transaction_stg", "table_legacy_schema": "dae_raw.global_branding_pos_transaction", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.global_branding_pos_transaction_stg", "table_partition": "\n  extract_date STRING", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
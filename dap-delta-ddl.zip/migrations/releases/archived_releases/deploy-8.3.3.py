# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.peap_application_status_stg(
student_id STRING,
application_id STRING,
application_status STRING,
status_date STRING,
award_loc_number STRING,
award_loc_type STRING,
override_ind STRING,
award_amount STRING,
corp_amount STRING,
district_amount STRING,
ret_check_type STRING,
check_number STRING,
award_amt_returned STRING,
district_change_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
check_id STRING,
update_date_appl_status STRING,
update_userid STRING,
update_date STRING,
create_userid STRING,
create_date STRING,
action_flag STRING,
original_create_date STRING,
original_update_date STRING,
tracking_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/peap_application_status_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.peap_student_application_detail_stg(
student_id STRING,
application_id STRING,
program_id STRING,
agreement_id STRING,
program_type STRING,
award_loc_number STRING,
award_loc_type STRING,
award_number STRING,
scholarship_year STRING,
did_not_agree_ind STRING,
application_status STRING,
status_date STRING,
work_willingness STRING,
defined_location STRING,
commitment_reqd STRING,
commitment_compl STRING,
pre_pharm_course_name STRING,
pre_pharm_start_date STRING,
pre_pharm_end_date STRING,
district_change_ind STRING,
switch_pgm_ind STRING,
exception_award_entry STRING,
pharmacy_acceptance STRING,
pre_pharm_1040 STRING,
tutiion_receipt STRING,
active_flag STRING,
pre_pharm_worked_ind STRING,
pharm_worked_ind STRING,
pre_pharm_amount_ind STRING,
stage STRING,
award_amount_type STRING,
reject_reason STRING,
award_amount STRING,
year_at_school STRING,
applied_date STRING,
approval_ind STRING,
rejected_ind STRING,
withdrawn_ind STRING,
check_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
dist_amount STRING,
employee_verification STRING,
prior_applicant STRING,
invoice_id STRING,
location_name STRING,
spanish_fluency_ind STRING,
update_date_stu_appl STRING,
update_userid STRING,
update_date STRING,
create_userid STRING,
create_date STRING,
action_flag STRING,
original_create_date STRING,
original_update_date STRING,
tracking_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/peap_student_application_detail_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.peap_student_profile_stg(
student_id STRING,
first_name STRING,
last_name STRING,
middle_initial STRING,
ssn STRING,
home_address_1 STRING,
home_address_2 STRING,
home_city STRING,
home_state STRING,
home_zip_1 STRING,
home_zip_2 STRING,
home_country STRING,
country_code STRING,
home_phone STRING,
cell_phone STRING,
email STRING,
school_address_1 STRING,
school_address_2 STRING,
school_city STRING,
school_state STRING,
school_zip_1 STRING,
school_zip_2 STRING,
school_phone STRING,
preferred_address STRING,
email_preference STRING,
page_number STRING,
address_ind STRING,
last_worked_loc_nbr STRING,
location_entry_ind STRING,
last_worked_year STRING,
last_worked_loc_type STRING,
cop_code STRING,
cop_start_date STRING,
expect_grad_date STRING,
altered_grad_date STRING,
min_grad_date STRING,
max_grad_date STRING,
year_at_school STRING,
alt_year_at_school STRING,
pharm_degree_type STRING,
alt_pharm_degree_type STRING,
min_stay_thru_date STRING,
max_stay_thru_date STRING,
act_stay_thru_date STRING,
registration_status STRING,
employee_status STRING,
student_status STRING,
cur_yr_award_status STRING,
cur_award_stat_date STRING,
exception_ind STRING,
commitment_status STRING,
commitment_stat_date STRING,
reg_pharm_date STRING,
employee_start_date STRING,
intern_start_date STRING,
position_code STRING,
work_ver_system STRING,
work_ver_appl STRING,
realigned_ind STRING,
total_commitment STRING,
profile_compl_date STRING,
eligibility_status STRING,
app_year_at_school STRING,
collections_ind STRING,
remainder_ind STRING,
preferred_phone STRING,
pph_closed_appl_ind STRING,
update_date_student_profile STRING,
update_userid STRING,
update_date STRING,
create_userid STRING,
create_date STRING,
action_flag STRING,
original_create_date STRING,
original_update_date STRING,
tracking_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/peap_student_profile_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.app_status_student_app_detail_matched_stg(
employee_id STRING,
scholarship_desc STRING,
school_key STRING,
application_id STRING,
check_nbr STRING,
check_amt STRING,
check_status STRING,
relinquishment_amt STRING,
corp_monies_charged STRING,
district_monies_charged STRING,
budget_credit_amt STRING,
award_nbr STRING,
payment_type STRING,
scholarship_year STRING,
status_date DATE,
scholarship_award_type STRING,
period_key STRING,
cd_key STRING,
scholarship_comments_ind STRING,
loc_id STRING,
location STRING,
position STRING,
school_phone_nbr STRING,
expect_grad_year STRING,
pharmacy_assoc_1 STRING,
scholarship_eligibility_status STRING,
stay_through_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/app_status_student_app_detail_matched_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.app_status_student_app_detail_sort_stg(
employee_id STRING,
scholarship_desc STRING,
school_key STRING,
application_id STRING,
check_nbr STRING,
check_amt STRING,
check_status STRING,
relinquishment_amt STRING,
corp_monies_charged STRING,
district_monies_charged STRING,
budget_credit_amt STRING,
award_nbr STRING,
payment_type STRING,
scholarship_year STRING,
status_date DATE,
scholarship_award_type STRING,
period_key STRING,
cd_key STRING,
scholarship_comments_ind STRING,
location STRING,
position STRING,
school_phone_nbr STRING,
expect_grad_year STRING,
pharmacy_assoc_1 STRING,
scholarship_eligibility_status STRING,
stay_through_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/app_status_student_app_detail_sort_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.application_status_intm_current_stg(
student_id STRING,
application_id STRING,
application_status STRING,
status_date DATE,
award_loc_number STRING,
award_loc_type STRING,
override_ind STRING,
award_amount STRING,
corp_amount STRING,
district_amount STRING,
ret_check_type STRING,
check_number STRING,
award_amt_returned STRING,
district_change_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
create_userid STRING,
create_date STRING,
update_userid STRING,
update_date STRING,
check_id STRING,
batch_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/application_status_intm_current_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.application_status_intm_current_new_stg(
student_id STRING,
application_id STRING,
application_status STRING,
status_date DATE,
award_loc_number STRING,
award_loc_type STRING,
override_ind STRING,
award_amount STRING,
corp_amount STRING,
district_amount STRING,
ret_check_type STRING,
check_number STRING,
award_amt_returned STRING,
district_change_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
create_userid STRING,
create_date STRING,
update_userid STRING,
update_date STRING,
check_id STRING,
batch_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/application_status_intm_current_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.application_status_persistent_stg(
student_id STRING,
application_id STRING,
application_status STRING,
status_date DATE,
award_loc_number STRING,
award_loc_type STRING,
override_ind STRING,
award_amount STRING,
corp_amount STRING,
district_amount STRING,
ret_check_type STRING,
check_number STRING,
award_amt_returned STRING,
district_change_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
create_userid STRING,
create_date STRING,
update_userid STRING,
update_date STRING,
check_id STRING,
batch_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/application_status_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.code_decode_temp_stg(
code STRING,
code_type STRING,
decode STRING,
status_ind STRING,
create_userid STRING,
create_date STRING,
update_userid STRING,
update_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/code_decode_temp_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fct_schloralship_details_app_detl_stg(
school_key BIGINT,
payment_type STRING,
scholarship_award_type STRING,
period_key BIGINT,
application_id BIGINT,
employee_id BIGINT,
scholarship_desc STRING,
check_nbr STRING,
check_amt DECIMAL(7,2),
check_status STRING,
relinquishment_amt DECIMAL(9,2),
corp_monies_charged DECIMAL(7,2),
district_monies_charged DECIMAL(7,2),
budget_credit_amt DECIMAL(7,2),
location STRING,
position STRING,
status_date DATE,
cd_key BIGINT,
scholarship_year INT,
award_nbr INT,
scholarship_comments_ind STRING,
school_phone_nbr STRING,
expect_grad_year DATE,
pharmacy_assoc_1 STRING,
scholarship_eligibility_status STRING,
stay_through_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fct_schloralship_details_app_detl_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fct_schloralship_dtl_std_app_detl_stg(
school_key BIGINT,
payment_type STRING,
scholarship_award_type STRING,
period_key BIGINT,
application_id BIGINT,
employee_id BIGINT,
scholarship_desc STRING,
check_nbr STRING,
check_amt DECIMAL(7,2),
check_status STRING,
relinquishment_amt DECIMAL(9,2),
corp_monies_charged DECIMAL(7,2),
district_monies_charged DECIMAL(7,2),
budget_credit_amt DECIMAL(7,2),
location STRING,
position STRING,
status_date DATE,
cd_key BIGINT,
scholarship_year INT,
award_nbr INT,
scholarship_comments_ind STRING,
school_phone_nbr STRING,
expect_grad_year DATE,
pharmacy_assoc_1 STRING,
scholarship_eligibility_status STRING,
stay_through_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fct_schloralship_dtl_std_app_detl_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fct_schloralship_dtl_std_profile_stg(
school_key BIGINT,
payment_type STRING,
scholarship_award_type STRING,
period_key BIGINT,
application_id BIGINT,
employee_id BIGINT,
scholarship_desc STRING,
check_nbr STRING,
check_amt DECIMAL(7,2),
check_status STRING,
relinquishment_amt DECIMAL(9,2),
corp_monies_charged DECIMAL(7,2),
district_monies_charged DECIMAL(7,2),
budget_credit_amt DECIMAL(7,2),
location STRING,
position STRING,
status_date DATE,
cd_key BIGINT,
scholarship_year INT,
award_nbr INT,
scholarship_comments_ind STRING,
school_phone_nbr STRING,
expect_grad_year DATE,
pharmacy_assoc_1 STRING,
scholarship_eligibility_status STRING,
stay_through_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fct_schloralship_dtl_std_profile_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_app_dtl_intm_current_stg(
student_id STRING,
application_id INT,
program_id INT,
agreement_id INT,
program_type STRING,
award_loc_number INT,
award_loc_type STRING,
award_number INT,
scholarship_year INT,
did_not_agree_ind STRING,
application_status INT,
status_date DATE,
work_willingness STRING,
defined_location STRING,
commitment_reqd INT,
commitment_compl INT,
pre_pharm_course_name STRING,
pre_pharm_start_date DATE,
pre_pharm_end_date DATE,
district_change_ind STRING,
switch_pgm_ind STRING,
exception_award_entry STRING,
pharmacy_acceptance STRING,
pre_pharm_1040 STRING,
tutiion_receipt STRING,
active_flag STRING,
pre_pharm_worked_ind STRING,
pharm_worked_ind STRING,
pre_pharm_amount_ind STRING,
stage STRING,
award_amount_type STRING,
reject_reason STRING,
award_amount INT,
create_userid STRING,
create_date DATE,
update_userid STRING,
update_date DATE,
year_at_school INT,
applied_date DATE,
approval_ind STRING,
rejected_ind STRING,
withdrawn_ind STRING,
check_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
dist_amount INT,
employee_verification STRING,
prior_applicant STRING,
invoice_id STRING,
location_name STRING,
spanish_fluency_ind STRING,
batch_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_app_dtl_intm_current_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_app_dtl_intm_current_new_stg(
student_id STRING,
application_id INT,
program_id INT,
agreement_id INT,
program_type STRING,
award_loc_number INT,
award_loc_type STRING,
award_number INT,
scholarship_year INT,
did_not_agree_ind STRING,
application_status INT,
status_date DATE,
work_willingness STRING,
defined_location STRING,
commitment_reqd INT,
commitment_compl INT,
pre_pharm_course_name STRING,
pre_pharm_start_date DATE,
pre_pharm_end_date DATE,
district_change_ind STRING,
switch_pgm_ind STRING,
exception_award_entry STRING,
pharmacy_acceptance STRING,
pre_pharm_1040 STRING,
tutiion_receipt STRING,
active_flag STRING,
pre_pharm_worked_ind STRING,
pharm_worked_ind STRING,
pre_pharm_amount_ind STRING,
stage STRING,
award_amount_type STRING,
reject_reason STRING,
award_amount INT,
create_userid STRING,
create_date DATE,
update_userid STRING,
update_date DATE,
year_at_school INT,
applied_date DATE,
approval_ind STRING,
rejected_ind STRING,
withdrawn_ind STRING,
check_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
dist_amount INT,
employee_verification STRING,
prior_applicant STRING,
invoice_id STRING,
location_name STRING,
spanish_fluency_ind STRING,
batch_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_app_dtl_intm_current_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_app_dtl_intm_current_unchanged_stg(
student_id STRING,
application_id INT,
program_id INT,
agreement_id INT,
program_type STRING,
award_loc_number INT,
award_loc_type STRING,
award_number INT,
scholarship_year INT,
did_not_agree_ind STRING,
application_status INT,
status_date DATE,
work_willingness STRING,
defined_location STRING,
commitment_reqd INT,
commitment_compl INT,
pre_pharm_course_name STRING,
pre_pharm_start_date DATE,
pre_pharm_end_date DATE,
district_change_ind STRING,
switch_pgm_ind STRING,
exception_award_entry STRING,
pharmacy_acceptance STRING,
pre_pharm_1040 STRING,
tutiion_receipt STRING,
active_flag STRING,
pre_pharm_worked_ind STRING,
pharm_worked_ind STRING,
pre_pharm_amount_ind STRING,
stage STRING,
award_amount_type STRING,
reject_reason STRING,
award_amount INT,
create_userid STRING,
create_date DATE,
update_userid STRING,
update_date DATE,
year_at_school INT,
applied_date DATE,
approval_ind STRING,
rejected_ind STRING,
withdrawn_ind STRING,
check_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
dist_amount INT,
employee_verification STRING,
prior_applicant STRING,
invoice_id STRING,
location_name STRING,
spanish_fluency_ind STRING,
batch_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_app_dtl_intm_current_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_app_dtl_intm_current_updated_stg(
student_id STRING,
application_id INT,
program_id INT,
agreement_id INT,
program_type STRING,
award_loc_number INT,
award_loc_type STRING,
award_number INT,
scholarship_year INT,
did_not_agree_ind STRING,
application_status INT,
status_date DATE,
work_willingness STRING,
defined_location STRING,
commitment_reqd INT,
commitment_compl INT,
pre_pharm_course_name STRING,
pre_pharm_start_date DATE,
pre_pharm_end_date DATE,
district_change_ind STRING,
switch_pgm_ind STRING,
exception_award_entry STRING,
pharmacy_acceptance STRING,
pre_pharm_1040 STRING,
tutiion_receipt STRING,
active_flag STRING,
pre_pharm_worked_ind STRING,
pharm_worked_ind STRING,
pre_pharm_amount_ind STRING,
stage STRING,
award_amount_type STRING,
reject_reason STRING,
award_amount INT,
create_userid STRING,
create_date DATE,
update_userid STRING,
update_date DATE,
year_at_school INT,
applied_date DATE,
approval_ind STRING,
rejected_ind STRING,
withdrawn_ind STRING,
check_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
dist_amount INT,
employee_verification STRING,
prior_applicant STRING,
invoice_id STRING,
location_name STRING,
spanish_fluency_ind STRING,
batch_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_app_dtl_intm_current_updated_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_application_detail_final_stg(
student_id STRING,
application_id STRING,
program_id STRING,
agreement_id STRING,
program_type STRING,
award_loc_number STRING,
award_loc_type STRING,
award_number STRING,
scholarship_year STRING,
did_not_agree_ind STRING,
application_status STRING,
status_date STRING,
work_willingness STRING,
defined_location STRING,
commitment_reqd STRING,
commitment_compl STRING,
pre_pharm_course_name STRING,
pre_pharm_start_date STRING,
pre_pharm_end_date STRING,
district_change_ind STRING,
switch_pgm_ind STRING,
exception_award_entry STRING,
pharmacy_acceptance STRING,
pre_pharm_1040 STRING,
tutiion_receipt STRING,
active_flag STRING,
pre_pharm_worked_ind STRING,
pharm_worked_ind STRING,
pre_pharm_amount_ind STRING,
stage STRING,
award_amount_type STRING,
reject_reason STRING,
award_amount STRING,
create_userid STRING,
create_date STRING,
update_userid STRING,
update_date STRING,
year_at_school STRING,
applied_date STRING,
approval_ind STRING,
rejected_ind STRING,
withdrawn_ind STRING,
check_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
dist_amount STRING,
employee_verification STRING,
prior_applicant STRING,
invoice_id STRING,
location_name STRING,
spanish_fluency_ind STRING,
batch_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_application_detail_final_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_application_detail_intm_gather_stg(
student_id STRING,
application_id INT,
program_id INT,
agreement_id INT,
program_type STRING,
award_loc_number INT,
award_loc_type STRING,
award_number INT,
scholarship_year INT,
did_not_agree_ind STRING,
application_status INT,
status_date DATE,
work_willingness STRING,
defined_location STRING,
commitment_reqd INT,
commitment_compl INT,
pre_pharm_course_name STRING,
pre_pharm_start_date DATE,
pre_pharm_end_date DATE,
district_change_ind STRING,
switch_pgm_ind STRING,
exception_award_entry STRING,
pharmacy_acceptance STRING,
pre_pharm_1040 STRING,
tutiion_receipt STRING,
active_flag STRING,
pre_pharm_worked_ind STRING,
pharm_worked_ind STRING,
pre_pharm_amount_ind STRING,
stage STRING,
award_amount_type STRING,
reject_reason STRING,
award_amount INT,
create_userid STRING,
create_date DATE,
update_userid STRING,
update_date DATE,
year_at_school INT,
applied_date DATE,
approval_ind STRING,
rejected_ind STRING,
withdrawn_ind STRING,
check_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
dist_amount INT,
employee_verification STRING,
prior_applicant STRING,
invoice_id STRING,
location_name STRING,
spanish_fluency_ind STRING,
batch_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_application_detail_intm_gather_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_application_detail_persistent_stg(
student_id STRING,
application_id INT,
program_id INT,
agreement_id INT,
program_type STRING,
award_loc_number INT,
award_loc_type STRING,
award_number INT,
scholarship_year INT,
did_not_agree_ind STRING,
application_status INT,
status_date DATE,
work_willingness STRING,
defined_location STRING,
commitment_reqd INT,
commitment_compl INT,
pre_pharm_course_name STRING,
pre_pharm_start_date DATE,
pre_pharm_end_date DATE,
district_change_ind STRING,
switch_pgm_ind STRING,
exception_award_entry STRING,
pharmacy_acceptance STRING,
pre_pharm_1040 STRING,
tutiion_receipt STRING,
active_flag STRING,
pre_pharm_worked_ind STRING,
pharm_worked_ind STRING,
pre_pharm_amount_ind STRING,
stage STRING,
award_amount_type STRING,
reject_reason STRING,
award_amount INT,
create_userid STRING,
create_date DATE,
update_userid STRING,
update_date DATE,
year_at_school INT,
applied_date DATE,
approval_ind STRING,
rejected_ind STRING,
withdrawn_ind STRING,
check_ind STRING,
expense_cd STRING,
dist_expense_cd STRING,
dist_amount INT,
employee_verification STRING,
prior_applicant STRING,
invoice_id STRING,
location_name STRING,
spanish_fluency_ind STRING,
batch_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_application_detail_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_profile_final_stg(
student_id STRING,
cop_code STRING,
school_key BIGINT,
employee_id BIGINT,
period_key BIGINT,
application_id BIGINT,
location STRING,
position STRING,
cd_key STRING,
school_phone_nbr STRING,
expect_grad_year DATE,
pharmacy_assoc_1 STRING,
scholarship_eligibility_status STRING,
stay_through_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_profile_final_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_profile_persistent_stg(
student_id STRING,
first_name STRING,
last_name STRING,
middle_initial STRING,
ssn STRING,
home_address_1 STRING,
home_address_2 STRING,
home_city STRING,
home_state STRING,
home_zip_1 STRING,
home_zip_2 STRING,
home_country STRING,
country_code STRING,
home_phone STRING,
cell_phone STRING,
email STRING,
school_address_1 STRING,
school_address_2 STRING,
school_city STRING,
school_state STRING,
school_zip_1 STRING,
school_zip_2 STRING,
school_phone STRING,
preferred_address STRING,
email_preference STRING,
page_number STRING,
address_ind STRING,
last_worked_loc_nbr STRING,
location_entry_ind STRING,
last_worked_year STRING,
last_worked_loc_type STRING,
cop_code STRING,
cop_start_date STRING,
expect_grad_date STRING,
altered_grad_date STRING,
min_grad_date STRING,
max_grad_date STRING,
year_at_school STRING,
alt_year_at_school STRING,
pharm_degree_type STRING,
alt_pharm_degree_type STRING,
min_stay_thru_date STRING,
max_stay_thru_date STRING,
act_stay_thru_date STRING,
registration_status STRING,
employee_status STRING,
student_status STRING,
cur_yr_award_status STRING,
cur_award_stat_date STRING,
exception_ind STRING,
commitment_status STRING,
commitment_stat_date STRING,
reg_pharm_date STRING,
employee_start_date STRING,
intern_start_date STRING,
position_code STRING,
work_ver_system STRING,
work_ver_appl STRING,
realigned_ind STRING,
total_commitment STRING,
profile_compl_date STRING,
create_userid STRING,
create_date STRING,
update_userid STRING,
update_date STRING,
eligibility_status STRING,
app_year_at_school STRING,
collections_ind STRING,
remainder_ind STRING,
preferred_phone STRING,
pph_closed_appl_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_profile_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.student_profile_ssn_formatted_stg(
student_id STRING,
first_name STRING,
last_name STRING,
middle_initial STRING,
ssn STRING,
home_address_1 STRING,
home_address_2 STRING,
home_city STRING,
home_state STRING,
home_zip_1 STRING,
home_zip_2 STRING,
home_country STRING,
country_code STRING,
home_phone STRING,
cell_phone STRING,
email STRING,
school_address_1 STRING,
school_address_2 STRING,
school_city STRING,
school_state STRING,
school_zip_1 STRING,
school_zip_2 STRING,
school_phone STRING,
preferred_address STRING,
email_preference STRING,
page_number STRING,
address_ind STRING,
last_worked_loc_nbr STRING,
location_entry_ind STRING,
last_worked_year STRING,
last_worked_loc_type STRING,
cop_code STRING,
cop_start_date STRING,
expect_grad_date STRING,
altered_grad_date STRING,
min_grad_date STRING,
max_grad_date STRING,
year_at_school STRING,
alt_year_at_school STRING,
pharm_degree_type STRING,
alt_pharm_degree_type STRING,
min_stay_thru_date STRING,
max_stay_thru_date STRING,
act_stay_thru_date STRING,
registration_status STRING,
employee_status STRING,
student_status STRING,
cur_yr_award_status STRING,
cur_award_stat_date STRING,
exception_ind STRING,
commitment_status STRING,
commitment_stat_date STRING,
reg_pharm_date STRING,
employee_start_date STRING,
intern_start_date STRING,
position_code STRING,
work_ver_system STRING,
work_ver_appl STRING,
realigned_ind STRING,
total_commitment STRING,
profile_compl_date STRING,
create_userid STRING,
create_date STRING,
update_userid STRING,
update_date STRING,
eligibility_status STRING,
app_year_at_school STRING,
collections_ind STRING,
remainder_ind STRING,
preferred_phone STRING,
pph_closed_appl_ind STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/student_profile_ssn_formatted_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE OR REPLACE VIEW staging__hr__compensation_benefits.application_status_temp_stg AS SELECT
peap_application_status_stg.student_id
, peap_application_status_stg.application_id
, peap_application_status_stg.application_status
, peap_application_status_stg.status_date
, peap_application_status_stg.award_loc_number
, peap_application_status_stg.award_loc_type
, peap_application_status_stg.override_ind
, peap_application_status_stg.award_amount
, peap_application_status_stg.corp_amount
, peap_application_status_stg.district_amount
, peap_application_status_stg.ret_check_type
, peap_application_status_stg.check_number
, peap_application_status_stg.award_amt_returned
, peap_application_status_stg.district_change_ind
, peap_application_status_stg.expense_cd
, peap_application_status_stg.dist_expense_cd
, peap_application_status_stg.create_userid
, peap_application_status_stg.create_date
, peap_application_status_stg.update_userid
, peap_application_status_stg.update_date
, peap_application_status_stg.check_id
FROM
staging__hr__compensation_benefits.peap_application_status_stg""")
# COMMAND ----------
spark.sql(f"""CREATE OR REPLACE VIEW staging__hr__compensation_benefits.student_application_detail_temp_stg AS SELECT
peap_student_application_detail_stg.student_id
, peap_student_application_detail_stg.application_id
, peap_student_application_detail_stg.program_id
, peap_student_application_detail_stg.agreement_id
, peap_student_application_detail_stg.program_type
, peap_student_application_detail_stg.award_loc_number
, peap_student_application_detail_stg.award_loc_type
, peap_student_application_detail_stg.award_number
, peap_student_application_detail_stg.scholarship_year
, peap_student_application_detail_stg.did_not_agree_ind
, peap_student_application_detail_stg.application_status
, peap_student_application_detail_stg.status_date
, peap_student_application_detail_stg.work_willingness
, peap_student_application_detail_stg.defined_location
, peap_student_application_detail_stg.commitment_reqd
, peap_student_application_detail_stg.commitment_compl
, peap_student_application_detail_stg.pre_pharm_course_name
, peap_student_application_detail_stg.pre_pharm_start_date
, peap_student_application_detail_stg.pre_pharm_end_date
, peap_student_application_detail_stg.district_change_ind
, peap_student_application_detail_stg.switch_pgm_ind
, peap_student_application_detail_stg.exception_award_entry
, peap_student_application_detail_stg.pharmacy_acceptance
, peap_student_application_detail_stg.pre_pharm_1040
, peap_student_application_detail_stg.tutiion_receipt
, peap_student_application_detail_stg.active_flag
, peap_student_application_detail_stg.pre_pharm_worked_ind
, peap_student_application_detail_stg.pharm_worked_ind
, peap_student_application_detail_stg.pre_pharm_amount_ind
, peap_student_application_detail_stg.stage
, peap_student_application_detail_stg.award_amount_type
, peap_student_application_detail_stg.reject_reason
, peap_student_application_detail_stg.award_amount
, peap_student_application_detail_stg.create_userid
, peap_student_application_detail_stg.create_date
, peap_student_application_detail_stg.update_userid
, peap_student_application_detail_stg.update_date
, peap_student_application_detail_stg.year_at_school
, peap_student_application_detail_stg.applied_date
, peap_student_application_detail_stg.approval_ind
, peap_student_application_detail_stg.rejected_ind
, peap_student_application_detail_stg.withdrawn_ind
, peap_student_application_detail_stg.check_ind
, peap_student_application_detail_stg.expense_cd
, peap_student_application_detail_stg.dist_expense_cd
, peap_student_application_detail_stg.dist_amount
, peap_student_application_detail_stg.employee_verification
, peap_student_application_detail_stg.prior_applicant
, peap_student_application_detail_stg.invoice_id
, peap_student_application_detail_stg.location_name
, peap_student_application_detail_stg.spanish_fluency_ind
FROM
staging__hr__compensation_benefits.peap_student_application_detail_stg""")
# COMMAND ----------
spark.sql(f"""CREATE OR REPLACE VIEW staging__hr__compensation_benefits.student_profile_temp_stg AS SELECT
peap_student_profile_stg.student_id
, peap_student_profile_stg.first_name
, peap_student_profile_stg.last_name
, peap_student_profile_stg.middle_initial
, peap_student_profile_stg.ssn
, peap_student_profile_stg.home_address_1
, peap_student_profile_stg.home_address_2
, peap_student_profile_stg.home_city
, peap_student_profile_stg.home_state
, peap_student_profile_stg.home_zip_1
, peap_student_profile_stg.home_zip_2
, peap_student_profile_stg.home_country
, peap_student_profile_stg.country_code
, peap_student_profile_stg.home_phone
, peap_student_profile_stg.cell_phone
, peap_student_profile_stg.email
, peap_student_profile_stg.school_address_1
, peap_student_profile_stg.school_address_2
, peap_student_profile_stg.school_city
, peap_student_profile_stg.school_state
, peap_student_profile_stg.school_zip_1
, peap_student_profile_stg.school_zip_2
, peap_student_profile_stg.school_phone
, peap_student_profile_stg.preferred_address
, peap_student_profile_stg.email_preference
, peap_student_profile_stg.page_number
, peap_student_profile_stg.address_ind
, peap_student_profile_stg.last_worked_loc_nbr
, peap_student_profile_stg.location_entry_ind
, peap_student_profile_stg.last_worked_year
, peap_student_profile_stg.last_worked_loc_type
, peap_student_profile_stg.cop_code
, peap_student_profile_stg.cop_start_date
, peap_student_profile_stg.expect_grad_date
, peap_student_profile_stg.altered_grad_date
, peap_student_profile_stg.min_grad_date
, peap_student_profile_stg.max_grad_date
, peap_student_profile_stg.year_at_school
, peap_student_profile_stg.alt_year_at_school
, peap_student_profile_stg.pharm_degree_type
, peap_student_profile_stg.alt_pharm_degree_type
, peap_student_profile_stg.min_stay_thru_date
, peap_student_profile_stg.max_stay_thru_date
, peap_student_profile_stg.act_stay_thru_date
, peap_student_profile_stg.registration_status
, peap_student_profile_stg.employee_status
, peap_student_profile_stg.student_status
, peap_student_profile_stg.cur_yr_award_status
, peap_student_profile_stg.cur_award_stat_date
, peap_student_profile_stg.exception_ind
, peap_student_profile_stg.commitment_status
, peap_student_profile_stg.commitment_stat_date
, peap_student_profile_stg.reg_pharm_date
, peap_student_profile_stg.employee_start_date
, peap_student_profile_stg.intern_start_date
, peap_student_profile_stg.position_code
, peap_student_profile_stg.work_ver_system
, peap_student_profile_stg.work_ver_appl
, peap_student_profile_stg.realigned_ind
, peap_student_profile_stg.total_commitment
, peap_student_profile_stg.profile_compl_date
, peap_student_profile_stg.create_userid
, peap_student_profile_stg.create_date
, peap_student_profile_stg.update_userid
, peap_student_profile_stg.update_date
, peap_student_profile_stg.eligibility_status
, peap_student_profile_stg.app_year_at_school
, peap_student_profile_stg.collections_ind
, peap_student_profile_stg.remainder_ind
, peap_student_profile_stg.preferred_phone
, peap_student_profile_stg.pph_closed_appl_ind
FROM
staging__hr__compensation_benefits.peap_student_profile_stg""")
# COMMAND ----------
migration_data=[{"release": "8.3.3", "scripts": ["D.71.1.wrg.hr__compensation_benefits.sql", "T.14739.1.wrg.peap_application_status_stg.sql", "T.14740.1.wrg.peap_student_application_detail_stg.sql", "T.14741.1.wrg.peap_student_profile_stg.sql", "T.14787.1.wrg.app_status_student_app_detail_matched_stg.sql", "T.14788.1.wrg.app_status_student_app_detail_sort_stg.sql", "T.14791.1.wrg.application_status_intm_current_stg.sql", "T.14792.1.wrg.application_status_intm_current_new_stg.sql", "T.14793.1.wrg.application_status_persistent_stg.sql", "T.14824.1.wrg.code_decode_temp_stg.sql", "T.14971.1.wrg.fct_schloralship_details_app_detl_stg.sql", "T.14972.1.wrg.fct_schloralship_dtl_std_app_detl_stg.sql", "T.14973.1.wrg.fct_schloralship_dtl_std_profile_stg.sql", "T.15220.1.wrg.student_app_dtl_intm_current_stg.sql", "T.15221.1.wrg.student_app_dtl_intm_current_new_stg.sql", "T.15222.1.wrg.student_app_dtl_intm_current_unchanged_stg.sql", "T.15223.1.wrg.student_app_dtl_intm_current_updated_stg.sql", "T.15224.1.wrg.student_application_detail_final_stg.sql", "T.15225.1.wrg.student_application_detail_intm_gather_stg.sql", "T.15226.1.wrg.student_application_detail_persistent_stg.sql", "T.15228.1.wrg.student_profile_final_stg.sql", "T.15229.1.wrg.student_profile_persistent_stg.sql", "T.15230.1.wrg.student_profile_ssn_formatted_stg.sql", "V.14794.1.wrg.application_status_temp_stg.sql", "V.15227.1.wrg.student_application_detail_temp_stg.sql", "V.15231.1.wrg.student_profile_temp_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.3.3", "table_id": "T.14739.1", "table_name": "peap_application_status_stg", "table_schema": "staging__hr__compensation_benefits.peap_application_status_stg", "table_legacy_schema": "hr_raw.peap_application_status", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.peap_application_status_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14740.1", "table_name": "peap_student_application_detail_stg", "table_schema": "staging__hr__compensation_benefits.peap_student_application_detail_stg", "table_legacy_schema": "hr_raw.peap_student_application_detail", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.peap_student_application_detail_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14741.1", "table_name": "peap_student_profile_stg", "table_schema": "staging__hr__compensation_benefits.peap_student_profile_stg", "table_legacy_schema": "hr_raw.peap_student_profile", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.peap_student_profile_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14787.1", "table_name": "app_status_student_app_detail_matched_stg", "table_schema": "staging__hr__compensation_benefits.app_status_student_app_detail_matched_stg", "table_legacy_schema": "hr_work.app_status_student_app_detail_matched", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.app_status_student_app_detail_matched_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14788.1", "table_name": "app_status_student_app_detail_sort_stg", "table_schema": "staging__hr__compensation_benefits.app_status_student_app_detail_sort_stg", "table_legacy_schema": "hr_work.app_status_student_app_detail_sort", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.app_status_student_app_detail_sort_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14791.1", "table_name": "application_status_intm_current_stg", "table_schema": "staging__hr__compensation_benefits.application_status_intm_current_stg", "table_legacy_schema": "hr_work.application_status_intm_current", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.application_status_intm_current_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14792.1", "table_name": "application_status_intm_current_new_stg", "table_schema": "staging__hr__compensation_benefits.application_status_intm_current_new_stg", "table_legacy_schema": "hr_work.application_status_intm_current_new", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.application_status_intm_current_new_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14793.1", "table_name": "application_status_persistent_stg", "table_schema": "staging__hr__compensation_benefits.application_status_persistent_stg", "table_legacy_schema": "hr_work.application_status_persistent", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.application_status_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14824.1", "table_name": "code_decode_temp_stg", "table_schema": "staging__hr__compensation_benefits.code_decode_temp_stg", "table_legacy_schema": "hr_work.code_decode_temp", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.code_decode_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14971.1", "table_name": "fct_schloralship_details_app_detl_stg", "table_schema": "staging__hr__compensation_benefits.fct_schloralship_details_app_detl_stg", "table_legacy_schema": "hr_work.fct_schloralship_details_app_detl", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fct_schloralship_details_app_detl_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14972.1", "table_name": "fct_schloralship_dtl_std_app_detl_stg", "table_schema": "staging__hr__compensation_benefits.fct_schloralship_dtl_std_app_detl_stg", "table_legacy_schema": "hr_work.fct_schloralship_dtl_std_app_detl", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fct_schloralship_dtl_std_app_detl_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.14973.1", "table_name": "fct_schloralship_dtl_std_profile_stg", "table_schema": "staging__hr__compensation_benefits.fct_schloralship_dtl_std_profile_stg", "table_legacy_schema": "hr_work.fct_schloralship_dtl_std_profile", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fct_schloralship_dtl_std_profile_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15220.1", "table_name": "student_app_dtl_intm_current_stg", "table_schema": "staging__hr__compensation_benefits.student_app_dtl_intm_current_stg", "table_legacy_schema": "hr_work.student_app_dtl_intm_current", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_app_dtl_intm_current_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15221.1", "table_name": "student_app_dtl_intm_current_new_stg", "table_schema": "staging__hr__compensation_benefits.student_app_dtl_intm_current_new_stg", "table_legacy_schema": "hr_work.student_app_dtl_intm_current_new", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_app_dtl_intm_current_new_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15222.1", "table_name": "student_app_dtl_intm_current_unchanged_stg", "table_schema": "staging__hr__compensation_benefits.student_app_dtl_intm_current_unchanged_stg", "table_legacy_schema": "hr_work.student_app_dtl_intm_current_unchanged", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_app_dtl_intm_current_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15223.1", "table_name": "student_app_dtl_intm_current_updated_stg", "table_schema": "staging__hr__compensation_benefits.student_app_dtl_intm_current_updated_stg", "table_legacy_schema": "hr_work.student_app_dtl_intm_current_updated", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_app_dtl_intm_current_updated_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15224.1", "table_name": "student_application_detail_final_stg", "table_schema": "staging__hr__compensation_benefits.student_application_detail_final_stg", "table_legacy_schema": "hr_work.student_application_detail_final", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_application_detail_final_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15225.1", "table_name": "student_application_detail_intm_gather_stg", "table_schema": "staging__hr__compensation_benefits.student_application_detail_intm_gather_stg", "table_legacy_schema": "hr_work.student_application_detail_intm_gather", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_application_detail_intm_gather_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15226.1", "table_name": "student_application_detail_persistent_stg", "table_schema": "staging__hr__compensation_benefits.student_application_detail_persistent_stg", "table_legacy_schema": "hr_work.student_application_detail_persistent", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_application_detail_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15228.1", "table_name": "student_profile_final_stg", "table_schema": "staging__hr__compensation_benefits.student_profile_final_stg", "table_legacy_schema": "hr_work.student_profile_final", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_profile_final_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15229.1", "table_name": "student_profile_persistent_stg", "table_schema": "staging__hr__compensation_benefits.student_profile_persistent_stg", "table_legacy_schema": "hr_work.student_profile_persistent", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_profile_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "T.15230.1", "table_name": "student_profile_ssn_formatted_stg", "table_schema": "staging__hr__compensation_benefits.student_profile_ssn_formatted_stg", "table_legacy_schema": "hr_work.student_profile_ssn_formatted", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_profile_ssn_formatted_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "V.14794.1", "table_name": "application_status_temp_stg", "table_schema": "staging__hr__compensation_benefits.application_status_temp_stg", "table_legacy_schema": "hr_work.application_status_temp", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.application_status_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "V.15227.1", "table_name": "student_application_detail_temp_stg", "table_schema": "staging__hr__compensation_benefits.student_application_detail_temp_stg", "table_legacy_schema": "hr_work.student_application_detail_temp", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_application_detail_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.3", "table_id": "V.15231.1", "table_name": "student_profile_temp_stg", "table_schema": "staging__hr__compensation_benefits.student_profile_temp_stg", "table_legacy_schema": "hr_work.student_profile_temp", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.student_profile_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

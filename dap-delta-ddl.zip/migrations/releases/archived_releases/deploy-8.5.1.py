# Databricks notebook source
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='retail_crt_sa', defaultValue='${retail_crt_sa}', label='retail_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__ccpa;""")
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM pharmacy_healthcare__patient_services.prescription_consult_activity;
VACUUM pharmacy_healthcare__patient_services.prescription_consult_activity RETAIN 0 HOURS;
DROP TABLE pharmacy_healthcare__patient_services.prescription_consult_activity;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_consult_activity", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.prescription_consult_activity(
rx_nbr INT,
str_nbr INT,
rx_fill_nbr INT ,
rx_partial_fill_nbr INT ,
consult_actv_type_cd STRING ,
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
fill_enter_tm STRING,
fill_sold_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
consult_campaign_id DECIMAL(8,0),
dspn_fill_nbr SMALLINT ,
consult_actv_stat_ind STRING ,
consult_reqst_rph_user_id DECIMAL(9,0),
consult_reqst_rph_intl STRING ,
consult_reqst_dttm TIMESTAMP,
consult_reqst_cmnts STRING ,
consult_rslv_rph_user_id DECIMAL(9,0),
consult_rslv_rph_intl STRING ,
consult_rslv_dttm TIMESTAMP,
consult_rslv_cmnts STRING ,
src_create_user_id DECIMAL(9,0),
src_create_dttm TIMESTAMP,
src_update_user_id DECIMAL(9,0),
src_update_dttm TIMESTAMP,
remote_str_nbr INT,
edw_batch_id DECIMAL(18,0),
edw_gg_commit_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
relocate_fm_str_nbr INT ,
consult_rph_barcd_sprvsr_id DECIMAL(9,0)
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/prescription_consult_activity'
PARTITIONED BY (
fill_sold_yr STRING,
fill_enter_mnth STRING)""")
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM retail__retail_sales.sales_transaction;
VACUUM retail__retail_sales.sales_transaction RETAIN 0 HOURS;
DROP TABLE retail__retail_sales.sales_transaction;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YYYY/MM/DD" }}',
sales_ord_src_type STRING COMMENT 'sales order source type' ,
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
dim_loc_store_sk BIGINT COMMENT 'dim_loc_sk' ,
loc_store_sk BIGINT COMMENT 'loc_id' ,
store_nbr INT COMMENT 'store DOUBLE' ,
dim_loc_mgrs_sk BIGINT COMMENT 'dim_loc_staff_sk' ,
src_cust_id STRING COMMENT 'ecom_customer_id' ,
txn_end_dttm TIMESTAMP COMMENT 'txn_end_dttm',
ord_stat_cd STRING COMMENT 'order status code' ,
fulfillment_type_cd STRING COMMENT 'fulfillment type code' ,
originating_str_nbr INT COMMENT 'originating_str_nbr' ,
originating_store_sk BIGINT COMMENT 'originating store surrogate key' ,
fulfillment_str_nbr INT COMMENT 'fulfillment store DOUBLE' ,
fulfillment_store_sk BIGINT COMMENT 'fulfillment store surrogate key' ,
pick_up_at_str_nbr INT COMMENT 'pick up at store DOUBLE' ,
pickup_at_store_sk BIGINT COMMENT 'pickup at store surrogate key' ,
bypass_reason_cd SMALLINT COMMENT 'bypass reason code' ,
ord_entry_channel_cd STRING COMMENT 'order entry channel code' ,
ord_desc STRING COMMENT 'order description' ,
promise_dt DATE COMMENT 'promise date{{"FORMAT":"YYYY/MM/DD" }}' ,
promise_tm STRING COMMENT 'promise time' ,
rx_reqst_fill_dt DATE COMMENT 'rx request fill date{{"FORMAT":"YYYY/MM/DD" }}' ,
rx_reqst_fill_tm STRING COMMENT 'rx request fill time' ,
txn_type STRING COMMENT 'txn_type' ,
ord_ship_dt DATE COMMENT 'order ship date{{"FORMAT":"YYYY/MM/DD" }}' ,
ord_ship_tm STRING COMMENT 'order ship time' ,
return_stat_desc STRING COMMENT 'return status description' ,
prcs_ind STRING COMMENT 'prcs indicator' ,
prcs_immediate_ind STRING COMMENT 'prcs immediate indicator' ,
nbr_of_images INT COMMENT 'number of images' ,
tot_image_sz_kb DECIMAL(10,2) COMMENT 'total image size mb' ,
pcp_ord_id STRING COMMENT 'pcp order id' ,
vndr_cust_id STRING COMMENT 'vendor customer id' ,
vndr_ord_id STRING COMMENT 'vendor order id' ,
commision_vndr_cd STRING COMMENT 'commision vendor code' ,
photo_origin_id STRING COMMENT 'photo origin identifier' ,
spcl_ord_desc STRING COMMENT 'special order description' ,
orig_inv_dlrs DECIMAL(8,2) COMMENT 'original invoice dollars' ,
prod_cost_dlrs DECIMAL(8,2) COMMENT 'product cost dollars' ,
shipping_price_dlrs DECIMAL(8,2) COMMENT 'shipping price dollars' ,
in_str_ord_ind STRING COMMENT 'in store order indicator' ,
share_ord_ind STRING COMMENT 'shared order indicator' ,
aarp_ind STRING COMMENT 'aarp indicator' ,
ord_return_ind STRING COMMENT 'order return indicator' ,
pre_click_ord_ind STRING COMMENT 'pre click order indicator' ,
held_ord_ind STRING COMMENT 'held order indicator' ,
lens_ord_ind STRING COMMENT 'lens order indicator' ,
self_pay_ind STRING COMMENT 'self pay indicator' ,
xref_line_item_seq_nbr SMALLINT COMMENT 'xref_line_item_seq_nbr',
generic_ord_ind STRING COMMENT 'generic order indicator' ,
fsa_ind STRING COMMENT 'flexible spending account indicator' ,
cashier_nbr SMALLINT COMMENT 'cashier_nbr' ,
create_id STRING COMMENT 'create_id' ,
cashier_employee_id DECIMAL(10,0) COMMENT 'cashier id' ,
mgr_employee_id DECIMAL(10,0) COMMENT 'manager id' ,
loyalty_employee_id DECIMAL(10,0) COMMENT 'employee_id' ,
exchange_cd STRING COMMENT 'exchange_cd' ,
offline_txn_ind STRING COMMENT 'offline_txn_ind' ,
price_verify_cd STRING COMMENT 'price_verify_cd' ,
register_nbr SMALLINT COMMENT 'register_nbr' ,
store_register_sk BIGINT COMMENT 'store register sk',
rfn_value STRING COMMENT 'rfn_value' ,
next_gen_rfn_value STRING COMMENT 'next_gen_rfn_value' ,
training_txn_ind STRING COMMENT 'training_txn_ind' ,
txn_incomplete_ind STRING COMMENT 'txn_incomplete_ind' ,
txn_nbr SMALLINT COMMENT 'txn_nbr',
txn_start_dttm TIMESTAMP COMMENT 'txn_start_dttm',
txn_tot_discnt_line_cnt SMALLINT COMMENT 'txn_tot_discnt_line_cnt' ,
txn_tot_discnt_line_qty SMALLINT COMMENT 'txn_tot_discnt_line_qty' ,
txn_tot_discnt_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_return_dlrs' ,
txn_tot_discnt_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_sale_dlrs' ,
txn_tot_dlrs DECIMAL(8,2) COMMENT 'txn_tot_dlrs' ,
txn_tot_line_cnt SMALLINT COMMENT 'txn_tot_line_cnt' ,
txn_tot_line_voided_cnt SMALLINT COMMENT 'txn_tot_line_voided_cnt' ,
txn_tot_line_voids_cnt SMALLINT COMMENT 'txn_tot_line_voids_cnt' ,
txn_tot_mfg_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_mfg_coup_dlrs' ,
txn_tot_net_qty DECIMAL(5,0) COMMENT 'txn_tot_net_qty' ,
txn_tot_price_vrfy_line_cnt SMALLINT COMMENT 'txn_tot_price_vrfy_line_cnt' ,
txn_tot_reg_line_cnt SMALLINT COMMENT 'txn_tot_reg_line_cnt' ,
txn_tot_reg_line_qty SMALLINT COMMENT 'txn_tot_reg_line_qty' ,
txn_tot_reg_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_return_dlrs' ,
txn_tot_reg_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_sale_dlrs' ,
txn_tot_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_return_dlrs' ,
txn_tot_return_line_cnt SMALLINT COMMENT 'txn_tot_return_line_cnt' ,
txn_tot_rx_line_cnt SMALLINT COMMENT 'txn_tot_rx_line_cnt' ,
txn_tot_tax_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tax_dlrs' ,
txn_tot_tndr_cnt SMALLINT COMMENT 'txn_tot_tndr_cnt' ,
txn_tot_tndr_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tndr_dlrs' ,
txn_tot_void_dlrs DECIMAL(8,2) COMMENT 'txn_tot_void_dlrs' ,
txn_tot_wag_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_wag_coup_dlrs' ,
discnt_mode_cd STRING COMMENT 'discnt_mode_cd' ,
affiliate_discnt_cd STRING COMMENT 'affiliate discount code' ,
post_void_status_cd STRING COMMENT 'post_void_status_cd' ,
return_reason_cd SMALLINT COMMENT 'return reason code' ,
return_auth_nbr STRING COMMENT 'return authorization DOUBLE' ,
vndr_refund_id DECIMAL(19,0) COMMENT 'vendor refund id' ,
shipping_price_discnt_dlrs DECIMAL(8,2) COMMENT 'shipping price discount dollars' ,
suggest_tax_return_dlrs DECIMAL(8,2) COMMENT 'suggested tax return dollars' ,
actl_tax_return_dlrs DECIMAL(8,2) COMMENT 'actl_tax_return_dlrs' ,
suggest_ship_return_dlrs DECIMAL(8,2) COMMENT 'suggested ship return dollars' ,
actl_ship_return_dlrs DECIMAL(8,2) COMMENT 'actl_ship_return_dlrs' ,
paypal_return_dlrs DECIMAL(8,2) COMMENT 'paypal_return_dlrs' ,
authenticator_id STRING COMMENT 'authenticator_id' ,
credit_card_return_dlrs DECIMAL(8,2) COMMENT 'credit_card_return_dlrs' ,
gift_card_return_dlrs DECIMAL(8,2) COMMENT 'gift_card_return_dlrs' ,
loyalty_enrl_ind STRING COMMENT 'loyalty enrollment indicator' ,
aarp_opt_out_ind STRING COMMENT 'aarp opt out indicator' ,
identification_method STRING COMMENT 'identification method' ,
price_button_evt_ind STRING COMMENT 'pricing button event indicator' ,
emp_discnt_button_use STRING COMMENT 'employee discount button_use' ,
loyalty_card_scan_ind STRING COMMENT 'loyalty card scan indicator' ,
store_emp_loyalty_acct_ind STRING COMMENT 'store employee loyalty account indicator' ,
onscreen_redeem_button_use STRING COMMENT 'onscreen_redeem_button_use' ,
bounty_super_refund_cd STRING COMMENT 'bounty_super_refund_cd' ,
csr_id STRING COMMENT 'csr identifier' ,
ord_sub_type_cd STRING COMMENT 'order sub type code' ,
void_type_cd STRING COMMENT 'void type code' ,
void_reason_cd STRING COMMENT 'void reason code' ,
emv_stat_cd STRING COMMENT 'emv status code' ,
pinpad_stat_cd STRING COMMENT 'pinpad status code' ,
channel_cd STRING COMMENT 'channel code' ,
channel_desc STRING COMMENT 'channel description' ,
channel_detail_cd STRING COMMENT 'channel detail code' ,
channel_detail_desc STRING COMMENT 'channel detail description' ,
func_cd STRING COMMENT 'functionality code' ,
func_desc STRING COMMENT 'functionality description' ,
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch id'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction'
PARTITIONED BY (
src_sys_cd,
sales_txn_dt)""")
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__retail__retail_sales.sales_transaction_data_migration;
VACUUM staging__retail__retail_sales.sales_transaction_data_migration RETAIN 0 HOURS;
DROP TABLE staging__retail__retail_sales.sales_transaction_data_migration;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_transaction_data_migration", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.sales_transaction_data_migration (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_ord_src_type STRING COMMENT 'sales order source type' ,
sales_txn_type STRING COMMENT 'sales_txn type',
dim_loc_store_sk BIGINT COMMENT 'dim_loc_sk' ,
loc_store_sk BIGINT COMMENT 'loc_id' ,
store_nbr INT COMMENT 'store DOUBLE' ,
dim_loc_mgrs_sk BIGINT COMMENT 'dim_loc_staff_sk' ,
src_cust_id STRING COMMENT 'ecom_customer_id' ,
txn_end_dttm TIMESTAMP COMMENT 'txn_end_dttm',
ord_stat_cd STRING COMMENT 'order status code' ,
fulfillment_type_cd STRING COMMENT 'fulfillment type code' ,
originating_str_nbr INT COMMENT 'originating_str_nbr' ,
originating_store_sk BIGINT COMMENT 'originating store surrogate key' ,
fulfillment_str_nbr INT COMMENT 'fulfillment store DOUBLE' ,
fulfillment_store_sk BIGINT COMMENT 'fulfillment store surrogate key' ,
pick_up_at_str_nbr INT COMMENT 'pick up at store DOUBLE' ,
pickup_at_store_sk BIGINT COMMENT 'pickup at store surrogate key' ,
bypass_reason_cd SMALLINT COMMENT 'bypass reason code' ,
ord_entry_channel_cd STRING COMMENT 'order entry channel code' ,
ord_desc STRING COMMENT 'order description' ,
promise_dt DATE COMMENT 'promise date{{"FORMAT":"YYYY/MM/DD" }}' ,
promise_tm STRING COMMENT 'promise time' ,
rx_reqst_fill_dt DATE COMMENT 'rx request fill date{{"FORMAT":"YYYY/MM/DD" }}' ,
rx_reqst_fill_tm STRING COMMENT 'rx request fill time' ,
txn_type STRING COMMENT 'txn_type' ,
ord_ship_dt DATE COMMENT 'order ship date{{"FORMAT":"YYYY/MM/DD" }}' ,
ord_ship_tm STRING COMMENT 'order ship time' ,
return_stat_desc STRING COMMENT 'return status description' ,
prcs_ind STRING COMMENT 'prcs indicator' ,
prcs_immediate_ind STRING COMMENT 'prcs immediate indicator' ,
nbr_of_images INT COMMENT 'number of images' ,
tot_image_sz_kb DECIMAL(10,2) COMMENT 'total image size mb' ,
pcp_ord_id STRING COMMENT 'pcp order id' ,
vndr_cust_id STRING COMMENT 'vendor customer id' ,
vndr_ord_id STRING COMMENT 'vendor order id' ,
commision_vndr_cd STRING COMMENT 'commision vendor code' ,
photo_origin_id STRING COMMENT 'photo origin identifier' ,
spcl_ord_desc STRING COMMENT 'special order description' ,
orig_inv_dlrs DECIMAL(8,2) COMMENT 'original invoice dollars' ,
prod_cost_dlrs DECIMAL(8,2) COMMENT 'product cost dollars' ,
shipping_price_dlrs DECIMAL(8,2) COMMENT 'shipping price dollars' ,
in_str_ord_ind STRING COMMENT 'in store order indicator' ,
share_ord_ind STRING COMMENT 'shared order indicator' ,
aarp_ind STRING COMMENT 'aarp indicator' ,
ord_return_ind STRING COMMENT 'order return indicator' ,
pre_click_ord_ind STRING COMMENT 'pre click order indicator' ,
held_ord_ind STRING COMMENT 'held order indicator' ,
lens_ord_ind STRING COMMENT 'lens order indicator' ,
self_pay_ind STRING COMMENT 'self pay indicator' ,
xref_line_item_seq_nbr SMALLINT COMMENT 'xref_line_item_seq_nbr',
generic_ord_ind STRING COMMENT 'generic order indicator' ,
fsa_ind STRING COMMENT 'flexible spending account indicator' ,
cashier_nbr SMALLINT COMMENT 'cashier_nbr' ,
create_id STRING COMMENT 'create_id' ,
cashier_employee_id DECIMAL(10,0) COMMENT 'cashier id' ,
mgr_employee_id DECIMAL(10,0) COMMENT 'manager id' ,
loyalty_employee_id DECIMAL(10,0) COMMENT 'employee_id' ,
exchange_cd STRING COMMENT 'exchange_cd' ,
offline_txn_ind STRING COMMENT 'offline_txn_ind' ,
price_verify_cd STRING COMMENT 'price_verify_cd' ,
register_nbr SMALLINT COMMENT 'register_nbr' ,
store_register_sk BIGINT COMMENT 'store register sk',
rfn_value STRING COMMENT 'rfn_value' ,
next_gen_rfn_value STRING COMMENT 'next_gen_rfn_value' ,
training_txn_ind STRING COMMENT 'training_txn_ind' ,
txn_incomplete_ind STRING COMMENT 'txn_incomplete_ind' ,
txn_nbr SMALLINT COMMENT 'txn_nbr',
txn_start_dttm TIMESTAMP COMMENT 'txn_start_dttm',
txn_tot_discnt_line_cnt SMALLINT COMMENT 'txn_tot_discnt_line_cnt' ,
txn_tot_discnt_line_qty SMALLINT COMMENT 'txn_tot_discnt_line_qty' ,
txn_tot_discnt_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_return_dlrs' ,
txn_tot_discnt_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_discnt_sale_dlrs' ,
txn_tot_dlrs DECIMAL(8,2) COMMENT 'txn_tot_dlrs' ,
txn_tot_line_cnt SMALLINT COMMENT 'txn_tot_line_cnt' ,
txn_tot_line_voided_cnt SMALLINT COMMENT 'txn_tot_line_voided_cnt' ,
txn_tot_line_voids_cnt SMALLINT COMMENT 'txn_tot_line_voids_cnt' ,
txn_tot_mfg_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_mfg_coup_dlrs' ,
txn_tot_net_qty DECIMAL(5,0) COMMENT 'txn_tot_net_qty' ,
txn_tot_price_vrfy_line_cnt SMALLINT COMMENT 'txn_tot_price_vrfy_line_cnt' ,
txn_tot_reg_line_cnt SMALLINT COMMENT 'txn_tot_reg_line_cnt' ,
txn_tot_reg_line_qty SMALLINT COMMENT 'txn_tot_reg_line_qty' ,
txn_tot_reg_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_return_dlrs' ,
txn_tot_reg_sale_dlrs DECIMAL(8,2) COMMENT 'txn_tot_reg_sale_dlrs' ,
txn_tot_return_dlrs DECIMAL(8,2) COMMENT 'txn_tot_return_dlrs' ,
txn_tot_return_line_cnt SMALLINT COMMENT 'txn_tot_return_line_cnt' ,
txn_tot_rx_line_cnt SMALLINT COMMENT 'txn_tot_rx_line_cnt' ,
txn_tot_tax_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tax_dlrs' ,
txn_tot_tndr_cnt SMALLINT COMMENT 'txn_tot_tndr_cnt' ,
txn_tot_tndr_dlrs DECIMAL(8,2) COMMENT 'txn_tot_tndr_dlrs' ,
txn_tot_void_dlrs DECIMAL(8,2) COMMENT 'txn_tot_void_dlrs' ,
txn_tot_wag_coup_dlrs DECIMAL(8,2) COMMENT 'txn_tot_wag_coup_dlrs' ,
discnt_mode_cd STRING COMMENT 'discnt_mode_cd' ,
affiliate_discnt_cd STRING COMMENT 'affiliate discount code' ,
post_void_status_cd STRING COMMENT 'post_void_status_cd' ,
return_reason_cd SMALLINT COMMENT 'return reason code' ,
return_auth_nbr STRING COMMENT 'return authorization DOUBLE' ,
vndr_refund_id DECIMAL(19,0) COMMENT 'vendor refund id' ,
shipping_price_discnt_dlrs DECIMAL(8,2) COMMENT 'shipping price discount dollars' ,
suggest_tax_return_dlrs DECIMAL(8,2) COMMENT 'suggested tax return dollars' ,
actl_tax_return_dlrs DECIMAL(8,2) COMMENT 'actl_tax_return_dlrs' ,
suggest_ship_return_dlrs DECIMAL(8,2) COMMENT 'suggested ship return dollars' ,
actl_ship_return_dlrs DECIMAL(8,2) COMMENT 'actl_ship_return_dlrs' ,
paypal_return_dlrs DECIMAL(8,2) COMMENT 'paypal_return_dlrs' ,
authenticator_id STRING COMMENT 'authenticator_id' ,
credit_card_return_dlrs DECIMAL(8,2) COMMENT 'credit_card_return_dlrs' ,
gift_card_return_dlrs DECIMAL(8,2) COMMENT 'gift_card_return_dlrs' ,
loyalty_enrl_ind STRING COMMENT 'loyalty enrollment indicator' ,
aarp_opt_out_ind STRING COMMENT 'aarp opt out indicator' ,
identification_method STRING COMMENT 'identification method' ,
price_button_evt_ind STRING COMMENT 'pricing button event indicator' ,
emp_discnt_button_use STRING COMMENT 'employee discount button_use' ,
loyalty_card_scan_ind STRING COMMENT 'loyalty card scan indicator' ,
store_emp_loyalty_acct_ind STRING COMMENT 'store employee loyalty account indicator' ,
onscreen_redeem_button_use STRING COMMENT 'onscreen_redeem_button_use' ,
bounty_super_refund_cd STRING COMMENT 'bounty_super_refund_cd' ,
csr_id STRING COMMENT 'csr identifier' ,
ord_sub_type_cd STRING COMMENT 'order sub type code' ,
void_type_cd STRING COMMENT 'void type code' ,
void_reason_cd STRING COMMENT 'void reason code' ,
emv_stat_cd STRING COMMENT 'emv status code' ,
pinpad_stat_cd STRING COMMENT 'pinpad status code' ,
channel_cd STRING COMMENT 'channel code' ,
channel_desc STRING COMMENT 'channel description' ,
channel_detail_cd STRING COMMENT 'channel detail code' ,
channel_detail_desc STRING COMMENT 'channel detail description' ,
func_cd STRING COMMENT 'functionality code' ,
func_desc STRING COMMENT 'functionality description' ,
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime'
)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/sales_transaction_data_migration'
PARTITIONED BY (
src_sys_cd STRING,
sales_txn_dt DATE)""")
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp1_stg;
VACUUM staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp1_stg RETAIN 0 HOURS;
DROP TABLE staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp1_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/icplus_status_update_har_1808_tmp1_stg", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp1_stg(
str_nbr INT,
bin_nbr STRING,
prcs_ctrl_nbr STRING,
store_npi_nbr STRING,
general_recipient_nbr STRING,
fill_enter_dt STRING,
rx_nbr INT,
rx_fill_nbr INT,
drug_id INT,
dspn_ndc STRING,
other_payr_coverage_cd SMALLINT,
plan_group_nbr STRING,
plan_tot_paid_dlrs DECIMAL(8,2),
plan_return_cost_dlrs DECIMAL(8,2),
plan_return_fee_dlrs DECIMAL(8,2),
plan_return_copay_dlrs DECIMAL(8,2),
plan_return_tax_dlrs DECIMAL(8,2),
plan_ar_dlrs DECIMAL(8,2),
plan_submit_fee_dlrs DECIMAL(8,2),
basis_of_reimb_detrm STRING,
fill_label_price_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
third_party_plan_id STRING,
claim_ref_nbr STRING,
del_adjud_cd STRING,
rx_create_dt STRING,
fill_sold_dt STRING,
fill_del_dt STRING,
pat_id DECIMAL(13,0),
plan_type STRING,
contract_name STRING,
plan_name STRING,
dspn_fill_nbr SMALLINT,
partial_fill_cd STRING,
fill_pay_method_cd STRING,
fill_days_supply SMALLINT,
fill_qty_dspn DECIMAL(8,3),
cob_ind STRING,
rx_partial_fill_nbr INT,
fill_enter_tm STRING,
update_dttm STRING,
edw_batch_id STRING)
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/icplus_status_update_har_1808_tmp1_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__ccpa.ccpa_customer_request_list_snflk_stg(
tkt_nbr STRING COMMENT 'ticket DOUBLE',
tkt_open_dt DATE COMMENT 'ticket open date',
reqst_type_cd STRING COMMENT 'request type code',
tkt_line_seq INT COMMENT 'ticket line sequence',
edw_tkt_receive_dt DATE COMMENT 'edw ticket receive date',
TASK_ID STRING COMMENT 'Task id',
TASK_DEADLINE DATE COMMENT 'Task deadline',
USER_TYPE STRING COMMENT 'User Type',
TASK_NAME STRING COMMENT 'Task name',
CV_FLAG STRING COMMENT 'CV Flag',
Minor_FL STRING COMMENT 'Minor Flag',
cust_src_id STRING COMMENT 'customer source identifier',
src_sys_cd STRING COMMENT 'source system code',
composite_type_cd STRING COMMENT 'composite type code',
msg_type_cd STRING COMMENT 'message type code',
LV_Flag STRING COMMENT 'Lesser Verification Flag',
REQ_STATUS STRING ,
STATUS_COMMENT STRING ,
Optout_begin_dt DATE COMMENT 'optout begin date',
Optout_end_dt DATE COMMENT 'optout end date',
Notification_dt DATE COMMENT 'Notification date',
cust_first_name STRING COMMENT 'customer first name',
cust_middle_name STRING COMMENT 'customer middle name',
cust_last_name STRING COMMENT 'customer last name',
cust_brth_dt DATE COMMENT 'customer birth date',
cust_addr_line_1 STRING COMMENT 'customer address line 1',
cust_addr_line_2 STRING COMMENT 'customer address line 2',
cust_city STRING COMMENT 'customer city',
cust_state_cd STRING COMMENT 'customer state code',
cust_zip_cd STRING COMMENT 'customer zip code',
cust_eml_addr STRING COMMENT 'customer email address',
cust_phone_nbr STRING COMMENT 'customer phone DOUBLE',
edw_reqst_complete_dt DATE COMMENT 'edw request complete date',
edw_tkt_complete_dt DATE COMMENT 'edw ticket complete date',
edw_cmnt_txt STRING COMMENT 'edw COMMENT text',
edw_detail_rpt_path STRING COMMENT 'edw detail report path',
edw_sumr_rpt_path STRING COMMENT 'edw summary report path',
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/ccpa/staging/ccpa_customer_request_list_snflk_stg'
PARTITIONED BY (
edw_create_dttm)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__ccpa.ccpa_customer_request_list_delta(
tkt_nbr STRING COMMENT 'ticket DOUBLE',
tkt_open_dt DATE COMMENT 'ticket open date',
reqst_type_cd STRING COMMENT 'request type code',
tkt_line_seq INT COMMENT 'ticket line sequence',
edw_tkt_receive_dt DATE COMMENT 'edw ticket receive date',
TASK_ID STRING COMMENT 'Task id',
TASK_DEADLINE DATE COMMENT 'Task deadline',
USER_TYPE STRING COMMENT 'User Type',
TASK_NAME STRING COMMENT 'Task name',
CV_FLAG STRING COMMENT 'CV Flag',
Minor_FL STRING COMMENT 'Minor Flag',
cust_src_id STRING COMMENT 'customer source identifier',
src_sys_cd STRING COMMENT 'source system code',
composite_type_cd STRING COMMENT 'composite type code',
msg_type_cd STRING COMMENT 'message type code',
LV_Flag STRING COMMENT 'Lesser Verification Flag',
REQ_STATUS STRING ,
STATUS_COMMENT STRING ,
Optout_begin_dt DATE COMMENT 'optout begin date',
Optout_end_dt DATE COMMENT 'optout end date',
Notification_dt DATE COMMENT 'Notification date',
cust_first_name STRING COMMENT 'customer first name',
cust_middle_name STRING COMMENT 'customer middle name',
cust_last_name STRING COMMENT 'customer last name',
cust_brth_dt DATE COMMENT 'customer birth date',
cust_addr_line_1 STRING COMMENT 'customer address line 1',
cust_addr_line_2 STRING COMMENT 'customer address line 2',
cust_city STRING COMMENT 'customer city',
cust_state_cd STRING COMMENT 'customer state code',
cust_zip_cd STRING COMMENT 'customer zip code',
cust_eml_addr STRING COMMENT 'customer email address',
cust_phone_nbr STRING COMMENT 'customer phone DOUBLE',
edw_reqst_complete_dt DATE COMMENT 'edw request complete date',
edw_tkt_complete_dt DATE COMMENT 'edw ticket complete date',
edw_cmnt_txt STRING COMMENT 'edw COMMENT text',
edw_detail_rpt_path STRING COMMENT 'edw detail report path',
edw_sumr_rpt_path STRING COMMENT 'edw summary report path',
edw_create_dttm TIMESTAMP COMMENT 'edw CREATE datetime',
edw_update_dttm TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://ccpa-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ccpa_customer_request_list_delta'
PARTITIONED BY (
edw_create_dttm)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.fl_fillsalesmetric_del_stg (
rx_nbr DECIMAL(38,0),
str_nbr DECIMAL(38,0),
rx_fill_nbr DECIMAL(38,0),
rx_partial_fill_nbr DECIMAL(38,0),
fill_enter_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
fill_enter_tm STRING
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/fl_fillsalesmetric_del_stg'""")
# COMMAND ----------
%sql
SET spark.databricks.delta.retentionDurationCheck.enabled = false;
DELETE FROM staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp2_stg;
VACUUM staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp2_stg RETAIN 0 HOURS;
DROP TABLE staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp2_stg;
SET spark.databricks.delta.retentionDurationCheck.enabled = True;
# COMMAND ----------
dbutils.fs.rm(f"abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/icplus_status_update_har_1808_tmp2_stg", recurse=True)
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp2_stg(
str_nbr INT,
bin_nbr STRING,
processor_ctrl_nbr STRING,
store_npi_nbr STRING,
general_recipient_nbr STRING,
fill_enter_dt STRING,
rx_nbr INT,
rx_fill_nbr INT,
drug_id INT,
dspn_ndc STRING,
other_payr_coverage_cd DECIMAL(2,0),
plan_group_nbr STRING,
plan_tot_paid_dlrs DECIMAL(8,2),
plan_return_cost_dlrs DECIMAL(8,2),
plan_return_fee_dlrs DECIMAL(8,2),
plan_return_copay_dlrs DECIMAL(8,2),
plan_return_tax_dlrs DECIMAL(8,2),
plan_ar_dlrs DECIMAL(8,2),
plan_submit_fee_dlrs DECIMAL(8,2),
basis_of_reimb_detrm STRING,
fill_label_price_dlrs DECIMAL(8,2),
fill_rtl_price_dlrs DECIMAL(8,2),
third_party_plan_id STRING,
claim_ref_nbr STRING,
del_adjud_cd STRING,
rx_create_dt STRING,
fill_sold_dt STRING,
fill_del_dt STRING,
pat_id DECIMAL(13,0),
plan_type_cd STRING,
contract_name STRING,
plan_name STRING,
dspn_fill_nbr SMALLINT,
partial_fill_cd STRING,
fill_pay_method_cd STRING,
fill_days_supply SMALLINT,
fill_qty_dspn DECIMAL(8,3),
cob_ind STRING,
rx_partial_fill_nbr INT,
fill_enter_tm STRING,
update_dttm STRING,
edw_batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/icplus_status_update_har_1808_tmp2_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.5.1", "scripts": ["D.91.1.wrg.retail__ccpa.sql", "D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "T.20015.0.wrg.icplus_status_update_har_1808_tmp1_stg.sql", "T.20015.1.wrg.icplus_status_update_har_1808_tmp1_stg.sql", "T.8900.0.wrg.icplus_status_update_har_1808_tmp2_stg.sql", "T.8900.1.wrg.icplus_status_update_har_1808_tmp2_stg.sql", "T.20028.1.wrg.ccpa_customer_request_list_snflk_stg.sql", "T.19971.0.crt.sales_transaction.sql", "T.19971.1.crt.sales_transaction.sql", "T.19973.0.wrg.sales_transaction_data_migration.sql", "T.19973.1.wrg.sales_transaction_data_migration.sql", "T.1637.0.crt.prescription_consult_activity.sql", "T.1637.1.crt.prescription_consult_activity.sql", "T.20030.1.wrg.fl_fillsalesmetric_del_stg.sql", "T.20029.1.crt.ccpa_customer_request_list_delta.sql"], "migration_date": "2022-08-18"}]
table_data=[{"release": "8.5.1", "table_id": "T.20015.1", "table_name": "icplus_status_update_har_1808_tmp1_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp1_stg", "table_legacy_schema": "dae_work.icplus_status_update_har_1808_tmp1", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp1_stg", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.1", "table_id": "T.8900.1", "table_name": "icplus_status_update_har_1808_tmp2_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp2_stg", "table_legacy_schema": "dae_work.icplus_status_update_har_1808_tmp2", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.icplus_status_update_har_1808_tmp2_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.1", "table_id": "T.20028.1", "table_name": "ccpa_customer_request_list_snflk_stg", "table_schema": "staging__retail__ccpa.ccpa_customer_request_list_snflk_stg", "table_legacy_schema": "acapdb.ccpa_customer_request_list_snflk_stg", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "staging__retail__ccpa.ccpa_customer_request_list_snflk_stg", "table_partition": "", "table_db": "staging__retail__ccpa", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.1", "table_id": "T.19971.1", "table_name": "sales_transaction", "table_schema": "retail__retail_sales.sales_transaction", "table_legacy_schema": "dae_cooked.sales_transaction", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction", "table_partition": "", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.1", "table_id": "T.19973.1", "table_name": "sales_transaction_data_migration", "table_schema": "staging__retail__retail_sales.sales_transaction_data_migration", "table_legacy_schema": "dae_cooked.sales_transaction", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.sales_transaction_data_migration", "table_partition": "", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.1", "table_id": "T.1637.1", "table_name": "prescription_consult_activity", "table_schema": "pharmacy_healthcare__patient_services.prescription_consult_activity", "table_legacy_schema": "dae_cooked.prescription_consult_activity", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.prescription_consult_activity", "table_partition": "\n  fill_sold_yr STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.1", "table_id": "T.20030.1", "table_name": "fl_fillsalesmetric_del_stg", "table_schema": "pharmacy_healthcare__patient_services.fl_fillsalesmetric_del_stg", "table_legacy_schema": "SNOWFLAKE", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.fl_fillsalesmetric_del_stg", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-18 12:13:11", "update_date": ""}, {"release": "8.5.1", "table_id": "T.20029.1", "table_name": "ccpa_customer_request_list_delta", "table_schema": "retail__ccpa.ccpa_customer_request_list_delta", "table_legacy_schema": "ccpa_customer_request_list_delta", "table_domain": "retail", "table_subdomain": "ccpa", "table_location": "retail__ccpa.ccpa_customer_request_list_delta", "table_partition": "", "table_db": "retail__ccpa", "table_zone": "curated", "create_date": "2022-08-18 12:13:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.','icplus_status_update_har_1808_tmp1_stg','icplus_status_update_har_1808_tmp2_stg','sales_transaction','sales_transaction_data_migration','prescription_consult_activity');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
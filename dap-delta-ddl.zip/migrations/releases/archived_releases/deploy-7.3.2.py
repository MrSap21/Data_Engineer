# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__drug;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__terms_of_employment;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__terms_of_employment.madetails_stg(
update_flag STRING,
person_id_external_external_code STRING,
effective_start_date STRING,
cust_racycle STRING,
cust_tsa_flag STRING,
cust_acq_comp_rate STRING,
cust_acq_company STRING,
cust_acq_date STRING,
cust_acq_emp_id STRING,
cust_acq_per_indicator STRING,
cust_ave_hours_day STRING,
cust_ave_hours_week STRING,
cust_deal_name STRING,
cust_emp_con_date STRING,
cust_non_compete_date STRING,
cust_ret_agr_date STRING,
cust_retention_date STRING,
cust_ring_fence_end STRING,
cust_ring_fence_start STRING,
cust_severance_date STRING,
cust_severance_flag STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/terms_of_employment/staging/madetails_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__drug.drug_medispan_cur_seq_stg(
ahfscc_therapeutic_class_cd INT,
allergy_pattern_cd SMALLINT,
awp_reportd_ind STRING,
dea_class_cd STRING,
desi_class_cd STRING,
dlrs_rank SMALLINT,
dosage_form_cd STRING,
drug_name_cd STRING,
drug_stat_cd STRING,
drug_strength DECIMAL(13,5),
drug_strength_uom STRING,
drug_to_drug_interact_cd SMALLINT,
drug_type_cd STRING,
dspn_unit_cd STRING,
dur_knwlgbsd_drug_cd_nbr STRING,
edw_batch_id DECIMAL(18,0),
fda_therapeutic_equivlnc_cd STRING,
form_type_cd STRING,
format_id_nbr STRING,
generic_drug_cd STRING,
generic_id_type_cd STRING,
generic_ingrd_id DECIMAL(9,0),
generic_prod_id STRING,
generic_prod_id_name STRING,
generic_prod_pkg_cd STRING,
hfpg_ind STRING,
history_seq_cd STRING,
history_seq_nbr SMALLINT,
internal_external_cd STRING,
labeler_cd INT,
legend_chng_dt STRING,
limit_stability_cd STRING,
maint_drug_ind STRING,
medispan_drug_class STRING,
medispan_drug_class_grp STRING,
medispan_drug_name STRING,
medispan_drug_subclass STRING,
mfgr_name STRING,
ndc_upc_hri_id STRING,
mfgr_name_abbr STRING,
new_drug_id STRING,
new_format_id_nbr STRING,
new_id_eff_dt STRING,
new_id_form_cd SMALLINT,
next_larger_ndc_suffix_nbr STRING,
next_smaller_ndc_suffix_nbr STRING,
old_drug_id STRING,
old_format_id_nbr STRING,
old_id_eff_dt STRING,
old_id_form_cd SMALLINT,
pcm_pattern_cd SMALLINT,
pkg_desc STRING,
pkg_qty INT,
pkg_sz DECIMAL(8,3),
pkg_sz_uom STRING,
ppg_ind STRING,
prod_desc_abbr STRING,
prod_name STRING,
prod_name_extn STRING,
repack_cd STRING,
route_admin STRING,
rx_otc_ind STRING,
rx_rank_cd SMALLINT,
secondary_drug_id STRING,
secondary_upc_hri_form_cd STRING,
seq_cd STRING,
single_ingrd_cd STRING,
src_eff_dt STRING,
src_eff_tm STRING,
src_end_dt STRING,
src_end_tm STRING,
storage_cond_cd STRING,
third_party_restrict_cd STRING,
tot_pkg_qty DECIMAL(12,3),
unit_dose_unit_of_use_cd STRING,
upc_hri_form_cd SMALLINT,
wholesale_unit_price DECIMAL(13,5))
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/drug/staging/drug_medispan_cur_seq_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.3.2", "scripts": ["D.20.1.wrg.pharmacy_healthcare__drug.sql", "D.72.1.wrg.hr__terms_of_employment.sql", "T.14722.1.wrg.madetails_stg.sql", "T.19940.1.wrg.drug_medispan_cur_seq_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.3.2", "table_id": "T.14722.1", "table_name": "madetails_stg", "table_schema": "staging__hr__terms_of_employment.madetails_stg", "table_legacy_schema": "hr_raw.madetails", "table_domain": "hr", "table_subdomain": "terms_of_employment", "table_location": "staging__hr__terms_of_employment.madetails_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__terms_of_employment", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.3.2", "table_id": "T.19940.1", "table_name": "drug_medispan_cur_seq_stg", "table_schema": "staging__pharmacy_healthcare__drug.drug_medispan_cur_seq_stg", "table_legacy_schema": "acapetldb.drug_medispan_cur_seq", "table_domain": "pharmacy_healthcare", "table_subdomain": "drug", "table_location": "staging__pharmacy_healthcare__drug.drug_medispan_cur_seq_stg", "table_partition": "", "table_db": "staging__pharmacy_healthcare__drug", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
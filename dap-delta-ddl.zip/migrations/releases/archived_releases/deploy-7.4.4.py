# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__retail_sales;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscalelevel_stg(
update_flag STRING,
code STRING,
effective_start_date STRING,
created_by STRING,
created_date_time STRING,
effective_end_date STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
next_pay_scale_level STRING,
pay_scale_level STRING,
pay_scale_group STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscalelevel_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscalelevel_delta_stg(
update_flag STRING,
code STRING,
effective_start_date STRING,
created_by STRING,
created_date_time STRING,
effective_end_date STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
next_pay_scale_level STRING,
pay_scale_level STRING,
pay_scale_group STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscalelevel_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscalelevel_unchanged_stg(
update_flag STRING,
code STRING,
effective_start_date STRING,
created_by STRING,
created_date_time STRING,
effective_end_date STRING,
external_name_default_value STRING,
external_name_en_us STRING,
external_name_localized STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
next_pay_scale_level STRING,
pay_scale_level STRING,
pay_scale_group STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscalelevel_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__retail__retail_sales.pos_str_promo_mvt_stg(
str STRING,
loc_store_sk STRING,
bdate STRING,
sales_txn_dt STRING,
reg STRING,
rnum STRING,
sales_txn_id STRING,
lyl STRING,
line STRING,
upc STRING,
prod_sk STRING,
rup STRING,
qty STRING,
rep STRING,
sep STRING,
promo_seq_num STRING,
typ STRING,
adj STRING,
plu STRING,
mode STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_retail')}.dfs.core.windows.net/retail/retail_sales/staging/pos_str_promo_mvt_stg'
PARTITIONED BY (
idh_ingestion_date STRING)""")
# COMMAND ----------
migration_data=[{"release": "7.4.4", "scripts": ["D.50.1.wrg.retail__retail_sales.sql", "D.67.1.wrg.hr__payroll.sql", "T.14736.1.wrg.payscalelevel_stg.sql", "T.15146.1.wrg.payscalelevel_delta_stg.sql", "T.15148.1.wrg.payscalelevel_unchanged_stg.sql", "T.19598.1.wrg.pos_str_promo_mvt_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.4.4", "table_id": "T.14736.1", "table_name": "payscalelevel_stg", "table_schema": "staging__hr__payroll.payscalelevel_stg", "table_legacy_schema": "hr_raw.payscalelevel", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscalelevel_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.4", "table_id": "T.15146.1", "table_name": "payscalelevel_delta_stg", "table_schema": "staging__hr__payroll.payscalelevel_delta_stg", "table_legacy_schema": "hr_work.payscalelevel_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscalelevel_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.4", "table_id": "T.15148.1", "table_name": "payscalelevel_unchanged_stg", "table_schema": "staging__hr__payroll.payscalelevel_unchanged_stg", "table_legacy_schema": "hr_work.payscalelevel_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscalelevel_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.4", "table_id": "T.19598.1", "table_name": "pos_str_promo_mvt_stg", "table_schema": "staging__retail__retail_sales.pos_str_promo_mvt_stg", "table_legacy_schema": "dae_raw.pos_str_promo_mvt", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "staging__retail__retail_sales.pos_str_promo_mvt_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__retail__retail_sales", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
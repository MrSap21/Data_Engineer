# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__lookup_codes;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__lookup_codes;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__compensation_benefits;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaycomponentgroup_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_component_flx STRING,
status STRING,
show_on_comp_ui STRING,
sort_order STRING,
use_for_comparatio_calc STRING,
use_for_range_penetration STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaycomponentgroup_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaygrade_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_grade_level STRING,
status STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaygrade_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscalepaycomponent_stg(
update_flag STRING,
pay_scale_level_code STRING,
pay_scale_level_effective_start_date STRING,
code STRING,
amount STRING,
created_by STRING,
created_date_time STRING,
currency STRING,
frequency STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
number STRING,
percentage STRING,
rate STRING,
unit STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscalepaycomponent_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.picklistvalue_stg(
update_flag STRING,
option_id STRING,
min_value STRING,
max_value STRING,
value STRING,
status STRING,
external_code STRING,
parent_option_id STRING,
country_description STRING,
picklist_type STRING,
picklist_label STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/picklistvalue_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.event_compensationinfo_stg(
employee_id STRING,
compensation_start_date STRING,
compensation_created_by STRING,
compensation_created_on STRING,
compensation_end_date STRING,
compensation_event STRING,
compensation_event_reason STRING,
compensation_last_modified_by STRING,
compensation_last_modified_on STRING,
pay_grade STRING,
pay_group STRING,
compensation_portlet_name STRING,
compensation_update_flag STRING,
pay_change_reason STRING,
pay_frequency STRING,
pay_frequency_desc STRING,
pay_type STRING,
pay_type_desc STRING,
previous_pay_frequency STRING,
previous_pay_type STRING,
compa_ratio STRING,
range_penetration STRING,
batch_id STRING,
period_date STRING,
flag STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING,
bonus_target DECIMAL(15,2),
lump_sum_amount DECIMAL(15,2),
lump_sum_effective_start_date STRING,
currency_code STRING,
pay_component_code STRING,
pay_rate DECIMAL(15,2),
previous_pay_rate DECIMAL(15,2),
pay_scale_area_code STRING,
pay_scale_group_code STRING,
pay_scale_level_code STRING,
pay_scale_type_code STRING,
pay_band_id STRING,
pay_band_name STRING,
position STRING,
location STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/event_compensationinfo_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaycomponent_delta_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
basepay_component_group STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
frequency_code STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
number DECIMAL(9,2),
pay_component_type STRING,
pay_component_value DECIMAL(9,2),
rate DECIMAL(9,2),
previous_pay_rate DECIMAL(9,2),
status STRING,
target STRING,
tax_treatment STRING,
used_for_comp_planning STRING,
can_override STRING,
display_on_self_service STRING,
is_earning STRING,
is_end_dated_payment STRING,
max_fraction_digits STRING,
recurring STRING,
self_service_description STRING,
unit_of_measure STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaycomponent_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaycomponent_new_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
basepay_component_group STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
frequency_code STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
number DECIMAL(9,2),
pay_component_type STRING,
pay_component_value DECIMAL(9,2),
rate DECIMAL(9,2),
previous_pay_rate DECIMAL(9,2),
status STRING,
target STRING,
tax_treatment STRING,
used_for_comp_planning STRING,
can_override STRING,
display_on_self_service STRING,
is_earning STRING,
is_end_dated_payment STRING,
max_fraction_digits STRING,
recurring STRING,
self_service_description STRING,
unit_of_measure STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaycomponent_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaycomponent_unchanged_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
basepay_component_group STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
frequency_code STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
number DECIMAL(9,2),
pay_component_type STRING,
pay_component_value DECIMAL(9,2),
rate DECIMAL(9,2),
previous_pay_rate DECIMAL(9,2),
status STRING,
target STRING,
tax_treatment STRING,
used_for_comp_planning STRING,
can_override STRING,
display_on_self_service STRING,
is_earning STRING,
is_end_dated_payment STRING,
max_fraction_digits STRING,
recurring STRING,
self_service_description STRING,
unit_of_measure STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaycomponent_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaycomponent_updated_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
basepay_component_group STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
currency STRING,
description STRING,
end_date STRING,
frequency_code STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
number DECIMAL(9,2),
pay_component_type STRING,
pay_component_value DECIMAL(9,2),
rate DECIMAL(9,2),
previous_pay_rate DECIMAL(9,2),
status STRING,
target STRING,
tax_treatment STRING,
used_for_comp_planning STRING,
can_override STRING,
display_on_self_service STRING,
is_earning STRING,
is_end_dated_payment STRING,
max_fraction_digits STRING,
recurring STRING,
self_service_description STRING,
unit_of_measure STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaycomponent_updated_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaygrade_delta_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_grade_level STRING,
previous_pay_grade_level STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaygrade_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaygrade_new_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_grade_level STRING,
previous_pay_grade_level STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaygrade_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaygrade_unchanged_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_grade_level STRING,
previous_pay_grade_level STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaygrade_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__compensation_benefits.fopaygrade_updated_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
pay_grade_level STRING,
previous_pay_grade_level STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/compensation_benefits/staging/fopaygrade_updated_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscalepaycomponent_delta_stg(
update_flag STRING,
pay_scale_level_code STRING,
pay_scale_level_effective_start_date STRING,
code STRING,
amount DECIMAL(9,2),
created_by STRING,
created_date_time STRING,
currency STRING,
frequency STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
number DECIMAL(9,2),
percentage DECIMAL(9,2),
rate DECIMAL(9,2),
unit STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscalepaycomponent_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.payscalepaycomponent_unchanged_stg(
update_flag STRING,
pay_scale_level_code STRING,
pay_scale_level_effective_start_date STRING,
code STRING,
amount DECIMAL(9,2),
created_by STRING,
created_date_time STRING,
currency STRING,
frequency STRING,
last_modified_by STRING,
last_modified_date_time STRING,
mdf_system_record_status STRING,
number DECIMAL(9,2),
percentage DECIMAL(9,2),
rate DECIMAL(9,2),
unit STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/payscalepaycomponent_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.picklistvalue_delta_stg(
update_flag STRING,
option_id STRING,
min_value STRING,
max_value STRING,
value STRING,
status STRING,
external_code STRING,
parent_option_id STRING,
country_description STRING,
picklist_type STRING,
picklist_label STRING,
batch_id STRING,
create_date TIMESTAMP,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/picklistvalue_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.picklistvalue_unchanged_stg(
update_flag STRING,
option_id STRING,
min_value STRING,
max_value STRING,
value STRING,
status STRING,
external_code STRING,
parent_option_id STRING,
country_description STRING,
picklist_type STRING,
picklist_label STRING,
batch_id STRING,
create_date TIMESTAMP,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/picklistvalue_unchanged_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.4.1", "scripts": ["D.56.1.wrg.hr__recruiting.sql", "D.57.1.crt.hr__compensation_benefits.sql", "D.60.1.crt.hr__payroll.sql", "D.62.1.crt.hr__lookup_codes.sql", "D.67.1.wrg.hr__payroll.sql", "D.69.1.wrg.hr__lookup_codes.sql", "D.71.1.wrg.hr__compensation_benefits.sql", "T.14712.1.wrg.fopaycomponentgroup_stg.sql", "T.14713.1.wrg.fopaygrade_stg.sql", "T.14737.1.wrg.payscalepaycomponent_stg.sql", "T.14744.1.wrg.picklistvalue_stg.sql", "T.14936.1.wrg.event_compensationinfo_stg.sql", "T.15028.1.wrg.fopaycomponent_delta_stg.sql", "T.15029.1.wrg.fopaycomponent_new_stg.sql", "T.15031.1.wrg.fopaycomponent_unchanged_stg.sql", "T.15032.1.wrg.fopaycomponent_updated_stg.sql", "T.15038.1.wrg.fopaygrade_delta_stg.sql", "T.15039.1.wrg.fopaygrade_new_stg.sql", "T.15041.1.wrg.fopaygrade_unchanged_stg.sql", "T.15042.1.wrg.fopaygrade_updated_stg.sql", "T.15150.1.wrg.payscalepaycomponent_delta_stg.sql", "T.15152.1.wrg.payscalepaycomponent_unchanged_stg.sql", "T.15176.1.wrg.picklistvalue_delta_stg.sql", "T.15178.1.wrg.picklistvalue_unchanged_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.4.1", "table_id": "T.14712.1", "table_name": "fopaycomponentgroup_stg", "table_schema": "staging__hr__compensation_benefits.fopaycomponentgroup_stg", "table_legacy_schema": "hr_raw.fopaycomponentgroup", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaycomponentgroup_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.14713.1", "table_name": "fopaygrade_stg", "table_schema": "staging__hr__compensation_benefits.fopaygrade_stg", "table_legacy_schema": "hr_raw.fopaygrade", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaygrade_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.14737.1", "table_name": "payscalepaycomponent_stg", "table_schema": "staging__hr__payroll.payscalepaycomponent_stg", "table_legacy_schema": "hr_raw.payscalepaycomponent", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscalepaycomponent_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.14744.1", "table_name": "picklistvalue_stg", "table_schema": "staging__hr__lookup_codes.picklistvalue_stg", "table_legacy_schema": "hr_raw.picklistvalue", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.picklistvalue_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.14936.1", "table_name": "event_compensationinfo_stg", "table_schema": "staging__hr__compensation_benefits.event_compensationinfo_stg", "table_legacy_schema": "hr_work.event_compensationinfo", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.event_compensationinfo_stg", "table_partition": "", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15028.1", "table_name": "fopaycomponent_delta_stg", "table_schema": "staging__hr__compensation_benefits.fopaycomponent_delta_stg", "table_legacy_schema": "hr_work.fopaycomponent_delta", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaycomponent_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15029.1", "table_name": "fopaycomponent_new_stg", "table_schema": "staging__hr__compensation_benefits.fopaycomponent_new_stg", "table_legacy_schema": "hr_work.fopaycomponent_new", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaycomponent_new_stg", "table_partition": "", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15031.1", "table_name": "fopaycomponent_unchanged_stg", "table_schema": "staging__hr__compensation_benefits.fopaycomponent_unchanged_stg", "table_legacy_schema": "hr_work.fopaycomponent_unchanged", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaycomponent_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15032.1", "table_name": "fopaycomponent_updated_stg", "table_schema": "staging__hr__compensation_benefits.fopaycomponent_updated_stg", "table_legacy_schema": "hr_work.fopaycomponent_updated", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaycomponent_updated_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15038.1", "table_name": "fopaygrade_delta_stg", "table_schema": "staging__hr__compensation_benefits.fopaygrade_delta_stg", "table_legacy_schema": "hr_work.fopaygrade_delta", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaygrade_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15039.1", "table_name": "fopaygrade_new_stg", "table_schema": "staging__hr__compensation_benefits.fopaygrade_new_stg", "table_legacy_schema": "hr_work.fopaygrade_new", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaygrade_new_stg", "table_partition": "", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15041.1", "table_name": "fopaygrade_unchanged_stg", "table_schema": "staging__hr__compensation_benefits.fopaygrade_unchanged_stg", "table_legacy_schema": "hr_work.fopaygrade_unchanged", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaygrade_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15042.1", "table_name": "fopaygrade_updated_stg", "table_schema": "staging__hr__compensation_benefits.fopaygrade_updated_stg", "table_legacy_schema": "hr_work.fopaygrade_updated", "table_domain": "hr", "table_subdomain": "compensation_benefits", "table_location": "staging__hr__compensation_benefits.fopaygrade_updated_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__compensation_benefits", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15150.1", "table_name": "payscalepaycomponent_delta_stg", "table_schema": "staging__hr__payroll.payscalepaycomponent_delta_stg", "table_legacy_schema": "hr_work.payscalepaycomponent_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscalepaycomponent_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15152.1", "table_name": "payscalepaycomponent_unchanged_stg", "table_schema": "staging__hr__payroll.payscalepaycomponent_unchanged_stg", "table_legacy_schema": "hr_work.payscalepaycomponent_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.payscalepaycomponent_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15176.1", "table_name": "picklistvalue_delta_stg", "table_schema": "staging__hr__lookup_codes.picklistvalue_delta_stg", "table_legacy_schema": "hr_work.picklistvalue_delta", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.picklistvalue_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.4.1", "table_id": "T.15178.1", "table_name": "picklistvalue_unchanged_stg", "table_schema": "staging__hr__lookup_codes.picklistvalue_unchanged_stg", "table_legacy_schema": "hr_work.picklistvalue_unchanged", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.picklistvalue_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_auto_chg_mfg_config_stg(
cdc_txn_commit_dttm STRING COMMENT 'FROM deserializer',
cdc_txn_commit_dttm_after STRING COMMENT 'FROM deserializer',
cdc_seq_nbr STRING COMMENT 'FROM deserializer',
cdc_seq_nbr_after STRING COMMENT 'FROM deserializer',
cdc_rba_nbr STRING COMMENT 'FROM deserializer',
cdc_rba_nbr_after STRING COMMENT 'FROM deserializer',
cdc_operation_type_cd STRING COMMENT 'FROM deserializer',
cdc_operation_type_cd_after STRING COMMENT 'FROM deserializer',
cdc_before_after_cd STRING COMMENT 'FROM deserializer',
cdc_before_after_cd_after STRING COMMENT 'FROM deserializer',
cdc_txn_position_cd STRING COMMENT 'FROM deserializer',
cdc_txn_position_cd_after STRING COMMENT 'FROM deserializer',
src_edw_batch_id STRING COMMENT 'FROM deserializer',
src_edw_batch_id_after STRING COMMENT 'FROM deserializer',
config_id STRING COMMENT 'FROM deserializer',
config_id_after STRING COMMENT 'FROM deserializer',
config_type_cd STRING COMMENT 'FROM deserializer',
config_type_cd_after STRING COMMENT 'FROM deserializer',
config_type_desc STRING COMMENT 'FROM deserializer',
config_type_desc_after STRING COMMENT 'FROM deserializer',
active_ind STRING COMMENT 'FROM deserializer',
active_ind_after STRING COMMENT 'FROM deserializer',
state_cd STRING COMMENT 'FROM deserializer',
state_cd_after STRING COMMENT 'FROM deserializer',
drug_class STRING COMMENT 'FROM deserializer',
drug_class_after STRING COMMENT 'FROM deserializer',
effective_start_date STRING COMMENT 'FROM deserializer',
effective_start_date_after STRING COMMENT 'FROM deserializer',
effective_end_date STRING COMMENT 'FROM deserializer',
effective_end_date_after STRING COMMENT 'FROM deserializer',
config_data STRING COMMENT 'FROM deserializer',
config_data_after STRING COMMENT 'FROM deserializer',
config_data_desc STRING COMMENT 'FROM deserializer',
config_data_desc_after STRING COMMENT 'FROM deserializer',
audit_sent_local_ind STRING COMMENT 'FROM deserializer',
audit_sent_local_ind_after STRING COMMENT 'FROM deserializer',
audit_dttm STRING COMMENT 'FROM deserializer',
audit_dttm_after STRING COMMENT 'FROM deserializer',
audit_image_cd STRING COMMENT 'FROM deserializer',
audit_image_cd_after STRING COMMENT 'FROM deserializer',
audit_action_cd STRING COMMENT 'FROM deserializer',
audit_action_cd_after STRING COMMENT 'FROM deserializer',
src_create_user_id STRING COMMENT 'FROM deserializer',
src_create_user_id_after STRING COMMENT 'FROM deserializer',
src_create_dttm STRING COMMENT 'FROM deserializer',
src_create_dttm_after STRING COMMENT 'FROM deserializer',
src_update_user_id STRING COMMENT 'FROM deserializer',
src_update_user_id_after STRING COMMENT 'FROM deserializer',
src_update_dttm STRING COMMENT 'FROM deserializer',
src_update_dttm_after STRING COMMENT 'FROM deserializer',
tracking_id STRING COMMENT 'FROM deserializer')
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_auto_chg_mfg_config_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
migration_data=[{"release": "8.2.9", "scripts": ["D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "T.19989.1.wrg.gg_tbf0_auto_chg_mfg_config_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.2.9", "table_id": "T.19989.1", "table_name": "gg_tbf0_auto_chg_mfg_config_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_auto_chg_mfg_config_stg", "table_legacy_schema": "dae_code_raw_ingestion.gg_tbf0_auto_chg_mfg_config", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_auto_chg_mfg_config_stg", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

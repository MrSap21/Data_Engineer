# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_partner_extracts', defaultValue='${STORAGE_ACCT_wrg_partner_extracts}', label='STORAGE_ACCT_wrg_partner_extracts')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__drug;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patient_average_enroll_days_cur_month_stg(
clientstoreid INT,
month INT,
average_enroll_days_90 INT,
average_enroll_days_30 INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patient_average_enroll_days_cur_month_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_include_exclude_patients_merge_stg(
pat_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patients_eligible_include_exclude_patients_merge_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_pilot_stores_stg(
str_nbr INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_pilot_stores_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__drug.drug_exclusion_list_stg(
generic_prod_id STRING,
prod_name STRING,
maint_drug_ind STRING,
drug_stat_cd STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/drug/staging/drug_exclusion_list_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.sa_pat_event_log_current_stg(
pharmacypatientid DECIMAL(13,0),
enrollment_status STRING,
status_change_date STRING,
reason_for_unenrollment STRING,
loginname STRING,
usergroup STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/sa_pat_event_log_current_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.satr_patient_dtl_sync_length_stg(
pharmacypatientid DECIMAL(13,0),
clientstoreid INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/satr_patient_dtl_sync_length_stg'
PARTITIONED BY (
sync_cycle_length INT)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_patient_enrolment_unenrollment_date_stg(
pharmacypatientid DECIMAL(13,0),
enrollment_status STRING,
unenrollment_date STRING,
enrollment_date STRING,
unenrollment_date_modified STRING,
enrollment_date_modified STRING,
month INT,
days_difference INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_patient_enrolment_unenrollment_date_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.eligible_patients_actual_idh_create_dttm_stg(
pat_id DECIMAL(13,0),
rpt_month STRING,
idh_create_dttm STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/eligible_patients_actual_idh_create_dttm_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.eligible_patients_actual_pat_entered_date_stg(
pat_id DECIMAL(13,0),
rpt_month STRING,
patient_entered_dt STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/eligible_patients_actual_pat_entered_date_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.missing_demo_profiles_temp_stg(
pat_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/missing_demo_profiles_temp_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.3.1", "scripts": ["D.20.1.wrg.pharmacy_healthcare__drug.sql", "D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "D.39.1.wrg.partner_extracts__pharmacy_healthcare.sql", "T.11683.1.wrg.satr_pilot_stores_stg.sql", "T.19499.1.wrg.drug_exclusion_list_stg.sql", "T.7892.1.wrg.eligible_patients_actual_idh_create_dttm_stg.sql", "T.7893.1.wrg.eligible_patients_actual_pat_entered_date_stg.sql", "T.9489.1.wrg.missing_demo_profiles_temp_stg.sql", "T.4893.1.wrg.satr_patient_dtl_sync_length_stg.sql", "T.4913.1.wrg.satr_patient_enrolment_unenrollment_date_stg.sql", "T.11603.1.wrg.satr_patient_average_enroll_days_cur_month_stg.sql", "T.11637.1.wrg.satr_patients_eligible_include_exclude_patients_merge_stg.sql", "T.19683.1.wrg.sa_pat_event_log_current_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.3.1", "table_id": "T.11683.1", "table_name": "satr_pilot_stores_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_pilot_stores_stg", "table_legacy_schema": "dae_work.satr_pilot_stores", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_pilot_stores_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.1", "table_id": "T.19499.1", "table_name": "drug_exclusion_list_stg", "table_schema": "staging__pharmacy_healthcare__drug.drug_exclusion_list_stg", "table_legacy_schema": "dae_raw.drug_exclusion_list", "table_domain": "pharmacy_healthcare", "table_subdomain": "drug", "table_location": "staging__pharmacy_healthcare__drug.drug_exclusion_list_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__drug", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.1", "table_id": "T.7892.1", "table_name": "eligible_patients_actual_idh_create_dttm_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.eligible_patients_actual_idh_create_dttm_stg", "table_legacy_schema": "dae_work.eligible_patients_actual_idh_create_dttm", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.eligible_patients_actual_idh_create_dttm_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.1", "table_id": "T.7893.1", "table_name": "eligible_patients_actual_pat_entered_date_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.eligible_patients_actual_pat_entered_date_stg", "table_legacy_schema": "dae_work.eligible_patients_actual_pat_entered_date", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.eligible_patients_actual_pat_entered_date_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.1", "table_id": "T.9489.1", "table_name": "missing_demo_profiles_temp_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.missing_demo_profiles_temp_stg", "table_legacy_schema": "dae_work.missing_demo_profiles_temp", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.missing_demo_profiles_temp_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.1", "table_id": "T.4893.1", "table_name": "satr_patient_dtl_sync_length_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.satr_patient_dtl_sync_length_stg", "table_legacy_schema": "dae_scratch.satr_patient_dtl_sync_length", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.satr_patient_dtl_sync_length_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.1", "table_id": "T.4913.1", "table_name": "satr_patient_enrolment_unenrollment_date_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patient_enrolment_unenrollment_date_stg", "table_legacy_schema": "dae_scratch.satr_patient_enrolment_unenrollment_date", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patient_enrolment_unenrollment_date_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.1", "table_id": "T.11603.1", "table_name": "satr_patient_average_enroll_days_cur_month_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patient_average_enroll_days_cur_month_stg", "table_legacy_schema": "dae_work.satr_patient_average_enroll_days_cur_month", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patient_average_enroll_days_cur_month_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.1", "table_id": "T.11637.1", "table_name": "satr_patients_eligible_include_exclude_patients_merge_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_include_exclude_patients_merge_stg", "table_legacy_schema": "dae_work.satr_patients_eligible_include_exclude_patients_merge", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_patients_eligible_include_exclude_patients_merge_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.3.1", "table_id": "T.19683.1", "table_name": "sa_pat_event_log_current_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.sa_pat_event_log_current_stg", "table_legacy_schema": "dae_raw.sa_pat_event_log_current", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.sa_pat_event_log_current_stg", "table_partition": "", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

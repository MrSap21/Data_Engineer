# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_mna_buyout', defaultValue='${STORAGE_ACCT_crt_mna_buyout}', label='STORAGE_ACCT_crt_mna_buyout')
dbutils.widgets.text(name='mna_buyout_crt_sa', defaultValue='${mna_buyout_crt_sa}', label='mna_buyout_crt_sa')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS mna_buyout__supply_chain;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item(
store_number INT,
category_number INT,
category_desc STRING,
item_sku INT,
item_desc STRING,
item_status STRING,
ioh_flag tinyint,
plano_conforming_flag tinyint,
catalog_conforming_flag tinyint,
ioh INT,
wag_mdse_div_name STRING,
wag_business_unit STRING,
wag_gmm STRING,
rad_cost DECIMAL(15,2))
USING DELTA
LOCATION
'abfss://supply-chain-phi@{getArgument('mna_buyout_crt_sa')}.dfs.core.windows.net/rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item'
PARTITIONED BY (
day_date DATE)""")
# COMMAND ----------
migration_data=[{"release": "9.6.5", "scripts": ["D.74.1.crt.mna_buyout__supply_chain.sql", "T.15499.1.crt.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item.sql"], "migration_date": "2022-10-28"}]
table_data=[{"release": "9.6.5", "table_id": "T.15499.1", "table_name": "rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item", "table_schema": "mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item", "table_legacy_schema": "mna_cooked.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item", "table_domain": "mna_buyout", "table_subdomain": "supply_chain", "table_location": "mna_buyout__supply_chain.rad_scm_cutover_invent_conform_catalog_conv_cost_day_str_item", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "mna_buyout__supply_chain", "table_zone": "curated", "create_date": "2022-10-28 05:59:39", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
DELETE FROM  master_data__information_schema.databricks_tables ddl WHERE table_id IN ('.');
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
# %sql
# MERGE INTO  master_data__information_schema.databricks_table_catalog tables
#     USING temp_catalog new
#     ON tables.table_schema = new.table_schema AND tables.table_name = new.table_name
# WHEN MATCHED THEN
#     UPDATE SET
#         tables.table_schema = new.table_schema,
#         tables.table_database = new.table_database,
#         tables.table_legacy_schema = new.table_legacy_schema
#         tables.table_name = new.table_name,
#         tables.table_domain = new.table_domain,
#         tables.table_subdomain = new.table_subdomain,
#         tables.table_data_class = new.table_data_class,
#         tables.table_location = new.table_location,
#         tables.table_partition = new.table_partition,
#         tables.table_zone = new.table_zone,
#         tables.create_date = tables.create_date
#         tables.update_date = current_timestamp()
# WHEN NOT MATCHED THEN
#     INSERT 
#         new.table_schema,
#         new.table_database,
#         new.table_name,
#         new.table_legacy_schema,
#         new.table_domain,
#         new.table_subdomain,
#         new.table_data_class,
#         new.table_location,
#         new.table_partition,
#         new.table_zone,
#         new.create_date,
#         new.update_date
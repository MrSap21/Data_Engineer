# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='STORAGE_ACCT_crt_digital', defaultValue='${STORAGE_ACCT_crt_digital}', label='STORAGE_ACCT_crt_digital')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_marketing', defaultValue='${STORAGE_ACCT_wrg_marketing}', label='STORAGE_ACCT_wrg_marketing')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__organization_structure;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__terms_of_employment;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__organization_structure;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__terms_of_employment;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.focompany_stg(
update_flag STRING,
country STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
end_date STRING,
external_code STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
start_date STRING,
status STRING,
cust_legal_entity_group STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/focompany_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.focostcenter_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
external_object_id STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
cust_legal_entity STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/focostcenter_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fodepartment_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_to_division_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
cust_to_division STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fodepartment_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fodivision_stg(
update_flag STRING,
start_date STRING,
external_code STRING,
created_by STRING,
created_on STRING,
created_date_time STRING,
line_of_business STRING,
description STRING,
description_defaul_tvalue STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fodivision_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.fofrequency_stg(
update_flag STRING,
external_code STRING,
annualization_factor STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
frequency_description STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
frequency_name STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/fofrequency_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.folegalentitylocalusa_stg(
update_flag STRING,
external_code STRING,
country STRING,
created_by STRING,
created_on STRING,
created_date_time STRING,
end_date STRING,
legal_entity_type_generic STRING,
fein_number STRING,
last_modified_by STRING,
last_modified_on STRING,
last_modified_date_time STRING,
legal_entity_type STRING,
start_date STRING,
status STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/folegalentitylocalusa_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.folocation_stg(
update_flag STRING,
location_id STRING,
start_date STRING,
address_line_1 STRING,
address_line_2 STRING,
city STRING,
country STRING,
county STRING,
province STRING,
state STRING,
zip STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
hcc_market STRING,
location_type STRING,
store_type STRING,
operation STRING,
region STRING,
area STRING,
district STRING,
hcc_clinic_no STRING,
location_description STRING,
end_date STRING,
geo_zone_id STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
location_group_flx STRING,
truncated_location_name STRING,
status_ind STRING,
timezone STRING,
location_type_code STRING,
location_type_description STRING,
operation_id STRING,
region_id STRING,
area_id STRING,
district_id STRING,
hcc_market_nbr STRING,
store_type_id STRING,
address_line_3 STRING,
apartment STRING,
town STRING,
building_number STRING,
building STRING,
bed_number STRING,
tracking_id STRING,
batch_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/folocation_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.focompany_delta_stg(
update_flag STRING,
country STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
end_date STRING,
external_code STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
start_date STRING,
status STRING,
cust_legal_entity_group STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/focompany_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.focompany_unchanged_stg(
update_flag STRING,
country STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
end_date STRING,
external_code STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
start_date STRING,
status STRING,
cust_legal_entity_group STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/focompany_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.focostcenter_delta_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
external_object_id STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
cust_legal_entity STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/focostcenter_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.focostcenter_unchanged_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
external_object_id STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
status STRING,
cust_legal_entity STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/focostcenter_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fodepartment_delta_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_to_division_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
cust_to_division STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fodepartment_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fodepartment_unchanged_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_to_division_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
cust_to_division STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fodepartment_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fodivision_delta_stg(
update_flag STRING,
start_date STRING,
external_code STRING,
created_by STRING,
created_on STRING,
created_date_time STRING,
line_of_business STRING,
description STRING,
description_defaul_tvalue STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fodivision_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fodivision_unchanged_stg(
update_flag STRING,
start_date STRING,
external_code STRING,
created_by STRING,
created_on STRING,
created_date_time STRING,
line_of_business STRING,
description STRING,
description_defaul_tvalue STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fodivision_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.fofrequency_delta_stg(
update_flag STRING,
external_code STRING,
annualization_factor DECIMAL(9,2),
created_by STRING,
created_date_time STRING,
created_on STRING,
frequency_description STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
frequency_name STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/fofrequency_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.fofrequency_unchanged_stg(
update_flag STRING,
external_code STRING,
annualization_factor DECIMAL(9,2),
created_by STRING,
created_date_time STRING,
created_on STRING,
frequency_description STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
frequency_name STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/fofrequency_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.folegalentitylocalusa_delta_stg(
update_flag STRING,
external_code STRING,
company_legal_entity_name STRING,
country STRING,
created_by STRING,
created_on STRING,
created_date_time STRING,
end_date STRING,
legal_entity_type_generic STRING,
fein_number STRING,
last_modified_by STRING,
last_modified_on STRING,
last_modified_date_time STRING,
legal_entity_type STRING,
start_date STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/folegalentitylocalusa_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__payroll.folegalentitylocalusa_unchanged_stg(
update_flag STRING,
external_code STRING,
company_legal_entity_name STRING,
country STRING,
created_by STRING,
created_on STRING,
created_date_time STRING,
end_date STRING,
legal_entity_type_generic STRING,
fein_number STRING,
last_modified_by STRING,
last_modified_on STRING,
last_modified_date_time STRING,
legal_entity_type STRING,
start_date STRING,
status STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/payroll/staging/folegalentitylocalusa_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.folocation_delta_stg(
update_flag STRING,
location_id STRING,
start_date STRING,
address_line_1 STRING,
address_line_2 STRING,
city STRING,
country STRING,
county STRING,
province STRING,
state STRING,
zip STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
hcc_market STRING,
location_type STRING,
store_type STRING,
operation STRING,
region STRING,
area STRING,
district STRING,
hcc_clinic_no STRING,
location_description STRING,
end_date STRING,
geo_zone_id STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
location_group_flx STRING,
truncated_location_name STRING,
status_ind STRING,
timezone STRING,
location_type_code STRING,
location_type_description STRING,
operation_id STRING,
region_id STRING,
area_id STRING,
district_id STRING,
hcc_market_nbr STRING,
store_type_id STRING,
address_line_3 STRING,
apartment STRING,
town STRING,
building_number STRING,
building STRING,
bed_number STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/folocation_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.folocation_unchanged_stg(
update_flag STRING,
location_id STRING,
start_date STRING,
address_line_1 STRING,
address_line_2 STRING,
city STRING,
country STRING,
county STRING,
province STRING,
state STRING,
zip STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
hcc_market STRING,
location_type STRING,
store_type STRING,
operation STRING,
region STRING,
area STRING,
district STRING,
hcc_clinic_no STRING,
location_description STRING,
end_date STRING,
geo_zone_id STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
location_group_flx STRING,
truncated_location_name STRING,
status_ind STRING,
timezone STRING,
location_type_code STRING,
location_type_description STRING,
operation_id STRING,
region_id STRING,
area_id STRING,
district_id STRING,
hcc_market_nbr STRING,
store_type_id STRING,
address_line_3 STRING,
apartment STRING,
town STRING,
building_number STRING,
building STRING,
bed_number STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/folocation_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__terms_of_employment.madetails_delta_stg(
update_flag STRING,
person_id_external_external_code STRING,
effective_start_date STRING,
cust_racycle STRING,
cust_tsa_flag STRING,
cust_acq_comp_rate STRING,
cust_acq_company STRING,
cust_acq_date STRING,
cust_acq_emp_id STRING,
cust_acq_per_indicator STRING,
cust_ave_hours_day STRING,
cust_ave_hours_week STRING,
cust_deal_name STRING,
cust_emp_con_date STRING,
cust_non_compete_date STRING,
cust_ret_agr_date STRING,
cust_retention_date STRING,
cust_ring_fence_end STRING,
cust_ring_fence_start STRING,
cust_severance_date STRING,
cust_severance_flag STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/terms_of_employment/staging/madetails_delta_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__terms_of_employment.madetails_unchanged_stg(
update_flag STRING,
person_id_external_external_code STRING,
effective_start_date STRING,
cust_racycle STRING,
cust_tsa_flag STRING,
cust_acq_comp_rate STRING,
cust_acq_company STRING,
cust_acq_date STRING,
cust_acq_emp_id STRING,
cust_acq_per_indicator STRING,
cust_ave_hours_day STRING,
cust_ave_hours_week STRING,
cust_deal_name STRING,
cust_emp_con_date STRING,
cust_non_compete_date STRING,
cust_ret_agr_date STRING,
cust_retention_date STRING,
cust_ring_fence_end STRING,
cust_ring_fence_start STRING,
cust_severance_date STRING,
cust_severance_flag STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/terms_of_employment/staging/madetails_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fodepartment_new_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_to_division_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
cust_to_division STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fodepartment_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__organization_structure.fodepartment_updated_stg(
update_flag STRING,
external_code STRING,
start_date STRING,
created_by STRING,
created_date_time STRING,
created_on STRING,
cust_to_division_prop STRING,
description STRING,
description_default_value STRING,
description_en_us STRING,
description_localized STRING,
end_date STRING,
head_of_unit STRING,
last_modified_by STRING,
last_modified_date_time STRING,
last_modified_on STRING,
name STRING,
name_default_value STRING,
name_en_us STRING,
name_localized STRING,
parent STRING,
status STRING,
cust_to_division STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/organization_structure/staging/fodepartment_updated_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__terms_of_employment.madetails_presistent_stg(
update_flag STRING,
person_id_external_external_code STRING,
effective_start_date STRING,
cust_racycle STRING,
cust_tsa_flag STRING,
cust_acq_comp_rate STRING,
cust_acq_company STRING,
cust_acq_date STRING,
cust_acq_emp_id STRING,
cust_acq_per_indicator STRING,
cust_ave_hours_day STRING,
cust_ave_hours_week STRING,
cust_deal_name STRING,
cust_emp_con_date STRING,
cust_non_compete_date STRING,
cust_ret_agr_date STRING,
cust_retention_date STRING,
cust_ring_fence_end STRING,
cust_ring_fence_start STRING,
cust_severance_date STRING,
cust_severance_flag STRING,
created_by STRING,
created_date_time STRING,
last_modified_by STRING,
last_modified_date_time STRING,
batch_id STRING,
create_date STRING,
create_user_id STRING,
update_date STRING,
update_user_id STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/terms_of_employment/staging/madetails_presistent_stg'""")
# COMMAND ----------
migration_data=[{"release": "7.2.3", "scripts": ["D.12.1.crt.digital__ecom.sql", "D.53.1.wrg.marketing__campaign.sql", "D.60.1.crt.hr__payroll.sql", "D.61.1.crt.hr__organization_structure.sql", "D.65.1.crt.hr__terms_of_employment.sql", "D.67.1.wrg.hr__payroll.sql", "D.68.1.wrg.hr__organization_structure.sql", "D.72.1.wrg.hr__terms_of_employment.sql", "T.14700.1.wrg.focompany_stg.sql", "T.14701.1.wrg.focostcenter_stg.sql", "T.14702.1.wrg.fodepartment_stg.sql", "T.14703.1.wrg.fodivision_stg.sql", "T.14705.1.wrg.fofrequency_stg.sql", "T.14708.1.wrg.folegalentitylocalusa_stg.sql", "T.14709.1.wrg.folocation_stg.sql", "T.14984.1.wrg.focompany_delta_stg.sql", "T.14986.1.wrg.focompany_unchanged_stg.sql", "T.14988.1.wrg.focostcenter_delta_stg.sql", "T.14990.1.wrg.focostcenter_unchanged_stg.sql", "T.14992.1.wrg.fodepartment_delta_stg.sql", "T.14994.1.wrg.fodepartment_unchanged_stg.sql", "T.14996.1.wrg.fodivision_delta_stg.sql", "T.14998.1.wrg.fodivision_unchanged_stg.sql", "T.15004.1.wrg.fofrequency_delta_stg.sql", "T.15006.1.wrg.fofrequency_unchanged_stg.sql", "T.15016.1.wrg.folegalentitylocalusa_delta_stg.sql", "T.15018.1.wrg.folegalentitylocalusa_unchanged_stg.sql", "T.15020.1.wrg.folocation_delta_stg.sql", "T.15022.1.wrg.folocation_unchanged_stg.sql", "T.15091.1.wrg.madetails_delta_stg.sql", "T.15093.1.wrg.madetails_unchanged_stg.sql", "T.19913.1.wrg.fodepartment_new_stg.sql", "T.19915.1.wrg.fodepartment_updated_stg.sql", "T.19916.1.wrg.madetails_presistent_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.2.3", "table_id": "T.14700.1", "table_name": "focompany_stg", "table_schema": "staging__hr__organization_structure.focompany_stg", "table_legacy_schema": "hr_raw.focompany", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.focompany_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14701.1", "table_name": "focostcenter_stg", "table_schema": "staging__hr__organization_structure.focostcenter_stg", "table_legacy_schema": "hr_raw.focostcenter", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.focostcenter_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14702.1", "table_name": "fodepartment_stg", "table_schema": "staging__hr__organization_structure.fodepartment_stg", "table_legacy_schema": "hr_raw.fodepartment", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fodepartment_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14703.1", "table_name": "fodivision_stg", "table_schema": "staging__hr__organization_structure.fodivision_stg", "table_legacy_schema": "hr_raw.fodivision", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fodivision_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14705.1", "table_name": "fofrequency_stg", "table_schema": "staging__hr__payroll.fofrequency_stg", "table_legacy_schema": "hr_raw.fofrequency", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.fofrequency_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14708.1", "table_name": "folegalentitylocalusa_stg", "table_schema": "staging__hr__payroll.folegalentitylocalusa_stg", "table_legacy_schema": "hr_raw.folegalentitylocalusa", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.folegalentitylocalusa_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14709.1", "table_name": "folocation_stg", "table_schema": "staging__hr__organization_structure.folocation_stg", "table_legacy_schema": "hr_raw.folocation", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.folocation_stg", "table_partition": "\n  partition_column STRING", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14984.1", "table_name": "focompany_delta_stg", "table_schema": "staging__hr__organization_structure.focompany_delta_stg", "table_legacy_schema": "hr_work.focompany_delta", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.focompany_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14986.1", "table_name": "focompany_unchanged_stg", "table_schema": "staging__hr__organization_structure.focompany_unchanged_stg", "table_legacy_schema": "hr_work.focompany_unchanged", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.focompany_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14988.1", "table_name": "focostcenter_delta_stg", "table_schema": "staging__hr__organization_structure.focostcenter_delta_stg", "table_legacy_schema": "hr_work.focostcenter_delta", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.focostcenter_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14990.1", "table_name": "focostcenter_unchanged_stg", "table_schema": "staging__hr__organization_structure.focostcenter_unchanged_stg", "table_legacy_schema": "hr_work.focostcenter_unchanged", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.focostcenter_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14992.1", "table_name": "fodepartment_delta_stg", "table_schema": "staging__hr__organization_structure.fodepartment_delta_stg", "table_legacy_schema": "hr_work.fodepartment_delta", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fodepartment_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14994.1", "table_name": "fodepartment_unchanged_stg", "table_schema": "staging__hr__organization_structure.fodepartment_unchanged_stg", "table_legacy_schema": "hr_work.fodepartment_unchanged", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fodepartment_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14996.1", "table_name": "fodivision_delta_stg", "table_schema": "staging__hr__organization_structure.fodivision_delta_stg", "table_legacy_schema": "hr_work.fodivision_delta", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fodivision_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.14998.1", "table_name": "fodivision_unchanged_stg", "table_schema": "staging__hr__organization_structure.fodivision_unchanged_stg", "table_legacy_schema": "hr_work.fodivision_unchanged", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fodivision_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.15004.1", "table_name": "fofrequency_delta_stg", "table_schema": "staging__hr__payroll.fofrequency_delta_stg", "table_legacy_schema": "hr_work.fofrequency_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.fofrequency_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.15006.1", "table_name": "fofrequency_unchanged_stg", "table_schema": "staging__hr__payroll.fofrequency_unchanged_stg", "table_legacy_schema": "hr_work.fofrequency_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.fofrequency_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.15016.1", "table_name": "folegalentitylocalusa_delta_stg", "table_schema": "staging__hr__payroll.folegalentitylocalusa_delta_stg", "table_legacy_schema": "hr_work.folegalentitylocalusa_delta", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.folegalentitylocalusa_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.15018.1", "table_name": "folegalentitylocalusa_unchanged_stg", "table_schema": "staging__hr__payroll.folegalentitylocalusa_unchanged_stg", "table_legacy_schema": "hr_work.folegalentitylocalusa_unchanged", "table_domain": "hr", "table_subdomain": "payroll", "table_location": "staging__hr__payroll.folegalentitylocalusa_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__payroll", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.15020.1", "table_name": "folocation_delta_stg", "table_schema": "staging__hr__organization_structure.folocation_delta_stg", "table_legacy_schema": "hr_work.folocation_delta", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.folocation_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.15022.1", "table_name": "folocation_unchanged_stg", "table_schema": "staging__hr__organization_structure.folocation_unchanged_stg", "table_legacy_schema": "hr_work.folocation_unchanged", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.folocation_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.15091.1", "table_name": "madetails_delta_stg", "table_schema": "staging__hr__terms_of_employment.madetails_delta_stg", "table_legacy_schema": "hr_work.madetails_delta", "table_domain": "hr", "table_subdomain": "terms_of_employment", "table_location": "staging__hr__terms_of_employment.madetails_delta_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__terms_of_employment", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.15093.1", "table_name": "madetails_unchanged_stg", "table_schema": "staging__hr__terms_of_employment.madetails_unchanged_stg", "table_legacy_schema": "hr_work.madetails_unchanged", "table_domain": "hr", "table_subdomain": "terms_of_employment", "table_location": "staging__hr__terms_of_employment.madetails_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__terms_of_employment", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.19913.1", "table_name": "fodepartment_new_stg", "table_schema": "staging__hr__organization_structure.fodepartment_new_stg", "table_legacy_schema": "hr_work.fodepartment_new", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fodepartment_new_stg", "table_partition": "", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.19915.1", "table_name": "fodepartment_updated_stg", "table_schema": "staging__hr__organization_structure.fodepartment_updated_stg", "table_legacy_schema": "hr_work.fodepartment_updated", "table_domain": "hr", "table_subdomain": "organization_structure", "table_location": "staging__hr__organization_structure.fodepartment_updated_stg", "table_partition": "", "table_db": "staging__hr__organization_structure", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.2.3", "table_id": "T.19916.1", "table_name": "madetails_presistent_stg", "table_schema": "staging__hr__terms_of_employment.madetails_presistent_stg", "table_legacy_schema": "hr_work.madetails_presistent", "table_domain": "hr", "table_subdomain": "terms_of_employment", "table_location": "staging__hr__terms_of_employment.madetails_presistent_stg", "table_partition": "", "table_db": "staging__hr__terms_of_employment", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
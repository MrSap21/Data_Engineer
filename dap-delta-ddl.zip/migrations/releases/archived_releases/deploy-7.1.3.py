# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_digital', defaultValue='${STORAGE_ACCT_crt_digital}', label='STORAGE_ACCT_crt_digital')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_marketing', defaultValue='${STORAGE_ACCT_wrg_marketing}', label='STORAGE_ACCT_wrg_marketing')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__marketing__campaign;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_decode_lrf_stg(
code_desc STRING
,code_id STRING
,create_dttm STRING
,create_user_id STRING
,decode_type STRING
,update_dttm STRING
,update_user_id STRING
,src_cd_val STRING
,tracking_id STRING
,file_arrival_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/acap_campaign_decode_lrf_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_email_exclusion_lrf_stg(
campaign_cd STRING
,effective_date STRING
,create_user_id STRING
,create_dttm STRING
,update_dttm STRING
,tracking_id STRING
,file_arrival_date STRING )
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/acap_campaign_email_exclusion_lrf_stg'
PARTITIONED BY (partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_master_lrf_stg(
acl_id STRING
,campaign_cd STRING
,campaign_id STRING
,cmg_batch_id STRING
,create_date STRING
,create_id STRING
,creator_ind STRING
,description STRING
,end_date STRING
,end_per_id STRING
,folder_id STRING
,initiative STRING
,last_run_date STRING
,name STRING
,objectives STRING
,policy_id STRING
,project_id STRING
,runby STRING
,start_date STRING
,start_per_id STRING
,update_date STRING
,update_id STRING
,tracking_id STRING
,file_arrival_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/acap_campaign_master_lrf_stg'
PARTITIONED BY (partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_offer_lrf_stg(
acl_id STRING
,cmg_batch_id STRING
,create_date STRING
,create_user STRING
,delete_lock STRING
,description STRING
,effective_date_ind STRING
,expiration_date_ind STRING
,folder_id STRING
,name STRING
,number_of_offer_codes STRING
,offer_code_1 STRING
,offer_code_2 STRING
,offer_code_3 STRING
,offer_code_4 STRING
,offer_code_5 STRING
,offer_templ_id STRING
,offer_id STRING
,policy_id STRING
,retired STRING
,update_date STRING
,update_user STRING
,tracking_id STRING
,file_arrival_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/acap_campaign_offer_lrf_stg'
PARTITIONED BY (partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_offer_attribute_lrf_stg(
attribute_id STRING
,attribute_number STRING
,attribute_text STRING
,cmg_batch_id STRING
,current_ind STRING
,dttm_value STRING
,effective_date STRING
,expiration_date STRING
,table_key_id STRING
,table_name STRING
,attribute_name STRING
,tracking_id STRING
,file_arrival_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/acap_campaign_offer_attribute_lrf_stg'
PARTITIONED BY (partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_vendor_lrf_stg(
vendor_id STRING
,effective_date STRING
,end_date STRING
,file_frequency STRING
,vendor_description STRING
,vendor_name STRING
,vendor_parent_org STRING
,create_dttm STRING
,update_dttm STRING
,tracking_id STRING
,file_arrival_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/acap_campaign_vendor_lrf_stg'
PARTITIONED BY (partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.acap_campaign_contact_hist_stg(
audience_id STRING
,campaign_id  STRING
,cell_id  STRING
,channel_cd  STRING
,cmg_batch_id  STRING
,contact_dttm  STRING
,contact_status_id STRING
,customer_src_cd STRING
,detailed_record STRING
,package_id  STRING
,per_id  STRING
,score_decile  STRING
,score_value  STRING
,str_nbr  STRING
,treatment_id  STRING
,department_id  STRING
,sub_department_id STRING
,offer_cd  STRING
,prod_id  STRING
,response_track_cd STRING
,update_dttm  STRING
,email  STRING
,target_src_id  STRING
,target_src_id_char STRING
,target_src_cd  STRING
,target_ref_id  STRING
,target_ref_cd  STRING
,target_ref_nbr  STRING
,campaigncode  STRING
,audience_level_id STRING
,rx_nbr  STRING
,rx_date  STRING
,rx_fill_nbr  STRING
,refill_due_date STRING
,loc_next_open_date STRING
,contact_type  STRING
,contact_attempts STRING
,contact_sequence STRING
,planned_contact_date STRING
,eid  STRING
,dspn_fill_nbr  STRING
,partial_fill_cd STRING
,drug_id  STRING
,generic_prod_id STRING
,ndc11  STRING
,ahfscc_therapeutic_class_cd STRING
,plan_grp_nbr_1  STRING
,plan_grp_nbr_2  STRING
,offer_qualifier STRING
,offer_position  STRING
,offer_type_cd  STRING
,suc_code_30  STRING
,suc_code_16  STRING
,status_bar_code STRING
,late_fill_stat_cd STRING
,contact_phone  STRING
,fill_days_supply STRING
,pdc_score  STRING
,barcode  STRING
,readable_barcode STRING
,cust_coupon_code STRING
,value_segment_cd STRING
,need_segment_cd STRING
,emnos_test_cell_cd_1 STRING
,emnos_test_cell_cd_2 STRING
,addtl_campaign_logic STRING
,addtl_campaign_logic_value STRING
,potential_segment_cd STRING
,vendor_id  STRING
,vendor_id_prior STRING
,days_late  STRING
,pdc_score_vendor STRING
,cycle_run_number STRING
,campaign_cd_suppressed STRING
,offer_cd_suppressed STRING
,package_cd  STRING
,vendor_group_id STRING
,model_type_cd  STRING
,ntfcn_id  STRING
,referral_id  STRING
,creative_id  STRING
,newline  STRING
,tracking_id  STRING
,file_arrival_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/campaign_contact_hist_stg'
PARTITIONED BY (partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__marketing__campaign.contact_hist_ora_reconcilaition_stg(
batch_dttm STRING
,contactdatetime STRING
,planned_contact_date STRING
,campaign_cd STRING
,channel_cd STRING
,packageid STRING
,cellid STRING
,offer_cd STRING
,treatment_id STRING
,treatment_cd STRING
,contactstatusid STRING
,count STRING
,tracking_id STRING
,file_arrival_date STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_marketing')}.dfs.core.windows.net/marketing/campaign/staging/contact_hist_ora_reconcilaition_stg'
PARTITIONED BY (partition_column STRING)""")
# COMMAND ----------
migration_data=[{"release": "7.1.3", "scripts": ["D.12.1.crt.digital__ecom.sql", "D.53.1.wrg.marketing__campaign.sql", "T.19891.1.wrg.acap_campaign_decode_lrf_stg.sql", "T.19892.1.wrg.acap_campaign_email_exclusion_lrf_stg.sql", "T.19893.1.wrg.acap_campaign_master_lrf_stg.sql", "T.19894.1.wrg.acap_campaign_offer_lrf_stg.sql", "T.19895.1.wrg.acap_campaign_offer_attribute_lrf_stg.sql", "T.19896.1.wrg.acap_campaign_vendor_lrf_stg.sql", "T.19897.1.wrg.campaign_contact_hist_stg.sql", "T.19899.1.wrg.contact_hist_ora_reconcilaition_stg.sql"], "migration_date": "2022-06-28"}]
table_data=[{"release": "7.1.3", "table_id": "T.19891.1", "table_name": "acap_campaign_decode_lrf_stg", "table_schema": "staging__marketing__campaign.acap_campaign_decode_lrf_stg", "table_legacy_schema": "dae_code_raw_ingestion.acap_campaign_decode_lrf", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.acap_campaign_decode_lrf_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.3", "table_id": "T.19892.1", "table_name": "acap_campaign_email_exclusion_lrf_stg", "table_schema": "staging__marketing__campaign.acap_campaign_email_exclusion_lrf_stg", "table_legacy_schema": "dae_code_raw_ingestion.acap_campaign_email_exclusion_lrf", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.acap_campaign_email_exclusion_lrf_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.3", "table_id": "T.19893.1", "table_name": "acap_campaign_master_lrf_stg", "table_schema": "staging__marketing__campaign.acap_campaign_master_lrf_stg", "table_legacy_schema": "dae_code_raw_ingestion.acap_campaign_master_lrf", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.acap_campaign_master_lrf_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.3", "table_id": "T.19894.1", "table_name": "acap_campaign_offer_lrf_stg", "table_schema": "staging__marketing__campaign.acap_campaign_offer_lrf_stg", "table_legacy_schema": "dae_code_raw_ingestion.acap_campaign_offer_lrf", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.acap_campaign_offer_lrf_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.3", "table_id": "T.19895.1", "table_name": "acap_campaign_offer_attribute_lrf_stg", "table_schema": "staging__marketing__campaign.acap_campaign_offer_attribute_lrf_stg", "table_legacy_schema": "dae_code_raw_ingestion.acap_campaign_offer_attribute_lrf", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.acap_campaign_offer_attribute_lrf_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.3", "table_id": "T.19896.1", "table_name": "acap_campaign_vendor_lrf_stg", "table_schema": "staging__marketing__campaign.acap_campaign_vendor_lrf_stg", "table_legacy_schema": "dae_code_raw_ingestion.acap_campaign_vendor_lrf", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.acap_campaign_vendor_lrf_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.3", "table_id": "T.19897.1", "table_name": "campaign_contact_hist_stg", "table_schema": "staging__marketing__campaign.campaign_contact_hist_stg", "table_legacy_schema": "dae_code_raw_ingestion.campaign_contact_hist", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.campaign_contact_hist_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}, {"release": "7.1.3", "table_id": "T.19899.1", "table_name": "contact_hist_ora_reconcilaition_stg", "table_schema": "staging__marketing__campaign.contact_hist_ora_reconcilaition_stg", "table_legacy_schema": "dae_code_raw_ingestion.contact_hist_ora_reconcilaition", "table_domain": "marketing", "table_subdomain": "campaign", "table_location": "staging__marketing__campaign.contact_hist_ora_reconcilaition_stg", "table_partition": "", "table_db": "staging__marketing__campaign", "table_zone": "wrangled", "create_date": "2022-06-28 16:15:11", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
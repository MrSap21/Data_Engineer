# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__lookup_codes;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_dedup_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_dedup_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_new_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_new_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_new_assign_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_new_assign_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_persistent_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_persistent_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_reformat_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_reformat_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_unchanged_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_unchanged_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.dim_cd_updated_stg(
cd_key BIGINT,
cd_id BIGINT,
cd_ind STRING,
cd_name STRING,
cd_type STRING,
cd_category STRING,
cd_desc STRING,
start_date DATE,
end_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/dim_cd_updated_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__hr__lookup_codes.max_cd_key_stg(
cd_key INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_hr')}.dfs.core.windows.net/hr/lookup_codes/staging/max_cd_key_stg'""")
# COMMAND ----------
migration_data=[{"release": "8.1.5", "scripts": ["D.69.1.wrg.hr__lookup_codes.sql", "T.14857.1.wrg.dim_cd_dedup_stg.sql", "T.14858.1.wrg.dim_cd_new_stg.sql", "T.14859.1.wrg.dim_cd_new_assign_stg.sql", "T.14862.1.wrg.dim_cd_persistent_stg.sql", "T.14864.1.wrg.dim_cd_reformat_stg.sql", "T.14868.1.wrg.dim_cd_unchanged_stg.sql", "T.14869.1.wrg.dim_cd_updated_stg.sql", "T.15095.1.wrg.max_cd_key_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.1.5", "table_id": "T.14857.1", "table_name": "dim_cd_dedup_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_dedup_stg", "table_legacy_schema": "hr_work.dim_cd_dedup", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_dedup_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.5", "table_id": "T.14858.1", "table_name": "dim_cd_new_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_new_stg", "table_legacy_schema": "hr_work.dim_cd_new", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_new_stg", "table_partition": "", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.5", "table_id": "T.14859.1", "table_name": "dim_cd_new_assign_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_new_assign_stg", "table_legacy_schema": "hr_work.dim_cd_new_assign", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_new_assign_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.5", "table_id": "T.14862.1", "table_name": "dim_cd_persistent_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_persistent_stg", "table_legacy_schema": "hr_work.dim_cd_persistent", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_persistent_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.5", "table_id": "T.14864.1", "table_name": "dim_cd_reformat_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_reformat_stg", "table_legacy_schema": "hr_work.dim_cd_reformat", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_reformat_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.5", "table_id": "T.14868.1", "table_name": "dim_cd_unchanged_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_unchanged_stg", "table_legacy_schema": "hr_work.dim_cd_unchanged", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_unchanged_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.5", "table_id": "T.14869.1", "table_name": "dim_cd_updated_stg", "table_schema": "staging__hr__lookup_codes.dim_cd_updated_stg", "table_legacy_schema": "hr_work.dim_cd_updated", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.dim_cd_updated_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.5", "table_id": "T.15095.1", "table_name": "max_cd_key_stg", "table_schema": "staging__hr__lookup_codes.max_cd_key_stg", "table_legacy_schema": "hr_work.max_cd_key", "table_domain": "hr", "table_subdomain": "lookup_codes", "table_location": "staging__hr__lookup_codes.max_cd_key_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__hr__lookup_codes", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

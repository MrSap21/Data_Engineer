# Databricks notebook source
dbutils.widgets.text(name='STORAGE_ACCT_crt_hr', defaultValue='${STORAGE_ACCT_crt_hr}', label='STORAGE_ACCT_crt_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_finance', defaultValue='${STORAGE_ACCT_wrg_finance}', label='STORAGE_ACCT_wrg_finance')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_hr', defaultValue='${STORAGE_ACCT_wrg_hr}', label='STORAGE_ACCT_wrg_hr')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_retail', defaultValue='${STORAGE_ACCT_wrg_retail}', label='STORAGE_ACCT_wrg_retail')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__product;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__retail__product;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__finance__account_payables;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__employment_history;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS hr__recruiting;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__employment_history;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__payroll;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__hr__organization_structure;""")
# COMMAND ----------
migration_data=[{"release": "7.2.1", "scripts": ["D.31.1.crt.retail__product.sql", "D.46.1.wrg.retail__product.sql", "D.47.1.wrg.finance__account_payables.sql", "D.56.1.wrg.hr__recruiting.sql", "D.59.1.crt.hr__employment_history.sql", "D.60.1.crt.hr__payroll.sql", "D.63.1.crt.hr__recruiting.sql", "D.66.1.wrg.hr__employment_history.sql", "D.67.1.wrg.hr__payroll.sql", "D.68.1.wrg.hr__organization_structure.sql"], "migration_date": "2022-06-28"}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
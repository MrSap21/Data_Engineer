# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_crt_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_crt_pharmacy_healthcare}', label='STORAGE_ACCT_crt_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='pharmacy_healthcare_crt_sa', defaultValue='${pharmacy_healthcare_crt_sa}', label='pharmacy_healthcare_crt_sa')
dbutils.widgets.text(name='STORAGE_ACCT_crt_retail', defaultValue='${STORAGE_ACCT_crt_retail}', label='STORAGE_ACCT_crt_retail')
dbutils.widgets.text(name='retail_crt_sa', defaultValue='${retail_crt_sa}', label='retail_crt_sa')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__retail_sales;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS retail__promotions;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__promotions.ad_event_loyalty_promo(
ad_evt_id INT COMMENT 'ad_evt_id',
primary_wic_nbr DECIMAL(6,0) COMMENT 'primary wic DOUBLE',
ad_offer_cd STRING COMMENT 'ad offer code',
offer_seq_nbr DECIMAL(4,0) COMMENT 'offer sequence DOUBLE',
src_sys_cd STRING COMMENT 'source system code',
ad_loyalty_promo_sk BIGINT COMMENT 'ad loyalty promo sk',
loyalty_attrib_id INT COMMENT 'loyalty attribute identifier',
loyalty_attrib_val STRING COMMENT 'loyalty attribute value',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0) )
USING DELTA
LOCATION
'abfss://promotions-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ad_event_loyalty_promo'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__promotions.ad_loyalty_promo(
AD_LOYALTY_PROMO_SK BIGINT COMMENT 'AD LOYALTY PROMO SK',
AD_EVT_ID INT COMMENT 'AD_EVT_ID',
PRIMARY_WIC_NBR DECIMAL(6,0) COMMENT 'PRIMARY_WIC_NBR',
AD_OFFER_CD STRING COMMENT 'AD_OFFER CODE',
SRC_SYS_CD STRING COMMENT 'SOURCE SYSTEM CODE',
AD_EVT_SK BIGINT COMMENT 'AD_EVT_SK',
AD_OFFER_DESC STRING COMMENT 'AD_OFFER_DESC',
LOYALTY_TEMPLATE_TYPE STRING COMMENT 'LTY_TEMPLATE_TYPE',
RBT_FORM_IN STRING COMMENT 'REBATE_FORM_IN',
MATH_TBL_ALLOW_IND STRING COMMENT 'MATH_TABLE_ALLOW_IND',
AD_EVT_PRINT_IND_1 STRING COMMENT 'AD_EVT_PRINT_IND_1',
AD_EVT_PRINT_IND_2 STRING COMMENT 'AD_EVT_PRINT_IND_2',
AD_EVT_VER_ITEM_STAT STRING COMMENT 'AD_EVT_VER_ITEM_STATUS',
EVT_TYPE_FM STRING COMMENT 'EVT_TYPE_FROM',
EVT_SEQ_NBR_FM STRING COMMENT 'EVT_SEQ_NBR_FROM',
EVT_VER_TYPE_CD_FM STRING COMMENT 'EVT_VER_TYPE_CD_FROM',
EVT_VER_SEQ_NBR_FM STRING COMMENT 'EVT_VER_SEQ_NBR_FROM',
ITEM_LINK_GRP_CD STRING COMMENT 'ITEM_LINK_GRP_CD',
ITEM_LINK_GRP_NBR INT COMMENT 'ITEM_LINK_GRP_NBR',
ITEM_CMNT_NBR INT COMMENT 'ITEM_COMMENT_NBR',
ITEM_CMNT_NBR_2 INT COMMENT 'ITEM_COMMENT_NBR_2',
ITEM_CMNT_NBR_3 INT COMMENT 'ITEM_COMMENT_NBR_3',
ITEM_CMNT_NBR_4 INT COMMENT 'ITEM_COMMENT_NBR_4',
ITEM_CMNT_NBR_5 INT COMMENT 'ITEM_COMMENT_NBR_5',
ITEM_MODIFY_FLAG STRING COMMENT 'ITEM_MODIFY_FLAG',
PVT_BRAND_IND STRING COMMENT 'PRIVATE_BRAND_IND',
TGTED_CUST_FLAG STRING COMMENT 'TARGETED_CUST_FLAG',
SUBTYPE_VAL_1 STRING COMMENT 'SUBTYPE_VALUE_1',
SUBTYPE_VAL_2 STRING COMMENT 'SUBTYPE_VALUE_2',
SUBTYPE_VAL_3 STRING COMMENT 'SUBTYPE_VALUE_3',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'EDW_CREATE_DTTM',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'EDW_UPDATE_DTTM',
EDW_BATCH_ID DECIMAL(18,0) COMMENT 'EDW_BATCH_ID'
,delta_batch_id  DECIMAL(18,0) )
USING DELTA
LOCATION
'abfss://promotions-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ad_loyalty_promo'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__promotions.ad_week_chain_upc(
ad_wk_chain_upc_sk BIGINT COMMENT 'ad week chain upc sk',
ad_evt_id INT COMMENT 'ad_evt_id',
prod_id_1 STRING COMMENT 'product identifier 1',
prod_id_2 STRING COMMENT 'product identifier 2',
prod_id_3 STRING COMMENT 'product identifier 3',
prod_id_4 STRING COMMENT 'product identifier 4',
src_sys_cd STRING COMMENT 'source system code',
ad_wk_period_id DECIMAL(5,0) COMMENT 'ad week period identifier',
edw_rec_begin_dt DATE COMMENT 'edw record begin date{{"FORMAT":"YYYY/MM/DD" }}',
dim_upc_prod_sk BIGINT COMMENT 'dim upc product sk',
upc_prod_sk BIGINT COMMENT 'upc product sk',
mss_prod_id DECIMAL(10,0) COMMENT 'mss product identifier',
upc_nbr DECIMAL(14,0) COMMENT 'upc DOUBLE',
primary_wic_nbr DECIMAL(6,0) COMMENT 'primary_wic_nbr',
edw_rec_end_dt DATE COMMENT 'edw record end date{{"FORMAT":"YYYY/MM/DD" }}',
ad_position_cd STRING COMMENT 'ad position code',
ad_position_nbr SMALLINT COMMENT 'ad position DOUBLE',
ad_sz_cd STRING COMMENT 'ad size code',
ad_spot_nbr SMALLINT COMMENT 'ad spot DOUBLE',
ad_promo_type_cd STRING COMMENT 'ad promo type code',
ad_price_dlrs DECIMAL(7,2) COMMENT 'ad price dollars',
ad_redtn_dlrs DECIMAL(6,2) COMMENT 'ad reduction dollars',
ad_price_mult_nbr SMALLINT COMMENT 'ad price multiple DOUBLE',
ad_price_rule_cd TINYINT COMMENT 'ad price rule code',
ad_page_nbr SMALLINT COMMENT 'ad page DOUBLE',
ad_pct_off DECIMAL(3,1) COMMENT 'ad pct off',
ad_coupon_nbr DECIMAL(4,0) COMMENT 'ad coupon DOUBLE',
ad_bagb_link STRING COMMENT 'ad bagb link',
ad_roto_kicker_cd STRING COMMENT 'ad roto kicker code',
single_unit_rtl DECIMAL(8,2) COMMENT 'single unit retail',
item_explsn_cd STRING COMMENT 'item explosion code',
loc_type DECIMAL(7,0) COMMENT 'location type',
ad_offer_cd STRING COMMENT 'ad offer code',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://promotions-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ad_week_chain_upc'
PARTITIONED BY (
ad_wk_batch STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__promotions.ad_week_sales_type(
SALES_TYPE_CD INT COMMENT 'SALES TYPE CODE',
PROD_ID_1 STRING COMMENT 'PRODUCT IDENTIFIER 1',
PROD_ID_2 STRING COMMENT 'PRODUCT IDENTIFIER 2',
PROD_ID_3 STRING COMMENT 'PRODUCT IDENTIFIER 3',
PROD_ID_4 STRING COMMENT 'PRODUCT IDENTIFIER 4',
SRC_SYS_CD STRING COMMENT 'SOURCE SYSTEM CODE',
AD_WK_PERIOD_ID DECIMAL(5,0) COMMENT 'AD WEEK PERIOD IDENTIFIER',
AD_EVT_TYPE_ID INT COMMENT 'AD EVENT TYPE IDENTIFIER',
DIM_UPC_PROD_SK BIGINT COMMENT 'DIM UPC PRODUCT SK',
UPC_PROD_SK BIGINT COMMENT 'UPC PRODUCT SK',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'EDW CREATE TIMESTAMP',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'EDW UPDATE TIMESTAMP',
EDW_BATCH_ID DECIMAL(18,0) COMMENT 'EDW BATCH IDENTIFIER'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://promotions-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ad_week_sales_type'
PARTITIONED BY (
ad_wk_batch STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__promotions.ad_week_store_event(
AD_EVT_ID INT COMMENT 'AD_EVT_ID',
STR_NBR INT COMMENT 'STORE_NBR',
AD_WK_PERIOD_ID DECIMAL(5,0) COMMENT 'AD WEEK PERIOD IDENTIFIER',
AD_EVT_SK BIGINT COMMENT 'AD_EVT_SK',
DIM_LOC_STR_SK BIGINT COMMENT 'DIM_LOC_STORE_SK',
LOC_STR_SK BIGINT COMMENT 'LOC_STORE_SK',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'EDW_CREATE_DTTM',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'EDW_UPDATE_DTTM',
EDW_BATCH_ID DECIMAL(18,0) COMMENT 'EDW_BATCH_ID'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://promotions-bussnstv@{getArgument('retail_crt_sa')}.dfs.core.windows.net/ad_week_store_event'
PARTITIONED BY (
ad_wk_batch STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.tl_prescription_erx_msg_map(
icp_erx_msg_id STRING ,
str_nbr DECIMAL(38,0),
rx_nbr DECIMAL(38,0),
rx_create_dt DATE COMMENT '{{"FORMAT":"YYYY-MM-DD"}}',
epbr_erx_msg_id STRING ,
pbr_clinic_id STRING ,
erx_xml_image_id STRING ,
erx_msg_type_sent STRING ,
erx_msg_sent_dttm TIMESTAMP,
erx_msg_type_rcvd STRING ,
erx_msg_rcvd_dttm TIMESTAMP,
create_user_id DECIMAL(9,0),
update_user_id DECIMAL(9,0),
update_dttm TIMESTAMP,
edw_gg_commit_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0),
relocate_fm_str_nbr DECIMAL(38,0),
drug_schedule STRING ,
erx_pat_full_name STRING ,
erx_pat_address STRING ,
erx_pbr_full_name STRING ,
erx_pbr_address STRING ,
digital_sig_ind STRING ,
erx_del_cntrl_drug_nme STRING ,
erx_del_cntrl_drug_ndc STRING ,
erx_del_cntrl_drug_gpi STRING ,
erx_del_cntrl_pbr_id DECIMAL(11,0),
erx_msg_vndr_name STRING ,
erx_msg_vndr_app_name STRING ,
erx_msg_vndr_app_vers_name STRING ,
drug_coverage_stat_array_cd STRING ,
pbr_dgtl_sig_val_txt STRING ,
pbr_dgtl_sig_dgst_val_txt STRING ,
pbr_dgtl_sig_publ_key_txt STRING ,
wag_dgtl_sig_val_txt STRING ,
wag_dgtl_sig_publ_key_txt STRING ,
erx_app_exception_rslv_ind STRING ,
fac_1_id STRING ,
fac_1_id_qlfr STRING ,
fac_2_id STRING ,
fac_2_id_qlfr STRING ,
fac_3_id STRING ,
fac_3_id_qlfr STRING ,
create_dttm STRING,
erx_phrm_ncpdp_id STRING ,
erx_pbr_npi DECIMAL(10,0) ,
erx_pbr_ord_nbr STRING ,
erx_pbr_phone_nbr STRING ,
erx_pat_brth_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
erx_drug_desc STRING ,
erx_ndc STRING ,
erx_rx_sig STRING ,
erx_rx_written_dttm TIMESTAMP ,
erx_rx_note STRING ,
cancel_reqst_deny_reason_cd STRING ,
cancel_reqst_deny_reason_txt STRING ,
erx_overwrite_cmnt_ind STRING ,
erx_relate_to_msg_id STRING ,
erx_relate_to_msg_sent_dttm TIMESTAMP ,
erx_prev_dspn_ind STRING ,
cancel_reqst_response_type_cd STRING
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/tl_prescription_erx_msg_map'
PARTITIONED BY (
rx_create_yr STRING,
rx_create_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.tl_prescription_erx_msg_map_data_migration(
icp_erx_msg_id STRING ,
str_nbr DECIMAL(38,0),
rx_nbr DECIMAL(38,0),
rx_create_dt DATE COMMENT '{{"FORMAT":"YYYY-MM-DD"}}',
epbr_erx_msg_id STRING ,
pbr_clinic_id STRING ,
erx_xml_image_id STRING ,
erx_msg_type_sent STRING ,
erx_msg_sent_dttm TIMESTAMP,
erx_msg_type_rcvd STRING ,
erx_msg_rcvd_dttm TIMESTAMP,
create_user_id DECIMAL(9,0),
update_user_id DECIMAL(9,0),
update_dttm TIMESTAMP,
edw_gg_commit_dttm TIMESTAMP,
edw_batch_id DECIMAL(18,0),
relocate_fm_str_nbr DECIMAL(38,0),
drug_schedule STRING ,
erx_pat_full_name STRING ,
erx_pat_address STRING ,
erx_pbr_full_name STRING ,
erx_pbr_address STRING ,
digital_sig_ind STRING ,
erx_del_cntrl_drug_nme STRING ,
erx_del_cntrl_drug_ndc STRING ,
erx_del_cntrl_drug_gpi STRING ,
erx_del_cntrl_pbr_id DECIMAL(11,0),
erx_msg_vndr_name STRING ,
erx_msg_vndr_app_name STRING ,
erx_msg_vndr_app_vers_name STRING ,
drug_coverage_stat_array_cd STRING ,
pbr_dgtl_sig_val_txt STRING ,
pbr_dgtl_sig_dgst_val_txt STRING ,
pbr_dgtl_sig_publ_key_txt STRING ,
wag_dgtl_sig_val_txt STRING ,
wag_dgtl_sig_publ_key_txt STRING ,
erx_app_exception_rslv_ind STRING ,
fac_1_id STRING ,
fac_1_id_qlfr STRING ,
fac_2_id STRING ,
fac_2_id_qlfr STRING ,
fac_3_id STRING ,
fac_3_id_qlfr STRING ,
create_dttm STRING,
erx_phrm_ncpdp_id STRING ,
erx_pbr_npi DECIMAL(10,0) ,
erx_pbr_ord_nbr STRING ,
erx_pbr_phone_nbr STRING ,
erx_pat_brth_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd" }}' ,
erx_drug_desc STRING ,
erx_ndc STRING ,
erx_rx_sig STRING ,
erx_rx_written_dttm TIMESTAMP ,
erx_rx_note STRING ,
cancel_reqst_deny_reason_cd STRING ,
cancel_reqst_deny_reason_txt STRING ,
erx_overwrite_cmnt_ind STRING ,
erx_relate_to_msg_id STRING ,
erx_relate_to_msg_sent_dttm TIMESTAMP ,
erx_prev_dspn_ind STRING ,
cancel_reqst_response_type_cd STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/tl_prescription_erx_msg_map_data_migration'
PARTITIONED BY (
rx_create_yr STRING,
rx_create_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_cost_adj (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YY/MM/DD" }}',
sales_ord_src_type STRING COMMENT 'Sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
line_item_seq_nbr INT COMMENT 'line item sequence DOUBLE',
adj_cd STRING COMMENT 'adj_cd',
adj_dlrs DECIMAL(8,2) COMMENT 'adj_dlrs',
loyalty_adj_dlrs DECIMAL(8,2) COMMENT 'loyalty_adj_dlrs',
cost_type_cd STRING COMMENT 'cost_type_cd',
create_dttm TIMESTAMP COMMENT 'create_dttm',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-phi@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_cost_adj'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_cost_dtl (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"YY/MM/DD" }}',
sales_ord_src_type STRING COMMENT 'Sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
line_item_seq_nbr INT COMMENT 'line item sequence DOUBLE',
cost_type_cd STRING COMMENT 'cost_type_cd',
cost_dlrs DECIMAL(8,2) COMMENT 'cost_dlrs',
cost_src_type_cd STRING COMMENT 'cost_src_type_cd',
create_dttm TIMESTAMP COMMENT 'create_dttm',
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-phi@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_cost_dtl'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS retail__retail_sales.sales_transaction_otuc (
sales_txn_id STRING COMMENT 'sales_txn_id',
sales_txn_dt DATE COMMENT 'sales_txn_date{{"FORMAT":"yyyy-mm-dd" }}',
sales_ord_src_type STRING COMMENT 'sales order source type',
sales_txn_type STRING COMMENT 'sales_txn type',
src_sys_cd STRING COMMENT 'sales_txn source system code',
line_item_seq_nbr INT COMMENT 'line item sequence DOUBLE',
line_item_dtl_nbr DECIMAL(38,0) COMMENT 'line item detail DOUBLE from next gen pos' ,
plu_nbr DECIMAL(4,0) COMMENT 'plu DOUBLE',
one_tm_use_coupon_barcode STRING COMMENT 'one time use coupon barcode',
entry_mode_cd STRING COMMENT 'entry_mode_code',
basket_lvl_cd STRING COMMENT 'basket level code' ,
EDW_CREATE_DTTM TIMESTAMP COMMENT 'edw CREATE datetime',
EDW_UPDATE_DTTM TIMESTAMP COMMENT 'edw update datetime',
edw_batch_id DECIMAL(18,0) COMMENT 'edw batch identifier'
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://retail-sales-phi@{getArgument('retail_crt_sa')}.dfs.core.windows.net/sales_transaction_otuc'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS pharmacy_healthcare__patient_services.tl_prescription_madr_queue (
EDW_BATCH_ID DECIMAL(18,0),
STORE_NBR INT,
RX_NBR INT,
RX_FILL_NBR INT,
RX_PARTIAL_FILL_NBR INT,
DSPN_FILL_NBR INT,
MADR_STATUS_CD STRING,
MADR_RULES_PASSED STRING ,
MADR_RULES_FAILED STRING ,
MADR_PULLBACK_DTTM TIMESTAMP,
MADR_FAILURE_REASON_CD STRING ,
SEND_TO_REMOTE_IND STRING ,
RX_TYPE_CD STRING,
ML_RELEVANT_CATEGORIES STRING ,
ML_CONFIDENCE_SCORES STRING ,
DAILY_DOSAGE DECIMAL(10,5),
SINGLE_DOSE DECIMAL(10,5),
SIG_ADMIN_TIME STRING ,
SIG_INDICATION STRING ,
SIG_ROA_VALUE STRING ,
QUALITY_ALERT_IND STRING ,
PBR_STATUS_CD STRING ,
PBR_ID DECIMAL(11,0),
NEW_TO_THERAPY_IND STRING ,
SRC_UPDATE_USER_ID INT,
SRC_UPDATE_DTTM TIMESTAMP,
SRC_CREATE_USER_ID DECIMAL(9,0),
SRC_CREATE_DTTM TIMESTAMP,
SRC_CREATE_DT STRING
,delta_batch_id  DECIMAL(18,0))
USING DELTA
LOCATION
'abfss://patient-services-phi@{getArgument('pharmacy_healthcare_crt_sa')}.dfs.core.windows.net/tl_prescription_madr_queue'""")
# COMMAND ----------
migration_data=[{"release": "8.1.0", "scripts": ["D.6.1.crt.pharmacy_healthcare__patient_services.sql", "D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "D.3.1.crt.retail__promotions.sql", "D.16.1.crt.retail__retail_sales.sql", "T.1888.1.crt.tl_prescription_erx_msg_map.sql", "T.19942.1.wrg.tl_prescription_erx_msg_map_data_migration.sql", "T.116.1.crt.ad_event_loyalty_promo.sql", "T.118.1.crt.ad_loyalty_promo.sql", "T.119.1.crt.ad_week_chain_upc.sql", "T.122.1.crt.ad_week_sales_type.sql", "T.125.1.crt.ad_week_store_event.sql", "T.19963.1.crt.sales_transaction_cost_adj.sql", "T.19963.1.crt.sales_transaction_otuc.sql", "T.19963.1.crt.sales_transaction_cost_dtl.sql", "T.19963.1.crt.tl_prescription_madr_queue.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.1.0", "table_id": "T.1888.1", "table_name": "tl_prescription_erx_msg_map", "table_schema": "pharmacy_healthcare__patient_services.tl_prescription_erx_msg_map", "table_legacy_schema": "dae_cooked.tl_prescription_erx_msg_map", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.tl_prescription_erx_msg_map", "table_partition": "\n  rx_create_yr STRING, \n  rx_create_mnth STRING", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.19942.1", "table_name": "tl_prescription_erx_msg_map_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.tl_prescription_erx_msg_map_data_migration", "table_legacy_schema": "", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.tl_prescription_erx_msg_map_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.116.1", "table_name": "ad_event_loyalty_promo", "table_schema": "retail__promotions.ad_event_loyalty_promo", "table_legacy_schema": "acapdb.ad_event_loyalty_promo", "table_domain": "retail", "table_subdomain": "promotions", "table_location": "retail__promotions.ad_event_loyalty_promo", "table_partition": "", "table_db": "retail__promotions", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.118.1", "table_name": "ad_loyalty_promo", "table_schema": "retail__promotions.ad_loyalty_promo", "table_legacy_schema": "acapdb.ad_loyalty_promo", "table_domain": "retail", "table_subdomain": "promotions", "table_location": "retail__promotions.ad_loyalty_promo", "table_partition": "", "table_db": "retail__promotions", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.119.1", "table_name": "ad_week_chain_upc", "table_schema": "retail__promotions.ad_week_chain_upc", "table_legacy_schema": "acapdb.ad_week_chain_upc", "table_domain": "retail", "table_subdomain": "promotions", "table_location": "retail__promotions.ad_week_chain_upc", "table_partition": "\n  ad_wk_batch STRING", "table_db": "retail__promotions", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.122.1", "table_name": "ad_week_sales_type", "table_schema": "retail__promotions.ad_week_sales_type", "table_legacy_schema": "acapdb.ad_week_sales_type", "table_domain": "retail", "table_subdomain": "promotions", "table_location": "retail__promotions.ad_week_sales_type", "table_partition": "\n  ad_wk_batch STRING", "table_db": "retail__promotions", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.125.1", "table_name": "ad_week_store_event", "table_schema": "retail__promotions.ad_week_store_event", "table_legacy_schema": "acapdb.ad_week_store_event", "table_domain": "retail", "table_subdomain": "promotions", "table_location": "retail__promotions.ad_week_store_event", "table_partition": "\n  ad_wk_batch STRING", "table_db": "retail__promotions", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.19963.1", "table_name": "sales_transaction_cost_adj", "table_schema": "retail__retail_sales.sales_transaction_cost_adj", "table_legacy_schema": "SNOWFLAKE", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_cost_adj", "table_partition": "", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.19963.1", "table_name": "sales_transaction_otuc", "table_schema": "retail__retail_sales.sales_transaction_otuc", "table_legacy_schema": "SNOWFLAKE", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_otuc", "table_partition": "", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.19963.1", "table_name": "sales_transaction_cost_dtl", "table_schema": "retail__retail_sales.sales_transaction_cost_dtl", "table_legacy_schema": "SNOWFLAKE", "table_domain": "retail", "table_subdomain": "retail_sales", "table_location": "retail__retail_sales.sales_transaction_cost_dtl", "table_partition": "", "table_db": "retail__retail_sales", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}, {"release": "8.1.0", "table_id": "T.19963.1", "table_name": "tl_prescription_madr_queue", "table_schema": "pharmacy_healthcare__patient_services.tl_prescription_madr_queue", "table_legacy_schema": "SNOWFLAKE", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "pharmacy_healthcare__patient_services.tl_prescription_madr_queue", "table_partition": "", "table_db": "pharmacy_healthcare__patient_services", "table_zone": "curated", "create_date": "2022-08-10 11:49:52", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;

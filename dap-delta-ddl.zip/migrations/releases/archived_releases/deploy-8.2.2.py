# Databricks notebook source 
dbutils.widgets.text(name='STORAGE_ACCT_wrg_pharmacy_healthcare', defaultValue='${STORAGE_ACCT_wrg_pharmacy_healthcare}', label='STORAGE_ACCT_wrg_pharmacy_healthcare')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_digital', defaultValue='${STORAGE_ACCT_wrg_digital}', label='STORAGE_ACCT_wrg_digital')
dbutils.widgets.text(name='STORAGE_ACCT_wrg_partner_extracts', defaultValue='${STORAGE_ACCT_wrg_partner_extracts}', label='STORAGE_ACCT_wrg_partner_extracts')
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__pharmacy_healthcare__patient_services;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare;""")
# COMMAND ----------
spark.sql(f"""CREATE SCHEMA IF NOT EXISTS staging__digital__ecom;""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_insert_records_stg(
store_nbr INT,
rx_nbr INT,
pat_id DECIMAL(13,0),
rx_fill_nbr INT,
dspn_fill_nbr SMALLINT,
image_id STRING,
drug_mme DECIMAL(5,1),
work_list_stat STRING,
rx_gfd_notes STRING,
work_list_nbr DECIMAL(10,0),
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
pbr_last_name STRING,
pbr_first_name STRING,
drug_name STRING,
rx_written_dttm STRING,
gfd_ws_orig_ind STRING,
rules_triggered STRING,
edw_batch_id DECIMAL(18,0),
src_create_mnth STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/rx_gfd_work_sheet_insert_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_pre_cdc_stg(
store_nbr INT,
rx_nbr INT,
pat_id DECIMAL(13,0),
rx_fill_nbr INT,
dspn_fill_nbr SMALLINT,
image_id STRING,
drug_mme DECIMAL(5,1),
work_list_stat STRING,
rx_gfd_notes STRING,
work_list_nbr DECIMAL(10,0),
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
pbr_last_name STRING,
pbr_first_name STRING,
drug_name STRING,
rx_written_dttm STRING,
gfd_ws_orig_ind STRING,
rules_triggered STRING,
edw_batch_id DECIMAL(18,0),
src_create_mnth STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/rx_gfd_work_sheet_pre_cdc_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_retained_records_stg(
store_nbr INT,
rx_nbr INT,
pat_id DECIMAL(13,0),
rx_fill_nbr INT,
dspn_fill_nbr SMALLINT,
image_id STRING,
drug_mme DECIMAL(5,1),
work_list_stat STRING,
rx_gfd_notes STRING,
work_list_nbr DECIMAL(10,0),
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
pbr_last_name STRING,
pbr_first_name STRING,
drug_name STRING,
rx_written_dttm STRING,
gfd_ws_orig_ind STRING,
rules_triggered STRING,
edw_batch_id DECIMAL(18,0),
src_create_mnth STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/rx_gfd_work_sheet_retained_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_update_records_stg(
store_nbr INT,
rx_nbr INT,
pat_id DECIMAL(13,0),
rx_fill_nbr INT,
dspn_fill_nbr SMALLINT,
image_id STRING,
drug_mme DECIMAL(5,1),
work_list_stat STRING,
rx_gfd_notes STRING,
work_list_nbr DECIMAL(10,0),
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
pbr_last_name STRING,
pbr_first_name STRING,
drug_name STRING,
rx_written_dttm STRING,
gfd_ws_orig_ind STRING,
rules_triggered STRING,
edw_batch_id DECIMAL(18,0),
src_create_mnth STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/rx_gfd_work_sheet_update_records_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_proc_test_store_stg(
store_nbr DECIMAL(5,0))
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_proc_test_store_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id STRING,
store_nbr STRING,
rx_nbr STRING,
pat_id STRING,
rx_fill_nbr STRING,
dspn_fill_nbr STRING,
image_id STRING,
drug_mme STRING,
work_list_stat STRING,
rx_gfd_notes STRING,
work_list_nbr STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING,
pbr_last_name STRING,
pbr_first_name STRING,
drug_name STRING,
rx_written_dttm STRING,
gfd_ws_orig_ind STRING,
rules_triggered STRING,
store_nbr_bkp STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_stg'
PARTITIONED BY (
src_create_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_de_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr INT,
cdc_rba_nbr DECIMAL(18,0),
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id DECIMAL(18,0),
store_nbr INT,
rx_nbr INT,
pat_id DECIMAL(13,0),
rx_fill_nbr INT,
dspn_fill_nbr SMALLINT,
image_id STRING,
drug_mme DECIMAL(5,1),
work_list_stat STRING,
rx_gfd_notes STRING,
work_list_nbr DECIMAL(10,0),
src_create_user_id DECIMAL(9,0),
src_create_dttm STRING,
src_update_user_id DECIMAL(9,0),
src_update_dttm STRING,
pbr_last_name STRING,
pbr_first_name STRING,
drug_name STRING,
rx_written_dttm STRING,
gfd_ws_orig_ind STRING,
rules_triggered STRING,
store_nbr_bkp INT)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_de_stg'
PARTITIONED BY (
src_create_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__partner_extracts__pharmacy_healthcare.satr_closed_store_list_stg(
from_store_nbr INT,
to_store_nbr INT,
tracking_id STRING,
srcfilename STRING,
ingestion_date DATE)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_partner_extracts')}.dfs.core.windows.net/partner_extracts/pharmacy_healthcare/staging/satr_closed_store_list_stg'
PARTITIONED BY (
ingestion_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.tl_prescription_close_log_data_migration(
xfer_fm_rx_nbr INT,
xfer_fm_str_nbr INT,
rx_create_dt DATE COMMENT '{{"FORMAT":"yyyy-mm-dd"}}',
xfer_to_rx_nbr INT ,
xfer_to_str_nbr INT ,
xfer_to_competitor_str_name STRING ,
close_reason_cd STRING ,
close_reason_cmnt STRING ,
xfer_fm_rph_initials STRING ,
xfer_to_rph_initials STRING ,
xfer_to_competitor_area_cd STRING ,
xfer_to_competitor_phone_nbr STRING ,
rx_xfer_close_reason_cd STRING ,
relocate_fm_str_nbr INT,
create_user_id DECIMAL(9,0) ,
edw_batch_id DECIMAL(18,0) ,
update_user_id DECIMAL(9,0) ,
update_dttm TIMESTAMP,
src_partition_nbr TINYINT ,
close_log_create_dttm TIMESTAMP,
xfer_to_rph_first_name STRING ,
xfer_to_rph_last_name STRING ,
xfer_to_phrm_dea_nbr STRING ,
xfer_to_competitor_addr_line STRING ,
xfer_to_competitor_city STRING ,
xfer_to_competitor_state_cd STRING ,
xfer_to_competitor_zip_cd_5 STRING ,
xfer_to_competitor_zip_cd_4 STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/tl_prescription_close_log_data_migration'
PARTITIONED BY (
rx_create_yr STRING,
rx_create_yrmnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__digital__ecom.sms_message_details_seq_stg(
messagedirection STRING COMMENT 'FROM deserializer',
message_id STRING COMMENT 'FROM deserializer',
client_id STRING COMMENT 'FROM deserializer',
client_name STRING COMMENT 'FROM deserializer',
carrier_id STRING COMMENT 'FROM deserializer',
carrier_name STRING COMMENT 'FROM deserializer',
short_code STRING COMMENT 'FROM deserializer',
country_code STRING COMMENT 'FROM deserializer',
phonenumber STRING COMMENT 'FROM deserializer',
campaigntype_id STRING COMMENT 'FROM deserializer',
campaigntypename STRING COMMENT 'FROM deserializer',
trigger_id STRING COMMENT 'FROM deserializer',
campaign_id STRING COMMENT 'FROM deserializer',
campaignname STRING COMMENT 'FROM deserializer',
clienttag STRING COMMENT 'FROM deserializer',
messagetext STRING COMMENT 'FROM deserializer',
status_id STRING COMMENT 'FROM deserializer',
statusdescription STRING COMMENT 'FROM deserializer',
detailedstatusid STRING COMMENT 'FROM deserializer',
detailedstatusdescription STRING COMMENT 'FROM deserializer',
submitted_date STRING COMMENT 'FROM deserializer')
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_digital')}.dfs.core.windows.net/digital/ecom/staging/sms_message_details_seq_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_gfd_work_sheet_dtl_stg(
cdc_txn_commit_dttm STRING COMMENT 'FROM deserializer',
cdc_txn_commit_dttm_after STRING COMMENT 'FROM deserializer',
cdc_seq_nbr STRING COMMENT 'FROM deserializer',
cdc_seq_nbr_after STRING COMMENT 'FROM deserializer',
cdc_rba_nbr STRING COMMENT 'FROM deserializer',
cdc_rba_nbr_after STRING COMMENT 'FROM deserializer',
cdc_operation_type_cd STRING COMMENT 'FROM deserializer',
cdc_operation_type_cd_after STRING COMMENT 'FROM deserializer',
cdc_before_after_cd STRING COMMENT 'FROM deserializer',
cdc_before_after_cd_after STRING COMMENT 'FROM deserializer',
cdc_txn_position_cd STRING COMMENT 'FROM deserializer',
cdc_txn_position_cd_after STRING COMMENT 'FROM deserializer',
edw_batch_id STRING COMMENT 'FROM deserializer',
edw_batch_id_after STRING COMMENT 'FROM deserializer',
work_list_nbr STRING COMMENT 'FROM deserializer',
work_list_nbr_after STRING COMMENT 'FROM deserializer',
pat_id STRING COMMENT 'FROM deserializer',
pat_id_after STRING COMMENT 'FROM deserializer',
rx_gfd_list_nbr STRING COMMENT 'FROM deserializer',
rx_gfd_list_nbr_after STRING COMMENT 'FROM deserializer',
rx_gfd_cd STRING COMMENT 'FROM deserializer',
rx_gfd_cd_after STRING COMMENT 'FROM deserializer',
rx_gfd_comments STRING COMMENT 'FROM deserializer',
rx_gfd_comments_after STRING COMMENT 'FROM deserializer',
src_create_user_id STRING COMMENT 'FROM deserializer',
src_create_user_id_after STRING COMMENT 'FROM deserializer',
src_create_dttm STRING COMMENT 'FROM deserializer',
src_create_dttm_after STRING COMMENT 'FROM deserializer',
src_update_user_id STRING COMMENT 'FROM deserializer',
src_update_user_id_after STRING COMMENT 'FROM deserializer',
src_update_dttm STRING COMMENT 'FROM deserializer',
src_update_dttm_after STRING COMMENT 'FROM deserializer',
tracking_id STRING COMMENT 'FROM deserializer')
USING DELTA
LOCATION 'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_rx_gfd_work_sheet_dtl_stg'
PARTITIONED BY (
partition_column STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_rx_gfd_work_sheet_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id STRING,
store_nbr STRING,
rx_nbr STRING,
pat_id STRING,
rx_fill_nbr STRING,
dspn_fill_nbr STRING,
image_id STRING,
drug_mme STRING,
work_list_stat STRING,
rx_gfd_notes STRING,
work_list_nbr STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING,
pbr_last_name STRING,
pbr_first_name STRING,
drug_name STRING,
rx_written_dttm STRING,
gfd_ws_orig_ind STRING,
rules_triggered STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/cons_etl_tbf0_rx_gfd_work_sheet_stg'
PARTITIONED BY (
src_create_mnth STRING)""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.etl_tbf0_rx_gfd_work_sheet_stg(
cdc_txn_commit_dttm STRING,
cdc_seq_nbr STRING,
cdc_rba_nbr STRING,
cdc_operation_type_cd STRING,
cdc_before_after_cd STRING,
cdc_txn_position_cd STRING,
edw_batch_id STRING,
store_nbr STRING,
rx_nbr STRING,
pat_id STRING,
rx_fill_nbr STRING,
dspn_fill_nbr STRING,
image_id STRING,
drug_mme STRING,
work_list_stat STRING,
rx_gfd_notes STRING,
work_list_nbr STRING,
src_create_user_id STRING,
src_create_dttm STRING,
src_update_user_id STRING,
src_update_dttm STRING,
pbr_last_name STRING,
pbr_first_name STRING,
drug_name STRING,
rx_written_dttm STRING,
gfd_ws_orig_ind STRING,
rules_triggered STRING,
tracking_id STRING,
partition_column STRING)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/etl_tbf0_rx_gfd_work_sheet_stg'""")
# COMMAND ----------
spark.sql(f"""CREATE TABLE IF NOT EXISTS staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_gfd_work_sheet_stg (
cdc_txn_commit_dttm string,
cdc_txn_commit_dttm_after string,
cdc_seq_nbr string,
cdc_seq_nbr_after string,
cdc_rba_nbr string,
cdc_rba_nbr_after string,
cdc_operation_type_cd string,
cdc_operation_type_cd_after string,
cdc_before_after_cd string,
cdc_before_after_cd_after string,
cdc_txn_position_cd string,
cdc_txn_position_cd_after string,
edw_batch_id string,
edw_batch_id_after string,
store_nbr string,
store_nbr_after string,
rx_nbr string,
rx_nbr_after string,
pat_id string,
pat_id_after string,
rx_fill_nbr string,
rx_fill_nbr_after string,
dspn_fill_nbr string,
dspn_fill_nbr_after string,
image_id string,
image_id_after string,
drug_mme string,
drug_mme_after string,
work_list_stat string,
work_list_stat_after string,
rx_gfd_notes string,
rx_gfd_notes_after string,
work_list_nbr string,
work_list_nbr_after string,
src_create_user_id string,
src_create_user_id_after string,
src_create_dttm string,
src_create_dttm_after string,
src_update_user_id string,
src_update_user_id_after string,
src_update_dttm string,
src_update_dttm_after string,
pbr_last_name string,
pbr_last_name_after string,
pbr_first_name string,
pbr_first_name_after string,
drug_name string,
drug_name_after string,
rx_written_dttm string,
rx_written_dttm_after string,
gfd_ws_orig_ind string,
gfd_ws_orig_ind_after string,
rules_triggered string,
rules_triggered_after string,
tracking_id string)
USING DELTA
LOCATION
'abfss://wrangled@{getArgument('STORAGE_ACCT_wrg_pharmacy_healthcare')}.dfs.core.windows.net/pharmacy_healthcare/patient_services/staging/gg_tbf0_rx_gfd_work_sheet_stg'
PARTITIONED BY (
partition_column string)""")
# COMMAND ----------
migration_data=[{"release": "8.2.2", "scripts": ["D.24.1.wrg.pharmacy_healthcare__patient_services.sql", "D.39.1.wrg.partner_extracts__pharmacy_healthcare.sql", "D.54.1.wrg.digital__ecom.sql", "T.10981.1.wrg.rx_gfd_work_sheet_insert_records_stg.sql", "T.10984.1.wrg.rx_gfd_work_sheet_pre_cdc_stg.sql", "T.10990.1.wrg.rx_gfd_work_sheet_retained_records_stg.sql", "T.10996.1.wrg.rx_gfd_work_sheet_update_records_stg.sql", "T.13384.1.wrg.wrk_rxo_etl_proc_test_store_stg.sql", "T.13706.1.wrg.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_stg.sql", "T.13708.1.wrg.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_de_stg.sql", "T.19736.1.wrg.satr_closed_store_list_stg.sql", "T.19923.1.wrg.tl_prescription_close_log_data_migration.sql", "T.19977.1.wrg.sms_message_details_seq_stg.sql", "T.19978.1.wrg.gg_tbf0_rx_gfd_work_sheet_dtl_stg.sql", "T.7452.1.wrg.cons_etl_tbf0_rx_gfd_work_sheet_stg.sql", "T.820.1.wrg.etl_tbf0_rx_gfd_work_sheet_stg.sql", "T.946.1.wrg.gg_tbf0_rx_gfd_work_sheet_stg.sql"], "migration_date": "2022-08-10"}]
table_data=[{"release": "8.2.2", "table_id": "T.10981.1", "table_name": "rx_gfd_work_sheet_insert_records_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_insert_records_stg", "table_legacy_schema": "dae_work.rx_gfd_work_sheet_insert_records", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_insert_records_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.10984.1", "table_name": "rx_gfd_work_sheet_pre_cdc_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_pre_cdc_stg", "table_legacy_schema": "dae_work.rx_gfd_work_sheet_pre_cdc", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_pre_cdc_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.10990.1", "table_name": "rx_gfd_work_sheet_retained_records_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_retained_records_stg", "table_legacy_schema": "dae_work.rx_gfd_work_sheet_retained_records", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_retained_records_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.10996.1", "table_name": "rx_gfd_work_sheet_update_records_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_update_records_stg", "table_legacy_schema": "dae_work.rx_gfd_work_sheet_update_records", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.rx_gfd_work_sheet_update_records_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.13384.1", "table_name": "wrk_rxo_etl_proc_test_store_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_proc_test_store_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_proc_test_store", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_proc_test_store_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.13706.1", "table_name": "wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.13708.1", "table_name": "wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_de_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_de_stg", "table_legacy_schema": "dae_work.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_de", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.wrk_rxo_etl_tbf0_rx_gfd_work_sheet_prep_de_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.19736.1", "table_name": "satr_closed_store_list_stg", "table_schema": "staging__partner_extracts__pharmacy_healthcare.satr_closed_store_list_stg", "table_legacy_schema": "dae_raw.satr_closed_store_list", "table_domain": "partner_extracts", "table_subdomain": "pharmacy_healthcare", "table_location": "staging__partner_extracts__pharmacy_healthcare.satr_closed_store_list_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__partner_extracts__pharmacy_healthcare", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.19923.1", "table_name": "tl_prescription_close_log_data_migration", "table_schema": "staging__pharmacy_healthcare__patient_services.tl_prescription_close_log_data_migration", "table_legacy_schema": "dae_cooked.tl_prescription_close_log", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.tl_prescription_close_log_data_migration", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.19977.1", "table_name": "sms_message_details_seq_stg", "table_schema": "staging__digital__ecom.sms_message_details_seq_stg", "table_legacy_schema": "acapetldb.sms_message_details_seq", "table_domain": "digital", "table_subdomain": "ecom", "table_location": "staging__digital__ecom.sms_message_details_seq_stg", "table_partition": "", "table_db": "staging__digital__ecom", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.19978.1", "table_name": "gg_tbf0_rx_gfd_work_sheet_dtl_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_gfd_work_sheet_dtl_stg", "table_legacy_schema": "dae_code_raw_ingestion.gg_tbf0_rx_gfd_work_sheet_dtl", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_gfd_work_sheet_dtl_stg", "table_partition": "", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.7452.1", "table_name": "cons_etl_tbf0_rx_gfd_work_sheet_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_rx_gfd_work_sheet_stg", "table_legacy_schema": "dae_work.cons_etl_tbf0_rx_gfd_work_sheet", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.cons_etl_tbf0_rx_gfd_work_sheet_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.820.1", "table_name": "etl_tbf0_rx_gfd_work_sheet_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.etl_tbf0_rx_gfd_work_sheet_stg", "table_legacy_schema": "dae_code_etl.etl_tbf0_rx_gfd_work_sheet", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.etl_tbf0_rx_gfd_work_sheet_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}, {"release": "8.2.2", "table_id": "T.946.1", "table_name": "gg_tbf0_rx_gfd_work_sheet_stg", "table_schema": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_gfd_work_sheet_stg", "table_legacy_schema": "dae_code_raw_ingestion.gg_tbf0_rx_gfd_work_sheet", "table_domain": "pharmacy_healthcare", "table_subdomain": "patient_services", "table_location": "staging__pharmacy_healthcare__patient_services.gg_tbf0_rx_gfd_work_sheet_stg", "table_partition": "\n  wo_complete_dt_bus_wk_sk INT", "table_db": "staging__pharmacy_healthcare__patient_services", "table_zone": "wrangled", "create_date": "2022-08-10 11:49:53", "update_date": ""}]
# COMMAND ----------
df_migrations = spark.createDataFrame(data=migration_data)
df_tables = spark.createDataFrame(data=table_data)
df_migrations.createOrReplaceTempView("temp_migrations") 
df_tables.createOrReplaceTempView("temp_tables") 
# COMMAND ----------
%sql
MERGE INTO master_data__information_schema.databricks_migrations ddl
    USING temp_migrations new
    ON ddl.release = new.release
WHEN MATCHED THEN
    UPDATE SET ddl.scripts = new.scripts, ddl.migration_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
# COMMAND ----------
%sql
MERGE INTO  master_data__information_schema.databricks_tables ddl
    USING temp_tables new
    ON ddl.table_id = new.table_id AND ddl.table_name = new.table_name
WHEN MATCHED THEN
    UPDATE SET
        ddl.table_schema = new.table_schema,
        ddl.table_db = new.table_db,
        ddl.table_domain = new.table_domain,
        ddl.table_subdomain = new.table_subdomain,
        ddl.table_location = new.table_location,
        ddl.table_partition = new.table_partition,
        ddl.table_zone = new.table_zone,
        ddl.update_date = current_timestamp()
WHEN NOT MATCHED THEN
    INSERT *
;
